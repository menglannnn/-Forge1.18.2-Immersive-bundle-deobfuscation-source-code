/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.time.Duration;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.concurrent.CompletionStage;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.BooleanSupplier;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.LongConsumer;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.logging.Level;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CorePublisher;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.scheduler.Scheduler;
/*      */ import reactor.core.scheduler.Schedulers;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Metrics;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.concurrent.Queues;
/*      */ import reactor.util.context.Context;
/*      */ import reactor.util.context.ContextView;
/*      */ import reactor.util.function.Tuple2;
/*      */ import reactor.util.function.Tuple3;
/*      */ import reactor.util.function.Tuple4;
/*      */ import reactor.util.function.Tuple5;
/*      */ import reactor.util.function.Tuple6;
/*      */ import reactor.util.function.Tuple7;
/*      */ import reactor.util.function.Tuple8;
/*      */ import reactor.util.function.Tuples;
/*      */ import reactor.util.retry.Retry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Mono<T>
/*      */   implements CorePublisher<T>
/*      */ {
/*      */   public static <T> Mono<T> create(Consumer<MonoSink<T>> callback) {
/*  200 */     return onAssembly(new MonoCreate<>(callback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> defer(Supplier<? extends Mono<? extends T>> supplier) {
/*  216 */     return onAssembly(new MonoDefer<>(supplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> Mono<T> deferWithContext(Function<Context, ? extends Mono<? extends T>> contextualMonoFactory) {
/*  235 */     return deferContextual(view -> (Mono)contextualMonoFactory.apply(Context.of(view)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> deferContextual(Function<ContextView, ? extends Mono<? extends T>> contextualMonoFactory) {
/*  252 */     return onAssembly(new MonoDeferContextual<>(contextualMonoFactory));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Long> delay(Duration duration) {
/*  269 */     return delay(duration, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Long> delay(Duration duration, Scheduler timer) {
/*  286 */     return onAssembly(new MonoDelay(duration.toNanos(), TimeUnit.NANOSECONDS, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> empty() {
/*  300 */     return MonoEmpty.instance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> error(Throwable error) {
/*  315 */     return onAssembly(new MonoError<>(error));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> error(Supplier<? extends Throwable> errorSupplier) {
/*  331 */     return onAssembly(new MonoErrorSupplied<>(errorSupplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   @Deprecated
/*      */   public static <T> Mono<T> first(Mono<? extends T>... monos) {
/*  350 */     return firstWithSignal(monos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> Mono<T> first(Iterable<? extends Mono<? extends T>> monos) {
/*  368 */     return firstWithSignal(monos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Mono<T> firstWithSignal(Mono<? extends T>... monos) {
/*  385 */     return onAssembly(new MonoFirstWithSignal<>(monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> firstWithSignal(Iterable<? extends Mono<? extends T>> monos) {
/*  401 */     return onAssembly(new MonoFirstWithSignal<>(monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> firstWithValue(Iterable<? extends Mono<? extends T>> monos) {
/*  434 */     return onAssembly(new MonoFirstWithValue<>(monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> Mono<T> firstWithValue(Mono<? extends T> first, Mono<? extends T>... others) {
/*  471 */     if (first instanceof MonoFirstWithValue) {
/*      */       
/*  473 */       MonoFirstWithValue<T> a = (MonoFirstWithValue)first;
/*  474 */       Mono<T> result = a.firstValuedAdditionalSources(others);
/*  475 */       if (result != null) {
/*  476 */         return result;
/*      */       }
/*      */     } 
/*  479 */     return onAssembly(new MonoFirstWithValue<>(first, others));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> from(Publisher<? extends T> source) {
/*  500 */     if (source instanceof Mono) {
/*      */       
/*  502 */       Mono<T> casted = (Mono)source;
/*  503 */       return casted;
/*      */     } 
/*  505 */     if (source instanceof FluxSourceMono || source instanceof FluxSourceMonoFuseable) {
/*      */ 
/*      */       
/*  508 */       FluxFromMonoOperator<T, T> wrapper = (FluxFromMonoOperator)source;
/*      */       
/*  510 */       return (Mono)wrapper.source;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  515 */     Publisher<? extends T> publisher = source;
/*  516 */     return onAssembly(wrap((Publisher)publisher, true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromCallable(Callable<? extends T> supplier) {
/*  532 */     return onAssembly(new MonoCallable<>(supplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromCompletionStage(CompletionStage<? extends T> completionStage) {
/*  551 */     return onAssembly(new MonoCompletionStage<>(completionStage, false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromCompletionStage(Supplier<? extends CompletionStage<? extends T>> stageSupplier) {
/*  571 */     return defer(() -> onAssembly(new MonoCompletionStage(stageSupplier.get(), false)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <I> Mono<I> fromDirect(Publisher<? extends I> source) {
/*  593 */     if (source instanceof Mono) {
/*      */       
/*  595 */       Mono<I> m = (Mono)source;
/*  596 */       return m;
/*      */     } 
/*  598 */     if (source instanceof FluxSourceMono || source instanceof FluxSourceMonoFuseable) {
/*      */ 
/*      */       
/*  601 */       FluxFromMonoOperator<I, I> wrapper = (FluxFromMonoOperator)source;
/*      */       
/*  603 */       return (Mono)wrapper.source;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  608 */     Publisher<? extends I> publisher = source;
/*  609 */     return onAssembly(wrap((Publisher)publisher, false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromFuture(CompletableFuture<? extends T> future) {
/*  629 */     return fromFuture(future, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromFuture(CompletableFuture<? extends T> future, boolean suppressCancel) {
/*  647 */     return onAssembly(new MonoCompletionStage<>(future, suppressCancel));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromFuture(Supplier<? extends CompletableFuture<? extends T>> futureSupplier) {
/*  665 */     return fromFuture(futureSupplier, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromFuture(Supplier<? extends CompletableFuture<? extends T>> futureSupplier, boolean suppressCancel) {
/*  686 */     return defer(() -> onAssembly(new MonoCompletionStage(futureSupplier.get(), suppressCancel)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromRunnable(Runnable runnable) {
/*  702 */     return onAssembly(new MonoRunnable<>(runnable));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> fromSupplier(Supplier<? extends T> supplier) {
/*  718 */     return onAssembly(new MonoSupplier<>(supplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> ignoreElements(Publisher<T> source) {
/*  738 */     return onAssembly(new MonoIgnorePublisher<>(source));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> just(T data) {
/*  754 */     return onAssembly(new MonoJust<>(data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> justOrEmpty(@Nullable Optional<? extends T> data) {
/*  770 */     return (data != null && data.isPresent()) ? just(data.get()) : empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> justOrEmpty(@Nullable T data) {
/*  786 */     return (data != null) ? just(data) : empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<T> never() {
/*  801 */     return MonoNever.instance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<Boolean> sequenceEqual(Publisher<? extends T> source1, Publisher<? extends T> source2) {
/*  816 */     return sequenceEqual(source1, source2, equalsBiPredicate(), Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<Boolean> sequenceEqual(Publisher<? extends T> source1, Publisher<? extends T> source2, BiPredicate<? super T, ? super T> isEqual) {
/*  835 */     return sequenceEqual(source1, source2, isEqual, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Mono<Boolean> sequenceEqual(Publisher<? extends T> source1, Publisher<? extends T> source2, BiPredicate<? super T, ? super T> isEqual, int prefetch) {
/*  856 */     return onAssembly(new MonoSequenceEqual<>(source1, source2, isEqual, prefetch));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Mono<Context> subscriberContext() {
/*  871 */     return onAssembly(MonoCurrentContext.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, D> Mono<T> using(Callable<? extends D> resourceSupplier, Function<? super D, ? extends Mono<? extends T>> sourceSupplier, Consumer<? super D> resourceCleanup, boolean eager) {
/*  902 */     return onAssembly(new MonoUsing<>(resourceSupplier, sourceSupplier, resourceCleanup, eager));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, D> Mono<T> using(Callable<? extends D> resourceSupplier, Function<? super D, ? extends Mono<? extends T>> sourceSupplier, Consumer<? super D> resourceCleanup) {
/*  928 */     return using(resourceSupplier, sourceSupplier, resourceCleanup, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, D> Mono<T> usingWhen(Publisher<D> resourceSupplier, Function<? super D, ? extends Mono<? extends T>> resourceClosure, Function<? super D, ? extends Publisher<?>> asyncCleanup) {
/*  978 */     return usingWhen(resourceSupplier, resourceClosure, asyncCleanup, (res, error) -> (Publisher)asyncCleanup.apply(res), asyncCleanup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T, D> Mono<T> usingWhen(Publisher<D> resourceSupplier, Function<? super D, ? extends Mono<? extends T>> resourceClosure, Function<? super D, ? extends Publisher<?>> asyncComplete, BiFunction<? super D, ? super Throwable, ? extends Publisher<?>> asyncError, Function<? super D, ? extends Publisher<?>> asyncCancel) {
/* 1041 */     return onAssembly(new MonoUsingWhen<>(resourceSupplier, resourceClosure, asyncComplete, asyncError, asyncCancel));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Void> when(Publisher<?>... sources) {
/* 1057 */     if (sources.length == 0) {
/* 1058 */       return empty();
/*      */     }
/* 1060 */     if (sources.length == 1) {
/* 1061 */       return empty(sources[0]);
/*      */     }
/* 1063 */     return onAssembly(new MonoWhen(false, sources));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Void> when(Iterable<? extends Publisher<?>> sources) {
/* 1082 */     return onAssembly(new MonoWhen(false, sources));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Void> whenDelayError(Iterable<? extends Publisher<?>> sources) {
/* 1100 */     return onAssembly(new MonoWhen(true, sources));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Mono<Void> whenDelayError(Publisher<?>... sources) {
/* 1116 */     if (sources.length == 0) {
/* 1117 */       return empty();
/*      */     }
/* 1119 */     if (sources.length == 1) {
/* 1120 */       return empty(sources[0]);
/*      */     }
/* 1122 */     return onAssembly(new MonoWhen(true, sources));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2> Mono<Tuple2<T1, T2>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2) {
/* 1142 */     return zip(p1, p2, (BiFunction)Flux.tuple2Function());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, O> Mono<O> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, BiFunction<? super T1, ? super T2, ? extends O> combinator) {
/* 1166 */     return onAssembly(new MonoZip<>(false, (Publisher<? extends T1>)p1, (Publisher)p2, combinator));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3> Mono<Tuple3<T1, T2, T3>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3) {
/* 1189 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4> Mono<Tuple4<T1, T2, T3, T4>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4) {
/* 1217 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5> Mono<Tuple5<T1, T2, T3, T4, T5>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5) {
/* 1248 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6> Mono<Tuple6<T1, T2, T3, T4, T5, T6>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6) {
/* 1282 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6, T7> Mono<Tuple7<T1, T2, T3, T4, T5, T6, T7>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6, Mono<? extends T7> p7) {
/* 1319 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6, (Publisher)p7 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6, T7, T8> Mono<Tuple8<T1, T2, T3, T4, T5, T6, T7, T8>> zip(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6, Mono<? extends T7> p7, Mono<? extends T8> p8) {
/* 1359 */     return onAssembly(new MonoZip<>(false, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6, (Publisher)p7, (Publisher)p8 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Mono<R> zip(Iterable<? extends Mono<?>> monos, Function<? super Object[], ? extends R> combinator) {
/* 1380 */     return onAssembly(new MonoZip<>(false, combinator, (Iterable)monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Mono<R> zip(Function<? super Object[], ? extends R> combinator, Mono<?>... monos) {
/* 1399 */     if (monos.length == 0) {
/* 1400 */       return empty();
/*      */     }
/* 1402 */     if (monos.length == 1) {
/* 1403 */       return monos[0].map(d -> combinator.apply(new Object[] { d }));
/*      */     }
/* 1405 */     return onAssembly(new MonoZip<>(false, combinator, (Publisher<?>[])monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2> Mono<Tuple2<T1, T2>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2) {
/* 1427 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3> Mono<Tuple3<T1, T2, T3>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3) {
/* 1451 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4> Mono<Tuple4<T1, T2, T3, T4>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4) {
/* 1480 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5> Mono<Tuple5<T1, T2, T3, T4, T5>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5) {
/* 1511 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6> Mono<Tuple6<T1, T2, T3, T4, T5, T6>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6) {
/* 1546 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6, T7> Mono<Tuple7<T1, T2, T3, T4, T5, T6, T7>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6, Mono<? extends T7> p7) {
/* 1584 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6, (Publisher)p7 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T1, T2, T3, T4, T5, T6, T7, T8> Mono<Tuple8<T1, T2, T3, T4, T5, T6, T7, T8>> zipDelayError(Mono<? extends T1> p1, Mono<? extends T2> p2, Mono<? extends T3> p3, Mono<? extends T4> p4, Mono<? extends T5> p5, Mono<? extends T6> p6, Mono<? extends T7> p7, Mono<? extends T8> p8) {
/* 1625 */     return onAssembly(new MonoZip<>(true, a -> Tuples.fromArray((Object[])a), (Publisher<?>[])new Publisher[] { (Publisher)p1, (Publisher)p2, (Publisher)p3, (Publisher)p4, (Publisher)p5, (Publisher)p6, (Publisher)p7, (Publisher)p8 }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Mono<R> zipDelayError(Iterable<? extends Mono<?>> monos, Function<? super Object[], ? extends R> combinator) {
/* 1646 */     return onAssembly(new MonoZip<>(true, combinator, (Iterable)monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Mono<R> zipDelayError(Function<? super Object[], ? extends R> combinator, Mono<?>... monos) {
/* 1669 */     if (monos.length == 0) {
/* 1670 */       return empty();
/*      */     }
/* 1672 */     if (monos.length == 1) {
/* 1673 */       return monos[0].map(d -> combinator.apply(new Object[] { d }));
/*      */     }
/* 1675 */     return onAssembly(new MonoZip<>(true, combinator, (Publisher<?>[])monos));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <P> P as(Function<? super Mono<T>, P> transformer) {
/* 1697 */     return transformer.apply(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> and(Publisher<?> other) {
/* 1713 */     if (this instanceof MonoWhen) {
/* 1714 */       MonoWhen o = (MonoWhen)this;
/* 1715 */       Mono<Void> result = o.whenAdditionalSource(other);
/* 1716 */       if (result != null) {
/* 1717 */         return result;
/*      */       }
/*      */     } 
/*      */     
/* 1721 */     return when((Publisher<?>[])new Publisher[] { (Publisher)this, other });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public T block() {
/* 1740 */     BlockingMonoSubscriber<T> subscriber = new BlockingMonoSubscriber<>();
/* 1741 */     subscribe((Subscriber<? super T>)subscriber);
/* 1742 */     return subscriber.blockingGet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public T block(Duration timeout) {
/* 1764 */     BlockingMonoSubscriber<T> subscriber = new BlockingMonoSubscriber<>();
/* 1765 */     subscribe((Subscriber<? super T>)subscriber);
/* 1766 */     return subscriber.blockingGet(timeout.toNanos(), TimeUnit.NANOSECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<T> blockOptional() {
/* 1785 */     BlockingOptionalMonoSubscriber<T> subscriber = new BlockingOptionalMonoSubscriber<>();
/* 1786 */     subscribe((Subscriber<? super T>)subscriber);
/* 1787 */     return subscriber.blockingGet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<T> blockOptional(Duration timeout) {
/* 1810 */     BlockingOptionalMonoSubscriber<T> subscriber = new BlockingOptionalMonoSubscriber<>();
/* 1811 */     subscribe((Subscriber<? super T>)subscriber);
/* 1812 */     return subscriber.blockingGet(timeout.toNanos(), TimeUnit.NANOSECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E> Mono<E> cast(Class<E> clazz) {
/* 1827 */     Objects.requireNonNull(clazz, "clazz");
/* 1828 */     return map(clazz::cast);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache() {
/* 1846 */     return onAssembly(new MonoCacheTime<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache(Duration ttl) {
/* 1866 */     return cache(ttl, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache(Duration ttl, Scheduler timer) {
/* 1889 */     return onAssembly(new MonoCacheTime<>(this, ttl, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache(Function<? super T, Duration> ttlForValue, Function<Throwable, Duration> ttlForError, Supplier<Duration> ttlForEmpty) {
/* 1925 */     return cache(ttlForValue, ttlForError, ttlForEmpty, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cache(Function<? super T, Duration> ttlForValue, Function<Throwable, Duration> ttlForError, Supplier<Duration> ttlForEmpty, Scheduler timer) {
/* 1963 */     return onAssembly(new MonoCacheTime<>(this, ttlForValue, ttlForError, ttlForEmpty, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cacheInvalidateIf(Predicate<? super T> invalidationPredicate) {
/* 2051 */     return onAssembly(new MonoCacheInvalidateIf<>(this, invalidationPredicate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cacheInvalidateWhen(Function<? super T, Mono<Void>> invalidationTriggerGenerator) {
/* 2113 */     return onAssembly(new MonoCacheInvalidateWhen<>(this, invalidationTriggerGenerator, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cacheInvalidateWhen(Function<? super T, Mono<Void>> invalidationTriggerGenerator, Consumer<? super T> onInvalidate) {
/* 2177 */     return onAssembly(new MonoCacheInvalidateWhen<>(this, invalidationTriggerGenerator, onInvalidate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> cancelOn(Scheduler scheduler) {
/* 2193 */     return onAssembly(new MonoCancelOn<>(this, scheduler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> checkpoint() {
/* 2212 */     return checkpoint(null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> checkpoint(String description) {
/* 2237 */     return checkpoint(Objects.<String>requireNonNull(description), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> checkpoint(@Nullable String description, boolean forceStackTrace) {
/*      */     FluxOnAssembly.AssemblySnapshot stacktrace;
/* 2273 */     if (!forceStackTrace) {
/* 2274 */       stacktrace = new FluxOnAssembly.CheckpointLightSnapshot(description);
/*      */     } else {
/*      */       
/* 2277 */       stacktrace = new FluxOnAssembly.CheckpointHeavySnapshot(description, Traces.callSiteSupplierFactory.get());
/*      */     } 
/*      */     
/* 2280 */     return new MonoOnAssembly<>(this, stacktrace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> concatWith(Publisher<? extends T> other) {
/* 2294 */     return Flux.concat((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> contextWrite(ContextView contextToAppend) {
/* 2316 */     return contextWrite(c -> c.putAll(contextToAppend));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> contextWrite(Function<Context, Context> contextModifier) {
/* 2340 */     return onAssembly(new MonoContextWrite<>(this, contextModifier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> defaultIfEmpty(T defaultV) {
/* 2356 */     if (this instanceof Fuseable.ScalarCallable) {
/*      */       try {
/* 2358 */         T v = block();
/* 2359 */         if (v == null) {
/* 2360 */           return just(defaultV);
/*      */         }
/*      */       }
/* 2363 */       catch (Throwable throwable) {}
/*      */ 
/*      */       
/* 2366 */       return this;
/*      */     } 
/* 2368 */     return onAssembly(new MonoDefaultIfEmpty<>(this, defaultV));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delayElement(Duration delay) {
/* 2387 */     return delayElement(delay, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delayElement(Duration delay, Scheduler timer) {
/* 2407 */     return onAssembly(new MonoDelayElement<>(this, delay.toNanos(), TimeUnit.NANOSECONDS, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delayUntil(Function<? super T, ? extends Publisher<?>> triggerProvider) {
/* 2431 */     Objects.requireNonNull(triggerProvider, "triggerProvider required");
/* 2432 */     if (this instanceof MonoDelayUntil) {
/* 2433 */       return ((MonoDelayUntil<T>)this).copyWithNewTriggerGenerator(false, triggerProvider);
/*      */     }
/* 2435 */     return onAssembly(new MonoDelayUntil<>(this, triggerProvider));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delaySubscription(Duration delay) {
/* 2451 */     return delaySubscription(delay, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> delaySubscription(Duration delay, Scheduler timer) {
/* 2468 */     return delaySubscription((Publisher<Long>)delay(delay, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> Mono<T> delaySubscription(Publisher<U> subscriptionDelay) {
/* 2486 */     return onAssembly(new MonoDelaySubscription<>(this, subscriptionDelay));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <X> Mono<X> dematerialize() {
/* 2505 */     Mono<T> mono = this;
/* 2506 */     return onAssembly(new MonoDematerialize<>((Mono)mono));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Mono<T> doAfterSuccessOrError(BiConsumer<? super T, Throwable> afterSuccessOrError) {
/* 2530 */     return doOnTerminalSignal(this, null, null, afterSuccessOrError);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doAfterTerminate(Runnable afterTerminate) {
/* 2546 */     Objects.requireNonNull(afterTerminate, "afterTerminate");
/* 2547 */     return onAssembly(new MonoPeekTerminal<>(this, null, null, (s, e) -> afterTerminate.run()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doFirst(Runnable onFirst) {
/* 2583 */     Objects.requireNonNull(onFirst, "onFirst");
/* 2584 */     if (this instanceof Fuseable) {
/* 2585 */       return onAssembly(new MonoDoFirstFuseable<>(this, onFirst));
/*      */     }
/* 2587 */     return onAssembly(new MonoDoFirst<>(this, onFirst));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doFinally(Consumer<SignalType> onFinally) {
/* 2610 */     Objects.requireNonNull(onFinally, "onFinally");
/* 2611 */     return onAssembly(new MonoDoFinally<>(this, onFinally));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnCancel(Runnable onCancel) {
/* 2627 */     Objects.requireNonNull(onCancel, "onCancel");
/* 2628 */     return doOnSignal(this, null, null, null, onCancel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<T> doOnDiscard(Class<R> type, Consumer<? super R> discardHook) {
/* 2656 */     return subscriberContext(Operators.discardLocalAdapter(type, discardHook));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnNext(Consumer<? super T> onNext) {
/* 2673 */     Objects.requireNonNull(onNext, "onNext");
/* 2674 */     return doOnSignal(this, null, onNext, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnSuccess(Consumer<? super T> onSuccess) {
/* 2698 */     Objects.requireNonNull(onSuccess, "onSuccess");
/* 2699 */     return doOnTerminalSignal(this, onSuccess, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnEach(Consumer<? super Signal<T>> signalConsumer) {
/* 2724 */     Objects.requireNonNull(signalConsumer, "signalConsumer");
/* 2725 */     if (this instanceof Fuseable) {
/* 2726 */       return onAssembly(new MonoDoOnEachFuseable<>(this, signalConsumer));
/*      */     }
/* 2728 */     return onAssembly(new MonoDoOnEach<>(this, signalConsumer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnError(Consumer<? super Throwable> onError) {
/* 2746 */     Objects.requireNonNull(onError, "onError");
/* 2747 */     return doOnTerminalSignal(this, null, onError, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> doOnError(Class<E> exceptionType, Consumer<? super E> onError) {
/* 2768 */     Objects.requireNonNull(exceptionType, "type");
/* 2769 */     Objects.requireNonNull(onError, "onError");
/* 2770 */     return doOnTerminalSignal(this, null, error -> { if (exceptionType.isInstance(error)) onError.accept(exceptionType.cast(error));  }null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnError(Predicate<? super Throwable> predicate, Consumer<? super Throwable> onError) {
/* 2793 */     Objects.requireNonNull(predicate, "predicate");
/* 2794 */     Objects.requireNonNull(onError, "onError");
/* 2795 */     return doOnTerminalSignal(this, null, error -> { if (predicate.test(error)) onError.accept(error);  }null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnRequest(LongConsumer consumer) {
/* 2818 */     Objects.requireNonNull(consumer, "consumer");
/* 2819 */     return doOnSignal(this, null, null, consumer, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnSubscribe(Consumer<? super Subscription> onSubscribe) {
/* 2842 */     Objects.requireNonNull(onSubscribe, "onSubscribe");
/* 2843 */     return doOnSignal(this, onSubscribe, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Mono<T> doOnSuccessOrError(BiConsumer<? super T, Throwable> onSuccessOrError) {
/* 2868 */     Objects.requireNonNull(onSuccessOrError, "onSuccessOrError");
/* 2869 */     return doOnTerminalSignal(this, v -> onSuccessOrError.accept(v, null), e -> onSuccessOrError.accept(null, e), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> doOnTerminate(Runnable onTerminate) {
/* 2888 */     Objects.requireNonNull(onTerminate, "onTerminate");
/* 2889 */     return doOnTerminalSignal(this, ignoreValue -> onTerminate.run(), ignoreError -> onTerminate.run(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Tuple2<Long, T>> elapsed() {
/* 2904 */     return elapsed(Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Tuple2<Long, T>> elapsed(Scheduler scheduler) {
/* 2920 */     Objects.requireNonNull(scheduler, "scheduler");
/* 2921 */     return onAssembly(new MonoElapsed<>(this, scheduler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> expandDeep(Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/* 2961 */     return Flux.onAssembly(new MonoExpand<>(this, expander, false, capacityHint));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> expandDeep(Function<? super T, ? extends Publisher<? extends T>> expander) {
/* 2998 */     return expandDeep(expander, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> expand(Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/* 3038 */     return Flux.onAssembly(new MonoExpand<>(this, expander, true, capacityHint));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> expand(Function<? super T, ? extends Publisher<? extends T>> expander) {
/* 3075 */     return expand(expander, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> filter(Predicate<? super T> tester) {
/* 3093 */     if (this instanceof Fuseable) {
/* 3094 */       return onAssembly(new MonoFilterFuseable<>(this, tester));
/*      */     }
/* 3096 */     return onAssembly(new MonoFilter<>(this, tester));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> filterWhen(Function<? super T, ? extends Publisher<Boolean>> asyncPredicate) {
/* 3120 */     return onAssembly(new MonoFilterWhen<>(this, asyncPredicate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> flatMap(Function<? super T, ? extends Mono<? extends R>> transformer) {
/* 3137 */     return onAssembly(new MonoFlatMap<>(this, transformer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Flux<R> flatMapMany(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/* 3154 */     return Flux.onAssembly(new MonoFlatMapMany<>(this, mapper));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Flux<R> flatMapMany(Function<? super T, ? extends Publisher<? extends R>> mapperOnNext, Function<? super Throwable, ? extends Publisher<? extends R>> mapperOnError, Supplier<? extends Publisher<? extends R>> mapperOnComplete) {
/* 3176 */     return flux().flatMap(mapperOnNext, mapperOnError, mapperOnComplete);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Flux<R> flatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper) {
/* 3205 */     return Flux.onAssembly(new MonoFlattenIterable<>(this, mapper, 2147483647, 
/* 3206 */           Queues.one()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> flux() {
/* 3215 */     if (this instanceof Callable && !(this instanceof Fuseable.ScalarCallable)) {
/* 3216 */       Callable<T> thiz = (Callable<T>)this;
/* 3217 */       return Flux.onAssembly(new FluxCallable<>(thiz));
/*      */     } 
/* 3219 */     return Flux.from((Publisher<? extends T>)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Boolean> hasElement() {
/* 3232 */     return onAssembly(new MonoHasElement<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> handle(BiConsumer<? super T, SynchronousSink<R>> handler) {
/* 3247 */     if (this instanceof Fuseable) {
/* 3248 */       return onAssembly(new MonoHandleFuseable<>(this, handler));
/*      */     }
/* 3250 */     return onAssembly(new MonoHandle<>(this, handler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> hide() {
/* 3262 */     return onAssembly(new MonoHide<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> ignoreElement() {
/* 3277 */     return onAssembly(new MonoIgnoreElement<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log() {
/* 3296 */     return log(null, Level.INFO, new SignalType[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(@Nullable String category) {
/* 3313 */     return log(category, Level.INFO, new SignalType[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(@Nullable String category, Level level, SignalType... options) {
/* 3339 */     return log(category, level, false, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(@Nullable String category, Level level, boolean showOperatorLine, SignalType... options) {
/* 3371 */     SignalLogger<T> log = new SignalLogger<>(this, category, level, showOperatorLine, options);
/*      */ 
/*      */     
/* 3374 */     if (this instanceof Fuseable) {
/* 3375 */       return onAssembly(new MonoLogFuseable<>(this, log));
/*      */     }
/* 3377 */     return onAssembly(new MonoLog<>(this, log));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(Logger logger) {
/* 3392 */     return log(logger, Level.INFO, false, new SignalType[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> log(Logger logger, Level level, boolean showOperatorLine, SignalType... options) {
/* 3419 */     SignalLogger<T> log = new SignalLogger<>(this, "IGNORED", level, showOperatorLine, s -> logger, options);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3424 */     if (this instanceof Fuseable) {
/* 3425 */       return onAssembly(new MonoLogFuseable<>(this, log));
/*      */     }
/* 3427 */     return onAssembly(new MonoLog<>(this, log));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> map(Function<? super T, ? extends R> mapper) {
/* 3442 */     if (this instanceof Fuseable) {
/* 3443 */       return onAssembly(new MonoMapFuseable<>(this, mapper));
/*      */     }
/* 3445 */     return onAssembly(new MonoMap<>(this, mapper));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> mapNotNull(Function<? super T, ? extends R> mapper) {
/* 3463 */     return handle((t, sink) -> {
/*      */           R r = mapper.apply(t);
/*      */           if (r != null) {
/*      */             sink.next(r);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Signal<T>> materialize() {
/* 3484 */     return onAssembly(new MonoMaterialize<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> mergeWith(Publisher<? extends T> other) {
/* 3499 */     return Flux.merge((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> metrics() {
/* 3524 */     if (!Metrics.isInstrumentationAvailable()) {
/* 3525 */       return this;
/*      */     }
/*      */     
/* 3528 */     if (this instanceof Fuseable) {
/* 3529 */       return onAssembly(new MonoMetricsFuseable<>(this));
/*      */     }
/* 3531 */     return onAssembly(new MonoMetrics<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> name(String name) {
/* 3548 */     return MonoName.createOrAppend(this, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> or(Mono<? extends T> other) {
/* 3563 */     if (this instanceof MonoFirstWithSignal) {
/* 3564 */       MonoFirstWithSignal<T> a = (MonoFirstWithSignal<T>)this;
/* 3565 */       Mono<T> result = a.orAdditionalSource(other);
/* 3566 */       if (result != null) {
/* 3567 */         return result;
/*      */       }
/*      */     } 
/* 3570 */     return firstWithSignal((Mono<? extends T>[])new Mono[] { this, other });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> Mono<U> ofType(Class<U> clazz) {
/* 3586 */     Objects.requireNonNull(clazz, "clazz");
/* 3587 */     return filter(o -> clazz.isAssignableFrom(o.getClass())).cast(clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorComplete() {
/* 3601 */     return onAssembly(new MonoOnErrorReturn<>(this, null, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorComplete(Class<? extends Throwable> type) {
/* 3616 */     Objects.requireNonNull(type, "type must not be null");
/* 3617 */     return onErrorComplete(type::isInstance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorComplete(Predicate<? super Throwable> predicate) {
/* 3632 */     Objects.requireNonNull(predicate, "predicate must not be null");
/* 3633 */     return onAssembly(new MonoOnErrorReturn<>(this, predicate, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorContinue(BiConsumer<Throwable, Object> errorConsumer) {
/* 3671 */     BiConsumer<Throwable, Object> genericConsumer = errorConsumer;
/* 3672 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*      */           
/* 3674 */           OnNextFailureStrategy.resume(genericConsumer)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorContinue(Class<E> type, BiConsumer<Throwable, Object> errorConsumer) {
/* 3715 */     return onErrorContinue(type::isInstance, errorConsumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorContinue(Predicate<E> errorPredicate, BiConsumer<Throwable, Object> errorConsumer) {
/* 3760 */     Predicate<Throwable> genericPredicate = errorPredicate;
/* 3761 */     BiConsumer<Throwable, Object> genericErrorConsumer = errorConsumer;
/* 3762 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*      */           
/* 3764 */           OnNextFailureStrategy.resumeIf(genericPredicate, genericErrorConsumer)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorStop() {
/* 3779 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*      */           
/* 3781 */           OnNextFailureStrategy.stop()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorMap(Predicate<? super Throwable> predicate, Function<? super Throwable, ? extends Throwable> mapper) {
/* 3797 */     return onErrorResume(predicate, e -> error(mapper.apply(e)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorMap(Function<? super Throwable, ? extends Throwable> mapper) {
/* 3811 */     return onErrorResume(e -> error(mapper.apply(e)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorMap(Class<E> type, Function<? super E, ? extends Throwable> mapper) {
/* 3829 */     Function<Throwable, Throwable> handler = (Function)mapper;
/* 3830 */     return onErrorMap(type::isInstance, handler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorResume(Function<? super Throwable, ? extends Mono<? extends T>> fallback) {
/* 3848 */     return onAssembly(new MonoOnErrorResume<>(this, fallback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorResume(Class<E> type, Function<? super E, ? extends Mono<? extends T>> fallback) {
/* 3866 */     Objects.requireNonNull(type, "type");
/*      */     
/* 3868 */     Function<? super E, ? extends Mono<? extends T>> function = fallback;
/*      */     
/* 3870 */     return onErrorResume(type::isInstance, function);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorResume(Predicate<? super Throwable> predicate, Function<? super Throwable, ? extends Mono<? extends T>> fallback) {
/* 3886 */     Objects.requireNonNull(predicate, "predicate");
/* 3887 */     return onErrorResume(e -> predicate.test(e) ? fallback.apply(e) : error(e));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorReturn(T fallbackValue) {
/* 3902 */     Objects.requireNonNull(fallbackValue, "fallbackValue must not be null");
/* 3903 */     return onAssembly(new MonoOnErrorReturn<>(this, null, fallbackValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Throwable> Mono<T> onErrorReturn(Class<E> type, T fallbackValue) {
/* 3920 */     Objects.requireNonNull(type, "type must not be null");
/* 3921 */     Objects.requireNonNull(fallbackValue, "fallbackValue must not be null");
/* 3922 */     return onErrorReturn(type::isInstance, fallbackValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onErrorReturn(Predicate<? super Throwable> predicate, T fallbackValue) {
/* 3938 */     Objects.requireNonNull(predicate, "predicate must not be null");
/* 3939 */     Objects.requireNonNull(fallbackValue, "fallbackValue must not be null");
/* 3940 */     return onAssembly(new MonoOnErrorReturn<>(this, predicate, fallbackValue));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> onTerminateDetach() {
/* 3952 */     return new MonoDetach<>(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> Mono<R> publish(Function<? super Mono<T>, ? extends Mono<? extends R>> transform) {
/* 3967 */     return onAssembly(new MonoPublishMulticast<>(this, transform));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> publishOn(Scheduler scheduler) {
/* 3990 */     if (this instanceof Callable) {
/* 3991 */       if (this instanceof Fuseable.ScalarCallable) {
/*      */         try {
/* 3993 */           T value = block();
/* 3994 */           return onAssembly(new MonoSubscribeOnValue<>(value, scheduler));
/*      */         }
/* 3996 */         catch (Throwable throwable) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 4001 */       Callable<T> c = (Callable<T>)this;
/* 4002 */       return onAssembly(new MonoSubscribeOnCallable<>(c, scheduler));
/*      */     } 
/* 4004 */     return onAssembly(new MonoPublishOn<>(this, scheduler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeat() {
/* 4017 */     return repeat(Flux.ALWAYS_BOOLEAN_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeat(BooleanSupplier predicate) {
/* 4032 */     return Flux.onAssembly(new MonoRepeatPredicate<>(this, predicate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeat(long numRepeat) {
/* 4047 */     if (numRepeat == 0L) {
/* 4048 */       return flux();
/*      */     }
/* 4050 */     return Flux.onAssembly(new MonoRepeat<>(this, numRepeat));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeat(long numRepeat, BooleanSupplier predicate) {
/* 4067 */     if (numRepeat < 0L) {
/* 4068 */       throw new IllegalArgumentException("numRepeat >= 0 required");
/*      */     }
/* 4070 */     if (numRepeat == 0L) {
/* 4071 */       return flux();
/*      */     }
/* 4073 */     return Flux.defer(() -> repeat(Flux.countingBooleanSupplier(predicate, numRepeat)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> repeatWhen(Function<Flux<Long>, ? extends Publisher<?>> repeatFactory) {
/* 4098 */     return Flux.onAssembly(new MonoRepeatWhen<>(this, repeatFactory));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> repeatWhenEmpty(Function<Flux<Long>, ? extends Publisher<?>> repeatFactory) {
/* 4118 */     return repeatWhenEmpty(2147483647, repeatFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> repeatWhenEmpty(int maxRepeat, Function<Flux<Long>, ? extends Publisher<?>> repeatFactory) {
/* 4141 */     return defer(() -> repeatWhen(()).next());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> retry() {
/* 4162 */     return retry(Long.MAX_VALUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> retry(long numRetries) {
/* 4178 */     return onAssembly(new MonoRetry<>(this, numRetries));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> retryWhen(Retry retrySpec) {
/* 4233 */     return onAssembly(new MonoRetryWhen<>(this, retrySpec));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> share() {
/* 4248 */     if (this instanceof Fuseable.ScalarCallable) {
/* 4249 */       return this;
/*      */     }
/*      */     
/* 4252 */     if (this instanceof NextProcessor && ((NextProcessor)this).isRefCounted) {
/* 4253 */       return this;
/*      */     }
/* 4255 */     return new NextProcessor<>(this, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> single() {
/* 4270 */     if (this instanceof Callable) {
/* 4271 */       if (this instanceof Fuseable.ScalarCallable) {
/*      */         T v;
/* 4273 */         Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)this;
/*      */ 
/*      */         
/*      */         try {
/* 4277 */           v = (T)scalarCallable.call();
/*      */         }
/* 4279 */         catch (Exception e) {
/* 4280 */           return error(Exceptions.unwrap(e));
/*      */         } 
/* 4282 */         if (v == null) {
/* 4283 */           return error(new NoSuchElementException("Source was a (constant) empty"));
/*      */         }
/* 4285 */         return just(v);
/*      */       } 
/*      */       
/* 4288 */       Callable<T> thiz = (Callable<T>)this;
/* 4289 */       return onAssembly(new MonoSingleCallable<>(thiz));
/*      */     } 
/* 4291 */     return onAssembly(new MonoSingleMono<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe() {
/* 4306 */     if (this instanceof NextProcessor) {
/* 4307 */       NextProcessor<T> s = (NextProcessor<T>)this;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4312 */       if (s.source != null && !s.isRefCounted) {
/* 4313 */         s.subscribe(new LambdaMonoSubscriber<>(null, null, null, null, null));
/* 4314 */         s.connect();
/* 4315 */         return s;
/*      */       } 
/*      */     } 
/* 4318 */     return subscribeWith(new LambdaMonoSubscriber(null, null, null, null, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(Consumer<? super T> consumer) {
/* 4339 */     Objects.requireNonNull(consumer, "consumer");
/* 4340 */     return subscribe(consumer, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, Consumer<? super Throwable> errorConsumer) {
/* 4364 */     Objects.requireNonNull(errorConsumer, "errorConsumer");
/* 4365 */     return subscribe(consumer, errorConsumer, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer) {
/* 4393 */     return subscribe(consumer, errorConsumer, completeConsumer, (Context)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Consumer<? super Subscription> subscriptionConsumer) {
/* 4426 */     return subscribeWith(new LambdaMonoSubscriber<>(consumer, errorConsumer, completeConsumer, subscriptionConsumer, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Context initialContext) {
/* 4457 */     return subscribeWith(new LambdaMonoSubscriber<>(consumer, errorConsumer, completeConsumer, null, initialContext));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void subscribe(Subscriber<? super T> actual) {
/* 4464 */     CorePublisher<T> publisher = Operators.onLastAssembly(this);
/* 4465 */     CoreSubscriber<? super T> subscriber = Operators.toCoreSubscriber(actual);
/*      */     
/* 4467 */     if (subscriber instanceof Fuseable.QueueSubscription && this != publisher && this instanceof Fuseable && !(publisher instanceof Fuseable)) {
/* 4468 */       subscriber = new FluxHide.SuppressFuseableSubscriber<>(subscriber);
/*      */     }
/*      */     
/*      */     try {
/* 4472 */       if (publisher instanceof OptimizableOperator) {
/* 4473 */         OptimizableOperator<T, T> operator = (OptimizableOperator)publisher;
/*      */         while (true) {
/* 4475 */           subscriber = operator.subscribeOrReturn(subscriber);
/* 4476 */           if (subscriber == null) {
/*      */             return;
/*      */           }
/*      */ 
/*      */           
/* 4481 */           OptimizableOperator<?, ? extends T> newSource = operator.nextOptimizableSource();
/* 4482 */           if (newSource == null) {
/* 4483 */             publisher = (CorePublisher)operator.source();
/*      */             break;
/*      */           } 
/* 4486 */           OptimizableOperator<?, ? extends T> optimizableOperator1 = newSource;
/*      */         } 
/*      */       } 
/*      */       
/* 4490 */       publisher.subscribe(subscriber);
/*      */     }
/* 4492 */     catch (Throwable e) {
/* 4493 */       Operators.reportThrowInSubscribe(subscriber, e);
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Mono<T> subscriberContext(Context mergeContext) {
/* 4532 */     return subscriberContext(c -> c.putAll(mergeContext.readOnly()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Mono<T> subscriberContext(Function<Context, Context> doOnContext) {
/* 4556 */     return new MonoContextWrite<>(this, doOnContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> subscribeOn(Scheduler scheduler) {
/* 4577 */     if (this instanceof Callable) {
/* 4578 */       if (this instanceof Fuseable.ScalarCallable) {
/*      */         try {
/* 4580 */           T value = block();
/* 4581 */           return onAssembly(new MonoSubscribeOnValue<>(value, scheduler));
/*      */         }
/* 4583 */         catch (Throwable throwable) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 4588 */       Callable<T> c = (Callable<T>)this;
/* 4589 */       return onAssembly(new MonoSubscribeOnCallable<>(c, scheduler));
/*      */     } 
/*      */     
/* 4592 */     return onAssembly(new MonoSubscribeOn<>(this, scheduler));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <E extends Subscriber<? super T>> E subscribeWith(E subscriber) {
/* 4605 */     subscribe((Subscriber<? super T>)subscriber);
/* 4606 */     return subscriber;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> switchIfEmpty(Mono<? extends T> alternate) {
/* 4621 */     return onAssembly(new MonoSwitchIfEmpty<>(this, alternate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> tag(String key, String value) {
/* 4642 */     return MonoName.createOrAppend(this, key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> take(Duration duration) {
/* 4659 */     return take(duration, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> take(Duration duration, Scheduler timer) {
/* 4678 */     return takeUntilOther((Publisher<?>)delay(duration, timer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> takeUntilOther(Publisher<?> other) {
/* 4696 */     return onAssembly(new MonoTakeUntilOther<>(this, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> then() {
/* 4711 */     return empty((Publisher<T>)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> then(Mono<V> other) {
/* 4732 */     if (this instanceof MonoIgnoreThen) {
/* 4733 */       MonoIgnoreThen<T> a = (MonoIgnoreThen<T>)this;
/* 4734 */       return a.shift(other);
/*      */     } 
/* 4736 */     return onAssembly(new MonoIgnoreThen<>((Publisher<?>[])new Publisher[] { (Publisher)this }, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> thenReturn(V value) {
/* 4752 */     return then(just(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> thenEmpty(Publisher<Void> other) {
/* 4769 */     return then(fromDirect(other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Flux<V> thenMany(Publisher<V> other) {
/* 4791 */     Flux<V> concat = Flux.concat((Publisher<? extends V>[])new Publisher[] { (Publisher)ignoreElement(), other });
/* 4792 */     return Flux.onAssembly(concat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Timed<T>> timed() {
/* 4821 */     return timed(Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Timed<T>> timed(Scheduler clock) {
/* 4849 */     return onAssembly(new MonoTimed<>(this, clock));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> timeout(Duration timeout) {
/* 4864 */     return timeout(timeout, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> timeout(Duration timeout, Mono<? extends T> fallback) {
/* 4882 */     return timeout(timeout, fallback, Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> timeout(Duration timeout, Scheduler timer) {
/* 4898 */     return timeout(timeout, null, timer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> timeout(Duration timeout, @Nullable Mono<? extends T> fallback, Scheduler timer) {
/* 4918 */     Mono<Long> _timer = delay(timeout, timer).onErrorReturn(Long.valueOf(0L));
/*      */     
/* 4920 */     if (fallback == null) {
/* 4921 */       return onAssembly(new MonoTimeout<>(this, (Publisher<Long>)_timer, timeout.toMillis() + "ms"));
/*      */     }
/* 4923 */     return onAssembly(new MonoTimeout<>(this, (Publisher<Long>)_timer, (Publisher<? extends T>)fallback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> Mono<T> timeout(Publisher<U> firstTimeout) {
/* 4940 */     return onAssembly(new MonoTimeout<>(this, firstTimeout, "first signal from a Publisher"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> Mono<T> timeout(Publisher<U> firstTimeout, Mono<? extends T> fallback) {
/* 4960 */     return onAssembly(new MonoTimeout<>(this, firstTimeout, (Publisher<? extends T>)fallback));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Tuple2<Long, T>> timestamp() {
/* 4975 */     return timestamp(Schedulers.parallel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Tuple2<Long, T>> timestamp(Scheduler scheduler) {
/* 4996 */     Objects.requireNonNull(scheduler, "scheduler");
/* 4997 */     return map(d -> Tuples.of(Long.valueOf(scheduler.now(TimeUnit.MILLISECONDS)), d));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final CompletableFuture<T> toFuture() {
/* 5010 */     return subscribeWith(new MonoToCompletableFuture<>(false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final MonoProcessor<T> toProcessor() {
/* 5023 */     if (this instanceof MonoProcessor) {
/* 5024 */       return (MonoProcessor<T>)this;
/*      */     }
/*      */     
/* 5027 */     NextProcessor<T> result = new NextProcessor<>(this);
/* 5028 */     result.connect();
/* 5029 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> transform(Function<? super Mono<T>, ? extends Publisher<V>> transformer) {
/* 5055 */     if (Hooks.DETECT_CONTEXT_LOSS) {
/* 5056 */       transformer = (Function)new ContextTrackingFunctionWrapper<>((Function)transformer);
/*      */     }
/* 5058 */     return onAssembly(from(transformer.apply(this)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> transformDeferred(Function<? super Mono<T>, ? extends Publisher<V>> transformer) {
/* 5082 */     return defer(() -> Hooks.DETECT_CONTEXT_LOSS ? from((Publisher)(new ContextTrackingFunctionWrapper<>(transformer)).apply((Publisher<T>)this)) : from(transformer.apply(this)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Mono<V> transformDeferredContextual(BiFunction<? super Mono<T>, ? super ContextView, ? extends Publisher<V>> transformer) {
/* 5116 */     return deferContextual(ctxView -> {
/*      */           if (Hooks.DETECT_CONTEXT_LOSS) {
/*      */             ContextTrackingFunctionWrapper<T, V> wrapper = new ContextTrackingFunctionWrapper<>((), transformer.toString());
/*      */             return wrap((Publisher<?>)wrapper.apply((Publisher<T>)this), true);
/*      */           } 
/*      */           return from(transformer.apply(this, ctxView));
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T2> Mono<Tuple2<T, T2>> zipWhen(Function<T, Mono<? extends T2>> rightGenerator) {
/* 5141 */     return zipWhen(rightGenerator, Tuples::of);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T2, O> Mono<O> zipWhen(Function<T, Mono<? extends T2>> rightGenerator, BiFunction<T, T2, O> combinator) {
/* 5161 */     Objects.requireNonNull(rightGenerator, "rightGenerator function is mandatory to get the right-hand side Mono");
/* 5162 */     Objects.requireNonNull(combinator, "combinator function is mandatory to combine results from both Monos");
/* 5163 */     return flatMap(t -> ((Mono)rightGenerator.apply(t)).map(()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T2> Mono<Tuple2<T, T2>> zipWith(Mono<? extends T2> other) {
/* 5181 */     return zipWith(other, (BiFunction)Flux.tuple2Function());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T2, O> Mono<O> zipWith(Mono<? extends T2> other, BiFunction<? super T, ? super T2, ? extends O> combinator) {
/* 5204 */     if (this instanceof MonoZip) {
/* 5205 */       MonoZip<T, O> o = (MonoZip)this;
/* 5206 */       Mono<O> result = o.zipAdditionalSource((Publisher)other, combinator);
/* 5207 */       if (result != null) {
/* 5208 */         return result;
/*      */       }
/*      */     } 
/*      */     
/* 5212 */     return zip(this, other, combinator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static <T> Mono<T> onAssembly(Mono<T> source) {
/* 5228 */     Function<Publisher, Publisher> hook = Hooks.onEachOperatorHook;
/* 5229 */     if (hook != null) {
/* 5230 */       source = (Mono<T>)hook.apply(source);
/*      */     }
/* 5232 */     if (Hooks.GLOBAL_TRACE) {
/* 5233 */       FluxOnAssembly.AssemblySnapshot stacktrace = new FluxOnAssembly.AssemblySnapshot(null, Traces.callSiteSupplierFactory.get());
/* 5234 */       source = (Mono<T>)Hooks.addAssemblyInfo(source, stacktrace);
/*      */     } 
/* 5236 */     return source;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 5241 */     return getClass().getSimpleName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> Mono<Void> empty(Publisher<T> source) {
/* 5247 */     Mono<Void> then = ignoreElements((Publisher)source);
/* 5248 */     return then;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> Mono<T> doOnSignal(Mono<T> source, @Nullable Consumer<? super Subscription> onSubscribe, @Nullable Consumer<? super T> onNext, @Nullable LongConsumer onRequest, @Nullable Runnable onCancel) {
/* 5256 */     if (source instanceof Fuseable) {
/* 5257 */       return onAssembly(new MonoPeekFuseable<>(source, onSubscribe, onNext, onRequest, onCancel));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5263 */     return onAssembly(new MonoPeek<>(source, onSubscribe, onNext, onRequest, onCancel));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> Mono<T> doOnTerminalSignal(Mono<T> source, @Nullable Consumer<? super T> onSuccess, @Nullable Consumer<? super Throwable> onError, @Nullable BiConsumer<? super T, Throwable> onAfterTerminate) {
/* 5274 */     return onAssembly(new MonoPeekTerminal<>(source, onSuccess, onError, onAfterTerminate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> Mono<T> wrap(Publisher<T> source, boolean enforceMonoContract) {
/* 5292 */     if (source instanceof Mono) {
/* 5293 */       return (Mono<T>)source;
/*      */     }
/* 5295 */     if (source instanceof FluxSourceMono || source instanceof FluxSourceMonoFuseable) {
/*      */ 
/*      */       
/* 5298 */       Mono<T> extracted = ((FluxFromMonoOperator)source).source;
/* 5299 */       return extracted;
/*      */     } 
/*      */ 
/*      */     
/* 5303 */     if (enforceMonoContract) {
/* 5304 */       if (source instanceof Flux && source instanceof Callable) {
/* 5305 */         Callable<T> m = (Callable<T>)source;
/* 5306 */         return Flux.wrapToMono(m);
/*      */       } 
/* 5308 */       if (source instanceof Flux) {
/* 5309 */         return new MonoNext<>((Flux<? extends T>)source);
/*      */       }
/* 5311 */       return new MonoFromPublisher<>(source);
/*      */     } 
/*      */ 
/*      */     
/* 5315 */     if (source instanceof Flux && source instanceof Fuseable) {
/* 5316 */       return new MonoSourceFluxFuseable<>((Flux<? extends T>)source);
/*      */     }
/* 5318 */     if (source instanceof Flux) {
/* 5319 */       return new MonoSourceFlux<>((Flux<? extends T>)source);
/*      */     }
/* 5321 */     if (source instanceof Fuseable) {
/* 5322 */       return new MonoSourceFuseable<>(source);
/*      */     }
/* 5324 */     return new MonoSource<>(source);
/*      */   }
/*      */ 
/*      */   
/*      */   static <T> BiPredicate<? super T, ? super T> equalsBiPredicate() {
/* 5329 */     return EQUALS_BIPREDICATE;
/*      */   }
/* 5331 */   static final BiPredicate EQUALS_BIPREDICATE = Object::equals;
/*      */   
/*      */   public abstract void subscribe(CoreSubscriber<? super T> paramCoreSubscriber);
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\Mono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */