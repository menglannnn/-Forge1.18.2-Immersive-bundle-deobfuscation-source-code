/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxSourceMonoFuseable<I>
/*    */   extends FluxFromMonoOperator<I, I>
/*    */   implements Fuseable
/*    */ {
/*    */   FluxSourceMonoFuseable(Mono<? extends I> source) {
/* 29 */     super(source);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super I> actual) {
/* 39 */     return actual;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 45 */     if (this.source instanceof Scannable) {
/* 46 */       return "FluxFromMono(" + Scannable.from(this.source).stepName() + ")";
/*    */     }
/* 48 */     return "FluxFromMono(" + this.source.toString() + ")";
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 53 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 54 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxSourceMonoFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */