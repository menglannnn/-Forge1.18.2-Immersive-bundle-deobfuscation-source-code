/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxTakeFuseable<T>
/*    */   extends InternalFluxOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   final long n;
/*    */   
/*    */   FluxTakeFuseable(Flux<? extends T> source, long n) {
/* 37 */     super(source);
/* 38 */     if (n < 0L) {
/* 39 */       throw new IllegalArgumentException("n >= 0 required but it was " + n);
/*    */     }
/* 41 */     this.n = n;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 46 */     return new FluxTake.TakeFuseableSubscriber<>(actual, this.n);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 51 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 52 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxTakeFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */