/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoCacheInvalidateIf<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */ {
/*     */   static final class ValueState<T>
/*     */     implements State<T>
/*     */   {
/*     */     @Nullable
/*     */     T value;
/*     */     
/*     */     ValueState(T value) {
/*  67 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T get() {
/*  73 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/*  78 */       this.value = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   static final State<?> EMPTY_STATE = new State()
/*     */     {
/*     */       @Nullable
/*     */       public Object get() {
/*  90 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void clear() {}
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   final Predicate<? super T> shouldInvalidatePredicate;
/*     */   
/*     */   volatile State<T> state;
/*     */   
/* 104 */   static final AtomicReferenceFieldUpdater<MonoCacheInvalidateIf, State> STATE = AtomicReferenceFieldUpdater.newUpdater(MonoCacheInvalidateIf.class, State.class, "state");
/*     */   
/*     */   MonoCacheInvalidateIf(Mono<T> source, Predicate<? super T> invalidationPredicate) {
/* 107 */     super(source);
/* 108 */     this.shouldInvalidatePredicate = Objects.<Predicate<? super T>>requireNonNull(invalidationPredicate, "invalidationPredicate");
/*     */     
/* 110 */     State<T> state = (State)EMPTY_STATE;
/* 111 */     this.state = state;
/*     */   }
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*     */     State<T> state;
/* 116 */     CacheMonoSubscriber<T> inner = new CacheMonoSubscriber<>(actual);
/*     */     
/*     */     while (true)
/* 119 */     { state = this.state;
/* 120 */       if (state == EMPTY_STATE || state instanceof CoordinatorSubscriber) {
/* 121 */         CoordinatorSubscriber<T> coordinator; boolean connectToUpstream = false;
/*     */         
/* 123 */         if (state == EMPTY_STATE) {
/* 124 */           coordinator = new CoordinatorSubscriber<>(this, this.source);
/* 125 */           if (!STATE.compareAndSet(this, EMPTY_STATE, coordinator)) {
/*     */             continue;
/*     */           }
/* 128 */           connectToUpstream = true;
/*     */         } else {
/*     */           
/* 131 */           coordinator = (CoordinatorSubscriber<T>)state;
/*     */         } 
/*     */         
/* 134 */         if (coordinator.add(inner)) {
/* 135 */           if (inner.isCancelled()) {
/* 136 */             coordinator.remove(inner);
/*     */           } else {
/*     */             
/* 139 */             inner.coordinator = coordinator;
/* 140 */             actual.onSubscribe(inner);
/*     */           } 
/*     */           
/* 143 */           if (connectToUpstream) {
/* 144 */             coordinator.delayedSubscribe();
/*     */           }
/* 146 */           return null;
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 151 */       T cached = state.get();
/*     */       try {
/* 153 */         boolean invalidated = this.shouldInvalidatePredicate.test(cached);
/* 154 */         if (invalidated) {
/* 155 */           if (STATE.compareAndSet(this, state, EMPTY_STATE)) {
/* 156 */             Operators.onDiscard(cached, actual.currentContext());
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/*     */         break;
/* 162 */       } catch (Throwable error) {
/* 163 */         if (STATE.compareAndSet(this, state, EMPTY_STATE)) {
/* 164 */           Operators.onDiscard(cached, actual.currentContext());
/* 165 */           Operators.error((Subscriber<?>)actual, error);
/* 166 */           return null;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 171 */       actual.onSubscribe(inner);
/* 172 */       inner.complete(state.get());
/* 173 */       return null; }  actual.onSubscribe(inner); inner.complete(state.get()); return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 180 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 181 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CoordinatorSubscriber<T>
/*     */     implements InnerConsumer<T>, State<T>
/*     */   {
/*     */     final MonoCacheInvalidateIf<T> main;
/*     */     
/*     */     final Mono<? extends T> source;
/*     */     
/*     */     boolean done = false;
/*     */     
/*     */     volatile Subscription upstream;
/* 195 */     static final AtomicReferenceFieldUpdater<CoordinatorSubscriber, Subscription> UPSTREAM = AtomicReferenceFieldUpdater.newUpdater(CoordinatorSubscriber.class, Subscription.class, "upstream");
/*     */ 
/*     */     
/*     */     volatile MonoCacheInvalidateIf.CacheMonoSubscriber<T>[] subscribers;
/*     */ 
/*     */     
/* 201 */     static final AtomicReferenceFieldUpdater<CoordinatorSubscriber, MonoCacheInvalidateIf.CacheMonoSubscriber[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(CoordinatorSubscriber.class, (Class)MonoCacheInvalidateIf.CacheMonoSubscriber[].class, "subscribers");
/*     */ 
/*     */     
/* 204 */     private static final MonoCacheInvalidateIf.CacheMonoSubscriber[] COORDINATOR_DONE = new MonoCacheInvalidateIf.CacheMonoSubscriber[0];
/*     */     
/* 206 */     private static final MonoCacheInvalidateIf.CacheMonoSubscriber[] COORDINATOR_INIT = new MonoCacheInvalidateIf.CacheMonoSubscriber[0];
/*     */ 
/*     */     
/*     */     CoordinatorSubscriber(MonoCacheInvalidateIf<T> main, Mono<? extends T> source) {
/* 210 */       this.main = main;
/* 211 */       this.source = source;
/* 212 */       this.subscribers = (MonoCacheInvalidateIf.CacheMonoSubscriber<T>[])COORDINATOR_INIT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T get() {
/* 222 */       throw new UnsupportedOperationException("coordinator State#get shouldn't be used");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final boolean add(MonoCacheInvalidateIf.CacheMonoSubscriber<T> toAdd) {
/*     */       while (true) {
/* 236 */         MonoCacheInvalidateIf.CacheMonoSubscriber<T>[] a = this.subscribers;
/* 237 */         if (a == COORDINATOR_DONE) {
/* 238 */           return false;
/*     */         }
/* 240 */         int n = a.length;
/*     */         
/* 242 */         MonoCacheInvalidateIf.CacheMonoSubscriber[] arrayOfCacheMonoSubscriber = new MonoCacheInvalidateIf.CacheMonoSubscriber[n + 1];
/* 243 */         System.arraycopy(a, 0, arrayOfCacheMonoSubscriber, 0, n);
/* 244 */         arrayOfCacheMonoSubscriber[n] = toAdd;
/* 245 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfCacheMonoSubscriber)) {
/* 246 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     final void remove(MonoCacheInvalidateIf.CacheMonoSubscriber<T> toRemove) {
/*     */       while (true) {
/* 253 */         MonoCacheInvalidateIf.CacheMonoSubscriber<T>[] a = this.subscribers;
/* 254 */         if (a == COORDINATOR_DONE || a == COORDINATOR_INIT) {
/*     */           return;
/*     */         }
/* 257 */         int n = a.length;
/* 258 */         int j = -1;
/* 259 */         for (int i = 0; i < n; i++) {
/* 260 */           if (a[i] == toRemove) {
/* 261 */             j = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 266 */         if (j < 0) {
/*     */           return;
/*     */         }
/*     */         
/* 270 */         if (n == 1) {
/* 271 */           if (SUBSCRIBERS.compareAndSet(this, a, COORDINATOR_DONE)) {
/*     */             
/* 273 */             this.upstream.cancel();
/*     */             
/* 275 */             MonoCacheInvalidateIf.STATE.compareAndSet(this.main, this, MonoCacheInvalidateIf.EMPTY_STATE);
/*     */             
/*     */             return;
/*     */           } 
/*     */           continue;
/*     */         } 
/* 281 */         MonoCacheInvalidateIf.CacheMonoSubscriber[] arrayOfCacheMonoSubscriber = new MonoCacheInvalidateIf.CacheMonoSubscriber[n - 1];
/* 282 */         System.arraycopy(a, 0, arrayOfCacheMonoSubscriber, 0, j);
/* 283 */         System.arraycopy(a, j + 1, arrayOfCacheMonoSubscriber, j, n - j - 1);
/* 284 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfCacheMonoSubscriber)) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void delayedSubscribe() {
/* 293 */       Subscription old = UPSTREAM.getAndSet(this, null);
/* 294 */       if (old != null && old != Operators.cancelledSubscription()) {
/* 295 */         old.cancel();
/*     */       }
/* 297 */       this.source.subscribe(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 303 */       if (UPSTREAM.compareAndSet(this, null, s)) {
/* 304 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 310 */       if (this.main.state != this || this.done) {
/* 311 */         Operators.onNextDropped(t, currentContext());
/*     */         return;
/*     */       } 
/* 314 */       this.done = true;
/*     */       
/* 316 */       MonoCacheInvalidateIf.State<T> valueState = new MonoCacheInvalidateIf.ValueState<>(t);
/* 317 */       if (MonoCacheInvalidateIf.STATE.compareAndSet(this.main, this, valueState)) {
/* 318 */         for (MonoCacheInvalidateIf.CacheMonoSubscriber<T> inner : (MonoCacheInvalidateIf.CacheMonoSubscriber[])SUBSCRIBERS.getAndSet(this, COORDINATOR_DONE)) {
/* 319 */           inner.complete(t);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 326 */       if (this.main.state != this || this.done) {
/* 327 */         Operators.onErrorDropped(t, currentContext());
/*     */         return;
/*     */       } 
/* 330 */       if (MonoCacheInvalidateIf.STATE.compareAndSet(this.main, this, MonoCacheInvalidateIf.EMPTY_STATE)) {
/* 331 */         for (MonoCacheInvalidateIf.CacheMonoSubscriber<T> inner : (MonoCacheInvalidateIf.CacheMonoSubscriber[])SUBSCRIBERS.getAndSet(this, COORDINATOR_DONE)) {
/* 332 */           inner.onError(t);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 339 */       if (this.done) {
/* 340 */         this.done = false;
/*     */         return;
/*     */       } 
/* 343 */       if (MonoCacheInvalidateIf.STATE.compareAndSet(this.main, this, MonoCacheInvalidateIf.EMPTY_STATE)) {
/* 344 */         for (MonoCacheInvalidateIf.CacheMonoSubscriber<T> inner : (MonoCacheInvalidateIf.CacheMonoSubscriber[])SUBSCRIBERS.getAndSet(this, COORDINATOR_DONE)) {
/* 345 */           inner.onError(new NoSuchElementException("cacheInvalidateWhen expects a value, source completed empty"));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 352 */       return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 358 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 359 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CacheMonoSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     MonoCacheInvalidateIf.CoordinatorSubscriber<T> coordinator;
/*     */     
/*     */     CacheMonoSubscriber(CoreSubscriber<? super T> actual) {
/* 369 */       super(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 374 */       super.cancel();
/* 375 */       MonoCacheInvalidateIf.CoordinatorSubscriber<T> coordinator = this.coordinator;
/* 376 */       if (coordinator != null) {
/* 377 */         coordinator.remove(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 383 */       if (key == Scannable.Attr.PARENT) return this.coordinator.main; 
/* 384 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 385 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */   
/*     */   static interface State<T> {
/*     */     @Nullable
/*     */     T get();
/*     */     
/*     */     void clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoCacheInvalidateIf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */