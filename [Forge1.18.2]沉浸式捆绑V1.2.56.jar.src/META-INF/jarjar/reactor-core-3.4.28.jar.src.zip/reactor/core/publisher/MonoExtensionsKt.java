/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import kotlin.Deprecated;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.ReplaceWith;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.jvm.functions.Function0;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.FunctionReference;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Reflection;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KDeclarationContainer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.reactivestreams.Publisher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\000>\n\000\n\002\030\002\n\000\n\002\020\000\n\002\b\002\n\002\020\003\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\b\n\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\032#\020\000\032\b\022\004\022\002H\0020\001\"\n\b\000\020\002\030\001*\0020\003*\006\022\002\b\0030\001H\b\032J\020\004\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002\"\b\b\001\020\005*\0020\006*\b\022\004\022\002H\0020\0012\f\020\007\032\b\022\004\022\002H\0050\b2\022\020\t\032\016\022\004\022\002H\005\022\004\022\0020\0130\nH\007\032#\020\f\032\b\022\004\022\002H\0020\001\"\n\b\000\020\002\030\001*\0020\003*\006\022\002\b\0030\001H\b\032J\020\r\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002\"\b\b\001\020\005*\0020\006*\b\022\004\022\002H\0020\0012\f\020\007\032\b\022\004\022\002H\0050\b2\022\020\016\032\016\022\004\022\002H\005\022\004\022\0020\0060\nH\007\032T\020\017\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003\"\b\b\001\020\005*\0020\006*\b\022\004\022\002H\0020\0012\f\020\007\032\b\022\004\022\002H\0050\b2\030\020\020\032\024\022\004\022\002H\005\022\n\022\b\022\004\022\002H\0020\0010\nH\007\032G\020\021\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003\"\b\b\001\020\005*\0020\006*\b\022\004\022\002H\0020\0012\f\020\007\032\b\022\004\022\002H\0050\b2\006\020\022\032\002H\002H\007¢\006\002\020\023\0322\020\024\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0012\022\020\025\032\016\022\n\022\b\022\004\022\002H\0020\0010\026H\007\032 \020\027\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\n\022\006\022\004\030\001H\0020\026H\007\032!\020\027\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003*\002H\002H\007¢\006\002\020\030\032 \020\027\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\n\022\006\022\004\030\001H\0020\031H\007\032\"\020\027\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\f\022\b\b\001\022\004\030\001H\0020\032H\007\032\030\020\027\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\0020\006H\007\032\036\020\027\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\033H\007¨\006\034"}, d2 = {"cast", "Lreactor/core/publisher/Mono;", "T", "", "doOnError", "E", "", "exceptionType", "Lkotlin/reflect/KClass;", "onError", "Lkotlin/Function1;", "", "ofType", "onErrorMap", "mapper", "onErrorResume", "fallback", "onErrorReturn", "value", "(Lreactor/core/publisher/Mono;Lkotlin/reflect/KClass;Ljava/lang/Object;)Lreactor/core/publisher/Mono;", "switchIfEmpty", "s", "Lkotlin/Function0;", "toMono", "(Ljava/lang/Object;)Lreactor/core/publisher/Mono;", "Ljava/util/concurrent/Callable;", "Ljava/util/concurrent/CompletableFuture;", "Lorg/reactivestreams/Publisher;", "reactor-core"})
/*     */ public final class MonoExtensionsKt
/*     */ {
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toMono"}, expression = "toMono()"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> toMono(@NotNull Publisher<?> $this$toMono) {
/*  37 */     Intrinsics.checkParameterIsNotNull($this$toMono, "$this$toMono"); Intrinsics.checkExpressionValueIsNotNull(Mono.from($this$toMono), "Mono.from(this)"); return (Mono)Mono.from($this$toMono);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toMono"}, expression = "toMono()"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> toMono(@NotNull Function0 $this$toMono) {
/*  46 */     Intrinsics.checkParameterIsNotNull($this$toMono, "$this$toMono"); Function0 function0 = $this$toMono; Intrinsics.checkExpressionValueIsNotNull(Mono.fromSupplier(new MonoExtensionsKt$sam$java_util_function_Supplier$0(function0)), "Mono.fromSupplier(this)"); return (Mono)Mono.fromSupplier(new MonoExtensionsKt$sam$java_util_function_Supplier$0(function0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toMono"}, expression = "toMono()"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> toMono(@NotNull Object $this$toMono) {
/*  56 */     Intrinsics.checkParameterIsNotNull($this$toMono, "$this$toMono"); Intrinsics.checkExpressionValueIsNotNull(Mono.just($this$toMono), "Mono.just(this)"); return Mono.just($this$toMono);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toMono"}, expression = "toMono()"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> toMono(@NotNull CompletableFuture<?> $this$toMono) {
/*  66 */     Intrinsics.checkParameterIsNotNull($this$toMono, "$this$toMono"); Intrinsics.checkExpressionValueIsNotNull(Mono.fromFuture($this$toMono), "Mono.fromFuture(this)"); return (Mono)Mono.fromFuture($this$toMono);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toMono"}, expression = "toMono()"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> toMono(@NotNull Callable $this$toMono) {
/*  76 */     Intrinsics.checkParameterIsNotNull($this$toMono, "$this$toMono"); MonoExtensionsKt$toMono$1 monoExtensionsKt$toMono$1 = new MonoExtensionsKt$toMono$1($this$toMono); Intrinsics.checkExpressionValueIsNotNull(Mono.fromCallable(new MonoExtensionsKt$sam$java_util_concurrent_Callable$0(monoExtensionsKt$toMono$1)), "Mono.fromCallable(this::call)"); return (Mono)Mono.fromCallable(new MonoExtensionsKt$sam$java_util_concurrent_Callable$0(monoExtensionsKt$toMono$1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toMono"}, expression = "toMono<T>()"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> toMono(@NotNull Throwable $this$toMono) {
/*  86 */     Intrinsics.checkParameterIsNotNull($this$toMono, "$this$toMono"); Intrinsics.checkExpressionValueIsNotNull(Mono.error($this$toMono), "Mono.error(this)"); return (Mono)Mono.error($this$toMono);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.doOnError"}, expression = "doOnError(exceptionType, onError)"))
/*     */   @NotNull
/*     */   public static final <T, E extends Throwable> Mono<T> doOnError(@NotNull Mono $this$doOnError, @NotNull KClass exceptionType, @NotNull Function1 onError) {
/* 107 */     Intrinsics.checkParameterIsNotNull($this$doOnError, "$this$doOnError"); Intrinsics.checkParameterIsNotNull(exceptionType, "exceptionType"); Intrinsics.checkParameterIsNotNull(onError, "onError"); Intrinsics.checkExpressionValueIsNotNull($this$doOnError.doOnError(JvmClassMappingKt.getJavaClass(exceptionType), new MonoExtensionsKt$doOnError$1(onError)), "doOnError(exceptionType.java) { onError(it) }"); return $this$doOnError.doOnError(JvmClassMappingKt.getJavaClass(exceptionType), new MonoExtensionsKt$doOnError$1(onError)); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\022\n\000\n\002\020\002\n\002\b\002\n\002\020\003\n\002\b\004\020\000\032\0020\001\"\004\b\000\020\002\"\b\b\001\020\003*\0020\0042\016\020\005\032\n \006*\004\030\001H\003H\003H\n¢\006\004\b\007\020\b"}, d2 = {"<anonymous>", "", "T", "E", "", "it", "kotlin.jvm.PlatformType", "accept", "(Ljava/lang/Throwable;)V"}) static final class MonoExtensionsKt$doOnError$1<T> implements Consumer { public final void accept(Throwable it) { Intrinsics.checkExpressionValueIsNotNull(it, "it"); this.$onError.invoke(it); }
/*     */ 
/*     */ 
/*     */     
/*     */     MonoExtensionsKt$doOnError$1(Function1 param1Function1) {} }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.onErrorMap"}, expression = "onErrorMap(exceptionType, mapper)"))
/*     */   @NotNull
/*     */   public static final <T, E extends Throwable> Mono<T> onErrorMap(@NotNull Mono $this$onErrorMap, @NotNull KClass exceptionType, @NotNull Function1 mapper) {
/* 118 */     Intrinsics.checkParameterIsNotNull($this$onErrorMap, "$this$onErrorMap"); Intrinsics.checkParameterIsNotNull(exceptionType, "exceptionType"); Intrinsics.checkParameterIsNotNull(mapper, "mapper"); Intrinsics.checkExpressionValueIsNotNull($this$onErrorMap.onErrorMap(JvmClassMappingKt.getJavaClass(exceptionType), new MonoExtensionsKt$onErrorMap$1<>(mapper)), "onErrorMap(exceptionType.java) { mapper(it) }"); return $this$onErrorMap.onErrorMap(JvmClassMappingKt.getJavaClass(exceptionType), new MonoExtensionsKt$onErrorMap$1<>(mapper)); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\n\n\000\n\002\020\003\n\002\b\006\020\000\032\0020\001\"\004\b\000\020\002\"\b\b\001\020\003*\0020\0012\016\020\004\032\n \005*\004\030\001H\003H\003H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "T", "E", "it", "kotlin.jvm.PlatformType", "apply", "(Ljava/lang/Throwable;)Ljava/lang/Throwable;"}) static final class MonoExtensionsKt$onErrorMap$1<T, R> implements Function { @NotNull public final Throwable apply(Throwable it) { Intrinsics.checkExpressionValueIsNotNull(it, "it"); return (Throwable)this.$mapper.invoke(it); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MonoExtensionsKt$onErrorMap$1(Function1 param1Function1) {} }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.onErrorResume"}, expression = "onErrorResume(exceptionType, fallback)"))
/*     */   @NotNull
/*     */   public static final <T, E extends Throwable> Mono<T> onErrorResume(@NotNull Mono $this$onErrorResume, @NotNull KClass exceptionType, @NotNull Function1 fallback) {
/* 139 */     Intrinsics.checkParameterIsNotNull($this$onErrorResume, "$this$onErrorResume"); Intrinsics.checkParameterIsNotNull(exceptionType, "exceptionType"); Intrinsics.checkParameterIsNotNull(fallback, "fallback"); Intrinsics.checkExpressionValueIsNotNull($this$onErrorResume.onErrorResume(JvmClassMappingKt.getJavaClass(exceptionType), new MonoExtensionsKt$onErrorResume$1<>(fallback)), "onErrorResume(exceptionType.java) { fallback(it) }"); return $this$onErrorResume.onErrorResume(JvmClassMappingKt.getJavaClass(exceptionType), new MonoExtensionsKt$onErrorResume$1<>(fallback)); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\026\n\000\n\002\030\002\n\000\n\002\020\000\n\000\n\002\020\003\n\002\b\004\020\000\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003\"\b\b\001\020\004*\0020\0052\016\020\006\032\n \007*\004\030\001H\004H\004H\n¢\006\004\b\b\020\t"}, d2 = {"<anonymous>", "Lreactor/core/publisher/Mono;", "T", "", "E", "", "it", "kotlin.jvm.PlatformType", "apply", "(Ljava/lang/Throwable;)Lreactor/core/publisher/Mono;"}) static final class MonoExtensionsKt$onErrorResume$1<T, R> implements Function { @NotNull public final Mono<T> apply(Throwable it) { Intrinsics.checkExpressionValueIsNotNull(it, "it"); return (Mono<T>)this.$fallback.invoke(it); }
/*     */ 
/*     */ 
/*     */     
/*     */     MonoExtensionsKt$onErrorResume$1(Function1 param1Function1) {} }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.onErrorReturn"}, expression = "onErrorReturn(exceptionType, value)"))
/*     */   @NotNull
/*     */   public static final <T, E extends Throwable> Mono<T> onErrorReturn(@NotNull Mono $this$onErrorReturn, @NotNull KClass exceptionType, @NotNull Object value) {
/* 150 */     Intrinsics.checkParameterIsNotNull($this$onErrorReturn, "$this$onErrorReturn"); Intrinsics.checkParameterIsNotNull(exceptionType, "exceptionType"); Intrinsics.checkParameterIsNotNull(value, "value"); Intrinsics.checkExpressionValueIsNotNull($this$onErrorReturn.onErrorReturn(JvmClassMappingKt.getJavaClass(exceptionType), value), "onErrorReturn(exceptionType.java, value)"); return $this$onErrorReturn.onErrorReturn(JvmClassMappingKt.getJavaClass(exceptionType), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.switchIfEmpty"}, expression = "switchIfEmpty(s)"))
/*     */   @NotNull
/*     */   public static final <T> Mono<T> switchIfEmpty(@NotNull Mono $this$switchIfEmpty, @NotNull Function0 s) {
/* 161 */     Intrinsics.checkParameterIsNotNull($this$switchIfEmpty, "$this$switchIfEmpty"); Intrinsics.checkParameterIsNotNull(s, "s"); Intrinsics.checkExpressionValueIsNotNull($this$switchIfEmpty.switchIfEmpty(Mono.defer(new MonoExtensionsKt$switchIfEmpty$1(s))), "this.switchIfEmpty(Mono.defer { s() })"); return $this$switchIfEmpty.switchIfEmpty(Mono.defer(new MonoExtensionsKt$switchIfEmpty$1(s))); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\002\020\000\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "Lreactor/core/publisher/Mono;", "T", "get"}) static final class MonoExtensionsKt$switchIfEmpty$1<T> implements Supplier { @NotNull public final Mono<T> get() { return (Mono<T>)this.$s.invoke(); }
/*     */ 
/*     */     
/*     */     MonoExtensionsKt$switchIfEmpty$1(Function0 param1Function0) {} }
/*     */ 
/*     */   
/*     */   @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3)
/*     */   final class MonoExtensionsKt$sam$java_util_function_Supplier$0 implements Supplier {
/*     */     MonoExtensionsKt$sam$java_util_function_Supplier$0(MonoExtensionsKt this$0) {
/*     */       this.function = (Function0)this$0;
/*     */     }
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3)
/*     */   final class MonoExtensionsKt$sam$java_util_concurrent_Callable$0 implements Callable {
/*     */     MonoExtensionsKt$sam$java_util_concurrent_Callable$0(MonoExtensionsKt this$0) {
/*     */       this.function = (Function0)this$0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */