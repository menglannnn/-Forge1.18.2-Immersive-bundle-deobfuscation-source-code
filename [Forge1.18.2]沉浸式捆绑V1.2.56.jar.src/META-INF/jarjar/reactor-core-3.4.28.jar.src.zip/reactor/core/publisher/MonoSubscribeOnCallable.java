/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.RejectedExecutionException;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSubscribeOnCallable<T>
/*    */   extends Mono<T>
/*    */   implements Fuseable, Scannable
/*    */ {
/*    */   final Callable<? extends T> callable;
/*    */   final Scheduler scheduler;
/*    */   
/*    */   MonoSubscribeOnCallable(Callable<? extends T> callable, Scheduler scheduler) {
/* 41 */     this.callable = Objects.<Callable<? extends T>>requireNonNull(callable, "callable");
/* 42 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler, "scheduler");
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 47 */     FluxSubscribeOnCallable.CallableSubscribeOnSubscription<T> parent = new FluxSubscribeOnCallable.CallableSubscribeOnSubscription<>(actual, this.callable, this.scheduler);
/*    */     
/* 49 */     actual.onSubscribe(parent);
/*    */     
/*    */     try {
/* 52 */       parent.setMainFuture(this.scheduler.schedule(parent));
/*    */     }
/* 54 */     catch (RejectedExecutionException ree) {
/* 55 */       if (parent.state != 4) {
/* 56 */         actual.onError(Operators.onRejectedExecution(ree, actual.currentContext()));
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 63 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/* 64 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*    */     
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoSubscribeOnCallable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */