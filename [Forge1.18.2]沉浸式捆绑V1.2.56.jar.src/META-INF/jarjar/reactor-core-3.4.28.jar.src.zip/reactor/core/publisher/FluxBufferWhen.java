/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxBufferWhen<T, OPEN, CLOSE, BUFFER extends Collection<? super T>>
/*     */   extends InternalFluxOperator<T, BUFFER>
/*     */ {
/*     */   final Publisher<OPEN> start;
/*     */   final Function<? super OPEN, ? extends Publisher<CLOSE>> end;
/*     */   final Supplier<BUFFER> bufferSupplier;
/*     */   final Supplier<? extends Queue<BUFFER>> queueSupplier;
/*     */   
/*     */   FluxBufferWhen(Flux<? extends T> source, Publisher<OPEN> start, Function<? super OPEN, ? extends Publisher<CLOSE>> end, Supplier<BUFFER> bufferSupplier, Supplier<? extends Queue<BUFFER>> queueSupplier) {
/*  67 */     super(source);
/*  68 */     this.start = Objects.<Publisher<OPEN>>requireNonNull(start, "start");
/*  69 */     this.end = Objects.<Function<? super OPEN, ? extends Publisher<CLOSE>>>requireNonNull(end, "end");
/*  70 */     this.bufferSupplier = Objects.<Supplier<BUFFER>>requireNonNull(bufferSupplier, "bufferSupplier");
/*  71 */     this.queueSupplier = Objects.<Supplier<? extends Queue<BUFFER>>>requireNonNull(queueSupplier, "queueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  76 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super BUFFER> actual) {
/*  81 */     BufferWhenMainSubscriber<T, OPEN, CLOSE, BUFFER> main = new BufferWhenMainSubscriber<>(actual, this.bufferSupplier, this.queueSupplier, this.start, this.end);
/*     */ 
/*     */     
/*  84 */     actual.onSubscribe(main);
/*     */     
/*  86 */     BufferWhenOpenSubscriber<OPEN> bos = new BufferWhenOpenSubscriber<>(main);
/*  87 */     if (main.subscribers.add(bos)) {
/*  88 */       this.start.subscribe((Subscriber)bos);
/*  89 */       return main;
/*     */     } 
/*     */     
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  98 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  99 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BufferWhenMainSubscriber<T, OPEN, CLOSE, BUFFER extends Collection<? super T>>
/*     */     implements InnerOperator<T, BUFFER>
/*     */   {
/*     */     final CoreSubscriber<? super BUFFER> actual;
/*     */     
/*     */     final Context ctx;
/*     */     final Publisher<? extends OPEN> bufferOpen;
/*     */     final Function<? super OPEN, ? extends Publisher<? extends CLOSE>> bufferClose;
/*     */     final Supplier<BUFFER> bufferSupplier;
/*     */     final Disposable.Composite subscribers;
/*     */     final Queue<BUFFER> queue;
/*     */     volatile long requested;
/* 115 */     static final AtomicLongFieldUpdater<BufferWhenMainSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(BufferWhenMainSubscriber.class, "requested");
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 119 */     static final AtomicReferenceFieldUpdater<BufferWhenMainSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(BufferWhenMainSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     volatile Throwable errors;
/*     */     
/* 124 */     static final AtomicReferenceFieldUpdater<BufferWhenMainSubscriber, Throwable> ERRORS = AtomicReferenceFieldUpdater.newUpdater(BufferWhenMainSubscriber.class, Throwable.class, "errors");
/*     */     
/*     */     volatile int windows;
/*     */     
/* 128 */     static final AtomicIntegerFieldUpdater<BufferWhenMainSubscriber> WINDOWS = AtomicIntegerFieldUpdater.newUpdater(BufferWhenMainSubscriber.class, "windows");
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     long index;
/*     */     
/*     */     LinkedHashMap<Long, BUFFER> buffers;
/*     */     
/*     */     long emitted;
/*     */     
/*     */     BufferWhenMainSubscriber(CoreSubscriber<? super BUFFER> actual, Supplier<BUFFER> bufferSupplier, Supplier<? extends Queue<BUFFER>> queueSupplier, Publisher<? extends OPEN> bufferOpen, Function<? super OPEN, ? extends Publisher<? extends CLOSE>> bufferClose) {
/* 141 */       this.actual = actual;
/* 142 */       this.ctx = actual.currentContext();
/* 143 */       this.bufferOpen = bufferOpen;
/* 144 */       this.bufferClose = bufferClose;
/* 145 */       this.bufferSupplier = bufferSupplier;
/* 146 */       this.queue = queueSupplier.get();
/* 147 */       this.buffers = new LinkedHashMap<>();
/* 148 */       this.subscribers = Disposables.composite();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 153 */       if (Operators.setOnce(S, this, s)) {
/* 154 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super BUFFER> actual() {
/* 160 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 165 */       synchronized (this) {
/* 166 */         Map<Long, BUFFER> bufs = this.buffers;
/* 167 */         if (bufs == null) {
/*     */           return;
/*     */         }
/* 170 */         if (bufs.isEmpty()) {
/* 171 */           Operators.onDiscard(t, this.ctx);
/*     */           return;
/*     */         } 
/* 174 */         for (Collection<T> collection : bufs.values()) {
/* 175 */           collection.add(t);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 182 */       if (Exceptions.addThrowable(ERRORS, this, t)) {
/* 183 */         Map<Long, BUFFER> bufs; this.subscribers.dispose();
/*     */         
/* 185 */         synchronized (this) {
/* 186 */           bufs = this.buffers;
/* 187 */           this.buffers = null;
/*     */         } 
/* 189 */         this.done = true;
/* 190 */         drain();
/* 191 */         if (bufs != null) {
/* 192 */           for (Collection<?> collection : bufs.values()) {
/* 193 */             Operators.onDiscardMultiple(collection, this.ctx);
/*     */           }
/*     */         }
/*     */       } else {
/*     */         
/* 198 */         Operators.onErrorDropped(t, this.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 204 */       this.subscribers.dispose();
/* 205 */       synchronized (this) {
/* 206 */         Map<Long, BUFFER> bufs = this.buffers;
/* 207 */         if (bufs == null) {
/*     */           return;
/*     */         }
/* 210 */         for (Collection collection : bufs.values()) {
/* 211 */           this.queue.offer((BUFFER)collection);
/*     */         }
/* 213 */         this.buffers = null;
/*     */       } 
/* 215 */       this.done = true;
/* 216 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 221 */       Operators.addCap(REQUESTED, this, n);
/* 222 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 227 */       if (Operators.terminate(S, this)) {
/* 228 */         Map<Long, BUFFER> bufs; this.cancelled = true;
/* 229 */         this.subscribers.dispose();
/*     */         
/* 231 */         synchronized (this) {
/* 232 */           bufs = this.buffers;
/* 233 */           this.buffers = null;
/*     */         } 
/*     */         
/* 236 */         if (WINDOWS.getAndIncrement(this) == 0) {
/* 237 */           Operators.onDiscardQueueWithClear(this.queue, this.ctx, Collection::stream);
/*     */         }
/*     */         
/* 240 */         if (bufs != null && !bufs.isEmpty()) {
/* 241 */           for (Collection<?> collection : bufs.values()) {
/* 242 */             Operators.onDiscardMultiple(collection, this.ctx);
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 249 */       if (WINDOWS.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 253 */       int missed = 1;
/* 254 */       long e = this.emitted;
/* 255 */       CoreSubscriber<? super BUFFER> coreSubscriber = this.actual;
/* 256 */       Queue<BUFFER> q = this.queue;
/*     */       
/*     */       do {
/* 259 */         long r = this.requested;
/*     */         
/* 261 */         while (e != r) {
/* 262 */           if (this.cancelled) {
/* 263 */             Operators.onDiscardQueueWithClear(q, this.ctx, Collection::stream);
/*     */             
/*     */             return;
/*     */           } 
/* 267 */           boolean d = this.done;
/* 268 */           if (d && this.errors != null) {
/* 269 */             Operators.onDiscardQueueWithClear(q, this.ctx, Collection::stream);
/* 270 */             Throwable ex = Exceptions.terminate(ERRORS, this);
/* 271 */             coreSubscriber.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/* 275 */           Collection collection = (Collection)q.poll();
/* 276 */           boolean empty = (collection == null);
/*     */           
/* 278 */           if (d && empty) {
/* 279 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 283 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 287 */           coreSubscriber.onNext(collection);
/* 288 */           e++;
/*     */         } 
/*     */         
/* 291 */         if (e == r) {
/* 292 */           if (this.cancelled) {
/* 293 */             Operators.onDiscardQueueWithClear(q, this.ctx, Collection::stream);
/*     */             
/*     */             return;
/*     */           } 
/* 297 */           if (this.done) {
/* 298 */             if (this.errors != null) {
/* 299 */               Operators.onDiscardQueueWithClear(q, this.ctx, Collection::stream);
/* 300 */               Throwable ex = Exceptions.terminate(ERRORS, this);
/* 301 */               coreSubscriber.onError(ex);
/*     */               return;
/*     */             } 
/* 304 */             if (q.isEmpty()) {
/* 305 */               coreSubscriber.onComplete();
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/*     */         } 
/* 311 */         this.emitted = e;
/* 312 */         missed = WINDOWS.addAndGet(this, -missed);
/* 313 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void open(OPEN token) {
/*     */       Publisher<? extends CLOSE> p;
/*     */       Collection collection;
/*     */       try {
/* 323 */         collection = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null Collection");
/* 324 */         p = Objects.<Publisher<? extends CLOSE>>requireNonNull(this.bufferClose.apply(token), "The bufferClose returned a null Publisher");
/*     */       }
/* 326 */       catch (Throwable ex) {
/* 327 */         Exceptions.throwIfFatal(ex);
/* 328 */         Operators.terminate(S, this);
/* 329 */         if (Exceptions.addThrowable(ERRORS, this, ex)) {
/* 330 */           Map<Long, BUFFER> bufs; this.subscribers.dispose();
/*     */           
/* 332 */           synchronized (this) {
/* 333 */             bufs = this.buffers;
/* 334 */             this.buffers = null;
/*     */           } 
/*     */           
/* 337 */           this.done = true;
/* 338 */           drain();
/* 339 */           if (bufs != null) {
/* 340 */             for (Collection<?> collection1 : bufs.values()) {
/* 341 */               Operators.onDiscardMultiple(collection1, this.ctx);
/*     */             }
/*     */           }
/*     */         } else {
/*     */           
/* 346 */           Operators.onErrorDropped(ex, this.ctx);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 351 */       long idx = this.index;
/* 352 */       this.index = idx + 1L;
/* 353 */       synchronized (this) {
/* 354 */         Map<Long, BUFFER> bufs = this.buffers;
/* 355 */         if (bufs == null) {
/*     */           return;
/*     */         }
/* 358 */         bufs.put(Long.valueOf(idx), (BUFFER)collection);
/*     */       } 
/*     */       
/* 361 */       FluxBufferWhen.BufferWhenCloseSubscriber<T, BUFFER> bc = new FluxBufferWhen.BufferWhenCloseSubscriber<>(this, idx);
/* 362 */       this.subscribers.add(bc);
/* 363 */       p.subscribe((Subscriber)bc);
/*     */     }
/*     */     
/*     */     void openComplete(FluxBufferWhen.BufferWhenOpenSubscriber<OPEN> os) {
/* 367 */       this.subscribers.remove(os);
/* 368 */       if (this.subscribers.size() == 0) {
/* 369 */         Operators.terminate(S, this);
/* 370 */         this.done = true;
/* 371 */         drain();
/*     */       } 
/*     */     }
/*     */     
/*     */     void close(FluxBufferWhen.BufferWhenCloseSubscriber<T, BUFFER> closer, long idx) {
/* 376 */       this.subscribers.remove(closer);
/* 377 */       boolean makeDone = false;
/* 378 */       if (this.subscribers.size() == 0) {
/* 379 */         makeDone = true;
/* 380 */         Operators.terminate(S, this);
/*     */       } 
/* 382 */       synchronized (this) {
/* 383 */         Map<Long, BUFFER> bufs = this.buffers;
/* 384 */         if (bufs == null) {
/*     */           return;
/*     */         }
/* 387 */         this.queue.offer(this.buffers.remove(Long.valueOf(idx)));
/*     */       } 
/* 389 */       if (makeDone) {
/* 390 */         this.done = true;
/*     */       }
/* 392 */       drain();
/*     */     }
/*     */     
/*     */     void boundaryError(Disposable boundary, Throwable ex) {
/* 396 */       Operators.terminate(S, this);
/* 397 */       this.subscribers.remove(boundary);
/* 398 */       if (Exceptions.addThrowable(ERRORS, this, ex)) {
/* 399 */         Map<Long, BUFFER> bufs; this.subscribers.dispose();
/*     */         
/* 401 */         synchronized (this) {
/* 402 */           bufs = this.buffers;
/* 403 */           this.buffers = null;
/*     */         } 
/* 405 */         this.done = true;
/* 406 */         drain();
/* 407 */         if (bufs != null) {
/* 408 */           for (Collection<?> collection : bufs.values()) {
/* 409 */             Operators.onDiscardMultiple(collection, this.ctx);
/*     */           }
/*     */         }
/*     */       } else {
/*     */         
/* 414 */         Operators.onErrorDropped(ex, this.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 421 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 422 */       if (key == Scannable.Attr.ACTUAL) return this.actual; 
/* 423 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 424 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.buffers.values()
/* 425 */             .stream()
/* 426 */             .mapToInt(Collection::size)
/* 427 */             .sum()); 
/* 428 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 429 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 430 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 431 */       if (key == Scannable.Attr.ERROR) return this.errors; 
/* 432 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 434 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BufferWhenOpenSubscriber<OPEN>
/*     */     implements Disposable, InnerConsumer<OPEN>
/*     */   {
/*     */     volatile Subscription subscription;
/* 443 */     static final AtomicReferenceFieldUpdater<BufferWhenOpenSubscriber, Subscription> SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(BufferWhenOpenSubscriber.class, Subscription.class, "subscription");
/*     */     
/*     */     final FluxBufferWhen.BufferWhenMainSubscriber<?, OPEN, ?, ?> parent;
/*     */     
/*     */     BufferWhenOpenSubscriber(FluxBufferWhen.BufferWhenMainSubscriber<?, OPEN, ?, ?> parent) {
/* 448 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 453 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 458 */       if (Operators.setOnce(SUBSCRIPTION, this, s)) {
/* 459 */         this.subscription.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 465 */       Operators.terminate(SUBSCRIPTION, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 470 */       return (this.subscription == Operators.cancelledSubscription());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(OPEN t) {
/* 475 */       this.parent.open(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 480 */       SUBSCRIPTION.lazySet(this, Operators.cancelledSubscription());
/* 481 */       this.parent.boundaryError(this, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 486 */       SUBSCRIPTION.lazySet(this, Operators.cancelledSubscription());
/* 487 */       this.parent.openComplete(this);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 493 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 494 */       if (key == Scannable.Attr.PARENT) return this.subscription; 
/* 495 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(Long.MAX_VALUE); 
/* 496 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 497 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 499 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BufferWhenCloseSubscriber<T, BUFFER extends Collection<? super T>>
/*     */     implements Disposable, InnerConsumer<Object>
/*     */   {
/*     */     volatile Subscription subscription;
/* 508 */     static final AtomicReferenceFieldUpdater<BufferWhenCloseSubscriber, Subscription> SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(BufferWhenCloseSubscriber.class, Subscription.class, "subscription");
/*     */     
/*     */     final FluxBufferWhen.BufferWhenMainSubscriber<T, ?, ?, BUFFER> parent;
/*     */     
/*     */     final long index;
/*     */     
/*     */     BufferWhenCloseSubscriber(FluxBufferWhen.BufferWhenMainSubscriber<T, ?, ?, BUFFER> parent, long index) {
/* 515 */       this.parent = parent;
/* 516 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 521 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 526 */       if (Operators.setOnce(SUBSCRIPTION, this, s)) {
/* 527 */         this.subscription.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 533 */       Operators.terminate(SUBSCRIPTION, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 538 */       return (this.subscription == Operators.cancelledSubscription());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 543 */       Subscription s = this.subscription;
/* 544 */       if (s != Operators.cancelledSubscription()) {
/* 545 */         SUBSCRIPTION.lazySet(this, Operators.cancelledSubscription());
/* 546 */         s.cancel();
/* 547 */         this.parent.close(this, this.index);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 553 */       if (this.subscription != Operators.cancelledSubscription()) {
/* 554 */         SUBSCRIPTION.lazySet(this, Operators.cancelledSubscription());
/* 555 */         this.parent.boundaryError(this, t);
/*     */       } else {
/*     */         
/* 558 */         Operators.onErrorDropped(t, this.parent.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 564 */       if (this.subscription != Operators.cancelledSubscription()) {
/* 565 */         SUBSCRIPTION.lazySet(this, Operators.cancelledSubscription());
/* 566 */         this.parent.close(this, this.index);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 573 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 574 */       if (key == Scannable.Attr.PARENT) return this.subscription; 
/* 575 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(Long.MAX_VALUE); 
/* 576 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 577 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 579 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxBufferWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */