/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxJoin<TLeft, TRight, TLeftEnd, TRightEnd, R>
/*     */   extends InternalFluxOperator<TLeft, R>
/*     */ {
/*     */   final Publisher<? extends TRight> other;
/*     */   final Function<? super TLeft, ? extends Publisher<TLeftEnd>> leftEnd;
/*     */   final Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd;
/*     */   final BiFunction<? super TLeft, ? super TRight, ? extends R> resultSelector;
/*     */   
/*     */   FluxJoin(Flux<TLeft> source, Publisher<? extends TRight> other, Function<? super TLeft, ? extends Publisher<TLeftEnd>> leftEnd, Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd, BiFunction<? super TLeft, ? super TRight, ? extends R> resultSelector) {
/*  65 */     super(source);
/*  66 */     this.other = Objects.<Publisher<? extends TRight>>requireNonNull(other, "other");
/*  67 */     this.leftEnd = Objects.<Function<? super TLeft, ? extends Publisher<TLeftEnd>>>requireNonNull(leftEnd, "leftEnd");
/*  68 */     this.rightEnd = Objects.<Function<? super TRight, ? extends Publisher<TRightEnd>>>requireNonNull(rightEnd, "rightEnd");
/*  69 */     this.resultSelector = Objects.<BiFunction<? super TLeft, ? super TRight, ? extends R>>requireNonNull(resultSelector, "resultSelector");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super TLeft> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  75 */     JoinSubscription<TLeft, TRight, TLeftEnd, TRightEnd, R> parent = new JoinSubscription<>(actual, this.leftEnd, this.rightEnd, this.resultSelector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     actual.onSubscribe(parent);
/*     */     
/*  83 */     FluxGroupJoin.LeftRightSubscriber left = new FluxGroupJoin.LeftRightSubscriber(parent, true);
/*  84 */     parent.cancellations.add(left);
/*  85 */     FluxGroupJoin.LeftRightSubscriber right = new FluxGroupJoin.LeftRightSubscriber(parent, false);
/*  86 */     parent.cancellations.add(right);
/*     */     
/*  88 */     this.source.subscribe(left);
/*  89 */     this.other.subscribe((Subscriber)right);
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  95 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  96 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class JoinSubscription<TLeft, TRight, TLeftEnd, TRightEnd, R>
/*     */     implements FluxGroupJoin.JoinSupport<R>
/*     */   {
/*     */     final Queue<Object> queue;
/*     */     
/*     */     final BiPredicate<Object, Object> queueBiOffer;
/*     */     
/*     */     final Disposable.Composite cancellations;
/*     */     
/*     */     final Map<Integer, TLeft> lefts;
/*     */     
/*     */     final Map<Integer, TRight> rights;
/*     */     
/*     */     final Function<? super TLeft, ? extends Publisher<TLeftEnd>> leftEnd;
/*     */     
/*     */     final Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd;
/*     */     
/*     */     final BiFunction<? super TLeft, ? super TRight, ? extends R> resultSelector;
/*     */     
/*     */     final CoreSubscriber<? super R> actual;
/*     */     volatile int wip;
/* 121 */     static final AtomicIntegerFieldUpdater<JoinSubscription> WIP = AtomicIntegerFieldUpdater.newUpdater(JoinSubscription.class, "wip");
/*     */ 
/*     */     
/*     */     volatile int active;
/*     */     
/* 126 */     static final AtomicIntegerFieldUpdater<JoinSubscription> ACTIVE = AtomicIntegerFieldUpdater.newUpdater(JoinSubscription.class, "active");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 132 */     static final AtomicLongFieldUpdater<JoinSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(JoinSubscription.class, "requested");
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */     
/* 138 */     static final AtomicReferenceFieldUpdater<JoinSubscription, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(JoinSubscription.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     int leftIndex;
/*     */ 
/*     */     
/*     */     int rightIndex;
/*     */     
/* 146 */     static final Integer LEFT_VALUE = Integer.valueOf(1);
/*     */     
/* 148 */     static final Integer RIGHT_VALUE = Integer.valueOf(2);
/*     */     
/* 150 */     static final Integer LEFT_CLOSE = Integer.valueOf(3);
/*     */     
/* 152 */     static final Integer RIGHT_CLOSE = Integer.valueOf(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JoinSubscription(CoreSubscriber<? super R> actual, Function<? super TLeft, ? extends Publisher<TLeftEnd>> leftEnd, Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd, BiFunction<? super TLeft, ? super TRight, ? extends R> resultSelector) {
/* 159 */       this.actual = actual;
/* 160 */       this.cancellations = Disposables.composite();
/* 161 */       this.queue = Queues.unboundedMultiproducer().get();
/* 162 */       this.queueBiOffer = (BiPredicate)this.queue;
/* 163 */       this.lefts = new LinkedHashMap<>();
/* 164 */       this.rights = new LinkedHashMap<>();
/* 165 */       this.leftEnd = leftEnd;
/* 166 */       this.rightEnd = rightEnd;
/* 167 */       this.resultSelector = resultSelector;
/* 168 */       ACTIVE.lazySet(this, 2);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super R> actual() {
/* 173 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 178 */       return Scannable.from(this.cancellations).inners();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 184 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 185 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancellations.isDisposed()); 
/* 186 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size() / 2); 
/* 187 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.active == 0)); 
/* 188 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 189 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 191 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 196 */       if (Operators.validate(n)) {
/* 197 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 203 */       if (this.cancellations.isDisposed()) {
/*     */         return;
/*     */       }
/* 206 */       this.cancellations.dispose();
/* 207 */       if (WIP.getAndIncrement(this) == 0) {
/* 208 */         this.queue.clear();
/*     */       }
/*     */     }
/*     */     
/*     */     void errorAll(Subscriber<?> a) {
/* 213 */       Throwable ex = Exceptions.terminate(ERROR, this);
/*     */       
/* 215 */       this.lefts.clear();
/* 216 */       this.rights.clear();
/*     */       
/* 218 */       a.onError(ex);
/*     */     }
/*     */     
/*     */     void drain() {
/* 222 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 226 */       int missed = 1;
/* 227 */       Queue<Object> q = this.queue;
/* 228 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/*     */ 
/*     */       
/*     */       while (true) {
/* 232 */         if (this.cancellations.isDisposed()) {
/* 233 */           q.clear();
/*     */           
/*     */           return;
/*     */         } 
/* 237 */         Throwable ex = this.error;
/* 238 */         if (ex != null) {
/* 239 */           q.clear();
/* 240 */           this.cancellations.dispose();
/* 241 */           errorAll((Subscriber<?>)coreSubscriber);
/*     */           
/*     */           return;
/*     */         } 
/* 245 */         boolean d = (this.active == 0);
/*     */         
/* 247 */         Integer mode = (Integer)q.poll();
/*     */         
/* 249 */         boolean empty = (mode == null);
/*     */         
/* 251 */         if (d && empty) {
/*     */           
/* 253 */           this.lefts.clear();
/* 254 */           this.rights.clear();
/* 255 */           this.cancellations.dispose();
/*     */           
/* 257 */           coreSubscriber.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 261 */         if (empty)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 434 */           missed = WIP.addAndGet(this, -missed);
/* 435 */           if (missed == 0)
/*     */             break;  continue; }  Object val = q.poll(); if (mode == LEFT_VALUE) { Publisher<TLeftEnd> p; TLeft left = (TLeft)val; int idx = this.leftIndex++; this.lefts.put(Integer.valueOf(idx), left); try { p = Objects.<Publisher<TLeftEnd>>requireNonNull(this.leftEnd.apply(left), "The leftEnd returned a null Publisher"); } catch (Throwable exc) { Exceptions.addThrowable(ERROR, this, Operators.onOperatorError(this, exc, left, this.actual.currentContext())); errorAll((Subscriber<?>)coreSubscriber); return; }  FluxGroupJoin.LeftRightEndSubscriber end = new FluxGroupJoin.LeftRightEndSubscriber(this, true, idx); this.cancellations.add(end); p.subscribe((Subscriber)end); ex = this.error; if (ex != null) { q.clear(); this.cancellations.dispose(); errorAll((Subscriber<?>)coreSubscriber); return; }  long r = this.requested; long e = 0L; for (TRight right : this.rights.values()) { R w; try { w = Objects.requireNonNull(this.resultSelector.apply(left, right), "The resultSelector returned a null value"); } catch (Throwable exc) { Exceptions.addThrowable(ERROR, this, Operators.onOperatorError(this, exc, right, this.actual.currentContext())); errorAll((Subscriber<?>)coreSubscriber); return; }  if (e != r) { coreSubscriber.onNext(w); e++; continue; }  Exceptions.addThrowable(ERROR, this, Exceptions.failWithOverflow("Could not emit value due to lack of requests")); q.clear(); this.cancellations.dispose(); errorAll((Subscriber<?>)coreSubscriber); return; }  if (e != 0L)
/*     */             Operators.produced(REQUESTED, this, e);  continue; }  if (mode == RIGHT_VALUE) { Publisher<TRightEnd> p; TRight right = (TRight)val; int idx = this.rightIndex++; this.rights.put(Integer.valueOf(idx), right); try { p = Objects.<Publisher<TRightEnd>>requireNonNull(this.rightEnd.apply(right), "The rightEnd returned a null Publisher"); } catch (Throwable exc) { Exceptions.addThrowable(ERROR, this, Operators.onOperatorError(this, exc, right, this.actual.currentContext())); errorAll((Subscriber<?>)coreSubscriber); return; }  FluxGroupJoin.LeftRightEndSubscriber end = new FluxGroupJoin.LeftRightEndSubscriber(this, false, idx); this.cancellations.add(end); p.subscribe((Subscriber)end); ex = this.error; if (ex != null) { q.clear(); this.cancellations.dispose(); errorAll((Subscriber<?>)coreSubscriber); return; }  long r = this.requested; long e = 0L; for (TLeft left : this.lefts.values()) { R w; try { w = Objects.requireNonNull(this.resultSelector.apply(left, right), "The resultSelector returned a null value"); } catch (Throwable exc) { Exceptions.addThrowable(ERROR, this, Operators.onOperatorError(this, exc, left, this.actual.currentContext())); errorAll((Subscriber<?>)coreSubscriber); return; }  if (e != r) { coreSubscriber.onNext(w); e++; continue; }  Exceptions.addThrowable(ERROR, this, Exceptions.failWithOverflow("Could not emit value due to lack of requests")); q.clear(); this.cancellations.dispose(); errorAll((Subscriber<?>)coreSubscriber); return; }
/*     */            if (e != 0L)
/*     */             Operators.produced(REQUESTED, this, e);  continue; }
/*     */          if (mode == LEFT_CLOSE) { FluxGroupJoin.LeftRightEndSubscriber end = (FluxGroupJoin.LeftRightEndSubscriber)val; this.lefts.remove(Integer.valueOf(end.index)); this.cancellations.remove(end); continue; }
/*     */          if (mode == RIGHT_CLOSE) { FluxGroupJoin.LeftRightEndSubscriber end = (FluxGroupJoin.LeftRightEndSubscriber)val; this.rights.remove(Integer.valueOf(end.index)); this.cancellations.remove(end); }
/*     */       
/* 443 */       }  } public void innerError(Throwable ex) { if (Exceptions.addThrowable(ERROR, this, ex)) {
/* 444 */         ACTIVE.decrementAndGet(this);
/* 445 */         drain();
/*     */       } else {
/*     */         
/* 448 */         Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/*     */     public void innerComplete(FluxGroupJoin.LeftRightSubscriber sender) {
/* 454 */       this.cancellations.remove(sender);
/* 455 */       ACTIVE.decrementAndGet(this);
/* 456 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerValue(boolean isLeft, Object o) {
/* 461 */       this.queueBiOffer.test(isLeft ? LEFT_VALUE : RIGHT_VALUE, o);
/* 462 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerClose(boolean isLeft, FluxGroupJoin.LeftRightEndSubscriber index) {
/* 467 */       this.queueBiOffer.test(isLeft ? LEFT_CLOSE : RIGHT_CLOSE, index);
/* 468 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerCloseError(Throwable ex) {
/* 473 */       if (Exceptions.addThrowable(ERROR, this, ex)) {
/* 474 */         drain();
/*     */       } else {
/*     */         
/* 477 */         Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxJoin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */