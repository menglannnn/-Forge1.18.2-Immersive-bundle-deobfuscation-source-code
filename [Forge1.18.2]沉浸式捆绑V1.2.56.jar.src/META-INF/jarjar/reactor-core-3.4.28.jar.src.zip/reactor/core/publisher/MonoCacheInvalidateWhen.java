/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoCacheInvalidateWhen<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */ {
/*  47 */   private static final Logger LOGGER = Loggers.getLogger(MonoCacheInvalidateWhen.class);
/*     */   
/*     */   final Function<? super T, Mono<Void>> invalidationTriggerGenerator;
/*     */   
/*     */   @Nullable
/*     */   final Consumer<? super T> invalidateHandler;
/*     */   
/*     */   volatile MonoCacheInvalidateIf.State<T> state;
/*     */   
/*  56 */   static final AtomicReferenceFieldUpdater<MonoCacheInvalidateWhen, MonoCacheInvalidateIf.State> STATE = AtomicReferenceFieldUpdater.newUpdater(MonoCacheInvalidateWhen.class, MonoCacheInvalidateIf.State.class, "state");
/*     */ 
/*     */   
/*     */   MonoCacheInvalidateWhen(Mono<T> source, Function<? super T, Mono<Void>> invalidationTriggerGenerator, @Nullable Consumer<? super T> invalidateHandler) {
/*  60 */     super(source);
/*  61 */     this.invalidationTriggerGenerator = Objects.<Function<? super T, Mono<Void>>>requireNonNull(invalidationTriggerGenerator, "invalidationTriggerGenerator");
/*  62 */     this.invalidateHandler = invalidateHandler;
/*     */     
/*  64 */     MonoCacheInvalidateIf.State<T> state = (MonoCacheInvalidateIf.State)MonoCacheInvalidateIf.EMPTY_STATE;
/*  65 */     this.state = state;
/*     */   }
/*     */   
/*     */   boolean compareAndInvalidate(MonoCacheInvalidateIf.State<T> expected) {
/*  69 */     if (STATE.compareAndSet(this, expected, MonoCacheInvalidateIf.EMPTY_STATE)) {
/*  70 */       if (expected instanceof MonoCacheInvalidateIf.ValueState) {
/*  71 */         LOGGER.trace("invalidated {}", new Object[] { expected.get() });
/*  72 */         safeInvalidateHandler(expected.get());
/*     */       } 
/*  74 */       return true;
/*     */     } 
/*  76 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   void invalidate() {
/*  81 */     MonoCacheInvalidateIf.State<T> oldState = STATE.getAndSet(this, MonoCacheInvalidateIf.EMPTY_STATE);
/*  82 */     if (oldState instanceof MonoCacheInvalidateIf.ValueState) {
/*  83 */       LOGGER.trace("invalidated {}", new Object[] { oldState.get() });
/*  84 */       safeInvalidateHandler(oldState.get());
/*     */     } 
/*     */   }
/*     */   
/*     */   void safeInvalidateHandler(@Nullable T value) {
/*  89 */     if (value != null && this.invalidateHandler != null) {
/*     */       try {
/*  91 */         this.invalidateHandler.accept(value);
/*     */       }
/*  93 */       catch (Throwable invalidateHandlerError) {
/*  94 */         LOGGER.warnOrDebug(isVerbose -> isVerbose ? ("Failed to apply invalidate handler on value " + value) : "Failed to apply invalidate handler", invalidateHandlerError);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*     */     MonoCacheInvalidateIf.State<T> state;
/* 103 */     CacheMonoSubscriber<T> inner = new CacheMonoSubscriber<>(actual);
/* 104 */     actual.onSubscribe(inner);
/*     */     while (true) {
/* 106 */       state = this.state;
/* 107 */       if (state == MonoCacheInvalidateIf.EMPTY_STATE || state instanceof CoordinatorSubscriber) {
/* 108 */         CoordinatorSubscriber<T> coordinator; boolean subscribe = false;
/*     */         
/* 110 */         if (state == MonoCacheInvalidateIf.EMPTY_STATE) {
/* 111 */           coordinator = new CoordinatorSubscriber<>(this);
/* 112 */           if (!STATE.compareAndSet(this, MonoCacheInvalidateIf.EMPTY_STATE, coordinator)) {
/*     */             continue;
/*     */           }
/* 115 */           subscribe = true;
/*     */         } else {
/*     */           
/* 118 */           coordinator = (CoordinatorSubscriber<T>)state;
/*     */         } 
/*     */         
/* 121 */         if (coordinator.add(inner)) {
/* 122 */           if (inner.isCancelled()) {
/* 123 */             coordinator.remove(inner);
/*     */           } else {
/*     */             
/* 126 */             inner.coordinator = coordinator;
/*     */           } 
/*     */           
/* 129 */           if (subscribe) {
/* 130 */             this.source.subscribe(coordinator);
/*     */           }
/* 132 */           return null;
/*     */         }  continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 137 */     inner.complete(state.get());
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 145 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 146 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CoordinatorSubscriber<T>
/*     */     implements InnerConsumer<T>, MonoCacheInvalidateIf.State<T>
/*     */   {
/*     */     final MonoCacheInvalidateWhen<T> main;
/*     */     
/*     */     Subscription subscription;
/*     */     
/*     */     volatile MonoCacheInvalidateWhen.CacheMonoSubscriber<T>[] subscribers;
/* 158 */     static final AtomicReferenceFieldUpdater<CoordinatorSubscriber, MonoCacheInvalidateWhen.CacheMonoSubscriber[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(CoordinatorSubscriber.class, (Class)MonoCacheInvalidateWhen.CacheMonoSubscriber[].class, "subscribers");
/*     */ 
/*     */     
/* 161 */     private static final MonoCacheInvalidateWhen.CacheMonoSubscriber[] COORDINATOR_DONE = new MonoCacheInvalidateWhen.CacheMonoSubscriber[0];
/*     */     
/* 163 */     private static final MonoCacheInvalidateWhen.CacheMonoSubscriber[] COORDINATOR_INIT = new MonoCacheInvalidateWhen.CacheMonoSubscriber[0];
/*     */ 
/*     */     
/*     */     CoordinatorSubscriber(MonoCacheInvalidateWhen<T> main) {
/* 167 */       this.main = main;
/* 168 */       this.subscribers = (MonoCacheInvalidateWhen.CacheMonoSubscriber<T>[])COORDINATOR_INIT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T get() {
/* 178 */       throw new UnsupportedOperationException("coordinator State#get shouldn't be used");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final boolean add(MonoCacheInvalidateWhen.CacheMonoSubscriber<T> toAdd) {
/*     */       while (true) {
/* 192 */         MonoCacheInvalidateWhen.CacheMonoSubscriber<T>[] a = this.subscribers;
/* 193 */         if (a == COORDINATOR_DONE) {
/* 194 */           return false;
/*     */         }
/* 196 */         int n = a.length;
/*     */         
/* 198 */         MonoCacheInvalidateWhen.CacheMonoSubscriber[] arrayOfCacheMonoSubscriber = new MonoCacheInvalidateWhen.CacheMonoSubscriber[n + 1];
/* 199 */         System.arraycopy(a, 0, arrayOfCacheMonoSubscriber, 0, n);
/* 200 */         arrayOfCacheMonoSubscriber[n] = toAdd;
/* 201 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfCacheMonoSubscriber)) {
/* 202 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     final void remove(MonoCacheInvalidateWhen.CacheMonoSubscriber<T> toRemove) {
/*     */       while (true) {
/* 209 */         MonoCacheInvalidateWhen.CacheMonoSubscriber<T>[] a = this.subscribers;
/* 210 */         if (a == COORDINATOR_DONE || a == COORDINATOR_INIT) {
/*     */           return;
/*     */         }
/* 213 */         int n = a.length;
/* 214 */         int j = -1;
/* 215 */         for (int i = 0; i < n; i++) {
/* 216 */           if (a[i] == toRemove) {
/* 217 */             j = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 222 */         if (j < 0) {
/*     */           return;
/*     */         }
/*     */         
/* 226 */         if (n == 1) {
/* 227 */           if (SUBSCRIBERS.compareAndSet(this, a, COORDINATOR_DONE)) {
/* 228 */             if (this.main.compareAndInvalidate(this)) {
/* 229 */               this.subscription.cancel();
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/*     */           continue;
/*     */         } 
/* 236 */         MonoCacheInvalidateWhen.CacheMonoSubscriber[] arrayOfCacheMonoSubscriber = new MonoCacheInvalidateWhen.CacheMonoSubscriber[n - 1];
/* 237 */         System.arraycopy(a, 0, arrayOfCacheMonoSubscriber, 0, j);
/* 238 */         System.arraycopy(a, j + 1, arrayOfCacheMonoSubscriber, j, n - j - 1);
/* 239 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfCacheMonoSubscriber)) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 249 */       if (Operators.validate(this.subscription, s)) {
/* 250 */         this.subscription = s;
/* 251 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean cacheLoadFailure(MonoCacheInvalidateIf.State<T> expected, Throwable failure) {
/* 256 */       if (MonoCacheInvalidateWhen.STATE.compareAndSet(this.main, expected, MonoCacheInvalidateIf.EMPTY_STATE)) {
/* 257 */         for (MonoCacheInvalidateWhen.CacheMonoSubscriber<T> inner : (MonoCacheInvalidateWhen.CacheMonoSubscriber[])SUBSCRIBERS.getAndSet(this, COORDINATOR_DONE)) {
/* 258 */           inner.onError(failure);
/*     */         }
/*     */         
/* 261 */         return true;
/*     */       } 
/* 263 */       return false;
/*     */     }
/*     */     
/*     */     void cacheLoad(T value) {
/* 267 */       MonoCacheInvalidateIf.State<T> valueState = new MonoCacheInvalidateIf.ValueState<>(value);
/* 268 */       if (MonoCacheInvalidateWhen.STATE.compareAndSet(this.main, this, valueState)) {
/* 269 */         Mono<Void> invalidateTrigger = null;
/*     */         try {
/* 271 */           invalidateTrigger = Objects.<Mono<Void>>requireNonNull(this.main.invalidationTriggerGenerator
/* 272 */               .apply(value), "invalidationTriggerGenerator produced a null trigger");
/*     */         
/*     */         }
/* 275 */         catch (Throwable generatorError) {
/* 276 */           if (cacheLoadFailure(valueState, generatorError)) {
/* 277 */             this.main.safeInvalidateHandler(value);
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/* 282 */         for (MonoCacheInvalidateWhen.CacheMonoSubscriber<T> inner : (MonoCacheInvalidateWhen.CacheMonoSubscriber[])SUBSCRIBERS.getAndSet(this, COORDINATOR_DONE)) {
/* 283 */           inner.complete(value);
/*     */         }
/* 285 */         invalidateTrigger.subscribe(new MonoCacheInvalidateWhen.TriggerSubscriber(this.main));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 291 */       if (this.main.state != this) {
/* 292 */         Operators.onNextDroppedMulticast(t, (InnerProducer<?>[])this.subscribers);
/*     */         return;
/*     */       } 
/* 295 */       cacheLoad(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 300 */       if (this.main.state != this) {
/* 301 */         Operators.onErrorDroppedMulticast(t, (InnerProducer<?>[])this.subscribers);
/*     */         return;
/*     */       } 
/* 304 */       cacheLoadFailure(this, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 309 */       if (this.main.state == this)
/*     */       {
/* 311 */         cacheLoadFailure(this, new NoSuchElementException("cacheInvalidateWhen expects a value, source completed empty"));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 318 */       return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 324 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 325 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CacheMonoSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     MonoCacheInvalidateWhen.CoordinatorSubscriber<T> coordinator;
/*     */     
/*     */     CacheMonoSubscriber(CoreSubscriber<? super T> actual) {
/* 335 */       super(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 340 */       super.cancel();
/* 341 */       MonoCacheInvalidateWhen.CoordinatorSubscriber<T> coordinator = this.coordinator;
/* 342 */       if (coordinator != null) {
/* 343 */         coordinator.remove(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 349 */       if (key == Scannable.Attr.PARENT) return this.coordinator.main; 
/* 350 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 351 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class TriggerSubscriber
/*     */     implements InnerConsumer<Void>
/*     */   {
/*     */     final MonoCacheInvalidateWhen<?> main;
/*     */     
/*     */     TriggerSubscriber(MonoCacheInvalidateWhen<?> main) {
/* 361 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 366 */       s.request(1L);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Void unused) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 376 */       MonoCacheInvalidateWhen.LOGGER.debug("Invalidation triggered by onError(" + t + ")");
/* 377 */       this.main.invalidate();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 382 */       this.main.invalidate();
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 387 */       return Context.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 393 */       if (key == Scannable.Attr.PARENT) return this.main;
/*     */       
/* 395 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.main.state == MonoCacheInvalidateIf.EMPTY_STATE || this.main.state instanceof MonoCacheInvalidateWhen.CoordinatorSubscriber)); 
/* 396 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 397 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(1); 
/* 398 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoCacheInvalidateWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */