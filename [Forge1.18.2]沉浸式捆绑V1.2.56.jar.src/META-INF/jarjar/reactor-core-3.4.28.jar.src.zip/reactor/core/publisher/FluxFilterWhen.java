/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FluxFilterWhen<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<Boolean>> asyncPredicate;
/*     */   final int bufferSize;
/*     */   
/*     */   FluxFilterWhen(Flux<T> source, Function<? super T, ? extends Publisher<Boolean>> asyncPredicate, int bufferSize) {
/*  62 */     super(source);
/*  63 */     this.asyncPredicate = asyncPredicate;
/*  64 */     this.bufferSize = bufferSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  69 */     return new FluxFilterWhenSubscriber<>(actual, this.asyncPredicate, this.bufferSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  74 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  75 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FluxFilterWhenSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final Function<? super T, ? extends Publisher<Boolean>> asyncPredicate;
/*     */     
/*     */     final int bufferSize;
/*     */     
/*     */     final AtomicReferenceArray<T> toFilter;
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final Context ctx;
/*     */     int consumed;
/*     */     long consumerIndex;
/*     */     long emitted;
/*     */     Boolean innerResult;
/*     */     long producerIndex;
/*     */     Subscription upstream;
/*     */     volatile boolean cancelled;
/*     */     volatile FluxFilterWhen.FilterWhenInner current;
/*     */     volatile boolean done;
/*     */     volatile Throwable error;
/*     */     volatile long requested;
/*     */     volatile int state;
/*     */     volatile int wip;
/* 102 */     static final AtomicReferenceFieldUpdater<FluxFilterWhenSubscriber, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(FluxFilterWhenSubscriber.class, Throwable.class, "error");
/*     */     
/* 104 */     static final AtomicLongFieldUpdater<FluxFilterWhenSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(FluxFilterWhenSubscriber.class, "requested");
/*     */     
/* 106 */     static final AtomicIntegerFieldUpdater<FluxFilterWhenSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(FluxFilterWhenSubscriber.class, "wip");
/*     */     
/* 108 */     static final AtomicReferenceFieldUpdater<FluxFilterWhenSubscriber, FluxFilterWhen.FilterWhenInner> CURRENT = AtomicReferenceFieldUpdater.newUpdater(FluxFilterWhenSubscriber.class, FluxFilterWhen.FilterWhenInner.class, "current");
/*     */ 
/*     */     
/* 111 */     static final FluxFilterWhen.FilterWhenInner INNER_CANCELLED = new FluxFilterWhen.FilterWhenInner(null, false);
/*     */     
/*     */     static final int STATE_FRESH = 0;
/*     */     
/*     */     static final int STATE_RUNNING = 1;
/*     */     
/*     */     static final int STATE_RESULT = 2;
/*     */     
/*     */     FluxFilterWhenSubscriber(CoreSubscriber<? super T> actual, Function<? super T, ? extends Publisher<Boolean>> asyncPredicate, int bufferSize) {
/* 120 */       this.actual = actual;
/* 121 */       this.ctx = actual.currentContext();
/* 122 */       this.toFilter = new AtomicReferenceArray<>(Queues.ceilingNextPowerOfTwo(bufferSize));
/* 123 */       this.asyncPredicate = asyncPredicate;
/* 124 */       this.bufferSize = bufferSize;
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 129 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 134 */       long pi = this.producerIndex;
/* 135 */       int m = this.toFilter.length() - 1;
/*     */       
/* 137 */       int offset = (int)pi & m;
/* 138 */       this.toFilter.lazySet(offset, t);
/* 139 */       this.producerIndex = pi + 1L;
/* 140 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 145 */       ERROR.set(this, t);
/* 146 */       this.done = true;
/* 147 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 152 */       this.done = true;
/* 153 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 158 */       if (Operators.validate(n)) {
/* 159 */         Operators.addCap(REQUESTED, this, n);
/* 160 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 166 */       if (!this.cancelled) {
/* 167 */         this.cancelled = true;
/* 168 */         this.upstream.cancel();
/* 169 */         cancelInner();
/* 170 */         if (WIP.getAndIncrement(this) == 0) {
/* 171 */           clear();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelInner() {
/* 177 */       FluxFilterWhen.FilterWhenInner a = CURRENT.get(this);
/* 178 */       if (a != INNER_CANCELLED) {
/* 179 */         a = CURRENT.getAndSet(this, INNER_CANCELLED);
/* 180 */         if (a != null && a != INNER_CANCELLED) {
/* 181 */           a.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void clear() {
/* 187 */       int n = this.toFilter.length();
/* 188 */       for (int i = 0; i < n; i++) {
/* 189 */         T old = this.toFilter.getAndSet(i, null);
/* 190 */         Operators.onDiscard(old, this.ctx);
/*     */       } 
/* 192 */       this.innerResult = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 197 */       if (Operators.validate(this.upstream, s)) {
/* 198 */         this.upstream = s;
/* 199 */         this.actual.onSubscribe(this);
/* 200 */         s.request(this.bufferSize);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void drain() {
/* 206 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 210 */       int missed = 1;
/* 211 */       int limit = Operators.unboundedOrLimit(this.bufferSize);
/* 212 */       long e = this.emitted;
/* 213 */       long ci = this.consumerIndex;
/* 214 */       int f = this.consumed;
/* 215 */       int m = this.toFilter.length() - 1;
/* 216 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       
/*     */       while (true) {
/* 219 */         long r = this.requested;
/*     */         
/* 221 */         while (e != r) {
/* 222 */           if (this.cancelled) {
/* 223 */             clear();
/*     */             
/*     */             return;
/*     */           } 
/* 227 */           boolean d = this.done;
/*     */           
/* 229 */           int offset = (int)ci & m;
/* 230 */           T t = this.toFilter.get(offset);
/* 231 */           boolean empty = (t == null);
/*     */           
/* 233 */           if (d && empty) {
/* 234 */             Throwable ex = Exceptions.terminate(ERROR, this);
/* 235 */             if (ex == null) {
/* 236 */               coreSubscriber.onComplete();
/*     */             } else {
/* 238 */               coreSubscriber.onError(ex);
/*     */             } 
/*     */             
/*     */             return;
/*     */           } 
/* 243 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 247 */           int s = this.state;
/* 248 */           if (s == 0) {
/*     */             Publisher<Boolean> p;
/*     */             
/*     */             try {
/* 252 */               p = Objects.<Publisher<Boolean>>requireNonNull(this.asyncPredicate.apply(t), "The asyncPredicate returned a null value");
/* 253 */             } catch (Throwable ex) {
/* 254 */               Exceptions.throwIfFatal(ex);
/* 255 */               Exceptions.addThrowable(ERROR, this, ex);
/* 256 */               p = null;
/*     */             } 
/*     */             
/* 259 */             if (p != null) {
/* 260 */               if (p instanceof Callable) {
/*     */                 Boolean u;
/*     */                 
/*     */                 try {
/* 264 */                   u = ((Callable<Boolean>)p).call();
/* 265 */                 } catch (Throwable ex) {
/* 266 */                   Exceptions.throwIfFatal(ex);
/* 267 */                   Exceptions.addThrowable(ERROR, this, ex);
/* 268 */                   u = null;
/*     */                 } 
/*     */                 
/* 271 */                 if (u != null && u.booleanValue()) {
/* 272 */                   coreSubscriber.onNext(t);
/* 273 */                   e++;
/*     */                 } else {
/*     */                   
/* 276 */                   Operators.onDiscard(t, this.ctx);
/*     */                 } 
/*     */               } else {
/* 279 */                 FluxFilterWhen.FilterWhenInner inner = new FluxFilterWhen.FilterWhenInner(this, !(p instanceof Mono));
/* 280 */                 if (CURRENT.compareAndSet(this, null, inner)) {
/* 281 */                   this.state = 1;
/* 282 */                   p.subscribe((Subscriber)inner);
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/* 288 */             T old = this.toFilter.getAndSet(offset, null);
/* 289 */             Operators.onDiscard(old, this.ctx);
/* 290 */             ci++;
/* 291 */             if (++f == limit) {
/* 292 */               f = 0;
/* 293 */               this.upstream.request(limit);
/*     */             }  continue;
/*     */           } 
/* 296 */           if (s == 2) {
/* 297 */             Boolean u = this.innerResult;
/* 298 */             this.innerResult = null;
/*     */             
/* 300 */             if (u != null && u.booleanValue()) {
/* 301 */               coreSubscriber.onNext(t);
/* 302 */               e++;
/*     */             } else {
/*     */               
/* 305 */               Operators.onDiscard(t, this.ctx);
/*     */             } 
/*     */             
/* 308 */             this.toFilter.lazySet(offset, null);
/* 309 */             ci++;
/* 310 */             if (++f == limit) {
/* 311 */               f = 0;
/* 312 */               this.upstream.request(limit);
/*     */             } 
/* 314 */             this.state = 0;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 320 */         if (e == r) {
/* 321 */           if (this.cancelled) {
/* 322 */             clear();
/*     */             
/*     */             return;
/*     */           } 
/* 326 */           boolean d = this.done;
/*     */           
/* 328 */           int offset = (int)ci & m;
/* 329 */           T t = this.toFilter.get(offset);
/* 330 */           boolean empty = (t == null);
/*     */           
/* 332 */           if (d && empty) {
/* 333 */             Throwable ex = Exceptions.terminate(ERROR, this);
/* 334 */             if (ex == null) {
/* 335 */               coreSubscriber.onComplete();
/*     */             } else {
/* 337 */               coreSubscriber.onError(ex);
/*     */             } 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 343 */         int w = this.wip;
/* 344 */         if (missed == w) {
/* 345 */           this.consumed = f;
/* 346 */           this.consumerIndex = ci;
/* 347 */           this.emitted = e;
/* 348 */           missed = WIP.addAndGet(this, -missed);
/* 349 */           if (missed == 0)
/*     */             break; 
/*     */           continue;
/*     */         } 
/* 353 */         missed = w;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void clearCurrent() {
/* 359 */       FluxFilterWhen.FilterWhenInner c = this.current;
/* 360 */       if (c != INNER_CANCELLED) {
/* 361 */         CURRENT.compareAndSet(this, c, null);
/*     */       }
/*     */     }
/*     */     
/*     */     void innerResult(Boolean item) {
/* 366 */       this.innerResult = item;
/* 367 */       this.state = 2;
/* 368 */       clearCurrent();
/* 369 */       drain();
/*     */     }
/*     */     
/*     */     void innerError(Throwable ex) {
/* 373 */       Exceptions.addThrowable(ERROR, this, ex);
/* 374 */       this.state = 2;
/* 375 */       clearCurrent();
/* 376 */       drain();
/*     */     }
/*     */     
/*     */     void innerComplete() {
/* 380 */       this.state = 2;
/* 381 */       clearCurrent();
/* 382 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 388 */       if (key == Scannable.Attr.PARENT) return this.upstream; 
/* 389 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 390 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 391 */       if (key == Scannable.Attr.ERROR)
/* 392 */         return this.error; 
/* 393 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 394 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.toFilter.length()); 
/* 395 */       if (key == Scannable.Attr.LARGE_BUFFERED) return Long.valueOf(this.producerIndex - this.consumerIndex); 
/* 396 */       if (key == Scannable.Attr.BUFFERED) {
/* 397 */         long realBuffered = this.producerIndex - this.consumerIndex;
/* 398 */         if (realBuffered <= 2147483647L) return Integer.valueOf((int)realBuffered); 
/* 399 */         return Integer.valueOf(-2147483648);
/*     */       } 
/* 401 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.bufferSize); 
/* 402 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 404 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 409 */       FluxFilterWhen.FilterWhenInner c = this.current;
/* 410 */       return (c == null) ? Stream.<Scannable>empty() : Stream.<Scannable>of(c);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FilterWhenInner
/*     */     implements InnerConsumer<Boolean>
/*     */   {
/*     */     final FluxFilterWhen.FluxFilterWhenSubscriber<?> parent;
/*     */     
/*     */     final boolean cancelOnNext;
/*     */     
/*     */     boolean done;
/*     */     volatile Subscription sub;
/* 424 */     static final AtomicReferenceFieldUpdater<FilterWhenInner, Subscription> SUB = AtomicReferenceFieldUpdater.newUpdater(FilterWhenInner.class, Subscription.class, "sub");
/*     */     
/*     */     FilterWhenInner(FluxFilterWhen.FluxFilterWhenSubscriber<?> parent, boolean cancelOnNext) {
/* 427 */       this.parent = parent;
/* 428 */       this.cancelOnNext = cancelOnNext;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 433 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 438 */       if (Operators.setOnce(SUB, this, s)) {
/* 439 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Boolean t) {
/* 445 */       if (!this.done) {
/* 446 */         if (this.cancelOnNext) {
/* 447 */           this.sub.cancel();
/*     */         }
/* 449 */         this.done = true;
/* 450 */         this.parent.innerResult(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 456 */       if (!this.done) {
/* 457 */         this.done = true;
/* 458 */         this.parent.innerError(t);
/*     */       } else {
/* 460 */         Operators.onErrorDropped(t, this.parent.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 466 */       if (!this.done) {
/* 467 */         this.done = true;
/* 468 */         this.parent.innerComplete();
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancel() {
/* 473 */       Operators.terminate(SUB, this);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 479 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 480 */       if (key == Scannable.Attr.ACTUAL) return this.sub; 
/* 481 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.sub == Operators.cancelledSubscription())); 
/* 482 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 483 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 484 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.done ? 0L : 1L); 
/* 485 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 487 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxFilterWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */