/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Queue;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Sinks
/*     */ {
/*     */   public static <T> Empty<T> empty() {
/*  66 */     return SinksSpecs.DEFAULT_SINKS.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> One<T> one() {
/*  81 */     return SinksSpecs.DEFAULT_SINKS.one();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ManySpec many() {
/*  93 */     return SinksSpecs.DEFAULT_SINKS.many();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RootSpec unsafe() {
/* 107 */     return SinksSpecs.UNSAFE_ROOT_SPEC;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum EmitResult
/*     */   {
/* 122 */     OK,
/*     */ 
/*     */ 
/*     */     
/* 126 */     FAIL_TERMINATED,
/*     */ 
/*     */ 
/*     */     
/* 130 */     FAIL_OVERFLOW,
/*     */ 
/*     */ 
/*     */     
/* 134 */     FAIL_CANCELLED,
/*     */ 
/*     */ 
/*     */     
/* 138 */     FAIL_NON_SERIALIZED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     FAIL_ZERO_SUBSCRIBER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSuccess() {
/* 152 */       return (this == OK);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isFailure() {
/* 159 */       return (this != OK);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void orThrow() {
/* 173 */       if (this == OK)
/*     */         return; 
/* 175 */       throw new Sinks.EmissionException(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void orThrowWithCause(Throwable cause) {
/* 188 */       if (this == OK)
/*     */         return; 
/* 190 */       throw new Sinks.EmissionException(cause, this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class EmissionException
/*     */     extends IllegalStateException
/*     */   {
/*     */     final Sinks.EmitResult reason;
/*     */ 
/*     */     
/*     */     public EmissionException(Sinks.EmitResult reason) {
/* 203 */       this(reason, "Sink emission failed with " + reason);
/*     */     }
/*     */     
/*     */     public EmissionException(Throwable cause, Sinks.EmitResult reason) {
/* 207 */       super("Sink emission failed with " + reason, cause);
/* 208 */       this.reason = reason;
/*     */     }
/*     */     
/*     */     public EmissionException(Sinks.EmitResult reason, String message) {
/* 212 */       super(message);
/* 213 */       this.reason = reason;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Sinks.EmitResult getReason() {
/* 222 */       return this.reason;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class OptimisticEmitFailureHandler
/*     */     implements EmitFailureHandler
/*     */   {
/*     */     private final long deadline;
/*     */ 
/*     */     
/*     */     OptimisticEmitFailureHandler(Duration duration) {
/* 235 */       this.deadline = System.nanoTime() + duration.toNanos();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean onEmitFailure(SignalType signalType, Sinks.EmitResult emitResult) {
/* 240 */       return (emitResult.equals(Sinks.EmitResult.FAIL_NON_SERIALIZED) && System.nanoTime() < this.deadline);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface EmitFailureHandler
/*     */   {
/*     */     public static final EmitFailureHandler FAIL_FAST = (signalType, emission) -> false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean onEmitFailure(SignalType param1SignalType, Sinks.EmitResult param1EmitResult);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static EmitFailureHandler busyLooping(Duration duration) {
/* 279 */       return new Sinks.OptimisticEmitFailureHandler(duration);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface RootSpec {
/*     */     <T> Sinks.Empty<T> empty();
/*     */     
/*     */     <T> Sinks.One<T> one();
/*     */     
/*     */     Sinks.ManySpec many();
/*     */     
/*     */     Sinks.ManyWithUpstreamUnsafeSpec manyWithUpstream();
/*     */   }
/*     */   
/*     */   public static interface ManySpec {
/*     */     Sinks.UnicastSpec unicast();
/*     */     
/*     */     Sinks.MulticastSpec multicast();
/*     */     
/*     */     Sinks.MulticastReplaySpec replay();
/*     */   }
/*     */   
/*     */   public static interface ManyWithUpstreamUnsafeSpec {
/*     */     <T> Sinks.ManyWithUpstream<T> multicastOnBackpressureBuffer();
/*     */     
/*     */     <T> Sinks.ManyWithUpstream<T> multicastOnBackpressureBuffer(int param1Int, boolean param1Boolean);
/*     */   }
/*     */   
/*     */   public static interface UnicastSpec {
/*     */     <T> Sinks.Many<T> onBackpressureBuffer();
/*     */     
/*     */     <T> Sinks.Many<T> onBackpressureBuffer(Queue<T> param1Queue);
/*     */     
/*     */     <T> Sinks.Many<T> onBackpressureBuffer(Queue<T> param1Queue, Disposable param1Disposable);
/*     */     
/*     */     <T> Sinks.Many<T> onBackpressureError();
/*     */   }
/*     */   
/*     */   public static interface MulticastSpec {
/*     */     <T> Sinks.Many<T> onBackpressureBuffer();
/*     */     
/*     */     <T> Sinks.Many<T> onBackpressureBuffer(int param1Int);
/*     */     
/*     */     <T> Sinks.Many<T> onBackpressureBuffer(int param1Int, boolean param1Boolean);
/*     */     
/*     */     <T> Sinks.Many<T> directAllOrNothing();
/*     */     
/*     */     <T> Sinks.Many<T> directBestEffort();
/*     */   }
/*     */   
/*     */   public static interface MulticastReplaySpec {
/*     */     <T> Sinks.Many<T> all();
/*     */     
/*     */     <T> Sinks.Many<T> all(int param1Int);
/*     */     
/*     */     <T> Sinks.Many<T> latest();
/*     */     
/*     */     <T> Sinks.Many<T> latestOrDefault(T param1T);
/*     */     
/*     */     <T> Sinks.Many<T> limit(int param1Int);
/*     */     
/*     */     <T> Sinks.Many<T> limit(Duration param1Duration);
/*     */     
/*     */     <T> Sinks.Many<T> limit(Duration param1Duration, Scheduler param1Scheduler);
/*     */     
/*     */     <T> Sinks.Many<T> limit(int param1Int, Duration param1Duration);
/*     */     
/*     */     <T> Sinks.Many<T> limit(int param1Int, Duration param1Duration, Scheduler param1Scheduler);
/*     */   }
/*     */   
/*     */   public static interface Many<T> extends Scannable {
/*     */     Sinks.EmitResult tryEmitNext(T param1T);
/*     */     
/*     */     Sinks.EmitResult tryEmitComplete();
/*     */     
/*     */     Sinks.EmitResult tryEmitError(Throwable param1Throwable);
/*     */     
/*     */     void emitNext(T param1T, Sinks.EmitFailureHandler param1EmitFailureHandler);
/*     */     
/*     */     void emitComplete(Sinks.EmitFailureHandler param1EmitFailureHandler);
/*     */     
/*     */     void emitError(Throwable param1Throwable, Sinks.EmitFailureHandler param1EmitFailureHandler);
/*     */     
/*     */     int currentSubscriberCount();
/*     */     
/*     */     Flux<T> asFlux();
/*     */   }
/*     */   
/*     */   public static interface ManyWithUpstream<T> extends Many<T> {
/*     */     Disposable subscribeTo(Publisher<? extends T> param1Publisher);
/*     */   }
/*     */   
/*     */   public static interface Empty<T> extends Scannable {
/*     */     Sinks.EmitResult tryEmitEmpty();
/*     */     
/*     */     Sinks.EmitResult tryEmitError(Throwable param1Throwable);
/*     */     
/*     */     void emitEmpty(Sinks.EmitFailureHandler param1EmitFailureHandler);
/*     */     
/*     */     void emitError(Throwable param1Throwable, Sinks.EmitFailureHandler param1EmitFailureHandler);
/*     */     
/*     */     int currentSubscriberCount();
/*     */     
/*     */     Mono<T> asMono();
/*     */   }
/*     */   
/*     */   public static interface One<T> extends Empty<T> {
/*     */     Sinks.EmitResult tryEmitValue(@Nullable T param1T);
/*     */     
/*     */     void emitValue(@Nullable T param1T, Sinks.EmitFailureHandler param1EmitFailureHandler);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\Sinks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */