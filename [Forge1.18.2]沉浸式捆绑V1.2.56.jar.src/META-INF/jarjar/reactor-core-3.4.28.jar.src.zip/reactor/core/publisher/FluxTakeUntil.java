/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxTakeUntil<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Predicate<? super T> predicate;
/*     */   
/*     */   FluxTakeUntil(Flux<? extends T> source, Predicate<? super T> predicate) {
/*  39 */     super(source);
/*  40 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  45 */     return new TakeUntilPredicateSubscriber<>(actual, this.predicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  50 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  51 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeUntilPredicateSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     TakeUntilPredicateSubscriber(CoreSubscriber<? super T> actual, Predicate<? super T> predicate) {
/*  65 */       this.actual = actual;
/*  66 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  71 */       if (Operators.validate(this.s, s)) {
/*  72 */         this.s = s;
/*  73 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       boolean b;
/*  79 */       if (this.done) {
/*  80 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*  84 */       this.actual.onNext(t);
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  89 */         b = this.predicate.test(t);
/*  90 */       } catch (Throwable e) {
/*  91 */         onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  96 */       if (b) {
/*  97 */         this.s.cancel();
/*     */         
/*  99 */         onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 105 */       if (this.done) {
/* 106 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 109 */       this.done = true;
/*     */       
/* 111 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 116 */       if (this.done) {
/*     */         return;
/*     */       }
/* 119 */       this.done = true;
/*     */       
/* 121 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 127 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 128 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 129 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 131 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 136 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 141 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 146 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxTakeUntil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */