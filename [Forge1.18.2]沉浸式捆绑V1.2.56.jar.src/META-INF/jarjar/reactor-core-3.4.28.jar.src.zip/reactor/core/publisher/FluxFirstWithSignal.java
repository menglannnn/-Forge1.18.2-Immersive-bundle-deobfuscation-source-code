/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxFirstWithSignal<T>
/*     */   extends Flux<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final Publisher<? extends T>[] array;
/*     */   final Iterable<? extends Publisher<? extends T>> iterable;
/*     */   
/*     */   @SafeVarargs
/*     */   FluxFirstWithSignal(Publisher<? extends T>... array) {
/*  46 */     this.array = Objects.<Publisher<? extends T>[]>requireNonNull(array, "array");
/*  47 */     this.iterable = null;
/*     */   }
/*     */   
/*     */   FluxFirstWithSignal(Iterable<? extends Publisher<? extends T>> iterable) {
/*  51 */     this.array = null;
/*  52 */     this.iterable = Objects.<Iterable<? extends Publisher<? extends T>>>requireNonNull(iterable);
/*     */   }
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     Publisher[] arrayOfPublisher;
/*     */     int n;
/*  58 */     Publisher<? extends T>[] a = this.array;
/*     */     
/*  60 */     if (a == null) {
/*  61 */       Iterator<? extends Publisher<? extends T>> it; n = 0;
/*  62 */       arrayOfPublisher = new Publisher[8];
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  67 */         it = Objects.<Iterator<? extends Publisher<? extends T>>>requireNonNull(this.iterable.iterator(), "The iterator returned is null");
/*     */       
/*     */       }
/*  70 */       catch (Throwable e) {
/*  71 */         Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/*  72 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       while (true) {
/*     */         boolean b;
/*     */         Publisher<? extends T> p;
/*     */         try {
/*  81 */           b = it.hasNext();
/*     */         }
/*  83 */         catch (Throwable e) {
/*  84 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/*  85 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/*  89 */         if (!b) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/*  96 */           p = Objects.<Publisher<? extends T>>requireNonNull(it.next(), "The Publisher returned by the iterator is null");
/*     */         
/*     */         }
/*  99 */         catch (Throwable e) {
/* 100 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 101 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 105 */         if (n == arrayOfPublisher.length) {
/* 106 */           Publisher[] arrayOfPublisher1 = new Publisher[n + (n >> 2)];
/* 107 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/* 108 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/* 110 */         arrayOfPublisher[n++] = p;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 115 */       n = arrayOfPublisher.length;
/*     */     } 
/*     */     
/* 118 */     if (n == 0) {
/* 119 */       Operators.complete((Subscriber<?>)actual);
/*     */       return;
/*     */     } 
/* 122 */     if (n == 1) {
/* 123 */       Publisher<? extends T> p = arrayOfPublisher[0];
/*     */       
/* 125 */       if (p == null) {
/* 126 */         Operators.error((Subscriber<?>)actual, new NullPointerException("The single source Publisher is null"));
/*     */       }
/*     */       else {
/*     */         
/* 130 */         p.subscribe((Subscriber)actual);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 135 */     RaceCoordinator<T> coordinator = new RaceCoordinator<>(n);
/*     */     
/* 137 */     coordinator.subscribe((Publisher<? extends T>[])arrayOfPublisher, n, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   FluxFirstWithSignal<T> orAdditionalSource(Publisher<? extends T> source) {
/* 152 */     if (this.array != null) {
/* 153 */       int n = this.array.length;
/* 154 */       Publisher[] arrayOfPublisher = new Publisher[n + 1];
/*     */       
/* 156 */       System.arraycopy(this.array, 0, arrayOfPublisher, 0, n);
/* 157 */       arrayOfPublisher[n] = source;
/*     */       
/* 159 */       return new FluxFirstWithSignal((Publisher<? extends T>[])arrayOfPublisher);
/*     */     } 
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 166 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RaceCoordinator<T>
/*     */     implements Subscription, Scannable
/*     */   {
/*     */     final FluxFirstWithSignal.FirstEmittingSubscriber<T>[] subscribers;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile int winner;
/*     */     
/* 180 */     static final AtomicIntegerFieldUpdater<RaceCoordinator> WINNER = AtomicIntegerFieldUpdater.newUpdater(RaceCoordinator.class, "winner");
/*     */ 
/*     */     
/*     */     RaceCoordinator(int n) {
/* 184 */       this.subscribers = (FluxFirstWithSignal.FirstEmittingSubscriber<T>[])new FluxFirstWithSignal.FirstEmittingSubscriber[n];
/* 185 */       this.winner = Integer.MIN_VALUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 190 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 196 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled);
/*     */       
/* 198 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void subscribe(Publisher<? extends T>[] sources, int n, CoreSubscriber<? super T> actual) {
/* 204 */       FluxFirstWithSignal.FirstEmittingSubscriber<T>[] a = this.subscribers;
/*     */       int i;
/* 206 */       for (i = 0; i < n; i++) {
/* 207 */         a[i] = new FluxFirstWithSignal.FirstEmittingSubscriber<>(actual, this, i);
/*     */       }
/*     */       
/* 210 */       actual.onSubscribe(this);
/*     */       
/* 212 */       for (i = 0; i < n; i++) {
/* 213 */         if (this.cancelled || this.winner != Integer.MIN_VALUE) {
/*     */           return;
/*     */         }
/*     */         
/* 217 */         Publisher<? extends T> p = sources[i];
/*     */         
/* 219 */         if (p == null) {
/* 220 */           if (WINNER.compareAndSet(this, -2147483648, -1)) {
/* 221 */             actual.onError(new NullPointerException("The " + i + " th Publisher source is null"));
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/* 226 */         p.subscribe((Subscriber)a[i]);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 233 */       if (Operators.validate(n)) {
/* 234 */         int w = this.winner;
/* 235 */         if (w >= 0) {
/* 236 */           this.subscribers[w].request(n);
/*     */         } else {
/*     */           
/* 239 */           for (FluxFirstWithSignal.FirstEmittingSubscriber<T> s : this.subscribers) {
/* 240 */             s.request(n);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 248 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 251 */       this.cancelled = true;
/*     */       
/* 253 */       int w = this.winner;
/* 254 */       if (w >= 0) {
/* 255 */         this.subscribers[w].cancel();
/*     */       } else {
/*     */         
/* 258 */         for (FluxFirstWithSignal.FirstEmittingSubscriber<T> s : this.subscribers) {
/* 259 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean tryWin(int index) {
/* 265 */       if (this.winner == Integer.MIN_VALUE && 
/* 266 */         WINNER.compareAndSet(this, -2147483648, index)) {
/*     */         
/* 268 */         FluxFirstWithSignal.FirstEmittingSubscriber<T>[] a = this.subscribers;
/* 269 */         int n = a.length;
/*     */         
/* 271 */         for (int i = 0; i < n; i++) {
/* 272 */           if (i != index) {
/* 273 */             a[i].cancel();
/*     */           }
/*     */         } 
/*     */         
/* 277 */         return true;
/*     */       } 
/*     */       
/* 280 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FirstEmittingSubscriber<T>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final FluxFirstWithSignal.RaceCoordinator<T> parent;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final int index;
/*     */     
/*     */     boolean won;
/*     */     
/*     */     FirstEmittingSubscriber(CoreSubscriber<? super T> actual, FluxFirstWithSignal.RaceCoordinator<T> parent, int index) {
/* 298 */       this.actual = actual;
/* 299 */       this.parent = parent;
/* 300 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 306 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 307 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.parent.cancelled); 
/* 308 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 310 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 315 */       set(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 320 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 325 */       if (this.won) {
/* 326 */         this.actual.onNext(t);
/*     */       }
/* 328 */       else if (this.parent.tryWin(this.index)) {
/* 329 */         this.won = true;
/* 330 */         this.actual.onNext(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 336 */       if (this.won) {
/* 337 */         this.actual.onError(t);
/*     */       }
/* 339 */       else if (this.parent.tryWin(this.index)) {
/* 340 */         this.won = true;
/* 341 */         this.actual.onError(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 347 */       if (this.won) {
/* 348 */         this.actual.onComplete();
/*     */       }
/* 350 */       else if (this.parent.tryWin(this.index)) {
/* 351 */         this.won = true;
/* 352 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxFirstWithSignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */