/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxCancelOn<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Scheduler scheduler;
/*     */   
/*     */   public FluxCancelOn(Flux<T> source, Scheduler scheduler) {
/*  33 */     super(source);
/*  34 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler, "scheduler");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  39 */     return new CancelSubscriber<>(actual, this.scheduler);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  44 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  45 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  47 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CancelSubscriber<T>
/*     */     implements InnerOperator<T, T>, Runnable
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Scheduler scheduler;
/*     */     Subscription s;
/*  58 */     volatile int cancelled = 0;
/*     */     
/*  60 */     static final AtomicIntegerFieldUpdater<CancelSubscriber> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(CancelSubscriber.class, "cancelled");
/*     */     
/*     */     CancelSubscriber(CoreSubscriber<? super T> actual, Scheduler scheduler) {
/*  63 */       this.actual = actual;
/*  64 */       this.scheduler = scheduler;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  69 */       if (Operators.validate(this.s, s)) {
/*  70 */         this.s = s;
/*  71 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  78 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  79 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled == 1)); 
/*  80 */       if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  81 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/*  83 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/*  88 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*  93 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  98 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 103 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 108 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 113 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 118 */       if (CANCELLED.compareAndSet(this, 0, 1))
/*     */         try {
/* 120 */           this.scheduler.schedule(this);
/*     */         }
/* 122 */         catch (RejectedExecutionException ree) {
/* 123 */           throw Operators.onRejectedExecution(ree, this.actual.currentContext());
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxCancelOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */