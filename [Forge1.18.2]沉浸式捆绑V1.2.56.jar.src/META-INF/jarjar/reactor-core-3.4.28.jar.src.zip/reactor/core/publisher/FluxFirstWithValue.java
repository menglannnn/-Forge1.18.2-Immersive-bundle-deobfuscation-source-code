/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxFirstWithValue<T>
/*     */   extends Flux<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final Publisher<? extends T>[] array;
/*     */   final Iterable<? extends Publisher<? extends T>> iterable;
/*     */   
/*     */   private FluxFirstWithValue(Publisher<? extends T>[] array) {
/*  46 */     this.array = Objects.<Publisher<? extends T>[]>requireNonNull(array, "array");
/*  47 */     this.iterable = null;
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   FluxFirstWithValue(Publisher<? extends T> first, Publisher<? extends T>... others) {
/*  52 */     Objects.requireNonNull(first, "first");
/*  53 */     Objects.requireNonNull(others, "others");
/*     */     
/*  55 */     Publisher[] arrayOfPublisher = new Publisher[others.length + 1];
/*  56 */     arrayOfPublisher[0] = first;
/*  57 */     System.arraycopy(others, 0, arrayOfPublisher, 1, others.length);
/*  58 */     this.array = (Publisher<? extends T>[])arrayOfPublisher;
/*  59 */     this.iterable = null;
/*     */   }
/*     */   
/*     */   FluxFirstWithValue(Iterable<? extends Publisher<? extends T>> iterable) {
/*  63 */     this.array = null;
/*  64 */     this.iterable = Objects.<Iterable<? extends Publisher<? extends T>>>requireNonNull(iterable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   @Nullable
/*     */   final FluxFirstWithValue<T> firstValuedAdditionalSources(Publisher<? extends T>... others) {
/*  80 */     Objects.requireNonNull(others, "others");
/*  81 */     if (others.length == 0) {
/*  82 */       return this;
/*     */     }
/*  84 */     if (this.array == null)
/*     */     {
/*  86 */       return null;
/*     */     }
/*  88 */     int currentSize = this.array.length;
/*  89 */     int otherSize = others.length;
/*     */     
/*  91 */     Publisher[] arrayOfPublisher = new Publisher[currentSize + otherSize];
/*  92 */     System.arraycopy(this.array, 0, arrayOfPublisher, 0, currentSize);
/*  93 */     System.arraycopy(others, 0, arrayOfPublisher, currentSize, otherSize);
/*     */     
/*  95 */     return new FluxFirstWithValue((Publisher<? extends T>[])arrayOfPublisher);
/*     */   }
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     Publisher[] arrayOfPublisher;
/*     */     int n;
/* 101 */     Publisher<? extends T>[] a = this.array;
/*     */     
/* 103 */     if (a == null) {
/* 104 */       Iterator<? extends Publisher<? extends T>> it; n = 0;
/* 105 */       arrayOfPublisher = new Publisher[8];
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 110 */         it = Objects.<Iterator<? extends Publisher<? extends T>>>requireNonNull(this.iterable.iterator(), "The iterator returned is null");
/*     */       }
/* 112 */       catch (Throwable e) {
/* 113 */         Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 114 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       while (true) {
/*     */         boolean b;
/*     */         Publisher<? extends T> p;
/*     */         try {
/* 123 */           b = it.hasNext();
/* 124 */         } catch (Throwable e) {
/* 125 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 126 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 130 */         if (!b) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 137 */           p = Objects.<Publisher<? extends T>>requireNonNull(it.next(), "The Publisher returned by the iterator is null");
/*     */         }
/* 139 */         catch (Throwable e) {
/* 140 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 141 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 145 */         if (n == arrayOfPublisher.length) {
/* 146 */           Publisher[] arrayOfPublisher1 = new Publisher[n + (n >> 2)];
/* 147 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/* 148 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/* 150 */         arrayOfPublisher[n++] = p;
/*     */       } 
/*     */     } else {
/*     */       
/* 154 */       n = arrayOfPublisher.length;
/*     */     } 
/*     */     
/* 157 */     if (n == 0) {
/* 158 */       Operators.complete((Subscriber<?>)actual);
/*     */       return;
/*     */     } 
/* 161 */     if (n == 1) {
/* 162 */       Publisher<? extends T> p = arrayOfPublisher[0];
/*     */       
/* 164 */       if (p == null) {
/* 165 */         Operators.error((Subscriber<?>)actual, new NullPointerException("The single source Publisher is null"));
/*     */       } else {
/*     */         
/* 168 */         p.subscribe((Subscriber)actual);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 173 */     RaceValuesCoordinator<T> coordinator = new RaceValuesCoordinator<>(n);
/*     */     
/* 175 */     coordinator.subscribe((Publisher<? extends T>[])arrayOfPublisher, n, actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 180 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RaceValuesCoordinator<T>
/*     */     implements Subscription, Scannable
/*     */   {
/*     */     final FluxFirstWithValue.FirstValuesEmittingSubscriber<T>[] subscribers;
/*     */     
/*     */     final Throwable[] errorsOrCompleteEmpty;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile int winner;
/* 195 */     static final AtomicIntegerFieldUpdater<RaceValuesCoordinator> WINNER = AtomicIntegerFieldUpdater.newUpdater(RaceValuesCoordinator.class, "winner");
/*     */ 
/*     */     
/*     */     volatile int nbErrorsOrCompletedEmpty;
/*     */     
/* 200 */     static final AtomicIntegerFieldUpdater<RaceValuesCoordinator> ERRORS_OR_COMPLETED_EMPTY = AtomicIntegerFieldUpdater.newUpdater(RaceValuesCoordinator.class, "nbErrorsOrCompletedEmpty");
/*     */ 
/*     */     
/*     */     public RaceValuesCoordinator(int n) {
/* 204 */       this.subscribers = (FluxFirstWithValue.FirstValuesEmittingSubscriber<T>[])new FluxFirstWithValue.FirstValuesEmittingSubscriber[n];
/* 205 */       this.errorsOrCompleteEmpty = new Throwable[n];
/* 206 */       this.winner = Integer.MIN_VALUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 211 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 216 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled);
/*     */       
/* 218 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     void subscribe(Publisher<? extends T>[] sources, int n, CoreSubscriber<? super T> actual) {
/*     */       int i;
/* 224 */       for (i = 0; i < n; i++) {
/* 225 */         this.subscribers[i] = new FluxFirstWithValue.FirstValuesEmittingSubscriber<>(actual, this, i);
/*     */       }
/*     */       
/* 228 */       actual.onSubscribe(this);
/*     */       
/* 230 */       for (i = 0; i < n; i++) {
/* 231 */         if (this.cancelled || this.winner != Integer.MIN_VALUE) {
/*     */           return;
/*     */         }
/*     */         
/* 235 */         if (sources[i] == null) {
/* 236 */           actual.onError(new NullPointerException("The " + i + " th Publisher source is null"));
/*     */           
/*     */           return;
/*     */         } 
/* 240 */         sources[i].subscribe((Subscriber)this.subscribers[i]);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 247 */       if (Operators.validate(n)) {
/* 248 */         int w = this.winner;
/* 249 */         if (w >= 0) {
/* 250 */           this.subscribers[w].request(n);
/*     */         } else {
/* 252 */           for (FluxFirstWithValue.FirstValuesEmittingSubscriber<T> s : this.subscribers) {
/* 253 */             s.request(n);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 261 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 264 */       this.cancelled = true;
/*     */       
/* 266 */       int w = this.winner;
/* 267 */       if (w >= 0) {
/* 268 */         this.subscribers[w].cancel();
/*     */       } else {
/* 270 */         for (FluxFirstWithValue.FirstValuesEmittingSubscriber<T> s : this.subscribers) {
/* 271 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean tryWin(int index) {
/* 277 */       if (this.winner == Integer.MIN_VALUE && 
/* 278 */         WINNER.compareAndSet(this, -2147483648, index)) {
/* 279 */         for (int i = 0; i < this.subscribers.length; i++) {
/* 280 */           if (i != index) {
/* 281 */             this.subscribers[i].cancel();
/* 282 */             this.errorsOrCompleteEmpty[i] = null;
/*     */           } 
/*     */         } 
/* 285 */         return true;
/*     */       } 
/*     */       
/* 288 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FirstValuesEmittingSubscriber<T>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final FluxFirstWithValue.RaceValuesCoordinator<T> parent;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final int index;
/*     */     boolean won;
/*     */     
/*     */     FirstValuesEmittingSubscriber(CoreSubscriber<? super T> actual, FluxFirstWithValue.RaceValuesCoordinator<T> parent, int index) {
/* 305 */       this.actual = actual;
/* 306 */       this.parent = parent;
/* 307 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 313 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 314 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.parent.cancelled); 
/* 315 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 317 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 322 */       set(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 327 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 332 */       if (this.won) {
/* 333 */         this.actual.onNext(t);
/* 334 */       } else if (this.parent.tryWin(this.index)) {
/* 335 */         this.won = true;
/* 336 */         this.actual.onNext(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 342 */       if (this.won) {
/* 343 */         this.actual.onError(t);
/*     */       } else {
/* 345 */         recordTerminalSignals(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 351 */       if (this.won) {
/* 352 */         this.actual.onComplete();
/*     */       } else {
/* 354 */         recordTerminalSignals(new NoSuchElementException("source at index " + this.index + " completed empty"));
/*     */       } 
/*     */     }
/*     */     
/*     */     void recordTerminalSignals(Throwable t) {
/* 359 */       this.parent.errorsOrCompleteEmpty[this.index] = t;
/* 360 */       int nb = FluxFirstWithValue.RaceValuesCoordinator.ERRORS_OR_COMPLETED_EMPTY.incrementAndGet(this.parent);
/*     */       
/* 362 */       if (nb == this.parent.subscribers.length) {
/* 363 */         NoSuchElementException e = new NoSuchElementException("All sources completed with error or without values");
/* 364 */         e.initCause(Exceptions.multiple(this.parent.errorsOrCompleteEmpty));
/* 365 */         this.actual.onError(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxFirstWithValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */