/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SerializedSubscriber<T>
/*     */   implements InnerOperator<T, T>
/*     */ {
/*     */   final CoreSubscriber<? super T> actual;
/*     */   boolean drainLoopInProgress;
/*     */   boolean concurrentlyAddedContent;
/*     */   volatile boolean done;
/*     */   volatile boolean cancelled;
/*     */   LinkedArrayNode<T> head;
/*     */   LinkedArrayNode<T> tail;
/*     */   Throwable error;
/*     */   Subscription s;
/*     */   
/*     */   SerializedSubscriber(CoreSubscriber<? super T> actual) {
/*  57 */     this.actual = actual;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription s) {
/*  62 */     if (Operators.validate(this.s, s)) {
/*  63 */       this.s = s;
/*     */       
/*  65 */       this.actual.onSubscribe(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNext(T t) {
/*  71 */     if (this.cancelled) {
/*  72 */       Operators.onDiscard(t, this.actual.currentContext());
/*     */       return;
/*     */     } 
/*  75 */     if (this.done) {
/*  76 */       Operators.onNextDropped(t, this.actual.currentContext());
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     synchronized (this) {
/*  81 */       if (this.cancelled) {
/*  82 */         Operators.onDiscard(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/*  85 */       if (this.done) {
/*  86 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*  90 */       if (this.drainLoopInProgress) {
/*  91 */         serAdd(t);
/*  92 */         this.concurrentlyAddedContent = true;
/*     */         
/*     */         return;
/*     */       } 
/*  96 */       this.drainLoopInProgress = true;
/*     */     } 
/*     */     
/*  99 */     this.actual.onNext(t);
/*     */     
/* 101 */     serDrainLoop(this.actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable t) {
/* 106 */     if (this.cancelled || this.done) {
/*     */       return;
/*     */     }
/*     */     
/* 110 */     synchronized (this) {
/* 111 */       if (this.cancelled || this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 115 */       this.done = true;
/* 116 */       this.error = t;
/*     */       
/* 118 */       if (this.drainLoopInProgress) {
/* 119 */         this.concurrentlyAddedContent = true;
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 124 */     this.actual.onError(t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 129 */     if (this.cancelled || this.done) {
/*     */       return;
/*     */     }
/*     */     
/* 133 */     synchronized (this) {
/* 134 */       if (this.cancelled || this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 138 */       this.done = true;
/*     */       
/* 140 */       if (this.drainLoopInProgress) {
/* 141 */         this.concurrentlyAddedContent = true;
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 146 */     this.actual.onComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   public void request(long n) {
/* 151 */     this.s.request(n);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 156 */     this.cancelled = true;
/* 157 */     this.s.cancel();
/*     */   }
/*     */   
/*     */   void serAdd(T value) {
/* 161 */     if (this.cancelled) {
/* 162 */       Operators.onDiscard(value, this.actual.currentContext());
/*     */       
/*     */       return;
/*     */     } 
/* 166 */     LinkedArrayNode<T> t = this.tail;
/*     */     
/* 168 */     if (t == null) {
/* 169 */       t = new LinkedArrayNode<>(value);
/*     */       
/* 171 */       this.head = t;
/* 172 */       this.tail = t;
/*     */     
/*     */     }
/* 175 */     else if (t.count == 16) {
/* 176 */       LinkedArrayNode<T> n = new LinkedArrayNode<>(value);
/*     */       
/* 178 */       t.next = n;
/* 179 */       this.tail = n;
/*     */     } else {
/*     */       
/* 182 */       t.array[t.count++] = value;
/*     */     } 
/*     */     
/* 185 */     if (this.cancelled)
/*     */     {
/*     */ 
/*     */       
/* 189 */       Operators.onDiscard(value, this.actual.currentContext()); } 
/*     */   }
/*     */   void serDrainLoop(CoreSubscriber<? super T> actual) {
/*     */     while (true) {
/*     */       boolean d;
/*     */       Throwable e;
/*     */       LinkedArrayNode<T> n;
/* 196 */       if (this.cancelled) {
/* 197 */         synchronized (this) {
/* 198 */           discardMultiple(this.head);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 207 */       synchronized (this) {
/* 208 */         if (this.cancelled) {
/* 209 */           discardMultiple(this.head);
/*     */           
/*     */           return;
/*     */         } 
/* 213 */         if (!this.concurrentlyAddedContent) {
/* 214 */           this.drainLoopInProgress = false;
/*     */           
/*     */           return;
/*     */         } 
/* 218 */         this.concurrentlyAddedContent = false;
/*     */         
/* 220 */         d = this.done;
/* 221 */         e = this.error;
/* 222 */         n = this.head;
/*     */         
/* 224 */         this.head = null;
/* 225 */         this.tail = null;
/*     */       } 
/*     */       
/* 228 */       while (n != null) {
/*     */         
/* 230 */         T[] arr = n.array;
/* 231 */         int c = n.count;
/*     */         
/* 233 */         for (int i = 0; i < c; i++) {
/*     */           
/* 235 */           if (this.cancelled) {
/* 236 */             synchronized (this) {
/* 237 */               discardMultiple(n);
/*     */             } 
/*     */             
/*     */             return;
/*     */           } 
/* 242 */           actual.onNext(arr[i]);
/*     */         } 
/*     */         
/* 245 */         n = n.next;
/*     */       } 
/*     */       
/* 248 */       if (this.cancelled) {
/* 249 */         synchronized (this) {
/* 250 */           discardMultiple(this.head);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 255 */       if (e != null) {
/* 256 */         actual.onError(e);
/*     */         return;
/*     */       } 
/* 259 */       if (d) {
/* 260 */         actual.onComplete();
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void discardMultiple(LinkedArrayNode<T> head) {
/* 267 */     LinkedArrayNode<T> originalHead = head;
/* 268 */     LinkedArrayNode<T> h = head;
/* 269 */     while (h != null) {
/*     */       
/* 271 */       for (int i = 0; i < h.count; i++) {
/* 272 */         Operators.onDiscard(h.array[i], this.actual.currentContext());
/*     */       }
/* 274 */       h = h.next;
/*     */       
/* 276 */       if (h == null && this.head != originalHead) {
/* 277 */         originalHead = this.head;
/* 278 */         h = originalHead;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> actual() {
/* 285 */     return this.actual;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 291 */     if (key == Scannable.Attr.PARENT) return this.s; 
/* 292 */     if (key == Scannable.Attr.ERROR) return this.error; 
/* 293 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(producerCapacity()); 
/* 294 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(16); 
/* 295 */     if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 296 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done);
/*     */     
/* 298 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   int producerCapacity() {
/* 302 */     LinkedArrayNode<T> node = this.tail;
/* 303 */     if (node != null) {
/* 304 */       return node.count;
/*     */     }
/* 306 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class LinkedArrayNode<T>
/*     */   {
/*     */     static final int DEFAULT_CAPACITY = 16;
/*     */ 
/*     */     
/*     */     final T[] array;
/*     */ 
/*     */     
/*     */     int count;
/*     */     
/*     */     LinkedArrayNode<T> next;
/*     */ 
/*     */     
/*     */     LinkedArrayNode(T value) {
/* 325 */       this.array = (T[])new Object[16];
/* 326 */       this.array[0] = value;
/* 327 */       this.count = 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\SerializedSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */