/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelFluxName<T>
/*     */   extends ParallelFlux<T>
/*     */   implements Scannable
/*     */ {
/*     */   final ParallelFlux<T> source;
/*     */   final String name;
/*     */   final Set<Tuple2<String, String>> tags;
/*     */   
/*     */   static <T> ParallelFlux<T> createOrAppend(ParallelFlux<T> source, String name) {
/*  49 */     Objects.requireNonNull(name, "name");
/*     */     
/*  51 */     if (source instanceof ParallelFluxName) {
/*  52 */       ParallelFluxName<T> s = (ParallelFluxName<T>)source;
/*  53 */       return new ParallelFluxName<>(s.source, name, s.tags);
/*     */     } 
/*  55 */     return new ParallelFluxName<>(source, name, null);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> ParallelFlux<T> createOrAppend(ParallelFlux<T> source, String tagName, String tagValue) {
/*  60 */     Objects.requireNonNull(tagName, "tagName");
/*  61 */     Objects.requireNonNull(tagValue, "tagValue");
/*     */     
/*  63 */     Set<Tuple2<String, String>> tags = Collections.singleton(Tuples.of(tagName, tagValue));
/*     */     
/*  65 */     if (source instanceof ParallelFluxName) {
/*  66 */       ParallelFluxName<T> s = (ParallelFluxName<T>)source;
/*  67 */       if (s.tags != null) {
/*  68 */         tags = new HashSet<>(tags);
/*  69 */         tags.addAll(s.tags);
/*     */       } 
/*  71 */       return new ParallelFluxName<>(s.source, s.name, tags);
/*     */     } 
/*  73 */     return new ParallelFluxName<>(source, null, tags);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ParallelFluxName(ParallelFlux<T> source, @Nullable String name, @Nullable Set<Tuple2<String, String>> tags) {
/*  79 */     this.source = source;
/*  80 */     this.name = name;
/*  81 */     this.tags = tags;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  86 */     return this.source.getPrefetch();
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/*  91 */     return this.source.parallelism();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  97 */     if (key == Scannable.Attr.NAME) {
/*  98 */       return this.name;
/*     */     }
/*     */     
/* 101 */     if (key == Scannable.Attr.TAGS && this.tags != null) {
/* 102 */       return this.tags.stream();
/*     */     }
/*     */     
/* 105 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 106 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch());
/*     */     
/* 108 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 109 */       return Scannable.Attr.RunStyle.SYNC;
/*     */     }
/*     */     
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/* 117 */     this.source.subscribe(subscribers);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelFluxName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */