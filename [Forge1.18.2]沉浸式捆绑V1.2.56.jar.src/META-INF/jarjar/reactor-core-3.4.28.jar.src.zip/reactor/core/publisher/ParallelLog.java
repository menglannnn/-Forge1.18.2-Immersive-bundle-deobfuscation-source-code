/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParallelLog<T>
/*    */   extends ParallelFlux<T>
/*    */   implements Scannable
/*    */ {
/*    */   final ParallelFlux<T> source;
/*    */   final SignalPeek<T> log;
/*    */   
/*    */   ParallelLog(ParallelFlux<T> source, SignalPeek<T> log) {
/* 39 */     this.source = source;
/* 40 */     this.log = log;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/* 46 */     if (!validate((Subscriber<?>[])subscribers)) {
/*    */       return;
/*    */     }
/*    */     
/* 50 */     int n = subscribers.length;
/* 51 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*    */     
/* 53 */     boolean conditional = subscribers[0] instanceof Fuseable.ConditionalSubscriber;
/*    */     
/* 55 */     for (int i = 0; i < n; i++) {
/* 56 */       if (conditional) {
/* 57 */         arrayOfCoreSubscriber[i] = new FluxPeekFuseable.PeekConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)subscribers[i], this.log);
/*    */       }
/*    */       else {
/*    */         
/* 61 */         arrayOfCoreSubscriber[i] = new FluxPeek.PeekSubscriber<>(subscribers[i], this.log);
/*    */       } 
/*    */     } 
/*    */     
/* 65 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*    */   }
/*    */ 
/*    */   
/*    */   public int parallelism() {
/* 70 */     return this.source.parallelism();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 75 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 81 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 82 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 83 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 85 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */