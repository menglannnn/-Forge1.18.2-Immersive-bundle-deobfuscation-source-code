/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import reactor.util.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StateLogger
/*     */ {
/*     */   final Logger logger;
/*     */   
/*     */   StateLogger(Logger logger) {
/*  29 */     this.logger = logger;
/*     */   }
/*     */   
/*     */   void log(String instance, String action, long initialState, long committedState) {
/*  33 */     log(instance, action, initialState, committedState, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void log(String instance, String action, long initialState, long committedState, boolean logStackTrace) {
/*  41 */     if (logStackTrace) {
/*  42 */       this.logger.trace(String.format("[%s][%s][%s][%s-%s]", new Object[] { instance, action, action, 
/*     */ 
/*     */ 
/*     */               
/*  46 */               Long.valueOf(Thread.currentThread()
/*  47 */                 .getId()), 
/*  48 */               formatState(initialState, 64), 
/*  49 */               formatState(committedState, 64) }), new RuntimeException());
/*     */     } else {
/*     */       
/*  52 */       this.logger.trace(String.format("[%s][%s][%s][%s-%s]", new Object[] { instance, action, 
/*     */ 
/*     */               
/*  55 */               Long.valueOf(Thread.currentThread()
/*  56 */                 .getId()), 
/*  57 */               formatState(initialState, 64), 
/*  58 */               formatState(committedState, 64) }));
/*     */     } 
/*     */   }
/*     */   
/*     */   void log(String instance, String action, int initialState, int committedState) {
/*  63 */     log(instance, action, initialState, committedState, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void log(String instance, String action, int initialState, int committedState, boolean logStackTrace) {
/*  71 */     if (logStackTrace) {
/*  72 */       this.logger.trace(String.format("[%s][%s][%s][%s-%s]", new Object[] { instance, action, action, 
/*     */ 
/*     */ 
/*     */               
/*  76 */               Long.valueOf(Thread.currentThread()
/*  77 */                 .getId()), 
/*  78 */               formatState(initialState, 32), 
/*  79 */               formatState(committedState, 32) }), new RuntimeException());
/*     */     } else {
/*     */       
/*  82 */       this.logger.trace(String.format("[%s][%s][%s][%s-%s]", new Object[] { instance, action, 
/*     */ 
/*     */               
/*  85 */               Long.valueOf(Thread.currentThread()
/*  86 */                 .getId()), 
/*  87 */               formatState(initialState, 32), 
/*  88 */               formatState(committedState, 32) }));
/*     */     } 
/*     */   }
/*     */   
/*     */   static String formatState(long state, int size) {
/*  93 */     String defaultFormat = Long.toBinaryString(state);
/*  94 */     StringBuilder formatted = new StringBuilder();
/*  95 */     int toPrepend = size - defaultFormat.length();
/*  96 */     for (int i = 0; i < size; i++) {
/*  97 */       if (i != 0 && i % 4 == 0) {
/*  98 */         formatted.append("_");
/*     */       }
/* 100 */       if (i < toPrepend) {
/* 101 */         formatted.append("0");
/*     */       } else {
/*     */         
/* 104 */         formatted.append(defaultFormat.charAt(i - toPrepend));
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     formatted.insert(0, "0b");
/* 109 */     return formatted.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\StateLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */