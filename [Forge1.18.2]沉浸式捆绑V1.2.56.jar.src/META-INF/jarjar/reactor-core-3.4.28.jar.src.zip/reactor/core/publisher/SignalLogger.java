/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.LongConsumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.logging.Level;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SignalLogger<IN>
/*     */   implements SignalPeek<IN>
/*     */ {
/*     */   static final int CONTEXT_PARENT = 256;
/*     */   static final int SUBSCRIBE = 128;
/*     */   static final int ON_SUBSCRIBE = 64;
/*     */   static final int ON_NEXT = 32;
/*     */   static final int ON_ERROR = 16;
/*     */   static final int ON_COMPLETE = 8;
/*     */   static final int REQUEST = 4;
/*     */   static final int CANCEL = 2;
/*     */   static final int AFTER_TERMINATE = 1;
/*     */   static final int ALL = 510;
/*  56 */   static final AtomicLong IDS = new AtomicLong(1L);
/*     */   
/*     */   final CorePublisher<IN> source;
/*     */   
/*     */   final Logger log;
/*     */   
/*     */   final boolean fuseable;
/*     */   
/*     */   final int options;
/*     */   
/*     */   final Level level;
/*     */   
/*     */   final String operatorLine;
/*     */   
/*     */   final long id;
/*     */   static final String LOG_TEMPLATE = "{}({})";
/*     */   static final String LOG_TEMPLATE_FUSEABLE = "| {}({})";
/*     */   
/*     */   SignalLogger(CorePublisher<IN> source, @Nullable String category, Level level, boolean correlateStack, SignalType... options) {
/*  75 */     this(source, category, level, correlateStack, Loggers::getLogger, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SignalLogger(CorePublisher<IN> source, @Nullable String category, Level level, boolean correlateStack, Function<String, Logger> loggerSupplier, @Nullable SignalType... options) {
/*  85 */     this.source = Objects.<CorePublisher<IN>>requireNonNull(source, "source");
/*  86 */     this.id = IDS.getAndIncrement();
/*  87 */     this.fuseable = source instanceof reactor.core.Fuseable;
/*     */     
/*  89 */     if (correlateStack) {
/*  90 */       this.operatorLine = Traces.extractOperatorAssemblyInformation(((Supplier<String>)Traces.callSiteSupplierFactory.get()).get());
/*     */     } else {
/*     */       
/*  93 */       this.operatorLine = null;
/*     */     } 
/*     */ 
/*     */     
/*  97 */     boolean generated = (category == null || category.isEmpty() || category.endsWith("."));
/*     */     
/*  99 */     category = (generated && category == null) ? "reactor." : category;
/* 100 */     if (generated) {
/* 101 */       if (source instanceof Mono) {
/*     */ 
/*     */         
/* 104 */         category = category + "Mono." + source.getClass().getSimpleName().replace("Mono", "");
/*     */       }
/* 106 */       else if (source instanceof ParallelFlux) {
/*     */ 
/*     */         
/* 109 */         category = category + "Parallel." + source.getClass().getSimpleName().replace("Parallel", "");
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 114 */         category = category + "Flux." + source.getClass().getSimpleName().replace("Flux", "");
/*     */       } 
/* 116 */       category = category + "." + this.id;
/*     */     } 
/*     */     
/* 119 */     this.log = loggerSupplier.apply(category);
/*     */     
/* 121 */     this.level = level;
/* 122 */     if (options == null || options.length == 0) {
/* 123 */       this.options = 510;
/*     */     } else {
/*     */       
/* 126 */       int opts = 0;
/* 127 */       for (SignalType option : options) {
/* 128 */         if (option == SignalType.CANCEL) {
/* 129 */           opts |= 0x2;
/*     */         }
/* 131 */         else if (option == SignalType.CURRENT_CONTEXT) {
/* 132 */           opts |= 0x100;
/*     */         }
/* 134 */         else if (option == SignalType.ON_SUBSCRIBE) {
/* 135 */           opts |= 0x40;
/*     */         }
/* 137 */         else if (option == SignalType.REQUEST) {
/* 138 */           opts |= 0x4;
/*     */         }
/* 140 */         else if (option == SignalType.ON_NEXT) {
/* 141 */           opts |= 0x20;
/*     */         }
/* 143 */         else if (option == SignalType.ON_ERROR) {
/* 144 */           opts |= 0x10;
/*     */         }
/* 146 */         else if (option == SignalType.ON_COMPLETE) {
/* 147 */           opts |= 0x8;
/*     */         }
/* 149 */         else if (option == SignalType.SUBSCRIBE) {
/* 150 */           opts |= 0x80;
/*     */         }
/* 152 */         else if (option == SignalType.AFTER_TERMINATE) {
/* 153 */           opts |= 0x1;
/*     */         } 
/*     */       } 
/* 156 */       this.options = opts;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 163 */     if (key == Scannable.Attr.PARENT) return this.source;
/*     */     
/* 165 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void log(SignalType signalType, Object signalValue) {
/* 175 */     String line = this.fuseable ? "| {}({})" : "{}({})";
/* 176 */     if (this.operatorLine != null) {
/* 177 */       line = line + " " + this.operatorLine;
/*     */     }
/* 179 */     if (this.level == Level.FINEST) {
/* 180 */       this.log.trace(line, new Object[] { signalType, signalValue });
/*     */     }
/* 182 */     else if (this.level == Level.FINE) {
/* 183 */       this.log.debug(line, new Object[] { signalType, signalValue });
/*     */     }
/* 185 */     else if (this.level == Level.INFO) {
/* 186 */       this.log.info(line, new Object[] { signalType, signalValue });
/*     */     }
/* 188 */     else if (this.level == Level.WARNING) {
/* 189 */       this.log.warn(line, new Object[] { signalType, signalValue });
/*     */     }
/* 191 */     else if (this.level == Level.SEVERE) {
/* 192 */       this.log.error(line, new Object[] { signalType, signalValue });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void safeLog(SignalType signalType, Object signalValue) {
/* 204 */     if (signalValue instanceof reactor.core.Fuseable.QueueSubscription) {
/* 205 */       signalValue = String.valueOf(signalValue);
/* 206 */       if (this.log.isDebugEnabled()) {
/* 207 */         this.log.debug("A Fuseable Subscription has been passed to the logging framework, this is generally a sign of a misplaced log(), eg. 'window(2).log()' instead of 'window(2).flatMap(w -> w.log())'");
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 212 */       log(signalType, signalValue);
/*     */     }
/* 214 */     catch (UnsupportedOperationException uoe) {
/* 215 */       log(signalType, String.valueOf(signalValue));
/* 216 */       if (this.log.isDebugEnabled()) {
/* 217 */         this.log.debug("UnsupportedOperationException has been raised by the logging framework, does your log() placement make sense? eg. 'window(2).log()' instead of 'window(2).flatMap(w -> w.log())'", uoe);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String subscriptionAsString(@Nullable Subscription s) {
/* 225 */     if (s == null) {
/* 226 */       return "null subscription";
/*     */     }
/* 228 */     StringBuilder asString = new StringBuilder();
/* 229 */     if (s instanceof reactor.core.Fuseable.SynchronousSubscription) {
/* 230 */       asString.append("[Synchronous Fuseable] ");
/*     */     }
/* 232 */     else if (s instanceof reactor.core.Fuseable.QueueSubscription) {
/* 233 */       asString.append("[Fuseable] ");
/*     */     } 
/*     */     
/* 236 */     Class<? extends Subscription> clazz = (Class)s.getClass();
/* 237 */     String name = clazz.getCanonicalName();
/* 238 */     if (name == null) {
/* 239 */       name = clazz.getName();
/*     */     }
/* 241 */     name = name.replaceFirst(clazz.getPackage()
/* 242 */         .getName() + ".", "");
/* 243 */     asString.append(name);
/*     */     
/* 245 */     return asString.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Subscription> onSubscribeCall() {
/* 251 */     if ((this.options & 0x40) == 64 && (this.level != Level.INFO || this.log.isInfoEnabled())) {
/* 252 */       return s -> log(SignalType.ON_SUBSCRIBE, subscriptionAsString(s));
/*     */     }
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Context> onCurrentContextCall() {
/* 260 */     if ((this.options & 0x100) == 256 && ((this.level == Level.FINE && this.log
/* 261 */       .isDebugEnabled()) || (this.level == Level.FINEST && this.log
/* 262 */       .isTraceEnabled()))) {
/* 263 */       return c -> log(SignalType.CURRENT_CONTEXT, c);
/*     */     }
/* 265 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super IN> onNextCall() {
/* 271 */     if ((this.options & 0x20) == 32 && (this.level != Level.INFO || this.log.isInfoEnabled())) {
/* 272 */       return d -> safeLog(SignalType.ON_NEXT, d);
/*     */     }
/* 274 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Throwable> onErrorCall() {
/* 280 */     boolean shouldLogAsDebug = (this.level == Level.FINE && this.log.isDebugEnabled());
/* 281 */     boolean shouldLogAsTrace = (this.level == Level.FINEST && this.log.isTraceEnabled());
/* 282 */     boolean shouldLogAsError = (this.level != Level.FINE && this.level != Level.FINEST && this.log.isErrorEnabled());
/* 283 */     if ((this.options & 0x10) == 16 && (shouldLogAsError || shouldLogAsDebug || shouldLogAsTrace)) {
/*     */       
/* 285 */       String line = this.fuseable ? "| {}({})" : "{}({})";
/* 286 */       if (this.operatorLine != null) {
/* 287 */         line = line + " " + this.operatorLine;
/*     */       }
/* 289 */       String s = line;
/* 290 */       if (shouldLogAsTrace) {
/* 291 */         return e -> {
/*     */             this.log.trace(s, new Object[] { SignalType.ON_ERROR, e, this.source });
/*     */             this.log.trace("", e);
/*     */           };
/*     */       }
/* 296 */       if (shouldLogAsDebug) {
/* 297 */         return e -> {
/*     */             this.log.debug(s, new Object[] { SignalType.ON_ERROR, e, this.source });
/*     */             
/*     */             this.log.debug("", e);
/*     */           };
/*     */       }
/* 303 */       return e -> {
/*     */           this.log.error(s, new Object[] { SignalType.ON_ERROR, e, this.source });
/*     */           
/*     */           this.log.error("", e);
/*     */         };
/*     */     } 
/* 309 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCompleteCall() {
/* 315 */     if ((this.options & 0x8) == 8 && (this.level != Level.INFO || this.log.isInfoEnabled())) {
/* 316 */       return () -> log(SignalType.ON_COMPLETE, "");
/*     */     }
/* 318 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onAfterTerminateCall() {
/* 324 */     if ((this.options & 0x1) == 1 && (this.level != Level.INFO || this.log.isInfoEnabled())) {
/* 325 */       return () -> log(SignalType.AFTER_TERMINATE, "");
/*     */     }
/* 327 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LongConsumer onRequestCall() {
/* 333 */     if ((this.options & 0x4) == 4 && (this.level != Level.INFO || this.log.isInfoEnabled())) {
/* 334 */       return n -> log(SignalType.REQUEST, (Long.MAX_VALUE == n) ? "unbounded" : Long.valueOf(n));
/*     */     }
/*     */     
/* 337 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCancelCall() {
/* 343 */     if ((this.options & 0x2) == 2 && (this.level != Level.INFO || this.log.isInfoEnabled())) {
/* 344 */       return () -> log(SignalType.CANCEL, "");
/*     */     }
/* 346 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 351 */     return "/loggers/" + this.log.getName() + "/" + this.id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\SignalLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */