/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Queue;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class QueueDrainSubscriber<T, U, V>
/*     */   extends QueueDrainSubscriberPad4
/*     */   implements InnerOperator<T, V>
/*     */ {
/*     */   final CoreSubscriber<? super V> actual;
/*     */   final Queue<U> queue;
/*     */   volatile boolean cancelled;
/*     */   volatile boolean done;
/*     */   Throwable error;
/*     */   
/*     */   QueueDrainSubscriber(CoreSubscriber<? super V> actual, Queue<U> queue) {
/*  52 */     this.actual = actual;
/*  53 */     this.queue = queue;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super V> actual() {
/*  58 */     return this.actual;
/*     */   }
/*     */   
/*     */   public final boolean cancelled() {
/*  62 */     return this.cancelled;
/*     */   }
/*     */   
/*     */   public final boolean done() {
/*  66 */     return this.done;
/*     */   }
/*     */   
/*     */   public final boolean enter() {
/*  70 */     return (this.wip.getAndIncrement() == 0);
/*     */   }
/*     */   
/*     */   public final boolean fastEnter() {
/*  74 */     return (this.wip.get() == 0 && this.wip.compareAndSet(0, 1));
/*     */   }
/*     */   
/*     */   protected final void fastPathEmitMax(U value, boolean delayError, Disposable dispose) {
/*  78 */     CoreSubscriber<? super V> coreSubscriber = this.actual;
/*  79 */     Queue<U> q = this.queue;
/*     */     
/*  81 */     if (this.wip.get() == 0 && this.wip.compareAndSet(0, 1)) {
/*  82 */       long r = this.requested;
/*  83 */       if (r != 0L) {
/*  84 */         if (accept((Subscriber<? super V>)coreSubscriber, value) && 
/*  85 */           r != Long.MAX_VALUE) {
/*  86 */           produced(1L);
/*     */         }
/*     */         
/*  89 */         if (leave(-1) == 0) {
/*     */           return;
/*     */         }
/*     */       } else {
/*  93 */         dispose.dispose();
/*  94 */         coreSubscriber.onError(Exceptions.failWithOverflow("Could not emit buffer due to lack of requests"));
/*     */         return;
/*     */       } 
/*     */     } else {
/*  98 */       q.offer(value);
/*  99 */       if (!enter()) {
/*     */         return;
/*     */       }
/*     */     } 
/* 103 */     drainMaxLoop(q, (Subscriber<? super V>)coreSubscriber, delayError, dispose, this);
/*     */   }
/*     */   
/*     */   protected final void fastPathOrderedEmitMax(U value, boolean delayError, Disposable dispose) {
/* 107 */     CoreSubscriber<? super V> coreSubscriber = this.actual;
/* 108 */     Queue<U> q = this.queue;
/*     */     
/* 110 */     if (this.wip.get() == 0 && this.wip.compareAndSet(0, 1)) {
/* 111 */       long r = this.requested;
/* 112 */       if (r != 0L) {
/* 113 */         if (q.isEmpty()) {
/* 114 */           if (accept((Subscriber<? super V>)coreSubscriber, value) && 
/* 115 */             r != Long.MAX_VALUE) {
/* 116 */             produced(1L);
/*     */           }
/*     */           
/* 119 */           if (leave(-1) == 0) {
/*     */             return;
/*     */           }
/*     */         } else {
/* 123 */           q.offer(value);
/*     */         } 
/*     */       } else {
/* 126 */         this.cancelled = true;
/* 127 */         dispose.dispose();
/* 128 */         coreSubscriber.onError(Exceptions.failWithOverflow("Could not emit buffer due to lack of requests"));
/*     */         return;
/*     */       } 
/*     */     } else {
/* 132 */       q.offer(value);
/* 133 */       if (!enter()) {
/*     */         return;
/*     */       }
/*     */     } 
/* 137 */     drainMaxLoop(q, (Subscriber<? super V>)coreSubscriber, delayError, dispose, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean accept(Subscriber<? super V> a, U v) {
/* 147 */     return false;
/*     */   }
/*     */   
/*     */   public final Throwable error() {
/* 151 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int leave(int m) {
/* 160 */     return this.wip.addAndGet(m);
/*     */   }
/*     */   
/*     */   public final long requested() {
/* 164 */     return this.requested;
/*     */   }
/*     */   
/*     */   public final long produced(long n) {
/* 168 */     return REQUESTED.addAndGet(this, -n);
/*     */   }
/*     */   
/*     */   public final void requested(long n) {
/* 172 */     if (Operators.validate(n)) {
/* 173 */       Operators.addCap(REQUESTED, this, n);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 180 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 181 */     if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 182 */     if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 183 */     if (key == Scannable.Attr.ERROR) return this.error;
/*     */     
/* 185 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <Q, S> void drainMaxLoop(Queue<Q> q, Subscriber<? super S> a, boolean delayError, Disposable dispose, QueueDrainSubscriber<?, Q, S> qd) {
/* 200 */     int missed = 1;
/*     */ 
/*     */     
/*     */     while (true) {
/* 204 */       boolean d = qd.done();
/*     */       
/* 206 */       Q v = q.poll();
/*     */       
/* 208 */       boolean empty = (v == null);
/*     */       
/* 210 */       if (checkTerminated(d, empty, a, delayError, q, qd)) {
/* 211 */         if (dispose != null) {
/* 212 */           dispose.dispose();
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 217 */       if (empty) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 238 */         missed = qd.leave(-missed);
/* 239 */         if (missed == 0)
/*     */           break;  continue;
/*     */       }  long r = qd.requested(); if (r != 0L) {
/*     */         if (qd.accept(a, v) && r != Long.MAX_VALUE)
/*     */           qd.produced(1L);  continue;
/*     */       }  q.clear(); if (dispose != null)
/*     */         dispose.dispose();  a.onError(Exceptions.failWithOverflow("Could not emit value due to lack of requests."));
/*     */       return;
/* 247 */     }  } static <Q, S> boolean checkTerminated(boolean d, boolean empty, Subscriber<?> s, boolean delayError, Queue<?> q, QueueDrainSubscriber<?, Q, S> qd) { if (qd.cancelled()) {
/* 248 */       q.clear();
/* 249 */       return true;
/*     */     } 
/*     */     
/* 252 */     if (d) {
/* 253 */       if (delayError) {
/* 254 */         if (empty) {
/* 255 */           Throwable err = qd.error();
/* 256 */           if (err != null) {
/* 257 */             s.onError(err);
/*     */           } else {
/* 259 */             s.onComplete();
/*     */           } 
/* 261 */           return true;
/*     */         } 
/*     */       } else {
/* 264 */         Throwable err = qd.error();
/* 265 */         if (err != null) {
/* 266 */           q.clear();
/* 267 */           s.onError(err);
/* 268 */           return true;
/*     */         } 
/* 270 */         if (empty) {
/* 271 */           s.onComplete();
/* 272 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 277 */     return false; }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\QueueDrainSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */