/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ImmutableSignal<T>
/*     */   implements Signal<T>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -2004454746525418508L;
/*     */   private final transient ContextView contextView;
/*     */   private final SignalType type;
/*     */   private final Throwable throwable;
/*     */   private final T value;
/*     */   private final transient Subscription subscription;
/*     */   
/*     */   ImmutableSignal(ContextView contextView, SignalType type, @Nullable T value, @Nullable Throwable e, @Nullable Subscription subscription) {
/*  51 */     this.contextView = contextView;
/*  52 */     this.value = value;
/*  53 */     this.subscription = subscription;
/*  54 */     this.throwable = e;
/*  55 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getThrowable() {
/*  61 */     return this.throwable;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Subscription getSubscription() {
/*  67 */     return this.subscription;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T get() {
/*  73 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignalType getType() {
/*  78 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public ContextView getContextView() {
/*  83 */     return this.contextView;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*  88 */     if (this == o) {
/*  89 */       return true;
/*     */     }
/*  91 */     if (o == null || !(o instanceof Signal)) {
/*  92 */       return false;
/*     */     }
/*     */     
/*  95 */     Signal<?> signal = (Signal)o;
/*     */     
/*  97 */     if (getType() != signal.getType()) {
/*  98 */       return false;
/*     */     }
/* 100 */     if (isOnComplete()) {
/* 101 */       return true;
/*     */     }
/* 103 */     if (isOnSubscribe()) {
/* 104 */       return Objects.equals(getSubscription(), signal.getSubscription());
/*     */     }
/* 106 */     if (isOnError()) {
/* 107 */       return Objects.equals(getThrowable(), signal.getThrowable());
/*     */     }
/* 109 */     if (isOnNext()) {
/* 110 */       return Objects.equals(get(), signal.get());
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 117 */     int result = getType().hashCode();
/* 118 */     if (isOnError()) {
/* 119 */       return 31 * result + ((getThrowable() != null) ? getThrowable().hashCode() : 0);
/*     */     }
/*     */     
/* 122 */     if (isOnNext())
/*     */     {
/* 124 */       return 31 * result + ((get() != null) ? get().hashCode() : 0);
/*     */     }
/* 126 */     if (isOnSubscribe()) {
/* 127 */       return 31 * result + ((getSubscription() != null) ? 
/* 128 */         getSubscription().hashCode() : 0);
/*     */     }
/* 130 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 135 */     switch (getType()) {
/*     */       case ON_SUBSCRIBE:
/* 137 */         return String.format("onSubscribe(%s)", new Object[] { getSubscription() });
/*     */       case ON_NEXT:
/* 139 */         return String.format("onNext(%s)", new Object[] { get() });
/*     */       case ON_ERROR:
/* 141 */         return String.format("onError(%s)", new Object[] { getThrowable() });
/*     */       case ON_COMPLETE:
/* 143 */         return "onComplete()";
/*     */     } 
/* 145 */     return String.format("Signal type=%s", new Object[] { getType() });
/*     */   }
/*     */ 
/*     */   
/* 149 */   private static final Signal<?> ON_COMPLETE = new ImmutableSignal(
/* 150 */       (ContextView)Context.empty(), SignalType.ON_COMPLETE, null, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <U> Signal<U> onComplete() {
/* 159 */     return (Signal)ON_COMPLETE;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ImmutableSignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */