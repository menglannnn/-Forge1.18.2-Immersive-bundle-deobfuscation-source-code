/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoLogFuseable<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   final SignalPeek<T> log;
/*    */   
/*    */   MonoLogFuseable(Mono<? extends T> source, SignalPeek<T> log) {
/* 41 */     super(source);
/* 42 */     this.log = log;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 48 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 49 */       return new FluxPeekFuseable.PeekFuseableConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this.log);
/*    */     }
/* 51 */     return new FluxPeekFuseable.PeekFuseableSubscriber<>(actual, this.log);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 56 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 57 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoLogFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */