/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LambdaSubscriber<T>
/*     */   implements InnerConsumer<T>, Disposable
/*     */ {
/*     */   final Consumer<? super T> consumer;
/*     */   final Consumer<? super Throwable> errorConsumer;
/*     */   final Runnable completeConsumer;
/*     */   final Consumer<? super Subscription> subscriptionConsumer;
/*     */   final Context initialContext;
/*     */   volatile Subscription subscription;
/*  46 */   static final AtomicReferenceFieldUpdater<LambdaSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(LambdaSubscriber.class, Subscription.class, "subscription");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LambdaSubscriber(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Consumer<? super Subscription> subscriptionConsumer, @Nullable Context initialContext) {
/*  71 */     this.consumer = consumer;
/*  72 */     this.errorConsumer = errorConsumer;
/*  73 */     this.completeConsumer = completeConsumer;
/*  74 */     this.subscriptionConsumer = subscriptionConsumer;
/*  75 */     this.initialContext = (initialContext == null) ? Context.empty() : initialContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LambdaSubscriber(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Consumer<? super Subscription> subscriptionConsumer) {
/*  96 */     this(consumer, errorConsumer, completeConsumer, subscriptionConsumer, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 101 */     return this.initialContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription s) {
/* 106 */     if (Operators.validate(this.subscription, s)) {
/* 107 */       this.subscription = s;
/* 108 */       if (this.subscriptionConsumer != null) {
/*     */         try {
/* 110 */           this.subscriptionConsumer.accept(s);
/*     */         }
/* 112 */         catch (Throwable t) {
/* 113 */           Exceptions.throwIfFatal(t);
/* 114 */           s.cancel();
/* 115 */           onError(t);
/*     */         } 
/*     */       } else {
/*     */         
/* 119 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 126 */     Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 127 */     if (s == Operators.cancelledSubscription()) {
/*     */       return;
/*     */     }
/* 130 */     if (this.completeConsumer != null) {
/*     */       try {
/* 132 */         this.completeConsumer.run();
/*     */       }
/* 134 */       catch (Throwable t) {
/* 135 */         Exceptions.throwIfFatal(t);
/* 136 */         onError(t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onError(Throwable t) {
/* 143 */     Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 144 */     if (s == Operators.cancelledSubscription()) {
/* 145 */       Operators.onErrorDropped(t, this.initialContext);
/*     */       return;
/*     */     } 
/* 148 */     if (this.errorConsumer != null) {
/* 149 */       this.errorConsumer.accept(t);
/*     */     } else {
/*     */       
/* 152 */       Operators.onErrorDropped(Exceptions.errorCallbackNotImplemented(t), this.initialContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onNext(T x) {
/*     */     try {
/* 159 */       if (this.consumer != null) {
/* 160 */         this.consumer.accept(x);
/*     */       }
/*     */     }
/* 163 */     catch (Throwable t) {
/* 164 */       Exceptions.throwIfFatal(t);
/* 165 */       this.subscription.cancel();
/* 166 */       onError(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 173 */     if (key == Scannable.Attr.PARENT) return this.subscription; 
/* 174 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 175 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 176 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 184 */     return (this.subscription == Operators.cancelledSubscription());
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 189 */     Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 190 */     if (s != null && s != Operators.cancelledSubscription())
/* 191 */       s.cancel(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\LambdaSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */