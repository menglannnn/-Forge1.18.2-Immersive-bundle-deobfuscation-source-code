/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoMap<T, R>
/*    */   extends InternalMonoOperator<T, R>
/*    */ {
/*    */   final Function<? super T, ? extends R> mapper;
/*    */   
/*    */   MonoMap(Mono<? extends T> source, Function<? super T, ? extends R> mapper) {
/* 44 */     super(source);
/* 45 */     this.mapper = Objects.<Function<? super T, ? extends R>>requireNonNull(mapper, "mapper");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/* 51 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 52 */       Fuseable.ConditionalSubscriber<? super R> cs = (Fuseable.ConditionalSubscriber<? super R>)actual;
/* 53 */       return new FluxMap.MapConditionalSubscriber<>(cs, this.mapper);
/*    */     } 
/* 55 */     return new FluxMap.MapSubscriber<>(actual, this.mapper);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 60 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 61 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */