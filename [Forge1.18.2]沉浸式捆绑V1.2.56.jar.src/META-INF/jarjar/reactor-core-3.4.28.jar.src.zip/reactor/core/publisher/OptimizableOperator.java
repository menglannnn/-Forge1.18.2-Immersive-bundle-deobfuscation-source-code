package reactor.core.publisher;

import reactor.core.CorePublisher;
import reactor.core.CoreSubscriber;
import reactor.util.annotation.Nullable;

interface OptimizableOperator<IN, OUT> extends CorePublisher<IN> {
  @Nullable
  CoreSubscriber<? super OUT> subscribeOrReturn(CoreSubscriber<? super IN> paramCoreSubscriber) throws Throwable;
  
  CorePublisher<? extends OUT> source();
  
  @Nullable
  OptimizableOperator<?, ? extends OUT> nextOptimizableSource();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\OptimizableOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */