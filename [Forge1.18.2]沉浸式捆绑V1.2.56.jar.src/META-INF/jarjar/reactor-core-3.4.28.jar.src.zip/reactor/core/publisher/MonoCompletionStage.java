/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CompletionStage;
/*     */ import java.util.concurrent.Future;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoCompletionStage<T>
/*     */   extends Mono<T>
/*     */   implements Fuseable, Scannable
/*     */ {
/*     */   final CompletionStage<? extends T> future;
/*     */   final boolean suppressCancellation;
/*     */   
/*     */   MonoCompletionStage(CompletionStage<? extends T> future, boolean suppressCancellation) {
/*  46 */     this.future = Objects.<CompletionStage<? extends T>>requireNonNull(future, "future");
/*  47 */     this.suppressCancellation = suppressCancellation;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  53 */     Operators.MonoSubscriber<T, T> sds = this.suppressCancellation ? new Operators.MonoSubscriber<>(actual) : new Operators.MonoSubscriber<T, T>(actual)
/*     */       {
/*     */         
/*     */         public void cancel()
/*     */         {
/*  58 */           super.cancel();
/*  59 */           if (MonoCompletionStage.this.future instanceof Future) {
/*  60 */             ((Future)MonoCompletionStage.this.future).cancel(true);
/*     */           }
/*     */         }
/*     */       };
/*     */     
/*  65 */     actual.onSubscribe(sds);
/*     */     
/*  67 */     if (sds.isCancelled()) {
/*     */       return;
/*     */     }
/*     */     
/*  71 */     this.future.handle((v, e) -> {
/*     */           if (sds.isCancelled()) {
/*     */             Context ctx = sds.currentContext();
/*     */ 
/*     */ 
/*     */             
/*     */             if (e == null || e instanceof java.util.concurrent.CancellationException) {
/*     */               Operators.onDiscard(v, ctx);
/*     */             } else {
/*     */               Operators.onErrorDropped(e, ctx);
/*     */ 
/*     */ 
/*     */               
/*     */               Operators.onDiscard(v, ctx);
/*     */             } 
/*     */ 
/*     */             
/*     */             return null;
/*     */           } 
/*     */ 
/*     */           
/*     */           try {
/*     */             if (e instanceof java.util.concurrent.CompletionException) {
/*     */               actual.onError(e.getCause());
/*     */             } else if (e != null) {
/*     */               actual.onError(e);
/*     */             } else if (v != null) {
/*     */               sds.complete(v);
/*     */             } else {
/*     */               actual.onComplete();
/*     */             } 
/* 102 */           } catch (Throwable e1) {
/*     */             Operators.onErrorDropped(e1, actual.currentContext());
/*     */             throw Exceptions.bubble(e1);
/*     */           } 
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 112 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC; 
/* 113 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoCompletionStage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */