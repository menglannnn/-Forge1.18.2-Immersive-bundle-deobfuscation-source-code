/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import io.micrometer.core.instrument.Clock;
/*     */ import io.micrometer.core.instrument.MeterRegistry;
/*     */ import io.micrometer.core.instrument.Tags;
/*     */ import io.micrometer.core.instrument.Timer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Metrics;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoMetricsFuseable<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */   implements Fuseable
/*     */ {
/*     */   final String name;
/*     */   final Tags tags;
/*     */   final MeterRegistry registryCandidate;
/*     */   
/*     */   MonoMetricsFuseable(Mono<? extends T> mono) {
/*  49 */     super(mono);
/*     */     
/*  51 */     this.name = FluxMetrics.resolveName((Publisher<?>)mono);
/*  52 */     this.tags = FluxMetrics.resolveTags((Publisher<?>)mono, FluxMetrics.DEFAULT_TAGS_MONO);
/*     */     
/*  54 */     this.registryCandidate = Metrics.MicrometerConfiguration.getRegistry();
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  59 */     return new MetricsFuseableSubscriber<>(actual, this.registryCandidate, Clock.SYSTEM, this.name, this.tags);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  65 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MetricsFuseableSubscriber<T>
/*     */     extends MonoMetrics.MetricsSubscriber<T>
/*     */     implements Fuseable, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     int mode;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MetricsFuseableSubscriber(CoreSubscriber<? super T> actual, MeterRegistry registry, Clock clock, String sequenceName, Tags sequenceTags) {
/*  88 */       super(actual, registry, clock, sequenceName, sequenceTags);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/*  93 */       if (this.qs != null) {
/*  94 */         this.qs.clear();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 100 */       if (this.mode == 2) {
/* 101 */         if (!this.done) {
/* 102 */           FluxMetrics.recordOnCompleteEmpty(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */         }
/* 104 */         this.actual.onComplete();
/*     */       } else {
/*     */         
/* 107 */         if (this.done) {
/*     */           return;
/*     */         }
/* 110 */         this.done = true;
/* 111 */         FluxMetrics.recordOnCompleteEmpty(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/* 112 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 118 */       if (this.mode == 2) {
/* 119 */         this.actual.onNext(null);
/*     */       } else {
/*     */         
/* 122 */         if (this.done) {
/* 123 */           FluxMetrics.recordMalformed(this.sequenceName, this.commonTags, this.registry);
/* 124 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           return;
/*     */         } 
/* 127 */         this.done = true;
/* 128 */         FluxMetrics.recordOnComplete(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */ 
/*     */ 
/*     */         
/* 132 */         this.actual.onNext(t);
/* 133 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 139 */       return (this.qs == null || this.qs.isEmpty());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 144 */       if (Operators.validate(this.s, s)) {
/* 145 */         FluxMetrics.recordOnSubscribe(this.sequenceName, this.commonTags, this.registry);
/* 146 */         this.subscribeToTerminateSample = Timer.start(this.clock);
/* 147 */         this.qs = Operators.as(s);
/* 148 */         this.s = s;
/* 149 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 157 */       if (this.qs == null) {
/* 158 */         return null;
/*     */       }
/*     */       try {
/* 161 */         T v = (T)this.qs.poll();
/* 162 */         if (!this.done) {
/* 163 */           if (v == null && this.mode == 1) {
/* 164 */             FluxMetrics.recordOnCompleteEmpty(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */           }
/* 166 */           else if (v != null) {
/* 167 */             FluxMetrics.recordOnComplete(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */           } 
/*     */         }
/* 170 */         this.done = true;
/* 171 */         return v;
/*     */       }
/* 173 */       catch (Throwable e) {
/* 174 */         FluxMetrics.recordOnError(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample, e);
/* 175 */         throw e;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int mode) {
/* 182 */       if (this.qs != null) {
/* 183 */         this.mode = this.qs.requestFusion(mode);
/* 184 */         return this.mode;
/*     */       } 
/* 186 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 191 */       return (this.qs == null) ? 0 : this.qs.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 196 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 197 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoMetricsFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */