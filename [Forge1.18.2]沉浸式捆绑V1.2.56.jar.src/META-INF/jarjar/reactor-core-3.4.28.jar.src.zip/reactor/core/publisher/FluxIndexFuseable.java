/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxIndexFuseable<T, I>
/*     */   extends InternalFluxOperator<T, I>
/*     */   implements Fuseable
/*     */ {
/*     */   private final BiFunction<? super Long, ? super T, ? extends I> indexMapper;
/*     */   
/*     */   FluxIndexFuseable(Flux<T> source, BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/*  45 */     super(source);
/*  46 */     this.indexMapper = FluxIndex.NullSafeIndexMapper.create(Objects.<BiFunction<? super Long, ? super T, ? extends I>>requireNonNull(indexMapper, "indexMapper must be non null"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super I> actual) {
/*  52 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  53 */       Fuseable.ConditionalSubscriber<? super I> cs = (Fuseable.ConditionalSubscriber<? super I>)actual;
/*     */       
/*  55 */       return new IndexFuseableConditionalSubscriber<>(cs, this.indexMapper);
/*     */     } 
/*     */     
/*  58 */     return new IndexFuseableSubscriber<>(actual, this.indexMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  65 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class IndexFuseableSubscriber<I, T>
/*     */     implements InnerOperator<T, I>, Fuseable.QueueSubscription<I>
/*     */   {
/*     */     final CoreSubscriber<? super I> actual;
/*     */     
/*     */     final BiFunction<? super Long, ? super T, ? extends I> indexMapper;
/*     */     boolean done;
/*     */     long index;
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     int sourceMode;
/*     */     
/*     */     IndexFuseableSubscriber(CoreSubscriber<? super I> actual, BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/*  81 */       this.actual = actual;
/*  82 */       this.indexMapper = indexMapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  87 */       if (Operators.validate((Subscription)this.s, s)) {
/*     */         
/*  89 */         Fuseable.QueueSubscription<T> qs = (Fuseable.QueueSubscription<T>)s;
/*  90 */         this.s = qs;
/*     */         
/*  92 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public I poll() {
/*  99 */       T v = (T)this.s.poll();
/* 100 */       if (v != null) {
/* 101 */         long i = this.index;
/* 102 */         I indexed = this.indexMapper.apply(Long.valueOf(i), v);
/* 103 */         this.index = i + 1L;
/* 104 */         return indexed;
/*     */       } 
/* 106 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 111 */       if (this.sourceMode == 2) {
/* 112 */         this.actual.onNext(null);
/*     */       } else {
/*     */         
/* 115 */         if (this.done) {
/* 116 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/* 120 */         long i = this.index;
/*     */         try {
/* 122 */           I indexed = this.indexMapper.apply(Long.valueOf(i), t);
/* 123 */           this.index = i + 1L;
/* 124 */           this.actual.onNext(indexed);
/*     */         }
/* 126 */         catch (Throwable e) {
/* 127 */           onError(Operators.onOperatorError((Subscription)this.s, e, t, this.actual.currentContext()));
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 134 */       if (this.done) {
/* 135 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 139 */       this.done = true;
/*     */       
/* 141 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 146 */       if (this.done) {
/*     */         return;
/*     */       }
/* 149 */       this.done = true;
/*     */       
/* 151 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super I> actual() {
/* 156 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 161 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 166 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 171 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 176 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 182 */       if (this.indexMapper != Flux.TUPLE2_BIFUNCTION && (requestedMode & 0x4) != 0) {
/* 183 */         return 0;
/*     */       }
/*     */       
/* 186 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 188 */       this.sourceMode = m;
/* 189 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 194 */       return this.s.size();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 200 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 201 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 202 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 204 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class IndexFuseableConditionalSubscriber<I, T>
/*     */     implements InnerOperator<T, I>, Fuseable.ConditionalSubscriber<T>, Fuseable.QueueSubscription<I>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super I> actual;
/*     */     
/*     */     final BiFunction<? super Long, ? super T, ? extends I> indexMapper;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     long index;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     int sourceMode;
/*     */     
/*     */     IndexFuseableConditionalSubscriber(Fuseable.ConditionalSubscriber<? super I> cs, BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/* 224 */       this.actual = cs;
/* 225 */       this.indexMapper = indexMapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 230 */       if (Operators.validate((Subscription)this.s, s)) {
/*     */         
/* 232 */         Fuseable.QueueSubscription<T> qs = (Fuseable.QueueSubscription<T>)s;
/* 233 */         this.s = qs;
/* 234 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public I poll() {
/* 241 */       T v = (T)this.s.poll();
/* 242 */       if (v != null) {
/* 243 */         long i = this.index;
/* 244 */         I indexed = this.indexMapper.apply(Long.valueOf(i), v);
/* 245 */         this.index = i + 1L;
/* 246 */         return indexed;
/*     */       } 
/* 248 */       return null;
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       I indexed;
/* 253 */       if (this.done) {
/* 254 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 255 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 259 */       long i = this.index;
/*     */       try {
/* 261 */         indexed = this.indexMapper.apply(Long.valueOf(i), t);
/* 262 */         this.index = i + 1L;
/*     */       }
/* 264 */       catch (Throwable e) {
/* 265 */         onError(Operators.onOperatorError((Subscription)this.s, e, t, this.actual.currentContext()));
/* 266 */         return true;
/*     */       } 
/*     */       
/* 269 */       return this.actual.tryOnNext(indexed);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 274 */       if (this.sourceMode == 2) {
/* 275 */         this.actual.onNext(null);
/*     */       } else {
/*     */         
/* 278 */         if (this.done) {
/* 279 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/* 283 */         long i = this.index;
/*     */         try {
/* 285 */           I indexed = this.indexMapper.apply(Long.valueOf(i), t);
/* 286 */           this.index = i + 1L;
/* 287 */           this.actual.onNext(indexed);
/*     */         }
/* 289 */         catch (Throwable e) {
/* 290 */           onError(Operators.onOperatorError((Subscription)this.s, e, t, this.actual.currentContext()));
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 297 */       if (this.done) {
/* 298 */         Operators.onErrorDropped(throwable, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 302 */       this.done = true;
/*     */       
/* 304 */       this.actual.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 309 */       if (this.done) {
/*     */         return;
/*     */       }
/* 312 */       this.done = true;
/*     */       
/* 314 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super I> actual() {
/* 319 */       return (CoreSubscriber<? super I>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 324 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 329 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 334 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 339 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 345 */       if (this.indexMapper != Flux.TUPLE2_BIFUNCTION && (requestedMode & 0x4) != 0) {
/* 346 */         return 0;
/*     */       }
/*     */       
/* 349 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 351 */       this.sourceMode = m;
/* 352 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 357 */       return this.s.size();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 363 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 364 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 365 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 367 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxIndexFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */