/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoCount<T>
/*    */   extends MonoFromFluxOperator<T, Long>
/*    */   implements Fuseable
/*    */ {
/*    */   MonoCount(Flux<? extends T> source) {
/* 35 */     super(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Long> actual) {
/* 40 */     return new CountSubscriber<>(actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 45 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 46 */     return super.scanUnsafe(key);
/*    */   }
/*    */   
/*    */   static final class CountSubscriber<T>
/*    */     extends Operators.MonoSubscriber<T, Long>
/*    */   {
/*    */     long counter;
/*    */     Subscription s;
/*    */     
/*    */     CountSubscriber(CoreSubscriber<? super Long> actual) {
/* 56 */       super(actual);
/*    */     }
/*    */ 
/*    */     
/*    */     @Nullable
/*    */     public Object scanUnsafe(Scannable.Attr key) {
/* 62 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 63 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */       
/* 65 */       return super.scanUnsafe(key);
/*    */     }
/*    */ 
/*    */     
/*    */     public void cancel() {
/* 70 */       super.cancel();
/* 71 */       this.s.cancel();
/*    */     }
/*    */ 
/*    */     
/*    */     public void onSubscribe(Subscription s) {
/* 76 */       if (Operators.validate(this.s, s)) {
/* 77 */         this.s = s;
/*    */         
/* 79 */         this.actual.onSubscribe(this);
/*    */         
/* 81 */         s.request(Long.MAX_VALUE);
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     public void onNext(T t) {
/* 87 */       this.counter++;
/*    */     }
/*    */ 
/*    */     
/*    */     public void onComplete() {
/* 92 */       complete(Long.valueOf(this.counter));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoCount.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */