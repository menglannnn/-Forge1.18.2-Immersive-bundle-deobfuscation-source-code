/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSkipUntilOther<T, U>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Publisher<U> other;
/*     */   
/*     */   FluxSkipUntilOther(Flux<? extends T> source, Publisher<U> other) {
/*  44 */     super(source);
/*  45 */     this.other = Objects.<Publisher<U>>requireNonNull(other, "other");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  50 */     SkipUntilMainSubscriber<T> mainSubscriber = new SkipUntilMainSubscriber<>(actual);
/*     */     
/*  52 */     SkipUntilOtherSubscriber<U> otherSubscriber = new SkipUntilOtherSubscriber<>(mainSubscriber);
/*     */     
/*  54 */     this.other.subscribe((Subscriber)otherSubscriber);
/*     */     
/*  56 */     return mainSubscriber;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  61 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  62 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class SkipUntilOtherSubscriber<U>
/*     */     implements InnerConsumer<U> {
/*     */     final FluxSkipUntilOther.SkipUntilMainSubscriber<?> main;
/*     */     
/*     */     SkipUntilOtherSubscriber(FluxSkipUntilOther.SkipUntilMainSubscriber<?> main) {
/*  70 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/*  75 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  81 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main.other == Operators.cancelledSubscription())); 
/*  82 */       if (key == Scannable.Attr.PARENT) return this.main.other; 
/*  83 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/*  84 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  86 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  91 */       this.main.setOther(s);
/*     */       
/*  93 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/*  98 */       if (this.main.gate) {
/*     */         return;
/*     */       }
/* 101 */       FluxSkipUntilOther.SkipUntilMainSubscriber<?> m = this.main;
/* 102 */       m.other.cancel();
/* 103 */       m.gate = true;
/* 104 */       m.other = Operators.cancelledSubscription();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 109 */       FluxSkipUntilOther.SkipUntilMainSubscriber<?> m = this.main;
/* 110 */       if (m.gate) {
/* 111 */         Operators.onErrorDropped(t, this.main.currentContext());
/*     */         return;
/*     */       } 
/* 114 */       m.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 119 */       FluxSkipUntilOther.SkipUntilMainSubscriber<?> m = this.main;
/* 120 */       if (m.gate) {
/*     */         return;
/*     */       }
/* 123 */       m.gate = true;
/* 124 */       m.other = Operators.cancelledSubscription();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class SkipUntilMainSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */ 
/*     */     
/*     */     final Context ctx;
/*     */ 
/*     */     
/*     */     volatile Subscription main;
/*     */     
/* 141 */     static final AtomicReferenceFieldUpdater<SkipUntilMainSubscriber, Subscription> MAIN = AtomicReferenceFieldUpdater.newUpdater(SkipUntilMainSubscriber.class, Subscription.class, "main");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Subscription other;
/*     */ 
/*     */ 
/*     */     
/* 149 */     static final AtomicReferenceFieldUpdater<SkipUntilMainSubscriber, Subscription> OTHER = AtomicReferenceFieldUpdater.newUpdater(SkipUntilMainSubscriber.class, Subscription.class, "other");
/*     */ 
/*     */     
/*     */     volatile boolean gate;
/*     */ 
/*     */     
/*     */     SkipUntilMainSubscriber(CoreSubscriber<? super T> actual) {
/* 156 */       this.actual = Operators.serialize(actual);
/* 157 */       this.ctx = actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 162 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 168 */       if (key == Scannable.Attr.PARENT) return this.main; 
/* 169 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main == Operators.cancelledSubscription())); 
/* 170 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 172 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 177 */       return Stream.of(Scannable.from(this.other));
/*     */     }
/*     */     
/*     */     void setOther(Subscription s) {
/* 181 */       if (!OTHER.compareAndSet(this, null, s)) {
/* 182 */         s.cancel();
/* 183 */         if (this.other != Operators.cancelledSubscription()) {
/* 184 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 191 */       this.main.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 196 */       Operators.terminate(MAIN, this);
/* 197 */       Operators.terminate(OTHER, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 202 */       if (!MAIN.compareAndSet(this, null, s)) {
/* 203 */         s.cancel();
/* 204 */         if (this.main != Operators.cancelledSubscription()) {
/* 205 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } else {
/*     */         
/* 209 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 215 */       if (this.gate) {
/* 216 */         this.actual.onNext(t);
/*     */       } else {
/*     */         
/* 219 */         Operators.onDiscard(t, this.ctx);
/* 220 */         this.main.request(1L);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 226 */       if (MAIN.compareAndSet(this, null, Operators.cancelledSubscription())) {
/* 227 */         Operators.error((Subscriber<?>)this.actual, t);
/*     */         return;
/*     */       } 
/* 230 */       if (this.main == Operators.cancelledSubscription()) {
/* 231 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 234 */       cancel();
/*     */       
/* 236 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 241 */       Operators.terminate(OTHER, this);
/*     */       
/* 243 */       this.actual.onComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxSkipUntilOther.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */