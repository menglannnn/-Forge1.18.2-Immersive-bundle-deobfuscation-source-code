/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxOnErrorReturn<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   @Nullable
/*     */   final Predicate<? super Throwable> resumableErrorPredicate;
/*     */   @Nullable
/*     */   final T fallbackValue;
/*     */   
/*     */   FluxOnErrorReturn(Flux<? extends T> source, @Nullable Predicate<? super Throwable> predicate, @Nullable T value) {
/*  44 */     super(source);
/*  45 */     this.resumableErrorPredicate = predicate;
/*  46 */     this.fallbackValue = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  51 */     return new ReturnSubscriber<>(actual, this.resumableErrorPredicate, this.fallbackValue, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  56 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  57 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ReturnSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     private static final byte STATE_CANCELLED = -3;
/*     */     
/*     */     private static final byte STATE_TERMINATED = -2;
/*     */     
/*     */     private static final byte STATE_PENDING_FALLBACK = -1;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final boolean trackRequestWhenFallbackDeferred;
/*     */     
/*     */     Subscription s;
/*     */     @Nullable
/*     */     final Predicate<? super Throwable> resumableErrorPredicate;
/*     */     @Nullable
/*     */     final T fallbackValue;
/*     */     volatile long requested;
/*  80 */     static final AtomicLongFieldUpdater<ReturnSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(ReturnSubscriber.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     ReturnSubscriber(CoreSubscriber<? super T> actual, @Nullable Predicate<? super Throwable> predicate, @Nullable T value, boolean trackRequestWhenFallbackDeferred) {
/*  85 */       this.actual = actual;
/*  86 */       this.resumableErrorPredicate = predicate;
/*  87 */       this.fallbackValue = value;
/*  88 */       this.trackRequestWhenFallbackDeferred = trackRequestWhenFallbackDeferred;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  93 */       if (Operators.validate(this.s, s)) {
/*  94 */         this.s = s;
/*  95 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 101 */       return this.actual;
/*     */     }
/*     */     
/*     */     void producedOne() {
/*     */       long r;
/*     */       do {
/* 107 */         r = REQUESTED.get(this);
/* 108 */         if (r == Long.MAX_VALUE || r <= 0L) {
/*     */           return;
/*     */         }
/*     */       }
/* 112 */       while (!REQUESTED.compareAndSet(this, r, r - 1L));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 120 */       if (REQUESTED.getAndSet(this, -3L) != -3L) {
/* 121 */         this.s.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/*     */       while (true) {
/* 129 */         long r = REQUESTED.get(this);
/* 130 */         if (r == Long.MAX_VALUE || r < -1L) {
/*     */           return;
/*     */         }
/*     */         
/* 134 */         if (r == -1L) {
/*     */           
/* 136 */           if (REQUESTED.compareAndSet(this, r, -2L)) {
/* 137 */             if (this.fallbackValue != null) {
/* 138 */               this.actual.onNext(this.fallbackValue);
/*     */             }
/* 140 */             this.actual.onComplete();
/*     */ 
/*     */             
/* 143 */             if (this.trackRequestWhenFallbackDeferred) {
/* 144 */               this.s.request(n);
/* 145 */               this.s.cancel();
/*     */             } 
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 151 */         long u = Operators.addCap(r, n);
/* 152 */         if (REQUESTED.compareAndSet(this, r, u)) {
/* 153 */           this.s.request(n);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 161 */       producedOne();
/* 162 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 167 */       if (this.requested != -3L) {
/* 168 */         REQUESTED.set(this, -2L);
/* 169 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 175 */       boolean shouldResume = (this.resumableErrorPredicate == null || this.resumableErrorPredicate.test(t));
/* 176 */       if (!shouldResume) {
/*     */         
/* 178 */         if (this.requested != -3L) {
/* 179 */           REQUESTED.set(this, -2L);
/* 180 */           this.actual.onError(t);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 185 */       if (this.fallbackValue == null) {
/*     */         
/* 187 */         if (this.requested != -3L) {
/* 188 */           REQUESTED.set(this, -2L);
/* 189 */           this.actual.onComplete();
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 195 */       long r = this.requested;
/* 196 */       if (r > 0L) {
/*     */         
/* 198 */         REQUESTED.set(this, -2L);
/* 199 */         this.actual.onNext(this.fallbackValue);
/* 200 */         this.actual.onComplete();
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 207 */       if (!REQUESTED.compareAndSet(this, 0L, -1L)) {
/*     */         
/* 209 */         r = this.requested;
/* 210 */         if (r > 0L) {
/* 211 */           REQUESTED.set(this, -2L);
/* 212 */           this.actual.onNext(this.fallbackValue);
/* 213 */           this.actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 221 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 222 */       if (key == Scannable.Attr.PARENT) return this.s;
/*     */       
/* 224 */       long r = this.requested;
/* 225 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((r == -3L)); 
/* 226 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((r == -2L)); 
/* 227 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf((r > 0L) ? r : 0L);
/*     */       
/* 229 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxOnErrorReturn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */