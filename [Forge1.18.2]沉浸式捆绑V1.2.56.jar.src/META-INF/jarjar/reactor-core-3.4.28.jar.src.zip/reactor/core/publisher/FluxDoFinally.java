/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDoFinally<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Consumer<SignalType> onFinally;
/*     */   
/*     */   static <T> CoreSubscriber<T> createSubscriber(CoreSubscriber<? super T> s, Consumer<SignalType> onFinally) {
/*  50 */     if (s instanceof Fuseable.ConditionalSubscriber) {
/*  51 */       return new DoFinallyConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)s, onFinally);
/*     */     }
/*  53 */     return new DoFinallySubscriber<>(s, onFinally);
/*     */   }
/*     */   
/*     */   FluxDoFinally(Flux<? extends T> source, Consumer<SignalType> onFinally) {
/*  57 */     super(source);
/*  58 */     this.onFinally = onFinally;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  63 */     return createSubscriber(actual, this.onFinally);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  68 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  69 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static class DoFinallySubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Consumer<SignalType> onFinally;
/*     */     
/*     */     volatile int once;
/*     */     
/*  82 */     static final AtomicIntegerFieldUpdater<DoFinallySubscriber> ONCE = AtomicIntegerFieldUpdater.newUpdater(DoFinallySubscriber.class, "once");
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     DoFinallySubscriber(CoreSubscriber<? super T> actual, Consumer<SignalType> onFinally) {
/*  87 */       this.actual = actual;
/*  88 */       this.onFinally = onFinally;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  94 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  95 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED)
/*  96 */         return Boolean.valueOf((this.once == 1)); 
/*  97 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  99 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 104 */       if (Operators.validate(this.s, s)) {
/* 105 */         this.s = s;
/*     */         
/* 107 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 113 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*     */       try {
/* 119 */         this.actual.onError(t);
/*     */       } finally {
/*     */         
/* 122 */         runFinally(SignalType.ON_ERROR);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 128 */       this.actual.onComplete();
/* 129 */       runFinally(SignalType.ON_COMPLETE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 134 */       this.s.cancel();
/* 135 */       runFinally(SignalType.CANCEL);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 140 */       this.s.request(n);
/*     */     }
/*     */     
/*     */     void runFinally(SignalType signalType) {
/* 144 */       if (ONCE.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 146 */           this.onFinally.accept(signalType);
/* 147 */         } catch (Throwable ex) {
/* 148 */           Exceptions.throwIfFatal(ex);
/* 149 */           Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 156 */       return this.actual;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DoFinallyConditionalSubscriber<T>
/*     */     extends DoFinallySubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     DoFinallyConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, Consumer<SignalType> onFinally) {
/* 166 */       super((CoreSubscriber<? super T>)actual, onFinally);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 172 */       return ((Fuseable.ConditionalSubscriber)this.actual).tryOnNext(t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxDoFinally.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */