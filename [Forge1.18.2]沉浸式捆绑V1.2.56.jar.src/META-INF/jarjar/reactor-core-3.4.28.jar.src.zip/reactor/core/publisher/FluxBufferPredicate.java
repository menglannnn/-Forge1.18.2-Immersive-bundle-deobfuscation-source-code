/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.AbstractQueue;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxBufferPredicate<T, C extends Collection<? super T>>
/*     */   extends InternalFluxOperator<T, C>
/*     */ {
/*     */   final Predicate<? super T> predicate;
/*     */   final Supplier<C> bufferSupplier;
/*     */   final Mode mode;
/*     */   
/*     */   public enum Mode
/*     */   {
/*  62 */     UNTIL, UNTIL_CUT_BEFORE, WHILE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxBufferPredicate(Flux<? extends T> source, Predicate<? super T> predicate, Supplier<C> bufferSupplier, Mode mode) {
/*  73 */     super(source);
/*  74 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*  75 */     this.bufferSupplier = Objects.<Supplier<C>>requireNonNull(bufferSupplier, "bufferSupplier");
/*  76 */     this.mode = mode;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  81 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super C> actual) {
/*  86 */     Collection collection = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null initial buffer");
/*     */ 
/*     */     
/*  89 */     BufferPredicateSubscriber<T, C> parent = new BufferPredicateSubscriber<>(actual, (C)collection, this.bufferSupplier, this.predicate, this.mode);
/*     */ 
/*     */     
/*  92 */     return parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  97 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  98 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class BufferPredicateSubscriber<T, C extends Collection<? super T>>
/*     */     extends AbstractQueue<C>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, C>, BooleanSupplier
/*     */   {
/*     */     final CoreSubscriber<? super C> actual;
/*     */     
/*     */     final Supplier<C> bufferSupplier;
/*     */     
/*     */     final FluxBufferPredicate.Mode mode;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     
/*     */     @Nullable
/*     */     C buffer;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     volatile boolean fastpath;
/*     */     
/*     */     volatile long requestedBuffers;
/*     */     
/* 124 */     static final AtomicLongFieldUpdater<BufferPredicateSubscriber> REQUESTED_BUFFERS = AtomicLongFieldUpdater.newUpdater(BufferPredicateSubscriber.class, "requestedBuffers");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long requestedFromSource;
/*     */ 
/*     */     
/* 131 */     static final AtomicLongFieldUpdater<BufferPredicateSubscriber> REQUESTED_FROM_SOURCE = AtomicLongFieldUpdater.newUpdater(BufferPredicateSubscriber.class, "requestedFromSource");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Subscription s;
/*     */ 
/*     */     
/* 138 */     static final AtomicReferenceFieldUpdater<BufferPredicateSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(BufferPredicateSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     BufferPredicateSubscriber(CoreSubscriber<? super C> actual, C initialBuffer, Supplier<C> bufferSupplier, Predicate<? super T> predicate, FluxBufferPredicate.Mode mode) {
/* 142 */       this.actual = actual;
/* 143 */       this.buffer = initialBuffer;
/* 144 */       this.bufferSupplier = bufferSupplier;
/* 145 */       this.predicate = predicate;
/* 146 */       this.mode = mode;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 151 */       if (Operators.validate(n)) {
/* 152 */         if (n == Long.MAX_VALUE) {
/*     */ 
/*     */           
/* 155 */           this.fastpath = true;
/* 156 */           REQUESTED_BUFFERS.set(this, Long.MAX_VALUE);
/* 157 */           REQUESTED_FROM_SOURCE.set(this, Long.MAX_VALUE);
/* 158 */           this.s.request(Long.MAX_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 167 */         else if (!DrainUtils.postCompleteRequest(n, (Subscriber<? super C>)this.actual, this, REQUESTED_BUFFERS, this, this)) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 172 */           Operators.addCap(REQUESTED_FROM_SOURCE, this, n);
/* 173 */           this.s.request(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 182 */       synchronized (this) {
/* 183 */         C b = this.buffer;
/* 184 */         this.buffer = null;
/* 185 */         Operators.onDiscardMultiple((Collection<?>)b, this.actual.currentContext());
/*     */       } 
/* 187 */       cleanup();
/* 188 */       Operators.terminate(S, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 193 */       if (Operators.setOnce(S, this, s)) {
/* 194 */         this.actual.onSubscribe(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 200 */       if (!tryOnNext(t)) {
/* 201 */         this.s.request(1L);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       boolean match;
/* 207 */       if (this.done) {
/* 208 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 209 */         return true;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 214 */         match = this.predicate.test(t);
/*     */       }
/* 216 */       catch (Throwable e) {
/* 217 */         Context ctx = this.actual.currentContext();
/* 218 */         onError(Operators.onOperatorError(this.s, e, t, ctx));
/* 219 */         Operators.onDiscard(t, ctx);
/* 220 */         return true;
/*     */       } 
/*     */       
/* 223 */       if (this.mode == FluxBufferPredicate.Mode.UNTIL && match) {
/* 224 */         if (cancelledWhileAdding(t)) {
/* 225 */           return true;
/*     */         }
/* 227 */         onNextNewBuffer();
/*     */       }
/* 229 */       else if (this.mode == FluxBufferPredicate.Mode.UNTIL_CUT_BEFORE && match) {
/* 230 */         onNextNewBuffer();
/* 231 */         if (cancelledWhileAdding(t)) {
/* 232 */           return true;
/*     */         }
/*     */       }
/* 235 */       else if (this.mode == FluxBufferPredicate.Mode.WHILE && !match) {
/* 236 */         onNextNewBuffer();
/*     */       
/*     */       }
/* 239 */       else if (cancelledWhileAdding(t)) {
/* 240 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 244 */       if (this.fastpath) {
/* 245 */         return true;
/*     */       }
/*     */       
/* 248 */       boolean isNotExpectingFromSource = (REQUESTED_FROM_SOURCE.decrementAndGet(this) == 0L);
/* 249 */       boolean isStillExpectingBuffer = (REQUESTED_BUFFERS.get(this) > 0L);
/* 250 */       if (isNotExpectingFromSource && isStillExpectingBuffer && REQUESTED_FROM_SOURCE
/* 251 */         .compareAndSet(this, 0L, 1L)) {
/* 252 */         return false;
/*     */       }
/* 254 */       return true;
/*     */     }
/*     */     
/*     */     boolean cancelledWhileAdding(T value) {
/* 258 */       synchronized (this) {
/* 259 */         C b = this.buffer;
/* 260 */         if (b == null || this.s == Operators.cancelledSubscription()) {
/* 261 */           Operators.onDiscard(value, this.actual.currentContext());
/* 262 */           return true;
/*     */         } 
/*     */         
/* 265 */         b.add(value);
/* 266 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     C triggerNewBuffer() {
/*     */       C b;
/*     */       Collection collection;
/* 274 */       synchronized (this) {
/* 275 */         b = this.buffer;
/*     */         
/* 277 */         if (b == null || this.s == Operators.cancelledSubscription()) {
/* 278 */           return null;
/*     */         }
/*     */       } 
/*     */       
/* 282 */       if (b.isEmpty())
/*     */       {
/* 284 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 291 */         collection = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null buffer");
/*     */       
/*     */       }
/* 294 */       catch (Throwable e) {
/* 295 */         onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/* 296 */         return null;
/*     */       } 
/*     */       
/* 299 */       synchronized (this) {
/* 300 */         if (this.buffer == null) {
/* 301 */           return null;
/*     */         }
/* 303 */         this.buffer = (C)collection;
/*     */       } 
/* 305 */       return b;
/*     */     }
/*     */     
/*     */     private void onNextNewBuffer() {
/* 309 */       C b = triggerNewBuffer();
/* 310 */       if (b != null) {
/* 311 */         if (this.fastpath) {
/* 312 */           this.actual.onNext(b);
/*     */           return;
/*     */         } 
/* 315 */         long r = REQUESTED_BUFFERS.getAndDecrement(this);
/* 316 */         if (r > 0L) {
/* 317 */           this.actual.onNext(b);
/*     */           return;
/*     */         } 
/* 320 */         cancel();
/* 321 */         this.actual.onError(Exceptions.failWithOverflow("Could not emit buffer due to lack of requests"));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super C> actual() {
/* 327 */       return this.actual;
/*     */     }
/*     */     
/*     */     public void onError(Throwable t) {
/*     */       C b;
/* 332 */       if (this.done) {
/* 333 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 336 */       this.done = true;
/*     */       
/* 338 */       synchronized (this) {
/* 339 */         b = this.buffer;
/* 340 */         this.buffer = null;
/*     */       } 
/* 342 */       cleanup();
/*     */ 
/*     */       
/* 345 */       Operators.onDiscardMultiple((Collection<?>)b, this.actual.currentContext());
/* 346 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 351 */       if (this.done) {
/*     */         return;
/*     */       }
/* 354 */       this.done = true;
/* 355 */       cleanup();
/* 356 */       DrainUtils.postComplete(this.actual, this, REQUESTED_BUFFERS, this, this);
/*     */     }
/*     */ 
/*     */     
/*     */     void cleanup() {
/* 361 */       if (this.predicate instanceof Disposable) {
/* 362 */         ((Disposable)this.predicate).dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 368 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 369 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 370 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(getAsBoolean()); 
/* 371 */       if (key == Scannable.Attr.CAPACITY) {
/* 372 */         C b = this.buffer;
/* 373 */         return Integer.valueOf((b != null) ? b.size() : 0);
/*     */       } 
/* 375 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requestedBuffers); 
/* 376 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 378 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getAsBoolean() {
/* 383 */       return (this.s == Operators.cancelledSubscription());
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<C> iterator() {
/* 388 */       if (isEmpty()) {
/* 389 */         return Collections.emptyIterator();
/*     */       }
/* 391 */       return Collections.<C>singleton(this.buffer).iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean offer(C objects) {
/* 396 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public C poll() {
/* 402 */       C b = this.buffer;
/* 403 */       if (b != null && !b.isEmpty()) {
/* 404 */         synchronized (this) {
/* 405 */           this.buffer = null;
/*     */         } 
/* 407 */         return b;
/*     */       } 
/* 409 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public C peek() {
/* 415 */       return this.buffer;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 420 */       C b = this.buffer;
/* 421 */       return (b == null || b.isEmpty()) ? 0 : 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 426 */       return "FluxBufferPredicate";
/*     */     }
/*     */   }
/*     */   
/*     */   static class ChangedPredicate<T, K>
/*     */     implements Predicate<T>, Disposable
/*     */   {
/*     */     private Function<? super T, ? extends K> keySelector;
/*     */     private BiPredicate<? super K, ? super K> keyComparator;
/*     */     private K lastKey;
/*     */     
/*     */     ChangedPredicate(Function<? super T, ? extends K> keySelector, BiPredicate<? super K, ? super K> keyComparator) {
/* 438 */       this.keySelector = keySelector;
/* 439 */       this.keyComparator = keyComparator;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 444 */       this.lastKey = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(T t) {
/* 449 */       K k = this.keySelector.apply(t);
/*     */       
/* 451 */       if (null == this.lastKey) {
/* 452 */         this.lastKey = k;
/* 453 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 457 */       boolean match = this.keyComparator.test(this.lastKey, k);
/* 458 */       this.lastKey = k;
/*     */       
/* 460 */       return !match;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxBufferPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */