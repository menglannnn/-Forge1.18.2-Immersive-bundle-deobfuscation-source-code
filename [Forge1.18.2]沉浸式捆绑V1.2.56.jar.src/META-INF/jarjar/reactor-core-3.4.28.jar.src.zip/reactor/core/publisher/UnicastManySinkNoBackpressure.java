/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UnicastManySinkNoBackpressure<T>
/*     */   extends Flux<T>
/*     */   implements InternalManySink<T>, Subscription, ContextHolder
/*     */ {
/*     */   volatile State state;
/*     */   
/*     */   public static <E> UnicastManySinkNoBackpressure<E> create() {
/*  35 */     return new UnicastManySinkNoBackpressure<>();
/*     */   }
/*     */   
/*     */   enum State {
/*  39 */     INITIAL,
/*  40 */     SUBSCRIBED,
/*  41 */     TERMINATED,
/*  42 */     CANCELLED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private static final AtomicReferenceFieldUpdater<UnicastManySinkNoBackpressure, State> STATE = AtomicReferenceFieldUpdater.newUpdater(UnicastManySinkNoBackpressure.class, State.class, "state");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private volatile CoreSubscriber<? super T> actual = null;
/*     */ 
/*     */   
/*     */   volatile long requested;
/*     */   
/*  59 */   static final AtomicLongFieldUpdater<UnicastManySinkNoBackpressure> REQUESTED = AtomicLongFieldUpdater.newUpdater(UnicastManySinkNoBackpressure.class, "requested");
/*     */   
/*     */   UnicastManySinkNoBackpressure() {
/*  62 */     STATE.lazySet(this, State.INITIAL);
/*     */   }
/*     */ 
/*     */   
/*     */   public int currentSubscriberCount() {
/*  67 */     return (this.state == State.SUBSCRIBED) ? 1 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<T> asFlux() {
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  77 */     Objects.requireNonNull(actual, "subscribe");
/*     */     
/*  79 */     if (!STATE.compareAndSet(this, State.INITIAL, State.SUBSCRIBED)) {
/*  80 */       Operators.reportThrowInSubscribe(actual, new IllegalStateException("Unicast Sinks.Many allows only a single Subscriber"));
/*     */       
/*     */       return;
/*     */     } 
/*  84 */     this.actual = actual;
/*  85 */     actual.onSubscribe(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void request(long n) {
/*  90 */     if (Operators.validate(n)) {
/*  91 */       Operators.addCap(REQUESTED, this, n);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/*  97 */     if (STATE.getAndSet(this, State.CANCELLED) == State.SUBSCRIBED) {
/*  98 */       this.actual = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 104 */     CoreSubscriber<? super T> actual = this.actual;
/* 105 */     return (actual != null) ? actual.currentContext() : Context.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitNext(T t) {
/* 110 */     Objects.requireNonNull(t, "t");
/*     */     
/* 112 */     switch (this.state) {
/*     */       case INITIAL:
/* 114 */         return Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER;
/*     */       case SUBSCRIBED:
/* 116 */         if (this.requested == 0L) {
/* 117 */           return Sinks.EmitResult.FAIL_OVERFLOW;
/*     */         }
/*     */         
/* 120 */         this.actual.onNext(t);
/* 121 */         Operators.produced(REQUESTED, this, 1L);
/* 122 */         return Sinks.EmitResult.OK;
/*     */       case TERMINATED:
/* 124 */         return Sinks.EmitResult.FAIL_TERMINATED;
/*     */       case CANCELLED:
/* 126 */         return Sinks.EmitResult.FAIL_CANCELLED;
/*     */     } 
/* 128 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitError(Throwable t) {
/* 134 */     Objects.requireNonNull(t, "t");
/*     */     while (true) {
/* 136 */       State s = this.state;
/* 137 */       switch (s) {
/*     */         case INITIAL:
/* 139 */           return Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER;
/*     */         case SUBSCRIBED:
/* 141 */           if (STATE.compareAndSet(this, s, State.TERMINATED)) {
/* 142 */             this.actual.onError(t);
/* 143 */             this.actual = null;
/* 144 */             return Sinks.EmitResult.OK;
/*     */           } 
/*     */           continue;
/*     */         case TERMINATED:
/* 148 */           return Sinks.EmitResult.FAIL_TERMINATED;
/*     */         case CANCELLED:
/* 150 */           return Sinks.EmitResult.FAIL_CANCELLED;
/*     */       }  break;
/* 152 */     }  throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitComplete() {
/*     */     while (true) {
/* 160 */       State s = this.state;
/* 161 */       switch (s) {
/*     */         case INITIAL:
/* 163 */           return Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER;
/*     */         case SUBSCRIBED:
/* 165 */           if (STATE.compareAndSet(this, s, State.TERMINATED)) {
/* 166 */             this.actual.onComplete();
/* 167 */             this.actual = null;
/* 168 */             return Sinks.EmitResult.OK;
/*     */           } 
/*     */           continue;
/*     */         case TERMINATED:
/* 172 */           return Sinks.EmitResult.FAIL_TERMINATED;
/*     */         case CANCELLED:
/* 174 */           return Sinks.EmitResult.FAIL_CANCELLED;
/*     */       }  break;
/* 176 */     }  throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 183 */     CoreSubscriber<? super T> a = this.actual;
/* 184 */     return (a == null) ? Stream.<Scannable>empty() : Stream.<Scannable>of(Scannable.from(a));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 190 */     if (key == Scannable.Attr.ACTUAL) return this.actual; 
/* 191 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.state == State.TERMINATED)); 
/* 192 */     if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.state == State.CANCELLED));
/*     */     
/* 194 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\UnicastManySinkNoBackpressure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */