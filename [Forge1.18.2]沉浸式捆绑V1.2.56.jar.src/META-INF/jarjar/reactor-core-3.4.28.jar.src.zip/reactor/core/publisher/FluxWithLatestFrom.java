/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxWithLatestFrom<T, U, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final Publisher<? extends U> other;
/*     */   final BiFunction<? super T, ? super U, ? extends R> combiner;
/*     */   
/*     */   FluxWithLatestFrom(Flux<? extends T> source, Publisher<? extends U> other, BiFunction<? super T, ? super U, ? extends R> combiner) {
/*  59 */     super(source);
/*  60 */     this.other = Objects.<Publisher<? extends U>>requireNonNull(other, "other");
/*  61 */     this.combiner = Objects.<BiFunction<? super T, ? super U, ? extends R>>requireNonNull(combiner, "combiner");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  66 */     CoreSubscriber<R> serial = Operators.serialize(actual);
/*     */     
/*  68 */     WithLatestFromSubscriber<T, U, R> main = new WithLatestFromSubscriber<>(serial, this.combiner);
/*     */ 
/*     */     
/*  71 */     WithLatestFromOtherSubscriber<U> secondary = new WithLatestFromOtherSubscriber<>(main);
/*     */ 
/*     */     
/*  74 */     this.other.subscribe((Subscriber)secondary);
/*     */     
/*  76 */     return main;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  81 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  82 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WithLatestFromSubscriber<T, U, R>
/*     */     implements InnerOperator<T, R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final BiFunction<? super T, ? super U, ? extends R> combiner;
/*     */     
/*     */     volatile Subscription main;
/*     */     
/*  95 */     static final AtomicReferenceFieldUpdater<WithLatestFromSubscriber, Subscription> MAIN = AtomicReferenceFieldUpdater.newUpdater(WithLatestFromSubscriber.class, Subscription.class, "main");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Subscription other;
/*     */ 
/*     */ 
/*     */     
/* 103 */     static final AtomicReferenceFieldUpdater<WithLatestFromSubscriber, Subscription> OTHER = AtomicReferenceFieldUpdater.newUpdater(WithLatestFromSubscriber.class, Subscription.class, "other");
/*     */ 
/*     */     
/*     */     volatile U otherValue;
/*     */ 
/*     */ 
/*     */     
/*     */     WithLatestFromSubscriber(CoreSubscriber<? super R> actual, BiFunction<? super T, ? super U, ? extends R> combiner) {
/* 111 */       this.actual = actual;
/* 112 */       this.combiner = combiner;
/*     */     }
/*     */     
/*     */     void setOther(Subscription s) {
/* 116 */       if (!OTHER.compareAndSet(this, null, s)) {
/* 117 */         s.cancel();
/* 118 */         if (this.other != Operators.cancelledSubscription()) {
/* 119 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 126 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 132 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main == Operators.cancelledSubscription())); 
/* 133 */       if (key == Scannable.Attr.PARENT) return this.main; 
/* 134 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 136 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 141 */       return Stream.of(Scannable.from(this.other));
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 146 */       this.main.request(n);
/*     */     }
/*     */     
/*     */     void cancelMain() {
/* 150 */       Subscription s = this.main;
/* 151 */       if (s != Operators.cancelledSubscription()) {
/* 152 */         s = MAIN.getAndSet(this, Operators.cancelledSubscription());
/* 153 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 154 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelOther() {
/* 160 */       Subscription s = this.other;
/* 161 */       if (s != Operators.cancelledSubscription()) {
/* 162 */         s = OTHER.getAndSet(this, Operators.cancelledSubscription());
/* 163 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 164 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 171 */       cancelMain();
/* 172 */       cancelOther();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 177 */       if (!MAIN.compareAndSet(this, null, s)) {
/* 178 */         s.cancel();
/* 179 */         if (this.main != Operators.cancelledSubscription()) {
/* 180 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } else {
/*     */         
/* 184 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 190 */       U u = this.otherValue;
/*     */       
/* 192 */       if (u != null) {
/*     */         R r;
/*     */         
/*     */         try {
/* 196 */           r = Objects.requireNonNull(this.combiner.apply(t, u), "The combiner returned a null value");
/*     */         
/*     */         }
/* 199 */         catch (Throwable e) {
/* 200 */           onError(Operators.onOperatorError(this, e, t, this.actual.currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 204 */         this.actual.onNext(r);
/*     */       } else {
/*     */         
/* 207 */         this.main.request(1L);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 213 */       if (this.main == null && 
/* 214 */         MAIN.compareAndSet(this, null, Operators.cancelledSubscription())) {
/* 215 */         cancelOther();
/*     */         
/* 217 */         Operators.error((Subscriber<?>)this.actual, t);
/*     */         
/*     */         return;
/*     */       } 
/* 221 */       cancelOther();
/*     */       
/* 223 */       this.otherValue = null;
/* 224 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 229 */       cancelOther();
/*     */       
/* 231 */       this.otherValue = null;
/* 232 */       this.actual.onComplete();
/*     */     }
/*     */     
/*     */     void otherError(Throwable t) {
/* 236 */       if (this.main == null && 
/* 237 */         MAIN.compareAndSet(this, null, Operators.cancelledSubscription())) {
/* 238 */         cancelMain();
/*     */         
/* 240 */         Operators.error((Subscriber<?>)this.actual, t);
/*     */         
/*     */         return;
/*     */       } 
/* 244 */       cancelMain();
/*     */       
/* 246 */       this.otherValue = null;
/* 247 */       this.actual.onError(t);
/*     */     }
/*     */     
/*     */     void otherComplete() {
/* 251 */       if (this.otherValue == null) {
/* 252 */         if (this.main == null && 
/* 253 */           MAIN.compareAndSet(this, null, 
/*     */             
/* 255 */             Operators.cancelledSubscription())) {
/* 256 */           cancelMain();
/*     */           
/* 258 */           Operators.complete((Subscriber<?>)this.actual);
/*     */           
/*     */           return;
/*     */         } 
/* 262 */         cancelMain();
/*     */         
/* 264 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class WithLatestFromOtherSubscriber<U>
/*     */     implements InnerConsumer<U> {
/*     */     final FluxWithLatestFrom.WithLatestFromSubscriber<?, U, ?> main;
/*     */     
/*     */     WithLatestFromOtherSubscriber(FluxWithLatestFrom.WithLatestFromSubscriber<?, U, ?> main) {
/* 274 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 279 */       this.main.setOther(s);
/*     */       
/* 281 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 287 */       if (key == Scannable.Attr.ACTUAL) {
/* 288 */         return this.main;
/*     */       }
/* 290 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 291 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 293 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 298 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 303 */       this.main.otherValue = t;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 308 */       this.main.otherError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 313 */       this.main.otherComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxWithLatestFrom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */