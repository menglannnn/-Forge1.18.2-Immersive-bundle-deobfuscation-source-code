/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoRepeat<T>
/*    */   extends FluxFromMonoOperator<T, T>
/*    */ {
/*    */   final long times;
/*    */   
/*    */   MonoRepeat(Mono<? extends T> source, long times) {
/* 38 */     super(source);
/* 39 */     if (times <= 0L) {
/* 40 */       throw new IllegalArgumentException("times > 0 required");
/*    */     }
/* 42 */     this.times = times;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 47 */     FluxRepeat.RepeatSubscriber<T> parent = new FluxRepeat.RepeatSubscriber<>(this.source, actual, this.times + 1L);
/*    */ 
/*    */     
/* 50 */     actual.onSubscribe(parent);
/*    */     
/* 52 */     if (!parent.isCancelled()) {
/* 53 */       parent.onComplete();
/*    */     }
/* 55 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 60 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 61 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoRepeat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */