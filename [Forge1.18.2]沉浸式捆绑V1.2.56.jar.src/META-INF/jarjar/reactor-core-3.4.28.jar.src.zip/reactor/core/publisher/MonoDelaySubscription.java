/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoDelaySubscription<T, U>
/*    */   extends InternalMonoOperator<T, T>
/*    */   implements Consumer<FluxDelaySubscription.DelaySubscriptionOtherSubscriber<T, U>>
/*    */ {
/*    */   final Publisher<U> other;
/*    */   
/*    */   MonoDelaySubscription(Mono<? extends T> source, Publisher<U> other) {
/* 40 */     super(source);
/* 41 */     this.other = Objects.<Publisher<U>>requireNonNull(other, "other");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 46 */     this.other.subscribe((Subscriber)new FluxDelaySubscription.DelaySubscriptionOtherSubscriber<>(actual, this));
/*    */     
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(FluxDelaySubscription.DelaySubscriptionOtherSubscriber<T, U> s) {
/* 53 */     this.source.subscribe(new FluxDelaySubscription.DelaySubscriptionMainSubscriber<>(s.actual, s));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 58 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 59 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoDelaySubscription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */