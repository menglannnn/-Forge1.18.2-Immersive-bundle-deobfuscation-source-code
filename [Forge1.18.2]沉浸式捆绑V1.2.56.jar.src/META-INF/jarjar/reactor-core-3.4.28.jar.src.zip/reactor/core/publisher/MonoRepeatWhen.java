/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoRepeatWhen<T>
/*    */   extends FluxFromMonoOperator<T, T>
/*    */ {
/*    */   final Function<? super Flux<Long>, ? extends Publisher<?>> whenSourceFactory;
/*    */   
/*    */   MonoRepeatWhen(Mono<? extends T> source, Function<? super Flux<Long>, ? extends Publisher<?>> whenSourceFactory) {
/* 44 */     super(source);
/* 45 */     this
/* 46 */       .whenSourceFactory = Objects.<Function<? super Flux<Long>, ? extends Publisher<?>>>requireNonNull(whenSourceFactory, "whenSourceFactory");
/*    */   }
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*    */     Publisher<?> p;
/* 51 */     FluxRepeatWhen.RepeatWhenOtherSubscriber other = new FluxRepeatWhen.RepeatWhenOtherSubscriber();
/*    */ 
/*    */     
/* 54 */     CoreSubscriber<T> serial = Operators.serialize(actual);
/*    */     
/* 56 */     FluxRepeatWhen.RepeatWhenMainSubscriber<T> main = new FluxRepeatWhen.RepeatWhenMainSubscriber<>(serial, other.completionSignal, this.source);
/*    */     
/* 58 */     other.main = main;
/*    */     
/* 60 */     serial.onSubscribe(main);
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 65 */       p = Objects.<Publisher>requireNonNull(this.whenSourceFactory.apply(other), "The whenSourceFactory returned a null Publisher");
/*    */     
/*    */     }
/* 68 */     catch (Throwable e) {
/* 69 */       actual.onError(Operators.onOperatorError(e, actual.currentContext()));
/* 70 */       return null;
/*    */     } 
/*    */     
/* 73 */     p.subscribe((Subscriber)other);
/*    */     
/* 75 */     if (!main.cancelled) {
/* 76 */       return main;
/*    */     }
/*    */     
/* 79 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 85 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 86 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoRepeatWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */