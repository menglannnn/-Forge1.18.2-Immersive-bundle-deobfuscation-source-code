/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface SourceProducer<O>
/*    */   extends Scannable, Publisher<O>
/*    */ {
/*    */   @Nullable
/*    */   default Object scanUnsafe(Scannable.Attr key) {
/* 39 */     if (key == Scannable.Attr.PARENT) return Scannable.from(null); 
/* 40 */     if (key == Scannable.Attr.ACTUAL) return Scannable.from(null);
/*    */     
/* 42 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   default String stepName() {
/* 47 */     return "source(" + getClass().getSimpleName() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\SourceProducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */