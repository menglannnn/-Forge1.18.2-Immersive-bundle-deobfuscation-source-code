/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoFirstWithValue<T>
/*     */   extends Mono<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final Mono<? extends T>[] array;
/*     */   final Iterable<? extends Mono<? extends T>> iterable;
/*     */   
/*     */   private MonoFirstWithValue(Mono<? extends T>[] array) {
/*  33 */     this.array = Objects.<Mono<? extends T>[]>requireNonNull(array, "array");
/*  34 */     this.iterable = null;
/*     */   }
/*     */   
/*     */   @SafeVarargs
/*     */   MonoFirstWithValue(Mono<? extends T> first, Mono<? extends T>... others) {
/*  39 */     Objects.requireNonNull(first, "first");
/*  40 */     Objects.requireNonNull(others, "others");
/*  41 */     Mono[] arrayOfMono = new Mono[others.length + 1];
/*  42 */     arrayOfMono[0] = first;
/*  43 */     System.arraycopy(others, 0, arrayOfMono, 1, others.length);
/*  44 */     this.array = (Mono<? extends T>[])arrayOfMono;
/*  45 */     this.iterable = null;
/*     */   }
/*     */   
/*     */   MonoFirstWithValue(Iterable<? extends Mono<? extends T>> iterable) {
/*  49 */     this.array = null;
/*  50 */     this.iterable = Objects.<Iterable<? extends Mono<? extends T>>>requireNonNull(iterable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @SafeVarargs
/*     */   final MonoFirstWithValue<T> firstValuedAdditionalSources(Mono<? extends T>... others) {
/*  66 */     Objects.requireNonNull(others, "others");
/*  67 */     if (others.length == 0) {
/*  68 */       return this;
/*     */     }
/*  70 */     if (this.array == null)
/*     */     {
/*  72 */       return null;
/*     */     }
/*  74 */     int currentSize = this.array.length;
/*  75 */     int otherSize = others.length;
/*  76 */     Mono[] arrayOfMono = new Mono[currentSize + otherSize];
/*  77 */     System.arraycopy(this.array, 0, arrayOfMono, 0, currentSize);
/*  78 */     System.arraycopy(others, 0, arrayOfMono, currentSize, otherSize);
/*     */     
/*  80 */     return new MonoFirstWithValue((Mono<? extends T>[])arrayOfMono);
/*     */   }
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     Publisher[] arrayOfPublisher;
/*     */     int n;
/*  86 */     Mono<? extends T>[] arrayOfMono = this.array;
/*     */     
/*  88 */     if (arrayOfMono == null) {
/*  89 */       Iterator<? extends Publisher<? extends T>> it; n = 0;
/*  90 */       arrayOfPublisher = new Publisher[8];
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  95 */         it = Objects.<Iterator<? extends Publisher<? extends T>>>requireNonNull((Iterator)this.iterable.iterator(), "The iterator returned is null");
/*     */       }
/*  97 */       catch (Throwable e) {
/*  98 */         Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/*  99 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       while (true) {
/*     */         boolean b;
/*     */         Publisher<? extends T> p;
/*     */         try {
/* 108 */           b = it.hasNext();
/*     */         }
/* 110 */         catch (Throwable e) {
/* 111 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 112 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 116 */         if (!b) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 123 */           p = Objects.<Publisher<? extends T>>requireNonNull(it.next(), "The Publisher returned by the iterator is null");
/*     */         
/*     */         }
/* 126 */         catch (Throwable e) {
/* 127 */           Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual
/* 128 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 132 */         if (n == arrayOfPublisher.length) {
/* 133 */           Publisher[] arrayOfPublisher1 = new Publisher[n + (n >> 2)];
/* 134 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/* 135 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/* 137 */         arrayOfPublisher[n++] = p;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 142 */       n = arrayOfPublisher.length;
/*     */     } 
/*     */     
/* 145 */     if (n == 0) {
/* 146 */       Operators.complete((Subscriber<?>)actual);
/*     */       return;
/*     */     } 
/* 149 */     if (n == 1) {
/* 150 */       Publisher<? extends T> p = arrayOfPublisher[0];
/*     */       
/* 152 */       if (p == null) {
/* 153 */         Operators.error((Subscriber<?>)actual, 
/* 154 */             Operators.onOperatorError(new NullPointerException("The single source Publisher is null"), actual
/* 155 */               .currentContext()));
/*     */       } else {
/*     */         
/* 158 */         p.subscribe((Subscriber)actual);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 163 */     FluxFirstWithValue.RaceValuesCoordinator<T> coordinator = new FluxFirstWithValue.RaceValuesCoordinator<>(n);
/*     */ 
/*     */     
/* 166 */     coordinator.subscribe((Publisher<? extends T>[])arrayOfPublisher, n, actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 171 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 172 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoFirstWithValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */