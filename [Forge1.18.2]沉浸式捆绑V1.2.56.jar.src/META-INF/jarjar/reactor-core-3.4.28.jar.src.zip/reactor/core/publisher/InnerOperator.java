/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface InnerOperator<I, O>
/*    */   extends InnerConsumer<I>, InnerProducer<O>
/*    */ {
/*    */   default Context currentContext() {
/* 33 */     return actual().currentContext();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\InnerOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */