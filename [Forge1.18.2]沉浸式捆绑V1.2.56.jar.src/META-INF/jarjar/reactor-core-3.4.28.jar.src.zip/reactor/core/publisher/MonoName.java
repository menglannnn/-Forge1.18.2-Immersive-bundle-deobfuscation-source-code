/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoName<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */ {
/*     */   final String name;
/*     */   final Set<Tuple2<String, String>> tags;
/*     */   
/*     */   static <T> Mono<T> createOrAppend(Mono<T> source, String name) {
/*  45 */     Objects.requireNonNull(name, "name");
/*     */     
/*  47 */     if (source instanceof MonoName) {
/*  48 */       MonoName<T> s = (MonoName<T>)source;
/*  49 */       return new MonoName<>(s.source, name, s.tags);
/*     */     } 
/*  51 */     if (source instanceof MonoNameFuseable) {
/*  52 */       MonoNameFuseable<T> s = (MonoNameFuseable<T>)source;
/*  53 */       return new MonoNameFuseable<>(s.source, name, s.tags);
/*     */     } 
/*  55 */     if (source instanceof reactor.core.Fuseable) {
/*  56 */       return new MonoNameFuseable<>(source, name, null);
/*     */     }
/*  58 */     return new MonoName<>(source, name, null);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> Mono<T> createOrAppend(Mono<T> source, String tagName, String tagValue) {
/*  63 */     Objects.requireNonNull(tagName, "tagName");
/*  64 */     Objects.requireNonNull(tagValue, "tagValue");
/*     */     
/*  66 */     Set<Tuple2<String, String>> tags = Collections.singleton(Tuples.of(tagName, tagValue));
/*     */     
/*  68 */     if (source instanceof MonoName) {
/*  69 */       MonoName<T> s = (MonoName<T>)source;
/*  70 */       if (s.tags != null) {
/*  71 */         tags = new HashSet<>(tags);
/*  72 */         tags.addAll(s.tags);
/*     */       } 
/*  74 */       return new MonoName<>(s.source, s.name, tags);
/*     */     } 
/*  76 */     if (source instanceof MonoNameFuseable) {
/*  77 */       MonoNameFuseable<T> s = (MonoNameFuseable<T>)source;
/*  78 */       if (s.tags != null) {
/*  79 */         tags = new HashSet<>(tags);
/*  80 */         tags.addAll(s.tags);
/*     */       } 
/*  82 */       return new MonoNameFuseable<>(s.source, s.name, tags);
/*     */     } 
/*  84 */     if (source instanceof reactor.core.Fuseable) {
/*  85 */       return new MonoNameFuseable<>(source, null, tags);
/*     */     }
/*  87 */     return new MonoName<>(source, null, tags);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   MonoName(Mono<? extends T> source, @Nullable String name, @Nullable Set<Tuple2<String, String>> tags) {
/*  93 */     super(source);
/*  94 */     this.name = name;
/*  95 */     this.tags = tags;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 100 */     return actual;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 106 */     if (key == Scannable.Attr.NAME) {
/* 107 */       return this.name;
/*     */     }
/*     */     
/* 110 */     if (key == Scannable.Attr.TAGS && this.tags != null) {
/* 111 */       return this.tags.stream();
/*     */     }
/*     */     
/* 114 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 115 */       return Scannable.Attr.RunStyle.SYNC;
/*     */     }
/*     */     
/* 118 */     return super.scanUnsafe(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */