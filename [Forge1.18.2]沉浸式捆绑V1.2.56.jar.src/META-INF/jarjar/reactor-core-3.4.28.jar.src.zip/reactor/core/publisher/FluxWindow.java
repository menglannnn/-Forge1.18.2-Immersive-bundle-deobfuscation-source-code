/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxWindow<T>
/*     */   extends InternalFluxOperator<T, Flux<T>>
/*     */ {
/*     */   final int size;
/*     */   final int skip;
/*     */   final Supplier<? extends Queue<T>> processorQueueSupplier;
/*     */   final Supplier<? extends Queue<Sinks.Many<T>>> overflowQueueSupplier;
/*     */   
/*     */   FluxWindow(Flux<? extends T> source, int size, Supplier<? extends Queue<T>> processorQueueSupplier) {
/*  56 */     super(source);
/*  57 */     if (size <= 0) {
/*  58 */       throw new IllegalArgumentException("size > 0 required but it was " + size);
/*     */     }
/*  60 */     this.size = size;
/*  61 */     this.skip = size;
/*  62 */     this
/*  63 */       .processorQueueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(processorQueueSupplier, "processorQueueSupplier");
/*  64 */     this.overflowQueueSupplier = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxWindow(Flux<? extends T> source, int size, int skip, Supplier<? extends Queue<T>> processorQueueSupplier, Supplier<? extends Queue<Sinks.Many<T>>> overflowQueueSupplier) {
/*  72 */     super(source);
/*  73 */     if (size <= 0) {
/*  74 */       throw new IllegalArgumentException("size > 0 required but it was " + size);
/*     */     }
/*  76 */     if (skip <= 0) {
/*  77 */       throw new IllegalArgumentException("skip > 0 required but it was " + skip);
/*     */     }
/*  79 */     this.size = size;
/*  80 */     this.skip = skip;
/*  81 */     this
/*  82 */       .processorQueueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(processorQueueSupplier, "processorQueueSupplier");
/*  83 */     this
/*  84 */       .overflowQueueSupplier = Objects.<Supplier<? extends Queue<Sinks.Many<T>>>>requireNonNull(overflowQueueSupplier, "overflowQueueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Flux<T>> actual) {
/*  89 */     if (this.skip == this.size) {
/*  90 */       return new WindowExactSubscriber<>(actual, this.size, this.processorQueueSupplier);
/*     */     }
/*     */ 
/*     */     
/*  94 */     if (this.skip > this.size) {
/*  95 */       return new WindowSkipSubscriber<>(actual, this.size, this.skip, this.processorQueueSupplier);
/*     */     }
/*     */ 
/*     */     
/*  99 */     return new WindowOverlapSubscriber<>(actual, this.size, this.skip, this.processorQueueSupplier, this.overflowQueueSupplier
/*     */         
/* 101 */         .get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 107 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 108 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowExactSubscriber<T>
/*     */     implements Disposable, InnerOperator<T, Flux<T>>
/*     */   {
/*     */     final CoreSubscriber<? super Flux<T>> actual;
/*     */     
/*     */     final Supplier<? extends Queue<T>> processorQueueSupplier;
/*     */     
/*     */     final int size;
/*     */     
/*     */     volatile int cancelled;
/*     */     
/* 123 */     static final AtomicIntegerFieldUpdater<WindowExactSubscriber> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(WindowExactSubscriber.class, "cancelled");
/*     */ 
/*     */     
/*     */     volatile int windowCount;
/*     */     
/* 128 */     static final AtomicIntegerFieldUpdater<WindowExactSubscriber> WINDOW_COUNT = AtomicIntegerFieldUpdater.newUpdater(WindowExactSubscriber.class, "windowCount");
/*     */ 
/*     */     
/*     */     int index;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     Sinks.Many<T> window;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     WindowExactSubscriber(CoreSubscriber<? super Flux<T>> actual, int size, Supplier<? extends Queue<T>> processorQueueSupplier) {
/* 141 */       this.actual = actual;
/* 142 */       this.size = size;
/* 143 */       this.processorQueueSupplier = processorQueueSupplier;
/* 144 */       WINDOW_COUNT.lazySet(this, 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 149 */       if (Operators.validate(this.s, s)) {
/* 150 */         this.s = s;
/* 151 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 157 */       if (this.done) {
/* 158 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 162 */       int i = this.index;
/*     */       
/* 164 */       Sinks.Many<T> w = this.window;
/* 165 */       if (this.cancelled == 0 && i == 0) {
/* 166 */         WINDOW_COUNT.getAndIncrement(this);
/*     */         
/* 168 */         w = Sinks.unsafe().many().unicast().onBackpressureBuffer(this.processorQueueSupplier.get(), this);
/* 169 */         this.window = w;
/*     */         
/* 171 */         this.actual.onNext(w.asFlux());
/*     */       } 
/*     */       
/* 174 */       i++;
/*     */       
/* 176 */       w.emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       
/* 178 */       if (i == this.size) {
/* 179 */         this.index = 0;
/* 180 */         this.window = null;
/* 181 */         w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       } else {
/*     */         
/* 184 */         this.index = i;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 190 */       if (this.done) {
/* 191 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 194 */       this.done = true;
/* 195 */       Sinks.Many<T> w = this.window;
/* 196 */       if (w != null) {
/* 197 */         this.window = null;
/* 198 */         w.emitError(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       } 
/*     */       
/* 201 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 206 */       if (this.done) {
/*     */         return;
/*     */       }
/* 209 */       this.done = true;
/* 210 */       Sinks.Many<T> w = this.window;
/* 211 */       if (w != null) {
/* 212 */         this.window = null;
/* 213 */         w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       } 
/*     */       
/* 216 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 221 */       if (Operators.validate(n)) {
/* 222 */         long u = Operators.multiplyCap(this.size, n);
/* 223 */         this.s.request(u);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 229 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 230 */         dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 236 */       if (WINDOW_COUNT.decrementAndGet(this) == 0) {
/* 237 */         this.s.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Flux<T>> actual() {
/* 243 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 248 */       return (this.cancelled == 1 || this.done);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 254 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 255 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled == 1)); 
/* 256 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.size); 
/* 257 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 258 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 260 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 265 */       return Stream.of(Scannable.from(this.window));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowSkipSubscriber<T>
/*     */     implements Disposable, InnerOperator<T, Flux<T>>
/*     */   {
/*     */     final CoreSubscriber<? super Flux<T>> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Supplier<? extends Queue<T>> processorQueueSupplier;
/*     */     
/*     */     final int size;
/*     */     
/*     */     final int skip;
/*     */     
/*     */     volatile int cancelled;
/* 284 */     static final AtomicIntegerFieldUpdater<WindowSkipSubscriber> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(WindowSkipSubscriber.class, "cancelled");
/*     */ 
/*     */     
/*     */     volatile int windowCount;
/*     */     
/* 289 */     static final AtomicIntegerFieldUpdater<WindowSkipSubscriber> WINDOW_COUNT = AtomicIntegerFieldUpdater.newUpdater(WindowSkipSubscriber.class, "windowCount");
/*     */ 
/*     */     
/*     */     volatile int firstRequest;
/*     */     
/* 294 */     static final AtomicIntegerFieldUpdater<WindowSkipSubscriber> FIRST_REQUEST = AtomicIntegerFieldUpdater.newUpdater(WindowSkipSubscriber.class, "firstRequest");
/*     */ 
/*     */     
/*     */     int index;
/*     */ 
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     Sinks.Many<T> window;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     WindowSkipSubscriber(CoreSubscriber<? super Flux<T>> actual, int size, int skip, Supplier<? extends Queue<T>> processorQueueSupplier) {
/* 309 */       this.actual = actual;
/* 310 */       this.ctx = actual.currentContext();
/* 311 */       this.size = size;
/* 312 */       this.skip = skip;
/* 313 */       this.processorQueueSupplier = processorQueueSupplier;
/* 314 */       WINDOW_COUNT.lazySet(this, 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 319 */       if (Operators.validate(this.s, s)) {
/* 320 */         this.s = s;
/* 321 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 327 */       if (this.done) {
/* 328 */         Operators.onNextDropped(t, this.ctx);
/*     */         
/*     */         return;
/*     */       } 
/* 332 */       int i = this.index;
/*     */       
/* 334 */       Sinks.Many<T> w = this.window;
/* 335 */       if (i == 0) {
/* 336 */         WINDOW_COUNT.getAndIncrement(this);
/*     */         
/* 338 */         w = Sinks.unsafe().many().unicast().onBackpressureBuffer(this.processorQueueSupplier.get(), this);
/* 339 */         this.window = w;
/*     */         
/* 341 */         this.actual.onNext(w.asFlux());
/*     */       } 
/*     */       
/* 344 */       i++;
/*     */       
/* 346 */       if (w != null) {
/* 347 */         w.emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       } else {
/*     */         
/* 350 */         Operators.onDiscard(t, this.ctx);
/*     */       } 
/*     */       
/* 353 */       if (i == this.size) {
/* 354 */         this.window = null;
/* 355 */         if (w != null) {
/* 356 */           w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */         }
/*     */       } 
/*     */       
/* 360 */       if (i == this.skip) {
/* 361 */         this.index = 0;
/*     */       } else {
/*     */         
/* 364 */         this.index = i;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 370 */       if (this.done) {
/* 371 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 374 */       this.done = true;
/*     */       
/* 376 */       Sinks.Many<T> w = this.window;
/* 377 */       if (w != null) {
/* 378 */         this.window = null;
/* 379 */         w.emitError(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       } 
/*     */       
/* 382 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 387 */       if (this.done) {
/*     */         return;
/*     */       }
/* 390 */       this.done = true;
/*     */       
/* 392 */       Sinks.Many<T> w = this.window;
/* 393 */       if (w != null) {
/* 394 */         this.window = null;
/* 395 */         w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       } 
/*     */       
/* 398 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 403 */       if (Operators.validate(n)) {
/* 404 */         if (this.firstRequest == 0 && FIRST_REQUEST.compareAndSet(this, 0, 1)) {
/* 405 */           long u = Operators.multiplyCap(this.size, n);
/* 406 */           long v = Operators.multiplyCap((this.skip - this.size), n - 1L);
/* 407 */           long w = Operators.addCap(u, v);
/* 408 */           this.s.request(w);
/*     */         } else {
/*     */           
/* 411 */           long u = Operators.multiplyCap(this.skip, n);
/* 412 */           this.s.request(u);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 419 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 420 */         dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 426 */       return (this.cancelled == 1 || this.done);
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 431 */       if (WINDOW_COUNT.decrementAndGet(this) == 0) {
/* 432 */         this.s.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Flux<T>> actual() {
/* 438 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 444 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 445 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled == 1)); 
/* 446 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.size); 
/* 447 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 448 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 450 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 455 */       return Stream.of(Scannable.from(this.window));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowOverlapSubscriber<T>
/*     */     extends ArrayDeque<Sinks.Many<T>>
/*     */     implements Disposable, InnerOperator<T, Flux<T>>
/*     */   {
/*     */     final CoreSubscriber<? super Flux<T>> actual;
/*     */     
/*     */     final Supplier<? extends Queue<T>> processorQueueSupplier;
/*     */     
/*     */     final Queue<Sinks.Many<T>> queue;
/*     */     
/*     */     final int size;
/*     */     
/*     */     final int skip;
/*     */     
/*     */     volatile int cancelled;
/* 475 */     static final AtomicIntegerFieldUpdater<WindowOverlapSubscriber> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(WindowOverlapSubscriber.class, "cancelled");
/*     */ 
/*     */     
/*     */     volatile int windowCount;
/*     */ 
/*     */     
/* 481 */     static final AtomicIntegerFieldUpdater<WindowOverlapSubscriber> WINDOW_COUNT = AtomicIntegerFieldUpdater.newUpdater(WindowOverlapSubscriber.class, "windowCount");
/*     */ 
/*     */     
/*     */     volatile int firstRequest;
/*     */ 
/*     */     
/* 487 */     static final AtomicIntegerFieldUpdater<WindowOverlapSubscriber> FIRST_REQUEST = AtomicIntegerFieldUpdater.newUpdater(WindowOverlapSubscriber.class, "firstRequest");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 493 */     static final AtomicLongFieldUpdater<WindowOverlapSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(WindowOverlapSubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/* 499 */     static final AtomicIntegerFieldUpdater<WindowOverlapSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(WindowOverlapSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     int index;
/*     */ 
/*     */     
/*     */     int produced;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     Throwable error;
/*     */ 
/*     */     
/*     */     WindowOverlapSubscriber(CoreSubscriber<? super Flux<T>> actual, int size, int skip, Supplier<? extends Queue<T>> processorQueueSupplier, Queue<Sinks.Many<T>> overflowQueue) {
/* 515 */       this.actual = actual;
/* 516 */       this.size = size;
/* 517 */       this.skip = skip;
/* 518 */       this.processorQueueSupplier = processorQueueSupplier;
/* 519 */       WINDOW_COUNT.lazySet(this, 1);
/* 520 */       this.queue = overflowQueue;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 525 */       if (Operators.validate(this.s, s)) {
/* 526 */         this.s = s;
/* 527 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 533 */       if (this.done) {
/* 534 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 538 */       int i = this.index;
/*     */       
/* 540 */       if (i == 0 && 
/* 541 */         this.cancelled == 0) {
/* 542 */         WINDOW_COUNT.getAndIncrement(this);
/*     */         
/* 544 */         Sinks.Many<T> w = Sinks.unsafe().many().unicast().onBackpressureBuffer(this.processorQueueSupplier.get(), this);
/*     */         
/* 546 */         offer(w);
/*     */         
/* 548 */         this.queue.offer(w);
/* 549 */         drain();
/*     */       } 
/*     */ 
/*     */       
/* 553 */       i++;
/*     */       
/* 555 */       for (Sinks.Many<T> w : this) {
/* 556 */         w.emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       }
/*     */       
/* 559 */       int p = this.produced + 1;
/* 560 */       if (p == this.size) {
/* 561 */         this.produced = p - this.skip;
/*     */         
/* 563 */         Sinks.Many<T> w = poll();
/* 564 */         if (w != null) {
/* 565 */           w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */         }
/*     */       } else {
/*     */         
/* 569 */         this.produced = p;
/*     */       } 
/*     */       
/* 572 */       if (i == this.skip) {
/* 573 */         this.index = 0;
/*     */       } else {
/*     */         
/* 576 */         this.index = i;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 582 */       if (this.done) {
/* 583 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 586 */       this.done = true;
/*     */       
/* 588 */       for (Sinks.Many<T> w : this) {
/* 589 */         w.emitError(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       }
/* 591 */       clear();
/*     */       
/* 593 */       this.error = t;
/* 594 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 599 */       if (this.done) {
/*     */         return;
/*     */       }
/* 602 */       this.done = true;
/*     */       
/* 604 */       for (Sinks.Many<T> w : this) {
/* 605 */         w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       }
/* 607 */       clear();
/*     */       
/* 609 */       drain();
/*     */     }
/*     */     
/*     */     void drain() {
/* 613 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 617 */       CoreSubscriber<? super Flux<T>> coreSubscriber = this.actual;
/* 618 */       Queue<Sinks.Many<T>> q = this.queue;
/* 619 */       int missed = 1;
/*     */ 
/*     */       
/*     */       do {
/* 623 */         long r = this.requested;
/* 624 */         long e = 0L;
/*     */         
/* 626 */         while (e != r) {
/* 627 */           boolean d = this.done;
/*     */           
/* 629 */           Sinks.Many<T> t = q.poll();
/*     */           
/* 631 */           boolean empty = (t == null);
/*     */           
/* 633 */           if (checkTerminated(d, empty, (Subscriber<?>)coreSubscriber, q)) {
/*     */             return;
/*     */           }
/*     */           
/* 637 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 641 */           coreSubscriber.onNext(t.asFlux());
/*     */           
/* 643 */           e++;
/*     */         } 
/*     */         
/* 646 */         if (e == r && 
/* 647 */           checkTerminated(this.done, q.isEmpty(), (Subscriber<?>)coreSubscriber, q)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 652 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 653 */           REQUESTED.addAndGet(this, -e);
/*     */         }
/*     */         
/* 656 */         missed = WIP.addAndGet(this, -missed);
/* 657 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, Queue<?> q) {
/* 664 */       if (this.cancelled == 1) {
/* 665 */         q.clear();
/* 666 */         return true;
/*     */       } 
/*     */       
/* 669 */       if (d) {
/* 670 */         Throwable e = this.error;
/*     */         
/* 672 */         if (e != null) {
/* 673 */           q.clear();
/* 674 */           a.onError(e);
/* 675 */           return true;
/*     */         } 
/* 677 */         if (empty) {
/* 678 */           a.onComplete();
/* 679 */           return true;
/*     */         } 
/*     */       } 
/*     */       
/* 683 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 688 */       if (Operators.validate(n)) {
/*     */         
/* 690 */         Operators.addCap(REQUESTED, this, n);
/*     */         
/* 692 */         if (this.firstRequest == 0 && FIRST_REQUEST.compareAndSet(this, 0, 1)) {
/* 693 */           long u = Operators.multiplyCap(this.skip, n - 1L);
/* 694 */           long v = Operators.addCap(this.size, u);
/* 695 */           this.s.request(v);
/*     */         } else {
/*     */           
/* 698 */           long u = Operators.multiplyCap(this.skip, n);
/* 699 */           this.s.request(u);
/*     */         } 
/*     */         
/* 702 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 708 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 709 */         dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 715 */       if (WINDOW_COUNT.decrementAndGet(this) == 0) {
/* 716 */         this.s.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Flux<T>> actual() {
/* 722 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 727 */       return (this.cancelled == 1 || this.done);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 733 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 734 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled == 1)); 
/* 735 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.size); 
/* 736 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 737 */       if (key == Scannable.Attr.LARGE_BUFFERED) return Long.valueOf(this.queue.size() + size()); 
/* 738 */       if (key == Scannable.Attr.BUFFERED) {
/* 739 */         long realBuffered = this.queue.size() + size();
/* 740 */         if (realBuffered < 2147483647L) return Integer.valueOf((int)realBuffered); 
/* 741 */         return Integer.valueOf(-2147483648);
/*     */       } 
/* 743 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 744 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 745 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 747 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 752 */       return Stream.<Object>of(toArray())
/* 753 */         .map(Scannable::from);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */