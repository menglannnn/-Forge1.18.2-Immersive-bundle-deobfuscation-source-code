/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.BooleanSupplier;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoRepeatPredicate<T>
/*    */   extends FluxFromMonoOperator<T, T>
/*    */ {
/*    */   final BooleanSupplier predicate;
/*    */   
/*    */   MonoRepeatPredicate(Mono<? extends T> source, BooleanSupplier predicate) {
/* 36 */     super(source);
/* 37 */     this.predicate = Objects.<BooleanSupplier>requireNonNull(predicate, "predicate");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 42 */     FluxRepeatPredicate.RepeatPredicateSubscriber<T> parent = new FluxRepeatPredicate.RepeatPredicateSubscriber<>(this.source, actual, this.predicate);
/*    */ 
/*    */     
/* 45 */     actual.onSubscribe(parent);
/*    */     
/* 47 */     if (!parent.isCancelled()) {
/* 48 */       parent.resubscribe();
/*    */     }
/* 50 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 55 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 56 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoRepeatPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */