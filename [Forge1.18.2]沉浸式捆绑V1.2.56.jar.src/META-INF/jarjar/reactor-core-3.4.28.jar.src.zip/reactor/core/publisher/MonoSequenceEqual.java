/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoSequenceEqual<T>
/*     */   extends Mono<Boolean>
/*     */   implements SourceProducer<Boolean>
/*     */ {
/*     */   final Publisher<? extends T> first;
/*     */   final Publisher<? extends T> second;
/*     */   final BiPredicate<? super T, ? super T> comparer;
/*     */   final int prefetch;
/*     */   
/*     */   MonoSequenceEqual(Publisher<? extends T> first, Publisher<? extends T> second, BiPredicate<? super T, ? super T> comparer, int prefetch) {
/*  45 */     this.first = Objects.<Publisher<? extends T>>requireNonNull(first, "first");
/*  46 */     this.second = Objects.<Publisher<? extends T>>requireNonNull(second, "second");
/*  47 */     this.comparer = Objects.<BiPredicate<? super T, ? super T>>requireNonNull(comparer, "comparer");
/*  48 */     if (prefetch < 1) {
/*  49 */       throw new IllegalArgumentException("Buffer size must be strictly positive: " + prefetch);
/*     */     }
/*     */     
/*  52 */     this.prefetch = prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Boolean> actual) {
/*  57 */     EqualCoordinator<T> ec = new EqualCoordinator<>(actual, this.prefetch, this.first, this.second, this.comparer);
/*     */     
/*  59 */     actual.onSubscribe(ec);
/*  60 */     ec.subscribe();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  65 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/*  66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class EqualCoordinator<T>
/*     */     implements InnerProducer<Boolean>
/*     */   {
/*     */     final CoreSubscriber<? super Boolean> actual;
/*     */     
/*     */     final BiPredicate<? super T, ? super T> comparer;
/*     */     final Publisher<? extends T> first;
/*     */     final Publisher<? extends T> second;
/*     */     final MonoSequenceEqual.EqualSubscriber<T> firstSubscriber;
/*     */     final MonoSequenceEqual.EqualSubscriber<T> secondSubscriber;
/*     */     volatile boolean cancelled;
/*     */     volatile int once;
/*  83 */     static final AtomicIntegerFieldUpdater<EqualCoordinator> ONCE = AtomicIntegerFieldUpdater.newUpdater(EqualCoordinator.class, "once");
/*     */ 
/*     */     
/*     */     T v1;
/*     */     
/*     */     T v2;
/*     */     
/*     */     volatile int wip;
/*     */     
/*  92 */     static final AtomicIntegerFieldUpdater<EqualCoordinator> WIP = AtomicIntegerFieldUpdater.newUpdater(EqualCoordinator.class, "wip");
/*     */ 
/*     */ 
/*     */     
/*     */     EqualCoordinator(CoreSubscriber<? super Boolean> actual, int prefetch, Publisher<? extends T> first, Publisher<? extends T> second, BiPredicate<? super T, ? super T> comparer) {
/*  97 */       this.actual = actual;
/*  98 */       this.first = first;
/*  99 */       this.second = second;
/* 100 */       this.comparer = comparer;
/* 101 */       this.firstSubscriber = new MonoSequenceEqual.EqualSubscriber<>(this, prefetch);
/* 102 */       this.secondSubscriber = new MonoSequenceEqual.EqualSubscriber<>(this, prefetch);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Boolean> actual() {
/* 107 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 113 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 114 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 116 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 121 */       return Stream.of((Scannable[])new MonoSequenceEqual.EqualSubscriber[] { this.firstSubscriber, this.secondSubscriber });
/*     */     }
/*     */     
/*     */     void subscribe() {
/* 125 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 126 */         this.first.subscribe((Subscriber)this.firstSubscriber);
/* 127 */         this.second.subscribe((Subscriber)this.secondSubscriber);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 133 */       if (!Operators.validate(n)) {
/*     */         return;
/*     */       }
/* 136 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 137 */         this.first.subscribe((Subscriber)this.firstSubscriber);
/* 138 */         this.second.subscribe((Subscriber)this.secondSubscriber);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 144 */       if (!this.cancelled) {
/* 145 */         this.cancelled = true;
/*     */         
/* 147 */         cancelInner(this.firstSubscriber);
/* 148 */         cancelInner(this.secondSubscriber);
/*     */         
/* 150 */         if (WIP.getAndIncrement(this) == 0) {
/* 151 */           this.firstSubscriber.queue.clear();
/* 152 */           this.secondSubscriber.queue.clear();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancel(MonoSequenceEqual.EqualSubscriber<T> s1, Queue<T> q1, MonoSequenceEqual.EqualSubscriber<T> s2, Queue<T> q2) {
/* 158 */       this.cancelled = true;
/* 159 */       cancelInner(s1);
/* 160 */       q1.clear();
/* 161 */       cancelInner(s2);
/* 162 */       q2.clear();
/*     */     }
/*     */     
/*     */     void cancelInner(MonoSequenceEqual.EqualSubscriber<T> innerSubscriber) {
/* 166 */       Subscription s = innerSubscriber.subscription;
/* 167 */       if (s != Operators.cancelledSubscription()) {
/* 168 */         s = MonoSequenceEqual.EqualSubscriber.S.getAndSet(innerSubscriber, 
/* 169 */             Operators.cancelledSubscription());
/* 170 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 171 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 177 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 181 */       int missed = 1;
/* 182 */       MonoSequenceEqual.EqualSubscriber<T> s1 = this.firstSubscriber;
/* 183 */       Queue<T> q1 = s1.queue;
/* 184 */       MonoSequenceEqual.EqualSubscriber<T> s2 = this.secondSubscriber;
/* 185 */       Queue<T> q2 = s2.queue;
/*     */       
/*     */       do {
/*     */         boolean e1, e2;
/* 189 */         long r = 0L; do {
/*     */           boolean c;
/* 191 */           if (this.cancelled) {
/* 192 */             q1.clear();
/* 193 */             q2.clear();
/*     */             
/*     */             return;
/*     */           } 
/* 197 */           boolean d1 = s1.done;
/*     */           
/* 199 */           if (d1) {
/* 200 */             Throwable e = s1.error;
/* 201 */             if (e != null) {
/* 202 */               cancel(s1, q1, s2, q2);
/*     */               
/* 204 */               this.actual.onError(e);
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 209 */           boolean d2 = s2.done;
/*     */           
/* 211 */           if (d2) {
/* 212 */             Throwable e = s2.error;
/* 213 */             if (e != null) {
/* 214 */               cancel(s1, q1, s2, q2);
/*     */               
/* 216 */               this.actual.onError(e);
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 221 */           if (this.v1 == null) {
/* 222 */             this.v1 = q1.poll();
/*     */           }
/* 224 */           e1 = (this.v1 == null);
/*     */           
/* 226 */           if (this.v2 == null) {
/* 227 */             this.v2 = q2.poll();
/*     */           }
/* 229 */           e2 = (this.v2 == null);
/*     */           
/* 231 */           if (d1 && d2 && e1 && e2) {
/* 232 */             this.actual.onNext(Boolean.valueOf(true));
/* 233 */             this.actual.onComplete();
/*     */             return;
/*     */           } 
/* 236 */           if (d1 && d2 && e1 != e2) {
/* 237 */             cancel(s1, q1, s2, q2);
/*     */             
/* 239 */             this.actual.onNext(Boolean.valueOf(false));
/* 240 */             this.actual.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 244 */           if (e1 || e2) {
/*     */             continue;
/*     */           }
/*     */           try {
/* 248 */             c = this.comparer.test(this.v1, this.v2);
/* 249 */           } catch (Throwable ex) {
/* 250 */             Exceptions.throwIfFatal(ex);
/* 251 */             cancel(s1, q1, s2, q2);
/*     */             
/* 253 */             this.actual.onError(Operators.onOperatorError(ex, this.actual
/* 254 */                   .currentContext()));
/*     */             
/*     */             return;
/*     */           } 
/* 258 */           if (!c) {
/* 259 */             cancel(s1, q1, s2, q2);
/*     */             
/* 261 */             this.actual.onNext(Boolean.valueOf(false));
/* 262 */             this.actual.onComplete();
/*     */             return;
/*     */           } 
/* 265 */           r++;
/*     */           
/* 267 */           this.v1 = null;
/* 268 */           this.v2 = null;
/*     */         
/*     */         }
/* 271 */         while (!e1 && !e2);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 276 */         if (r != 0L) {
/* 277 */           s1.cachedSubscription.request(r);
/* 278 */           s2.cachedSubscription.request(r);
/*     */         } 
/*     */ 
/*     */         
/* 282 */         missed = WIP.addAndGet(this, -missed);
/* 283 */       } while (missed != 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class EqualSubscriber<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final MonoSequenceEqual.EqualCoordinator<T> parent;
/*     */     
/*     */     final Queue<T> queue;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     Throwable error;
/*     */     Subscription cachedSubscription;
/*     */     volatile Subscription subscription;
/* 302 */     static final AtomicReferenceFieldUpdater<EqualSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(EqualSubscriber.class, Subscription.class, "subscription");
/*     */ 
/*     */     
/*     */     EqualSubscriber(MonoSequenceEqual.EqualCoordinator<T> parent, int prefetch) {
/* 306 */       this.parent = parent;
/* 307 */       this.prefetch = prefetch;
/* 308 */       this.queue = Queues.get(prefetch).get();
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 313 */       return this.parent.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 319 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 320 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 321 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 322 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.subscription == Operators.cancelledSubscription())); 
/* 323 */       if (key == Scannable.Attr.PARENT) return this.subscription; 
/* 324 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 325 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 326 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 328 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 333 */       if (Operators.setOnce(S, this, s)) {
/* 334 */         this.cachedSubscription = s;
/* 335 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 341 */       if (!this.queue.offer(t)) {
/* 342 */         onError(Operators.onOperatorError(this.cachedSubscription, 
/* 343 */               Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, 
/* 344 */               currentContext()));
/*     */         return;
/*     */       } 
/* 347 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 352 */       this.error = t;
/* 353 */       this.done = true;
/* 354 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 359 */       this.done = true;
/* 360 */       this.parent.drain();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoSequenceEqual.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */