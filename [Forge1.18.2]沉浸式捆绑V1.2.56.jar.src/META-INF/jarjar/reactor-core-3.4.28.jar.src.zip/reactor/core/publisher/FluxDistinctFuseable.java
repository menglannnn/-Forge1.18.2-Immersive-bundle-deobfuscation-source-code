/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.BiPredicate;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Supplier;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxDistinctFuseable<T, K, C>
/*    */   extends InternalFluxOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<? super T, ? extends K> keyExtractor;
/*    */   final Supplier<C> collectionSupplier;
/*    */   final BiPredicate<C, K> distinctPredicate;
/*    */   final Consumer<C> cleanupCallback;
/*    */   
/*    */   FluxDistinctFuseable(Flux<? extends T> source, Function<? super T, ? extends K> keyExtractor, Supplier<C> collectionSupplier, BiPredicate<C, K> distinctPredicate, Consumer<C> cleanupCallback) {
/* 50 */     super(source);
/* 51 */     this.keyExtractor = Objects.<Function<? super T, ? extends K>>requireNonNull(keyExtractor, "keyExtractor");
/* 52 */     this.collectionSupplier = Objects.<Supplier<C>>requireNonNull(collectionSupplier, "collectionSupplier");
/* 53 */     this.distinctPredicate = Objects.<BiPredicate<C, K>>requireNonNull(distinctPredicate, "distinctPredicate");
/* 54 */     this.cleanupCallback = Objects.<Consumer<C>>requireNonNull(cleanupCallback, "cleanupCallback");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 59 */     C collection = Objects.requireNonNull(this.collectionSupplier.get(), "The collectionSupplier returned a null collection");
/*    */ 
/*    */     
/* 62 */     return new FluxDistinct.DistinctFuseableSubscriber<>(actual, collection, this.keyExtractor, this.distinctPredicate, this.cleanupCallback);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 68 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 69 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxDistinctFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */