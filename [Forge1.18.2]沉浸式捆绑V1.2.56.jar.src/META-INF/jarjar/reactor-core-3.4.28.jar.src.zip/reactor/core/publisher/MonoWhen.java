/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoWhen
/*     */   extends Mono<Void>
/*     */   implements SourceProducer<Void>
/*     */ {
/*     */   final boolean delayError;
/*     */   final Publisher<?>[] sources;
/*     */   final Iterable<? extends Publisher<?>> sourcesIterable;
/*     */   
/*     */   MonoWhen(boolean delayError, Publisher<?>... sources) {
/*  45 */     this.delayError = delayError;
/*  46 */     this.sources = (Publisher<?>[])Objects.requireNonNull(sources, "sources");
/*  47 */     this.sourcesIterable = null;
/*     */   }
/*     */   
/*     */   MonoWhen(boolean delayError, Iterable<? extends Publisher<?>> sourcesIterable) {
/*  51 */     this.delayError = delayError;
/*  52 */     this.sources = null;
/*  53 */     this.sourcesIterable = Objects.<Iterable<? extends Publisher<?>>>requireNonNull(sourcesIterable, "sourcesIterable");
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Mono<Void> whenAdditionalSource(Publisher<?> source) {
/*  59 */     Publisher<?>[] arrayOfPublisher = this.sources;
/*  60 */     if (arrayOfPublisher != null) {
/*  61 */       int oldLen = arrayOfPublisher.length;
/*  62 */       Publisher[] arrayOfPublisher1 = new Publisher[oldLen + 1];
/*  63 */       System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, oldLen);
/*  64 */       arrayOfPublisher1[oldLen] = source;
/*     */       
/*  66 */       return new MonoWhen(this.delayError, (Publisher<?>[])arrayOfPublisher1);
/*     */     } 
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Void> actual) {
/*     */     Publisher[] arrayOfPublisher;
/*  75 */     int n = 0;
/*  76 */     if (this.sources != null) {
/*  77 */       Publisher<?>[] a = this.sources;
/*  78 */       n = a.length;
/*     */     } else {
/*     */       
/*  81 */       arrayOfPublisher = new Publisher[8];
/*  82 */       for (Publisher<?> m : this.sourcesIterable) {
/*  83 */         if (n == arrayOfPublisher.length) {
/*  84 */           Publisher[] arrayOfPublisher1 = new Publisher[n + (n >> 2)];
/*  85 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/*  86 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/*  88 */         arrayOfPublisher[n++] = m;
/*     */       } 
/*     */     } 
/*     */     
/*  92 */     if (n == 0) {
/*  93 */       Operators.complete((Subscriber<?>)actual);
/*     */       
/*     */       return;
/*     */     } 
/*  97 */     WhenCoordinator parent = new WhenCoordinator(actual, n, this.delayError);
/*  98 */     actual.onSubscribe(parent);
/*  99 */     parent.subscribe((Publisher<?>[])arrayOfPublisher);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 104 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 105 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WhenCoordinator
/*     */     extends Operators.MonoSubscriber<Object, Void>
/*     */   {
/*     */     final MonoWhen.WhenInner[] subscribers;
/*     */     
/*     */     final boolean delayError;
/*     */     
/*     */     volatile int done;
/* 119 */     static final AtomicIntegerFieldUpdater<WhenCoordinator> DONE = AtomicIntegerFieldUpdater.newUpdater(WhenCoordinator.class, "done");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     WhenCoordinator(CoreSubscriber<? super Void> subscriber, int n, boolean delayError) {
/* 125 */       super(subscriber);
/* 126 */       this.delayError = delayError;
/* 127 */       this.subscribers = new MonoWhen.WhenInner[n];
/* 128 */       for (int i = 0; i < n; i++) {
/* 129 */         this.subscribers[i] = new MonoWhen.WhenInner(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 136 */       if (key == Scannable.Attr.TERMINATED) {
/* 137 */         return Boolean.valueOf((this.done == this.subscribers.length));
/*     */       }
/* 139 */       if (key == Scannable.Attr.BUFFERED) {
/* 140 */         return Integer.valueOf(this.subscribers.length);
/*     */       }
/* 142 */       if (key == Scannable.Attr.DELAY_ERROR) {
/* 143 */         return Boolean.valueOf(this.delayError);
/*     */       }
/* 145 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 146 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 149 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 154 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */     
/*     */     void subscribe(Publisher<?>[] sources) {
/* 158 */       MonoWhen.WhenInner[] a = this.subscribers;
/* 159 */       for (int i = 0; i < a.length; i++) {
/* 160 */         sources[i].subscribe((Subscriber)a[i]);
/*     */       }
/*     */     }
/*     */     
/*     */     void signalError(Throwable t) {
/* 165 */       if (this.delayError) {
/* 166 */         signal();
/*     */       } else {
/*     */         
/* 169 */         int n = this.subscribers.length;
/* 170 */         if (DONE.getAndSet(this, n) != n) {
/* 171 */           cancel();
/* 172 */           this.actual.onError(t);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void signal() {
/* 179 */       MonoWhen.WhenInner[] a = this.subscribers;
/* 180 */       int n = a.length;
/* 181 */       if (DONE.incrementAndGet(this) != n) {
/*     */         return;
/*     */       }
/*     */       
/* 185 */       Throwable error = null;
/* 186 */       Throwable compositeError = null;
/*     */       
/* 188 */       for (int i = 0; i < a.length; i++) {
/* 189 */         MonoWhen.WhenInner m = a[i];
/* 190 */         Throwable e = m.error;
/* 191 */         if (e != null) {
/* 192 */           if (compositeError != null) {
/*     */             
/* 194 */             compositeError.addSuppressed(e);
/*     */           }
/* 196 */           else if (error != null) {
/* 197 */             compositeError = Exceptions.multiple(new Throwable[] { error, e });
/*     */           } else {
/*     */             
/* 200 */             error = e;
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 206 */       if (compositeError != null) {
/* 207 */         this.actual.onError(compositeError);
/*     */       }
/* 209 */       else if (error != null) {
/* 210 */         this.actual.onError(error);
/*     */       } else {
/*     */         
/* 213 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 219 */       if (!isCancelled()) {
/* 220 */         super.cancel();
/* 221 */         for (MonoWhen.WhenInner ms : this.subscribers) {
/* 222 */           ms.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WhenInner
/*     */     implements InnerConsumer<Object>
/*     */   {
/*     */     final MonoWhen.WhenCoordinator parent;
/*     */     
/*     */     volatile Subscription s;
/* 235 */     static final AtomicReferenceFieldUpdater<WhenInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(WhenInner.class, Subscription.class, "s");
/*     */     
/*     */     Throwable error;
/*     */ 
/*     */     
/*     */     WhenInner(MonoWhen.WhenCoordinator parent) {
/* 241 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 247 */       if (key == Scannable.Attr.CANCELLED) {
/* 248 */         return Boolean.valueOf((this.s == Operators.cancelledSubscription()));
/*     */       }
/* 250 */       if (key == Scannable.Attr.PARENT) {
/* 251 */         return this.s;
/*     */       }
/* 253 */       if (key == Scannable.Attr.ACTUAL) {
/* 254 */         return this.parent;
/*     */       }
/* 256 */       if (key == Scannable.Attr.ERROR) {
/* 257 */         return this.error;
/*     */       }
/* 259 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 260 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 263 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 268 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 273 */       if (Operators.setOnce(S, this, s)) {
/* 274 */         s.request(Long.MAX_VALUE);
/*     */       } else {
/*     */         
/* 277 */         s.cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {}
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 287 */       this.error = t;
/* 288 */       this.parent.signalError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 293 */       this.parent.signal();
/*     */     }
/*     */     
/*     */     void cancel() {
/* 297 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */