/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParallelFluxHide<T>
/*    */   extends ParallelFlux<T>
/*    */   implements Scannable
/*    */ {
/*    */   final ParallelFlux<T> source;
/*    */   
/*    */   ParallelFluxHide(ParallelFlux<T> source) {
/* 35 */     this.source = source;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 40 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   public int parallelism() {
/* 45 */     return this.source.parallelism();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 51 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 52 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 53 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 55 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/* 60 */     if (!validate((Subscriber<?>[])subscribers)) {
/*    */       return;
/*    */     }
/*    */     
/* 64 */     int n = subscribers.length;
/* 65 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*    */     
/* 67 */     for (int i = 0; i < n; i++) {
/* 68 */       arrayOfCoreSubscriber[i] = new FluxHide.HideSubscriber<>(subscribers[i]);
/*    */     }
/*    */     
/* 71 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelFluxHide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */