/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.Queue;
/*    */ import java.util.Spliterator;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Supplier;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoFlattenIterable<T, R>
/*    */   extends FluxFromMonoOperator<T, R>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<? super T, ? extends Iterable<? extends R>> mapper;
/*    */   final int prefetch;
/*    */   final Supplier<Queue<T>> queueSupplier;
/*    */   
/*    */   MonoFlattenIterable(Mono<? extends T> source, Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch, Supplier<Queue<T>> queueSupplier) {
/* 50 */     super(source);
/* 51 */     if (prefetch <= 0) {
/* 52 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*    */     }
/* 54 */     this.mapper = Objects.<Function<? super T, ? extends Iterable<? extends R>>>requireNonNull(mapper, "mapper");
/* 55 */     this.prefetch = prefetch;
/* 56 */     this.queueSupplier = Objects.<Supplier<Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 61 */     return this.prefetch;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) throws Exception {
/* 67 */     if (this.source instanceof Callable) {
/* 68 */       T v = ((Callable)this.source).call();
/*    */       
/* 70 */       if (v == null) {
/* 71 */         Operators.complete((Subscriber<?>)actual);
/* 72 */         return null;
/*    */       } 
/*    */       
/* 75 */       Iterable<? extends R> iter = this.mapper.apply(v);
/* 76 */       Spliterator<? extends R> sp = iter.spliterator();
/* 77 */       boolean itFinite = FluxIterable.checkFinite(sp);
/*    */       
/* 79 */       FluxIterable.subscribe(actual, sp, itFinite);
/*    */       
/* 81 */       return null;
/*    */     } 
/* 83 */     return new FluxFlattenIterable.FlattenIterableSubscriber<>(actual, this.mapper, this.prefetch, this.queueSupplier);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 91 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 92 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoFlattenIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */