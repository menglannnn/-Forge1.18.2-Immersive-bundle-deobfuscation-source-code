/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxJust<T>
/*    */   extends Flux<T>
/*    */   implements Fuseable.ScalarCallable<T>, Fuseable, SourceProducer<T>
/*    */ {
/*    */   final T value;
/*    */   
/*    */   FluxJust(T value) {
/* 58 */     this.value = Objects.requireNonNull(value, "value");
/*    */   }
/*    */ 
/*    */   
/*    */   public T call() throws Exception {
/* 63 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 68 */     actual.onSubscribe(Operators.scalarSubscription(actual, this.value, "just"));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 73 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(1); 
/* 74 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxJust.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */