/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxTakeUntilOther<T, U>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Publisher<U> other;
/*     */   
/*     */   FluxTakeUntilOther(Flux<? extends T> source, Publisher<U> other) {
/*  42 */     super(source);
/*  43 */     this.other = Objects.<Publisher<U>>requireNonNull(other, "other");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  48 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  53 */     TakeUntilMainSubscriber<T> mainSubscriber = new TakeUntilMainSubscriber<>(actual);
/*     */     
/*  55 */     TakeUntilOtherSubscriber<U> otherSubscriber = new TakeUntilOtherSubscriber<>(mainSubscriber);
/*     */     
/*  57 */     this.other.subscribe((Subscriber)otherSubscriber);
/*     */     
/*  59 */     return mainSubscriber;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  65 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class TakeUntilOtherSubscriber<U>
/*     */     implements InnerConsumer<U> {
/*     */     final FluxTakeUntilOther.TakeUntilMainSubscriber<?> main;
/*     */     boolean once;
/*     */     
/*     */     TakeUntilOtherSubscriber(FluxTakeUntilOther.TakeUntilMainSubscriber<?> main) {
/*  74 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/*  79 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  85 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main.other == Operators.cancelledSubscription())); 
/*  86 */       if (key == Scannable.Attr.PARENT) return this.main.other; 
/*  87 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/*  88 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  90 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  95 */       this.main.setOther(s);
/*     */       
/*  97 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 102 */       if (this.once) {
/*     */         return;
/*     */       }
/* 105 */       this.once = true;
/*     */       
/* 107 */       this.main.cancelOther();
/*     */       
/* 109 */       this.main.cancelMainAndComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 114 */       if (this.once) {
/*     */         return;
/*     */       }
/* 117 */       this.once = true;
/* 118 */       this.main.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 123 */       if (this.once) {
/*     */         return;
/*     */       }
/* 126 */       this.once = true;
/*     */       
/* 128 */       this.main.cancelMainAndComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeUntilMainSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     volatile Subscription main;
/*     */     
/* 140 */     static final AtomicReferenceFieldUpdater<TakeUntilMainSubscriber, Subscription> MAIN = AtomicReferenceFieldUpdater.newUpdater(TakeUntilMainSubscriber.class, Subscription.class, "main");
/*     */ 
/*     */     
/*     */     volatile Subscription other;
/*     */     
/* 145 */     static final AtomicReferenceFieldUpdater<TakeUntilMainSubscriber, Subscription> OTHER = AtomicReferenceFieldUpdater.newUpdater(TakeUntilMainSubscriber.class, Subscription.class, "other");
/*     */     
/*     */     TakeUntilMainSubscriber(CoreSubscriber<? super T> actual) {
/* 148 */       this.actual = Operators.serialize(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 154 */       if (key == Scannable.Attr.PARENT) return this.main; 
/* 155 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.main == Operators.cancelledSubscription())); 
/* 156 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 158 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 163 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 168 */       return Stream.of(Scannable.from(this.other));
/*     */     }
/*     */     
/*     */     void setOther(Subscription s) {
/* 172 */       if (!OTHER.compareAndSet(this, null, s)) {
/* 173 */         s.cancel();
/* 174 */         if (this.other != Operators.cancelledSubscription()) {
/* 175 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 182 */       this.main.request(n);
/*     */     }
/*     */     
/*     */     void cancelMainAndComplete() {
/* 186 */       Subscription s = this.main;
/* 187 */       if (s != Operators.cancelledSubscription()) {
/* 188 */         s = MAIN.getAndSet(this, Operators.cancelledSubscription());
/* 189 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 190 */           s.cancel();
/*     */         }
/*     */         
/* 193 */         if (s == null) {
/*     */ 
/*     */           
/* 196 */           Operators.complete((Subscriber<?>)this.actual);
/*     */         }
/*     */         else {
/*     */           
/* 200 */           this.actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelOther() {
/* 206 */       Subscription s = this.other;
/* 207 */       if (s != Operators.cancelledSubscription()) {
/* 208 */         s = OTHER.getAndSet(this, Operators.cancelledSubscription());
/* 209 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 210 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 218 */       Subscription s = this.main;
/* 219 */       if (s != Operators.cancelledSubscription()) {
/* 220 */         s = MAIN.getAndSet(this, Operators.cancelledSubscription());
/* 221 */         if (s != null && s != Operators.cancelledSubscription()) {
/* 222 */           s.cancel();
/*     */         }
/*     */       } 
/*     */       
/* 226 */       cancelOther();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 231 */       if (!MAIN.compareAndSet(this, null, s)) {
/* 232 */         s.cancel();
/* 233 */         if (this.main != Operators.cancelledSubscription()) {
/* 234 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } else {
/* 237 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 243 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 248 */       if (this.main == null && 
/* 249 */         MAIN.compareAndSet(this, null, Operators.cancelledSubscription())) {
/* 250 */         Operators.error((Subscriber<?>)this.actual, t);
/*     */         
/*     */         return;
/*     */       } 
/* 254 */       cancelOther();
/*     */       
/* 256 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 261 */       if (this.main == null && 
/* 262 */         MAIN.compareAndSet(this, null, Operators.cancelledSubscription())) {
/* 263 */         Operators.complete((Subscriber<?>)this.actual);
/*     */         
/*     */         return;
/*     */       } 
/* 267 */       cancelOther();
/*     */       
/* 269 */       this.actual.onComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxTakeUntilOther.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */