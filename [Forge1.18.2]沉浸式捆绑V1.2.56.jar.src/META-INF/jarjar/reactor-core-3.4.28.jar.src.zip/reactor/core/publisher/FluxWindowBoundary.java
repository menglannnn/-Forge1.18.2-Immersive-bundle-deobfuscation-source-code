/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxWindowBoundary<T, U>
/*     */   extends InternalFluxOperator<T, Flux<T>>
/*     */ {
/*     */   final Publisher<U> other;
/*     */   final Supplier<? extends Queue<T>> processorQueueSupplier;
/*     */   
/*     */   FluxWindowBoundary(Flux<? extends T> source, Publisher<U> other, Supplier<? extends Queue<T>> processorQueueSupplier) {
/*  55 */     super(source);
/*  56 */     this.other = Objects.<Publisher<U>>requireNonNull(other, "other");
/*  57 */     this.processorQueueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(processorQueueSupplier, "processorQueueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  62 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Flux<T>> actual) {
/*  69 */     WindowBoundaryMain<T, U> main = new WindowBoundaryMain<>(actual, this.processorQueueSupplier, this.processorQueueSupplier.get());
/*     */     
/*  71 */     actual.onSubscribe(main);
/*     */     
/*  73 */     if (main.emit(main.window)) {
/*  74 */       this.other.subscribe((Subscriber)main.boundary);
/*     */       
/*  76 */       return main;
/*     */     } 
/*     */     
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  85 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  86 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowBoundaryMain<T, U>
/*     */     implements InnerOperator<T, Flux<T>>, Disposable
/*     */   {
/*     */     final Supplier<? extends Queue<T>> processorQueueSupplier;
/*     */     
/*     */     final FluxWindowBoundary.WindowBoundaryOther<U> boundary;
/*     */     
/*     */     final Queue<Object> queue;
/*     */     
/*     */     final CoreSubscriber<? super Flux<T>> actual;
/*     */     
/*     */     Sinks.Many<T> window;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 105 */     static final AtomicReferenceFieldUpdater<WindowBoundaryMain, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(WindowBoundaryMain.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 110 */     static final AtomicLongFieldUpdater<WindowBoundaryMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(WindowBoundaryMain.class, "requested");
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 115 */     static final AtomicReferenceFieldUpdater<WindowBoundaryMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(WindowBoundaryMain.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     volatile int cancelled;
/*     */     
/* 120 */     static final AtomicIntegerFieldUpdater<WindowBoundaryMain> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(WindowBoundaryMain.class, "cancelled");
/*     */ 
/*     */     
/*     */     volatile int windowCount;
/*     */     
/* 125 */     static final AtomicIntegerFieldUpdater<WindowBoundaryMain> WINDOW_COUNT = AtomicIntegerFieldUpdater.newUpdater(WindowBoundaryMain.class, "windowCount");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/* 130 */     static final AtomicIntegerFieldUpdater<WindowBoundaryMain> WIP = AtomicIntegerFieldUpdater.newUpdater(WindowBoundaryMain.class, "wip");
/*     */     
/*     */     boolean done;
/*     */     
/* 134 */     static final Object BOUNDARY_MARKER = new Object();
/*     */     
/* 136 */     static final Object DONE = new Object();
/*     */ 
/*     */ 
/*     */     
/*     */     WindowBoundaryMain(CoreSubscriber<? super Flux<T>> actual, Supplier<? extends Queue<T>> processorQueueSupplier, Queue<T> processorQueue) {
/* 141 */       this.actual = actual;
/* 142 */       this.processorQueueSupplier = processorQueueSupplier;
/* 143 */       this.window = Sinks.unsafe().many().unicast().onBackpressureBuffer(processorQueue, this);
/* 144 */       WINDOW_COUNT.lazySet(this, 2);
/* 145 */       this.boundary = new FluxWindowBoundary.WindowBoundaryOther<>(this);
/* 146 */       this.queue = Queues.unboundedMultiproducer().get();
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super Flux<T>> actual() {
/* 151 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 157 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 158 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 159 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled == 1)); 
/* 160 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 161 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 162 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 163 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 164 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 166 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 171 */       return Stream.of(new Scannable[] { this.boundary, Scannable.from(this.window) });
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 176 */       if (Operators.setOnce(S, this, s)) {
/* 177 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 183 */       if (this.done) {
/* 184 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 187 */       synchronized (this) {
/* 188 */         this.queue.offer(t);
/*     */       } 
/* 190 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 195 */       if (this.done) {
/* 196 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 199 */       this.done = true;
/* 200 */       this.boundary.cancel();
/* 201 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 202 */         drain();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 208 */       if (this.done) {
/*     */         return;
/*     */       }
/* 211 */       this.done = true;
/* 212 */       this.boundary.cancel();
/* 213 */       synchronized (this) {
/* 214 */         this.queue.offer(DONE);
/*     */       } 
/* 216 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 221 */       if (WINDOW_COUNT.decrementAndGet(this) == 0) {
/* 222 */         cancelMain();
/* 223 */         this.boundary.cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 229 */       return (this.cancelled == 1 || this.done);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 234 */       if (Operators.validate(n)) {
/* 235 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */     
/*     */     void cancelMain() {
/* 240 */       Operators.terminate(S, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 245 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 246 */         dispose();
/*     */       }
/*     */     }
/*     */     
/*     */     void boundaryNext() {
/* 251 */       synchronized (this) {
/* 252 */         this.queue.offer(BOUNDARY_MARKER);
/*     */       } 
/*     */       
/* 255 */       if (this.cancelled != 0) {
/* 256 */         this.boundary.cancel();
/*     */       }
/*     */       
/* 259 */       drain();
/*     */     }
/*     */     
/*     */     void boundaryError(Throwable e) {
/* 263 */       cancelMain();
/* 264 */       if (Exceptions.addThrowable(ERROR, this, e)) {
/* 265 */         drain();
/*     */       } else {
/* 267 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void boundaryComplete() {
/* 272 */       cancelMain();
/* 273 */       synchronized (this) {
/* 274 */         this.queue.offer(DONE);
/*     */       } 
/* 276 */       drain();
/*     */     }
/*     */     
/*     */     void drain() {
/* 280 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 284 */       CoreSubscriber<? super Flux<T>> coreSubscriber = this.actual;
/* 285 */       Queue<Object> q = this.queue;
/* 286 */       Sinks.Many<T> w = this.window;
/*     */       
/* 288 */       int missed = 1;
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 293 */         if (this.error != null) {
/* 294 */           q.clear();
/* 295 */           Throwable e = Exceptions.terminate(ERROR, this);
/* 296 */           if (e != Exceptions.TERMINATED) {
/* 297 */             w.emitError(e, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */             
/* 299 */             coreSubscriber.onError(e);
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 304 */         Object o = q.poll();
/*     */         
/* 306 */         if (o == null)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 353 */           missed = WIP.addAndGet(this, -missed);
/* 354 */           if (missed == 0)
/*     */             break;  continue; }  if (o == DONE) { q.clear(); w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST); coreSubscriber.onComplete(); return; }  if (o != BOUNDARY_MARKER) { T v = (T)o; w.emitNext(v, Sinks.EmitFailureHandler.FAIL_FAST); }
/*     */          if (o == BOUNDARY_MARKER) { w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST); if (this.cancelled == 0) { if (this.requested != 0L) { Queue<T> pq = this.processorQueueSupplier.get(); WINDOW_COUNT.getAndIncrement(this); w = Sinks.unsafe().many().unicast().onBackpressureBuffer(pq, this); this.window = w; coreSubscriber.onNext(w.asFlux()); if (this.requested != Long.MAX_VALUE)
/*     */                 REQUESTED.decrementAndGet(this);  continue; }
/*     */              q.clear(); cancelMain(); this.boundary.cancel(); coreSubscriber.onError(Exceptions.failWithOverflow("Could not create new window due to lack of requests")); return; }
/*     */            }
/*     */       
/* 361 */       }  } boolean emit(Sinks.Many<T> w) { long r = this.requested;
/* 362 */       if (r != 0L) {
/* 363 */         this.actual.onNext(w.asFlux());
/* 364 */         if (r != Long.MAX_VALUE) {
/* 365 */           REQUESTED.decrementAndGet(this);
/*     */         }
/* 367 */         return true;
/*     */       } 
/* 369 */       cancel();
/*     */       
/* 371 */       this.actual.onError(Exceptions.failWithOverflow("Could not emit buffer due to lack of requests"));
/*     */       
/* 373 */       return false; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowBoundaryOther<U>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerConsumer<U>
/*     */   {
/*     */     final FluxWindowBoundary.WindowBoundaryMain<?, U> main;
/*     */     
/*     */     WindowBoundaryOther(FluxWindowBoundary.WindowBoundaryMain<?, U> main) {
/* 385 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 390 */       if (set(s)) {
/* 391 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 397 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 403 */       if (key == Scannable.Attr.ACTUAL) {
/* 404 */         return this.main;
/*     */       }
/* 406 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 407 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 409 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 414 */       this.main.boundaryNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 419 */       this.main.boundaryError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 424 */       this.main.boundaryComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxWindowBoundary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */