/*    */ package reactor.core.publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BlockingLastSubscriber<T>
/*    */   extends BlockingSingleSubscriber<T>
/*    */ {
/*    */   public void onNext(T t) {
/* 29 */     this.value = t;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onError(Throwable t) {
/* 34 */     this.value = null;
/* 35 */     this.error = t;
/* 36 */     countDown();
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 41 */     return "blockLast";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\BlockingLastSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */