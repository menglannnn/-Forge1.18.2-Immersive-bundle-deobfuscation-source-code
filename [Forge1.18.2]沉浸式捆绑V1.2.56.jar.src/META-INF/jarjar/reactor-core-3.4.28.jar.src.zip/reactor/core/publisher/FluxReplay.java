/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.CancellationException;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.stream.Stream;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CorePublisher;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.core.scheduler.Scheduler;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.concurrent.Queues;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class FluxReplay<T>
/*      */   extends ConnectableFlux<T>
/*      */   implements Scannable, Fuseable, OptimizableOperator<T, T>
/*      */ {
/*      */   final CorePublisher<T> source;
/*      */   final int history;
/*      */   final long ttl;
/*      */   final Scheduler scheduler;
/*      */   volatile ReplaySubscriber<T> connection;
/*   57 */   static final AtomicReferenceFieldUpdater<FluxReplay, ReplaySubscriber> CONNECTION = AtomicReferenceFieldUpdater.newUpdater(FluxReplay.class, ReplaySubscriber.class, "connection");
/*      */   @Nullable
/*      */   final OptimizableOperator<?, T> optimizableOperator;
/*      */   
/*      */   static interface ReplaySubscription<T> extends Fuseable.QueueSubscription<T>, InnerProducer<T> {
/*      */     CoreSubscriber<? super T> actual();
/*      */     
/*      */     boolean enter();
/*      */     
/*      */     int leave(int param1Int);
/*      */     
/*      */     void produced(long param1Long);
/*      */     
/*      */     void node(@Nullable Object param1Object);
/*      */     
/*      */     @Nullable
/*      */     Object node();
/*      */     
/*      */     int tailIndex();
/*      */     
/*      */     void tailIndex(int param1Int);
/*      */     
/*      */     int index();
/*      */     
/*      */     void index(int param1Int);
/*      */     
/*      */     int fusionMode();
/*      */     
/*      */     boolean isCancelled();
/*      */     
/*      */     long requested();
/*      */     
/*      */     void requestMore(int param1Int); }
/*      */   
/*      */   static interface ReplayBuffer<T> {
/*      */     void add(T param1T);
/*      */     
/*      */     void onError(Throwable param1Throwable);
/*      */     
/*      */     @Nullable
/*      */     Throwable getError();
/*      */     
/*      */     void onComplete();
/*      */     
/*      */     void replay(FluxReplay.ReplaySubscription<T> param1ReplaySubscription);
/*      */     
/*      */     boolean isDone();
/*      */     
/*      */     @Nullable
/*      */     T poll(FluxReplay.ReplaySubscription<T> param1ReplaySubscription);
/*      */     
/*      */     void clear(FluxReplay.ReplaySubscription<T> param1ReplaySubscription);
/*      */     
/*      */     boolean isEmpty(FluxReplay.ReplaySubscription<T> param1ReplaySubscription);
/*      */     
/*      */     int size(FluxReplay.ReplaySubscription<T> param1ReplaySubscription);
/*      */     
/*      */     int size();
/*      */     
/*      */     int capacity();
/*      */     
/*      */     boolean isExpired(); }
/*      */   
/*      */   static final class SizeAndTimeBoundReplayBuffer<T> implements ReplayBuffer<T> {
/*      */     final int limit;
/*      */     final int indexUpdateLimit;
/*      */     final long maxAge;
/*      */     final Scheduler scheduler;
/*      */     int size;
/*      */     volatile TimedNode<T> head;
/*      */     TimedNode<T> tail;
/*      */     Throwable error;
/*      */     static final long NOT_DONE = -9223372036854775808L;
/*      */     
/*      */     static final class TimedNode<T> extends AtomicReference<TimedNode<T>> {
/*      */       final int index;
/*      */       final T value;
/*      */       final long time;
/*      */       
/*      */       TimedNode(int index, @Nullable T value, long time) {
/*  137 */         this.index = index;
/*  138 */         this.value = value;
/*  139 */         this.time = time;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  144 */         return "TimedNode{index=" + this.index + ", value=" + this.value + ", time=" + this.time + '}';
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  165 */     volatile long done = Long.MIN_VALUE;
/*      */ 
/*      */ 
/*      */     
/*      */     SizeAndTimeBoundReplayBuffer(int limit, long maxAge, Scheduler scheduler) {
/*  170 */       this.limit = limit;
/*  171 */       this.indexUpdateLimit = Operators.unboundedOrLimit(limit);
/*  172 */       this.maxAge = maxAge;
/*  173 */       this.scheduler = scheduler;
/*  174 */       TimedNode<T> h = new TimedNode<>(-1, null, 0L);
/*  175 */       this.tail = h;
/*  176 */       this.head = h;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isExpired() {
/*  181 */       long done = this.done;
/*  182 */       return (done != Long.MIN_VALUE && this.scheduler.now(TimeUnit.NANOSECONDS) - this.maxAge > done);
/*      */     }
/*      */ 
/*      */     
/*      */     void replayNormal(FluxReplay.ReplaySubscription<T> rs) {
/*  187 */       int missed = 1;
/*  188 */       CoreSubscriber<? super T> coreSubscriber = rs.actual();
/*      */ 
/*      */       
/*      */       do {
/*  192 */         TimedNode<T> node = (TimedNode<T>)rs.node();
/*  193 */         if (node == null) {
/*  194 */           node = this.head;
/*  195 */           if (this.done == Long.MIN_VALUE) {
/*      */             
/*  197 */             long limit = this.scheduler.now(TimeUnit.NANOSECONDS) - this.maxAge;
/*  198 */             TimedNode<T> next = node;
/*  199 */             while (next != null) {
/*  200 */               long ts = next.time;
/*  201 */               if (ts > limit) {
/*      */                 break;
/*      */               }
/*  204 */               node = next;
/*  205 */               next = node.get();
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  210 */         long r = rs.requested();
/*  211 */         long e = 0L;
/*      */         
/*  213 */         while (e != r) {
/*  214 */           if (rs.isCancelled()) {
/*  215 */             rs.node(null);
/*      */             
/*      */             return;
/*      */           } 
/*  219 */           boolean d = (this.done != Long.MIN_VALUE);
/*  220 */           TimedNode<T> next = node.get();
/*  221 */           boolean empty = (next == null);
/*      */           
/*  223 */           if (d && empty) {
/*  224 */             rs.node(null);
/*  225 */             Throwable ex = this.error;
/*  226 */             if (ex != null) {
/*  227 */               coreSubscriber.onError(ex);
/*      */             } else {
/*      */               
/*  230 */               coreSubscriber.onComplete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*  235 */           if (empty) {
/*      */             break;
/*      */           }
/*      */           
/*  239 */           coreSubscriber.onNext(next.value);
/*      */           
/*  241 */           e++;
/*  242 */           node = next;
/*      */           
/*  244 */           if ((next.index + 1) % this.indexUpdateLimit == 0) {
/*  245 */             rs.requestMore(next.index + 1);
/*      */           }
/*      */         } 
/*      */         
/*  249 */         if (e == r) {
/*  250 */           if (rs.isCancelled()) {
/*  251 */             rs.node(null);
/*      */             
/*      */             return;
/*      */           } 
/*  255 */           boolean d = (this.done != Long.MIN_VALUE);
/*  256 */           boolean empty = (node.get() == null);
/*      */           
/*  258 */           if (d && empty) {
/*  259 */             rs.node(null);
/*  260 */             Throwable ex = this.error;
/*  261 */             if (ex != null) {
/*  262 */               coreSubscriber.onError(ex);
/*      */             } else {
/*      */               
/*  265 */               coreSubscriber.onComplete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/*  271 */         if (e != 0L && 
/*  272 */           r != Long.MAX_VALUE) {
/*  273 */           rs.produced(e);
/*      */         }
/*      */ 
/*      */         
/*  277 */         rs.node(node);
/*      */         
/*  279 */         missed = rs.leave(missed);
/*  280 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void replayFused(FluxReplay.ReplaySubscription<T> rs) {
/*  287 */       int missed = 1;
/*      */       
/*  289 */       CoreSubscriber<? super T> coreSubscriber = rs.actual();
/*      */ 
/*      */       
/*      */       do {
/*  293 */         if (rs.isCancelled()) {
/*  294 */           rs.node(null);
/*      */           
/*      */           return;
/*      */         } 
/*  298 */         boolean d = (this.done != Long.MIN_VALUE);
/*      */         
/*  300 */         coreSubscriber.onNext(null);
/*      */         
/*  302 */         if (d) {
/*  303 */           Throwable ex = this.error;
/*  304 */           if (ex != null) {
/*  305 */             coreSubscriber.onError(ex);
/*      */           } else {
/*      */             
/*  308 */             coreSubscriber.onComplete();
/*      */           } 
/*      */           
/*      */           return;
/*      */         } 
/*  313 */         missed = rs.leave(missed);
/*  314 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onError(Throwable ex) {
/*  322 */       this.done = this.scheduler.now(TimeUnit.NANOSECONDS);
/*  323 */       this.error = ex;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Throwable getError() {
/*  329 */       return this.error;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  334 */       this.done = this.scheduler.now(TimeUnit.NANOSECONDS);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDone() {
/*  339 */       return (this.done != Long.MIN_VALUE);
/*      */     }
/*      */ 
/*      */     
/*      */     TimedNode<T> latestHead(FluxReplay.ReplaySubscription<T> rs) {
/*  344 */       long now = this.scheduler.now(TimeUnit.NANOSECONDS) - this.maxAge;
/*      */       
/*  346 */       TimedNode<T> h = (TimedNode<T>)rs.node();
/*  347 */       if (h == null) {
/*  348 */         h = this.head;
/*      */       }
/*      */       TimedNode<T> n;
/*  351 */       while ((n = h.get()) != null && 
/*  352 */         n.time <= now)
/*      */       {
/*      */         
/*  355 */         h = n;
/*      */       }
/*  357 */       return h;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public T poll(FluxReplay.ReplaySubscription<T> rs) {
/*  363 */       TimedNode<T> node = latestHead(rs);
/*      */       
/*  365 */       long now = this.scheduler.now(TimeUnit.NANOSECONDS) - this.maxAge; TimedNode<T> next;
/*  366 */       while ((next = node.get()) != null) {
/*  367 */         if (next.time > now) {
/*  368 */           node = next;
/*      */           break;
/*      */         } 
/*  371 */         node = next;
/*      */       } 
/*  373 */       if (next == null) {
/*  374 */         if (node.index != -1 && (node.index + 1) % this.indexUpdateLimit == 0) {
/*  375 */           rs.requestMore(node.index + 1);
/*      */         }
/*  377 */         return null;
/*      */       } 
/*  379 */       rs.node(next);
/*  380 */       if ((next.index + 1) % this.indexUpdateLimit == 0) {
/*  381 */         rs.requestMore(next.index + 1);
/*      */       }
/*      */       
/*  384 */       return node.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear(FluxReplay.ReplaySubscription<T> rs) {
/*  389 */       rs.node(null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isEmpty(FluxReplay.ReplaySubscription<T> rs) {
/*  395 */       TimedNode<T> node = latestHead(rs);
/*  396 */       return (node.get() == null);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size(FluxReplay.ReplaySubscription<T> rs) {
/*  401 */       TimedNode<T> node = latestHead(rs);
/*  402 */       int count = 0;
/*      */       
/*      */       TimedNode<T> next;
/*  405 */       while ((next = node.get()) != null && count != Integer.MAX_VALUE) {
/*  406 */         count++;
/*  407 */         node = next;
/*      */       } 
/*      */       
/*  410 */       return count;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  415 */       TimedNode<T> node = this.head;
/*  416 */       int count = 0;
/*      */       
/*      */       TimedNode<T> next;
/*  419 */       while ((next = node.get()) != null && count != Integer.MAX_VALUE) {
/*  420 */         count++;
/*  421 */         node = next;
/*      */       } 
/*      */       
/*  424 */       return count;
/*      */     }
/*      */ 
/*      */     
/*      */     public int capacity() {
/*  429 */       return this.limit;
/*      */     }
/*      */ 
/*      */     
/*      */     public void add(T value) {
/*  434 */       TimedNode<T> tail = this.tail;
/*      */ 
/*      */       
/*  437 */       TimedNode<T> valueNode = new TimedNode<>(tail.index + 1, value, this.scheduler.now(TimeUnit.NANOSECONDS));
/*  438 */       tail.set(valueNode);
/*  439 */       this.tail = valueNode;
/*  440 */       int s = this.size;
/*  441 */       if (s == this.limit) {
/*  442 */         this.head = this.head.get();
/*      */       } else {
/*      */         
/*  445 */         this.size = s + 1;
/*      */       } 
/*  447 */       long limit = this.scheduler.now(TimeUnit.NANOSECONDS) - this.maxAge;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  452 */       if (this.maxAge == 0L) {
/*  453 */         this.head = valueNode;
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  459 */       TimedNode<T> h = this.head;
/*      */       
/*  461 */       int removed = 0;
/*      */       while (true) {
/*  463 */         TimedNode<T> next = h.get();
/*  464 */         if (next == null) {
/*      */           break;
/*      */         }
/*      */         
/*  468 */         if (next.time > limit || next == valueNode) {
/*      */ 
/*      */           
/*  471 */           if (removed != 0) {
/*  472 */             this.size -= removed;
/*  473 */             this.head = h;
/*      */           } 
/*      */           
/*      */           break;
/*      */         } 
/*  478 */         h = next;
/*  479 */         removed++;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void replay(FluxReplay.ReplaySubscription<T> rs) {
/*  486 */       if (!rs.enter()) {
/*      */         return;
/*      */       }
/*      */       
/*  490 */       if (rs.fusionMode() == 0) {
/*  491 */         replayNormal(rs);
/*      */       } else {
/*      */         
/*  494 */         replayFused(rs);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class UnboundedReplayBuffer<T>
/*      */     implements ReplayBuffer<T>
/*      */   {
/*      */     final int batchSize;
/*      */     
/*      */     final int indexUpdateLimit;
/*      */     
/*      */     volatile int size;
/*      */     
/*      */     final Object[] head;
/*      */     Object[] tail;
/*      */     int tailIndex;
/*      */     volatile boolean done;
/*      */     Throwable error;
/*      */     
/*      */     UnboundedReplayBuffer(int batchSize) {
/*  516 */       this.batchSize = batchSize;
/*  517 */       this.indexUpdateLimit = Operators.unboundedOrLimit(batchSize);
/*  518 */       Object[] n = new Object[batchSize + 1];
/*  519 */       this.tail = n;
/*  520 */       this.head = n;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isExpired() {
/*  525 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Throwable getError() {
/*  531 */       return this.error;
/*      */     }
/*      */ 
/*      */     
/*      */     public int capacity() {
/*  536 */       return Integer.MAX_VALUE;
/*      */     }
/*      */ 
/*      */     
/*      */     public void add(T value) {
/*  541 */       int i = this.tailIndex;
/*  542 */       Object[] a = this.tail;
/*  543 */       if (i == a.length - 1) {
/*  544 */         Object[] b = new Object[a.length];
/*  545 */         b[0] = value;
/*  546 */         this.tailIndex = 1;
/*  547 */         a[i] = b;
/*  548 */         this.tail = b;
/*      */       } else {
/*      */         
/*  551 */         a[i] = value;
/*  552 */         this.tailIndex = i + 1;
/*      */       } 
/*  554 */       this.size++;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable ex) {
/*  559 */       this.error = ex;
/*  560 */       this.done = true;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  565 */       this.done = true;
/*      */     }
/*      */     
/*      */     void replayNormal(FluxReplay.ReplaySubscription<T> rs) {
/*  569 */       int missed = 1;
/*      */       
/*  571 */       CoreSubscriber<? super T> coreSubscriber = rs.actual();
/*  572 */       int n = this.batchSize;
/*      */ 
/*      */       
/*      */       do {
/*  576 */         long r = rs.requested();
/*  577 */         long e = 0L;
/*      */         
/*  579 */         Object[] node = (Object[])rs.node();
/*  580 */         if (node == null) {
/*  581 */           node = this.head;
/*      */         }
/*  583 */         int tailIndex = rs.tailIndex();
/*  584 */         int index = rs.index();
/*      */         
/*  586 */         while (e != r) {
/*  587 */           if (rs.isCancelled()) {
/*  588 */             rs.node(null);
/*      */             
/*      */             return;
/*      */           } 
/*  592 */           boolean d = this.done;
/*  593 */           boolean empty = (index == this.size);
/*      */           
/*  595 */           if (d && empty) {
/*  596 */             rs.node(null);
/*  597 */             Throwable ex = this.error;
/*  598 */             if (ex != null) {
/*  599 */               coreSubscriber.onError(ex);
/*      */             } else {
/*      */               
/*  602 */               coreSubscriber.onComplete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*  607 */           if (empty) {
/*      */             break;
/*      */           }
/*      */           
/*  611 */           if (tailIndex == n) {
/*  612 */             node = (Object[])node[tailIndex];
/*  613 */             tailIndex = 0;
/*      */           } 
/*      */           
/*  616 */           T v = (T)node[tailIndex];
/*      */           
/*  618 */           coreSubscriber.onNext(v);
/*      */           
/*  620 */           e++;
/*  621 */           tailIndex++;
/*  622 */           index++;
/*      */           
/*  624 */           if (index % this.indexUpdateLimit == 0) {
/*  625 */             rs.requestMore(index);
/*      */           }
/*      */         } 
/*      */         
/*  629 */         if (e == r) {
/*  630 */           if (rs.isCancelled()) {
/*  631 */             rs.node(null);
/*      */             
/*      */             return;
/*      */           } 
/*  635 */           boolean d = this.done;
/*  636 */           boolean empty = (index == this.size);
/*      */           
/*  638 */           if (d && empty) {
/*  639 */             rs.node(null);
/*  640 */             Throwable ex = this.error;
/*  641 */             if (ex != null) {
/*  642 */               coreSubscriber.onError(ex);
/*      */             } else {
/*      */               
/*  645 */               coreSubscriber.onComplete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/*  651 */         if (e != 0L && 
/*  652 */           r != Long.MAX_VALUE) {
/*  653 */           rs.produced(e);
/*      */         }
/*      */ 
/*      */         
/*  657 */         rs.index(index);
/*  658 */         rs.tailIndex(tailIndex);
/*  659 */         rs.node(node);
/*      */         
/*  661 */         missed = rs.leave(missed);
/*  662 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void replayFused(FluxReplay.ReplaySubscription<T> rs) {
/*  669 */       int missed = 1;
/*      */       
/*  671 */       CoreSubscriber<? super T> coreSubscriber = rs.actual();
/*      */ 
/*      */       
/*      */       do {
/*  675 */         if (rs.isCancelled()) {
/*  676 */           rs.node(null);
/*      */           
/*      */           return;
/*      */         } 
/*  680 */         boolean d = this.done;
/*      */         
/*  682 */         coreSubscriber.onNext(null);
/*      */         
/*  684 */         if (d) {
/*  685 */           Throwable ex = this.error;
/*  686 */           if (ex != null) {
/*  687 */             coreSubscriber.onError(ex);
/*      */           } else {
/*      */             
/*  690 */             coreSubscriber.onComplete();
/*      */           } 
/*      */           
/*      */           return;
/*      */         } 
/*  695 */         missed = rs.leave(missed);
/*  696 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void replay(FluxReplay.ReplaySubscription<T> rs) {
/*  704 */       if (!rs.enter()) {
/*      */         return;
/*      */       }
/*      */       
/*  708 */       if (rs.fusionMode() == 0) {
/*  709 */         replayNormal(rs);
/*      */       } else {
/*      */         
/*  712 */         replayFused(rs);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDone() {
/*  718 */       return this.done;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public T poll(FluxReplay.ReplaySubscription<T> rs) {
/*  724 */       int index = rs.index();
/*  725 */       if (index == this.size) {
/*  726 */         return null;
/*      */       }
/*  728 */       Object[] node = (Object[])rs.node();
/*  729 */       if (node == null) {
/*  730 */         node = this.head;
/*  731 */         rs.node(node);
/*      */       } 
/*  733 */       int tailIndex = rs.tailIndex();
/*  734 */       if (tailIndex == this.batchSize) {
/*  735 */         node = (Object[])node[tailIndex];
/*  736 */         tailIndex = 0;
/*  737 */         rs.node(node);
/*      */       } 
/*  739 */       T v = (T)node[tailIndex];
/*  740 */       rs.tailIndex(tailIndex + 1);
/*      */       
/*  742 */       if ((index + 1) % this.indexUpdateLimit == 0) {
/*  743 */         rs.requestMore(index + 1);
/*      */       } else {
/*      */         
/*  746 */         rs.index(index + 1);
/*      */       } 
/*      */       
/*  749 */       return v;
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear(FluxReplay.ReplaySubscription<T> rs) {
/*  754 */       rs.node(null);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty(FluxReplay.ReplaySubscription<T> rs) {
/*  759 */       return (rs.index() == this.size);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size(FluxReplay.ReplaySubscription<T> rs) {
/*  764 */       return this.size - rs.index();
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  769 */       return this.size;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class SizeBoundReplayBuffer<T>
/*      */     implements ReplayBuffer<T>
/*      */   {
/*      */     final int limit;
/*      */     
/*      */     final int indexUpdateLimit;
/*      */     
/*      */     volatile Node<T> head;
/*      */     
/*      */     Node<T> tail;
/*      */     int size;
/*      */     volatile boolean done;
/*      */     Throwable error;
/*      */     
/*      */     SizeBoundReplayBuffer(int limit) {
/*  789 */       if (limit < 0) {
/*  790 */         throw new IllegalArgumentException("Limit cannot be negative");
/*      */       }
/*  792 */       this.limit = limit;
/*  793 */       this.indexUpdateLimit = Operators.unboundedOrLimit(limit);
/*      */       
/*  795 */       Node<T> n = new Node<>(-1, null);
/*  796 */       this.tail = n;
/*  797 */       this.head = n;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isExpired() {
/*  802 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public int capacity() {
/*  807 */       return this.limit;
/*      */     }
/*      */ 
/*      */     
/*      */     public void add(T value) {
/*  812 */       Node<T> tail = this.tail;
/*  813 */       Node<T> n = new Node<>(tail.index + 1, value);
/*  814 */       tail.set(n);
/*  815 */       this.tail = n;
/*  816 */       int s = this.size;
/*  817 */       if (s == this.limit) {
/*  818 */         this.head = this.head.get();
/*      */       } else {
/*      */         
/*  821 */         this.size = s + 1;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable ex) {
/*  827 */       this.error = ex;
/*  828 */       this.done = true;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  833 */       this.done = true;
/*      */     }
/*      */     
/*      */     void replayNormal(FluxReplay.ReplaySubscription<T> rs) {
/*  837 */       CoreSubscriber<? super T> coreSubscriber = rs.actual();
/*      */       
/*  839 */       int missed = 1;
/*      */ 
/*      */       
/*      */       do {
/*  843 */         long r = rs.requested();
/*  844 */         long e = 0L;
/*      */         
/*  846 */         Node<T> node = (Node<T>)rs.node();
/*  847 */         if (node == null) {
/*  848 */           node = this.head;
/*      */         }
/*      */         
/*  851 */         while (e != r) {
/*  852 */           if (rs.isCancelled()) {
/*  853 */             rs.node(null);
/*      */             
/*      */             return;
/*      */           } 
/*  857 */           boolean d = this.done;
/*  858 */           Node<T> next = node.get();
/*  859 */           boolean empty = (next == null);
/*      */           
/*  861 */           if (d && empty) {
/*  862 */             rs.node(null);
/*  863 */             Throwable ex = this.error;
/*  864 */             if (ex != null) {
/*  865 */               coreSubscriber.onError(ex);
/*      */             } else {
/*      */               
/*  868 */               coreSubscriber.onComplete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*  873 */           if (empty) {
/*      */             break;
/*      */           }
/*      */           
/*  877 */           coreSubscriber.onNext(next.value);
/*      */           
/*  879 */           e++;
/*  880 */           node = next;
/*      */           
/*  882 */           if ((next.index + 1) % this.indexUpdateLimit == 0) {
/*  883 */             rs.requestMore(next.index + 1);
/*      */           }
/*      */         } 
/*      */         
/*  887 */         if (e == r) {
/*  888 */           if (rs.isCancelled()) {
/*  889 */             rs.node(null);
/*      */             
/*      */             return;
/*      */           } 
/*  893 */           boolean d = this.done;
/*  894 */           boolean empty = (node.get() == null);
/*      */           
/*  896 */           if (d && empty) {
/*  897 */             rs.node(null);
/*  898 */             Throwable ex = this.error;
/*  899 */             if (ex != null) {
/*  900 */               coreSubscriber.onError(ex);
/*      */             } else {
/*      */               
/*  903 */               coreSubscriber.onComplete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/*  909 */         if (e != 0L && 
/*  910 */           r != Long.MAX_VALUE) {
/*  911 */           rs.produced(e);
/*      */         }
/*      */ 
/*      */         
/*  915 */         rs.node(node);
/*      */         
/*  917 */         missed = rs.leave(missed);
/*  918 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void replayFused(FluxReplay.ReplaySubscription<T> rs) {
/*  925 */       int missed = 1;
/*      */       
/*  927 */       CoreSubscriber<? super T> coreSubscriber = rs.actual();
/*      */ 
/*      */       
/*      */       do {
/*  931 */         if (rs.isCancelled()) {
/*  932 */           rs.node(null);
/*      */           
/*      */           return;
/*      */         } 
/*  936 */         boolean d = this.done;
/*      */         
/*  938 */         coreSubscriber.onNext(null);
/*      */         
/*  940 */         if (d) {
/*  941 */           Throwable ex = this.error;
/*  942 */           if (ex != null) {
/*  943 */             coreSubscriber.onError(ex);
/*      */           } else {
/*      */             
/*  946 */             coreSubscriber.onComplete();
/*      */           } 
/*      */           
/*      */           return;
/*      */         } 
/*  951 */         missed = rs.leave(missed);
/*  952 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void replay(FluxReplay.ReplaySubscription<T> rs) {
/*  960 */       if (!rs.enter()) {
/*      */         return;
/*      */       }
/*      */       
/*  964 */       if (rs.fusionMode() == 0) {
/*  965 */         replayNormal(rs);
/*      */       } else {
/*      */         
/*  968 */         replayFused(rs);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Throwable getError() {
/*  975 */       return this.error;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDone() {
/*  980 */       return this.done;
/*      */     }
/*      */ 
/*      */     
/*      */     static final class Node<T>
/*      */       extends AtomicReference<Node<T>>
/*      */     {
/*      */       private static final long serialVersionUID = 3713592843205853725L;
/*      */       final int index;
/*      */       final T value;
/*      */       
/*      */       Node(int index, @Nullable T value) {
/*  992 */         this.index = index;
/*  993 */         this.value = value;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/*  998 */         return "Node(" + this.value + ")";
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public T poll(FluxReplay.ReplaySubscription<T> rs) {
/* 1005 */       Node<T> node = (Node<T>)rs.node();
/* 1006 */       if (node == null) {
/* 1007 */         node = this.head;
/* 1008 */         rs.node(node);
/*      */       } 
/*      */       
/* 1011 */       Node<T> next = node.get();
/* 1012 */       if (next == null) {
/* 1013 */         return null;
/*      */       }
/* 1015 */       rs.node(next);
/*      */       
/* 1017 */       if ((next.index + 1) % this.indexUpdateLimit == 0) {
/* 1018 */         rs.requestMore(next.index + 1);
/*      */       }
/*      */       
/* 1021 */       return next.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear(FluxReplay.ReplaySubscription<T> rs) {
/* 1026 */       rs.node(null);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty(FluxReplay.ReplaySubscription<T> rs) {
/* 1031 */       Node<T> node = (Node<T>)rs.node();
/* 1032 */       if (node == null) {
/* 1033 */         node = this.head;
/* 1034 */         rs.node(node);
/*      */       } 
/* 1036 */       return (node.get() == null);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size(FluxReplay.ReplaySubscription<T> rs) {
/* 1041 */       Node<T> node = (Node<T>)rs.node();
/* 1042 */       if (node == null) {
/* 1043 */         node = this.head;
/*      */       }
/* 1045 */       int count = 0;
/*      */       
/*      */       Node<T> next;
/* 1048 */       while ((next = node.get()) != null && count != Integer.MAX_VALUE) {
/* 1049 */         count++;
/* 1050 */         node = next;
/*      */       } 
/*      */       
/* 1053 */       return count;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1058 */       Node<T> node = this.head;
/* 1059 */       int count = 0;
/*      */       
/*      */       Node<T> next;
/* 1062 */       while ((next = node.get()) != null && count != Integer.MAX_VALUE) {
/* 1063 */         count++;
/* 1064 */         node = next;
/*      */       } 
/*      */       
/* 1067 */       return count;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   FluxReplay(CorePublisher<T> source, int history, long ttl, @Nullable Scheduler scheduler) {
/* 1075 */     this.source = Objects.<CorePublisher<T>>requireNonNull(source, "source");
/* 1076 */     if (source instanceof OptimizableOperator) {
/*      */       
/* 1078 */       OptimizableOperator<?, T> optimSource = (OptimizableOperator)source;
/* 1079 */       this.optimizableOperator = optimSource;
/*      */     } else {
/*      */       
/* 1082 */       this.optimizableOperator = null;
/*      */     } 
/*      */     
/* 1085 */     if (history <= 0) {
/* 1086 */       throw new IllegalArgumentException("History cannot be zero or negative : " + history);
/*      */     }
/*      */     
/* 1089 */     this.history = history;
/*      */     
/* 1091 */     if (scheduler != null && ttl < 0L) {
/* 1092 */       throw new IllegalArgumentException("TTL cannot be negative : " + ttl);
/*      */     }
/* 1094 */     this.ttl = ttl;
/* 1095 */     this.scheduler = scheduler;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPrefetch() {
/* 1100 */     return this.history;
/*      */   }
/*      */   
/*      */   ReplaySubscriber<T> newState() {
/* 1104 */     if (this.scheduler != null) {
/* 1105 */       return new ReplaySubscriber<>(new SizeAndTimeBoundReplayBuffer<>(this.history, this.ttl, this.scheduler), this, this.history);
/*      */     }
/*      */ 
/*      */     
/* 1109 */     if (this.history != Integer.MAX_VALUE) {
/* 1110 */       return new ReplaySubscriber<>(new SizeBoundReplayBuffer<>(this.history), this, this.history);
/*      */     }
/*      */ 
/*      */     
/* 1114 */     return new ReplaySubscriber<>(new UnboundedReplayBuffer<>(Queues.SMALL_BUFFER_SIZE), this, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void connect(Consumer<? super Disposable> cancelSupport) {
/*      */     ReplaySubscriber<T> s;
/*      */     while (true) {
/* 1124 */       s = this.connection;
/* 1125 */       if (s == null) {
/* 1126 */         ReplaySubscriber<T> u = newState();
/* 1127 */         if (!CONNECTION.compareAndSet(this, null, u)) {
/*      */           continue;
/*      */         }
/*      */         
/* 1131 */         s = u;
/*      */       }  break;
/*      */     } 
/* 1134 */     boolean doConnect = s.tryConnect();
/*      */ 
/*      */ 
/*      */     
/* 1138 */     cancelSupport.accept(s);
/* 1139 */     if (doConnect) {
/*      */       try {
/* 1141 */         this.source.subscribe(s);
/*      */       }
/* 1143 */       catch (Throwable e) {
/* 1144 */         Operators.reportThrowInSubscribe(s, e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void subscribe(CoreSubscriber<? super T> actual) {
/*      */     try {
/* 1153 */       CoreSubscriber<? super T> nextSubscriber = subscribeOrReturn(actual);
/* 1154 */       if (nextSubscriber == null) {
/*      */         return;
/*      */       }
/* 1157 */       this.source.subscribe(nextSubscriber);
/*      */     }
/* 1159 */     catch (Throwable e) {
/* 1160 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) throws Throwable {
/*      */     boolean expired;
/*      */     ReplaySubscriber<T> c;
/*      */     while (true) {
/* 1169 */       c = this.connection;
/* 1170 */       expired = (this.scheduler != null && c != null && c.buffer.isExpired());
/* 1171 */       if (c == null || expired) {
/* 1172 */         ReplaySubscriber<T> u = newState();
/* 1173 */         if (!CONNECTION.compareAndSet(this, c, u)) {
/*      */           continue;
/*      */         }
/*      */         
/* 1177 */         c = u;
/*      */       }  break;
/*      */     } 
/* 1180 */     ReplayInner<T> inner = new ReplayInner<>(actual, c);
/* 1181 */     actual.onSubscribe(inner);
/* 1182 */     c.add(inner);
/*      */     
/* 1184 */     if (inner.isCancelled()) {
/* 1185 */       c.remove(inner);
/* 1186 */       return null;
/*      */     } 
/*      */     
/* 1189 */     c.buffer.replay(inner);
/*      */     
/* 1191 */     if (expired) {
/* 1192 */       return c;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1197 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public final CorePublisher<? extends T> source() {
/* 1202 */     return this.source;
/*      */   }
/*      */ 
/*      */   
/*      */   public final OptimizableOperator<?, ? extends T> nextOptimizableSource() {
/* 1207 */     return this.optimizableOperator;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/* 1213 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 1214 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 1215 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/* 1216 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */     
/* 1218 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   static final class ReplaySubscriber<T>
/*      */     implements InnerConsumer<T>, Disposable
/*      */   {
/*      */     final FluxReplay<T> parent;
/*      */     
/*      */     final FluxReplay.ReplayBuffer<T> buffer;
/*      */     
/*      */     final long prefetch;
/*      */     
/*      */     final int limit;
/*      */     Subscription s;
/*      */     int produced;
/*      */     int nextPrefetchIndex;
/*      */     volatile FluxReplay.ReplaySubscription<T>[] subscribers;
/*      */     volatile long state;
/* 1237 */     static final AtomicLongFieldUpdater<ReplaySubscriber> STATE = AtomicLongFieldUpdater.newUpdater(ReplaySubscriber.class, "state");
/*      */ 
/*      */     
/* 1240 */     static final FluxReplay.ReplaySubscription[] EMPTY = new FluxReplay.ReplaySubscription[0];
/*      */     
/* 1242 */     static final FluxReplay.ReplaySubscription[] TERMINATED = new FluxReplay.ReplaySubscription[0]; static final long CONNECTED_FLAG = 1152921504606846976L;
/*      */     static final long SUBSCRIBED_FLAG = 2305843009213693952L;
/*      */     
/*      */     ReplaySubscriber(FluxReplay.ReplayBuffer<T> buffer, FluxReplay<T> parent, int prefetch) {
/* 1246 */       this.buffer = buffer;
/* 1247 */       this.parent = parent;
/* 1248 */       this.subscribers = (FluxReplay.ReplaySubscription<T>[])EMPTY;
/* 1249 */       this.prefetch = Operators.unboundedOrPrefetch(prefetch);
/* 1250 */       this.limit = Operators.unboundedOrLimit(prefetch);
/* 1251 */       this.nextPrefetchIndex = this.limit;
/*      */     }
/*      */     static final long DISPOSED_FLAG = -9223372036854775808L; static final long WORK_IN_PROGRESS_MAX_VALUE = 1152921504606846975L;
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 1256 */       if (this.buffer.isDone()) {
/* 1257 */         s.cancel();
/*      */         
/*      */         return;
/*      */       } 
/* 1261 */       if (Operators.validate(this.s, s)) {
/* 1262 */         this.s = s;
/* 1263 */         long previousState = markSubscribed(this);
/*      */         
/* 1265 */         if (isDisposed(previousState)) {
/* 1266 */           s.cancel();
/*      */           
/*      */           return;
/*      */         } 
/* 1270 */         s.request(this.prefetch);
/*      */       } 
/*      */     }
/*      */     
/*      */     void manageRequest(long currentState) {
/* 1275 */       Subscription p = this.s;
/*      */       do {
/*      */         boolean shouldPrefetch;
/* 1278 */         int nextPrefetchIndex = this.nextPrefetchIndex;
/*      */ 
/*      */ 
/*      */         
/* 1282 */         FluxReplay.ReplaySubscription<T>[] subscribers = this.subscribers;
/* 1283 */         if (subscribers.length > 0) {
/* 1284 */           shouldPrefetch = true;
/* 1285 */           for (FluxReplay.ReplaySubscription<T> rp : subscribers) {
/* 1286 */             if (rp.index() < nextPrefetchIndex) {
/* 1287 */               shouldPrefetch = false;
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } else {
/* 1293 */           shouldPrefetch = (this.produced >= nextPrefetchIndex);
/*      */         } 
/*      */         
/* 1296 */         if (shouldPrefetch) {
/* 1297 */           int limit = this.limit;
/* 1298 */           this.nextPrefetchIndex = nextPrefetchIndex + limit;
/* 1299 */           p.request(limit);
/*      */         } 
/*      */         
/* 1302 */         currentState = markWorkDone(this, currentState);
/*      */         
/* 1304 */         if (isDisposed(currentState)) {
/*      */           return;
/*      */         }
/*      */       }
/* 1308 */       while (isWorkInProgress(currentState));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/* 1316 */       FluxReplay.ReplayBuffer<T> b = this.buffer;
/* 1317 */       if (b.isDone()) {
/* 1318 */         Operators.onNextDropped(t, currentContext());
/*      */         
/*      */         return;
/*      */       } 
/* 1322 */       this.produced++;
/*      */       
/* 1324 */       b.add(t);
/*      */       
/* 1326 */       FluxReplay.ReplaySubscription<T>[] subscribers = this.subscribers;
/* 1327 */       if (subscribers.length == 0) {
/* 1328 */         if (this.produced % this.limit == 0) {
/* 1329 */           long previousState = markWorkAdded(this);
/* 1330 */           if (isDisposed(previousState)) {
/*      */             return;
/*      */           }
/*      */           
/* 1334 */           if (isWorkInProgress(previousState)) {
/*      */             return;
/*      */           }
/*      */           
/* 1338 */           manageRequest(previousState + 1L);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/* 1343 */       for (FluxReplay.ReplaySubscription<T> rs : subscribers) {
/* 1344 */         b.replay(rs);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 1352 */       FluxReplay.ReplayBuffer<T> b = this.buffer;
/* 1353 */       if (b.isDone()) {
/* 1354 */         Operators.onErrorDropped(t, currentContext());
/*      */       } else {
/*      */         
/* 1357 */         b.onError(t);
/*      */         
/* 1359 */         for (FluxReplay.ReplaySubscription<T> rs : terminate()) {
/* 1360 */           b.replay(rs);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 1367 */       FluxReplay.ReplayBuffer<T> b = this.buffer;
/* 1368 */       if (!b.isDone()) {
/* 1369 */         b.onComplete();
/*      */         
/* 1371 */         for (FluxReplay.ReplaySubscription<T> rs : terminate()) {
/* 1372 */           b.replay(rs);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void dispose() {
/* 1379 */       long previousState = markDisposed(this);
/* 1380 */       if (isDisposed(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/* 1384 */       if (isSubscribed(previousState)) {
/* 1385 */         this.s.cancel();
/*      */       }
/*      */       
/* 1388 */       FluxReplay.CONNECTION.lazySet(this.parent, null);
/*      */       
/* 1390 */       CancellationException ex = new CancellationException("Disconnected");
/* 1391 */       FluxReplay.ReplayBuffer<T> buffer = this.buffer;
/* 1392 */       buffer.onError(ex);
/*      */       
/* 1394 */       for (FluxReplay.ReplaySubscription<T> inner : terminate()) {
/* 1395 */         buffer.replay(inner);
/*      */       }
/*      */     }
/*      */     
/*      */     boolean add(FluxReplay.ReplayInner<T> inner) {
/* 1400 */       if (this.subscribers == TERMINATED) {
/* 1401 */         return false;
/*      */       }
/* 1403 */       synchronized (this) {
/* 1404 */         FluxReplay.ReplaySubscription<T>[] a = this.subscribers;
/* 1405 */         if (a == TERMINATED) {
/* 1406 */           return false;
/*      */         }
/* 1408 */         int n = a.length;
/*      */         
/* 1410 */         FluxReplay.ReplayInner[] arrayOfReplayInner = new FluxReplay.ReplayInner[n + 1];
/*      */         
/* 1412 */         System.arraycopy(a, 0, arrayOfReplayInner, 0, n);
/* 1413 */         arrayOfReplayInner[n] = inner;
/*      */         
/* 1415 */         this.subscribers = (FluxReplay.ReplaySubscription<T>[])arrayOfReplayInner;
/* 1416 */         return true;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void remove(FluxReplay.ReplaySubscription<T> inner) {
/* 1422 */       FluxReplay.ReplaySubscription<T>[] a = this.subscribers;
/* 1423 */       if (a == TERMINATED || a == EMPTY) {
/*      */         return;
/*      */       }
/* 1426 */       synchronized (this) {
/* 1427 */         FluxReplay.ReplayInner[] arrayOfReplayInner; a = this.subscribers;
/* 1428 */         if (a == TERMINATED || a == EMPTY) {
/*      */           return;
/*      */         }
/*      */         
/* 1432 */         int j = -1;
/* 1433 */         int n = a.length;
/* 1434 */         for (int i = 0; i < n; i++) {
/* 1435 */           if (a[i] == inner) {
/* 1436 */             j = i;
/*      */             break;
/*      */           } 
/*      */         } 
/* 1440 */         if (j < 0) {
/*      */           return;
/*      */         }
/*      */ 
/*      */         
/* 1445 */         if (n == 1) {
/* 1446 */           FluxReplay.ReplaySubscription[] arrayOfReplaySubscription = EMPTY;
/*      */         } else {
/*      */           
/* 1449 */           arrayOfReplayInner = new FluxReplay.ReplayInner[n - 1];
/* 1450 */           System.arraycopy(a, 0, arrayOfReplayInner, 0, j);
/* 1451 */           System.arraycopy(a, j + 1, arrayOfReplayInner, j, n - j - 1);
/*      */         } 
/*      */         
/* 1454 */         this.subscribers = (FluxReplay.ReplaySubscription<T>[])arrayOfReplayInner;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     FluxReplay.ReplaySubscription<T>[] terminate() {
/* 1460 */       FluxReplay.ReplaySubscription<T>[] a = this.subscribers;
/* 1461 */       if (a == TERMINATED) {
/* 1462 */         return a;
/*      */       }
/* 1464 */       synchronized (this) {
/* 1465 */         a = this.subscribers;
/* 1466 */         if (a != TERMINATED) {
/* 1467 */           this.subscribers = (FluxReplay.ReplaySubscription<T>[])TERMINATED;
/*      */         }
/* 1469 */         return a;
/*      */       } 
/*      */     }
/*      */     
/*      */     boolean isTerminated() {
/* 1474 */       return (this.subscribers == TERMINATED);
/*      */     }
/*      */     
/*      */     boolean tryConnect() {
/* 1478 */       return markConnected(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 1483 */       return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1489 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 1490 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 1491 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.buffer.capacity()); 
/* 1492 */       if (key == Scannable.Attr.ERROR) return this.buffer.getError(); 
/* 1493 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.buffer.size()); 
/* 1494 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isTerminated()); 
/* 1495 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 1496 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/* 1498 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<? extends Scannable> inners() {
/* 1503 */       return Stream.of((Scannable[])this.subscribers);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDisposed() {
/* 1508 */       return isDisposed(this.state);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static boolean markConnected(ReplaySubscriber<?> instance) {
/*      */       while (true) {
/* 1528 */         long state = instance.state;
/*      */         
/* 1530 */         if (isConnected(state)) {
/* 1531 */           return false;
/*      */         }
/*      */         
/* 1534 */         if (STATE.compareAndSet(instance, state, state | 0x1000000000000000L)) {
/* 1535 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static long markSubscribed(ReplaySubscriber<?> instance) {
/*      */       while (true) {
/* 1549 */         long state = instance.state;
/*      */         
/* 1551 */         if (isDisposed(state)) {
/* 1552 */           return state;
/*      */         }
/*      */         
/* 1555 */         if (STATE.compareAndSet(instance, state, state | 0x2000000000000000L)) {
/* 1556 */           return state;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static long markWorkAdded(ReplaySubscriber<?> instance) {
/*      */       while (true) {
/* 1570 */         long state = instance.state;
/*      */         
/* 1572 */         if (isDisposed(state)) {
/* 1573 */           return state;
/*      */         }
/*      */         
/* 1576 */         if ((state & 0xFFFFFFFFFFFFFFFL) == 1152921504606846975L) {
/* 1577 */           return state;
/*      */         }
/*      */         
/* 1580 */         if (STATE.compareAndSet(instance, state, state + 1L)) {
/* 1581 */           return state;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static long markWorkDone(ReplaySubscriber<?> instance, long currentState) {
/*      */       while (true) {
/* 1595 */         long state = instance.state;
/*      */         
/* 1597 */         if (currentState != state) {
/* 1598 */           return state;
/*      */         }
/*      */         
/* 1601 */         long nextState = state & 0xF000000000000000L;
/* 1602 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1603 */           return nextState;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static long markDisposed(ReplaySubscriber<?> instance) {
/*      */       while (true) {
/* 1617 */         long state = instance.state;
/*      */         
/* 1619 */         if (isDisposed(state)) {
/* 1620 */           return state;
/*      */         }
/*      */         
/* 1623 */         if (STATE.compareAndSet(instance, state, state | Long.MIN_VALUE)) {
/* 1624 */           return state;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static boolean isConnected(long state) {
/* 1638 */       return ((state & 0x1000000000000000L) == 1152921504606846976L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static boolean isSubscribed(long state) {
/* 1649 */       return ((state & 0x2000000000000000L) == 2305843009213693952L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static boolean isWorkInProgress(long state) {
/* 1659 */       return ((state & 0xFFFFFFFFFFFFFFFL) > 0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static boolean isDisposed(long state) {
/* 1669 */       return ((state & Long.MIN_VALUE) == Long.MIN_VALUE);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class ReplayInner<T>
/*      */     implements ReplaySubscription<T>
/*      */   {
/*      */     final CoreSubscriber<? super T> actual;
/*      */     
/*      */     final FluxReplay.ReplaySubscriber<T> parent;
/*      */     
/*      */     int index;
/*      */     
/*      */     int tailIndex;
/*      */     
/*      */     Object node;
/*      */     
/*      */     int fusionMode;
/*      */     
/*      */     long totalRequested;
/*      */     
/*      */     volatile int wip;
/* 1692 */     static final AtomicIntegerFieldUpdater<ReplayInner> WIP = AtomicIntegerFieldUpdater.newUpdater(ReplayInner.class, "wip");
/*      */ 
/*      */     
/*      */     volatile long requested;
/*      */     
/* 1697 */     static final AtomicLongFieldUpdater<ReplayInner> REQUESTED = AtomicLongFieldUpdater.newUpdater(ReplayInner.class, "requested");
/*      */     
/*      */     ReplayInner(CoreSubscriber<? super T> actual, FluxReplay.ReplaySubscriber<T> parent) {
/* 1700 */       this.actual = actual;
/* 1701 */       this.parent = parent;
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 1706 */       if (Operators.validate(n) && 
/* 1707 */         Operators.addCapCancellable(REQUESTED, this, n) != Long.MIN_VALUE) {
/*      */         
/* 1709 */         this.totalRequested = Operators.addCap(this.totalRequested, n);
/*      */         
/* 1711 */         this.parent.buffer.replay(this);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1719 */       if (key == Scannable.Attr.PARENT) {
/* 1720 */         return this.parent;
/*      */       }
/* 1722 */       if (key == Scannable.Attr.TERMINATED) {
/* 1723 */         return Boolean.valueOf(this.parent.isTerminated());
/*      */       }
/* 1725 */       if (key == Scannable.Attr.BUFFERED) {
/* 1726 */         return Integer.valueOf(size());
/*      */       }
/* 1728 */       if (key == Scannable.Attr.CANCELLED) {
/* 1729 */         return Boolean.valueOf(isCancelled());
/*      */       }
/* 1731 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/* 1732 */         return Long.valueOf(Math.max(0L, this.requested));
/*      */       }
/* 1734 */       if (key == Scannable.Attr.RUN_ON) {
/* 1735 */         return this.parent.parent.scheduler;
/*      */       }
/*      */       
/* 1738 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 1743 */       if (REQUESTED.getAndSet(this, Long.MIN_VALUE) != Long.MIN_VALUE) {
/* 1744 */         this.parent.remove(this);
/* 1745 */         if (enter()) {
/* 1746 */           this.node = null;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public long requested() {
/* 1753 */       return this.requested;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isCancelled() {
/* 1758 */       return (this.requested == Long.MIN_VALUE);
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> actual() {
/* 1763 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public int requestFusion(int requestedMode) {
/* 1768 */       if ((requestedMode & 0x2) != 0) {
/* 1769 */         this.fusionMode = 2;
/* 1770 */         return 2;
/*      */       } 
/* 1772 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public T poll() {
/* 1778 */       return this.parent.buffer.poll(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1783 */       this.parent.buffer.clear(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1788 */       return this.parent.buffer.isEmpty(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1793 */       return this.parent.buffer.size(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void node(@Nullable Object node) {
/* 1798 */       this.node = node;
/*      */     }
/*      */ 
/*      */     
/*      */     public int fusionMode() {
/* 1803 */       return this.fusionMode;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object node() {
/* 1809 */       return this.node;
/*      */     }
/*      */ 
/*      */     
/*      */     public int index() {
/* 1814 */       return this.index;
/*      */     }
/*      */ 
/*      */     
/*      */     public void index(int index) {
/* 1819 */       this.index = index;
/*      */     }
/*      */ 
/*      */     
/*      */     public void requestMore(int index) {
/* 1824 */       this.index = index;
/*      */       
/* 1826 */       long previousState = FluxReplay.ReplaySubscriber.markWorkAdded(this.parent);
/*      */       
/* 1828 */       if (FluxReplay.ReplaySubscriber.isDisposed(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/* 1832 */       if (FluxReplay.ReplaySubscriber.isWorkInProgress(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/* 1836 */       this.parent.manageRequest(previousState + 1L);
/*      */     }
/*      */ 
/*      */     
/*      */     public int tailIndex() {
/* 1841 */       return this.tailIndex;
/*      */     }
/*      */ 
/*      */     
/*      */     public void tailIndex(int tailIndex) {
/* 1846 */       this.tailIndex = tailIndex;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean enter() {
/* 1851 */       return (WIP.getAndIncrement(this) == 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public int leave(int missed) {
/* 1856 */       return WIP.addAndGet(this, -missed);
/*      */     }
/*      */ 
/*      */     
/*      */     public void produced(long n) {
/* 1861 */       REQUESTED.addAndGet(this, -n);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxReplay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */