/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoHasElement<T>
/*    */   extends InternalMonoOperator<T, Boolean>
/*    */   implements Fuseable
/*    */ {
/*    */   MonoHasElement(Mono<? extends T> source) {
/* 31 */     super(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 36 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 37 */     return super.scanUnsafe(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Boolean> actual) {
/* 42 */     return new HasElementSubscriber<>(actual);
/*    */   }
/*    */   
/*    */   static final class HasElementSubscriber<T>
/*    */     extends Operators.MonoSubscriber<T, Boolean> {
/*    */     Subscription s;
/*    */     
/*    */     HasElementSubscriber(CoreSubscriber<? super Boolean> actual) {
/* 50 */       super(actual);
/*    */     }
/*    */ 
/*    */     
/*    */     @Nullable
/*    */     public Object scanUnsafe(Scannable.Attr key) {
/* 56 */       if (key == Scannable.Attr.PARENT) {
/* 57 */         return this.s;
/*    */       }
/* 59 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 60 */         return Scannable.Attr.RunStyle.SYNC;
/*    */       }
/* 62 */       return super.scanUnsafe(key);
/*    */     }
/*    */ 
/*    */     
/*    */     public void cancel() {
/* 67 */       super.cancel();
/* 68 */       this.s.cancel();
/*    */     }
/*    */ 
/*    */     
/*    */     public void onSubscribe(Subscription s) {
/* 73 */       if (Operators.validate(this.s, s)) {
/* 74 */         this.s = s;
/* 75 */         this.actual.onSubscribe(this);
/*    */         
/* 77 */         s.request(Long.MAX_VALUE);
/*    */       } 
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public void onNext(T t) {
/* 84 */       complete(Boolean.valueOf(true));
/*    */     }
/*    */ 
/*    */     
/*    */     public void onComplete() {
/* 89 */       complete(Boolean.valueOf(false));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoHasElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */