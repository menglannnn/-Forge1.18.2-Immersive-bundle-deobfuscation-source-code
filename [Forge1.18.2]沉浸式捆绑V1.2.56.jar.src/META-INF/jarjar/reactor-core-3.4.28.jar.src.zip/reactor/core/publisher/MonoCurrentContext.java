/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ final class MonoCurrentContext
/*    */   extends Mono<Context>
/*    */   implements Fuseable, Scannable
/*    */ {
/* 31 */   static final MonoCurrentContext INSTANCE = new MonoCurrentContext();
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super Context> actual) {
/* 35 */     Context ctx = actual.currentContext();
/* 36 */     actual.onSubscribe(Operators.scalarSubscription(actual, ctx));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 41 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 42 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoCurrentContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */