/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelGroup<T>
/*     */   extends Flux<GroupedFlux<Integer, T>>
/*     */   implements Scannable, Fuseable
/*     */ {
/*     */   final ParallelFlux<? extends T> source;
/*     */   
/*     */   ParallelGroup(ParallelFlux<? extends T> source) {
/*  43 */     this.source = source;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super GroupedFlux<Integer, T>> actual) {
/*  48 */     int n = this.source.parallelism();
/*     */ 
/*     */     
/*  51 */     ParallelInnerGroup[] arrayOfParallelInnerGroup = new ParallelInnerGroup[n];
/*     */     
/*  53 */     for (int i = 0; i < n; i++) {
/*  54 */       arrayOfParallelInnerGroup[i] = new ParallelInnerGroup(i);
/*     */     }
/*     */     
/*  57 */     FluxArray.subscribe(actual, (GroupedFlux<Integer, T>[])arrayOfParallelInnerGroup);
/*     */     
/*  59 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfParallelInnerGroup);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  65 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  66 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  67 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ParallelInnerGroup<T>
/*     */     extends GroupedFlux<Integer, T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final int key;
/*     */     volatile int once;
/*  79 */     static final AtomicIntegerFieldUpdater<ParallelInnerGroup> ONCE = AtomicIntegerFieldUpdater.newUpdater(ParallelInnerGroup.class, "once");
/*     */ 
/*     */     
/*     */     volatile Subscription s;
/*     */     
/*  84 */     static final AtomicReferenceFieldUpdater<ParallelInnerGroup, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ParallelInnerGroup.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/*  89 */     static final AtomicLongFieldUpdater<ParallelInnerGroup> REQUESTED = AtomicLongFieldUpdater.newUpdater(ParallelInnerGroup.class, "requested");
/*     */     
/*     */     CoreSubscriber<? super T> actual;
/*     */     
/*     */     ParallelInnerGroup(int key) {
/*  94 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public Integer key() {
/*  99 */       return Integer.valueOf(this.key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super T> actual) {
/* 104 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 105 */         this.actual = actual;
/* 106 */         actual.onSubscribe(this);
/*     */       } else {
/* 108 */         Operators.error((Subscriber<?>)actual, new IllegalStateException("This ParallelGroup can be subscribed to at most once."));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 114 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 120 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 121 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 122 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 123 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 125 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 130 */       if (Operators.setOnce(S, this, s)) {
/* 131 */         long r = REQUESTED.getAndSet(this, 0L);
/* 132 */         if (r != 0L) {
/* 133 */           s.request(r);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 140 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 145 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 150 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 155 */       if (Operators.validate(n)) {
/* 156 */         Subscription a = this.s;
/* 157 */         if (a == null) {
/* 158 */           Operators.addCap(REQUESTED, this, n);
/*     */           
/* 160 */           a = this.s;
/* 161 */           if (a != null) {
/* 162 */             long r = REQUESTED.getAndSet(this, 0L);
/* 163 */             if (r != 0L) {
/* 164 */               a.request(n);
/*     */             }
/*     */           } 
/*     */         } else {
/* 168 */           a.request(n);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 175 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */