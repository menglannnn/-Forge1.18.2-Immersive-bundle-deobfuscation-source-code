/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Stream;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class FluxFlatMap<T, R>
/*      */   extends InternalFluxOperator<T, R>
/*      */ {
/*      */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*      */   final boolean delayError;
/*      */   final int maxConcurrency;
/*      */   final Supplier<? extends Queue<R>> mainQueueSupplier;
/*      */   final int prefetch;
/*      */   final Supplier<? extends Queue<R>> innerQueueSupplier;
/*      */   
/*      */   FluxFlatMap(Flux<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency, Supplier<? extends Queue<R>> mainQueueSupplier, int prefetch, Supplier<? extends Queue<R>> innerQueueSupplier) {
/*   69 */     super(source);
/*   70 */     if (prefetch <= 0) {
/*   71 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*      */     }
/*   73 */     if (maxConcurrency <= 0) {
/*   74 */       throw new IllegalArgumentException("maxConcurrency > 0 required but it was " + maxConcurrency);
/*      */     }
/*   76 */     this.mapper = Objects.<Function<? super T, ? extends Publisher<? extends R>>>requireNonNull(mapper, "mapper");
/*   77 */     this.delayError = delayError;
/*   78 */     this.prefetch = prefetch;
/*   79 */     this.maxConcurrency = maxConcurrency;
/*   80 */     this
/*   81 */       .mainQueueSupplier = Objects.<Supplier<? extends Queue<R>>>requireNonNull(mainQueueSupplier, "mainQueueSupplier");
/*   82 */     this
/*   83 */       .innerQueueSupplier = Objects.<Supplier<? extends Queue<R>>>requireNonNull(innerQueueSupplier, "innerQueueSupplier");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPrefetch() {
/*   88 */     return this.prefetch;
/*      */   }
/*      */ 
/*      */   
/*      */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*   93 */     if (trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, this.mapper, false, true)) {
/*   94 */       return null;
/*      */     }
/*      */     
/*   97 */     return new FlatMapMain<>(actual, this.mapper, this.delayError, this.maxConcurrency, this.mainQueueSupplier, this.prefetch, this.innerQueueSupplier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, R> boolean trySubscribeScalarMap(Publisher<? extends T> source, CoreSubscriber<? super R> s, Function<? super T, ? extends Publisher<? extends R>> mapper, boolean fuseableExpected, boolean errorContinueExpected) {
/*  123 */     if (source instanceof Callable) {
/*      */       T t;
/*      */       Publisher<? extends R> p;
/*      */       try {
/*  127 */         t = ((Callable)source).call();
/*      */       }
/*  129 */       catch (Throwable e) {
/*  130 */         Context ctx = s.currentContext();
/*      */ 
/*      */         
/*  133 */         Throwable e_ = errorContinueExpected ? Operators.onNextError(null, e, ctx) : Operators.onOperatorError(e, ctx);
/*  134 */         if (e_ != null) {
/*  135 */           Operators.error((Subscriber<?>)s, e_);
/*      */         }
/*      */         else {
/*      */           
/*  139 */           Operators.complete((Subscriber<?>)s);
/*      */         } 
/*  141 */         return true;
/*      */       } 
/*      */       
/*  144 */       if (t == null) {
/*  145 */         Operators.complete((Subscriber<?>)s);
/*  146 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  152 */         p = Objects.<Publisher<? extends R>>requireNonNull(mapper.apply(t), "The mapper returned a null Publisher");
/*      */       
/*      */       }
/*  155 */       catch (Throwable e) {
/*  156 */         Context ctx = s.currentContext();
/*      */ 
/*      */         
/*  159 */         Throwable e_ = errorContinueExpected ? Operators.<T>onNextError(t, e, ctx) : Operators.onOperatorError(null, e, t, ctx);
/*  160 */         if (e_ != null) {
/*  161 */           Operators.error((Subscriber<?>)s, e_);
/*      */         }
/*      */         else {
/*      */           
/*  165 */           Operators.complete((Subscriber<?>)s);
/*      */         } 
/*  167 */         return true;
/*      */       } 
/*      */       
/*  170 */       if (p instanceof Callable) {
/*      */         R v;
/*      */         
/*      */         try {
/*  174 */           v = ((Callable)p).call();
/*      */         }
/*  176 */         catch (Throwable e) {
/*  177 */           Context ctx = s.currentContext();
/*      */ 
/*      */           
/*  180 */           Throwable e_ = errorContinueExpected ? Operators.<T>onNextError(t, e, ctx) : Operators.onOperatorError(null, e, t, ctx);
/*  181 */           if (e_ != null) {
/*  182 */             Operators.error((Subscriber<?>)s, e_);
/*      */           }
/*      */           else {
/*      */             
/*  186 */             Operators.complete((Subscriber<?>)s);
/*      */           } 
/*  188 */           return true;
/*      */         } 
/*      */         
/*  191 */         if (v != null) {
/*  192 */           s.onSubscribe(Operators.scalarSubscription(s, v));
/*      */         } else {
/*      */           
/*  195 */           Operators.complete((Subscriber<?>)s);
/*      */         }
/*      */       
/*      */       }
/*  199 */       else if (!fuseableExpected || p instanceof Fuseable) {
/*  200 */         p.subscribe((Subscriber)s);
/*      */       } else {
/*      */         
/*  203 */         p.subscribe((Subscriber)new FluxHide.SuppressFuseableSubscriber<>(s));
/*      */       } 
/*      */ 
/*      */       
/*  207 */       return true;
/*      */     } 
/*      */     
/*  210 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/*  215 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  216 */     return super.scanUnsafe(key);
/*      */   }
/*      */ 
/*      */   
/*      */   static final class FlatMapMain<T, R>
/*      */     extends FlatMapTracker<FlatMapInner<R>>
/*      */     implements InnerOperator<T, R>
/*      */   {
/*      */     final boolean delayError;
/*      */     
/*      */     final int maxConcurrency;
/*      */     
/*      */     final int prefetch;
/*      */     final int limit;
/*      */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*      */     final Supplier<? extends Queue<R>> mainQueueSupplier;
/*      */     final Supplier<? extends Queue<R>> innerQueueSupplier;
/*      */     final CoreSubscriber<? super R> actual;
/*      */     volatile Queue<R> scalarQueue;
/*      */     volatile Throwable error;
/*  236 */     static final AtomicReferenceFieldUpdater<FlatMapMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(FlatMapMain.class, Throwable.class, "error");
/*      */ 
/*      */     
/*      */     volatile boolean done;
/*      */ 
/*      */     
/*      */     volatile boolean cancelled;
/*      */ 
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     volatile long requested;
/*      */     
/*  249 */     static final AtomicLongFieldUpdater<FlatMapMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(FlatMapMain.class, "requested");
/*      */ 
/*      */     
/*      */     volatile int wip;
/*      */     
/*  254 */     static final AtomicIntegerFieldUpdater<FlatMapMain> WIP = AtomicIntegerFieldUpdater.newUpdater(FlatMapMain.class, "wip");
/*      */ 
/*      */     
/*  257 */     static final FluxFlatMap.FlatMapInner[] EMPTY = new FluxFlatMap.FlatMapInner[0];
/*      */ 
/*      */     
/*  260 */     static final FluxFlatMap.FlatMapInner[] TERMINATED = new FluxFlatMap.FlatMapInner[0];
/*      */ 
/*      */ 
/*      */     
/*      */     int lastIndex;
/*      */ 
/*      */ 
/*      */     
/*      */     int produced;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     FlatMapMain(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency, Supplier<? extends Queue<R>> mainQueueSupplier, int prefetch, Supplier<? extends Queue<R>> innerQueueSupplier) {
/*  274 */       this.actual = actual;
/*  275 */       this.mapper = mapper;
/*  276 */       this.delayError = delayError;
/*  277 */       this.maxConcurrency = maxConcurrency;
/*  278 */       this.mainQueueSupplier = mainQueueSupplier;
/*  279 */       this.prefetch = prefetch;
/*  280 */       this.innerQueueSupplier = innerQueueSupplier;
/*  281 */       this.limit = Operators.unboundedOrLimit(maxConcurrency);
/*      */     }
/*      */ 
/*      */     
/*      */     public final CoreSubscriber<? super R> actual() {
/*  286 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<? extends Scannable> inners() {
/*  291 */       return Stream.<Scannable>of((Scannable[])this.array).filter(Objects::nonNull);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  297 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  298 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/*  299 */       if (key == Scannable.Attr.ERROR) return this.error; 
/*  300 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && (this.scalarQueue == null || this.scalarQueue.isEmpty()))); 
/*  301 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/*  302 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.maxConcurrency); 
/*  303 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/*  304 */       if (key == Scannable.Attr.LARGE_BUFFERED) return Long.valueOf(((this.scalarQueue != null) ? this.scalarQueue.size() : 0L) + this.size); 
/*  305 */       if (key == Scannable.Attr.BUFFERED) {
/*  306 */         long realBuffered = ((this.scalarQueue != null) ? this.scalarQueue.size() : 0L) + this.size;
/*  307 */         if (realBuffered <= 2147483647L) return Integer.valueOf((int)realBuffered); 
/*  308 */         return Integer.valueOf(-2147483648);
/*      */       } 
/*  310 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/*  312 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     FluxFlatMap.FlatMapInner<R>[] empty() {
/*  318 */       return (FluxFlatMap.FlatMapInner<R>[])EMPTY;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     FluxFlatMap.FlatMapInner<R>[] terminated() {
/*  324 */       return (FluxFlatMap.FlatMapInner<R>[])TERMINATED;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     FluxFlatMap.FlatMapInner<R>[] newArray(int size) {
/*  330 */       return (FluxFlatMap.FlatMapInner<R>[])new FluxFlatMap.FlatMapInner[size];
/*      */     }
/*      */ 
/*      */     
/*      */     void setIndex(FluxFlatMap.FlatMapInner<R> entry, int index) {
/*  335 */       entry.index = index;
/*      */     }
/*      */ 
/*      */     
/*      */     void unsubscribeEntry(FluxFlatMap.FlatMapInner<R> entry) {
/*  340 */       entry.cancel();
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/*  345 */       if (Operators.validate(n)) {
/*  346 */         Operators.addCap(REQUESTED, this, n);
/*  347 */         drain((R)null);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  353 */       if (!this.cancelled) {
/*  354 */         this.cancelled = true;
/*      */         
/*  356 */         if (WIP.getAndIncrement(this) == 0) {
/*  357 */           Operators.onDiscardQueueWithClear(this.scalarQueue, this.actual.currentContext(), null);
/*  358 */           this.scalarQueue = null;
/*  359 */           this.s.cancel();
/*  360 */           unsubscribe();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  367 */       if (Operators.validate(this.s, s)) {
/*  368 */         this.s = s;
/*      */         
/*  370 */         this.actual.onSubscribe(this);
/*  371 */         s.request(Operators.unboundedOrPrefetch(this.maxConcurrency));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/*      */       Publisher<? extends R> p;
/*  378 */       if (this.done) {
/*  379 */         Operators.onNextDropped(t, this.actual.currentContext());
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*      */       try {
/*  386 */         p = Objects.<Publisher<? extends R>>requireNonNull(this.mapper.apply(t), "The mapper returned a null Publisher");
/*      */       
/*      */       }
/*  389 */       catch (Throwable e) {
/*  390 */         Context ctx = this.actual.currentContext();
/*  391 */         Throwable e_ = Operators.onNextError(t, e, ctx, this.s);
/*  392 */         Operators.onDiscard(t, ctx);
/*  393 */         if (e_ != null) {
/*  394 */           onError(e_);
/*      */         } else {
/*      */           
/*  397 */           tryEmitScalar((R)null);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  402 */       if (p instanceof Callable) {
/*      */         R v;
/*      */         try {
/*  405 */           v = ((Callable)p).call();
/*      */         }
/*  407 */         catch (Throwable e) {
/*  408 */           Context ctx = this.actual.currentContext();
/*      */           
/*  410 */           Throwable e_ = Operators.onNextError(t, e, ctx);
/*  411 */           if (e_ == null) {
/*  412 */             tryEmitScalar((R)null);
/*      */           }
/*  414 */           else if (!this.delayError || !Exceptions.addThrowable(ERROR, this, e_)) {
/*      */             
/*  416 */             onError(Operators.onOperatorError(this.s, e_, t, ctx));
/*      */           } 
/*  418 */           Operators.onDiscard(t, ctx);
/*  419 */           tryEmitScalar((R)null);
/*      */           return;
/*      */         } 
/*  422 */         tryEmitScalar(v);
/*      */       } else {
/*      */         
/*  425 */         FluxFlatMap.FlatMapInner<R> inner = new FluxFlatMap.FlatMapInner<>(this, this.prefetch);
/*  426 */         if (add(inner)) {
/*  427 */           p.subscribe((Subscriber)inner);
/*      */         } else {
/*  429 */           Operators.onDiscard(t, this.actual.currentContext());
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     Queue<R> getOrCreateScalarQueue() {
/*  436 */       Queue<R> q = this.scalarQueue;
/*  437 */       if (q == null) {
/*  438 */         q = this.mainQueueSupplier.get();
/*  439 */         this.scalarQueue = q;
/*      */       } 
/*  441 */       return q;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  446 */       if (this.done) {
/*  447 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*      */         return;
/*      */       } 
/*  450 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/*  451 */         this.done = true;
/*  452 */         drain((R)null);
/*      */       } else {
/*      */         
/*  455 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  461 */       if (this.done) {
/*      */         return;
/*      */       }
/*      */       
/*  465 */       this.done = true;
/*  466 */       drain((R)null);
/*      */     }
/*      */     
/*      */     void tryEmitScalar(@Nullable R v) {
/*  470 */       if (v == null) {
/*  471 */         if (this.maxConcurrency != Integer.MAX_VALUE) {
/*  472 */           int p = this.produced + 1;
/*  473 */           if (p == this.limit) {
/*  474 */             this.produced = 0;
/*  475 */             this.s.request(p);
/*      */           } else {
/*      */             
/*  478 */             this.produced = p;
/*      */           } 
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*  484 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/*  485 */         long r = this.requested;
/*      */         
/*  487 */         Queue<R> q = this.scalarQueue;
/*  488 */         if (r != 0L && (q == null || q.isEmpty())) {
/*  489 */           this.actual.onNext(v);
/*      */           
/*  491 */           if (r != Long.MAX_VALUE) {
/*  492 */             REQUESTED.decrementAndGet(this);
/*      */           }
/*      */           
/*  495 */           if (this.maxConcurrency != Integer.MAX_VALUE) {
/*  496 */             int p = this.produced + 1;
/*  497 */             if (p == this.limit) {
/*  498 */               this.produced = 0;
/*  499 */               this.s.request(p);
/*      */             } else {
/*      */               
/*  502 */               this.produced = p;
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  507 */           if (q == null) {
/*  508 */             q = getOrCreateScalarQueue();
/*      */           }
/*      */           
/*  511 */           if (!q.offer(v) && failOverflow(v, this.s)) {
/*  512 */             this.done = true;
/*  513 */             drainLoop();
/*      */             return;
/*      */           } 
/*      */         } 
/*  517 */         if (WIP.decrementAndGet(this) == 0) {
/*  518 */           if (this.cancelled) {
/*  519 */             Operators.onDiscard(v, this.actual.currentContext());
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*  524 */         drainLoop();
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  529 */         Queue<R> q = getOrCreateScalarQueue();
/*      */         
/*  531 */         if (!q.offer(v) && failOverflow(v, this.s)) {
/*  532 */           this.done = true;
/*      */         }
/*  534 */         drain(v);
/*      */       } 
/*      */     }
/*      */     
/*      */     void tryEmit(FluxFlatMap.FlatMapInner<R> inner, R v) {
/*  539 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/*  540 */         long r = this.requested;
/*      */         
/*  542 */         Queue<R> q = inner.queue;
/*  543 */         if (r != 0L && (q == null || q.isEmpty())) {
/*  544 */           this.actual.onNext(v);
/*      */           
/*  546 */           if (r != Long.MAX_VALUE) {
/*  547 */             REQUESTED.decrementAndGet(this);
/*      */           }
/*      */           
/*  550 */           inner.request(1L);
/*      */         } else {
/*      */           
/*  553 */           if (q == null) {
/*  554 */             q = getOrCreateInnerQueue(inner);
/*      */           }
/*      */           
/*  557 */           if (!q.offer(v) && failOverflow(v, inner)) {
/*  558 */             inner.done = true;
/*  559 */             drainLoop();
/*      */             return;
/*      */           } 
/*      */         } 
/*  563 */         if (WIP.decrementAndGet(this) == 0) {
/*  564 */           if (this.cancelled) {
/*  565 */             Operators.onDiscard(v, this.actual.currentContext());
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*  570 */         drainLoop();
/*      */       } else {
/*      */         
/*  573 */         Queue<R> q = getOrCreateInnerQueue(inner);
/*      */         
/*  575 */         if (!q.offer(v) && failOverflow(v, inner)) {
/*  576 */           inner.done = true;
/*      */         }
/*  578 */         drain(v);
/*      */       } 
/*      */     }
/*      */     
/*      */     void drain(@Nullable R dataSignal) {
/*  583 */       if (WIP.getAndIncrement(this) != 0) {
/*  584 */         if (dataSignal != null && this.cancelled) {
/*  585 */           Operators.onDiscard(dataSignal, this.actual.currentContext());
/*      */         }
/*      */         return;
/*      */       } 
/*  589 */       drainLoop();
/*      */     }
/*      */     
/*      */     void drainLoop() {
/*  593 */       int missed = 1;
/*      */       
/*  595 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/*      */ 
/*      */       
/*      */       while (true) {
/*  599 */         boolean d = this.done;
/*      */         
/*  601 */         FluxFlatMap.FlatMapInner[] arrayOfFlatMapInner = (FluxFlatMap.FlatMapInner[])get();
/*      */         
/*  603 */         int n = arrayOfFlatMapInner.length;
/*      */         
/*  605 */         Queue<R> sq = this.scalarQueue;
/*      */         
/*  607 */         boolean noSources = isEmpty();
/*      */         
/*  609 */         if (checkTerminated(d, (noSources && (sq == null || sq.isEmpty())), (Subscriber<?>)coreSubscriber, (R)null)) {
/*      */           return;
/*      */         }
/*      */         
/*  613 */         boolean again = false;
/*      */         
/*  615 */         long r = this.requested;
/*  616 */         long e = 0L;
/*  617 */         long replenishMain = 0L;
/*      */         
/*  619 */         if (r != 0L && sq != null) {
/*      */           
/*  621 */           while (e != r) {
/*  622 */             d = this.done;
/*      */             
/*  624 */             R v = sq.poll();
/*      */             
/*  626 */             boolean empty = (v == null);
/*      */             
/*  628 */             if (checkTerminated(d, false, (Subscriber<?>)coreSubscriber, v)) {
/*      */               return;
/*      */             }
/*      */             
/*  632 */             if (empty) {
/*      */               break;
/*      */             }
/*      */             
/*  636 */             coreSubscriber.onNext(v);
/*      */             
/*  638 */             e++;
/*      */           } 
/*      */           
/*  641 */           if (e != 0L) {
/*  642 */             replenishMain += e;
/*  643 */             if (r != Long.MAX_VALUE) {
/*  644 */               r = REQUESTED.addAndGet(this, -e);
/*      */             }
/*  646 */             e = 0L;
/*  647 */             again = true;
/*      */           } 
/*      */         } 
/*  650 */         if (r != 0L && !noSources) {
/*      */           
/*  652 */           int j = this.lastIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  658 */           for (int i = 0; i < n; i++) {
/*  659 */             if (this.cancelled) {
/*  660 */               Operators.onDiscardQueueWithClear(this.scalarQueue, this.actual.currentContext(), null);
/*  661 */               this.scalarQueue = null;
/*  662 */               this.s.cancel();
/*  663 */               unsubscribe();
/*      */               
/*      */               return;
/*      */             } 
/*  667 */             FluxFlatMap.FlatMapInner<R> inner = arrayOfFlatMapInner[j];
/*  668 */             if (inner != null) {
/*  669 */               d = inner.done;
/*  670 */               Queue<R> q = inner.queue;
/*  671 */               if (d && q == null) {
/*  672 */                 remove(inner.index);
/*  673 */                 again = true;
/*  674 */                 replenishMain++;
/*      */               }
/*  676 */               else if (q != null) {
/*  677 */                 while (e != r) {
/*  678 */                   R v; d = inner.done;
/*      */ 
/*      */ 
/*      */                   
/*      */                   try {
/*  683 */                     v = q.poll();
/*      */                   }
/*  685 */                   catch (Throwable ex) {
/*  686 */                     ex = Operators.onOperatorError(inner, ex, this.actual
/*  687 */                         .currentContext());
/*  688 */                     if (!Exceptions.addThrowable(ERROR, this, ex)) {
/*  689 */                       Operators.onErrorDropped(ex, this.actual
/*  690 */                           .currentContext());
/*      */                     }
/*  692 */                     v = null;
/*  693 */                     d = true;
/*      */                   } 
/*      */                   
/*  696 */                   boolean empty = (v == null);
/*      */                   
/*  698 */                   if (checkTerminated(d, false, (Subscriber<?>)coreSubscriber, v)) {
/*      */                     return;
/*      */                   }
/*      */                   
/*  702 */                   if (d && empty) {
/*  703 */                     remove(inner.index);
/*  704 */                     again = true;
/*  705 */                     replenishMain++;
/*      */                     
/*      */                     break;
/*      */                   } 
/*  709 */                   if (empty) {
/*      */                     break;
/*      */                   }
/*      */                   
/*  713 */                   coreSubscriber.onNext(v);
/*      */                   
/*  715 */                   e++;
/*      */                 } 
/*      */                 
/*  718 */                 if (e == r) {
/*  719 */                   d = inner.done;
/*  720 */                   boolean empty = q.isEmpty();
/*  721 */                   if (d && empty) {
/*  722 */                     remove(inner.index);
/*  723 */                     again = true;
/*  724 */                     replenishMain++;
/*      */                   } 
/*      */                 } 
/*      */                 
/*  728 */                 if (e != 0L) {
/*  729 */                   if (!inner.done) {
/*  730 */                     inner.request(e);
/*      */                   }
/*  732 */                   if (r != Long.MAX_VALUE) {
/*  733 */                     r = REQUESTED.addAndGet(this, -e);
/*  734 */                     if (r == 0L) {
/*      */                       break;
/*      */                     }
/*      */                   } 
/*  738 */                   e = 0L;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  743 */             if (r == 0L) {
/*      */               break;
/*      */             }
/*      */             
/*  747 */             if (++j == n) {
/*  748 */               j = 0;
/*      */             }
/*      */           } 
/*      */           
/*  752 */           this.lastIndex = j;
/*      */         } 
/*      */         
/*  755 */         if (r == 0L && !noSources) {
/*  756 */           arrayOfFlatMapInner = (FluxFlatMap.FlatMapInner[])get();
/*  757 */           n = arrayOfFlatMapInner.length;
/*      */           
/*  759 */           for (int i = 0; i < n; i++) {
/*  760 */             if (this.cancelled) {
/*  761 */               Operators.onDiscardQueueWithClear(this.scalarQueue, this.actual.currentContext(), null);
/*  762 */               this.scalarQueue = null;
/*  763 */               this.s.cancel();
/*  764 */               unsubscribe();
/*      */               
/*      */               return;
/*      */             } 
/*  768 */             FluxFlatMap.FlatMapInner<R> inner = arrayOfFlatMapInner[i];
/*  769 */             if (inner != null) {
/*      */ 
/*      */ 
/*      */               
/*  773 */               d = inner.done;
/*  774 */               Queue<R> q = inner.queue;
/*  775 */               boolean empty = (q == null || q.isEmpty());
/*      */ 
/*      */               
/*  778 */               if (!empty) {
/*      */                 break;
/*      */               }
/*      */               
/*  782 */               if (d && empty) {
/*  783 */                 remove(inner.index);
/*  784 */                 again = true;
/*  785 */                 replenishMain++;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*  790 */         if (replenishMain != 0L && !this.done && !this.cancelled) {
/*  791 */           this.s.request(replenishMain);
/*      */         }
/*      */         
/*  794 */         if (again) {
/*      */           continue;
/*      */         }
/*      */         
/*  798 */         missed = WIP.addAndGet(this, -missed);
/*  799 */         if (missed == 0) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, @Nullable R value) {
/*  806 */       if (this.cancelled) {
/*  807 */         Context ctx = this.actual.currentContext();
/*  808 */         Operators.onDiscard(value, ctx);
/*  809 */         Operators.onDiscardQueueWithClear(this.scalarQueue, ctx, null);
/*  810 */         this.scalarQueue = null;
/*  811 */         this.s.cancel();
/*  812 */         unsubscribe();
/*      */         
/*  814 */         return true;
/*      */       } 
/*      */       
/*  817 */       if (this.delayError) {
/*  818 */         if (d && empty) {
/*  819 */           Throwable e = this.error;
/*  820 */           if (e != null && e != Exceptions.TERMINATED) {
/*  821 */             e = Exceptions.terminate(ERROR, this);
/*  822 */             a.onError(e);
/*      */           } else {
/*      */             
/*  825 */             a.onComplete();
/*      */           } 
/*      */           
/*  828 */           return true;
/*      */         }
/*      */       
/*      */       }
/*  832 */       else if (d) {
/*  833 */         Throwable e = this.error;
/*  834 */         if (e != null && e != Exceptions.TERMINATED) {
/*  835 */           e = Exceptions.terminate(ERROR, this);
/*  836 */           Context ctx = this.actual.currentContext();
/*  837 */           Operators.onDiscard(value, ctx);
/*  838 */           Operators.onDiscardQueueWithClear(this.scalarQueue, ctx, null);
/*  839 */           this.scalarQueue = null;
/*  840 */           this.s.cancel();
/*  841 */           unsubscribe();
/*      */           
/*  843 */           a.onError(e);
/*  844 */           return true;
/*      */         } 
/*  846 */         if (empty) {
/*  847 */           a.onComplete();
/*  848 */           return true;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  853 */       return false;
/*      */     }
/*      */     
/*      */     void innerError(FluxFlatMap.FlatMapInner<R> inner, Throwable e) {
/*  857 */       e = Operators.onNextInnerError(e, currentContext(), this.s);
/*  858 */       if (e != null) {
/*  859 */         if (Exceptions.addThrowable(ERROR, this, e)) {
/*  860 */           if (!this.delayError) {
/*  861 */             this.done = true;
/*      */           }
/*  863 */           inner.done = true;
/*  864 */           drain((R)null);
/*      */         } else {
/*      */           
/*  867 */           inner.done = true;
/*  868 */           Operators.onErrorDropped(e, this.actual.currentContext());
/*      */         } 
/*      */       } else {
/*      */         
/*  872 */         inner.done = true;
/*  873 */         drain((R)null);
/*      */       } 
/*      */     }
/*      */     
/*      */     boolean failOverflow(R v, Subscription toCancel) {
/*  878 */       Throwable e = Operators.onOperatorError(toCancel, 
/*  879 */           Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), v, this.actual
/*  880 */           .currentContext());
/*      */       
/*  882 */       Operators.onDiscard(v, this.actual.currentContext());
/*      */       
/*  884 */       if (!Exceptions.addThrowable(ERROR, this, e)) {
/*  885 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*  886 */         return false;
/*      */       } 
/*  888 */       return true;
/*      */     }
/*      */     
/*      */     void innerComplete(FluxFlatMap.FlatMapInner<R> inner) {
/*  892 */       if (WIP.getAndIncrement(this) != 0) {
/*      */         return;
/*      */       }
/*  895 */       drainLoop();
/*      */     }
/*      */     
/*      */     Queue<R> getOrCreateInnerQueue(FluxFlatMap.FlatMapInner<R> inner) {
/*  899 */       Queue<R> q = inner.queue;
/*  900 */       if (q == null) {
/*  901 */         q = this.innerQueueSupplier.get();
/*  902 */         inner.queue = q;
/*      */       } 
/*  904 */       return q;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class FlatMapInner<R>
/*      */     implements InnerConsumer<R>, Subscription
/*      */   {
/*      */     final FluxFlatMap.FlatMapMain<?, R> parent;
/*      */     
/*      */     final int prefetch;
/*      */     
/*      */     final int limit;
/*      */     
/*      */     volatile Subscription s;
/*      */     
/*  921 */     static final AtomicReferenceFieldUpdater<FlatMapInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(FlatMapInner.class, Subscription.class, "s");
/*      */ 
/*      */     
/*      */     long produced;
/*      */ 
/*      */     
/*      */     volatile Queue<R> queue;
/*      */ 
/*      */     
/*      */     volatile boolean done;
/*      */ 
/*      */     
/*      */     int sourceMode;
/*      */     
/*      */     int index;
/*      */ 
/*      */     
/*      */     FlatMapInner(FluxFlatMap.FlatMapMain<?, R> parent, int prefetch) {
/*  939 */       this.parent = parent;
/*  940 */       this.prefetch = prefetch;
/*      */       
/*  942 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  947 */       if (Operators.setOnce(S, this, s)) {
/*  948 */         if (s instanceof Fuseable.QueueSubscription) {
/*  949 */           Fuseable.QueueSubscription<R> f = (Fuseable.QueueSubscription<R>)s;
/*      */           
/*  951 */           int m = f.requestFusion(7);
/*  952 */           if (m == 1) {
/*  953 */             this.sourceMode = 1;
/*  954 */             this.queue = (Queue<R>)f;
/*  955 */             this.done = true;
/*  956 */             this.parent.drain((R)null);
/*      */             return;
/*      */           } 
/*  959 */           if (m == 2) {
/*  960 */             this.sourceMode = 2;
/*  961 */             this.queue = (Queue<R>)f;
/*      */           } 
/*      */         } 
/*      */         
/*  965 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(R t) {
/*  971 */       if (this.sourceMode == 2) {
/*  972 */         this.parent.drain(t);
/*      */       } else {
/*      */         
/*  975 */         if (this.done) {
/*  976 */           Operators.onNextDropped(t, this.parent.currentContext());
/*      */           
/*      */           return;
/*      */         } 
/*  980 */         if (this.s == Operators.cancelledSubscription()) {
/*  981 */           Operators.onDiscard(t, this.parent.currentContext());
/*      */           
/*      */           return;
/*      */         } 
/*  985 */         this.parent.tryEmit(this, t);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  991 */       this.parent.innerError(this, t);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  997 */       this.done = true;
/*  998 */       this.parent.innerComplete(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 1003 */       if (this.sourceMode == 1) {
/*      */         return;
/*      */       }
/* 1006 */       long p = this.produced + n;
/* 1007 */       if (p >= this.limit) {
/* 1008 */         this.produced = 0L;
/* 1009 */         this.s.request(p);
/*      */       } else {
/*      */         
/* 1012 */         this.produced = p;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 1018 */       return this.parent.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 1023 */       Operators.terminate(S, this);
/* 1024 */       Operators.onDiscardQueueWithClear(this.queue, this.parent.currentContext(), null);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1030 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 1031 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 1032 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && (this.queue == null || this.queue.isEmpty()))); 
/* 1033 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 1034 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue == null) ? 0 : this.queue.size()); 
/* 1035 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 1036 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/* 1038 */       return null;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxFlatMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */