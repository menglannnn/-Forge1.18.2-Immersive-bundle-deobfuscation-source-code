/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxLift<I, O>
/*    */   extends InternalFluxOperator<I, O>
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   
/*    */   FluxLift(Publisher<I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 34 */     super(Flux.from(p));
/* 35 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 40 */     if (this.source instanceof Scannable) {
/* 41 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 43 */     return super.stepName();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 48 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 49 */     if (key == Scannable.Attr.LIFTER) return this.liftFunction.name; 
/* 50 */     return super.scanUnsafe(key);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/* 56 */     CoreSubscriber<? super I> input = this.liftFunction.lifter.apply(this.source, actual);
/*    */     
/* 58 */     Objects.requireNonNull(input, "Lifted subscriber MUST NOT be null");
/*    */     
/* 60 */     return input;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxLift.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */