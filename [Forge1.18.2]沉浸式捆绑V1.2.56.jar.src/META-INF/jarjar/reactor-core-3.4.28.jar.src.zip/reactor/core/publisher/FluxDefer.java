/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Supplier;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxDefer<T>
/*    */   extends Flux<T>
/*    */   implements SourceProducer<T>
/*    */ {
/*    */   final Supplier<? extends Publisher<? extends T>> supplier;
/*    */   
/*    */   FluxDefer(Supplier<? extends Publisher<? extends T>> supplier) {
/* 37 */     this.supplier = Objects.<Supplier<? extends Publisher<? extends T>>>requireNonNull(supplier, "supplier");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/*    */     Publisher<? extends T> p;
/*    */     try {
/* 46 */       p = Objects.<Publisher<? extends T>>requireNonNull(this.supplier.get(), "The Publisher returned by the supplier is null");
/*    */     
/*    */     }
/* 49 */     catch (Throwable e) {
/* 50 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*    */       
/*    */       return;
/*    */     } 
/* 54 */     from(p).subscribe(actual);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 60 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 61 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxDefer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */