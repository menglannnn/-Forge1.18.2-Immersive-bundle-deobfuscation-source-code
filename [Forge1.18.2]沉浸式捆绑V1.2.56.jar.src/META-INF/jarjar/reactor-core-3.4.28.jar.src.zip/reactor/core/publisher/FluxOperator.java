/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FluxOperator<I, O>
/*    */   extends Flux<O>
/*    */   implements Scannable
/*    */ {
/*    */   protected final Flux<? extends I> source;
/*    */   
/*    */   protected FluxOperator(Flux<? extends I> source) {
/* 45 */     this.source = Objects.<Flux<? extends I>>requireNonNull(source);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 51 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 52 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */