/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelLiftFuseable<I, O>
/*     */   extends ParallelFlux<O>
/*     */   implements Scannable, Fuseable
/*     */ {
/*     */   final Operators.LiftFunction<I, O> liftFunction;
/*     */   final ParallelFlux<I> source;
/*     */   
/*     */   ParallelLiftFuseable(ParallelFlux<I> p, Operators.LiftFunction<I, O> liftFunction) {
/*  39 */     this.source = Objects.<ParallelFlux<I>>requireNonNull(p, "source");
/*  40 */     this.liftFunction = liftFunction;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  45 */     return this.source.getPrefetch();
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/*  50 */     return this.source.parallelism();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  56 */     if (key == Scannable.Attr.PARENT) {
/*  57 */       return this.source;
/*     */     }
/*  59 */     if (key == Scannable.Attr.PREFETCH) {
/*  60 */       return Integer.valueOf(getPrefetch());
/*     */     }
/*  62 */     if (key == Scannable.Attr.RUN_STYLE) {
/*  63 */       return Scannable.from(this.source).scanUnsafe(key);
/*     */     }
/*  65 */     if (key == Scannable.Attr.LIFTER) {
/*  66 */       return this.liftFunction.name;
/*     */     }
/*     */     
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String stepName() {
/*  74 */     if (this.source instanceof Scannable) {
/*  75 */       return Scannable.from(this.source).stepName();
/*     */     }
/*  77 */     return super.stepName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super O>[] s) {
/*  83 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[parallelism()];
/*     */     
/*  85 */     int i = 0;
/*  86 */     while (i < arrayOfCoreSubscriber.length) {
/*  87 */       CoreSubscriber<? super O> actual = s[i];
/*     */       
/*  89 */       CoreSubscriber<? super I> converted = Objects.<CoreSubscriber<? super I>>requireNonNull(this.liftFunction.lifter.apply(this.source, actual), "Lifted subscriber MUST NOT be null");
/*     */ 
/*     */       
/*  92 */       Objects.requireNonNull(converted, "Lifted subscriber MUST NOT be null");
/*     */       
/*  94 */       if (actual instanceof Fuseable.QueueSubscription && !(converted instanceof Fuseable.QueueSubscription))
/*     */       {
/*     */         
/*  97 */         converted = new FluxHide.SuppressFuseableSubscriber<>(converted);
/*     */       }
/*     */       
/* 100 */       arrayOfCoreSubscriber[i] = converted;
/* 101 */       i++;
/*     */     } 
/*     */     
/* 104 */     this.source.subscribe((CoreSubscriber<? super I>[])arrayOfCoreSubscriber);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelLiftFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */