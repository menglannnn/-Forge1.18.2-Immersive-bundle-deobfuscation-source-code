/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxScanSeed<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final BiFunction<R, ? super T, R> accumulator;
/*     */   final Supplier<R> initialSupplier;
/*     */   
/*     */   FluxScanSeed(Flux<? extends T> source, Supplier<R> initialSupplier, BiFunction<R, ? super T, R> accumulator) {
/*  59 */     super(source);
/*  60 */     this.accumulator = Objects.<BiFunction<R, ? super T, R>>requireNonNull(accumulator, "accumulator");
/*  61 */     this.initialSupplier = Objects.<Supplier<R>>requireNonNull(initialSupplier, "initialSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  66 */     ScanSeedCoordinator<T, R> coordinator = new ScanSeedCoordinator<>(actual, this.source, this.accumulator, this.initialSupplier);
/*     */ 
/*     */     
/*  69 */     actual.onSubscribe(coordinator);
/*     */     
/*  71 */     if (!coordinator.isCancelled()) {
/*  72 */       coordinator.onComplete();
/*     */     }
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  79 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  80 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ScanSeedCoordinator<T, R>
/*     */     extends Operators.MultiSubscriptionSubscriber<R, R>
/*     */   {
/*     */     final Supplier<R> initialSupplier;
/*     */     
/*     */     final Flux<? extends T> source;
/*     */     final BiFunction<R, ? super T, R> accumulator;
/*     */     volatile int wip;
/*     */     long produced;
/*     */     private FluxScanSeed.ScanSeedSubscriber<T, R> seedSubscriber;
/*     */     
/*     */     ScanSeedCoordinator(CoreSubscriber<? super R> actual, Flux<? extends T> source, BiFunction<R, ? super T, R> accumulator, Supplier<R> initialSupplier) {
/*  96 */       super(actual);
/*  97 */       this.source = source;
/*  98 */       this.accumulator = accumulator;
/*  99 */       this.initialSupplier = initialSupplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 104 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         do {
/* 106 */           if (isCancelled()) {
/*     */             return;
/*     */           }
/*     */           
/* 110 */           if (null != this.seedSubscriber && this.subscription == this.seedSubscriber) {
/* 111 */             this.actual.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 115 */           long c = this.produced;
/* 116 */           if (c != 0L) {
/* 117 */             this.produced = 0L;
/* 118 */             produced(c);
/*     */           } 
/*     */           
/* 121 */           if (null == this.seedSubscriber) {
/*     */             R initialValue;
/*     */             
/*     */             try {
/* 125 */               initialValue = Objects.requireNonNull(this.initialSupplier.get(), "The initial value supplied is null");
/*     */             
/*     */             }
/* 128 */             catch (Throwable e) {
/* 129 */               onError(Operators.onOperatorError(e, this.actual.currentContext()));
/*     */               
/*     */               return;
/*     */             } 
/* 133 */             onSubscribe(Operators.scalarSubscription(this, (T)initialValue));
/* 134 */             this.seedSubscriber = new FluxScanSeed.ScanSeedSubscriber<>(this, this.accumulator, initialValue);
/*     */           }
/*     */           else {
/*     */             
/* 138 */             this.source.subscribe(this.seedSubscriber);
/*     */           } 
/*     */           
/* 141 */           if (isCancelled()) {
/*     */             return;
/*     */           }
/*     */         }
/* 145 */         while (WIP.decrementAndGet(this) != 0);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(R r) {
/* 152 */       this.produced++;
/* 153 */       this.actual.onNext(r);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 158 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 159 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 164 */     static final AtomicIntegerFieldUpdater<ScanSeedCoordinator> WIP = AtomicIntegerFieldUpdater.newUpdater(ScanSeedCoordinator.class, "wip");
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ScanSeedSubscriber<T, R>
/*     */     implements InnerOperator<T, R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final BiFunction<R, ? super T, R> accumulator;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     R value;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     ScanSeedSubscriber(CoreSubscriber<? super R> actual, BiFunction<R, ? super T, R> accumulator, R initialValue) {
/* 182 */       this.actual = actual;
/* 183 */       this.accumulator = accumulator;
/* 184 */       this.value = initialValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 189 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 194 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 199 */       if (this.done) {
/*     */         return;
/*     */       }
/* 202 */       this.done = true;
/* 203 */       this.value = null;
/* 204 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 209 */       if (this.done) {
/* 210 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 213 */       this.done = true;
/* 214 */       this.value = null;
/* 215 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 220 */       if (this.done) {
/* 221 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 225 */       R r = this.value;
/*     */       
/*     */       try {
/* 228 */         r = Objects.requireNonNull(this.accumulator.apply(r, t), "The accumulator returned a null value");
/*     */       
/*     */       }
/* 231 */       catch (Throwable e) {
/* 232 */         onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 236 */       this.actual.onNext(r);
/* 237 */       this.value = r;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 242 */       if (Operators.validate(this.s, s)) {
/* 243 */         this.s = s;
/* 244 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 250 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 256 */       if (key == Scannable.Attr.PARENT) {
/* 257 */         return this.s;
/*     */       }
/* 259 */       if (key == Scannable.Attr.TERMINATED) {
/* 260 */         return Boolean.valueOf(this.done);
/*     */       }
/* 262 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 263 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 265 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxScanSeed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */