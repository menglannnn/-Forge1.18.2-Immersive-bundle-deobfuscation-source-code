/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoCallableOnAssembly<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */   implements Callable<T>, AssemblyOp
/*     */ {
/*     */   final FluxOnAssembly.AssemblySnapshot stacktrace;
/*     */   
/*     */   MonoCallableOnAssembly(Mono<? extends T> source, FluxOnAssembly.AssemblySnapshot stacktrace) {
/*  48 */     super(source);
/*  49 */     this.stacktrace = stacktrace;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T block() {
/*  56 */     return block(Duration.ZERO);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T block(Duration timeout) {
/*     */     try {
/*  64 */       return ((Callable)this.source).call();
/*     */     }
/*  66 */     catch (Throwable e) {
/*  67 */       throw Exceptions.propagate(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  74 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*     */       
/*  76 */       Fuseable.ConditionalSubscriber<? super T> cs = (Fuseable.ConditionalSubscriber<? super T>)actual;
/*  77 */       return new FluxOnAssembly.OnAssemblyConditionalSubscriber<>(cs, this.stacktrace, (Publisher<?>)this.source, (Publisher<?>)this);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     return new FluxOnAssembly.OnAssemblySubscriber<>(actual, this.stacktrace, (Publisher<?>)this.source, (Publisher<?>)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T call() throws Exception {
/*  91 */     return ((Callable)this.source).call();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  96 */     if (key == Scannable.Attr.ACTUAL_METADATA) return Boolean.valueOf(!this.stacktrace.isCheckpoint); 
/*  97 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  99 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String stepName() {
/* 104 */     return this.stacktrace.operatorAssemblyInformation();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     return this.stacktrace.operatorAssemblyInformation();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoCallableOnAssembly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */