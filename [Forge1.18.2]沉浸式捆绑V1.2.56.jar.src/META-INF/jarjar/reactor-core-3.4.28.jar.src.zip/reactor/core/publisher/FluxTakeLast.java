/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxTakeLast<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final int n;
/*     */   
/*     */   FluxTakeLast(Flux<? extends T> source, int n) {
/*  39 */     super(source);
/*  40 */     if (n < 0) {
/*  41 */       throw new IllegalArgumentException("n >= required but it was " + n);
/*     */     }
/*  43 */     this.n = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  48 */     if (this.n == 0) {
/*  49 */       return new TakeLastZeroSubscriber<>(actual);
/*     */     }
/*     */     
/*  52 */     return new TakeLastManySubscriber<>(actual, this.n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  58 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  59 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  64 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   static final class TakeLastZeroSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     Subscription s;
/*     */     
/*     */     TakeLastZeroSubscriber(CoreSubscriber<? super T> actual) {
/*  74 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  80 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  81 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  83 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  88 */       if (Operators.validate(this.s, s)) {
/*  89 */         this.s = s;
/*     */         
/*  91 */         this.actual.onSubscribe(this);
/*     */         
/*  93 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 104 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 109 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 114 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 119 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 124 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeLastManySubscriber<T>
/*     */     extends ArrayDeque<T>
/*     */     implements BooleanSupplier, InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final int n;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     volatile long requested;
/* 142 */     static final AtomicLongFieldUpdater<TakeLastManySubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(TakeLastManySubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     TakeLastManySubscriber(CoreSubscriber<? super T> actual, int n) {
/* 146 */       this.actual = actual;
/* 147 */       this.n = n;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getAsBoolean() {
/* 152 */       return this.cancelled;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 157 */       if (Operators.validate(n)) {
/* 158 */         DrainUtils.postCompleteRequest(n, (Subscriber<? super T>)this.actual, this, REQUESTED, this, this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 164 */       this.cancelled = true;
/* 165 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 170 */       if (Operators.validate(this.s, s)) {
/* 171 */         this.s = s;
/*     */         
/* 173 */         this.actual.onSubscribe(this);
/*     */         
/* 175 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 181 */       if (size() == this.n) {
/* 182 */         poll();
/*     */       }
/* 184 */       offer(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 189 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 194 */       DrainUtils.postComplete(this.actual, this, REQUESTED, this, this);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 200 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 201 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 202 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 203 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(size()); 
/* 204 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 206 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 211 */       return this.actual;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxTakeLast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */