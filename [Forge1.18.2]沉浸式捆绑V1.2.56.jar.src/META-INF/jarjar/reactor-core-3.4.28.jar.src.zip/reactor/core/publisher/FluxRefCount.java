/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxRefCount<T>
/*     */   extends Flux<T>
/*     */   implements Scannable, Fuseable
/*     */ {
/*     */   final ConnectableFlux<? extends T> source;
/*     */   final int n;
/*     */   @Nullable
/*     */   RefCountMonitor<T> connection;
/*     */   
/*     */   FluxRefCount(ConnectableFlux<? extends T> source, int n) {
/*  50 */     if (n <= 0) {
/*  51 */       throw new IllegalArgumentException("n > 0 required but it was " + n);
/*     */     }
/*  53 */     this.source = Objects.<ConnectableFlux<? extends T>>requireNonNull(source, "source");
/*  54 */     this.n = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  59 */     return this.source.getPrefetch();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     RefCountMonitor<T> conn;
/*  66 */     boolean connect = false;
/*  67 */     synchronized (this) {
/*  68 */       conn = this.connection;
/*  69 */       if (conn == null || conn.terminated) {
/*  70 */         conn = new RefCountMonitor<>(this);
/*  71 */         this.connection = conn;
/*     */       } 
/*     */       
/*  74 */       long c = conn.subscribers;
/*  75 */       conn.subscribers = c + 1L;
/*  76 */       if (!conn.connected && c + 1L == this.n) {
/*  77 */         connect = true;
/*  78 */         conn.connected = true;
/*     */       } 
/*     */     } 
/*     */     
/*  82 */     this.source.subscribe(new RefCountInner<>(actual, conn));
/*     */     
/*  84 */     if (connect) {
/*  85 */       this.source.connect(conn);
/*     */     }
/*     */   }
/*     */   
/*     */   void cancel(RefCountMonitor<T> rc) {
/*  90 */     Disposable dispose = null;
/*  91 */     synchronized (this) {
/*  92 */       if (rc.terminated) {
/*     */         return;
/*     */       }
/*  95 */       long c = rc.subscribers - 1L;
/*  96 */       rc.subscribers = c;
/*  97 */       if (c != 0L || !rc.connected) {
/*     */         return;
/*     */       }
/* 100 */       if (rc == this.connection) {
/* 101 */         dispose = RefCountMonitor.DISCONNECT.getAndSet(rc, Disposables.disposed());
/* 102 */         this.connection = null;
/*     */       } 
/*     */     } 
/* 105 */     if (dispose != null) {
/* 106 */       dispose.dispose();
/*     */     }
/*     */   }
/*     */   
/*     */   void terminated(RefCountMonitor rc) {
/* 111 */     synchronized (this) {
/* 112 */       if (!rc.terminated) {
/* 113 */         rc.terminated = true;
/* 114 */         this.connection = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 122 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 123 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 124 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RefCountMonitor<T>
/*     */     implements Consumer<Disposable>
/*     */   {
/*     */     final FluxRefCount<? extends T> parent;
/*     */     
/*     */     long subscribers;
/*     */     
/*     */     boolean terminated;
/*     */     
/*     */     boolean connected;
/*     */     volatile Disposable disconnect;
/* 141 */     static final AtomicReferenceFieldUpdater<RefCountMonitor, Disposable> DISCONNECT = AtomicReferenceFieldUpdater.newUpdater(RefCountMonitor.class, Disposable.class, "disconnect");
/*     */     
/*     */     RefCountMonitor(FluxRefCount<? extends T> parent) {
/* 144 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Disposable r) {
/* 149 */       OperatorDisposables.replace(DISCONNECT, this, r);
/*     */     }
/*     */     
/*     */     void innerCancelled() {
/* 153 */       this.parent.cancel(this);
/*     */     }
/*     */     
/*     */     void upstreamFinished() {
/* 157 */       this.parent.terminated(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RefCountInner<T>
/*     */     implements Fuseable.QueueSubscription<T>, InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final FluxRefCount.RefCountMonitor<T> connection;
/*     */     
/*     */     Subscription s;
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     volatile int parentDone;
/* 172 */     static final AtomicIntegerFieldUpdater<RefCountInner> PARENT_DONE = AtomicIntegerFieldUpdater.newUpdater(RefCountInner.class, "parentDone");
/*     */     
/*     */     RefCountInner(CoreSubscriber<? super T> actual, FluxRefCount.RefCountMonitor<T> connection) {
/* 175 */       this.actual = actual;
/* 176 */       this.connection = connection;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 182 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 183 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.parentDone == 1)); 
/* 184 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.parentDone == 2)); 
/* 185 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 187 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 192 */       if (Operators.validate(this.s, s)) {
/* 193 */         this.s = s;
/* 194 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 200 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 205 */       if (PARENT_DONE.compareAndSet(this, 0, 1)) {
/* 206 */         this.connection.upstreamFinished();
/* 207 */         this.actual.onError(t);
/*     */       } else {
/*     */         
/* 210 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 216 */       if (PARENT_DONE.compareAndSet(this, 0, 1)) {
/* 217 */         this.connection.upstreamFinished();
/* 218 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 224 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 229 */       this.s.cancel();
/* 230 */       if (PARENT_DONE.compareAndSet(this, 0, 2)) {
/* 231 */         this.connection.innerCancelled();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 237 */       return this.actual;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 243 */       if (this.s instanceof Fuseable.QueueSubscription) {
/* 244 */         this.qs = (Fuseable.QueueSubscription<T>)this.s;
/* 245 */         return this.qs.requestFusion(requestedMode);
/*     */       } 
/* 247 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 253 */       return (T)this.qs.poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 258 */       return this.qs.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 263 */       return this.qs.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 268 */       this.qs.clear();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxRefCount.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */