/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CorePublisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxSourceFuseable<I>
/*    */   extends Flux<I>
/*    */   implements Fuseable, SourceProducer<I>, OptimizableOperator<I, I>
/*    */ {
/*    */   final Publisher<? extends I> source;
/*    */   @Nullable
/*    */   final OptimizableOperator<?, I> optimizableOperator;
/*    */   
/*    */   FluxSourceFuseable(Publisher<? extends I> source) {
/* 41 */     this.source = Objects.<Publisher<? extends I>>requireNonNull(source);
/* 42 */     if (source instanceof OptimizableOperator) {
/*    */       
/* 44 */       OptimizableOperator<?, I> optimSource = (OptimizableOperator)source;
/* 45 */       this.optimizableOperator = optimSource;
/*    */     } else {
/*    */       
/* 48 */       this.optimizableOperator = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super I> actual) {
/* 60 */     this.source.subscribe((Subscriber)actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super I> actual) {
/* 65 */     return actual;
/*    */   }
/*    */ 
/*    */   
/*    */   public final CorePublisher<? extends I> source() {
/* 70 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final OptimizableOperator<?, ? extends I> nextOptimizableSource() {
/* 75 */     return this.optimizableOperator;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 81 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 82 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 83 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 84 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxSourceFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */