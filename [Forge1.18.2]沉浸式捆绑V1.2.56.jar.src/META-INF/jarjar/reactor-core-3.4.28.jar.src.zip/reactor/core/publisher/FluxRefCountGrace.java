/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxRefCountGrace<T>
/*     */   extends Flux<T>
/*     */   implements Scannable, Fuseable
/*     */ {
/*     */   final ConnectableFlux<T> source;
/*     */   final int n;
/*     */   final Duration gracePeriod;
/*     */   final Scheduler scheduler;
/*     */   RefConnection connection;
/*     */   
/*     */   FluxRefCountGrace(ConnectableFlux<T> source, int n, Duration gracePeriod, Scheduler scheduler) {
/*  49 */     this.source = source;
/*  50 */     this.n = n;
/*  51 */     this.gracePeriod = gracePeriod;
/*  52 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  58 */     return this.source.getPrefetch();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  65 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     RefConnection conn;
/*  75 */     boolean connect = false;
/*  76 */     synchronized (this) {
/*  77 */       conn = this.connection;
/*  78 */       if (conn == null || conn.isTerminated()) {
/*  79 */         conn = new RefConnection(this);
/*  80 */         this.connection = conn;
/*     */       } 
/*     */       
/*  83 */       long c = conn.subscriberCount;
/*  84 */       if (c == 0L && conn.timer != null) {
/*  85 */         conn.timer.dispose();
/*     */       }
/*  87 */       conn.subscriberCount = c + 1L;
/*  88 */       if (!conn.connected && c + 1L == this.n) {
/*  89 */         connect = true;
/*  90 */         conn.connected = true;
/*     */       } 
/*     */     } 
/*     */     
/*  94 */     this.source.subscribe(new RefCountInner<>(actual, this, conn));
/*     */     
/*  96 */     if (connect) {
/*  97 */       this.source.connect(conn);
/*     */     }
/*     */   }
/*     */   
/*     */   void cancel(RefConnection rc) {
/* 102 */     boolean replaceTimer = false;
/* 103 */     Disposable dispose = null;
/* 104 */     Disposable.Swap sd = null;
/* 105 */     synchronized (this) {
/* 106 */       if (rc.terminated) {
/*     */         return;
/*     */       }
/* 109 */       long c = rc.subscriberCount - 1L;
/* 110 */       rc.subscriberCount = c;
/* 111 */       if (c != 0L || !rc.connected) {
/*     */         return;
/*     */       }
/* 114 */       if (!this.gracePeriod.isZero()) {
/* 115 */         sd = Disposables.swap();
/* 116 */         rc.timer = (Disposable)sd;
/* 117 */         replaceTimer = true;
/*     */       }
/* 119 */       else if (rc == this.connection) {
/*     */ 
/*     */         
/* 122 */         this.connection = null;
/* 123 */         dispose = RefConnection.SOURCE_DISCONNECTOR.getAndSet(rc, Disposables.disposed());
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     if (replaceTimer) {
/* 128 */       sd.replace(this.scheduler.schedule(rc, this.gracePeriod.toNanos(), TimeUnit.NANOSECONDS));
/* 129 */     } else if (dispose != null) {
/* 130 */       dispose.dispose();
/*     */     } 
/*     */   }
/*     */   
/*     */   void terminated(RefConnection rc) {
/* 135 */     synchronized (this) {
/* 136 */       if (!rc.terminated) {
/* 137 */         rc.terminated = true;
/* 138 */         this.connection = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void timeout(RefConnection rc) {
/* 144 */     Disposable dispose = null;
/* 145 */     synchronized (this) {
/* 146 */       if (rc.subscriberCount == 0L && rc == this.connection) {
/* 147 */         this.connection = null;
/* 148 */         dispose = RefConnection.SOURCE_DISCONNECTOR.getAndSet(rc, Disposables.disposed());
/*     */       } 
/*     */     } 
/* 151 */     if (dispose != null) {
/* 152 */       dispose.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RefConnection
/*     */     implements Runnable, Consumer<Disposable>
/*     */   {
/*     */     final FluxRefCountGrace<?> parent;
/*     */     
/*     */     Disposable timer;
/*     */     long subscriberCount;
/*     */     boolean connected;
/*     */     boolean terminated;
/*     */     volatile Disposable sourceDisconnector;
/* 167 */     static final AtomicReferenceFieldUpdater<RefConnection, Disposable> SOURCE_DISCONNECTOR = AtomicReferenceFieldUpdater.newUpdater(RefConnection.class, Disposable.class, "sourceDisconnector");
/*     */     
/*     */     RefConnection(FluxRefCountGrace<?> parent) {
/* 170 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isTerminated() {
/* 178 */       Disposable sd = this.sourceDisconnector;
/* 179 */       return (this.terminated || (sd != null && sd.isDisposed()));
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 184 */       this.parent.timeout(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Disposable t) {
/* 189 */       OperatorDisposables.replace(SOURCE_DISCONNECTOR, this, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RefCountInner<T>
/*     */     implements Fuseable.QueueSubscription<T>, InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final FluxRefCountGrace<T> parent;
/*     */     
/*     */     final FluxRefCountGrace.RefConnection connection;
/*     */     
/*     */     Subscription s;
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     volatile int parentDone;
/* 206 */     static final AtomicIntegerFieldUpdater<RefCountInner> PARENT_DONE = AtomicIntegerFieldUpdater.newUpdater(RefCountInner.class, "parentDone");
/*     */ 
/*     */     
/*     */     RefCountInner(CoreSubscriber<? super T> actual, FluxRefCountGrace<T> parent, FluxRefCountGrace.RefConnection connection) {
/* 210 */       this.actual = actual;
/* 211 */       this.parent = parent;
/* 212 */       this.connection = connection;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 217 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 222 */       if (PARENT_DONE.compareAndSet(this, 0, 1)) {
/* 223 */         this.parent.terminated(this.connection);
/*     */       }
/* 225 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 230 */       if (PARENT_DONE.compareAndSet(this, 0, 1)) {
/* 231 */         this.parent.terminated(this.connection);
/*     */       }
/* 233 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 238 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 243 */       this.s.cancel();
/* 244 */       if (PARENT_DONE.compareAndSet(this, 0, 1)) {
/* 245 */         this.parent.cancel(this.connection);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 251 */       if (Operators.validate(this.s, s)) {
/* 252 */         this.s = s;
/*     */         
/* 254 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 261 */       if (this.s instanceof Fuseable.QueueSubscription) {
/* 262 */         this.qs = (Fuseable.QueueSubscription<T>)this.s;
/* 263 */         return this.qs.requestFusion(requestedMode);
/*     */       } 
/* 265 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 271 */       return (T)this.qs.poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 276 */       return this.qs.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 281 */       return this.qs.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 286 */       this.qs.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 291 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 296 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 297 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxRefCountGrace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */