/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelFluxOnAssembly<T>
/*     */   extends ParallelFlux<T>
/*     */   implements Fuseable, AssemblyOp, Scannable
/*     */ {
/*     */   final ParallelFlux<T> source;
/*     */   final FluxOnAssembly.AssemblySnapshot stacktrace;
/*     */   
/*     */   ParallelFluxOnAssembly(ParallelFlux<T> source, FluxOnAssembly.AssemblySnapshot stacktrace) {
/*  49 */     this.source = source;
/*  50 */     this.stacktrace = stacktrace;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  55 */     return this.source.getPrefetch();
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/*  60 */     return this.source.parallelism();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/*  66 */     if (!validate((Subscriber<?>[])subscribers)) {
/*     */       return;
/*     */     }
/*     */     
/*  70 */     int n = subscribers.length;
/*  71 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*     */ 
/*     */     
/*  74 */     for (int i = 0; i < n; i++) {
/*  75 */       CoreSubscriber<? super T> s = subscribers[i];
/*  76 */       if (s instanceof Fuseable.ConditionalSubscriber) {
/*  77 */         Fuseable.ConditionalSubscriber<? super T> cs = (Fuseable.ConditionalSubscriber<? super T>)s;
/*     */         
/*  79 */         s = new FluxOnAssembly.OnAssemblyConditionalSubscriber<>(cs, this.stacktrace, (Publisher<?>)this.source, (Publisher<?>)this);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/*  85 */         s = new FluxOnAssembly.OnAssemblySubscriber<>(s, this.stacktrace, (Publisher<?>)this.source, (Publisher<?>)this);
/*     */       } 
/*  87 */       arrayOfCoreSubscriber[i] = s;
/*     */     } 
/*     */     
/*  90 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  96 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  97 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  98 */     if (key == Scannable.Attr.ACTUAL_METADATA) return Boolean.valueOf(!this.stacktrace.isCheckpoint); 
/*  99 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String stepName() {
/* 106 */     return this.stacktrace.operatorAssemblyInformation();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return this.stacktrace.operatorAssemblyInformation();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelFluxOnAssembly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */