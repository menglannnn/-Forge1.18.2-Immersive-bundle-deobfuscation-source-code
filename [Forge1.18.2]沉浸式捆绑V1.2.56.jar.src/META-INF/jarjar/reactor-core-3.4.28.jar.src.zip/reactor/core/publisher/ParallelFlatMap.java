/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Queue;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelFlatMap<T, R>
/*     */   extends ParallelFlux<R>
/*     */   implements Scannable
/*     */ {
/*     */   final ParallelFlux<T> source;
/*     */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */   final boolean delayError;
/*     */   final int maxConcurrency;
/*     */   final Supplier<? extends Queue<R>> mainQueueSupplier;
/*     */   final int prefetch;
/*     */   final Supplier<? extends Queue<R>> innerQueueSupplier;
/*     */   
/*     */   ParallelFlatMap(ParallelFlux<T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency, Supplier<? extends Queue<R>> mainQueueSupplier, int prefetch, Supplier<? extends Queue<R>> innerQueueSupplier) {
/*  56 */     this.source = source;
/*  57 */     this.mapper = mapper;
/*  58 */     this.delayError = delayError;
/*  59 */     this.maxConcurrency = maxConcurrency;
/*  60 */     this.mainQueueSupplier = mainQueueSupplier;
/*  61 */     this.prefetch = prefetch;
/*  62 */     this.innerQueueSupplier = innerQueueSupplier;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  68 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  69 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  70 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/*  71 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  78 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/*  83 */     return this.source.parallelism();
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super R>[] subscribers) {
/*  88 */     if (!validate((Subscriber<?>[])subscribers)) {
/*     */       return;
/*     */     }
/*     */     
/*  92 */     int n = subscribers.length;
/*     */ 
/*     */     
/*  95 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*     */     
/*  97 */     for (int i = 0; i < n; i++) {
/*  98 */       arrayOfCoreSubscriber[i] = new FluxFlatMap.FlatMapMain<>(subscribers[i], this.mapper, this.delayError, this.maxConcurrency, this.mainQueueSupplier, this.prefetch, this.innerQueueSupplier);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelFlatMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */