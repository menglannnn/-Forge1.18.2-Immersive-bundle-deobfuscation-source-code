/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Set;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxNameFuseable<T>
/*    */   extends InternalFluxOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   final String name;
/*    */   final Set<Tuple2<String, String>> tags;
/*    */   
/*    */   FluxNameFuseable(Flux<? extends T> source, @Nullable String name, @Nullable Set<Tuple2<String, String>> tags) {
/* 46 */     super(source);
/* 47 */     this.name = name;
/* 48 */     this.tags = tags;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 53 */     return actual;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 59 */     if (key == Scannable.Attr.NAME) {
/* 60 */       return this.name;
/*    */     }
/*    */     
/* 63 */     if (key == Scannable.Attr.TAGS && this.tags != null) {
/* 64 */       return this.tags.stream();
/*    */     }
/*    */     
/* 67 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 68 */       return Scannable.Attr.RunStyle.SYNC;
/*    */     }
/*    */     
/* 71 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxNameFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */