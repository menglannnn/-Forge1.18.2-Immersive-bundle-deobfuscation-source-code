/*    */ package reactor.core.publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BlockingMonoSubscriber<T>
/*    */   extends BlockingSingleSubscriber<T>
/*    */ {
/*    */   public void onNext(T t) {
/* 31 */     if (this.value == null) {
/* 32 */       this.value = t;
/* 33 */       countDown();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onError(Throwable t) {
/* 39 */     if (this.value == null) {
/* 40 */       this.error = t;
/*    */     }
/* 42 */     countDown();
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 47 */     return "block";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\BlockingMonoSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */