/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import io.micrometer.core.instrument.Clock;
/*     */ import io.micrometer.core.instrument.MeterRegistry;
/*     */ import io.micrometer.core.instrument.Tags;
/*     */ import io.micrometer.core.instrument.Timer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Metrics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoMetrics<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */ {
/*     */   final String name;
/*     */   final Tags tags;
/*     */   final MeterRegistry registryCandidate;
/*     */   
/*     */   MonoMetrics(Mono<? extends T> mono) {
/*  45 */     super(mono);
/*     */     
/*  47 */     this.name = FluxMetrics.resolveName((Publisher<?>)mono);
/*  48 */     this.tags = FluxMetrics.resolveTags((Publisher<?>)mono, FluxMetrics.DEFAULT_TAGS_MONO);
/*     */     
/*  50 */     this.registryCandidate = Metrics.MicrometerConfiguration.getRegistry();
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  55 */     return new MetricsSubscriber<>(actual, this.registryCandidate, Clock.SYSTEM, this.name, this.tags);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  60 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  61 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static class MetricsSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final Clock clock;
/*     */     final String sequenceName;
/*     */     final Tags commonTags;
/*     */     final MeterRegistry registry;
/*     */     Timer.Sample subscribeToTerminateSample;
/*     */     boolean done;
/*     */     Subscription s;
/*     */     
/*     */     MetricsSubscriber(CoreSubscriber<? super T> actual, MeterRegistry registry, Clock clock, String sequenceName, Tags commonTags) {
/*  78 */       this.actual = actual;
/*  79 */       this.clock = clock;
/*  80 */       this.sequenceName = sequenceName;
/*  81 */       this.commonTags = commonTags;
/*  82 */       this.registry = registry;
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/*  87 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public final void cancel() {
/*  92 */       FluxMetrics.recordCancel(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*  93 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/*  98 */       if (this.done) {
/*     */         return;
/*     */       }
/* 101 */       this.done = true;
/* 102 */       FluxMetrics.recordOnCompleteEmpty(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/* 103 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onError(Throwable e) {
/* 108 */       if (this.done) {
/* 109 */         FluxMetrics.recordMalformed(this.sequenceName, this.commonTags, this.registry);
/* 110 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 113 */       this.done = true;
/* 114 */       FluxMetrics.recordOnError(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample, e);
/* 115 */       this.actual.onError(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 120 */       if (this.done) {
/* 121 */         FluxMetrics.recordMalformed(this.sequenceName, this.commonTags, this.registry);
/* 122 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 125 */       this.done = true;
/* 126 */       FluxMetrics.recordOnComplete(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/* 127 */       this.actual.onNext(t);
/* 128 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 133 */       if (Operators.validate(this.s, s)) {
/* 134 */         FluxMetrics.recordOnSubscribe(this.sequenceName, this.commonTags, this.registry);
/* 135 */         this.subscribeToTerminateSample = Timer.start(this.clock);
/* 136 */         this.s = s;
/* 137 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public final void request(long l) {
/* 143 */       if (Operators.validate(l)) {
/* 144 */         this.s.request(l);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 150 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 151 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoMetrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */