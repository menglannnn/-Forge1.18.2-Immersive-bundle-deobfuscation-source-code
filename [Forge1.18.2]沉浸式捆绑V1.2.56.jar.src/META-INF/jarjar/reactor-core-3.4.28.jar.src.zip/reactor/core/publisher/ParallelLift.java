/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParallelLift<I, O>
/*    */   extends ParallelFlux<O>
/*    */   implements Scannable
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   final ParallelFlux<I> source;
/*    */   
/*    */   ParallelLift(ParallelFlux<I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 36 */     this.source = Objects.<ParallelFlux<I>>requireNonNull(p, "source");
/* 37 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 42 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   public int parallelism() {
/* 47 */     return this.source.parallelism();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 53 */     if (key == Scannable.Attr.PARENT) {
/* 54 */       return this.source;
/*    */     }
/* 56 */     if (key == Scannable.Attr.PREFETCH) {
/* 57 */       return Integer.valueOf(getPrefetch());
/*    */     }
/* 59 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 60 */       return Scannable.from(this.source).scanUnsafe(key);
/*    */     }
/* 62 */     if (key == Scannable.Attr.LIFTER) {
/* 63 */       return this.liftFunction.name;
/*    */     }
/*    */     
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 71 */     if (this.source instanceof Scannable) {
/* 72 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 74 */     return super.stepName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super O>[] s) {
/* 80 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[parallelism()];
/*    */     
/* 82 */     int i = 0;
/* 83 */     while (i < arrayOfCoreSubscriber.length) {
/* 84 */       arrayOfCoreSubscriber[i] = 
/* 85 */         Objects.<CoreSubscriber>requireNonNull(this.liftFunction.lifter.apply(this.source, s[i]), "Lifted subscriber MUST NOT be null");
/*    */       
/* 87 */       i++;
/*    */     } 
/*    */     
/* 90 */     this.source.subscribe((CoreSubscriber<? super I>[])arrayOfCoreSubscriber);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelLift.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */