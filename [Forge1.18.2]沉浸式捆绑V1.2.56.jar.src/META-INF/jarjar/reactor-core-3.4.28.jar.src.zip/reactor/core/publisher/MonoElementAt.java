/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoElementAt<T>
/*     */   extends MonoFromFluxOperator<T, T>
/*     */   implements Fuseable
/*     */ {
/*     */   final long index;
/*     */   final T defaultValue;
/*     */   
/*     */   MonoElementAt(Flux<? extends T> source, long index) {
/*  41 */     super(source);
/*  42 */     if (index < 0L) {
/*  43 */       throw new IndexOutOfBoundsException("index >= required but it was " + index);
/*     */     }
/*  45 */     this.index = index;
/*  46 */     this.defaultValue = null;
/*     */   }
/*     */   
/*     */   MonoElementAt(Flux<? extends T> source, long index, T defaultValue) {
/*  50 */     super(source);
/*  51 */     if (index < 0L) {
/*  52 */       throw new IndexOutOfBoundsException("index >= required but it was " + index);
/*     */     }
/*  54 */     this.index = index;
/*  55 */     this.defaultValue = Objects.requireNonNull(defaultValue, "defaultValue");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  60 */     return new ElementAtSubscriber<>(actual, this.index, this.defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  65 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  66 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ElementAtSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     final T defaultValue;
/*     */     
/*     */     long index;
/*     */     
/*     */     final long target;
/*     */     
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     ElementAtSubscriber(CoreSubscriber<? super T> actual, long index, T defaultValue) {
/*  83 */       super(actual);
/*  84 */       this.index = index;
/*  85 */       this.target = index;
/*  86 */       this.defaultValue = defaultValue;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  92 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  93 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  94 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  96 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 101 */       super.request(n);
/* 102 */       if (n > 0L) {
/* 103 */         this.s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 109 */       super.cancel();
/* 110 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 115 */       if (Operators.validate(this.s, s)) {
/* 116 */         this.s = s;
/*     */         
/* 118 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 124 */       if (this.done) {
/* 125 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 129 */       long i = this.index;
/* 130 */       if (i == 0L) {
/* 131 */         this.done = true;
/* 132 */         this.s.cancel();
/*     */         
/* 134 */         this.actual.onNext(t);
/* 135 */         this.actual.onComplete();
/*     */         return;
/*     */       } 
/* 138 */       this.index = i - 1L;
/* 139 */       Operators.onDiscard(t, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 144 */       if (this.done) {
/* 145 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 148 */       this.done = true;
/*     */       
/* 150 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 155 */       if (this.done) {
/*     */         return;
/*     */       }
/* 158 */       this.done = true;
/*     */       
/* 160 */       if (this.defaultValue != null) {
/* 161 */         complete(this.defaultValue);
/*     */       } else {
/*     */         
/* 164 */         long count = this.target - this.index;
/* 165 */         this.actual.onError(Operators.onOperatorError(new IndexOutOfBoundsException("source had " + count + " elements, expected at least " + (this.target + 1L)), this.actual
/*     */               
/* 167 */               .currentContext()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoElementAt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */