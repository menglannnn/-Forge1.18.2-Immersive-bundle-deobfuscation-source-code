/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxTimed<T>
/*     */   extends InternalFluxOperator<T, Timed<T>>
/*     */ {
/*     */   final Scheduler clock;
/*     */   
/*     */   FluxTimed(Flux<? extends T> source, Scheduler clock) {
/*  38 */     super(source);
/*  39 */     this.clock = clock;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Timed<T>> actual) {
/*  44 */     return new TimedSubscriber<>(actual, this.clock);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  49 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  55 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  57 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ImmutableTimed<T>
/*     */     implements Timed<T>
/*     */   {
/*     */     final long eventElapsedSinceSubscriptionNanos;
/*     */ 
/*     */     
/*     */     final long eventElapsedNanos;
/*     */ 
/*     */     
/*     */     final long eventTimestampEpochMillis;
/*     */ 
/*     */     
/*     */     final T event;
/*     */ 
/*     */     
/*     */     ImmutableTimed(long eventElapsedSinceSubscriptionNanos, long eventElapsedNanos, long eventTimestampEpochMillis, T event) {
/*  78 */       this.eventElapsedSinceSubscriptionNanos = eventElapsedSinceSubscriptionNanos;
/*  79 */       this.eventElapsedNanos = eventElapsedNanos;
/*  80 */       this.eventTimestampEpochMillis = eventTimestampEpochMillis;
/*  81 */       this.event = event;
/*     */     }
/*     */ 
/*     */     
/*     */     public T get() {
/*  86 */       return this.event;
/*     */     }
/*     */ 
/*     */     
/*     */     public Duration elapsed() {
/*  91 */       return Duration.ofNanos(this.eventElapsedNanos);
/*     */     }
/*     */ 
/*     */     
/*     */     public Duration elapsedSinceSubscription() {
/*  96 */       return Duration.ofNanos(this.eventElapsedSinceSubscriptionNanos);
/*     */     }
/*     */ 
/*     */     
/*     */     public Instant timestamp() {
/* 101 */       return Instant.ofEpochMilli(this.eventTimestampEpochMillis);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 106 */       if (this == o) {
/* 107 */         return true;
/*     */       }
/* 109 */       if (o == null || getClass() != o.getClass()) {
/* 110 */         return false;
/*     */       }
/* 112 */       ImmutableTimed<?> timed = (ImmutableTimed)o;
/* 113 */       return (this.eventElapsedSinceSubscriptionNanos == timed.eventElapsedSinceSubscriptionNanos && this.eventElapsedNanos == timed.eventElapsedNanos && this.eventTimestampEpochMillis == timed.eventTimestampEpochMillis && this.event.equals(timed.event));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 119 */       return Objects.hash(new Object[] { Long.valueOf(this.eventElapsedSinceSubscriptionNanos), 
/* 120 */             Long.valueOf(this.eventElapsedNanos), 
/* 121 */             Long.valueOf(this.eventTimestampEpochMillis), this.event });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 127 */       return "Timed(" + this.event + "){eventElapsedNanos=" + this.eventElapsedNanos + ", eventElapsedSinceSubscriptionNanos=" + this.eventElapsedSinceSubscriptionNanos + ",  eventTimestampEpochMillis=" + this.eventTimestampEpochMillis + '}';
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TimedSubscriber<T>
/*     */     implements InnerOperator<T, Timed<T>>
/*     */   {
/*     */     final CoreSubscriber<? super Timed<T>> actual;
/*     */     final Scheduler clock;
/*     */     long subscriptionNanos;
/*     */     long lastEventNanos;
/*     */     boolean done;
/*     */     Subscription s;
/*     */     
/*     */     TimedSubscriber(CoreSubscriber<? super Timed<T>> actual, Scheduler clock) {
/* 143 */       this.actual = actual;
/* 144 */       this.clock = clock;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Timed<T>> actual() {
/* 149 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 154 */       if (Operators.validate(this.s, s)) {
/* 155 */         this.s = s;
/*     */         
/* 157 */         this.subscriptionNanos = this.clock.now(TimeUnit.NANOSECONDS);
/* 158 */         this.lastEventNanos = this.subscriptionNanos;
/*     */         
/* 160 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 166 */       if (this.done) {
/* 167 */         Operators.onNextDropped(t, currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 171 */       long nowNanos = this.clock.now(TimeUnit.NANOSECONDS);
/* 172 */       long timestamp = this.clock.now(TimeUnit.MILLISECONDS);
/* 173 */       Timed<T> timed = new FluxTimed.ImmutableTimed<>(nowNanos - this.subscriptionNanos, nowNanos - this.lastEventNanos, timestamp, t);
/* 174 */       this.lastEventNanos = nowNanos;
/* 175 */       this.actual.onNext(timed);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 180 */       if (this.done) {
/* 181 */         Operators.onErrorDropped(throwable, currentContext());
/*     */         return;
/*     */       } 
/* 184 */       this.done = true;
/* 185 */       this.actual.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 190 */       if (this.done) {
/*     */         return;
/*     */       }
/* 193 */       this.done = true;
/* 194 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long l) {
/* 199 */       if (Operators.validate(l)) {
/* 200 */         this.s.request(l);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 206 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 212 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 213 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 215 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxTimed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */