/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDematerialize<T>
/*     */   extends InternalFluxOperator<Signal<T>, T>
/*     */ {
/*     */   FluxDematerialize(Flux<Signal<T>> source) {
/*  30 */     super(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super Signal<T>> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  35 */     return new DematerializeSubscriber<>(actual, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  40 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  41 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DematerializeSubscriber<T>
/*     */     implements InnerOperator<Signal<T>, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final boolean completeAfterOnNext;
/*     */     Subscription s;
/*     */     boolean done;
/*     */     volatile boolean cancelled;
/*     */     
/*     */     DematerializeSubscriber(CoreSubscriber<? super T> subscriber, boolean completeAfterOnNext) {
/*  56 */       this.actual = subscriber;
/*  57 */       this.completeAfterOnNext = completeAfterOnNext;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  63 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  64 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  65 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/*  66 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(0); 
/*  67 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  69 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  74 */       if (Operators.validate(this.s, s)) {
/*  75 */         this.s = s;
/*     */         
/*  77 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Signal<T> t) {
/*  83 */       if (this.done) {
/*     */         
/*  85 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*  89 */       if (t.isOnComplete()) {
/*  90 */         this.s.cancel();
/*  91 */         onComplete();
/*     */       }
/*  93 */       else if (t.isOnError()) {
/*  94 */         this.s.cancel();
/*  95 */         onError(t.getThrowable());
/*     */       }
/*  97 */       else if (t.isOnNext()) {
/*  98 */         this.actual.onNext(t.get());
/*  99 */         if (this.completeAfterOnNext) {
/* 100 */           onComplete();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 107 */       if (this.done) {
/* 108 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 111 */       this.done = true;
/* 112 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 117 */       if (this.done) {
/*     */         return;
/*     */       }
/* 120 */       this.done = true;
/* 121 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 126 */       if (Operators.validate(n)) {
/* 127 */         this.s.request(n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 133 */       if (!this.cancelled) {
/* 134 */         this.cancelled = true;
/* 135 */         this.s.cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 141 */       return this.actual;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxDematerialize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */