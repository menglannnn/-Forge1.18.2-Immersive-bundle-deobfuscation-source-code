/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxFilter<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Predicate<? super T> predicate;
/*     */   
/*     */   FluxFilter(Flux<? extends T> source, Predicate<? super T> predicate) {
/*  42 */     super(source);
/*  43 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  49 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  50 */       return new FilterConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this.predicate);
/*     */     }
/*     */     
/*  53 */     return new FilterSubscriber<>(actual, this.predicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  58 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  59 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FilterSubscriber<T>
/*     */     implements InnerOperator<T, T>, Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     FilterSubscriber(CoreSubscriber<? super T> actual, Predicate<? super T> predicate) {
/*  76 */       this.actual = actual;
/*  77 */       this.ctx = actual.currentContext();
/*  78 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  83 */       if (Operators.validate(this.s, s)) {
/*  84 */         this.s = s;
/*  85 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       boolean b;
/*  91 */       if (this.done) {
/*  92 */         Operators.onNextDropped(t, this.ctx);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/*  99 */         b = this.predicate.test(t);
/*     */       }
/* 101 */       catch (Throwable e) {
/* 102 */         Throwable e_ = Operators.onNextError(t, e, this.ctx, this.s);
/* 103 */         if (e_ != null) {
/* 104 */           onError(e_);
/*     */         } else {
/*     */           
/* 107 */           this.s.request(1L);
/*     */         } 
/* 109 */         Operators.onDiscard(t, this.ctx);
/*     */         return;
/*     */       } 
/* 112 */       if (b) {
/* 113 */         this.actual.onNext(t);
/*     */       } else {
/*     */         
/* 116 */         Operators.onDiscard(t, this.ctx);
/* 117 */         this.s.request(1L);
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       boolean b;
/* 123 */       if (this.done) {
/* 124 */         Operators.onNextDropped(t, this.ctx);
/* 125 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 131 */         b = this.predicate.test(t);
/*     */       }
/* 133 */       catch (Throwable e) {
/* 134 */         Throwable e_ = Operators.onNextError(t, e, this.ctx, this.s);
/* 135 */         if (e_ != null) {
/* 136 */           onError(e_);
/*     */         }
/* 138 */         Operators.onDiscard(t, this.ctx);
/* 139 */         return false;
/*     */       } 
/* 141 */       if (b) {
/* 142 */         this.actual.onNext(t);
/*     */       } else {
/*     */         
/* 145 */         Operators.onDiscard(t, this.ctx);
/*     */       } 
/* 147 */       return b;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 152 */       if (this.done) {
/* 153 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 156 */       this.done = true;
/* 157 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 162 */       if (this.done) {
/*     */         return;
/*     */       }
/* 165 */       this.done = true;
/* 166 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 172 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 173 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 174 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 176 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 181 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 186 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 191 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FilterConditionalSubscriber<T>
/*     */     implements InnerOperator<T, T>, Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     FilterConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, Predicate<? super T> predicate) {
/* 210 */       this.actual = actual;
/* 211 */       this.ctx = actual.currentContext();
/* 212 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 217 */       if (Operators.validate(this.s, s)) {
/* 218 */         this.s = s;
/* 219 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       boolean b;
/* 225 */       if (this.done) {
/* 226 */         Operators.onNextDropped(t, this.ctx);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 233 */         b = this.predicate.test(t);
/*     */       }
/* 235 */       catch (Throwable e) {
/* 236 */         Throwable e_ = Operators.onNextError(t, e, this.ctx, this.s);
/* 237 */         if (e_ != null) {
/* 238 */           onError(e_);
/*     */         } else {
/*     */           
/* 241 */           this.s.request(1L);
/*     */         } 
/* 243 */         Operators.onDiscard(t, this.ctx);
/*     */         return;
/*     */       } 
/* 246 */       if (b) {
/* 247 */         this.actual.onNext(t);
/*     */       } else {
/*     */         
/* 250 */         this.s.request(1L);
/* 251 */         Operators.onDiscard(t, this.ctx);
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       boolean b;
/* 257 */       if (this.done) {
/* 258 */         Operators.onNextDropped(t, this.ctx);
/* 259 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 265 */         b = this.predicate.test(t);
/*     */       }
/* 267 */       catch (Throwable e) {
/* 268 */         Throwable e_ = Operators.onNextError(t, e, this.ctx, this.s);
/* 269 */         if (e_ != null) {
/* 270 */           onError(e_);
/*     */         }
/* 272 */         Operators.onDiscard(t, this.ctx);
/* 273 */         return false;
/*     */       } 
/* 275 */       if (b) {
/* 276 */         return this.actual.tryOnNext(t);
/*     */       }
/*     */       
/* 279 */       Operators.onDiscard(t, this.ctx);
/* 280 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 286 */       if (this.done) {
/* 287 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 290 */       this.done = true;
/* 291 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 296 */       if (this.done) {
/*     */         return;
/*     */       }
/* 299 */       this.done = true;
/* 300 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 306 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 307 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 308 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 310 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 316 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 321 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 326 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */