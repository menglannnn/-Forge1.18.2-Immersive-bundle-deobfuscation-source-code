/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Spliterator;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxIterable<T>
/*     */   extends Flux<T>
/*     */   implements Fuseable, SourceProducer<T>
/*     */ {
/*     */   final Iterable<? extends T> iterable;
/*     */   @Nullable
/*     */   private final Runnable onClose;
/*     */   
/*     */   static <T> boolean checkFinite(Spliterator<? extends T> spliterator) {
/*  57 */     return spliterator.hasCharacteristics(64);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxIterable(Iterable<? extends T> iterable) {
/*  65 */     this.iterable = Objects.<Iterable<? extends T>>requireNonNull(iterable, "iterable");
/*  66 */     this.onClose = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     boolean knownToBeFinite;
/*     */     Spliterator<? extends T> sp;
/*     */     try {
/*  75 */       sp = this.iterable.spliterator();
/*  76 */       knownToBeFinite = checkFinite(sp);
/*     */     }
/*  78 */     catch (Throwable e) {
/*  79 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*     */       
/*     */       return;
/*     */     } 
/*  83 */     subscribe(actual, sp, knownToBeFinite, this.onClose);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  88 */     if (key == Scannable.Attr.BUFFERED) {
/*  89 */       if (this.iterable instanceof Collection) return Integer.valueOf(((Collection)this.iterable).size()); 
/*  90 */       if (this.iterable instanceof Tuple2) return Integer.valueOf(((Tuple2)this.iterable).size()); 
/*     */     } 
/*  92 */     if (key == Scannable.Attr.RUN_STYLE) {
/*  93 */       return Scannable.Attr.RunStyle.SYNC;
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void subscribe(CoreSubscriber<? super T> s, Spliterator<? extends T> sp, boolean knownToBeFinite) {
/* 105 */     subscribe(s, sp, knownToBeFinite, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void subscribe(CoreSubscriber<? super T> s, Spliterator<? extends T> sp, boolean knownToBeFinite, @Nullable Runnable onClose) {
/*     */     boolean isEmpty;
/* 121 */     if (sp == null) {
/* 122 */       Operators.error((Subscriber<?>)s, new NullPointerException("The iterator is null"));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 129 */       isEmpty = (knownToBeFinite && sp.estimateSize() == 0L);
/*     */     }
/* 131 */     catch (Throwable e) {
/* 132 */       Operators.error((Subscriber<?>)s, Operators.onOperatorError(e, s.currentContext()));
/* 133 */       if (onClose != null) {
/*     */         try {
/* 135 */           onClose.run();
/*     */         }
/* 137 */         catch (Throwable t) {
/* 138 */           Operators.onErrorDropped(t, s.currentContext());
/*     */         } 
/*     */       }
/*     */       return;
/*     */     } 
/* 143 */     if (isEmpty) {
/* 144 */       Operators.complete((Subscriber<?>)s);
/* 145 */       if (onClose != null) {
/*     */         try {
/* 147 */           onClose.run();
/*     */         }
/* 149 */         catch (Throwable t) {
/* 150 */           Operators.onErrorDropped(t, s.currentContext());
/*     */         } 
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 156 */     if (s instanceof Fuseable.ConditionalSubscriber) {
/* 157 */       boolean hasNext; IterableSubscriptionConditional<? extends T> isc = new IterableSubscriptionConditional<>((Fuseable.ConditionalSubscriber<? super T>)s, sp, knownToBeFinite, onClose);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 165 */         hasNext = isc.hasNext();
/*     */       }
/* 167 */       catch (Throwable ex) {
/* 168 */         Operators.error((Subscriber<?>)s, ex);
/* 169 */         isc.onCloseWithDropError();
/*     */         
/*     */         return;
/*     */       } 
/* 173 */       if (!hasNext) {
/* 174 */         Operators.complete((Subscriber<?>)s);
/* 175 */         isc.onCloseWithDropError();
/*     */         
/*     */         return;
/*     */       } 
/* 179 */       s.onSubscribe(isc);
/*     */     } else {
/*     */       boolean hasNext;
/* 182 */       IterableSubscription<? extends T> is = new IterableSubscription<>(s, sp, knownToBeFinite, onClose);
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 187 */         hasNext = is.hasNext();
/*     */       }
/* 189 */       catch (Throwable ex) {
/* 190 */         Operators.error((Subscriber<?>)s, ex);
/* 191 */         is.onCloseWithDropError();
/*     */         
/*     */         return;
/*     */       } 
/* 195 */       if (!hasNext) {
/* 196 */         Operators.complete((Subscriber<?>)s);
/* 197 */         is.onCloseWithDropError();
/*     */         
/*     */         return;
/*     */       } 
/* 201 */       s.onSubscribe(is);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static final class IterableSubscription<T>
/*     */     implements InnerProducer<T>, Fuseable.SynchronousSubscription<T>, Consumer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Spliterator<? extends T> spliterator;
/*     */     
/*     */     final boolean knownToBeFinite;
/*     */     
/*     */     final Runnable onClose;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     volatile long requested;
/* 219 */     static final AtomicLongFieldUpdater<IterableSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(IterableSubscription.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     int state;
/*     */ 
/*     */     
/*     */     static final int STATE_HAS_NEXT_NO_VALUE = 0;
/*     */ 
/*     */     
/*     */     static final int STATE_HAS_NEXT_HAS_VALUE = 1;
/*     */ 
/*     */     
/*     */     static final int STATE_NO_NEXT = 2;
/*     */ 
/*     */     
/*     */     static final int STATE_CALL_HAS_NEXT = 3;
/*     */ 
/*     */     
/*     */     T current;
/*     */ 
/*     */     
/*     */     boolean valueReady = false;
/*     */ 
/*     */     
/*     */     T nextElement;
/*     */ 
/*     */     
/*     */     Throwable hasNextFailure;
/*     */ 
/*     */ 
/*     */     
/*     */     IterableSubscription(CoreSubscriber<? super T> actual, Spliterator<? extends T> spliterator, boolean knownToBeFinite, @Nullable Runnable onClose) {
/* 252 */       this.actual = actual;
/* 253 */       this.spliterator = spliterator;
/* 254 */       this.knownToBeFinite = knownToBeFinite;
/* 255 */       this.onClose = onClose;
/*     */     }
/*     */ 
/*     */     
/*     */     IterableSubscription(CoreSubscriber<? super T> actual, Spliterator<? extends T> spliterator, boolean knownToBeFinite) {
/* 260 */       this(actual, spliterator, knownToBeFinite, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(T t) {
/* 265 */       this.valueReady = true;
/* 266 */       this.nextElement = t;
/*     */     }
/*     */     
/*     */     boolean hasNext() {
/* 270 */       if (!this.valueReady)
/* 271 */         this.spliterator.tryAdvance(this); 
/* 272 */       return this.valueReady;
/*     */     }
/*     */     
/*     */     T next() {
/* 276 */       if (!this.valueReady && !hasNext()) {
/* 277 */         throw new NoSuchElementException();
/*     */       }
/* 279 */       this.valueReady = false;
/* 280 */       T t = this.nextElement;
/* 281 */       this.nextElement = null;
/* 282 */       return t;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 288 */       if (Operators.validate(n) && 
/* 289 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/* 290 */         if (n == Long.MAX_VALUE) {
/* 291 */           fastPath();
/*     */         } else {
/*     */           
/* 294 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void onCloseWithDropError() {
/* 301 */       if (this.onClose != null) {
/*     */         try {
/* 303 */           this.onClose.run();
/*     */         }
/* 305 */         catch (Throwable t) {
/* 306 */           Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     void slowPath(long n) {
/* 312 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       
/* 314 */       long e = 0L;
/*     */ 
/*     */       
/*     */       while (true) {
/* 318 */         while (e != n) {
/*     */           T t;
/*     */           boolean b;
/*     */           try {
/* 322 */             t = Objects.requireNonNull(next(), "The iterator returned a null value");
/*     */           
/*     */           }
/* 325 */           catch (Throwable ex) {
/* 326 */             coreSubscriber.onError(ex);
/* 327 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 331 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 335 */           coreSubscriber.onNext(t);
/*     */           
/* 337 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 344 */             b = hasNext();
/*     */           }
/* 346 */           catch (Throwable ex) {
/* 347 */             coreSubscriber.onError(ex);
/* 348 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 352 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 356 */           if (!b) {
/* 357 */             coreSubscriber.onComplete();
/* 358 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 362 */           e++;
/*     */         } 
/*     */         
/* 365 */         n = this.requested;
/*     */         
/* 367 */         if (n == e) {
/* 368 */           n = REQUESTED.addAndGet(this, -e);
/* 369 */           if (n == 0L) {
/*     */             return;
/*     */           }
/* 372 */           e = 0L;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void fastPath() {
/* 378 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       while (true) {
/*     */         T t;
/*     */         boolean b;
/* 382 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 389 */           t = Objects.requireNonNull(next(), "The iterator returned a null value");
/*     */         
/*     */         }
/* 392 */         catch (Exception ex) {
/* 393 */           coreSubscriber.onError(ex);
/* 394 */           onCloseWithDropError();
/*     */           
/*     */           return;
/*     */         } 
/* 398 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 402 */         coreSubscriber.onNext(t);
/*     */         
/* 404 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 411 */           b = hasNext();
/*     */         }
/* 413 */         catch (Exception ex) {
/* 414 */           coreSubscriber.onError(ex);
/* 415 */           onCloseWithDropError();
/*     */           
/*     */           return;
/*     */         } 
/* 419 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 423 */         if (!b) {
/* 424 */           coreSubscriber.onComplete();
/* 425 */           onCloseWithDropError();
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 433 */       onCloseWithDropError();
/* 434 */       this.cancelled = true;
/* 435 */       Operators.onDiscard(this.nextElement, this.actual.currentContext());
/* 436 */       Operators.onDiscardMultiple(this.spliterator, this.knownToBeFinite, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 441 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 447 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 448 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 449 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.state == 2)); 
/* 450 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 452 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 457 */       Operators.onDiscard(this.nextElement, this.actual.currentContext());
/* 458 */       Operators.onDiscardMultiple(this.spliterator, this.knownToBeFinite, this.actual.currentContext());
/* 459 */       this.state = 2;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/*     */       boolean hasNext;
/* 464 */       int s = this.state;
/* 465 */       if (s == 2) {
/* 466 */         return true;
/*     */       }
/* 468 */       if (this.cancelled && !this.knownToBeFinite) {
/* 469 */         return true;
/*     */       }
/* 471 */       if (s == 1 || s == 0) {
/* 472 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 477 */         hasNext = hasNext();
/*     */       }
/* 479 */       catch (Throwable t) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 484 */         this.state = 0;
/* 485 */         this.hasNextFailure = t;
/* 486 */         return false;
/*     */       } 
/*     */       
/* 489 */       if (hasNext) {
/* 490 */         this.state = 0;
/* 491 */         return false;
/*     */       } 
/* 493 */       this.state = 2;
/* 494 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 501 */       if (this.hasNextFailure != null) {
/* 502 */         this.state = 2;
/* 503 */         throw Exceptions.propagate(this.hasNextFailure);
/*     */       } 
/* 505 */       if (!isEmpty()) {
/*     */         T c;
/* 507 */         if (this.state == 0) {
/* 508 */           c = next();
/*     */         } else {
/*     */           
/* 511 */           c = this.current;
/* 512 */           this.current = null;
/*     */         } 
/* 514 */         this.state = 3;
/* 515 */         if (c == null) {
/* 516 */           onCloseWithDropError();
/* 517 */           throw new NullPointerException("iterator returned a null value");
/*     */         } 
/* 519 */         return c;
/*     */       } 
/* 521 */       onCloseWithDropError();
/* 522 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 527 */       if (this.state == 2) {
/* 528 */         return 0;
/*     */       }
/* 530 */       return 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class IterableSubscriptionConditional<T>
/*     */     implements InnerProducer<T>, Fuseable.SynchronousSubscription<T>, Consumer<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final Spliterator<? extends T> spliterator;
/*     */     
/*     */     final boolean knownToBeFinite;
/*     */     
/*     */     final Runnable onClose;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     volatile long requested;
/* 548 */     static final AtomicLongFieldUpdater<IterableSubscriptionConditional> REQUESTED = AtomicLongFieldUpdater.newUpdater(IterableSubscriptionConditional.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     int state;
/*     */ 
/*     */     
/*     */     static final int STATE_HAS_NEXT_NO_VALUE = 0;
/*     */ 
/*     */     
/*     */     static final int STATE_HAS_NEXT_HAS_VALUE = 1;
/*     */ 
/*     */     
/*     */     static final int STATE_NO_NEXT = 2;
/*     */ 
/*     */     
/*     */     static final int STATE_CALL_HAS_NEXT = 3;
/*     */ 
/*     */     
/*     */     T current;
/*     */ 
/*     */     
/*     */     boolean valueReady = false;
/*     */ 
/*     */     
/*     */     T nextElement;
/*     */ 
/*     */     
/*     */     Throwable hasNextFailure;
/*     */ 
/*     */ 
/*     */     
/*     */     IterableSubscriptionConditional(Fuseable.ConditionalSubscriber<? super T> actual, Spliterator<? extends T> spliterator, boolean knownToBeFinite, @Nullable Runnable onClose) {
/* 581 */       this.actual = actual;
/* 582 */       this.spliterator = spliterator;
/* 583 */       this.knownToBeFinite = knownToBeFinite;
/* 584 */       this.onClose = onClose;
/*     */     }
/*     */ 
/*     */     
/*     */     IterableSubscriptionConditional(Fuseable.ConditionalSubscriber<? super T> actual, Spliterator<? extends T> spliterator, boolean knownToBeFinite) {
/* 589 */       this(actual, spliterator, knownToBeFinite, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(T t) {
/* 594 */       this.valueReady = true;
/* 595 */       this.nextElement = t;
/*     */     }
/*     */     
/*     */     boolean hasNext() {
/* 599 */       if (!this.valueReady)
/* 600 */         this.spliterator.tryAdvance(this); 
/* 601 */       return this.valueReady;
/*     */     }
/*     */     
/*     */     T next() {
/* 605 */       if (!this.valueReady && !hasNext()) {
/* 606 */         throw new NoSuchElementException();
/*     */       }
/* 608 */       this.valueReady = false;
/* 609 */       T t = this.nextElement;
/* 610 */       this.nextElement = null;
/* 611 */       return t;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 617 */       if (Operators.validate(n) && 
/* 618 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/* 619 */         if (n == Long.MAX_VALUE) {
/* 620 */           fastPath();
/*     */         } else {
/*     */           
/* 623 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void onCloseWithDropError() {
/* 630 */       if (this.onClose != null) {
/*     */         try {
/* 632 */           this.onClose.run();
/*     */         }
/* 634 */         catch (Throwable t) {
/* 635 */           Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     void slowPath(long n) {
/* 641 */       Fuseable.ConditionalSubscriber<? super T> s = this.actual;
/*     */       
/* 643 */       long e = 0L;
/*     */ 
/*     */       
/*     */       while (true) {
/* 647 */         while (e != n) {
/*     */           T t;
/*     */           boolean b;
/*     */           try {
/* 651 */             t = Objects.requireNonNull(next(), "The iterator returned a null value");
/*     */           
/*     */           }
/* 654 */           catch (Throwable ex) {
/* 655 */             s.onError(ex);
/* 656 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 660 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 664 */           boolean consumed = s.tryOnNext(t);
/*     */           
/* 666 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 673 */             b = hasNext();
/*     */           }
/* 675 */           catch (Throwable ex) {
/* 676 */             s.onError(ex);
/* 677 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 681 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 685 */           if (!b) {
/* 686 */             s.onComplete();
/* 687 */             onCloseWithDropError();
/*     */             
/*     */             return;
/*     */           } 
/* 691 */           if (consumed) {
/* 692 */             e++;
/*     */           }
/*     */         } 
/*     */         
/* 696 */         n = this.requested;
/*     */         
/* 698 */         if (n == e) {
/* 699 */           n = REQUESTED.addAndGet(this, -e);
/* 700 */           if (n == 0L) {
/*     */             return;
/*     */           }
/* 703 */           e = 0L;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void fastPath() {
/* 709 */       Fuseable.ConditionalSubscriber<? super T> s = this.actual;
/*     */       while (true) {
/*     */         T t;
/*     */         boolean b;
/* 713 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 720 */           t = Objects.requireNonNull(next(), "The iterator returned a null value");
/*     */         
/*     */         }
/* 723 */         catch (Exception ex) {
/* 724 */           s.onError(ex);
/* 725 */           onCloseWithDropError();
/*     */           
/*     */           return;
/*     */         } 
/* 729 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 733 */         s.tryOnNext(t);
/*     */         
/* 735 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 742 */           b = hasNext();
/*     */         }
/* 744 */         catch (Exception ex) {
/* 745 */           s.onError(ex);
/* 746 */           onCloseWithDropError();
/*     */           
/*     */           return;
/*     */         } 
/* 750 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 754 */         if (!b) {
/* 755 */           s.onComplete();
/* 756 */           onCloseWithDropError();
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 764 */       onCloseWithDropError();
/* 765 */       this.cancelled = true;
/* 766 */       Operators.onDiscard(this.nextElement, this.actual.currentContext());
/* 767 */       Operators.onDiscardMultiple(this.spliterator, this.knownToBeFinite, this.actual.currentContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 772 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 778 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 779 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 780 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.state == 2)); 
/* 781 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 783 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 788 */       Operators.onDiscard(this.nextElement, this.actual.currentContext());
/* 789 */       Operators.onDiscardMultiple(this.spliterator, this.knownToBeFinite, this.actual.currentContext());
/* 790 */       this.state = 2;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/*     */       boolean hasNext;
/* 795 */       int s = this.state;
/* 796 */       if (s == 2) {
/* 797 */         return true;
/*     */       }
/* 799 */       if (this.cancelled && !this.knownToBeFinite) {
/* 800 */         return true;
/*     */       }
/* 802 */       if (s == 1 || s == 0) {
/* 803 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 808 */         hasNext = hasNext();
/*     */       }
/* 810 */       catch (Throwable t) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 815 */         this.state = 0;
/* 816 */         this.hasNextFailure = t;
/* 817 */         return false;
/*     */       } 
/*     */       
/* 820 */       if (hasNext) {
/* 821 */         this.state = 0;
/* 822 */         return false;
/*     */       } 
/* 824 */       this.state = 2;
/* 825 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 832 */       if (this.hasNextFailure != null) {
/* 833 */         this.state = 2;
/* 834 */         throw Exceptions.propagate(this.hasNextFailure);
/*     */       } 
/* 836 */       if (!isEmpty()) {
/*     */         T c;
/* 838 */         if (this.state == 0) {
/* 839 */           c = next();
/*     */         } else {
/*     */           
/* 842 */           c = this.current;
/* 843 */           this.current = null;
/*     */         } 
/* 845 */         this.state = 3;
/* 846 */         return c;
/*     */       } 
/* 848 */       onCloseWithDropError();
/* 849 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 854 */       if (this.state == 2) {
/* 855 */         return 0;
/*     */       }
/* 857 */       return 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */