/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.Queue;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Supplier;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParallelConcatMap<T, R>
/*    */   extends ParallelFlux<R>
/*    */   implements Scannable
/*    */ {
/*    */   final ParallelFlux<T> source;
/*    */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*    */   final Supplier<? extends Queue<T>> queueSupplier;
/*    */   final int prefetch;
/*    */   final FluxConcatMap.ErrorMode errorMode;
/*    */   
/*    */   ParallelConcatMap(ParallelFlux<T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, Supplier<? extends Queue<T>> queueSupplier, int prefetch, FluxConcatMap.ErrorMode errorMode) {
/* 53 */     this.source = source;
/* 54 */     this.mapper = Objects.<Function<? super T, ? extends Publisher<? extends R>>>requireNonNull(mapper, "mapper");
/* 55 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/* 56 */     this.prefetch = prefetch;
/* 57 */     this.errorMode = Objects.<FluxConcatMap.ErrorMode>requireNonNull(errorMode, "errorMode");
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 63 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 64 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 65 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf((this.errorMode != FluxConcatMap.ErrorMode.IMMEDIATE)); 
/* 66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 68 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 73 */     return this.prefetch;
/*    */   }
/*    */ 
/*    */   
/*    */   public int parallelism() {
/* 78 */     return this.source.parallelism();
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super R>[] subscribers) {
/* 83 */     if (!validate((Subscriber<?>[])subscribers)) {
/*    */       return;
/*    */     }
/*    */     
/* 87 */     int n = subscribers.length;
/*    */ 
/*    */     
/* 90 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*    */     
/* 92 */     for (int i = 0; i < n; i++) {
/* 93 */       arrayOfCoreSubscriber[i] = FluxConcatMap.subscriber(subscribers[i], this.mapper, this.queueSupplier, this.prefetch, this.errorMode);
/*    */     }
/*    */ 
/*    */     
/* 97 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ParallelConcatMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */