/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxAutoConnect<T>
/*    */   extends Flux<T>
/*    */   implements Scannable
/*    */ {
/*    */   final ConnectableFlux<? extends T> source;
/*    */   final Consumer<? super Disposable> cancelSupport;
/*    */   volatile int remaining;
/* 45 */   static final AtomicIntegerFieldUpdater<FluxAutoConnect> REMAINING = AtomicIntegerFieldUpdater.newUpdater(FluxAutoConnect.class, "remaining");
/*    */ 
/*    */ 
/*    */   
/*    */   FluxAutoConnect(ConnectableFlux<? extends T> source, int n, Consumer<? super Disposable> cancelSupport) {
/* 50 */     if (n <= 0) {
/* 51 */       throw new IllegalArgumentException("n > required but it was " + n);
/*    */     }
/* 53 */     this.source = Objects.<ConnectableFlux<? extends T>>requireNonNull(source, "source");
/* 54 */     this.cancelSupport = Objects.<Consumer<? super Disposable>>requireNonNull(cancelSupport, "cancelSupport");
/* 55 */     REMAINING.lazySet(this, n);
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 60 */     this.source.subscribe(actual);
/* 61 */     if (this.remaining > 0 && REMAINING.decrementAndGet(this) == 0) {
/* 62 */       this.source.connect(this.cancelSupport);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 68 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 74 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 75 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 76 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.remaining); 
/* 77 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 79 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxAutoConnect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */