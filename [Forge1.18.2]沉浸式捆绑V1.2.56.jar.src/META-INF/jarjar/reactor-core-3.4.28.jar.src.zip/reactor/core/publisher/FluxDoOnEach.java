/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDoOnEach<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Consumer<? super Signal<T>> onSignal;
/*     */   
/*     */   FluxDoOnEach(Flux<? extends T> source, Consumer<? super Signal<T>> onSignal) {
/*  47 */     super(source);
/*  48 */     this.onSignal = Objects.<Consumer<? super Signal<T>>>requireNonNull(onSignal, "onSignal");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> DoOnEachSubscriber<T> createSubscriber(CoreSubscriber<? super T> actual, Consumer<? super Signal<T>> onSignal, boolean fuseable, boolean isMono) {
/*  54 */     if (fuseable) {
/*  55 */       if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  56 */         return new DoOnEachFuseableConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, onSignal, isMono);
/*     */       }
/*  58 */       return new DoOnEachFuseableSubscriber<>(actual, onSignal, isMono);
/*     */     } 
/*     */     
/*  61 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  62 */       return new DoOnEachConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, onSignal, isMono);
/*     */     }
/*  64 */     return new DoOnEachSubscriber<>(actual, onSignal, isMono);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  69 */     return createSubscriber(actual, this.onSignal, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  74 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  75 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static class DoOnEachSubscriber<T>
/*     */     implements InnerOperator<T, T>, Signal<T>
/*     */   {
/*     */     static final short STATE_FLUX_START = 0;
/*     */     
/*     */     static final short STATE_MONO_START = 1;
/*     */     
/*     */     static final short STATE_SKIP_HANDLER = 2;
/*     */     
/*     */     static final short STATE_DONE = 3;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final Context cachedContext;
/*     */     final Consumer<? super Signal<T>> onSignal;
/*     */     T t;
/*     */     Subscription s;
/*     */     @Nullable
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     short state;
/*     */     
/*     */     DoOnEachSubscriber(CoreSubscriber<? super T> actual, Consumer<? super Signal<T>> onSignal, boolean monoFlavor) {
/* 100 */       this.actual = actual;
/* 101 */       this.cachedContext = actual.currentContext();
/* 102 */       this.onSignal = onSignal;
/* 103 */       this.state = monoFlavor ? 1 : 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 108 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 113 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 118 */       if (Operators.validate(this.s, s)) {
/* 119 */         this.s = s;
/* 120 */         this.qs = Operators.as(s);
/* 121 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 127 */       return this.cachedContext;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 133 */       if (key == Scannable.Attr.PARENT) {
/* 134 */         return this.s;
/*     */       }
/* 136 */       if (key == Scannable.Attr.TERMINATED) {
/* 137 */         return Boolean.valueOf((this.state == 3));
/*     */       }
/* 139 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 140 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 143 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 148 */       if (this.state == 3) {
/* 149 */         Operators.onNextDropped(t, this.cachedContext);
/*     */         return;
/*     */       } 
/*     */       try {
/* 153 */         this.t = t;
/* 154 */         this.onSignal.accept(this);
/*     */       }
/* 156 */       catch (Throwable e) {
/* 157 */         onError(Operators.onOperatorError(this.s, e, t, this.cachedContext));
/*     */         
/*     */         return;
/*     */       } 
/* 161 */       if (this.state == 1) {
/* 162 */         this.state = 2;
/*     */         try {
/* 164 */           this.onSignal.accept(Signal.complete(this.cachedContext));
/*     */         }
/* 166 */         catch (Throwable e) {
/* 167 */           this.state = 1;
/* 168 */           onError(Operators.onOperatorError(this.s, e, this.cachedContext));
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 173 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 178 */       if (this.state == 3) {
/* 179 */         Operators.onErrorDropped(t, this.cachedContext);
/*     */         return;
/*     */       } 
/* 182 */       boolean applyHandler = (this.state < 2);
/* 183 */       this.state = 3;
/* 184 */       if (applyHandler) {
/*     */         try {
/* 186 */           this.onSignal.accept(Signal.error(t, this.cachedContext));
/*     */         }
/* 188 */         catch (Throwable e) {
/*     */           
/* 190 */           t = Operators.onOperatorError(null, e, t, this.cachedContext);
/*     */         } 
/*     */       }
/*     */       
/*     */       try {
/* 195 */         this.actual.onError(t);
/*     */       }
/* 197 */       catch (UnsupportedOperationException use) {
/* 198 */         if (!Exceptions.isErrorCallbackNotImplemented(use) && use.getCause() != t) {
/* 199 */           throw use;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 207 */       if (this.state == 3) {
/*     */         return;
/*     */       }
/* 210 */       short oldState = this.state;
/* 211 */       this.state = 3;
/* 212 */       if (oldState < 2) {
/*     */         try {
/* 214 */           this.onSignal.accept(Signal.complete(this.cachedContext));
/*     */         }
/* 216 */         catch (Throwable e) {
/* 217 */           this.state = oldState;
/* 218 */           onError(Operators.onOperatorError(this.s, e, this.cachedContext));
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/* 223 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 228 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Throwable getThrowable() {
/* 234 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Subscription getSubscription() {
/* 240 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T get() {
/* 246 */       return this.t;
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextView getContextView() {
/* 251 */       return (ContextView)this.cachedContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public SignalType getType() {
/* 256 */       return SignalType.ON_NEXT;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 261 */       return "doOnEach_onNext(" + this.t + ")";
/*     */     }
/*     */   }
/*     */   
/*     */   static class DoOnEachFuseableSubscriber<T>
/*     */     extends DoOnEachSubscriber<T>
/*     */     implements Fuseable, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     int fusionMode;
/*     */     
/*     */     DoOnEachFuseableSubscriber(CoreSubscriber<? super T> actual, Consumer<? super Signal<T>> onSignal, boolean isMono) {
/* 272 */       super(actual, onSignal, isMono);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 277 */       if (this.fusionMode == 2) {
/* 278 */         this.actual.onNext(null);
/*     */         return;
/*     */       } 
/* 281 */       super.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int mode) {
/* 286 */       Fuseable.QueueSubscription<T> qs = this.qs;
/* 287 */       if (qs != null && (mode & 0x4) == 0) {
/* 288 */         int m = qs.requestFusion(mode);
/* 289 */         if (m == 1 || m == 2) {
/* 290 */           this.fusionMode = m;
/* 291 */           return m;
/*     */         } 
/*     */       } 
/* 294 */       this.fusionMode = 0;
/* 295 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 300 */       this.qs.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 305 */       return (this.qs == null || this.qs.isEmpty());
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 311 */       if (this.qs == null) {
/* 312 */         return null;
/*     */       }
/* 314 */       T v = (T)this.qs.poll();
/* 315 */       if (v == null && this.fusionMode == 1) {
/* 316 */         this.state = 3;
/*     */         try {
/* 318 */           this.onSignal.accept(Signal.complete(this.cachedContext));
/*     */         }
/* 320 */         catch (Throwable e) {
/* 321 */           throw e;
/*     */         } 
/* 323 */       } else if (v != null) {
/* 324 */         this.t = v;
/* 325 */         this.onSignal.accept(this);
/*     */       } 
/* 327 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 332 */       return (this.qs == null) ? 0 : this.qs.size();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class DoOnEachConditionalSubscriber<T>
/*     */     extends DoOnEachSubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     DoOnEachConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, Consumer<? super Signal<T>> onSignal, boolean isMono) {
/* 341 */       super((CoreSubscriber<? super T>)actual, onSignal, isMono);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 347 */       boolean result = ((Fuseable.ConditionalSubscriber)this.actual).tryOnNext(t);
/* 348 */       if (result) {
/* 349 */         this.t = t;
/* 350 */         this.onSignal.accept(this);
/*     */       } 
/*     */ 
/*     */       
/* 354 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class DoOnEachFuseableConditionalSubscriber<T>
/*     */     extends DoOnEachFuseableSubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     DoOnEachFuseableConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, Consumer<? super Signal<T>> onSignal, boolean isMono) {
/* 363 */       super((CoreSubscriber<? super T>)actual, onSignal, isMono);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 369 */       boolean result = ((Fuseable.ConditionalSubscriber)this.actual).tryOnNext(t);
/* 370 */       if (result) {
/* 371 */         this.t = t;
/* 372 */         this.onSignal.accept(this);
/*     */       } 
/*     */       
/* 375 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxDoOnEach.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */