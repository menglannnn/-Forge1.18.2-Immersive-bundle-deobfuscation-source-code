/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NextProcessor<O>
/*     */   extends MonoProcessor<O>
/*     */ {
/*     */   final boolean isRefCounted;
/*     */   volatile NextInner<O>[] subscribers;
/*  52 */   static final AtomicReferenceFieldUpdater<NextProcessor, NextInner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(NextProcessor.class, (Class)NextInner[].class, "subscribers");
/*     */ 
/*     */   
/*  55 */   static final NextInner[] EMPTY = new NextInner[0];
/*     */ 
/*     */   
/*  58 */   static final NextInner[] TERMINATED = new NextInner[0];
/*     */ 
/*     */   
/*  61 */   static final NextInner[] EMPTY_WITH_SOURCE = new NextInner[0];
/*     */ 
/*     */   
/*     */   volatile Subscription subscription;
/*     */   
/*  66 */   static final AtomicReferenceFieldUpdater<NextProcessor, Subscription> UPSTREAM = AtomicReferenceFieldUpdater.newUpdater(NextProcessor.class, Subscription.class, "subscription");
/*     */   
/*     */   @Nullable
/*     */   CorePublisher<? extends O> source;
/*     */   @Nullable
/*     */   Throwable error;
/*     */   @Nullable
/*     */   O value;
/*     */   
/*     */   NextProcessor(@Nullable CorePublisher<? extends O> source) {
/*  76 */     this(source, false);
/*     */   }
/*     */   
/*     */   NextProcessor(@Nullable CorePublisher<? extends O> source, boolean isRefCounted) {
/*  80 */     this.source = source;
/*  81 */     this.isRefCounted = isRefCounted;
/*  82 */     SUBSCRIBERS.lazySet(this, (source != null) ? EMPTY_WITH_SOURCE : EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public O peek() {
/*  87 */     if (!isTerminated()) {
/*  88 */       return null;
/*     */     }
/*     */     
/*  91 */     if (this.value != null) {
/*  92 */       return this.value;
/*     */     }
/*     */     
/*  95 */     if (this.error != null) {
/*  96 */       RuntimeException re = Exceptions.propagate(this.error);
/*  97 */       re = Exceptions.addSuppressed(re, new Exception("Mono#peek terminated with an error"));
/*  98 */       throw re;
/*     */     } 
/*     */     
/* 101 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public O block(@Nullable Duration timeout) {
/*     */     try {
/*     */       long delay;
/* 108 */       if (isTerminated()) {
/* 109 */         return peek();
/*     */       }
/*     */       
/* 112 */       connect();
/*     */ 
/*     */       
/* 115 */       if (null == timeout) {
/* 116 */         delay = 0L;
/*     */       } else {
/*     */         
/* 119 */         delay = System.nanoTime() + timeout.toNanos();
/*     */       } 
/*     */       while (true) {
/* 122 */         if (isTerminated()) {
/* 123 */           if (this.error != null) {
/* 124 */             RuntimeException re = Exceptions.propagate(this.error);
/* 125 */             re = Exceptions.addSuppressed(re, new Exception("Mono#block terminated with an error"));
/* 126 */             throw re;
/*     */           } 
/* 128 */           return this.value;
/*     */         } 
/* 130 */         if (timeout != null && delay < System.nanoTime()) {
/* 131 */           cancel();
/* 132 */           throw new IllegalStateException("Timeout on Mono blocking read");
/*     */         } 
/*     */         
/* 135 */         Thread.sleep(1L);
/*     */       }
/*     */     
/*     */     }
/* 139 */     catch (InterruptedException ie) {
/* 140 */       Thread.currentThread()
/* 141 */         .interrupt();
/*     */       
/* 143 */       throw new IllegalStateException("Thread Interruption on Mono blocking read");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 150 */     Sinks.EmitResult emitResult = tryEmitValue(null);
/*     */   }
/*     */   void emitEmpty(Sinks.EmitFailureHandler failureHandler) {
/*     */     Sinks.EmitResult emitResult;
/*     */     while (true) {
/* 155 */       emitResult = tryEmitValue(null);
/* 156 */       if (emitResult.isSuccess()) {
/*     */         return;
/*     */       }
/*     */       
/* 160 */       boolean shouldRetry = failureHandler.onEmitFailure(SignalType.ON_COMPLETE, emitResult);
/*     */       
/* 162 */       if (shouldRetry)
/*     */         continue; 
/*     */       break;
/*     */     } 
/* 166 */     switch (emitResult) {
/*     */       case FAIL_ZERO_SUBSCRIBER:
/*     */       case FAIL_OVERFLOW:
/*     */       case FAIL_CANCELLED:
/*     */       case FAIL_TERMINATED:
/*     */         return;
/*     */       case FAIL_NON_SERIALIZED:
/* 173 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*     */     } 
/*     */ 
/*     */     
/* 177 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onError(Throwable cause) {
/*     */     Sinks.EmitResult emitResult;
/*     */     while (true) {
/* 185 */       emitResult = tryEmitError(cause);
/* 186 */       if (emitResult.isSuccess()) {
/*     */         return;
/*     */       }
/*     */       
/* 190 */       boolean shouldRetry = Sinks.EmitFailureHandler.FAIL_FAST.onEmitFailure(SignalType.ON_ERROR, emitResult);
/*     */       
/* 192 */       if (shouldRetry)
/*     */         continue; 
/*     */       break;
/*     */     } 
/* 196 */     switch (emitResult) {
/*     */       case FAIL_ZERO_SUBSCRIBER:
/*     */       case FAIL_OVERFLOW:
/*     */       case FAIL_CANCELLED:
/*     */         return;
/*     */       case FAIL_TERMINATED:
/* 202 */         Operators.onErrorDropped(cause, currentContext());
/*     */         return;
/*     */       case FAIL_NON_SERIALIZED:
/* 205 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*     */     } 
/*     */ 
/*     */     
/* 209 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Sinks.EmitResult tryEmitError(Throwable cause) {
/* 216 */     Objects.requireNonNull(cause, "onError cannot be null");
/*     */     
/* 218 */     if (UPSTREAM.getAndSet(this, Operators.cancelledSubscription()) == Operators.cancelledSubscription()) {
/* 219 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 222 */     this.error = cause;
/* 223 */     this.value = null;
/* 224 */     this.source = null;
/*     */ 
/*     */     
/* 227 */     for (NextInner<O> as : (NextInner[])SUBSCRIBERS.getAndSet(this, TERMINATED)) {
/* 228 */       as.onError(cause);
/*     */     }
/* 230 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */   
/*     */   public final void onNext(@Nullable O value) {
/*     */     Sinks.EmitResult emitResult;
/* 235 */     if (value == null) {
/* 236 */       emitEmpty(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       
/*     */       return;
/*     */     } 
/*     */     while (true) {
/* 241 */       emitResult = tryEmitValue(value);
/* 242 */       if (emitResult.isSuccess()) {
/*     */         return;
/*     */       }
/*     */       
/* 246 */       boolean shouldRetry = Sinks.EmitFailureHandler.FAIL_FAST.onEmitFailure(SignalType.ON_NEXT, emitResult);
/*     */       
/* 248 */       if (shouldRetry)
/*     */         continue; 
/*     */       break;
/*     */     } 
/* 252 */     switch (emitResult) {
/*     */       case FAIL_ZERO_SUBSCRIBER:
/*     */         return;
/*     */ 
/*     */       
/*     */       case FAIL_OVERFLOW:
/* 258 */         Operators.onDiscard(value, currentContext());
/*     */         
/* 260 */         onError(Exceptions.failWithOverflow("Backpressure overflow during Sinks.Many#emitNext"));
/*     */         return;
/*     */       case FAIL_CANCELLED:
/* 263 */         Operators.onDiscard(value, currentContext());
/*     */         return;
/*     */       case FAIL_TERMINATED:
/* 266 */         Operators.onNextDropped(value, currentContext());
/*     */         return;
/*     */       case FAIL_NON_SERIALIZED:
/* 269 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*     */     } 
/*     */ 
/*     */     
/* 273 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Sinks.EmitResult tryEmitValue(@Nullable O value) {
/*     */     Subscription s;
/* 280 */     if ((s = UPSTREAM.getAndSet(this, Operators.cancelledSubscription())) == Operators.cancelledSubscription()) {
/* 281 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 284 */     this.value = value;
/* 285 */     CorePublisher<? extends O> corePublisher = this.source;
/* 286 */     this.source = null;
/*     */     
/* 288 */     NextInner[] arrayOfNextInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/*     */     
/* 290 */     if (value == null) {
/* 291 */       for (NextInner<O> as : arrayOfNextInner) {
/* 292 */         as.onComplete();
/*     */       }
/*     */     } else {
/*     */       
/* 296 */       if (s != null && !(corePublisher instanceof Mono)) {
/* 297 */         s.cancel();
/*     */       }
/*     */       
/* 300 */       for (NextInner<O> as : arrayOfNextInner) {
/* 301 */         as.complete(value);
/*     */       }
/*     */     } 
/* 304 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 309 */     if (key == Scannable.Attr.PARENT)
/* 310 */       return this.subscription; 
/* 311 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 316 */     return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   public long downstreamCount() {
/* 321 */     return this.subscribers.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 327 */     Subscription s = UPSTREAM.getAndSet(this, Operators.cancelledSubscription());
/* 328 */     if (s == Operators.cancelledSubscription()) {
/*     */       return;
/*     */     }
/*     */     
/* 332 */     this.source = null;
/* 333 */     if (s != null) {
/* 334 */       s.cancel();
/*     */     }
/*     */     
/*     */     NextInner[] arrayOfNextInner;
/*     */     
/* 339 */     if ((arrayOfNextInner = SUBSCRIBERS.getAndSet(this, TERMINATED)) != TERMINATED) {
/* 340 */       Exception e = new CancellationException("Disposed");
/* 341 */       this.error = e;
/* 342 */       this.value = null;
/*     */       
/* 344 */       for (NextInner<O> as : arrayOfNextInner) {
/* 345 */         as.onError(e);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 354 */     if (isTerminated()) {
/*     */       return;
/*     */     }
/*     */     
/* 358 */     Subscription s = UPSTREAM.getAndSet(this, Operators.cancelledSubscription());
/* 359 */     if (s == Operators.cancelledSubscription()) {
/*     */       return;
/*     */     }
/*     */     
/* 363 */     this.source = null;
/* 364 */     if (s != null) {
/* 365 */       s.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription subscription) {
/* 371 */     if (Operators.setOnce(UPSTREAM, this, subscription)) {
/* 372 */       subscription.request(Long.MAX_VALUE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCancelled() {
/* 380 */     return (this.subscription == Operators.cancelledSubscription() && !isTerminated());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 385 */     return (this.subscribers == TERMINATED);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getError() {
/* 391 */     return this.error;
/*     */   }
/*     */   
/*     */   boolean add(NextInner<O> ps) {
/*     */     while (true) {
/* 396 */       NextInner<O>[] a = this.subscribers;
/*     */       
/* 398 */       if (a == TERMINATED) {
/* 399 */         return false;
/*     */       }
/*     */       
/* 402 */       int n = a.length;
/* 403 */       NextInner[] arrayOfNextInner = new NextInner[n + 1];
/* 404 */       System.arraycopy(a, 0, arrayOfNextInner, 0, n);
/* 405 */       arrayOfNextInner[n] = ps;
/*     */       
/* 407 */       if (SUBSCRIBERS.compareAndSet(this, a, arrayOfNextInner)) {
/* 408 */         CorePublisher<? extends O> corePublisher = this.source;
/* 409 */         if (corePublisher != null && a == EMPTY_WITH_SOURCE) {
/* 410 */           corePublisher.subscribe((Subscriber)this);
/*     */         }
/* 412 */         return true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void remove(NextInner<O> ps) {
/*     */     while (true) {
/*     */       NextInner[] arrayOfNextInner;
/* 420 */       NextInner<O>[] a = this.subscribers;
/* 421 */       int n = a.length;
/* 422 */       if (n == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 426 */       int j = -1;
/* 427 */       for (int i = 0; i < n; i++) {
/* 428 */         if (a[i] == ps) {
/* 429 */           j = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 434 */       if (j < 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 439 */       boolean disconnect = false;
/* 440 */       if (n == 1) {
/* 441 */         if (this.isRefCounted && this.source != null) {
/* 442 */           arrayOfNextInner = EMPTY_WITH_SOURCE;
/* 443 */           disconnect = true;
/*     */         } else {
/*     */           
/* 446 */           arrayOfNextInner = EMPTY;
/*     */         } 
/*     */       } else {
/*     */         
/* 450 */         arrayOfNextInner = new NextInner[n - 1];
/* 451 */         System.arraycopy(a, 0, arrayOfNextInner, 0, j);
/* 452 */         System.arraycopy(a, j + 1, arrayOfNextInner, j, n - j - 1);
/*     */       } 
/* 454 */       if (SUBSCRIBERS.compareAndSet(this, a, arrayOfNextInner)) {
/* 455 */         if (disconnect) {
/* 456 */           Subscription oldSubscription = UPSTREAM.getAndSet(this, null);
/* 457 */           if (oldSubscription != null) {
/* 458 */             oldSubscription.cancel();
/*     */           }
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super O> actual) {
/* 468 */     NextInner<O> as = new NextInner<>(actual, this);
/* 469 */     actual.onSubscribe(as);
/* 470 */     if (add(as)) {
/* 471 */       if (as.isCancelled()) {
/* 472 */         remove(as);
/*     */       }
/*     */     } else {
/*     */       
/* 476 */       Throwable ex = this.error;
/* 477 */       if (ex != null) {
/* 478 */         actual.onError(ex);
/*     */       } else {
/*     */         
/* 481 */         O v = this.value;
/* 482 */         if (v != null) {
/* 483 */           as.complete(v);
/*     */         } else {
/*     */           
/* 486 */           as.onComplete();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 494 */     return Stream.of((Scannable[])this.subscribers);
/*     */   }
/*     */   
/*     */   void connect() {
/* 498 */     CorePublisher<? extends O> corePublisher = this.source;
/* 499 */     if (corePublisher != null && SUBSCRIBERS.compareAndSet(this, EMPTY_WITH_SOURCE, EMPTY))
/* 500 */       corePublisher.subscribe((Subscriber)this); 
/*     */   }
/*     */   
/*     */   static final class NextInner<T>
/*     */     extends Operators.MonoSubscriber<T, T> {
/*     */     final NextProcessor<T> parent;
/*     */     
/*     */     NextInner(CoreSubscriber<? super T> actual, NextProcessor<T> parent) {
/* 508 */       super(actual);
/* 509 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 514 */       if (STATE.getAndSet(this, 4) != 4) {
/* 515 */         this.parent.remove(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 521 */       if (!isCancelled()) {
/* 522 */         this.actual.onComplete();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 528 */       if (!isCancelled()) {
/* 529 */         this.actual.onError(t);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 535 */       if (key == Scannable.Attr.PARENT) {
/* 536 */         return this.parent;
/*     */       }
/* 538 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 539 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 541 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\NextProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */