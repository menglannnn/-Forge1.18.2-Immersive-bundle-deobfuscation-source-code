/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxHandleFuseable<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final BiConsumer<? super T, SynchronousSink<R>> handler;
/*     */   
/*     */   FluxHandleFuseable(Flux<? extends T> source, BiConsumer<? super T, SynchronousSink<R>> handler) {
/*  54 */     super(source);
/*  55 */     this.handler = Objects.<BiConsumer<? super T, SynchronousSink<R>>>requireNonNull(handler, "handler");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  60 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*     */       
/*  62 */       Fuseable.ConditionalSubscriber<? super R> cs = (Fuseable.ConditionalSubscriber<? super R>)actual;
/*  63 */       return new HandleFuseableConditionalSubscriber<>(cs, this.handler);
/*     */     } 
/*  65 */     return new HandleFuseableSubscriber<>(actual, this.handler);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  70 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  71 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class HandleFuseableSubscriber<T, R>
/*     */     implements InnerOperator<T, R>, Fuseable.ConditionalSubscriber<T>, Fuseable.QueueSubscription<R>, SynchronousSink<R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final BiConsumer<? super T, SynchronousSink<R>> handler;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     boolean stop;
/*     */     
/*     */     Throwable error;
/*     */     
/*     */     R data;
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     int sourceMode;
/*     */     
/*     */     HandleFuseableSubscriber(CoreSubscriber<? super R> actual, BiConsumer<? super T, SynchronousSink<R>> handler) {
/*  93 */       this.actual = actual;
/*  94 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Context currentContext() {
/* 100 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextView contextView() {
/* 105 */       return (ContextView)this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 110 */       if (this.done) {
/* 111 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 112 */         return true;
/*     */       } 
/*     */       
/*     */       try {
/* 116 */         this.handler.accept(t, this);
/*     */       }
/* 118 */       catch (Throwable e) {
/* 119 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 120 */         if (e_ != null) {
/* 121 */           onError(e_);
/* 122 */           return true;
/*     */         } 
/*     */         
/* 125 */         reset();
/* 126 */         return false;
/*     */       } 
/*     */       
/* 129 */       R v = this.data;
/* 130 */       this.data = null;
/* 131 */       if (v != null) {
/* 132 */         this.actual.onNext(v);
/*     */       }
/* 134 */       if (this.stop) {
/* 135 */         if (this.error != null) {
/* 136 */           Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), (Subscription)this.s);
/* 137 */           if (e_ != null) {
/* 138 */             this.done = true;
/* 139 */             this.actual.onError(e_);
/*     */           } else {
/*     */             
/* 142 */             reset();
/* 143 */             return false;
/*     */           } 
/*     */         } else {
/*     */           
/* 147 */           this.done = true;
/* 148 */           this.s.cancel();
/* 149 */           this.actual.onComplete();
/*     */         } 
/* 151 */         return true;
/*     */       } 
/* 153 */       return (v != null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 159 */       if (Operators.validate((Subscription)this.s, s)) {
/* 160 */         this.s = (Fuseable.QueueSubscription<T>)s;
/* 161 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 167 */       if (this.sourceMode == 2) {
/* 168 */         this.actual.onNext(null);
/*     */       } else {
/*     */         
/* 171 */         if (this.done) {
/* 172 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           return;
/*     */         } 
/*     */         try {
/* 176 */           this.handler.accept(t, this);
/*     */         }
/* 178 */         catch (Throwable e) {
/* 179 */           Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 180 */           if (e_ != null) {
/* 181 */             onError(e_);
/*     */           } else {
/*     */             
/* 184 */             this.s.request(1L);
/*     */           } 
/*     */           return;
/*     */         } 
/* 188 */         R v = this.data;
/* 189 */         this.data = null;
/* 190 */         if (v != null) {
/* 191 */           this.actual.onNext(v);
/*     */         }
/* 193 */         if (this.stop) {
/* 194 */           if (this.error != null) {
/* 195 */             Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), (Subscription)this.s);
/* 196 */             if (e_ != null) {
/* 197 */               this.done = true;
/* 198 */               this.actual.onError(e_);
/*     */             } else {
/*     */               
/* 201 */               reset();
/* 202 */               this.s.request(1L);
/*     */             } 
/*     */           } else {
/*     */             
/* 206 */             this.done = true;
/* 207 */             this.s.cancel();
/* 208 */             this.actual.onComplete();
/*     */           }
/*     */         
/* 211 */         } else if (v == null) {
/* 212 */           this.s.request(1L);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 219 */       if (this.done) {
/* 220 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 224 */       this.done = true;
/*     */       
/* 226 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 231 */       if (this.done) {
/*     */         return;
/*     */       }
/* 234 */       this.done = true;
/*     */       
/* 236 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 242 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 243 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 244 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 245 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 247 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 252 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 257 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 262 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R poll() {
/* 268 */       if (this.sourceMode == 2) {
/* 269 */         if (this.done) {
/* 270 */           return null;
/*     */         }
/* 272 */         long dropped = 0L;
/*     */         while (true) {
/* 274 */           T v = (T)this.s.poll();
/*     */           
/* 276 */           if (v != null) {
/*     */             try {
/* 278 */               this.handler.accept(v, this);
/*     */             }
/* 280 */             catch (Throwable error) {
/* 281 */               RuntimeException e_ = Operators.onNextPollError(v, error, this.actual.currentContext());
/* 282 */               if (e_ != null) {
/* 283 */                 throw e_;
/*     */               }
/*     */               
/* 286 */               reset();
/*     */               
/*     */               continue;
/*     */             } 
/* 290 */             R u = this.data;
/* 291 */             this.data = null;
/* 292 */             if (this.stop) {
/* 293 */               if (this.error != null) {
/* 294 */                 RuntimeException e_ = Operators.onNextPollError(v, this.error, this.actual.currentContext());
/* 295 */                 if (e_ != null) {
/* 296 */                   this.done = true;
/* 297 */                   throw e_;
/*     */                 }
/*     */               
/*     */               } else {
/*     */                 
/* 302 */                 this.done = true;
/* 303 */                 this.s.cancel();
/* 304 */                 this.actual.onComplete();
/*     */               } 
/* 306 */               return u;
/*     */             } 
/* 308 */             if (u != null) {
/* 309 */               return u;
/*     */             }
/* 311 */             dropped++; continue;
/*     */           } 
/* 313 */           if (dropped != 0L) {
/* 314 */             request(dropped);
/* 315 */             dropped = 0L; continue;
/*     */           }  break;
/*     */         } 
/* 318 */         return null;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 324 */         T v = (T)this.s.poll();
/* 325 */         if (v != null) {
/*     */           try {
/* 327 */             this.handler.accept(v, this);
/*     */           }
/* 329 */           catch (Throwable error) {
/* 330 */             RuntimeException e_ = Operators.onNextPollError(v, error, this.actual.currentContext());
/* 331 */             if (e_ != null) {
/* 332 */               throw e_;
/*     */             }
/*     */             
/* 335 */             reset();
/*     */             
/*     */             continue;
/*     */           } 
/* 339 */           R u = this.data;
/* 340 */           this.data = null;
/* 341 */           if (this.stop) {
/* 342 */             if (this.error != null) {
/* 343 */               RuntimeException e_ = Operators.onNextPollError(v, this.error, this.actual.currentContext());
/* 344 */               if (e_ != null) {
/* 345 */                 this.done = true;
/* 346 */                 throw e_;
/*     */               } 
/*     */               
/* 349 */               reset();
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 354 */             this.done = true;
/* 355 */             return u;
/*     */           } 
/*     */           
/* 358 */           if (u != null)
/* 359 */             return u;  continue;
/*     */         } 
/*     */         break;
/*     */       } 
/* 363 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void reset() {
/* 370 */       this.done = false;
/* 371 */       this.stop = false;
/* 372 */       this.error = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 377 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 382 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 388 */       if ((requestedMode & 0x4) != 0) {
/* 389 */         return 0;
/*     */       }
/*     */       
/* 392 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 394 */       this.sourceMode = m;
/* 395 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 400 */       return this.s.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public void complete() {
/* 405 */       if (this.stop) {
/* 406 */         throw new IllegalStateException("Cannot complete after a complete or error");
/*     */       }
/* 408 */       this.stop = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable e) {
/* 413 */       if (this.stop) {
/* 414 */         throw new IllegalStateException("Cannot error after a complete or error");
/*     */       }
/* 416 */       this.error = Objects.<Throwable>requireNonNull(e, "error");
/* 417 */       this.stop = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void next(R o) {
/* 422 */       if (this.data != null) {
/* 423 */         throw new IllegalStateException("Cannot emit more than one data");
/*     */       }
/* 425 */       if (this.stop) {
/* 426 */         throw new IllegalStateException("Cannot emit after a complete or error");
/*     */       }
/* 428 */       this.data = Objects.requireNonNull(o, "data");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class HandleFuseableConditionalSubscriber<T, R>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, R>, Fuseable.QueueSubscription<R>, SynchronousSink<R>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super R> actual;
/*     */     
/*     */     final BiConsumer<? super T, SynchronousSink<R>> handler;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     boolean stop;
/*     */     
/*     */     Throwable error;
/*     */     R data;
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     int sourceMode;
/*     */     
/*     */     HandleFuseableConditionalSubscriber(Fuseable.ConditionalSubscriber<? super R> actual, BiConsumer<? super T, SynchronousSink<R>> handler) {
/* 450 */       this.actual = actual;
/* 451 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Context currentContext() {
/* 457 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextView contextView() {
/* 462 */       return (ContextView)this.actual.currentContext();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 468 */       if (Operators.validate((Subscription)this.s, s)) {
/* 469 */         this.s = (Fuseable.QueueSubscription<T>)s;
/* 470 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 477 */       if (this.sourceMode == 2) {
/* 478 */         this.actual.onNext(null);
/*     */       } else {
/*     */         
/* 481 */         if (this.done) {
/* 482 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           return;
/*     */         } 
/*     */         try {
/* 486 */           this.handler.accept(t, this);
/*     */         }
/* 488 */         catch (Throwable e) {
/* 489 */           Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 490 */           if (e_ != null) {
/* 491 */             onError(e_);
/*     */           } else {
/*     */             
/* 494 */             reset();
/* 495 */             this.s.request(1L);
/*     */           } 
/*     */           return;
/*     */         } 
/* 499 */         R v = this.data;
/* 500 */         this.data = null;
/* 501 */         if (v != null) {
/* 502 */           this.actual.onNext(v);
/*     */         }
/* 504 */         if (this.stop) {
/* 505 */           if (this.error != null) {
/* 506 */             Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), (Subscription)this.s);
/* 507 */             if (e_ != null) {
/* 508 */               this.done = true;
/* 509 */               this.actual.onError(e_);
/*     */             } else {
/*     */               
/* 512 */               reset();
/* 513 */               this.s.request(1L);
/*     */             } 
/*     */           } else {
/*     */             
/* 517 */             this.done = true;
/* 518 */             this.s.cancel();
/* 519 */             this.actual.onComplete();
/*     */           }
/*     */         
/* 522 */         } else if (v == null) {
/* 523 */           this.s.request(1L);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void reset() {
/* 529 */       this.done = false;
/* 530 */       this.stop = false;
/* 531 */       this.error = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 536 */       if (this.done) {
/* 537 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 538 */         return true;
/*     */       } 
/*     */       
/*     */       try {
/* 542 */         this.handler.accept(t, this);
/*     */       }
/* 544 */       catch (Throwable e) {
/* 545 */         Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), (Subscription)this.s);
/* 546 */         if (e_ != null) {
/* 547 */           onError(e_);
/* 548 */           return true;
/*     */         } 
/*     */         
/* 551 */         reset();
/* 552 */         return false;
/*     */       } 
/*     */       
/* 555 */       R v = this.data;
/* 556 */       this.data = null;
/* 557 */       boolean emit = false;
/* 558 */       if (v != null) {
/* 559 */         emit = this.actual.tryOnNext(v);
/*     */       }
/* 561 */       if (this.stop) {
/* 562 */         if (this.error != null) {
/* 563 */           Throwable e_ = Operators.onNextError(t, this.error, this.actual.currentContext(), (Subscription)this.s);
/* 564 */           if (e_ != null) {
/* 565 */             this.done = true;
/* 566 */             this.actual.onError(e_);
/*     */           } else {
/*     */             
/* 569 */             reset();
/* 570 */             return false;
/*     */           } 
/*     */         } else {
/*     */           
/* 574 */           this.done = true;
/* 575 */           this.s.cancel();
/* 576 */           this.actual.onComplete();
/*     */         } 
/* 578 */         return true;
/*     */       } 
/* 580 */       return emit;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 585 */       if (this.done) {
/* 586 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 590 */       this.done = true;
/*     */       
/* 592 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 597 */       if (this.done) {
/*     */         return;
/*     */       }
/* 600 */       this.done = true;
/*     */       
/* 602 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void complete() {
/* 607 */       if (this.stop) {
/* 608 */         throw new IllegalStateException("Cannot complete after a complete or error");
/*     */       }
/* 610 */       this.stop = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable e) {
/* 615 */       if (this.stop) {
/* 616 */         throw new IllegalStateException("Cannot error after a complete or error");
/*     */       }
/* 618 */       this.error = Objects.<Throwable>requireNonNull(e, "error");
/* 619 */       this.stop = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void next(R o) {
/* 624 */       if (this.data != null) {
/* 625 */         throw new IllegalStateException("Cannot emit more than one data");
/*     */       }
/* 627 */       if (this.stop) {
/* 628 */         throw new IllegalStateException("Cannot emit after a complete or error");
/*     */       }
/* 630 */       this.data = Objects.requireNonNull(o, "data");
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 636 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 637 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 638 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 639 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 641 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 646 */       return (CoreSubscriber<? super R>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 651 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 656 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R poll() {
/* 662 */       if (this.sourceMode == 2) {
/* 663 */         if (this.done) {
/* 664 */           return null;
/*     */         }
/* 666 */         long dropped = 0L;
/*     */         while (true) {
/* 668 */           T v = (T)this.s.poll();
/*     */           
/* 670 */           if (v != null) {
/*     */             try {
/* 672 */               this.handler.accept(v, this);
/*     */             }
/* 674 */             catch (Throwable error) {
/* 675 */               RuntimeException e_ = Operators.onNextPollError(v, error, this.actual.currentContext());
/* 676 */               if (e_ != null) {
/* 677 */                 throw e_;
/*     */               }
/*     */               
/* 680 */               reset();
/*     */               
/*     */               continue;
/*     */             } 
/* 684 */             R u = this.data;
/* 685 */             this.data = null;
/* 686 */             if (this.stop) {
/* 687 */               if (this.error != null) {
/* 688 */                 Throwable e_ = Operators.onNextError(v, this.error, this.actual.currentContext(), (Subscription)this.s);
/* 689 */                 if (e_ != null) {
/* 690 */                   this.done = true;
/* 691 */                   throw Exceptions.propagate(e_);
/*     */                 } 
/*     */                 
/* 694 */                 reset();
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 699 */               this.done = true;
/* 700 */               this.s.cancel();
/* 701 */               this.actual.onComplete();
/*     */               
/* 703 */               return u;
/*     */             } 
/* 705 */             if (u != null) {
/* 706 */               return u;
/*     */             }
/* 708 */             dropped++; continue;
/*     */           } 
/* 710 */           if (dropped != 0L) {
/* 711 */             request(dropped);
/* 712 */             dropped = 0L; continue;
/*     */           }  break;
/*     */         } 
/* 715 */         return null;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 721 */         T v = (T)this.s.poll();
/* 722 */         if (v != null) {
/*     */           try {
/* 724 */             this.handler.accept(v, this);
/*     */           }
/* 726 */           catch (Throwable error) {
/* 727 */             RuntimeException e_ = Operators.onNextPollError(v, error, this.actual.currentContext());
/* 728 */             if (e_ != null) {
/* 729 */               throw e_;
/*     */             }
/*     */             
/* 732 */             reset();
/*     */             
/*     */             continue;
/*     */           } 
/* 736 */           R u = this.data;
/* 737 */           this.data = null;
/* 738 */           if (this.stop) {
/* 739 */             this.done = true;
/* 740 */             if (this.error != null) {
/* 741 */               RuntimeException e_ = Operators.onNextPollError(v, this.error, this.actual.currentContext());
/* 742 */               if (e_ != null) {
/* 743 */                 throw e_;
/*     */               }
/*     */               
/* 746 */               reset();
/*     */               
/*     */               continue;
/*     */             } 
/* 750 */             return u;
/*     */           } 
/* 752 */           if (u != null)
/* 753 */             return u;  continue;
/*     */         } 
/*     */         break;
/*     */       } 
/* 757 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 765 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 770 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 776 */       if ((requestedMode & 0x4) != 0) {
/* 777 */         return 0;
/*     */       }
/*     */       
/* 780 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 782 */       this.sourceMode = m;
/* 783 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 788 */       return this.s.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxHandleFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */