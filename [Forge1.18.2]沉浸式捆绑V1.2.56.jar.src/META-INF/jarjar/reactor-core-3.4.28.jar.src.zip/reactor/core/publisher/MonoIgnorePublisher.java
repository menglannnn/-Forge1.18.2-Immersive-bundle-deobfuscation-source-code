/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CorePublisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoIgnorePublisher<T>
/*    */   extends Mono<T>
/*    */   implements Scannable, OptimizableOperator<T, T>
/*    */ {
/*    */   final Publisher<? extends T> source;
/*    */   @Nullable
/*    */   final OptimizableOperator<?, T> optimizableOperator;
/*    */   
/*    */   MonoIgnorePublisher(Publisher<? extends T> source) {
/* 43 */     this.source = Objects.<Publisher<? extends T>>requireNonNull(source, "publisher");
/* 44 */     if (source instanceof OptimizableOperator) {
/*    */       
/* 46 */       OptimizableOperator<?, T> optimSource = (OptimizableOperator)source;
/* 47 */       this.optimizableOperator = optimSource;
/*    */     } else {
/*    */       
/* 50 */       this.optimizableOperator = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/*    */     try {
/* 57 */       this.source.subscribe((Subscriber)subscribeOrReturn(actual));
/*    */     }
/* 59 */     catch (Throwable e) {
/* 60 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*    */       return;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public final CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) throws Throwable {
/* 67 */     return new MonoIgnoreElements.IgnoreElementsSubscriber<>(actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CorePublisher<? extends T> source() {
/* 72 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final OptimizableOperator<?, ? extends T> nextOptimizableSource() {
/* 77 */     return this.optimizableOperator;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 83 */     if (key == Scannable.Attr.PARENT) {
/* 84 */       return this.source;
/*    */     }
/* 86 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 87 */       return Scannable.Attr.RunStyle.SYNC;
/*    */     }
/* 89 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoIgnorePublisher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */