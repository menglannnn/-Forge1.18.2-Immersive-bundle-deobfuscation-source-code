/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxSwitchIfEmpty<T>
/*    */   extends InternalFluxOperator<T, T>
/*    */ {
/*    */   final Publisher<? extends T> other;
/*    */   
/*    */   FluxSwitchIfEmpty(Flux<? extends T> source, Publisher<? extends T> other) {
/* 36 */     super(source);
/* 37 */     this.other = Objects.<Publisher<? extends T>>requireNonNull(other, "other");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 42 */     SwitchIfEmptySubscriber<T> parent = new SwitchIfEmptySubscriber<>(actual, this.other);
/*    */     
/* 44 */     actual.onSubscribe(parent);
/*    */     
/* 46 */     return parent;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 51 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 52 */     return super.scanUnsafe(key);
/*    */   }
/*    */ 
/*    */   
/*    */   static final class SwitchIfEmptySubscriber<T>
/*    */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*    */   {
/*    */     final Publisher<? extends T> other;
/*    */     
/*    */     boolean once;
/*    */     
/*    */     SwitchIfEmptySubscriber(CoreSubscriber<? super T> actual, Publisher<? extends T> other) {
/* 64 */       super(actual);
/* 65 */       this.other = other;
/*    */     }
/*    */ 
/*    */     
/*    */     public void onNext(T t) {
/* 70 */       if (!this.once) {
/* 71 */         this.once = true;
/*    */       }
/*    */       
/* 74 */       this.actual.onNext(t);
/*    */     }
/*    */ 
/*    */     
/*    */     public void onComplete() {
/* 79 */       if (!this.once) {
/* 80 */         this.once = true;
/*    */         
/* 82 */         this.other.subscribe((Subscriber)this);
/*    */       } else {
/*    */         
/* 85 */         this.actual.onComplete();
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     public Object scanUnsafe(Scannable.Attr key) {
/* 91 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 92 */       return super.scanUnsafe(key);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxSwitchIfEmpty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */