/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.stream.Stream;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Disposables;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.core.scheduler.Scheduler;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.concurrent.Queues;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class FluxWindowTimeout<T>
/*      */   extends InternalFluxOperator<T, Flux<T>>
/*      */ {
/*      */   final int maxSize;
/*      */   final long timespan;
/*      */   final TimeUnit unit;
/*      */   final Scheduler timer;
/*      */   final boolean fairBackpressure;
/*      */   
/*      */   FluxWindowTimeout(Flux<T> source, int maxSize, long timespan, TimeUnit unit, Scheduler timer, boolean fairBackpressure) {
/*   56 */     super(source);
/*   57 */     if (timespan <= 0L) {
/*   58 */       throw new IllegalArgumentException("Timeout period must be strictly positive");
/*      */     }
/*   60 */     if (maxSize <= 0) {
/*   61 */       throw new IllegalArgumentException("maxSize must be strictly positive");
/*      */     }
/*   63 */     this.fairBackpressure = fairBackpressure;
/*   64 */     this.timer = Objects.<Scheduler>requireNonNull(timer, "Timer");
/*   65 */     this.timespan = timespan;
/*   66 */     this.unit = Objects.<TimeUnit>requireNonNull(unit, "unit");
/*   67 */     this.maxSize = maxSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Flux<T>> actual) {
/*   72 */     if (this.fairBackpressure) {
/*   73 */       return new WindowTimeoutWithBackpressureSubscriber<>(actual, this.maxSize, this.timespan, this.unit, this.timer, null);
/*      */     }
/*   75 */     return new WindowTimeoutSubscriber<>(actual, this.maxSize, this.timespan, this.unit, this.timer);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/*   80 */     if (key == Scannable.Attr.RUN_ON) {
/*   81 */       return this.timer;
/*      */     }
/*   83 */     if (key == Scannable.Attr.RUN_STYLE) {
/*   84 */       return Scannable.Attr.RunStyle.ASYNC;
/*      */     }
/*      */     
/*   87 */     return super.scanUnsafe(key);
/*      */   }
/*      */ 
/*      */   
/*      */   static final class WindowTimeoutWithBackpressureSubscriber<T>
/*      */     implements InnerOperator<T, Flux<T>>
/*      */   {
/*      */     @Nullable
/*      */     final StateLogger logger;
/*      */     
/*      */     final CoreSubscriber<? super Flux<T>> actual;
/*      */     
/*      */     final long timespan;
/*      */     
/*      */     final TimeUnit unit;
/*      */     final Scheduler scheduler;
/*      */     final int maxSize;
/*      */     final Scheduler.Worker worker;
/*      */     final int limit;
/*      */     volatile long requested;
/*  107 */     static final AtomicLongFieldUpdater<WindowTimeoutWithBackpressureSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(WindowTimeoutWithBackpressureSubscriber.class, "requested");
/*      */ 
/*      */     
/*      */     volatile long state;
/*      */ 
/*      */     
/*  113 */     static final AtomicLongFieldUpdater<WindowTimeoutWithBackpressureSubscriber> STATE = AtomicLongFieldUpdater.newUpdater(WindowTimeoutWithBackpressureSubscriber.class, "state");
/*      */ 
/*      */     
/*      */     static final long CANCELLED_FLAG = -9223372036854775808L;
/*      */ 
/*      */     
/*      */     static final long TERMINATED_FLAG = 4611686018427387904L;
/*      */ 
/*      */     
/*      */     static final long HAS_UNSENT_WINDOW = 2305843009213693952L;
/*      */     
/*      */     static final long HAS_WORK_IN_PROGRESS = 1152921504606846976L;
/*      */     
/*      */     static final long REQUEST_INDEX_MASK = 1152920405095219200L;
/*      */     
/*      */     static final long ACTIVE_WINDOW_INDEX_MASK = 1099510579200L;
/*      */     
/*      */     static final long NEXT_WINDOW_INDEX_MASK = 1048575L;
/*      */     
/*      */     static final int ACTIVE_WINDOW_INDEX_SHIFT = 20;
/*      */     
/*      */     static final int REQUEST_INDEX_SHIFT = 40;
/*      */     
/*      */     boolean done;
/*      */     
/*      */     Throwable error;
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     FluxWindowTimeout.InnerWindow<T> window;
/*      */ 
/*      */     
/*      */     WindowTimeoutWithBackpressureSubscriber(CoreSubscriber<? super Flux<T>> actual, int maxSize, long timespan, TimeUnit unit, Scheduler scheduler, @Nullable StateLogger logger) {
/*  146 */       this.actual = actual;
/*  147 */       this.timespan = timespan;
/*  148 */       this.unit = unit;
/*  149 */       this.scheduler = scheduler;
/*  150 */       this.maxSize = maxSize;
/*  151 */       this.limit = Operators.unboundedOrLimit(maxSize);
/*  152 */       this.worker = scheduler.createWorker();
/*  153 */       this.logger = logger;
/*      */       
/*  155 */       STATE.lazySet(this, 1L);
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super Flux<T>> actual() {
/*  160 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  165 */       if (Operators.validate(this.s, s)) {
/*  166 */         this.s = s;
/*      */         
/*  168 */         this.actual.onSubscribe(this);
/*      */       } 
/*      */     }
/*      */     
/*      */     public void onNext(T t) {
/*      */       FluxWindowTimeout.InnerWindow<T> window;
/*  174 */       if (this.done) {
/*  175 */         Operators.onNextDropped(t, this.actual.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*      */       do {
/*  180 */         if (isCancelled(this.state)) {
/*  181 */           Operators.onDiscard(t, this.actual.currentContext());
/*      */           
/*      */           return;
/*      */         } 
/*  185 */         window = this.window;
/*  186 */       } while (!window.sendNext(t));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  194 */       if (this.done) {
/*  195 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  199 */       this.error = t;
/*  200 */       this.done = true;
/*      */       
/*  202 */       long previousState = markTerminated(this);
/*      */       
/*  204 */       if (isCancelled(previousState) || isTerminated(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  208 */       FluxWindowTimeout.InnerWindow<T> window = this.window;
/*  209 */       if (window != null) {
/*  210 */         window.sendError(t);
/*      */         
/*  212 */         if (hasUnsentWindow(previousState)) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */       
/*  217 */       if (hasWorkInProgress(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  221 */       this.actual.onError(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  226 */       if (this.done) {
/*      */         return;
/*      */       }
/*      */       
/*  230 */       this.done = true;
/*      */ 
/*      */       
/*  233 */       long previousState = markTerminated(this);
/*      */       
/*  235 */       if (isCancelled(previousState) || isTerminated(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  239 */       FluxWindowTimeout.InnerWindow<T> window = this.window;
/*  240 */       if (window != null) {
/*  241 */         window.sendComplete();
/*      */         
/*  243 */         if (hasUnsentWindow(previousState)) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */       
/*  248 */       if (hasWorkInProgress(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  252 */       this.actual.onComplete();
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/*  257 */       long previousRequested = Operators.addCap(REQUESTED, this, n);
/*  258 */       if (previousRequested == Long.MAX_VALUE) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*  266 */         long previousState = this.state;
/*      */         
/*  268 */         if (isCancelled(previousState)) {
/*      */           return;
/*      */         }
/*      */         
/*  272 */         if (hasWorkInProgress(previousState)) {
/*  273 */           long nextState = previousState & 0xF00000FFFFFFFFFFL | incrementRequestIndex(previousState);
/*  274 */           if (STATE.compareAndSet(this, previousState, nextState)) {
/*  275 */             if (this.logger != null) {
/*  276 */               this.logger.log(toString(), "mre", previousState, nextState);
/*      */             }
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           continue;
/*      */         } 
/*  284 */         boolean hasUnsentWindow = hasUnsentWindow(previousState);
/*      */         
/*  286 */         if (!hasUnsentWindow && (isTerminated(previousState) || activeWindowIndex(previousState) == nextWindowIndex(previousState))) {
/*      */           return;
/*      */         }
/*      */         
/*  290 */         long expectedState = previousState & 0xDFFFFFFFFFFFFFFFL | 0x1000000000000000L;
/*      */ 
/*      */         
/*  293 */         if (STATE.compareAndSet(this, previousState, expectedState)) {
/*  294 */           if (this.logger != null) {
/*  295 */             this.logger.log(toString(), "mre", previousState, expectedState);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  301 */           drain(previousState, expectedState);
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } void tryCreateNextWindow(int windowIndex) {
/*      */       long previousState, expectedState;
/*      */       boolean hasWorkInProgress;
/*      */       do {
/*  309 */         previousState = this.state;
/*      */         
/*  311 */         if (isCancelled(previousState)) {
/*      */           return;
/*      */         }
/*      */         
/*  315 */         if (nextWindowIndex(previousState) != windowIndex) {
/*      */           return;
/*      */         }
/*      */         
/*  319 */         hasWorkInProgress = hasWorkInProgress(previousState);
/*  320 */         if (!hasWorkInProgress && isTerminated(previousState) && !hasUnsentWindow(previousState)) {
/*      */           return;
/*      */         }
/*      */         
/*  324 */         expectedState = previousState & 0xFFFFFFFFFFF00000L | incrementNextWindowIndex(previousState) | 0x1000000000000000L;
/*  325 */       } while (!STATE.compareAndSet(this, previousState, expectedState));
/*      */       
/*  327 */       if (hasWorkInProgress) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  335 */       drain(previousState, expectedState);
/*      */     }
/*      */     
/*      */     void drain(long previousState, long expectedState) {
/*      */       while (true) {
/*  340 */         long n = this.requested;
/*  341 */         if (this.logger != null) {
/*  342 */           this.logger.log(toString(), "dr" + n, previousState, expectedState);
/*      */         }
/*      */ 
/*      */         
/*  346 */         boolean hasUnsentWindow = hasUnsentWindow(previousState);
/*      */         
/*  348 */         int activeWindowIndex = activeWindowIndex(expectedState);
/*  349 */         int nextWindowIndex = nextWindowIndex(expectedState);
/*      */ 
/*      */ 
/*      */         
/*  353 */         if (activeWindowIndex == nextWindowIndex && !hasUnsentWindow) {
/*  354 */           expectedState = markWorkDone(this, expectedState);
/*  355 */           previousState = expectedState | 0x1000000000000000L;
/*      */           
/*  357 */           if (isCancelled(expectedState)) {
/*      */             return;
/*      */           }
/*      */           
/*  361 */           if (isTerminated(expectedState)) {
/*  362 */             Throwable e = this.error;
/*  363 */             if (e != null) {
/*  364 */               this.actual.onError(e);
/*      */             } else {
/*      */               
/*  367 */               this.actual.onComplete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  373 */           if (!hasWorkInProgress(expectedState)) {
/*      */             return;
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  380 */         if (n > 0L) {
/*      */           long nextRequest;
/*  382 */           if (hasUnsentWindow) {
/*  383 */             FluxWindowTimeout.InnerWindow<T> currentUnsentWindow = this.window;
/*      */ 
/*      */             
/*  386 */             this.actual.onNext(currentUnsentWindow);
/*      */             
/*  388 */             if (n != Long.MAX_VALUE) {
/*  389 */               n = REQUESTED.decrementAndGet(this);
/*  390 */               if (this.logger != null) {
/*  391 */                 this.logger.log(toString(), "dec", n, n);
/*      */               }
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  397 */             long previousInnerWindowState = currentUnsentWindow.sendSent();
/*      */             
/*  399 */             if (isTerminated(expectedState)) {
/*  400 */               Throwable e = this.error;
/*  401 */               if (e != null) {
/*  402 */                 if (!isTerminated(previousInnerWindowState)) {
/*  403 */                   currentUnsentWindow.sendError(e);
/*      */                 }
/*  405 */                 this.actual.onError(e);
/*      */               } else {
/*      */                 
/*  408 */                 if (!isTerminated(previousInnerWindowState)) {
/*  409 */                   currentUnsentWindow.sendComplete();
/*      */                 }
/*  411 */                 this.actual.onComplete();
/*      */               } 
/*      */ 
/*      */               
/*      */               return;
/*      */             } 
/*      */ 
/*      */             
/*  419 */             if (nextWindowIndex > activeWindowIndex && (FluxWindowTimeout.InnerWindow.isTimeout(previousInnerWindowState) || FluxWindowTimeout.InnerWindow.isTerminated(previousInnerWindowState))) {
/*  420 */               boolean shouldBeUnsent = (n == 0L);
/*  421 */               FluxWindowTimeout.InnerWindow<T> innerWindow = new FluxWindowTimeout.InnerWindow<>(this.maxSize, this, nextWindowIndex, shouldBeUnsent, this.logger);
/*      */ 
/*      */ 
/*      */               
/*  425 */               this.window = innerWindow;
/*      */               
/*  427 */               if (!shouldBeUnsent) {
/*  428 */                 this.actual.onNext(innerWindow);
/*      */                 
/*  430 */                 if (n != Long.MAX_VALUE) {
/*  431 */                   REQUESTED.decrementAndGet(this);
/*      */                 }
/*      */               } 
/*      */               
/*  435 */               previousState = commitWork(this, expectedState, shouldBeUnsent);
/*      */ 
/*      */               
/*  438 */               expectedState = previousState & 0xFFFFFF00000FFFFFL & 0xDFFFFFFFFFFFFFFFL ^ ((expectedState == previousState) ? 1152921504606846976L : 0L) | incrementActiveWindowIndex(previousState) | (shouldBeUnsent ? 2305843009213693952L : 0L);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  443 */               previousState = previousState & 0xDFFFFFFFFFFFFFFFL | (shouldBeUnsent ? 2305843009213693952L : 0L);
/*      */               
/*  445 */               if (isCancelled(expectedState)) {
/*  446 */                 innerWindow.sendCancel();
/*  447 */                 if (shouldBeUnsent) {
/*  448 */                   innerWindow.cancel();
/*      */                 }
/*      */                 
/*      */                 return;
/*      */               } 
/*  453 */               if (isTerminated(expectedState) && !shouldBeUnsent) {
/*  454 */                 Throwable e = this.error;
/*  455 */                 if (e != null) {
/*  456 */                   innerWindow.sendError(e);
/*  457 */                   this.actual.onError(e);
/*      */                 } else {
/*      */                   
/*  460 */                   innerWindow.sendComplete();
/*  461 */                   this.actual.onComplete();
/*      */                 } 
/*      */                 
/*      */                 return;
/*      */               } 
/*      */               try {
/*  467 */                 innerWindow.scheduleTimeout();
/*      */               }
/*  469 */               catch (Exception e) {
/*  470 */                 if (hasWorkInProgress(expectedState)) {
/*  471 */                   this.actual.onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*      */                 } else {
/*      */                   
/*  474 */                   onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*      */                 } 
/*      */                 
/*      */                 return;
/*      */               } 
/*      */               
/*  480 */               long l = FluxWindowTimeout.InnerWindow.received(previousInnerWindowState);
/*  481 */               if (l > 0L) {
/*  482 */                 this.s.request(l);
/*      */               }
/*      */ 
/*      */               
/*  486 */               if (!hasWorkInProgress(expectedState))
/*      */                 return; 
/*      */               continue;
/*      */             } 
/*  490 */             previousState = commitSent(this, expectedState);
/*  491 */             expectedState = previousState & 0xDFFFFFFFFFFFFFFFL ^ ((expectedState == previousState) ? 1152921504606846976L : 0L);
/*  492 */             previousState &= 0xDFFFFFFFFFFFFFFFL;
/*      */             
/*  494 */             if (isCancelled(expectedState)) {
/*      */               return;
/*      */             }
/*      */             
/*  498 */             if (isTerminated(expectedState)) {
/*  499 */               Throwable e = this.error;
/*  500 */               if (e != null) {
/*  501 */                 this.actual.onError(e);
/*      */               } else {
/*      */                 
/*  504 */                 this.actual.onComplete();
/*      */               } 
/*      */               
/*      */               return;
/*      */             } 
/*  509 */             if (!hasWorkInProgress(expectedState)) {
/*      */               return;
/*      */             }
/*      */             continue;
/*      */           } 
/*  514 */           FluxWindowTimeout.InnerWindow<T> nextWindow = new FluxWindowTimeout.InnerWindow<>(this.maxSize, this, nextWindowIndex, false, this.logger);
/*      */ 
/*      */ 
/*      */           
/*  518 */           FluxWindowTimeout.InnerWindow<T> previousWindow = this.window;
/*      */           
/*  520 */           this.window = nextWindow;
/*      */           
/*  522 */           this.actual.onNext(nextWindow);
/*      */           
/*  524 */           if (n != Long.MAX_VALUE) {
/*  525 */             REQUESTED.decrementAndGet(this);
/*      */           }
/*      */           
/*  528 */           previousState = commitWork(this, expectedState, false);
/*      */ 
/*      */           
/*  531 */           expectedState = previousState & 0xFFFFFF00000FFFFFL & 0xDFFFFFFFFFFFFFFFL ^ ((expectedState == previousState) ? 1152921504606846976L : 0L) | incrementActiveWindowIndex(previousState);
/*      */           
/*  533 */           if (isCancelled(expectedState)) {
/*  534 */             previousWindow.sendCancel();
/*  535 */             nextWindow.sendCancel();
/*      */             
/*      */             return;
/*      */           } 
/*  539 */           if (isTerminated(expectedState)) {
/*  540 */             Throwable e = this.error;
/*  541 */             if (e != null) {
/*  542 */               previousWindow.sendError(e);
/*  543 */               nextWindow.sendError(e);
/*  544 */               this.actual.onError(e);
/*      */             } else {
/*      */               
/*  547 */               previousWindow.sendComplete();
/*  548 */               nextWindow.sendComplete();
/*  549 */               this.actual.onComplete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*      */           try {
/*  555 */             nextWindow.scheduleTimeout();
/*      */           }
/*  557 */           catch (Exception e) {
/*  558 */             if (hasWorkInProgress(expectedState)) {
/*  559 */               this.actual.onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*      */             } else {
/*      */               
/*  562 */               onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*      */             } 
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  569 */           if (previousWindow == null) {
/*      */             
/*  571 */             nextRequest = this.maxSize;
/*      */           } else {
/*      */             
/*  574 */             long previousActiveWindowState = previousWindow.sendComplete();
/*  575 */             nextRequest = FluxWindowTimeout.InnerWindow.received(previousActiveWindowState);
/*      */           } 
/*      */           
/*  578 */           if (nextRequest > 0L) {
/*  579 */             this.s.request(nextRequest);
/*      */           }
/*      */           
/*  582 */           if (!hasWorkInProgress(expectedState)) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */         } 
/*  587 */         if (n == 0L && !hasUnsentWindow) {
/*  588 */           FluxWindowTimeout.InnerWindow<T> nextWindow = new FluxWindowTimeout.InnerWindow<>(this.maxSize, this, nextWindowIndex, true, this.logger);
/*      */ 
/*      */           
/*  591 */           FluxWindowTimeout.InnerWindow<T> previousWindow = this.window;
/*  592 */           this.window = nextWindow;
/*      */ 
/*      */ 
/*      */           
/*  596 */           previousState = commitWork(this, expectedState, true);
/*      */ 
/*      */           
/*  599 */           expectedState = previousState & 0xFFFFFF00000FFFFFL & 0xDFFFFFFFFFFFFFFFL ^ ((expectedState == previousState) ? 1152921504606846976L : 0L) | incrementActiveWindowIndex(previousState) | 0x2000000000000000L;
/*      */           
/*  601 */           previousState |= 0x2000000000000000L;
/*      */           
/*  603 */           if (isCancelled(expectedState)) {
/*  604 */             previousWindow.sendCancel();
/*  605 */             nextWindow.sendCancel();
/*  606 */             nextWindow.cancel();
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */ 
/*      */           
/*      */           try {
/*  614 */             nextWindow.scheduleTimeout();
/*      */           }
/*  616 */           catch (Exception e) {
/*  617 */             if (hasWorkInProgress(expectedState)) {
/*  618 */               this.actual.onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*      */             } else {
/*      */               
/*  621 */               onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  627 */           long previousActiveWindowState = previousWindow.sendComplete();
/*  628 */           long nextRequest = FluxWindowTimeout.InnerWindow.received(previousActiveWindowState);
/*      */           
/*  630 */           if (nextRequest > 0L) {
/*  631 */             this.s.request(nextRequest);
/*      */           }
/*      */           
/*  634 */           if (!hasWorkInProgress(expectedState)) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */         } 
/*  639 */         expectedState = markWorkDone(this, expectedState);
/*  640 */         previousState = expectedState | 0x1000000000000000L;
/*      */         
/*  642 */         if (isCancelled(expectedState)) {
/*  643 */           FluxWindowTimeout.InnerWindow<T> currentWindow = this.window;
/*  644 */           long previousWindowState = currentWindow.sendCancel();
/*  645 */           if (!FluxWindowTimeout.InnerWindow.isSent(previousWindowState)) {
/*  646 */             currentWindow.cancel();
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*  651 */         if (isTerminated(expectedState) && !hasUnsentWindow(expectedState)) {
/*  652 */           Throwable e = this.error;
/*  653 */           if (e != null) {
/*  654 */             this.actual.onError(e);
/*      */           } else {
/*      */             
/*  657 */             this.actual.onComplete();
/*      */           } 
/*      */           
/*      */           return;
/*      */         } 
/*  662 */         if (!hasWorkInProgress(expectedState)) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  671 */       long previousState = markCancelled(this);
/*  672 */       if ((!hasWorkInProgress(previousState) && isTerminated(previousState) && !hasUnsentWindow(previousState)) || isCancelled(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  676 */       this.s.cancel();
/*      */       
/*  678 */       FluxWindowTimeout.InnerWindow<T> currentActiveWindow = this.window;
/*  679 */       if (currentActiveWindow != null && 
/*  680 */         !FluxWindowTimeout.InnerWindow.isSent(currentActiveWindow.sendCancel()) && 
/*  681 */         !hasWorkInProgress(previousState)) {
/*  682 */         currentActiveWindow.cancel();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     Disposable schedule(Runnable runnable, long createTime) {
/*  689 */       long delayedNanos = this.scheduler.now(TimeUnit.NANOSECONDS) - createTime;
/*      */       
/*  691 */       long timeSpanInNanos = this.unit.toNanos(this.timespan);
/*  692 */       long newTimeSpanInNanos = timeSpanInNanos - delayedNanos;
/*  693 */       if (newTimeSpanInNanos > 0L) {
/*  694 */         return this.worker.schedule(runnable, this.timespan, this.unit);
/*      */       }
/*  696 */       runnable.run();
/*  697 */       return FluxWindowTimeout.InnerWindow.DISPOSED;
/*      */     }
/*      */ 
/*      */     
/*      */     long now() {
/*  702 */       return this.scheduler.now(TimeUnit.NANOSECONDS);
/*      */     }
/*      */     
/*      */     static boolean hasUnsentWindow(long state) {
/*  706 */       return ((state & 0x2000000000000000L) == 2305843009213693952L);
/*      */     }
/*      */     
/*      */     static boolean isCancelled(long state) {
/*  710 */       return ((state & Long.MIN_VALUE) == Long.MIN_VALUE);
/*      */     }
/*      */     
/*      */     static boolean isTerminated(long state) {
/*  714 */       return ((state & 0x4000000000000000L) == 4611686018427387904L);
/*      */     }
/*      */     
/*      */     static boolean hasWorkInProgress(long state) {
/*  718 */       return ((state & 0x1000000000000000L) == 1152921504606846976L);
/*      */     }
/*      */     
/*      */     static long incrementRequestIndex(long state) {
/*  722 */       return ((state & 0xFFFFF0000000000L) >> 40L) + 1L << 40L & 0xFFFFF0000000000L;
/*      */     }
/*      */     
/*      */     static long incrementActiveWindowIndex(long state) {
/*  726 */       return ((state & 0xFFFFF00000L) >> 20L) + 1L << 20L & 0xFFFFF00000L;
/*      */     }
/*      */     
/*      */     static int activeWindowIndex(long state) {
/*  730 */       return (int)((state & 0xFFFFF00000L) >> 20L);
/*      */     }
/*      */     
/*      */     static long incrementNextWindowIndex(long state) {
/*  734 */       return (state & 0xFFFFFL) + 1L & 0xFFFFFL;
/*      */     }
/*      */     
/*      */     static int nextWindowIndex(long state) {
/*  738 */       return (int)(state & 0xFFFFFL);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static <T> long markTerminated(WindowTimeoutWithBackpressureSubscriber<T> instance) {
/*      */       while (true) {
/*  753 */         long previousState = instance.state;
/*      */         
/*  755 */         if (isTerminated(previousState) || isCancelled(previousState)) {
/*  756 */           return previousState;
/*      */         }
/*      */         
/*  759 */         long nextState = previousState | 0x4000000000000000L;
/*  760 */         if (STATE.compareAndSet(instance, previousState, nextState)) {
/*  761 */           if (instance.logger != null) {
/*  762 */             instance.logger.log(instance.toString(), "mtd", previousState, nextState);
/*      */           }
/*  764 */           return previousState;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static <T> long markCancelled(WindowTimeoutWithBackpressureSubscriber<T> instance) {
/*      */       while (true) {
/*  780 */         long previousState = instance.state;
/*  781 */         if ((!hasWorkInProgress(previousState) && isTerminated(previousState) && !hasUnsentWindow(previousState)) || isCancelled(previousState)) {
/*  782 */           return previousState;
/*      */         }
/*      */         
/*  785 */         long nextState = previousState | Long.MIN_VALUE;
/*  786 */         if (STATE.compareAndSet(instance, previousState, nextState)) {
/*  787 */           return previousState;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static <T> long markWorkDone(WindowTimeoutWithBackpressureSubscriber<T> instance, long expectedState) {
/*      */       while (true) {
/*  802 */         long currentState = instance.state;
/*      */         
/*  804 */         if (expectedState != currentState) {
/*  805 */           if (instance.logger != null) {
/*  806 */             instance.logger.log(instance.toString(), "fwd", currentState, currentState);
/*      */           }
/*  808 */           return currentState;
/*      */         } 
/*      */         
/*  811 */         long nextState = currentState ^ 0x1000000000000000L;
/*  812 */         if (STATE.compareAndSet(instance, currentState, nextState)) {
/*  813 */           if (instance.logger != null) {
/*  814 */             instance.logger.log(instance.toString(), "mwd", currentState, nextState);
/*      */           }
/*  816 */           return nextState;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static <T> long commitSent(WindowTimeoutWithBackpressureSubscriber<T> instance, long expectedState) {
/*      */       while (true) {
/*  832 */         long currentState = instance.state;
/*      */         
/*  834 */         long clearState = currentState & 0xDFFFFFFFFFFFFFFFL;
/*  835 */         long nextState = clearState ^ ((expectedState == currentState) ? 1152921504606846976L : 0L);
/*      */         
/*  837 */         if (STATE.compareAndSet(instance, currentState, nextState)) {
/*  838 */           if (instance.logger != null) {
/*  839 */             instance.logger.log(instance.toString(), "cts", currentState, nextState);
/*      */           }
/*  841 */           return currentState;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static <T> long commitWork(WindowTimeoutWithBackpressureSubscriber<T> instance, long expectedState, boolean setUnsentFlag) {
/*      */       while (true) {
/*  857 */         long currentState = instance.state;
/*      */         
/*  859 */         long clearState = currentState & 0xFFFFFF00000FFFFFL & 0xDFFFFFFFFFFFFFFFL;
/*      */         
/*  861 */         long nextState = clearState ^ ((expectedState == currentState) ? 1152921504606846976L : 0L) | incrementActiveWindowIndex(currentState) | (setUnsentFlag ? 2305843009213693952L : 0L);
/*      */ 
/*      */         
/*  864 */         if (STATE.compareAndSet(instance, currentState, nextState)) {
/*  865 */           if (instance.logger != null) {
/*  866 */             instance.logger.log(instance.toString(), "ctw", currentState, nextState);
/*      */           }
/*  868 */           return currentState;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static final class InnerWindow<T>
/*      */     extends Flux<T>
/*      */     implements InnerProducer<T>, Runnable {
/*  877 */     static final Disposable DISPOSED = Disposables.disposed();
/*      */     
/*      */     @Nullable
/*      */     final StateLogger logger;
/*      */     
/*      */     final FluxWindowTimeout.WindowTimeoutWithBackpressureSubscriber<T> parent;
/*      */     
/*      */     final int max;
/*      */     
/*      */     final Queue<T> queue;
/*      */     
/*      */     final long createTime;
/*      */     
/*      */     final int index;
/*      */     volatile long requested;
/*  892 */     static final AtomicLongFieldUpdater<InnerWindow> REQUESTED = AtomicLongFieldUpdater.newUpdater(InnerWindow.class, "requested");
/*      */ 
/*      */     
/*      */     volatile long state;
/*      */     
/*  897 */     static final AtomicLongFieldUpdater<InnerWindow> STATE = AtomicLongFieldUpdater.newUpdater(InnerWindow.class, "state");
/*      */ 
/*      */     
/*      */     volatile Disposable timer;
/*      */     
/*  902 */     static final AtomicReferenceFieldUpdater<InnerWindow, Disposable> TIMER = AtomicReferenceFieldUpdater.newUpdater(InnerWindow.class, Disposable.class, "timer");
/*      */ 
/*      */     
/*      */     CoreSubscriber<? super T> actual;
/*      */     
/*      */     Throwable error;
/*      */     
/*  909 */     int received = 0;
/*  910 */     int produced = 0; static final long FINALIZED_STATE = -9223372036854775808L; static final long TERMINATED_STATE = 4611686018427387904L; static final long PARENT_CANCELLED_STATE = 2305843009213693952L; static final long CANCELLED_STATE = 1152921504606846976L; static final long TIMEOUT_STATE = 576460752303423488L; static final long HAS_VALUES_STATE = 288230376151711744L; static final long HAS_SUBSCRIBER_STATE = 144115188075855872L;
/*      */     static final long HAS_SUBSCRIBER_SET_STATE = 72057594037927936L;
/*      */     static final long UNSENT_STATE = 36028797018963968L;
/*      */     static final long RECEIVED_MASK = 36028797002186752L;
/*      */     static final long WORK_IN_PROGRESS_MAX = 16777215L;
/*      */     static final long RECEIVED_SHIFT_BITS = 24L;
/*      */     
/*      */     InnerWindow(int max, FluxWindowTimeout.WindowTimeoutWithBackpressureSubscriber<T> parent, int index, boolean markUnsent, @Nullable StateLogger logger) {
/*  918 */       this.max = max;
/*  919 */       this.parent = parent;
/*  920 */       this.queue = Queues.get(max).get();
/*  921 */       this.index = index;
/*  922 */       this.logger = logger;
/*      */       
/*  924 */       if (markUnsent) {
/*  925 */         STATE.lazySet(this, 36028797018963968L);
/*  926 */         if (this.logger != null) {
/*  927 */           this.logger.log(toString(), "mct", 0L, 36028797018963968L);
/*      */         }
/*      */       }
/*  930 */       else if (this.logger != null) {
/*  931 */         this.logger.log(toString(), "mct", 0, 0);
/*      */       } 
/*      */ 
/*      */       
/*  935 */       this.createTime = parent.now();
/*      */     }
/*      */ 
/*      */     
/*      */     public void subscribe(CoreSubscriber<? super T> actual) {
/*  940 */       long previousState = markSubscribedOnce(this);
/*  941 */       if (hasSubscribedOnce(previousState)) {
/*  942 */         Operators.error((Subscriber<?>)actual, new IllegalStateException("Only one subscriber allowed"));
/*      */         
/*      */         return;
/*      */       } 
/*  946 */       this.actual = actual;
/*      */       
/*  948 */       actual.onSubscribe(this);
/*      */       
/*  950 */       previousState = markSubscriberSet(this);
/*  951 */       if (isFinalized(previousState) || hasWorkInProgress(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  955 */       if (!hasValues(previousState) && isTerminated(previousState)) {
/*  956 */         Throwable t = this.error;
/*  957 */         if (t != null) {
/*  958 */           actual.onError(t);
/*      */         } else {
/*  960 */           actual.onComplete();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> actual() {
/*  967 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/*  972 */       Operators.addCap(REQUESTED, this, n);
/*  973 */       long previousState = markHasRequest(this);
/*      */       
/*  975 */       if (hasWorkInProgress(previousState) || isCancelled(previousState) || isFinalized(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  979 */       if (hasValues(previousState)) {
/*  980 */         drain((previousState | 0x100000000000000L) + 1L);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  986 */       long previousState = markCancelled(this);
/*  987 */       if (isCancelled(previousState) || isFinalized(previousState) || hasWorkInProgress(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/*  991 */       clearAndFinalize();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     long sendCancel() {
/*      */       long state;
/*      */       long nextState;
/*      */       do {
/* 1003 */         state = this.state;
/*      */         
/* 1005 */         if (isCancelledByParent(state)) {
/* 1006 */           return state;
/*      */         }
/*      */         
/* 1009 */         long cleanState = state & 0xFFFFFFFFFF000000L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1016 */         nextState = cleanState | 0x4000000000000000L | 0x2000000000000000L | (hasSubscriberSet(state) ? (hasValues(state) ? incrementWork(state & 0xFFFFFFL) : Long.MIN_VALUE) : 0L);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1021 */       while (!STATE.compareAndSet(this, state, nextState));
/*      */       
/* 1023 */       if (isFinalized(state)) {
/* 1024 */         return state;
/*      */       }
/*      */       
/* 1027 */       if (!isTimeout(state)) {
/* 1028 */         Disposable timer = TIMER.getAndSet(this, DISPOSED);
/* 1029 */         if (timer != null) {
/* 1030 */           timer.dispose();
/*      */         }
/*      */       } 
/*      */       
/* 1034 */       if (hasSubscriberSet(state)) {
/* 1035 */         if (hasWorkInProgress(state)) {
/* 1036 */           return state;
/*      */         }
/*      */         
/* 1039 */         if (isCancelled(state)) {
/* 1040 */           clearAndFinalize();
/* 1041 */           return state;
/*      */         } 
/*      */         
/* 1044 */         if (hasValues(state)) {
/* 1045 */           drain(nextState);
/*      */         } else {
/* 1047 */           this.actual.onComplete();
/*      */         } 
/*      */       } 
/*      */       
/* 1051 */       return state;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean sendNext(T t) {
/*      */       long previousState, nextState;
/* 1057 */       int received = this.received + 1;
/* 1058 */       if (received > this.max) {
/* 1059 */         return false;
/*      */       }
/* 1061 */       this.received = received;
/*      */       
/* 1063 */       this.queue.offer(t);
/*      */ 
/*      */ 
/*      */       
/* 1067 */       if (received == this.max) {
/* 1068 */         previousState = markHasValuesAndTerminated(this);
/* 1069 */         nextState = (previousState | 0x4000000000000000L | 0x400000000000000L) + 1L;
/*      */         
/* 1071 */         if (!isTimeout(previousState)) {
/* 1072 */           Disposable timer = TIMER.getAndSet(this, DISPOSED);
/* 1073 */           if (timer != null) {
/* 1074 */             timer.dispose();
/*      */           }
/*      */           
/* 1077 */           if (!isCancelledByParent(previousState)) {
/* 1078 */             this.parent.tryCreateNextWindow(this.index);
/*      */           }
/*      */         } 
/*      */       } else {
/* 1082 */         previousState = markHasValues(this);
/* 1083 */         nextState = (previousState | 0x400000000000000L) + 1L;
/*      */       } 
/*      */       
/* 1086 */       if (isFinalized(previousState)) {
/* 1087 */         if (isCancelledByParent(previousState)) {
/* 1088 */           clearQueue();
/* 1089 */           return true;
/*      */         } 
/* 1091 */         if (isCancelled(previousState)) {
/* 1092 */           clearQueue();
/*      */ 
/*      */           
/* 1095 */           this.parent.s.request(1L);
/* 1096 */           return true;
/*      */         } 
/*      */         
/* 1099 */         if (this.queue.poll() != t) {
/*      */ 
/*      */           
/* 1102 */           this.parent.s.request(1L);
/* 1103 */           return true;
/*      */         } 
/*      */         
/* 1106 */         return false;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1111 */       if (isTimeout(previousState) && isTerminated(previousState))
/*      */       {
/* 1113 */         this.parent.s.request(1L);
/*      */       }
/*      */       
/* 1116 */       if (hasSubscriberSet(previousState)) {
/* 1117 */         if (hasWorkInProgress(previousState)) {
/* 1118 */           return true;
/*      */         }
/*      */         
/* 1121 */         if (isCancelled(previousState)) {
/* 1122 */           clearAndFinalize();
/* 1123 */           return true;
/*      */         } 
/*      */         
/* 1126 */         drain(nextState);
/*      */       } 
/*      */       
/* 1129 */       return true;
/*      */     }
/*      */     
/*      */     long sendComplete() {
/* 1133 */       long previousState = markTerminated(this);
/* 1134 */       if (isFinalized(previousState) || isTerminated(previousState)) {
/* 1135 */         return previousState;
/*      */       }
/*      */       
/* 1138 */       if (!isTimeout(previousState)) {
/* 1139 */         Disposable timer = TIMER.getAndSet(this, DISPOSED);
/*      */         
/* 1141 */         if (timer != null) {
/* 1142 */           timer.dispose();
/*      */         }
/*      */       } 
/*      */       
/* 1146 */       if (hasSubscriberSet(previousState)) {
/* 1147 */         if (hasWorkInProgress(previousState)) {
/* 1148 */           return previousState;
/*      */         }
/*      */         
/* 1151 */         if (isCancelled(previousState)) {
/* 1152 */           clearAndFinalize();
/* 1153 */           return previousState;
/*      */         } 
/*      */         
/* 1156 */         if (hasValues(previousState)) {
/* 1157 */           drain((previousState | 0x4000000000000000L) + 1L);
/*      */         } else {
/* 1159 */           this.actual.onComplete();
/*      */         } 
/*      */       } 
/*      */       
/* 1163 */       return previousState;
/*      */     }
/*      */     
/*      */     long sendError(Throwable error) {
/* 1167 */       this.error = error;
/*      */       
/* 1169 */       long previousState = markTerminated(this);
/* 1170 */       if (isFinalized(previousState) || isTerminated(previousState)) {
/* 1171 */         return previousState;
/*      */       }
/*      */       
/* 1174 */       if (!isTimeout(previousState)) {
/* 1175 */         Disposable timer = TIMER.getAndSet(this, DISPOSED);
/*      */         
/* 1177 */         if (timer != null) {
/* 1178 */           timer.dispose();
/*      */         }
/*      */       } 
/*      */       
/* 1182 */       if (hasSubscriberSet(previousState)) {
/* 1183 */         if (hasWorkInProgress(previousState)) {
/* 1184 */           return previousState;
/*      */         }
/*      */         
/* 1187 */         if (isCancelled(previousState)) {
/* 1188 */           clearAndFinalize();
/* 1189 */           return previousState;
/*      */         } 
/*      */         
/* 1192 */         if (hasValues(previousState)) {
/* 1193 */           drain((previousState | 0x4000000000000000L) + 1L);
/*      */         } else {
/* 1195 */           this.actual.onError(error);
/*      */         } 
/*      */       } 
/*      */       
/* 1199 */       return previousState;
/*      */     }
/*      */     
/*      */     long sendSent() {
/* 1203 */       long previousState = markSent(this);
/* 1204 */       if (isFinalized(previousState) || (!isTerminated(previousState) && !isTimeout(previousState))) {
/* 1205 */         return previousState;
/*      */       }
/*      */       
/* 1208 */       if (hasSubscriberSet(previousState)) {
/* 1209 */         if (hasWorkInProgress(previousState)) {
/* 1210 */           return previousState;
/*      */         }
/*      */         
/* 1213 */         if (isCancelled(previousState)) {
/* 1214 */           clearAndFinalize();
/* 1215 */           return previousState;
/*      */         } 
/*      */         
/* 1218 */         if (hasValues(previousState)) {
/* 1219 */           drain((previousState ^ 0x80000000000000L | 0x4000000000000000L) + 1L);
/*      */         } else {
/* 1221 */           this.actual.onComplete();
/*      */         } 
/*      */       } 
/*      */       
/* 1225 */       return previousState;
/*      */     }
/*      */     
/*      */     void drain(long expectedState) {
/* 1229 */       Queue<T> q = this.queue;
/* 1230 */       CoreSubscriber<? super T> a = this.actual;
/*      */       
/*      */       do {
/* 1233 */         long r = this.requested;
/*      */         
/* 1235 */         int e = 0;
/* 1236 */         boolean empty = false;
/* 1237 */         while (e < r) {
/* 1238 */           T v = q.poll();
/*      */           
/* 1240 */           empty = (v == null);
/* 1241 */           if (checkTerminated(this.produced + e, a, v)) {
/*      */             return;
/*      */           }
/*      */           
/* 1245 */           if (empty) {
/*      */             break;
/*      */           }
/*      */           
/* 1249 */           a.onNext(v);
/*      */           
/* 1251 */           e++;
/*      */         } 
/*      */         
/* 1254 */         this.produced += e;
/*      */         
/* 1256 */         if (checkTerminated(this.produced, a, null)) {
/*      */           return;
/*      */         }
/*      */         
/* 1260 */         if (e != 0 && r != Long.MAX_VALUE) {
/* 1261 */           REQUESTED.addAndGet(this, -e);
/*      */         }
/*      */         
/* 1264 */         expectedState = markWorkDone(this, expectedState, !empty);
/* 1265 */         if (isCancelled(expectedState)) {
/* 1266 */           clearAndFinalize();
/*      */           
/*      */           return;
/*      */         } 
/* 1270 */       } while (hasWorkInProgress(expectedState));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean checkTerminated(int totalProduced, CoreSubscriber<? super T> actual, @Nullable T value) {
/* 1280 */       long state = this.state;
/* 1281 */       if (isCancelled(state)) {
/* 1282 */         if (value != null) {
/* 1283 */           Operators.onDiscard(value, actual.currentContext());
/*      */         }
/* 1285 */         clearAndFinalize();
/* 1286 */         return true;
/*      */       } 
/*      */       
/* 1289 */       if (value == null && received(state) <= totalProduced && isTerminated(state)) {
/* 1290 */         if (!markFinalized(state)) {
/* 1291 */           return false;
/*      */         }
/*      */         
/* 1294 */         Throwable e = this.error;
/* 1295 */         if (e != null) {
/* 1296 */           actual.onError(e);
/*      */         } else {
/*      */           
/* 1299 */           actual.onComplete();
/*      */         } 
/*      */         
/* 1302 */         return true;
/*      */       } 
/*      */       
/* 1305 */       return false;
/*      */     }
/*      */     
/*      */     void scheduleTimeout() {
/* 1309 */       Disposable nextTimer = this.parent.schedule(this, this.createTime);
/* 1310 */       if (!TIMER.compareAndSet(this, null, nextTimer)) {
/* 1311 */         nextTimer.dispose();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/* 1317 */       long previousState = markTimeout(this);
/* 1318 */       if (isTerminated(previousState) || isCancelledByParent(previousState)) {
/*      */         return;
/*      */       }
/*      */       
/* 1322 */       this.parent.tryCreateNextWindow(this.index);
/*      */     } void clearAndFinalize() {
/*      */       long state;
/*      */       long nextState;
/*      */       do {
/* 1327 */         state = this.state;
/*      */         
/* 1329 */         clearQueue();
/*      */         
/* 1331 */         if (isFinalized(state)) {
/*      */           return;
/*      */         }
/*      */         
/* 1335 */         nextState = (state | Long.MIN_VALUE) & 0xFFFFFFFFFF000000L ^ (hasValues(state) ? 288230376151711744L : 0L);
/* 1336 */       } while (!STATE.compareAndSet(this, state, nextState));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean markFinalized(long state) {
/* 1344 */       long nextState = (state | Long.MIN_VALUE) & 0xFFFFFFFFFF000000L ^ (hasValues(state) ? 288230376151711744L : 0L);
/* 1345 */       if (STATE.compareAndSet(this, state, nextState)) {
/* 1346 */         return true;
/*      */       }
/*      */       
/* 1349 */       return false;
/*      */     }
/*      */     
/*      */     void clearQueue() {
/* 1353 */       Queue<T> q = this.queue;
/* 1354 */       Context context = (this.actual != null) ? this.actual.currentContext() : this.parent.currentContext();
/*      */       
/*      */       T v;
/* 1357 */       while ((v = q.poll()) != null) {
/* 1358 */         Operators.onDiscard(v, context);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static <T> long markSent(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1388 */         long state = instance.state;
/*      */         
/* 1390 */         if (isCancelled(state)) {
/* 1391 */           return state;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1400 */         long nextState = state ^ 0x80000000000000L | ((isTimeout(state) || isTerminated(state)) ? (0x4000000000000000L | (hasSubscriberSet(state) ? (hasValues(state) ? incrementWork(state & 0xFFFFFFL) : Long.MIN_VALUE) : 0L)) : 0L);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1405 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1406 */           if (instance.logger != null) {
/* 1407 */             instance.logger.log(instance.toString(), "mst", state, nextState);
/*      */           }
/*      */           
/* 1410 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static boolean isSent(long state) {
/* 1416 */       return ((state & 0x80000000000000L) == 0L);
/*      */     }
/*      */     
/*      */     static <T> long markTimeout(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1421 */         long state = instance.state;
/*      */         
/* 1423 */         if (isTerminated(state)) {
/* 1424 */           return state;
/*      */         }
/*      */         
/* 1427 */         long nextState = state | 0x800000000000000L;
/* 1428 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1429 */           if (instance.logger != null) {
/* 1430 */             instance.logger.log(instance.toString(), "mtt", state, nextState);
/*      */           }
/* 1432 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static boolean isTimeout(long state) {
/* 1438 */       return ((state & 0x800000000000000L) == 576460752303423488L);
/*      */     }
/*      */     
/*      */     static <T> long markCancelled(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1443 */         long state = instance.state;
/*      */         
/* 1445 */         if (isCancelled(state) || isFinalized(state)) {
/* 1446 */           return state;
/*      */         }
/*      */         
/* 1449 */         long cleanState = state & 0xFFFFFFFFFF000000L;
/*      */         
/* 1451 */         long nextState = cleanState | 0x1000000000000000L | 0x100000000000000L | incrementWork(state & 0xFFFFFFL);
/* 1452 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1453 */           if (instance.logger != null) {
/* 1454 */             instance.logger.log(instance.toString(), "mcd", state, nextState);
/*      */           }
/*      */           
/* 1457 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static boolean isCancelled(long state) {
/* 1463 */       return ((state & 0x1000000000000000L) == 1152921504606846976L);
/*      */     }
/*      */     
/*      */     static boolean isCancelledByParent(long state) {
/* 1467 */       return ((state & 0x2000000000000000L) == 2305843009213693952L);
/*      */     }
/*      */     
/*      */     static <T> long markHasValues(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1472 */         long nextState, state = instance.state;
/*      */         
/* 1474 */         if (isFinalized(state)) {
/* 1475 */           if (instance.logger != null) {
/* 1476 */             instance.logger.log(instance.toString(), "fhv", state, state);
/*      */           }
/* 1478 */           return state;
/*      */         } 
/*      */ 
/*      */         
/* 1482 */         if (hasSubscriberSet(state)) {
/* 1483 */           long cleanState = state & 0xFFFFFFFFFF000000L & 0xFF80000000FFFFFFL;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1488 */           nextState = cleanState | 0x400000000000000L | incrementReceived(state & 0x7FFFFFFF000000L) | incrementWork(state & 0xFFFFFFL);
/*      */         } else {
/*      */           
/* 1491 */           long cleanState = state & 0xFFFFFFFFFF000000L & 0xFF80000000FFFFFFL;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1496 */           nextState = cleanState | 0x400000000000000L | incrementReceived(state & 0x7FFFFFFF000000L) | (hasWorkInProgress(state) ? incrementWork(state & 0xFFFFFFL) : 0L);
/*      */         } 
/*      */         
/* 1499 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1500 */           if (instance.logger != null) {
/* 1501 */             instance.logger.log(instance.toString(), "mhv", state, nextState);
/*      */           }
/*      */           
/* 1504 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static <T> long markHasValuesAndTerminated(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1511 */         long nextState, state = instance.state;
/*      */         
/* 1513 */         if (isFinalized(state)) {
/* 1514 */           if (instance.logger != null) {
/* 1515 */             instance.logger.log(instance.toString(), "fht", state, state);
/*      */           }
/* 1517 */           return state;
/*      */         } 
/*      */         
/* 1520 */         long cleanState = state & 0xFFFFFFFFFF000000L & 0xFF80000000FFFFFFL;
/*      */ 
/*      */         
/* 1523 */         if (hasSubscriberSet(state)) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1528 */           nextState = cleanState | 0x400000000000000L | 0x4000000000000000L | incrementReceived(state & 0x7FFFFFFF000000L) | incrementWork(state & 0xFFFFFFL);
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1535 */           nextState = cleanState | 0x400000000000000L | 0x4000000000000000L | incrementReceived(state & 0x7FFFFFFF000000L) | (hasWorkInProgress(state) ? incrementWork(state & 0xFFFFFFL) : 0L);
/*      */         } 
/*      */         
/* 1538 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1539 */           if (instance.logger != null) {
/* 1540 */             instance.logger.log(instance.toString(), "hvt", state, nextState);
/*      */           }
/*      */           
/* 1543 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static boolean hasValues(long state) {
/* 1549 */       return ((state & 0x400000000000000L) == 288230376151711744L);
/*      */     }
/*      */     
/*      */     static long received(long state) {
/* 1553 */       return (state & 0x7FFFFFFF000000L) >> 24L;
/*      */     }
/*      */     
/*      */     static <T> long markHasRequest(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1558 */         long state = instance.state;
/*      */         
/* 1560 */         if (isCancelled(state) || isFinalized(state)) {
/* 1561 */           return state;
/*      */         }
/*      */         
/* 1564 */         long cleanState = state & 0xFFFFFFFFFF000000L;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1569 */         long nextState = cleanState | 0x100000000000000L | (hasValues(state) ? incrementWork(state & 0xFFFFFFL) : 0L);
/*      */ 
/*      */ 
/*      */         
/* 1573 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1574 */           if (instance.logger != null) {
/* 1575 */             instance.logger.log(instance.toString(), "mhr", state, nextState);
/*      */           }
/* 1577 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static <T> long markTerminated(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1584 */         long state = instance.state;
/*      */         
/* 1586 */         if (isFinalized(state) || isTerminated(state)) {
/* 1587 */           return state;
/*      */         }
/*      */         
/* 1590 */         long cleanState = state & 0xFFFFFFFFFF000000L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1597 */         long nextState = cleanState | 0x4000000000000000L | (hasSubscriberSet(state) ? (hasValues(state) ? incrementWork(state & 0xFFFFFFL) : Long.MIN_VALUE) : 0L);
/*      */ 
/*      */ 
/*      */         
/* 1601 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1602 */           if (instance.logger != null) {
/* 1603 */             instance.logger.log(instance.toString(), "mtd", state, nextState);
/*      */           }
/* 1605 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static boolean isTerminated(long state) {
/* 1611 */       return ((state & 0x4000000000000000L) == 4611686018427387904L);
/*      */     }
/*      */     
/*      */     static long incrementWork(long currentWork) {
/* 1615 */       return (currentWork == 16777215L) ? 1L : (currentWork + 1L);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     static long incrementReceived(long currentWork) {
/* 1621 */       return (currentWork >> 24L) + 1L << 24L;
/*      */     }
/*      */     
/*      */     static <T> long markSubscribedOnce(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1626 */         long state = instance.state;
/*      */         
/* 1628 */         if (hasSubscribedOnce(state)) {
/* 1629 */           return state;
/*      */         }
/*      */         
/* 1632 */         long nextState = state | 0x200000000000000L;
/* 1633 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1634 */           if (instance.logger != null) {
/* 1635 */             instance.logger.log(instance.toString(), "mso", state, nextState);
/*      */           }
/* 1637 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static boolean hasSubscribedOnce(long state) {
/* 1643 */       return ((state & 0x200000000000000L) == 144115188075855872L);
/*      */     }
/*      */     
/*      */     static <T> long markSubscriberSet(InnerWindow<T> instance) {
/*      */       while (true) {
/* 1648 */         long state = instance.state;
/*      */         
/* 1650 */         if (isFinalized(state) || hasWorkInProgress(state)) {
/* 1651 */           return state;
/*      */         }
/*      */ 
/*      */         
/* 1655 */         long nextState = state | 0x100000000000000L | ((isTerminated(state) && !hasValues(state)) ? Long.MIN_VALUE : 0L);
/* 1656 */         if (STATE.compareAndSet(instance, state, nextState)) {
/* 1657 */           if (instance.logger != null) {
/* 1658 */             instance.logger.log(instance.toString(), "mss", state, nextState);
/*      */           }
/* 1660 */           return state;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     static boolean hasSubscriberSet(long state) {
/* 1666 */       return ((state & 0x100000000000000L) == 72057594037927936L);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     static <T> long markWorkDone(InnerWindow<T> instance, long expectedState, boolean hasValues) {
/* 1672 */       long state = instance.state;
/*      */       
/* 1674 */       if (expectedState != state) {
/* 1675 */         return state;
/*      */       }
/*      */       
/* 1678 */       long nextState = (state ^ (hasValues ? 0L : 288230376151711744L)) & 0xFFFFFFFFFF000000L;
/*      */       
/* 1680 */       if (STATE.compareAndSet(instance, state, nextState)) {
/* 1681 */         if (instance.logger != null) {
/* 1682 */           instance.logger.log(instance.toString(), "mwd", state, nextState);
/*      */         }
/* 1684 */         return nextState;
/*      */       } 
/*      */       
/* 1687 */       return instance.state;
/*      */     }
/*      */     
/*      */     static boolean hasWorkInProgress(long state) {
/* 1691 */       return ((state & 0xFFFFFFL) > 0L);
/*      */     }
/*      */     
/*      */     static boolean isFinalized(long state) {
/* 1695 */       return ((state & Long.MIN_VALUE) == Long.MIN_VALUE);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1700 */       return super.toString() + " " + this.index;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class WindowTimeoutSubscriber<T>
/*      */     implements InnerOperator<T, Flux<T>>
/*      */   {
/*      */     final CoreSubscriber<? super Flux<T>> actual;
/*      */     
/*      */     final long timespan;
/*      */     
/*      */     final TimeUnit unit;
/*      */     final Scheduler scheduler;
/*      */     final int maxSize;
/*      */     final Scheduler.Worker worker;
/*      */     final Queue<Object> queue;
/*      */     Throwable error;
/*      */     volatile boolean done;
/*      */     volatile boolean cancelled;
/*      */     volatile long requested;
/* 1721 */     static final AtomicLongFieldUpdater<WindowTimeoutSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(WindowTimeoutSubscriber.class, "requested");
/*      */ 
/*      */     
/*      */     volatile int wip;
/*      */ 
/*      */     
/* 1727 */     static final AtomicIntegerFieldUpdater<WindowTimeoutSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(WindowTimeoutSubscriber.class, "wip");
/*      */ 
/*      */     
/*      */     int count;
/*      */     
/*      */     long producerIndex;
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     Sinks.Many<T> window;
/*      */     
/*      */     volatile boolean terminated;
/*      */     
/*      */     volatile Disposable timer;
/*      */     
/* 1742 */     static final AtomicReferenceFieldUpdater<WindowTimeoutSubscriber, Disposable> TIMER = AtomicReferenceFieldUpdater.newUpdater(WindowTimeoutSubscriber.class, Disposable.class, "timer");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     WindowTimeoutSubscriber(CoreSubscriber<? super Flux<T>> actual, int maxSize, long timespan, TimeUnit unit, Scheduler scheduler) {
/* 1752 */       this.actual = actual;
/* 1753 */       this
/* 1754 */         .queue = Queues.unboundedMultiproducer().get();
/* 1755 */       this.timespan = timespan;
/* 1756 */       this.unit = unit;
/* 1757 */       this.scheduler = scheduler;
/* 1758 */       this.maxSize = maxSize;
/* 1759 */       this.worker = scheduler.createWorker();
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super Flux<T>> actual() {
/* 1764 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<? extends Scannable> inners() {
/* 1769 */       Sinks.Many<T> w = this.window;
/* 1770 */       return (w == null) ? Stream.<Scannable>empty() : Stream.<Scannable>of(Scannable.from(w));
/*      */     }
/*      */ 
/*      */     
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1775 */       if (key == Scannable.Attr.PARENT) {
/* 1776 */         return this.s;
/*      */       }
/* 1778 */       if (key == Scannable.Attr.CANCELLED) {
/* 1779 */         return Boolean.valueOf(this.cancelled);
/*      */       }
/* 1781 */       if (key == Scannable.Attr.TERMINATED) {
/* 1782 */         return Boolean.valueOf(this.done);
/*      */       }
/* 1784 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/* 1785 */         return Long.valueOf(this.requested);
/*      */       }
/* 1787 */       if (key == Scannable.Attr.CAPACITY) {
/* 1788 */         return Integer.valueOf(this.maxSize);
/*      */       }
/* 1790 */       if (key == Scannable.Attr.BUFFERED) {
/* 1791 */         return Integer.valueOf(this.queue.size());
/*      */       }
/* 1793 */       if (key == Scannable.Attr.RUN_ON) {
/* 1794 */         return this.worker;
/*      */       }
/* 1796 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 1797 */         return Scannable.Attr.RunStyle.ASYNC;
/*      */       }
/* 1799 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 1804 */       if (Operators.validate(this.s, s)) {
/* 1805 */         this.s = s;
/*      */         
/* 1807 */         CoreSubscriber<? super Flux<T>> coreSubscriber = this.actual;
/*      */         
/* 1809 */         coreSubscriber.onSubscribe(this);
/*      */         
/* 1811 */         if (this.cancelled) {
/*      */           return;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1818 */         Sinks.Many<T> w = Sinks.unsafe().many().unicast().onBackpressureBuffer();
/* 1819 */         this.window = w;
/*      */         
/* 1821 */         long r = this.requested;
/* 1822 */         if (r != 0L) {
/* 1823 */           coreSubscriber.onNext(w.asFlux());
/* 1824 */           if (r != Long.MAX_VALUE) {
/* 1825 */             REQUESTED.decrementAndGet(this);
/*      */           }
/*      */         } else {
/*      */           
/* 1829 */           coreSubscriber.onError(Operators.onOperatorError(s, 
/* 1830 */                 Exceptions.failWithOverflow(), this.actual
/* 1831 */                 .currentContext()));
/*      */           
/*      */           return;
/*      */         } 
/* 1835 */         if (OperatorDisposables.replace(TIMER, this, newPeriod())) {
/* 1836 */           s.request(Long.MAX_VALUE);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     Disposable newPeriod() {
/*      */       try {
/* 1843 */         return this.worker.schedulePeriodically(new ConsumerIndexHolder(this.producerIndex, this), this.timespan, this.timespan, this.unit);
/*      */       
/*      */       }
/* 1846 */       catch (Exception e) {
/* 1847 */         this.actual.onError(Operators.onRejectedExecution(e, this.s, null, null, this.actual
/*      */ 
/*      */ 
/*      */               
/* 1851 */               .currentContext()));
/* 1852 */         return Disposables.disposed();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/* 1858 */       if (this.terminated) {
/*      */         return;
/*      */       }
/*      */       
/* 1862 */       if (WIP.get(this) == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 1863 */         Sinks.Many<T> w = this.window;
/* 1864 */         w.emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*      */         
/* 1866 */         int c = this.count + 1;
/*      */         
/* 1868 */         if (c >= this.maxSize) {
/* 1869 */           this.producerIndex++;
/* 1870 */           this.count = 0;
/*      */           
/* 1872 */           w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*      */           
/* 1874 */           long r = this.requested;
/*      */           
/* 1876 */           if (r != 0L) {
/*      */ 
/*      */ 
/*      */             
/* 1880 */             w = Sinks.unsafe().many().unicast().onBackpressureBuffer();
/* 1881 */             this.window = w;
/* 1882 */             this.actual.onNext(w.asFlux());
/* 1883 */             if (r != Long.MAX_VALUE) {
/* 1884 */               REQUESTED.decrementAndGet(this);
/*      */             }
/*      */             
/* 1887 */             Disposable tm = this.timer;
/* 1888 */             tm.dispose();
/*      */             
/* 1890 */             Disposable task = newPeriod();
/*      */             
/* 1892 */             if (!TIMER.compareAndSet(this, tm, task)) {
/* 1893 */               task.dispose();
/*      */             }
/*      */           } else {
/*      */             
/* 1897 */             this.window = null;
/* 1898 */             this.actual.onError(Operators.onOperatorError(this.s, 
/* 1899 */                   Exceptions.failWithOverflow(), t, this.actual
/*      */                   
/* 1901 */                   .currentContext()));
/* 1902 */             this.timer.dispose();
/* 1903 */             this.worker.dispose();
/*      */             
/*      */             return;
/*      */           } 
/*      */         } else {
/* 1908 */           this.count = c;
/*      */         } 
/*      */         
/* 1911 */         if (WIP.decrementAndGet(this) == 0) {
/*      */           return;
/*      */         }
/*      */       } else {
/*      */         
/* 1916 */         this.queue.offer(t);
/* 1917 */         if (!enter()) {
/*      */           return;
/*      */         }
/*      */       } 
/* 1921 */       drainLoop();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 1926 */       this.error = t;
/* 1927 */       this.done = true;
/* 1928 */       if (enter()) {
/* 1929 */         drainLoop();
/*      */       }
/*      */       
/* 1932 */       this.actual.onError(t);
/* 1933 */       this.timer.dispose();
/* 1934 */       this.worker.dispose();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 1939 */       this.done = true;
/* 1940 */       if (enter()) {
/* 1941 */         drainLoop();
/*      */       }
/*      */       
/* 1944 */       this.actual.onComplete();
/* 1945 */       this.timer.dispose();
/* 1946 */       this.worker.dispose();
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 1951 */       if (Operators.validate(n)) {
/* 1952 */         Operators.addCap(REQUESTED, this, n);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 1958 */       this.cancelled = true;
/*      */     }
/*      */ 
/*      */     
/*      */     void drainLoop() {
/* 1963 */       Queue<Object> q = this.queue;
/* 1964 */       CoreSubscriber<? super Flux<T>> coreSubscriber = this.actual;
/* 1965 */       Sinks.Many<T> w = this.window;
/*      */       
/* 1967 */       int missed = 1;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1971 */         if (this.terminated) {
/* 1972 */           this.s.cancel();
/* 1973 */           q.clear();
/* 1974 */           this.timer.dispose();
/* 1975 */           this.worker.dispose();
/*      */           
/*      */           return;
/*      */         } 
/* 1979 */         boolean d = this.done;
/*      */         
/* 1981 */         Object o = q.poll();
/*      */         
/* 1983 */         boolean empty = (o == null);
/* 1984 */         boolean isHolder = o instanceof ConsumerIndexHolder;
/*      */         
/* 1986 */         if (d && (empty || isHolder)) {
/* 1987 */           this.window = null;
/* 1988 */           q.clear();
/* 1989 */           Throwable err = this.error;
/* 1990 */           if (err != null) {
/* 1991 */             w.emitError(err, Sinks.EmitFailureHandler.FAIL_FAST);
/*      */           } else {
/*      */             
/* 1994 */             w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*      */           } 
/* 1996 */           this.timer.dispose();
/* 1997 */           this.worker.dispose();
/*      */           
/*      */           return;
/*      */         } 
/* 2001 */         if (empty)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2081 */           missed = WIP.addAndGet(this, -missed);
/* 2082 */           if (missed == 0)
/*      */             break;  continue; }  if (isHolder) { w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST); this.count = 0; w = Sinks.unsafe().many().unicast().onBackpressureBuffer(); this.window = w; long r = this.requested; if (r != 0L) { coreSubscriber.onNext(w.asFlux()); if (r != Long.MAX_VALUE)
/*      */               REQUESTED.decrementAndGet(this);  continue; }  this.window = null; this.queue.clear(); coreSubscriber.onError(Operators.onOperatorError(this.s, Exceptions.failWithOverflow(), this.actual.currentContext())); this.timer.dispose(); this.worker.dispose(); return; }  w.emitNext((T)o, Sinks.EmitFailureHandler.FAIL_FAST); int c = this.count + 1; if (c >= this.maxSize) { this.producerIndex++; this.count = 0; w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST); long r = this.requested; if (r != 0L) { w = Sinks.unsafe().many().unicast().onBackpressureBuffer(); this.window = w; this.actual.onNext(w.asFlux()); if (r != Long.MAX_VALUE)
/*      */               REQUESTED.decrementAndGet(this);  Disposable tm = this.timer; tm.dispose(); Disposable task = newPeriod(); if (!TIMER.compareAndSet(this, tm, task))
/*      */               task.dispose();  continue; }
/*      */            this.window = null; coreSubscriber.onError(Operators.onOperatorError(this.s, Exceptions.failWithOverflow(), o, this.actual.currentContext())); this.timer.dispose(); this.worker.dispose(); return; }
/*      */          this.count = c;
/* 2089 */       }  } boolean enter() { return (WIP.getAndIncrement(this) == 0); }
/*      */ 
/*      */     
/*      */     static final class ConsumerIndexHolder
/*      */       implements Runnable {
/*      */       final long index;
/*      */       final FluxWindowTimeout.WindowTimeoutSubscriber<?> parent;
/*      */       
/*      */       ConsumerIndexHolder(long index, FluxWindowTimeout.WindowTimeoutSubscriber<?> parent) {
/* 2098 */         this.index = index;
/* 2099 */         this.parent = parent;
/*      */       }
/*      */ 
/*      */       
/*      */       public void run() {
/* 2104 */         FluxWindowTimeout.WindowTimeoutSubscriber<?> p = this.parent;
/*      */         
/* 2106 */         if (!p.cancelled) {
/* 2107 */           p.queue.offer(this);
/*      */         } else {
/*      */           
/* 2110 */           p.terminated = true;
/* 2111 */           p.timer.dispose();
/* 2112 */           p.worker.dispose();
/*      */         } 
/* 2114 */         if (p.enter())
/* 2115 */           p.drainLoop(); 
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxWindowTimeout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */