/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoReduce<T>
/*     */   extends MonoFromFluxOperator<T, T>
/*     */   implements Fuseable
/*     */ {
/*     */   final BiFunction<T, T, T> aggregator;
/*     */   
/*     */   MonoReduce(Flux<? extends T> source, BiFunction<T, T, T> aggregator) {
/*  41 */     super(source);
/*  42 */     this.aggregator = Objects.<BiFunction<T, T, T>>requireNonNull(aggregator, "aggregator");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  47 */     return new ReduceSubscriber<>(actual, this.aggregator);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  52 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  53 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ReduceSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     final BiFunction<T, T, T> aggregator;
/*     */     
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     ReduceSubscriber(CoreSubscriber<? super T> actual, BiFunction<T, T, T> aggregator) {
/*  66 */       super(actual);
/*  67 */       this.aggregator = aggregator;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  73 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  74 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  75 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  77 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  82 */       if (Operators.validate(this.s, s)) {
/*  83 */         this.s = s;
/*  84 */         this.actual.onSubscribe(this);
/*  85 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  91 */       if (this.done) {
/*  92 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/*  95 */       T r = this.value;
/*  96 */       if (r == null) {
/*  97 */         setValue(t);
/*     */       } else {
/*     */         
/*     */         try {
/* 101 */           r = Objects.requireNonNull(this.aggregator.apply(r, t), "The aggregator returned a null value");
/*     */         
/*     */         }
/* 104 */         catch (Throwable ex) {
/* 105 */           this.done = true;
/* 106 */           Context ctx = this.actual.currentContext();
/* 107 */           Operators.onDiscard(t, ctx);
/* 108 */           Operators.onDiscard(this.value, ctx);
/* 109 */           this.value = null;
/* 110 */           this.actual.onError(Operators.onOperatorError(this.s, ex, t, this.actual
/* 111 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 115 */         setValue(r);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 121 */       if (this.done) {
/* 122 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 125 */       this.done = true;
/* 126 */       discard(this.value);
/* 127 */       this.value = null;
/* 128 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 133 */       if (this.done) {
/*     */         return;
/*     */       }
/* 136 */       this.done = true;
/* 137 */       T r = this.value;
/* 138 */       if (r != null) {
/* 139 */         complete(r);
/*     */       } else {
/*     */         
/* 142 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 148 */       super.cancel();
/* 149 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoReduce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */