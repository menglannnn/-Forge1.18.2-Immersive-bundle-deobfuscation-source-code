/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MonoFromFluxOperator<I, O>
/*     */   extends Mono<O>
/*     */   implements Scannable, OptimizableOperator<O, I>
/*     */ {
/*     */   protected final Flux<? extends I> source;
/*     */   @Nullable
/*     */   final OptimizableOperator<?, I> optimizableOperator;
/*     */   
/*     */   protected MonoFromFluxOperator(Flux<? extends I> source) {
/*  49 */     this.source = Objects.<Flux<? extends I>>requireNonNull(source);
/*  50 */     if (source instanceof OptimizableOperator) {
/*     */       
/*  52 */       OptimizableOperator<?, I> sourceOptim = (OptimizableOperator)source;
/*  53 */       this.optimizableOperator = sourceOptim;
/*     */     } else {
/*     */       
/*  56 */       this.optimizableOperator = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  63 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/*  64 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void subscribe(CoreSubscriber<? super O> subscriber) {
/*  71 */     OptimizableOperator<I, O> operator = this;
/*     */     try {
/*     */       while (true) {
/*  74 */         subscriber = operator.subscribeOrReturn(subscriber);
/*  75 */         if (subscriber == null) {
/*     */           return;
/*     */         }
/*     */         
/*  79 */         OptimizableOperator<?, ? extends O> newSource = operator.nextOptimizableSource();
/*  80 */         if (newSource == null) {
/*  81 */           operator.source().subscribe(subscriber);
/*     */           return;
/*     */         } 
/*  84 */         OptimizableOperator<?, ? extends O> optimizableOperator1 = newSource;
/*     */       }
/*     */     
/*  87 */     } catch (Throwable e) {
/*  88 */       Operators.reportThrowInSubscribe(subscriber, e);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public abstract CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> paramCoreSubscriber);
/*     */ 
/*     */   
/*     */   public final CorePublisher<? extends I> source() {
/*  99 */     return this.source;
/*     */   }
/*     */ 
/*     */   
/*     */   public final OptimizableOperator<?, ? extends I> nextOptimizableSource() {
/* 104 */     return this.optimizableOperator;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoFromFluxOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */