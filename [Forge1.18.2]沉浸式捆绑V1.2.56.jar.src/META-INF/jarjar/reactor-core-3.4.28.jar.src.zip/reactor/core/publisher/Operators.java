/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.Spliterator;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.stream.Stream;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CorePublisher;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Operators
/*      */ {
/*      */   public static long addCap(long a, long b) {
/*   71 */     long res = a + b;
/*   72 */     if (res < 0L) {
/*   73 */       return Long.MAX_VALUE;
/*      */     }
/*   75 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> long addCap(AtomicLongFieldUpdater<T> updater, T instance, long toAdd) {
/*      */     while (true) {
/*   91 */       long r = updater.get(instance);
/*   92 */       if (r == Long.MAX_VALUE) {
/*   93 */         return Long.MAX_VALUE;
/*      */       }
/*   95 */       long u = addCap(r, toAdd);
/*   96 */       if (updater.compareAndSet(instance, r, u)) {
/*   97 */         return r;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <T> Fuseable.QueueSubscription<T> as(Subscription s) {
/*  110 */     if (s instanceof Fuseable.QueueSubscription) {
/*  111 */       return (Fuseable.QueueSubscription<T>)s;
/*      */     }
/*  113 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Subscription cancelledSubscription() {
/*  127 */     return CancelledSubscription.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void complete(Subscriber<?> s) {
/*  136 */     s.onSubscribe((Subscription)EmptySubscription.INSTANCE);
/*  137 */     s.onComplete();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CoreSubscriber<T> drainSubscriber() {
/*  149 */     return DrainSubscriber.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CoreSubscriber<T> emptySubscriber() {
/*  161 */     return (CoreSubscriber)EMPTY_SUBSCRIBER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Subscription emptySubscription() {
/*  175 */     return (Subscription)EmptySubscription.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean canAppearAfterOnSubscribe(Subscription subscription) {
/*  186 */     return (subscription == EmptySubscription.FROM_SUBSCRIBE_INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void error(Subscriber<?> s, Throwable e) {
/*  197 */     s.onSubscribe((Subscription)EmptySubscription.INSTANCE);
/*  198 */     s.onError(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportThrowInSubscribe(CoreSubscriber<?> subscriber, Throwable e) {
/*      */     try {
/*  226 */       subscriber.onSubscribe((Subscription)EmptySubscription.FROM_SUBSCRIBE_INSTANCE);
/*      */     }
/*  228 */     catch (Throwable onSubscribeError) {
/*  229 */       Exceptions.throwIfFatal(onSubscribeError);
/*  230 */       e.addSuppressed(onSubscribeError);
/*      */     } 
/*  232 */     subscriber.onError(onOperatorError(e, subscriber.currentContext()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <I, O> Function<? super Publisher<I>, ? extends Publisher<O>> lift(BiFunction<Scannable, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter) {
/*  260 */     return LiftFunction.liftScannable(null, lifter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <O> Function<? super Publisher<O>, ? extends Publisher<O>> lift(Predicate<Scannable> filter, BiFunction<Scannable, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super O>> lifter) {
/*  296 */     return LiftFunction.liftScannable(filter, lifter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <I, O> Function<? super Publisher<I>, ? extends Publisher<O>> liftPublisher(BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter) {
/*  320 */     return LiftFunction.liftPublisher(null, lifter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <O> Function<? super Publisher<O>, ? extends Publisher<O>> liftPublisher(Predicate<Publisher> filter, BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super O>> lifter) {
/*  351 */     return LiftFunction.liftPublisher(filter, lifter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long multiplyCap(long a, long b) {
/*  363 */     long u = a * b;
/*  364 */     if ((a | b) >>> 31L != 0L && 
/*  365 */       u / a != b) {
/*  366 */       return Long.MAX_VALUE;
/*      */     }
/*      */     
/*  369 */     return u;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final <R> Function<Context, Context> discardLocalAdapter(Class<R> type, Consumer<? super R> discardHook) {
/*  384 */     Objects.requireNonNull(type, "onDiscard must be based on a type");
/*  385 */     Objects.requireNonNull(discardHook, "onDiscard must be provided a discardHook Consumer");
/*      */     
/*  387 */     Consumer<Object> safeConsumer = obj -> {
/*      */         if (type.isInstance(obj)) {
/*      */           discardHook.accept(type.cast(obj));
/*      */         }
/*      */       };
/*      */     
/*  393 */     return ctx -> {
/*      */         Consumer<Object> consumer = (Consumer<Object>)ctx.getOrDefault("reactor.onDiscard.local", null);
/*      */         return (consumer == null) ? ctx.put("reactor.onDiscard.local", safeConsumer) : ctx.put("reactor.onDiscard.local", safeConsumer.andThen(consumer));
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Context enableOnDiscard(@Nullable Context target, Consumer<?> discardConsumer) {
/*  414 */     Objects.requireNonNull(discardConsumer, "discardConsumer must be provided");
/*  415 */     if (target == null) {
/*  416 */       return Context.of("reactor.onDiscard.local", discardConsumer);
/*      */     }
/*  418 */     return target.put("reactor.onDiscard.local", discardConsumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void onDiscard(@Nullable T element, Context context) {
/*  438 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  439 */     if (element != null && hook != null) {
/*      */       try {
/*  441 */         hook.accept(element);
/*      */       }
/*  443 */       catch (Throwable t) {
/*  444 */         log.warn("Error in discard hook", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void onDiscardQueueWithClear(@Nullable Queue<T> queue, Context context, @Nullable Function<T, Stream<?>> extract) {
/*  468 */     if (queue == null) {
/*      */       return;
/*      */     }
/*      */     
/*  472 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  473 */     if (hook == null) {
/*  474 */       queue.clear();
/*      */       
/*      */       return;
/*      */     } 
/*      */     try {
/*      */       while (true) {
/*  480 */         T toDiscard = queue.poll();
/*  481 */         if (toDiscard == null) {
/*      */           break;
/*      */         }
/*      */         
/*  485 */         if (extract != null) {
/*      */           try {
/*  487 */             ((Stream)extract.apply(toDiscard))
/*  488 */               .forEach(elementToDiscard -> {
/*      */                   
/*      */                   try {
/*      */                     hook.accept(elementToDiscard);
/*  492 */                   } catch (Throwable t) {
/*      */                     
/*      */                     log.warn("Error while discarding item extracted from a queue element, continuing with next item", t);
/*      */                   } 
/*      */                 });
/*  497 */           } catch (Throwable t) {
/*  498 */             log.warn("Error while extracting items to discard from queue element, continuing with next queue element", t);
/*      */           } 
/*      */           continue;
/*      */         } 
/*      */         try {
/*  503 */           hook.accept(toDiscard);
/*      */         }
/*  505 */         catch (Throwable t) {
/*  506 */           log.warn("Error while discarding a queue element, continuing with next queue element", t);
/*      */         }
/*      */       
/*      */       }
/*      */     
/*  511 */     } catch (Throwable t) {
/*  512 */       log.warn("Cannot further apply discard hook while discarding and clearing a queue", t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onDiscardMultiple(Stream<?> multiple, Context context) {
/*  529 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  530 */     if (hook != null) {
/*      */       try {
/*  532 */         multiple.filter(Objects::nonNull)
/*  533 */           .forEach(v -> {
/*      */               
/*      */               try {
/*      */                 hook.accept(v);
/*  537 */               } catch (Throwable t) {
/*      */                 
/*      */                 log.warn("Error while discarding a stream element, continuing with next element", t);
/*      */               } 
/*      */             });
/*  542 */       } catch (Throwable t) {
/*  543 */         log.warn("Error while discarding stream, stopping", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onDiscardMultiple(@Nullable Collection<?> multiple, Context context) {
/*  560 */     if (multiple == null)
/*  561 */       return;  Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  562 */     if (hook != null) {
/*      */       try {
/*  564 */         if (multiple.isEmpty()) {
/*      */           return;
/*      */         }
/*  567 */         for (Object o : multiple) {
/*  568 */           if (o != null) {
/*      */             try {
/*  570 */               hook.accept(o);
/*      */             }
/*  572 */             catch (Throwable t) {
/*  573 */               log.warn("Error while discarding element from a Collection, continuing with next element", t);
/*      */             }
/*      */           
/*      */           }
/*      */         } 
/*  578 */       } catch (Throwable t) {
/*  579 */         log.warn("Error while discarding collection, stopping", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onDiscardMultiple(@Nullable Iterator<?> multiple, boolean knownToBeFinite, Context context) {
/*  598 */     if (multiple == null)
/*  599 */       return;  if (!knownToBeFinite)
/*      */       return; 
/*  601 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  602 */     if (hook != null) {
/*      */       try {
/*  604 */         multiple.forEachRemaining(o -> {
/*      */               
/*      */               if (o != null) {
/*      */                 try {
/*      */                   hook.accept(o);
/*  609 */                 } catch (Throwable t) {
/*      */                   
/*      */                   log.warn("Error while discarding element from an Iterator, continuing with next element", t);
/*      */                 } 
/*      */               }
/*      */             });
/*  615 */       } catch (Throwable t) {
/*  616 */         log.warn("Error while discarding Iterator, stopping", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onDiscardMultiple(@Nullable Spliterator<?> multiple, boolean knownToBeFinite, Context context) {
/*  635 */     if (multiple == null)
/*  636 */       return;  if (!knownToBeFinite)
/*      */       return; 
/*  638 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onDiscard.local", null);
/*  639 */     if (hook != null) {
/*      */       try {
/*  641 */         multiple.forEachRemaining(o -> {
/*      */               
/*      */               if (o != null) {
/*      */                 try {
/*      */                   hook.accept(o);
/*  646 */                 } catch (Throwable t) {
/*      */                   
/*      */                   log.warn("Error while discarding element from an Spliterator, continuing with next element", t);
/*      */                 } 
/*      */               }
/*      */             });
/*  652 */       } catch (Throwable t) {
/*  653 */         log.warn("Error while discarding Spliterator, stopping", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onErrorDropped(Throwable e, Context context) {
/*  668 */     Consumer<? super Throwable> hook = (Consumer<? super Throwable>)context.getOrDefault("reactor.onErrorDropped.local", null);
/*  669 */     if (hook == null) {
/*  670 */       hook = Hooks.onErrorDroppedHook;
/*      */     }
/*  672 */     if (hook == null) {
/*  673 */       log.error("Operator called default onErrorDropped", e);
/*      */       return;
/*      */     } 
/*  676 */     hook.accept(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void onNextDropped(T t, Context context) {
/*  690 */     Objects.requireNonNull(t, "onNext");
/*  691 */     Objects.requireNonNull(context, "context");
/*  692 */     Consumer<Object> hook = (Consumer<Object>)context.getOrDefault("reactor.onNextDropped.local", null);
/*  693 */     if (hook == null) {
/*  694 */       hook = Hooks.onNextDroppedHook;
/*      */     }
/*  696 */     if (hook != null) {
/*  697 */       hook.accept(t);
/*      */     }
/*  699 */     else if (log.isDebugEnabled()) {
/*  700 */       log.debug("onNextDropped: " + t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable onOperatorError(Throwable error, Context context) {
/*  716 */     return onOperatorError(null, error, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable onOperatorError(@Nullable Subscription subscription, Throwable error, Context context) {
/*  734 */     return onOperatorError(subscription, error, null, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable onOperatorError(@Nullable Subscription subscription, Throwable error, @Nullable Object dataSignal, Context context) {
/*  756 */     Exceptions.throwIfFatal(error);
/*  757 */     if (subscription != null) {
/*  758 */       subscription.cancel();
/*      */     }
/*      */     
/*  761 */     Throwable t = Exceptions.unwrap(error);
/*      */     
/*  763 */     BiFunction<? super Throwable, Object, ? extends Throwable> hook = (BiFunction<? super Throwable, Object, ? extends Throwable>)context.getOrDefault("reactor.onOperatorError.local", null);
/*  764 */     if (hook == null) {
/*  765 */       hook = Hooks.onOperatorErrorHook;
/*      */     }
/*  767 */     if (hook == null) {
/*  768 */       if (dataSignal != null && 
/*  769 */         dataSignal != t && dataSignal instanceof Throwable) {
/*  770 */         t = Exceptions.addSuppressed(t, (Throwable)dataSignal);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  776 */       return t;
/*      */     } 
/*  778 */     return hook.apply(error, dataSignal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RuntimeException onRejectedExecution(Throwable original, Context context) {
/*  794 */     return onRejectedExecution(original, null, null, null, context);
/*      */   }
/*      */   
/*      */   static final OnNextFailureStrategy onNextErrorStrategy(Context context) {
/*  798 */     OnNextFailureStrategy strategy = null;
/*      */     
/*  800 */     BiFunction<? super Throwable, Object, ? extends Throwable> fn = (BiFunction<? super Throwable, Object, ? extends Throwable>)context.getOrDefault("reactor.onNextError.localStrategy", null);
/*      */     
/*  802 */     if (fn instanceof OnNextFailureStrategy) {
/*  803 */       strategy = (OnNextFailureStrategy)fn;
/*  804 */     } else if (fn != null) {
/*  805 */       strategy = new OnNextFailureStrategy.LambdaOnNextErrorStrategy(fn);
/*      */     } 
/*      */     
/*  808 */     if (strategy == null) strategy = Hooks.onNextErrorHook; 
/*  809 */     if (strategy == null) strategy = OnNextFailureStrategy.STOP; 
/*  810 */     return strategy;
/*      */   }
/*      */   
/*      */   public static final BiFunction<? super Throwable, Object, ? extends Throwable> onNextErrorFunction(Context context) {
/*  814 */     return onNextErrorStrategy(context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <T> Throwable onNextError(@Nullable T value, Throwable error, Context context, Subscription subscriptionForCancel) {
/*  857 */     error = unwrapOnNextError(error);
/*  858 */     OnNextFailureStrategy strategy = onNextErrorStrategy(context);
/*  859 */     if (strategy.test(error, value)) {
/*      */       
/*  861 */       Throwable t = strategy.process(error, value, context);
/*  862 */       if (t != null) {
/*  863 */         subscriptionForCancel.cancel();
/*      */       }
/*  865 */       return t;
/*      */     } 
/*      */ 
/*      */     
/*  869 */     return onOperatorError(subscriptionForCancel, error, value, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <T> Throwable onNextError(@Nullable T value, Throwable error, Context context) {
/*  891 */     error = unwrapOnNextError(error);
/*  892 */     OnNextFailureStrategy strategy = onNextErrorStrategy(context);
/*  893 */     if (strategy.test(error, value))
/*      */     {
/*  895 */       return strategy.process(error, value, context);
/*      */     }
/*      */     
/*  898 */     return onOperatorError(null, error, value, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Throwable onNextInnerError(Throwable error, Context context, @Nullable Subscription subscriptionForCancel) {
/*  916 */     error = unwrapOnNextError(error);
/*  917 */     OnNextFailureStrategy strategy = onNextErrorStrategy(context);
/*  918 */     if (strategy.test(error, (Object)null)) {
/*      */       
/*  920 */       Throwable t = strategy.process(error, null, context);
/*  921 */       if (t != null && subscriptionForCancel != null) {
/*  922 */         subscriptionForCancel.cancel();
/*      */       }
/*  924 */       return t;
/*      */     } 
/*      */     
/*  927 */     return error;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static <T> RuntimeException onNextPollError(@Nullable T value, Throwable error, Context context) {
/*  955 */     error = unwrapOnNextError(error);
/*  956 */     OnNextFailureStrategy strategy = onNextErrorStrategy(context);
/*  957 */     if (strategy.test(error, value)) {
/*      */       
/*  959 */       Throwable throwable = strategy.process(error, value, context);
/*  960 */       if (throwable != null) return Exceptions.propagate(throwable); 
/*  961 */       return null;
/*      */     } 
/*      */     
/*  964 */     Throwable t = onOperatorError(null, error, value, context);
/*  965 */     return Exceptions.propagate(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CorePublisher<T> onLastAssembly(CorePublisher<T> source) {
/*  979 */     Function<Publisher, Publisher> hook = Hooks.onLastOperatorHook;
/*  980 */     if (hook == null) {
/*  981 */       return source;
/*      */     }
/*      */     
/*  984 */     Publisher<T> publisher = Objects.<Publisher<T>>requireNonNull(hook.apply(source), "LastOperator hook returned null");
/*      */     
/*  986 */     if (publisher instanceof CorePublisher) {
/*  987 */       return (CorePublisher<T>)publisher;
/*      */     }
/*      */     
/*  990 */     return new CorePublisherAdapter<>(publisher);
/*      */   }
/*      */ 
/*      */   
/*      */   private static Throwable unwrapOnNextError(Throwable error) {
/*  995 */     return Exceptions.isBubbling(error) ? error : Exceptions.unwrap(error);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RuntimeException onRejectedExecution(Throwable original, @Nullable Subscription subscription, @Nullable Throwable suppressed, @Nullable Object dataSignal, Context context) {
/* 1019 */     if (context.hasKey("reactor.onRejectedExecution.local")) {
/* 1020 */       context = context.put("reactor.onOperatorError.local", context.get("reactor.onRejectedExecution.local"));
/*      */     }
/*      */ 
/*      */     
/* 1024 */     RejectedExecutionException ree = Exceptions.failWithRejected(original);
/* 1025 */     if (suppressed != null) {
/* 1026 */       ree.addSuppressed(suppressed);
/*      */     }
/* 1028 */     if (dataSignal != null) {
/* 1029 */       return Exceptions.propagate(onOperatorError(subscription, ree, dataSignal, context));
/*      */     }
/*      */     
/* 1032 */     return Exceptions.propagate(onOperatorError(subscription, ree, context));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> long produced(AtomicLongFieldUpdater<T> updater, T instance, long toSub) {
/*      */     long r;
/*      */     long u;
/*      */     do {
/* 1049 */       r = updater.get(instance);
/* 1050 */       if (r == 0L || r == Long.MAX_VALUE) {
/* 1051 */         return r;
/*      */       }
/* 1053 */       u = subOrZero(r, toSub);
/* 1054 */     } while (!updater.compareAndSet(instance, r, u));
/*      */     
/* 1056 */     return u;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F> boolean replace(AtomicReferenceFieldUpdater<F, Subscription> field, F instance, Subscription s) {
/*      */     while (true) {
/* 1075 */       Subscription a = field.get(instance);
/* 1076 */       if (a == CancelledSubscription.INSTANCE) {
/* 1077 */         s.cancel();
/* 1078 */         return false;
/*      */       } 
/* 1080 */       if (field.compareAndSet(instance, a, s)) {
/* 1081 */         return true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportBadRequest(long n) {
/* 1094 */     if (log.isDebugEnabled()) {
/* 1095 */       log.debug("Negative request", 
/* 1096 */           Exceptions.nullOrNegativeRequestException(n));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportMoreProduced() {
/* 1107 */     if (log.isDebugEnabled()) {
/* 1108 */       log.debug("More data produced than requested", 
/* 1109 */           Exceptions.failWithOverflow());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportSubscriptionSet() {
/* 1119 */     if (log.isDebugEnabled()) {
/* 1120 */       log.debug("Duplicate Subscription has been detected", 
/* 1121 */           Exceptions.duplicateOnSubscribeException());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Subscription scalarSubscription(CoreSubscriber<? super T> subscriber, T value) {
/* 1136 */     return new ScalarSubscription<>(subscriber, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Subscription scalarSubscription(CoreSubscriber<? super T> subscriber, T value, String stepName) {
/* 1152 */     return new ScalarSubscription<>(subscriber, value, stepName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CoreSubscriber<T> serialize(CoreSubscriber<? super T> subscriber) {
/* 1169 */     return new SerializedSubscriber<>(subscriber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F> boolean set(AtomicReferenceFieldUpdater<F, Subscription> field, F instance, Subscription s) {
/*      */     while (true) {
/* 1190 */       Subscription a = field.get(instance);
/* 1191 */       if (a == CancelledSubscription.INSTANCE) {
/* 1192 */         s.cancel();
/* 1193 */         return false;
/*      */       } 
/* 1195 */       if (field.compareAndSet(instance, a, s)) {
/* 1196 */         if (a != null) {
/* 1197 */           a.cancel();
/*      */         }
/* 1199 */         return true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F> boolean setOnce(AtomicReferenceFieldUpdater<F, Subscription> field, F instance, Subscription s) {
/* 1218 */     Objects.requireNonNull(s, "subscription");
/* 1219 */     Subscription a = field.get(instance);
/* 1220 */     if (a == CancelledSubscription.INSTANCE) {
/* 1221 */       s.cancel();
/* 1222 */       return false;
/*      */     } 
/* 1224 */     if (a != null) {
/* 1225 */       s.cancel();
/* 1226 */       reportSubscriptionSet();
/* 1227 */       return false;
/*      */     } 
/*      */     
/* 1230 */     if (field.compareAndSet(instance, null, s)) {
/* 1231 */       return true;
/*      */     }
/*      */     
/* 1234 */     a = field.get(instance);
/*      */     
/* 1236 */     if (a == CancelledSubscription.INSTANCE) {
/* 1237 */       s.cancel();
/* 1238 */       return false;
/*      */     } 
/*      */     
/* 1241 */     s.cancel();
/* 1242 */     reportSubscriptionSet();
/* 1243 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long subOrZero(long a, long b) {
/* 1254 */     long res = a - b;
/* 1255 */     if (res < 0L) {
/* 1256 */       return 0L;
/*      */     }
/* 1258 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <F> boolean terminate(AtomicReferenceFieldUpdater<F, Subscription> field, F instance) {
/* 1273 */     Subscription a = field.get(instance);
/* 1274 */     if (a != CancelledSubscription.INSTANCE) {
/* 1275 */       a = field.getAndSet(instance, CancelledSubscription.INSTANCE);
/* 1276 */       if (a != null && a != CancelledSubscription.INSTANCE) {
/* 1277 */         a.cancel();
/* 1278 */         return true;
/*      */       } 
/*      */     } 
/* 1281 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean validate(@Nullable Subscription current, Subscription next) {
/* 1293 */     Objects.requireNonNull(next, "Subscription cannot be null");
/* 1294 */     if (current != null) {
/* 1295 */       next.cancel();
/*      */       
/* 1297 */       return false;
/*      */     } 
/*      */     
/* 1300 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean validate(long n) {
/* 1309 */     if (n <= 0L) {
/* 1310 */       reportBadRequest(n);
/* 1311 */       return false;
/*      */     } 
/* 1313 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> CoreSubscriber<? super T> toCoreSubscriber(Subscriber<? super T> actual) {
/*      */     CoreSubscriber<? super T> _actual;
/* 1329 */     Objects.requireNonNull(actual, "actual");
/*      */ 
/*      */ 
/*      */     
/* 1333 */     if (actual instanceof CoreSubscriber) {
/* 1334 */       _actual = (CoreSubscriber<? super T>)actual;
/*      */     } else {
/*      */       
/* 1337 */       _actual = new StrictSubscriber<>(actual);
/*      */     } 
/*      */     
/* 1340 */     return _actual;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Fuseable.ConditionalSubscriber<? super T> toConditionalSubscriber(CoreSubscriber<? super T> actual) {
/*      */     Fuseable.ConditionalSubscriber<? super T> _actual;
/* 1357 */     Objects.requireNonNull(actual, "actual");
/*      */ 
/*      */ 
/*      */     
/* 1361 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 1362 */       _actual = (Fuseable.ConditionalSubscriber<? super T>)actual;
/*      */     } else {
/*      */       
/* 1365 */       _actual = new ConditionalSubscriberAdapter<>(actual);
/*      */     } 
/*      */     
/* 1368 */     return _actual;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static Context multiSubscribersContext(InnerProducer<?>[] multicastInners) {
/* 1374 */     if (multicastInners.length > 0) {
/* 1375 */       return multicastInners[0].actual().currentContext();
/*      */     }
/* 1377 */     return Context.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> long addCapCancellable(AtomicLongFieldUpdater<T> updater, T instance, long n) {
/*      */     while (true) {
/* 1395 */       long r = updater.get(instance);
/* 1396 */       if (r == Long.MIN_VALUE || r == Long.MAX_VALUE) {
/* 1397 */         return r;
/*      */       }
/* 1399 */       long u = addCap(r, n);
/* 1400 */       if (updater.compareAndSet(instance, r, u)) {
/* 1401 */         return r;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void onErrorDroppedMulticast(Throwable e, InnerProducer<?>[] multicastInners) {
/* 1417 */     onErrorDropped(e, multiSubscribersContext(multicastInners));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> void onNextDroppedMulticast(T t, InnerProducer<?>[] multicastInners) {
/* 1435 */     onNextDropped(t, multiSubscribersContext(multicastInners));
/*      */   }
/*      */   
/*      */   static <T> long producedCancellable(AtomicLongFieldUpdater<T> updater, T instance, long n) {
/*      */     while (true) {
/* 1440 */       long current = updater.get(instance);
/* 1441 */       if (current == Long.MIN_VALUE) {
/* 1442 */         return Long.MIN_VALUE;
/*      */       }
/* 1444 */       if (current == Long.MAX_VALUE) {
/* 1445 */         return Long.MAX_VALUE;
/*      */       }
/* 1447 */       long update = current - n;
/* 1448 */       if (update < 0L) {
/* 1449 */         reportBadRequest(update);
/* 1450 */         update = 0L;
/*      */       } 
/* 1452 */       if (updater.compareAndSet(instance, current, update)) {
/* 1453 */         return update;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   static long unboundedOrPrefetch(int prefetch) {
/* 1459 */     return (prefetch == Integer.MAX_VALUE) ? Long.MAX_VALUE : prefetch;
/*      */   }
/*      */   
/*      */   static int unboundedOrLimit(int prefetch) {
/* 1463 */     return (prefetch == Integer.MAX_VALUE) ? Integer.MAX_VALUE : (prefetch - (prefetch >> 2));
/*      */   }
/*      */   
/*      */   static int unboundedOrLimit(int prefetch, int lowTide) {
/* 1467 */     if (lowTide <= 0) {
/* 1468 */       return prefetch;
/*      */     }
/* 1470 */     if (lowTide >= prefetch) {
/* 1471 */       return unboundedOrLimit(prefetch);
/*      */     }
/* 1473 */     return (prefetch == Integer.MAX_VALUE) ? Integer.MAX_VALUE : lowTide;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class CorePublisherAdapter<T>
/*      */     implements CorePublisher<T>, OptimizableOperator<T, T>
/*      */   {
/*      */     final Publisher<T> publisher;
/*      */     
/*      */     @Nullable
/*      */     final OptimizableOperator<?, T> optimizableOperator;
/*      */ 
/*      */     
/*      */     CorePublisherAdapter(Publisher<T> publisher) {
/* 1488 */       this.publisher = publisher;
/* 1489 */       if (publisher instanceof OptimizableOperator) {
/*      */         
/* 1491 */         OptimizableOperator<?, T> optimSource = (OptimizableOperator)publisher;
/* 1492 */         this.optimizableOperator = optimSource;
/*      */       } else {
/*      */         
/* 1495 */         this.optimizableOperator = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void subscribe(CoreSubscriber<? super T> subscriber) {
/* 1501 */       this.publisher.subscribe((Subscriber)subscriber);
/*      */     }
/*      */ 
/*      */     
/*      */     public void subscribe(Subscriber<? super T> s) {
/* 1506 */       this.publisher.subscribe(s);
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 1511 */       return actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public final CorePublisher<? extends T> source() {
/* 1516 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final OptimizableOperator<?, ? extends T> nextOptimizableSource() {
/* 1521 */       return this.optimizableOperator;
/*      */     }
/*      */   }
/*      */   
/* 1525 */   static final Fuseable.ConditionalSubscriber<?> EMPTY_SUBSCRIBER = new Fuseable.ConditionalSubscriber<Object>()
/*      */     {
/*      */       public void onSubscribe(Subscription s) {
/* 1528 */         Throwable e = new IllegalStateException("onSubscribe should not be used");
/* 1529 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/*      */       }
/*      */ 
/*      */       
/*      */       public void onNext(Object o) {
/* 1534 */         Throwable e = new IllegalStateException("onNext should not be used, got " + o);
/* 1535 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean tryOnNext(Object o) {
/* 1540 */         Throwable e = new IllegalStateException("tryOnNext should not be used, got " + o);
/* 1541 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/* 1542 */         return false;
/*      */       }
/*      */ 
/*      */       
/*      */       public void onError(Throwable t) {
/* 1547 */         Throwable e = new IllegalStateException("onError should not be used", t);
/* 1548 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/*      */       }
/*      */ 
/*      */       
/*      */       public void onComplete() {
/* 1553 */         Throwable e = new IllegalStateException("onComplete should not be used");
/* 1554 */         Operators.log.error("Unexpected call to Operators.emptySubscriber()", e);
/*      */       }
/*      */ 
/*      */       
/*      */       public Context currentContext() {
/* 1559 */         return Context.empty();
/*      */       }
/*      */     };
/*      */   
/*      */   static final class CancelledSubscription
/*      */     implements Subscription, Scannable {
/* 1565 */     static final CancelledSubscription INSTANCE = new CancelledSubscription();
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1570 */       if (key == Scannable.Attr.CANCELLED) {
/* 1571 */         return Boolean.valueOf(true);
/*      */       }
/* 1573 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void cancel() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void request(long n) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public String stepName() {
/* 1588 */       return "cancelledSubscription";
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EmptySubscription implements Fuseable.QueueSubscription<Object>, Scannable {
/* 1593 */     static final EmptySubscription INSTANCE = new EmptySubscription();
/* 1594 */     static final EmptySubscription FROM_SUBSCRIBE_INSTANCE = new EmptySubscription();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void cancel() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1608 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object poll() {
/* 1614 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void request(long n) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public int requestFusion(int requestedMode) {
/* 1624 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1630 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(true); 
/* 1631 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1636 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public String stepName() {
/* 1641 */       return "emptySubscription";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class DeferredSubscription
/*      */     implements Subscription, Scannable
/*      */   {
/*      */     static final int STATE_CANCELLED = -2;
/*      */     
/*      */     static final int STATE_SUBSCRIBED = -1;
/*      */     
/*      */     Subscription s;
/*      */     
/*      */     volatile long requested;
/*      */ 
/*      */     
/*      */     protected boolean isCancelled() {
/* 1659 */       return (this.requested == -2L);
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 1664 */       long state = REQUESTED.getAndSet(this, -2L);
/* 1665 */       if (state == -2L) {
/*      */         return;
/*      */       }
/*      */       
/* 1669 */       if (state == -1L) {
/* 1670 */         this.s.cancel();
/*      */       }
/*      */     }
/*      */     
/*      */     protected void terminate() {
/* 1675 */       REQUESTED.getAndSet(this, -2L);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1681 */       long requested = this.requested;
/* 1682 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 1683 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf((requested < 0L) ? 0L : requested); 
/* 1684 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled());
/*      */       
/* 1686 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 1691 */       long r = this.requested;
/*      */       
/* 1693 */       if (r > -1L) {
/*      */         do
/*      */         {
/* 1696 */           if (r == Long.MAX_VALUE) {
/*      */             return;
/*      */           }
/* 1699 */           long u = Operators.addCap(r, n);
/* 1700 */           if (REQUESTED.compareAndSet(this, r, u)) {
/*      */             return;
/*      */           }
/*      */           
/* 1704 */           r = this.requested;
/*      */         }
/* 1706 */         while (r >= 0L);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1713 */       if (r == -2L) {
/*      */         return;
/*      */       }
/*      */       
/* 1717 */       this.s.request(n);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean set(Subscription s) {
/* 1727 */       Objects.requireNonNull(s, "s");
/* 1728 */       long state = this.requested;
/* 1729 */       Subscription a = this.s;
/* 1730 */       if (state == -2L) {
/* 1731 */         s.cancel();
/* 1732 */         return false;
/*      */       } 
/* 1734 */       if (a != null) {
/* 1735 */         s.cancel();
/* 1736 */         Operators.reportSubscriptionSet();
/* 1737 */         return false;
/*      */       } 
/*      */ 
/*      */       
/* 1741 */       long accumulated = 0L;
/*      */       while (true) {
/* 1743 */         long r = this.requested;
/*      */         
/* 1745 */         if (r == -2L || r == -1L) {
/* 1746 */           s.cancel();
/* 1747 */           return false;
/*      */         } 
/*      */         
/* 1750 */         this.s = s;
/*      */         
/* 1752 */         long toRequest = r - accumulated;
/* 1753 */         if (toRequest > 0L) {
/* 1754 */           s.request(toRequest);
/*      */         }
/* 1756 */         accumulated += toRequest;
/*      */         
/* 1758 */         if (REQUESTED.compareAndSet(this, r, -1L)) {
/* 1759 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1765 */     static final AtomicLongFieldUpdater<DeferredSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(DeferredSubscription.class, "requested");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class MonoSubscriber<I, O>
/*      */     implements InnerOperator<I, O>, Fuseable, Fuseable.QueueSubscription<O>
/*      */   {
/*      */     protected final CoreSubscriber<? super O> actual;
/*      */     
/*      */     @Nullable
/*      */     protected O value;
/*      */     
/*      */     volatile int state;
/*      */     
/*      */     static final int NO_REQUEST_NO_VALUE = 0;
/*      */     
/*      */     static final int NO_REQUEST_HAS_VALUE = 1;
/*      */     
/*      */     static final int HAS_REQUEST_NO_VALUE = 2;
/*      */     
/*      */     static final int HAS_REQUEST_HAS_VALUE = 3;
/*      */     
/*      */     static final int CANCELLED = 4;
/*      */ 
/*      */     
/*      */     public MonoSubscriber(CoreSubscriber<? super O> actual) {
/* 1792 */       this.actual = actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 1797 */       O v = this.value;
/* 1798 */       this.value = null;
/* 1799 */       STATE.set(this, 4);
/* 1800 */       discard(v);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1806 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 1807 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.state == 3 || this.state == 1)); 
/* 1808 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647);
/*      */       
/* 1810 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void clear() {
/* 1815 */       this.value = null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void complete(@Nullable O v) {
/*      */       int state;
/*      */       do {
/* 1827 */         state = this.state;
/*      */ 
/*      */         
/* 1830 */         if ((state & 0xFFFFFFFD) != 0) {
/* 1831 */           this.value = null;
/* 1832 */           discard(v);
/*      */           
/*      */           return;
/*      */         } 
/* 1836 */         if (state == 2 && STATE.compareAndSet(this, 2, 3)) {
/* 1837 */           this.value = null;
/* 1838 */           CoreSubscriber<? super O> coreSubscriber = this.actual;
/* 1839 */           coreSubscriber.onNext(v);
/* 1840 */           coreSubscriber.onComplete();
/*      */           return;
/*      */         } 
/* 1843 */         setValue(v);
/* 1844 */       } while (state != 0 || !STATE.compareAndSet(this, 0, 1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void discard(@Nullable O v) {
/* 1858 */       Operators.onDiscard(v, this.actual.currentContext());
/*      */     }
/*      */ 
/*      */     
/*      */     public final CoreSubscriber<? super O> actual() {
/* 1863 */       return this.actual;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean isCancelled() {
/* 1871 */       return (this.state == 4);
/*      */     }
/*      */ 
/*      */     
/*      */     public final boolean isEmpty() {
/* 1876 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 1881 */       this.actual.onComplete();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 1886 */       this.actual.onError(t);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onNext(I t) {
/* 1892 */       setValue((O)t);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {}
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public final O poll() {
/* 1903 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 1908 */       if (Operators.validate(n)) {
/*      */         do {
/* 1910 */           int s = this.state;
/* 1911 */           if (s == 4) {
/*      */             return;
/*      */           }
/*      */           
/* 1915 */           if ((s & 0xFFFFFFFE) != 0) {
/*      */             return;
/*      */           }
/* 1918 */           if (s == 1 && STATE.compareAndSet(this, 1, 3)) {
/* 1919 */             O v = this.value;
/* 1920 */             if (v != null) {
/* 1921 */               this.value = null;
/* 1922 */               CoreSubscriber<? super O> coreSubscriber = this.actual;
/* 1923 */               coreSubscriber.onNext(v);
/* 1924 */               coreSubscriber.onComplete();
/*      */             } 
/*      */             return;
/*      */           } 
/* 1928 */         } while (!STATE.compareAndSet(this, 0, 2));
/*      */         return;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int requestFusion(int mode) {
/* 1937 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(@Nullable O value) {
/* 1948 */       if (STATE.get(this) == 4) {
/* 1949 */         discard(value);
/*      */         return;
/*      */       } 
/* 1952 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1957 */       return isEmpty() ? 0 : 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1983 */     static final AtomicIntegerFieldUpdater<MonoSubscriber> STATE = AtomicIntegerFieldUpdater.newUpdater(MonoSubscriber.class, "state");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class MultiSubscriptionSubscriber<I, O>
/*      */     implements InnerOperator<I, O>
/*      */   {
/*      */     final CoreSubscriber<? super O> actual;
/*      */ 
/*      */     
/*      */     protected boolean unbounded;
/*      */ 
/*      */     
/*      */     Subscription subscription;
/*      */ 
/*      */     
/*      */     long requested;
/*      */ 
/*      */     
/*      */     volatile Subscription missedSubscription;
/*      */ 
/*      */     
/*      */     volatile long missedRequested;
/*      */ 
/*      */     
/*      */     volatile long missedProduced;
/*      */ 
/*      */     
/*      */     volatile int wip;
/*      */ 
/*      */     
/*      */     volatile boolean cancelled;
/*      */ 
/*      */ 
/*      */     
/*      */     public MultiSubscriptionSubscriber(CoreSubscriber<? super O> actual) {
/* 2021 */       this.actual = actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super O> actual() {
/* 2026 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 2031 */       if (!this.cancelled) {
/* 2032 */         this.cancelled = true;
/*      */         
/* 2034 */         drain();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 2041 */       if (key == Scannable.Attr.PARENT)
/* 2042 */         return (this.missedSubscription != null) ? this.missedSubscription : this.subscription; 
/* 2043 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 2044 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/* 2045 */         return Long.valueOf(Operators.addCap(this.requested, this.missedRequested));
/*      */       }
/* 2047 */       return super.scanUnsafe(key);
/*      */     }
/*      */     
/*      */     public final boolean isUnbounded() {
/* 2051 */       return this.unbounded;
/*      */     }
/*      */     
/*      */     final boolean isCancelled() {
/* 2055 */       return this.cancelled;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 2060 */       this.actual.onComplete();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 2065 */       this.actual.onError(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 2070 */       set(s);
/*      */     }
/*      */     
/*      */     public final void produced(long n) {
/* 2074 */       if (this.unbounded) {
/*      */         return;
/*      */       }
/* 2077 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 2078 */         long r = this.requested;
/*      */         
/* 2080 */         if (r != Long.MAX_VALUE) {
/* 2081 */           long u = r - n;
/* 2082 */           if (u < 0L) {
/* 2083 */             Operators.reportMoreProduced();
/* 2084 */             u = 0L;
/*      */           } 
/* 2086 */           this.requested = u;
/*      */         } else {
/* 2088 */           this.unbounded = true;
/*      */         } 
/*      */         
/* 2091 */         if (WIP.decrementAndGet(this) == 0) {
/*      */           return;
/*      */         }
/*      */         
/* 2095 */         drainLoop();
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2100 */       Operators.addCap(MISSED_PRODUCED, this, n);
/*      */       
/* 2102 */       drain();
/*      */     }
/*      */     
/*      */     final void producedOne() {
/* 2106 */       if (this.unbounded) {
/*      */         return;
/*      */       }
/* 2109 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 2110 */         long r = this.requested;
/*      */         
/* 2112 */         if (r != Long.MAX_VALUE) {
/* 2113 */           r--;
/* 2114 */           if (r < 0L) {
/* 2115 */             Operators.reportMoreProduced();
/* 2116 */             r = 0L;
/*      */           } 
/* 2118 */           this.requested = r;
/*      */         } else {
/* 2120 */           this.unbounded = true;
/*      */         } 
/*      */         
/* 2123 */         if (WIP.decrementAndGet(this) == 0) {
/*      */           return;
/*      */         }
/*      */         
/* 2127 */         drainLoop();
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2132 */       Operators.addCap(MISSED_PRODUCED, this, 1L);
/*      */       
/* 2134 */       drain();
/*      */     }
/*      */ 
/*      */     
/*      */     public final void request(long n) {
/* 2139 */       if (Operators.validate(n)) {
/* 2140 */         if (this.unbounded) {
/*      */           return;
/*      */         }
/* 2143 */         if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 2144 */           long r = this.requested;
/*      */           
/* 2146 */           if (r != Long.MAX_VALUE) {
/* 2147 */             r = Operators.addCap(r, n);
/* 2148 */             this.requested = r;
/* 2149 */             if (r == Long.MAX_VALUE) {
/* 2150 */               this.unbounded = true;
/*      */             }
/*      */           } 
/* 2153 */           Subscription a = this.subscription;
/*      */           
/* 2155 */           if (WIP.decrementAndGet(this) != 0) {
/* 2156 */             drainLoop();
/*      */           }
/*      */           
/* 2159 */           if (a != null) {
/* 2160 */             a.request(n);
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/* 2166 */         Operators.addCap(MISSED_REQUESTED, this, n);
/*      */         
/* 2168 */         drain();
/*      */       } 
/*      */     }
/*      */     
/*      */     public final void set(Subscription s) {
/* 2173 */       if (this.cancelled) {
/* 2174 */         s.cancel();
/*      */         
/*      */         return;
/*      */       } 
/* 2178 */       Objects.requireNonNull(s);
/*      */       
/* 2180 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 2181 */         Subscription subscription = this.subscription;
/*      */         
/* 2183 */         if (subscription != null && shouldCancelCurrent()) {
/* 2184 */           subscription.cancel();
/*      */         }
/*      */         
/* 2187 */         this.subscription = s;
/*      */         
/* 2189 */         long r = this.requested;
/*      */         
/* 2191 */         if (WIP.decrementAndGet(this) != 0) {
/* 2192 */           drainLoop();
/*      */         }
/*      */         
/* 2195 */         if (r != 0L) {
/* 2196 */           s.request(r);
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2202 */       Subscription a = MISSED_SUBSCRIPTION.getAndSet(this, s);
/* 2203 */       if (a != null && shouldCancelCurrent()) {
/* 2204 */         a.cancel();
/*      */       }
/* 2206 */       drain();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean shouldCancelCurrent() {
/* 2215 */       return false;
/*      */     }
/*      */     
/*      */     final void drain() {
/* 2219 */       if (WIP.getAndIncrement(this) != 0) {
/*      */         return;
/*      */       }
/* 2222 */       drainLoop();
/*      */     }
/*      */     
/*      */     final void drainLoop() {
/* 2226 */       int missed = 1;
/*      */       
/* 2228 */       long requestAmount = 0L;
/* 2229 */       long alreadyInRequestAmount = 0L;
/* 2230 */       Subscription requestTarget = null;
/*      */ 
/*      */       
/*      */       while (true) {
/* 2234 */         Subscription ms = this.missedSubscription;
/*      */         
/* 2236 */         if (ms != null) {
/* 2237 */           ms = MISSED_SUBSCRIPTION.getAndSet(this, null);
/*      */         }
/*      */         
/* 2240 */         long mr = this.missedRequested;
/* 2241 */         if (mr != 0L) {
/* 2242 */           mr = MISSED_REQUESTED.getAndSet(this, 0L);
/*      */         }
/*      */         
/* 2245 */         long mp = this.missedProduced;
/* 2246 */         if (mp != 0L) {
/* 2247 */           mp = MISSED_PRODUCED.getAndSet(this, 0L);
/*      */         }
/*      */         
/* 2250 */         Subscription a = this.subscription;
/*      */         
/* 2252 */         if (this.cancelled) {
/* 2253 */           if (a != null) {
/* 2254 */             a.cancel();
/* 2255 */             this.subscription = null;
/*      */           } 
/* 2257 */           if (ms != null) {
/* 2258 */             ms.cancel();
/*      */           }
/*      */         } else {
/* 2261 */           long r = this.requested;
/* 2262 */           if (r != Long.MAX_VALUE) {
/* 2263 */             long u = Operators.addCap(r, mr);
/*      */             
/* 2265 */             if (u != Long.MAX_VALUE) {
/* 2266 */               long v = u - mp;
/* 2267 */               if (v < 0L) {
/* 2268 */                 Operators.reportMoreProduced();
/* 2269 */                 v = 0L;
/*      */               } 
/* 2271 */               r = v;
/*      */             } else {
/* 2273 */               r = u;
/*      */             } 
/* 2275 */             this.requested = r;
/*      */           } 
/*      */           
/* 2278 */           if (ms != null) {
/* 2279 */             if (a != null && shouldCancelCurrent()) {
/* 2280 */               a.cancel();
/*      */             }
/* 2282 */             this.subscription = ms;
/* 2283 */             if (r != 0L) {
/* 2284 */               requestAmount = Operators.addCap(requestAmount, r - alreadyInRequestAmount);
/* 2285 */               requestTarget = ms;
/*      */             } 
/* 2287 */           } else if (mr != 0L && a != null) {
/* 2288 */             requestAmount = Operators.addCap(requestAmount, mr);
/* 2289 */             alreadyInRequestAmount += mr;
/* 2290 */             requestTarget = a;
/*      */           } 
/*      */         } 
/*      */         
/* 2294 */         missed = WIP.addAndGet(this, -missed);
/* 2295 */         if (missed == 0) {
/* 2296 */           if (requestAmount != 0L) {
/* 2297 */             requestTarget.request(requestAmount);
/*      */           }
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2306 */     static final AtomicReferenceFieldUpdater<MultiSubscriptionSubscriber, Subscription> MISSED_SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(MultiSubscriptionSubscriber.class, Subscription.class, "missedSubscription");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2312 */     static final AtomicLongFieldUpdater<MultiSubscriptionSubscriber> MISSED_REQUESTED = AtomicLongFieldUpdater.newUpdater(MultiSubscriptionSubscriber.class, "missedRequested");
/*      */ 
/*      */     
/* 2315 */     static final AtomicLongFieldUpdater<MultiSubscriptionSubscriber> MISSED_PRODUCED = AtomicLongFieldUpdater.newUpdater(MultiSubscriptionSubscriber.class, "missedProduced");
/*      */ 
/*      */     
/* 2318 */     static final AtomicIntegerFieldUpdater<MultiSubscriptionSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(MultiSubscriptionSubscriber.class, "wip");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class ScalarSubscription<T>
/*      */     implements Fuseable.SynchronousSubscription<T>, InnerProducer<T>
/*      */   {
/*      */     final CoreSubscriber<? super T> actual;
/*      */ 
/*      */     
/*      */     final T value;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     final String stepName;
/*      */ 
/*      */     
/*      */     volatile int once;
/*      */ 
/*      */     
/*      */     ScalarSubscription(CoreSubscriber<? super T> actual, T value) {
/* 2340 */       this(actual, value, null);
/*      */     }
/*      */     
/*      */     ScalarSubscription(CoreSubscriber<? super T> actual, T value, String stepName) {
/* 2344 */       this.value = Objects.requireNonNull(value, "value");
/* 2345 */       this.actual = Objects.<CoreSubscriber<? super T>>requireNonNull(actual, "actual");
/* 2346 */       this.stepName = stepName;
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/* 2351 */       if (this.once == 0) {
/* 2352 */         Operators.onDiscard(this.value, this.actual.currentContext());
/*      */       }
/* 2354 */       ONCE.lazySet(this, 2);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 2359 */       if (this.once == 0) {
/* 2360 */         Operators.onDiscard(this.value, this.actual.currentContext());
/*      */       }
/* 2362 */       ONCE.lazySet(this, 1);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 2367 */       return (this.once != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> actual() {
/* 2372 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public T poll() {
/* 2378 */       if (this.once == 0) {
/* 2379 */         ONCE.lazySet(this, 1);
/* 2380 */         return this.value;
/*      */       } 
/* 2382 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 2388 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.once == 1)); 
/* 2389 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.once == 2)); 
/* 2390 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/* 2392 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 2397 */       if (Operators.validate(n) && 
/* 2398 */         ONCE.compareAndSet(this, 0, 1)) {
/* 2399 */         CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 2400 */         coreSubscriber.onNext(this.value);
/* 2401 */         if (this.once != 2) {
/* 2402 */           coreSubscriber.onComplete();
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int requestFusion(int requestedMode) {
/* 2410 */       if ((requestedMode & 0x1) != 0) {
/* 2411 */         return 1;
/*      */       }
/* 2413 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 2418 */       return isEmpty() ? 0 : 1;
/*      */     }
/*      */ 
/*      */     
/*      */     public String stepName() {
/* 2423 */       return (this.stepName != null) ? this.stepName : ("scalarSubscription(" + this.value + ")");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2428 */     static final AtomicIntegerFieldUpdater<ScalarSubscription> ONCE = AtomicIntegerFieldUpdater.newUpdater(ScalarSubscription.class, "once");
/*      */   }
/*      */   
/*      */   static final class DrainSubscriber<T>
/*      */     implements CoreSubscriber<T> {
/* 2433 */     static final DrainSubscriber INSTANCE = new DrainSubscriber();
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 2437 */       s.request(Long.MAX_VALUE);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onNext(Object o) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 2447 */       Operators.onErrorDropped(Exceptions.errorCallbackNotImplemented(t), Context.empty());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onComplete() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 2457 */       return Context.empty();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class ConditionalSubscriberAdapter<T>
/*      */     implements Fuseable.ConditionalSubscriber<T>
/*      */   {
/*      */     final CoreSubscriber<T> delegate;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ConditionalSubscriberAdapter(CoreSubscriber<T> delegate) {
/* 2473 */       this.delegate = delegate;
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 2478 */       return this.delegate.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/* 2483 */       this.delegate.onSubscribe(s);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/* 2488 */       this.delegate.onNext(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 2493 */       this.delegate.onError(t);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 2498 */       this.delegate.onComplete();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryOnNext(T t) {
/* 2503 */       this.delegate.onNext(t);
/* 2504 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class LiftFunction<I, O>
/*      */     implements Function<Publisher<I>, Publisher<O>>
/*      */   {
/*      */     final Predicate<Publisher> filter;
/*      */     
/*      */     final String name;
/*      */     
/*      */     final BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter;
/*      */ 
/*      */     
/*      */     static final <I, O> LiftFunction<I, O> liftScannable(@Nullable Predicate<Scannable> filter, BiFunction<Scannable, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter) {
/* 2520 */       Objects.requireNonNull(lifter, "lifter");
/*      */       
/* 2522 */       Predicate<Publisher> effectiveFilter = null;
/* 2523 */       if (filter != null) {
/* 2524 */         effectiveFilter = (pub -> filter.test(Scannable.from(pub)));
/*      */       }
/*      */ 
/*      */       
/* 2528 */       BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> effectiveLifter = (pub, sub) -> (CoreSubscriber)lifter.apply(Scannable.from(pub), sub);
/*      */       
/* 2530 */       return new LiftFunction<>(effectiveFilter, effectiveLifter, lifter.toString());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     static final <I, O> LiftFunction<I, O> liftPublisher(@Nullable Predicate<Publisher> filter, BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter) {
/* 2536 */       Objects.requireNonNull(lifter, "lifter");
/* 2537 */       return new LiftFunction<>(filter, lifter, lifter.toString());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private LiftFunction(@Nullable Predicate<Publisher> filter, BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>> lifter, String name) {
/* 2543 */       this.filter = filter;
/* 2544 */       this.lifter = Objects.<BiFunction<Publisher, ? super CoreSubscriber<? super O>, ? extends CoreSubscriber<? super I>>>requireNonNull(lifter, "lifter");
/* 2545 */       this.name = Objects.<String>requireNonNull(name, "name");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Publisher<O> apply(Publisher<I> publisher) {
/* 2551 */       if (this.filter != null && !this.filter.test(publisher)) {
/* 2552 */         return publisher;
/*      */       }
/*      */       
/* 2555 */       if (publisher instanceof Fuseable) {
/* 2556 */         if (publisher instanceof Mono) {
/* 2557 */           return (Publisher)new MonoLiftFuseable<>(publisher, this);
/*      */         }
/* 2559 */         if (publisher instanceof ParallelFlux) {
/* 2560 */           return (Publisher)new ParallelLiftFuseable<>((ParallelFlux<I>)publisher, this);
/*      */         }
/* 2562 */         if (publisher instanceof ConnectableFlux) {
/* 2563 */           return (Publisher)new ConnectableLiftFuseable<>((ConnectableFlux<I>)publisher, this);
/*      */         }
/* 2565 */         if (publisher instanceof GroupedFlux) {
/* 2566 */           return (Publisher)new GroupedLiftFuseable<>((GroupedFlux)publisher, this);
/*      */         }
/* 2568 */         return (Publisher)new FluxLiftFuseable<>(publisher, this);
/*      */       } 
/*      */       
/* 2571 */       if (publisher instanceof Mono) {
/* 2572 */         return (Publisher)new MonoLift<>(publisher, this);
/*      */       }
/* 2574 */       if (publisher instanceof ParallelFlux) {
/* 2575 */         return (Publisher)new ParallelLift<>((ParallelFlux<I>)publisher, this);
/*      */       }
/* 2577 */       if (publisher instanceof ConnectableFlux) {
/* 2578 */         return (Publisher)new ConnectableLift<>((ConnectableFlux<I>)publisher, this);
/*      */       }
/* 2580 */       if (publisher instanceof GroupedFlux) {
/* 2581 */         return (Publisher)new GroupedLift<>((GroupedFlux)publisher, this);
/*      */       }
/* 2583 */       return (Publisher)new FluxLift<>(publisher, this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class MonoInnerProducerBase<O>
/*      */     implements InnerProducer<O>
/*      */   {
/*      */     private final CoreSubscriber<? super O> actual;
/*      */ 
/*      */     
/*      */     private O value;
/*      */ 
/*      */     
/*      */     private volatile int state;
/*      */ 
/*      */     
/* 2601 */     private static final AtomicIntegerFieldUpdater<MonoInnerProducerBase> STATE = AtomicIntegerFieldUpdater.newUpdater(MonoInnerProducerBase.class, "state"); private static final int HAS_VALUE = 1; private static final int HAS_REQUEST = 2;
/*      */     
/*      */     public MonoInnerProducerBase(CoreSubscriber<? super O> actual) {
/* 2604 */       this.actual = actual;
/*      */     }
/*      */     private static final int HAS_COMPLETED = 4; private static final int CANCELLED = 128;
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 2610 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 2611 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(hasCompleted(this.state)); 
/* 2612 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 2613 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void complete(O v) {
/*      */       int s;
/*      */       do {
/* 2625 */         s = this.state;
/* 2626 */         if (isCancelled(s)) {
/* 2627 */           discard(v);
/*      */           
/*      */           return;
/*      */         } 
/* 2631 */         if (hasRequest(s) && STATE.compareAndSet(this, s, s | 0x5)) {
/* 2632 */           this.value = null;
/*      */           
/* 2634 */           doOnComplete(v);
/*      */           
/* 2636 */           this.actual.onNext(v);
/* 2637 */           this.actual.onComplete();
/*      */           
/*      */           return;
/*      */         } 
/* 2641 */         this.value = v;
/* 2642 */       } while (!STATE.compareAndSet(this, s, s | 0x5));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void complete() {
/*      */       while (true) {
/* 2655 */         int s = this.state;
/* 2656 */         if (isCancelled(s)) {
/*      */           return;
/*      */         }
/* 2659 */         if (STATE.compareAndSet(this, s, s | 0x4)) {
/* 2660 */           if (hasValue(s) && hasRequest(s)) {
/* 2661 */             O v = this.value;
/* 2662 */             this.value = null;
/*      */             
/* 2664 */             doOnComplete(v);
/*      */             
/* 2666 */             this.actual.onNext(v);
/* 2667 */             this.actual.onComplete();
/*      */             return;
/*      */           } 
/* 2670 */           if (!hasValue(s)) {
/* 2671 */             this.actual.onComplete();
/*      */             return;
/*      */           } 
/* 2674 */           if (!hasRequest(s)) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void doOnComplete(O v) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final void discard(@Nullable O v) {
/* 2699 */       Operators.onDiscard(v, this.actual.currentContext());
/*      */     }
/*      */     
/*      */     protected final void discardTheValue() {
/* 2703 */       discard(this.value);
/* 2704 */       this.value = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public final CoreSubscriber<? super O> actual() {
/* 2709 */       return this.actual;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean isCancelled() {
/* 2717 */       return (this.state == 128);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void request(long n) {
/* 2723 */       if (Operators.validate(n)) {
/*      */         while (true) {
/* 2725 */           int s = this.state;
/* 2726 */           if (isCancelled(s)) {
/*      */             return;
/*      */           }
/* 2729 */           if (hasRequest(s)) {
/*      */             return;
/*      */           }
/* 2732 */           if (STATE.compareAndSet(this, s, s | 0x2)) {
/* 2733 */             doOnRequest(n);
/* 2734 */             if (hasValue(s) && hasCompleted(s)) {
/* 2735 */               O v = this.value;
/* 2736 */               this.value = null;
/*      */               
/* 2738 */               doOnComplete(v);
/*      */               
/* 2740 */               this.actual.onNext(v);
/* 2741 */               this.actual.onComplete();
/*      */             } 
/*      */             return;
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void doOnRequest(long n) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final void setValue(@Nullable O value) {
/*      */       int s;
/* 2765 */       this.value = value;
/*      */       do {
/* 2767 */         s = this.state;
/* 2768 */         if (isCancelled(s)) {
/* 2769 */           discardTheValue();
/*      */           return;
/*      */         } 
/* 2772 */       } while (!STATE.compareAndSet(this, s, s | 0x1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void cancel() {
/* 2780 */       int previous = STATE.getAndSet(this, 128);
/*      */       
/* 2782 */       if (isCancelled(previous)) {
/*      */         return;
/*      */       }
/*      */       
/* 2786 */       doOnCancel();
/*      */       
/* 2788 */       if (hasValue(previous) && (previous & 0x6) != 6)
/*      */       {
/*      */         
/* 2791 */         discardTheValue();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void doOnCancel() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean isCancelled(int s) {
/* 2811 */       return (s == 128);
/*      */     }
/*      */     
/*      */     private static boolean hasRequest(int s) {
/* 2815 */       return ((s & 0x2) == 2);
/*      */     }
/*      */     
/*      */     private static boolean hasValue(int s) {
/* 2819 */       return ((s & 0x1) == 1);
/*      */     }
/*      */     
/*      */     private static boolean hasCompleted(int s) {
/* 2823 */       return ((s & 0x4) == 4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2829 */   static final Logger log = Loggers.getLogger(Operators.class);
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\Operators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */