/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxCallableOnAssembly<T>
/*    */   extends InternalFluxOperator<T, T>
/*    */   implements Fuseable, Callable<T>, AssemblyOp
/*    */ {
/*    */   final FluxOnAssembly.AssemblySnapshot stacktrace;
/*    */   
/*    */   FluxCallableOnAssembly(Flux<? extends T> source, FluxOnAssembly.AssemblySnapshot stacktrace) {
/* 44 */     super(source);
/* 45 */     this.stacktrace = stacktrace;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 50 */     return FluxOnAssembly.wrapSubscriber(actual, this.source, (Publisher<?>)this, this.stacktrace);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T call() throws Exception {
/* 56 */     return ((Callable)this.source).call();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 61 */     if (key == Scannable.Attr.ACTUAL_METADATA) return Boolean.valueOf(!this.stacktrace.isCheckpoint); 
/* 62 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 64 */     return super.scanUnsafe(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 69 */     return this.stacktrace.operatorAssemblyInformation();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return this.stacktrace.operatorAssemblyInformation();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxCallableOnAssembly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */