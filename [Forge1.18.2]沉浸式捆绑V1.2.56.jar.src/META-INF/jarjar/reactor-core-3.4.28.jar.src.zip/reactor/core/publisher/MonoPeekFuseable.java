/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongConsumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoPeekFuseable<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */   implements Fuseable, SignalPeek<T>
/*     */ {
/*     */   final Consumer<? super Subscription> onSubscribeCall;
/*     */   final Consumer<? super T> onNextCall;
/*     */   final LongConsumer onRequestCall;
/*     */   final Runnable onCancelCall;
/*     */   
/*     */   MonoPeekFuseable(Mono<? extends T> source, @Nullable Consumer<? super Subscription> onSubscribeCall, @Nullable Consumer<? super T> onNextCall, @Nullable LongConsumer onRequestCall, @Nullable Runnable onCancelCall) {
/*  50 */     super(source);
/*     */     
/*  52 */     this.onSubscribeCall = onSubscribeCall;
/*  53 */     this.onNextCall = onNextCall;
/*  54 */     this.onRequestCall = onRequestCall;
/*  55 */     this.onCancelCall = onCancelCall;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  61 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  62 */       return new FluxPeekFuseable.PeekFuseableConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this);
/*     */     }
/*     */     
/*  65 */     return new FluxPeekFuseable.PeekFuseableSubscriber<>(actual, this);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Subscription> onSubscribeCall() {
/*  71 */     return this.onSubscribeCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super T> onNextCall() {
/*  77 */     return this.onNextCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Throwable> onErrorCall() {
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCompleteCall() {
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onAfterTerminateCall() {
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LongConsumer onRequestCall() {
/* 101 */     return this.onRequestCall;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCancelCall() {
/* 107 */     return this.onCancelCall;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 112 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 113 */     return super.scanUnsafe(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoPeekFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */