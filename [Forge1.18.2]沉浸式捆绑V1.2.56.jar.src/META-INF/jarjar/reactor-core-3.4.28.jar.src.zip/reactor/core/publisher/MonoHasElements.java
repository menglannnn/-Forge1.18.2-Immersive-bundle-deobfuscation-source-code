/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoHasElements<T>
/*    */   extends MonoFromFluxOperator<T, Boolean>
/*    */   implements Fuseable
/*    */ {
/*    */   MonoHasElements(Flux<? extends T> source) {
/* 32 */     super(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Boolean> actual) {
/* 37 */     return new HasElementsSubscriber<>(actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 42 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 43 */     return super.scanUnsafe(key);
/*    */   }
/*    */   
/*    */   static final class HasElementsSubscriber<T> extends Operators.MonoSubscriber<T, Boolean> {
/*    */     Subscription s;
/*    */     
/*    */     HasElementsSubscriber(CoreSubscriber<? super Boolean> actual) {
/* 50 */       super(actual);
/*    */     }
/*    */ 
/*    */     
/*    */     @Nullable
/*    */     public Object scanUnsafe(Scannable.Attr key) {
/* 56 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 57 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */       
/* 59 */       return super.scanUnsafe(key);
/*    */     }
/*    */ 
/*    */     
/*    */     public void cancel() {
/* 64 */       super.cancel();
/* 65 */       this.s.cancel();
/*    */     }
/*    */ 
/*    */     
/*    */     public void onSubscribe(Subscription s) {
/* 70 */       if (Operators.validate(this.s, s)) {
/* 71 */         this.s = s;
/* 72 */         this.actual.onSubscribe(this);
/*    */         
/* 74 */         s.request(Long.MAX_VALUE);
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     public void onNext(T t) {
/* 80 */       this.s.cancel();
/*    */       
/* 82 */       complete(Boolean.valueOf(true));
/*    */     }
/*    */ 
/*    */     
/*    */     public void onComplete() {
/* 87 */       complete(Boolean.valueOf(false));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoHasElements.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */