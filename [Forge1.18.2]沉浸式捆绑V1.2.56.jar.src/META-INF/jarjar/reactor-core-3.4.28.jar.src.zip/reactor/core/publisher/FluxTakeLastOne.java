/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxTakeLastOne<T>
/*    */   extends InternalFluxOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   FluxTakeLastOne(Flux<? extends T> source) {
/* 31 */     super(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 36 */     return new MonoTakeLastOne.TakeLastOneSubscriber<>(actual, null, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 41 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 46 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 47 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxTakeLastOne.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */