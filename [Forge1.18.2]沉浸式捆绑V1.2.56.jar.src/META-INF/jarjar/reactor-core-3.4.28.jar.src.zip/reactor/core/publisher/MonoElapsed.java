/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ import reactor.util.function.Tuple2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoElapsed<T>
/*    */   extends InternalMonoOperator<T, Tuple2<Long, T>>
/*    */   implements Fuseable
/*    */ {
/*    */   final Scheduler scheduler;
/*    */   
/*    */   MonoElapsed(Mono<T> source, Scheduler scheduler) {
/* 32 */     super(source);
/* 33 */     this.scheduler = scheduler;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Tuple2<Long, T>> actual) {
/* 38 */     return new FluxElapsed.ElapsedSubscriber<>(actual, this.scheduler);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 43 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/* 44 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 46 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoElapsed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */