/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoMaterialize<T>
/*     */   extends InternalMonoOperator<T, Signal<T>>
/*     */ {
/*     */   MonoMaterialize(Mono<T> source) {
/*  31 */     super(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Signal<T>> actual) {
/*  36 */     return new MaterializeSubscriber<>(actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  41 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  42 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MaterializeSubscriber<T>
/*     */     implements InnerOperator<T, Signal<T>>
/*     */   {
/*     */     final CoreSubscriber<? super Signal<T>> actual;
/*     */ 
/*     */     
/*     */     boolean alreadyReceivedSignalFromSource;
/*     */ 
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     volatile boolean requested;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     volatile Signal<T> signalToReplayUponFirstRequest;
/*     */ 
/*     */ 
/*     */     
/*     */     MaterializeSubscriber(CoreSubscriber<? super Signal<T>> actual) {
/*  69 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Signal<T>> actual() {
/*  74 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  80 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  81 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  83 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  88 */       if (Operators.validate(this.s, s)) {
/*  89 */         this.s = s;
/*  90 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  96 */       if (this.alreadyReceivedSignalFromSource || !this.requested) {
/*     */         
/*  98 */         Operators.onNextDropped(t, currentContext());
/*     */         return;
/*     */       } 
/* 101 */       this.alreadyReceivedSignalFromSource = true;
/* 102 */       Signal<T> signal = Signal.next(t, currentContext());
/* 103 */       this.actual.onNext(signal);
/* 104 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 109 */       if (this.alreadyReceivedSignalFromSource) {
/*     */         
/* 111 */         Operators.onErrorDropped(throwable, currentContext());
/*     */         return;
/*     */       } 
/* 114 */       this.alreadyReceivedSignalFromSource = true;
/* 115 */       this.signalToReplayUponFirstRequest = Signal.error(throwable, currentContext());
/* 116 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 121 */       if (this.alreadyReceivedSignalFromSource) {
/*     */         return;
/*     */       }
/*     */       
/* 125 */       this.alreadyReceivedSignalFromSource = true;
/* 126 */       this.signalToReplayUponFirstRequest = Signal.complete(currentContext());
/* 127 */       drain();
/*     */     }
/*     */     
/*     */     boolean drain() {
/* 131 */       Signal<T> signal = this.signalToReplayUponFirstRequest;
/* 132 */       if (signal != null && this.requested) {
/* 133 */         this.actual.onNext(signal);
/* 134 */         this.actual.onComplete();
/* 135 */         this.signalToReplayUponFirstRequest = null;
/* 136 */         return true;
/*     */       } 
/* 138 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long l) {
/* 143 */       if (!this.requested && Operators.validate(l)) {
/* 144 */         this.requested = true;
/* 145 */         if (drain()) {
/*     */           return;
/*     */         }
/* 148 */         this.s.request(l);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 154 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoMaterialize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */