/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxRepeat<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final long times;
/*     */   
/*     */   FluxRepeat(Flux<? extends T> source, long times) {
/*  41 */     super(source);
/*  42 */     if (times <= 0L) {
/*  43 */       throw new IllegalArgumentException("times > 0 required");
/*     */     }
/*  45 */     this.times = times;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  50 */     RepeatSubscriber<T> parent = new RepeatSubscriber<>(this.source, actual, this.times + 1L);
/*     */     
/*  52 */     actual.onSubscribe(parent);
/*     */     
/*  54 */     if (!parent.isCancelled()) {
/*  55 */       parent.onComplete();
/*     */     }
/*  57 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  62 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  63 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RepeatSubscriber<T>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */   {
/*     */     final CorePublisher<? extends T> source;
/*     */     
/*     */     long remaining;
/*     */     
/*     */     volatile int wip;
/*     */     
/*  76 */     static final AtomicIntegerFieldUpdater<RepeatSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(RepeatSubscriber.class, "wip");
/*     */     
/*     */     long produced;
/*     */     
/*     */     RepeatSubscriber(CorePublisher<? extends T> source, CoreSubscriber<? super T> actual, long remaining) {
/*  81 */       super(actual);
/*  82 */       this.source = source;
/*  83 */       this.remaining = remaining;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  88 */       this.produced++;
/*     */       
/*  90 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/*  95 */       long r = this.remaining;
/*  96 */       if (r != Long.MAX_VALUE) {
/*  97 */         if (r == 0L) {
/*  98 */           this.actual.onComplete();
/*     */           return;
/*     */         } 
/* 101 */         this.remaining = r - 1L;
/*     */       } 
/*     */       
/* 104 */       resubscribe();
/*     */     }
/*     */     
/*     */     void resubscribe() {
/* 108 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         do {
/* 110 */           if (isCancelled()) {
/*     */             return;
/*     */           }
/*     */           
/* 114 */           long c = this.produced;
/* 115 */           if (c != 0L) {
/* 116 */             this.produced = 0L;
/* 117 */             produced(c);
/*     */           } 
/*     */           
/* 120 */           this.source.subscribe(this);
/*     */         }
/* 122 */         while (WIP.decrementAndGet(this) != 0);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 128 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 129 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxRepeat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */