/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSampleFirst<T, U>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<U>> throttler;
/*     */   
/*     */   FluxSampleFirst(Flux<? extends T> source, Function<? super T, ? extends Publisher<U>> throttler) {
/*  50 */     super(source);
/*  51 */     this.throttler = Objects.<Function<? super T, ? extends Publisher<U>>>requireNonNull(throttler, "throttler");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  56 */     SampleFirstMain<T, U> main = new SampleFirstMain<>(actual, this.throttler);
/*     */     
/*  58 */     actual.onSubscribe(main);
/*     */     
/*  60 */     return main;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  65 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  70 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  71 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SampleFirstMain<T, U>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final Function<? super T, ? extends Publisher<U>> throttler;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     volatile boolean gate;
/*     */     volatile Subscription s;
/*  86 */     static final AtomicReferenceFieldUpdater<SampleFirstMain, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(SampleFirstMain.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Subscription other;
/*     */ 
/*     */     
/*  93 */     static final AtomicReferenceFieldUpdater<SampleFirstMain, Subscription> OTHER = AtomicReferenceFieldUpdater.newUpdater(SampleFirstMain.class, Subscription.class, "other");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 100 */     static final AtomicLongFieldUpdater<SampleFirstMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(SampleFirstMain.class, "requested");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/* 105 */     static final AtomicIntegerFieldUpdater<SampleFirstMain> WIP = AtomicIntegerFieldUpdater.newUpdater(SampleFirstMain.class, "wip");
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 110 */     static final AtomicReferenceFieldUpdater<SampleFirstMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(SampleFirstMain.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SampleFirstMain(CoreSubscriber<? super T> actual, Function<? super T, ? extends Publisher<U>> throttler) {
/* 116 */       this.actual = actual;
/* 117 */       this.ctx = actual.currentContext();
/* 118 */       this.throttler = throttler;
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 123 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 128 */       return Stream.of(Scannable.from(this.other));
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 134 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 135 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 136 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 137 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 138 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 140 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 145 */       if (Operators.validate(n)) {
/* 146 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 152 */       Operators.terminate(S, this);
/* 153 */       Operators.terminate(OTHER, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 158 */       if (Operators.setOnce(S, this, s)) {
/* 159 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 165 */       if (!this.gate) {
/* 166 */         Publisher<U> p; this.gate = true;
/*     */         
/* 168 */         if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 169 */           this.actual.onNext(t);
/* 170 */           if (WIP.decrementAndGet(this) != 0) {
/* 171 */             handleTermination();
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } else {
/*     */           return;
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 182 */           p = Objects.<Publisher<U>>requireNonNull(this.throttler.apply(t), "The throttler returned a null publisher");
/*     */         
/*     */         }
/* 185 */         catch (Throwable e) {
/* 186 */           Operators.terminate(S, this);
/* 187 */           error(Operators.onOperatorError(null, e, t, this.ctx));
/*     */           
/*     */           return;
/*     */         } 
/* 191 */         FluxSampleFirst.SampleFirstOther<U> other = new FluxSampleFirst.SampleFirstOther<>(this);
/*     */         
/* 193 */         if (Operators.replace(OTHER, this, other)) {
/* 194 */           p.subscribe((Subscriber)other);
/*     */         }
/*     */       } else {
/*     */         
/* 198 */         Operators.onDiscard(t, this.ctx);
/*     */       } 
/*     */     }
/*     */     
/*     */     void handleTermination() {
/* 203 */       Throwable e = Exceptions.terminate(ERROR, this);
/* 204 */       if (e != null && e != Exceptions.TERMINATED) {
/* 205 */         this.actual.onError(e);
/*     */       } else {
/*     */         
/* 208 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */     
/*     */     void error(Throwable e) {
/* 213 */       if (Exceptions.addThrowable(ERROR, this, e)) {
/* 214 */         if (WIP.getAndIncrement(this) == 0) {
/* 215 */           handleTermination();
/*     */         }
/*     */       } else {
/*     */         
/* 219 */         Operators.onErrorDropped(e, this.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 225 */       Operators.terminate(OTHER, this);
/*     */       
/* 227 */       error(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 232 */       Operators.terminate(OTHER, this);
/*     */       
/* 234 */       if (WIP.getAndIncrement(this) == 0) {
/* 235 */         handleTermination();
/*     */       }
/*     */     }
/*     */     
/*     */     void otherNext() {
/* 240 */       this.gate = false;
/*     */     }
/*     */     
/*     */     void otherError(Throwable e) {
/* 244 */       Operators.terminate(S, this);
/*     */       
/* 246 */       error(e);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SampleFirstOther<U>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerConsumer<U> {
/*     */     final FluxSampleFirst.SampleFirstMain<?, U> main;
/*     */     
/*     */     SampleFirstOther(FluxSampleFirst.SampleFirstMain<?, U> main) {
/* 256 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 261 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 267 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/* 268 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 270 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 275 */       if (set(s)) {
/* 276 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 282 */       cancel();
/*     */       
/* 284 */       this.main.otherNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 289 */       this.main.otherError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 294 */       this.main.otherNext();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxSampleFirst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */