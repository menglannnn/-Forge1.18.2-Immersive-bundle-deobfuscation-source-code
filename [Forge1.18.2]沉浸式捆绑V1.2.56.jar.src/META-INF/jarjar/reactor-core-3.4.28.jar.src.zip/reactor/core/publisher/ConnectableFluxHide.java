/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConnectableFluxHide<T>
/*    */   extends InternalConnectableFluxOperator<T, T>
/*    */   implements Scannable
/*    */ {
/*    */   ConnectableFluxHide(ConnectableFlux<T> source) {
/* 35 */     super(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 40 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 46 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 47 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 48 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 50 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public final CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 55 */     return actual;
/*    */   }
/*    */ 
/*    */   
/*    */   public void connect(Consumer<? super Disposable> cancelSupport) {
/* 60 */     this.source.connect(cancelSupport);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\ConnectableFluxHide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */