/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoSubscribeOn<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */ {
/*     */   final Scheduler scheduler;
/*     */   
/*     */   MonoSubscribeOn(Mono<? extends T> source, Scheduler scheduler) {
/*  42 */     super(source);
/*  43 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  48 */     Scheduler.Worker worker = this.scheduler.createWorker();
/*     */     
/*  50 */     SubscribeOnSubscriber<T> parent = new SubscribeOnSubscriber<>((Publisher<? extends T>)this.source, actual, worker);
/*     */     
/*  52 */     actual.onSubscribe(parent);
/*     */     
/*     */     try {
/*  55 */       worker.schedule(parent);
/*     */     }
/*  57 */     catch (RejectedExecutionException ree) {
/*  58 */       if (parent.s != Operators.cancelledSubscription()) {
/*  59 */         actual.onError(Operators.onRejectedExecution(ree, parent, null, null, actual
/*  60 */               .currentContext()));
/*     */       }
/*     */     } 
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  68 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  69 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  71 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SubscribeOnSubscriber<T>
/*     */     implements InnerOperator<T, T>, Runnable
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Publisher<? extends T> parent;
/*     */     
/*     */     final Scheduler.Worker worker;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/*  86 */     static final AtomicReferenceFieldUpdater<SubscribeOnSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(SubscribeOnSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/*  93 */     static final AtomicLongFieldUpdater<SubscribeOnSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(SubscribeOnSubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     volatile Thread thread;
/*     */ 
/*     */     
/*  99 */     static final AtomicReferenceFieldUpdater<SubscribeOnSubscriber, Thread> THREAD = AtomicReferenceFieldUpdater.newUpdater(SubscribeOnSubscriber.class, Thread.class, "thread");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SubscribeOnSubscriber(Publisher<? extends T> parent, CoreSubscriber<? super T> actual, Scheduler.Worker worker) {
/* 106 */       this.actual = actual;
/* 107 */       this.parent = parent;
/* 108 */       this.worker = worker;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 114 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 115 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 116 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 117 */       if (key == Scannable.Attr.RUN_ON) return this.worker; 
/* 118 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 120 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 125 */       THREAD.lazySet(this, Thread.currentThread());
/* 126 */       this.parent.subscribe((Subscriber)this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 131 */       if (Operators.setOnce(S, this, s)) {
/* 132 */         long r = REQUESTED.getAndSet(this, 0L);
/* 133 */         if (r != 0L) {
/* 134 */           trySchedule(r, s);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 141 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 146 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*     */       try {
/* 152 */         this.actual.onError(t);
/*     */       } finally {
/*     */         
/* 155 */         this.worker.dispose();
/* 156 */         THREAD.lazySet(this, null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 162 */       this.actual.onComplete();
/* 163 */       this.worker.dispose();
/* 164 */       THREAD.lazySet(this, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 169 */       if (Operators.validate(n)) {
/* 170 */         Subscription a = this.s;
/* 171 */         if (a != null) {
/* 172 */           trySchedule(n, a);
/*     */         } else {
/*     */           
/* 175 */           Operators.addCap(REQUESTED, this, n);
/* 176 */           a = this.s;
/* 177 */           if (a != null) {
/* 178 */             long r = REQUESTED.getAndSet(this, 0L);
/* 179 */             if (r != 0L) {
/* 180 */               trySchedule(n, a);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void trySchedule(long n, Subscription s) {
/* 188 */       if (Thread.currentThread() == THREAD.get(this)) {
/* 189 */         s.request(n);
/*     */       } else {
/*     */         
/*     */         try {
/* 193 */           this.worker.schedule(() -> s.request(n));
/*     */         
/*     */         }
/* 196 */         catch (RejectedExecutionException ree) {
/* 197 */           if (!this.worker.isDisposed()) {
/* 198 */             this.actual.onError(Operators.onRejectedExecution(ree, this, null, null, this.actual
/*     */ 
/*     */ 
/*     */                   
/* 202 */                   .currentContext()));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 210 */       Operators.terminate(S, this);
/* 211 */       this.worker.dispose();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoSubscribeOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */