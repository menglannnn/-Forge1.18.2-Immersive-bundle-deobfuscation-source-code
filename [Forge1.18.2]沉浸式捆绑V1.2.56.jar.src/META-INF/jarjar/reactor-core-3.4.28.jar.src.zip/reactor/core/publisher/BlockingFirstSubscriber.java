/*    */ package reactor.core.publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BlockingFirstSubscriber<T>
/*    */   extends BlockingSingleSubscriber<T>
/*    */ {
/*    */   public void onNext(T t) {
/* 29 */     if (this.value == null) {
/* 30 */       this.value = t;
/* 31 */       dispose();
/* 32 */       countDown();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onError(Throwable t) {
/* 38 */     if (this.value == null) {
/* 39 */       this.error = t;
/*    */     }
/* 41 */     countDown();
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 46 */     return "blockFirst";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\BlockingFirstSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */