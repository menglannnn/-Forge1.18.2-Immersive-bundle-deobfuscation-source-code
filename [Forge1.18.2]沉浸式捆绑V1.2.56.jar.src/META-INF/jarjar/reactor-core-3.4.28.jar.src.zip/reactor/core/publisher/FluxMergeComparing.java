/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMergeComparing<T>
/*     */   extends Flux<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final int prefetch;
/*     */   final Comparator<? super T> valueComparator;
/*     */   final Publisher<? extends T>[] sources;
/*     */   final boolean delayError;
/*     */   final boolean waitForAllSources;
/*     */   
/*     */   @SafeVarargs
/*     */   FluxMergeComparing(int prefetch, Comparator<? super T> valueComparator, boolean delayError, boolean waitForAllSources, Publisher<? extends T>... sources) {
/*  58 */     if (prefetch <= 0) {
/*  59 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  61 */     this.sources = Objects.<Publisher<? extends T>[]>requireNonNull(sources, "sources must be non-null");
/*     */     
/*  63 */     for (int i = 0; i < sources.length; i++) {
/*  64 */       Publisher<? extends T> source = sources[i];
/*  65 */       if (source == null) {
/*  66 */         throw new NullPointerException("sources[" + i + "] is null");
/*     */       }
/*     */     } 
/*     */     
/*  70 */     this.prefetch = prefetch;
/*  71 */     this.valueComparator = valueComparator;
/*  72 */     this.delayError = delayError;
/*  73 */     this.waitForAllSources = waitForAllSources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxMergeComparing<T> mergeAdditionalSource(Publisher<? extends T> source, Comparator<? super T> otherComparator) {
/*  87 */     int n = this.sources.length;
/*     */     
/*  89 */     Publisher[] arrayOfPublisher = new Publisher[n + 1];
/*  90 */     System.arraycopy(this.sources, 0, arrayOfPublisher, 0, n);
/*  91 */     arrayOfPublisher[n] = source;
/*     */     
/*  93 */     if (!this.valueComparator.equals(otherComparator)) {
/*     */       
/*  95 */       Comparator<? super T> comparator = this.valueComparator;
/*  96 */       Comparator<T> newComparator = (Comparator)comparator.thenComparing(otherComparator);
/*  97 */       return new FluxMergeComparing(this.prefetch, newComparator, this.delayError, this.waitForAllSources, (Publisher<? extends T>[])arrayOfPublisher);
/*     */     } 
/*  99 */     return new FluxMergeComparing(this.prefetch, this.valueComparator, this.delayError, this.waitForAllSources, (Publisher<? extends T>[])arrayOfPublisher);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 104 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 110 */     if (key == Scannable.Attr.PARENT) return (this.sources.length > 0) ? this.sources[0] : null; 
/* 111 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 112 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 113 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 120 */     MergeOrderedMainProducer<T> main = new MergeOrderedMainProducer<>(actual, this.valueComparator, this.prefetch, this.sources.length, this.delayError, this.waitForAllSources);
/* 121 */     actual.onSubscribe(main);
/* 122 */     main.subscribe(this.sources);
/*     */   }
/*     */   
/*     */   static final class MergeOrderedMainProducer<T>
/*     */     implements InnerProducer<T>
/*     */   {
/* 128 */     static final Object DONE = new Object();
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final FluxMergeComparing.MergeOrderedInnerSubscriber<T>[] subscribers;
/*     */     
/*     */     final Comparator<? super T> comparator;
/*     */     
/*     */     final Object[] values;
/*     */     final boolean delayError;
/*     */     final boolean waitForAllSources;
/*     */     boolean done;
/*     */     volatile Throwable error;
/* 141 */     static final AtomicReferenceFieldUpdater<MergeOrderedMainProducer, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(MergeOrderedMainProducer.class, Throwable.class, "error");
/*     */     
/*     */     volatile int cancelled;
/*     */     
/* 145 */     static final AtomicIntegerFieldUpdater<MergeOrderedMainProducer> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(MergeOrderedMainProducer.class, "cancelled");
/*     */     
/*     */     volatile long requested;
/*     */     
/* 149 */     static final AtomicLongFieldUpdater<MergeOrderedMainProducer> REQUESTED = AtomicLongFieldUpdater.newUpdater(MergeOrderedMainProducer.class, "requested");
/*     */     
/*     */     volatile long emitted;
/*     */     
/* 153 */     static final AtomicLongFieldUpdater<MergeOrderedMainProducer> EMITTED = AtomicLongFieldUpdater.newUpdater(MergeOrderedMainProducer.class, "emitted");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/* 158 */     static final AtomicIntegerFieldUpdater<MergeOrderedMainProducer> WIP = AtomicIntegerFieldUpdater.newUpdater(MergeOrderedMainProducer.class, "wip");
/*     */ 
/*     */     
/*     */     MergeOrderedMainProducer(CoreSubscriber<? super T> actual, Comparator<? super T> comparator, int prefetch, int n, boolean delayError, boolean waitForAllSources) {
/* 162 */       this.actual = actual;
/* 163 */       this.comparator = comparator;
/* 164 */       this.delayError = delayError;
/* 165 */       this.waitForAllSources = waitForAllSources;
/*     */ 
/*     */       
/* 168 */       FluxMergeComparing.MergeOrderedInnerSubscriber[] arrayOfMergeOrderedInnerSubscriber = new FluxMergeComparing.MergeOrderedInnerSubscriber[n];
/*     */       
/* 170 */       this.subscribers = (FluxMergeComparing.MergeOrderedInnerSubscriber<T>[])arrayOfMergeOrderedInnerSubscriber;
/*     */       
/* 172 */       for (int i = 0; i < n; i++) {
/* 173 */         this.subscribers[i] = new FluxMergeComparing.MergeOrderedInnerSubscriber<>(this, prefetch);
/*     */       }
/* 175 */       this.values = new Object[n];
/*     */     }
/*     */     
/*     */     void subscribe(Publisher<? extends T>[] sources) {
/* 179 */       if (sources.length != this.subscribers.length) {
/* 180 */         throw new IllegalArgumentException("must subscribe with " + this.subscribers.length + " sources");
/*     */       }
/* 182 */       for (int i = 0; i < sources.length; i++) {
/* 183 */         Objects.requireNonNull(sources[i], "subscribed with a null source: sources[" + i + "]");
/* 184 */         sources[i].subscribe((Subscriber)this.subscribers[i]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 190 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 195 */       Operators.addCap(REQUESTED, this, n);
/* 196 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 201 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 202 */         for (FluxMergeComparing.MergeOrderedInnerSubscriber<T> subscriber : this.subscribers) {
/* 203 */           subscriber.cancel();
/*     */         }
/*     */         
/* 206 */         if (WIP.getAndIncrement(this) == 0) {
/* 207 */           discardData();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void onInnerError(FluxMergeComparing.MergeOrderedInnerSubscriber<T> inner, Throwable ex) {
/* 213 */       Throwable e = Operators.onNextInnerError(ex, actual().currentContext(), this);
/* 214 */       if (e != null) {
/* 215 */         if (Exceptions.addThrowable(ERROR, this, e)) {
/* 216 */           if (!this.delayError) {
/* 217 */             this.done = true;
/*     */           }
/* 219 */           inner.done = true;
/* 220 */           drain();
/*     */         } else {
/*     */           
/* 223 */           inner.done = true;
/* 224 */           Operators.onErrorDropped(e, this.actual.currentContext());
/*     */         } 
/*     */       } else {
/*     */         
/* 228 */         inner.done = true;
/* 229 */         drain();
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 234 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 238 */       int missed = 1;
/* 239 */       CoreSubscriber<? super T> actual = this.actual;
/* 240 */       Comparator<? super T> comparator = this.comparator;
/*     */       
/* 242 */       FluxMergeComparing.MergeOrderedInnerSubscriber<T>[] subscribers = this.subscribers;
/* 243 */       int n = subscribers.length;
/*     */       
/* 245 */       Object[] values = this.values;
/*     */       
/* 247 */       long e = this.emitted;
/*     */       
/*     */       do {
/* 250 */         long r = this.requested;
/*     */         
/*     */         while (true) {
/* 253 */           boolean d = this.done;
/* 254 */           if (this.cancelled != 0) {
/* 255 */             Arrays.fill(values, (Object)null);
/*     */             
/* 257 */             for (FluxMergeComparing.MergeOrderedInnerSubscriber<T> inner : subscribers) {
/* 258 */               inner.queue.clear();
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/* 263 */           int innerDoneCount = 0;
/* 264 */           int nonEmpty = 0;
/* 265 */           for (int i = 0; i < n; i++) {
/* 266 */             Object o = values[i];
/* 267 */             if (o == DONE) {
/* 268 */               innerDoneCount++;
/* 269 */               nonEmpty++;
/*     */             }
/* 271 */             else if (o == null) {
/* 272 */               boolean innerDone = (subscribers[i]).done;
/* 273 */               o = (subscribers[i]).queue.poll();
/* 274 */               if (o != null) {
/* 275 */                 values[i] = o;
/* 276 */                 nonEmpty++;
/*     */               }
/* 278 */               else if (innerDone) {
/* 279 */                 values[i] = DONE;
/* 280 */                 innerDoneCount++;
/* 281 */                 nonEmpty++;
/*     */               } 
/*     */             } else {
/*     */               
/* 285 */               nonEmpty++;
/*     */             } 
/*     */           } 
/*     */           
/* 289 */           if (checkTerminated((d || innerDoneCount == n), (Subscriber<?>)actual)) {
/*     */             return;
/*     */           }
/*     */           
/* 293 */           if ((this.waitForAllSources && nonEmpty != n) || (!this.waitForAllSources && (nonEmpty == 0 || nonEmpty == innerDoneCount)) || e >= r) {
/*     */             break;
/*     */           }
/*     */           
/* 297 */           T min = null;
/* 298 */           int minIndex = -1;
/*     */           
/* 300 */           int j = 0;
/* 301 */           for (Object o : values) {
/* 302 */             if (o != DONE && o != null) {
/*     */               boolean smaller;
/*     */               
/*     */               try {
/* 306 */                 T t = (T)o;
/* 307 */                 smaller = (min == null || comparator.compare(min, t) > 0);
/* 308 */               } catch (Throwable ex) {
/* 309 */                 Exceptions.addThrowable(ERROR, this, ex);
/* 310 */                 cancel();
/* 311 */                 actual.onError(Exceptions.terminate(ERROR, this));
/*     */                 return;
/*     */               } 
/* 314 */               if (smaller) {
/*     */                 
/* 316 */                 T t = (T)o;
/* 317 */                 min = t;
/* 318 */                 minIndex = j;
/*     */               } 
/*     */             } 
/* 321 */             j++;
/*     */           } 
/*     */           
/* 324 */           if (minIndex >= 0) {
/* 325 */             values[minIndex] = null;
/*     */             
/* 327 */             actual.onNext(min);
/*     */             
/* 329 */             e++;
/* 330 */             subscribers[minIndex].request(1L);
/*     */           } 
/*     */         } 
/*     */         
/* 334 */         this.emitted = e;
/* 335 */         missed = WIP.addAndGet(this, -missed);
/* 336 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean checkTerminated(boolean d, Subscriber<?> a) {
/* 343 */       if (this.cancelled != 0) {
/* 344 */         discardData();
/* 345 */         return true;
/*     */       } 
/*     */       
/* 348 */       if (!d) {
/* 349 */         return false;
/*     */       }
/*     */       
/* 352 */       if (this.delayError) {
/* 353 */         Throwable e = this.error;
/* 354 */         if (e != null && e != Exceptions.TERMINATED) {
/* 355 */           e = Exceptions.terminate(ERROR, this);
/* 356 */           a.onError(e);
/*     */         } else {
/*     */           
/* 359 */           a.onComplete();
/*     */         } 
/*     */       } else {
/*     */         
/* 363 */         Throwable e = this.error;
/* 364 */         if (e != null && e != Exceptions.TERMINATED) {
/* 365 */           e = Exceptions.terminate(ERROR, this);
/* 366 */           cancel();
/* 367 */           discardData();
/* 368 */           a.onError(e);
/*     */         } else {
/*     */           
/* 371 */           a.onComplete();
/*     */         } 
/*     */       } 
/* 374 */       return true;
/*     */     }
/*     */     
/*     */     private void discardData() {
/* 378 */       Context ctx = actual().currentContext();
/* 379 */       for (Object v : this.values) {
/* 380 */         if (v != DONE) {
/* 381 */           Operators.onDiscard(v, ctx);
/*     */         }
/*     */       } 
/* 384 */       Arrays.fill(this.values, (Object)null);
/* 385 */       for (FluxMergeComparing.MergeOrderedInnerSubscriber<T> subscriber : this.subscribers) {
/* 386 */         Operators.onDiscardQueueWithClear(subscriber.queue, ctx, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 392 */       if (key == Scannable.Attr.ACTUAL) return this.actual; 
/* 393 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled > 0)); 
/* 394 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 395 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 396 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested - this.emitted); 
/* 397 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 399 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MergeOrderedInnerSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final FluxMergeComparing.MergeOrderedMainProducer<T> parent;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final Queue<T> queue;
/*     */     int consumed;
/*     */     volatile boolean done;
/*     */     volatile Subscription s;
/* 417 */     static final AtomicReferenceFieldUpdater<MergeOrderedInnerSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(MergeOrderedInnerSubscriber.class, Subscription.class, "s");
/*     */     
/*     */     MergeOrderedInnerSubscriber(FluxMergeComparing.MergeOrderedMainProducer<T> parent, int prefetch) {
/* 420 */       this.parent = parent;
/* 421 */       this.prefetch = prefetch;
/* 422 */       this.limit = prefetch - (prefetch >> 2);
/* 423 */       this.queue = Queues.get(prefetch).get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 428 */       if (Operators.setOnce(S, this, s)) {
/* 429 */         s.request(this.prefetch);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T item) {
/* 435 */       if (this.parent.done || this.done) {
/* 436 */         Operators.onNextDropped(item, actual().currentContext());
/*     */         return;
/*     */       } 
/* 439 */       this.queue.offer(item);
/* 440 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 445 */       this.parent.onInnerError(this, throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 450 */       this.done = true;
/* 451 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 459 */       int c = this.consumed + 1;
/* 460 */       if (c == this.limit) {
/* 461 */         this.consumed = 0;
/* 462 */         Subscription sub = this.s;
/* 463 */         if (sub != this) {
/* 464 */           sub.request(c);
/*     */         }
/*     */       } else {
/*     */         
/* 468 */         this.consumed = c;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 474 */       Subscription sub = S.getAndSet(this, this);
/* 475 */       if (sub != null && sub != this) {
/* 476 */         sub.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 482 */       return this.parent.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 488 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 489 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 490 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 491 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 492 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 493 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 495 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxMergeComparing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */