/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxZipIterable<T, U, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final Iterable<? extends U> other;
/*     */   final BiFunction<? super T, ? super U, ? extends R> zipper;
/*     */   
/*     */   FluxZipIterable(Flux<? extends T> source, Iterable<? extends U> other, BiFunction<? super T, ? super U, ? extends R> zipper) {
/*  45 */     super(source);
/*  46 */     this.other = Objects.<Iterable<? extends U>>requireNonNull(other, "other");
/*  47 */     this.zipper = Objects.<BiFunction<? super T, ? super U, ? extends R>>requireNonNull(zipper, "zipper");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  52 */     Iterator<? extends U> it = Objects.<Iterator<? extends U>>requireNonNull(this.other.iterator(), "The other iterable produced a null iterator");
/*     */ 
/*     */     
/*  55 */     boolean b = it.hasNext();
/*     */     
/*  57 */     if (!b) {
/*  58 */       Operators.complete((Subscriber<?>)actual);
/*  59 */       return null;
/*     */     } 
/*     */     
/*  62 */     return new ZipSubscriber<>(actual, it, this.zipper);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  67 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  68 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ZipSubscriber<T, U, R>
/*     */     implements InnerOperator<T, R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final Iterator<? extends U> it;
/*     */     
/*     */     final BiFunction<? super T, ? super U, ? extends R> zipper;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     ZipSubscriber(CoreSubscriber<? super R> actual, Iterator<? extends U> it, BiFunction<? super T, ? super U, ? extends R> zipper) {
/*  87 */       this.actual = actual;
/*  88 */       this.it = it;
/*  89 */       this.zipper = zipper;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  95 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  96 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  97 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  99 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 104 */       if (Operators.validate(this.s, s)) {
/* 105 */         this.s = s;
/* 106 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     } public void onNext(T t) {
/*     */       U u;
/*     */       R r;
/*     */       boolean b;
/* 112 */       if (this.done) {
/* 113 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 120 */         u = this.it.next();
/*     */       }
/* 122 */       catch (Throwable e) {
/* 123 */         this.done = true;
/* 124 */         this.actual.onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/* 131 */         r = Objects.requireNonNull(this.zipper.apply(t, u), "The zipper returned a null value");
/*     */       
/*     */       }
/* 134 */       catch (Throwable e) {
/* 135 */         this.done = true;
/* 136 */         this.actual.onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 140 */       this.actual.onNext(r);
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 145 */         b = this.it.hasNext();
/*     */       }
/* 147 */       catch (Throwable e) {
/* 148 */         this.done = true;
/* 149 */         this.actual.onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 153 */       if (!b) {
/* 154 */         this.done = true;
/* 155 */         this.s.cancel();
/* 156 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 162 */       if (this.done) {
/* 163 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 166 */       this.done = true;
/* 167 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 172 */       if (this.done) {
/*     */         return;
/*     */       }
/* 175 */       this.done = true;
/* 176 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 181 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 186 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 191 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxZipIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */