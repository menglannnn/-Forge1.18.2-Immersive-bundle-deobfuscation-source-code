/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxPublish<T>
/*     */   extends ConnectableFlux<T>
/*     */   implements Scannable
/*     */ {
/*     */   final Flux<? extends T> source;
/*     */   final int prefetch;
/*     */   final Supplier<? extends Queue<T>> queueSupplier;
/*     */   final boolean resetUponSourceTermination;
/*     */   volatile PublishSubscriber<T> connection;
/*  68 */   static final AtomicReferenceFieldUpdater<FluxPublish, PublishSubscriber> CONNECTION = AtomicReferenceFieldUpdater.newUpdater(FluxPublish.class, PublishSubscriber.class, "connection");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxPublish(Flux<? extends T> source, int prefetch, Supplier<? extends Queue<T>> queueSupplier, boolean resetUponSourceTermination) {
/*  76 */     if (prefetch <= 0) {
/*  77 */       throw new IllegalArgumentException("bufferSize > 0 required but it was " + prefetch);
/*     */     }
/*  79 */     this.source = Objects.<Flux<? extends T>>requireNonNull(source, "source");
/*  80 */     this.prefetch = prefetch;
/*  81 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*  82 */     this.resetUponSourceTermination = resetUponSourceTermination;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(Consumer<? super Disposable> cancelSupport) {
/*     */     PublishSubscriber<T> s;
/*     */     while (true) {
/*  90 */       s = this.connection;
/*  91 */       if (s == null || s.isTerminated()) {
/*  92 */         PublishSubscriber<T> u = new PublishSubscriber<>(this.prefetch, this);
/*     */         
/*  94 */         if (!CONNECTION.compareAndSet(this, s, u)) {
/*     */           continue;
/*     */         }
/*     */         
/*  98 */         s = u;
/*     */       }  break;
/*     */     } 
/* 101 */     boolean doConnect = s.tryConnect();
/*     */ 
/*     */ 
/*     */     
/* 105 */     cancelSupport.accept(s);
/* 106 */     if (doConnect) {
/* 107 */       this.source.subscribe(s);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 113 */     PublishInner<T> inner = new PublishInner<>(actual);
/* 114 */     actual.onSubscribe(inner);
/*     */     
/* 116 */     while (!inner.isCancelled()) {
/*     */ 
/*     */ 
/*     */       
/* 120 */       PublishSubscriber<T> c = this.connection;
/* 121 */       if (c == null || (this.resetUponSourceTermination && c.isTerminated())) {
/* 122 */         PublishSubscriber<T> u = new PublishSubscriber<>(this.prefetch, this);
/* 123 */         if (!CONNECTION.compareAndSet(this, c, u)) {
/*     */           continue;
/*     */         }
/*     */         
/* 127 */         c = u;
/*     */       } 
/*     */       
/* 130 */       if (c.add(inner)) {
/* 131 */         if (inner.isCancelled()) {
/* 132 */           c.remove(inner);
/*     */         } else {
/* 134 */           inner.parent = c;
/*     */         } 
/* 136 */         c.drain(); break;
/*     */       } 
/* 138 */       if (!this.resetUponSourceTermination) {
/* 139 */         if (c.error != null) {
/* 140 */           inner.actual.onError(c.error); break;
/*     */         } 
/* 142 */         inner.actual.onComplete();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 151 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 157 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 158 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 159 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PublishSubscriber<T>
/*     */     implements InnerConsumer<T>, Disposable
/*     */   {
/*     */     final int prefetch;
/*     */     
/*     */     final FluxPublish<T> parent;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 174 */     static final AtomicReferenceFieldUpdater<PublishSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(PublishSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile FluxPublish.PubSubInner<T>[] subscribers;
/*     */ 
/*     */ 
/*     */     
/* 182 */     static final AtomicReferenceFieldUpdater<PublishSubscriber, FluxPublish.PubSubInner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(PublishSubscriber.class, (Class)FluxPublish.PubSubInner[].class, "subscribers");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/* 189 */     static final AtomicIntegerFieldUpdater<PublishSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(PublishSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     volatile int connected;
/*     */     
/* 194 */     static final AtomicIntegerFieldUpdater<PublishSubscriber> CONNECTED = AtomicIntegerFieldUpdater.newUpdater(PublishSubscriber.class, "connected");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     static final FluxPublish.PubSubInner[] INIT = (FluxPublish.PubSubInner[])new FluxPublish.PublishInner[0];
/*     */     
/* 202 */     static final FluxPublish.PubSubInner[] CANCELLED = (FluxPublish.PubSubInner[])new FluxPublish.PublishInner[0];
/*     */     
/* 204 */     static final FluxPublish.PubSubInner[] TERMINATED = (FluxPublish.PubSubInner[])new FluxPublish.PublishInner[0];
/*     */ 
/*     */     
/*     */     volatile Queue<T> queue;
/*     */ 
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 216 */     static final AtomicReferenceFieldUpdater<PublishSubscriber, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(PublishSubscriber.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PublishSubscriber(int prefetch, FluxPublish<T> parent) {
/* 222 */       this.prefetch = prefetch;
/* 223 */       this.parent = parent;
/* 224 */       SUBSCRIBERS.lazySet(this, INIT);
/*     */     }
/*     */     
/*     */     boolean isTerminated() {
/* 228 */       return (this.subscribers == TERMINATED);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 233 */       if (Operators.setOnce(S, this, s)) {
/* 234 */         if (s instanceof Fuseable.QueueSubscription) {
/* 235 */           Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*     */ 
/*     */           
/* 238 */           int m = f.requestFusion(7);
/* 239 */           if (m == 1) {
/* 240 */             this.sourceMode = m;
/* 241 */             this.queue = (Queue<T>)f;
/* 242 */             drain();
/*     */             return;
/*     */           } 
/* 245 */           if (m == 2) {
/* 246 */             this.sourceMode = m;
/* 247 */             this.queue = (Queue<T>)f;
/* 248 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 253 */         this.queue = this.parent.queueSupplier.get();
/*     */         
/* 255 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 261 */       if (this.done) {
/* 262 */         if (t != null) {
/* 263 */           Operators.onNextDropped(t, currentContext());
/*     */         }
/*     */         return;
/*     */       } 
/* 267 */       if (this.sourceMode == 2) {
/* 268 */         drain();
/*     */         
/*     */         return;
/*     */       } 
/* 272 */       if (!this.queue.offer(t)) {
/* 273 */         Throwable ex = Operators.onOperatorError(this.s, 
/* 274 */             Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, currentContext());
/* 275 */         if (!Exceptions.addThrowable(ERROR, this, ex)) {
/* 276 */           Operators.onErrorDroppedMulticast(ex, (InnerProducer<?>[])this.subscribers);
/*     */           return;
/*     */         } 
/* 279 */         this.done = true;
/*     */       } 
/* 281 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 286 */       if (this.done) {
/* 287 */         Operators.onErrorDroppedMulticast(t, (InnerProducer<?>[])this.subscribers);
/*     */         return;
/*     */       } 
/* 290 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 291 */         this.done = true;
/* 292 */         drain();
/*     */       } else {
/*     */         
/* 295 */         Operators.onErrorDroppedMulticast(t, (InnerProducer<?>[])this.subscribers);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 301 */       if (this.done) {
/*     */         return;
/*     */       }
/* 304 */       this.done = true;
/* 305 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 310 */       if (SUBSCRIBERS.get(this) == TERMINATED) {
/*     */         return;
/*     */       }
/* 313 */       if (FluxPublish.CONNECTION.compareAndSet(this.parent, this, null)) {
/* 314 */         Operators.terminate(S, this);
/* 315 */         if (WIP.getAndIncrement(this) != 0) {
/*     */           return;
/*     */         }
/* 318 */         disconnectAction();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void disconnectAction() {
/* 324 */       FluxPublish.PubSubInner[] arrayOfPubSubInner = SUBSCRIBERS.getAndSet(this, CANCELLED);
/* 325 */       if (arrayOfPubSubInner.length > 0) {
/* 326 */         this.queue.clear();
/* 327 */         CancellationException ex = new CancellationException("Disconnected");
/*     */         
/* 329 */         for (FluxPublish.PubSubInner<T> inner : arrayOfPubSubInner) {
/* 330 */           inner.actual.onError(ex);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean add(FluxPublish.PublishInner<T> inner) {
/*     */       while (true) {
/* 337 */         FluxPublish.PubSubInner<T>[] a = this.subscribers;
/* 338 */         if (a == TERMINATED) {
/* 339 */           return false;
/*     */         }
/* 341 */         int n = a.length;
/* 342 */         FluxPublish.PubSubInner[] arrayOfPubSubInner = new FluxPublish.PubSubInner[n + 1];
/* 343 */         System.arraycopy(a, 0, arrayOfPubSubInner, 0, n);
/* 344 */         arrayOfPubSubInner[n] = inner;
/* 345 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfPubSubInner))
/* 346 */           return true; 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void remove(FluxPublish.PubSubInner<T> inner) {
/*     */       FluxPublish.PubSubInner<T>[] a;
/*     */       FluxPublish.PubSubInner[] arrayOfPubSubInner;
/*     */       do {
/* 354 */         a = this.subscribers;
/* 355 */         if (a == TERMINATED || a == CANCELLED) {
/*     */           return;
/*     */         }
/* 358 */         int n = a.length;
/* 359 */         int j = -1;
/* 360 */         for (int i = 0; i < n; i++) {
/* 361 */           if (a[i] == inner) {
/* 362 */             j = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 367 */         if (j < 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 373 */         if (n == 1) {
/* 374 */           arrayOfPubSubInner = CANCELLED;
/*     */         } else {
/*     */           
/* 377 */           arrayOfPubSubInner = new FluxPublish.PubSubInner[n - 1];
/* 378 */           System.arraycopy(a, 0, arrayOfPubSubInner, 0, j);
/* 379 */           System.arraycopy(a, j + 1, arrayOfPubSubInner, j, n - j - 1);
/*     */         } 
/* 381 */       } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfPubSubInner));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FluxPublish.PubSubInner<T>[] terminate() {
/* 391 */       return (FluxPublish.PubSubInner<T>[])SUBSCRIBERS.getAndSet(this, TERMINATED);
/*     */     }
/*     */     
/*     */     boolean tryConnect() {
/* 395 */       return (this.connected == 0 && CONNECTED.compareAndSet(this, 0, 1));
/*     */     }
/*     */     
/*     */     final void drain() {
/* 399 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 403 */       int missed = 1;
/*     */ 
/*     */       
/*     */       while (true) {
/* 407 */         boolean d = this.done;
/*     */         
/* 409 */         Queue<T> q = this.queue;
/*     */         
/* 411 */         boolean empty = (q == null || q.isEmpty());
/*     */         
/* 413 */         if (checkTerminated(d, empty)) {
/*     */           return;
/*     */         }
/*     */         
/* 417 */         FluxPublish.PubSubInner<T>[] a = this.subscribers;
/*     */         
/* 419 */         if (a != CANCELLED && !empty) {
/* 420 */           long maxRequested = Long.MAX_VALUE;
/*     */           
/* 422 */           int len = a.length;
/* 423 */           int cancel = 0;
/*     */           
/* 425 */           for (FluxPublish.PubSubInner<T> inner : a) {
/* 426 */             long r = inner.requested;
/* 427 */             if (r >= 0L) {
/* 428 */               maxRequested = Math.min(maxRequested, r);
/*     */             } else {
/*     */               
/* 431 */               cancel++;
/*     */             } 
/*     */           } 
/*     */           
/* 435 */           if (len == cancel) {
/*     */             T v;
/*     */             
/*     */             try {
/* 439 */               v = q.poll();
/*     */             }
/* 441 */             catch (Throwable ex) {
/* 442 */               Exceptions.addThrowable(ERROR, this, 
/*     */                   
/* 444 */                   Operators.onOperatorError(this.s, ex, currentContext()));
/* 445 */               d = true;
/* 446 */               v = null;
/*     */             } 
/* 448 */             if (checkTerminated(d, (v == null))) {
/*     */               return;
/*     */             }
/* 451 */             if (this.sourceMode != 1) {
/* 452 */               this.s.request(1L);
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/* 457 */           int e = 0;
/*     */           
/* 459 */           while (e < maxRequested && cancel != Integer.MIN_VALUE) {
/* 460 */             T v; d = this.done;
/*     */ 
/*     */             
/*     */             try {
/* 464 */               v = q.poll();
/*     */             }
/* 466 */             catch (Throwable ex) {
/* 467 */               Exceptions.addThrowable(ERROR, this, 
/*     */                   
/* 469 */                   Operators.onOperatorError(this.s, ex, currentContext()));
/* 470 */               d = true;
/* 471 */               v = null;
/*     */             } 
/*     */             
/* 474 */             empty = (v == null);
/*     */             
/* 476 */             if (checkTerminated(d, empty)) {
/*     */               return;
/*     */             }
/*     */             
/* 480 */             if (empty) {
/*     */               
/* 482 */               if (this.sourceMode == 1) {
/* 483 */                 this.done = true;
/* 484 */                 checkTerminated(true, true);
/*     */               } 
/*     */               
/*     */               break;
/*     */             } 
/* 489 */             for (FluxPublish.PubSubInner<T> inner : a) {
/* 490 */               inner.actual.onNext(v);
/* 491 */               if (Operators.producedCancellable(FluxPublish.PubSubInner.REQUESTED, inner, 1L) == Long.MIN_VALUE)
/*     */               {
/*     */                 
/* 494 */                 cancel = Integer.MIN_VALUE;
/*     */               }
/*     */             } 
/*     */             
/* 498 */             e++;
/*     */           } 
/*     */           
/* 501 */           if (e != 0 && this.sourceMode != 1) {
/* 502 */             this.s.request(e);
/*     */           }
/*     */           
/* 505 */           if (maxRequested != 0L && !empty) {
/*     */             continue;
/*     */           }
/*     */         }
/* 509 */         else if (this.sourceMode == 1) {
/* 510 */           this.done = true;
/* 511 */           if (checkTerminated(true, empty)) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 516 */         missed = WIP.addAndGet(this, -missed);
/* 517 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty) {
/* 524 */       if (this.s == Operators.cancelledSubscription()) {
/* 525 */         disconnectAction();
/* 526 */         return true;
/*     */       } 
/* 528 */       if (d) {
/* 529 */         Throwable e = this.error;
/* 530 */         if (e != null && e != Exceptions.TERMINATED) {
/* 531 */           if (this.parent.resetUponSourceTermination) {
/* 532 */             FluxPublish.CONNECTION.compareAndSet(this.parent, this, null);
/* 533 */             e = Exceptions.terminate(ERROR, this);
/*     */           } 
/* 535 */           this.queue.clear();
/* 536 */           for (FluxPublish.PubSubInner<T> inner : terminate()) {
/* 537 */             inner.actual.onError(e);
/*     */           }
/* 539 */           return true;
/*     */         } 
/* 541 */         if (empty) {
/* 542 */           if (this.parent.resetUponSourceTermination) {
/* 543 */             FluxPublish.CONNECTION.compareAndSet(this.parent, this, null);
/*     */           }
/* 545 */           for (FluxPublish.PubSubInner<T> inner : terminate()) {
/* 546 */             inner.actual.onComplete();
/*     */           }
/* 548 */           return true;
/*     */         } 
/*     */       } 
/* 551 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 556 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 561 */       return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 567 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 568 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 569 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 570 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 571 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isTerminated()); 
/* 572 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 573 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 575 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 580 */       return (this.s == Operators.cancelledSubscription() || this.done);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static abstract class PubSubInner<T>
/*     */     implements InnerProducer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     volatile long requested;
/*     */     
/* 592 */     static final AtomicLongFieldUpdater<PubSubInner> REQUESTED = AtomicLongFieldUpdater.newUpdater(PubSubInner.class, "requested");
/*     */     
/*     */     PubSubInner(CoreSubscriber<? super T> actual) {
/* 595 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public final void request(long n) {
/* 600 */       if (Operators.validate(n)) {
/* 601 */         Operators.addCapCancellable(REQUESTED, this, n);
/* 602 */         drainParent();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public final void cancel() {
/* 608 */       long r = this.requested;
/* 609 */       if (r != Long.MIN_VALUE) {
/* 610 */         r = REQUESTED.getAndSet(this, Long.MIN_VALUE);
/* 611 */         if (r != Long.MIN_VALUE) {
/* 612 */           removeAndDrainParent();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     final boolean isCancelled() {
/* 618 */       return (this.requested == Long.MIN_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 623 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 629 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 630 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(isCancelled() ? 0L : this.requested); 
/* 631 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 633 */       return super.scanUnsafe(key);
/*     */     }
/*     */     
/*     */     abstract void drainParent();
/*     */     
/*     */     abstract void removeAndDrainParent(); }
/*     */   
/*     */   static final class PublishInner<T> extends PubSubInner<T> {
/*     */     FluxPublish.PublishSubscriber<T> parent;
/*     */     
/*     */     PublishInner(CoreSubscriber<? super T> actual) {
/* 644 */       super(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     void drainParent() {
/* 649 */       FluxPublish.PublishSubscriber<T> p = this.parent;
/* 650 */       if (p != null) {
/* 651 */         p.drain();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void removeAndDrainParent() {
/* 657 */       FluxPublish.PublishSubscriber<T> p = this.parent;
/* 658 */       if (p != null) {
/* 659 */         p.remove(this);
/* 660 */         p.drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 667 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 668 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.parent != null && this.parent.isTerminated())); 
/* 669 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 671 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxPublish.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */