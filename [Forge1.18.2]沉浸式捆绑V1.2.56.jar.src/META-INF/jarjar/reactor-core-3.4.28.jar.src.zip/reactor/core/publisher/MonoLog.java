/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoLog<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final SignalPeek<T> log;
/*    */   
/*    */   MonoLog(Mono<? extends T> source, SignalPeek<T> log) {
/* 40 */     super(source);
/* 41 */     this.log = log;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 46 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*    */       
/* 48 */       Fuseable.ConditionalSubscriber<T> s2 = (Fuseable.ConditionalSubscriber)actual;
/* 49 */       return new FluxPeekFuseable.PeekConditionalSubscriber<>(s2, this.log);
/*    */     } 
/* 51 */     return new FluxPeek.PeekSubscriber<>(actual, this.log);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 56 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 57 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */