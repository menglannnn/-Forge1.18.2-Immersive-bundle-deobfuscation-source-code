/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BlockingSingleSubscriber<T>
/*     */   extends CountDownLatch
/*     */   implements InnerConsumer<T>, Disposable
/*     */ {
/*     */   T value;
/*     */   Throwable error;
/*     */   Subscription s;
/*     */   volatile boolean cancelled;
/*     */   
/*     */   BlockingSingleSubscriber() {
/*  43 */     super(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription s) {
/*  48 */     this.s = s;
/*  49 */     if (!this.cancelled) {
/*  50 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/*  56 */     countDown();
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/*  61 */     return Context.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dispose() {
/*  66 */     this.cancelled = true;
/*  67 */     Subscription s = this.s;
/*  68 */     if (s != null) {
/*  69 */       this.s = null;
/*  70 */       s.cancel();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   final T blockingGet() {
/*  82 */     if (Schedulers.isInNonBlockingThread()) {
/*  83 */       throw new IllegalStateException("block()/blockFirst()/blockLast() are blocking, which is not supported in thread " + Thread.currentThread().getName());
/*     */     }
/*  85 */     if (getCount() != 0L) {
/*     */       try {
/*  87 */         await();
/*     */       }
/*  89 */       catch (InterruptedException ex) {
/*  90 */         dispose();
/*  91 */         throw Exceptions.propagate(ex);
/*     */       } 
/*     */     }
/*     */     
/*  95 */     Throwable e = this.error;
/*  96 */     if (e != null) {
/*  97 */       RuntimeException re = Exceptions.propagate(e);
/*     */       
/*  99 */       re.addSuppressed(new Exception("#block terminated with an error"));
/* 100 */       throw re;
/*     */     } 
/* 102 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   final T blockingGet(long timeout, TimeUnit unit) {
/* 116 */     if (Schedulers.isInNonBlockingThread()) {
/* 117 */       throw new IllegalStateException("block()/blockFirst()/blockLast() are blocking, which is not supported in thread " + Thread.currentThread().getName());
/*     */     }
/* 119 */     if (getCount() != 0L) {
/*     */       try {
/* 121 */         if (!await(timeout, unit)) {
/* 122 */           dispose();
/* 123 */           throw new IllegalStateException("Timeout on blocking read for " + timeout + " " + unit);
/*     */         }
/*     */       
/* 126 */       } catch (InterruptedException ex) {
/* 127 */         dispose();
/* 128 */         RuntimeException re = Exceptions.propagate(ex);
/*     */         
/* 130 */         re.addSuppressed(new Exception("#block has been interrupted"));
/* 131 */         throw re;
/*     */       } 
/*     */     }
/*     */     
/* 135 */     Throwable e = this.error;
/* 136 */     if (e != null) {
/* 137 */       RuntimeException re = Exceptions.propagate(e);
/*     */       
/* 139 */       re.addSuppressed(new Exception("#block terminated with an error"));
/* 140 */       throw re;
/*     */     } 
/* 142 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 150 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((getCount() == 0L)); 
/* 151 */     if (key == Scannable.Attr.PARENT) return this.s; 
/* 152 */     if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 153 */     if (key == Scannable.Attr.ERROR) return this.error; 
/* 154 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 155 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 162 */     return (this.cancelled || getCount() == 0L);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\BlockingSingleSubscriber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */