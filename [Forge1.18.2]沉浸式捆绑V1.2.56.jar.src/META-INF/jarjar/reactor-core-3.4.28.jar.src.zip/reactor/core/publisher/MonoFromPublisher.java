/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CorePublisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoFromPublisher<T>
/*    */   extends Mono<T>
/*    */   implements Scannable, OptimizableOperator<T, T>
/*    */ {
/*    */   final Publisher<? extends T> source;
/*    */   @Nullable
/*    */   final OptimizableOperator<?, T> optimizableOperator;
/*    */   
/*    */   MonoFromPublisher(Publisher<? extends T> source) {
/* 44 */     this.source = Objects.<Publisher<? extends T>>requireNonNull(source, "publisher");
/* 45 */     if (source instanceof OptimizableOperator) {
/*    */       
/* 47 */       OptimizableOperator<?, T> optimSource = (OptimizableOperator)source;
/* 48 */       this.optimizableOperator = optimSource;
/*    */     } else {
/*    */       
/* 51 */       this.optimizableOperator = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/*    */     try {
/* 59 */       CoreSubscriber<? super T> subscriber = subscribeOrReturn(actual);
/* 60 */       if (subscriber == null) {
/*    */         return;
/*    */       }
/* 63 */       this.source.subscribe((Subscriber)subscriber);
/*    */     }
/* 65 */     catch (Throwable e) {
/* 66 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*    */       return;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) throws Throwable {
/* 73 */     return new MonoNext.NextSubscriber<>(actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public final CorePublisher<? extends T> source() {
/* 78 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final OptimizableOperator<?, ? extends T> nextOptimizableSource() {
/* 83 */     return this.optimizableOperator;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 89 */     if (key == Scannable.Attr.PARENT) {
/* 90 */       return this.source;
/*    */     }
/* 92 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 93 */       return Scannable.Attr.RunStyle.SYNC;
/*    */     }
/* 95 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoFromPublisher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */