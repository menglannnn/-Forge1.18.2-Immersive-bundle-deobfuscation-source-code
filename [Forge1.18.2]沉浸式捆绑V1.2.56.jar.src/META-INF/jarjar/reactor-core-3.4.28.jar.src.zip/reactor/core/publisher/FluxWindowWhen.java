/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxWindowWhen<T, U, V>
/*     */   extends InternalFluxOperator<T, Flux<T>>
/*     */ {
/*     */   final Publisher<U> start;
/*     */   final Function<? super U, ? extends Publisher<V>> end;
/*     */   final Supplier<? extends Queue<T>> processorQueueSupplier;
/*     */   
/*     */   FluxWindowWhen(Flux<? extends T> source, Publisher<U> start, Function<? super U, ? extends Publisher<V>> end, Supplier<? extends Queue<T>> processorQueueSupplier) {
/*  61 */     super(source);
/*  62 */     this.start = Objects.<Publisher<U>>requireNonNull(start, "start");
/*  63 */     this.end = Objects.<Function<? super U, ? extends Publisher<V>>>requireNonNull(end, "end");
/*  64 */     this
/*  65 */       .processorQueueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(processorQueueSupplier, "processorQueueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  70 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Flux<T>> actual) {
/*  76 */     WindowWhenMainSubscriber<T, U, V> main = new WindowWhenMainSubscriber<>(actual, this.start, this.end, this.processorQueueSupplier);
/*     */     
/*  78 */     actual.onSubscribe(main);
/*     */     
/*  80 */     if (main.cancelled) {
/*  81 */       return null;
/*     */     }
/*  83 */     WindowWhenOpenSubscriber<T, U> os = new WindowWhenOpenSubscriber<>(main);
/*     */     
/*  85 */     if (WindowWhenMainSubscriber.BOUNDARY.compareAndSet(main, null, os)) {
/*  86 */       WindowWhenMainSubscriber.OPEN_WINDOW_COUNT.incrementAndGet(main);
/*  87 */       this.start.subscribe(os);
/*  88 */       return main;
/*     */     } 
/*     */     
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  97 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  98 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowWhenMainSubscriber<T, U, V>
/*     */     extends QueueDrainSubscriber<T, Object, Flux<T>>
/*     */   {
/*     */     final Publisher<U> open;
/*     */     
/*     */     final Function<? super U, ? extends Publisher<V>> close;
/*     */     
/*     */     final Supplier<? extends Queue<T>> processorQueueSupplier;
/*     */     final Disposable.Composite resources;
/*     */     Subscription s;
/*     */     volatile Disposable boundary;
/* 113 */     static final AtomicReferenceFieldUpdater<WindowWhenMainSubscriber, Disposable> BOUNDARY = AtomicReferenceFieldUpdater.newUpdater(WindowWhenMainSubscriber.class, Disposable.class, "boundary");
/*     */     
/*     */     final List<Sinks.Many<T>> windows;
/*     */     
/*     */     volatile long openWindowCount;
/*     */     
/* 119 */     static final AtomicLongFieldUpdater<WindowWhenMainSubscriber> OPEN_WINDOW_COUNT = AtomicLongFieldUpdater.newUpdater(WindowWhenMainSubscriber.class, "openWindowCount");
/*     */ 
/*     */ 
/*     */     
/*     */     WindowWhenMainSubscriber(CoreSubscriber<? super Flux<T>> actual, Publisher<U> open, Function<? super U, ? extends Publisher<V>> close, Supplier<? extends Queue<T>> processorQueueSupplier) {
/* 124 */       super(actual, Queues.unboundedMultiproducer().get());
/* 125 */       this.open = open;
/* 126 */       this.close = close;
/* 127 */       this.processorQueueSupplier = processorQueueSupplier;
/* 128 */       this.resources = Disposables.composite();
/* 129 */       this.windows = new ArrayList<>();
/* 130 */       OPEN_WINDOW_COUNT.lazySet(this, 1L);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 135 */       if (Operators.validate(this.s, s)) {
/* 136 */         this.s = s;
/* 137 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 143 */       if (this.done) {
/* 144 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 147 */       if (fastEnter()) {
/* 148 */         for (Sinks.Many<T> w : this.windows) {
/* 149 */           w.emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */         }
/* 151 */         if (leave(-1) == 0) {
/*     */           return;
/*     */         }
/*     */       } else {
/* 155 */         this.queue.offer(t);
/* 156 */         if (!enter()) {
/*     */           return;
/*     */         }
/*     */       } 
/* 160 */       drainLoop();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 165 */       if (this.done) {
/* 166 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 169 */       this.error = t;
/* 170 */       this.done = true;
/*     */       
/* 172 */       if (enter()) {
/* 173 */         drainLoop();
/*     */       }
/*     */       
/* 176 */       if (OPEN_WINDOW_COUNT.decrementAndGet(this) == 0L) {
/* 177 */         this.resources.dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 183 */       if (this.done) {
/*     */         return;
/*     */       }
/* 186 */       this.done = true;
/*     */       
/* 188 */       if (enter()) {
/* 189 */         drainLoop();
/*     */       }
/*     */       
/* 192 */       if (OPEN_WINDOW_COUNT.decrementAndGet(this) == 0L) {
/* 193 */         this.resources.dispose();
/*     */       }
/*     */     }
/*     */     
/*     */     void error(Throwable t) {
/* 198 */       this.s.cancel();
/* 199 */       this.resources.dispose();
/* 200 */       OperatorDisposables.dispose(BOUNDARY, this);
/*     */       
/* 202 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 207 */       requested(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 212 */       this.cancelled = true;
/*     */     }
/*     */     
/*     */     void dispose() {
/* 216 */       this.resources.dispose();
/* 217 */       OperatorDisposables.dispose(BOUNDARY, this);
/*     */     }
/*     */     
/*     */     void drainLoop() {
/* 221 */       Queue<Object> q = this.queue;
/* 222 */       CoreSubscriber<? super Flux<T>> coreSubscriber = this.actual;
/* 223 */       List<Sinks.Many<T>> ws = this.windows;
/* 224 */       int missed = 1;
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 229 */         boolean d = this.done;
/* 230 */         Object o = q.poll();
/*     */         
/* 232 */         boolean empty = (o == null);
/*     */         
/* 234 */         if (d && empty) {
/* 235 */           dispose();
/* 236 */           Throwable e = this.error;
/* 237 */           if (e != null) {
/* 238 */             this.actual.onError(e);
/* 239 */             for (Sinks.Many<T> w : ws) {
/* 240 */               w.emitError(e, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */             }
/*     */           } else {
/* 243 */             this.actual.onComplete();
/* 244 */             for (Sinks.Many<T> w : ws) {
/* 245 */               w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST);
/*     */             }
/*     */           } 
/* 248 */           ws.clear();
/*     */           
/*     */           return;
/*     */         } 
/* 252 */         if (empty)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 321 */           missed = leave(-missed);
/* 322 */           if (missed == 0)
/*     */             break;  continue; }  if (o instanceof FluxWindowWhen.WindowOperation) { Publisher<V> p; FluxWindowWhen.WindowOperation<T, U> wo = (FluxWindowWhen.WindowOperation<T, U>)o; Sinks.Many<T> w = wo.w; if (w != null) { if (ws.remove(wo.w)) { wo.w.emitComplete(Sinks.EmitFailureHandler.FAIL_FAST); if (OPEN_WINDOW_COUNT.decrementAndGet(this) == 0L) { dispose(); return; }  }  continue; }  if (this.cancelled)
/*     */             continue;  w = Sinks.unsafe().many().unicast().onBackpressureBuffer(this.processorQueueSupplier.get()); long r = requested(); if (r != 0L) { ws.add(w); coreSubscriber.onNext(w.asFlux()); if (r != Long.MAX_VALUE)
/*     */               produced(1L);  } else { this.cancelled = true; coreSubscriber.onError(Exceptions.failWithOverflow("Could not deliver new window due to lack of requests")); continue; }  try { p = Objects.<Publisher<V>>requireNonNull(this.close.apply(wo.open), "The publisher supplied is null"); } catch (Throwable e) { this.cancelled = true; coreSubscriber.onError(e); continue; }  FluxWindowWhen.WindowWhenCloseSubscriber<T, V> cl = new FluxWindowWhen.WindowWhenCloseSubscriber<>(this, w); if (this.resources.add(cl)) { OPEN_WINDOW_COUNT.getAndIncrement(this); p.subscribe(cl); }
/*     */            continue; }
/*     */          for (Sinks.Many<T> w : ws) { T t = (T)o; w.emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST); }
/*     */       
/* 329 */       }  } void open(U b) { this.queue.offer(new FluxWindowWhen.WindowOperation<>(null, b));
/* 330 */       if (enter()) {
/* 331 */         drainLoop();
/*     */       } }
/*     */ 
/*     */     
/*     */     void close(FluxWindowWhen.WindowWhenCloseSubscriber<T, V> w) {
/* 336 */       this.resources.remove(w);
/* 337 */       this.queue.offer(new FluxWindowWhen.WindowOperation<>(w.w, null));
/* 338 */       if (enter()) {
/* 339 */         drainLoop();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 345 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 346 */       return super.scanUnsafe(key);
/*     */     } }
/*     */   
/*     */   static final class WindowOperation<T, U> {
/*     */     final Sinks.Many<T> w;
/*     */     final U open;
/*     */     
/*     */     WindowOperation(@Nullable Sinks.Many<T> w, @Nullable U open) {
/* 354 */       this.w = w;
/* 355 */       this.open = open;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowWhenOpenSubscriber<T, U>
/*     */     implements Disposable, Subscriber<U>
/*     */   {
/*     */     volatile Subscription subscription;
/* 364 */     static final AtomicReferenceFieldUpdater<WindowWhenOpenSubscriber, Subscription> SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(WindowWhenOpenSubscriber.class, Subscription.class, "subscription");
/*     */     
/*     */     final FluxWindowWhen.WindowWhenMainSubscriber<T, U, ?> parent;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     WindowWhenOpenSubscriber(FluxWindowWhen.WindowWhenMainSubscriber<T, U, ?> parent) {
/* 371 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 376 */       if (Operators.setOnce(SUBSCRIPTION, this, s)) {
/* 377 */         this.subscription.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 383 */       Operators.terminate(SUBSCRIPTION, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 388 */       return (this.subscription == Operators.cancelledSubscription());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 393 */       if (this.done) {
/*     */         return;
/*     */       }
/* 396 */       this.parent.open(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 401 */       if (this.done) {
/* 402 */         Operators.onErrorDropped(t, this.parent.actual.currentContext());
/*     */         return;
/*     */       } 
/* 405 */       this.done = true;
/* 406 */       this.parent.error(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 411 */       if (this.done) {
/*     */         return;
/*     */       }
/* 414 */       this.done = true;
/* 415 */       this.parent.onComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowWhenCloseSubscriber<T, V>
/*     */     implements Disposable, Subscriber<V>
/*     */   {
/*     */     volatile Subscription subscription;
/* 424 */     static final AtomicReferenceFieldUpdater<WindowWhenCloseSubscriber, Subscription> SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(WindowWhenCloseSubscriber.class, Subscription.class, "subscription");
/*     */     
/*     */     final FluxWindowWhen.WindowWhenMainSubscriber<T, ?, V> parent;
/*     */     
/*     */     final Sinks.Many<T> w;
/*     */     boolean done;
/*     */     
/*     */     WindowWhenCloseSubscriber(FluxWindowWhen.WindowWhenMainSubscriber<T, ?, V> parent, Sinks.Many<T> w) {
/* 432 */       this.parent = parent;
/* 433 */       this.w = w;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 438 */       if (Operators.setOnce(SUBSCRIPTION, this, s)) {
/* 439 */         this.subscription.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 445 */       Operators.terminate(SUBSCRIPTION, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 450 */       return (this.subscription == Operators.cancelledSubscription());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(V t) {
/* 455 */       if (this.done) {
/*     */         return;
/*     */       }
/* 458 */       this.done = true;
/* 459 */       dispose();
/* 460 */       this.parent.close(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 465 */       if (this.done) {
/* 466 */         Operators.onErrorDropped(t, this.parent.actual.currentContext());
/*     */         return;
/*     */       } 
/* 469 */       this.done = true;
/* 470 */       this.parent.error(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 475 */       if (this.done) {
/*     */         return;
/*     */       }
/* 478 */       this.done = true;
/* 479 */       this.parent.close(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxWindowWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */