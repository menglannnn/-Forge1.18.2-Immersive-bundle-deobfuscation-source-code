/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class DirectProcessor<T>
/*     */   extends FluxProcessor<T, T>
/*     */   implements DirectInnerContainer<T>
/*     */ {
/*     */   @Deprecated
/*     */   public static <E> DirectProcessor<E> create() {
/* 102 */     return new DirectProcessor<>();
/*     */   }
/*     */   
/* 105 */   private volatile SinkManyBestEffort.DirectInner<T>[] subscribers = (SinkManyBestEffort.DirectInner<T>[])SinkManyBestEffort.EMPTY;
/*     */ 
/*     */ 
/*     */   
/* 109 */   private static final AtomicReferenceFieldUpdater<DirectProcessor, SinkManyBestEffort.DirectInner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(DirectProcessor.class, (Class)SinkManyBestEffort.DirectInner[].class, "subscribers");
/*     */ 
/*     */ 
/*     */   
/*     */   Throwable error;
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 118 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 123 */     return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription s) {
/* 128 */     Objects.requireNonNull(s, "s");
/* 129 */     if (this.subscribers != SinkManyBestEffort.TERMINATED) {
/* 130 */       s.request(Long.MAX_VALUE);
/*     */     } else {
/*     */       
/* 133 */       s.cancel();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 140 */     Sinks.EmitResult emitResult = tryEmitComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   private void emitComplete() {
/* 145 */     Sinks.EmitResult emitResult = tryEmitComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   private Sinks.EmitResult tryEmitComplete() {
/* 150 */     SinkManyBestEffort.DirectInner[] arrayOfDirectInner = SUBSCRIBERS.getAndSet(this, SinkManyBestEffort.TERMINATED);
/*     */     
/* 152 */     if (arrayOfDirectInner == SinkManyBestEffort.TERMINATED) {
/* 153 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 156 */     for (SinkManyBestEffort.DirectInner<?> s : arrayOfDirectInner) {
/* 157 */       s.emitComplete();
/*     */     }
/* 159 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable throwable) {
/* 164 */     emitError(throwable);
/*     */   }
/*     */   
/*     */   private void emitError(Throwable error) {
/* 168 */     Sinks.EmitResult result = tryEmitError(error);
/* 169 */     if (result == Sinks.EmitResult.FAIL_TERMINATED) {
/* 170 */       Operators.onErrorDroppedMulticast(error, (InnerProducer<?>[])this.subscribers);
/*     */     }
/*     */   }
/*     */   
/*     */   private Sinks.EmitResult tryEmitError(Throwable t) {
/* 175 */     Objects.requireNonNull(t, "t");
/*     */ 
/*     */     
/* 178 */     SinkManyBestEffort.DirectInner[] arrayOfDirectInner = SUBSCRIBERS.getAndSet(this, SinkManyBestEffort.TERMINATED);
/*     */     
/* 180 */     if (arrayOfDirectInner == SinkManyBestEffort.TERMINATED) {
/* 181 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 184 */     this.error = t;
/* 185 */     for (SinkManyBestEffort.DirectInner<?> s : arrayOfDirectInner) {
/* 186 */       s.emitError(t);
/*     */     }
/* 188 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */   
/*     */   private void emitNext(T value) {
/* 192 */     switch (tryEmitNext(value)) {
/*     */       case FAIL_ZERO_SUBSCRIBER:
/*     */         return;
/*     */ 
/*     */       
/*     */       case FAIL_OVERFLOW:
/* 198 */         Operators.onDiscard(value, currentContext());
/*     */         
/* 200 */         emitError(Exceptions.failWithOverflow("Backpressure overflow during Sinks.Many#emitNext"));
/*     */       
/*     */       case FAIL_CANCELLED:
/* 203 */         Operators.onDiscard(value, currentContext());
/*     */       
/*     */       case FAIL_TERMINATED:
/* 206 */         Operators.onNextDroppedMulticast(value, (InnerProducer<?>[])this.subscribers);
/*     */       
/*     */       case OK:
/*     */         return;
/*     */     } 
/* 211 */     throw new IllegalStateException("unexpected return code");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNext(T t) {
/* 217 */     emitNext(t);
/*     */   }
/*     */   
/*     */   private Sinks.EmitResult tryEmitNext(T t) {
/* 221 */     Objects.requireNonNull(t, "t");
/*     */     
/* 223 */     SinkManyBestEffort.DirectInner<T>[] inners = this.subscribers;
/*     */     
/* 225 */     if (inners == SinkManyBestEffort.TERMINATED) {
/* 226 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/* 228 */     if (inners == SinkManyBestEffort.EMPTY) {
/* 229 */       return Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER;
/*     */     }
/*     */     
/* 232 */     for (SinkManyBestEffort.DirectInner<T> s : inners) {
/* 233 */       s.directEmitNext(t);
/*     */     }
/* 235 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isIdentityProcessor() {
/* 240 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 245 */     Objects.requireNonNull(actual, "subscribe");
/*     */     
/* 247 */     SinkManyBestEffort.DirectInner<T> p = new SinkManyBestEffort.DirectInner<>(actual, this);
/* 248 */     actual.onSubscribe(p);
/*     */     
/* 250 */     if (add(p)) {
/* 251 */       if (p.isCancelled()) {
/* 252 */         remove(p);
/*     */       }
/*     */     } else {
/*     */       
/* 256 */       Throwable e = this.error;
/* 257 */       if (e != null) {
/* 258 */         actual.onError(e);
/*     */       } else {
/*     */         
/* 261 */         actual.onComplete();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 268 */     return Stream.of((Scannable[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 273 */     return (SinkManyBestEffort.TERMINATED == this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   public long downstreamCount() {
/* 278 */     return this.subscribers.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(SinkManyBestEffort.DirectInner<T> s) {
/* 283 */     SinkManyBestEffort.DirectInner<T>[] a = this.subscribers;
/* 284 */     if (a == SinkManyBestEffort.TERMINATED) {
/* 285 */       return false;
/*     */     }
/*     */     
/* 288 */     synchronized (this) {
/* 289 */       a = this.subscribers;
/* 290 */       if (a == SinkManyBestEffort.TERMINATED) {
/* 291 */         return false;
/*     */       }
/* 293 */       int len = a.length;
/*     */       
/* 295 */       SinkManyBestEffort.DirectInner[] arrayOfDirectInner = new SinkManyBestEffort.DirectInner[len + 1];
/* 296 */       System.arraycopy(a, 0, arrayOfDirectInner, 0, len);
/* 297 */       arrayOfDirectInner[len] = s;
/*     */       
/* 299 */       this.subscribers = (SinkManyBestEffort.DirectInner<T>[])arrayOfDirectInner;
/*     */       
/* 301 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(SinkManyBestEffort.DirectInner<T> s) {
/* 308 */     SinkManyBestEffort.DirectInner<T>[] a = this.subscribers;
/* 309 */     if (a == SinkManyBestEffort.TERMINATED || a == SinkManyBestEffort.EMPTY) {
/*     */       return;
/*     */     }
/*     */     
/* 313 */     synchronized (this) {
/* 314 */       a = this.subscribers;
/* 315 */       if (a == SinkManyBestEffort.TERMINATED || a == SinkManyBestEffort.EMPTY) {
/*     */         return;
/*     */       }
/* 318 */       int len = a.length;
/*     */       
/* 320 */       int j = -1;
/*     */       
/* 322 */       for (int i = 0; i < len; i++) {
/* 323 */         if (a[i] == s) {
/* 324 */           j = i;
/*     */           break;
/*     */         } 
/*     */       } 
/* 328 */       if (j < 0) {
/*     */         return;
/*     */       }
/* 331 */       if (len == 1) {
/* 332 */         this.subscribers = (SinkManyBestEffort.DirectInner<T>[])SinkManyBestEffort.EMPTY;
/*     */         
/*     */         return;
/*     */       } 
/* 336 */       SinkManyBestEffort.DirectInner[] arrayOfDirectInner = new SinkManyBestEffort.DirectInner[len - 1];
/* 337 */       System.arraycopy(a, 0, arrayOfDirectInner, 0, j);
/* 338 */       System.arraycopy(a, j + 1, arrayOfDirectInner, j, len - j - 1);
/*     */       
/* 340 */       this.subscribers = (SinkManyBestEffort.DirectInner<T>[])arrayOfDirectInner;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasDownstreams() {
/* 346 */     SinkManyBestEffort.DirectInner<T>[] s = this.subscribers;
/* 347 */     return (s != SinkManyBestEffort.EMPTY && s != SinkManyBestEffort.TERMINATED);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getError() {
/* 353 */     if (this.subscribers == SinkManyBestEffort.TERMINATED) {
/* 354 */       return this.error;
/*     */     }
/* 356 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\DirectProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */