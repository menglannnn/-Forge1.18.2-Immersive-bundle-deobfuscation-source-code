/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MonoCacheTime<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */   implements Runnable
/*     */ {
/*  46 */   private static final Duration DURATION_INFINITE = Duration.ofMillis(Long.MAX_VALUE);
/*     */   
/*  48 */   private static final Logger LOGGER = Loggers.getLogger(MonoCacheTime.class);
/*     */   
/*     */   final Function<? super Signal<T>, Duration> ttlGenerator;
/*     */   
/*     */   final Scheduler clock;
/*     */   
/*     */   volatile Signal<T> state;
/*  55 */   static final AtomicReferenceFieldUpdater<MonoCacheTime, Signal> STATE = AtomicReferenceFieldUpdater.newUpdater(MonoCacheTime.class, Signal.class, "state");
/*     */   
/*  57 */   static final Signal<?> EMPTY = new ImmutableSignal((ContextView)Context.empty(), SignalType.ON_NEXT, null, null, null);
/*     */   
/*     */   MonoCacheTime(Mono<? extends T> source, Duration ttl, Scheduler clock) {
/*  60 */     super(source);
/*  61 */     Objects.requireNonNull(ttl, "ttl must not be null");
/*  62 */     Objects.requireNonNull(clock, "clock must not be null");
/*     */     
/*  64 */     this.ttlGenerator = (ignoredSignal -> ttl);
/*  65 */     this.clock = clock;
/*     */     
/*  67 */     Signal<T> state = (Signal)EMPTY;
/*  68 */     this.state = state;
/*     */   }
/*     */   
/*     */   MonoCacheTime(Mono<? extends T> source) {
/*  72 */     this(source, sig -> DURATION_INFINITE, Schedulers.immediate());
/*     */   }
/*     */ 
/*     */   
/*     */   MonoCacheTime(Mono<? extends T> source, Function<? super Signal<T>, Duration> ttlGenerator, Scheduler clock) {
/*  77 */     super(source);
/*  78 */     this.ttlGenerator = ttlGenerator;
/*  79 */     this.clock = clock;
/*     */     
/*  81 */     Signal<T> state = (Signal)EMPTY;
/*  82 */     this.state = state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MonoCacheTime(Mono<? extends T> source, Function<? super T, Duration> valueTtlGenerator, Function<Throwable, Duration> errorTtlGenerator, Supplier<Duration> emptyTtlGenerator, Scheduler clock) {
/*  90 */     super(source);
/*  91 */     Objects.requireNonNull(valueTtlGenerator, "valueTtlGenerator must not be null");
/*  92 */     Objects.requireNonNull(errorTtlGenerator, "errorTtlGenerator must not be null");
/*  93 */     Objects.requireNonNull(emptyTtlGenerator, "emptyTtlGenerator must not be null");
/*  94 */     Objects.requireNonNull(clock, "clock must not be null");
/*     */     
/*  96 */     this.ttlGenerator = (sig -> sig.isOnNext() ? (Duration)valueTtlGenerator.apply(sig.get()) : (sig.isOnError() ? errorTtlGenerator.apply(sig.getThrowable()) : emptyTtlGenerator.get()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     this.clock = clock;
/*     */     
/* 103 */     Signal<T> emptyState = (Signal)EMPTY;
/* 104 */     this.state = emptyState;
/*     */   }
/*     */   
/*     */   public void run() {
/* 108 */     LOGGER.debug("expired {}", new Object[] { this.state });
/*     */     
/* 110 */     Signal<T> emptyState = (Signal)EMPTY;
/* 111 */     this.state = emptyState;
/*     */   }
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*     */     Signal<T> state;
/* 116 */     CacheMonoSubscriber<T> inner = new CacheMonoSubscriber<>(actual);
/* 117 */     actual.onSubscribe(inner);
/*     */     while (true)
/* 119 */     { state = this.state;
/* 120 */       if (state == EMPTY || state instanceof CoordinatorSubscriber)
/* 121 */       { CoordinatorSubscriber<T> coordinator; boolean subscribe = false;
/*     */         
/* 123 */         if (state == EMPTY) {
/* 124 */           coordinator = new CoordinatorSubscriber<>(this);
/* 125 */           if (!STATE.compareAndSet(this, EMPTY, coordinator)) {
/*     */             continue;
/*     */           }
/* 128 */           subscribe = true;
/*     */         } else {
/*     */           
/* 131 */           coordinator = (CoordinatorSubscriber<T>)state;
/*     */         } 
/*     */         
/* 134 */         if (coordinator.add(inner))
/* 135 */         { if (inner.isCancelled()) {
/* 136 */             coordinator.remove(inner);
/*     */           } else {
/*     */             
/* 139 */             inner.coordinator = coordinator;
/*     */           } 
/*     */           
/* 142 */           if (subscribe) {
/* 143 */             this.source.subscribe(coordinator);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 162 */           return null; }  continue; }  break; }  if (state.isOnNext()) { inner.complete(state.get()); } else if (state.isOnComplete()) { inner.onComplete(); } else { inner.onError(state.getThrowable()); }  return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 167 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 168 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CoordinatorSubscriber<T>
/*     */     implements InnerConsumer<T>, Signal<T>
/*     */   {
/*     */     final MonoCacheTime<T> main;
/*     */     volatile Subscription subscription;
/* 177 */     static final AtomicReferenceFieldUpdater<CoordinatorSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(CoordinatorSubscriber.class, Subscription.class, "subscription");
/*     */     
/*     */     volatile Operators.MonoSubscriber<T, T>[] subscribers;
/*     */     
/* 181 */     static final AtomicReferenceFieldUpdater<CoordinatorSubscriber, Operators.MonoSubscriber[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(CoordinatorSubscriber.class, (Class)Operators.MonoSubscriber[].class, "subscribers");
/*     */ 
/*     */     
/*     */     CoordinatorSubscriber(MonoCacheTime<T> main) {
/* 185 */       this.main = main;
/* 186 */       this.subscribers = (Operators.MonoSubscriber<T, T>[])EMPTY;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Throwable getThrowable() {
/* 195 */       throw new UnsupportedOperationException("illegal signal use");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Subscription getSubscription() {
/* 204 */       throw new UnsupportedOperationException("illegal signal use");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 213 */       throw new UnsupportedOperationException("illegal signal use");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SignalType getType() {
/* 222 */       throw new UnsupportedOperationException("illegal signal use");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContextView getContextView() {
/* 231 */       throw new UnsupportedOperationException("illegal signal use: getContextView");
/*     */     }
/*     */     
/*     */     final boolean add(Operators.MonoSubscriber<T, T> toAdd) {
/*     */       while (true) {
/* 236 */         Operators.MonoSubscriber<T, T>[] a = this.subscribers;
/* 237 */         if (a == TERMINATED) {
/* 238 */           return false;
/*     */         }
/* 240 */         int n = a.length;
/*     */         
/* 242 */         Operators.MonoSubscriber[] arrayOfMonoSubscriber = new Operators.MonoSubscriber[n + 1];
/* 243 */         System.arraycopy(a, 0, arrayOfMonoSubscriber, 0, n);
/* 244 */         arrayOfMonoSubscriber[n] = toAdd;
/* 245 */         if (SUBSCRIBERS.compareAndSet(this, a, arrayOfMonoSubscriber))
/* 246 */           return true; 
/*     */       } 
/*     */     }
/*     */     final void remove(Operators.MonoSubscriber<T, T> toRemove) {
/*     */       Operators.MonoSubscriber<T, T>[] a;
/*     */       Operators.MonoSubscriber[] arrayOfMonoSubscriber;
/*     */       do {
/* 253 */         a = this.subscribers;
/* 254 */         if (a == TERMINATED || a == EMPTY) {
/*     */           return;
/*     */         }
/* 257 */         int n = a.length;
/* 258 */         int j = -1;
/* 259 */         for (int i = 0; i < n; i++) {
/* 260 */           if (a[i] == toRemove) {
/* 261 */             j = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 266 */         if (j < 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 271 */         if (n == 1) {
/* 272 */           arrayOfMonoSubscriber = EMPTY;
/*     */         } else {
/*     */           
/* 275 */           arrayOfMonoSubscriber = new Operators.MonoSubscriber[n - 1];
/* 276 */           System.arraycopy(a, 0, arrayOfMonoSubscriber, 0, j);
/* 277 */           System.arraycopy(a, j + 1, arrayOfMonoSubscriber, j, n - j - 1);
/*     */         } 
/* 279 */       } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfMonoSubscriber));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 291 */       if (Operators.validate(this.subscription, s)) {
/* 292 */         this.subscription = s;
/* 293 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void signalCached(Signal<T> signal) {
/* 299 */       Signal<T> signalToPropagate = signal;
/* 300 */       if (MonoCacheTime.STATE.compareAndSet(this.main, this, signal)) {
/* 301 */         Duration ttl = null;
/*     */         try {
/* 303 */           ttl = this.main.ttlGenerator.apply(signal);
/*     */         }
/* 305 */         catch (Throwable generatorError) {
/* 306 */           signalToPropagate = Signal.error(generatorError);
/* 307 */           MonoCacheTime.STATE.set(this.main, signalToPropagate);
/* 308 */           if (signal.isOnError())
/*     */           {
/* 310 */             Exceptions.addSuppressed(generatorError, signal.getThrowable());
/*     */           }
/*     */         } 
/*     */         
/* 314 */         if (ttl != null) {
/* 315 */           if (ttl.isZero()) {
/*     */             
/* 317 */             this.main.run();
/*     */           }
/* 319 */           else if (!ttl.equals(MonoCacheTime.DURATION_INFINITE)) {
/* 320 */             this.main.clock.schedule(this.main, ttl.toNanos(), TimeUnit.NANOSECONDS);
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 326 */           if (signal.isOnNext()) {
/* 327 */             Operators.onNextDropped(signal.get(), currentContext());
/*     */           }
/*     */ 
/*     */           
/* 331 */           this.main.run();
/*     */         } 
/*     */       } 
/*     */       
/* 335 */       for (Operators.MonoSubscriber<T, T> inner : (Operators.MonoSubscriber[])SUBSCRIBERS.getAndSet(this, TERMINATED)) {
/* 336 */         if (signalToPropagate.isOnNext()) {
/* 337 */           inner.complete(signalToPropagate.get());
/*     */         }
/* 339 */         else if (signalToPropagate.isOnError()) {
/* 340 */           inner.onError(signalToPropagate.getThrowable());
/*     */         } else {
/*     */           
/* 343 */           inner.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 350 */       if (this.main.state != this) {
/* 351 */         Operators.onNextDroppedMulticast(t, (InnerProducer<?>[])this.subscribers);
/*     */         return;
/*     */       } 
/* 354 */       signalCached(Signal.next(t));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 359 */       if (this.main.state != this) {
/* 360 */         Operators.onErrorDroppedMulticast(t, (InnerProducer<?>[])this.subscribers);
/*     */         return;
/*     */       } 
/* 363 */       signalCached(Signal.error(t));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 368 */       signalCached(Signal.complete());
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 373 */       return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 379 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 380 */       return null;
/*     */     }
/*     */     
/* 383 */     private static final Operators.MonoSubscriber[] TERMINATED = new Operators.MonoSubscriber[0];
/* 384 */     private static final Operators.MonoSubscriber[] EMPTY = new Operators.MonoSubscriber[0];
/*     */   }
/*     */   
/*     */   static final class CacheMonoSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, T> {
/*     */     MonoCacheTime.CoordinatorSubscriber<T> coordinator;
/*     */     
/*     */     CacheMonoSubscriber(CoreSubscriber<? super T> actual) {
/* 392 */       super(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 397 */       super.cancel();
/* 398 */       MonoCacheTime.CoordinatorSubscriber<T> coordinator = this.coordinator;
/* 399 */       if (coordinator != null) {
/* 400 */         coordinator.remove(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 406 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 407 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoCacheTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */