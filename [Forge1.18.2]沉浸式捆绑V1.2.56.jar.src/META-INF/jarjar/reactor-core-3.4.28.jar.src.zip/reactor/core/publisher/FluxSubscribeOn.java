/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSubscribeOn<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Scheduler scheduler;
/*     */   final boolean requestOnSeparateThread;
/*     */   
/*     */   FluxSubscribeOn(Flux<? extends T> source, Scheduler scheduler, boolean requestOnSeparateThread) {
/*  47 */     super(source);
/*  48 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler, "scheduler");
/*  49 */     this.requestOnSeparateThread = requestOnSeparateThread;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  54 */     Scheduler.Worker worker = Objects.<Scheduler.Worker>requireNonNull(this.scheduler.createWorker(), "The scheduler returned a null Function");
/*     */ 
/*     */     
/*  57 */     SubscribeOnSubscriber<T> parent = new SubscribeOnSubscriber<>(this.source, actual, worker, this.requestOnSeparateThread);
/*     */     
/*  59 */     actual.onSubscribe(parent);
/*     */     
/*     */     try {
/*  62 */       worker.schedule(parent);
/*     */     }
/*  64 */     catch (RejectedExecutionException ree) {
/*  65 */       if (parent.s != Operators.cancelledSubscription()) {
/*  66 */         actual.onError(Operators.onRejectedExecution(ree, parent, null, null, actual
/*  67 */               .currentContext()));
/*     */       }
/*     */     } 
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  75 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  76 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC; 
/*  77 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SubscribeOnSubscriber<T>
/*     */     implements InnerOperator<T, T>, Runnable
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final CorePublisher<? extends T> source;
/*     */     
/*     */     final Scheduler.Worker worker;
/*     */     final boolean requestOnSeparateThread;
/*     */     volatile Subscription s;
/*  91 */     static final AtomicReferenceFieldUpdater<SubscribeOnSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(SubscribeOnSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */ 
/*     */     
/* 100 */     static final AtomicLongFieldUpdater<SubscribeOnSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(SubscribeOnSubscriber.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Thread thread;
/*     */ 
/*     */     
/* 107 */     static final AtomicReferenceFieldUpdater<SubscribeOnSubscriber, Thread> THREAD = AtomicReferenceFieldUpdater.newUpdater(SubscribeOnSubscriber.class, Thread.class, "thread");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SubscribeOnSubscriber(CorePublisher<? extends T> source, CoreSubscriber<? super T> actual, Scheduler.Worker worker, boolean requestOnSeparateThread) {
/* 113 */       this.actual = actual;
/* 114 */       this.worker = worker;
/* 115 */       this.source = source;
/* 116 */       this.requestOnSeparateThread = requestOnSeparateThread;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 121 */       if (Operators.setOnce(S, this, s)) {
/* 122 */         long r = REQUESTED.getAndSet(this, 0L);
/* 123 */         if (r != 0L) {
/* 124 */           requestUpstream(r, s);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void requestUpstream(long n, Subscription s) {
/* 130 */       if (!this.requestOnSeparateThread || Thread.currentThread() == THREAD.get(this)) {
/* 131 */         s.request(n);
/*     */       } else {
/*     */         
/*     */         try {
/* 135 */           this.worker.schedule(() -> s.request(n));
/*     */         }
/* 137 */         catch (RejectedExecutionException ree) {
/* 138 */           if (!this.worker.isDisposed())
/*     */           {
/*     */ 
/*     */             
/* 142 */             throw Operators.onRejectedExecution(ree, this, null, null, this.actual
/* 143 */                 .currentContext());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 151 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*     */       try {
/* 157 */         this.actual.onError(t);
/*     */       } finally {
/*     */         
/* 160 */         this.worker.dispose();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 166 */       this.actual.onComplete();
/* 167 */       this.worker.dispose();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 172 */       if (Operators.validate(n)) {
/* 173 */         Subscription s = S.get(this);
/* 174 */         if (s != null) {
/* 175 */           requestUpstream(n, s);
/*     */         } else {
/*     */           
/* 178 */           Operators.addCap(REQUESTED, this, n);
/* 179 */           s = S.get(this);
/* 180 */           if (s != null) {
/* 181 */             long r = REQUESTED.getAndSet(this, 0L);
/* 182 */             if (r != 0L) {
/* 183 */               requestUpstream(r, s);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 193 */       THREAD.lazySet(this, Thread.currentThread());
/* 194 */       this.source.subscribe(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 199 */       Subscription a = this.s;
/* 200 */       if (a != Operators.cancelledSubscription()) {
/* 201 */         a = S.getAndSet(this, Operators.cancelledSubscription());
/* 202 */         if (a != null && a != Operators.cancelledSubscription()) {
/* 203 */           a.cancel();
/*     */         }
/*     */       } 
/* 206 */       this.worker.dispose();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 212 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 213 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 214 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 215 */       if (key == Scannable.Attr.RUN_ON) return this.worker; 
/* 216 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 218 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 223 */       return this.actual;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\FluxSubscribeOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */