/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoDoOnEach<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final Consumer<? super Signal<T>> onSignal;
/*    */   
/*    */   MonoDoOnEach(Mono<? extends T> source, Consumer<? super Signal<T>> onSignal) {
/* 36 */     super(source);
/* 37 */     this.onSignal = Objects.<Consumer<? super Signal<T>>>requireNonNull(onSignal, "onSignal");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 42 */     return FluxDoOnEach.createSubscriber(actual, this.onSignal, false, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 47 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 48 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoDoOnEach.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */