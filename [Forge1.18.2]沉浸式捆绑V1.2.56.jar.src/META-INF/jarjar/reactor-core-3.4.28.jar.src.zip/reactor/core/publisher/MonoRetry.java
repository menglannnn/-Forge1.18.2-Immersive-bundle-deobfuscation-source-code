/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoRetry<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final long times;
/*    */   
/*    */   MonoRetry(Mono<? extends T> source, long times) {
/* 35 */     super(source);
/* 36 */     if (times < 0L) {
/* 37 */       throw new IllegalArgumentException("times >= 0 required");
/*    */     }
/* 39 */     this.times = times;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 44 */     FluxRetry.RetrySubscriber<T> parent = new FluxRetry.RetrySubscriber<>(this.source, actual, this.times);
/*    */ 
/*    */     
/* 47 */     actual.onSubscribe(parent);
/*    */     
/* 49 */     if (!parent.isCancelled()) {
/* 50 */       parent.resubscribe();
/*    */     }
/* 52 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 57 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 58 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\publisher\MonoRetry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */