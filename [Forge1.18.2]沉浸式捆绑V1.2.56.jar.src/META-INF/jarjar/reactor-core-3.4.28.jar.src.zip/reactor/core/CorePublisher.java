package reactor.core;

import org.reactivestreams.Publisher;

public interface CorePublisher<T> extends Publisher<T> {
  void subscribe(CoreSubscriber<? super T> paramCoreSubscriber);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\CorePublisher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */