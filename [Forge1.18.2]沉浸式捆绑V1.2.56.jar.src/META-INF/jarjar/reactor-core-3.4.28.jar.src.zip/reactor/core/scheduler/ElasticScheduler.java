/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedDeque;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ElasticScheduler
/*     */   implements Scheduler, Scannable
/*     */ {
/*     */   static final ThreadFactory EVICTOR_FACTORY;
/*  57 */   static final AtomicLong COUNTER = new AtomicLong();
/*     */   static {
/*  59 */     EVICTOR_FACTORY = (r -> {
/*     */         Thread t = new Thread(r, "elastic-evictor-" + COUNTER.incrementAndGet());
/*     */         t.setDaemon(true);
/*     */         return t;
/*     */       });
/*     */   }
/*  65 */   static final CachedService SHUTDOWN = new CachedService(null);
/*     */ 
/*     */   
/*     */   static final int DEFAULT_TTL_SECONDS = 60;
/*     */   
/*     */   final ThreadFactory factory;
/*     */   
/*     */   final int ttlSeconds;
/*     */   
/*     */   final Deque<ScheduledExecutorServiceExpiry> cache;
/*     */   
/*     */   final Queue<CachedService> all;
/*     */   
/*     */   ScheduledExecutorService evictor;
/*     */   
/*     */   volatile boolean shutdown;
/*     */ 
/*     */   
/*     */   ElasticScheduler(ThreadFactory factory, int ttlSeconds) {
/*  84 */     if (ttlSeconds < 0) {
/*  85 */       throw new IllegalArgumentException("ttlSeconds must be positive, was: " + ttlSeconds);
/*     */     }
/*  87 */     this.ttlSeconds = ttlSeconds;
/*  88 */     this.factory = factory;
/*  89 */     this.cache = new ConcurrentLinkedDeque<>();
/*  90 */     this.all = new ConcurrentLinkedQueue<>();
/*     */     
/*  92 */     this.shutdown = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService createUndecoratedService() {
/* 100 */     ScheduledThreadPoolExecutor poolExecutor = new ScheduledThreadPoolExecutor(1, this.factory);
/* 101 */     poolExecutor.setMaximumPoolSize(1);
/* 102 */     poolExecutor.setRemoveOnCancelPolicy(true);
/* 103 */     return poolExecutor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/* 108 */     if (this.evictor != null && isDisposed()) {
/* 109 */       throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 114 */     this.evictor = Executors.newSingleThreadScheduledExecutor(EVICTOR_FACTORY);
/* 115 */     this.evictor.scheduleAtFixedRate(this::eviction, this.ttlSeconds, this.ttlSeconds, TimeUnit.SECONDS);
/*     */ 
/*     */ 
/*     */     
/* 119 */     this.shutdown = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/* 124 */     if (!this.shutdown) {
/*     */       return;
/*     */     }
/* 127 */     this.evictor = Executors.newSingleThreadScheduledExecutor(EVICTOR_FACTORY);
/* 128 */     this.evictor.scheduleAtFixedRate(this::eviction, this.ttlSeconds, this.ttlSeconds, TimeUnit.SECONDS);
/*     */ 
/*     */ 
/*     */     
/* 132 */     this.shutdown = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 137 */     return this.shutdown;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 142 */     if (this.shutdown) {
/*     */       return;
/*     */     }
/* 145 */     this.shutdown = true;
/*     */     
/* 147 */     this.evictor.shutdownNow();
/*     */     
/* 149 */     this.cache.clear();
/*     */     
/*     */     CachedService cached;
/*     */     
/* 153 */     while ((cached = this.all.poll()) != null) {
/* 154 */       cached.exec.shutdownNow();
/*     */     }
/*     */   }
/*     */   
/*     */   CachedService pick() {
/* 159 */     if (this.shutdown) {
/* 160 */       return SHUTDOWN;
/*     */     }
/*     */     
/* 163 */     ScheduledExecutorServiceExpiry e = this.cache.pollLast();
/* 164 */     if (e != null) {
/* 165 */       return e.cached;
/*     */     }
/*     */     
/* 168 */     CachedService result = new CachedService(this);
/* 169 */     this.all.offer(result);
/* 170 */     if (this.shutdown) {
/* 171 */       this.all.remove(result);
/* 172 */       return SHUTDOWN;
/*     */     } 
/* 174 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/* 179 */     CachedService cached = pick();
/*     */     
/* 181 */     return Schedulers.directSchedule(cached.exec, task, cached, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 190 */     CachedService cached = pick();
/*     */     
/* 192 */     return Schedulers.directSchedule(cached.exec, task, cached, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 201 */     CachedService cached = pick();
/*     */     
/* 203 */     return (Disposable)Disposables.composite(new Disposable[] { Schedulers.directSchedulePeriodically(cached.exec, task, initialDelay, period, unit), cached });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 213 */     StringBuilder ts = (new StringBuilder("elastic")).append('(');
/* 214 */     if (this.factory instanceof ReactorThreadFactory) {
/* 215 */       ts.append('"').append(((ReactorThreadFactory)this.factory).get()).append('"');
/*     */     }
/* 217 */     ts.append(')');
/* 218 */     return ts.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 223 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 224 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(2147483647); 
/* 225 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.cache.size()); 
/* 226 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 233 */     return this.cache.stream()
/* 234 */       .map(cached -> cached.cached);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 239 */     return new ElasticWorker(pick());
/*     */   }
/*     */   
/*     */   void eviction() {
/* 243 */     long now = System.currentTimeMillis();
/*     */     
/* 245 */     List<ScheduledExecutorServiceExpiry> list = new ArrayList<>(this.cache);
/* 246 */     for (ScheduledExecutorServiceExpiry e : list) {
/* 247 */       if (e.expireMillis < now && 
/* 248 */         this.cache.remove(e)) {
/* 249 */         e.cached.exec.shutdownNow();
/* 250 */         this.all.remove(e.cached);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static final class CachedService
/*     */     implements Disposable, Scannable
/*     */   {
/*     */     final ElasticScheduler parent;
/*     */     final ScheduledExecutorService exec;
/*     */     
/*     */     CachedService(@Nullable ElasticScheduler parent) {
/* 262 */       this.parent = parent;
/* 263 */       if (parent != null) {
/* 264 */         this.exec = Schedulers.decorateExecutorService(parent, parent.createUndecoratedService());
/*     */       } else {
/*     */         
/* 267 */         this.exec = Executors.newSingleThreadScheduledExecutor();
/* 268 */         this.exec.shutdownNow();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 274 */       if (this.exec != null && 
/* 275 */         this != ElasticScheduler.SHUTDOWN && !this.parent.shutdown) {
/*     */ 
/*     */         
/* 278 */         ElasticScheduler.ScheduledExecutorServiceExpiry e = new ElasticScheduler.ScheduledExecutorServiceExpiry(this, System.currentTimeMillis() + this.parent.ttlSeconds * 1000L);
/* 279 */         this.parent.cache.offerLast(e);
/* 280 */         if (this.parent.shutdown && 
/* 281 */           this.parent.cache.remove(e)) {
/* 282 */           this.exec.shutdownNow();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 291 */       if (key == Scannable.Attr.NAME) return this.parent.scanUnsafe(key); 
/* 292 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 293 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 294 */       if (key == Scannable.Attr.CAPACITY) {
/*     */         
/* 296 */         Integer capacity = (Integer)Schedulers.scanExecutor(this.exec, key);
/* 297 */         if (capacity == null || capacity.intValue() == -1) return Integer.valueOf(1); 
/*     */       } 
/* 299 */       return Schedulers.scanExecutor(this.exec, key);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ScheduledExecutorServiceExpiry
/*     */   {
/*     */     final ElasticScheduler.CachedService cached;
/*     */     final long expireMillis;
/*     */     
/*     */     ScheduledExecutorServiceExpiry(ElasticScheduler.CachedService cached, long expireMillis) {
/* 309 */       this.cached = cached;
/* 310 */       this.expireMillis = expireMillis;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ElasticWorker
/*     */     extends AtomicBoolean
/*     */     implements Scheduler.Worker, Scannable {
/*     */     final ElasticScheduler.CachedService cached;
/*     */     final Disposable.Composite tasks;
/*     */     
/*     */     ElasticWorker(ElasticScheduler.CachedService cached) {
/* 321 */       this.cached = cached;
/* 322 */       this.tasks = Disposables.composite();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task) {
/* 327 */       return Schedulers.workerSchedule(this.cached.exec, this.tasks, task, 0L, TimeUnit.MILLISECONDS);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 336 */       return Schedulers.workerSchedule(this.cached.exec, this.tasks, task, delay, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 344 */       return Schedulers.workerSchedulePeriodically(this.cached.exec, this.tasks, task, initialDelay, period, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 354 */       if (compareAndSet(false, true)) {
/* 355 */         this.tasks.dispose();
/* 356 */         this.cached.dispose();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 362 */       return this.tasks.isDisposed();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 367 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 368 */       if (key == Scannable.Attr.NAME) return this.cached.scanUnsafe(key) + ".worker"; 
/* 369 */       if (key == Scannable.Attr.PARENT) return this.cached.parent;
/*     */       
/* 371 */       return this.cached.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\scheduler\ElasticScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */