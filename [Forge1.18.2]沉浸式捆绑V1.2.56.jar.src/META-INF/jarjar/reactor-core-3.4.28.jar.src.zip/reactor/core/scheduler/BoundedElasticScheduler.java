/*      */ package reactor.core.scheduler;
/*      */ 
/*      */ import java.time.Clock;
/*      */ import java.time.Instant;
/*      */ import java.time.ZoneId;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Deque;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.ConcurrentLinkedDeque;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ScheduledFuture;
/*      */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.TimeoutException;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.stream.Stream;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Disposables;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class BoundedElasticScheduler
/*      */   implements Scheduler, SchedulerState.DisposeAwaiter<BoundedElasticScheduler.BoundedServices>, Scannable
/*      */ {
/*   76 */   static final Logger LOGGER = Loggers.getLogger(BoundedElasticScheduler.class);
/*      */   
/*      */   static final int DEFAULT_TTL_SECONDS = 60;
/*      */   
/*      */   final int maxThreads;
/*      */   
/*      */   final int maxTaskQueuedPerThread;
/*      */   
/*      */   final Clock clock;
/*      */   
/*      */   final ThreadFactory factory;
/*      */   
/*      */   final long ttlMillis;
/*      */   volatile SchedulerState<BoundedServices> state;
/*   90 */   static final AtomicReferenceFieldUpdater<BoundedElasticScheduler, SchedulerState> STATE = AtomicReferenceFieldUpdater.newUpdater(BoundedElasticScheduler.class, SchedulerState.class, "state");
/*      */ 
/*      */   
/*   93 */   private static final SchedulerState<BoundedServices> INIT = SchedulerState.init(BoundedServices.SHUTDOWN);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BoundedElasticScheduler(int maxThreads, int maxTaskQueuedPerThread, ThreadFactory threadFactory, long ttlMillis, Clock clock) {
/*  101 */     if (ttlMillis <= 0L) {
/*  102 */       throw new IllegalArgumentException("TTL must be strictly positive, was " + ttlMillis + "ms");
/*      */     }
/*  104 */     if (maxThreads <= 0) {
/*  105 */       throw new IllegalArgumentException("maxThreads must be strictly positive, was " + maxThreads);
/*      */     }
/*  107 */     if (maxTaskQueuedPerThread <= 0) {
/*  108 */       throw new IllegalArgumentException("maxTaskQueuedPerThread must be strictly positive, was " + maxTaskQueuedPerThread);
/*      */     }
/*  110 */     this.maxThreads = maxThreads;
/*  111 */     this.maxTaskQueuedPerThread = maxTaskQueuedPerThread;
/*  112 */     this.factory = threadFactory;
/*  113 */     this.clock = Objects.<Clock>requireNonNull(clock, "A Clock must be provided");
/*  114 */     this.ttlMillis = ttlMillis;
/*      */     
/*  116 */     STATE.lazySet(this, INIT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BoundedElasticScheduler(int maxThreads, int maxTaskQueuedPerThread, ThreadFactory factory, int ttlSeconds) {
/*  130 */     this(maxThreads, maxTaskQueuedPerThread, factory, ttlSeconds * 1000L, 
/*  131 */         Clock.tickSeconds(BoundedServices.ZONE_UTC));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BoundedScheduledExecutorService createBoundedExecutorService() {
/*  139 */     return new BoundedScheduledExecutorService(this.maxTaskQueuedPerThread, this.factory);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDisposed() {
/*  144 */     return (this.state.currentResource == BoundedServices.SHUTDOWN);
/*      */   }
/*      */ 
/*      */   
/*      */   public void init() {
/*  149 */     SchedulerState<BoundedServices> a = this.state;
/*  150 */     if (a != INIT) {
/*  151 */       if (a.currentResource == BoundedServices.SHUTDOWN) {
/*  152 */         throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  161 */     SchedulerState<BoundedServices> b = SchedulerState.init(new BoundedServices(this));
/*  162 */     if (STATE.compareAndSet(this, INIT, b)) {
/*      */       try {
/*  164 */         ((BoundedServices)b.currentResource).evictor.scheduleAtFixedRate((BoundedServices)b.currentResource::eviction, this.ttlMillis, this.ttlMillis, TimeUnit.MILLISECONDS);
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*  169 */       } catch (RejectedExecutionException ree) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  175 */         throw new IllegalStateException("Scheduler disposed during initialization");
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  180 */     ((BoundedServices)b.currentResource).evictor.shutdownNow();
/*      */ 
/*      */ 
/*      */     
/*  184 */     if (isDisposed()) {
/*  185 */       throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void start() {
/*  194 */     SchedulerState<BoundedServices> a = this.state;
/*      */     
/*  196 */     if (a.currentResource != BoundedServices.SHUTDOWN) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  201 */     SchedulerState<BoundedServices> b = SchedulerState.init(new BoundedServices(this));
/*  202 */     if (STATE.compareAndSet(this, a, b)) {
/*      */       try {
/*  204 */         ((BoundedServices)b.currentResource).evictor.scheduleAtFixedRate((BoundedServices)b.currentResource::eviction, this.ttlMillis, this.ttlMillis, TimeUnit.MILLISECONDS);
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*  209 */       } catch (RejectedExecutionException rejectedExecutionException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  218 */     ((BoundedServices)b.currentResource).evictor.shutdownNow();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean await(BoundedServices boundedServices, long timeout, TimeUnit timeUnit) throws InterruptedException {
/*  223 */     if (!boundedServices.evictor.awaitTermination(timeout, timeUnit)) {
/*  224 */       return false;
/*      */     }
/*  226 */     for (BoundedState bs : boundedServices.busyStates.array) {
/*  227 */       if (!bs.executor.awaitTermination(timeout, timeUnit)) {
/*  228 */         return false;
/*      */       }
/*      */     } 
/*  231 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  236 */     SchedulerState<BoundedServices> previous = this.state;
/*      */     
/*  238 */     if (previous.currentResource == BoundedServices.SHUTDOWN) {
/*      */ 
/*      */       
/*  241 */       if (previous.initialResource != null) {
/*  242 */         ((BoundedServices)previous.initialResource).evictor.shutdownNow();
/*  243 */         for (BoundedState bs : ((BoundedServices)previous.initialResource).busyStates.array) {
/*  244 */           bs.shutdown(true);
/*      */         }
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*  250 */     BoundedState[] toAwait = ((BoundedServices)previous.currentResource).dispose();
/*  251 */     SchedulerState<BoundedServices> shutDown = SchedulerState.transition((BoundedServices)previous.currentResource, BoundedServices.SHUTDOWN, this);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  256 */     STATE.compareAndSet(this, previous, shutDown);
/*      */ 
/*      */ 
/*      */     
/*  260 */     assert shutDown.initialResource != null;
/*  261 */     ((BoundedServices)shutDown.initialResource).evictor.shutdownNow();
/*  262 */     for (BoundedState bs : toAwait) {
/*  263 */       bs.shutdown(true);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> disposeGracefully() {
/*  269 */     return Mono.defer(() -> {
/*      */           SchedulerState<BoundedServices> previous = this.state;
/*      */           if (previous.currentResource == BoundedServices.SHUTDOWN) {
/*      */             return previous.onDispose;
/*      */           }
/*      */           BoundedState[] toAwait = ((BoundedServices)previous.currentResource).dispose();
/*      */           SchedulerState<BoundedServices> shutDown = SchedulerState.transition((BoundedServices)previous.currentResource, BoundedServices.SHUTDOWN, this);
/*      */           STATE.compareAndSet(this, previous, shutDown);
/*      */           assert shutDown.initialResource != null;
/*      */           ((BoundedServices)shutDown.initialResource).evictor.shutdown();
/*      */           for (BoundedState bs : toAwait) {
/*      */             bs.shutdown(false);
/*      */           }
/*      */           return shutDown.onDispose;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Disposable schedule(Runnable task) {
/*  298 */     BoundedState picked = ((BoundedServices)this.state.currentResource).pick();
/*      */     try {
/*  300 */       return Schedulers.directSchedule(picked.executor, task, picked, 0L, TimeUnit.MILLISECONDS);
/*  301 */     } catch (RejectedExecutionException ex) {
/*      */       
/*  303 */       picked.dispose();
/*  304 */       throw ex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/*  311 */     BoundedState picked = ((BoundedServices)this.state.currentResource).pick();
/*      */     try {
/*  313 */       return Schedulers.directSchedule(picked.executor, task, picked, delay, unit);
/*  314 */     } catch (RejectedExecutionException ex) {
/*      */       
/*  316 */       picked.dispose();
/*  317 */       throw ex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/*  326 */     BoundedState picked = ((BoundedServices)this.state.currentResource).pick();
/*      */     try {
/*  328 */       Disposable scheduledTask = Schedulers.directSchedulePeriodically(picked.executor, task, initialDelay, period, unit);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  335 */       return (Disposable)Disposables.composite(new Disposable[] { scheduledTask, picked });
/*  336 */     } catch (RejectedExecutionException ex) {
/*      */       
/*  338 */       picked.dispose();
/*  339 */       throw ex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  346 */     StringBuilder ts = (new StringBuilder("boundedElastic")).append('(');
/*  347 */     if (this.factory instanceof ReactorThreadFactory) {
/*  348 */       ts.append('"').append(((ReactorThreadFactory)this.factory).get()).append("\",");
/*      */     }
/*  350 */     ts.append("maxThreads=").append(this.maxThreads)
/*  351 */       .append(",maxTaskQueuedPerThread=").append((this.maxTaskQueuedPerThread == Integer.MAX_VALUE) ? "unbounded" : Integer.valueOf(this.maxTaskQueuedPerThread))
/*  352 */       .append(",ttl=");
/*  353 */     if (this.ttlMillis < 1000L) {
/*  354 */       ts.append(this.ttlMillis).append("ms)");
/*      */     } else {
/*      */       
/*  357 */       ts.append(this.ttlMillis / 1000L).append("s)");
/*      */     } 
/*  359 */     return ts.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int estimateSize() {
/*  366 */     return ((BoundedServices)this.state.currentResource).get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int estimateBusy() {
/*  373 */     return ((BoundedServices)this.state.currentResource).busyStates.array.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int estimateIdle() {
/*  380 */     return ((BoundedServices)this.state.currentResource).idleQueue.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int estimateRemainingTaskCapacity() {
/*  389 */     BoundedState[] busyArray = ((BoundedServices)this.state.currentResource).busyStates.array;
/*  390 */     int totalTaskCapacity = this.maxTaskQueuedPerThread * this.maxThreads;
/*  391 */     for (BoundedState state : busyArray) {
/*  392 */       int stateQueueSize = state.estimateQueueSize();
/*  393 */       if (stateQueueSize >= 0) {
/*  394 */         totalTaskCapacity -= stateQueueSize;
/*      */       } else {
/*      */         
/*  397 */         return -1;
/*      */       } 
/*      */     } 
/*  400 */     return totalTaskCapacity;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/*  405 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/*  406 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(estimateSize()); 
/*  407 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.maxThreads); 
/*  408 */     if (key == Scannable.Attr.NAME) return toString();
/*      */     
/*  410 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Stream<? extends Scannable> inners() {
/*  415 */     BoundedServices services = (BoundedServices)this.state.currentResource;
/*  416 */     return Stream.<Scannable>concat(Stream.of((Scannable[])services.busyStates.array), services.idleQueue.stream())
/*  417 */       .filter(obj -> (obj != null && obj != BoundedServices.CREATING));
/*      */   }
/*      */ 
/*      */   
/*      */   public Scheduler.Worker createWorker() {
/*  422 */     BoundedState picked = ((BoundedServices)this.state.currentResource).pick();
/*  423 */     ExecutorServiceWorker worker = new ExecutorServiceWorker(picked.executor);
/*  424 */     worker.disposables.add(picked);
/*  425 */     return worker;
/*      */   }
/*      */   
/*      */   static final class BusyStates
/*      */   {
/*      */     final BoundedElasticScheduler.BoundedState[] array;
/*      */     final boolean shutdown;
/*      */     
/*      */     public BusyStates(BoundedElasticScheduler.BoundedState[] array, boolean shutdown)
/*      */     {
/*  435 */       this.array = array;
/*  436 */       this.shutdown = shutdown; } } static final class BoundedServices extends AtomicInteger { static final class BusyStates { public BusyStates(BoundedElasticScheduler.BoundedState[] array, boolean shutdown) { this.array = array; this.shutdown = shutdown; }
/*      */ 
/*      */ 
/*      */       
/*      */       final BoundedElasticScheduler.BoundedState[] array;
/*      */       
/*      */       final boolean shutdown; }
/*      */ 
/*      */ 
/*      */     
/*  446 */     static final ZoneId ZONE_UTC = ZoneId.of("UTC");
/*      */     
/*  448 */     static final BusyStates ALL_IDLE = new BusyStates(new BoundedElasticScheduler.BoundedState[0], false);
/*  449 */     static final BusyStates ALL_SHUTDOWN = new BusyStates(new BoundedElasticScheduler.BoundedState[0], true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  457 */     static final ScheduledExecutorService EVICTOR_SHUTDOWN = Executors.newSingleThreadScheduledExecutor(); static {
/*  458 */       EVICTOR_SHUTDOWN.shutdownNow();
/*      */     }
/*  460 */     static final BoundedServices SHUTDOWN = new BoundedServices();
/*  461 */     static final BoundedServices SHUTTING_DOWN = new BoundedServices(); static final BoundedElasticScheduler.BoundedState CREATING; static {
/*  462 */       SHUTDOWN.dispose();
/*  463 */       SHUTTING_DOWN.dispose();
/*      */       
/*  465 */       ScheduledExecutorService s = Executors.newSingleThreadScheduledExecutor();
/*  466 */       s.shutdownNow();
/*  467 */       CREATING = new BoundedElasticScheduler.BoundedState(SHUTDOWN, s)
/*      */         {
/*      */           public String toString() {
/*  470 */             return "CREATING BoundedState";
/*      */           }
/*      */         };
/*  473 */       CREATING.markCount = -1;
/*  474 */       CREATING.idleSinceTimestamp = -1L;
/*      */     }
/*      */     
/*  477 */     static final AtomicLong EVICTOR_COUNTER = new AtomicLong(); static final ThreadFactory EVICTOR_FACTORY; final BoundedElasticScheduler parent; final Clock clock; final ScheduledExecutorService evictor; final Deque<BoundedElasticScheduler.BoundedState> idleQueue; volatile BusyStates busyStates; static {
/*  478 */       EVICTOR_FACTORY = (r -> {
/*      */           Thread t = new Thread(r, "boundedElastic-evictor-" + EVICTOR_COUNTER.incrementAndGet());
/*      */           t.setDaemon(true);
/*      */           return t;
/*      */         });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  493 */     static final AtomicReferenceFieldUpdater<BoundedServices, BusyStates> BUSY_STATES = AtomicReferenceFieldUpdater.newUpdater(BoundedServices.class, BusyStates.class, "busyStates");
/*      */ 
/*      */ 
/*      */     
/*      */     private BoundedServices() {
/*  498 */       this.parent = null;
/*  499 */       this.clock = Clock.fixed(Instant.EPOCH, ZONE_UTC);
/*  500 */       this.idleQueue = new ConcurrentLinkedDeque<>();
/*  501 */       this.busyStates = ALL_SHUTDOWN;
/*  502 */       this.evictor = EVICTOR_SHUTDOWN;
/*      */     }
/*      */     
/*      */     BoundedServices(BoundedElasticScheduler parent) {
/*  506 */       this.parent = parent;
/*  507 */       this.clock = parent.clock;
/*  508 */       this.idleQueue = new ConcurrentLinkedDeque<>();
/*  509 */       this.busyStates = ALL_IDLE;
/*  510 */       this.evictor = Executors.newSingleThreadScheduledExecutor(EVICTOR_FACTORY);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void eviction() {
/*  518 */       long evictionTimestamp = this.parent.clock.millis();
/*  519 */       List<BoundedElasticScheduler.BoundedState> idleCandidates = new ArrayList<>(this.idleQueue);
/*  520 */       for (BoundedElasticScheduler.BoundedState candidate : idleCandidates) {
/*  521 */         if (candidate.tryEvict(evictionTimestamp, this.parent.ttlMillis)) {
/*  522 */           this.idleQueue.remove(candidate);
/*  523 */           decrementAndGet();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     boolean setBusy(BoundedElasticScheduler.BoundedState bs) {
/*      */       BusyStates previous;
/*      */       int len;
/*      */       BoundedElasticScheduler.BoundedState[] replacement;
/*      */       do {
/*  534 */         previous = this.busyStates;
/*  535 */         if (previous.shutdown) {
/*  536 */           return false;
/*      */         }
/*      */         
/*  539 */         len = previous.array.length;
/*  540 */         replacement = new BoundedElasticScheduler.BoundedState[len + 1];
/*  541 */         System.arraycopy(previous.array, 0, replacement, 0, len);
/*  542 */         replacement[len] = bs;
/*      */       }
/*  544 */       while (!BUSY_STATES.compareAndSet(this, previous, new BusyStates(replacement, false)));
/*      */       
/*  546 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     void setIdle(BoundedElasticScheduler.BoundedState boundedState) {
/*      */       BusyStates current, replacement;
/*      */       do {
/*  553 */         current = this.busyStates;
/*  554 */         BoundedElasticScheduler.BoundedState[] arr = this.busyStates.array;
/*  555 */         int len = arr.length;
/*      */         
/*  557 */         if (len == 0 || current.shutdown) {
/*      */           return;
/*      */         }
/*      */         
/*  561 */         replacement = null;
/*  562 */         if (len == 1) {
/*  563 */           if (arr[0] == boundedState) {
/*  564 */             replacement = ALL_IDLE;
/*      */           }
/*      */         } else {
/*      */           
/*  568 */           for (int i = 0; i < len; i++) {
/*  569 */             BoundedElasticScheduler.BoundedState state = arr[i];
/*  570 */             if (state == boundedState) {
/*  571 */               replacement = new BusyStates(new BoundedElasticScheduler.BoundedState[len - 1], false);
/*      */ 
/*      */               
/*  574 */               System.arraycopy(arr, 0, replacement.array, 0, i);
/*  575 */               System.arraycopy(arr, i + 1, replacement.array, i, len - i - 1);
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*  580 */         if (replacement == null) {
/*      */           return;
/*      */         }
/*      */       }
/*  584 */       while (!BUSY_STATES.compareAndSet(this, current, replacement));
/*      */ 
/*      */       
/*  587 */       this.idleQueue.add(boundedState);
/*      */       
/*  589 */       if (this.busyStates.shutdown) {
/*      */         
/*  591 */         boundedState.shutdown(true);
/*  592 */         while ((boundedState = this.idleQueue.pollLast()) != null) {
/*  593 */           boundedState.shutdown(true);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     BoundedElasticScheduler.BoundedState pick() {
/*      */       while (true) {
/*  610 */         if (this.busyStates == ALL_SHUTDOWN) {
/*  611 */           return CREATING;
/*      */         }
/*      */         
/*  614 */         int a = get();
/*  615 */         if (!this.idleQueue.isEmpty()) {
/*      */           
/*  617 */           BoundedElasticScheduler.BoundedState bs = this.idleQueue.pollLast();
/*  618 */           if (bs != null && bs.markPicked()) {
/*  619 */             boolean accepted = setBusy(bs);
/*  620 */             if (!accepted) {
/*  621 */               bs.shutdown(true);
/*  622 */               return CREATING;
/*      */             } 
/*  624 */             return bs;
/*      */           } 
/*      */           continue;
/*      */         } 
/*  628 */         if (a < this.parent.maxThreads) {
/*      */           
/*  630 */           if (compareAndSet(a, a + 1)) {
/*  631 */             ScheduledExecutorService scheduledExecutorService = Schedulers.decorateExecutorService(this.parent, this.parent.createBoundedExecutorService());
/*  632 */             BoundedElasticScheduler.BoundedState newState = new BoundedElasticScheduler.BoundedState(this, scheduledExecutorService);
/*  633 */             if (newState.markPicked()) {
/*  634 */               boolean accepted = setBusy(newState);
/*  635 */               if (!accepted) {
/*  636 */                 newState.shutdown(true);
/*  637 */                 return CREATING;
/*      */               } 
/*  639 */               return newState;
/*      */             } 
/*      */           } 
/*      */           
/*      */           continue;
/*      */         } 
/*  645 */         BoundedElasticScheduler.BoundedState s = choseOneBusy();
/*  646 */         if (s != null && s.markPicked()) {
/*  647 */           return s;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     private BoundedElasticScheduler.BoundedState choseOneBusy() {
/*  656 */       BoundedElasticScheduler.BoundedState[] arr = this.busyStates.array;
/*  657 */       int len = arr.length;
/*  658 */       if (len == 0) {
/*  659 */         return null;
/*      */       }
/*  661 */       if (len == 1) {
/*  662 */         return arr[0];
/*      */       }
/*      */       
/*  665 */       BoundedElasticScheduler.BoundedState choice = arr[0];
/*  666 */       int leastBusy = Integer.MAX_VALUE;
/*      */       
/*  668 */       for (int i = 0; i < arr.length; i++) {
/*  669 */         BoundedElasticScheduler.BoundedState state = arr[i];
/*  670 */         int busy = state.markCount;
/*  671 */         if (busy < leastBusy) {
/*  672 */           leastBusy = busy;
/*  673 */           choice = state;
/*      */         } 
/*      */       } 
/*  676 */       return choice;
/*      */     }
/*      */     
/*      */     public BoundedElasticScheduler.BoundedState[] dispose() {
/*      */       BusyStates current;
/*      */       do {
/*  682 */         current = this.busyStates;
/*      */         
/*  684 */         if (current.shutdown) {
/*  685 */           return current.array;
/*      */         }
/*      */       }
/*  688 */       while (!BUSY_STATES.compareAndSet(this, current, new BusyStates(current.array, true)));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  696 */       BoundedElasticScheduler.BoundedState[] arr = current.array;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  704 */       ArrayList<BoundedElasticScheduler.BoundedState> toAwait = new ArrayList<>(this.idleQueue.size() + arr.length);
/*      */       BoundedElasticScheduler.BoundedState bs;
/*  706 */       while ((bs = this.idleQueue.pollLast()) != null) {
/*  707 */         toAwait.add(bs);
/*      */       }
/*  709 */       Collections.addAll(toAwait, arr);
/*  710 */       return toAwait.<BoundedElasticScheduler.BoundedState>toArray(new BoundedElasticScheduler.BoundedState[0]);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class BoundedState
/*      */     implements Disposable, Scannable
/*      */   {
/*      */     static final int EVICTED = -1;
/*      */ 
/*      */     
/*      */     final BoundedElasticScheduler.BoundedServices parent;
/*      */ 
/*      */     
/*      */     final ScheduledExecutorService executor;
/*      */ 
/*      */     
/*  729 */     long idleSinceTimestamp = -1L;
/*      */     
/*      */     volatile int markCount;
/*  732 */     static final AtomicIntegerFieldUpdater<BoundedState> MARK_COUNT = AtomicIntegerFieldUpdater.newUpdater(BoundedState.class, "markCount");
/*      */     
/*      */     BoundedState(BoundedElasticScheduler.BoundedServices parent, ScheduledExecutorService executor) {
/*  735 */       this.parent = parent;
/*  736 */       this.executor = executor;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int estimateQueueSize() {
/*  743 */       if (this.executor instanceof ScheduledThreadPoolExecutor) {
/*  744 */         return ((ScheduledThreadPoolExecutor)this.executor).getQueue().size();
/*      */       }
/*  746 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean markPicked() {
/*      */       while (true) {
/*  757 */         int i = MARK_COUNT.get(this);
/*  758 */         if (i == -1) {
/*  759 */           return false;
/*      */         }
/*  761 */         if (MARK_COUNT.compareAndSet(this, i, i + 1)) {
/*  762 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean tryEvict(long evictionTimestamp, long ttlMillis) {
/*  778 */       long idleSince = this.idleSinceTimestamp;
/*  779 */       if (idleSince < 0L) return false; 
/*  780 */       long elapsed = evictionTimestamp - idleSince;
/*  781 */       if (elapsed >= ttlMillis && 
/*  782 */         MARK_COUNT.compareAndSet(this, 0, -1)) {
/*  783 */         this.executor.shutdownNow();
/*  784 */         return true;
/*      */       } 
/*      */       
/*  787 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void release() {
/*  800 */       int picked = MARK_COUNT.decrementAndGet(this);
/*  801 */       if (picked < 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  806 */       if (picked == 0) {
/*      */         
/*  808 */         this.idleSinceTimestamp = this.parent.clock.millis();
/*  809 */         this.parent.setIdle(this);
/*      */       }
/*      */       else {
/*      */         
/*  813 */         this.idleSinceTimestamp = -1L;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void shutdown(boolean now) {
/*  824 */       this.idleSinceTimestamp = -1L;
/*  825 */       MARK_COUNT.set(this, -1);
/*  826 */       if (now) {
/*  827 */         this.executor.shutdownNow();
/*      */       } else {
/*  829 */         this.executor.shutdown();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void dispose() {
/*  838 */       release();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isDisposed() {
/*  848 */       return (MARK_COUNT.get(this) <= 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  853 */       return Schedulers.scanExecutor(this.executor, key);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  858 */       return "BoundedState@" + System.identityHashCode(this) + "{ backing=" + MARK_COUNT.get(this) + ", idleSince=" + this.idleSinceTimestamp + ", executor=" + this.executor + '}';
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class BoundedScheduledExecutorService
/*      */     extends ScheduledThreadPoolExecutor
/*      */     implements Scannable
/*      */   {
/*      */     final int queueCapacity;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     BoundedScheduledExecutorService(int queueCapacity, ThreadFactory factory) {
/*  883 */       super(1, factory);
/*  884 */       setMaximumPoolSize(1);
/*  885 */       setRemoveOnCancelPolicy(true);
/*  886 */       if (queueCapacity < 1) {
/*  887 */         throw new IllegalArgumentException("was expecting a non-zero positive queue capacity");
/*      */       }
/*      */       
/*  890 */       this.queueCapacity = queueCapacity;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  895 */       if (Scannable.Attr.TERMINATED == key) return Boolean.valueOf(isTerminated()); 
/*  896 */       if (Scannable.Attr.BUFFERED == key) return Integer.valueOf(getQueue().size()); 
/*  897 */       if (Scannable.Attr.CAPACITY == key) return Integer.valueOf(this.queueCapacity); 
/*  898 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  903 */       int queued = getQueue().size();
/*  904 */       long completed = getCompletedTaskCount();
/*  905 */       String state = (getActiveCount() > 0) ? "ACTIVE" : "IDLE";
/*  906 */       if (this.queueCapacity == Integer.MAX_VALUE) {
/*  907 */         return "BoundedScheduledExecutorService{" + state + ", queued=" + queued + "/unbounded, completed=" + completed + '}';
/*      */       }
/*  909 */       return "BoundedScheduledExecutorService{" + state + ", queued=" + queued + "/" + this.queueCapacity + ", completed=" + completed + '}';
/*      */     }
/*      */     
/*      */     void ensureQueueCapacity(int taskCount) {
/*  913 */       if (this.queueCapacity == Integer.MAX_VALUE) {
/*      */         return;
/*      */       }
/*  916 */       int queueSize = getQueue().size();
/*  917 */       if (queueSize + taskCount > this.queueCapacity) {
/*  918 */         throw Exceptions.failWithRejected("Task capacity of bounded elastic scheduler reached while scheduling " + taskCount + " tasks (" + (queueSize + taskCount) + "/" + this.queueCapacity + ")");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
/*  930 */       ensureQueueCapacity(1);
/*  931 */       return super.schedule(command, delay, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
/*  942 */       ensureQueueCapacity(1);
/*  943 */       return super.schedule(callable, delay, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
/*  955 */       ensureQueueCapacity(1);
/*  956 */       return super.scheduleAtFixedRate(command, initialDelay, period, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
/*  968 */       ensureQueueCapacity(1);
/*  969 */       return super.scheduleWithFixedDelay(command, initialDelay, delay, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void shutdown() {
/*  977 */       super.shutdown();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<Runnable> shutdownNow() {
/*  985 */       return super.shutdownNow();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isShutdown() {
/*  993 */       return super.isShutdown();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isTerminated() {
/* 1001 */       return super.isTerminated();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/* 1010 */       return super.awaitTermination(timeout, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized <T> Future<T> submit(Callable<T> task) {
/* 1018 */       ensureQueueCapacity(1);
/* 1019 */       return super.submit(task);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized <T> Future<T> submit(Runnable task, T result) {
/* 1027 */       ensureQueueCapacity(1);
/* 1028 */       return super.submit(task, result);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized Future<?> submit(Runnable task) {
/* 1036 */       ensureQueueCapacity(1);
/* 1037 */       return super.submit(task);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
/* 1047 */       ensureQueueCapacity(tasks.size());
/* 1048 */       return super.invokeAll(tasks);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
/* 1060 */       ensureQueueCapacity(tasks.size());
/* 1061 */       return super.invokeAll(tasks, timeout, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
/* 1070 */       ensureQueueCapacity(tasks.size());
/* 1071 */       return super.invokeAny(tasks);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 1083 */       ensureQueueCapacity(tasks.size());
/* 1084 */       return super.invokeAny(tasks, timeout, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public synchronized void execute(Runnable command) {
/* 1092 */       ensureQueueCapacity(1);
/* 1093 */       super.submit(command);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\scheduler\BoundedElasticScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */