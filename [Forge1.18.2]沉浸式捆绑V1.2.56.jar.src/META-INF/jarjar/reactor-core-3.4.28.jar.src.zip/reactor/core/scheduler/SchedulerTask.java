/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SchedulerTask
/*     */   implements Runnable, Disposable, Callable<Void>
/*     */ {
/*     */   final Runnable task;
/*  32 */   static final Future<Void> FINISHED = new FutureTask<>(() -> null);
/*  33 */   static final Future<Void> CANCELLED = new FutureTask<>(() -> null);
/*     */   
/*  35 */   static final Disposable TAKEN = Disposables.disposed();
/*     */   
/*     */   volatile Future<?> future;
/*     */   
/*  39 */   static final AtomicReferenceFieldUpdater<SchedulerTask, Future> FUTURE = AtomicReferenceFieldUpdater.newUpdater(SchedulerTask.class, Future.class, "future");
/*     */   
/*     */   volatile Disposable parent;
/*     */   
/*  43 */   static final AtomicReferenceFieldUpdater<SchedulerTask, Disposable> PARENT = AtomicReferenceFieldUpdater.newUpdater(SchedulerTask.class, Disposable.class, "parent");
/*     */   
/*     */   Thread thread;
/*     */   
/*     */   SchedulerTask(Runnable task, @Nullable Disposable parent) {
/*  48 */     this.task = task;
/*  49 */     PARENT.lazySet(this, parent);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Void call() {
/*  55 */     this.thread = Thread.currentThread();
/*  56 */     Disposable d = null;
/*     */     try {
/*     */       do {
/*  59 */         d = this.parent;
/*  60 */         if (d == TAKEN || d == null) {
/*     */           break;
/*     */         }
/*  63 */       } while (!PARENT.compareAndSet(this, d, TAKEN));
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  68 */         this.task.run();
/*     */       }
/*  70 */       catch (Throwable ex) {
/*  71 */         Schedulers.handleError(ex);
/*     */       } 
/*     */     } finally {
/*     */       Future<?> f;
/*  75 */       this.thread = null;
/*     */       
/*     */       do {
/*  78 */         f = this.future;
/*  79 */       } while (f != CANCELLED && !FUTURE.compareAndSet(this, f, FINISHED));
/*     */ 
/*     */ 
/*     */       
/*  83 */       if (d != null) {
/*  84 */         d.dispose();
/*     */       }
/*     */     } 
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  92 */     call();
/*     */   }
/*     */   void setFuture(Future<?> f) {
/*     */     Future<?> o;
/*     */     do {
/*  97 */       o = this.future;
/*  98 */       if (o == FINISHED) {
/*     */         return;
/*     */       }
/* 101 */       if (o == CANCELLED) {
/* 102 */         f.cancel((this.thread != Thread.currentThread()));
/*     */         return;
/*     */       } 
/* 105 */     } while (!FUTURE.compareAndSet(this, o, f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 113 */     Future<?> a = this.future;
/* 114 */     return (FINISHED == a || CANCELLED == a);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*     */     while (true) {
/* 120 */       Future<?> f = this.future;
/* 121 */       if (f == FINISHED || f == CANCELLED) {
/*     */         break;
/*     */       }
/* 124 */       if (FUTURE.compareAndSet(this, f, CANCELLED)) {
/* 125 */         if (f != null) {
/* 126 */           f.cancel((this.thread != Thread.currentThread()));
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/*     */     while (true) {
/* 134 */       Disposable d = this.parent;
/* 135 */       if (d == TAKEN || d == null) {
/*     */         break;
/*     */       }
/* 138 */       if (PARENT.compareAndSet(this, d, TAKEN)) {
/* 139 */         d.dispose();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\scheduler\SchedulerTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */