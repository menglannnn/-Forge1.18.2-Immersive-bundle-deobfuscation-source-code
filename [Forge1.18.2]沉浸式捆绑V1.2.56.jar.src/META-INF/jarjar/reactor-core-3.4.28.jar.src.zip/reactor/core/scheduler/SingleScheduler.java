/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SingleScheduler
/*     */   implements Scheduler, Supplier<ScheduledExecutorService>, Scannable, SchedulerState.DisposeAwaiter<ScheduledExecutorService>
/*     */ {
/*  40 */   static final AtomicLong COUNTER = new AtomicLong();
/*     */ 
/*     */ 
/*     */   
/*  44 */   static final ScheduledExecutorService TERMINATED = Executors.newSingleThreadScheduledExecutor(); static {
/*  45 */     TERMINATED.shutdownNow();
/*     */   }
/*     */ 
/*     */   
/*     */   final ThreadFactory factory;
/*     */   
/*     */   volatile SchedulerState<ScheduledExecutorService> state;
/*     */   
/*  53 */   private static final AtomicReferenceFieldUpdater<SingleScheduler, SchedulerState> STATE = AtomicReferenceFieldUpdater.newUpdater(SingleScheduler.class, SchedulerState.class, "state");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private static final SchedulerState<ScheduledExecutorService> INIT = SchedulerState.init(TERMINATED);
/*     */   
/*     */   SingleScheduler(ThreadFactory factory) {
/*  61 */     this.factory = factory;
/*  62 */     STATE.lazySet(this, INIT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService get() {
/*  71 */     ScheduledThreadPoolExecutor e = (ScheduledThreadPoolExecutor)Executors.newScheduledThreadPool(1, this.factory);
/*  72 */     e.setRemoveOnCancelPolicy(true);
/*  73 */     e.setMaximumPoolSize(1);
/*  74 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  80 */     SchedulerState<ScheduledExecutorService> current = this.state;
/*  81 */     return (current != INIT && current.currentResource == TERMINATED);
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/*  86 */     SchedulerState<ScheduledExecutorService> a = this.state;
/*  87 */     if (a != INIT) {
/*  88 */       if (a.currentResource == TERMINATED) {
/*  89 */         throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  97 */     SchedulerState<ScheduledExecutorService> b = SchedulerState.init(
/*  98 */         Schedulers.decorateExecutorService(this, get()));
/*     */ 
/*     */     
/* 101 */     if (!STATE.compareAndSet(this, INIT, b)) {
/* 102 */       ((ScheduledExecutorService)b.currentResource).shutdownNow();
/*     */ 
/*     */ 
/*     */       
/* 106 */       if (isDisposed()) {
/* 107 */         throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 117 */     SchedulerState<ScheduledExecutorService> a = this.state;
/* 118 */     if (a.currentResource != TERMINATED) {
/*     */       return;
/*     */     }
/*     */     
/* 122 */     SchedulerState<ScheduledExecutorService> b = SchedulerState.init(
/* 123 */         Schedulers.decorateExecutorService(this, get()));
/*     */ 
/*     */     
/* 126 */     if (STATE.compareAndSet(this, a, b)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 131 */     ((ScheduledExecutorService)b.currentResource).shutdownNow();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean await(ScheduledExecutorService resource, long timeout, TimeUnit timeUnit) throws InterruptedException {
/* 136 */     return resource.awaitTermination(timeout, timeUnit);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 141 */     SchedulerState<ScheduledExecutorService> previous = this.state;
/*     */     
/* 143 */     if (previous.currentResource == TERMINATED) {
/*     */ 
/*     */       
/* 146 */       assert previous.initialResource != null;
/* 147 */       ((ScheduledExecutorService)previous.initialResource).shutdownNow();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 152 */     SchedulerState<ScheduledExecutorService> terminated = SchedulerState.transition((ScheduledExecutorService)previous.currentResource, TERMINATED, this);
/*     */     
/* 154 */     STATE.compareAndSet(this, previous, terminated);
/*     */ 
/*     */ 
/*     */     
/* 158 */     assert terminated.initialResource != null;
/* 159 */     ((ScheduledExecutorService)terminated.initialResource).shutdownNow();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeGracefully() {
/* 164 */     return Mono.defer(() -> {
/*     */           SchedulerState<ScheduledExecutorService> previous = this.state;
/*     */           if (previous.currentResource == TERMINATED) {
/*     */             return previous.onDispose;
/*     */           }
/*     */           SchedulerState<ScheduledExecutorService> terminated = SchedulerState.transition((ScheduledExecutorService)previous.currentResource, TERMINATED, this);
/*     */           STATE.compareAndSet(this, previous, terminated);
/*     */           assert terminated.initialResource != null;
/*     */           ((ScheduledExecutorService)terminated.initialResource).shutdown();
/*     */           return terminated.onDispose;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/* 186 */     ScheduledExecutorService executor = (ScheduledExecutorService)this.state.currentResource;
/* 187 */     return Schedulers.directSchedule(executor, task, null, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 193 */     return Schedulers.directSchedule((ScheduledExecutorService)this.state.currentResource, task, null, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 201 */     return Schedulers.directSchedulePeriodically((ScheduledExecutorService)this.state.currentResource, task, initialDelay, period, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 211 */     StringBuilder ts = (new StringBuilder("single")).append('(');
/* 212 */     if (this.factory instanceof ReactorThreadFactory) {
/* 213 */       ts.append('"').append(((ReactorThreadFactory)this.factory).get()).append('"');
/*     */     }
/* 215 */     return ts.append(')').toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 220 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 221 */     if (key == Scannable.Attr.NAME) return toString(); 
/* 222 */     if (key == Scannable.Attr.CAPACITY || key == Scannable.Attr.BUFFERED) return Integer.valueOf(1);
/*     */     
/* 224 */     return Schedulers.scanExecutor((Executor)this.state.currentResource, key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 229 */     return new ExecutorServiceWorker((ScheduledExecutorService)this.state.currentResource);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\scheduler\SingleScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */