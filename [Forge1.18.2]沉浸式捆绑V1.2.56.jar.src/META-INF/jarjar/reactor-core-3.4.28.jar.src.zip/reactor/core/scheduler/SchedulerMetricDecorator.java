/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import io.micrometer.core.instrument.MeterRegistry;
/*     */ import io.micrometer.core.instrument.Tags;
/*     */ import io.micrometer.core.instrument.binder.jvm.ExecutorServiceMetrics;
/*     */ import io.micrometer.core.instrument.search.Search;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.BiFunction;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Metrics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SchedulerMetricDecorator
/*     */   implements BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService>, Disposable
/*     */ {
/*     */   static final String TAG_SCHEDULER_ID = "reactor.scheduler.id";
/*     */   static final String METRICS_DECORATOR_KEY = "reactor.metrics.decorator";
/*  44 */   final WeakHashMap<Scheduler, String> seenSchedulers = new WeakHashMap<>();
/*  45 */   final Map<String, AtomicInteger> schedulerDifferentiator = new HashMap<>();
/*  46 */   final WeakHashMap<Scheduler, AtomicInteger> executorDifferentiator = new WeakHashMap<>();
/*     */   final MeterRegistry registry;
/*     */   
/*     */   SchedulerMetricDecorator() {
/*  50 */     this.registry = Metrics.MicrometerConfiguration.getRegistry();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ScheduledExecutorService apply(Scheduler scheduler, final ScheduledExecutorService service) {
/*  58 */     String schedulerName = (String)Scannable.from(scheduler).scanOrDefault(Scannable.Attr.NAME, scheduler.getClass().getName());
/*     */ 
/*     */ 
/*     */     
/*  62 */     String schedulerId = this.seenSchedulers.computeIfAbsent(scheduler, s -> {
/*     */           int schedulerDifferentiator = ((AtomicInteger)this.schedulerDifferentiator.computeIfAbsent(schedulerName, ())).getAndIncrement();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return (schedulerDifferentiator == 0) ? schedulerName : (schedulerName + "#" + schedulerDifferentiator);
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     final String executorId = schedulerId + "-" + ((AtomicInteger)this.executorDifferentiator.computeIfAbsent(scheduler, key -> new AtomicInteger(0))).getAndIncrement();
/*     */     
/*  76 */     final Tags tags = Tags.of("reactor.scheduler.id", schedulerId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     class MetricsRemovingScheduledExecutorService
/*     */       extends DelegatingScheduledExecutorService
/*     */     {
/*     */       MetricsRemovingScheduledExecutorService()
/*     */       {
/*  91 */         super(ExecutorServiceMetrics.monitor(SchedulerMetricDecorator.this.registry, param1ScheduledExecutorService, param1String, (Iterable)param1Tags));
/*     */       }
/*     */ 
/*     */       
/*     */       public List<Runnable> shutdownNow() {
/*  96 */         removeMetrics();
/*  97 */         return super.shutdownNow();
/*     */       }
/*     */ 
/*     */       
/*     */       public void shutdown() {
/* 102 */         removeMetrics();
/* 103 */         super.shutdown();
/*     */       }
/*     */       
/*     */       void removeMetrics() {
/* 107 */         Search.in(SchedulerMetricDecorator.this.registry)
/* 108 */           .tag("name", executorId)
/* 109 */           .meters()
/* 110 */           .forEach(SchedulerMetricDecorator.this.registry::remove);
/*     */       }
/*     */     };
/* 113 */     return new MetricsRemovingScheduledExecutorService();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 118 */     Search.in(this.registry)
/* 119 */       .tagKeys(new String[] { "reactor.scheduler.id"
/* 120 */         }).meters()
/* 121 */       .forEach(this.registry::remove);
/*     */ 
/*     */ 
/*     */     
/* 125 */     this.seenSchedulers.clear();
/* 126 */     this.schedulerDifferentiator.clear();
/* 127 */     this.executorDifferentiator.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\scheduler\SchedulerMetricDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */