/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DelegateServiceScheduler
/*     */   implements Scheduler, SchedulerState.DisposeAwaiter<ScheduledExecutorService>, Scannable
/*     */ {
/*  54 */   static final ScheduledExecutorService TERMINATED = Executors.newSingleThreadScheduledExecutor(); static {
/*  55 */     TERMINATED.shutdownNow();
/*     */   }
/*     */ 
/*     */   
/*     */   final String executorName;
/*     */   
/*     */   final ScheduledExecutorService original;
/*     */   
/*     */   @Nullable
/*     */   volatile SchedulerState<ScheduledExecutorService> state;
/*  65 */   static final AtomicReferenceFieldUpdater<DelegateServiceScheduler, SchedulerState> STATE = AtomicReferenceFieldUpdater.newUpdater(DelegateServiceScheduler.class, SchedulerState.class, "state");
/*     */ 
/*     */   
/*     */   DelegateServiceScheduler(String executorName, ExecutorService executorService) {
/*  69 */     this.executorName = executorName;
/*  70 */     this.original = convert(executorService);
/*     */   }
/*     */   
/*     */   ScheduledExecutorService getOrCreate() {
/*  74 */     SchedulerState<ScheduledExecutorService> s = this.state;
/*  75 */     if (s == null) {
/*  76 */       init();
/*  77 */       s = this.state;
/*  78 */       if (s == null) {
/*  79 */         throw new IllegalStateException("executor is null after implicit start()");
/*     */       }
/*     */     } 
/*  82 */     return (ScheduledExecutorService)s.currentResource;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/*  87 */     return new ExecutorServiceWorker(getOrCreate());
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/*  92 */     return Schedulers.directSchedule(getOrCreate(), task, null, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/*  97 */     return Schedulers.directSchedule(getOrCreate(), task, null, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 105 */     return Schedulers.directSchedulePeriodically(getOrCreate(), task, initialDelay, period, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 114 */     STATE.compareAndSet(this, null, 
/* 115 */         SchedulerState.init(Schedulers.decorateExecutorService(this, this.original)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/* 120 */     SchedulerState<ScheduledExecutorService> a = this.state;
/* 121 */     if (a != null) {
/* 122 */       if (a.currentResource == TERMINATED) {
/* 123 */         throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 131 */     if (!STATE.compareAndSet(this, null, 
/* 132 */         SchedulerState.init(Schedulers.decorateExecutorService(this, this.original)))) {
/* 133 */       if (isDisposed()) {
/* 134 */         throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 143 */     SchedulerState<ScheduledExecutorService> current = this.state;
/* 144 */     return (current != null && current.currentResource == TERMINATED);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean await(ScheduledExecutorService resource, long timeout, TimeUnit timeUnit) throws InterruptedException {
/* 150 */     return resource.awaitTermination(timeout, timeUnit);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 155 */     SchedulerState<ScheduledExecutorService> previous = this.state;
/*     */     
/* 157 */     if (previous != null && previous.currentResource == TERMINATED) {
/* 158 */       assert previous.initialResource != null;
/* 159 */       ((ScheduledExecutorService)previous.initialResource).shutdownNow();
/*     */       
/*     */       return;
/*     */     } 
/* 163 */     SchedulerState<ScheduledExecutorService> terminated = SchedulerState.transition((previous == null) ? null : (ScheduledExecutorService)previous.currentResource, TERMINATED, this);
/*     */ 
/*     */     
/* 166 */     STATE.compareAndSet(this, previous, terminated);
/*     */ 
/*     */ 
/*     */     
/* 170 */     if (terminated.initialResource != null) {
/* 171 */       ((ScheduledExecutorService)terminated.initialResource).shutdownNow();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeGracefully() {
/* 177 */     return Mono.defer(() -> {
/*     */           SchedulerState<ScheduledExecutorService> previous = this.state;
/*     */           if (previous != null && previous.currentResource == TERMINATED) {
/*     */             return previous.onDispose;
/*     */           }
/*     */           SchedulerState<ScheduledExecutorService> terminated = SchedulerState.transition((previous == null) ? null : (ScheduledExecutorService)previous.currentResource, TERMINATED, this);
/*     */           STATE.compareAndSet(this, previous, terminated);
/*     */           if (terminated.initialResource != null) {
/*     */             ((ScheduledExecutorService)terminated.initialResource).shutdown();
/*     */           }
/*     */           return terminated.onDispose;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ScheduledExecutorService convert(ExecutorService executor) {
/* 200 */     if (executor instanceof ScheduledExecutorService) {
/* 201 */       return (ScheduledExecutorService)executor;
/*     */     }
/* 203 */     return new UnsupportedScheduledExecutorService(executor);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 208 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 209 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 211 */     SchedulerState<ScheduledExecutorService> s = this.state;
/* 212 */     if (s != null) {
/* 213 */       return Schedulers.scanExecutor((Executor)s.currentResource, key);
/*     */     }
/* 215 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 220 */     return "fromExecutorService(" + this.executorName + ')';
/*     */   }
/*     */   
/*     */   static final class UnsupportedScheduledExecutorService
/*     */     implements ScheduledExecutorService, Supplier<ExecutorService>
/*     */   {
/*     */     final ExecutorService exec;
/*     */     
/*     */     UnsupportedScheduledExecutorService(ExecutorService exec) {
/* 229 */       this.exec = exec;
/*     */     }
/*     */ 
/*     */     
/*     */     public ExecutorService get() {
/* 234 */       return this.exec;
/*     */     }
/*     */ 
/*     */     
/*     */     public void shutdown() {
/* 239 */       this.exec.shutdown();
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public List<Runnable> shutdownNow() {
/* 245 */       return this.exec.shutdownNow();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isShutdown() {
/* 250 */       return this.exec.isShutdown();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTerminated() {
/* 255 */       return this.exec.isTerminated();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean awaitTermination(long timeout, @NonNull TimeUnit unit) throws InterruptedException {
/* 261 */       return this.exec.awaitTermination(timeout, unit);
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> Future<T> submit(@NonNull Callable<T> task) {
/* 267 */       return this.exec.submit(task);
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> Future<T> submit(@NonNull Runnable task, T result) {
/* 273 */       return this.exec.submit(task, result);
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Future<?> submit(@NonNull Runnable task) {
/* 279 */       return this.exec.submit(task);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> List<Future<T>> invokeAll(@NonNull Collection<? extends Callable<T>> tasks) throws InterruptedException {
/* 286 */       return this.exec.invokeAll(tasks);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> List<Future<T>> invokeAll(@NonNull Collection<? extends Callable<T>> tasks, long timeout, @NonNull TimeUnit unit) throws InterruptedException {
/* 294 */       return this.exec.invokeAll(tasks, timeout, unit);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <T> T invokeAny(@NonNull Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
/* 301 */       return this.exec.invokeAny(tasks);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> T invokeAny(@NonNull Collection<? extends Callable<T>> tasks, long timeout, @NonNull TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 309 */       return this.exec.invokeAny(tasks, timeout, unit);
/*     */     }
/*     */ 
/*     */     
/*     */     public void execute(@NonNull Runnable command) {
/* 314 */       this.exec.execute(command);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public ScheduledFuture<?> schedule(@NonNull Runnable command, long delay, @NonNull TimeUnit unit) {
/* 322 */       throw Exceptions.failWithRejectedNotTimeCapable();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public <V> ScheduledFuture<V> schedule(@NonNull Callable<V> callable, long delay, @NonNull TimeUnit unit) {
/* 330 */       throw Exceptions.failWithRejectedNotTimeCapable();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public ScheduledFuture<?> scheduleAtFixedRate(@NonNull Runnable command, long initialDelay, long period, @NonNull TimeUnit unit) {
/* 339 */       throw Exceptions.failWithRejectedNotTimeCapable();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public ScheduledFuture<?> scheduleWithFixedDelay(@NonNull Runnable command, long initialDelay, long delay, @NonNull TimeUnit unit) {
/* 348 */       throw Exceptions.failWithRejectedNotTimeCapable();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 353 */       return this.exec.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.28.jar!\reactor\core\scheduler\DelegateServiceScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */