/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CacheWriter<K, V>
/*    */ {
/*    */   void write(K paramK, V paramV);
/*    */   
/*    */   void delete(K paramK, V paramV, RemovalCause paramRemovalCause);
/*    */   
/*    */   static <K, V> CacheWriter<K, V> disabledWriter() {
/* 65 */     CacheWriter<K, V> writer = DisabledWriter.INSTANCE;
/* 66 */     return writer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\CacheWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */