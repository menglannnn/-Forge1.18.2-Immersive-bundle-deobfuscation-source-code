/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SILAW<K, V>
/*    */   extends SILA<K, V>
/*    */ {
/*    */   final WriteOrderDeque<Node<K, V>> writeOrderDeque;
/*    */   volatile long expiresAfterWriteNanos;
/*    */   
/*    */   SILAW(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 38 */     super(builder, cacheLoader, async);
/* 39 */     this.writeOrderDeque = new WriteOrderDeque<>();
/* 40 */     this.expiresAfterWriteNanos = builder.getExpiresAfterWriteNanos();
/*    */   }
/*    */   
/*    */   protected final WriteOrderDeque<Node<K, V>> writeOrderDeque() {
/* 44 */     return this.writeOrderDeque;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterWrite() {
/* 48 */     return true;
/*    */   }
/*    */   
/*    */   protected final long expiresAfterWriteNanos() {
/* 52 */     return this.expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterWriteNanos(long expiresAfterWriteNanos) {
/* 56 */     this.expiresAfterWriteNanos = expiresAfterWriteNanos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SILAW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */