/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import com.github.benmanes.caffeine.cache.stats.CacheStats;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletionException;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface LocalManualCache<K, V>
/*     */   extends Cache<K, V>
/*     */ {
/*     */   default long estimatedSize() {
/*  47 */     return cache().estimatedSize();
/*     */   }
/*     */ 
/*     */   
/*     */   default void cleanUp() {
/*  52 */     cache().cleanUp();
/*     */   }
/*     */ 
/*     */   
/*     */   default V getIfPresent(Object key) {
/*  57 */     return cache().getIfPresent(key, true);
/*     */   }
/*     */ 
/*     */   
/*     */   default V get(K key, Function<? super K, ? extends V> mappingFunction) {
/*  62 */     return cache().computeIfAbsent(key, mappingFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   default Map<K, V> getAllPresent(Iterable<?> keys) {
/*  67 */     return cache().getAllPresent(keys);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default Map<K, V> getAll(Iterable<? extends K> keys, Function<Iterable<? extends K>, Map<K, V>> mappingFunction) {
/*  73 */     Objects.requireNonNull(mappingFunction);
/*     */     
/*  75 */     Set<K> keysToLoad = new LinkedHashSet<>();
/*  76 */     Map<K, V> found = cache().getAllPresent(keys);
/*  77 */     Map<K, V> result = new LinkedHashMap<>(found.size());
/*  78 */     for (K key : keys) {
/*  79 */       V value = found.get(key);
/*  80 */       if (value == null) {
/*  81 */         keysToLoad.add(key);
/*     */       }
/*  83 */       result.put(key, value);
/*     */     } 
/*  85 */     if (keysToLoad.isEmpty()) {
/*  86 */       return found;
/*     */     }
/*     */     
/*  89 */     bulkLoad(keysToLoad, result, mappingFunction);
/*  90 */     return Collections.unmodifiableMap(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void bulkLoad(Set<K> keysToLoad, Map<K, V> result, Function<Iterable<? extends K>, Map<K, V>> mappingFunction) {
/*  99 */     boolean success = false;
/* 100 */     long startTime = cache().statsTicker().read();
/*     */     try {
/* 102 */       Map<K, V> loaded = mappingFunction.apply(keysToLoad);
/* 103 */       loaded.forEach((key, value) -> cache().put((K)key, (V)value, false));
/*     */       
/* 105 */       for (K key : keysToLoad) {
/* 106 */         V value = loaded.get(key);
/* 107 */         if (value == null) {
/* 108 */           result.remove(key); continue;
/*     */         } 
/* 110 */         result.put(key, value);
/*     */       } 
/*     */       
/* 113 */       success = !loaded.isEmpty();
/* 114 */     } catch (RuntimeException e) {
/* 115 */       throw e;
/* 116 */     } catch (Exception e) {
/* 117 */       throw new CompletionException(e);
/*     */     } finally {
/* 119 */       long loadTime = cache().statsTicker().read() - startTime;
/* 120 */       if (success) {
/* 121 */         cache().statsCounter().recordLoadSuccess(loadTime);
/*     */       } else {
/* 123 */         cache().statsCounter().recordLoadFailure(loadTime);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   default void put(K key, V value) {
/* 130 */     cache().put(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   default void putAll(Map<? extends K, ? extends V> map) {
/* 135 */     cache().putAll(map);
/*     */   }
/*     */ 
/*     */   
/*     */   default void invalidate(Object key) {
/* 140 */     cache().remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   default void invalidateAll(Iterable<?> keys) {
/* 145 */     cache().invalidateAll(keys);
/*     */   }
/*     */ 
/*     */   
/*     */   default void invalidateAll() {
/* 150 */     cache().clear();
/*     */   }
/*     */ 
/*     */   
/*     */   default CacheStats stats() {
/* 155 */     return cache().statsCounter().snapshot();
/*     */   }
/*     */ 
/*     */   
/*     */   default ConcurrentMap<K, V> asMap() {
/* 160 */     return cache();
/*     */   }
/*     */   
/*     */   LocalCache<K, V> cache();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\LocalManualCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */