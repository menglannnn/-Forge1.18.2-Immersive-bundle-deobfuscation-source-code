/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSLSA<K, V>
/*     */   extends SSLS<K, V>
/*     */ {
/*     */   final Ticker ticker;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque;
/*     */   final Expiry<K, V> expiry;
/*     */   final TimerWheel<K, V> timerWheel;
/*     */   volatile long expiresAfterAccessNanos;
/*     */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*     */   final Pacer pacer;
/*     */   
/*     */   SSLSA(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/*  48 */     super(builder, cacheLoader, async);
/*  49 */     this.ticker = builder.getTicker();
/*  50 */     this
/*     */ 
/*     */       
/*  53 */       .accessOrderWindowDeque = (builder.evicts() || builder.expiresAfterAccess()) ? new AccessOrderDeque<>() : null;
/*  54 */     this.expiry = builder.getExpiry(this.isAsync);
/*  55 */     this.timerWheel = builder.expiresVariable() ? new TimerWheel<>(this) : null;
/*  56 */     this.expiresAfterAccessNanos = builder.getExpiresAfterAccessNanos();
/*  57 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*  58 */     this
/*     */ 
/*     */       
/*  61 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*     */   }
/*     */   
/*     */   public final Ticker expirationTicker() {
/*  65 */     return this.ticker;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque() {
/*  69 */     return this.accessOrderWindowDeque;
/*     */   }
/*     */   
/*     */   protected final boolean expiresVariable() {
/*  73 */     return (this.timerWheel != null);
/*     */   }
/*     */   
/*     */   protected final Expiry<K, V> expiry() {
/*  77 */     return this.expiry;
/*     */   }
/*     */   
/*     */   protected final TimerWheel<K, V> timerWheel() {
/*  81 */     return this.timerWheel;
/*     */   }
/*     */   
/*     */   protected final boolean expiresAfterAccess() {
/*  85 */     return (this.timerWheel == null);
/*     */   }
/*     */   
/*     */   protected final long expiresAfterAccessNanos() {
/*  89 */     return this.expiresAfterAccessNanos;
/*     */   }
/*     */   
/*     */   protected final void setExpiresAfterAccessNanos(long expiresAfterAccessNanos) {
/*  93 */     this.expiresAfterAccessNanos = expiresAfterAccessNanos;
/*     */   }
/*     */   
/*     */   protected final MpscGrowableArrayQueue<Runnable> writeBuffer() {
/*  97 */     return this.writeBuffer;
/*     */   }
/*     */   
/*     */   protected final boolean buffersWrites() {
/* 101 */     return true;
/*     */   }
/*     */   
/*     */   public final Pacer pacer() {
/* 105 */     return this.pacer;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSLSA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */