/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CaffeineSpec
/*     */ {
/*     */   static final String SPLIT_OPTIONS = ",";
/*     */   static final String SPLIT_KEY_VALUE = "=";
/*     */   final String specification;
/*  79 */   int initialCapacity = -1;
/*  80 */   long maximumWeight = -1L;
/*  81 */   long maximumSize = -1L;
/*     */   
/*     */   boolean recordStats;
/*     */   Caffeine.Strength keyStrength;
/*     */   Caffeine.Strength valueStrength;
/*     */   Duration expireAfterWrite;
/*     */   Duration expireAfterAccess;
/*     */   Duration refreshAfterWrite;
/*     */   
/*     */   private CaffeineSpec(String specification) {
/*  91 */     this.specification = Objects.<String>requireNonNull(specification);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Caffeine<Object, Object> toBuilder() {
/* 100 */     Caffeine<Object, Object> builder = Caffeine.newBuilder();
/* 101 */     if (this.initialCapacity != -1) {
/* 102 */       builder.initialCapacity(this.initialCapacity);
/*     */     }
/* 104 */     if (this.maximumSize != -1L) {
/* 105 */       builder.maximumSize(this.maximumSize);
/*     */     }
/* 107 */     if (this.maximumWeight != -1L) {
/* 108 */       builder.maximumWeight(this.maximumWeight);
/*     */     }
/* 110 */     if (this.keyStrength != null) {
/* 111 */       Caffeine.requireState((this.keyStrength == Caffeine.Strength.WEAK));
/* 112 */       builder.weakKeys();
/*     */     } 
/* 114 */     if (this.valueStrength != null) {
/* 115 */       if (this.valueStrength == Caffeine.Strength.WEAK) {
/* 116 */         builder.weakValues();
/* 117 */       } else if (this.valueStrength == Caffeine.Strength.SOFT) {
/* 118 */         builder.softValues();
/*     */       } else {
/* 120 */         throw new IllegalStateException();
/*     */       } 
/*     */     }
/* 123 */     if (this.expireAfterWrite != null) {
/* 124 */       builder.expireAfterWrite(this.expireAfterWrite);
/*     */     }
/* 126 */     if (this.expireAfterAccess != null) {
/* 127 */       builder.expireAfterAccess(this.expireAfterAccess);
/*     */     }
/* 129 */     if (this.refreshAfterWrite != null) {
/* 130 */       builder.refreshAfterWrite(this.refreshAfterWrite);
/*     */     }
/* 132 */     if (this.recordStats) {
/* 133 */       builder.recordStats();
/*     */     }
/* 135 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CaffeineSpec parse(String specification) {
/* 146 */     CaffeineSpec spec = new CaffeineSpec(specification);
/* 147 */     for (String option : specification.split(",")) {
/* 148 */       spec.parseOption(option.trim());
/*     */     }
/* 150 */     return spec;
/*     */   }
/*     */ 
/*     */   
/*     */   void parseOption(String option) {
/* 155 */     if (option.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 160 */     String[] keyAndValue = option.split("=");
/* 161 */     Caffeine.requireArgument((keyAndValue.length <= 2), "key-value pair %s with more than one equals sign", new Object[] { option });
/*     */ 
/*     */     
/* 164 */     String key = keyAndValue[0].trim();
/* 165 */     String value = (keyAndValue.length == 1) ? null : keyAndValue[1].trim();
/*     */     
/* 167 */     configure(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void configure(String key, String value) {
/* 172 */     switch (key) {
/*     */       case "initialCapacity":
/* 174 */         initialCapacity(key, value);
/*     */         return;
/*     */       case "maximumSize":
/* 177 */         maximumSize(key, value);
/*     */         return;
/*     */       case "maximumWeight":
/* 180 */         maximumWeight(key, value);
/*     */         return;
/*     */       case "weakKeys":
/* 183 */         weakKeys(value);
/*     */         return;
/*     */       case "weakValues":
/* 186 */         valueStrength(key, value, Caffeine.Strength.WEAK);
/*     */         return;
/*     */       case "softValues":
/* 189 */         valueStrength(key, value, Caffeine.Strength.SOFT);
/*     */         return;
/*     */       case "expireAfterAccess":
/* 192 */         expireAfterAccess(key, value);
/*     */         return;
/*     */       case "expireAfterWrite":
/* 195 */         expireAfterWrite(key, value);
/*     */         return;
/*     */       case "refreshAfterWrite":
/* 198 */         refreshAfterWrite(key, value);
/*     */         return;
/*     */       case "recordStats":
/* 201 */         recordStats(value);
/*     */         return;
/*     */     } 
/* 204 */     throw new IllegalArgumentException("Unknown key " + key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void initialCapacity(String key, String value) {
/* 210 */     Caffeine.requireArgument((this.initialCapacity == -1), "initial capacity was already set to %,d", new Object[] {
/* 211 */           Integer.valueOf(this.initialCapacity) });
/* 212 */     this.initialCapacity = parseInt(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void maximumSize(String key, String value) {
/* 217 */     Caffeine.requireArgument((this.maximumSize == -1L), "maximum size was already set to %,d", new Object[] {
/* 218 */           Long.valueOf(this.maximumSize) });
/* 219 */     Caffeine.requireArgument((this.maximumWeight == -1L), "maximum weight was already set to %,d", new Object[] {
/* 220 */           Long.valueOf(this.maximumWeight) });
/* 221 */     this.maximumSize = parseLong(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void maximumWeight(String key, String value) {
/* 226 */     Caffeine.requireArgument((this.maximumWeight == -1L), "maximum weight was already set to %,d", new Object[] {
/* 227 */           Long.valueOf(this.maximumWeight) });
/* 228 */     Caffeine.requireArgument((this.maximumSize == -1L), "maximum size was already set to %,d", new Object[] {
/* 229 */           Long.valueOf(this.maximumSize) });
/* 230 */     this.maximumWeight = parseLong(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void weakKeys(String value) {
/* 235 */     Caffeine.requireArgument((value == null), "weak keys does not take a value", new Object[0]);
/* 236 */     Caffeine.requireArgument((this.keyStrength == null), "weak keys was already set", new Object[0]);
/* 237 */     this.keyStrength = Caffeine.Strength.WEAK;
/*     */   }
/*     */ 
/*     */   
/*     */   void valueStrength(String key, String value, Caffeine.Strength strength) {
/* 242 */     Caffeine.requireArgument((value == null), "%s does not take a value", new Object[] { key });
/* 243 */     Caffeine.requireArgument((this.valueStrength == null), "%s was already set to %s", new Object[] { key, this.valueStrength });
/* 244 */     this.valueStrength = strength;
/*     */   }
/*     */ 
/*     */   
/*     */   void expireAfterAccess(String key, String value) {
/* 249 */     Caffeine.requireArgument((this.expireAfterAccess == null), "expireAfterAccess was already set", new Object[0]);
/* 250 */     this.expireAfterAccess = parseDuration(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void expireAfterWrite(String key, String value) {
/* 255 */     Caffeine.requireArgument((this.expireAfterWrite == null), "expireAfterWrite was already set", new Object[0]);
/* 256 */     this.expireAfterWrite = parseDuration(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void refreshAfterWrite(String key, String value) {
/* 261 */     Caffeine.requireArgument((this.refreshAfterWrite == null), "refreshAfterWrite was already set", new Object[0]);
/* 262 */     this.refreshAfterWrite = parseDuration(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void recordStats(String value) {
/* 267 */     Caffeine.requireArgument((value == null), "record stats does not take a value", new Object[0]);
/* 268 */     Caffeine.requireArgument(!this.recordStats, "record stats was already set", new Object[0]);
/* 269 */     this.recordStats = true;
/*     */   }
/*     */ 
/*     */   
/*     */   static int parseInt(String key, String value) {
/* 274 */     Caffeine.requireArgument((value != null && !value.isEmpty()), "value of key %s was omitted", new Object[] { key });
/*     */     try {
/* 276 */       return Integer.parseInt(value);
/* 277 */     } catch (NumberFormatException e) {
/* 278 */       throw new IllegalArgumentException(String.format("key %s value was set to %s, must be an integer", new Object[] { key, value }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static long parseLong(String key, String value) {
/* 285 */     Caffeine.requireArgument((value != null && !value.isEmpty()), "value of key %s was omitted", new Object[] { key });
/*     */     try {
/* 287 */       return Long.parseLong(value);
/* 288 */     } catch (NumberFormatException e) {
/* 289 */       throw new IllegalArgumentException(String.format("key %s value was set to %s, must be a long", new Object[] { key, value }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Duration parseDuration(String key, String value) {
/* 296 */     Caffeine.requireArgument((value != null && !value.isEmpty()), "value of key %s omitted", new Object[] { key });
/*     */ 
/*     */     
/* 299 */     boolean isIsoFormat = (value.contains("p") || value.contains("P"));
/* 300 */     if (isIsoFormat) {
/* 301 */       Duration duration1 = Duration.parse(value);
/* 302 */       Caffeine.requireArgument(!duration1.isNegative(), "key %s invalid format; was %s, but the duration cannot be negative", new Object[] { key, value });
/*     */       
/* 304 */       return duration1;
/*     */     } 
/*     */ 
/*     */     
/* 308 */     long duration = parseLong(key, value.substring(0, value.length() - 1));
/* 309 */     TimeUnit unit = parseTimeUnit(key, value);
/* 310 */     return Duration.ofNanos(unit.toNanos(duration));
/*     */   }
/*     */ 
/*     */   
/*     */   static TimeUnit parseTimeUnit(String key, String value) {
/* 315 */     Caffeine.requireArgument((value != null && !value.isEmpty()), "value of key %s omitted", new Object[] { key });
/*     */     
/* 317 */     char lastChar = Character.toLowerCase(value.charAt(value.length() - 1));
/* 318 */     switch (lastChar) {
/*     */       case 'd':
/* 320 */         return TimeUnit.DAYS;
/*     */       case 'h':
/* 322 */         return TimeUnit.HOURS;
/*     */       case 'm':
/* 324 */         return TimeUnit.MINUTES;
/*     */       case 's':
/* 326 */         return TimeUnit.SECONDS;
/*     */     } 
/* 328 */     throw new IllegalArgumentException(String.format("key %s invalid format; was %s, must end with one of [dDhHmMsS]", new Object[] { key, value }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 335 */     if (this == o)
/* 336 */       return true; 
/* 337 */     if (!(o instanceof CaffeineSpec)) {
/* 338 */       return false;
/*     */     }
/* 340 */     CaffeineSpec spec = (CaffeineSpec)o;
/* 341 */     return (Objects.equals(Integer.valueOf(this.initialCapacity), Integer.valueOf(spec.initialCapacity)) && 
/* 342 */       Objects.equals(Long.valueOf(this.maximumSize), Long.valueOf(spec.maximumSize)) && 
/* 343 */       Objects.equals(Long.valueOf(this.maximumWeight), Long.valueOf(spec.maximumWeight)) && 
/* 344 */       Objects.equals(this.keyStrength, spec.keyStrength) && 
/* 345 */       Objects.equals(this.valueStrength, spec.valueStrength) && 
/* 346 */       Objects.equals(Boolean.valueOf(this.recordStats), Boolean.valueOf(spec.recordStats)) && 
/* 347 */       Objects.equals(this.expireAfterWrite, spec.expireAfterWrite) && 
/* 348 */       Objects.equals(this.expireAfterAccess, spec.expireAfterAccess) && 
/* 349 */       Objects.equals(this.refreshAfterWrite, spec.refreshAfterWrite));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 354 */     return Objects.hash(new Object[] {
/* 355 */           Integer.valueOf(this.initialCapacity), Long.valueOf(this.maximumSize), Long.valueOf(this.maximumWeight), this.keyStrength, this.valueStrength, 
/* 356 */           Boolean.valueOf(this.recordStats), this.expireAfterWrite, this.expireAfterAccess, this.refreshAfterWrite
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toParsableString() {
/* 367 */     return this.specification;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 376 */     return getClass().getSimpleName() + '{' + toParsableString() + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\CaffeineSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */