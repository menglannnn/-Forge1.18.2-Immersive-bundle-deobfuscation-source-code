/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WILMSW<K, V>
/*    */   extends WILMS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   final WriteOrderDeque<Node<K, V>> writeOrderDeque;
/*    */   volatile long expiresAfterWriteNanos;
/*    */   final Pacer pacer;
/*    */   
/*    */   WILMSW(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 42 */     super(builder, cacheLoader, async);
/* 43 */     this.ticker = builder.getTicker();
/* 44 */     this.writeOrderDeque = new WriteOrderDeque<>();
/* 45 */     this.expiresAfterWriteNanos = builder.getExpiresAfterWriteNanos();
/* 46 */     this
/*    */ 
/*    */       
/* 49 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*    */   }
/*    */   
/*    */   public final Ticker expirationTicker() {
/* 53 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected final WriteOrderDeque<Node<K, V>> writeOrderDeque() {
/* 57 */     return this.writeOrderDeque;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterWrite() {
/* 61 */     return true;
/*    */   }
/*    */   
/*    */   protected final long expiresAfterWriteNanos() {
/* 65 */     return this.expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterWriteNanos(long expiresAfterWriteNanos) {
/* 69 */     this.expiresAfterWriteNanos = expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   public final Pacer pacer() {
/* 73 */     return this.pacer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\WILMSW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */