/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BoundedBuffer<E>
/*     */   extends StripedBuffer<E>
/*     */ {
/*     */   static final int BUFFER_SIZE = 16;
/*     */   static final int MASK = 15;
/*     */   
/*     */   protected Buffer<E> create(E e) {
/*  53 */     return new RingBuffer<>(e);
/*     */   }
/*     */   
/*     */   static final class RingBuffer<E>
/*     */     extends BBHeader.ReadAndWriteCounterRef implements Buffer<E> {
/*     */     final AtomicReferenceArray<E> buffer;
/*     */     
/*     */     public RingBuffer(E e) {
/*  61 */       this.buffer = new AtomicReferenceArray<>(16);
/*  62 */       this.buffer.lazySet(0, e);
/*     */     }
/*     */ 
/*     */     
/*     */     public int offer(E e) {
/*  67 */       long head = this.readCounter;
/*  68 */       long tail = relaxedWriteCounter();
/*  69 */       long size = tail - head;
/*  70 */       if (size >= 16L) {
/*  71 */         return 1;
/*     */       }
/*  73 */       if (casWriteCounter(tail, tail + 1L)) {
/*  74 */         int index = (int)(tail & 0xFL);
/*  75 */         this.buffer.lazySet(index, e);
/*  76 */         return 0;
/*     */       } 
/*  78 */       return -1;
/*     */     }
/*     */ 
/*     */     
/*     */     public void drainTo(Consumer<E> consumer) {
/*  83 */       long head = this.readCounter;
/*  84 */       long tail = relaxedWriteCounter();
/*  85 */       long size = tail - head;
/*  86 */       if (size == 0L) {
/*     */         return;
/*     */       }
/*     */       do {
/*  90 */         int index = (int)(head & 0xFL);
/*  91 */         E e = this.buffer.get(index);
/*  92 */         if (e == null) {
/*     */           break;
/*     */         }
/*     */         
/*  96 */         this.buffer.lazySet(index, null);
/*  97 */         consumer.accept(e);
/*  98 */         head++;
/*  99 */       } while (head != tail);
/* 100 */       lazySetReadCounter(head);
/*     */     }
/*     */ 
/*     */     
/*     */     public int reads() {
/* 105 */       return (int)this.readCounter;
/*     */     }
/*     */ 
/*     */     
/*     */     public int writes() {
/* 110 */       return (int)this.writeCounter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\BoundedBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */