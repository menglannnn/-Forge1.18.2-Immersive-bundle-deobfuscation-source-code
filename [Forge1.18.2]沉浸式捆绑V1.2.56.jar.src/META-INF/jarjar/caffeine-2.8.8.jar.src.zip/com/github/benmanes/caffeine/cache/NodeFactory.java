/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface NodeFactory<K, V>
/*     */ {
/*  27 */   public static final Object RETIRED_STRONG_KEY = new Object();
/*     */   
/*  29 */   public static final Object DEAD_STRONG_KEY = new Object();
/*     */   
/*  31 */   public static final References.WeakKeyReference<Object> RETIRED_WEAK_KEY = new References.WeakKeyReference(null, null);
/*     */   
/*  33 */   public static final References.WeakKeyReference<Object> DEAD_WEAK_KEY = new References.WeakKeyReference(null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Node<K, V> newNode(K paramK, ReferenceQueue<K> paramReferenceQueue, V paramV, ReferenceQueue<V> paramReferenceQueue1, int paramInt, long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Node<K, V> newNode(Object paramObject, V paramV, ReferenceQueue<V> paramReferenceQueue, int paramInt, long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Object newReferenceKey(K key, ReferenceQueue<K> referenceQueue) {
/*  54 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Object newLookupKey(Object key) {
/*  64 */     return key;
/*     */   }
/*     */ 
/*     */   
/*     */   static <K, V> NodeFactory<K, V> newFactory(Caffeine<K, V> builder, boolean isAsync) {
/*  69 */     StringBuilder sb = new StringBuilder("com.github.benmanes.caffeine.cache.");
/*  70 */     if (builder.isStrongKeys()) {
/*  71 */       sb.append('P');
/*     */     } else {
/*  73 */       sb.append('F');
/*     */     } 
/*  75 */     if (builder.isStrongValues()) {
/*  76 */       sb.append('S');
/*  77 */     } else if (builder.isWeakValues()) {
/*  78 */       sb.append('W');
/*     */     } else {
/*  80 */       sb.append('D');
/*     */     } 
/*  82 */     if (builder.expiresVariable()) {
/*  83 */       if (builder.refreshAfterWrite()) {
/*  84 */         sb.append('A');
/*  85 */         if (builder.evicts()) {
/*  86 */           sb.append('W');
/*     */         }
/*     */       } else {
/*  89 */         sb.append('W');
/*     */       } 
/*     */     } else {
/*  92 */       if (builder.expiresAfterAccess()) {
/*  93 */         sb.append('A');
/*     */       }
/*  95 */       if (builder.expiresAfterWrite()) {
/*  96 */         sb.append('W');
/*     */       }
/*     */     } 
/*  99 */     if (builder.refreshAfterWrite()) {
/* 100 */       sb.append('R');
/*     */     }
/* 102 */     if (builder.evicts()) {
/* 103 */       sb.append('M');
/* 104 */       if (isAsync || (builder.isWeighted() && builder.weigher != Weigher.singletonWeigher())) {
/* 105 */         sb.append('W');
/*     */       } else {
/* 107 */         sb.append('S');
/*     */       } 
/*     */     } 
/*     */     try {
/* 111 */       Class<?> clazz = Class.forName(sb.toString());
/*     */       
/* 113 */       NodeFactory<K, V> factory = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/* 114 */       return factory;
/* 115 */     } catch (ReflectiveOperationException e) {
/* 116 */       throw new IllegalStateException(sb.toString(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   default boolean weakValues() {
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   default boolean softValues() {
/* 127 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\NodeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */