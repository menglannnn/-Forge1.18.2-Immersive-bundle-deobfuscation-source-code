/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PDAWR<K, V>
/*    */   extends PDAW<K, V>
/*    */ {
/*    */   PDAWR() {}
/*    */   
/*    */   PDAWR(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 44 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   PDAWR(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 48 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   public Node<K, V> getPreviousInVariableOrder() {
/* 52 */     return this.previousInWriteOrder;
/*    */   }
/*    */   
/*    */   public void setPreviousInVariableOrder(Node<K, V> previousInWriteOrder) {
/* 56 */     this.previousInWriteOrder = previousInWriteOrder;
/*    */   }
/*    */   
/*    */   public Node<K, V> getNextInVariableOrder() {
/* 60 */     return this.nextInWriteOrder;
/*    */   }
/*    */   
/*    */   public void setNextInVariableOrder(Node<K, V> nextInWriteOrder) {
/* 64 */     this.nextInWriteOrder = nextInWriteOrder;
/*    */   }
/*    */   
/*    */   public long getVariableTime() {
/* 68 */     return UnsafeAccess.UNSAFE.getLong(this, ACCESS_TIME_OFFSET);
/*    */   }
/*    */   
/*    */   public void setVariableTime(long accessTime) {
/* 72 */     UnsafeAccess.UNSAFE.putLong(this, ACCESS_TIME_OFFSET, accessTime);
/*    */   }
/*    */   
/*    */   public boolean casVariableTime(long expect, long update) {
/* 76 */     return (this.accessTime == expect && UnsafeAccess.UNSAFE
/* 77 */       .compareAndSwapLong(this, ACCESS_TIME_OFFSET, expect, update));
/*    */   }
/*    */   
/*    */   public final boolean casWriteTime(long expect, long update) {
/* 81 */     return (this.writeTime == expect && UnsafeAccess.UNSAFE
/* 82 */       .compareAndSwapLong(this, WRITE_TIME_OFFSET, expect, update));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 92 */     return new PDAWR(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 97 */     return new PDAWR(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PDAWR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */