/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSLA<K, V>
/*     */   extends SSL<K, V>
/*     */ {
/*     */   final Ticker ticker;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque;
/*     */   final Expiry<K, V> expiry;
/*     */   final TimerWheel<K, V> timerWheel;
/*     */   volatile long expiresAfterAccessNanos;
/*     */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*     */   final Pacer pacer;
/*     */   
/*     */   SSLA(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/*  47 */     super(builder, cacheLoader, async);
/*  48 */     this.ticker = builder.getTicker();
/*  49 */     this
/*     */ 
/*     */       
/*  52 */       .accessOrderWindowDeque = (builder.evicts() || builder.expiresAfterAccess()) ? new AccessOrderDeque<>() : null;
/*  53 */     this.expiry = builder.getExpiry(this.isAsync);
/*  54 */     this.timerWheel = builder.expiresVariable() ? new TimerWheel<>(this) : null;
/*  55 */     this.expiresAfterAccessNanos = builder.getExpiresAfterAccessNanos();
/*  56 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*  57 */     this
/*     */ 
/*     */       
/*  60 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*     */   }
/*     */   
/*     */   public final Ticker expirationTicker() {
/*  64 */     return this.ticker;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque() {
/*  68 */     return this.accessOrderWindowDeque;
/*     */   }
/*     */   
/*     */   protected final boolean expiresVariable() {
/*  72 */     return (this.timerWheel != null);
/*     */   }
/*     */   
/*     */   protected final Expiry<K, V> expiry() {
/*  76 */     return this.expiry;
/*     */   }
/*     */   
/*     */   protected final TimerWheel<K, V> timerWheel() {
/*  80 */     return this.timerWheel;
/*     */   }
/*     */   
/*     */   protected final boolean expiresAfterAccess() {
/*  84 */     return (this.timerWheel == null);
/*     */   }
/*     */   
/*     */   protected final long expiresAfterAccessNanos() {
/*  88 */     return this.expiresAfterAccessNanos;
/*     */   }
/*     */   
/*     */   protected final void setExpiresAfterAccessNanos(long expiresAfterAccessNanos) {
/*  92 */     this.expiresAfterAccessNanos = expiresAfterAccessNanos;
/*     */   }
/*     */   
/*     */   protected final MpscGrowableArrayQueue<Runnable> writeBuffer() {
/*  96 */     return this.writeBuffer;
/*     */   }
/*     */   
/*     */   protected final boolean buffersWrites() {
/* 100 */     return true;
/*     */   }
/*     */   
/*     */   public final Pacer pacer() {
/* 104 */     return this.pacer;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSLA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */