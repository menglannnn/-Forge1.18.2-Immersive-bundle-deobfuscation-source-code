/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SI<K, V>
/*    */   extends BoundedLocalCache<K, V>
/*    */ {
/* 32 */   final ReferenceQueue<V> valueReferenceQueue = new ReferenceQueue<>();
/*    */   
/*    */   SI(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 35 */     super(builder, (CacheLoader)cacheLoader, async);
/*    */   }
/*    */   
/*    */   protected final ReferenceQueue<V> valueReferenceQueue() {
/* 39 */     return this.valueReferenceQueue;
/*    */   }
/*    */   
/*    */   protected final boolean collectValues() {
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */