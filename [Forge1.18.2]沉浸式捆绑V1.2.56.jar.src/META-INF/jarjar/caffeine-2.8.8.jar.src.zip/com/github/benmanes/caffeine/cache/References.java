/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class References
/*     */ {
/*     */   static interface InternalReference<E>
/*     */   {
/*     */     E get();
/*     */     
/*     */     Object getKeyReference();
/*     */     
/*     */     default boolean referenceEquals(Object object) {
/*  68 */       if (object == this)
/*  69 */         return true; 
/*  70 */       if (object instanceof InternalReference) {
/*  71 */         InternalReference<?> referent = (InternalReference)object;
/*  72 */         return (get() == referent.get());
/*     */       } 
/*  74 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class LookupKeyReference<E>
/*     */     implements InternalReference<E>
/*     */   {
/*     */     private final int hashCode;
/*     */     
/*     */     private final E e;
/*     */ 
/*     */     
/*     */     public LookupKeyReference(E e) {
/*  88 */       this.hashCode = System.identityHashCode(e);
/*  89 */       this.e = Objects.requireNonNull(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public E get() {
/*  94 */       return this.e;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getKeyReference() {
/*  99 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object object) {
/* 104 */       return referenceEquals(object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 109 */       return this.hashCode;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class WeakKeyReference<K>
/*     */     extends WeakReference<K>
/*     */     implements InternalReference<K>
/*     */   {
/*     */     private final int hashCode;
/*     */ 
/*     */     
/*     */     public WeakKeyReference(K key, ReferenceQueue<K> queue) {
/* 122 */       super(key, queue);
/* 123 */       this.hashCode = System.identityHashCode(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getKeyReference() {
/* 128 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object object) {
/* 133 */       return referenceEquals(object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 138 */       return this.hashCode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class WeakValueReference<V>
/*     */     extends WeakReference<V>
/*     */     implements InternalReference<V>
/*     */   {
/*     */     private final Object keyReference;
/*     */ 
/*     */ 
/*     */     
/*     */     public WeakValueReference(Object keyReference, V value, ReferenceQueue<V> queue) {
/* 153 */       super(value, queue);
/* 154 */       this.keyReference = keyReference;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getKeyReference() {
/* 159 */       return this.keyReference;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object object) {
/* 164 */       return referenceEquals(object);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 170 */       return super.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class SoftValueReference<V>
/*     */     extends SoftReference<V>
/*     */     implements InternalReference<V>
/*     */   {
/*     */     private final Object keyReference;
/*     */ 
/*     */ 
/*     */     
/*     */     public SoftValueReference(Object keyReference, V value, ReferenceQueue<V> queue) {
/* 185 */       super(value, queue);
/* 186 */       this.keyReference = keyReference;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getKeyReference() {
/* 191 */       return this.keyReference;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object object) {
/* 196 */       return referenceEquals(object);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 202 */       return super.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\References.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */