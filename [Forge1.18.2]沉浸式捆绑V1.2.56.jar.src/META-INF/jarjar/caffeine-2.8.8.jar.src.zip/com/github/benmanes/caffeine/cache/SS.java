/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SS<K, V>
/*    */   extends BoundedLocalCache<K, V>
/*    */ {
/*    */   SS(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 31 */     super(builder, (CacheLoader)cacheLoader, async);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */