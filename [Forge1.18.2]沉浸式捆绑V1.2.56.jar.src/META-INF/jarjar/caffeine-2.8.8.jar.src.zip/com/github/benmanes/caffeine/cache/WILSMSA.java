/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WILSMSA<K, V>
/*    */   extends WILSMS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   final Expiry<K, V> expiry;
/*    */   final TimerWheel<K, V> timerWheel;
/*    */   volatile long expiresAfterAccessNanos;
/*    */   final Pacer pacer;
/*    */   
/*    */   WILSMSA(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 45 */     super(builder, cacheLoader, async);
/* 46 */     this.ticker = builder.getTicker();
/* 47 */     this.expiry = builder.getExpiry(this.isAsync);
/* 48 */     this.timerWheel = builder.expiresVariable() ? new TimerWheel<>(this) : null;
/* 49 */     this.expiresAfterAccessNanos = builder.getExpiresAfterAccessNanos();
/* 50 */     this
/*    */ 
/*    */       
/* 53 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*    */   }
/*    */   
/*    */   public final Ticker expirationTicker() {
/* 57 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected final boolean expiresVariable() {
/* 61 */     return (this.timerWheel != null);
/*    */   }
/*    */   
/*    */   protected final Expiry<K, V> expiry() {
/* 65 */     return this.expiry;
/*    */   }
/*    */   
/*    */   protected final TimerWheel<K, V> timerWheel() {
/* 69 */     return this.timerWheel;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterAccess() {
/* 73 */     return (this.timerWheel == null);
/*    */   }
/*    */   
/*    */   protected final long expiresAfterAccessNanos() {
/* 77 */     return this.expiresAfterAccessNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterAccessNanos(long expiresAfterAccessNanos) {
/* 81 */     this.expiresAfterAccessNanos = expiresAfterAccessNanos;
/*    */   }
/*    */   
/*    */   public final Pacer pacer() {
/* 85 */     return this.pacer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\WILSMSA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */