/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import com.github.benmanes.caffeine.cache.stats.StatsCounter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SSS<K, V>
/*    */   extends SS<K, V>
/*    */ {
/*    */   final StatsCounter statsCounter;
/*    */   
/*    */   SSS(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 36 */     super(builder, cacheLoader, async);
/* 37 */     this.statsCounter = builder.getStatsCounterSupplier().get();
/*    */   }
/*    */   
/*    */   public final boolean isRecordingStats() {
/* 41 */     return true;
/*    */   }
/*    */   
/*    */   public final Ticker statsTicker() {
/* 45 */     return Ticker.systemTicker();
/*    */   }
/*    */   
/*    */   public final StatsCounter statsCounter() {
/* 49 */     return this.statsCounter;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */