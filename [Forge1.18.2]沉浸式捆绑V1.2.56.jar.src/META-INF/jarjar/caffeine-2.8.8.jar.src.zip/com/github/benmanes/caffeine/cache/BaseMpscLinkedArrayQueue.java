/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseMpscLinkedArrayQueue<E>
/*     */   extends BaseMpscLinkedArrayQueueColdProducerFields<E>
/*     */ {
/*     */   private static final long P_INDEX_OFFSET;
/*     */   private static final long C_INDEX_OFFSET;
/*     */   private static final long P_LIMIT_OFFSET;
/*     */   
/*     */   static {
/*     */     try {
/* 211 */       Field iField = BaseMpscLinkedArrayQueueProducerFields.class.getDeclaredField("producerIndex");
/* 212 */       P_INDEX_OFFSET = UnsafeAccess.UNSAFE.objectFieldOffset(iField);
/* 213 */     } catch (NoSuchFieldException e) {
/* 214 */       throw new RuntimeException(e);
/*     */     } 
/*     */     try {
/* 217 */       Field iField = BaseMpscLinkedArrayQueueConsumerFields.class.getDeclaredField("consumerIndex");
/* 218 */       C_INDEX_OFFSET = UnsafeAccess.UNSAFE.objectFieldOffset(iField);
/* 219 */     } catch (NoSuchFieldException e) {
/* 220 */       throw new RuntimeException(e);
/*     */     } 
/*     */     
/*     */     try {
/* 224 */       Field iField = BaseMpscLinkedArrayQueueColdProducerFields.class.getDeclaredField("producerLimit");
/* 225 */       P_LIMIT_OFFSET = UnsafeAccess.UNSAFE.objectFieldOffset(iField);
/* 226 */     } catch (NoSuchFieldException e) {
/* 227 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/* 231 */   private static final Object JUMP = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BaseMpscLinkedArrayQueue(int initialCapacity) {
/* 238 */     if (initialCapacity < 2) {
/* 239 */       throw new IllegalArgumentException("Initial capacity must be 2 or more");
/*     */     }
/*     */     
/* 242 */     int p2capacity = Caffeine.ceilingPowerOfTwo(initialCapacity);
/*     */     
/* 244 */     long mask = p2capacity - 1L << 1L;
/*     */     
/* 246 */     E[] buffer = allocate(p2capacity + 1);
/* 247 */     this.producerBuffer = buffer;
/* 248 */     this.producerMask = mask;
/* 249 */     this.consumerBuffer = buffer;
/* 250 */     this.consumerMask = mask;
/* 251 */     soProducerLimit(mask);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Iterator<E> iterator() {
/* 256 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 261 */     return getClass().getName() + "@" + Integer.toHexString(hashCode());
/*     */   }
/*     */   public boolean offer(E e) {
/*     */     long mask;
/*     */     E[] buffer;
/*     */     long pIndex;
/* 267 */     if (null == e) {
/* 268 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 276 */       long producerLimit = lvProducerLimit();
/* 277 */       pIndex = lvProducerIndex();
/*     */       
/* 279 */       if ((pIndex & 0x1L) == 1L) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 285 */       mask = this.producerMask;
/* 286 */       buffer = this.producerBuffer;
/*     */ 
/*     */ 
/*     */       
/* 290 */       if (producerLimit <= pIndex) {
/* 291 */         int result = offerSlowPath(mask, pIndex, producerLimit);
/* 292 */         switch (result) {
/*     */           case 1:
/*     */             continue;
/*     */ 
/*     */           
/*     */           case 2:
/* 298 */             return false;
/*     */           case 3:
/* 300 */             resize(mask, buffer, pIndex, e);
/* 301 */             return true;
/*     */         } 
/*     */       
/*     */       } 
/* 305 */       if (casProducerIndex(pIndex, pIndex + 2L)) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 310 */     long offset = modifiedCalcElementOffset(pIndex, mask);
/* 311 */     UnsafeRefArrayAccess.soElement(buffer, offset, e);
/* 312 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int offerSlowPath(long mask, long pIndex, long producerLimit) {
/* 320 */     long cIndex = lvConsumerIndex();
/* 321 */     long bufferCapacity = getCurrentBufferCapacity(mask);
/* 322 */     int result = 0;
/* 323 */     if (cIndex + bufferCapacity > pIndex) {
/* 324 */       if (!casProducerLimit(producerLimit, cIndex + bufferCapacity)) {
/* 325 */         result = 1;
/*     */       
/*     */       }
/*     */     }
/* 329 */     else if (availableInQueue(pIndex, cIndex) <= 0L) {
/* 330 */       result = 2;
/*     */     
/*     */     }
/* 333 */     else if (casProducerIndex(pIndex, pIndex + 1L)) {
/* 334 */       result = 3;
/*     */     } else {
/* 336 */       result = 1;
/*     */     } 
/* 338 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long modifiedCalcElementOffset(long index, long mask) {
/* 352 */     return UnsafeRefArrayAccess.REF_ARRAY_BASE + ((index & mask) << UnsafeRefArrayAccess.REF_ELEMENT_SHIFT - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E poll() {
/* 363 */     E[] buffer = this.consumerBuffer;
/* 364 */     long index = this.consumerIndex;
/* 365 */     long mask = this.consumerMask;
/*     */     
/* 367 */     long offset = modifiedCalcElementOffset(index, mask);
/* 368 */     Object e = UnsafeRefArrayAccess.lvElement(buffer, offset);
/* 369 */     if (e == null) {
/* 370 */       if (index != lvProducerIndex()) {
/*     */ 
/*     */         
/*     */         do {
/*     */ 
/*     */           
/* 376 */           e = UnsafeRefArrayAccess.lvElement(buffer, offset);
/* 377 */         } while (e == null);
/*     */       } else {
/* 379 */         return null;
/*     */       } 
/*     */     }
/* 382 */     if (e == JUMP) {
/* 383 */       E[] nextBuffer = getNextBuffer(buffer, mask);
/* 384 */       return newBufferPoll(nextBuffer, index);
/*     */     } 
/* 386 */     UnsafeRefArrayAccess.soElement(buffer, offset, null);
/* 387 */     soConsumerIndex(index + 2L);
/* 388 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E peek() {
/* 399 */     E[] buffer = this.consumerBuffer;
/* 400 */     long index = this.consumerIndex;
/* 401 */     long mask = this.consumerMask;
/*     */     
/* 403 */     long offset = modifiedCalcElementOffset(index, mask);
/* 404 */     Object e = UnsafeRefArrayAccess.lvElement(buffer, offset);
/* 405 */     if (e == null && index != lvProducerIndex())
/*     */     {
/*     */ 
/*     */       
/* 409 */       while ((e = UnsafeRefArrayAccess.<E>lvElement(buffer, offset)) == null);
/*     */     }
/*     */ 
/*     */     
/* 413 */     if (e == JUMP) {
/* 414 */       return newBufferPeek(getNextBuffer(buffer, mask), index);
/*     */     }
/* 416 */     return (E)e;
/*     */   }
/*     */ 
/*     */   
/*     */   private E[] getNextBuffer(E[] buffer, long mask) {
/* 421 */     long nextArrayOffset = nextArrayOffset(mask);
/* 422 */     E[] nextBuffer = (E[])UnsafeRefArrayAccess.<Object[]>lvElement((Object[][])buffer, nextArrayOffset);
/* 423 */     UnsafeRefArrayAccess.soElement(buffer, nextArrayOffset, null);
/* 424 */     return nextBuffer;
/*     */   }
/*     */   
/*     */   private static long nextArrayOffset(long mask) {
/* 428 */     return modifiedCalcElementOffset(mask + 2L, Long.MAX_VALUE);
/*     */   }
/*     */   
/*     */   private E newBufferPoll(E[] nextBuffer, long index) {
/* 432 */     long offsetInNew = newBufferAndOffset(nextBuffer, index);
/* 433 */     E n = UnsafeRefArrayAccess.lvElement(nextBuffer, offsetInNew);
/* 434 */     if (n == null) {
/* 435 */       throw new IllegalStateException("new buffer must have at least one element");
/*     */     }
/* 437 */     UnsafeRefArrayAccess.soElement(nextBuffer, offsetInNew, null);
/* 438 */     soConsumerIndex(index + 2L);
/* 439 */     return n;
/*     */   }
/*     */   
/*     */   private E newBufferPeek(E[] nextBuffer, long index) {
/* 443 */     long offsetInNew = newBufferAndOffset(nextBuffer, index);
/* 444 */     E n = UnsafeRefArrayAccess.lvElement(nextBuffer, offsetInNew);
/* 445 */     if (null == n) {
/* 446 */       throw new IllegalStateException("new buffer must have at least one element");
/*     */     }
/* 448 */     return n;
/*     */   }
/*     */   
/*     */   private long newBufferAndOffset(E[] nextBuffer, long index) {
/* 452 */     this.consumerBuffer = nextBuffer;
/* 453 */     this.consumerMask = nextBuffer.length - 2L << 1L;
/* 454 */     long offsetInNew = modifiedCalcElementOffset(index, this.consumerMask);
/* 455 */     return offsetInNew;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int size() {
/* 468 */     long after = lvConsumerIndex();
/*     */     
/*     */     while (true) {
/* 471 */       long before = after;
/* 472 */       long currentProducerIndex = lvProducerIndex();
/* 473 */       after = lvConsumerIndex();
/* 474 */       if (before == after) {
/* 475 */         long size = currentProducerIndex - after >> 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 482 */         if (size > 2147483647L) {
/* 483 */           return Integer.MAX_VALUE;
/*     */         }
/* 485 */         return (int)size;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEmpty() {
/* 496 */     return (lvConsumerIndex() == lvProducerIndex());
/*     */   }
/*     */   
/*     */   private long lvProducerIndex() {
/* 500 */     return UnsafeAccess.UNSAFE.getLongVolatile(this, P_INDEX_OFFSET);
/*     */   }
/*     */   
/*     */   private long lvConsumerIndex() {
/* 504 */     return UnsafeAccess.UNSAFE.getLongVolatile(this, C_INDEX_OFFSET);
/*     */   }
/*     */   
/*     */   private void soProducerIndex(long v) {
/* 508 */     UnsafeAccess.UNSAFE.putOrderedLong(this, P_INDEX_OFFSET, v);
/*     */   }
/*     */   
/*     */   private boolean casProducerIndex(long expect, long newValue) {
/* 512 */     return UnsafeAccess.UNSAFE.compareAndSwapLong(this, P_INDEX_OFFSET, expect, newValue);
/*     */   }
/*     */   
/*     */   private void soConsumerIndex(long v) {
/* 516 */     UnsafeAccess.UNSAFE.putOrderedLong(this, C_INDEX_OFFSET, v);
/*     */   }
/*     */   
/*     */   private long lvProducerLimit() {
/* 520 */     return this.producerLimit;
/*     */   }
/*     */   
/*     */   private boolean casProducerLimit(long expect, long newValue) {
/* 524 */     return UnsafeAccess.UNSAFE.compareAndSwapLong(this, P_LIMIT_OFFSET, expect, newValue);
/*     */   }
/*     */   
/*     */   private void soProducerLimit(long v) {
/* 528 */     UnsafeAccess.UNSAFE.putOrderedLong(this, P_LIMIT_OFFSET, v);
/*     */   }
/*     */   
/*     */   public long currentProducerIndex() {
/* 532 */     return lvProducerIndex() / 2L;
/*     */   }
/*     */   
/*     */   public long currentConsumerIndex() {
/* 536 */     return lvConsumerIndex() / 2L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean relaxedOffer(E e) {
/* 542 */     return offer(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public E relaxedPoll() {
/* 547 */     E[] buffer = this.consumerBuffer;
/* 548 */     long index = this.consumerIndex;
/* 549 */     long mask = this.consumerMask;
/*     */     
/* 551 */     long offset = modifiedCalcElementOffset(index, mask);
/* 552 */     Object e = UnsafeRefArrayAccess.lvElement(buffer, offset);
/* 553 */     if (e == null) {
/* 554 */       return null;
/*     */     }
/* 556 */     if (e == JUMP) {
/* 557 */       E[] nextBuffer = getNextBuffer(buffer, mask);
/* 558 */       return newBufferPoll(nextBuffer, index);
/*     */     } 
/* 560 */     UnsafeRefArrayAccess.soElement(buffer, offset, null);
/* 561 */     soConsumerIndex(index + 2L);
/* 562 */     return (E)e;
/*     */   }
/*     */ 
/*     */   
/*     */   public E relaxedPeek() {
/* 567 */     E[] buffer = this.consumerBuffer;
/* 568 */     long index = this.consumerIndex;
/* 569 */     long mask = this.consumerMask;
/*     */     
/* 571 */     long offset = modifiedCalcElementOffset(index, mask);
/* 572 */     Object e = UnsafeRefArrayAccess.lvElement(buffer, offset);
/* 573 */     if (e == JUMP) {
/* 574 */       return newBufferPeek(getNextBuffer(buffer, mask), index);
/*     */     }
/* 576 */     return (E)e;
/*     */   }
/*     */   
/*     */   private void resize(long oldMask, E[] oldBuffer, long pIndex, E e) {
/* 580 */     int newBufferLength = getNextBufferSize(oldBuffer);
/* 581 */     E[] newBuffer = allocate(newBufferLength);
/*     */     
/* 583 */     this.producerBuffer = newBuffer;
/* 584 */     int newMask = newBufferLength - 2 << 1;
/* 585 */     this.producerMask = newMask;
/*     */     
/* 587 */     long offsetInOld = modifiedCalcElementOffset(pIndex, oldMask);
/* 588 */     long offsetInNew = modifiedCalcElementOffset(pIndex, newMask);
/*     */ 
/*     */     
/* 591 */     UnsafeRefArrayAccess.soElement(newBuffer, offsetInNew, e);
/* 592 */     UnsafeRefArrayAccess.soElement(oldBuffer, nextArrayOffset(oldMask), (E)newBuffer);
/*     */ 
/*     */     
/* 595 */     long cIndex = lvConsumerIndex();
/* 596 */     long availableInQueue = availableInQueue(pIndex, cIndex);
/* 597 */     if (availableInQueue <= 0L) {
/* 598 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 603 */     soProducerLimit(pIndex + Math.min(newMask, availableInQueue));
/*     */ 
/*     */     
/* 606 */     soProducerIndex(pIndex + 2L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 611 */     UnsafeRefArrayAccess.soElement(oldBuffer, offsetInOld, (E)JUMP);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <E> E[] allocate(int capacity) {
/* 616 */     return (E[])new Object[capacity];
/*     */   }
/*     */   
/*     */   protected abstract long availableInQueue(long paramLong1, long paramLong2);
/*     */   
/*     */   public abstract int capacity();
/*     */   
/*     */   protected abstract int getNextBufferSize(E[] paramArrayOfE);
/*     */   
/*     */   protected abstract long getCurrentBufferCapacity(long paramLong);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\BaseMpscLinkedArrayQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */