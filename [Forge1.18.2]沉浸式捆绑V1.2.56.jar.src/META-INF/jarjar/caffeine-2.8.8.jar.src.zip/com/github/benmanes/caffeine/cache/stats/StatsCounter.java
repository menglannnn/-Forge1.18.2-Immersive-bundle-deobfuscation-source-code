/*     */ package com.github.benmanes.caffeine.cache.stats;
/*     */ 
/*     */ import com.github.benmanes.caffeine.cache.RemovalCause;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface StatsCounter
/*     */ {
/*     */   void recordHits(int paramInt);
/*     */   
/*     */   void recordMisses(int paramInt);
/*     */   
/*     */   void recordLoadSuccess(long paramLong);
/*     */   
/*     */   void recordLoadFailure(long paramLong);
/*     */   
/*     */   @Deprecated
/*     */   void recordEviction();
/*     */   
/*     */   @Deprecated
/*     */   default void recordEviction(int weight) {
/*  96 */     recordEviction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void recordEviction(int weight, RemovalCause cause) {
/* 109 */     recordEviction(weight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CacheStats snapshot();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static StatsCounter disabledStatsCounter() {
/* 131 */     return DisabledStatsCounter.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static StatsCounter guardedStatsCounter(StatsCounter statsCounter) {
/* 142 */     return (statsCounter instanceof GuardedStatsCounter) ? 
/* 143 */       statsCounter : 
/* 144 */       new GuardedStatsCounter(statsCounter);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\stats\StatsCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */