/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractLinkedDeque<E>
/*     */   extends AbstractCollection<E>
/*     */   implements LinkedDeque<E>
/*     */ {
/*     */   E first;
/*     */   E last;
/*     */   
/*     */   void linkFirst(E e) {
/*  59 */     E f = this.first;
/*  60 */     this.first = e;
/*     */     
/*  62 */     if (f == null) {
/*  63 */       this.last = e;
/*     */     } else {
/*  65 */       setPrevious(f, e);
/*  66 */       setNext(e, f);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void linkLast(E e) {
/*  76 */     E l = this.last;
/*  77 */     this.last = e;
/*     */     
/*  79 */     if (l == null) {
/*  80 */       this.first = e;
/*     */     } else {
/*  82 */       setNext(l, e);
/*  83 */       setPrevious(e, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   E unlinkFirst() {
/*  90 */     E f = this.first;
/*  91 */     E next = getNext(f);
/*  92 */     setNext(f, null);
/*     */     
/*  94 */     this.first = next;
/*  95 */     if (next == null) {
/*  96 */       this.last = null;
/*     */     } else {
/*  98 */       setPrevious(next, null);
/*     */     } 
/* 100 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   E unlinkLast() {
/* 106 */     E l = this.last;
/* 107 */     E prev = getPrevious(l);
/* 108 */     setPrevious(l, null);
/* 109 */     this.last = prev;
/* 110 */     if (prev == null) {
/* 111 */       this.first = null;
/*     */     } else {
/* 113 */       setNext(prev, null);
/*     */     } 
/* 115 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   void unlink(E e) {
/* 120 */     E prev = getPrevious(e);
/* 121 */     E next = getNext(e);
/*     */     
/* 123 */     if (prev == null) {
/* 124 */       this.first = next;
/*     */     } else {
/* 126 */       setNext(prev, next);
/* 127 */       setPrevious(e, null);
/*     */     } 
/*     */     
/* 130 */     if (next == null) {
/* 131 */       this.last = prev;
/*     */     } else {
/* 133 */       setPrevious(next, prev);
/* 134 */       setNext(e, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 140 */     return (this.first == null);
/*     */   }
/*     */   
/*     */   void checkNotEmpty() {
/* 144 */     if (isEmpty()) {
/* 145 */       throw new NoSuchElementException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 156 */     int size = 0;
/* 157 */     for (E e = this.first; e != null; e = getNext(e)) {
/* 158 */       size++;
/*     */     }
/* 160 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 166 */     for (E e = this.first; e != null; ) {
/* 167 */       E next = getNext(e);
/* 168 */       setPrevious(e, null);
/* 169 */       setNext(e, null);
/* 170 */       e = next;
/*     */     } 
/* 172 */     this.first = this.last = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFirst(E e) {
/* 180 */     return (e != null && e == this.first);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLast(E e) {
/* 185 */     return (e != null && e == this.last);
/*     */   }
/*     */ 
/*     */   
/*     */   public void moveToFront(E e) {
/* 190 */     if (e != this.first) {
/* 191 */       unlink(e);
/* 192 */       linkFirst(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void moveToBack(E e) {
/* 198 */     if (e != this.last) {
/* 199 */       unlink(e);
/* 200 */       linkLast(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public E peek() {
/* 206 */     return peekFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public E peekFirst() {
/* 211 */     return this.first;
/*     */   }
/*     */ 
/*     */   
/*     */   public E peekLast() {
/* 216 */     return this.last;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E getFirst() {
/* 222 */     checkNotEmpty();
/* 223 */     return peekFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E getLast() {
/* 229 */     checkNotEmpty();
/* 230 */     return peekLast();
/*     */   }
/*     */ 
/*     */   
/*     */   public E element() {
/* 235 */     return getFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean offer(E e) {
/* 240 */     return offerLast(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean offerFirst(E e) {
/* 245 */     if (contains(e)) {
/* 246 */       return false;
/*     */     }
/* 248 */     linkFirst(e);
/* 249 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean offerLast(E e) {
/* 254 */     if (contains(e)) {
/* 255 */       return false;
/*     */     }
/* 257 */     linkLast(e);
/* 258 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E e) {
/* 263 */     return offerLast(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFirst(E e) {
/* 268 */     if (!offerFirst(e)) {
/* 269 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addLast(E e) {
/* 275 */     if (!offerLast(e)) {
/* 276 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public E poll() {
/* 282 */     return pollFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public E pollFirst() {
/* 287 */     return isEmpty() ? null : unlinkFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public E pollLast() {
/* 292 */     return isEmpty() ? null : unlinkLast();
/*     */   }
/*     */ 
/*     */   
/*     */   public E remove() {
/* 297 */     return removeFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E removeFirst() {
/* 303 */     checkNotEmpty();
/* 304 */     return pollFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeFirstOccurrence(Object o) {
/* 309 */     return remove(o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E removeLast() {
/* 315 */     checkNotEmpty();
/* 316 */     return pollLast();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeLastOccurrence(Object o) {
/* 321 */     return remove(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 326 */     boolean modified = false;
/* 327 */     for (Object o : c) {
/* 328 */       modified |= remove(o);
/*     */     }
/* 330 */     return modified;
/*     */   }
/*     */ 
/*     */   
/*     */   public void push(E e) {
/* 335 */     addFirst(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public E pop() {
/* 340 */     return removeFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public LinkedDeque.PeekingIterator<E> iterator() {
/* 345 */     return new AbstractLinkedIterator(this.first)
/*     */       {
/*     */         E computeNext() {
/* 348 */           return AbstractLinkedDeque.this.getNext(this.cursor);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public LinkedDeque.PeekingIterator<E> descendingIterator() {
/* 355 */     return new AbstractLinkedIterator(this.last)
/*     */       {
/*     */         E computeNext() {
/* 358 */           return AbstractLinkedDeque.this.getPrevious(this.cursor);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract boolean contains(Object paramObject);
/*     */   
/*     */   abstract class AbstractLinkedIterator
/*     */     implements LinkedDeque.PeekingIterator<E>
/*     */   {
/*     */     E previous;
/*     */     E cursor;
/*     */     
/*     */     AbstractLinkedIterator(E start) {
/* 373 */       this.cursor = start;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 378 */       return (this.cursor != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public E peek() {
/* 383 */       return this.cursor;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public E next() {
/* 389 */       if (!hasNext()) {
/* 390 */         throw new NoSuchElementException();
/*     */       }
/* 392 */       this.previous = this.cursor;
/* 393 */       this.cursor = computeNext();
/* 394 */       return this.previous;
/*     */     }
/*     */ 
/*     */     
/*     */     abstract E computeNext();
/*     */ 
/*     */     
/*     */     public void remove() {
/* 402 */       if (this.previous == null) {
/* 403 */         throw new IllegalStateException();
/*     */       }
/* 405 */       AbstractLinkedDeque.this.remove(this.previous);
/* 406 */       this.previous = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\AbstractLinkedDeque.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */