/*      */ package com.github.benmanes.caffeine.cache;
/*      */ 
/*      */ import com.github.benmanes.caffeine.cache.stats.StatsCounter;
/*      */ import com.google.errorprone.annotations.FormatMethod;
/*      */ import java.time.Duration;
/*      */ import java.util.Locale;
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.ForkJoinPool;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Caffeine<K, V>
/*      */ {
/*  140 */   static final Logger logger = Logger.getLogger(Caffeine.class.getName()); static final int UNSET_INT = -1; static final int DEFAULT_INITIAL_CAPACITY = 16;
/*  141 */   static final Supplier<StatsCounter> ENABLED_STATS_COUNTER_SUPPLIER = com.github.benmanes.caffeine.cache.stats.ConcurrentStatsCounter::new; static final int DEFAULT_EXPIRATION_NANOS = 0; static final int DEFAULT_REFRESH_NANOS = 0;
/*      */   
/*  143 */   enum Strength { WEAK, SOFT; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean strictParsing = true;
/*      */ 
/*      */ 
/*      */   
/*  152 */   long maximumSize = -1L;
/*  153 */   long maximumWeight = -1L;
/*  154 */   int initialCapacity = -1;
/*      */   
/*  156 */   long expireAfterWriteNanos = -1L;
/*  157 */   long expireAfterAccessNanos = -1L;
/*  158 */   long refreshAfterWriteNanos = -1L;
/*      */   
/*      */   RemovalListener<? super K, ? super V> removalListener;
/*      */   
/*      */   Supplier<StatsCounter> statsCounterSupplier;
/*      */   
/*      */   CacheWriter<? super K, ? super V> writer;
/*      */   
/*      */   Weigher<? super K, ? super V> weigher;
/*      */   
/*      */   Expiry<? super K, ? super V> expiry;
/*      */   Scheduler scheduler;
/*      */   Executor executor;
/*      */   Ticker ticker;
/*      */   Strength keyStrength;
/*      */   Strength valueStrength;
/*      */   
/*      */   @FormatMethod
/*      */   static void requireArgument(boolean expression, String template, Object... args) {
/*  177 */     if (!expression) {
/*  178 */       throw new IllegalArgumentException(String.format(template, args));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void requireArgument(boolean expression) {
/*  184 */     if (!expression) {
/*  185 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void requireState(boolean expression) {
/*  191 */     if (!expression) {
/*  192 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @FormatMethod
/*      */   static void requireState(boolean expression, String template, Object... args) {
/*  199 */     if (!expression) {
/*  200 */       throw new IllegalStateException(String.format(template, args));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static int ceilingPowerOfTwo(int x) {
/*  207 */     return 1 << -Integer.numberOfLeadingZeros(x - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static long ceilingPowerOfTwo(long x) {
/*  213 */     return 1L << -Long.numberOfLeadingZeros(x - 1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Caffeine<Object, Object> newBuilder() {
/*  227 */     return new Caffeine<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Caffeine<Object, Object> from(CaffeineSpec spec) {
/*  238 */     Caffeine<Object, Object> builder = spec.toBuilder();
/*  239 */     builder.strictParsing = false;
/*  240 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Caffeine<Object, Object> from(String spec) {
/*  251 */     return from(CaffeineSpec.parse(spec));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> initialCapacity(int initialCapacity) {
/*  266 */     requireState((this.initialCapacity == -1), "initial capacity was already set to %s", new Object[] {
/*  267 */           Integer.valueOf(this.initialCapacity) });
/*  268 */     requireArgument((initialCapacity >= 0));
/*  269 */     this.initialCapacity = initialCapacity;
/*  270 */     return this;
/*      */   }
/*      */   
/*      */   boolean hasInitialCapacity() {
/*  274 */     return (this.initialCapacity != -1);
/*      */   }
/*      */   
/*      */   int getInitialCapacity() {
/*  278 */     return hasInitialCapacity() ? this.initialCapacity : 16;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> executor(Executor executor) {
/*  300 */     requireState((this.executor == null), "executor was already set to %s", new Object[] { this.executor });
/*  301 */     this.executor = Objects.<Executor>requireNonNull(executor);
/*  302 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   Executor getExecutor() {
/*  307 */     return (this.executor == null) ? ForkJoinPool.commonPool() : this.executor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> scheduler(Scheduler scheduler) {
/*  333 */     requireState((this.scheduler == null), "scheduler was already set to %s", new Object[] { this.scheduler });
/*  334 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler);
/*  335 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   Scheduler getScheduler() {
/*  340 */     if (this.scheduler == null || this.scheduler == Scheduler.disabledScheduler())
/*  341 */       return Scheduler.disabledScheduler(); 
/*  342 */     if (this.scheduler == Scheduler.systemScheduler()) {
/*  343 */       return this.scheduler;
/*      */     }
/*  345 */     return Scheduler.guardedScheduler(this.scheduler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> maximumSize(long maximumSize) {
/*  369 */     requireState((this.maximumSize == -1L), "maximum size was already set to %s", new Object[] {
/*  370 */           Long.valueOf(this.maximumSize) });
/*  371 */     requireState((this.maximumWeight == -1L), "maximum weight was already set to %s", new Object[] {
/*  372 */           Long.valueOf(this.maximumWeight) });
/*  373 */     requireState((this.weigher == null), "maximum size can not be combined with weigher", new Object[0]);
/*  374 */     requireArgument((maximumSize >= 0L), "maximum size must not be negative", new Object[0]);
/*  375 */     this.maximumSize = maximumSize;
/*  376 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> maximumWeight(long maximumWeight) {
/*  406 */     requireState((this.maximumWeight == -1L), "maximum weight was already set to %s", new Object[] {
/*  407 */           Long.valueOf(this.maximumWeight) });
/*  408 */     requireState((this.maximumSize == -1L), "maximum size was already set to %s", new Object[] {
/*  409 */           Long.valueOf(this.maximumSize) });
/*  410 */     requireArgument((maximumWeight >= 0L), "maximum weight must not be negative", new Object[0]);
/*  411 */     this.maximumWeight = maximumWeight;
/*  412 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> Caffeine<K1, V1> weigher(Weigher<? super K1, ? super V1> weigher) {
/*  448 */     Objects.requireNonNull(weigher);
/*  449 */     requireState((this.weigher == null), "weigher was already set to %s", new Object[] { this.weigher });
/*  450 */     requireState((!this.strictParsing || this.maximumSize == -1L), "weigher can not be combined with maximum size", new Object[0]);
/*      */ 
/*      */ 
/*      */     
/*  454 */     Caffeine<K1, V1> self = this;
/*  455 */     self.weigher = weigher;
/*  456 */     return self;
/*      */   }
/*      */   
/*      */   boolean evicts() {
/*  460 */     return (getMaximum() != -1L);
/*      */   }
/*      */   
/*      */   boolean isWeighted() {
/*  464 */     return (this.weigher != null);
/*      */   }
/*      */   
/*      */   long getMaximum() {
/*  468 */     return isWeighted() ? this.maximumWeight : this.maximumSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   <K1 extends K, V1 extends V> Weigher<K1, V1> getWeigher(boolean isAsync) {
/*  475 */     Weigher<K1, V1> delegate = (this.weigher == null || this.weigher == Weigher.singletonWeigher()) ? Weigher.<K1, V1>singletonWeigher() : Weigher.<K1, V1>boundedWeigher((Weigher)this.weigher);
/*  476 */     return isAsync ? (Weigher<K1, V1>)new Async.AsyncWeigher<>(delegate) : delegate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> weakKeys() {
/*  499 */     requireState((this.keyStrength == null), "Key strength was already set to %s", new Object[] { this.keyStrength });
/*  500 */     requireState((this.writer == null), "Weak keys may not be used with CacheWriter", new Object[0]);
/*      */     
/*  502 */     this.keyStrength = Strength.WEAK;
/*  503 */     return this;
/*      */   }
/*      */   
/*      */   boolean isStrongKeys() {
/*  507 */     return (this.keyStrength == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> weakValues() {
/*  531 */     requireState((this.valueStrength == null), "Value strength was already set to %s", new Object[] { this.valueStrength });
/*  532 */     this.valueStrength = Strength.WEAK;
/*  533 */     return this;
/*      */   }
/*      */   
/*      */   boolean isStrongValues() {
/*  537 */     return (this.valueStrength == null);
/*      */   }
/*      */   
/*      */   boolean isWeakValues() {
/*  541 */     return (this.valueStrength == Strength.WEAK);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> softValues() {
/*  568 */     requireState((this.valueStrength == null), "Value strength was already set to %s", new Object[] { this.valueStrength });
/*  569 */     this.valueStrength = Strength.SOFT;
/*  570 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> expireAfterWrite(Duration duration) {
/*  590 */     return expireAfterWrite(saturatedToNanos(duration), TimeUnit.NANOSECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> expireAfterWrite(long duration, TimeUnit unit) {
/*  613 */     requireState((this.expireAfterWriteNanos == -1L), "expireAfterWrite was already set to %s ns", new Object[] {
/*  614 */           Long.valueOf(this.expireAfterWriteNanos) });
/*  615 */     requireState((this.expiry == null), "expireAfterWrite may not be used with variable expiration", new Object[0]);
/*  616 */     requireArgument((duration >= 0L), "duration cannot be negative: %s %s", new Object[] { Long.valueOf(duration), unit });
/*  617 */     this.expireAfterWriteNanos = unit.toNanos(duration);
/*  618 */     return this;
/*      */   }
/*      */   
/*      */   long getExpiresAfterWriteNanos() {
/*  622 */     return expiresAfterWrite() ? this.expireAfterWriteNanos : 0L;
/*      */   }
/*      */   
/*      */   boolean expiresAfterWrite() {
/*  626 */     return (this.expireAfterWriteNanos != -1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> expireAfterAccess(Duration duration) {
/*  649 */     return expireAfterAccess(saturatedToNanos(duration), TimeUnit.NANOSECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> expireAfterAccess(long duration, TimeUnit unit) {
/*  675 */     requireState((this.expireAfterAccessNanos == -1L), "expireAfterAccess was already set to %s ns", new Object[] {
/*  676 */           Long.valueOf(this.expireAfterAccessNanos) });
/*  677 */     requireState((this.expiry == null), "expireAfterAccess may not be used with variable expiration", new Object[0]);
/*  678 */     requireArgument((duration >= 0L), "duration cannot be negative: %s %s", new Object[] { Long.valueOf(duration), unit });
/*  679 */     this.expireAfterAccessNanos = unit.toNanos(duration);
/*  680 */     return this;
/*      */   }
/*      */   
/*      */   long getExpiresAfterAccessNanos() {
/*  684 */     return expiresAfterAccess() ? this.expireAfterAccessNanos : 0L;
/*      */   }
/*      */   
/*      */   boolean expiresAfterAccess() {
/*  688 */     return (this.expireAfterAccessNanos != -1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> Caffeine<K1, V1> expireAfter(Expiry<? super K1, ? super V1> expiry) {
/*  711 */     Objects.requireNonNull(expiry);
/*  712 */     requireState((this.expiry == null), "Expiry was already set to %s", new Object[] { this.expiry });
/*  713 */     requireState((this.expireAfterAccessNanos == -1L), "Expiry may not be used with expiresAfterAccess", new Object[0]);
/*      */     
/*  715 */     requireState((this.expireAfterWriteNanos == -1L), "Expiry may not be used with expiresAfterWrite", new Object[0]);
/*      */ 
/*      */ 
/*      */     
/*  719 */     Caffeine<K1, V1> self = this;
/*  720 */     self.expiry = expiry;
/*  721 */     return self;
/*      */   }
/*      */   
/*      */   boolean expiresVariable() {
/*  725 */     return (this.expiry != null);
/*      */   }
/*      */ 
/*      */   
/*      */   Expiry<K, V> getExpiry(boolean isAsync) {
/*  730 */     return (isAsync && this.expiry != null) ? 
/*  731 */       (Expiry<K, V>)new Async.AsyncExpiry<>((Expiry)this.expiry) : 
/*  732 */       (Expiry)this.expiry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> refreshAfterWrite(Duration duration) {
/*  756 */     return refreshAfterWrite(saturatedToNanos(duration), TimeUnit.NANOSECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> refreshAfterWrite(long duration, TimeUnit unit) {
/*  783 */     Objects.requireNonNull(unit);
/*  784 */     requireState((this.refreshAfterWriteNanos == -1L), "refreshAfterWriteNanos was already set to %s ns", new Object[] {
/*  785 */           Long.valueOf(this.refreshAfterWriteNanos) });
/*  786 */     requireArgument((duration > 0L), "duration must be positive: %s %s", new Object[] { Long.valueOf(duration), unit });
/*  787 */     this.refreshAfterWriteNanos = unit.toNanos(duration);
/*  788 */     return this;
/*      */   }
/*      */   
/*      */   long getRefreshAfterWriteNanos() {
/*  792 */     return refreshAfterWrite() ? this.refreshAfterWriteNanos : 0L;
/*      */   }
/*      */   
/*      */   boolean refreshAfterWrite() {
/*  796 */     return (this.refreshAfterWriteNanos != -1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> ticker(Ticker ticker) {
/*  813 */     requireState((this.ticker == null), "Ticker was already set to %s", new Object[] { this.ticker });
/*  814 */     this.ticker = Objects.<Ticker>requireNonNull(ticker);
/*  815 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Ticker getTicker() {
/*  821 */     boolean useTicker = (expiresVariable() || expiresAfterAccess() || expiresAfterWrite() || refreshAfterWrite() || isRecordingStats());
/*  822 */     return useTicker ? (
/*  823 */       (this.ticker == null) ? Ticker.systemTicker() : this.ticker) : 
/*  824 */       Ticker.disabledTicker();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> Caffeine<K1, V1> removalListener(RemovalListener<? super K1, ? super V1> removalListener) {
/*  855 */     requireState((this.removalListener == null), "removal listener was already set to %s", new Object[] { this.removalListener });
/*      */ 
/*      */ 
/*      */     
/*  859 */     Caffeine<K1, V1> self = this;
/*  860 */     self.removalListener = Objects.<RemovalListener<? super K, ? super V>>requireNonNull(removalListener);
/*  861 */     return self;
/*      */   }
/*      */ 
/*      */   
/*      */   <K1 extends K, V1 extends V> RemovalListener<K1, V1> getRemovalListener(boolean async) {
/*  866 */     RemovalListener<? super K, ? super V> removalListener = this.removalListener;
/*  867 */     return (async && removalListener != null) ? 
/*  868 */       (RemovalListener<K1, V1>)new Async.AsyncRemovalListener<>((RemovalListener)removalListener, getExecutor()) : 
/*  869 */       (RemovalListener)removalListener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> Caffeine<K1, V1> writer(CacheWriter<? super K1, ? super V1> writer) {
/*  903 */     requireState((this.writer == null), "Writer was already set to %s", new Object[] { this.writer });
/*  904 */     requireState((this.keyStrength == null), "Weak keys may not be used with CacheWriter", new Object[0]);
/*      */ 
/*      */     
/*  907 */     Caffeine<K1, V1> self = this;
/*  908 */     self.writer = Objects.<CacheWriter<? super K, ? super V>>requireNonNull(writer);
/*  909 */     return self;
/*      */   }
/*      */ 
/*      */   
/*      */   <K1 extends K, V1 extends V> CacheWriter<K1, V1> getCacheWriter() {
/*  914 */     CacheWriter<? super K, ? super V> cacheWriter = this.writer;
/*  915 */     return (cacheWriter == null) ? CacheWriter.<K1, V1>disabledWriter() : (CacheWriter)cacheWriter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> recordStats() {
/*  928 */     requireState((this.statsCounterSupplier == null), "Statistics recording was already set", new Object[0]);
/*  929 */     this.statsCounterSupplier = ENABLED_STATS_COUNTER_SUPPLIER;
/*  930 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Caffeine<K, V> recordStats(Supplier<? extends StatsCounter> statsCounterSupplier) {
/*  946 */     requireState((this.statsCounterSupplier == null), "Statistics recording was already set", new Object[0]);
/*  947 */     Objects.requireNonNull(statsCounterSupplier);
/*  948 */     this.statsCounterSupplier = (() -> StatsCounter.guardedStatsCounter(statsCounterSupplier.get()));
/*  949 */     return this;
/*      */   }
/*      */   
/*      */   boolean isRecordingStats() {
/*  953 */     return (this.statsCounterSupplier != null);
/*      */   }
/*      */ 
/*      */   
/*      */   Supplier<StatsCounter> getStatsCounterSupplier() {
/*  958 */     return (this.statsCounterSupplier == null) ? 
/*  959 */       StatsCounter::disabledStatsCounter : 
/*  960 */       this.statsCounterSupplier;
/*      */   }
/*      */   
/*      */   boolean isBounded() {
/*  964 */     return (this.maximumSize != -1L || this.maximumWeight != -1L || this.expireAfterAccessNanos != -1L || this.expireAfterWriteNanos != -1L || this.expiry != null || this.keyStrength != null || this.valueStrength != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> Cache<K1, V1> build() {
/*  990 */     requireWeightWithWeigher();
/*  991 */     requireNonLoadingCache();
/*      */ 
/*      */     
/*  994 */     Caffeine<K1, V1> self = this;
/*  995 */     return isBounded() ? 
/*  996 */       new BoundedLocalCache.BoundedLocalManualCache<>(self) : 
/*  997 */       new UnboundedLocalCache.UnboundedLocalManualCache<>(self);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> LoadingCache<K1, V1> build(CacheLoader<? super K1, V1> loader) {
/* 1017 */     requireWeightWithWeigher();
/*      */ 
/*      */     
/* 1020 */     Caffeine<K1, V1> self = this;
/* 1021 */     return (isBounded() || refreshAfterWrite()) ? 
/* 1022 */       new BoundedLocalCache.BoundedLocalLoadingCache<>(self, loader) : 
/* 1023 */       new UnboundedLocalCache.UnboundedLocalLoadingCache<>(self, loader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> AsyncCache<K1, V1> buildAsync() {
/* 1048 */     requireState((this.valueStrength == null), "Weak or soft values can not be combined with AsyncCache", new Object[0]);
/* 1049 */     requireState((this.writer == null), "CacheWriter can not be combined with AsyncCache", new Object[0]);
/* 1050 */     requireWeightWithWeigher();
/* 1051 */     requireNonLoadingCache();
/*      */ 
/*      */     
/* 1054 */     Caffeine<K1, V1> self = this;
/* 1055 */     return isBounded() ? 
/* 1056 */       new BoundedLocalCache.BoundedLocalAsyncCache<>(self) : 
/* 1057 */       new UnboundedLocalCache.UnboundedLocalAsyncCache<>(self);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> AsyncLoadingCache<K1, V1> buildAsync(CacheLoader<? super K1, V1> loader) {
/* 1081 */     return buildAsync(loader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <K1 extends K, V1 extends V> AsyncLoadingCache<K1, V1> buildAsync(AsyncCacheLoader<? super K1, V1> loader) {
/* 1105 */     requireState((this.valueStrength == null), "Weak or soft values can not be combined with AsyncLoadingCache", new Object[0]);
/*      */     
/* 1107 */     requireState((this.writer == null), "CacheWriter can not be combined with AsyncLoadingCache", new Object[0]);
/* 1108 */     requireWeightWithWeigher();
/* 1109 */     Objects.requireNonNull(loader);
/*      */ 
/*      */     
/* 1112 */     Caffeine<K1, V1> self = this;
/* 1113 */     return (isBounded() || refreshAfterWrite()) ? 
/* 1114 */       new BoundedLocalCache.BoundedLocalAsyncLoadingCache<>(self, loader) : 
/* 1115 */       new UnboundedLocalCache.UnboundedLocalAsyncLoadingCache<>(self, loader);
/*      */   }
/*      */   
/*      */   void requireNonLoadingCache() {
/* 1119 */     requireState((this.refreshAfterWriteNanos == -1L), "refreshAfterWrite requires a LoadingCache", new Object[0]);
/*      */   }
/*      */   
/*      */   void requireWeightWithWeigher() {
/* 1123 */     if (this.weigher == null) {
/* 1124 */       requireState((this.maximumWeight == -1L), "maximumWeight requires weigher", new Object[0]);
/* 1125 */     } else if (this.strictParsing) {
/* 1126 */       requireState((this.maximumWeight != -1L), "weigher requires maximumWeight", new Object[0]);
/* 1127 */     } else if (this.maximumWeight == -1L) {
/* 1128 */       logger.log(Level.WARNING, "ignoring weigher specified without maximumWeight");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long saturatedToNanos(Duration duration) {
/*      */     try {
/* 1143 */       return duration.toNanos();
/* 1144 */     } catch (ArithmeticException tooBig) {
/* 1145 */       return duration.isNegative() ? Long.MIN_VALUE : Long.MAX_VALUE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1155 */     StringBuilder s = new StringBuilder(64);
/* 1156 */     s.append(getClass().getSimpleName()).append('{');
/* 1157 */     int baseLength = s.length();
/* 1158 */     if (this.initialCapacity != -1) {
/* 1159 */       s.append("initialCapacity=").append(this.initialCapacity).append(", ");
/*      */     }
/* 1161 */     if (this.maximumSize != -1L) {
/* 1162 */       s.append("maximumSize=").append(this.maximumSize).append(", ");
/*      */     }
/* 1164 */     if (this.maximumWeight != -1L) {
/* 1165 */       s.append("maximumWeight=").append(this.maximumWeight).append(", ");
/*      */     }
/* 1167 */     if (this.expireAfterWriteNanos != -1L) {
/* 1168 */       s.append("expireAfterWrite=").append(this.expireAfterWriteNanos).append("ns, ");
/*      */     }
/* 1170 */     if (this.expireAfterAccessNanos != -1L) {
/* 1171 */       s.append("expireAfterAccess=").append(this.expireAfterAccessNanos).append("ns, ");
/*      */     }
/* 1173 */     if (this.expiry != null) {
/* 1174 */       s.append("expiry, ");
/*      */     }
/* 1176 */     if (this.refreshAfterWriteNanos != -1L) {
/* 1177 */       s.append("refreshAfterWriteNanos=").append(this.refreshAfterWriteNanos).append("ns, ");
/*      */     }
/* 1179 */     if (this.keyStrength != null) {
/* 1180 */       s.append("keyStrength=").append(this.keyStrength.toString().toLowerCase(Locale.US)).append(", ");
/*      */     }
/* 1182 */     if (this.valueStrength != null) {
/* 1183 */       s.append("valueStrength=").append(this.valueStrength.toString().toLowerCase(Locale.US)).append(", ");
/*      */     }
/* 1185 */     if (this.removalListener != null) {
/* 1186 */       s.append("removalListener, ");
/*      */     }
/* 1188 */     if (this.writer != null) {
/* 1189 */       s.append("writer, ");
/*      */     }
/* 1191 */     if (s.length() > baseLength) {
/* 1192 */       s.deleteCharAt(s.length() - 2);
/*      */     }
/* 1194 */     return s.append('}').toString();
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\Caffeine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */