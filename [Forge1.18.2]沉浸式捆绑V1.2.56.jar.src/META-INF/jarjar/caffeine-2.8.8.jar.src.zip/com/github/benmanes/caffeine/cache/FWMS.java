/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FWMS<K, V>
/*    */   extends FW<K, V>
/*    */ {
/*    */   int queueType;
/*    */   Node<K, V> previousInAccessOrder;
/*    */   Node<K, V> nextInAccessOrder;
/*    */   
/*    */   FWMS() {}
/*    */   
/*    */   FWMS(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 48 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   FWMS(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 52 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   public int getQueueType() {
/* 56 */     return this.queueType;
/*    */   }
/*    */   
/*    */   public void setQueueType(int queueType) {
/* 60 */     this.queueType = queueType;
/*    */   }
/*    */   
/*    */   public Node<K, V> getPreviousInAccessOrder() {
/* 64 */     return this.previousInAccessOrder;
/*    */   }
/*    */   
/*    */   public void setPreviousInAccessOrder(Node<K, V> previousInAccessOrder) {
/* 68 */     this.previousInAccessOrder = previousInAccessOrder;
/*    */   }
/*    */   
/*    */   public Node<K, V> getNextInAccessOrder() {
/* 72 */     return this.nextInAccessOrder;
/*    */   }
/*    */   
/*    */   public void setNextInAccessOrder(Node<K, V> nextInAccessOrder) {
/* 76 */     this.nextInAccessOrder = nextInAccessOrder;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 86 */     return new FWMS(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 91 */     return new FWMS(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FWMS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */