/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import com.github.benmanes.caffeine.cache.stats.CacheStats;
/*     */ import com.google.errorprone.annotations.CompatibleWith;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Cache<K, V>
/*     */ {
/*     */   V getIfPresent(@CompatibleWith("K") Object paramObject);
/*     */   
/*     */   V get(K paramK, Function<? super K, ? extends V> paramFunction);
/*     */   
/*     */   Map<K, V> getAllPresent(Iterable<?> paramIterable);
/*     */   
/*     */   default Map<K, V> getAll(Iterable<? extends K> keys, Function<Iterable<? extends K>, Map<K, V>> mappingFunction) {
/* 125 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   void put(K paramK, V paramV);
/*     */   
/*     */   void putAll(Map<? extends K, ? extends V> paramMap);
/*     */   
/*     */   void invalidate(@CompatibleWith("K") Object paramObject);
/*     */   
/*     */   void invalidateAll(Iterable<?> paramIterable);
/*     */   
/*     */   void invalidateAll();
/*     */   
/*     */   long estimatedSize();
/*     */   
/*     */   CacheStats stats();
/*     */   
/*     */   ConcurrentMap<K, V> asMap();
/*     */   
/*     */   void cleanUp();
/*     */   
/*     */   Policy<K, V> policy();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\Cache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */