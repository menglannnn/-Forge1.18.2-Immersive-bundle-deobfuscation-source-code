/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Async
/*     */ {
/*     */   static final long ASYNC_EXPIRY = 6917529027641081854L;
/*     */   
/*     */   static boolean isReady(CompletableFuture<?> future) {
/*  42 */     return (future != null && future.isDone() && 
/*  43 */       !future.isCompletedExceptionally() && future
/*  44 */       .join() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <V> V getIfReady(CompletableFuture<V> future) {
/*  50 */     return isReady(future) ? future.join() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   static <V> V getWhenSuccessful(CompletableFuture<V> future) {
/*     */     try {
/*  56 */       return (future == null) ? null : future.join();
/*  57 */     } catch (CancellationException|java.util.concurrent.CompletionException e) {
/*  58 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static final class AsyncRemovalListener<K, V>
/*     */     implements RemovalListener<K, CompletableFuture<V>>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     final RemovalListener<K, V> delegate;
/*     */     
/*     */     final Executor executor;
/*     */ 
/*     */     
/*     */     AsyncRemovalListener(RemovalListener<K, V> delegate, Executor executor) {
/*  74 */       this.delegate = Objects.<RemovalListener<K, V>>requireNonNull(delegate);
/*  75 */       this.executor = Objects.<Executor>requireNonNull(executor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onRemoval(K key, CompletableFuture<V> future, RemovalCause cause) {
/*  82 */       if (future != null) {
/*  83 */         future.thenAcceptAsync(value -> { if (value != null) this.delegate.onRemoval((K)key, (V)value, cause);  }this.executor);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object writeReplace() {
/*  92 */       return this.delegate;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AsyncWeigher<K, V>
/*     */     implements Weigher<K, CompletableFuture<V>>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     final Weigher<K, V> delegate;
/*     */ 
/*     */ 
/*     */     
/*     */     AsyncWeigher(Weigher<K, V> delegate) {
/* 109 */       this.delegate = Objects.<Weigher<K, V>>requireNonNull(delegate);
/*     */     }
/*     */ 
/*     */     
/*     */     public int weigh(K key, CompletableFuture<V> future) {
/* 114 */       return Async.isReady(future) ? this.delegate.weigh(key, future.join()) : 0;
/*     */     }
/*     */     
/*     */     Object writeReplace() {
/* 118 */       return this.delegate;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AsyncExpiry<K, V>
/*     */     implements Expiry<K, CompletableFuture<V>>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     final Expiry<K, V> delegate;
/*     */ 
/*     */ 
/*     */     
/*     */     AsyncExpiry(Expiry<K, V> delegate) {
/* 135 */       this.delegate = Objects.<Expiry<K, V>>requireNonNull(delegate);
/*     */     }
/*     */ 
/*     */     
/*     */     public long expireAfterCreate(K key, CompletableFuture<V> future, long currentTime) {
/* 140 */       if (Async.isReady(future)) {
/* 141 */         long duration = this.delegate.expireAfterCreate(key, future.join(), currentTime);
/* 142 */         return Math.min(duration, 4611686018427387903L);
/*     */       } 
/* 144 */       return 6917529027641081854L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long expireAfterUpdate(K key, CompletableFuture<V> future, long currentTime, long currentDuration) {
/* 150 */       if (Async.isReady(future)) {
/*     */ 
/*     */         
/* 153 */         long duration = (currentDuration > 4611686018427387903L) ? this.delegate.expireAfterCreate(key, future.join(), currentTime) : this.delegate.expireAfterUpdate(key, future.join(), currentTime, currentDuration);
/* 154 */         return Math.min(duration, 4611686018427387903L);
/*     */       } 
/* 156 */       return 6917529027641081854L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long expireAfterRead(K key, CompletableFuture<V> future, long currentTime, long currentDuration) {
/* 162 */       if (Async.isReady(future)) {
/* 163 */         long duration = this.delegate.expireAfterRead(key, future.join(), currentTime, currentDuration);
/* 164 */         return Math.min(duration, 4611686018427387903L);
/*     */       } 
/* 166 */       return 6917529027641081854L;
/*     */     }
/*     */     
/*     */     Object writeReplace() {
/* 170 */       return this.delegate;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\Async.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */