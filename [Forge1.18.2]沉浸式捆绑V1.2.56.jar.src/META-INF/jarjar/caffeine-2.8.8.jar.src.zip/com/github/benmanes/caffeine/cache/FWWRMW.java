/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FWWRMW<K, V>
/*     */   extends FWWR<K, V>
/*     */ {
/*     */   int queueType;
/*     */   int weight;
/*     */   int policyWeight;
/*     */   Node<K, V> previousInAccessOrder;
/*     */   Node<K, V> nextInAccessOrder;
/*     */   
/*     */   FWWRMW() {}
/*     */   
/*     */   FWWRMW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  54 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*  55 */     this.weight = weight;
/*     */   }
/*     */ 
/*     */   
/*     */   FWWRMW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  60 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*  61 */     this.weight = weight;
/*     */   }
/*     */   
/*     */   public int getQueueType() {
/*  65 */     return this.queueType;
/*     */   }
/*     */   
/*     */   public void setQueueType(int queueType) {
/*  69 */     this.queueType = queueType;
/*     */   }
/*     */   
/*     */   public int getWeight() {
/*  73 */     return this.weight;
/*     */   }
/*     */   
/*     */   public void setWeight(int weight) {
/*  77 */     this.weight = weight;
/*     */   }
/*     */   
/*     */   public int getPolicyWeight() {
/*  81 */     return this.policyWeight;
/*     */   }
/*     */   
/*     */   public void setPolicyWeight(int policyWeight) {
/*  85 */     this.policyWeight = policyWeight;
/*     */   }
/*     */   
/*     */   public Node<K, V> getPreviousInAccessOrder() {
/*  89 */     return this.previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public void setPreviousInAccessOrder(Node<K, V> previousInAccessOrder) {
/*  93 */     this.previousInAccessOrder = previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public Node<K, V> getNextInAccessOrder() {
/*  97 */     return this.nextInAccessOrder;
/*     */   }
/*     */   
/*     */   public void setNextInAccessOrder(Node<K, V> nextInAccessOrder) {
/* 101 */     this.nextInAccessOrder = nextInAccessOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 111 */     return new FWWRMW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 116 */     return new FWWRMW(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FWWRMW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */