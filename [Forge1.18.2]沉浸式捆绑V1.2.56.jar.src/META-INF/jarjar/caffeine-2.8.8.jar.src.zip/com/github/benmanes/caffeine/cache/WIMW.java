/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WIMW<K, V>
/*     */   extends WI<K, V>
/*     */ {
/*     */   long maximum;
/*     */   long weightedSize;
/*     */   long windowMaximum;
/*     */   long windowWeightedSize;
/*     */   long mainProtectedMaximum;
/*     */   long mainProtectedWeightedSize;
/*     */   double stepSize;
/*     */   long adjustment;
/*     */   int hitsInSample;
/*     */   int missesInSample;
/*     */   double previousSampleHitRate;
/*     */   final FrequencySketch<K> sketch;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderProbationDeque;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderProtectedDeque;
/*     */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*     */   
/*     */   WIMW(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/*  64 */     super(builder, cacheLoader, async);
/*  65 */     this.sketch = new FrequencySketch<>();
/*  66 */     if (builder.hasInitialCapacity()) {
/*  67 */       long capacity = Math.min(builder.getMaximum(), builder.getInitialCapacity());
/*  68 */       this.sketch.ensureCapacity(capacity);
/*     */     } 
/*  70 */     this
/*     */ 
/*     */       
/*  73 */       .accessOrderWindowDeque = (builder.evicts() || builder.expiresAfterAccess()) ? new AccessOrderDeque<>() : null;
/*  74 */     this.accessOrderProbationDeque = new AccessOrderDeque<>();
/*  75 */     this.accessOrderProtectedDeque = new AccessOrderDeque<>();
/*  76 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*     */   }
/*     */   
/*     */   protected final boolean evicts() {
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   protected final long maximum() {
/*  84 */     return this.maximum;
/*     */   }
/*     */   
/*     */   protected final void setMaximum(long maximum) {
/*  88 */     this.maximum = maximum;
/*     */   }
/*     */   
/*     */   protected final long weightedSize() {
/*  92 */     return this.weightedSize;
/*     */   }
/*     */   
/*     */   protected final void setWeightedSize(long weightedSize) {
/*  96 */     this.weightedSize = weightedSize;
/*     */   }
/*     */   
/*     */   protected final long windowMaximum() {
/* 100 */     return this.windowMaximum;
/*     */   }
/*     */   
/*     */   protected final void setWindowMaximum(long windowMaximum) {
/* 104 */     this.windowMaximum = windowMaximum;
/*     */   }
/*     */   
/*     */   protected final long windowWeightedSize() {
/* 108 */     return this.windowWeightedSize;
/*     */   }
/*     */   
/*     */   protected final void setWindowWeightedSize(long windowWeightedSize) {
/* 112 */     this.windowWeightedSize = windowWeightedSize;
/*     */   }
/*     */   
/*     */   protected final long mainProtectedMaximum() {
/* 116 */     return this.mainProtectedMaximum;
/*     */   }
/*     */   
/*     */   protected final void setMainProtectedMaximum(long mainProtectedMaximum) {
/* 120 */     this.mainProtectedMaximum = mainProtectedMaximum;
/*     */   }
/*     */   
/*     */   protected final long mainProtectedWeightedSize() {
/* 124 */     return this.mainProtectedWeightedSize;
/*     */   }
/*     */   
/*     */   protected final void setMainProtectedWeightedSize(long mainProtectedWeightedSize) {
/* 128 */     this.mainProtectedWeightedSize = mainProtectedWeightedSize;
/*     */   }
/*     */   
/*     */   protected final double stepSize() {
/* 132 */     return this.stepSize;
/*     */   }
/*     */   
/*     */   protected final void setStepSize(double stepSize) {
/* 136 */     this.stepSize = stepSize;
/*     */   }
/*     */   
/*     */   protected final long adjustment() {
/* 140 */     return this.adjustment;
/*     */   }
/*     */   
/*     */   protected final void setAdjustment(long adjustment) {
/* 144 */     this.adjustment = adjustment;
/*     */   }
/*     */   
/*     */   protected final int hitsInSample() {
/* 148 */     return this.hitsInSample;
/*     */   }
/*     */   
/*     */   protected final void setHitsInSample(int hitsInSample) {
/* 152 */     this.hitsInSample = hitsInSample;
/*     */   }
/*     */   
/*     */   protected final int missesInSample() {
/* 156 */     return this.missesInSample;
/*     */   }
/*     */   
/*     */   protected final void setMissesInSample(int missesInSample) {
/* 160 */     this.missesInSample = missesInSample;
/*     */   }
/*     */   
/*     */   protected final double previousSampleHitRate() {
/* 164 */     return this.previousSampleHitRate;
/*     */   }
/*     */   
/*     */   protected final void setPreviousSampleHitRate(double previousSampleHitRate) {
/* 168 */     this.previousSampleHitRate = previousSampleHitRate;
/*     */   }
/*     */   
/*     */   protected final FrequencySketch<K> frequencySketch() {
/* 172 */     return this.sketch;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque() {
/* 176 */     return this.accessOrderWindowDeque;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderProbationDeque() {
/* 180 */     return this.accessOrderProbationDeque;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderProtectedDeque() {
/* 184 */     return this.accessOrderProtectedDeque;
/*     */   }
/*     */   
/*     */   protected final MpscGrowableArrayQueue<Runnable> writeBuffer() {
/* 188 */     return this.writeBuffer;
/*     */   }
/*     */   
/*     */   protected final boolean buffersWrites() {
/* 192 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\WIMW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */