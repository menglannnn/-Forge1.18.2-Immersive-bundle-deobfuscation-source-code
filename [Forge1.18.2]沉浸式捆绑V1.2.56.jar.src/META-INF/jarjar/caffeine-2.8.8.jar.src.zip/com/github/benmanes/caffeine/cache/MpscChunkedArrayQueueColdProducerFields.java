/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MpscChunkedArrayQueueColdProducerFields<E>
/*     */   extends BaseMpscLinkedArrayQueue<E>
/*     */ {
/*     */   protected final long maxQueueCapacity;
/*     */   
/*     */   MpscChunkedArrayQueueColdProducerFields(int initialCapacity, int maxCapacity) {
/* 114 */     super(initialCapacity);
/* 115 */     if (maxCapacity < 4) {
/* 116 */       throw new IllegalArgumentException("Max capacity must be 4 or more");
/*     */     }
/* 118 */     if (Caffeine.ceilingPowerOfTwo(initialCapacity) >= Caffeine.ceilingPowerOfTwo(maxCapacity)) {
/* 119 */       throw new IllegalArgumentException("Initial capacity cannot exceed maximum capacity(both rounded up to a power of 2)");
/*     */     }
/*     */     
/* 122 */     this.maxQueueCapacity = Caffeine.ceilingPowerOfTwo(maxCapacity) << 1L;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\MpscChunkedArrayQueueColdProducerFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */