/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SSLSAWR<K, V>
/*    */   extends SSLSAW<K, V>
/*    */ {
/*    */   volatile long refreshAfterWriteNanos;
/*    */   
/*    */   SSLSAWR(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 38 */     super(builder, cacheLoader, async);
/* 39 */     this.refreshAfterWriteNanos = builder.getRefreshAfterWriteNanos();
/*    */   }
/*    */   
/*    */   protected boolean refreshAfterWrite() {
/* 43 */     return true;
/*    */   }
/*    */   
/*    */   protected long refreshAfterWriteNanos() {
/* 47 */     return this.refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/* 51 */     this.refreshAfterWriteNanos = refreshAfterWriteNanos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSLSAWR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */