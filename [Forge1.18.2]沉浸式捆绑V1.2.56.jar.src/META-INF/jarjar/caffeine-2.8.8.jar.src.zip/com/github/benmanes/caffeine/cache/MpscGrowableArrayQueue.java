/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MpscGrowableArrayQueue<E>
/*    */   extends MpscChunkedArrayQueue<E>
/*    */ {
/*    */   MpscGrowableArrayQueue(int initialCapacity, int maxCapacity) {
/* 48 */     super(initialCapacity, maxCapacity);
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getNextBufferSize(E[] buffer) {
/* 53 */     long maxSize = this.maxQueueCapacity / 2L;
/* 54 */     if (buffer.length > maxSize) {
/* 55 */       throw new IllegalStateException();
/*    */     }
/* 57 */     int newSize = 2 * (buffer.length - 1);
/* 58 */     return newSize + 1;
/*    */   }
/*    */ 
/*    */   
/*    */   protected long getCurrentBufferCapacity(long mask) {
/* 63 */     return (mask + 2L == this.maxQueueCapacity) ? this.maxQueueCapacity : mask;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\MpscGrowableArrayQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */