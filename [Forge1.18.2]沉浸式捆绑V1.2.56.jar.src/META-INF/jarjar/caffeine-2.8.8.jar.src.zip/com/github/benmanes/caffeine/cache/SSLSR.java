/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SSLSR<K, V>
/*    */   extends SSLS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   volatile long refreshAfterWriteNanos;
/*    */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*    */   
/*    */   SSLSR(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 40 */     super(builder, cacheLoader, async);
/* 41 */     this.ticker = builder.getTicker();
/* 42 */     this.refreshAfterWriteNanos = builder.getRefreshAfterWriteNanos();
/* 43 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*    */   }
/*    */   
/*    */   public Ticker expirationTicker() {
/* 47 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected boolean refreshAfterWrite() {
/* 51 */     return true;
/*    */   }
/*    */   
/*    */   protected long refreshAfterWriteNanos() {
/* 55 */     return this.refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/* 59 */     this.refreshAfterWriteNanos = refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected MpscGrowableArrayQueue<Runnable> writeBuffer() {
/* 63 */     return this.writeBuffer;
/*    */   }
/*    */   
/*    */   protected boolean buffersWrites() {
/* 67 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSLSR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */