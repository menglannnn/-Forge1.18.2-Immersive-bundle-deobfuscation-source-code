/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class StripedBuffer<E>
/*     */   implements Buffer<E>
/*     */ {
/*  87 */   static final long TABLE_BUSY = UnsafeAccess.objectFieldOffset(StripedBuffer.class, "tableBusy");
/*  88 */   static final long PROBE = UnsafeAccess.objectFieldOffset(Thread.class, "threadLocalRandomProbe");
/*     */ 
/*     */   
/*  91 */   static final int NCPU = Runtime.getRuntime().availableProcessors();
/*     */ 
/*     */   
/*  94 */   static final int MAXIMUM_TABLE_SIZE = 4 * Caffeine.ceilingPowerOfTwo(NCPU);
/*     */ 
/*     */   
/*     */   static final int ATTEMPTS = 3;
/*     */ 
/*     */   
/*     */   volatile transient Buffer<E>[] table;
/*     */ 
/*     */   
/*     */   volatile transient int tableBusy;
/*     */ 
/*     */   
/*     */   final boolean casTableBusy() {
/* 107 */     return UnsafeAccess.UNSAFE.compareAndSwapInt(this, TABLE_BUSY, 0, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int getProbe() {
/* 115 */     return UnsafeAccess.UNSAFE.getInt(Thread.currentThread(), PROBE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int advanceProbe(int probe) {
/* 123 */     probe ^= probe << 13;
/* 124 */     probe ^= probe >>> 17;
/* 125 */     probe ^= probe << 5;
/* 126 */     UnsafeAccess.UNSAFE.putInt(Thread.currentThread(), PROBE, probe);
/* 127 */     return probe;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Buffer<E> create(E paramE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int offer(E e) {
/* 141 */     int result = 0;
/*     */     
/* 143 */     boolean uncontended = true;
/* 144 */     Buffer<E>[] buffers = this.table; int mask; Buffer<E> buffer;
/* 145 */     if (buffers != null && (mask = buffers.length - 1) >= 0 && (
/*     */       
/* 147 */       buffer = buffers[getProbe() & mask]) != null)
/* 148 */     { if (!(uncontended = ((result = buffer.offer(e)) != -1)))
/* 149 */       { expandOrRetry(e, uncontended);
/*     */         
/* 151 */         return result; }  return result; }  expandOrRetry(e, uncontended); return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void drainTo(Consumer<E> consumer) {
/* 156 */     Buffer<E>[] buffers = this.table;
/* 157 */     if (buffers == null) {
/*     */       return;
/*     */     }
/* 160 */     for (Buffer<E> buffer : buffers) {
/* 161 */       if (buffer != null) {
/* 162 */         buffer.drainTo(consumer);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int reads() {
/* 169 */     Buffer<E>[] buffers = this.table;
/* 170 */     if (buffers == null) {
/* 171 */       return 0;
/*     */     }
/* 173 */     int reads = 0;
/* 174 */     for (Buffer<E> buffer : buffers) {
/* 175 */       if (buffer != null) {
/* 176 */         reads += buffer.reads();
/*     */       }
/*     */     } 
/* 179 */     return reads;
/*     */   }
/*     */ 
/*     */   
/*     */   public int writes() {
/* 184 */     Buffer<E>[] buffers = this.table;
/* 185 */     if (buffers == null) {
/* 186 */       return 0;
/*     */     }
/* 188 */     int writes = 0;
/* 189 */     for (Buffer<E> buffer : buffers) {
/* 190 */       if (buffer != null) {
/* 191 */         writes += buffer.writes();
/*     */       }
/*     */     } 
/* 194 */     return writes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void expandOrRetry(E e, boolean wasUncontended) {
/*     */     int h;
/* 208 */     if ((h = getProbe()) == 0) {
/* 209 */       ThreadLocalRandom.current();
/* 210 */       h = getProbe();
/* 211 */       wasUncontended = true;
/*     */     } 
/* 213 */     boolean collide = false;
/* 214 */     int attempt = 0; while (true) { if (attempt < 3) {
/*     */         Buffer<E>[] buffers;
/*     */         
/*     */         int n;
/* 218 */         if ((buffers = this.table) != null && (n = buffers.length) > 0)
/* 219 */         { Buffer<E> buffer; if ((buffer = buffers[n - 1 & h]) == null)
/* 220 */           { if (this.tableBusy == 0 && casTableBusy())
/* 221 */             { boolean created = false; try {
/*     */                 Buffer<E>[] rs;
/*     */                 int mask;
/*     */                 int j;
/* 225 */                 if ((rs = this.table) != null && (mask = rs.length) > 0 && rs[j = mask - 1 & h] == null) {
/*     */                   
/* 227 */                   rs[j] = create(e);
/* 228 */                   created = true;
/*     */                 } 
/*     */               } finally {
/* 231 */                 this.tableBusy = 0;
/*     */               } 
/* 233 */               if (created) {
/*     */                 break;
/*     */               } }
/*     */             else
/*     */             
/* 238 */             { collide = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 258 */               h = advanceProbe(h); }  continue; }  if (!wasUncontended) { wasUncontended = true; } else { if (buffer.offer(e) != -1) break;  if (n >= MAXIMUM_TABLE_SIZE || this.table != buffers) { collide = false; } else if (!collide) { collide = true; } else if (this.tableBusy == 0 && casTableBusy()) { try { if (this.table == buffers)
/* 259 */                   this.table = Arrays.<Buffer<E>>copyOf(buffers, n << 1);  } finally { this.tableBusy = 0; }  collide = false; continue; }  }  } else { if (this.tableBusy == 0 && this.table == buffers && casTableBusy()) {
/* 260 */             boolean init = false;
/*     */             try {
/* 262 */               if (this.table == buffers) {
/*     */                 
/* 264 */                 Buffer[] arrayOfBuffer = new Buffer[1];
/* 265 */                 arrayOfBuffer[0] = create(e);
/* 266 */                 this.table = (Buffer<E>[])arrayOfBuffer;
/* 267 */                 init = true;
/*     */               } 
/*     */             } finally {
/* 270 */               this.tableBusy = 0;
/*     */             } 
/* 272 */             if (init)
/*     */               break; 
/*     */           } 
/*     */           continue; }
/*     */       
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */       h = advanceProbe(h);
/*     */       attempt++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\StripedBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */