/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PDAWMW<K, V>
/*    */   extends PDAW<K, V>
/*    */ {
/*    */   int queueType;
/*    */   int weight;
/*    */   int policyWeight;
/*    */   
/*    */   PDAWMW() {}
/*    */   
/*    */   PDAWMW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 50 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/* 51 */     this.weight = weight;
/*    */   }
/*    */ 
/*    */   
/*    */   PDAWMW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 56 */     super(keyReference, value, valueReferenceQueue, weight, now);
/* 57 */     this.weight = weight;
/*    */   }
/*    */   
/*    */   public int getQueueType() {
/* 61 */     return this.queueType;
/*    */   }
/*    */   
/*    */   public void setQueueType(int queueType) {
/* 65 */     this.queueType = queueType;
/*    */   }
/*    */   
/*    */   public int getWeight() {
/* 69 */     return this.weight;
/*    */   }
/*    */   
/*    */   public void setWeight(int weight) {
/* 73 */     this.weight = weight;
/*    */   }
/*    */   
/*    */   public int getPolicyWeight() {
/* 77 */     return this.policyWeight;
/*    */   }
/*    */   
/*    */   public void setPolicyWeight(int policyWeight) {
/* 81 */     this.policyWeight = policyWeight;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 91 */     return new PDAWMW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 96 */     return new PDAWMW(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PDAWMW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */