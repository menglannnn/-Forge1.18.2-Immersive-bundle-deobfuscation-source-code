/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PSAW<K, V>
/*     */   extends PSA<K, V>
/*     */ {
/*  35 */   protected static final long WRITE_TIME_OFFSET = UnsafeAccess.objectFieldOffset(PSAW.class, "writeTime");
/*     */ 
/*     */   
/*     */   volatile long writeTime;
/*     */ 
/*     */   
/*     */   Node<K, V> previousInWriteOrder;
/*     */ 
/*     */   
/*     */   Node<K, V> nextInWriteOrder;
/*     */ 
/*     */ 
/*     */   
/*     */   PSAW() {}
/*     */ 
/*     */ 
/*     */   
/*     */   PSAW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  53 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*  54 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, now);
/*     */   }
/*     */   
/*     */   PSAW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  58 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*  59 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, now);
/*     */   }
/*     */   
/*     */   public Node<K, V> getPreviousInVariableOrder() {
/*  63 */     return this.previousInWriteOrder;
/*     */   }
/*     */   
/*     */   public void setPreviousInVariableOrder(Node<K, V> previousInWriteOrder) {
/*  67 */     this.previousInWriteOrder = previousInWriteOrder;
/*     */   }
/*     */   
/*     */   public Node<K, V> getNextInVariableOrder() {
/*  71 */     return this.nextInWriteOrder;
/*     */   }
/*     */   
/*     */   public void setNextInVariableOrder(Node<K, V> nextInWriteOrder) {
/*  75 */     this.nextInWriteOrder = nextInWriteOrder;
/*     */   }
/*     */   
/*     */   public long getVariableTime() {
/*  79 */     return UnsafeAccess.UNSAFE.getLong(this, WRITE_TIME_OFFSET);
/*     */   }
/*     */   
/*     */   public void setVariableTime(long writeTime) {
/*  83 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, writeTime);
/*     */   }
/*     */   
/*     */   public boolean casVariableTime(long expect, long update) {
/*  87 */     return (this.writeTime == expect && UnsafeAccess.UNSAFE
/*  88 */       .compareAndSwapLong(this, WRITE_TIME_OFFSET, expect, update));
/*     */   }
/*     */   
/*     */   public final long getWriteTime() {
/*  92 */     return UnsafeAccess.UNSAFE.getLong(this, WRITE_TIME_OFFSET);
/*     */   }
/*     */   
/*     */   public final void setWriteTime(long writeTime) {
/*  96 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, writeTime);
/*     */   }
/*     */   
/*     */   public final Node<K, V> getPreviousInWriteOrder() {
/* 100 */     return this.previousInWriteOrder;
/*     */   }
/*     */   
/*     */   public final void setPreviousInWriteOrder(Node<K, V> previousInWriteOrder) {
/* 104 */     this.previousInWriteOrder = previousInWriteOrder;
/*     */   }
/*     */   
/*     */   public final Node<K, V> getNextInWriteOrder() {
/* 108 */     return this.nextInWriteOrder;
/*     */   }
/*     */   
/*     */   public final void setNextInWriteOrder(Node<K, V> nextInWriteOrder) {
/* 112 */     this.nextInWriteOrder = nextInWriteOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 122 */     return new PSAW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 127 */     return new PSAW(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PSAW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */