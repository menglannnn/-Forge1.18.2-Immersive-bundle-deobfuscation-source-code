/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WISW<K, V>
/*    */   extends WIS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   final WriteOrderDeque<Node<K, V>> writeOrderDeque;
/*    */   volatile long expiresAfterWriteNanos;
/*    */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*    */   final Pacer pacer;
/*    */   
/*    */   WISW(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 43 */     super(builder, cacheLoader, async);
/* 44 */     this.ticker = builder.getTicker();
/* 45 */     this.writeOrderDeque = new WriteOrderDeque<>();
/* 46 */     this.expiresAfterWriteNanos = builder.getExpiresAfterWriteNanos();
/* 47 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/* 48 */     this
/*    */ 
/*    */       
/* 51 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*    */   }
/*    */   
/*    */   public final Ticker expirationTicker() {
/* 55 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected final WriteOrderDeque<Node<K, V>> writeOrderDeque() {
/* 59 */     return this.writeOrderDeque;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterWrite() {
/* 63 */     return true;
/*    */   }
/*    */   
/*    */   protected final long expiresAfterWriteNanos() {
/* 67 */     return this.expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterWriteNanos(long expiresAfterWriteNanos) {
/* 71 */     this.expiresAfterWriteNanos = expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected final MpscGrowableArrayQueue<Runnable> writeBuffer() {
/* 75 */     return this.writeBuffer;
/*    */   }
/*    */   
/*    */   protected final boolean buffersWrites() {
/* 79 */     return true;
/*    */   }
/*    */   
/*    */   public final Pacer pacer() {
/* 83 */     return this.pacer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\WISW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */