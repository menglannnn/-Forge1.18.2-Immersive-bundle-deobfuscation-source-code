/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.CompletionException;
/*     */ import java.util.function.Function;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface LocalLoadingCache<K, V>
/*     */   extends LocalManualCache<K, V>, LoadingCache<K, V>
/*     */ {
/*  41 */   public static final Logger logger = Logger.getLogger(LocalLoadingCache.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default V get(K key) {
/*  54 */     return cache().computeIfAbsent(key, mappingFunction());
/*     */   }
/*     */ 
/*     */   
/*     */   default Map<K, V> getAll(Iterable<? extends K> keys) {
/*  59 */     Function<Iterable<? extends K>, Map<K, V>> mappingFunction = bulkMappingFunction();
/*  60 */     return (mappingFunction == null) ? 
/*  61 */       loadSequentially(keys) : 
/*  62 */       getAll(keys, mappingFunction);
/*     */   }
/*     */ 
/*     */   
/*     */   default Map<K, V> loadSequentially(Iterable<? extends K> keys) {
/*  67 */     Set<K> uniqueKeys = new LinkedHashSet<>();
/*  68 */     for (K key : keys) {
/*  69 */       uniqueKeys.add(key);
/*     */     }
/*     */     
/*  72 */     int count = 0;
/*  73 */     Map<K, V> result = new LinkedHashMap<>(uniqueKeys.size());
/*     */     try {
/*  75 */       for (K key : uniqueKeys) {
/*  76 */         count++;
/*     */         
/*  78 */         V value = get(key);
/*  79 */         if (value != null) {
/*  80 */           result.put(key, value);
/*     */         }
/*     */       } 
/*  83 */     } catch (Throwable t) {
/*  84 */       cache().statsCounter().recordMisses(uniqueKeys.size() - count);
/*  85 */       throw t;
/*     */     } 
/*  87 */     return Collections.unmodifiableMap(result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default void refresh(K key) {
/*  93 */     Objects.requireNonNull(key);
/*     */     
/*  95 */     long[] writeTime = new long[1];
/*  96 */     long startTime = cache().statsTicker().read();
/*  97 */     V oldValue = cache().getIfPresentQuietly(key, writeTime);
/*     */ 
/*     */     
/* 100 */     CompletableFuture<V> refreshFuture = (oldValue == null) ? cacheLoader().asyncLoad(key, cache().executor()) : cacheLoader().asyncReload(key, oldValue, cache().executor());
/* 101 */     refreshFuture.whenComplete((newValue, error) -> {
/*     */           long loadTime = cache().statsTicker().read() - startTime;
/*     */           if (error != null) {
/*     */             logger.log(Level.WARNING, "Exception thrown during refresh", error);
/*     */             cache().statsCounter().recordLoadFailure(loadTime);
/*     */             return;
/*     */           } 
/*     */           boolean[] discard = new boolean[1];
/*     */           cache().compute((K)key, (), false, false, true);
/*     */           if (discard[0] && cache().hasRemovalListener()) {
/*     */             cache().notifyRemoval((K)key, (V)newValue, RemovalCause.REPLACED);
/*     */           }
/*     */           if (newValue == null) {
/*     */             cache().statsCounter().recordLoadFailure(loadTime);
/*     */           } else {
/*     */             cache().statsCounter().recordLoadSuccess(loadTime);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <K, V> Function<K, V> newMappingFunction(CacheLoader<? super K, V> cacheLoader) {
/* 139 */     return key -> {
/*     */         try {
/*     */           return cacheLoader.load(key);
/* 142 */         } catch (RuntimeException e) {
/*     */           throw e;
/* 144 */         } catch (InterruptedException e) {
/*     */           Thread.currentThread().interrupt();
/*     */           throw new CompletionException(e);
/* 147 */         } catch (Exception e) {
/*     */           throw new CompletionException(e);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <K, V> Function<Iterable<? extends K>, Map<K, V>> newBulkMappingFunction(CacheLoader<? super K, V> cacheLoader) {
/* 156 */     if (!hasLoadAll(cacheLoader)) {
/* 157 */       return null;
/*     */     }
/* 159 */     return keysToLoad -> {
/*     */ 
/*     */         
/*     */         try {
/*     */           return cacheLoader.loadAll(keysToLoad);
/* 164 */         } catch (RuntimeException e) {
/*     */           throw e;
/* 166 */         } catch (InterruptedException e) {
/*     */           Thread.currentThread().interrupt();
/*     */           throw new CompletionException(e);
/* 169 */         } catch (Exception e) {
/*     */           throw new CompletionException(e);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean hasLoadAll(CacheLoader<?, ?> loader) {
/*     */     try {
/* 178 */       Method classLoadAll = loader.getClass().getMethod("loadAll", new Class[] { Iterable.class });
/* 179 */       Method defaultLoadAll = CacheLoader.class.getMethod("loadAll", new Class[] { Iterable.class });
/* 180 */       return !classLoadAll.equals(defaultLoadAll);
/* 181 */     } catch (NoSuchMethodException|SecurityException e) {
/* 182 */       logger.log(Level.WARNING, "Cannot determine if CacheLoader can bulk load", e);
/* 183 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   CacheLoader<? super K, V> cacheLoader();
/*     */   
/*     */   Function<K, V> mappingFunction();
/*     */   
/*     */   Function<Iterable<? extends K>, Map<K, V>> bulkMappingFunction();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\LocalLoadingCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */