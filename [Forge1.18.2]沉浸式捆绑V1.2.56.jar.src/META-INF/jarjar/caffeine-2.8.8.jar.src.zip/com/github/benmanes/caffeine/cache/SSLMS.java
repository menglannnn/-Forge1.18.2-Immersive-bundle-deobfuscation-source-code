/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSLMS<K, V>
/*     */   extends SSL<K, V>
/*     */ {
/*     */   long maximum;
/*     */   long weightedSize;
/*     */   long windowMaximum;
/*     */   long windowWeightedSize;
/*     */   long mainProtectedMaximum;
/*     */   long mainProtectedWeightedSize;
/*     */   double stepSize;
/*     */   long adjustment;
/*     */   int hitsInSample;
/*     */   int missesInSample;
/*     */   double previousSampleHitRate;
/*     */   final FrequencySketch<K> sketch;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderProbationDeque;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderProtectedDeque;
/*     */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*     */   
/*     */   SSLMS(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/*  65 */     super(builder, cacheLoader, async);
/*  66 */     this.sketch = new FrequencySketch<>();
/*  67 */     if (builder.hasInitialCapacity()) {
/*  68 */       long capacity = Math.min(builder.getMaximum(), builder.getInitialCapacity());
/*  69 */       this.sketch.ensureCapacity(capacity);
/*     */     } 
/*  71 */     this
/*     */ 
/*     */       
/*  74 */       .accessOrderWindowDeque = (builder.evicts() || builder.expiresAfterAccess()) ? new AccessOrderDeque<>() : null;
/*  75 */     this.accessOrderProbationDeque = new AccessOrderDeque<>();
/*  76 */     this.accessOrderProtectedDeque = new AccessOrderDeque<>();
/*  77 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*     */   }
/*     */   
/*     */   protected final boolean evicts() {
/*  81 */     return true;
/*     */   }
/*     */   
/*     */   protected final long maximum() {
/*  85 */     return this.maximum;
/*     */   }
/*     */   
/*     */   protected final void setMaximum(long maximum) {
/*  89 */     this.maximum = maximum;
/*     */   }
/*     */   
/*     */   protected final long weightedSize() {
/*  93 */     return this.weightedSize;
/*     */   }
/*     */   
/*     */   protected final void setWeightedSize(long weightedSize) {
/*  97 */     this.weightedSize = weightedSize;
/*     */   }
/*     */   
/*     */   protected final long windowMaximum() {
/* 101 */     return this.windowMaximum;
/*     */   }
/*     */   
/*     */   protected final void setWindowMaximum(long windowMaximum) {
/* 105 */     this.windowMaximum = windowMaximum;
/*     */   }
/*     */   
/*     */   protected final long windowWeightedSize() {
/* 109 */     return this.windowWeightedSize;
/*     */   }
/*     */   
/*     */   protected final void setWindowWeightedSize(long windowWeightedSize) {
/* 113 */     this.windowWeightedSize = windowWeightedSize;
/*     */   }
/*     */   
/*     */   protected final long mainProtectedMaximum() {
/* 117 */     return this.mainProtectedMaximum;
/*     */   }
/*     */   
/*     */   protected final void setMainProtectedMaximum(long mainProtectedMaximum) {
/* 121 */     this.mainProtectedMaximum = mainProtectedMaximum;
/*     */   }
/*     */   
/*     */   protected final long mainProtectedWeightedSize() {
/* 125 */     return this.mainProtectedWeightedSize;
/*     */   }
/*     */   
/*     */   protected final void setMainProtectedWeightedSize(long mainProtectedWeightedSize) {
/* 129 */     this.mainProtectedWeightedSize = mainProtectedWeightedSize;
/*     */   }
/*     */   
/*     */   protected final double stepSize() {
/* 133 */     return this.stepSize;
/*     */   }
/*     */   
/*     */   protected final void setStepSize(double stepSize) {
/* 137 */     this.stepSize = stepSize;
/*     */   }
/*     */   
/*     */   protected final long adjustment() {
/* 141 */     return this.adjustment;
/*     */   }
/*     */   
/*     */   protected final void setAdjustment(long adjustment) {
/* 145 */     this.adjustment = adjustment;
/*     */   }
/*     */   
/*     */   protected final int hitsInSample() {
/* 149 */     return this.hitsInSample;
/*     */   }
/*     */   
/*     */   protected final void setHitsInSample(int hitsInSample) {
/* 153 */     this.hitsInSample = hitsInSample;
/*     */   }
/*     */   
/*     */   protected final int missesInSample() {
/* 157 */     return this.missesInSample;
/*     */   }
/*     */   
/*     */   protected final void setMissesInSample(int missesInSample) {
/* 161 */     this.missesInSample = missesInSample;
/*     */   }
/*     */   
/*     */   protected final double previousSampleHitRate() {
/* 165 */     return this.previousSampleHitRate;
/*     */   }
/*     */   
/*     */   protected final void setPreviousSampleHitRate(double previousSampleHitRate) {
/* 169 */     this.previousSampleHitRate = previousSampleHitRate;
/*     */   }
/*     */   
/*     */   protected final FrequencySketch<K> frequencySketch() {
/* 173 */     return this.sketch;
/*     */   }
/*     */   
/*     */   protected boolean fastpath() {
/* 177 */     return true;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque() {
/* 181 */     return this.accessOrderWindowDeque;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderProbationDeque() {
/* 185 */     return this.accessOrderProbationDeque;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderProtectedDeque() {
/* 189 */     return this.accessOrderProtectedDeque;
/*     */   }
/*     */   
/*     */   protected final MpscGrowableArrayQueue<Runnable> writeBuffer() {
/* 193 */     return this.writeBuffer;
/*     */   }
/*     */   
/*     */   protected final boolean buffersWrites() {
/* 197 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSLMS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */