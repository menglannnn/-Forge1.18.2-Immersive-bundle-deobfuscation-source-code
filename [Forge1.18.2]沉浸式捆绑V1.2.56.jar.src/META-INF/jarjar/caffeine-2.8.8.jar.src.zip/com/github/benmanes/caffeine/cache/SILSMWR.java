/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SILSMWR<K, V>
/*    */   extends SILSMW<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   volatile long refreshAfterWriteNanos;
/*    */   
/*    */   SILSMWR(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 39 */     super(builder, cacheLoader, async);
/* 40 */     this.ticker = builder.getTicker();
/* 41 */     this.refreshAfterWriteNanos = builder.getRefreshAfterWriteNanos();
/*    */   }
/*    */   
/*    */   public Ticker expirationTicker() {
/* 45 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected boolean refreshAfterWrite() {
/* 49 */     return true;
/*    */   }
/*    */   
/*    */   protected long refreshAfterWriteNanos() {
/* 53 */     return this.refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/* 57 */     this.refreshAfterWriteNanos = refreshAfterWriteNanos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SILSMWR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */