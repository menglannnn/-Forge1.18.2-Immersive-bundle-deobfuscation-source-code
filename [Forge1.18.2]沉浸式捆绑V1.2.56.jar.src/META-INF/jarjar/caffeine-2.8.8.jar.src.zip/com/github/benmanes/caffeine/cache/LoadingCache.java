package com.github.benmanes.caffeine.cache;

import java.util.Map;

public interface LoadingCache<K, V> extends Cache<K, V> {
  V get(K paramK);
  
  Map<K, V> getAll(Iterable<? extends K> paramIterable);
  
  void refresh(K paramK);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\LoadingCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */