/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.function.Function;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class LocalAsyncLoadingCache<K, V>
/*     */   implements LocalAsyncCache<K, V>, AsyncLoadingCache<K, V>
/*     */ {
/*  39 */   static final Logger logger = Logger.getLogger(LocalAsyncLoadingCache.class.getName());
/*     */   
/*     */   final boolean canBulkLoad;
/*     */   
/*     */   final AsyncCacheLoader<K, V> loader;
/*     */   
/*     */   LoadingCacheView<K, V> cacheView;
/*     */   
/*     */   LocalAsyncLoadingCache(AsyncCacheLoader<? super K, V> loader) {
/*  48 */     this.loader = (AsyncCacheLoader)loader;
/*  49 */     this.canBulkLoad = canBulkLoad(loader);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean canBulkLoad(AsyncCacheLoader<?, ?> loader) {
/*     */     try {
/*  55 */       Class<?> defaultLoaderClass = AsyncCacheLoader.class;
/*  56 */       if (loader instanceof CacheLoader) {
/*  57 */         defaultLoaderClass = CacheLoader.class;
/*     */         
/*  59 */         Method classLoadAll = loader.getClass().getMethod("loadAll", new Class[] { Iterable.class });
/*  60 */         Method defaultLoadAll = CacheLoader.class.getMethod("loadAll", new Class[] { Iterable.class });
/*  61 */         if (!classLoadAll.equals(defaultLoadAll)) {
/*  62 */           return true;
/*     */         }
/*     */       } 
/*     */       
/*  66 */       Method classAsyncLoadAll = loader.getClass().getMethod("asyncLoadAll", new Class[] { Iterable.class, Executor.class });
/*     */       
/*  68 */       Method defaultAsyncLoadAll = defaultLoaderClass.getMethod("asyncLoadAll", new Class[] { Iterable.class, Executor.class });
/*     */       
/*  70 */       return !classAsyncLoadAll.equals(defaultAsyncLoadAll);
/*  71 */     } catch (NoSuchMethodException|SecurityException e) {
/*  72 */       logger.log(Level.WARNING, "Cannot determine if CacheLoader can bulk load", e);
/*  73 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<V> get(K key) {
/*  79 */     Objects.requireNonNull(this.loader); return get(key, this.loader::asyncLoad);
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<Map<K, V>> getAll(Iterable<? extends K> keys) {
/*  84 */     if (this.canBulkLoad) {
/*  85 */       Objects.requireNonNull(this.loader); return getAll(keys, this.loader::asyncLoadAll);
/*     */     } 
/*     */     
/*  88 */     Map<K, CompletableFuture<V>> result = new LinkedHashMap<>();
/*  89 */     Function<K, CompletableFuture<V>> mappingFunction = this::get;
/*  90 */     for (K key : keys) {
/*  91 */       CompletableFuture<V> future = result.computeIfAbsent(key, mappingFunction);
/*  92 */       Objects.requireNonNull(future);
/*     */     } 
/*  94 */     return composeResult(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public LoadingCache<K, V> synchronous() {
/*  99 */     return (this.cacheView == null) ? (this.cacheView = new LoadingCacheView<>(this)) : this.cacheView;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class LoadingCacheView<K, V>
/*     */     extends LocalAsyncCache.AbstractCacheView<K, V>
/*     */     implements LoadingCache<K, V>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     final LocalAsyncLoadingCache<K, V> asyncCache;
/*     */     
/*     */     LoadingCacheView(LocalAsyncLoadingCache<K, V> asyncCache) {
/* 111 */       this.asyncCache = Objects.<LocalAsyncLoadingCache<K, V>>requireNonNull(asyncCache);
/*     */     }
/*     */ 
/*     */     
/*     */     LocalAsyncLoadingCache<K, V> asyncCache() {
/* 116 */       return this.asyncCache;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public V get(K key) {
/* 122 */       return (V)resolve(this.asyncCache.get(key));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<K, V> getAll(Iterable<? extends K> keys) {
/* 128 */       return (Map<K, V>)resolve(this.asyncCache.getAll(keys));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void refresh(K key) {
/* 134 */       Objects.requireNonNull(key);
/*     */       
/* 136 */       long[] writeTime = new long[1];
/* 137 */       CompletableFuture<V> oldValueFuture = (CompletableFuture<V>)this.asyncCache.cache().getIfPresentQuietly(key, writeTime);
/* 138 */       if (oldValueFuture == null || (oldValueFuture
/* 139 */         .isDone() && oldValueFuture.isCompletedExceptionally())) {
/* 140 */         Objects.requireNonNull(this.asyncCache.loader); this.asyncCache.get(key, this.asyncCache.loader::asyncLoad, false); return;
/*     */       } 
/* 142 */       if (!oldValueFuture.isDone()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 147 */       oldValueFuture.thenAccept(oldValue -> {
/*     */             long now = this.asyncCache.cache().statsTicker().read();
/*     */             CompletableFuture<V> refreshFuture = (oldValue == null) ? this.asyncCache.loader.asyncLoad((K)key, this.asyncCache.cache().executor()) : this.asyncCache.loader.asyncReload((K)key, (V)oldValue, this.asyncCache.cache().executor());
/*     */             refreshFuture.whenComplete(());
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\LocalAsyncLoadingCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */