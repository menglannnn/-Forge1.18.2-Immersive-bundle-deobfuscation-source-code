package com.github.benmanes.caffeine.cache;

abstract class BaseMpscLinkedArrayQueueProducerFields<E> extends BaseMpscLinkedArrayQueuePad1<E> {
  protected long producerIndex;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\BaseMpscLinkedArrayQueueProducerFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */