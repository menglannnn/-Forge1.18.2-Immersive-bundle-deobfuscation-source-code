/*      */ package com.github.benmanes.caffeine.cache;
/*      */ 
/*      */ import com.github.benmanes.caffeine.cache.stats.CacheStats;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.concurrent.CompletionException;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Function;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ interface LocalAsyncCache<K, V>
/*      */   extends AsyncCache<K, V>
/*      */ {
/*   58 */   public static final Logger logger = Logger.getLogger(LocalAsyncCache.class.getName());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default CompletableFuture<V> getIfPresent(Object key) {
/*   68 */     return cache().getIfPresent(key, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   default CompletableFuture<V> get(K key, Function<? super K, ? extends V> mappingFunction) {
/*   74 */     Objects.requireNonNull(mappingFunction);
/*   75 */     return get(key, (k1, executor) -> CompletableFuture.supplyAsync((), executor));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default CompletableFuture<V> get(K key, BiFunction<? super K, Executor, CompletableFuture<V>> mappingFunction) {
/*   82 */     return get(key, mappingFunction, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   default CompletableFuture<V> get(K key, BiFunction<? super K, Executor, CompletableFuture<V>> mappingFunction, boolean recordStats) {
/*   88 */     long startTime = cache().statsTicker().read();
/*      */     
/*   90 */     CompletableFuture[] arrayOfCompletableFuture = new CompletableFuture[1];
/*   91 */     CompletableFuture<V> future = cache().computeIfAbsent(key, k -> { result[0] = mappingFunction.apply(key, cache().executor()); return Objects.<CompletableFuture>requireNonNull(result[0]); }recordStats, false);
/*      */ 
/*      */ 
/*      */     
/*   95 */     if (arrayOfCompletableFuture[0] != null) {
/*   96 */       handleCompletion(key, arrayOfCompletableFuture[0], startTime, false);
/*      */     }
/*   98 */     return future;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   default CompletableFuture<Map<K, V>> getAll(Iterable<? extends K> keys, Function<Iterable<? extends K>, Map<K, V>> mappingFunction) {
/*  104 */     Objects.requireNonNull(mappingFunction);
/*  105 */     return getAll(keys, (keysToLoad, executor) -> CompletableFuture.supplyAsync((), executor));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default CompletableFuture<Map<K, V>> getAll(Iterable<? extends K> keys, BiFunction<Iterable<? extends K>, Executor, CompletableFuture<Map<K, V>>> mappingFunction) {
/*  113 */     Objects.requireNonNull(mappingFunction);
/*  114 */     Objects.requireNonNull(keys);
/*      */     
/*  116 */     Map<K, CompletableFuture<V>> futures = new LinkedHashMap<>();
/*  117 */     Map<K, CompletableFuture<V>> proxies = new HashMap<>();
/*  118 */     for (K key : keys) {
/*  119 */       if (futures.containsKey(key)) {
/*      */         continue;
/*      */       }
/*  122 */       CompletableFuture<V> future = cache().getIfPresent(key, false);
/*  123 */       if (future == null) {
/*  124 */         CompletableFuture<V> proxy = new CompletableFuture<>();
/*  125 */         future = cache().putIfAbsent(key, proxy);
/*  126 */         if (future == null) {
/*  127 */           future = proxy;
/*  128 */           proxies.put(key, proxy);
/*      */         } 
/*      */       } 
/*  131 */       futures.put(key, future);
/*      */     } 
/*  133 */     cache().statsCounter().recordMisses(proxies.size());
/*  134 */     cache().statsCounter().recordHits(futures.size() - proxies.size());
/*  135 */     if (proxies.isEmpty()) {
/*  136 */       return composeResult(futures);
/*      */     }
/*      */     
/*  139 */     AsyncBulkCompleter<K, V> completer = new AsyncBulkCompleter<>(cache(), proxies);
/*      */     try {
/*  141 */       ((CompletableFuture<K>)mappingFunction.apply(proxies.keySet(), cache().executor())).whenComplete((BiConsumer)completer);
/*  142 */       return composeResult(futures);
/*  143 */     } catch (Throwable t) {
/*  144 */       completer.accept((Map<K, V>)null, t);
/*  145 */       throw t;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default CompletableFuture<Map<K, V>> composeResult(Map<K, CompletableFuture<V>> futures) {
/*  155 */     if (futures.isEmpty()) {
/*  156 */       return CompletableFuture.completedFuture(Collections.emptyMap());
/*      */     }
/*      */     
/*  159 */     CompletableFuture[] arrayOfCompletableFuture = (CompletableFuture[])futures.values().toArray((Object[])new CompletableFuture[0]);
/*  160 */     return CompletableFuture.allOf((CompletableFuture<?>[])arrayOfCompletableFuture).thenApply(ignored -> {
/*      */           Map<K, V> result = new LinkedHashMap<>(futures.size());
/*      */           futures.forEach(());
/*      */           return Collections.unmodifiableMap(result);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default void put(K key, CompletableFuture<V> valueFuture) {
/*  175 */     if (valueFuture.isCompletedExceptionally() || (valueFuture
/*  176 */       .isDone() && valueFuture.join() == null)) {
/*  177 */       cache().statsCounter().recordLoadFailure(0L);
/*  178 */       cache().remove(key);
/*      */       return;
/*      */     } 
/*  181 */     long startTime = cache().statsTicker().read();
/*  182 */     cache().put(key, valueFuture);
/*  183 */     handleCompletion(key, valueFuture, startTime, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   default void handleCompletion(K key, CompletableFuture<V> valueFuture, long startTime, boolean recordMiss) {
/*  189 */     AtomicBoolean completed = new AtomicBoolean();
/*  190 */     valueFuture.whenComplete((value, error) -> {
/*      */           if (!completed.compareAndSet(false, true)) {
/*      */             return;
/*      */           }
/*      */           long loadTime = cache().statsTicker().read() - startTime;
/*      */           if (value == null) {
/*      */             if (error != null) {
/*      */               logger.log(Level.WARNING, "Exception thrown during asynchronous load", error);
/*      */             }
/*      */             cache().remove(key, valueFuture);
/*      */             cache().statsCounter().recordLoadFailure(loadTime);
/*      */             if (recordMiss)
/*      */               cache().statsCounter().recordMisses(1); 
/*      */           } else {
/*      */             cache().replace((K)key, valueFuture, valueFuture);
/*      */             cache().statsCounter().recordLoadSuccess(loadTime);
/*      */             if (recordMiss)
/*      */               cache().statsCounter().recordMisses(1); 
/*      */           } 
/*      */         });
/*      */   }
/*      */   
/*      */   LocalCache<K, CompletableFuture<V>> cache();
/*      */   
/*      */   Policy<K, V> policy();
/*      */   
/*      */   public static final class AsyncBulkCompleter<K, V>
/*      */     implements BiConsumer<Map<K, V>, Throwable>
/*      */   {
/*      */     private final LocalCache<K, CompletableFuture<V>> cache;
/*      */     private final Map<K, CompletableFuture<V>> proxies;
/*      */     private final long startTime;
/*      */     
/*      */     AsyncBulkCompleter(LocalCache<K, CompletableFuture<V>> cache, Map<K, CompletableFuture<V>> proxies) {
/*  224 */       this.startTime = cache.statsTicker().read();
/*  225 */       this.proxies = proxies;
/*  226 */       this.cache = cache;
/*      */     }
/*      */ 
/*      */     
/*      */     public void accept(Map<K, V> result, Throwable error) {
/*  231 */       long loadTime = this.cache.statsTicker().read() - this.startTime;
/*      */       
/*  233 */       if (result == null) {
/*  234 */         if (error == null) {
/*  235 */           error = new NullMapCompletionException();
/*      */         }
/*  237 */         for (Map.Entry<K, CompletableFuture<V>> entry : this.proxies.entrySet()) {
/*  238 */           this.cache.remove(entry.getKey(), entry.getValue());
/*  239 */           ((CompletableFuture)entry.getValue()).obtrudeException(error);
/*      */         } 
/*  241 */         this.cache.statsCounter().recordLoadFailure(loadTime);
/*  242 */         LocalAsyncCache.logger.log(Level.WARNING, "Exception thrown during asynchronous load", error);
/*      */       } else {
/*  244 */         fillProxies(result);
/*  245 */         addNewEntries(result);
/*  246 */         this.cache.statsCounter().recordLoadSuccess(loadTime);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void fillProxies(Map<K, V> result) {
/*  252 */       this.proxies.forEach((key, future) -> {
/*      */             V value = (V)result.get(key);
/*      */             future.obtrudeValue(value);
/*      */             if (value == null) {
/*      */               this.cache.remove(key, future);
/*      */             } else {
/*      */               this.cache.replace((K)key, future, future);
/*      */             } 
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void addNewEntries(Map<K, V> result) {
/*  266 */       if (this.proxies.size() == result.size()) {
/*      */         return;
/*      */       }
/*  269 */       result.forEach((key, value) -> {
/*      */             if (!this.proxies.containsKey(key))
/*      */               this.cache.put((K)key, CompletableFuture.completedFuture((V)value)); 
/*      */           });
/*      */     }
/*      */     
/*      */     static final class NullMapCompletionException
/*      */       extends CompletionException {
/*      */       private static final long serialVersionUID = 1L;
/*      */       
/*      */       public NullMapCompletionException() {
/*  280 */         super("null map", null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static final class AsyncAsMapView<K, V>
/*      */     implements ConcurrentMap<K, CompletableFuture<V>> {
/*      */     final LocalAsyncCache<K, V> asyncCache;
/*      */     
/*      */     AsyncAsMapView(LocalAsyncCache<K, V> asyncCache) {
/*  290 */       this.asyncCache = Objects.<LocalAsyncCache<K, V>>requireNonNull(asyncCache);
/*      */     }
/*      */     public boolean isEmpty() {
/*  293 */       return this.asyncCache.cache().isEmpty();
/*      */     }
/*      */     public int size() {
/*  296 */       return this.asyncCache.cache().size();
/*      */     }
/*      */     public void clear() {
/*  299 */       this.asyncCache.cache().clear();
/*      */     }
/*      */     public boolean containsKey(Object key) {
/*  302 */       return this.asyncCache.cache().containsKey(key);
/*      */     }
/*      */     public boolean containsValue(Object value) {
/*  305 */       return this.asyncCache.cache().containsValue(value);
/*      */     }
/*      */     public CompletableFuture<V> get(Object key) {
/*  308 */       return (CompletableFuture<V>)this.asyncCache.cache().get(key);
/*      */     }
/*      */     public CompletableFuture<V> putIfAbsent(K key, CompletableFuture<V> value) {
/*  311 */       CompletableFuture<V> prior = this.asyncCache.cache().putIfAbsent(key, value);
/*  312 */       long startTime = this.asyncCache.cache().statsTicker().read();
/*  313 */       if (prior == null) {
/*  314 */         this.asyncCache.handleCompletion(key, value, startTime, false);
/*      */       }
/*  316 */       return prior;
/*      */     }
/*      */     public CompletableFuture<V> put(K key, CompletableFuture<V> value) {
/*  319 */       CompletableFuture<V> prior = this.asyncCache.cache().put(key, value);
/*  320 */       long startTime = this.asyncCache.cache().statsTicker().read();
/*  321 */       this.asyncCache.handleCompletion(key, value, startTime, false);
/*  322 */       return prior;
/*      */     }
/*      */     
/*      */     public void putAll(Map<? extends K, ? extends CompletableFuture<V>> map) {
/*  326 */       map.forEach(this::put);
/*      */     }
/*      */     public CompletableFuture<V> replace(K key, CompletableFuture<V> value) {
/*  329 */       CompletableFuture<V> prior = this.asyncCache.cache().replace(key, value);
/*  330 */       long startTime = this.asyncCache.cache().statsTicker().read();
/*  331 */       if (prior != null) {
/*  332 */         this.asyncCache.handleCompletion(key, value, startTime, false);
/*      */       }
/*  334 */       return prior;
/*      */     }
/*      */     
/*      */     public boolean replace(K key, CompletableFuture<V> oldValue, CompletableFuture<V> newValue) {
/*  338 */       boolean replaced = this.asyncCache.cache().replace(key, oldValue, newValue);
/*  339 */       long startTime = this.asyncCache.cache().statsTicker().read();
/*  340 */       if (replaced) {
/*  341 */         this.asyncCache.handleCompletion(key, newValue, startTime, false);
/*      */       }
/*  343 */       return replaced;
/*      */     }
/*      */     public CompletableFuture<V> remove(Object key) {
/*  346 */       return (CompletableFuture<V>)this.asyncCache.cache().remove(key);
/*      */     }
/*      */     public boolean remove(Object key, Object value) {
/*  349 */       return this.asyncCache.cache().remove(key, value);
/*      */     }
/*      */ 
/*      */     
/*      */     public CompletableFuture<V> computeIfAbsent(K key, Function<? super K, ? extends CompletableFuture<V>> mappingFunction) {
/*  354 */       Objects.requireNonNull(mappingFunction);
/*      */       
/*  356 */       CompletableFuture[] arrayOfCompletableFuture = new CompletableFuture[1];
/*  357 */       long startTime = this.asyncCache.cache().statsTicker().read();
/*  358 */       CompletableFuture<V> future = this.asyncCache.cache().computeIfAbsent(key, k -> { result[0] = mappingFunction.apply(k); return result[0]; }false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  363 */       if (arrayOfCompletableFuture[0] == null) {
/*  364 */         if (future != null && this.asyncCache.cache().isRecordingStats()) {
/*  365 */           future.whenComplete((r, e) -> {
/*      */                 if (r != null || e == null) {
/*      */                   this.asyncCache.cache().statsCounter().recordHits(1);
/*      */                 }
/*      */               });
/*      */         }
/*      */       } else {
/*  372 */         this.asyncCache.handleCompletion(key, arrayOfCompletableFuture[0], startTime, true);
/*      */       } 
/*  374 */       return future;
/*      */     }
/*      */     
/*      */     public CompletableFuture<V> computeIfPresent(K key, BiFunction<? super K, ? super CompletableFuture<V>, ? extends CompletableFuture<V>> remappingFunction) {
/*  378 */       Objects.requireNonNull(remappingFunction);
/*      */ 
/*      */       
/*  381 */       CompletableFuture[] arrayOfCompletableFuture = new CompletableFuture[1];
/*  382 */       long startTime = this.asyncCache.cache().statsTicker().read();
/*  383 */       this.asyncCache.cache().compute(key, (k, oldValue) -> { result[0] = (oldValue == null) ? null : remappingFunction.apply(k, oldValue); return result[0]; }false, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  388 */       if (arrayOfCompletableFuture[0] != null) {
/*  389 */         this.asyncCache.handleCompletion(key, arrayOfCompletableFuture[0], startTime, false);
/*      */       }
/*  391 */       return arrayOfCompletableFuture[0];
/*      */     }
/*      */     
/*      */     public CompletableFuture<V> compute(K key, BiFunction<? super K, ? super CompletableFuture<V>, ? extends CompletableFuture<V>> remappingFunction) {
/*  395 */       Objects.requireNonNull(remappingFunction);
/*      */ 
/*      */       
/*  398 */       CompletableFuture[] arrayOfCompletableFuture = new CompletableFuture[1];
/*  399 */       long startTime = this.asyncCache.cache().statsTicker().read();
/*  400 */       this.asyncCache.cache().compute(key, (k, oldValue) -> { result[0] = remappingFunction.apply(k, oldValue); return result[0]; }false, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  405 */       if (arrayOfCompletableFuture[0] != null) {
/*  406 */         this.asyncCache.handleCompletion(key, arrayOfCompletableFuture[0], startTime, false);
/*      */       }
/*  408 */       return arrayOfCompletableFuture[0];
/*      */     }
/*      */ 
/*      */     
/*      */     public CompletableFuture<V> merge(K key, CompletableFuture<V> value, BiFunction<? super CompletableFuture<V>, ? super CompletableFuture<V>, ? extends CompletableFuture<V>> remappingFunction) {
/*  413 */       Objects.requireNonNull(value);
/*  414 */       Objects.requireNonNull(remappingFunction);
/*      */ 
/*      */       
/*  417 */       CompletableFuture[] arrayOfCompletableFuture = new CompletableFuture[1];
/*  418 */       long startTime = this.asyncCache.cache().statsTicker().read();
/*  419 */       this.asyncCache.cache().compute(key, (k, oldValue) -> { result[0] = (oldValue == null) ? value : remappingFunction.apply(oldValue, value); return result[0]; }false, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  424 */       if (arrayOfCompletableFuture[0] != null) {
/*  425 */         this.asyncCache.handleCompletion(key, arrayOfCompletableFuture[0], startTime, false);
/*      */       }
/*  427 */       return arrayOfCompletableFuture[0];
/*      */     }
/*      */     public Set<K> keySet() {
/*  430 */       return this.asyncCache.cache().keySet();
/*      */     }
/*      */     public Collection<CompletableFuture<V>> values() {
/*  433 */       return this.asyncCache.cache().values();
/*      */     }
/*      */     public Set<Map.Entry<K, CompletableFuture<V>>> entrySet() {
/*  436 */       return this.asyncCache.cache().entrySet();
/*      */     }
/*      */     public boolean equals(Object o) {
/*  439 */       return this.asyncCache.cache().equals(o);
/*      */     }
/*      */     public int hashCode() {
/*  442 */       return this.asyncCache.cache().hashCode();
/*      */     }
/*      */     public String toString() {
/*  445 */       return this.asyncCache.cache().toString();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final class CacheView<K, V>
/*      */     extends AbstractCacheView<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     final LocalAsyncCache<K, V> asyncCache;
/*      */     
/*      */     CacheView(LocalAsyncCache<K, V> asyncCache) {
/*  456 */       this.asyncCache = Objects.<LocalAsyncCache<K, V>>requireNonNull(asyncCache);
/*      */     }
/*      */     LocalAsyncCache<K, V> asyncCache() {
/*  459 */       return this.asyncCache;
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class AbstractCacheView<K, V>
/*      */     implements Cache<K, V>, Serializable
/*      */   {
/*      */     transient LocalAsyncCache.AsMapView<K, V> asMapView;
/*      */     
/*      */     abstract LocalAsyncCache<K, V> asyncCache();
/*      */     
/*      */     public V getIfPresent(Object key) {
/*  471 */       CompletableFuture<V> future = (CompletableFuture<V>)asyncCache().cache().getIfPresent(key, true);
/*  472 */       return Async.getIfReady(future);
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<K, V> getAllPresent(Iterable<?> keys) {
/*  477 */       Set<Object> uniqueKeys = new LinkedHashSet();
/*  478 */       for (Object key : keys) {
/*  479 */         uniqueKeys.add(key);
/*      */       }
/*      */       
/*  482 */       int misses = 0;
/*  483 */       Map<Object, Object> result = new LinkedHashMap<>();
/*  484 */       for (Object key : uniqueKeys) {
/*  485 */         CompletableFuture<V> future = (CompletableFuture<V>)asyncCache().cache().get(key);
/*  486 */         Object value = Async.getIfReady(future);
/*  487 */         if (value == null) {
/*  488 */           misses++; continue;
/*      */         } 
/*  490 */         result.put(key, value);
/*      */       } 
/*      */       
/*  493 */       asyncCache().cache().statsCounter().recordMisses(misses);
/*  494 */       asyncCache().cache().statsCounter().recordHits(result.size());
/*      */ 
/*      */       
/*  497 */       Map<Object, Object> map1 = result;
/*  498 */       return Collections.unmodifiableMap((Map)map1);
/*      */     }
/*      */ 
/*      */     
/*      */     public V get(K key, Function<? super K, ? extends V> mappingFunction) {
/*  503 */       return resolve(asyncCache().get(key, mappingFunction));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<K, V> getAll(Iterable<? extends K> keys, Function<Iterable<? extends K>, Map<K, V>> mappingFunction) {
/*  509 */       return resolve(asyncCache().getAll(keys, mappingFunction));
/*      */     }
/*      */ 
/*      */     
/*      */     protected static <T> T resolve(CompletableFuture<T> future) throws Error {
/*      */       try {
/*  515 */         return future.get();
/*  516 */       } catch (ExecutionException e) {
/*  517 */         if (e.getCause() instanceof LocalAsyncCache.AsyncBulkCompleter.NullMapCompletionException)
/*  518 */           throw new NullPointerException(e.getCause().getMessage()); 
/*  519 */         if (e.getCause() instanceof RuntimeException)
/*  520 */           throw (RuntimeException)e.getCause(); 
/*  521 */         if (e.getCause() instanceof Error) {
/*  522 */           throw (Error)e.getCause();
/*      */         }
/*  524 */         throw new CompletionException(e.getCause());
/*  525 */       } catch (InterruptedException e) {
/*  526 */         throw new CompletionException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void put(K key, V value) {
/*  532 */       Objects.requireNonNull(value);
/*  533 */       asyncCache().cache().put(key, CompletableFuture.completedFuture(value));
/*      */     }
/*      */ 
/*      */     
/*      */     public void putAll(Map<? extends K, ? extends V> map) {
/*  538 */       map.forEach(this::put);
/*      */     }
/*      */ 
/*      */     
/*      */     public void invalidate(Object key) {
/*  543 */       asyncCache().cache().remove(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void invalidateAll(Iterable<?> keys) {
/*  548 */       asyncCache().cache().invalidateAll(keys);
/*      */     }
/*      */ 
/*      */     
/*      */     public void invalidateAll() {
/*  553 */       asyncCache().cache().clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public long estimatedSize() {
/*  558 */       return asyncCache().cache().size();
/*      */     }
/*      */ 
/*      */     
/*      */     public CacheStats stats() {
/*  563 */       return asyncCache().cache().statsCounter().snapshot();
/*      */     }
/*      */ 
/*      */     
/*      */     public void cleanUp() {
/*  568 */       asyncCache().cache().cleanUp();
/*      */     }
/*      */ 
/*      */     
/*      */     public Policy<K, V> policy() {
/*  573 */       return asyncCache().policy();
/*      */     }
/*      */ 
/*      */     
/*      */     public ConcurrentMap<K, V> asMap() {
/*  578 */       return (this.asMapView == null) ? (this.asMapView = new LocalAsyncCache.AsMapView<>(asyncCache().cache())) : this.asMapView;
/*      */     }
/*      */   }
/*      */   
/*      */   public static final class AsMapView<K, V>
/*      */     extends AbstractMap<K, V> implements ConcurrentMap<K, V> {
/*      */     final LocalCache<K, CompletableFuture<V>> delegate;
/*      */     Collection<V> values;
/*      */     Set<Map.Entry<K, V>> entries;
/*      */     
/*      */     AsMapView(LocalCache<K, CompletableFuture<V>> delegate) {
/*  589 */       this.delegate = delegate;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  594 */       return this.delegate.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  599 */       return this.delegate.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/*  604 */       this.delegate.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsKey(Object key) {
/*  609 */       return this.delegate.containsKey(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsValue(Object value) {
/*  614 */       Objects.requireNonNull(value);
/*      */       
/*  616 */       for (CompletableFuture<V> valueFuture : this.delegate.values()) {
/*  617 */         if (value.equals(Async.getIfReady(valueFuture))) {
/*  618 */           return true;
/*      */         }
/*      */       } 
/*  621 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public V get(Object key) {
/*  626 */       return Async.getIfReady(this.delegate.get(key));
/*      */     }
/*      */ 
/*      */     
/*      */     public V putIfAbsent(K key, V value) {
/*  631 */       Objects.requireNonNull(value);
/*      */       
/*      */       while (true) {
/*  634 */         CompletableFuture<V> priorFuture = this.delegate.get(key);
/*  635 */         if (priorFuture != null) {
/*  636 */           if (!priorFuture.isDone()) {
/*  637 */             Async.getWhenSuccessful(priorFuture);
/*      */             
/*      */             continue;
/*      */           } 
/*  641 */           V v = Async.getWhenSuccessful(priorFuture);
/*  642 */           if (v != null) {
/*  643 */             return v;
/*      */           }
/*      */         } 
/*      */         
/*  647 */         boolean[] added = { false };
/*  648 */         CompletableFuture<V> computed = this.delegate.compute(key, (k, valueFuture) -> {
/*  649 */               added[0] = (valueFuture == null || (valueFuture.isDone() && Async.getIfReady(valueFuture) == null));
/*      */               
/*      */               return added[0] ? CompletableFuture.<Object>completedFuture(value) : valueFuture;
/*      */             }false, false, false);
/*      */         
/*  654 */         if (added[0]) {
/*  655 */           return null;
/*      */         }
/*  657 */         V prior = Async.getWhenSuccessful(computed);
/*  658 */         if (prior != null) {
/*  659 */           return prior;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public V put(K key, V value) {
/*  667 */       Objects.requireNonNull(value);
/*      */       
/*  669 */       CompletableFuture<V> oldValueFuture = this.delegate.put(key, CompletableFuture.completedFuture(value));
/*  670 */       return Async.getWhenSuccessful(oldValueFuture);
/*      */     }
/*      */ 
/*      */     
/*      */     public V remove(Object key) {
/*  675 */       CompletableFuture<V> oldValueFuture = this.delegate.remove(key);
/*  676 */       return Async.getWhenSuccessful(oldValueFuture);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object key, Object value) {
/*  681 */       Objects.requireNonNull(key);
/*  682 */       if (value == null) {
/*  683 */         return false;
/*      */       }
/*      */ 
/*      */       
/*  687 */       K castedKey = (K)key;
/*  688 */       boolean[] done = { false };
/*  689 */       boolean[] removed = { false };
/*      */       while (true) {
/*  691 */         CompletableFuture<V> future = this.delegate.get(key);
/*  692 */         if (future == null || future.isCompletedExceptionally()) {
/*  693 */           return false;
/*      */         }
/*      */         
/*  696 */         Async.getWhenSuccessful(future);
/*  697 */         this.delegate.compute(castedKey, (k, oldValueFuture) -> {
/*      */               if (oldValueFuture == null) {
/*      */                 done[0] = true;
/*      */                 return null;
/*      */               } 
/*      */               if (!oldValueFuture.isDone()) {
/*      */                 return oldValueFuture;
/*      */               }
/*      */               done[0] = true;
/*      */               V oldValue = Async.getIfReady(oldValueFuture);
/*      */               removed[0] = value.equals(oldValue);
/*  708 */               return (oldValue == null || removed[0]) ? null : oldValueFuture;
/*      */             }false, false, true);
/*      */         
/*  711 */         if (done[0]) {
/*  712 */           return removed[0];
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public V replace(K key, V value) {
/*  719 */       Objects.requireNonNull(value);
/*      */ 
/*      */       
/*  722 */       V[] oldValue = (V[])new Object[1];
/*  723 */       boolean[] done = { false };
/*      */       while (true) {
/*  725 */         CompletableFuture<V> future = this.delegate.get(key);
/*  726 */         if (future == null || future.isCompletedExceptionally()) {
/*  727 */           return null;
/*      */         }
/*      */         
/*  730 */         Async.getWhenSuccessful(future);
/*  731 */         this.delegate.compute(key, (k, oldValueFuture) -> { if (oldValueFuture == null) { done[0] = true; return null; }  if (!oldValueFuture.isDone()) return oldValueFuture;  done[0] = true; oldValue[0] = Async.getIfReady(oldValueFuture); return (oldValue[0] == null) ? null : CompletableFuture.<Object>completedFuture(value); }false, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  744 */         if (done[0]) {
/*  745 */           return oldValue[0];
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean replace(K key, V oldValue, V newValue) {
/*  752 */       Objects.requireNonNull(oldValue);
/*  753 */       Objects.requireNonNull(newValue);
/*      */       
/*  755 */       boolean[] done = { false };
/*  756 */       boolean[] replaced = { false };
/*      */       while (true) {
/*  758 */         CompletableFuture<V> future = this.delegate.get(key);
/*  759 */         if (future == null || future.isCompletedExceptionally()) {
/*  760 */           return false;
/*      */         }
/*      */         
/*  763 */         Async.getWhenSuccessful(future);
/*  764 */         this.delegate.compute(key, (k, oldValueFuture) -> { if (oldValueFuture == null) { done[0] = true; return null; }  if (!oldValueFuture.isDone()) return oldValueFuture;  done[0] = true; replaced[0] = oldValue.equals(Async.getIfReady(oldValueFuture)); return replaced[0] ? CompletableFuture.<Object>completedFuture(newValue) : oldValueFuture; }false, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  777 */         if (done[0]) {
/*  778 */           return replaced[0];
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
/*      */       V result;
/*  785 */       Objects.requireNonNull(mappingFunction);
/*      */       
/*      */       while (true)
/*  788 */       { CompletableFuture<V> priorFuture = this.delegate.get(key);
/*  789 */         if (priorFuture != null) {
/*  790 */           if (!priorFuture.isDone()) {
/*  791 */             Async.getWhenSuccessful(priorFuture);
/*      */             
/*      */             continue;
/*      */           } 
/*  795 */           V prior = Async.getWhenSuccessful(priorFuture);
/*  796 */           if (prior != null) {
/*  797 */             this.delegate.statsCounter().recordHits(1);
/*  798 */             return prior;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  803 */         CompletableFuture[] arrayOfCompletableFuture = new CompletableFuture[1];
/*  804 */         CompletableFuture<V> computed = this.delegate.compute(key, (k, valueFuture) -> { if (valueFuture != null && valueFuture.isDone() && Async.getIfReady(valueFuture) != null) return valueFuture;  V newValue = this.delegate.<Object, V>statsAware(mappingFunction, true).apply(key); if (newValue == null) return null;  future[0] = CompletableFuture.completedFuture(newValue); return future[0]; }false, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  818 */         result = Async.getWhenSuccessful(computed);
/*  819 */         if (computed == arrayOfCompletableFuture[0] || result != null)
/*  820 */           break;  }  return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/*  828 */       Objects.requireNonNull(remappingFunction);
/*      */ 
/*      */       
/*  831 */       V[] newValue = (V[])new Object[1];
/*      */       while (true) {
/*  833 */         Async.getWhenSuccessful(this.delegate.get(key));
/*      */         
/*  835 */         CompletableFuture<V> valueFuture = this.delegate.computeIfPresent(key, (k, oldValueFuture) -> {
/*      */               if (!oldValueFuture.isDone()) {
/*      */                 return oldValueFuture;
/*      */               }
/*      */               
/*      */               V oldValue = Async.getIfReady(oldValueFuture);
/*      */               
/*      */               if (oldValue == null) {
/*      */                 return null;
/*      */               }
/*      */               
/*      */               newValue[0] = remappingFunction.apply(key, oldValue);
/*      */               return (newValue[0] == null) ? null : CompletableFuture.<Object>completedFuture(newValue[0]);
/*      */             });
/*  849 */         if (newValue[0] != null)
/*  850 */           return newValue[0]; 
/*  851 */         if (valueFuture == null) {
/*  852 */           return null;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/*  860 */       Objects.requireNonNull(remappingFunction);
/*      */ 
/*      */       
/*  863 */       V[] newValue = (V[])new Object[1];
/*      */       while (true) {
/*  865 */         Async.getWhenSuccessful(this.delegate.get(key));
/*      */         
/*  867 */         CompletableFuture<V> valueFuture = this.delegate.compute(key, (k, oldValueFuture) -> { if (oldValueFuture != null && !oldValueFuture.isDone()) return oldValueFuture;  V oldValue = Async.getIfReady(oldValueFuture); BiFunction<? super K, ? super V, ? extends V> function = this.delegate.statsAware(remappingFunction, false, true, true); newValue[0] = function.apply((K)key, oldValue); return (newValue[0] == null) ? null : CompletableFuture.<Object>completedFuture(newValue[0]); }false, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  880 */         if (newValue[0] != null)
/*  881 */           return newValue[0]; 
/*  882 */         if (valueFuture == null) {
/*  883 */           return null;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
/*      */       CompletableFuture<V> mergedValueFuture;
/*  891 */       Objects.requireNonNull(value);
/*  892 */       Objects.requireNonNull(remappingFunction);
/*      */       
/*  894 */       CompletableFuture<V> newValueFuture = CompletableFuture.completedFuture(value);
/*  895 */       boolean[] merged = { false };
/*      */       do {
/*  897 */         Async.getWhenSuccessful(this.delegate.get(key));
/*      */         
/*  899 */         mergedValueFuture = this.delegate.merge(key, newValueFuture, (oldValueFuture, valueFuture) -> {
/*      */               if (oldValueFuture != null && !oldValueFuture.isDone()) {
/*      */                 return oldValueFuture;
/*      */               }
/*      */ 
/*      */               
/*      */               merged[0] = true;
/*      */ 
/*      */               
/*      */               V oldValue = Async.getIfReady(oldValueFuture);
/*      */ 
/*      */               
/*      */               if (oldValue == null) {
/*      */                 return valueFuture;
/*      */               }
/*      */ 
/*      */               
/*      */               V mergedValue = remappingFunction.apply(oldValue, value);
/*      */ 
/*      */               
/*      */               return (mergedValue == null) ? null : ((mergedValue == oldValue) ? oldValueFuture : ((mergedValue == value) ? valueFuture : CompletableFuture.completedFuture(mergedValue)));
/*      */             });
/*  921 */       } while (!merged[0] && mergedValueFuture != newValueFuture);
/*  922 */       return Async.getWhenSuccessful(mergedValueFuture);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Set<K> keySet() {
/*  929 */       return this.delegate.keySet();
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<V> values() {
/*  934 */       return (this.values == null) ? (this.values = new Values()) : this.values;
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<K, V>> entrySet() {
/*  939 */       return (this.entries == null) ? (this.entries = new EntrySet()) : this.entries;
/*      */     }
/*      */     
/*      */     private final class Values extends AbstractCollection<V> {
/*      */       private Values() {}
/*      */       
/*      */       public boolean isEmpty() {
/*  946 */         return LocalAsyncCache.AsMapView.this.isEmpty();
/*      */       }
/*      */ 
/*      */       
/*      */       public int size() {
/*  951 */         return LocalAsyncCache.AsMapView.this.size();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean contains(Object o) {
/*  956 */         return LocalAsyncCache.AsMapView.this.containsValue(o);
/*      */       }
/*      */ 
/*      */       
/*      */       public void clear() {
/*  961 */         LocalAsyncCache.AsMapView.this.clear();
/*      */       }
/*      */ 
/*      */       
/*      */       public Iterator<V> iterator() {
/*  966 */         return new Iterator<V>() {
/*  967 */             Iterator<Map.Entry<K, V>> iterator = LocalAsyncCache.AsMapView.this.entrySet().iterator();
/*      */ 
/*      */             
/*      */             public boolean hasNext() {
/*  971 */               return this.iterator.hasNext();
/*      */             }
/*      */ 
/*      */             
/*      */             public V next() {
/*  976 */               return (V)((Map.Entry)this.iterator.next()).getValue();
/*      */             }
/*      */ 
/*      */             
/*      */             public void remove() {
/*  981 */               this.iterator.remove();
/*      */             }
/*      */           };
/*      */       }
/*      */     }
/*      */     
/*      */     private final class EntrySet extends AbstractSet<Map.Entry<K, V>> {
/*      */       private EntrySet() {}
/*      */       
/*      */       public boolean isEmpty() {
/*  991 */         return LocalAsyncCache.AsMapView.this.isEmpty();
/*      */       }
/*      */ 
/*      */       
/*      */       public int size() {
/*  996 */         return LocalAsyncCache.AsMapView.this.size();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean contains(Object o) {
/* 1001 */         if (!(o instanceof Map.Entry)) {
/* 1002 */           return false;
/*      */         }
/* 1004 */         Map.Entry<?, ?> entry = (Map.Entry<?, ?>)o;
/* 1005 */         V value = (V)LocalAsyncCache.AsMapView.this.get(entry.getKey());
/* 1006 */         return (value != null && value.equals(entry.getValue()));
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean remove(Object obj) {
/* 1011 */         if (!(obj instanceof Map.Entry)) {
/* 1012 */           return false;
/*      */         }
/* 1014 */         Map.Entry<?, ?> entry = (Map.Entry<?, ?>)obj;
/* 1015 */         return LocalAsyncCache.AsMapView.this.remove(entry.getKey(), entry.getValue());
/*      */       }
/*      */ 
/*      */       
/*      */       public void clear() {
/* 1020 */         LocalAsyncCache.AsMapView.this.clear();
/*      */       }
/*      */ 
/*      */       
/*      */       public Iterator<Map.Entry<K, V>> iterator() {
/* 1025 */         return new Iterator<Map.Entry<K, V>>() {
/* 1026 */             Iterator<Map.Entry<K, CompletableFuture<V>>> iterator = LocalAsyncCache.AsMapView.this.delegate.entrySet().iterator();
/*      */             
/*      */             Map.Entry<K, V> cursor;
/*      */             K removalKey;
/*      */             
/*      */             public boolean hasNext() {
/* 1032 */               while (this.cursor == null && this.iterator.hasNext()) {
/* 1033 */                 Map.Entry<K, CompletableFuture<V>> entry = this.iterator.next();
/* 1034 */                 V value = Async.getIfReady(entry.getValue());
/* 1035 */                 if (value != null) {
/* 1036 */                   this.cursor = new WriteThroughEntry<>(LocalAsyncCache.AsMapView.this, entry.getKey(), value);
/*      */                 }
/*      */               } 
/* 1039 */               return (this.cursor != null);
/*      */             }
/*      */ 
/*      */             
/*      */             public Map.Entry<K, V> next() {
/* 1044 */               if (!hasNext()) {
/* 1045 */                 throw new NoSuchElementException();
/*      */               }
/*      */               
/* 1048 */               K key = this.cursor.getKey();
/* 1049 */               Map.Entry<K, V> entry = this.cursor;
/* 1050 */               this.removalKey = key;
/* 1051 */               this.cursor = null;
/* 1052 */               return entry;
/*      */             }
/*      */ 
/*      */             
/*      */             public void remove() {
/* 1057 */               Caffeine.requireState((this.removalKey != null));
/* 1058 */               LocalAsyncCache.AsMapView.this.delegate.remove(this.removalKey);
/* 1059 */               this.removalKey = null;
/*      */             }
/*      */           };
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\LocalAsyncCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */