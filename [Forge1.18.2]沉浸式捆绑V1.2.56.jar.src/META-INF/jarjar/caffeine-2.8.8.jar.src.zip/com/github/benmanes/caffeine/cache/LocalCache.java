/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import com.github.benmanes.caffeine.cache.stats.StatsCounter;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface LocalCache<K, V>
/*     */   extends ConcurrentMap<K, V>
/*     */ {
/*     */   default V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/*  95 */     return compute(key, remappingFunction, false, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction) {
/* 108 */     return computeIfAbsent(key, mappingFunction, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void invalidateAll(Iterable<?> keys) {
/* 120 */     for (Object key : keys) {
/* 121 */       remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T, R> Function<? super T, ? extends R> statsAware(Function<? super T, ? extends R> mappingFunction, boolean recordLoad) {
/* 131 */     if (!isRecordingStats()) {
/* 132 */       return mappingFunction;
/*     */     }
/* 134 */     return key -> {
/*     */         R value;
/*     */         statsCounter().recordMisses(1);
/*     */         long startTime = statsTicker().read();
/*     */         try {
/*     */           value = mappingFunction.apply(key);
/* 140 */         } catch (RuntimeException|Error e) {
/*     */           statsCounter().recordLoadFailure(statsTicker().read() - startTime);
/*     */           throw e;
/*     */         } 
/*     */         long loadTime = statsTicker().read() - startTime;
/*     */         if (recordLoad) {
/*     */           if (value == null) {
/*     */             statsCounter().recordLoadFailure(loadTime);
/*     */           } else {
/*     */             statsCounter().recordLoadSuccess(loadTime);
/*     */           } 
/*     */         }
/*     */         return (Function)value;
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default <T, U, R> BiFunction<? super T, ? super U, ? extends R> statsAware(BiFunction<? super T, ? super U, ? extends R> remappingFunction) {
/* 159 */     return statsAware(remappingFunction, true, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T, U, R> BiFunction<? super T, ? super U, ? extends R> statsAware(BiFunction<? super T, ? super U, ? extends R> remappingFunction, boolean recordMiss, boolean recordLoad, boolean recordLoadFailure) {
/* 167 */     if (!isRecordingStats()) {
/* 168 */       return remappingFunction;
/*     */     }
/* 170 */     return (t, u) -> {
/*     */         R result;
/*     */         if (u == null && recordMiss) {
/*     */           statsCounter().recordMisses(1);
/*     */         }
/*     */         long startTime = statsTicker().read();
/*     */         try {
/*     */           result = remappingFunction.apply(t, u);
/* 178 */         } catch (RuntimeException|Error e) {
/*     */           if (recordLoadFailure)
/*     */             statsCounter().recordLoadFailure(statsTicker().read() - startTime); 
/*     */           throw e;
/*     */         } 
/*     */         long loadTime = statsTicker().read() - startTime;
/*     */         if (recordLoad)
/*     */           if (result == null) {
/*     */             statsCounter().recordLoadFailure(loadTime);
/*     */           } else {
/*     */             statsCounter().recordLoadSuccess(loadTime);
/*     */           }  
/*     */         return (BiFunction)result;
/*     */       };
/*     */   }
/*     */   
/*     */   boolean isRecordingStats();
/*     */   
/*     */   StatsCounter statsCounter();
/*     */   
/*     */   boolean hasRemovalListener();
/*     */   
/*     */   RemovalListener<K, V> removalListener();
/*     */   
/*     */   void notifyRemoval(K paramK, V paramV, RemovalCause paramRemovalCause);
/*     */   
/*     */   Executor executor();
/*     */   
/*     */   boolean hasWriteTime();
/*     */   
/*     */   Ticker expirationTicker();
/*     */   
/*     */   Ticker statsTicker();
/*     */   
/*     */   long estimatedSize();
/*     */   
/*     */   V getIfPresent(Object paramObject, boolean paramBoolean);
/*     */   
/*     */   V getIfPresentQuietly(Object paramObject, long[] paramArrayOflong);
/*     */   
/*     */   Map<K, V> getAllPresent(Iterable<?> paramIterable);
/*     */   
/*     */   V put(K paramK, V paramV, boolean paramBoolean);
/*     */   
/*     */   V compute(K paramK, BiFunction<? super K, ? super V, ? extends V> paramBiFunction, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*     */   
/*     */   V computeIfAbsent(K paramK, Function<? super K, ? extends V> paramFunction, boolean paramBoolean1, boolean paramBoolean2);
/*     */   
/*     */   void cleanUp();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\LocalCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */