/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SIR<K, V>
/*    */   extends SI<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   volatile long refreshAfterWriteNanos;
/*    */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*    */   
/*    */   SIR(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 38 */     super(builder, cacheLoader, async);
/* 39 */     this.ticker = builder.getTicker();
/* 40 */     this.refreshAfterWriteNanos = builder.getRefreshAfterWriteNanos();
/* 41 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*    */   }
/*    */   
/*    */   public Ticker expirationTicker() {
/* 45 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected boolean refreshAfterWrite() {
/* 49 */     return true;
/*    */   }
/*    */   
/*    */   protected long refreshAfterWriteNanos() {
/* 53 */     return this.refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/* 57 */     this.refreshAfterWriteNanos = refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected MpscGrowableArrayQueue<Runnable> writeBuffer() {
/* 61 */     return this.writeBuffer;
/*    */   }
/*    */   
/*    */   protected boolean buffersWrites() {
/* 65 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SIR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */