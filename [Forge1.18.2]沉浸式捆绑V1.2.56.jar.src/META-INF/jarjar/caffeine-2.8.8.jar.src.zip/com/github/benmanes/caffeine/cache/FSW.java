/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FSW<K, V>
/*     */   extends FS<K, V>
/*     */ {
/*  34 */   protected static final long WRITE_TIME_OFFSET = UnsafeAccess.objectFieldOffset(FSW.class, "writeTime");
/*     */ 
/*     */   
/*     */   volatile long writeTime;
/*     */ 
/*     */   
/*     */   Node<K, V> previousInWriteOrder;
/*     */ 
/*     */   
/*     */   Node<K, V> nextInWriteOrder;
/*     */ 
/*     */ 
/*     */   
/*     */   FSW() {}
/*     */ 
/*     */ 
/*     */   
/*     */   FSW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  52 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*  53 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, now);
/*     */   }
/*     */   
/*     */   FSW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  57 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*  58 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, now);
/*     */   }
/*     */   
/*     */   public Node<K, V> getPreviousInVariableOrder() {
/*  62 */     return this.previousInWriteOrder;
/*     */   }
/*     */   
/*     */   public void setPreviousInVariableOrder(Node<K, V> previousInWriteOrder) {
/*  66 */     this.previousInWriteOrder = previousInWriteOrder;
/*     */   }
/*     */   
/*     */   public Node<K, V> getNextInVariableOrder() {
/*  70 */     return this.nextInWriteOrder;
/*     */   }
/*     */   
/*     */   public void setNextInVariableOrder(Node<K, V> nextInWriteOrder) {
/*  74 */     this.nextInWriteOrder = nextInWriteOrder;
/*     */   }
/*     */   
/*     */   public long getVariableTime() {
/*  78 */     return UnsafeAccess.UNSAFE.getLong(this, WRITE_TIME_OFFSET);
/*     */   }
/*     */   
/*     */   public void setVariableTime(long writeTime) {
/*  82 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, writeTime);
/*     */   }
/*     */   
/*     */   public boolean casVariableTime(long expect, long update) {
/*  86 */     return (this.writeTime == expect && UnsafeAccess.UNSAFE
/*  87 */       .compareAndSwapLong(this, WRITE_TIME_OFFSET, expect, update));
/*     */   }
/*     */   
/*     */   public final long getWriteTime() {
/*  91 */     return UnsafeAccess.UNSAFE.getLong(this, WRITE_TIME_OFFSET);
/*     */   }
/*     */   
/*     */   public final void setWriteTime(long writeTime) {
/*  95 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, writeTime);
/*     */   }
/*     */   
/*     */   public final Node<K, V> getPreviousInWriteOrder() {
/*  99 */     return this.previousInWriteOrder;
/*     */   }
/*     */   
/*     */   public final void setPreviousInWriteOrder(Node<K, V> previousInWriteOrder) {
/* 103 */     this.previousInWriteOrder = previousInWriteOrder;
/*     */   }
/*     */   
/*     */   public final Node<K, V> getNextInWriteOrder() {
/* 107 */     return this.nextInWriteOrder;
/*     */   }
/*     */   
/*     */   public final void setNextInWriteOrder(Node<K, V> nextInWriteOrder) {
/* 111 */     this.nextInWriteOrder = nextInWriteOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 121 */     return new FSW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 126 */     return new FSW(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FSW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */