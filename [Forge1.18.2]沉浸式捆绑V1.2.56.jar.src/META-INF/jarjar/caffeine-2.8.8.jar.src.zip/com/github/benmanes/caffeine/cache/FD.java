/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FD<K, V>
/*     */   extends Node<K, V>
/*     */   implements NodeFactory<K, V>
/*     */ {
/*  37 */   protected static final long KEY_OFFSET = UnsafeAccess.objectFieldOffset(FD.class, "key");
/*     */ 
/*     */ 
/*     */   
/*  41 */   protected static final long VALUE_OFFSET = UnsafeAccess.objectFieldOffset(FD.class, "value");
/*     */ 
/*     */ 
/*     */   
/*     */   volatile References.WeakKeyReference<K> key;
/*     */ 
/*     */   
/*     */   volatile References.SoftValueReference<V> value;
/*     */ 
/*     */ 
/*     */   
/*     */   FD() {}
/*     */ 
/*     */ 
/*     */   
/*     */   FD(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  57 */     this(new References.WeakKeyReference<>(key, keyReferenceQueue), value, valueReferenceQueue, weight, now);
/*     */   }
/*     */   
/*     */   FD(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  61 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, keyReference);
/*  62 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, new References.SoftValueReference<>(keyReference, value, valueReferenceQueue));
/*     */   }
/*     */ 
/*     */   
/*     */   public final K getKey() {
/*  67 */     return ((Reference<K>)UnsafeAccess.UNSAFE.getObject(this, KEY_OFFSET)).get();
/*     */   }
/*     */   
/*     */   public final Object getKeyReference() {
/*  71 */     return UnsafeAccess.UNSAFE.getObject(this, KEY_OFFSET);
/*     */   }
/*     */   
/*     */   public final V getValue() {
/*  75 */     return ((Reference<V>)UnsafeAccess.UNSAFE.getObject(this, VALUE_OFFSET)).get();
/*     */   }
/*     */   
/*     */   public final Object getValueReference() {
/*  79 */     return UnsafeAccess.UNSAFE.getObject(this, VALUE_OFFSET);
/*     */   }
/*     */   
/*     */   public final void setValue(V value, ReferenceQueue<V> referenceQueue) {
/*  83 */     ((Reference)getValueReference()).clear();
/*  84 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, new References.SoftValueReference<>(
/*  85 */           getKeyReference(), value, referenceQueue));
/*     */   }
/*     */   
/*     */   public final boolean containsValue(Object value) {
/*  89 */     return (getValue() == value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  99 */     return new FD(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 104 */     return new FD(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */   
/*     */   public Object newLookupKey(Object key) {
/* 108 */     return new References.LookupKeyReference(key);
/*     */   }
/*     */   
/*     */   public Object newReferenceKey(K key, ReferenceQueue<K> referenceQueue) {
/* 112 */     return new References.WeakKeyReference<>(key, referenceQueue);
/*     */   }
/*     */   
/*     */   public boolean softValues() {
/* 116 */     return true;
/*     */   }
/*     */   
/*     */   public final boolean isAlive() {
/* 120 */     Object key = getKeyReference();
/* 121 */     return (key != RETIRED_WEAK_KEY && key != DEAD_WEAK_KEY);
/*     */   }
/*     */   
/*     */   public final boolean isRetired() {
/* 125 */     return (getKeyReference() == RETIRED_WEAK_KEY);
/*     */   }
/*     */   
/*     */   public final void retire() {
/* 129 */     ((Reference)getKeyReference()).clear();
/* 130 */     ((Reference)getValueReference()).clear();
/* 131 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, RETIRED_WEAK_KEY);
/*     */   }
/*     */   
/*     */   public final boolean isDead() {
/* 135 */     return (getKeyReference() == DEAD_WEAK_KEY);
/*     */   }
/*     */   
/*     */   public final void die() {
/* 139 */     ((Reference)getKeyReference()).clear();
/* 140 */     ((Reference)getValueReference()).clear();
/* 141 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, DEAD_WEAK_KEY);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */