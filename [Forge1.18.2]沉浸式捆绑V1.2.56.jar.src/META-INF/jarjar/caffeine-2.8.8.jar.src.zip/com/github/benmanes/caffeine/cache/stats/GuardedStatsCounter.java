/*     */ package com.github.benmanes.caffeine.cache.stats;
/*     */ 
/*     */ import com.github.benmanes.caffeine.cache.RemovalCause;
/*     */ import java.util.Objects;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class GuardedStatsCounter
/*     */   implements StatsCounter
/*     */ {
/*  33 */   static final Logger logger = Logger.getLogger(GuardedStatsCounter.class.getName());
/*     */   
/*     */   final StatsCounter delegate;
/*     */   
/*     */   GuardedStatsCounter(StatsCounter delegate) {
/*  38 */     this.delegate = Objects.<StatsCounter>requireNonNull(delegate);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordHits(int count) {
/*     */     try {
/*  44 */       this.delegate.recordHits(count);
/*  45 */     } catch (Throwable t) {
/*  46 */       logger.log(Level.WARNING, "Exception thrown by stats counter", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordMisses(int count) {
/*     */     try {
/*  53 */       this.delegate.recordMisses(count);
/*  54 */     } catch (Throwable t) {
/*  55 */       logger.log(Level.WARNING, "Exception thrown by stats counter", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordLoadSuccess(long loadTime) {
/*     */     try {
/*  62 */       this.delegate.recordLoadSuccess(loadTime);
/*  63 */     } catch (Throwable t) {
/*  64 */       logger.log(Level.WARNING, "Exception thrown by stats counter", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordLoadFailure(long loadTime) {
/*     */     try {
/*  71 */       this.delegate.recordLoadFailure(loadTime);
/*  72 */     } catch (Throwable t) {
/*  73 */       logger.log(Level.WARNING, "Exception thrown by stats counter", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordEviction() {
/*     */     try {
/*  81 */       this.delegate.recordEviction();
/*  82 */     } catch (Throwable t) {
/*  83 */       logger.log(Level.WARNING, "Exception thrown by stats counter", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordEviction(int weight) {
/*     */     try {
/*  91 */       this.delegate.recordEviction(weight);
/*  92 */     } catch (Throwable t) {
/*  93 */       logger.log(Level.WARNING, "Exception thrown by stats counter", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordEviction(int weight, RemovalCause cause) {
/*     */     try {
/* 100 */       this.delegate.recordEviction(weight, cause);
/* 101 */     } catch (Throwable t) {
/* 102 */       logger.log(Level.WARNING, "Exception thrown by stats counter", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CacheStats snapshot() {
/*     */     try {
/* 109 */       return this.delegate.snapshot();
/* 110 */     } catch (Throwable t) {
/* 111 */       logger.log(Level.WARNING, "Exception thrown by stats counter", t);
/* 112 */       return CacheStats.empty();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 118 */     return this.delegate.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\stats\GuardedStatsCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */