/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SIL<K, V>
/*    */   extends SI<K, V>
/*    */ {
/*    */   final RemovalListener<K, V> removalListener;
/*    */   
/*    */   SIL(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 34 */     super(builder, cacheLoader, async);
/* 35 */     this.removalListener = builder.getRemovalListener(async);
/*    */   }
/*    */   
/*    */   public final RemovalListener<K, V> removalListener() {
/* 39 */     return this.removalListener;
/*    */   }
/*    */   
/*    */   public final boolean hasRemovalListener() {
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SIL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */