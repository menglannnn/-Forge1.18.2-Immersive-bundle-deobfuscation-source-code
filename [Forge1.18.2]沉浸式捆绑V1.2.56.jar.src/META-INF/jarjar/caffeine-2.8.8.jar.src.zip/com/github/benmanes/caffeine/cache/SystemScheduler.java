/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum SystemScheduler
/*     */   implements Scheduler
/*     */ {
/* 102 */   INSTANCE;
/*     */   static {
/* 104 */     delayedExecutor = getDelayedExecutorMethod();
/*     */   }
/*     */   static final Method delayedExecutor;
/*     */   
/*     */   public Future<?> schedule(Executor executor, Runnable command, long delay, TimeUnit unit) {
/* 109 */     Objects.requireNonNull(executor);
/* 110 */     Objects.requireNonNull(command);
/* 111 */     Objects.requireNonNull(unit);
/*     */     
/*     */     try {
/* 114 */       Executor scheduler = (Executor)delayedExecutor.invoke(CompletableFuture.class, new Object[] {
/* 115 */             Long.valueOf(delay), unit, executor });
/* 116 */       return CompletableFuture.runAsync(command, scheduler);
/* 117 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 118 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   static Method getDelayedExecutorMethod() {
/*     */     try {
/* 124 */       return CompletableFuture.class.getMethod("delayedExecutor", new Class[] { long.class, TimeUnit.class, Executor.class });
/*     */     }
/* 126 */     catch (NoSuchMethodException|SecurityException e) {
/* 127 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   static boolean isPresent() {
/* 132 */     return (delayedExecutor != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SystemScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */