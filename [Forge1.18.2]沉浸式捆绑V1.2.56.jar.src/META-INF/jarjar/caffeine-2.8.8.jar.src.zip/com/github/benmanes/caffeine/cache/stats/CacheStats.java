/*     */ package com.github.benmanes.caffeine.cache.stats;
/*     */ 
/*     */ import com.google.errorprone.annotations.Immutable;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Immutable
/*     */ public final class CacheStats
/*     */ {
/*  61 */   private static final CacheStats EMPTY_STATS = new CacheStats(0L, 0L, 0L, 0L, 0L, 0L, 0L);
/*     */ 
/*     */   
/*     */   private final long hitCount;
/*     */ 
/*     */   
/*     */   private final long missCount;
/*     */ 
/*     */   
/*     */   private final long loadSuccessCount;
/*     */ 
/*     */   
/*     */   private final long loadFailureCount;
/*     */ 
/*     */   
/*     */   private final long totalLoadTime;
/*     */ 
/*     */   
/*     */   private final long evictionCount;
/*     */   
/*     */   private final long evictionWeight;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public CacheStats(long hitCount, long missCount, long loadSuccessCount, long loadFailureCount, long totalLoadTime, long evictionCount) {
/*  86 */     this(hitCount, missCount, loadSuccessCount, loadFailureCount, totalLoadTime, evictionCount, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheStats(long hitCount, long missCount, long loadSuccessCount, long loadFailureCount, long totalLoadTime, long evictionCount, long evictionWeight) {
/* 107 */     if (hitCount < 0L || missCount < 0L || loadSuccessCount < 0L || loadFailureCount < 0L || totalLoadTime < 0L || evictionCount < 0L || evictionWeight < 0L)
/*     */     {
/* 109 */       throw new IllegalArgumentException();
/*     */     }
/* 111 */     this.hitCount = hitCount;
/* 112 */     this.missCount = missCount;
/* 113 */     this.loadSuccessCount = loadSuccessCount;
/* 114 */     this.loadFailureCount = loadFailureCount;
/* 115 */     this.totalLoadTime = totalLoadTime;
/* 116 */     this.evictionCount = evictionCount;
/* 117 */     this.evictionWeight = evictionWeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CacheStats empty() {
/* 127 */     return EMPTY_STATS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long requestCount() {
/* 142 */     return saturatedAdd(this.hitCount, this.missCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long hitCount() {
/* 152 */     return this.hitCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double hitRate() {
/* 164 */     long requestCount = requestCount();
/* 165 */     return (requestCount == 0L) ? 1.0D : (this.hitCount / requestCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long missCount() {
/* 179 */     return this.missCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double missRate() {
/* 195 */     long requestCount = requestCount();
/* 196 */     return (requestCount == 0L) ? 0.0D : (this.missCount / requestCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long loadCount() {
/* 212 */     return saturatedAdd(this.loadSuccessCount, this.loadFailureCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long loadSuccessCount() {
/* 226 */     return this.loadSuccessCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long loadFailureCount() {
/* 240 */     return this.loadFailureCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double loadFailureRate() {
/* 256 */     long totalLoadCount = saturatedAdd(this.loadSuccessCount, this.loadFailureCount);
/* 257 */     return (totalLoadCount == 0L) ? 0.0D : (this.loadFailureCount / totalLoadCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long totalLoadTime() {
/* 269 */     return this.totalLoadTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double averageLoadPenalty() {
/* 284 */     long totalLoadCount = saturatedAdd(this.loadSuccessCount, this.loadFailureCount);
/* 285 */     return (totalLoadCount == 0L) ? 0.0D : (this.totalLoadTime / totalLoadCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long evictionCount() {
/* 296 */     return this.evictionCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long evictionWeight() {
/* 307 */     return this.evictionWeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheStats minus(CacheStats other) {
/* 320 */     return new CacheStats(
/* 321 */         Math.max(0L, saturatedSubtract(this.hitCount, other.hitCount)), 
/* 322 */         Math.max(0L, saturatedSubtract(this.missCount, other.missCount)), 
/* 323 */         Math.max(0L, saturatedSubtract(this.loadSuccessCount, other.loadSuccessCount)), 
/* 324 */         Math.max(0L, saturatedSubtract(this.loadFailureCount, other.loadFailureCount)), 
/* 325 */         Math.max(0L, saturatedSubtract(this.totalLoadTime, other.totalLoadTime)), 
/* 326 */         Math.max(0L, saturatedSubtract(this.evictionCount, other.evictionCount)), 
/* 327 */         Math.max(0L, saturatedSubtract(this.evictionWeight, other.evictionWeight)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheStats plus(CacheStats other) {
/* 343 */     return new CacheStats(
/* 344 */         saturatedAdd(this.hitCount, other.hitCount), 
/* 345 */         saturatedAdd(this.missCount, other.missCount), 
/* 346 */         saturatedAdd(this.loadSuccessCount, other.loadSuccessCount), 
/* 347 */         saturatedAdd(this.loadFailureCount, other.loadFailureCount), 
/* 348 */         saturatedAdd(this.totalLoadTime, other.totalLoadTime), 
/* 349 */         saturatedAdd(this.evictionCount, other.evictionCount), 
/* 350 */         saturatedAdd(this.evictionWeight, other.evictionWeight));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long saturatedSubtract(long a, long b) {
/* 359 */     long naiveDifference = a - b;
/* 360 */     if (((((a ^ b) >= 0L) ? 1 : 0) | (((a ^ naiveDifference) >= 0L) ? 1 : 0)) != 0)
/*     */     {
/*     */       
/* 363 */       return naiveDifference;
/*     */     }
/*     */     
/* 366 */     return Long.MAX_VALUE + (naiveDifference >>> 63L ^ 0x1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long saturatedAdd(long a, long b) {
/* 375 */     long naiveSum = a + b;
/* 376 */     if (((((a ^ b) < 0L) ? 1 : 0) | (((a ^ naiveSum) >= 0L) ? 1 : 0)) != 0)
/*     */     {
/*     */       
/* 379 */       return naiveSum;
/*     */     }
/*     */     
/* 382 */     return Long.MAX_VALUE + (naiveSum >>> 63L ^ 0x1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 387 */     return Objects.hash(new Object[] { Long.valueOf(this.hitCount), Long.valueOf(this.missCount), Long.valueOf(this.loadSuccessCount), 
/* 388 */           Long.valueOf(this.loadFailureCount), Long.valueOf(this.totalLoadTime), Long.valueOf(this.evictionCount), Long.valueOf(this.evictionWeight) });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 393 */     if (o == this)
/* 394 */       return true; 
/* 395 */     if (!(o instanceof CacheStats)) {
/* 396 */       return false;
/*     */     }
/* 398 */     CacheStats other = (CacheStats)o;
/* 399 */     return (this.hitCount == other.hitCount && this.missCount == other.missCount && this.loadSuccessCount == other.loadSuccessCount && this.loadFailureCount == other.loadFailureCount && this.totalLoadTime == other.totalLoadTime && this.evictionCount == other.evictionCount && this.evictionWeight == other.evictionWeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 410 */     return getClass().getSimpleName() + '{' + "hitCount=" + this.hitCount + ", missCount=" + this.missCount + ", loadSuccessCount=" + this.loadSuccessCount + ", loadFailureCount=" + this.loadFailureCount + ", totalLoadTime=" + this.totalLoadTime + ", evictionCount=" + this.evictionCount + ", evictionWeight=" + this.evictionWeight + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\stats\CacheStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */