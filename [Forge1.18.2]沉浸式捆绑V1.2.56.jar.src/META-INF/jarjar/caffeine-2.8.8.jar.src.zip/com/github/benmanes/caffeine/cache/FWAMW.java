/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FWAMW<K, V>
/*    */   extends FWA<K, V>
/*    */ {
/*    */   int queueType;
/*    */   int weight;
/*    */   int policyWeight;
/*    */   
/*    */   FWAMW() {}
/*    */   
/*    */   FWAMW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 49 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/* 50 */     this.weight = weight;
/*    */   }
/*    */   
/*    */   FWAMW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 54 */     super(keyReference, value, valueReferenceQueue, weight, now);
/* 55 */     this.weight = weight;
/*    */   }
/*    */   
/*    */   public int getQueueType() {
/* 59 */     return this.queueType;
/*    */   }
/*    */   
/*    */   public void setQueueType(int queueType) {
/* 63 */     this.queueType = queueType;
/*    */   }
/*    */   
/*    */   public int getWeight() {
/* 67 */     return this.weight;
/*    */   }
/*    */   
/*    */   public void setWeight(int weight) {
/* 71 */     this.weight = weight;
/*    */   }
/*    */   
/*    */   public int getPolicyWeight() {
/* 75 */     return this.policyWeight;
/*    */   }
/*    */   
/*    */   public void setPolicyWeight(int policyWeight) {
/* 79 */     this.policyWeight = policyWeight;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 89 */     return new FWAMW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 94 */     return new FWAMW(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FWAMW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */