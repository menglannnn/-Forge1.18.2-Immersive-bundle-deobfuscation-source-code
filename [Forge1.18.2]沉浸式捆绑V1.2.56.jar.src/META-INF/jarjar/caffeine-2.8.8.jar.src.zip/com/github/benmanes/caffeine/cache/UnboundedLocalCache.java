/*      */ package com.github.benmanes.caffeine.cache;
/*      */ 
/*      */ import com.github.benmanes.caffeine.cache.stats.StatsCounter;
/*      */ import java.io.InvalidObjectException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.Spliterator;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class UnboundedLocalCache<K, V>
/*      */   implements LocalCache<K, V>
/*      */ {
/*      */   final RemovalListener<K, V> removalListener;
/*      */   final ConcurrentHashMap<K, V> data;
/*      */   final StatsCounter statsCounter;
/*      */   final boolean isRecordingStats;
/*      */   final CacheWriter<K, V> writer;
/*      */   final Executor executor;
/*      */   final Ticker ticker;
/*      */   transient Set<K> keySet;
/*      */   transient Collection<V> values;
/*      */   transient Set<Map.Entry<K, V>> entrySet;
/*      */   
/*      */   UnboundedLocalCache(Caffeine<? super K, ? super V> builder, boolean async) {
/*   70 */     this.data = new ConcurrentHashMap<>(builder.getInitialCapacity());
/*   71 */     this.statsCounter = builder.getStatsCounterSupplier().get();
/*   72 */     this.removalListener = builder.getRemovalListener(async);
/*   73 */     this.isRecordingStats = builder.isRecordingStats();
/*   74 */     this.writer = builder.getCacheWriter();
/*   75 */     this.executor = builder.getExecutor();
/*   76 */     this.ticker = builder.getTicker();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasWriteTime() {
/*   81 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V getIfPresent(Object key, boolean recordStats) {
/*   88 */     V value = this.data.get(key);
/*      */     
/*   90 */     if (recordStats) {
/*   91 */       if (value == null) {
/*   92 */         this.statsCounter.recordMisses(1);
/*      */       } else {
/*   94 */         this.statsCounter.recordHits(1);
/*      */       } 
/*      */     }
/*   97 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public V getIfPresentQuietly(Object key, long[] writeTime) {
/*  102 */     return this.data.get(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public long estimatedSize() {
/*  107 */     return this.data.mappingCount();
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<K, V> getAllPresent(Iterable<?> keys) {
/*  112 */     Set<Object> uniqueKeys = new LinkedHashSet();
/*  113 */     for (Object key : keys) {
/*  114 */       uniqueKeys.add(key);
/*      */     }
/*      */     
/*  117 */     int misses = 0;
/*  118 */     Map<Object, Object> result = new LinkedHashMap<>(uniqueKeys.size());
/*  119 */     for (Object key : uniqueKeys) {
/*  120 */       Object value = this.data.get(key);
/*  121 */       if (value == null) {
/*  122 */         misses++; continue;
/*      */       } 
/*  124 */       result.put(key, value);
/*      */     } 
/*      */     
/*  127 */     this.statsCounter.recordMisses(misses);
/*  128 */     this.statsCounter.recordHits(result.size());
/*      */ 
/*      */     
/*  131 */     Map<Object, Object> map1 = result;
/*  132 */     return Collections.unmodifiableMap((Map)map1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void cleanUp() {}
/*      */ 
/*      */   
/*      */   public StatsCounter statsCounter() {
/*  140 */     return this.statsCounter;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasRemovalListener() {
/*  145 */     return (this.removalListener != null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public RemovalListener<K, V> removalListener() {
/*  151 */     return this.removalListener;
/*      */   }
/*      */ 
/*      */   
/*      */   public void notifyRemoval(K key, V value, RemovalCause cause) {
/*  156 */     Objects.requireNonNull(removalListener(), "Notification should be guarded with a check");
/*  157 */     this.executor.execute(() -> removalListener().onRemoval((K)key, (V)value, cause));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRecordingStats() {
/*  162 */     return this.isRecordingStats;
/*      */   }
/*      */ 
/*      */   
/*      */   public Executor executor() {
/*  167 */     return this.executor;
/*      */   }
/*      */ 
/*      */   
/*      */   public Ticker expirationTicker() {
/*  172 */     return Ticker.disabledTicker();
/*      */   }
/*      */ 
/*      */   
/*      */   public Ticker statsTicker() {
/*  177 */     return this.ticker;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void forEach(BiConsumer<? super K, ? super V> action) {
/*  184 */     this.data.forEach(action);
/*      */   }
/*      */ 
/*      */   
/*      */   public void replaceAll(BiFunction<? super K, ? super V, ? extends V> function) {
/*  189 */     Objects.requireNonNull(function);
/*      */ 
/*      */ 
/*      */     
/*  193 */     K[] notificationKey = (K[])new Object[1];
/*      */     
/*  195 */     V[] notificationValue = (V[])new Object[1];
/*  196 */     this.data.replaceAll((key, value) -> {
/*      */           if (notificationKey[0] != null) {
/*      */             notifyRemoval((K)notificationKey[0], (V)notificationValue[0], RemovalCause.REPLACED);
/*      */             
/*      */             notificationValue[0] = null;
/*      */             
/*      */             notificationKey[0] = null;
/*      */           } 
/*      */           V newValue = Objects.requireNonNull(function.apply(key, value));
/*      */           if (newValue != value) {
/*      */             this.writer.write((K)key, newValue);
/*      */           }
/*      */           if (hasRemovalListener() && newValue != value) {
/*      */             notificationKey[0] = key;
/*      */             notificationValue[0] = value;
/*      */           } 
/*      */           return (BiFunction)newValue;
/*      */         });
/*  214 */     if (notificationKey[0] != null) {
/*  215 */       notifyRemoval(notificationKey[0], notificationValue[0], RemovalCause.REPLACED);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction, boolean recordStats, boolean recordLoad) {
/*  222 */     Objects.requireNonNull(mappingFunction);
/*      */ 
/*      */     
/*  225 */     V value = this.data.get(key);
/*  226 */     if (value != null) {
/*  227 */       if (recordStats) {
/*  228 */         this.statsCounter.recordHits(1);
/*      */       }
/*  230 */       return value;
/*      */     } 
/*      */     
/*  233 */     boolean[] missed = new boolean[1];
/*  234 */     value = this.data.computeIfAbsent(key, k -> {
/*      */           missed[0] = true;
/*      */ 
/*      */           
/*      */           return recordStats ? statsAware(mappingFunction, recordLoad).apply(key) : mappingFunction.apply(key);
/*      */         });
/*      */     
/*  241 */     if (!missed[0] && recordStats) {
/*  242 */       this.statsCounter.recordHits(1);
/*      */     }
/*  244 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/*  250 */     Objects.requireNonNull(remappingFunction);
/*      */ 
/*      */     
/*  253 */     if (!this.data.containsKey(key)) {
/*  254 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  259 */     V[] oldValue = (V[])new Object[1];
/*  260 */     RemovalCause[] cause = new RemovalCause[1];
/*  261 */     V nv = this.data.computeIfPresent(key, (k, value) -> {
/*      */           BiFunction<? super K, ? super V, ? extends V> function = statsAware(remappingFunction, false, true, true);
/*      */           
/*      */           V newValue = function.apply((K)k, (V)value);
/*      */           
/*      */           cause[0] = (newValue == null) ? RemovalCause.EXPLICIT : RemovalCause.REPLACED;
/*      */           
/*      */           if (hasRemovalListener() && newValue != value) {
/*      */             oldValue[0] = value;
/*      */           }
/*      */           return (BiFunction)newValue;
/*      */         });
/*  273 */     if (oldValue[0] != null) {
/*  274 */       notifyRemoval(key, oldValue[0], cause[0]);
/*      */     }
/*  276 */     return nv;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction, boolean recordMiss, boolean recordLoad, boolean recordLoadFailure) {
/*  282 */     Objects.requireNonNull(remappingFunction);
/*  283 */     return remap(key, statsAware(remappingFunction, recordMiss, recordLoad, recordLoadFailure));
/*      */   }
/*      */ 
/*      */   
/*      */   public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
/*  288 */     Objects.requireNonNull(remappingFunction);
/*  289 */     Objects.requireNonNull(value);
/*      */     
/*  291 */     return remap(key, (k, oldValue) -> (oldValue == null) ? value : statsAware(remappingFunction).apply(oldValue, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   V remap(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/*  305 */     V[] oldValue = (V[])new Object[1];
/*  306 */     RemovalCause[] cause = new RemovalCause[1];
/*  307 */     V nv = this.data.compute(key, (k, value) -> {
/*      */           V newValue = remappingFunction.apply(k, value);
/*      */           
/*      */           if (value == null && newValue == null) {
/*      */             return null;
/*      */           }
/*      */           
/*      */           cause[0] = (newValue == null) ? RemovalCause.EXPLICIT : RemovalCause.REPLACED;
/*      */           if (hasRemovalListener() && value != null && newValue != value) {
/*      */             oldValue[0] = value;
/*      */           }
/*      */           return (BiFunction)newValue;
/*      */         });
/*  320 */     if (oldValue[0] != null) {
/*  321 */       notifyRemoval(key, oldValue[0], cause[0]);
/*      */     }
/*  323 */     return nv;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  330 */     return this.data.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   public int size() {
/*  335 */     return this.data.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear() {
/*  340 */     if (!hasRemovalListener() && this.writer == CacheWriter.disabledWriter()) {
/*  341 */       this.data.clear();
/*      */       return;
/*      */     } 
/*  344 */     for (K key : this.data.keySet()) {
/*  345 */       remove(key);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsKey(Object key) {
/*  351 */     return this.data.containsKey(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsValue(Object value) {
/*  356 */     return this.data.containsValue(value);
/*      */   }
/*      */ 
/*      */   
/*      */   public V get(Object key) {
/*  361 */     return getIfPresent(key, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public V put(K key, V value) {
/*  366 */     return put(key, value, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public V put(K key, V value, boolean notifyWriter) {
/*  371 */     Objects.requireNonNull(value);
/*      */ 
/*      */ 
/*      */     
/*  375 */     V[] oldValue = (V[])new Object[1];
/*  376 */     if (this.writer == CacheWriter.disabledWriter() || !notifyWriter) {
/*  377 */       oldValue[0] = this.data.put(key, value);
/*      */     } else {
/*  379 */       this.data.compute(key, (k, v) -> {
/*      */             if (value != v) {
/*      */               this.writer.write((K)key, (V)value);
/*      */             }
/*      */             
/*      */             oldValue[0] = v;
/*      */             return value;
/*      */           });
/*      */     } 
/*  388 */     if (hasRemovalListener() && oldValue[0] != null && oldValue[0] != value) {
/*  389 */       notifyRemoval(key, oldValue[0], RemovalCause.REPLACED);
/*      */     }
/*      */     
/*  392 */     return oldValue[0];
/*      */   }
/*      */ 
/*      */   
/*      */   public V putIfAbsent(K key, V value) {
/*  397 */     Objects.requireNonNull(value);
/*      */     
/*  399 */     boolean[] wasAbsent = new boolean[1];
/*  400 */     V val = this.data.computeIfAbsent(key, k -> {
/*      */           this.writer.write((K)key, (V)value);
/*      */           wasAbsent[0] = true;
/*      */           return value;
/*      */         });
/*  405 */     return wasAbsent[0] ? null : val;
/*      */   }
/*      */ 
/*      */   
/*      */   public void putAll(Map<? extends K, ? extends V> map) {
/*  410 */     if (!hasRemovalListener() && this.writer == CacheWriter.disabledWriter()) {
/*  411 */       this.data.putAll(map);
/*      */       return;
/*      */     } 
/*  414 */     map.forEach(this::put);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V remove(Object key) {
/*  420 */     K castKey = (K)key;
/*      */     
/*  422 */     V[] oldValue = (V[])new Object[1];
/*      */     
/*  424 */     if (this.writer == CacheWriter.disabledWriter()) {
/*  425 */       oldValue[0] = this.data.remove(key);
/*      */     } else {
/*  427 */       this.data.computeIfPresent(castKey, (k, v) -> {
/*      */             this.writer.delete((K)castKey, (V)v, RemovalCause.EXPLICIT);
/*      */             
/*      */             oldValue[0] = v;
/*      */             return null;
/*      */           });
/*      */     } 
/*  434 */     if (hasRemovalListener() && oldValue[0] != null) {
/*  435 */       notifyRemoval(castKey, oldValue[0], RemovalCause.EXPLICIT);
/*      */     }
/*      */     
/*  438 */     return oldValue[0];
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean remove(Object key, Object value) {
/*  443 */     if (value == null) {
/*  444 */       Objects.requireNonNull(key);
/*  445 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  449 */     K castKey = (K)key;
/*      */     
/*  451 */     V[] oldValue = (V[])new Object[1];
/*      */     
/*  453 */     this.data.computeIfPresent(castKey, (k, v) -> {
/*      */           if (v.equals(value)) {
/*      */             this.writer.delete((K)castKey, (V)v, RemovalCause.EXPLICIT);
/*      */             
/*      */             oldValue[0] = v;
/*      */             return null;
/*      */           } 
/*      */           return v;
/*      */         });
/*  462 */     boolean removed = (oldValue[0] != null);
/*  463 */     if (hasRemovalListener() && removed) {
/*  464 */       notifyRemoval(castKey, oldValue[0], RemovalCause.EXPLICIT);
/*      */     }
/*  466 */     return removed;
/*      */   }
/*      */ 
/*      */   
/*      */   public V replace(K key, V value) {
/*  471 */     Objects.requireNonNull(value);
/*      */ 
/*      */     
/*  474 */     V[] oldValue = (V[])new Object[1];
/*  475 */     this.data.computeIfPresent(key, (k, v) -> {
/*      */           if (value != v) {
/*      */             this.writer.write((K)key, (V)value);
/*      */           }
/*      */           
/*      */           oldValue[0] = v;
/*      */           return value;
/*      */         });
/*  483 */     if (hasRemovalListener() && oldValue[0] != null && oldValue[0] != value) {
/*  484 */       notifyRemoval(key, value, RemovalCause.REPLACED);
/*      */     }
/*  486 */     return oldValue[0];
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean replace(K key, V oldValue, V newValue) {
/*  491 */     Objects.requireNonNull(oldValue);
/*  492 */     Objects.requireNonNull(newValue);
/*      */ 
/*      */     
/*  495 */     V[] prev = (V[])new Object[1];
/*  496 */     this.data.computeIfPresent(key, (k, v) -> {
/*      */           if (v.equals(oldValue)) {
/*      */             if (newValue != v) {
/*      */               this.writer.write((K)key, (V)newValue);
/*      */             }
/*      */             
/*      */             prev[0] = v;
/*      */             return newValue;
/*      */           } 
/*      */           return v;
/*      */         });
/*  507 */     boolean replaced = (prev[0] != null);
/*  508 */     if (hasRemovalListener() && replaced && prev[0] != newValue) {
/*  509 */       notifyRemoval(key, prev[0], RemovalCause.REPLACED);
/*      */     }
/*  511 */     return replaced;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/*  516 */     return this.data.equals(o);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  521 */     return this.data.hashCode();
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  526 */     return this.data.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<K> keySet() {
/*  531 */     Set<K> ks = this.keySet;
/*  532 */     return (ks == null) ? (this.keySet = new KeySetView<>(this)) : ks;
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection<V> values() {
/*  537 */     Collection<V> vs = this.values;
/*  538 */     return (vs == null) ? (this.values = new ValuesView<>(this)) : vs;
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<Map.Entry<K, V>> entrySet() {
/*  543 */     Set<Map.Entry<K, V>> es = this.entrySet;
/*  544 */     return (es == null) ? (this.entrySet = new EntrySetView<>(this)) : es;
/*      */   }
/*      */   
/*      */   static final class KeySetView<K>
/*      */     extends AbstractSet<K> {
/*      */     final UnboundedLocalCache<K, ?> cache;
/*      */     
/*      */     KeySetView(UnboundedLocalCache<K, ?> cache) {
/*  552 */       this.cache = Objects.<UnboundedLocalCache<K, ?>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  557 */       return this.cache.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  562 */       return this.cache.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/*  567 */       this.cache.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object o) {
/*  572 */       return this.cache.containsKey(o);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object obj) {
/*  577 */       return (this.cache.remove(obj) != null);
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<K> iterator() {
/*  582 */       return new UnboundedLocalCache.KeyIterator<>(this.cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public Spliterator<K> spliterator() {
/*  587 */       return this.cache.data.keySet().spliterator();
/*      */     }
/*      */   }
/*      */   
/*      */   static final class KeyIterator<K>
/*      */     implements Iterator<K> {
/*      */     final UnboundedLocalCache<K, ?> cache;
/*      */     final Iterator<K> iterator;
/*      */     K current;
/*      */     
/*      */     KeyIterator(UnboundedLocalCache<K, ?> cache) {
/*  598 */       this.cache = Objects.<UnboundedLocalCache<K, ?>>requireNonNull(cache);
/*  599 */       this.iterator = cache.data.keySet().iterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/*  604 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public K next() {
/*  609 */       this.current = this.iterator.next();
/*  610 */       return this.current;
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/*  615 */       if (this.current == null) {
/*  616 */         throw new IllegalStateException();
/*      */       }
/*  618 */       this.cache.remove(this.current);
/*  619 */       this.current = null;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ValuesView<K, V>
/*      */     extends AbstractCollection<V> {
/*      */     final UnboundedLocalCache<K, V> cache;
/*      */     
/*      */     ValuesView(UnboundedLocalCache<K, V> cache) {
/*  628 */       this.cache = Objects.<UnboundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  633 */       return this.cache.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  638 */       return this.cache.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/*  643 */       this.cache.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object o) {
/*  648 */       return this.cache.containsValue(o);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeIf(Predicate<? super V> filter) {
/*  653 */       Objects.requireNonNull(filter);
/*  654 */       boolean removed = false;
/*  655 */       for (Map.Entry<K, V> entry : this.cache.data.entrySet()) {
/*  656 */         if (filter.test(entry.getValue())) {
/*  657 */           removed |= this.cache.remove(entry.getKey(), entry.getValue());
/*      */         }
/*      */       } 
/*  660 */       return removed;
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<V> iterator() {
/*  665 */       return new UnboundedLocalCache.ValuesIterator<>(this.cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public Spliterator<V> spliterator() {
/*  670 */       return this.cache.data.values().spliterator();
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ValuesIterator<K, V>
/*      */     implements Iterator<V> {
/*      */     final UnboundedLocalCache<K, V> cache;
/*      */     final Iterator<Map.Entry<K, V>> iterator;
/*      */     Map.Entry<K, V> entry;
/*      */     
/*      */     ValuesIterator(UnboundedLocalCache<K, V> cache) {
/*  681 */       this.cache = Objects.<UnboundedLocalCache<K, V>>requireNonNull(cache);
/*  682 */       this.iterator = cache.data.entrySet().iterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/*  687 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public V next() {
/*  692 */       this.entry = this.iterator.next();
/*  693 */       return this.entry.getValue();
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/*  698 */       if (this.entry == null) {
/*  699 */         throw new IllegalStateException();
/*      */       }
/*  701 */       this.cache.remove(this.entry.getKey());
/*  702 */       this.entry = null;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EntrySetView<K, V>
/*      */     extends AbstractSet<Map.Entry<K, V>> {
/*      */     final UnboundedLocalCache<K, V> cache;
/*      */     
/*      */     EntrySetView(UnboundedLocalCache<K, V> cache) {
/*  711 */       this.cache = Objects.<UnboundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  716 */       return this.cache.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  721 */       return this.cache.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/*  726 */       this.cache.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object o) {
/*  731 */       if (!(o instanceof Map.Entry)) {
/*  732 */         return false;
/*      */       }
/*  734 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)o;
/*  735 */       V value = this.cache.get(entry.getKey());
/*  736 */       return (value != null && value.equals(entry.getValue()));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object obj) {
/*  741 */       if (!(obj instanceof Map.Entry)) {
/*  742 */         return false;
/*      */       }
/*  744 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)obj;
/*  745 */       return this.cache.remove(entry.getKey(), entry.getValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeIf(Predicate<? super Map.Entry<K, V>> filter) {
/*  750 */       Objects.requireNonNull(filter);
/*  751 */       boolean removed = false;
/*  752 */       for (Map.Entry<K, V> entry : this.cache.data.entrySet()) {
/*  753 */         if (filter.test(entry)) {
/*  754 */           removed |= this.cache.remove(entry.getKey(), entry.getValue());
/*      */         }
/*      */       } 
/*  757 */       return removed;
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<Map.Entry<K, V>> iterator() {
/*  762 */       return new UnboundedLocalCache.EntryIterator<>(this.cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public Spliterator<Map.Entry<K, V>> spliterator() {
/*  767 */       return new UnboundedLocalCache.EntrySpliterator<>(this.cache);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EntryIterator<K, V>
/*      */     implements Iterator<Map.Entry<K, V>> {
/*      */     final UnboundedLocalCache<K, V> cache;
/*      */     final Iterator<Map.Entry<K, V>> iterator;
/*      */     Map.Entry<K, V> entry;
/*      */     
/*      */     EntryIterator(UnboundedLocalCache<K, V> cache) {
/*  778 */       this.cache = Objects.<UnboundedLocalCache<K, V>>requireNonNull(cache);
/*  779 */       this.iterator = cache.data.entrySet().iterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/*  784 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public Map.Entry<K, V> next() {
/*  789 */       this.entry = this.iterator.next();
/*  790 */       return new WriteThroughEntry<>(this.cache, this.entry.getKey(), this.entry.getValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/*  795 */       if (this.entry == null) {
/*  796 */         throw new IllegalStateException();
/*      */       }
/*  798 */       this.cache.remove(this.entry.getKey());
/*  799 */       this.entry = null;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EntrySpliterator<K, V>
/*      */     implements Spliterator<Map.Entry<K, V>> {
/*      */     final Spliterator<Map.Entry<K, V>> spliterator;
/*      */     final UnboundedLocalCache<K, V> cache;
/*      */     
/*      */     EntrySpliterator(UnboundedLocalCache<K, V> cache) {
/*  809 */       this(cache, cache.data.entrySet().spliterator());
/*      */     }
/*      */     
/*      */     EntrySpliterator(UnboundedLocalCache<K, V> cache, Spliterator<Map.Entry<K, V>> spliterator) {
/*  813 */       this.spliterator = Objects.<Spliterator<Map.Entry<K, V>>>requireNonNull(spliterator);
/*  814 */       this.cache = Objects.<UnboundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public void forEachRemaining(Consumer<? super Map.Entry<K, V>> action) {
/*  819 */       Objects.requireNonNull(action);
/*  820 */       this.spliterator.forEachRemaining(entry -> {
/*      */             Map.Entry<K, V> e = new WriteThroughEntry<>(this.cache, (K)entry.getKey(), (V)entry.getValue());
/*      */             action.accept(e);
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryAdvance(Consumer<? super Map.Entry<K, V>> action) {
/*  828 */       Objects.requireNonNull(action);
/*  829 */       return this.spliterator.tryAdvance(entry -> {
/*      */             Map.Entry<K, V> e = new WriteThroughEntry<>(this.cache, (K)entry.getKey(), (V)entry.getValue());
/*      */             action.accept(e);
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     public EntrySpliterator<K, V> trySplit() {
/*  837 */       Spliterator<Map.Entry<K, V>> split = this.spliterator.trySplit();
/*  838 */       return (split == null) ? null : new EntrySpliterator(this.cache, split);
/*      */     }
/*      */ 
/*      */     
/*      */     public long estimateSize() {
/*  843 */       return this.spliterator.estimateSize();
/*      */     }
/*      */ 
/*      */     
/*      */     public int characteristics() {
/*  848 */       return this.spliterator.characteristics();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class UnboundedLocalManualCache<K, V>
/*      */     implements LocalManualCache<K, V>, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     final UnboundedLocalCache<K, V> cache;
/*      */     Policy<K, V> policy;
/*      */     
/*      */     UnboundedLocalManualCache(Caffeine<K, V> builder) {
/*  861 */       this.cache = new UnboundedLocalCache<>(builder, false);
/*      */     }
/*      */ 
/*      */     
/*      */     public UnboundedLocalCache<K, V> cache() {
/*  866 */       return this.cache;
/*      */     }
/*      */ 
/*      */     
/*      */     public Policy<K, V> policy() {
/*  871 */       return (this.policy == null) ? (
/*  872 */         this.policy = new UnboundedLocalCache.UnboundedPolicy<>(this.cache, Function.identity())) : 
/*  873 */         this.policy;
/*      */     }
/*      */ 
/*      */     
/*      */     private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/*  878 */       throw new InvalidObjectException("Proxy required");
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/*  882 */       SerializationProxy<K, V> proxy = new SerializationProxy<>();
/*  883 */       proxy.isRecordingStats = this.cache.isRecordingStats;
/*  884 */       proxy.removalListener = this.cache.removalListener;
/*  885 */       proxy.ticker = this.cache.ticker;
/*  886 */       proxy.writer = this.cache.writer;
/*  887 */       return proxy;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class UnboundedPolicy<K, V>
/*      */     implements Policy<K, V> {
/*      */     final UnboundedLocalCache<K, V> cache;
/*      */     final Function<V, V> transformer;
/*      */     
/*      */     UnboundedPolicy(UnboundedLocalCache<K, V> cache, Function<V, V> transformer) {
/*  897 */       this.transformer = transformer;
/*  898 */       this.cache = cache;
/*      */     }
/*      */     public boolean isRecordingStats() {
/*  901 */       return this.cache.isRecordingStats;
/*      */     }
/*      */     public V getIfPresentQuietly(Object key) {
/*  904 */       return this.transformer.apply(this.cache.data.get(key));
/*      */     }
/*      */     public Optional<Policy.Eviction<K, V>> eviction() {
/*  907 */       return Optional.empty();
/*      */     }
/*      */     public Optional<Policy.Expiration<K, V>> expireAfterAccess() {
/*  910 */       return Optional.empty();
/*      */     }
/*      */     public Optional<Policy.Expiration<K, V>> expireAfterWrite() {
/*  913 */       return Optional.empty();
/*      */     }
/*      */     public Optional<Policy.Expiration<K, V>> refreshAfterWrite() {
/*  916 */       return Optional.empty();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class UnboundedLocalLoadingCache<K, V>
/*      */     extends UnboundedLocalManualCache<K, V>
/*      */     implements LocalLoadingCache<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     final Function<K, V> mappingFunction;
/*      */     final CacheLoader<? super K, V> loader;
/*      */     final Function<Iterable<? extends K>, Map<K, V>> bulkMappingFunction;
/*      */     
/*      */     UnboundedLocalLoadingCache(Caffeine<K, V> builder, CacheLoader<? super K, V> loader) {
/*  931 */       super(builder);
/*  932 */       this.loader = loader;
/*  933 */       this.mappingFunction = LocalLoadingCache.newMappingFunction(loader);
/*  934 */       this.bulkMappingFunction = LocalLoadingCache.newBulkMappingFunction(loader);
/*      */     }
/*      */ 
/*      */     
/*      */     public CacheLoader<? super K, V> cacheLoader() {
/*  939 */       return this.loader;
/*      */     }
/*      */ 
/*      */     
/*      */     public Function<K, V> mappingFunction() {
/*  944 */       return this.mappingFunction;
/*      */     }
/*      */ 
/*      */     
/*      */     public Function<Iterable<? extends K>, Map<K, V>> bulkMappingFunction() {
/*  949 */       return this.bulkMappingFunction;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     Object writeReplace() {
/*  955 */       SerializationProxy<K, V> proxy = (SerializationProxy<K, V>)super.writeReplace();
/*  956 */       proxy.loader = this.loader;
/*  957 */       return proxy;
/*      */     }
/*      */ 
/*      */     
/*      */     private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/*  962 */       throw new InvalidObjectException("Proxy required");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class UnboundedLocalAsyncCache<K, V>
/*      */     implements LocalAsyncCache<K, V>, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */     final UnboundedLocalCache<K, CompletableFuture<V>> cache;
/*      */     
/*      */     ConcurrentMap<K, CompletableFuture<V>> mapView;
/*      */     LocalAsyncCache.CacheView<K, V> cacheView;
/*      */     Policy<K, V> policy;
/*      */     
/*      */     UnboundedLocalAsyncCache(Caffeine<K, V> builder) {
/*  979 */       this.cache = new UnboundedLocalCache<>((Caffeine)builder, true);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public UnboundedLocalCache<K, CompletableFuture<V>> cache() {
/*  985 */       return this.cache;
/*      */     }
/*      */ 
/*      */     
/*      */     public ConcurrentMap<K, CompletableFuture<V>> asMap() {
/*  990 */       return (this.mapView == null) ? (this.mapView = new LocalAsyncCache.AsyncAsMapView<>(this)) : this.mapView;
/*      */     }
/*      */ 
/*      */     
/*      */     public Cache<K, V> synchronous() {
/*  995 */       return (this.cacheView == null) ? (this.cacheView = new LocalAsyncCache.CacheView<>(this)) : this.cacheView;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Policy<K, V> policy() {
/* 1001 */       UnboundedLocalCache<K, CompletableFuture<V>> unboundedLocalCache = this.cache;
/* 1002 */       Function<CompletableFuture<V>, V> transformer = Async::getIfReady;
/*      */       
/* 1004 */       Function<CompletableFuture<V>, V> function1 = transformer;
/* 1005 */       return (this.policy == null) ? (
/* 1006 */         this.policy = new UnboundedLocalCache.UnboundedPolicy<>((UnboundedLocalCache)unboundedLocalCache, (Function)function1)) : 
/* 1007 */         this.policy;
/*      */     }
/*      */ 
/*      */     
/*      */     private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 1012 */       throw new InvalidObjectException("Proxy required");
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/* 1016 */       SerializationProxy<K, V> proxy = new SerializationProxy<>();
/* 1017 */       proxy.isRecordingStats = this.cache.isRecordingStats;
/* 1018 */       proxy.removalListener = this.cache.removalListener;
/* 1019 */       proxy.ticker = this.cache.ticker;
/* 1020 */       proxy.writer = this.cache.writer;
/* 1021 */       proxy.async = true;
/* 1022 */       return proxy;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class UnboundedLocalAsyncLoadingCache<K, V>
/*      */     extends LocalAsyncLoadingCache<K, V>
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */     final UnboundedLocalCache<K, CompletableFuture<V>> cache;
/*      */     
/*      */     ConcurrentMap<K, CompletableFuture<V>> mapView;
/*      */     Policy<K, V> policy;
/*      */     
/*      */     UnboundedLocalAsyncLoadingCache(Caffeine<K, V> builder, AsyncCacheLoader<? super K, V> loader) {
/* 1039 */       super(loader);
/* 1040 */       this.cache = new UnboundedLocalCache<>((Caffeine)builder, true);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalCache<K, CompletableFuture<V>> cache() {
/* 1046 */       return this.cache;
/*      */     }
/*      */ 
/*      */     
/*      */     public ConcurrentMap<K, CompletableFuture<V>> asMap() {
/* 1051 */       return (this.mapView == null) ? (this.mapView = new LocalAsyncCache.AsyncAsMapView<>(this)) : this.mapView;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Policy<K, V> policy() {
/* 1057 */       UnboundedLocalCache<K, CompletableFuture<V>> unboundedLocalCache = this.cache;
/* 1058 */       Function<CompletableFuture<V>, V> transformer = Async::getIfReady;
/*      */       
/* 1060 */       Function<CompletableFuture<V>, V> function1 = transformer;
/* 1061 */       return (this.policy == null) ? (
/* 1062 */         this.policy = new UnboundedLocalCache.UnboundedPolicy<>((UnboundedLocalCache)unboundedLocalCache, (Function)function1)) : 
/* 1063 */         this.policy;
/*      */     }
/*      */ 
/*      */     
/*      */     private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 1068 */       throw new InvalidObjectException("Proxy required");
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/* 1072 */       SerializationProxy<K, V> proxy = new SerializationProxy<>();
/* 1073 */       proxy.isRecordingStats = this.cache.isRecordingStats();
/* 1074 */       proxy.removalListener = this.cache.removalListener();
/* 1075 */       proxy.ticker = this.cache.ticker;
/* 1076 */       proxy.writer = this.cache.writer;
/* 1077 */       proxy.loader = this.loader;
/* 1078 */       proxy.async = true;
/* 1079 */       return proxy;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\UnboundedLocalCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */