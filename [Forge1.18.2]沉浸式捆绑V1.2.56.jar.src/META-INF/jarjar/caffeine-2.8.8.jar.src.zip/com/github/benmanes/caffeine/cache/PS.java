/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PS<K, V>
/*     */   extends Node<K, V>
/*     */   implements NodeFactory<K, V>
/*     */ {
/*  34 */   protected static final long KEY_OFFSET = UnsafeAccess.objectFieldOffset(PS.class, "key");
/*     */ 
/*     */ 
/*     */   
/*  38 */   protected static final long VALUE_OFFSET = UnsafeAccess.objectFieldOffset(PS.class, "value");
/*     */ 
/*     */ 
/*     */   
/*     */   volatile K key;
/*     */ 
/*     */   
/*     */   volatile V value;
/*     */ 
/*     */ 
/*     */   
/*     */   PS() {}
/*     */ 
/*     */ 
/*     */   
/*     */   PS(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  54 */     this(key, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */   
/*     */   PS(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  58 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, keyReference);
/*  59 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, value);
/*     */   }
/*     */   
/*     */   public final K getKey() {
/*  63 */     return (K)UnsafeAccess.UNSAFE.getObject(this, KEY_OFFSET);
/*     */   }
/*     */   
/*     */   public final Object getKeyReference() {
/*  67 */     return UnsafeAccess.UNSAFE.getObject(this, KEY_OFFSET);
/*     */   }
/*     */   
/*     */   public final V getValue() {
/*  71 */     return (V)UnsafeAccess.UNSAFE.getObject(this, VALUE_OFFSET);
/*     */   }
/*     */   
/*     */   public final Object getValueReference() {
/*  75 */     return UnsafeAccess.UNSAFE.getObject(this, VALUE_OFFSET);
/*     */   }
/*     */   
/*     */   public final void setValue(V value, ReferenceQueue<V> referenceQueue) {
/*  79 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, value);
/*     */   }
/*     */   
/*     */   public final boolean containsValue(Object value) {
/*  83 */     return Objects.equals(value, getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  93 */     return new PS(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  98 */     return new PS(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */   
/*     */   public final boolean isAlive() {
/* 102 */     Object key = getKeyReference();
/* 103 */     return (key != RETIRED_STRONG_KEY && key != DEAD_STRONG_KEY);
/*     */   }
/*     */   
/*     */   public final boolean isRetired() {
/* 107 */     return (getKeyReference() == RETIRED_STRONG_KEY);
/*     */   }
/*     */   
/*     */   public final void retire() {
/* 111 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, RETIRED_STRONG_KEY);
/*     */   }
/*     */   
/*     */   public final boolean isDead() {
/* 115 */     return (getKeyReference() == DEAD_STRONG_KEY);
/*     */   }
/*     */   
/*     */   public final void die() {
/* 119 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, null);
/* 120 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, DEAD_STRONG_KEY);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */