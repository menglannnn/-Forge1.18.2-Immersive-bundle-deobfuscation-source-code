/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PSWMW<K, V>
/*     */   extends PSW<K, V>
/*     */ {
/*     */   int queueType;
/*     */   int weight;
/*     */   int policyWeight;
/*     */   Node<K, V> previousInAccessOrder;
/*     */   Node<K, V> nextInAccessOrder;
/*     */   
/*     */   PSWMW() {}
/*     */   
/*     */   PSWMW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  53 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*  54 */     this.weight = weight;
/*     */   }
/*     */   
/*     */   PSWMW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  58 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*  59 */     this.weight = weight;
/*     */   }
/*     */   
/*     */   public int getQueueType() {
/*  63 */     return this.queueType;
/*     */   }
/*     */   
/*     */   public void setQueueType(int queueType) {
/*  67 */     this.queueType = queueType;
/*     */   }
/*     */   
/*     */   public int getWeight() {
/*  71 */     return this.weight;
/*     */   }
/*     */   
/*     */   public void setWeight(int weight) {
/*  75 */     this.weight = weight;
/*     */   }
/*     */   
/*     */   public int getPolicyWeight() {
/*  79 */     return this.policyWeight;
/*     */   }
/*     */   
/*     */   public void setPolicyWeight(int policyWeight) {
/*  83 */     this.policyWeight = policyWeight;
/*     */   }
/*     */   
/*     */   public Node<K, V> getPreviousInAccessOrder() {
/*  87 */     return this.previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public void setPreviousInAccessOrder(Node<K, V> previousInAccessOrder) {
/*  91 */     this.previousInAccessOrder = previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public Node<K, V> getNextInAccessOrder() {
/*  95 */     return this.nextInAccessOrder;
/*     */   }
/*     */   
/*     */   public void setNextInAccessOrder(Node<K, V> nextInAccessOrder) {
/*  99 */     this.nextInAccessOrder = nextInAccessOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 109 */     return new PSWMW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 114 */     return new PSWMW(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PSWMW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */