/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BoundedWeigher<K, V>
/*    */   implements Weigher<K, V>, Serializable
/*    */ {
/*    */   static final long serialVersionUID = 1L;
/*    */   final Weigher<? super K, ? super V> delegate;
/*    */   
/*    */   BoundedWeigher(Weigher<? super K, ? super V> delegate) {
/* 88 */     this.delegate = Objects.<Weigher<? super K, ? super V>>requireNonNull(delegate);
/*    */   }
/*    */ 
/*    */   
/*    */   public int weigh(K key, V value) {
/* 93 */     int weight = this.delegate.weigh(key, value);
/* 94 */     Caffeine.requireArgument((weight >= 0));
/* 95 */     return weight;
/*    */   }
/*    */   
/*    */   Object writeReplace() {
/* 99 */     return this.delegate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\BoundedWeigher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */