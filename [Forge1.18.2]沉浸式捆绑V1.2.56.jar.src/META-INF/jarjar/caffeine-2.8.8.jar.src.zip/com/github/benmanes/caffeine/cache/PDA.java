/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PDA<K, V>
/*     */   extends PD<K, V>
/*     */ {
/*  34 */   protected static final long ACCESS_TIME_OFFSET = UnsafeAccess.objectFieldOffset(PDA.class, "accessTime");
/*     */ 
/*     */   
/*     */   volatile long accessTime;
/*     */ 
/*     */   
/*     */   Node<K, V> previousInAccessOrder;
/*     */ 
/*     */   
/*     */   Node<K, V> nextInAccessOrder;
/*     */ 
/*     */ 
/*     */   
/*     */   PDA() {}
/*     */ 
/*     */ 
/*     */   
/*     */   PDA(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  52 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*  53 */     UnsafeAccess.UNSAFE.putLong(this, ACCESS_TIME_OFFSET, now);
/*     */   }
/*     */   
/*     */   PDA(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  57 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*  58 */     UnsafeAccess.UNSAFE.putLong(this, ACCESS_TIME_OFFSET, now);
/*     */   }
/*     */   
/*     */   public Node<K, V> getPreviousInVariableOrder() {
/*  62 */     return this.previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public void setPreviousInVariableOrder(Node<K, V> previousInAccessOrder) {
/*  66 */     this.previousInAccessOrder = previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public Node<K, V> getNextInVariableOrder() {
/*  70 */     return this.nextInAccessOrder;
/*     */   }
/*     */   
/*     */   public void setNextInVariableOrder(Node<K, V> nextInAccessOrder) {
/*  74 */     this.nextInAccessOrder = nextInAccessOrder;
/*     */   }
/*     */   
/*     */   public long getVariableTime() {
/*  78 */     return UnsafeAccess.UNSAFE.getLong(this, ACCESS_TIME_OFFSET);
/*     */   }
/*     */   
/*     */   public void setVariableTime(long accessTime) {
/*  82 */     UnsafeAccess.UNSAFE.putLong(this, ACCESS_TIME_OFFSET, accessTime);
/*     */   }
/*     */   
/*     */   public boolean casVariableTime(long expect, long update) {
/*  86 */     return (this.accessTime == expect && UnsafeAccess.UNSAFE
/*  87 */       .compareAndSwapLong(this, ACCESS_TIME_OFFSET, expect, update));
/*     */   }
/*     */   
/*     */   public final long getAccessTime() {
/*  91 */     return UnsafeAccess.UNSAFE.getLong(this, ACCESS_TIME_OFFSET);
/*     */   }
/*     */   
/*     */   public final void setAccessTime(long accessTime) {
/*  95 */     UnsafeAccess.UNSAFE.putLong(this, ACCESS_TIME_OFFSET, accessTime);
/*     */   }
/*     */   
/*     */   public final Node<K, V> getPreviousInAccessOrder() {
/*  99 */     return this.previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public final void setPreviousInAccessOrder(Node<K, V> previousInAccessOrder) {
/* 103 */     this.previousInAccessOrder = previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public final Node<K, V> getNextInAccessOrder() {
/* 107 */     return this.nextInAccessOrder;
/*     */   }
/*     */   
/*     */   public final void setNextInAccessOrder(Node<K, V> nextInAccessOrder) {
/* 111 */     this.nextInAccessOrder = nextInAccessOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 121 */     return new PDA(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 126 */     return new PDA(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PDA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */