/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WILSMSAW<K, V>
/*    */   extends WILSMSA<K, V>
/*    */ {
/*    */   final WriteOrderDeque<Node<K, V>> writeOrderDeque;
/*    */   volatile long expiresAfterWriteNanos;
/*    */   
/*    */   WILSMSAW(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 40 */     super(builder, cacheLoader, async);
/* 41 */     this.writeOrderDeque = new WriteOrderDeque<>();
/* 42 */     this.expiresAfterWriteNanos = builder.getExpiresAfterWriteNanos();
/*    */   }
/*    */   
/*    */   protected final WriteOrderDeque<Node<K, V>> writeOrderDeque() {
/* 46 */     return this.writeOrderDeque;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterWrite() {
/* 50 */     return true;
/*    */   }
/*    */   
/*    */   protected final long expiresAfterWriteNanos() {
/* 54 */     return this.expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterWriteNanos(long expiresAfterWriteNanos) {
/* 58 */     this.expiresAfterWriteNanos = expiresAfterWriteNanos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\WILSMSAW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */