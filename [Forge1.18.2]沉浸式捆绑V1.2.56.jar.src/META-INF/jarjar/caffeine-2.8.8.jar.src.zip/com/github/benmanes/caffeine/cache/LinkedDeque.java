/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface LinkedDeque<E>
/*     */   extends Deque<E>
/*     */ {
/*     */   boolean isFirst(E paramE);
/*     */   
/*     */   boolean isLast(E paramE);
/*     */   
/*     */   void moveToFront(E paramE);
/*     */   
/*     */   void moveToBack(E paramE);
/*     */   
/*     */   E getPrevious(E paramE);
/*     */   
/*     */   void setPrevious(E paramE1, E paramE2);
/*     */   
/*     */   E getNext(E paramE);
/*     */   
/*     */   void setNext(E paramE1, E paramE2);
/*     */   
/*     */   PeekingIterator<E> iterator();
/*     */   
/*     */   PeekingIterator<E> descendingIterator();
/*     */   
/*     */   public static interface PeekingIterator<E>
/*     */     extends Iterator<E>
/*     */   {
/*     */     E peek();
/*     */     
/*     */     static <E> PeekingIterator<E> concat(final PeekingIterator<E> first, final PeekingIterator<E> second) {
/* 108 */       return new PeekingIterator<E>() {
/*     */           public boolean hasNext() {
/* 110 */             return (first.hasNext() || second.hasNext());
/*     */           }
/*     */           public E next() {
/* 113 */             if (first.hasNext())
/* 114 */               return first.next(); 
/* 115 */             if (second.hasNext()) {
/* 116 */               return second.next();
/*     */             }
/* 118 */             throw new NoSuchElementException();
/*     */           }
/*     */           public E peek() {
/* 121 */             return first.hasNext() ? first.peek() : second.peek();
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     static <E> PeekingIterator<E> comparing(final PeekingIterator<E> first, final PeekingIterator<E> second, final Comparator<E> comparator) {
/* 129 */       return new PeekingIterator<E>() {
/*     */           public boolean hasNext() {
/* 131 */             return (first.hasNext() || second.hasNext());
/*     */           }
/*     */           public E next() {
/* 134 */             if (!first.hasNext())
/* 135 */               return second.next(); 
/* 136 */             if (!second.hasNext()) {
/* 137 */               return first.next();
/*     */             }
/* 139 */             E o1 = first.peek();
/* 140 */             E o2 = second.peek();
/* 141 */             boolean greaterOrEqual = (comparator.compare(o1, o2) >= 0);
/* 142 */             return greaterOrEqual ? first.next() : second.next();
/*     */           }
/*     */           public E peek() {
/* 145 */             if (!first.hasNext())
/* 146 */               return second.peek(); 
/* 147 */             if (!second.hasNext()) {
/* 148 */               return first.peek();
/*     */             }
/* 150 */             E o1 = first.peek();
/* 151 */             E o2 = second.peek();
/* 152 */             boolean greaterOrEqual = (comparator.compare(o1, o2) >= 0);
/* 153 */             return greaterOrEqual ? first.peek() : second.peek();
/*     */           }
/*     */         };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\LinkedDeque.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */