/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AccessOrderDeque<E extends AccessOrderDeque.AccessOrder<E>>
/*    */   extends AbstractLinkedDeque<E>
/*    */ {
/*    */   public boolean contains(Object o) {
/* 34 */     return (o instanceof AccessOrder && contains((AccessOrder)o));
/*    */   }
/*    */ 
/*    */   
/*    */   boolean contains(AccessOrder<?> e) {
/* 39 */     return (e.getPreviousInAccessOrder() != null || e
/* 40 */       .getNextInAccessOrder() != null || e == this.first);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean remove(Object o) {
/* 47 */     return (o instanceof AccessOrder && remove((E)o));
/*    */   }
/*    */ 
/*    */   
/*    */   boolean remove(E e) {
/* 52 */     if (contains((AccessOrder<?>)e)) {
/* 53 */       unlink(e);
/* 54 */       return true;
/*    */     } 
/* 56 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public E getPrevious(E e) {
/* 61 */     return e.getPreviousInAccessOrder();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPrevious(E e, E prev) {
/* 66 */     e.setPreviousInAccessOrder(prev);
/*    */   }
/*    */ 
/*    */   
/*    */   public E getNext(E e) {
/* 71 */     return e.getNextInAccessOrder();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setNext(E e, E next) {
/* 76 */     e.setNextInAccessOrder(next);
/*    */   }
/*    */   
/*    */   static interface AccessOrder<T extends AccessOrder<T>> {
/*    */     T getPreviousInAccessOrder();
/*    */     
/*    */     void setPreviousInAccessOrder(T param1T);
/*    */     
/*    */     T getNextInAccessOrder();
/*    */     
/*    */     void setNextInAccessOrder(T param1T);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\AccessOrderDeque.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */