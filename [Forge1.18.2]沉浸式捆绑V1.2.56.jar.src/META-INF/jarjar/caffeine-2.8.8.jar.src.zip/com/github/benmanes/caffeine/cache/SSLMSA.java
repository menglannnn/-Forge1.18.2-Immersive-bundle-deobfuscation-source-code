/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SSLMSA<K, V>
/*    */   extends SSLMS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   final Expiry<K, V> expiry;
/*    */   final TimerWheel<K, V> timerWheel;
/*    */   volatile long expiresAfterAccessNanos;
/*    */   final Pacer pacer;
/*    */   
/*    */   SSLMSA(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 44 */     super(builder, cacheLoader, async);
/* 45 */     this.ticker = builder.getTicker();
/* 46 */     this.expiry = builder.getExpiry(this.isAsync);
/* 47 */     this.timerWheel = builder.expiresVariable() ? new TimerWheel<>(this) : null;
/* 48 */     this.expiresAfterAccessNanos = builder.getExpiresAfterAccessNanos();
/* 49 */     this
/*    */ 
/*    */       
/* 52 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*    */   }
/*    */   
/*    */   public final Ticker expirationTicker() {
/* 56 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected boolean fastpath() {
/* 60 */     return false;
/*    */   }
/*    */   
/*    */   protected final boolean expiresVariable() {
/* 64 */     return (this.timerWheel != null);
/*    */   }
/*    */   
/*    */   protected final Expiry<K, V> expiry() {
/* 68 */     return this.expiry;
/*    */   }
/*    */   
/*    */   protected final TimerWheel<K, V> timerWheel() {
/* 72 */     return this.timerWheel;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterAccess() {
/* 76 */     return (this.timerWheel == null);
/*    */   }
/*    */   
/*    */   protected final long expiresAfterAccessNanos() {
/* 80 */     return this.expiresAfterAccessNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterAccessNanos(long expiresAfterAccessNanos) {
/* 84 */     this.expiresAfterAccessNanos = expiresAfterAccessNanos;
/*    */   }
/*    */   
/*    */   public final Pacer pacer() {
/* 88 */     return this.pacer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSLMSA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */