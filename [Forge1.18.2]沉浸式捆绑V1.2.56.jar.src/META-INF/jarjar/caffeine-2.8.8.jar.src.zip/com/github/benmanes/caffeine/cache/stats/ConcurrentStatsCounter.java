/*     */ package com.github.benmanes.caffeine.cache.stats;
/*     */ 
/*     */ import com.github.benmanes.caffeine.cache.RemovalCause;
/*     */ import java.util.concurrent.atomic.LongAdder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConcurrentStatsCounter
/*     */   implements StatsCounter
/*     */ {
/*  43 */   private final LongAdder hitCount = new LongAdder();
/*  44 */   private final LongAdder missCount = new LongAdder();
/*  45 */   private final LongAdder loadSuccessCount = new LongAdder();
/*  46 */   private final LongAdder loadFailureCount = new LongAdder();
/*  47 */   private final LongAdder totalLoadTime = new LongAdder();
/*  48 */   private final LongAdder evictionCount = new LongAdder();
/*  49 */   private final LongAdder evictionWeight = new LongAdder();
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordHits(int count) {
/*  54 */     this.hitCount.add(count);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordMisses(int count) {
/*  59 */     this.missCount.add(count);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordLoadSuccess(long loadTime) {
/*  64 */     this.loadSuccessCount.increment();
/*  65 */     this.totalLoadTime.add(loadTime);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordLoadFailure(long loadTime) {
/*  70 */     this.loadFailureCount.increment();
/*  71 */     this.totalLoadTime.add(loadTime);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void recordEviction() {
/*  77 */     this.evictionCount.increment();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void recordEviction(int weight) {
/*  83 */     this.evictionCount.increment();
/*  84 */     this.evictionWeight.add(weight);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordEviction(int weight, RemovalCause cause) {
/*  89 */     this.evictionCount.increment();
/*  90 */     this.evictionWeight.add(weight);
/*     */   }
/*     */ 
/*     */   
/*     */   public CacheStats snapshot() {
/*  95 */     return new CacheStats(
/*  96 */         negativeToMaxValue(this.hitCount.sum()), 
/*  97 */         negativeToMaxValue(this.missCount.sum()), 
/*  98 */         negativeToMaxValue(this.loadSuccessCount.sum()), 
/*  99 */         negativeToMaxValue(this.loadFailureCount.sum()), 
/* 100 */         negativeToMaxValue(this.totalLoadTime.sum()), 
/* 101 */         negativeToMaxValue(this.evictionCount.sum()), 
/* 102 */         negativeToMaxValue(this.evictionWeight.sum()));
/*     */   }
/*     */ 
/*     */   
/*     */   private static long negativeToMaxValue(long value) {
/* 107 */     return (value >= 0L) ? value : Long.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementBy(StatsCounter other) {
/* 116 */     CacheStats otherStats = other.snapshot();
/* 117 */     this.hitCount.add(otherStats.hitCount());
/* 118 */     this.missCount.add(otherStats.missCount());
/* 119 */     this.loadSuccessCount.add(otherStats.loadSuccessCount());
/* 120 */     this.loadFailureCount.add(otherStats.loadFailureCount());
/* 121 */     this.totalLoadTime.add(otherStats.totalLoadTime());
/* 122 */     this.evictionCount.add(otherStats.evictionCount());
/* 123 */     this.evictionWeight.add(otherStats.evictionWeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 128 */     return snapshot().toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\stats\ConcurrentStatsCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */