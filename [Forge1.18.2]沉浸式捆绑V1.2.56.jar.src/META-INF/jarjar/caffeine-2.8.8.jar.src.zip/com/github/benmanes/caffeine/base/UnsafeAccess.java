/*    */ package com.github.benmanes.caffeine.base;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import sun.misc.Unsafe;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class UnsafeAccess
/*    */ {
/*    */   static final String ANDROID = "THE_ONE";
/*    */   static final String OPEN_JDK = "theUnsafe";
/*    */   public static final Unsafe UNSAFE;
/*    */   
/*    */   static {
/*    */     try {
/* 44 */       UNSAFE = load("theUnsafe", "THE_ONE");
/* 45 */     } catch (Exception e) {
/* 46 */       throw new Error("Failed to load sun.misc.Unsafe", e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static long objectFieldOffset(Class<?> clazz, String fieldName) {
/*    */     try {
/* 59 */       return UNSAFE.objectFieldOffset(clazz.getDeclaredField(fieldName));
/* 60 */     } catch (NoSuchFieldException|SecurityException e) {
/* 61 */       throw new Error(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static Unsafe load(String openJdk, String android) throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
/*    */     Field field;
/*    */     try {
/* 70 */       field = Unsafe.class.getDeclaredField(openJdk);
/* 71 */     } catch (NoSuchFieldException e) {
/*    */       
/*    */       try {
/* 74 */         field = Unsafe.class.getDeclaredField(android);
/* 75 */       } catch (NoSuchFieldException e2) {
/*    */         
/* 77 */         Constructor<Unsafe> unsafeConstructor = Unsafe.class.getDeclaredConstructor(new Class[0]);
/* 78 */         unsafeConstructor.setAccessible(true);
/* 79 */         return unsafeConstructor.newInstance(new Object[0]);
/*    */       } 
/*    */     } 
/* 82 */     field.setAccessible(true);
/* 83 */     return (Unsafe)field.get(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\base\UnsafeAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */