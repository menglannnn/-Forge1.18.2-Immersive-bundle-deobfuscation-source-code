/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.Executor;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Pacer
/*    */ {
/* 35 */   static final long TOLERANCE = Caffeine.ceilingPowerOfTwo(TimeUnit.SECONDS.toNanos(1L));
/*    */   
/*    */   final Scheduler scheduler;
/*    */   
/*    */   long nextFireTime;
/*    */   Future<?> future;
/*    */   
/*    */   Pacer(Scheduler scheduler) {
/* 43 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler);
/*    */   }
/*    */ 
/*    */   
/*    */   public void schedule(Executor executor, Runnable command, long now, long delay) {
/* 48 */     long scheduleAt = now + delay;
/*    */     
/* 50 */     if (this.future == null) {
/*    */       
/* 52 */       if (this.nextFireTime != 0L) {
/*    */         return;
/*    */       }
/* 55 */     } else if (this.nextFireTime - now > 0L) {
/*    */       
/* 57 */       if (maySkip(scheduleAt)) {
/*    */         return;
/*    */       }
/* 60 */       this.future.cancel(false);
/*    */     } 
/* 62 */     long actualDelay = calculateSchedule(now, delay, scheduleAt);
/* 63 */     this.future = this.scheduler.schedule(executor, command, actualDelay, TimeUnit.NANOSECONDS);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean maySkip(long scheduleAt) {
/* 70 */     long delta = scheduleAt - this.nextFireTime;
/* 71 */     return (delta >= 0L || -delta <= TOLERANCE);
/*    */   }
/*    */ 
/*    */   
/*    */   long calculateSchedule(long now, long delay, long scheduleAt) {
/* 76 */     if (delay <= TOLERANCE) {
/*    */       
/* 78 */       this.nextFireTime = now + TOLERANCE;
/* 79 */       return TOLERANCE;
/*    */     } 
/* 81 */     this.nextFireTime = scheduleAt;
/* 82 */     return delay;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\Pacer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */