/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SILSW<K, V>
/*    */   extends SILS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   final WriteOrderDeque<Node<K, V>> writeOrderDeque;
/*    */   volatile long expiresAfterWriteNanos;
/*    */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*    */   final Pacer pacer;
/*    */   
/*    */   SILSW(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 44 */     super(builder, cacheLoader, async);
/* 45 */     this.ticker = builder.getTicker();
/* 46 */     this.writeOrderDeque = new WriteOrderDeque<>();
/* 47 */     this.expiresAfterWriteNanos = builder.getExpiresAfterWriteNanos();
/* 48 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/* 49 */     this
/*    */ 
/*    */       
/* 52 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*    */   }
/*    */   
/*    */   public final Ticker expirationTicker() {
/* 56 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected final WriteOrderDeque<Node<K, V>> writeOrderDeque() {
/* 60 */     return this.writeOrderDeque;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterWrite() {
/* 64 */     return true;
/*    */   }
/*    */   
/*    */   protected final long expiresAfterWriteNanos() {
/* 68 */     return this.expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterWriteNanos(long expiresAfterWriteNanos) {
/* 72 */     this.expiresAfterWriteNanos = expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected final MpscGrowableArrayQueue<Runnable> writeBuffer() {
/* 76 */     return this.writeBuffer;
/*    */   }
/*    */   
/*    */   protected final boolean buffersWrites() {
/* 80 */     return true;
/*    */   }
/*    */   
/*    */   public final Pacer pacer() {
/* 84 */     return this.pacer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SILSW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */