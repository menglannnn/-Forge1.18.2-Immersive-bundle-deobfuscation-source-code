/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PDWRMS<K, V>
/*    */   extends PDWR<K, V>
/*    */ {
/*    */   int queueType;
/*    */   Node<K, V> previousInAccessOrder;
/*    */   Node<K, V> nextInAccessOrder;
/*    */   
/*    */   PDWRMS() {}
/*    */   
/*    */   PDWRMS(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 50 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   PDWRMS(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 55 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   public int getQueueType() {
/* 59 */     return this.queueType;
/*    */   }
/*    */   
/*    */   public void setQueueType(int queueType) {
/* 63 */     this.queueType = queueType;
/*    */   }
/*    */   
/*    */   public Node<K, V> getPreviousInAccessOrder() {
/* 67 */     return this.previousInAccessOrder;
/*    */   }
/*    */   
/*    */   public void setPreviousInAccessOrder(Node<K, V> previousInAccessOrder) {
/* 71 */     this.previousInAccessOrder = previousInAccessOrder;
/*    */   }
/*    */   
/*    */   public Node<K, V> getNextInAccessOrder() {
/* 75 */     return this.nextInAccessOrder;
/*    */   }
/*    */   
/*    */   public void setNextInAccessOrder(Node<K, V> nextInAccessOrder) {
/* 79 */     this.nextInAccessOrder = nextInAccessOrder;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 89 */     return new PDWRMS(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 94 */     return new PDWRMS(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PDWRMS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */