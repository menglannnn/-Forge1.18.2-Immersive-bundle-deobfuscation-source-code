/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import com.google.errorprone.annotations.concurrent.GuardedBy;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Node<K, V>
/*     */   implements AccessOrderDeque.AccessOrder<Node<K, V>>, WriteOrderDeque.WriteOrder<Node<K, V>>
/*     */ {
/*     */   public static final int WINDOW = 0;
/*     */   public static final int PROBATION = 1;
/*     */   public static final int PROTECTED = 2;
/*     */   
/*     */   @GuardedBy("this")
/*     */   public int getWeight() {
/*  76 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @GuardedBy("this")
/*     */   public void setWeight(int weight) {}
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public int getPolicyWeight() {
/*  87 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public void setPolicyWeight(int weight) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getVariableTime() {
/* 122 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariableTime(long time) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean casVariableTime(long expect, long update) {
/* 136 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public Node<K, V> getPreviousInVariableOrder() {
/* 141 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public void setPreviousInVariableOrder(Node<K, V> prev) {
/* 146 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public Node<K, V> getNextInVariableOrder() {
/* 151 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public void setNextInVariableOrder(Node<K, V> prev) {
/* 156 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean inWindow() {
/* 167 */     return (getQueueType() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inMainProbation() {
/* 172 */     return (getQueueType() == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inMainProtected() {
/* 177 */     return (getQueueType() == 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void makeWindow() {
/* 182 */     setQueueType(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void makeMainProbation() {
/* 187 */     setQueueType(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void makeMainProtected() {
/* 192 */     setQueueType(2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getQueueType() {
/* 197 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setQueueType(int queueType) {
/* 202 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAccessTime() {
/* 207 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessTime(long time) {}
/*     */ 
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public Node<K, V> getPreviousInAccessOrder() {
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public void setPreviousInAccessOrder(Node<K, V> prev) {
/* 225 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public Node<K, V> getNextInAccessOrder() {
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public void setNextInAccessOrder(Node<K, V> next) {
/* 237 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getWriteTime() {
/* 244 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWriteTime(long time) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean casWriteTime(long expect, long update) {
/* 258 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public Node<K, V> getPreviousInWriteOrder() {
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public void setPreviousInWriteOrder(Node<K, V> prev) {
/* 270 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public Node<K, V> getNextInWriteOrder() {
/* 276 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @GuardedBy("evictionLock")
/*     */   public void setNextInWriteOrder(Node<K, V> next) {
/* 282 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 287 */     return String.format("%s=[key=%s, value=%s, weight=%d, queueType=%,d, accessTimeNS=%,d, writeTimeNS=%,d, varTimeNs=%,d, prevInAccess=%s, nextInAccess=%s, prevInWrite=%s, nextInWrite=%s]", new Object[] {
/*     */           
/* 289 */           getClass().getSimpleName(), getKey(), getValue(), Integer.valueOf(getWeight()), 
/* 290 */           Integer.valueOf(getQueueType()), Long.valueOf(getAccessTime()), Long.valueOf(getWriteTime()), Long.valueOf(getVariableTime()), 
/* 291 */           Boolean.valueOf((getPreviousInAccessOrder() != null)), Boolean.valueOf((getNextInAccessOrder() != null)), 
/* 292 */           Boolean.valueOf((getPreviousInWriteOrder() != null)), Boolean.valueOf((getNextInWriteOrder() != null))
/*     */         });
/*     */   }
/*     */   
/*     */   public abstract K getKey();
/*     */   
/*     */   public abstract Object getKeyReference();
/*     */   
/*     */   public abstract V getValue();
/*     */   
/*     */   public abstract Object getValueReference();
/*     */   
/*     */   @GuardedBy("this")
/*     */   public abstract void setValue(V paramV, ReferenceQueue<V> paramReferenceQueue);
/*     */   
/*     */   public abstract boolean containsValue(Object paramObject);
/*     */   
/*     */   public abstract boolean isAlive();
/*     */   
/*     */   @GuardedBy("this")
/*     */   public abstract boolean isRetired();
/*     */   
/*     */   @GuardedBy("this")
/*     */   public abstract boolean isDead();
/*     */   
/*     */   @GuardedBy("this")
/*     */   public abstract void retire();
/*     */   
/*     */   @GuardedBy("this")
/*     */   public abstract void die();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */