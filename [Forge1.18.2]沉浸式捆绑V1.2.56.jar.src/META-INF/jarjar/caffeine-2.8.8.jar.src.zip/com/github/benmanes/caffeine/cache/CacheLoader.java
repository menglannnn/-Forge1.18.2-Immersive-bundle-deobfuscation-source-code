/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.CompletionException;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface CacheLoader<K, V>
/*     */   extends AsyncCacheLoader<K, V>
/*     */ {
/*     */   default Map<K, V> loadAll(Iterable<? extends K> keys) throws Exception {
/*  88 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default CompletableFuture<V> asyncLoad(K key, Executor executor) {
/* 100 */     Objects.requireNonNull(key);
/* 101 */     Objects.requireNonNull(executor);
/* 102 */     return CompletableFuture.supplyAsync(() -> {
/*     */           try {
/*     */             return (Supplier)load((K)key);
/* 105 */           } catch (RuntimeException e) {
/*     */             throw e;
/* 107 */           } catch (Exception e) {
/*     */             throw new CompletionException(e);
/*     */           } 
/*     */         }executor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default CompletableFuture<Map<K, V>> asyncLoadAll(Iterable<? extends K> keys, Executor executor) {
/* 134 */     Objects.requireNonNull(keys);
/* 135 */     Objects.requireNonNull(executor);
/* 136 */     return CompletableFuture.supplyAsync(() -> {
/*     */           try {
/*     */             return loadAll(keys);
/* 139 */           } catch (RuntimeException e) {
/*     */             throw e;
/* 141 */           } catch (Exception e) {
/*     */             throw new CompletionException(e);
/*     */           } 
/*     */         }executor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default V reload(K key, V oldValue) throws Exception {
/* 166 */     return load(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default CompletableFuture<V> asyncReload(K key, V oldValue, Executor executor) {
/* 186 */     Objects.requireNonNull(key);
/* 187 */     Objects.requireNonNull(executor);
/* 188 */     return CompletableFuture.supplyAsync(() -> {
/*     */           try {
/*     */             return (Supplier)reload((K)key, (V)oldValue);
/* 191 */           } catch (RuntimeException e) {
/*     */             throw e;
/* 193 */           } catch (Exception e) {
/*     */             throw new CompletionException(e);
/*     */           } 
/*     */         }executor);
/*     */   }
/*     */   
/*     */   V load(K paramK) throws Exception;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\CacheLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */