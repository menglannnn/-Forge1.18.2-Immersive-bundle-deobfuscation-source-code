/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FDAMS<K, V>
/*    */   extends FDA<K, V>
/*    */ {
/*    */   int queueType;
/*    */   
/*    */   FDAMS() {}
/*    */   
/*    */   FDAMS(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 45 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   FDAMS(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 49 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   public int getQueueType() {
/* 53 */     return this.queueType;
/*    */   }
/*    */   
/*    */   public void setQueueType(int queueType) {
/* 57 */     this.queueType = queueType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 67 */     return new FDAMS(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 72 */     return new FDAMS(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FDAMS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */