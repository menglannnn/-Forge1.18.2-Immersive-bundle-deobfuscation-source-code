/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SSMSA<K, V>
/*    */   extends SSMS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   final Expiry<K, V> expiry;
/*    */   final TimerWheel<K, V> timerWheel;
/*    */   volatile long expiresAfterAccessNanos;
/*    */   final Pacer pacer;
/*    */   
/*    */   SSMSA(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 43 */     super(builder, cacheLoader, async);
/* 44 */     this.ticker = builder.getTicker();
/* 45 */     this.expiry = builder.getExpiry(this.isAsync);
/* 46 */     this.timerWheel = builder.expiresVariable() ? new TimerWheel<>(this) : null;
/* 47 */     this.expiresAfterAccessNanos = builder.getExpiresAfterAccessNanos();
/* 48 */     this
/*    */ 
/*    */       
/* 51 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*    */   }
/*    */   
/*    */   public final Ticker expirationTicker() {
/* 55 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected boolean fastpath() {
/* 59 */     return false;
/*    */   }
/*    */   
/*    */   protected final boolean expiresVariable() {
/* 63 */     return (this.timerWheel != null);
/*    */   }
/*    */   
/*    */   protected final Expiry<K, V> expiry() {
/* 67 */     return this.expiry;
/*    */   }
/*    */   
/*    */   protected final TimerWheel<K, V> timerWheel() {
/* 71 */     return this.timerWheel;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterAccess() {
/* 75 */     return (this.timerWheel == null);
/*    */   }
/*    */   
/*    */   protected final long expiresAfterAccessNanos() {
/* 79 */     return this.expiresAfterAccessNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterAccessNanos(long expiresAfterAccessNanos) {
/* 83 */     this.expiresAfterAccessNanos = expiresAfterAccessNanos;
/*    */   }
/*    */   
/*    */   public final Pacer pacer() {
/* 87 */     return this.pacer;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSMSA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */