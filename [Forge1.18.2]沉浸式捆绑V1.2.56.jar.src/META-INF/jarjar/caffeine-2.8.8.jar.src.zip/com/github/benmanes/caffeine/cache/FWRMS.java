/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FWRMS<K, V>
/*    */   extends FWR<K, V>
/*    */ {
/*    */   int queueType;
/*    */   Node<K, V> previousInAccessOrder;
/*    */   Node<K, V> nextInAccessOrder;
/*    */   
/*    */   FWRMS() {}
/*    */   
/*    */   FWRMS(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 49 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   FWRMS(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 53 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   public int getQueueType() {
/* 57 */     return this.queueType;
/*    */   }
/*    */   
/*    */   public void setQueueType(int queueType) {
/* 61 */     this.queueType = queueType;
/*    */   }
/*    */   
/*    */   public Node<K, V> getPreviousInAccessOrder() {
/* 65 */     return this.previousInAccessOrder;
/*    */   }
/*    */   
/*    */   public void setPreviousInAccessOrder(Node<K, V> previousInAccessOrder) {
/* 69 */     this.previousInAccessOrder = previousInAccessOrder;
/*    */   }
/*    */   
/*    */   public Node<K, V> getNextInAccessOrder() {
/* 73 */     return this.nextInAccessOrder;
/*    */   }
/*    */   
/*    */   public void setNextInAccessOrder(Node<K, V> nextInAccessOrder) {
/* 77 */     this.nextInAccessOrder = nextInAccessOrder;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 87 */     return new FWRMS(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 92 */     return new FWRMS(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FWRMS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */