/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SIAW<K, V>
/*    */   extends SIA<K, V>
/*    */ {
/*    */   final WriteOrderDeque<Node<K, V>> writeOrderDeque;
/*    */   volatile long expiresAfterWriteNanos;
/*    */   
/*    */   SIAW(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 37 */     super(builder, cacheLoader, async);
/* 38 */     this.writeOrderDeque = new WriteOrderDeque<>();
/* 39 */     this.expiresAfterWriteNanos = builder.getExpiresAfterWriteNanos();
/*    */   }
/*    */   
/*    */   protected final WriteOrderDeque<Node<K, V>> writeOrderDeque() {
/* 43 */     return this.writeOrderDeque;
/*    */   }
/*    */   
/*    */   protected final boolean expiresAfterWrite() {
/* 47 */     return true;
/*    */   }
/*    */   
/*    */   protected final long expiresAfterWriteNanos() {
/* 51 */     return this.expiresAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected final void setExpiresAfterWriteNanos(long expiresAfterWriteNanos) {
/* 55 */     this.expiresAfterWriteNanos = expiresAfterWriteNanos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SIAW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */