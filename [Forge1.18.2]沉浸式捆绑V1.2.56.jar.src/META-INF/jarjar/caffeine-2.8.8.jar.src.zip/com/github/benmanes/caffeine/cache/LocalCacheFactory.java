/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class LocalCacheFactory
/*    */ {
/*    */   public static final String MAXIMUM = "maximum";
/*    */   public static final String WINDOW_MAXIMUM = "windowMaximum";
/*    */   public static final String MAIN_PROTECTED_MAXIMUM = "mainProtectedMaximum";
/*    */   public static final String WEIGHTED_SIZE = "weightedSize";
/*    */   public static final String WINDOW_WEIGHTED_SIZE = "windowWeightedSize";
/*    */   public static final String MAIN_PROTECTED_WEIGHTED_SIZE = "mainProtectedWeightedSize";
/*    */   public static final String KEY = "key";
/*    */   public static final String VALUE = "value";
/*    */   public static final String ACCESS_TIME = "accessTime";
/*    */   public static final String WRITE_TIME = "writeTime";
/*    */   
/*    */   static <K, V> BoundedLocalCache<K, V> newBoundedLocalCache(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 52 */     StringBuilder sb = new StringBuilder("com.github.benmanes.caffeine.cache.");
/* 53 */     if (builder.isStrongKeys()) {
/* 54 */       sb.append('S');
/*    */     } else {
/* 56 */       sb.append('W');
/*    */     } 
/* 58 */     if (builder.isStrongValues()) {
/* 59 */       sb.append('S');
/*    */     } else {
/* 61 */       sb.append('I');
/*    */     } 
/* 63 */     if (builder.removalListener != null) {
/* 64 */       sb.append('L');
/*    */     }
/* 66 */     if (builder.isRecordingStats()) {
/* 67 */       sb.append('S');
/*    */     }
/* 69 */     if (builder.evicts()) {
/* 70 */       sb.append('M');
/* 71 */       if (builder.isWeighted()) {
/* 72 */         sb.append('W');
/*    */       } else {
/* 74 */         sb.append('S');
/*    */       } 
/*    */     } 
/* 77 */     if (builder.expiresAfterAccess() || builder.expiresVariable()) {
/* 78 */       sb.append('A');
/*    */     }
/* 80 */     if (builder.expiresAfterWrite()) {
/* 81 */       sb.append('W');
/*    */     }
/* 83 */     if (builder.refreshAfterWrite()) {
/* 84 */       sb.append('R');
/*    */     }
/*    */     try {
/* 87 */       Class<?> clazz = Class.forName(sb.toString());
/*    */       
/* 89 */       Constructor<?> ctor = clazz.getDeclaredConstructor(new Class[] { Caffeine.class, CacheLoader.class, boolean.class });
/*    */ 
/*    */       
/* 92 */       BoundedLocalCache<K, V> factory = (BoundedLocalCache<K, V>)ctor.newInstance(new Object[] { builder, cacheLoader, Boolean.valueOf(async) });
/* 93 */       return factory;
/* 94 */     } catch (ReflectiveOperationException e) {
/* 95 */       throw new IllegalStateException(sb.toString(), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\LocalCacheFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */