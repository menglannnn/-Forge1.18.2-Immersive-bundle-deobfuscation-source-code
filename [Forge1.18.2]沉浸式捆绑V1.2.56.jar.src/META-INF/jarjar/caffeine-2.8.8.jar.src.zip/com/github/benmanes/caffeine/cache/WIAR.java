/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WIAR<K, V>
/*    */   extends WIA<K, V>
/*    */ {
/*    */   volatile long refreshAfterWriteNanos;
/*    */   
/*    */   WIAR(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 35 */     super(builder, cacheLoader, async);
/* 36 */     this.refreshAfterWriteNanos = builder.getRefreshAfterWriteNanos();
/*    */   }
/*    */   
/*    */   protected boolean refreshAfterWrite() {
/* 40 */     return true;
/*    */   }
/*    */   
/*    */   protected long refreshAfterWriteNanos() {
/* 44 */     return this.refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/* 48 */     this.refreshAfterWriteNanos = refreshAfterWriteNanos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\WIAR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */