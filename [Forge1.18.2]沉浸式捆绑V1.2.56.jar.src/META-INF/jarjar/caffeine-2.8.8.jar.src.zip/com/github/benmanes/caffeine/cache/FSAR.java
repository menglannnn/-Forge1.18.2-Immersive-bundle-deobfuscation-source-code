/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FSAR<K, V>
/*    */   extends FSA<K, V>
/*    */ {
/* 35 */   protected static final long WRITE_TIME_OFFSET = UnsafeAccess.objectFieldOffset(FSAR.class, "writeTime");
/*    */ 
/*    */ 
/*    */   
/*    */   volatile long writeTime;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   FSAR() {}
/*    */ 
/*    */ 
/*    */   
/*    */   FSAR(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 49 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/* 50 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, now);
/*    */   }
/*    */   
/*    */   FSAR(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 54 */     super(keyReference, value, valueReferenceQueue, weight, now);
/* 55 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, now);
/*    */   }
/*    */   
/*    */   public final long getWriteTime() {
/* 59 */     return UnsafeAccess.UNSAFE.getLong(this, WRITE_TIME_OFFSET);
/*    */   }
/*    */   
/*    */   public final void setWriteTime(long writeTime) {
/* 63 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, writeTime);
/*    */   }
/*    */   
/*    */   public final boolean casWriteTime(long expect, long update) {
/* 67 */     return (this.writeTime == expect && UnsafeAccess.UNSAFE
/* 68 */       .compareAndSwapLong(this, WRITE_TIME_OFFSET, expect, update));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 78 */     return new FSAR(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 83 */     return new FSAR(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FSAR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */