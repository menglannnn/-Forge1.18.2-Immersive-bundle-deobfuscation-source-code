/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FrequencySketch<E>
/*     */ {
/*  55 */   static final long[] SEED = new long[] { -4348849565147123417L, -5435081209227447693L, -7286425919675154353L, -3750763034362895579L };
/*     */ 
/*     */ 
/*     */   
/*     */   static final long RESET_MASK = 8608480567731124087L;
/*     */ 
/*     */ 
/*     */   
/*     */   static final long ONE_MASK = 1229782938247303441L;
/*     */ 
/*     */   
/*     */   int sampleSize;
/*     */ 
/*     */   
/*     */   int tableMask;
/*     */ 
/*     */   
/*     */   long[] table;
/*     */ 
/*     */   
/*     */   int size;
/*     */ 
/*     */ 
/*     */   
/*     */   public void ensureCapacity(long maximumSize) {
/*  80 */     Caffeine.requireArgument((maximumSize >= 0L));
/*  81 */     int maximum = (int)Math.min(maximumSize, 1073741823L);
/*  82 */     if (this.table != null && this.table.length >= maximum) {
/*     */       return;
/*     */     }
/*     */     
/*  86 */     this.table = new long[(maximum == 0) ? 1 : Caffeine.ceilingPowerOfTwo(maximum)];
/*  87 */     this.tableMask = Math.max(0, this.table.length - 1);
/*  88 */     this.sampleSize = (maximumSize == 0L) ? 10 : (10 * maximum);
/*  89 */     if (this.sampleSize <= 0) {
/*  90 */       this.sampleSize = Integer.MAX_VALUE;
/*     */     }
/*  92 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotInitialized() {
/* 100 */     return (this.table == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int frequency(E e) {
/* 111 */     if (isNotInitialized()) {
/* 112 */       return 0;
/*     */     }
/*     */     
/* 115 */     int hash = spread(e.hashCode());
/* 116 */     int start = (hash & 0x3) << 2;
/* 117 */     int frequency = Integer.MAX_VALUE;
/* 118 */     for (int i = 0; i < 4; i++) {
/* 119 */       int index = indexOf(hash, i);
/* 120 */       int count = (int)(this.table[index] >>> start + i << 2 & 0xFL);
/* 121 */       frequency = Math.min(frequency, count);
/*     */     } 
/* 123 */     return frequency;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void increment(E e) {
/* 134 */     if (isNotInitialized()) {
/*     */       return;
/*     */     }
/*     */     
/* 138 */     int hash = spread(e.hashCode());
/* 139 */     int start = (hash & 0x3) << 2;
/*     */ 
/*     */     
/* 142 */     int index0 = indexOf(hash, 0);
/* 143 */     int index1 = indexOf(hash, 1);
/* 144 */     int index2 = indexOf(hash, 2);
/* 145 */     int index3 = indexOf(hash, 3);
/*     */     
/* 147 */     boolean added = incrementAt(index0, start);
/* 148 */     added |= incrementAt(index1, start + 1);
/* 149 */     added |= incrementAt(index2, start + 2);
/* 150 */     added |= incrementAt(index3, start + 3);
/*     */     
/* 152 */     if (added && ++this.size == this.sampleSize) {
/* 153 */       reset();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean incrementAt(int i, int j) {
/* 165 */     int offset = j << 2;
/* 166 */     long mask = 15L << offset;
/* 167 */     if ((this.table[i] & mask) != mask) {
/* 168 */       this.table[i] = this.table[i] + (1L << offset);
/* 169 */       return true;
/*     */     } 
/* 171 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   void reset() {
/* 176 */     int count = 0;
/* 177 */     for (int i = 0; i < this.table.length; i++) {
/* 178 */       count += Long.bitCount(this.table[i] & 0x1111111111111111L);
/* 179 */       this.table[i] = this.table[i] >>> 1L & 0x7777777777777777L;
/*     */     } 
/* 181 */     this.size = (this.size >>> 1) - (count >>> 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int indexOf(int item, int i) {
/* 192 */     long hash = (item + SEED[i]) * SEED[i];
/* 193 */     hash += hash >>> 32L;
/* 194 */     return (int)hash & this.tableMask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int spread(int x) {
/* 202 */     x = (x >>> 16 ^ x) * 73244475;
/* 203 */     x = (x >>> 16 ^ x) * 73244475;
/* 204 */     return x >>> 16 ^ x;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FrequencySketch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */