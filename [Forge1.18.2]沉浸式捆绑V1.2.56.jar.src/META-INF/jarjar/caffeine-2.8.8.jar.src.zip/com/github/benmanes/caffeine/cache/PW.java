/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PW<K, V>
/*     */   extends Node<K, V>
/*     */   implements NodeFactory<K, V>
/*     */ {
/*  35 */   protected static final long KEY_OFFSET = UnsafeAccess.objectFieldOffset(PW.class, "key");
/*     */ 
/*     */ 
/*     */   
/*  39 */   protected static final long VALUE_OFFSET = UnsafeAccess.objectFieldOffset(PW.class, "value");
/*     */ 
/*     */ 
/*     */   
/*     */   volatile K key;
/*     */ 
/*     */   
/*     */   volatile References.WeakValueReference<V> value;
/*     */ 
/*     */ 
/*     */   
/*     */   PW() {}
/*     */ 
/*     */ 
/*     */   
/*     */   PW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  55 */     this(key, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */   
/*     */   PW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  59 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, keyReference);
/*  60 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, new References.WeakValueReference<>(keyReference, value, valueReferenceQueue));
/*     */   }
/*     */ 
/*     */   
/*     */   public final K getKey() {
/*  65 */     return (K)UnsafeAccess.UNSAFE.getObject(this, KEY_OFFSET);
/*     */   }
/*     */   
/*     */   public final Object getKeyReference() {
/*  69 */     return UnsafeAccess.UNSAFE.getObject(this, KEY_OFFSET);
/*     */   }
/*     */   
/*     */   public final V getValue() {
/*  73 */     return ((Reference<V>)UnsafeAccess.UNSAFE.getObject(this, VALUE_OFFSET)).get();
/*     */   }
/*     */   
/*     */   public final Object getValueReference() {
/*  77 */     return UnsafeAccess.UNSAFE.getObject(this, VALUE_OFFSET);
/*     */   }
/*     */   
/*     */   public final void setValue(V value, ReferenceQueue<V> referenceQueue) {
/*  81 */     ((Reference)getValueReference()).clear();
/*  82 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, new References.WeakValueReference<>(
/*  83 */           getKeyReference(), value, referenceQueue));
/*     */   }
/*     */   
/*     */   public final boolean containsValue(Object value) {
/*  87 */     return (getValue() == value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  97 */     return new PW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 102 */     return new PW(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */   
/*     */   public boolean weakValues() {
/* 106 */     return true;
/*     */   }
/*     */   
/*     */   public final boolean isAlive() {
/* 110 */     Object key = getKeyReference();
/* 111 */     return (key != RETIRED_STRONG_KEY && key != DEAD_STRONG_KEY);
/*     */   }
/*     */   
/*     */   public final boolean isRetired() {
/* 115 */     return (getKeyReference() == RETIRED_STRONG_KEY);
/*     */   }
/*     */   
/*     */   public final void retire() {
/* 119 */     ((Reference)getValueReference()).clear();
/* 120 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, RETIRED_STRONG_KEY);
/*     */   }
/*     */   
/*     */   public final boolean isDead() {
/* 124 */     return (getKeyReference() == DEAD_STRONG_KEY);
/*     */   }
/*     */   
/*     */   public final void die() {
/* 128 */     ((Reference)getValueReference()).clear();
/* 129 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, DEAD_STRONG_KEY);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */