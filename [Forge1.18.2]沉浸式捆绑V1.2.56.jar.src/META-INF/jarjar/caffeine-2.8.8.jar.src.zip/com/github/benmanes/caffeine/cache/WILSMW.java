/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WILSMW<K, V>
/*     */   extends WILS<K, V>
/*     */ {
/*     */   long maximum;
/*     */   long weightedSize;
/*     */   long windowMaximum;
/*     */   long windowWeightedSize;
/*     */   long mainProtectedMaximum;
/*     */   long mainProtectedWeightedSize;
/*     */   double stepSize;
/*     */   long adjustment;
/*     */   int hitsInSample;
/*     */   int missesInSample;
/*     */   double previousSampleHitRate;
/*     */   final FrequencySketch<K> sketch;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderProbationDeque;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderProtectedDeque;
/*     */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*     */   
/*     */   WILSMW(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/*  66 */     super(builder, cacheLoader, async);
/*  67 */     this.sketch = new FrequencySketch<>();
/*  68 */     if (builder.hasInitialCapacity()) {
/*  69 */       long capacity = Math.min(builder.getMaximum(), builder.getInitialCapacity());
/*  70 */       this.sketch.ensureCapacity(capacity);
/*     */     } 
/*  72 */     this
/*     */ 
/*     */       
/*  75 */       .accessOrderWindowDeque = (builder.evicts() || builder.expiresAfterAccess()) ? new AccessOrderDeque<>() : null;
/*  76 */     this.accessOrderProbationDeque = new AccessOrderDeque<>();
/*  77 */     this.accessOrderProtectedDeque = new AccessOrderDeque<>();
/*  78 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*     */   }
/*     */   
/*     */   protected final boolean evicts() {
/*  82 */     return true;
/*     */   }
/*     */   
/*     */   protected final long maximum() {
/*  86 */     return this.maximum;
/*     */   }
/*     */   
/*     */   protected final void setMaximum(long maximum) {
/*  90 */     this.maximum = maximum;
/*     */   }
/*     */   
/*     */   protected final long weightedSize() {
/*  94 */     return this.weightedSize;
/*     */   }
/*     */   
/*     */   protected final void setWeightedSize(long weightedSize) {
/*  98 */     this.weightedSize = weightedSize;
/*     */   }
/*     */   
/*     */   protected final long windowMaximum() {
/* 102 */     return this.windowMaximum;
/*     */   }
/*     */   
/*     */   protected final void setWindowMaximum(long windowMaximum) {
/* 106 */     this.windowMaximum = windowMaximum;
/*     */   }
/*     */   
/*     */   protected final long windowWeightedSize() {
/* 110 */     return this.windowWeightedSize;
/*     */   }
/*     */   
/*     */   protected final void setWindowWeightedSize(long windowWeightedSize) {
/* 114 */     this.windowWeightedSize = windowWeightedSize;
/*     */   }
/*     */   
/*     */   protected final long mainProtectedMaximum() {
/* 118 */     return this.mainProtectedMaximum;
/*     */   }
/*     */   
/*     */   protected final void setMainProtectedMaximum(long mainProtectedMaximum) {
/* 122 */     this.mainProtectedMaximum = mainProtectedMaximum;
/*     */   }
/*     */   
/*     */   protected final long mainProtectedWeightedSize() {
/* 126 */     return this.mainProtectedWeightedSize;
/*     */   }
/*     */   
/*     */   protected final void setMainProtectedWeightedSize(long mainProtectedWeightedSize) {
/* 130 */     this.mainProtectedWeightedSize = mainProtectedWeightedSize;
/*     */   }
/*     */   
/*     */   protected final double stepSize() {
/* 134 */     return this.stepSize;
/*     */   }
/*     */   
/*     */   protected final void setStepSize(double stepSize) {
/* 138 */     this.stepSize = stepSize;
/*     */   }
/*     */   
/*     */   protected final long adjustment() {
/* 142 */     return this.adjustment;
/*     */   }
/*     */   
/*     */   protected final void setAdjustment(long adjustment) {
/* 146 */     this.adjustment = adjustment;
/*     */   }
/*     */   
/*     */   protected final int hitsInSample() {
/* 150 */     return this.hitsInSample;
/*     */   }
/*     */   
/*     */   protected final void setHitsInSample(int hitsInSample) {
/* 154 */     this.hitsInSample = hitsInSample;
/*     */   }
/*     */   
/*     */   protected final int missesInSample() {
/* 158 */     return this.missesInSample;
/*     */   }
/*     */   
/*     */   protected final void setMissesInSample(int missesInSample) {
/* 162 */     this.missesInSample = missesInSample;
/*     */   }
/*     */   
/*     */   protected final double previousSampleHitRate() {
/* 166 */     return this.previousSampleHitRate;
/*     */   }
/*     */   
/*     */   protected final void setPreviousSampleHitRate(double previousSampleHitRate) {
/* 170 */     this.previousSampleHitRate = previousSampleHitRate;
/*     */   }
/*     */   
/*     */   protected final FrequencySketch<K> frequencySketch() {
/* 174 */     return this.sketch;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque() {
/* 178 */     return this.accessOrderWindowDeque;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderProbationDeque() {
/* 182 */     return this.accessOrderProbationDeque;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderProtectedDeque() {
/* 186 */     return this.accessOrderProtectedDeque;
/*     */   }
/*     */   
/*     */   protected final MpscGrowableArrayQueue<Runnable> writeBuffer() {
/* 190 */     return this.writeBuffer;
/*     */   }
/*     */   
/*     */   protected final boolean buffersWrites() {
/* 194 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\WILSMW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */