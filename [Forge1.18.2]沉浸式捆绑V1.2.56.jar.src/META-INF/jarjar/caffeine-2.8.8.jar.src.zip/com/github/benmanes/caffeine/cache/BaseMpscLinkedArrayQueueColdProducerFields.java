package com.github.benmanes.caffeine.cache;

abstract class BaseMpscLinkedArrayQueueColdProducerFields<E> extends BaseMpscLinkedArrayQueuePad3<E> {
  protected volatile long producerLimit;
  
  protected long producerMask;
  
  protected E[] producerBuffer;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\BaseMpscLinkedArrayQueueColdProducerFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */