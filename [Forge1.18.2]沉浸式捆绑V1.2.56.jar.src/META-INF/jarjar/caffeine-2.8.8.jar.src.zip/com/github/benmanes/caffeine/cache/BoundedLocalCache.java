/*      */ package com.github.benmanes.caffeine.cache;
/*      */ 
/*      */ import com.github.benmanes.caffeine.cache.stats.StatsCounter;
/*      */ import com.google.errorprone.annotations.concurrent.GuardedBy;
/*      */ import java.io.InvalidObjectException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.ReferenceQueue;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.OptionalInt;
/*      */ import java.util.OptionalLong;
/*      */ import java.util.Set;
/*      */ import java.util.Spliterator;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.concurrent.CompletionStage;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.ForkJoinPool;
/*      */ import java.util.concurrent.ForkJoinTask;
/*      */ import java.util.concurrent.ThreadLocalRandom;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class BoundedLocalCache<K, V>
/*      */   extends BLCHeader.DrainStatusRef<K, V>
/*      */   implements LocalCache<K, V>
/*      */ {
/*  183 */   static final Logger logger = Logger.getLogger(BoundedLocalCache.class.getName());
/*      */ 
/*      */   
/*  186 */   static final int NCPU = Runtime.getRuntime().availableProcessors();
/*      */   
/*      */   static final int WRITE_BUFFER_MIN = 4;
/*      */   
/*  190 */   static final int WRITE_BUFFER_MAX = 128 * Caffeine.ceilingPowerOfTwo(NCPU);
/*      */   
/*      */   static final int WRITE_BUFFER_RETRIES = 100;
/*      */   
/*      */   static final long MAXIMUM_CAPACITY = 9223372034707292160L;
/*      */   
/*      */   static final double PERCENT_MAIN = 0.99D;
/*      */   
/*      */   static final double PERCENT_MAIN_PROTECTED = 0.8D;
/*      */   
/*      */   static final double HILL_CLIMBER_RESTART_THRESHOLD = 0.05D;
/*      */   
/*      */   static final double HILL_CLIMBER_STEP_PERCENT = 0.0625D;
/*      */   
/*      */   static final double HILL_CLIMBER_STEP_DECAY_RATE = 0.98D;
/*      */   
/*      */   static final int QUEUE_TRANSFER_THRESHOLD = 1000;
/*      */   
/*  208 */   static final long EXPIRE_WRITE_TOLERANCE = TimeUnit.SECONDS.toNanos(1L);
/*      */   
/*      */   static final long MAXIMUM_EXPIRY = 4611686018427387903L;
/*      */   
/*      */   final ConcurrentHashMap<Object, Node<K, V>> data;
/*      */   
/*      */   final CacheLoader<K, V> cacheLoader;
/*      */   
/*      */   final PerformCleanupTask drainBuffersTask;
/*      */   
/*      */   final Consumer<Node<K, V>> accessPolicy;
/*      */   
/*      */   final Buffer<Node<K, V>> readBuffer;
/*      */   final NodeFactory<K, V> nodeFactory;
/*      */   final ReentrantLock evictionLock;
/*      */   final CacheWriter<K, V> writer;
/*      */   final Weigher<K, V> weigher;
/*      */   final Executor executor;
/*      */   final boolean isAsync;
/*      */   transient Set<K> keySet;
/*      */   transient Collection<V> values;
/*      */   transient Set<Map.Entry<K, V>> entrySet;
/*      */   
/*      */   protected BoundedLocalCache(Caffeine<K, V> builder, CacheLoader<K, V> cacheLoader, boolean isAsync) {
/*  232 */     this.isAsync = isAsync;
/*  233 */     this.cacheLoader = cacheLoader;
/*  234 */     this.executor = builder.getExecutor();
/*  235 */     this.writer = builder.getCacheWriter();
/*  236 */     this.evictionLock = new ReentrantLock();
/*  237 */     this.weigher = builder.getWeigher(isAsync);
/*  238 */     this.drainBuffersTask = new PerformCleanupTask(this);
/*  239 */     this.nodeFactory = NodeFactory.newFactory(builder, isAsync);
/*  240 */     this.data = new ConcurrentHashMap<>(builder.getInitialCapacity());
/*  241 */     this
/*      */       
/*  243 */       .readBuffer = (evicts() || collectKeys() || collectValues() || expiresAfterAccess()) ? new BoundedBuffer<>() : Buffer.<Node<K, V>>disabled();
/*  244 */     this.accessPolicy = (evicts() || expiresAfterAccess()) ? this::onAccess : (e -> {
/*      */       
/*  246 */       }); if (evicts()) {
/*  247 */       setMaximumSize(builder.getMaximum());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isComputingAsync(Node<?, ?> node) {
/*  255 */     return (this.isAsync && !Async.isReady((CompletableFuture)node.getValue()));
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected AccessOrderDeque<Node<K, V>> accessOrderWindowDeque() {
/*  260 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected AccessOrderDeque<Node<K, V>> accessOrderProbationDeque() {
/*  265 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected AccessOrderDeque<Node<K, V>> accessOrderProtectedDeque() {
/*  270 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected WriteOrderDeque<Node<K, V>> writeOrderDeque() {
/*  275 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean buffersWrites() {
/*  280 */     return false;
/*      */   }
/*      */   
/*      */   protected MpscGrowableArrayQueue<Runnable> writeBuffer() {
/*  284 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final Executor executor() {
/*  289 */     return this.executor;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean hasWriter() {
/*  294 */     return (this.writer != CacheWriter.disabledWriter());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRecordingStats() {
/*  301 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public StatsCounter statsCounter() {
/*  306 */     return StatsCounter.disabledStatsCounter();
/*      */   }
/*      */ 
/*      */   
/*      */   public Ticker statsTicker() {
/*  311 */     return Ticker.disabledTicker();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RemovalListener<K, V> removalListener() {
/*  319 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasRemovalListener() {
/*  324 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void notifyRemoval(K key, V value, RemovalCause cause) {
/*  329 */     Caffeine.requireState(hasRemovalListener(), "Notification should be guarded with a check", new Object[0]);
/*  330 */     Runnable task = () -> {
/*      */         try {
/*      */           removalListener().onRemoval((K)key, (V)value, cause);
/*  333 */         } catch (Throwable t) {
/*      */           logger.log(Level.WARNING, "Exception thrown by removal listener", t);
/*      */         } 
/*      */       };
/*      */     try {
/*  338 */       this.executor.execute(task);
/*  339 */     } catch (Throwable t) {
/*  340 */       logger.log(Level.SEVERE, "Exception thrown when submitting removal listener", t);
/*  341 */       task.run();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean collectKeys() {
/*  349 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean collectValues() {
/*  354 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected ReferenceQueue<K> keyReferenceQueue() {
/*  359 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected ReferenceQueue<V> valueReferenceQueue() {
/*  364 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Pacer pacer() {
/*  371 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean expiresVariable() {
/*  376 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean expiresAfterAccess() {
/*  381 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected long expiresAfterAccessNanos() {
/*  386 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected void setExpiresAfterAccessNanos(long expireAfterAccessNanos) {
/*  390 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean expiresAfterWrite() {
/*  395 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected long expiresAfterWriteNanos() {
/*  400 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected void setExpiresAfterWriteNanos(long expireAfterWriteNanos) {
/*  404 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean refreshAfterWrite() {
/*  409 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected long refreshAfterWriteNanos() {
/*  414 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/*  418 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasWriteTime() {
/*  423 */     return (expiresAfterWrite() || refreshAfterWrite());
/*      */   }
/*      */ 
/*      */   
/*      */   protected Expiry<K, V> expiry() {
/*  428 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Ticker expirationTicker() {
/*  433 */     return Ticker.disabledTicker();
/*      */   }
/*      */   
/*      */   protected TimerWheel<K, V> timerWheel() {
/*  437 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean evicts() {
/*  444 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isWeighted() {
/*  449 */     return (this.weigher != Weigher.singletonWeigher());
/*      */   }
/*      */   
/*      */   protected FrequencySketch<K> frequencySketch() {
/*  453 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean fastpath() {
/*  458 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected long maximum() {
/*  463 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected long windowMaximum() {
/*  468 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected long mainProtectedMaximum() {
/*  473 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setMaximum(long maximum) {
/*  478 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setWindowMaximum(long maximum) {
/*  483 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setMainProtectedMaximum(long maximum) {
/*  488 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected long weightedSize() {
/*  493 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected long windowWeightedSize() {
/*  498 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   protected long mainProtectedWeightedSize() {
/*  503 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setWeightedSize(long weightedSize) {
/*  508 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setWindowWeightedSize(long weightedSize) {
/*  513 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setMainProtectedWeightedSize(long weightedSize) {
/*  518 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected int hitsInSample() {
/*  522 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected int missesInSample() {
/*  526 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected int sampleCount() {
/*  530 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected double stepSize() {
/*  534 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected double previousSampleHitRate() {
/*  538 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected long adjustment() {
/*  542 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setHitsInSample(int hitCount) {
/*  547 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setMissesInSample(int missCount) {
/*  552 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setSampleCount(int sampleCount) {
/*  557 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setStepSize(double stepSize) {
/*  562 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setPreviousSampleHitRate(double hitRate) {
/*  567 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   protected void setAdjustment(long amount) {
/*  572 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void setMaximumSize(long maximum) {
/*  581 */     Caffeine.requireArgument((maximum >= 0L), "maximum must not be negative", new Object[0]);
/*  582 */     if (maximum == maximum()) {
/*      */       return;
/*      */     }
/*      */     
/*  586 */     long max = Math.min(maximum, 9223372034707292160L);
/*  587 */     long window = max - (long)(0.99D * max);
/*  588 */     long mainProtected = (long)(0.8D * (max - window));
/*      */     
/*  590 */     setMaximum(max);
/*  591 */     setWindowMaximum(window);
/*  592 */     setMainProtectedMaximum(mainProtected);
/*      */     
/*  594 */     setHitsInSample(0);
/*  595 */     setMissesInSample(0);
/*  596 */     setStepSize(-0.0625D * max);
/*      */     
/*  598 */     if (frequencySketch() != null && !isWeighted() && weightedSize() >= max >>> 1L)
/*      */     {
/*  600 */       frequencySketch().ensureCapacity(max);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void evictEntries() {
/*  607 */     if (!evicts()) {
/*      */       return;
/*      */     }
/*  610 */     int candidates = evictFromWindow();
/*  611 */     evictFromMain(candidates);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   int evictFromWindow() {
/*  622 */     int candidates = 0;
/*  623 */     Node<K, V> node = accessOrderWindowDeque().peek();
/*  624 */     while (windowWeightedSize() > windowMaximum()) {
/*      */       
/*  626 */       if (node == null) {
/*      */         break;
/*      */       }
/*      */       
/*  630 */       Node<K, V> next = node.getNextInAccessOrder();
/*  631 */       if (node.getPolicyWeight() != 0) {
/*  632 */         node.makeMainProbation();
/*  633 */         accessOrderWindowDeque().remove(node);
/*  634 */         accessOrderProbationDeque().add(node);
/*  635 */         candidates++;
/*      */         
/*  637 */         setWindowWeightedSize(windowWeightedSize() - node.getPolicyWeight());
/*      */       } 
/*  639 */       node = next;
/*      */     } 
/*      */     
/*  642 */     return candidates;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void evictFromMain(int candidates) {
/*  660 */     int victimQueue = 1;
/*  661 */     Node<K, V> victim = accessOrderProbationDeque().peekFirst();
/*  662 */     Node<K, V> candidate = accessOrderProbationDeque().peekLast();
/*  663 */     while (weightedSize() > maximum()) {
/*      */       
/*  665 */       if (candidates == 0) {
/*  666 */         candidate = null;
/*      */       }
/*      */ 
/*      */       
/*  670 */       if (candidate == null && victim == null) {
/*  671 */         if (victimQueue == 1) {
/*  672 */           victim = accessOrderProtectedDeque().peekFirst();
/*  673 */           victimQueue = 2; continue;
/*      */         } 
/*  675 */         if (victimQueue == 2) {
/*  676 */           victim = accessOrderWindowDeque().peekFirst();
/*  677 */           victimQueue = 0;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/*  686 */       if (victim != null && victim.getPolicyWeight() == 0) {
/*  687 */         victim = victim.getNextInAccessOrder(); continue;
/*      */       } 
/*  689 */       if (candidate != null && candidate.getPolicyWeight() == 0) {
/*  690 */         candidate = candidate.getPreviousInAccessOrder();
/*  691 */         candidates--;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  696 */       if (victim == null) {
/*      */         
/*  698 */         Node<K, V> previous = candidate.getPreviousInAccessOrder();
/*  699 */         Node<K, V> node1 = candidate;
/*  700 */         candidate = previous;
/*  701 */         candidates--;
/*  702 */         evictEntry(node1, RemovalCause.SIZE, 0L); continue;
/*      */       } 
/*  704 */       if (candidate == null) {
/*  705 */         Node<K, V> node = victim;
/*  706 */         victim = victim.getNextInAccessOrder();
/*  707 */         evictEntry(node, RemovalCause.SIZE, 0L);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  712 */       K victimKey = victim.getKey();
/*  713 */       K candidateKey = candidate.getKey();
/*  714 */       if (victimKey == null) {
/*  715 */         Node<K, V> node = victim;
/*  716 */         victim = victim.getNextInAccessOrder();
/*  717 */         evictEntry(node, RemovalCause.COLLECTED, 0L); continue;
/*      */       } 
/*  719 */       if (candidateKey == null) {
/*  720 */         candidates--;
/*  721 */         Node<K, V> node = candidate;
/*  722 */         candidate = candidate.getPreviousInAccessOrder();
/*  723 */         evictEntry(node, RemovalCause.COLLECTED, 0L);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  728 */       if (candidate.getPolicyWeight() > maximum()) {
/*  729 */         candidates--;
/*  730 */         Node<K, V> node = candidate;
/*  731 */         candidate = candidate.getPreviousInAccessOrder();
/*  732 */         evictEntry(node, RemovalCause.SIZE, 0L);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  737 */       candidates--;
/*  738 */       if (admit(candidateKey, victimKey)) {
/*  739 */         Node<K, V> node = victim;
/*  740 */         victim = victim.getNextInAccessOrder();
/*  741 */         evictEntry(node, RemovalCause.SIZE, 0L);
/*  742 */         candidate = candidate.getPreviousInAccessOrder(); continue;
/*      */       } 
/*  744 */       Node<K, V> evict = candidate;
/*  745 */       candidate = candidate.getPreviousInAccessOrder();
/*  746 */       evictEntry(evict, RemovalCause.SIZE, 0L);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   boolean admit(K candidateKey, K victimKey) {
/*  763 */     int victimFreq = frequencySketch().frequency(victimKey);
/*  764 */     int candidateFreq = frequencySketch().frequency(candidateKey);
/*  765 */     if (candidateFreq > victimFreq)
/*  766 */       return true; 
/*  767 */     if (candidateFreq <= 5)
/*      */     {
/*      */ 
/*      */       
/*  771 */       return false;
/*      */     }
/*  773 */     int random = ThreadLocalRandom.current().nextInt();
/*  774 */     return ((random & 0x7F) == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void expireEntries() {
/*  780 */     long now = expirationTicker().read();
/*  781 */     expireAfterAccessEntries(now);
/*  782 */     expireAfterWriteEntries(now);
/*  783 */     expireVariableEntries(now);
/*      */     
/*  785 */     Pacer pacer = pacer();
/*  786 */     if (pacer != null) {
/*  787 */       long delay = getExpirationDelay(now);
/*  788 */       if (delay != Long.MAX_VALUE) {
/*  789 */         pacer.schedule(this.executor, this.drainBuffersTask, now, delay);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void expireAfterAccessEntries(long now) {
/*  797 */     if (!expiresAfterAccess()) {
/*      */       return;
/*      */     }
/*      */     
/*  801 */     expireAfterAccessEntries(accessOrderWindowDeque(), now);
/*  802 */     if (evicts()) {
/*  803 */       expireAfterAccessEntries(accessOrderProbationDeque(), now);
/*  804 */       expireAfterAccessEntries(accessOrderProtectedDeque(), now);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void expireAfterAccessEntries(AccessOrderDeque<Node<K, V>> accessOrderDeque, long now) {
/*  811 */     long duration = expiresAfterAccessNanos();
/*      */     while (true) {
/*  813 */       Node<K, V> node = accessOrderDeque.peekFirst();
/*  814 */       if (node == null || now - node.getAccessTime() < duration) {
/*      */         return;
/*      */       }
/*  817 */       evictEntry(node, RemovalCause.EXPIRED, now);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void expireAfterWriteEntries(long now) {
/*  824 */     if (!expiresAfterWrite()) {
/*      */       return;
/*      */     }
/*  827 */     long duration = expiresAfterWriteNanos();
/*      */     while (true) {
/*  829 */       Node<K, V> node = writeOrderDeque().peekFirst();
/*  830 */       if (node == null || now - node.getWriteTime() < duration) {
/*      */         break;
/*      */       }
/*  833 */       evictEntry(node, RemovalCause.EXPIRED, now);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void expireVariableEntries(long now) {
/*  840 */     if (expiresVariable()) {
/*  841 */       timerWheel().advance(now);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   private long getExpirationDelay(long now) {
/*  848 */     long delay = Long.MAX_VALUE;
/*  849 */     if (expiresAfterAccess()) {
/*  850 */       Node<K, V> node = accessOrderWindowDeque().peekFirst();
/*  851 */       if (node != null) {
/*  852 */         delay = Math.min(delay, expiresAfterAccessNanos() - now - node.getAccessTime());
/*      */       }
/*  854 */       if (evicts()) {
/*  855 */         node = accessOrderProbationDeque().peekFirst();
/*  856 */         if (node != null) {
/*  857 */           delay = Math.min(delay, expiresAfterAccessNanos() - now - node.getAccessTime());
/*      */         }
/*  859 */         node = accessOrderProtectedDeque().peekFirst();
/*  860 */         if (node != null) {
/*  861 */           delay = Math.min(delay, expiresAfterAccessNanos() - now - node.getAccessTime());
/*      */         }
/*      */       } 
/*      */     } 
/*  865 */     if (expiresAfterWrite()) {
/*  866 */       Node<K, V> node = writeOrderDeque().peekFirst();
/*  867 */       if (node != null) {
/*  868 */         delay = Math.min(delay, expiresAfterWriteNanos() - now - node.getWriteTime());
/*      */       }
/*      */     } 
/*  871 */     if (expiresVariable()) {
/*  872 */       delay = Math.min(delay, timerWheel().getExpirationDelay());
/*      */     }
/*  874 */     return delay;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean hasExpired(Node<K, V> node, long now) {
/*  880 */     return ((expiresAfterAccess() && now - node.getAccessTime() >= expiresAfterAccessNanos())) | ((
/*  881 */       expiresAfterWrite() && now - node.getWriteTime() >= expiresAfterWriteNanos())) | ((
/*  882 */       expiresVariable() && now - node.getVariableTime() >= 0L) ? 1 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   boolean evictEntry(Node<K, V> node, RemovalCause cause, long now) {
/*  897 */     K key = node.getKey();
/*      */     
/*  899 */     V[] value = (V[])new Object[1];
/*  900 */     boolean[] removed = new boolean[1];
/*  901 */     boolean[] resurrect = new boolean[1];
/*  902 */     RemovalCause[] actualCause = new RemovalCause[1];
/*      */     
/*  904 */     this.data.computeIfPresent(node.getKeyReference(), (k, n) -> {
/*      */           if (n != node) {
/*      */             return n;
/*      */           }
/*      */           
/*      */           synchronized (n) {
/*      */             value[0] = n.getValue();
/*  911 */             actualCause[0] = (key == null || value[0] == null) ? RemovalCause.COLLECTED : cause;
/*      */             
/*      */             if (actualCause[0] == RemovalCause.EXPIRED) {
/*      */               int i;
/*      */               
/*      */               boolean expired = false;
/*      */               if (expiresAfterAccess()) {
/*      */                 i = expired | ((now - n.getAccessTime() >= expiresAfterAccessNanos()) ? 1 : 0);
/*      */               }
/*      */               if (expiresAfterWrite()) {
/*      */                 i |= (now - n.getWriteTime() >= expiresAfterWriteNanos()) ? 1 : 0;
/*      */               }
/*      */               if (expiresVariable()) {
/*      */                 i |= (n.getVariableTime() <= now) ? 1 : 0;
/*      */               }
/*      */               if (i == 0) {
/*      */                 resurrect[0] = true;
/*      */                 return n;
/*      */               } 
/*      */             } else if (actualCause[0] == RemovalCause.SIZE) {
/*      */               int weight = node.getWeight();
/*      */               if (weight == 0) {
/*      */                 resurrect[0] = true;
/*      */                 return n;
/*      */               } 
/*      */             } 
/*      */             if (key != null) {
/*      */               this.writer.delete((K)key, (V)value[0], actualCause[0]);
/*      */             }
/*      */             makeDead(n);
/*      */           } 
/*      */           removed[0] = true;
/*      */           return null;
/*      */         });
/*  945 */     if (resurrect[0]) {
/*  946 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  952 */     if (node.inWindow() && (evicts() || expiresAfterAccess())) {
/*  953 */       accessOrderWindowDeque().remove(node);
/*  954 */     } else if (evicts()) {
/*  955 */       if (node.inMainProbation()) {
/*  956 */         accessOrderProbationDeque().remove(node);
/*      */       } else {
/*  958 */         accessOrderProtectedDeque().remove(node);
/*      */       } 
/*      */     } 
/*  961 */     if (expiresAfterWrite()) {
/*  962 */       writeOrderDeque().remove(node);
/*  963 */     } else if (expiresVariable()) {
/*  964 */       timerWheel().deschedule(node);
/*      */     } 
/*      */     
/*  967 */     if (removed[0]) {
/*  968 */       statsCounter().recordEviction(node.getWeight(), actualCause[0]);
/*  969 */       if (hasRemovalListener())
/*      */       {
/*      */         
/*  972 */         notifyRemoval(key, value[0], actualCause[0]);
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  977 */       makeDead(node);
/*      */     } 
/*      */     
/*  980 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void climb() {
/*  986 */     if (!evicts()) {
/*      */       return;
/*      */     }
/*      */     
/*  990 */     determineAdjustment();
/*  991 */     demoteFromMainProtected();
/*  992 */     long amount = adjustment();
/*  993 */     if (amount == 0L)
/*      */       return; 
/*  995 */     if (amount > 0L) {
/*  996 */       increaseWindow();
/*      */     } else {
/*  998 */       decreaseWindow();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void determineAdjustment() {
/* 1005 */     if (frequencySketch().isNotInitialized()) {
/* 1006 */       setPreviousSampleHitRate(0.0D);
/* 1007 */       setMissesInSample(0);
/* 1008 */       setHitsInSample(0);
/*      */       
/*      */       return;
/*      */     } 
/* 1012 */     int requestCount = hitsInSample() + missesInSample();
/* 1013 */     if (requestCount < (frequencySketch()).sampleSize) {
/*      */       return;
/*      */     }
/*      */     
/* 1017 */     double hitRate = hitsInSample() / requestCount;
/* 1018 */     double hitRateChange = hitRate - previousSampleHitRate();
/* 1019 */     double amount = (hitRateChange >= 0.0D) ? stepSize() : -stepSize();
/*      */ 
/*      */     
/* 1022 */     double nextStepSize = (Math.abs(hitRateChange) >= 0.05D) ? (0.0625D * maximum() * ((amount >= 0.0D) ? true : -1)) : (0.98D * amount);
/* 1023 */     setPreviousSampleHitRate(hitRate);
/* 1024 */     setAdjustment((long)amount);
/* 1025 */     setStepSize(nextStepSize);
/* 1026 */     setMissesInSample(0);
/* 1027 */     setHitsInSample(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void increaseWindow() {
/* 1039 */     if (mainProtectedMaximum() == 0L) {
/*      */       return;
/*      */     }
/*      */     
/* 1043 */     long quota = Math.min(adjustment(), mainProtectedMaximum());
/* 1044 */     setMainProtectedMaximum(mainProtectedMaximum() - quota);
/* 1045 */     setWindowMaximum(windowMaximum() + quota);
/* 1046 */     demoteFromMainProtected();
/*      */     
/* 1048 */     for (int i = 0; i < 1000; i++) {
/* 1049 */       Node<K, V> candidate = accessOrderProbationDeque().peek();
/* 1050 */       boolean probation = true;
/* 1051 */       if (candidate == null || quota < candidate.getPolicyWeight()) {
/* 1052 */         candidate = accessOrderProtectedDeque().peek();
/* 1053 */         probation = false;
/*      */       } 
/* 1055 */       if (candidate == null) {
/*      */         break;
/*      */       }
/*      */       
/* 1059 */       int weight = candidate.getPolicyWeight();
/* 1060 */       if (quota < weight) {
/*      */         break;
/*      */       }
/*      */       
/* 1064 */       quota -= weight;
/* 1065 */       if (probation) {
/* 1066 */         accessOrderProbationDeque().remove(candidate);
/*      */       } else {
/* 1068 */         setMainProtectedWeightedSize(mainProtectedWeightedSize() - weight);
/* 1069 */         accessOrderProtectedDeque().remove(candidate);
/*      */       } 
/* 1071 */       setWindowWeightedSize(windowWeightedSize() + weight);
/* 1072 */       accessOrderWindowDeque().add(candidate);
/* 1073 */       candidate.makeWindow();
/*      */     } 
/*      */     
/* 1076 */     setMainProtectedMaximum(mainProtectedMaximum() + quota);
/* 1077 */     setWindowMaximum(windowMaximum() - quota);
/* 1078 */     setAdjustment(quota);
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void decreaseWindow() {
/* 1084 */     if (windowMaximum() <= 1L) {
/*      */       return;
/*      */     }
/*      */     
/* 1088 */     long quota = Math.min(-adjustment(), Math.max(0L, windowMaximum() - 1L));
/* 1089 */     setMainProtectedMaximum(mainProtectedMaximum() + quota);
/* 1090 */     setWindowMaximum(windowMaximum() - quota);
/*      */     
/* 1092 */     for (int i = 0; i < 1000; i++) {
/* 1093 */       Node<K, V> candidate = accessOrderWindowDeque().peek();
/* 1094 */       if (candidate == null) {
/*      */         break;
/*      */       }
/*      */       
/* 1098 */       int weight = candidate.getPolicyWeight();
/* 1099 */       if (quota < weight) {
/*      */         break;
/*      */       }
/*      */       
/* 1103 */       quota -= weight;
/* 1104 */       setMainProtectedWeightedSize(mainProtectedWeightedSize() + weight);
/* 1105 */       setWindowWeightedSize(windowWeightedSize() - weight);
/* 1106 */       accessOrderWindowDeque().remove(candidate);
/* 1107 */       accessOrderProbationDeque().add(candidate);
/* 1108 */       candidate.makeMainProbation();
/*      */     } 
/*      */     
/* 1111 */     setMainProtectedMaximum(mainProtectedMaximum() - quota);
/* 1112 */     setWindowMaximum(windowMaximum() + quota);
/* 1113 */     setAdjustment(-quota);
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void demoteFromMainProtected() {
/* 1119 */     long mainProtectedMaximum = mainProtectedMaximum();
/* 1120 */     long mainProtectedWeightedSize = mainProtectedWeightedSize();
/* 1121 */     if (mainProtectedWeightedSize <= mainProtectedMaximum) {
/*      */       return;
/*      */     }
/*      */     
/* 1125 */     for (int i = 0; i < 1000 && 
/* 1126 */       mainProtectedWeightedSize > mainProtectedMaximum; i++) {
/*      */ 
/*      */ 
/*      */       
/* 1130 */       Node<K, V> demoted = accessOrderProtectedDeque().poll();
/* 1131 */       if (demoted == null) {
/*      */         break;
/*      */       }
/* 1134 */       demoted.makeMainProbation();
/* 1135 */       accessOrderProbationDeque().add(demoted);
/* 1136 */       mainProtectedWeightedSize -= demoted.getPolicyWeight();
/*      */     } 
/* 1138 */     setMainProtectedWeightedSize(mainProtectedWeightedSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void afterRead(Node<K, V> node, long now, boolean recordHit) {
/* 1149 */     if (recordHit) {
/* 1150 */       statsCounter().recordHits(1);
/*      */     }
/*      */     
/* 1153 */     boolean delayable = (skipReadBuffer() || this.readBuffer.offer(node) != 1);
/* 1154 */     if (shouldDrainBuffers(delayable)) {
/* 1155 */       scheduleDrainBuffers();
/*      */     }
/* 1157 */     refreshIfNeeded(node, now);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean skipReadBuffer() {
/* 1162 */     return (fastpath() && frequencySketch().isNotInitialized());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void refreshIfNeeded(Node<K, V> node, long now) {
/* 1173 */     if (!refreshAfterWrite()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1178 */     long oldWriteTime = node.getWriteTime();
/* 1179 */     long refreshWriteTime = now + 6917529027641081854L; K key; V oldValue;
/* 1180 */     if (now - oldWriteTime > refreshAfterWriteNanos() && (
/* 1181 */       key = node.getKey()) != null && (oldValue = node.getValue()) != null && node
/* 1182 */       .casWriteTime(oldWriteTime, refreshWriteTime)) {
/*      */       try {
/*      */         CompletableFuture<V> refreshFuture;
/* 1185 */         long startTime = statsTicker().read();
/* 1186 */         if (this.isAsync) {
/*      */           
/* 1188 */           CompletableFuture<V> future = (CompletableFuture<V>)oldValue;
/* 1189 */           if (Async.isReady(future)) {
/*      */             
/* 1191 */             CompletableFuture<V> refresh = future.thenCompose(value -> this.cacheLoader.asyncReload((K)key, (V)value, this.executor));
/*      */             
/* 1193 */             refreshFuture = refresh;
/*      */           } else {
/*      */             
/* 1196 */             node.casWriteTime(refreshWriteTime, oldWriteTime);
/*      */             
/*      */             return;
/*      */           } 
/*      */         } else {
/* 1201 */           CompletableFuture<V> refresh = this.cacheLoader.asyncReload(key, oldValue, this.executor);
/* 1202 */           refreshFuture = refresh;
/*      */         } 
/* 1204 */         refreshFuture.whenComplete((newValue, error) -> {
/*      */               long loadTime = statsTicker().read() - startTime;
/*      */               
/*      */               if (error != null) {
/*      */                 logger.log(Level.WARNING, "Exception thrown during refresh", error);
/*      */                 
/*      */                 node.casWriteTime(refreshWriteTime, oldWriteTime);
/*      */                 statsCounter().recordLoadFailure(loadTime);
/*      */                 return;
/*      */               } 
/* 1214 */               V value = (this.isAsync && newValue != null) ? (V)refreshFuture : (V)newValue;
/*      */ 
/*      */ 
/*      */               
/*      */               boolean[] discard = new boolean[1];
/*      */ 
/*      */ 
/*      */               
/*      */               compute((K)key, (), false, false, true);
/*      */ 
/*      */               
/*      */               if (discard[0] && hasRemovalListener()) {
/*      */                 notifyRemoval((K)key, value, RemovalCause.REPLACED);
/*      */               }
/*      */ 
/*      */               
/*      */               if (newValue == null) {
/*      */                 statsCounter().recordLoadFailure(loadTime);
/*      */               } else {
/*      */                 statsCounter().recordLoadSuccess(loadTime);
/*      */               } 
/*      */             });
/* 1236 */       } catch (Throwable t) {
/* 1237 */         CompletableFuture<V> refreshFuture; node.casWriteTime(refreshWriteTime, oldWriteTime);
/* 1238 */         logger.log(Level.SEVERE, "Exception thrown when submitting refresh task", (Throwable)refreshFuture);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long expireAfterCreate(K key, V value, Expiry<K, V> expiry, long now) {
/* 1253 */     if (expiresVariable() && key != null && value != null) {
/* 1254 */       long duration = expiry.expireAfterCreate(key, value, now);
/* 1255 */       return this.isAsync ? (now + duration) : (now + Math.min(duration, 4611686018427387903L));
/*      */     } 
/* 1257 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long expireAfterUpdate(Node<K, V> node, K key, V value, Expiry<K, V> expiry, long now) {
/* 1272 */     if (expiresVariable() && key != null && value != null) {
/* 1273 */       long currentDuration = Math.max(1L, node.getVariableTime() - now);
/* 1274 */       long duration = expiry.expireAfterUpdate(key, value, now, currentDuration);
/* 1275 */       return this.isAsync ? (now + duration) : (now + Math.min(duration, 4611686018427387903L));
/*      */     } 
/* 1277 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long expireAfterRead(Node<K, V> node, K key, V value, Expiry<K, V> expiry, long now) {
/* 1292 */     if (expiresVariable() && key != null && value != null) {
/* 1293 */       long currentDuration = Math.max(1L, node.getVariableTime() - now);
/* 1294 */       long duration = expiry.expireAfterRead(key, value, now, currentDuration);
/* 1295 */       return this.isAsync ? (now + duration) : (now + Math.min(duration, 4611686018427387903L));
/*      */     } 
/* 1297 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void tryExpireAfterRead(Node<K, V> node, K key, V value, Expiry<K, V> expiry, long now) {
/* 1311 */     if (!expiresVariable() || key == null || value == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1315 */     long variableTime = node.getVariableTime();
/* 1316 */     long currentDuration = Math.max(1L, variableTime - now);
/* 1317 */     if (this.isAsync && currentDuration > 4611686018427387903L) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1322 */     long duration = expiry.expireAfterRead(key, value, now, currentDuration);
/* 1323 */     if (duration != currentDuration) {
/* 1324 */       long expirationTime = this.isAsync ? (now + duration) : (now + Math.min(duration, 4611686018427387903L));
/* 1325 */       node.casVariableTime(variableTime, expirationTime);
/*      */     } 
/*      */   }
/*      */   
/*      */   void setVariableTime(Node<K, V> node, long expirationTime) {
/* 1330 */     if (expiresVariable()) {
/* 1331 */       node.setVariableTime(expirationTime);
/*      */     }
/*      */   }
/*      */   
/*      */   void setWriteTime(Node<K, V> node, long now) {
/* 1336 */     if (expiresAfterWrite() || refreshAfterWrite()) {
/* 1337 */       node.setWriteTime(now);
/*      */     }
/*      */   }
/*      */   
/*      */   void setAccessTime(Node<K, V> node, long now) {
/* 1342 */     if (expiresAfterAccess()) {
/* 1343 */       node.setAccessTime(now);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void afterWrite(Runnable task) {
/* 1353 */     if (buffersWrites()) {
/* 1354 */       for (int i = 0; i < 100; i++) {
/* 1355 */         if (writeBuffer().offer(task)) {
/* 1356 */           scheduleAfterWrite();
/*      */           return;
/*      */         } 
/* 1359 */         scheduleDrainBuffers();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1366 */         performCleanUp(task);
/* 1367 */       } catch (RuntimeException e) {
/* 1368 */         logger.log(Level.SEVERE, "Exception thrown when performing the maintenance task", e);
/*      */       } 
/*      */     } else {
/* 1371 */       scheduleAfterWrite();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void scheduleAfterWrite() {
/*      */     while (true) {
/* 1383 */       switch (drainStatus()) {
/*      */         case 0:
/* 1385 */           casDrainStatus(0, 1);
/* 1386 */           scheduleDrainBuffers();
/*      */           return;
/*      */         case 1:
/* 1389 */           scheduleDrainBuffers();
/*      */           return;
/*      */         case 2:
/* 1392 */           if (casDrainStatus(2, 3))
/*      */             return;  continue;
/*      */         case 3:
/*      */           return;
/*      */       } 
/*      */       break;
/*      */     } 
/* 1399 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void scheduleDrainBuffers() {
/* 1409 */     if (drainStatus() >= 2) {
/*      */       return;
/*      */     }
/* 1412 */     if (this.evictionLock.tryLock()) {
/*      */       try {
/* 1414 */         int drainStatus = drainStatus();
/* 1415 */         if (drainStatus >= 2) {
/*      */           return;
/*      */         }
/* 1418 */         lazySetDrainStatus(2);
/* 1419 */         this.executor.execute(this.drainBuffersTask);
/* 1420 */       } catch (Throwable t) {
/* 1421 */         logger.log(Level.WARNING, "Exception thrown when submitting maintenance task", t);
/* 1422 */         maintenance((Runnable)null);
/*      */       } finally {
/* 1424 */         this.evictionLock.unlock();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void cleanUp() {
/*      */     try {
/* 1432 */       performCleanUp((Runnable)null);
/* 1433 */     } catch (RuntimeException e) {
/* 1434 */       logger.log(Level.SEVERE, "Exception thrown when performing the maintenance task", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void performCleanUp(Runnable task) {
/* 1445 */     this.evictionLock.lock();
/*      */     try {
/* 1447 */       maintenance(task);
/*      */     } finally {
/* 1449 */       this.evictionLock.unlock();
/*      */     } 
/* 1451 */     if (drainStatus() == 1 && this.executor == ForkJoinPool.commonPool()) {
/* 1452 */       scheduleDrainBuffers();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void maintenance(Runnable task) {
/* 1465 */     lazySetDrainStatus(2);
/*      */     
/*      */     try {
/* 1468 */       drainReadBuffer();
/*      */       
/* 1470 */       drainWriteBuffer();
/* 1471 */       if (task != null) {
/* 1472 */         task.run();
/*      */       }
/*      */       
/* 1475 */       drainKeyReferences();
/* 1476 */       drainValueReferences();
/*      */       
/* 1478 */       expireEntries();
/* 1479 */       evictEntries();
/*      */       
/* 1481 */       climb();
/*      */     } finally {
/* 1483 */       if (drainStatus() != 2 || !casDrainStatus(2, 0)) {
/* 1484 */         lazySetDrainStatus(1);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void drainKeyReferences() {
/* 1492 */     if (!collectKeys()) {
/*      */       return;
/*      */     }
/*      */     Reference<? extends K> keyRef;
/* 1496 */     while ((keyRef = keyReferenceQueue().poll()) != null) {
/* 1497 */       Node<K, V> node = this.data.get(keyRef);
/* 1498 */       if (node != null) {
/* 1499 */         evictEntry(node, RemovalCause.COLLECTED, 0L);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void drainValueReferences() {
/* 1507 */     if (!collectValues()) {
/*      */       return;
/*      */     }
/*      */     Reference<? extends V> valueRef;
/* 1511 */     while ((valueRef = valueReferenceQueue().poll()) != null) {
/*      */       
/* 1513 */       References.InternalReference<V> ref = (References.InternalReference)valueRef;
/* 1514 */       Node<K, V> node = this.data.get(ref.getKeyReference());
/* 1515 */       if (node != null && valueRef == node.getValueReference()) {
/* 1516 */         evictEntry(node, RemovalCause.COLLECTED, 0L);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void drainReadBuffer() {
/* 1524 */     if (!skipReadBuffer()) {
/* 1525 */       this.readBuffer.drainTo(this.accessPolicy);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void onAccess(Node<K, V> node) {
/* 1532 */     if (evicts()) {
/* 1533 */       K key = node.getKey();
/* 1534 */       if (key == null) {
/*      */         return;
/*      */       }
/* 1537 */       frequencySketch().increment(key);
/* 1538 */       if (node.inWindow()) {
/* 1539 */         reorder(accessOrderWindowDeque(), node);
/* 1540 */       } else if (node.inMainProbation()) {
/* 1541 */         reorderProbation(node);
/*      */       } else {
/* 1543 */         reorder(accessOrderProtectedDeque(), node);
/*      */       } 
/* 1545 */       setHitsInSample(hitsInSample() + 1);
/* 1546 */     } else if (expiresAfterAccess()) {
/* 1547 */       reorder(accessOrderWindowDeque(), node);
/*      */     } 
/* 1549 */     if (expiresVariable()) {
/* 1550 */       timerWheel().reschedule(node);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void reorderProbation(Node<K, V> node) {
/* 1557 */     if (!accessOrderProbationDeque().contains(node)) {
/*      */       return;
/*      */     }
/* 1560 */     if (node.getPolicyWeight() > mainProtectedMaximum()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1566 */     setMainProtectedWeightedSize(mainProtectedWeightedSize() + node.getPolicyWeight());
/* 1567 */     accessOrderProbationDeque().remove(node);
/* 1568 */     accessOrderProtectedDeque().add(node);
/* 1569 */     node.makeMainProtected();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <K, V> void reorder(LinkedDeque<Node<K, V>> deque, Node<K, V> node) {
/* 1577 */     if (deque.contains(node)) {
/* 1578 */       deque.moveToBack(node);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void drainWriteBuffer() {
/* 1585 */     if (!buffersWrites()) {
/*      */       return;
/*      */     }
/*      */     
/* 1589 */     for (int i = 0; i < WRITE_BUFFER_MAX; i++) {
/* 1590 */       Runnable task = writeBuffer().poll();
/* 1591 */       if (task == null) {
/*      */         return;
/*      */       }
/* 1594 */       task.run();
/*      */     } 
/* 1596 */     lazySetDrainStatus(3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void makeDead(Node<K, V> node) {
/* 1607 */     synchronized (node) {
/* 1608 */       if (node.isDead()) {
/*      */         return;
/*      */       }
/* 1611 */       if (evicts()) {
/*      */ 
/*      */ 
/*      */         
/* 1615 */         if (node.inWindow()) {
/* 1616 */           setWindowWeightedSize(windowWeightedSize() - node.getWeight());
/* 1617 */         } else if (node.inMainProtected()) {
/* 1618 */           setMainProtectedWeightedSize(mainProtectedWeightedSize() - node.getWeight());
/*      */         } 
/* 1620 */         setWeightedSize(weightedSize() - node.getWeight());
/*      */       } 
/* 1622 */       node.die();
/*      */     } 
/*      */   }
/*      */   
/*      */   final class AddTask
/*      */     implements Runnable {
/*      */     final Node<K, V> node;
/*      */     final int weight;
/*      */     
/*      */     AddTask(Node<K, V> node, int weight) {
/* 1632 */       this.weight = weight;
/* 1633 */       this.node = node;
/*      */     }
/*      */ 
/*      */     
/*      */     @GuardedBy("evictionLock")
/*      */     public void run() {
/*      */       boolean isAlive;
/* 1640 */       if (BoundedLocalCache.this.evicts()) {
/* 1641 */         long weightedSize = BoundedLocalCache.this.weightedSize();
/* 1642 */         BoundedLocalCache.this.setWeightedSize(weightedSize + this.weight);
/* 1643 */         BoundedLocalCache.this.setWindowWeightedSize(BoundedLocalCache.this.windowWeightedSize() + this.weight);
/* 1644 */         this.node.setPolicyWeight(this.node.getPolicyWeight() + this.weight);
/*      */         
/* 1646 */         long maximum = BoundedLocalCache.this.maximum();
/* 1647 */         if (weightedSize >= maximum >>> 1L) {
/*      */           
/* 1649 */           long capacity = BoundedLocalCache.this.isWeighted() ? BoundedLocalCache.this.data.mappingCount() : maximum;
/* 1650 */           BoundedLocalCache.this.frequencySketch().ensureCapacity(capacity);
/*      */         } 
/*      */         
/* 1653 */         K key = this.node.getKey();
/* 1654 */         if (key != null) {
/* 1655 */           BoundedLocalCache.this.frequencySketch().increment(key);
/*      */         }
/*      */         
/* 1658 */         BoundedLocalCache.this.setMissesInSample(BoundedLocalCache.this.missesInSample() + 1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1663 */       synchronized (this.node) {
/* 1664 */         isAlive = this.node.isAlive();
/*      */       } 
/* 1666 */       if (isAlive) {
/* 1667 */         if (BoundedLocalCache.this.expiresAfterWrite()) {
/* 1668 */           BoundedLocalCache.this.writeOrderDeque().add(this.node);
/*      */         }
/* 1670 */         if (BoundedLocalCache.this.evicts() || BoundedLocalCache.this.expiresAfterAccess()) {
/* 1671 */           BoundedLocalCache.this.accessOrderWindowDeque().add(this.node);
/*      */         }
/* 1673 */         if (BoundedLocalCache.this.expiresVariable()) {
/* 1674 */           BoundedLocalCache.this.timerWheel().schedule(this.node);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1679 */       if (BoundedLocalCache.this.isComputingAsync(this.node))
/* 1680 */         synchronized (this.node) {
/* 1681 */           if (!Async.isReady((CompletableFuture)this.node.getValue())) {
/* 1682 */             long expirationTime = BoundedLocalCache.this.expirationTicker().read() + 6917529027641081854L;
/* 1683 */             BoundedLocalCache.this.setVariableTime(this.node, expirationTime);
/* 1684 */             BoundedLocalCache.this.setAccessTime(this.node, expirationTime);
/* 1685 */             BoundedLocalCache.this.setWriteTime(this.node, expirationTime);
/*      */           } 
/*      */         }  
/*      */     }
/*      */   }
/*      */   
/*      */   final class RemovalTask
/*      */     implements Runnable
/*      */   {
/*      */     final Node<K, V> node;
/*      */     
/*      */     RemovalTask(Node<K, V> node) {
/* 1697 */       this.node = node;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @GuardedBy("evictionLock")
/*      */     public void run() {
/* 1704 */       if (this.node.inWindow() && (BoundedLocalCache.this.evicts() || BoundedLocalCache.this.expiresAfterAccess())) {
/* 1705 */         BoundedLocalCache.this.accessOrderWindowDeque().remove(this.node);
/* 1706 */       } else if (BoundedLocalCache.this.evicts()) {
/* 1707 */         if (this.node.inMainProbation()) {
/* 1708 */           BoundedLocalCache.this.accessOrderProbationDeque().remove(this.node);
/*      */         } else {
/* 1710 */           BoundedLocalCache.this.accessOrderProtectedDeque().remove(this.node);
/*      */         } 
/*      */       } 
/* 1713 */       if (BoundedLocalCache.this.expiresAfterWrite()) {
/* 1714 */         BoundedLocalCache.this.writeOrderDeque().remove(this.node);
/* 1715 */       } else if (BoundedLocalCache.this.expiresVariable()) {
/* 1716 */         BoundedLocalCache.this.timerWheel().deschedule(this.node);
/*      */       } 
/* 1718 */       BoundedLocalCache.this.makeDead(this.node);
/*      */     }
/*      */   }
/*      */   
/*      */   final class UpdateTask
/*      */     implements Runnable {
/*      */     final int weightDifference;
/*      */     final Node<K, V> node;
/*      */     
/*      */     public UpdateTask(Node<K, V> node, int weightDifference) {
/* 1728 */       this.weightDifference = weightDifference;
/* 1729 */       this.node = node;
/*      */     }
/*      */ 
/*      */     
/*      */     @GuardedBy("evictionLock")
/*      */     public void run() {
/* 1735 */       if (BoundedLocalCache.this.evicts()) {
/* 1736 */         if (this.node.inWindow()) {
/* 1737 */           BoundedLocalCache.this.setWindowWeightedSize(BoundedLocalCache.this.windowWeightedSize() + this.weightDifference);
/* 1738 */         } else if (this.node.inMainProtected()) {
/* 1739 */           BoundedLocalCache.this.setMainProtectedWeightedSize(BoundedLocalCache.this.mainProtectedMaximum() + this.weightDifference);
/*      */         } 
/* 1741 */         BoundedLocalCache.this.setWeightedSize(BoundedLocalCache.this.weightedSize() + this.weightDifference);
/* 1742 */         this.node.setPolicyWeight(this.node.getPolicyWeight() + this.weightDifference);
/*      */       } 
/* 1744 */       if (BoundedLocalCache.this.evicts() || BoundedLocalCache.this.expiresAfterAccess()) {
/* 1745 */         BoundedLocalCache.this.onAccess(this.node);
/*      */       }
/* 1747 */       if (BoundedLocalCache.this.expiresAfterWrite()) {
/* 1748 */         BoundedLocalCache.reorder(BoundedLocalCache.this.writeOrderDeque(), this.node);
/* 1749 */       } else if (BoundedLocalCache.this.expiresVariable()) {
/* 1750 */         BoundedLocalCache.this.timerWheel().reschedule(this.node);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/* 1759 */     return this.data.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   public int size() {
/* 1764 */     return this.data.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public long estimatedSize() {
/* 1769 */     return this.data.mappingCount();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/* 1775 */     this.evictionLock.lock();
/*      */     
/* 1777 */     try { long now = expirationTicker().read();
/*      */       
/*      */       Runnable task;
/*      */       
/* 1781 */       while (buffersWrites() && (task = writeBuffer().poll()) != null) {
/* 1782 */         task.run();
/*      */       }
/*      */ 
/*      */       
/* 1786 */       for (Node<K, V> node : this.data.values()) {
/* 1787 */         removeNode(node, now);
/*      */       }
/*      */ 
/*      */       
/* 1791 */       this.readBuffer.drainTo(e -> { 
/*      */           }); }
/* 1793 */     finally { this.evictionLock.unlock(); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   @GuardedBy("evictionLock")
/*      */   void removeNode(Node<K, V> node, long now) {
/* 1800 */     K key = node.getKey();
/*      */     
/* 1802 */     V[] value = (V[])new Object[1];
/* 1803 */     RemovalCause[] cause = new RemovalCause[1];
/*      */     
/* 1805 */     this.data.computeIfPresent(node.getKeyReference(), (k, n) -> {
/*      */           if (n != node) {
/*      */             return n;
/*      */           }
/*      */           
/*      */           synchronized (n) {
/*      */             value[0] = n.getValue();
/*      */             
/*      */             if (key == null || value[0] == null) {
/*      */               cause[0] = RemovalCause.COLLECTED;
/*      */             } else if (hasExpired(n, now)) {
/*      */               cause[0] = RemovalCause.EXPIRED;
/*      */             } else {
/*      */               cause[0] = RemovalCause.EXPLICIT;
/*      */             } 
/*      */             
/*      */             if (key != null) {
/*      */               this.writer.delete((K)key, (V)value[0], cause[0]);
/*      */             }
/*      */             makeDead(n);
/*      */             return null;
/*      */           } 
/*      */         });
/* 1828 */     if (node.inWindow() && (evicts() || expiresAfterAccess())) {
/* 1829 */       accessOrderWindowDeque().remove(node);
/* 1830 */     } else if (evicts()) {
/* 1831 */       if (node.inMainProbation()) {
/* 1832 */         accessOrderProbationDeque().remove(node);
/*      */       } else {
/* 1834 */         accessOrderProtectedDeque().remove(node);
/*      */       } 
/*      */     } 
/* 1837 */     if (expiresAfterWrite()) {
/* 1838 */       writeOrderDeque().remove(node);
/* 1839 */     } else if (expiresVariable()) {
/* 1840 */       timerWheel().deschedule(node);
/*      */     } 
/*      */     
/* 1843 */     if (cause[0] != null && hasRemovalListener()) {
/* 1844 */       notifyRemoval(key, value[0], cause[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsKey(Object key) {
/* 1850 */     Node<K, V> node = this.data.get(this.nodeFactory.newLookupKey(key));
/* 1851 */     return (node != null && node.getValue() != null && 
/* 1852 */       !hasExpired(node, expirationTicker().read()));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsValue(Object value) {
/* 1857 */     Objects.requireNonNull(value);
/*      */     
/* 1859 */     long now = expirationTicker().read();
/* 1860 */     for (Node<K, V> node : this.data.values()) {
/* 1861 */       if (node.containsValue(value) && !hasExpired(node, now) && node.getKey() != null) {
/* 1862 */         return true;
/*      */       }
/*      */     } 
/* 1865 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public V get(Object key) {
/* 1870 */     return getIfPresent(key, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public V getIfPresent(Object key, boolean recordStats) {
/* 1875 */     Node<K, V> node = this.data.get(this.nodeFactory.newLookupKey(key));
/* 1876 */     if (node == null) {
/* 1877 */       if (recordStats) {
/* 1878 */         statsCounter().recordMisses(1);
/*      */       }
/* 1880 */       if (drainStatus() == 1) {
/* 1881 */         scheduleDrainBuffers();
/*      */       }
/* 1883 */       return null;
/*      */     } 
/*      */     
/* 1886 */     V value = node.getValue();
/* 1887 */     long now = expirationTicker().read();
/* 1888 */     if (hasExpired(node, now) || (collectValues() && value == null)) {
/* 1889 */       if (recordStats) {
/* 1890 */         statsCounter().recordMisses(1);
/*      */       }
/* 1892 */       scheduleDrainBuffers();
/* 1893 */       return null;
/*      */     } 
/*      */     
/* 1896 */     if (!isComputingAsync(node)) {
/*      */       
/* 1898 */       K castedKey = (K)key;
/* 1899 */       setAccessTime(node, now);
/* 1900 */       tryExpireAfterRead(node, castedKey, value, expiry(), now);
/*      */     } 
/* 1902 */     afterRead(node, now, recordStats);
/* 1903 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V getIfPresentQuietly(Object key, long[] writeTime) {
/* 1909 */     Node<K, V> node = this.data.get(this.nodeFactory.newLookupKey(key)); V value;
/* 1910 */     if (node == null || (value = node.getValue()) == null || 
/* 1911 */       hasExpired(node, expirationTicker().read())) {
/* 1912 */       return null;
/*      */     }
/* 1914 */     writeTime[0] = node.getWriteTime();
/* 1915 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<K, V> getAllPresent(Iterable<?> keys) {
/* 1920 */     Set<Object> uniqueKeys = new LinkedHashSet();
/* 1921 */     for (Object key : keys) {
/* 1922 */       uniqueKeys.add(key);
/*      */     }
/*      */     
/* 1925 */     int misses = 0;
/* 1926 */     long now = expirationTicker().read();
/* 1927 */     Map<Object, Object> result = new LinkedHashMap<>(uniqueKeys.size());
/* 1928 */     for (Object key : uniqueKeys) {
/*      */       
/* 1930 */       Node<K, V> node = this.data.get(this.nodeFactory.newLookupKey(key)); V value;
/* 1931 */       if (node == null || (value = node.getValue()) == null || hasExpired(node, now)) {
/* 1932 */         misses++; continue;
/*      */       } 
/* 1934 */       result.put(key, value);
/*      */       
/* 1936 */       if (!isComputingAsync(node)) {
/*      */         
/* 1938 */         K castedKey = (K)key;
/* 1939 */         tryExpireAfterRead(node, castedKey, value, expiry(), now);
/* 1940 */         setAccessTime(node, now);
/*      */       } 
/* 1942 */       afterRead(node, now, false);
/*      */     } 
/*      */     
/* 1945 */     statsCounter().recordMisses(misses);
/* 1946 */     statsCounter().recordHits(result.size());
/*      */ 
/*      */     
/* 1949 */     Map<Object, Object> map1 = result;
/* 1950 */     return Collections.unmodifiableMap((Map)map1);
/*      */   }
/*      */ 
/*      */   
/*      */   public V put(K key, V value) {
/* 1955 */     return put(key, value, expiry(), true, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public V put(K key, V value, boolean notifyWriter) {
/* 1960 */     return put(key, value, expiry(), notifyWriter, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public V putIfAbsent(K key, V value) {
/* 1965 */     return put(key, value, expiry(), true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   V put(K key, V value, Expiry<K, V> expiry, boolean notifyWriter, boolean onlyIfAbsent) {
/*      */     Node<K, V> prior;
/*      */     V oldValue;
/*      */     int oldWeight;
/*      */     boolean expired, mayUpdate, exceedsTolerance;
/* 1980 */     Objects.requireNonNull(key);
/* 1981 */     Objects.requireNonNull(value);
/*      */     
/* 1983 */     Node<K, V> node = null;
/* 1984 */     long now = expirationTicker().read();
/* 1985 */     int newWeight = this.weigher.weigh(key, value);
/*      */     while (true) {
/* 1987 */       prior = this.data.get(this.nodeFactory.newLookupKey(key));
/* 1988 */       if (prior == null) {
/* 1989 */         if (node == null) {
/* 1990 */           node = this.nodeFactory.newNode(key, keyReferenceQueue(), value, 
/* 1991 */               valueReferenceQueue(), newWeight, now);
/* 1992 */           setVariableTime(node, expireAfterCreate(key, value, expiry, now));
/*      */         } 
/* 1994 */         if (notifyWriter && hasWriter()) {
/* 1995 */           Node<K, V> computed = node;
/* 1996 */           prior = this.data.computeIfAbsent(node.getKeyReference(), k -> {
/*      */                 this.writer.write((K)key, (V)value);
/*      */                 return computed;
/*      */               });
/* 2000 */           if (prior == node) {
/* 2001 */             afterWrite(new AddTask(node, newWeight));
/* 2002 */             return null;
/*      */           } 
/*      */         } else {
/* 2005 */           prior = this.data.putIfAbsent(node.getKeyReference(), node);
/* 2006 */           if (prior == null) {
/* 2007 */             afterWrite(new AddTask(node, newWeight));
/* 2008 */             return null;
/*      */           } 
/*      */         } 
/* 2011 */       } else if (onlyIfAbsent) {
/*      */         
/* 2013 */         V currentValue = prior.getValue();
/* 2014 */         if (currentValue != null && !hasExpired(prior, now)) {
/* 2015 */           if (!isComputingAsync(prior)) {
/* 2016 */             tryExpireAfterRead(prior, key, currentValue, expiry(), now);
/* 2017 */             setAccessTime(prior, now);
/*      */           } 
/* 2019 */           afterRead(prior, now, false);
/* 2020 */           return currentValue;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2027 */       expired = false;
/* 2028 */       mayUpdate = true;
/* 2029 */       exceedsTolerance = false;
/* 2030 */       synchronized (prior) {
/* 2031 */         long varTime; if (!prior.isAlive()) {
/*      */           continue;
/*      */         }
/* 2034 */         oldValue = prior.getValue();
/* 2035 */         oldWeight = prior.getWeight();
/* 2036 */         if (oldValue == null) {
/* 2037 */           varTime = expireAfterCreate(key, value, expiry, now);
/* 2038 */           this.writer.delete(key, null, RemovalCause.COLLECTED);
/* 2039 */         } else if (hasExpired(prior, now)) {
/* 2040 */           expired = true;
/* 2041 */           varTime = expireAfterCreate(key, value, expiry, now);
/* 2042 */           this.writer.delete(key, oldValue, RemovalCause.EXPIRED);
/* 2043 */         } else if (onlyIfAbsent) {
/* 2044 */           mayUpdate = false;
/* 2045 */           varTime = expireAfterRead(prior, key, value, expiry, now);
/*      */         } else {
/* 2047 */           varTime = expireAfterUpdate(prior, key, value, expiry, now);
/*      */         } 
/*      */         
/* 2050 */         if (notifyWriter && (expired || (mayUpdate && value != oldValue))) {
/* 2051 */           this.writer.write(key, value);
/*      */         }
/* 2053 */         if (mayUpdate) {
/*      */ 
/*      */ 
/*      */           
/* 2057 */           exceedsTolerance = ((expiresAfterWrite() && now - prior.getWriteTime() > EXPIRE_WRITE_TOLERANCE) || (expiresVariable() && Math.abs(varTime - prior.getVariableTime()) > EXPIRE_WRITE_TOLERANCE));
/*      */           
/* 2059 */           setWriteTime(prior, now);
/* 2060 */           prior.setWeight(newWeight);
/* 2061 */           prior.setValue(value, valueReferenceQueue());
/*      */         } 
/*      */         
/* 2064 */         setVariableTime(prior, varTime);
/* 2065 */         setAccessTime(prior, now);
/*      */       }  break;
/*      */     } 
/* 2068 */     if (hasRemovalListener()) {
/* 2069 */       if (expired) {
/* 2070 */         notifyRemoval(key, oldValue, RemovalCause.EXPIRED);
/* 2071 */       } else if (oldValue == null) {
/* 2072 */         notifyRemoval(key, (V)null, RemovalCause.COLLECTED);
/* 2073 */       } else if (mayUpdate && value != oldValue) {
/* 2074 */         notifyRemoval(key, oldValue, RemovalCause.REPLACED);
/*      */       } 
/*      */     }
/*      */     
/* 2078 */     int weightedDifference = mayUpdate ? (newWeight - oldWeight) : 0;
/* 2079 */     if (oldValue == null || weightedDifference != 0 || expired) {
/* 2080 */       afterWrite(new UpdateTask(prior, weightedDifference));
/* 2081 */     } else if (!onlyIfAbsent && exceedsTolerance) {
/* 2082 */       afterWrite(new UpdateTask(prior, weightedDifference));
/*      */     } else {
/* 2084 */       if (mayUpdate) {
/* 2085 */         setWriteTime(prior, now);
/*      */       }
/* 2087 */       afterRead(prior, now, false);
/*      */     } 
/*      */     
/* 2090 */     return expired ? null : oldValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V remove(Object key) {
/* 2097 */     K castKey = (K)key;
/*      */     
/* 2099 */     Node[] arrayOfNode = new Node[1];
/*      */     
/* 2101 */     V[] oldValue = (V[])new Object[1];
/* 2102 */     RemovalCause[] cause = new RemovalCause[1];
/*      */     
/* 2104 */     this.data.computeIfPresent(this.nodeFactory.newLookupKey(key), (k, n) -> {
/*      */           synchronized (n) {
/*      */             oldValue[0] = n.getValue();
/*      */             
/*      */             if (oldValue[0] == null) {
/*      */               cause[0] = RemovalCause.COLLECTED;
/*      */             } else if (hasExpired(n, expirationTicker().read())) {
/*      */               cause[0] = RemovalCause.EXPIRED;
/*      */             } else {
/*      */               cause[0] = RemovalCause.EXPLICIT;
/*      */             } 
/*      */             this.writer.delete((K)castKey, (V)oldValue[0], cause[0]);
/*      */             n.retire();
/*      */           } 
/*      */           node[0] = n;
/*      */           return null;
/*      */         });
/* 2121 */     if (cause[0] != null) {
/* 2122 */       afterWrite(new RemovalTask(arrayOfNode[0]));
/* 2123 */       if (hasRemovalListener()) {
/* 2124 */         notifyRemoval(castKey, oldValue[0], cause[0]);
/*      */       }
/*      */     } 
/* 2127 */     return (cause[0] == RemovalCause.EXPLICIT) ? oldValue[0] : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean remove(Object key, Object value) {
/* 2132 */     Objects.requireNonNull(key);
/* 2133 */     if (value == null) {
/* 2134 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2138 */     Node[] arrayOfNode = new Node[1];
/*      */     
/* 2140 */     K[] oldKey = (K[])new Object[1];
/*      */     
/* 2142 */     V[] oldValue = (V[])new Object[1];
/* 2143 */     RemovalCause[] cause = new RemovalCause[1];
/*      */     
/* 2145 */     this.data.computeIfPresent(this.nodeFactory.newLookupKey(key), (kR, node) -> {
/*      */           synchronized (node) {
/*      */             oldKey[0] = node.getKey();
/*      */             
/*      */             oldValue[0] = node.getValue();
/*      */             if (oldKey[0] == null) {
/*      */               cause[0] = RemovalCause.COLLECTED;
/*      */             } else if (hasExpired(node, expirationTicker().read())) {
/*      */               cause[0] = RemovalCause.EXPIRED;
/*      */             } else if (node.containsValue(value)) {
/*      */               cause[0] = RemovalCause.EXPLICIT;
/*      */             } else {
/*      */               return node;
/*      */             } 
/*      */             this.writer.delete((K)oldKey[0], (V)oldValue[0], cause[0]);
/*      */             removed[0] = node;
/*      */             node.retire();
/*      */             return null;
/*      */           } 
/*      */         });
/* 2165 */     if (arrayOfNode[0] == null)
/* 2166 */       return false; 
/* 2167 */     if (hasRemovalListener()) {
/* 2168 */       notifyRemoval(oldKey[0], oldValue[0], cause[0]);
/*      */     }
/* 2170 */     afterWrite(new RemovalTask(arrayOfNode[0]));
/* 2171 */     return (cause[0] == RemovalCause.EXPLICIT);
/*      */   }
/*      */ 
/*      */   
/*      */   public V replace(K key, V value) {
/* 2176 */     Objects.requireNonNull(key);
/* 2177 */     Objects.requireNonNull(value);
/*      */     
/* 2179 */     int[] oldWeight = new int[1];
/*      */     
/* 2181 */     K[] nodeKey = (K[])new Object[1];
/*      */     
/* 2183 */     V[] oldValue = (V[])new Object[1];
/* 2184 */     long[] now = new long[1];
/* 2185 */     int weight = this.weigher.weigh(key, value);
/* 2186 */     Node<K, V> node = this.data.computeIfPresent(this.nodeFactory.newLookupKey(key), (k, n) -> {
/*      */           synchronized (n) {
/*      */             nodeKey[0] = n.getKey();
/*      */             
/*      */             oldValue[0] = n.getValue();
/*      */             
/*      */             oldWeight[0] = n.getWeight();
/*      */             
/*      */             if (nodeKey[0] == null || oldValue[0] == null || hasExpired(n, now[0] = expirationTicker().read())) {
/*      */               oldValue[0] = null;
/*      */               
/*      */               return n;
/*      */             } 
/*      */             long varTime = expireAfterUpdate(n, (K)key, (V)value, expiry(), now[0]);
/*      */             if (value != oldValue[0]) {
/*      */               this.writer.write((K)nodeKey[0], (V)value);
/*      */             }
/*      */             n.setValue((V)value, valueReferenceQueue());
/*      */             n.setWeight(weight);
/*      */             setVariableTime(n, varTime);
/*      */             setAccessTime(n, now[0]);
/*      */             setWriteTime(n, now[0]);
/*      */             return n;
/*      */           } 
/*      */         });
/* 2211 */     if (oldValue[0] == null) {
/* 2212 */       return null;
/*      */     }
/*      */     
/* 2215 */     int weightedDifference = weight - oldWeight[0];
/* 2216 */     if (expiresAfterWrite() || weightedDifference != 0) {
/* 2217 */       afterWrite(new UpdateTask(node, weightedDifference));
/*      */     } else {
/* 2219 */       afterRead(node, now[0], false);
/*      */     } 
/*      */     
/* 2222 */     if (hasRemovalListener() && value != oldValue[0]) {
/* 2223 */       notifyRemoval(nodeKey[0], oldValue[0], RemovalCause.REPLACED);
/*      */     }
/* 2225 */     return oldValue[0];
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean replace(K key, V oldValue, V newValue) {
/* 2230 */     Objects.requireNonNull(key);
/* 2231 */     Objects.requireNonNull(oldValue);
/* 2232 */     Objects.requireNonNull(newValue);
/*      */     
/* 2234 */     int weight = this.weigher.weigh(key, newValue);
/* 2235 */     boolean[] replaced = new boolean[1];
/*      */     
/* 2237 */     K[] nodeKey = (K[])new Object[1];
/*      */     
/* 2239 */     V[] prevValue = (V[])new Object[1];
/* 2240 */     int[] oldWeight = new int[1];
/* 2241 */     long[] now = new long[1];
/* 2242 */     Node<K, V> node = this.data.computeIfPresent(this.nodeFactory.newLookupKey(key), (k, n) -> {
/*      */           synchronized (n) {
/*      */             nodeKey[0] = n.getKey();
/*      */             
/*      */             prevValue[0] = n.getValue();
/*      */             
/*      */             oldWeight[0] = n.getWeight();
/*      */             
/*      */             if (nodeKey[0] == null || prevValue[0] == null || !n.containsValue(oldValue) || hasExpired(n, now[0] = expirationTicker().read())) {
/*      */               return n;
/*      */             }
/*      */             
/*      */             long varTime = expireAfterUpdate(n, (K)key, (V)newValue, expiry(), now[0]);
/*      */             if (newValue != prevValue[0]) {
/*      */               this.writer.write((K)key, (V)newValue);
/*      */             }
/*      */             n.setValue((V)newValue, valueReferenceQueue());
/*      */             n.setWeight(weight);
/*      */             setVariableTime(n, varTime);
/*      */             setAccessTime(n, now[0]);
/*      */             setWriteTime(n, now[0]);
/*      */             replaced[0] = true;
/*      */           } 
/*      */           return n;
/*      */         });
/* 2267 */     if (!replaced[0]) {
/* 2268 */       return false;
/*      */     }
/*      */     
/* 2271 */     int weightedDifference = weight - oldWeight[0];
/* 2272 */     if (expiresAfterWrite() || weightedDifference != 0) {
/* 2273 */       afterWrite(new UpdateTask(node, weightedDifference));
/*      */     } else {
/* 2275 */       afterRead(node, now[0], false);
/*      */     } 
/*      */     
/* 2278 */     if (hasRemovalListener() && oldValue != newValue) {
/* 2279 */       notifyRemoval(nodeKey[0], prevValue[0], RemovalCause.REPLACED);
/*      */     }
/* 2281 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void replaceAll(BiFunction<? super K, ? super V, ? extends V> function) {
/* 2286 */     Objects.requireNonNull(function);
/*      */     
/* 2288 */     BiFunction<K, V, V> remappingFunction = (key, oldValue) -> {
/*      */         V newValue = Objects.requireNonNull(function.apply(key, oldValue));
/*      */         if (oldValue != newValue) {
/*      */           this.writer.write((K)key, newValue);
/*      */         }
/*      */         return (BiFunction)newValue;
/*      */       };
/* 2295 */     for (K key : keySet()) {
/* 2296 */       long[] now = { expirationTicker().read() };
/* 2297 */       Object lookupKey = this.nodeFactory.newLookupKey(key);
/* 2298 */       remap(key, lookupKey, remappingFunction, now, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V computeIfAbsent(K key, Function<? super K, ? extends V> mappingFunction, boolean recordStats, boolean recordLoad) {
/* 2305 */     Objects.requireNonNull(key);
/* 2306 */     Objects.requireNonNull(mappingFunction);
/* 2307 */     long now = expirationTicker().read();
/*      */ 
/*      */     
/* 2310 */     Node<K, V> node = this.data.get(this.nodeFactory.newLookupKey(key));
/* 2311 */     if (node != null) {
/* 2312 */       V value = node.getValue();
/* 2313 */       if (value != null && !hasExpired(node, now)) {
/* 2314 */         if (!isComputingAsync(node)) {
/* 2315 */           tryExpireAfterRead(node, key, value, expiry(), now);
/* 2316 */           setAccessTime(node, now);
/*      */         } 
/*      */         
/* 2319 */         afterRead(node, now, recordStats);
/* 2320 */         return value;
/*      */       } 
/*      */     } 
/* 2323 */     if (recordStats) {
/* 2324 */       mappingFunction = statsAware(mappingFunction, recordLoad);
/*      */     }
/* 2326 */     Object keyRef = this.nodeFactory.newReferenceKey(key, keyReferenceQueue());
/* 2327 */     return doComputeIfAbsent(key, keyRef, mappingFunction, new long[] { now }, recordStats);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   V doComputeIfAbsent(K key, Object keyRef, Function<? super K, ? extends V> mappingFunction, long[] now, boolean recordStats) {
/* 2334 */     V[] oldValue = (V[])new Object[1];
/*      */     
/* 2336 */     V[] newValue = (V[])new Object[1];
/*      */     
/* 2338 */     K[] nodeKey = (K[])new Object[1];
/*      */     
/* 2340 */     Node[] arrayOfNode = new Node[1];
/*      */     
/* 2342 */     int[] weight = new int[2];
/* 2343 */     RemovalCause[] cause = new RemovalCause[1];
/* 2344 */     Node<K, V> node = this.data.compute(keyRef, (k, n) -> {
/*      */           if (n == null) {
/*      */             newValue[0] = mappingFunction.apply(key);
/*      */             
/*      */             if (newValue[0] == null) {
/*      */               return null;
/*      */             }
/*      */             
/*      */             now[0] = expirationTicker().read();
/*      */             
/*      */             weight[1] = this.weigher.weigh((K)key, (V)newValue[0]);
/*      */             
/*      */             n = this.nodeFactory.newNode((K)key, keyReferenceQueue(), (V)newValue[0], valueReferenceQueue(), weight[1], now[0]);
/*      */             
/*      */             setVariableTime(n, expireAfterCreate((K)key, (V)newValue[0], expiry(), now[0]));
/*      */             return n;
/*      */           } 
/*      */           synchronized (n) {
/*      */             nodeKey[0] = n.getKey();
/*      */             weight[0] = n.getWeight();
/*      */             oldValue[0] = n.getValue();
/*      */             if (nodeKey[0] == null || oldValue[0] == null) {
/*      */               cause[0] = RemovalCause.COLLECTED;
/*      */             } else if (hasExpired(n, now[0])) {
/*      */               cause[0] = RemovalCause.EXPIRED;
/*      */             } else {
/*      */               return n;
/*      */             } 
/*      */             this.writer.delete((K)nodeKey[0], (V)oldValue[0], cause[0]);
/*      */             newValue[0] = mappingFunction.apply(key);
/*      */             if (newValue[0] == null) {
/*      */               removed[0] = n;
/*      */               n.retire();
/*      */               return null;
/*      */             } 
/*      */             weight[1] = this.weigher.weigh((K)key, (V)newValue[0]);
/*      */             n.setValue((V)newValue[0], valueReferenceQueue());
/*      */             n.setWeight(weight[1]);
/*      */             now[0] = expirationTicker().read();
/*      */             setVariableTime(n, expireAfterCreate((K)key, (V)newValue[0], expiry(), now[0]));
/*      */             setAccessTime(n, now[0]);
/*      */             setWriteTime(n, now[0]);
/*      */             return n;
/*      */           } 
/*      */         });
/* 2389 */     if (node == null) {
/* 2390 */       if (arrayOfNode[0] != null) {
/* 2391 */         afterWrite(new RemovalTask(arrayOfNode[0]));
/*      */       }
/* 2393 */       return null;
/*      */     } 
/* 2395 */     if (cause[0] != null) {
/* 2396 */       if (hasRemovalListener()) {
/* 2397 */         notifyRemoval(nodeKey[0], oldValue[0], cause[0]);
/*      */       }
/* 2399 */       statsCounter().recordEviction(weight[0], cause[0]);
/*      */     } 
/* 2401 */     if (newValue[0] == null) {
/* 2402 */       if (!isComputingAsync(node)) {
/* 2403 */         tryExpireAfterRead(node, key, oldValue[0], expiry(), now[0]);
/* 2404 */         setAccessTime(node, now[0]);
/*      */       } 
/*      */       
/* 2407 */       afterRead(node, now[0], recordStats);
/* 2408 */       return oldValue[0];
/*      */     } 
/* 2410 */     if (oldValue[0] == null && cause[0] == null) {
/* 2411 */       afterWrite(new AddTask(node, weight[1]));
/*      */     } else {
/* 2413 */       int weightedDifference = weight[1] - weight[0];
/* 2414 */       afterWrite(new UpdateTask(node, weightedDifference));
/*      */     } 
/*      */     
/* 2417 */     return newValue[0];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V computeIfPresent(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
/* 2423 */     Objects.requireNonNull(key);
/* 2424 */     Objects.requireNonNull(remappingFunction);
/*      */ 
/*      */     
/* 2427 */     Object lookupKey = this.nodeFactory.newLookupKey(key);
/* 2428 */     Node<K, V> node = this.data.get(lookupKey);
/*      */     
/* 2430 */     if (node == null)
/* 2431 */       return null;  long now;
/* 2432 */     if (node.getValue() == null || hasExpired(node, now = expirationTicker().read())) {
/* 2433 */       scheduleDrainBuffers();
/* 2434 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 2438 */     BiFunction<? super K, ? super V, ? extends V> statsAwareRemappingFunction = statsAware(remappingFunction, false, true, true);
/*      */     
/* 2440 */     return remap(key, lookupKey, statsAwareRemappingFunction, new long[] { now }, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V compute(K key, BiFunction<? super K, ? super V, ? extends V> remappingFunction, boolean recordMiss, boolean recordLoad, boolean recordLoadFailure) {
/* 2447 */     Objects.requireNonNull(key);
/* 2448 */     Objects.requireNonNull(remappingFunction);
/*      */     
/* 2450 */     long[] now = { expirationTicker().read() };
/* 2451 */     Object keyRef = this.nodeFactory.newReferenceKey(key, keyReferenceQueue());
/*      */     
/* 2453 */     BiFunction<? super K, ? super V, ? extends V> statsAwareRemappingFunction = statsAware(remappingFunction, recordMiss, recordLoad, recordLoadFailure);
/* 2454 */     return remap(key, keyRef, statsAwareRemappingFunction, now, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V merge(K key, V value, BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
/* 2460 */     Objects.requireNonNull(key);
/* 2461 */     Objects.requireNonNull(value);
/* 2462 */     Objects.requireNonNull(remappingFunction);
/*      */     
/* 2464 */     long[] now = { expirationTicker().read() };
/* 2465 */     Object keyRef = this.nodeFactory.newReferenceKey(key, keyReferenceQueue());
/* 2466 */     BiFunction<? super K, ? super V, ? extends V> mergeFunction = (k, oldValue) -> (oldValue == null) ? value : statsAware(remappingFunction).apply(oldValue, value);
/*      */     
/* 2468 */     return remap(key, keyRef, mergeFunction, now, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   V remap(K key, Object keyRef, BiFunction<? super K, ? super V, ? extends V> remappingFunction, long[] now, boolean computeIfAbsent) {
/* 2491 */     K[] nodeKey = (K[])new Object[1];
/*      */     
/* 2493 */     V[] oldValue = (V[])new Object[1];
/*      */     
/* 2495 */     V[] newValue = (V[])new Object[1];
/*      */     
/* 2497 */     Node[] arrayOfNode = new Node[1];
/*      */     
/* 2499 */     int[] weight = new int[2];
/* 2500 */     RemovalCause[] cause = new RemovalCause[1];
/*      */     
/* 2502 */     Node<K, V> node = this.data.compute(keyRef, (kr, n) -> {
/*      */           if (n == null) {
/*      */             if (!computeIfAbsent) {
/*      */               return null;
/*      */             }
/*      */             
/*      */             newValue[0] = remappingFunction.apply(key, null);
/*      */             
/*      */             if (newValue[0] == null) {
/*      */               return null;
/*      */             }
/*      */             
/*      */             now[0] = expirationTicker().read();
/*      */             
/*      */             weight[1] = this.weigher.weigh((K)key, (V)newValue[0]);
/*      */             
/*      */             n = this.nodeFactory.newNode(keyRef, (V)newValue[0], valueReferenceQueue(), weight[1], now[0]);
/*      */             
/*      */             setVariableTime(n, expireAfterCreate((K)key, (V)newValue[0], expiry(), now[0]));
/*      */             return n;
/*      */           } 
/*      */           synchronized (n) {
/*      */             nodeKey[0] = n.getKey();
/*      */             oldValue[0] = n.getValue();
/*      */             if (nodeKey[0] == null || oldValue[0] == null) {
/*      */               cause[0] = RemovalCause.COLLECTED;
/*      */             } else if (hasExpired(n, now[0])) {
/*      */               cause[0] = RemovalCause.EXPIRED;
/*      */             } 
/*      */             if (cause[0] != null) {
/*      */               this.writer.delete((K)nodeKey[0], (V)oldValue[0], cause[0]);
/*      */               if (!computeIfAbsent) {
/*      */                 removed[0] = n;
/*      */                 n.retire();
/*      */                 return null;
/*      */               } 
/*      */             } 
/*      */             newValue[0] = remappingFunction.apply(nodeKey[0], (cause[0] == null) ? oldValue[0] : null);
/*      */             if (newValue[0] == null) {
/*      */               if (cause[0] == null) {
/*      */                 cause[0] = RemovalCause.EXPLICIT;
/*      */               }
/*      */               removed[0] = n;
/*      */               n.retire();
/*      */               return null;
/*      */             } 
/*      */             weight[0] = n.getWeight();
/*      */             weight[1] = this.weigher.weigh((K)key, (V)newValue[0]);
/*      */             now[0] = expirationTicker().read();
/*      */             if (cause[0] == null) {
/*      */               if (newValue[0] != oldValue[0]) {
/*      */                 cause[0] = RemovalCause.REPLACED;
/*      */               }
/*      */               setVariableTime(n, expireAfterUpdate(n, (K)key, (V)newValue[0], expiry(), now[0]));
/*      */             } else {
/*      */               setVariableTime(n, expireAfterCreate((K)key, (V)newValue[0], expiry(), now[0]));
/*      */             } 
/*      */             n.setValue((V)newValue[0], valueReferenceQueue());
/*      */             n.setWeight(weight[1]);
/*      */             setAccessTime(n, now[0]);
/*      */             setWriteTime(n, now[0]);
/*      */             return n;
/*      */           } 
/*      */         });
/* 2566 */     if (cause[0] != null) {
/* 2567 */       if (cause[0].wasEvicted()) {
/* 2568 */         statsCounter().recordEviction(weight[0], cause[0]);
/*      */       }
/* 2570 */       if (hasRemovalListener()) {
/* 2571 */         notifyRemoval(nodeKey[0], oldValue[0], cause[0]);
/*      */       }
/*      */     } 
/*      */     
/* 2575 */     if (arrayOfNode[0] != null) {
/* 2576 */       afterWrite(new RemovalTask(arrayOfNode[0]));
/* 2577 */     } else if (node != null) {
/*      */       
/* 2579 */       if (oldValue[0] == null && cause[0] == null) {
/* 2580 */         afterWrite(new AddTask(node, weight[1]));
/*      */       } else {
/* 2582 */         int weightedDifference = weight[1] - weight[0];
/* 2583 */         if (expiresAfterWrite() || weightedDifference != 0) {
/* 2584 */           afterWrite(new UpdateTask(node, weightedDifference));
/*      */         } else {
/* 2586 */           if (cause[0] == null) {
/* 2587 */             if (!isComputingAsync(node)) {
/* 2588 */               tryExpireAfterRead(node, key, newValue[0], expiry(), now[0]);
/* 2589 */               setAccessTime(node, now[0]);
/*      */             } 
/* 2591 */           } else if (cause[0] == RemovalCause.COLLECTED) {
/* 2592 */             scheduleDrainBuffers();
/*      */           } 
/* 2594 */           afterRead(node, now[0], false);
/*      */         } 
/*      */       } 
/*      */     } 
/* 2598 */     return newValue[0];
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<K> keySet() {
/* 2603 */     Set<K> ks = this.keySet;
/* 2604 */     return (ks == null) ? (this.keySet = new KeySetView<>(this)) : ks;
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection<V> values() {
/* 2609 */     Collection<V> vs = this.values;
/* 2610 */     return (vs == null) ? (this.values = new ValuesView<>(this)) : vs;
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<Map.Entry<K, V>> entrySet() {
/* 2615 */     Set<Map.Entry<K, V>> es = this.entrySet;
/* 2616 */     return (es == null) ? (this.entrySet = new EntrySetView<>(this)) : es;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map<K, V> evictionOrder(int limit, Function<V, V> transformer, boolean hottest) {
/* 2630 */     Supplier<Iterator<Node<K, V>>> iteratorSupplier = () -> {
/*      */         Comparator<Node<K, V>> comparator = Comparator.comparingInt(());
/*      */ 
/*      */         
/*      */         if (hottest) {
/*      */           LinkedDeque.PeekingIterator<Node<K, V>> secondary = LinkedDeque.PeekingIterator.comparing(accessOrderProbationDeque().descendingIterator(), accessOrderWindowDeque().descendingIterator(), comparator);
/*      */ 
/*      */           
/*      */           return LinkedDeque.PeekingIterator.concat(accessOrderProtectedDeque().descendingIterator(), secondary);
/*      */         } 
/*      */ 
/*      */         
/*      */         LinkedDeque.PeekingIterator<Node<K, V>> primary = LinkedDeque.PeekingIterator.comparing(accessOrderWindowDeque().iterator(), accessOrderProbationDeque().iterator(), comparator.reversed());
/*      */         
/*      */         return LinkedDeque.PeekingIterator.concat(primary, accessOrderProtectedDeque().iterator());
/*      */       };
/*      */     
/* 2647 */     return fixedSnapshot(iteratorSupplier, limit, transformer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map<K, V> expireAfterAccessOrder(int limit, Function<V, V> transformer, boolean oldest) {
/* 2661 */     if (!evicts()) {
/* 2662 */       Supplier<Iterator<Node<K, V>>> supplier = () -> oldest ? accessOrderWindowDeque().iterator() : accessOrderWindowDeque().descendingIterator();
/*      */ 
/*      */       
/* 2665 */       return fixedSnapshot(supplier, limit, transformer);
/*      */     } 
/*      */     
/* 2668 */     Supplier<Iterator<Node<K, V>>> iteratorSupplier = () -> {
/*      */         LinkedDeque.PeekingIterator<Node<K, V>> first; LinkedDeque.PeekingIterator<Node<K, V>> second;
/*      */         LinkedDeque.PeekingIterator<Node<K, V>> third;
/*      */         Comparator<Node<K, V>> comparator = Comparator.comparingLong(Node::getAccessTime);
/*      */         if (oldest) {
/*      */           first = accessOrderWindowDeque().iterator();
/*      */           second = accessOrderProbationDeque().iterator();
/*      */           third = accessOrderProtectedDeque().iterator();
/*      */         } else {
/*      */           comparator = comparator.reversed();
/*      */           first = accessOrderWindowDeque().descendingIterator();
/*      */           second = accessOrderProbationDeque().descendingIterator();
/*      */           third = accessOrderProtectedDeque().descendingIterator();
/*      */         } 
/*      */         return LinkedDeque.PeekingIterator.comparing(LinkedDeque.PeekingIterator.comparing(first, second, comparator), third, comparator);
/*      */       };
/* 2684 */     return fixedSnapshot(iteratorSupplier, limit, transformer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map<K, V> expireAfterWriteOrder(int limit, Function<V, V> transformer, boolean oldest) {
/* 2698 */     Supplier<Iterator<Node<K, V>>> iteratorSupplier = () -> oldest ? writeOrderDeque().iterator() : writeOrderDeque().descendingIterator();
/*      */ 
/*      */     
/* 2701 */     return fixedSnapshot(iteratorSupplier, limit, transformer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map<K, V> fixedSnapshot(Supplier<Iterator<Node<K, V>>> iteratorSupplier, int limit, Function<V, V> transformer) {
/* 2715 */     Caffeine.requireArgument((limit >= 0));
/* 2716 */     this.evictionLock.lock();
/*      */     try {
/* 2718 */       maintenance((Runnable)null);
/*      */       
/* 2720 */       int initialCapacity = Math.min(limit, size());
/* 2721 */       Iterator<Node<K, V>> iterator = iteratorSupplier.get();
/* 2722 */       Map<K, V> map = new LinkedHashMap<>(initialCapacity);
/* 2723 */       while (map.size() < limit && iterator.hasNext()) {
/* 2724 */         Node<K, V> node = iterator.next();
/* 2725 */         K key = node.getKey();
/* 2726 */         V value = transformer.apply(node.getValue());
/* 2727 */         if (key != null && value != null && node.isAlive()) {
/* 2728 */           map.put(key, value);
/*      */         }
/*      */       } 
/* 2731 */       return Collections.unmodifiableMap(map);
/*      */     } finally {
/* 2733 */       this.evictionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map<K, V> variableSnapshot(boolean ascending, int limit, Function<V, V> transformer) {
/* 2748 */     this.evictionLock.lock();
/*      */     try {
/* 2750 */       maintenance((Runnable)null);
/* 2751 */       return timerWheel().snapshot(ascending, limit, transformer);
/*      */     } finally {
/* 2753 */       this.evictionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   static final class KeySetView<K, V>
/*      */     extends AbstractSet<K> {
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     
/*      */     KeySetView(BoundedLocalCache<K, V> cache) {
/* 2762 */       this.cache = Objects.<BoundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 2767 */       return this.cache.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 2772 */       this.cache.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object obj) {
/* 2777 */       return this.cache.containsKey(obj);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object obj) {
/* 2782 */       return (this.cache.remove(obj) != null);
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<K> iterator() {
/* 2787 */       return new BoundedLocalCache.KeyIterator<>(this.cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public Spliterator<K> spliterator() {
/* 2792 */       return new BoundedLocalCache.KeySpliterator<>(this.cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 2797 */       List<Object> keys = new ArrayList(size());
/* 2798 */       for (Object key : this) {
/* 2799 */         keys.add(key);
/*      */       }
/* 2801 */       return keys.toArray();
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] array) {
/* 2806 */       List<Object> keys = new ArrayList(size());
/* 2807 */       for (Object key : this) {
/* 2808 */         keys.add(key);
/*      */       }
/* 2810 */       return keys.toArray(array);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class KeyIterator<K, V>
/*      */     implements Iterator<K> {
/*      */     final BoundedLocalCache.EntryIterator<K, V> iterator;
/*      */     
/*      */     KeyIterator(BoundedLocalCache<K, V> cache) {
/* 2819 */       this.iterator = new BoundedLocalCache.EntryIterator<>(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/* 2824 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public K next() {
/* 2829 */       return this.iterator.nextKey();
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 2834 */       this.iterator.remove();
/*      */     }
/*      */   }
/*      */   
/*      */   static final class KeySpliterator<K, V>
/*      */     implements Spliterator<K> {
/*      */     final Spliterator<Node<K, V>> spliterator;
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     
/*      */     KeySpliterator(BoundedLocalCache<K, V> cache) {
/* 2844 */       this(cache, cache.data.values().spliterator());
/*      */     }
/*      */     
/*      */     KeySpliterator(BoundedLocalCache<K, V> cache, Spliterator<Node<K, V>> spliterator) {
/* 2848 */       this.spliterator = Objects.<Spliterator<Node<K, V>>>requireNonNull(spliterator);
/* 2849 */       this.cache = Objects.<BoundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public void forEachRemaining(Consumer<? super K> action) {
/* 2854 */       Objects.requireNonNull(action);
/* 2855 */       Consumer<Node<K, V>> consumer = node -> {
/*      */           K key = (K)node.getKey();
/*      */           V value = (V)node.getValue();
/*      */           long now = this.cache.expirationTicker().read();
/*      */           if (key != null && value != null && node.isAlive() && !this.cache.hasExpired(node, now)) {
/*      */             action.accept(key);
/*      */           }
/*      */         };
/* 2863 */       this.spliterator.forEachRemaining(consumer);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryAdvance(Consumer<? super K> action) {
/* 2868 */       Objects.requireNonNull(action);
/* 2869 */       boolean[] advanced = { false };
/* 2870 */       Consumer<Node<K, V>> consumer = node -> {
/*      */           K key = (K)node.getKey();
/*      */           
/*      */           V value = (V)node.getValue();
/*      */           long now = this.cache.expirationTicker().read();
/*      */           if (key != null && value != null && node.isAlive() && !this.cache.hasExpired(node, now)) {
/*      */             action.accept(key);
/*      */             advanced[0] = true;
/*      */           } 
/*      */         };
/* 2880 */       while (this.spliterator.tryAdvance(consumer)) {
/* 2881 */         if (advanced[0]) {
/* 2882 */           return true;
/*      */         }
/*      */       } 
/*      */       
/* 2886 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Spliterator<K> trySplit() {
/* 2892 */       Spliterator<Node<K, V>> split = this.spliterator.trySplit();
/* 2893 */       return (split == null) ? null : new KeySpliterator(this.cache, split);
/*      */     }
/*      */ 
/*      */     
/*      */     public long estimateSize() {
/* 2898 */       return this.spliterator.estimateSize();
/*      */     }
/*      */ 
/*      */     
/*      */     public int characteristics() {
/* 2903 */       return 4353;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ValuesView<K, V>
/*      */     extends AbstractCollection<V> {
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     
/*      */     ValuesView(BoundedLocalCache<K, V> cache) {
/* 2912 */       this.cache = Objects.<BoundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 2917 */       return this.cache.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 2922 */       this.cache.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object o) {
/* 2927 */       return this.cache.containsValue(o);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeIf(Predicate<? super V> filter) {
/* 2932 */       Objects.requireNonNull(filter);
/* 2933 */       boolean removed = false;
/* 2934 */       for (Map.Entry<K, V> entry : this.cache.entrySet()) {
/* 2935 */         if (filter.test(entry.getValue())) {
/* 2936 */           removed |= this.cache.remove(entry.getKey(), entry.getValue());
/*      */         }
/*      */       } 
/* 2939 */       return removed;
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<V> iterator() {
/* 2944 */       return new BoundedLocalCache.ValueIterator<>(this.cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public Spliterator<V> spliterator() {
/* 2949 */       return new BoundedLocalCache.ValueSpliterator<>(this.cache);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ValueIterator<K, V>
/*      */     implements Iterator<V> {
/*      */     final BoundedLocalCache.EntryIterator<K, V> iterator;
/*      */     
/*      */     ValueIterator(BoundedLocalCache<K, V> cache) {
/* 2958 */       this.iterator = new BoundedLocalCache.EntryIterator<>(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/* 2963 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public V next() {
/* 2968 */       return this.iterator.nextValue();
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 2973 */       this.iterator.remove();
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ValueSpliterator<K, V>
/*      */     implements Spliterator<V> {
/*      */     final Spliterator<Node<K, V>> spliterator;
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     
/*      */     ValueSpliterator(BoundedLocalCache<K, V> cache) {
/* 2983 */       this(cache, cache.data.values().spliterator());
/*      */     }
/*      */     
/*      */     ValueSpliterator(BoundedLocalCache<K, V> cache, Spliterator<Node<K, V>> spliterator) {
/* 2987 */       this.spliterator = Objects.<Spliterator<Node<K, V>>>requireNonNull(spliterator);
/* 2988 */       this.cache = Objects.<BoundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public void forEachRemaining(Consumer<? super V> action) {
/* 2993 */       Objects.requireNonNull(action);
/* 2994 */       Consumer<Node<K, V>> consumer = node -> {
/*      */           K key = (K)node.getKey();
/*      */           V value = (V)node.getValue();
/*      */           long now = this.cache.expirationTicker().read();
/*      */           if (key != null && value != null && node.isAlive() && !this.cache.hasExpired(node, now)) {
/*      */             action.accept(value);
/*      */           }
/*      */         };
/* 3002 */       this.spliterator.forEachRemaining(consumer);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryAdvance(Consumer<? super V> action) {
/* 3007 */       Objects.requireNonNull(action);
/* 3008 */       boolean[] advanced = { false };
/* 3009 */       long now = this.cache.expirationTicker().read();
/* 3010 */       Consumer<Node<K, V>> consumer = node -> {
/*      */           K key = (K)node.getKey();
/*      */           
/*      */           V value = (V)node.getValue();
/*      */           if (key != null && value != null && !this.cache.hasExpired(node, now) && node.isAlive()) {
/*      */             action.accept(value);
/*      */             advanced[0] = true;
/*      */           } 
/*      */         };
/* 3019 */       while (this.spliterator.tryAdvance(consumer)) {
/* 3020 */         if (advanced[0]) {
/* 3021 */           return true;
/*      */         }
/*      */       } 
/*      */       
/* 3025 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Spliterator<V> trySplit() {
/* 3031 */       Spliterator<Node<K, V>> split = this.spliterator.trySplit();
/* 3032 */       return (split == null) ? null : new ValueSpliterator(this.cache, split);
/*      */     }
/*      */ 
/*      */     
/*      */     public long estimateSize() {
/* 3037 */       return this.spliterator.estimateSize();
/*      */     }
/*      */ 
/*      */     
/*      */     public int characteristics() {
/* 3042 */       return 4352;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EntrySetView<K, V>
/*      */     extends AbstractSet<Map.Entry<K, V>> {
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     
/*      */     EntrySetView(BoundedLocalCache<K, V> cache) {
/* 3051 */       this.cache = Objects.<BoundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 3056 */       return this.cache.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 3061 */       this.cache.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object obj) {
/* 3066 */       if (!(obj instanceof Map.Entry)) {
/* 3067 */         return false;
/*      */       }
/* 3069 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)obj;
/* 3070 */       Node<K, V> node = this.cache.data.get(this.cache.nodeFactory.newLookupKey(entry.getKey()));
/* 3071 */       return (node != null && Objects.equals(node.getValue(), entry.getValue()));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object obj) {
/* 3076 */       if (!(obj instanceof Map.Entry)) {
/* 3077 */         return false;
/*      */       }
/* 3079 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)obj;
/* 3080 */       return this.cache.remove(entry.getKey(), entry.getValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeIf(Predicate<? super Map.Entry<K, V>> filter) {
/* 3085 */       Objects.requireNonNull(filter);
/* 3086 */       boolean removed = false;
/* 3087 */       for (Map.Entry<K, V> entry : this) {
/* 3088 */         if (filter.test(entry)) {
/* 3089 */           removed |= this.cache.remove(entry.getKey(), entry.getValue());
/*      */         }
/*      */       } 
/* 3092 */       return removed;
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<Map.Entry<K, V>> iterator() {
/* 3097 */       return new BoundedLocalCache.EntryIterator<>(this.cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public Spliterator<Map.Entry<K, V>> spliterator() {
/* 3102 */       return new BoundedLocalCache.EntrySpliterator<>(this.cache);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EntryIterator<K, V>
/*      */     implements Iterator<Map.Entry<K, V>>
/*      */   {
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     final Iterator<Node<K, V>> iterator;
/*      */     final long now;
/*      */     K key;
/*      */     V value;
/*      */     K removalKey;
/*      */     Node<K, V> next;
/*      */     
/*      */     EntryIterator(BoundedLocalCache<K, V> cache) {
/* 3118 */       this.iterator = cache.data.values().iterator();
/* 3119 */       this.now = cache.expirationTicker().read();
/* 3120 */       this.cache = cache;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/* 3125 */       if (this.next != null) {
/* 3126 */         return true;
/*      */       }
/*      */       
/* 3129 */       while (this.iterator.hasNext()) {
/* 3130 */         this.next = this.iterator.next();
/* 3131 */         this.value = this.next.getValue();
/* 3132 */         this.key = this.next.getKey();
/* 3133 */         if (this.cache.hasExpired(this.next, this.now) || this.key == null || this.value == null || !this.next.isAlive()) {
/* 3134 */           this.value = null;
/* 3135 */           this.next = null;
/* 3136 */           this.key = null;
/*      */           continue;
/*      */         } 
/* 3139 */         return true;
/*      */       } 
/* 3141 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     K nextKey() {
/* 3147 */       if (!hasNext()) {
/* 3148 */         throw new NoSuchElementException();
/*      */       }
/* 3150 */       this.removalKey = this.key;
/* 3151 */       this.value = null;
/* 3152 */       this.next = null;
/* 3153 */       this.key = null;
/* 3154 */       return this.removalKey;
/*      */     }
/*      */ 
/*      */     
/*      */     V nextValue() {
/* 3159 */       if (!hasNext()) {
/* 3160 */         throw new NoSuchElementException();
/*      */       }
/* 3162 */       this.removalKey = this.key;
/* 3163 */       V val = this.value;
/* 3164 */       this.value = null;
/* 3165 */       this.next = null;
/* 3166 */       this.key = null;
/* 3167 */       return val;
/*      */     }
/*      */ 
/*      */     
/*      */     public Map.Entry<K, V> next() {
/* 3172 */       if (!hasNext()) {
/* 3173 */         throw new NoSuchElementException();
/*      */       }
/*      */       
/* 3176 */       Map.Entry<K, V> entry = new WriteThroughEntry<>(this.cache, this.key, this.value);
/* 3177 */       this.removalKey = this.key;
/* 3178 */       this.value = null;
/* 3179 */       this.next = null;
/* 3180 */       this.key = null;
/* 3181 */       return entry;
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 3186 */       if (this.removalKey == null) {
/* 3187 */         throw new IllegalStateException();
/*      */       }
/* 3189 */       this.cache.remove(this.removalKey);
/* 3190 */       this.removalKey = null;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class EntrySpliterator<K, V>
/*      */     implements Spliterator<Map.Entry<K, V>> {
/*      */     final Spliterator<Node<K, V>> spliterator;
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     
/*      */     EntrySpliterator(BoundedLocalCache<K, V> cache) {
/* 3200 */       this(cache, cache.data.values().spliterator());
/*      */     }
/*      */     
/*      */     EntrySpliterator(BoundedLocalCache<K, V> cache, Spliterator<Node<K, V>> spliterator) {
/* 3204 */       this.spliterator = Objects.<Spliterator<Node<K, V>>>requireNonNull(spliterator);
/* 3205 */       this.cache = Objects.<BoundedLocalCache<K, V>>requireNonNull(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public void forEachRemaining(Consumer<? super Map.Entry<K, V>> action) {
/* 3210 */       Objects.requireNonNull(action);
/* 3211 */       Consumer<Node<K, V>> consumer = node -> {
/*      */           K key = (K)node.getKey();
/*      */           V value = (V)node.getValue();
/*      */           long now = this.cache.expirationTicker().read();
/*      */           if (key != null && value != null && node.isAlive() && !this.cache.hasExpired(node, now)) {
/*      */             action.accept(new WriteThroughEntry<>(this.cache, key, value));
/*      */           }
/*      */         };
/* 3219 */       this.spliterator.forEachRemaining(consumer);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean tryAdvance(Consumer<? super Map.Entry<K, V>> action) {
/* 3224 */       Objects.requireNonNull(action);
/* 3225 */       boolean[] advanced = { false };
/* 3226 */       Consumer<Node<K, V>> consumer = node -> {
/*      */           K key = (K)node.getKey();
/*      */           
/*      */           V value = (V)node.getValue();
/*      */           long now = this.cache.expirationTicker().read();
/*      */           if (key != null && value != null && node.isAlive() && !this.cache.hasExpired(node, now)) {
/*      */             action.accept(new WriteThroughEntry<>(this.cache, key, value));
/*      */             advanced[0] = true;
/*      */           } 
/*      */         };
/* 3236 */       while (this.spliterator.tryAdvance(consumer)) {
/* 3237 */         if (advanced[0]) {
/* 3238 */           return true;
/*      */         }
/*      */       } 
/*      */       
/* 3242 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Spliterator<Map.Entry<K, V>> trySplit() {
/* 3248 */       Spliterator<Node<K, V>> split = this.spliterator.trySplit();
/* 3249 */       return (split == null) ? null : new EntrySpliterator(this.cache, split);
/*      */     }
/*      */ 
/*      */     
/*      */     public long estimateSize() {
/* 3254 */       return this.spliterator.estimateSize();
/*      */     }
/*      */ 
/*      */     
/*      */     public int characteristics() {
/* 3259 */       return 4353;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class PerformCleanupTask
/*      */     extends ForkJoinTask<Void>
/*      */     implements Runnable {
/*      */     private static final long serialVersionUID = 1L;
/*      */     final WeakReference<BoundedLocalCache<?, ?>> reference;
/*      */     
/*      */     PerformCleanupTask(BoundedLocalCache<?, ?> cache) {
/* 3270 */       this.reference = new WeakReference<>(cache);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean exec() {
/*      */       try {
/* 3276 */         run();
/* 3277 */       } catch (Throwable t) {
/* 3278 */         BoundedLocalCache.logger.log(Level.SEVERE, "Exception thrown when performing the maintenance task", t);
/*      */       } 
/*      */ 
/*      */       
/* 3282 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/* 3287 */       BoundedLocalCache<?, ?> cache = this.reference.get();
/* 3288 */       if (cache != null) {
/* 3289 */         cache.performCleanUp((Runnable)null);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Void getRawResult() {
/* 3300 */       return null;
/*      */     }
/*      */     public void setRawResult(Void v) {}
/*      */     public boolean cancel(boolean mayInterruptIfRunning) {
/* 3304 */       return false;
/*      */     }
/*      */     public void complete(Void value) {}
/*      */     public void completeExceptionally(Throwable ex) {} }
/*      */   
/*      */   static <K, V> SerializationProxy<K, V> makeSerializationProxy(BoundedLocalCache<?, ?> cache, boolean isWeighted) {
/* 3310 */     SerializationProxy<K, V> proxy = new SerializationProxy<>();
/* 3311 */     proxy.weakKeys = cache.collectKeys();
/* 3312 */     proxy.weakValues = cache.nodeFactory.weakValues();
/* 3313 */     proxy.softValues = cache.nodeFactory.softValues();
/* 3314 */     proxy.isRecordingStats = cache.isRecordingStats();
/* 3315 */     proxy.removalListener = cache.removalListener();
/* 3316 */     proxy.ticker = cache.expirationTicker();
/* 3317 */     proxy.writer = cache.writer;
/* 3318 */     if (cache.expiresAfterAccess()) {
/* 3319 */       proxy.expiresAfterAccessNanos = cache.expiresAfterAccessNanos();
/*      */     }
/* 3321 */     if (cache.expiresAfterWrite()) {
/* 3322 */       proxy.expiresAfterWriteNanos = cache.expiresAfterWriteNanos();
/*      */     }
/* 3324 */     if (cache.expiresVariable()) {
/* 3325 */       proxy.expiry = cache.expiry();
/*      */     }
/* 3327 */     if (cache.evicts()) {
/* 3328 */       if (isWeighted) {
/* 3329 */         proxy.weigher = cache.weigher;
/* 3330 */         proxy.maximumWeight = cache.maximum();
/*      */       } else {
/* 3332 */         proxy.maximumSize = cache.maximum();
/*      */       } 
/*      */     }
/* 3335 */     return proxy;
/*      */   }
/*      */ 
/*      */   
/*      */   static class BoundedLocalManualCache<K, V>
/*      */     implements LocalManualCache<K, V>, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     final boolean isWeighted;
/*      */     Policy<K, V> policy;
/*      */     
/*      */     BoundedLocalManualCache(Caffeine<K, V> builder) {
/* 3349 */       this(builder, null);
/*      */     }
/*      */     
/*      */     BoundedLocalManualCache(Caffeine<K, V> builder, CacheLoader<? super K, V> loader) {
/* 3353 */       this.cache = LocalCacheFactory.newBoundedLocalCache(builder, loader, false);
/* 3354 */       this.isWeighted = builder.isWeighted();
/*      */     }
/*      */ 
/*      */     
/*      */     public BoundedLocalCache<K, V> cache() {
/* 3359 */       return this.cache;
/*      */     }
/*      */ 
/*      */     
/*      */     public Policy<K, V> policy() {
/* 3364 */       return (this.policy == null) ? (
/* 3365 */         this.policy = new BoundedLocalCache.BoundedPolicy<>(this.cache, Function.identity(), this.isWeighted)) : 
/* 3366 */         this.policy;
/*      */     }
/*      */ 
/*      */     
/*      */     private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 3371 */       throw new InvalidObjectException("Proxy required");
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/* 3375 */       return BoundedLocalCache.makeSerializationProxy(this.cache, this.isWeighted);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class BoundedPolicy<K, V>
/*      */     implements Policy<K, V> {
/*      */     final BoundedLocalCache<K, V> cache;
/*      */     final Function<V, V> transformer;
/*      */     final boolean isWeighted;
/*      */     Optional<Policy.Eviction<K, V>> eviction;
/*      */     Optional<Policy.Expiration<K, V>> refreshes;
/*      */     Optional<Policy.Expiration<K, V>> afterWrite;
/*      */     Optional<Policy.Expiration<K, V>> afterAccess;
/*      */     Optional<Policy.VarExpiration<K, V>> variable;
/*      */     
/*      */     BoundedPolicy(BoundedLocalCache<K, V> cache, Function<V, V> transformer, boolean isWeighted) {
/* 3391 */       this.transformer = transformer;
/* 3392 */       this.isWeighted = isWeighted;
/* 3393 */       this.cache = cache;
/*      */     }
/*      */     
/*      */     public boolean isRecordingStats() {
/* 3397 */       return this.cache.isRecordingStats();
/*      */     }
/*      */     public V getIfPresentQuietly(Object key) {
/* 3400 */       Node<K, V> node = this.cache.data.get(this.cache.nodeFactory.newLookupKey(key));
/* 3401 */       if (node == null || this.cache.hasExpired(node, this.cache.expirationTicker().read())) {
/* 3402 */         return null;
/*      */       }
/* 3404 */       return this.transformer.apply(node.getValue());
/*      */     }
/*      */     public Optional<Policy.Eviction<K, V>> eviction() {
/* 3407 */       return this.cache.evicts() ? (
/* 3408 */         (this.eviction == null) ? (this.eviction = Optional.of(new BoundedEviction())) : this.eviction) : 
/* 3409 */         Optional.<Policy.Eviction<K, V>>empty();
/*      */     }
/*      */     public Optional<Policy.Expiration<K, V>> expireAfterAccess() {
/* 3412 */       if (!this.cache.expiresAfterAccess()) {
/* 3413 */         return Optional.empty();
/*      */       }
/* 3415 */       return (this.afterAccess == null) ? (
/* 3416 */         this.afterAccess = Optional.of(new BoundedExpireAfterAccess())) : 
/* 3417 */         this.afterAccess;
/*      */     }
/*      */     public Optional<Policy.Expiration<K, V>> expireAfterWrite() {
/* 3420 */       if (!this.cache.expiresAfterWrite()) {
/* 3421 */         return Optional.empty();
/*      */       }
/* 3423 */       return (this.afterWrite == null) ? (
/* 3424 */         this.afterWrite = Optional.of(new BoundedExpireAfterWrite())) : 
/* 3425 */         this.afterWrite;
/*      */     }
/*      */     public Optional<Policy.VarExpiration<K, V>> expireVariably() {
/* 3428 */       if (!this.cache.expiresVariable()) {
/* 3429 */         return Optional.empty();
/*      */       }
/* 3431 */       return (this.variable == null) ? (
/* 3432 */         this.variable = Optional.of(new BoundedVarExpiration())) : 
/* 3433 */         this.variable;
/*      */     }
/*      */     public Optional<Policy.Expiration<K, V>> refreshAfterWrite() {
/* 3436 */       if (!this.cache.refreshAfterWrite()) {
/* 3437 */         return Optional.empty();
/*      */       }
/* 3439 */       return (this.refreshes == null) ? (
/* 3440 */         this.refreshes = Optional.of(new BoundedRefreshAfterWrite())) : 
/* 3441 */         this.refreshes;
/*      */     }
/*      */     
/*      */     final class BoundedEviction implements Policy.Eviction<K, V> {
/*      */       public boolean isWeighted() {
/* 3446 */         return BoundedLocalCache.BoundedPolicy.this.isWeighted;
/*      */       }
/*      */       public OptionalInt weightOf(K key) {
/* 3449 */         Objects.requireNonNull(key);
/* 3450 */         if (!BoundedLocalCache.BoundedPolicy.this.isWeighted) {
/* 3451 */           return OptionalInt.empty();
/*      */         }
/* 3453 */         Node<K, V> node = (Node<K, V>)BoundedLocalCache.BoundedPolicy.this.cache.data.get(BoundedLocalCache.BoundedPolicy.this.cache.nodeFactory.newLookupKey(key));
/* 3454 */         if (node == null) {
/* 3455 */           return OptionalInt.empty();
/*      */         }
/* 3457 */         synchronized (node) {
/* 3458 */           return OptionalInt.of(node.getWeight());
/*      */         } 
/*      */       }
/*      */       public OptionalLong weightedSize() {
/* 3462 */         if (BoundedLocalCache.BoundedPolicy.this.cache.evicts() && isWeighted()) {
/* 3463 */           BoundedLocalCache.BoundedPolicy.this.cache.evictionLock.lock();
/*      */           try {
/* 3465 */             return OptionalLong.of(Math.max(0L, BoundedLocalCache.BoundedPolicy.this.cache.weightedSize()));
/*      */           } finally {
/* 3467 */             BoundedLocalCache.BoundedPolicy.this.cache.evictionLock.unlock();
/*      */           } 
/*      */         } 
/* 3470 */         return OptionalLong.empty();
/*      */       }
/*      */       public long getMaximum() {
/* 3473 */         BoundedLocalCache.BoundedPolicy.this.cache.evictionLock.lock();
/*      */         try {
/* 3475 */           return BoundedLocalCache.BoundedPolicy.this.cache.maximum();
/*      */         } finally {
/* 3477 */           BoundedLocalCache.BoundedPolicy.this.cache.evictionLock.unlock();
/*      */         } 
/*      */       }
/*      */       public void setMaximum(long maximum) {
/* 3481 */         BoundedLocalCache.BoundedPolicy.this.cache.evictionLock.lock();
/*      */         try {
/* 3483 */           BoundedLocalCache.BoundedPolicy.this.cache.setMaximumSize(maximum);
/* 3484 */           BoundedLocalCache.BoundedPolicy.this.cache.maintenance((Runnable)null);
/*      */         } finally {
/* 3486 */           BoundedLocalCache.BoundedPolicy.this.cache.evictionLock.unlock();
/*      */         } 
/*      */       }
/*      */       public Map<K, V> coldest(int limit) {
/* 3490 */         return BoundedLocalCache.BoundedPolicy.this.cache.evictionOrder(limit, BoundedLocalCache.BoundedPolicy.this.transformer, false);
/*      */       }
/*      */       public Map<K, V> hottest(int limit) {
/* 3493 */         return BoundedLocalCache.BoundedPolicy.this.cache.evictionOrder(limit, BoundedLocalCache.BoundedPolicy.this.transformer, true);
/*      */       }
/*      */     }
/*      */     
/*      */     final class BoundedExpireAfterAccess
/*      */       implements Policy.Expiration<K, V> {
/*      */       public OptionalLong ageOf(K key, TimeUnit unit) {
/* 3500 */         Objects.requireNonNull(key);
/* 3501 */         Objects.requireNonNull(unit);
/* 3502 */         Object lookupKey = BoundedLocalCache.BoundedPolicy.this.cache.nodeFactory.newLookupKey(key);
/* 3503 */         Node<?, ?> node = (Node<?, ?>)BoundedLocalCache.BoundedPolicy.this.cache.data.get(lookupKey);
/* 3504 */         if (node == null) {
/* 3505 */           return OptionalLong.empty();
/*      */         }
/* 3507 */         long age = BoundedLocalCache.BoundedPolicy.this.cache.expirationTicker().read() - node.getAccessTime();
/* 3508 */         return (age > BoundedLocalCache.BoundedPolicy.this.cache.expiresAfterAccessNanos()) ? 
/* 3509 */           OptionalLong.empty() : 
/* 3510 */           OptionalLong.of(unit.convert(age, TimeUnit.NANOSECONDS));
/*      */       }
/*      */       public long getExpiresAfter(TimeUnit unit) {
/* 3513 */         return unit.convert(BoundedLocalCache.BoundedPolicy.this.cache.expiresAfterAccessNanos(), TimeUnit.NANOSECONDS);
/*      */       }
/*      */       public void setExpiresAfter(long duration, TimeUnit unit) {
/* 3516 */         Caffeine.requireArgument((duration >= 0L));
/* 3517 */         BoundedLocalCache.BoundedPolicy.this.cache.setExpiresAfterAccessNanos(unit.toNanos(duration));
/* 3518 */         BoundedLocalCache.BoundedPolicy.this.cache.scheduleAfterWrite();
/*      */       }
/*      */       public Map<K, V> oldest(int limit) {
/* 3521 */         return BoundedLocalCache.BoundedPolicy.this.cache.expireAfterAccessOrder(limit, BoundedLocalCache.BoundedPolicy.this.transformer, true);
/*      */       }
/*      */       public Map<K, V> youngest(int limit) {
/* 3524 */         return BoundedLocalCache.BoundedPolicy.this.cache.expireAfterAccessOrder(limit, BoundedLocalCache.BoundedPolicy.this.transformer, false);
/*      */       }
/*      */     }
/*      */     
/*      */     final class BoundedExpireAfterWrite
/*      */       implements Policy.Expiration<K, V> {
/*      */       public OptionalLong ageOf(K key, TimeUnit unit) {
/* 3531 */         Objects.requireNonNull(key);
/* 3532 */         Objects.requireNonNull(unit);
/* 3533 */         Object lookupKey = BoundedLocalCache.BoundedPolicy.this.cache.nodeFactory.newLookupKey(key);
/* 3534 */         Node<?, ?> node = (Node<?, ?>)BoundedLocalCache.BoundedPolicy.this.cache.data.get(lookupKey);
/* 3535 */         if (node == null) {
/* 3536 */           return OptionalLong.empty();
/*      */         }
/* 3538 */         long age = BoundedLocalCache.BoundedPolicy.this.cache.expirationTicker().read() - node.getWriteTime();
/* 3539 */         return (age > BoundedLocalCache.BoundedPolicy.this.cache.expiresAfterWriteNanos()) ? 
/* 3540 */           OptionalLong.empty() : 
/* 3541 */           OptionalLong.of(unit.convert(age, TimeUnit.NANOSECONDS));
/*      */       }
/*      */       public long getExpiresAfter(TimeUnit unit) {
/* 3544 */         return unit.convert(BoundedLocalCache.BoundedPolicy.this.cache.expiresAfterWriteNanos(), TimeUnit.NANOSECONDS);
/*      */       }
/*      */       public void setExpiresAfter(long duration, TimeUnit unit) {
/* 3547 */         Caffeine.requireArgument((duration >= 0L));
/* 3548 */         BoundedLocalCache.BoundedPolicy.this.cache.setExpiresAfterWriteNanos(unit.toNanos(duration));
/* 3549 */         BoundedLocalCache.BoundedPolicy.this.cache.scheduleAfterWrite();
/*      */       }
/*      */       public Map<K, V> oldest(int limit) {
/* 3552 */         return BoundedLocalCache.BoundedPolicy.this.cache.expireAfterWriteOrder(limit, BoundedLocalCache.BoundedPolicy.this.transformer, true);
/*      */       }
/*      */       public Map<K, V> youngest(int limit) {
/* 3555 */         return BoundedLocalCache.BoundedPolicy.this.cache.expireAfterWriteOrder(limit, BoundedLocalCache.BoundedPolicy.this.transformer, false);
/*      */       }
/*      */     }
/*      */     
/*      */     final class BoundedVarExpiration
/*      */       implements Policy.VarExpiration<K, V> {
/*      */       public OptionalLong getExpiresAfter(K key, TimeUnit unit) {
/* 3562 */         Objects.requireNonNull(key);
/* 3563 */         Objects.requireNonNull(unit);
/* 3564 */         Object lookupKey = BoundedLocalCache.BoundedPolicy.this.cache.nodeFactory.newLookupKey(key);
/* 3565 */         Node<?, ?> node = (Node<?, ?>)BoundedLocalCache.BoundedPolicy.this.cache.data.get(lookupKey);
/* 3566 */         if (node == null) {
/* 3567 */           return OptionalLong.empty();
/*      */         }
/* 3569 */         long duration = node.getVariableTime() - BoundedLocalCache.BoundedPolicy.this.cache.expirationTicker().read();
/* 3570 */         return (duration <= 0L) ? 
/* 3571 */           OptionalLong.empty() : 
/* 3572 */           OptionalLong.of(unit.convert(duration, TimeUnit.NANOSECONDS));
/*      */       }
/*      */       public void setExpiresAfter(K key, long duration, TimeUnit unit) {
/* 3575 */         Objects.requireNonNull(key);
/* 3576 */         Objects.requireNonNull(unit);
/* 3577 */         Caffeine.requireArgument((duration >= 0L));
/* 3578 */         Object lookupKey = BoundedLocalCache.BoundedPolicy.this.cache.nodeFactory.newLookupKey(key);
/* 3579 */         Node<K, V> node = (Node<K, V>)BoundedLocalCache.BoundedPolicy.this.cache.data.get(lookupKey);
/* 3580 */         if (node != null) {
/*      */           
/* 3582 */           long now, durationNanos = TimeUnit.NANOSECONDS.convert(duration, unit);
/* 3583 */           synchronized (node) {
/* 3584 */             now = BoundedLocalCache.BoundedPolicy.this.cache.expirationTicker().read();
/* 3585 */             node.setVariableTime(now + Math.min(durationNanos, 4611686018427387903L));
/*      */           } 
/* 3587 */           BoundedLocalCache.BoundedPolicy.this.cache.afterRead(node, now, false);
/*      */         } 
/*      */       }
/*      */       public void put(K key, V value, long duration, TimeUnit unit) {
/* 3591 */         put(key, value, duration, unit, false);
/*      */       }
/*      */       public boolean putIfAbsent(K key, V value, long duration, TimeUnit unit) {
/* 3594 */         V previous = put(key, value, duration, unit, true);
/* 3595 */         return (previous == null);
/*      */       } V put(K key, V value, final long duration, final TimeUnit unit, boolean onlyIfAbsent) {
/*      */         CompletableFuture<V> completableFuture;
/* 3598 */         Objects.requireNonNull(unit);
/* 3599 */         Objects.requireNonNull(value);
/* 3600 */         Caffeine.requireArgument((duration >= 0L));
/* 3601 */         Expiry<K, V> expiry = new Expiry<K, V>()
/*      */           {
/*      */             public long expireAfterCreate(K key, V value, long currentTime) {
/* 3604 */               return unit.toNanos(duration);
/*      */             }
/*      */             
/*      */             public long expireAfterUpdate(K key, V value, long currentTime, long currentDuration) {
/* 3608 */               return unit.toNanos(duration);
/*      */             }
/*      */             
/*      */             public long expireAfterRead(K key, V value, long currentTime, long currentDuration) {
/* 3612 */               return currentDuration;
/*      */             }
/*      */           };
/* 3615 */         if (BoundedLocalCache.BoundedPolicy.this.cache.isAsync) {
/*      */           
/* 3617 */           Expiry<K, V> asyncExpiry = (Expiry<K, V>)new Async.AsyncExpiry<>(expiry);
/* 3618 */           expiry = asyncExpiry;
/*      */ 
/*      */           
/* 3621 */           CompletableFuture<V> completableFuture1 = CompletableFuture.completedFuture(value);
/* 3622 */           completableFuture = completableFuture1;
/*      */         } 
/* 3624 */         return BoundedLocalCache.BoundedPolicy.this.cache.put(key, (V)completableFuture, expiry, true, onlyIfAbsent);
/*      */       }
/*      */       public Map<K, V> oldest(int limit) {
/* 3627 */         return BoundedLocalCache.BoundedPolicy.this.cache.variableSnapshot(true, limit, BoundedLocalCache.BoundedPolicy.this.transformer);
/*      */       }
/*      */       public Map<K, V> youngest(int limit) {
/* 3630 */         return BoundedLocalCache.BoundedPolicy.this.cache.variableSnapshot(false, limit, BoundedLocalCache.BoundedPolicy.this.transformer);
/*      */       }
/*      */     }
/*      */     
/*      */     final class BoundedRefreshAfterWrite
/*      */       implements Policy.Expiration<K, V> {
/*      */       public OptionalLong ageOf(K key, TimeUnit unit) {
/* 3637 */         Objects.requireNonNull(key);
/* 3638 */         Objects.requireNonNull(unit);
/* 3639 */         Object lookupKey = BoundedLocalCache.BoundedPolicy.this.cache.nodeFactory.newLookupKey(key);
/* 3640 */         Node<?, ?> node = (Node<?, ?>)BoundedLocalCache.BoundedPolicy.this.cache.data.get(lookupKey);
/* 3641 */         if (node == null) {
/* 3642 */           return OptionalLong.empty();
/*      */         }
/* 3644 */         long age = BoundedLocalCache.BoundedPolicy.this.cache.expirationTicker().read() - node.getWriteTime();
/* 3645 */         return (age > BoundedLocalCache.BoundedPolicy.this.cache.refreshAfterWriteNanos()) ? 
/* 3646 */           OptionalLong.empty() : 
/* 3647 */           OptionalLong.of(unit.convert(age, TimeUnit.NANOSECONDS));
/*      */       }
/*      */       public long getExpiresAfter(TimeUnit unit) {
/* 3650 */         return unit.convert(BoundedLocalCache.BoundedPolicy.this.cache.refreshAfterWriteNanos(), TimeUnit.NANOSECONDS);
/*      */       }
/*      */       public void setExpiresAfter(long duration, TimeUnit unit) {
/* 3653 */         Caffeine.requireArgument((duration >= 0L));
/* 3654 */         BoundedLocalCache.BoundedPolicy.this.cache.setRefreshAfterWriteNanos(unit.toNanos(duration));
/* 3655 */         BoundedLocalCache.BoundedPolicy.this.cache.scheduleAfterWrite();
/*      */       }
/*      */       
/*      */       public Map<K, V> oldest(int limit) {
/* 3659 */         return BoundedLocalCache.BoundedPolicy.this.cache.expiresAfterWrite() ? (
/* 3660 */           (Policy.Expiration<K, V>)BoundedLocalCache.BoundedPolicy.this.expireAfterWrite().get()).oldest(limit) : 
/* 3661 */           sortedByWriteTime(limit, true);
/*      */       }
/*      */       
/*      */       public Map<K, V> youngest(int limit) {
/* 3665 */         return BoundedLocalCache.BoundedPolicy.this.cache.expiresAfterWrite() ? (
/* 3666 */           (Policy.Expiration<K, V>)BoundedLocalCache.BoundedPolicy.this.expireAfterWrite().get()).youngest(limit) : 
/* 3667 */           sortedByWriteTime(limit, false);
/*      */       }
/*      */       Map<K, V> sortedByWriteTime(int limit, boolean ascending) {
/* 3670 */         Comparator<Node<K, V>> comparator = Comparator.comparingLong(Node::getWriteTime);
/*      */         
/* 3672 */         Iterator<Node<K, V>> iterator = BoundedLocalCache.BoundedPolicy.this.cache.data.values().stream().parallel().sorted(ascending ? comparator : comparator.reversed()).limit(limit).iterator();
/* 3673 */         return BoundedLocalCache.BoundedPolicy.this.cache.fixedSnapshot(() -> iterator, limit, BoundedLocalCache.BoundedPolicy.this.transformer);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class BoundedLocalLoadingCache<K, V>
/*      */     extends BoundedLocalManualCache<K, V>
/*      */     implements LocalLoadingCache<K, V>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     final Function<K, V> mappingFunction;
/*      */     final Function<Iterable<? extends K>, Map<K, V>> bulkMappingFunction;
/*      */     
/*      */     BoundedLocalLoadingCache(Caffeine<K, V> builder, CacheLoader<? super K, V> loader) {
/* 3688 */       super(builder, loader);
/* 3689 */       Objects.requireNonNull(loader);
/* 3690 */       this.mappingFunction = LocalLoadingCache.newMappingFunction(loader);
/* 3691 */       this.bulkMappingFunction = LocalLoadingCache.newBulkMappingFunction(loader);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public CacheLoader<? super K, V> cacheLoader() {
/* 3697 */       return this.cache.cacheLoader;
/*      */     }
/*      */ 
/*      */     
/*      */     public Function<K, V> mappingFunction() {
/* 3702 */       return this.mappingFunction;
/*      */     }
/*      */ 
/*      */     
/*      */     public Function<Iterable<? extends K>, Map<K, V>> bulkMappingFunction() {
/* 3707 */       return this.bulkMappingFunction;
/*      */     }
/*      */ 
/*      */     
/*      */     private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 3712 */       throw new InvalidObjectException("Proxy required");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     Object writeReplace() {
/* 3718 */       SerializationProxy<K, V> proxy = (SerializationProxy<K, V>)super.writeReplace();
/* 3719 */       if (this.cache.refreshAfterWrite()) {
/* 3720 */         proxy.refreshAfterWriteNanos = this.cache.refreshAfterWriteNanos();
/*      */       }
/* 3722 */       proxy.loader = this.cache.cacheLoader;
/* 3723 */       return proxy;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class BoundedLocalAsyncCache<K, V>
/*      */     implements LocalAsyncCache<K, V>, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */     final BoundedLocalCache<K, CompletableFuture<V>> cache;
/*      */     
/*      */     final boolean isWeighted;
/*      */     ConcurrentMap<K, CompletableFuture<V>> mapView;
/*      */     LocalAsyncCache.CacheView<K, V> cacheView;
/*      */     Policy<K, V> policy;
/*      */     
/*      */     BoundedLocalAsyncCache(Caffeine<K, V> builder) {
/* 3741 */       this
/* 3742 */         .cache = LocalCacheFactory.newBoundedLocalCache((Caffeine)builder, null, true);
/* 3743 */       this.isWeighted = builder.isWeighted();
/*      */     }
/*      */ 
/*      */     
/*      */     public BoundedLocalCache<K, CompletableFuture<V>> cache() {
/* 3748 */       return this.cache;
/*      */     }
/*      */ 
/*      */     
/*      */     public ConcurrentMap<K, CompletableFuture<V>> asMap() {
/* 3753 */       return (this.mapView == null) ? (this.mapView = new LocalAsyncCache.AsyncAsMapView<>(this)) : this.mapView;
/*      */     }
/*      */ 
/*      */     
/*      */     public Cache<K, V> synchronous() {
/* 3758 */       return (this.cacheView == null) ? (this.cacheView = new LocalAsyncCache.CacheView<>(this)) : this.cacheView;
/*      */     }
/*      */ 
/*      */     
/*      */     public Policy<K, V> policy() {
/* 3763 */       if (this.policy == null) {
/*      */         
/* 3765 */         BoundedLocalCache<K, CompletableFuture<V>> boundedLocalCache = this.cache;
/* 3766 */         Function<CompletableFuture<V>, V> transformer = Async::getIfReady;
/*      */         
/* 3768 */         Function<CompletableFuture<V>, V> function1 = transformer;
/* 3769 */         this.policy = new BoundedLocalCache.BoundedPolicy<>((BoundedLocalCache)boundedLocalCache, (Function)function1, this.isWeighted);
/*      */       } 
/* 3771 */       return this.policy;
/*      */     }
/*      */ 
/*      */     
/*      */     private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 3776 */       throw new InvalidObjectException("Proxy required");
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/* 3780 */       SerializationProxy<K, V> proxy = BoundedLocalCache.makeSerializationProxy(this.cache, this.isWeighted);
/* 3781 */       if (this.cache.refreshAfterWrite()) {
/* 3782 */         proxy.refreshAfterWriteNanos = this.cache.refreshAfterWriteNanos();
/*      */       }
/* 3784 */       proxy.async = true;
/* 3785 */       return proxy;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class BoundedLocalAsyncLoadingCache<K, V>
/*      */     extends LocalAsyncLoadingCache<K, V>
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */     final BoundedLocalCache<K, CompletableFuture<V>> cache;
/*      */     
/*      */     final boolean isWeighted;
/*      */     ConcurrentMap<K, CompletableFuture<V>> mapView;
/*      */     Policy<K, V> policy;
/*      */     
/*      */     BoundedLocalAsyncLoadingCache(Caffeine<K, V> builder, AsyncCacheLoader<? super K, V> loader) {
/* 3803 */       super(loader);
/* 3804 */       this.isWeighted = builder.isWeighted();
/* 3805 */       this
/* 3806 */         .cache = LocalCacheFactory.newBoundedLocalCache((Caffeine)builder, new AsyncLoader<>((AsyncCacheLoader)loader, builder), true);
/*      */     }
/*      */ 
/*      */     
/*      */     public BoundedLocalCache<K, CompletableFuture<V>> cache() {
/* 3811 */       return this.cache;
/*      */     }
/*      */ 
/*      */     
/*      */     public ConcurrentMap<K, CompletableFuture<V>> asMap() {
/* 3816 */       return (this.mapView == null) ? (this.mapView = new LocalAsyncCache.AsyncAsMapView<>(this)) : this.mapView;
/*      */     }
/*      */ 
/*      */     
/*      */     public Policy<K, V> policy() {
/* 3821 */       if (this.policy == null) {
/*      */         
/* 3823 */         BoundedLocalCache<K, CompletableFuture<V>> boundedLocalCache = this.cache;
/* 3824 */         Function<CompletableFuture<V>, V> transformer = Async::getIfReady;
/*      */         
/* 3826 */         Function<CompletableFuture<V>, V> function1 = transformer;
/* 3827 */         this.policy = new BoundedLocalCache.BoundedPolicy<>((BoundedLocalCache)boundedLocalCache, (Function)function1, this.isWeighted);
/*      */       } 
/* 3829 */       return this.policy;
/*      */     }
/*      */ 
/*      */     
/*      */     private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 3834 */       throw new InvalidObjectException("Proxy required");
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/* 3838 */       SerializationProxy<K, V> proxy = BoundedLocalCache.makeSerializationProxy(this.cache, this.isWeighted);
/* 3839 */       if (this.cache.refreshAfterWrite()) {
/* 3840 */         proxy.refreshAfterWriteNanos = this.cache.refreshAfterWriteNanos();
/*      */       }
/* 3842 */       proxy.loader = this.loader;
/* 3843 */       proxy.async = true;
/* 3844 */       return proxy;
/*      */     }
/*      */     
/*      */     static final class AsyncLoader<K, V> implements CacheLoader<K, V> {
/*      */       final AsyncCacheLoader<? super K, V> loader;
/*      */       final Executor executor;
/*      */       
/*      */       AsyncLoader(AsyncCacheLoader<? super K, V> loader, Caffeine<?, ?> builder) {
/* 3852 */         this.executor = Objects.<Executor>requireNonNull(builder.getExecutor());
/* 3853 */         this.loader = Objects.<AsyncCacheLoader<? super K, V>>requireNonNull(loader);
/*      */       }
/*      */ 
/*      */       
/*      */       public V load(K key) {
/* 3858 */         return (V)this.loader.asyncLoad(key, this.executor);
/*      */       }
/*      */ 
/*      */       
/*      */       public V reload(K key, V oldValue) {
/* 3863 */         return (V)this.loader.asyncReload(key, oldValue, this.executor);
/*      */       }
/*      */       
/*      */       public CompletableFuture<V> asyncReload(K key, V oldValue, Executor executor) {
/* 3867 */         return this.loader.asyncReload(key, oldValue, executor);
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\BoundedLocalCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */