/*    */ package com.github.benmanes.caffeine.cache.stats;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum DisabledStatsCounter
/*    */   implements StatsCounter
/*    */ {
/* 24 */   INSTANCE;
/*    */ 
/*    */ 
/*    */   
/*    */   public void recordHits(int count) {}
/*    */ 
/*    */   
/*    */   public void recordMisses(int count) {}
/*    */ 
/*    */   
/*    */   public void recordLoadSuccess(long loadTime) {}
/*    */ 
/*    */   
/*    */   public void recordLoadFailure(long loadTime) {}
/*    */ 
/*    */   
/*    */   public void recordEviction() {}
/*    */ 
/*    */   
/*    */   public CacheStats snapshot() {
/* 44 */     return CacheStats.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return snapshot().toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\stats\DisabledStatsCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */