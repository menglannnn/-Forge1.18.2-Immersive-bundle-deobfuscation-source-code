/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ExecutorServiceScheduler
/*     */   implements Scheduler, Serializable
/*     */ {
/* 137 */   static final Logger logger = Logger.getLogger(ExecutorServiceScheduler.class.getName());
/*     */   
/*     */   static final long serialVersionUID = 1L;
/*     */   final ScheduledExecutorService scheduledExecutorService;
/*     */   
/*     */   ExecutorServiceScheduler(ScheduledExecutorService scheduledExecutorService) {
/* 143 */     this.scheduledExecutorService = Objects.<ScheduledExecutorService>requireNonNull(scheduledExecutorService);
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> schedule(Executor executor, Runnable command, long delay, TimeUnit unit) {
/* 148 */     Objects.requireNonNull(executor);
/* 149 */     Objects.requireNonNull(command);
/* 150 */     Objects.requireNonNull(unit);
/*     */     
/* 152 */     if (this.scheduledExecutorService.isShutdown()) {
/* 153 */       return DisabledFuture.INSTANCE;
/*     */     }
/* 155 */     return this.scheduledExecutorService.schedule(() -> {
/*     */           try {
/*     */             executor.execute(command);
/* 158 */           } catch (Throwable t) {
/*     */             logger.log(Level.WARNING, "Exception thrown when submitting scheduled task", t);
/*     */             throw t;
/*     */           } 
/*     */         }delay, unit);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\ExecutorServiceScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */