/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PSWR<K, V>
/*    */   extends PSW<K, V>
/*    */ {
/*    */   PSWR() {}
/*    */   
/*    */   PSWR(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 43 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   PSWR(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 47 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   public final boolean casWriteTime(long expect, long update) {
/* 51 */     return (this.writeTime == expect && UnsafeAccess.UNSAFE
/* 52 */       .compareAndSwapLong(this, WRITE_TIME_OFFSET, expect, update));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 62 */     return new PSWR(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 67 */     return new PSWR(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PSWR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */