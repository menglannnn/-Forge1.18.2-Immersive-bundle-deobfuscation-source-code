/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WISR<K, V>
/*    */   extends WIS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   volatile long refreshAfterWriteNanos;
/*    */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*    */   
/*    */   WISR(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 39 */     super(builder, cacheLoader, async);
/* 40 */     this.ticker = builder.getTicker();
/* 41 */     this.refreshAfterWriteNanos = builder.getRefreshAfterWriteNanos();
/* 42 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*    */   }
/*    */   
/*    */   public Ticker expirationTicker() {
/* 46 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected boolean refreshAfterWrite() {
/* 50 */     return true;
/*    */   }
/*    */   
/*    */   protected long refreshAfterWriteNanos() {
/* 54 */     return this.refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/* 58 */     this.refreshAfterWriteNanos = refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected MpscGrowableArrayQueue<Runnable> writeBuffer() {
/* 62 */     return this.writeBuffer;
/*    */   }
/*    */   
/*    */   protected boolean buffersWrites() {
/* 66 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\WISR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */