/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FDMW<K, V>
/*     */   extends FD<K, V>
/*     */ {
/*     */   int queueType;
/*     */   int weight;
/*     */   int policyWeight;
/*     */   Node<K, V> previousInAccessOrder;
/*     */   Node<K, V> nextInAccessOrder;
/*     */   
/*     */   FDMW() {}
/*     */   
/*     */   FDMW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  52 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*  53 */     this.weight = weight;
/*     */   }
/*     */   
/*     */   FDMW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  57 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*  58 */     this.weight = weight;
/*     */   }
/*     */   
/*     */   public int getQueueType() {
/*  62 */     return this.queueType;
/*     */   }
/*     */   
/*     */   public void setQueueType(int queueType) {
/*  66 */     this.queueType = queueType;
/*     */   }
/*     */   
/*     */   public int getWeight() {
/*  70 */     return this.weight;
/*     */   }
/*     */   
/*     */   public void setWeight(int weight) {
/*  74 */     this.weight = weight;
/*     */   }
/*     */   
/*     */   public int getPolicyWeight() {
/*  78 */     return this.policyWeight;
/*     */   }
/*     */   
/*     */   public void setPolicyWeight(int policyWeight) {
/*  82 */     this.policyWeight = policyWeight;
/*     */   }
/*     */   
/*     */   public Node<K, V> getPreviousInAccessOrder() {
/*  86 */     return this.previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public void setPreviousInAccessOrder(Node<K, V> previousInAccessOrder) {
/*  90 */     this.previousInAccessOrder = previousInAccessOrder;
/*     */   }
/*     */   
/*     */   public Node<K, V> getNextInAccessOrder() {
/*  94 */     return this.nextInAccessOrder;
/*     */   }
/*     */   
/*     */   public void setNextInAccessOrder(Node<K, V> nextInAccessOrder) {
/*  98 */     this.nextInAccessOrder = nextInAccessOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 108 */     return new FDMW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 113 */     return new FDMW(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FDMW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */