/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SerializationProxy<K, V>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   boolean async;
/*     */   boolean weakKeys;
/*     */   boolean weakValues;
/*     */   boolean softValues;
/*     */   boolean isRecordingStats;
/*     */   long refreshAfterWriteNanos;
/*     */   long expiresAfterWriteNanos;
/*     */   long expiresAfterAccessNanos;
/*  44 */   long maximumSize = -1L;
/*  45 */   long maximumWeight = -1L;
/*     */   
/*     */   Ticker ticker;
/*     */   
/*     */   Expiry<?, ?> expiry;
/*     */   Weigher<?, ?> weigher;
/*     */   CacheWriter<?, ?> writer;
/*     */   AsyncCacheLoader<?, ?> loader;
/*     */   RemovalListener<?, ?> removalListener;
/*     */   
/*     */   Caffeine<Object, Object> recreateCaffeine() {
/*  56 */     Caffeine<Object, Object> builder = Caffeine.newBuilder();
/*  57 */     if (this.ticker != null) {
/*  58 */       builder.ticker(this.ticker);
/*     */     }
/*  60 */     if (this.isRecordingStats) {
/*  61 */       builder.recordStats();
/*     */     }
/*  63 */     if (this.maximumSize != -1L) {
/*  64 */       builder.maximumSize(this.maximumSize);
/*     */     }
/*  66 */     if (this.weigher != null) {
/*  67 */       builder.maximumWeight(this.maximumWeight);
/*  68 */       builder.weigher(this.weigher);
/*     */     } 
/*  70 */     if (this.expiry != null) {
/*  71 */       builder.expireAfter(this.expiry);
/*     */     }
/*  73 */     if (this.expiresAfterWriteNanos > 0L) {
/*  74 */       builder.expireAfterWrite(this.expiresAfterWriteNanos, TimeUnit.NANOSECONDS);
/*     */     }
/*  76 */     if (this.expiresAfterAccessNanos > 0L) {
/*  77 */       builder.expireAfterAccess(this.expiresAfterAccessNanos, TimeUnit.NANOSECONDS);
/*     */     }
/*  79 */     if (this.refreshAfterWriteNanos > 0L) {
/*  80 */       builder.refreshAfterWrite(this.refreshAfterWriteNanos, TimeUnit.NANOSECONDS);
/*     */     }
/*  82 */     if (this.weakKeys) {
/*  83 */       builder.weakKeys();
/*     */     }
/*  85 */     if (this.weakValues) {
/*  86 */       builder.weakValues();
/*     */     }
/*  88 */     if (this.softValues) {
/*  89 */       builder.softValues();
/*     */     }
/*  91 */     if (this.removalListener != null) {
/*  92 */       builder.removalListener(this.removalListener);
/*     */     }
/*  94 */     if (this.writer != null && this.writer != CacheWriter.disabledWriter()) {
/*  95 */       builder.writer(this.writer);
/*     */     }
/*  97 */     return builder;
/*     */   }
/*     */   
/*     */   Object readResolve() {
/* 101 */     Caffeine<Object, Object> builder = recreateCaffeine();
/* 102 */     if (this.async) {
/* 103 */       if (this.loader == null) {
/* 104 */         return builder.buildAsync();
/*     */       }
/*     */       
/* 107 */       AsyncCacheLoader<?, ?> asyncCacheLoader = this.loader;
/* 108 */       return builder.buildAsync(asyncCacheLoader);
/*     */     } 
/*     */     
/* 111 */     if (this.loader == null) {
/* 112 */       return builder.build();
/*     */     }
/*     */     
/* 115 */     CacheLoader<K, V> cacheLoader = (CacheLoader)this.loader;
/* 116 */     return builder.build(cacheLoader);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SerializationProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */