/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FDR<K, V>
/*    */   extends FD<K, V>
/*    */ {
/* 34 */   protected static final long WRITE_TIME_OFFSET = UnsafeAccess.objectFieldOffset(FDR.class, "writeTime");
/*    */ 
/*    */ 
/*    */   
/*    */   volatile long writeTime;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   FDR() {}
/*    */ 
/*    */ 
/*    */   
/*    */   FDR(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 48 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/* 49 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, now);
/*    */   }
/*    */   
/*    */   FDR(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 53 */     super(keyReference, value, valueReferenceQueue, weight, now);
/* 54 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, now);
/*    */   }
/*    */   
/*    */   public final long getWriteTime() {
/* 58 */     return UnsafeAccess.UNSAFE.getLong(this, WRITE_TIME_OFFSET);
/*    */   }
/*    */   
/*    */   public final void setWriteTime(long writeTime) {
/* 62 */     UnsafeAccess.UNSAFE.putLong(this, WRITE_TIME_OFFSET, writeTime);
/*    */   }
/*    */   
/*    */   public final boolean casWriteTime(long expect, long update) {
/* 66 */     return (this.writeTime == expect && UnsafeAccess.UNSAFE
/* 67 */       .compareAndSwapLong(this, WRITE_TIME_OFFSET, expect, update));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 77 */     return new FDR(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 82 */     return new FDR(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FDR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */