package com.github.benmanes.caffeine.cache;

public interface Expiry<K, V> {
  long expireAfterCreate(K paramK, V paramV, long paramLong);
  
  long expireAfterUpdate(K paramK, V paramV, long paramLong1, long paramLong2);
  
  long expireAfterRead(K paramK, V paramV, long paramLong1, long paramLong2);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\Expiry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */