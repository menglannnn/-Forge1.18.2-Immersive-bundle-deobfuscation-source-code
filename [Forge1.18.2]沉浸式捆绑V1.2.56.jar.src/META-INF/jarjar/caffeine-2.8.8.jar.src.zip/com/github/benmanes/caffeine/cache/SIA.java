/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SIA<K, V>
/*     */   extends SI<K, V>
/*     */ {
/*     */   final Ticker ticker;
/*     */   final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque;
/*     */   final Expiry<K, V> expiry;
/*     */   final TimerWheel<K, V> timerWheel;
/*     */   volatile long expiresAfterAccessNanos;
/*     */   final MpscGrowableArrayQueue<Runnable> writeBuffer;
/*     */   final Pacer pacer;
/*     */   
/*     */   SIA(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/*  46 */     super(builder, cacheLoader, async);
/*  47 */     this.ticker = builder.getTicker();
/*  48 */     this
/*     */ 
/*     */       
/*  51 */       .accessOrderWindowDeque = (builder.evicts() || builder.expiresAfterAccess()) ? new AccessOrderDeque<>() : null;
/*  52 */     this.expiry = builder.getExpiry(this.isAsync);
/*  53 */     this.timerWheel = builder.expiresVariable() ? new TimerWheel<>(this) : null;
/*  54 */     this.expiresAfterAccessNanos = builder.getExpiresAfterAccessNanos();
/*  55 */     this.writeBuffer = new MpscGrowableArrayQueue<>(4, WRITE_BUFFER_MAX);
/*  56 */     this
/*     */ 
/*     */       
/*  59 */       .pacer = (builder.getScheduler() == Scheduler.disabledScheduler()) ? null : new Pacer(builder.getScheduler());
/*     */   }
/*     */   
/*     */   public final Ticker expirationTicker() {
/*  63 */     return this.ticker;
/*     */   }
/*     */   
/*     */   protected final AccessOrderDeque<Node<K, V>> accessOrderWindowDeque() {
/*  67 */     return this.accessOrderWindowDeque;
/*     */   }
/*     */   
/*     */   protected final boolean expiresVariable() {
/*  71 */     return (this.timerWheel != null);
/*     */   }
/*     */   
/*     */   protected final Expiry<K, V> expiry() {
/*  75 */     return this.expiry;
/*     */   }
/*     */   
/*     */   protected final TimerWheel<K, V> timerWheel() {
/*  79 */     return this.timerWheel;
/*     */   }
/*     */   
/*     */   protected final boolean expiresAfterAccess() {
/*  83 */     return (this.timerWheel == null);
/*     */   }
/*     */   
/*     */   protected final long expiresAfterAccessNanos() {
/*  87 */     return this.expiresAfterAccessNanos;
/*     */   }
/*     */   
/*     */   protected final void setExpiresAfterAccessNanos(long expiresAfterAccessNanos) {
/*  91 */     this.expiresAfterAccessNanos = expiresAfterAccessNanos;
/*     */   }
/*     */   
/*     */   protected final MpscGrowableArrayQueue<Runnable> writeBuffer() {
/*  95 */     return this.writeBuffer;
/*     */   }
/*     */   
/*     */   protected final boolean buffersWrites() {
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   public final Pacer pacer() {
/* 103 */     return this.pacer;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SIA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */