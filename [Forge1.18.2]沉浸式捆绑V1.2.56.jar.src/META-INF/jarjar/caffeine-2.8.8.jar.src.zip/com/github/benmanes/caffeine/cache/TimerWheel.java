/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TimerWheel<K, V>
/*     */ {
/*  57 */   static final int[] BUCKETS = new int[] { 64, 64, 32, 4, 1 };
/*  58 */   static final long[] SPANS = new long[] {
/*  59 */       Caffeine.ceilingPowerOfTwo(TimeUnit.SECONDS.toNanos(1L)), 
/*  60 */       Caffeine.ceilingPowerOfTwo(TimeUnit.MINUTES.toNanos(1L)), 
/*  61 */       Caffeine.ceilingPowerOfTwo(TimeUnit.HOURS.toNanos(1L)), 
/*  62 */       Caffeine.ceilingPowerOfTwo(TimeUnit.DAYS.toNanos(1L)), BUCKETS[3] * 
/*  63 */       Caffeine.ceilingPowerOfTwo(TimeUnit.DAYS.toNanos(1L)), BUCKETS[3] * 
/*  64 */       Caffeine.ceilingPowerOfTwo(TimeUnit.DAYS.toNanos(1L))
/*     */     };
/*  66 */   static final long[] SHIFT = new long[] {
/*  67 */       Long.numberOfTrailingZeros(SPANS[0]), 
/*  68 */       Long.numberOfTrailingZeros(SPANS[1]), 
/*  69 */       Long.numberOfTrailingZeros(SPANS[2]), 
/*  70 */       Long.numberOfTrailingZeros(SPANS[3]), 
/*  71 */       Long.numberOfTrailingZeros(SPANS[4])
/*     */     };
/*     */   
/*     */   final BoundedLocalCache<K, V> cache;
/*     */   
/*     */   final Node<K, V>[][] wheel;
/*     */   
/*     */   long nanos;
/*     */   
/*     */   TimerWheel(BoundedLocalCache<K, V> cache) {
/*  81 */     this.cache = Objects.<BoundedLocalCache<K, V>>requireNonNull(cache);
/*     */     
/*  83 */     this.wheel = (Node<K, V>[][])new Node[BUCKETS.length][1];
/*  84 */     for (int i = 0; i < this.wheel.length; i++) {
/*  85 */       this.wheel[i] = (Node<K, V>[])new Node[BUCKETS[i]];
/*  86 */       for (int j = 0; j < (this.wheel[i]).length; j++) {
/*  87 */         this.wheel[i][j] = new Sentinel<>();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void advance(long currentTimeNanos) {
/*  98 */     long previousTimeNanos = this.nanos;
/*     */     try {
/* 100 */       this.nanos = currentTimeNanos;
/* 101 */       for (int i = 0; i < SHIFT.length; i++) {
/* 102 */         long previousTicks = previousTimeNanos >>> (int)SHIFT[i];
/* 103 */         long currentTicks = currentTimeNanos >>> (int)SHIFT[i];
/* 104 */         if (currentTicks - previousTicks <= 0L) {
/*     */           break;
/*     */         }
/* 107 */         expire(i, previousTicks, currentTicks);
/*     */       } 
/* 109 */     } catch (Throwable t) {
/* 110 */       this.nanos = previousTimeNanos;
/* 111 */       throw t;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void expire(int index, long previousTicks, long currentTicks) {
/*     */     int start, end;
/* 123 */     Node<K, V>[] timerWheel = this.wheel[index];
/*     */ 
/*     */     
/* 126 */     if (currentTicks - previousTicks >= timerWheel.length) {
/* 127 */       end = timerWheel.length;
/* 128 */       start = 0;
/*     */     } else {
/* 130 */       long l = SPANS[index] - 1L;
/* 131 */       start = (int)(previousTicks & l);
/* 132 */       end = 1 + (int)(currentTicks & l);
/*     */     } 
/*     */     
/* 135 */     int mask = timerWheel.length - 1;
/* 136 */     for (int i = start; i < end; i++) {
/* 137 */       Node<K, V> sentinel = timerWheel[i & mask];
/* 138 */       Node<K, V> prev = sentinel.getPreviousInVariableOrder();
/* 139 */       Node<K, V> node = sentinel.getNextInVariableOrder();
/* 140 */       sentinel.setPreviousInVariableOrder(sentinel);
/* 141 */       sentinel.setNextInVariableOrder(sentinel);
/*     */       
/* 143 */       while (node != sentinel) {
/* 144 */         Node<K, V> next = node.getNextInVariableOrder();
/* 145 */         node.setPreviousInVariableOrder(null);
/* 146 */         node.setNextInVariableOrder(null);
/*     */         
/*     */         try {
/* 149 */           if (node.getVariableTime() - this.nanos > 0L || 
/* 150 */             !this.cache.evictEntry(node, RemovalCause.EXPIRED, this.nanos)) {
/* 151 */             schedule(node);
/*     */           }
/* 153 */           node = next;
/* 154 */         } catch (Throwable t) {
/* 155 */           node.setPreviousInVariableOrder(sentinel.getPreviousInVariableOrder());
/* 156 */           node.setNextInVariableOrder(next);
/* 157 */           sentinel.getPreviousInVariableOrder().setNextInVariableOrder(node);
/* 158 */           sentinel.setPreviousInVariableOrder(prev);
/* 159 */           throw t;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void schedule(Node<K, V> node) {
/* 171 */     Node<K, V> sentinel = findBucket(node.getVariableTime());
/* 172 */     link(sentinel, node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reschedule(Node<K, V> node) {
/* 181 */     if (node.getNextInVariableOrder() != null) {
/* 182 */       unlink(node);
/* 183 */       schedule(node);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deschedule(Node<K, V> node) {
/* 193 */     unlink(node);
/* 194 */     node.setNextInVariableOrder(null);
/* 195 */     node.setPreviousInVariableOrder(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Node<K, V> findBucket(long time) {
/* 205 */     long duration = time - this.nanos;
/* 206 */     int length = this.wheel.length - 1;
/* 207 */     for (int i = 0; i < length; i++) {
/* 208 */       if (duration < SPANS[i + 1]) {
/* 209 */         long ticks = time >>> (int)SHIFT[i];
/* 210 */         int index = (int)(ticks & ((this.wheel[i]).length - 1));
/* 211 */         return this.wheel[i][index];
/*     */       } 
/*     */     } 
/* 214 */     return this.wheel[length][0];
/*     */   }
/*     */ 
/*     */   
/*     */   void link(Node<K, V> sentinel, Node<K, V> node) {
/* 219 */     node.setPreviousInVariableOrder(sentinel.getPreviousInVariableOrder());
/* 220 */     node.setNextInVariableOrder(sentinel);
/*     */     
/* 222 */     sentinel.getPreviousInVariableOrder().setNextInVariableOrder(node);
/* 223 */     sentinel.setPreviousInVariableOrder(node);
/*     */   }
/*     */ 
/*     */   
/*     */   void unlink(Node<K, V> node) {
/* 228 */     Node<K, V> next = node.getNextInVariableOrder();
/* 229 */     if (next != null) {
/* 230 */       Node<K, V> prev = node.getPreviousInVariableOrder();
/* 231 */       next.setPreviousInVariableOrder(prev);
/* 232 */       prev.setNextInVariableOrder(next);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getExpirationDelay() {
/* 239 */     for (int i = 0; i < SHIFT.length; i++) {
/* 240 */       Node<K, V>[] timerWheel = this.wheel[i];
/* 241 */       long ticks = this.nanos >>> (int)SHIFT[i];
/*     */       
/* 243 */       long spanMask = SPANS[i] - 1L;
/* 244 */       int start = (int)(ticks & spanMask);
/* 245 */       int end = start + timerWheel.length;
/* 246 */       int mask = timerWheel.length - 1;
/* 247 */       for (int j = start; j < end; ) {
/* 248 */         Node<K, V> sentinel = timerWheel[j & mask];
/* 249 */         Node<K, V> next = sentinel.getNextInVariableOrder();
/* 250 */         if (next == sentinel) {
/*     */           j++; continue;
/*     */         } 
/* 253 */         long buckets = (j - start);
/* 254 */         long delay = (buckets << (int)SHIFT[i]) - (this.nanos & spanMask);
/* 255 */         delay = (delay > 0L) ? delay : SPANS[i];
/*     */         
/* 257 */         for (int k = i + 1; k < SHIFT.length; k++) {
/* 258 */           long nextDelay = peekAhead(k);
/* 259 */           delay = Math.min(delay, nextDelay);
/*     */         } 
/*     */         
/* 262 */         return delay;
/*     */       } 
/*     */     } 
/* 265 */     return Long.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long peekAhead(int i) {
/* 272 */     long ticks = this.nanos >>> (int)SHIFT[i];
/* 273 */     Node<K, V>[] timerWheel = this.wheel[i];
/*     */     
/* 275 */     long spanMask = SPANS[i] - 1L;
/* 276 */     int mask = timerWheel.length - 1;
/* 277 */     int probe = (int)(ticks + 1L & mask);
/* 278 */     Node<K, V> sentinel = timerWheel[probe];
/* 279 */     Node<K, V> next = sentinel.getNextInVariableOrder();
/* 280 */     return (next == sentinel) ? Long.MAX_VALUE : (SPANS[i] - (this.nanos & spanMask));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<K, V> snapshot(boolean ascending, int limit, Function<V, V> transformer) {
/* 294 */     Caffeine.requireArgument((limit >= 0));
/*     */     
/* 296 */     Map<K, V> map = new LinkedHashMap<>(Math.min(limit, this.cache.size()));
/* 297 */     int startLevel = ascending ? 0 : (this.wheel.length - 1);
/* 298 */     for (int i = 0; i < this.wheel.length; i++) {
/* 299 */       int indexOffset = ascending ? i : -i;
/* 300 */       int index = startLevel + indexOffset;
/*     */       
/* 302 */       int ticks = (int)(this.nanos >>> (int)SHIFT[index]);
/* 303 */       int bucketMask = (this.wheel[index]).length - 1;
/* 304 */       int startBucket = (ticks & bucketMask) + (ascending ? 1 : 0);
/* 305 */       for (int j = 0; j < (this.wheel[index]).length; j++) {
/* 306 */         int bucketOffset = ascending ? j : -j;
/* 307 */         Node<K, V> sentinel = this.wheel[index][startBucket + bucketOffset & bucketMask];
/*     */         
/* 309 */         Node<K, V> node = traverse(ascending, sentinel);
/* 310 */         for (; node != sentinel && 
/* 311 */           map.size() < limit; node = traverse(ascending, node)) {
/*     */ 
/*     */ 
/*     */           
/* 315 */           K key = node.getKey();
/* 316 */           V value = transformer.apply(node.getValue());
/* 317 */           if (key != null && value != null && node.isAlive()) {
/* 318 */             map.put(key, value);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 323 */     return Collections.unmodifiableMap(map);
/*     */   }
/*     */   
/*     */   static <K, V> Node<K, V> traverse(boolean ascending, Node<K, V> node) {
/* 327 */     return ascending ? node.getNextInVariableOrder() : node.getPreviousInVariableOrder();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 332 */     StringBuilder builder = new StringBuilder();
/* 333 */     for (int i = 0; i < this.wheel.length; i++) {
/* 334 */       Map<Integer, List<K>> buckets = new TreeMap<>();
/* 335 */       for (int j = 0; j < (this.wheel[i]).length; j++) {
/* 336 */         List<K> events = new ArrayList<>();
/* 337 */         Node<K, V> node = this.wheel[i][j].getNextInVariableOrder();
/* 338 */         for (; node != this.wheel[i][j]; node = node.getNextInVariableOrder()) {
/* 339 */           events.add(node.getKey());
/*     */         }
/* 341 */         if (!events.isEmpty()) {
/* 342 */           buckets.put(Integer.valueOf(j), events);
/*     */         }
/*     */       } 
/* 345 */       builder.append("Wheel #").append(i + 1).append(": ").append(buckets).append('\n');
/*     */     } 
/* 347 */     return builder.deleteCharAt(builder.length() - 1).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Sentinel<K, V>
/*     */     extends Node<K, V>
/*     */   {
/* 356 */     Node<K, V> prev = this.next = this;
/*     */     Node<K, V> next;
/*     */     
/*     */     public Node<K, V> getPreviousInVariableOrder() {
/* 360 */       return this.prev;
/*     */     }
/*     */     
/*     */     public void setPreviousInVariableOrder(Node<K, V> prev) {
/* 364 */       this.prev = prev;
/*     */     }
/*     */     public Node<K, V> getNextInVariableOrder() {
/* 367 */       return this.next;
/*     */     }
/*     */     
/*     */     public void setNextInVariableOrder(Node<K, V> next) {
/* 371 */       this.next = next;
/*     */     }
/*     */     
/* 374 */     public K getKey() { return null; }
/* 375 */     public Object getKeyReference() { throw new UnsupportedOperationException(); }
/* 376 */     public V getValue() { return null; } public Object getValueReference() {
/* 377 */       throw new UnsupportedOperationException();
/*     */     }
/* 379 */     public boolean containsValue(Object value) { return false; } public void setValue(V value, ReferenceQueue<V> referenceQueue) {} public boolean isAlive() {
/* 380 */       return false; }
/* 381 */     public boolean isRetired() { return false; } public boolean isDead() {
/* 382 */       return false;
/*     */     }
/*     */     
/*     */     public void retire() {}
/*     */     
/*     */     public void die() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\TimerWheel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */