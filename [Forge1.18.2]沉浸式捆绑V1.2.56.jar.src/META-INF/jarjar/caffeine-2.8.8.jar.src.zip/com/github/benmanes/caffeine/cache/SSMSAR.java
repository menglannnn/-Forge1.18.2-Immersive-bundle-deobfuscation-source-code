/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SSMSAR<K, V>
/*    */   extends SSMSA<K, V>
/*    */ {
/*    */   volatile long refreshAfterWriteNanos;
/*    */   
/*    */   SSMSAR(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 36 */     super(builder, cacheLoader, async);
/* 37 */     this.refreshAfterWriteNanos = builder.getRefreshAfterWriteNanos();
/*    */   }
/*    */   
/*    */   protected boolean refreshAfterWrite() {
/* 41 */     return true;
/*    */   }
/*    */   
/*    */   protected long refreshAfterWriteNanos() {
/* 45 */     return this.refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/* 49 */     this.refreshAfterWriteNanos = refreshAfterWriteNanos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SSMSAR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */