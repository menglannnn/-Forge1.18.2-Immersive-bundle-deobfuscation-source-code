/*     */ package com.github.benmanes.caffeine.cache;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FS<K, V>
/*     */   extends Node<K, V>
/*     */   implements NodeFactory<K, V>
/*     */ {
/*  37 */   protected static final long KEY_OFFSET = UnsafeAccess.objectFieldOffset(FS.class, "key");
/*     */ 
/*     */ 
/*     */   
/*  41 */   protected static final long VALUE_OFFSET = UnsafeAccess.objectFieldOffset(FS.class, "value");
/*     */ 
/*     */ 
/*     */   
/*     */   volatile References.WeakKeyReference<K> key;
/*     */ 
/*     */   
/*     */   volatile V value;
/*     */ 
/*     */ 
/*     */   
/*     */   FS() {}
/*     */ 
/*     */ 
/*     */   
/*     */   FS(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  57 */     this(new References.WeakKeyReference<>(key, keyReferenceQueue), value, valueReferenceQueue, weight, now);
/*     */   }
/*     */   
/*     */   FS(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  61 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, keyReference);
/*  62 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, value);
/*     */   }
/*     */   
/*     */   public final K getKey() {
/*  66 */     return ((Reference<K>)UnsafeAccess.UNSAFE.getObject(this, KEY_OFFSET)).get();
/*     */   }
/*     */   
/*     */   public final Object getKeyReference() {
/*  70 */     return UnsafeAccess.UNSAFE.getObject(this, KEY_OFFSET);
/*     */   }
/*     */   
/*     */   public final V getValue() {
/*  74 */     return (V)UnsafeAccess.UNSAFE.getObject(this, VALUE_OFFSET);
/*     */   }
/*     */   
/*     */   public final Object getValueReference() {
/*  78 */     return UnsafeAccess.UNSAFE.getObject(this, VALUE_OFFSET);
/*     */   }
/*     */   
/*     */   public final void setValue(V value, ReferenceQueue<V> referenceQueue) {
/*  82 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, value);
/*     */   }
/*     */   
/*     */   public final boolean containsValue(Object value) {
/*  86 */     return Objects.equals(value, getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/*  96 */     return new FS(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 101 */     return new FS(keyReference, value, valueReferenceQueue, weight, now);
/*     */   }
/*     */   
/*     */   public Object newLookupKey(Object key) {
/* 105 */     return new References.LookupKeyReference(key);
/*     */   }
/*     */   
/*     */   public Object newReferenceKey(K key, ReferenceQueue<K> referenceQueue) {
/* 109 */     return new References.WeakKeyReference<>(key, referenceQueue);
/*     */   }
/*     */   
/*     */   public final boolean isAlive() {
/* 113 */     Object key = getKeyReference();
/* 114 */     return (key != RETIRED_WEAK_KEY && key != DEAD_WEAK_KEY);
/*     */   }
/*     */   
/*     */   public final boolean isRetired() {
/* 118 */     return (getKeyReference() == RETIRED_WEAK_KEY);
/*     */   }
/*     */   
/*     */   public final void retire() {
/* 122 */     ((Reference)getKeyReference()).clear();
/* 123 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, RETIRED_WEAK_KEY);
/*     */   }
/*     */   
/*     */   public final boolean isDead() {
/* 127 */     return (getKeyReference() == DEAD_WEAK_KEY);
/*     */   }
/*     */   
/*     */   public final void die() {
/* 131 */     ((Reference)getKeyReference()).clear();
/* 132 */     UnsafeAccess.UNSAFE.putObject(this, VALUE_OFFSET, null);
/* 133 */     UnsafeAccess.UNSAFE.putObject(this, KEY_OFFSET, DEAD_WEAK_KEY);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */