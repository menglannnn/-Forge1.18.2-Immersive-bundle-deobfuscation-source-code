/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SISMSR<K, V>
/*    */   extends SISMS<K, V>
/*    */ {
/*    */   final Ticker ticker;
/*    */   volatile long refreshAfterWriteNanos;
/*    */   
/*    */   SISMSR(Caffeine<K, V> builder, CacheLoader<? super K, V> cacheLoader, boolean async) {
/* 38 */     super(builder, cacheLoader, async);
/* 39 */     this.ticker = builder.getTicker();
/* 40 */     this.refreshAfterWriteNanos = builder.getRefreshAfterWriteNanos();
/*    */   }
/*    */   
/*    */   public Ticker expirationTicker() {
/* 44 */     return this.ticker;
/*    */   }
/*    */   
/*    */   protected boolean refreshAfterWrite() {
/* 48 */     return true;
/*    */   }
/*    */   
/*    */   protected long refreshAfterWriteNanos() {
/* 52 */     return this.refreshAfterWriteNanos;
/*    */   }
/*    */   
/*    */   protected void setRefreshAfterWriteNanos(long refreshAfterWriteNanos) {
/* 56 */     this.refreshAfterWriteNanos = refreshAfterWriteNanos;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\SISMSR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */