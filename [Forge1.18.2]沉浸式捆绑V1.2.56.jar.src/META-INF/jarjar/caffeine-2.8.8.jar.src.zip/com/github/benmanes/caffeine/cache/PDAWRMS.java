/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PDAWRMS<K, V>
/*    */   extends PDAWR<K, V>
/*    */ {
/*    */   int queueType;
/*    */   
/*    */   PDAWRMS() {}
/*    */   
/*    */   PDAWRMS(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 47 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   PDAWRMS(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 52 */     super(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */   
/*    */   public int getQueueType() {
/* 56 */     return this.queueType;
/*    */   }
/*    */   
/*    */   public void setQueueType(int queueType) {
/* 60 */     this.queueType = queueType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 70 */     return new PDAWRMS(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 75 */     return new PDAWRMS(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\PDAWRMS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */