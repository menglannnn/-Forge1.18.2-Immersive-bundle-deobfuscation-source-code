/*    */ package com.github.benmanes.caffeine.cache;
/*    */ 
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FWAWRMW<K, V>
/*    */   extends FWAWR<K, V>
/*    */ {
/*    */   int queueType;
/*    */   int weight;
/*    */   int policyWeight;
/*    */   
/*    */   FWAWRMW() {}
/*    */   
/*    */   FWAWRMW(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 51 */     super(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/* 52 */     this.weight = weight;
/*    */   }
/*    */ 
/*    */   
/*    */   FWAWRMW(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 57 */     super(keyReference, value, valueReferenceQueue, weight, now);
/* 58 */     this.weight = weight;
/*    */   }
/*    */   
/*    */   public int getQueueType() {
/* 62 */     return this.queueType;
/*    */   }
/*    */   
/*    */   public void setQueueType(int queueType) {
/* 66 */     this.queueType = queueType;
/*    */   }
/*    */   
/*    */   public int getWeight() {
/* 70 */     return this.weight;
/*    */   }
/*    */   
/*    */   public void setWeight(int weight) {
/* 74 */     this.weight = weight;
/*    */   }
/*    */   
/*    */   public int getPolicyWeight() {
/* 78 */     return this.policyWeight;
/*    */   }
/*    */   
/*    */   public void setPolicyWeight(int policyWeight) {
/* 82 */     this.policyWeight = policyWeight;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(K key, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 92 */     return new FWAWRMW(key, keyReferenceQueue, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ 
/*    */   
/*    */   public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
/* 97 */     return new FWAWRMW(keyReference, value, valueReferenceQueue, weight, now);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\caffeine-2.8.8.jar!\com\github\benmanes\caffeine\cache\FWAWRMW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */