/*     */ package org.reactivestreams;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Flow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FlowAdapters
/*     */ {
/*     */   private FlowAdapters() {
/*  16 */     throw new IllegalStateException("No instances!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Publisher<T> toPublisher(Flow.Publisher<? extends T> flowPublisher) {
/*     */     Publisher<T> publisher;
/*  28 */     Objects.requireNonNull(flowPublisher, "flowPublisher");
/*     */     
/*  30 */     if (flowPublisher instanceof FlowPublisherFromReactive) {
/*  31 */       publisher = ((FlowPublisherFromReactive)flowPublisher).reactiveStreams;
/*  32 */     } else if (flowPublisher instanceof Publisher) {
/*  33 */       publisher = (Publisher)flowPublisher;
/*     */     } else {
/*  35 */       publisher = new ReactivePublisherFromFlow<T>(flowPublisher);
/*     */     } 
/*  37 */     return publisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Flow.Publisher<T> toFlowPublisher(Publisher<? extends T> reactiveStreamsPublisher) {
/*     */     Flow.Publisher<T> flowPublisher;
/*  50 */     Objects.requireNonNull(reactiveStreamsPublisher, "reactiveStreamsPublisher");
/*     */     
/*  52 */     if (reactiveStreamsPublisher instanceof ReactivePublisherFromFlow) {
/*  53 */       flowPublisher = ((ReactivePublisherFromFlow)reactiveStreamsPublisher).flow;
/*  54 */     } else if (reactiveStreamsPublisher instanceof Flow.Publisher) {
/*  55 */       flowPublisher = (Flow.Publisher)reactiveStreamsPublisher;
/*     */     } else {
/*  57 */       flowPublisher = new FlowPublisherFromReactive<T>(reactiveStreamsPublisher);
/*     */     } 
/*  59 */     return flowPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, U> Processor<T, U> toProcessor(Flow.Processor<? super T, ? extends U> flowProcessor) {
/*     */     Processor<T, U> processor;
/*  73 */     Objects.requireNonNull(flowProcessor, "flowProcessor");
/*     */     
/*  75 */     if (flowProcessor instanceof FlowToReactiveProcessor) {
/*  76 */       processor = ((FlowToReactiveProcessor)flowProcessor).reactiveStreams;
/*  77 */     } else if (flowProcessor instanceof Processor) {
/*  78 */       processor = (Processor)flowProcessor;
/*     */     } else {
/*  80 */       processor = new ReactiveToFlowProcessor<T, U>(flowProcessor);
/*     */     } 
/*  82 */     return processor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, U> Flow.Processor<T, U> toFlowProcessor(Processor<? super T, ? extends U> reactiveStreamsProcessor) {
/*     */     Flow.Processor<T, U> flowProcessor;
/*  96 */     Objects.requireNonNull(reactiveStreamsProcessor, "reactiveStreamsProcessor");
/*     */     
/*  98 */     if (reactiveStreamsProcessor instanceof ReactiveToFlowProcessor) {
/*  99 */       flowProcessor = ((ReactiveToFlowProcessor)reactiveStreamsProcessor).flow;
/* 100 */     } else if (reactiveStreamsProcessor instanceof Flow.Processor) {
/* 101 */       flowProcessor = (Flow.Processor)reactiveStreamsProcessor;
/*     */     } else {
/* 103 */       flowProcessor = new FlowToReactiveProcessor<T, U>(reactiveStreamsProcessor);
/*     */     } 
/* 105 */     return flowProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Flow.Subscriber<T> toFlowSubscriber(Subscriber<T> reactiveStreamsSubscriber) {
/*     */     Flow.Subscriber<T> flowSubscriber;
/* 116 */     Objects.requireNonNull(reactiveStreamsSubscriber, "reactiveStreamsSubscriber");
/*     */     
/* 118 */     if (reactiveStreamsSubscriber instanceof ReactiveToFlowSubscriber) {
/* 119 */       flowSubscriber = ((ReactiveToFlowSubscriber)reactiveStreamsSubscriber).flow;
/* 120 */     } else if (reactiveStreamsSubscriber instanceof Flow.Subscriber) {
/* 121 */       flowSubscriber = (Flow.Subscriber<T>)reactiveStreamsSubscriber;
/*     */     } else {
/* 123 */       flowSubscriber = new FlowToReactiveSubscriber<T>(reactiveStreamsSubscriber);
/*     */     } 
/* 125 */     return flowSubscriber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Subscriber<T> toSubscriber(Flow.Subscriber<T> flowSubscriber) {
/*     */     Subscriber<T> subscriber;
/* 136 */     Objects.requireNonNull(flowSubscriber, "flowSubscriber");
/*     */     
/* 138 */     if (flowSubscriber instanceof FlowToReactiveSubscriber) {
/* 139 */       subscriber = ((FlowToReactiveSubscriber)flowSubscriber).reactiveStreams;
/* 140 */     } else if (flowSubscriber instanceof Subscriber) {
/* 141 */       subscriber = (Subscriber<T>)flowSubscriber;
/*     */     } else {
/* 143 */       subscriber = new ReactiveToFlowSubscriber<T>(flowSubscriber);
/*     */     } 
/* 145 */     return subscriber;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FlowToReactiveSubscription
/*     */     implements Flow.Subscription
/*     */   {
/*     */     final Subscription reactiveStreams;
/*     */     
/*     */     public FlowToReactiveSubscription(Subscription reactive) {
/* 155 */       this.reactiveStreams = reactive;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 160 */       this.reactiveStreams.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 165 */       this.reactiveStreams.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ReactiveToFlowSubscription
/*     */     implements Subscription
/*     */   {
/*     */     final Flow.Subscription flow;
/*     */ 
/*     */     
/*     */     public ReactiveToFlowSubscription(Flow.Subscription flow) {
/* 177 */       this.flow = flow;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 182 */       this.flow.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 187 */       this.flow.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class FlowToReactiveSubscriber<T>
/*     */     implements Flow.Subscriber<T>
/*     */   {
/*     */     final Subscriber<? super T> reactiveStreams;
/*     */ 
/*     */ 
/*     */     
/*     */     public FlowToReactiveSubscriber(Subscriber<? super T> reactive) {
/* 201 */       this.reactiveStreams = reactive;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Flow.Subscription subscription) {
/* 206 */       this.reactiveStreams.onSubscribe((subscription == null) ? null : new FlowAdapters.ReactiveToFlowSubscription(subscription));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T item) {
/* 211 */       this.reactiveStreams.onNext(item);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 216 */       this.reactiveStreams.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 221 */       this.reactiveStreams.onComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ReactiveToFlowSubscriber<T>
/*     */     implements Subscriber<T>
/*     */   {
/*     */     final Flow.Subscriber<? super T> flow;
/*     */ 
/*     */     
/*     */     public ReactiveToFlowSubscriber(Flow.Subscriber<? super T> flow) {
/* 234 */       this.flow = flow;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription subscription) {
/* 239 */       this.flow.onSubscribe((subscription == null) ? null : new FlowAdapters.FlowToReactiveSubscription(subscription));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T item) {
/* 244 */       this.flow.onNext(item);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 249 */       this.flow.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 254 */       this.flow.onComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ReactiveToFlowProcessor<T, U>
/*     */     implements Processor<T, U>
/*     */   {
/*     */     final Flow.Processor<? super T, ? extends U> flow;
/*     */ 
/*     */ 
/*     */     
/*     */     public ReactiveToFlowProcessor(Flow.Processor<? super T, ? extends U> flow) {
/* 268 */       this.flow = flow;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription subscription) {
/* 273 */       this.flow.onSubscribe((subscription == null) ? null : new FlowAdapters.FlowToReactiveSubscription(subscription));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 278 */       this.flow.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 283 */       this.flow.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 288 */       this.flow.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(Subscriber<? super U> s) {
/* 293 */       this.flow.subscribe((s == null) ? null : new FlowAdapters.FlowToReactiveSubscriber<U>(s));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class FlowToReactiveProcessor<T, U>
/*     */     implements Flow.Processor<T, U>
/*     */   {
/*     */     final Processor<? super T, ? extends U> reactiveStreams;
/*     */ 
/*     */     
/*     */     public FlowToReactiveProcessor(Processor<? super T, ? extends U> reactive) {
/* 306 */       this.reactiveStreams = reactive;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Flow.Subscription subscription) {
/* 311 */       this.reactiveStreams.onSubscribe((subscription == null) ? null : new FlowAdapters.ReactiveToFlowSubscription(subscription));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 316 */       this.reactiveStreams.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 321 */       this.reactiveStreams.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 326 */       this.reactiveStreams.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(Flow.Subscriber<? super U> s) {
/* 331 */       this.reactiveStreams.subscribe((s == null) ? null : new FlowAdapters.ReactiveToFlowSubscriber<U>(s));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ReactivePublisherFromFlow<T>
/*     */     implements Publisher<T>
/*     */   {
/*     */     final Flow.Publisher<? extends T> flow;
/*     */ 
/*     */     
/*     */     public ReactivePublisherFromFlow(Flow.Publisher<? extends T> flowPublisher) {
/* 343 */       this.flow = flowPublisher;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(Subscriber<? super T> reactive) {
/* 348 */       this.flow.subscribe((reactive == null) ? null : new FlowAdapters.FlowToReactiveSubscriber<T>(reactive));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class FlowPublisherFromReactive<T>
/*     */     implements Flow.Publisher<T>
/*     */   {
/*     */     final Publisher<? extends T> reactiveStreams;
/*     */ 
/*     */     
/*     */     public FlowPublisherFromReactive(Publisher<? extends T> reactivePublisher) {
/* 361 */       this.reactiveStreams = reactivePublisher;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(Flow.Subscriber<? super T> flow) {
/* 366 */       this.reactiveStreams.subscribe((flow == null) ? null : new FlowAdapters.ReactiveToFlowSubscriber<T>(flow));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactive-streams-1.0.4.jar!\org\reactivestreams\FlowAdapters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */