package org.reactivestreams;

public interface Publisher<T> {
  void subscribe(Subscriber<? super T> paramSubscriber);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactive-streams-1.0.4.jar!\org\reactivestreams\Publisher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */