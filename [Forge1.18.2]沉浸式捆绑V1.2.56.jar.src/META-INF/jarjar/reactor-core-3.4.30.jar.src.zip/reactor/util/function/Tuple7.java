/*     */ package reactor.util.function;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple7<T1, T2, T3, T4, T5, T6, T7>
/*     */   extends Tuple6<T1, T2, T3, T4, T5, T6>
/*     */ {
/*     */   private static final long serialVersionUID = -8002391247456579281L;
/*     */   @NonNull
/*     */   final T7 t7;
/*     */   
/*     */   Tuple7(T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7) {
/*  45 */     super(t1, t2, t3, t4, t5, t6);
/*  46 */     this.t7 = Objects.requireNonNull(t7, "t7");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T7 getT7() {
/*  55 */     return this.t7;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple7<R, T2, T3, T4, T5, T6, T7> mapT1(Function<T1, R> mapper) {
/*  67 */     return new Tuple7((T1)mapper.apply(this.t1), this.t2, this.t3, this.t4, this.t5, this.t6, this.t7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple7<T1, R, T3, T4, T5, T6, T7> mapT2(Function<T2, R> mapper) {
/*  79 */     return new Tuple7(this.t1, (T2)mapper.apply(this.t2), this.t3, this.t4, this.t5, this.t6, this.t7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple7<T1, T2, R, T4, T5, T6, T7> mapT3(Function<T3, R> mapper) {
/*  91 */     return new Tuple7(this.t1, this.t2, (T3)mapper.apply(this.t3), this.t4, this.t5, this.t6, this.t7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple7<T1, T2, T3, R, T5, T6, T7> mapT4(Function<T4, R> mapper) {
/* 103 */     return new Tuple7(this.t1, this.t2, this.t3, (T4)mapper.apply(this.t4), this.t5, this.t6, this.t7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple7<T1, T2, T3, T4, R, T6, T7> mapT5(Function<T5, R> mapper) {
/* 115 */     return new Tuple7(this.t1, this.t2, this.t3, this.t4, (T5)mapper.apply(this.t5), this.t6, this.t7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple7<T1, T2, T3, T4, T5, R, T7> mapT6(Function<T6, R> mapper) {
/* 127 */     return new Tuple7(this.t1, this.t2, this.t3, this.t4, this.t5, (T6)mapper.apply(this.t6), this.t7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple7<T1, T2, T3, T4, T5, T6, R> mapT7(Function<T7, R> mapper) {
/* 139 */     return new Tuple7(this.t1, this.t2, this.t3, this.t4, this.t5, this.t6, (T7)mapper.apply(this.t7));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(int index) {
/* 145 */     switch (index) {
/*     */       case 0:
/* 147 */         return this.t1;
/*     */       case 1:
/* 149 */         return this.t2;
/*     */       case 2:
/* 151 */         return this.t3;
/*     */       case 3:
/* 153 */         return this.t4;
/*     */       case 4:
/* 155 */         return this.t5;
/*     */       case 5:
/* 157 */         return this.t6;
/*     */       case 6:
/* 159 */         return this.t7;
/*     */     } 
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 167 */     return new Object[] { this.t1, this.t2, this.t3, this.t4, this.t5, this.t6, this.t7 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 172 */     if (this == o) return true; 
/* 173 */     if (!(o instanceof Tuple7)) return false; 
/* 174 */     if (!super.equals(o)) return false;
/*     */ 
/*     */     
/* 177 */     Tuple7 tuple7 = (Tuple7)o;
/*     */     
/* 179 */     return this.t7.equals(tuple7.t7);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 185 */     int result = super.hashCode();
/* 186 */     result = 31 * result + this.t7.hashCode();
/* 187 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 192 */     return 7;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\function\Tuple7.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */