/*     */ package reactor.util.function;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple6<T1, T2, T3, T4, T5, T6>
/*     */   extends Tuple5<T1, T2, T3, T4, T5>
/*     */ {
/*     */   private static final long serialVersionUID = 770306356087176830L;
/*     */   @NonNull
/*     */   final T6 t6;
/*     */   
/*     */   Tuple6(T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6) {
/*  44 */     super(t1, t2, t3, t4, t5);
/*  45 */     this.t6 = Objects.requireNonNull(t6, "t6");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T6 getT6() {
/*  54 */     return this.t6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple6<R, T2, T3, T4, T5, T6> mapT1(Function<T1, R> mapper) {
/*  66 */     return new Tuple6((T1)mapper.apply(this.t1), this.t2, this.t3, this.t4, this.t5, this.t6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple6<T1, R, T3, T4, T5, T6> mapT2(Function<T2, R> mapper) {
/*  78 */     return new Tuple6(this.t1, (T2)mapper.apply(this.t2), this.t3, this.t4, this.t5, this.t6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple6<T1, T2, R, T4, T5, T6> mapT3(Function<T3, R> mapper) {
/*  90 */     return new Tuple6(this.t1, this.t2, (T3)mapper.apply(this.t3), this.t4, this.t5, this.t6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple6<T1, T2, T3, R, T5, T6> mapT4(Function<T4, R> mapper) {
/* 102 */     return new Tuple6(this.t1, this.t2, this.t3, (T4)mapper.apply(this.t4), this.t5, this.t6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple6<T1, T2, T3, T4, R, T6> mapT5(Function<T5, R> mapper) {
/* 114 */     return new Tuple6(this.t1, this.t2, this.t3, this.t4, (T5)mapper.apply(this.t5), this.t6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple6<T1, T2, T3, T4, T5, R> mapT6(Function<T6, R> mapper) {
/* 126 */     return new Tuple6(this.t1, this.t2, this.t3, this.t4, this.t5, (T6)mapper.apply(this.t6));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(int index) {
/* 132 */     switch (index) {
/*     */       case 0:
/* 134 */         return this.t1;
/*     */       case 1:
/* 136 */         return this.t2;
/*     */       case 2:
/* 138 */         return this.t3;
/*     */       case 3:
/* 140 */         return this.t4;
/*     */       case 4:
/* 142 */         return this.t5;
/*     */       case 5:
/* 144 */         return this.t6;
/*     */     } 
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 152 */     return new Object[] { this.t1, this.t2, this.t3, this.t4, this.t5, this.t6 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 157 */     if (this == o) return true; 
/* 158 */     if (!(o instanceof Tuple6)) return false; 
/* 159 */     if (!super.equals(o)) return false;
/*     */ 
/*     */     
/* 162 */     Tuple6 tuple6 = (Tuple6)o;
/*     */     
/* 164 */     return this.t6.equals(tuple6.t6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 170 */     int result = super.hashCode();
/* 171 */     result = 31 * result + this.t6.hashCode();
/* 172 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 177 */     return 6;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\function\Tuple6.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */