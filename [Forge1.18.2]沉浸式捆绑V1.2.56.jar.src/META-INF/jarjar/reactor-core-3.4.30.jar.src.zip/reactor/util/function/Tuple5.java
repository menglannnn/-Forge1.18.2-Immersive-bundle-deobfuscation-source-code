/*     */ package reactor.util.function;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import reactor.util.annotation.NonNull;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple5<T1, T2, T3, T4, T5>
/*     */   extends Tuple4<T1, T2, T3, T4>
/*     */ {
/*     */   private static final long serialVersionUID = 3541548454198133275L;
/*     */   @NonNull
/*     */   final T5 t5;
/*     */   
/*     */   Tuple5(T1 t1, T2 t2, T3 t3, T4 t4, T5 t5) {
/*  43 */     super(t1, t2, t3, t4);
/*  44 */     this.t5 = Objects.requireNonNull(t5, "t5");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T5 getT5() {
/*  53 */     return this.t5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple5<R, T2, T3, T4, T5> mapT1(Function<T1, R> mapper) {
/*  65 */     return new Tuple5((T1)mapper.apply(this.t1), this.t2, this.t3, this.t4, this.t5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple5<T1, R, T3, T4, T5> mapT2(Function<T2, R> mapper) {
/*  77 */     return new Tuple5(this.t1, (T2)mapper.apply(this.t2), this.t3, this.t4, this.t5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple5<T1, T2, R, T4, T5> mapT3(Function<T3, R> mapper) {
/*  89 */     return new Tuple5(this.t1, this.t2, (T3)mapper.apply(this.t3), this.t4, this.t5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple5<T1, T2, T3, R, T5> mapT4(Function<T4, R> mapper) {
/* 101 */     return new Tuple5(this.t1, this.t2, this.t3, (T4)mapper.apply(this.t4), this.t5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Tuple5<T1, T2, T3, T4, R> mapT5(Function<T5, R> mapper) {
/* 113 */     return new Tuple5(this.t1, this.t2, this.t3, this.t4, (T5)mapper.apply(this.t5));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(int index) {
/* 119 */     switch (index) {
/*     */       case 0:
/* 121 */         return this.t1;
/*     */       case 1:
/* 123 */         return this.t2;
/*     */       case 2:
/* 125 */         return this.t3;
/*     */       case 3:
/* 127 */         return this.t4;
/*     */       case 4:
/* 129 */         return this.t5;
/*     */     } 
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 137 */     return new Object[] { this.t1, this.t2, this.t3, this.t4, this.t5 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 142 */     if (this == o) return true; 
/* 143 */     if (!(o instanceof Tuple5)) return false; 
/* 144 */     if (!super.equals(o)) return false;
/*     */ 
/*     */     
/* 147 */     Tuple5 tuple5 = (Tuple5)o;
/*     */     
/* 149 */     return this.t5.equals(tuple5.t5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 155 */     int result = super.hashCode();
/* 156 */     result = 31 * result + this.t5.hashCode();
/* 157 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 162 */     return 5;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\function\Tuple5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */