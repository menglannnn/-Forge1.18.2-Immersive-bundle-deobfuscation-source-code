/*    */ package reactor.util.retry;
/*    */ 
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ImmutableRetrySignal
/*    */   implements Retry.RetrySignal
/*    */ {
/*    */   final long failureTotalIndex;
/*    */   final long failureSubsequentIndex;
/*    */   final Throwable failure;
/*    */   final ContextView retryContext;
/*    */   
/*    */   ImmutableRetrySignal(long failureTotalIndex, long failureSubsequentIndex, Throwable failure) {
/* 37 */     this(failureTotalIndex, failureSubsequentIndex, failure, (ContextView)Context.empty());
/*    */   }
/*    */ 
/*    */   
/*    */   ImmutableRetrySignal(long failureTotalIndex, long failureSubsequentIndex, Throwable failure, ContextView retryContext) {
/* 42 */     this.failureTotalIndex = failureTotalIndex;
/* 43 */     this.failureSubsequentIndex = failureSubsequentIndex;
/* 44 */     this.failure = failure;
/* 45 */     this.retryContext = retryContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public long totalRetries() {
/* 50 */     return this.failureTotalIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public long totalRetriesInARow() {
/* 55 */     return this.failureSubsequentIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable failure() {
/* 60 */     return this.failure;
/*    */   }
/*    */ 
/*    */   
/*    */   public ContextView retryContextView() {
/* 65 */     return this.retryContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public Retry.RetrySignal copy() {
/* 70 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     return "attempt #" + (this.failureTotalIndex + 1L) + " (" + (this.failureSubsequentIndex + 1L) + " in a row), last failure={" + this.failure + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\retry\ImmutableRetrySignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */