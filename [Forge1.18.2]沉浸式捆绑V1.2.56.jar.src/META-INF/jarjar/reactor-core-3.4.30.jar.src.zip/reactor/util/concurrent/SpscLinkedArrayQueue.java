/*     */ package reactor.util.concurrent;
/*     */ 
/*     */ import java.util.AbstractQueue;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*     */ import java.util.function.BiPredicate;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SpscLinkedArrayQueue<T>
/*     */   extends AbstractQueue<T>
/*     */   implements BiPredicate<T, T>
/*     */ {
/*     */   final int mask;
/*     */   volatile long producerIndex;
/*  51 */   static final AtomicLongFieldUpdater<SpscLinkedArrayQueue> PRODUCER_INDEX = AtomicLongFieldUpdater.newUpdater(SpscLinkedArrayQueue.class, "producerIndex");
/*     */ 
/*     */   
/*     */   AtomicReferenceArray<Object> producerArray;
/*     */   
/*     */   volatile long consumerIndex;
/*     */   
/*  58 */   static final AtomicLongFieldUpdater<SpscLinkedArrayQueue> CONSUMER_INDEX = AtomicLongFieldUpdater.newUpdater(SpscLinkedArrayQueue.class, "consumerIndex");
/*     */   
/*     */   AtomicReferenceArray<Object> consumerArray;
/*     */   
/*  62 */   static final Object NEXT = new Object();
/*     */   
/*     */   SpscLinkedArrayQueue(int linkSize) {
/*  65 */     int c = Queues.ceilingNextPowerOfTwo(Math.max(8, linkSize));
/*  66 */     this.producerArray = this.consumerArray = new AtomicReferenceArray(c + 1);
/*  67 */     this.mask = c - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean offer(T e) {
/*  72 */     Objects.requireNonNull(e);
/*     */     
/*  74 */     long pi = this.producerIndex;
/*  75 */     AtomicReferenceArray<Object> a = this.producerArray;
/*  76 */     int m = this.mask;
/*     */     
/*  78 */     int offset = (int)(pi + 1L) & m;
/*     */     
/*  80 */     if (a.get(offset) != null) {
/*  81 */       offset = (int)pi & m;
/*     */       
/*  83 */       AtomicReferenceArray<Object> b = new AtomicReferenceArray(m + 2);
/*  84 */       this.producerArray = b;
/*  85 */       b.lazySet(offset, e);
/*  86 */       a.lazySet(m + 1, b);
/*  87 */       a.lazySet(offset, NEXT);
/*  88 */       PRODUCER_INDEX.lazySet(this, pi + 1L);
/*     */     } else {
/*     */       
/*  91 */       offset = (int)pi & m;
/*  92 */       a.lazySet(offset, e);
/*  93 */       PRODUCER_INDEX.lazySet(this, pi + 1L);
/*     */     } 
/*     */     
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean test(T first, T second) {
/* 110 */     AtomicReferenceArray<Object> buffer = this.producerArray;
/* 111 */     long p = this.producerIndex;
/* 112 */     int m = this.mask;
/*     */     
/* 114 */     int pi = (int)(p + 2L) & m;
/*     */     
/* 116 */     if (null != buffer.get(pi)) {
/* 117 */       AtomicReferenceArray<Object> newBuffer = new AtomicReferenceArray(m + 2);
/*     */       
/* 119 */       this.producerArray = newBuffer;
/*     */       
/* 121 */       pi = (int)p & m;
/* 122 */       newBuffer.lazySet(pi + 1, second);
/* 123 */       newBuffer.lazySet(pi, first);
/* 124 */       buffer.lazySet(buffer.length() - 1, newBuffer);
/*     */       
/* 126 */       buffer.lazySet(pi, NEXT);
/*     */       
/* 128 */       PRODUCER_INDEX.lazySet(this, p + 2L);
/*     */     }
/*     */     else {
/*     */       
/* 132 */       pi = (int)p & m;
/* 133 */       buffer.lazySet(pi + 1, second);
/* 134 */       buffer.lazySet(pi, first);
/* 135 */       PRODUCER_INDEX.lazySet(this, p + 2L);
/*     */     } 
/*     */     
/* 138 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T poll() {
/* 145 */     long ci = this.consumerIndex;
/* 146 */     AtomicReferenceArray<Object> a = this.consumerArray;
/* 147 */     int m = this.mask;
/*     */     
/* 149 */     int offset = (int)ci & m;
/*     */     
/* 151 */     Object o = a.get(offset);
/*     */     
/* 153 */     if (o == null) {
/* 154 */       return null;
/*     */     }
/* 156 */     if (o == NEXT) {
/* 157 */       AtomicReferenceArray<Object> b = (AtomicReferenceArray<Object>)a.get(m + 1);
/* 158 */       a.lazySet(m + 1, null);
/* 159 */       o = b.get(offset);
/* 160 */       a = b;
/* 161 */       this.consumerArray = b;
/*     */     } 
/* 163 */     a.lazySet(offset, null);
/* 164 */     CONSUMER_INDEX.lazySet(this, ci + 1L);
/*     */     
/* 166 */     return (T)o;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T peek() {
/* 173 */     long ci = this.consumerIndex;
/* 174 */     AtomicReferenceArray<Object> a = this.consumerArray;
/* 175 */     int m = this.mask;
/*     */     
/* 177 */     int offset = (int)ci & m;
/*     */     
/* 179 */     Object o = a.get(offset);
/*     */     
/* 181 */     if (o == null) {
/* 182 */       return null;
/*     */     }
/* 184 */     if (o == NEXT) {
/* 185 */       a = (AtomicReferenceArray<Object>)a.get(m + 1);
/* 186 */       o = a.get(offset);
/*     */     } 
/*     */     
/* 189 */     return (T)o;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 194 */     return (this.producerIndex == this.consumerIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 199 */     long ci = this.consumerIndex;
/*     */     while (true) {
/* 201 */       long pi = this.producerIndex;
/* 202 */       long ci2 = this.consumerIndex;
/* 203 */       if (ci == ci2) {
/* 204 */         return (int)(pi - ci);
/*     */       }
/* 206 */       ci = ci2;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 212 */     while (poll() != null && !isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 218 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\concurrent\SpscLinkedArrayQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */