/*     */ package reactor.util.concurrent;
/*     */ 
/*     */ import java.util.AbstractQueue;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiPredicate;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MpscLinkedQueue<E>
/*     */   extends AbstractQueue<E>
/*     */   implements BiPredicate<E, E>
/*     */ {
/*     */   private volatile LinkedQueueNode<E> producerNode;
/*  39 */   private static final AtomicReferenceFieldUpdater<MpscLinkedQueue, LinkedQueueNode> PRODUCER_NODE_UPDATER = AtomicReferenceFieldUpdater.newUpdater(MpscLinkedQueue.class, LinkedQueueNode.class, "producerNode");
/*     */   
/*     */   private volatile LinkedQueueNode<E> consumerNode;
/*     */   
/*  43 */   private static final AtomicReferenceFieldUpdater<MpscLinkedQueue, LinkedQueueNode> CONSUMER_NODE_UPDATER = AtomicReferenceFieldUpdater.newUpdater(MpscLinkedQueue.class, LinkedQueueNode.class, "consumerNode");
/*     */   
/*     */   public MpscLinkedQueue() {
/*  46 */     LinkedQueueNode<E> node = new LinkedQueueNode<>();
/*  47 */     CONSUMER_NODE_UPDATER.lazySet(this, node);
/*  48 */     PRODUCER_NODE_UPDATER.getAndSet(this, node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean offer(E e) {
/*  71 */     Objects.requireNonNull(e, "The offered value 'e' must be non-null");
/*     */     
/*  73 */     LinkedQueueNode<E> nextNode = new LinkedQueueNode<>(e);
/*  74 */     LinkedQueueNode<E> prevProducerNode = PRODUCER_NODE_UPDATER.getAndSet(this, nextNode);
/*     */ 
/*     */     
/*  77 */     prevProducerNode.soNext(nextNode);
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean test(E e1, E e2) {
/* 105 */     Objects.requireNonNull(e1, "The offered value 'e1' must be non-null");
/* 106 */     Objects.requireNonNull(e2, "The offered value 'e2' must be non-null");
/*     */     
/* 108 */     LinkedQueueNode<E> nextNode = new LinkedQueueNode<>(e1);
/* 109 */     LinkedQueueNode<E> nextNextNode = new LinkedQueueNode<>(e2);
/*     */     
/* 111 */     LinkedQueueNode<E> prevProducerNode = PRODUCER_NODE_UPDATER.getAndSet(this, nextNextNode);
/*     */ 
/*     */     
/* 114 */     nextNode.soNext(nextNextNode);
/* 115 */     prevProducerNode.soNext(nextNode);
/*     */     
/* 117 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public E poll() {
/* 139 */     LinkedQueueNode<E> currConsumerNode = this.consumerNode;
/* 140 */     LinkedQueueNode<E> nextNode = currConsumerNode.lvNext();
/*     */     
/* 142 */     if (nextNode != null) {
/*     */ 
/*     */       
/* 145 */       E nextValue = nextNode.getAndNullValue();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 150 */       currConsumerNode.soNext(currConsumerNode);
/* 151 */       CONSUMER_NODE_UPDATER.lazySet(this, nextNode);
/*     */       
/* 153 */       return nextValue;
/*     */     } 
/* 155 */     if (currConsumerNode != this.producerNode) {
/*     */       
/* 157 */       while ((nextNode = currConsumerNode.lvNext()) == null);
/*     */ 
/*     */       
/* 160 */       E nextValue = nextNode.getAndNullValue();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       currConsumerNode.soNext(currConsumerNode);
/* 166 */       CONSUMER_NODE_UPDATER.lazySet(this, nextNode);
/*     */       
/* 168 */       return nextValue;
/*     */     } 
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public E peek() {
/* 176 */     LinkedQueueNode<E> currConsumerNode = this.consumerNode;
/* 177 */     LinkedQueueNode<E> nextNode = currConsumerNode.lvNext();
/*     */     
/* 179 */     if (nextNode != null)
/*     */     {
/* 181 */       return nextNode.lpValue();
/*     */     }
/* 183 */     if (currConsumerNode != this.producerNode) {
/*     */       
/* 185 */       while ((nextNode = currConsumerNode.lvNext()) == null);
/*     */       
/* 187 */       return nextNode.lpValue();
/*     */     } 
/*     */     
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 195 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 201 */     while (poll() != null && !isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 208 */     LinkedQueueNode<E> chaserNode = this.consumerNode;
/* 209 */     LinkedQueueNode<E> producerNode = this.producerNode;
/* 210 */     int size = 0;
/*     */     
/* 212 */     while (chaserNode != producerNode && chaserNode != null && size < Integer.MAX_VALUE) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 217 */       LinkedQueueNode<E> next = chaserNode.lvNext();
/*     */       
/* 219 */       if (next == chaserNode)
/*     */       {
/* 221 */         return size;
/*     */       }
/* 223 */       chaserNode = next;
/* 224 */       size++;
/*     */     } 
/* 226 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 231 */     return (this.consumerNode == this.producerNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 236 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   static final class LinkedQueueNode<E>
/*     */   {
/*     */     private volatile LinkedQueueNode<E> next;
/* 243 */     private static final AtomicReferenceFieldUpdater<LinkedQueueNode, LinkedQueueNode> NEXT_UPDATER = AtomicReferenceFieldUpdater.newUpdater(LinkedQueueNode.class, LinkedQueueNode.class, "next");
/*     */     
/*     */     private E value;
/*     */ 
/*     */     
/*     */     LinkedQueueNode() {
/* 249 */       this(null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     LinkedQueueNode(@Nullable E val) {
/* 255 */       spValue(val);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public E getAndNullValue() {
/* 266 */       E temp = lpValue();
/* 267 */       spValue(null);
/* 268 */       return temp;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public E lpValue() {
/* 274 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void spValue(@Nullable E newValue) {
/* 279 */       this.value = newValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public void soNext(@Nullable LinkedQueueNode<E> n) {
/* 284 */       NEXT_UPDATER.lazySet(this, n);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public LinkedQueueNode<E> lvNext() {
/* 290 */       return this.next;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\concurrent\MpscLinkedQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */