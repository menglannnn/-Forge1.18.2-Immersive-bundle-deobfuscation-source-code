/*    */ package reactor.util.context;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.NoSuchElementException;
/*    */ import java.util.Objects;
/*    */ import java.util.function.BiConsumer;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Context0
/*    */   implements CoreContext
/*    */ {
/* 27 */   static final Context0 INSTANCE = new Context0();
/*    */ 
/*    */   
/*    */   public Context put(Object key, Object value) {
/* 31 */     Objects.requireNonNull(key, "key");
/* 32 */     Objects.requireNonNull(value, "value");
/* 33 */     return new Context1(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Context delete(Object key) {
/* 38 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> T get(Object key) {
/* 43 */     throw new NoSuchElementException("Context is empty");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasKey(Object key) {
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 53 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 58 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return "Context0{}";
/*    */   }
/*    */ 
/*    */   
/*    */   public Stream<Map.Entry<Object, Object>> stream() {
/* 68 */     return Stream.empty();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void forEach(BiConsumer<Object, Object> action) {}
/*    */ 
/*    */   
/*    */   public Context putAllInto(Context base) {
/* 77 */     return base;
/*    */   }
/*    */   
/*    */   public void unsafePutAllInto(ContextN other) {}
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\context\Context0.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */