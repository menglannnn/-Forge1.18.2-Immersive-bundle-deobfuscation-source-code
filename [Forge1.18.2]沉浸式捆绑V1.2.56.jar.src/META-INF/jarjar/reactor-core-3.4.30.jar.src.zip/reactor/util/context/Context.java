/*     */ package reactor.util.context;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Context
/*     */   extends ContextView
/*     */ {
/*     */   static Context empty() {
/*  47 */     return Context0.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Context of(Object key, Object value) {
/*  59 */     return new Context1(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Context of(Object key1, Object value1, Object key2, Object value2) {
/*  74 */     return new Context2(key1, value1, key2, value2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Context of(Object key1, Object value1, Object key2, Object value2, Object key3, Object value3) {
/*  92 */     return new Context3(key1, value1, key2, value2, key3, value3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Context of(Object key1, Object value1, Object key2, Object value2, Object key3, Object value3, Object key4, Object value4) {
/* 113 */     return new Context4(key1, value1, key2, value2, key3, value3, key4, value4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Context of(Object key1, Object value1, Object key2, Object value2, Object key3, Object value3, Object key4, Object value4, Object key5, Object value5) {
/* 137 */     return new Context5(key1, value1, key2, value2, key3, value3, key4, value4, key5, value5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Context of(Map<?, ?> map) {
/* 149 */     int size = ((Map)Objects.<Map>requireNonNull(map, "map")).size();
/* 150 */     if (size == 0) return empty(); 
/* 151 */     if (size <= 5) {
/* 152 */       Map.Entry[] entries = (Map.Entry[])map.entrySet().toArray((Object[])new Map.Entry[size]);
/* 153 */       switch (size) {
/*     */         case 1:
/* 155 */           return new Context1(entries[0].getKey(), entries[0].getValue());
/*     */         case 2:
/* 157 */           return new Context2(entries[0].getKey(), entries[0].getValue(), entries[1]
/* 158 */               .getKey(), entries[1].getValue());
/*     */         case 3:
/* 160 */           return new Context3(entries[0].getKey(), entries[0].getValue(), entries[1]
/* 161 */               .getKey(), entries[1].getValue(), entries[2]
/* 162 */               .getKey(), entries[2].getValue());
/*     */         case 4:
/* 164 */           return new Context4(entries[0].getKey(), entries[0].getValue(), entries[1]
/* 165 */               .getKey(), entries[1].getValue(), entries[2]
/* 166 */               .getKey(), entries[2].getValue(), entries[3]
/* 167 */               .getKey(), entries[3].getValue());
/*     */         case 5:
/* 169 */           return new Context5(entries[0].getKey(), entries[0].getValue(), entries[1]
/* 170 */               .getKey(), entries[1].getValue(), entries[2]
/* 171 */               .getKey(), entries[2].getValue(), entries[3]
/* 172 */               .getKey(), entries[3].getValue(), entries[4]
/* 173 */               .getKey(), entries[4].getValue());
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 178 */     map.forEach((key, value) -> {
/*     */           Objects.requireNonNull(key, "null key found");
/*     */           
/*     */           if (value == null) {
/*     */             throw new NullPointerException("null value for key " + key);
/*     */           }
/*     */         });
/* 185 */     Map<?, ?> map1 = map;
/* 186 */     return new ContextN((Map)map1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Context of(ContextView contextView) {
/* 198 */     Objects.requireNonNull(contextView, "contextView");
/* 199 */     if (contextView instanceof Context) {
/* 200 */       return (Context)contextView;
/*     */     }
/* 202 */     return empty().putAll(contextView);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ContextView readOnly() {
/* 211 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Context putNonNull(Object key, @Nullable Object valueOrNull) {
/* 239 */     if (valueOrNull != null) {
/* 240 */       return put(key, valueOrNull);
/*     */     }
/* 242 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Context putAll(ContextView other) {
/* 266 */     if (other.isEmpty()) return this;
/*     */     
/* 268 */     if (other instanceof CoreContext) {
/* 269 */       CoreContext coreContext = (CoreContext)other;
/* 270 */       return coreContext.putAllInto(this);
/*     */     } 
/*     */     
/* 273 */     ContextN newContext = new ContextN(size() + other.size());
/* 274 */     stream().sequential().forEach(newContext);
/* 275 */     other.stream().sequential().forEach(newContext);
/* 276 */     if (newContext.size() <= 5)
/*     */     {
/* 278 */       return of(newContext);
/*     */     }
/* 280 */     return newContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Context putAllMap(Map<?, ?> from) {
/* 292 */     if (from.isEmpty()) {
/* 293 */       return this;
/*     */     }
/*     */     
/* 296 */     ContextN combined = new ContextN(size() + from.size());
/* 297 */     forEach(combined);
/* 298 */     from.forEach(combined);
/* 299 */     if (combined.size() <= 5) {
/* 300 */       return of(combined);
/*     */     }
/* 302 */     return combined;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Context putAll(Context context) {
/* 316 */     return putAll(context.readOnly());
/*     */   }
/*     */   
/*     */   Context put(Object paramObject1, Object paramObject2);
/*     */   
/*     */   Context delete(Object paramObject);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\context\Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */