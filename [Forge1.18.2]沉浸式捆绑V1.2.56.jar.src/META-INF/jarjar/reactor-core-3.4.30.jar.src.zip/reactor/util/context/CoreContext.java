/*    */ package reactor.util.context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface CoreContext
/*    */   extends Context
/*    */ {
/*    */   default boolean isEmpty() {
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   default Context putAll(ContextView other) {
/* 36 */     if (other.isEmpty()) return this;
/*    */     
/* 38 */     if (other instanceof CoreContext) {
/* 39 */       CoreContext coreContext = (CoreContext)other;
/* 40 */       return coreContext.putAllInto(this);
/*    */     } 
/*    */     
/* 43 */     ContextN newContext = new ContextN(size() + other.size());
/* 44 */     unsafePutAllInto(newContext);
/* 45 */     other.stream().sequential().forEach(newContext);
/* 46 */     if (newContext.size() <= 5)
/*    */     {
/* 48 */       return Context.of(newContext);
/*    */     }
/* 50 */     return newContext;
/*    */   }
/*    */   
/*    */   Context putAllInto(Context paramContext);
/*    */   
/*    */   void unsafePutAllInto(ContextN paramContextN);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reacto\\util\context\CoreContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */