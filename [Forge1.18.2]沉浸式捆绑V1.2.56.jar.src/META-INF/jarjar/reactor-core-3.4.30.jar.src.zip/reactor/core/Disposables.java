/*     */ package reactor.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Disposables
/*     */ {
/*     */   public static Disposable.Composite composite() {
/*  49 */     return new ListCompositeDisposable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Disposable.Composite composite(Disposable... disposables) {
/*  59 */     return new ListCompositeDisposable(disposables);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Disposable.Composite composite(Iterable<? extends Disposable> disposables) {
/*  70 */     return new ListCompositeDisposable(disposables);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Disposable disposed() {
/*  79 */     return new AlwaysDisposable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Disposable never() {
/*  89 */     return new NeverDisposable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Disposable single() {
/*  99 */     return new SimpleDisposable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Disposable.Swap swap() {
/* 109 */     return new SwapDisposable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ListCompositeDisposable
/*     */     implements Disposable.Composite, Scannable
/*     */   {
/*     */     @Nullable
/*     */     List<Disposable> resources;
/*     */ 
/*     */     
/*     */     volatile boolean disposed;
/*     */ 
/*     */ 
/*     */     
/*     */     ListCompositeDisposable() {}
/*     */ 
/*     */     
/*     */     ListCompositeDisposable(Disposable... resources) {
/* 129 */       Objects.requireNonNull(resources, "resources is null");
/* 130 */       this.resources = new LinkedList<>();
/* 131 */       for (Disposable d : resources) {
/* 132 */         Objects.requireNonNull(d, "Disposable item is null");
/* 133 */         this.resources.add(d);
/*     */       } 
/*     */     }
/*     */     
/*     */     ListCompositeDisposable(Iterable<? extends Disposable> resources) {
/* 138 */       Objects.requireNonNull(resources, "resources is null");
/* 139 */       this.resources = new LinkedList<>();
/* 140 */       for (Disposable d : resources) {
/* 141 */         Objects.requireNonNull(d, "Disposable item is null");
/* 142 */         this.resources.add(d);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void dispose() {
/*     */       List<Disposable> set;
/* 148 */       if (this.disposed) {
/*     */         return;
/*     */       }
/*     */       
/* 152 */       synchronized (this) {
/* 153 */         if (this.disposed) {
/*     */           return;
/*     */         }
/* 156 */         this.disposed = true;
/* 157 */         set = this.resources;
/* 158 */         this.resources = null;
/*     */       } 
/*     */       
/* 161 */       dispose(set);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 166 */       return this.disposed;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(Disposable d) {
/* 171 */       Objects.requireNonNull(d, "d is null");
/* 172 */       if (!this.disposed) {
/* 173 */         synchronized (this) {
/* 174 */           if (!this.disposed) {
/* 175 */             List<Disposable> set = this.resources;
/* 176 */             if (set == null) {
/* 177 */               set = new LinkedList<>();
/* 178 */               this.resources = set;
/*     */             } 
/* 180 */             set.add(d);
/* 181 */             return true;
/*     */           } 
/*     */         } 
/*     */       }
/* 185 */       d.dispose();
/* 186 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends Disposable> ds) {
/* 191 */       Objects.requireNonNull(ds, "ds is null");
/* 192 */       if (!this.disposed) {
/* 193 */         synchronized (this) {
/* 194 */           if (!this.disposed) {
/* 195 */             List<Disposable> set = this.resources;
/* 196 */             if (set == null) {
/* 197 */               set = new LinkedList<>();
/* 198 */               this.resources = set;
/*     */             } 
/* 200 */             for (Disposable d : ds) {
/* 201 */               Objects.requireNonNull(d, "d is null");
/* 202 */               set.add(d);
/*     */             } 
/* 204 */             return true;
/*     */           } 
/*     */         } 
/*     */       }
/* 208 */       for (Disposable d : ds) {
/* 209 */         d.dispose();
/*     */       }
/* 211 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Disposable d) {
/* 216 */       Objects.requireNonNull(d, "Disposable item is null");
/* 217 */       if (this.disposed) {
/* 218 */         return false;
/*     */       }
/* 220 */       synchronized (this) {
/* 221 */         if (this.disposed) {
/* 222 */           return false;
/*     */         }
/*     */         
/* 225 */         List<Disposable> set = this.resources;
/* 226 */         if (set == null || !set.remove(d)) {
/* 227 */           return false;
/*     */         }
/*     */       } 
/* 230 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 235 */       List<Disposable> r = this.resources;
/* 236 */       return (r == null) ? 0 : r.size();
/*     */     }
/*     */     
/*     */     Stream<Disposable> asStream() {
/* 240 */       List<Disposable> r = this.resources;
/* 241 */       return (r == null) ? Stream.<Disposable>empty() : r.stream();
/*     */     }
/*     */     public void clear() {
/*     */       List<Disposable> set;
/* 245 */       if (this.disposed) {
/*     */         return;
/*     */       }
/*     */       
/* 249 */       synchronized (this) {
/* 250 */         if (this.disposed) {
/*     */           return;
/*     */         }
/*     */         
/* 254 */         set = this.resources;
/* 255 */         this.resources = null;
/*     */       } 
/*     */       
/* 258 */       dispose(set);
/*     */     }
/*     */     
/*     */     void dispose(@Nullable List<Disposable> set) {
/* 262 */       if (set == null) {
/*     */         return;
/*     */       }
/* 265 */       List<Throwable> errors = null;
/* 266 */       for (Disposable o : set) {
/*     */         try {
/* 268 */           o.dispose();
/* 269 */         } catch (Throwable ex) {
/* 270 */           Exceptions.throwIfFatal(ex);
/* 271 */           if (errors == null) {
/* 272 */             errors = new ArrayList<>();
/*     */           }
/* 274 */           errors.add(ex);
/*     */         } 
/*     */       } 
/* 277 */       if (errors != null) {
/* 278 */         if (errors.size() == 1) {
/* 279 */           throw Exceptions.propagate((Throwable)errors.get(0));
/*     */         }
/* 281 */         throw Exceptions.multiple(errors);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 287 */       return asStream()
/* 288 */         .filter(Scannable.class::isInstance)
/* 289 */         .map(Scannable::from);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr<Boolean> key) {
/* 295 */       if (key == Scannable.Attr.CANCELLED) {
/* 296 */         return Boolean.valueOf(isDisposed());
/*     */       }
/* 298 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class SwapDisposable
/*     */     implements Disposable.Swap
/*     */   {
/*     */     volatile Disposable inner;
/*     */ 
/*     */ 
/*     */     
/* 313 */     static final AtomicReferenceFieldUpdater<SwapDisposable, Disposable> INNER = AtomicReferenceFieldUpdater.newUpdater(SwapDisposable.class, Disposable.class, "inner");
/*     */ 
/*     */     
/*     */     public boolean update(@Nullable Disposable next) {
/* 317 */       return Disposables.set(INNER, this, next);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean replace(@Nullable Disposable next) {
/* 322 */       return Disposables.replace(INNER, this, next);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Disposable get() {
/* 328 */       return this.inner;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 333 */       Disposables.dispose(INNER, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 338 */       return Disposables.isDisposed(INNER.get(this));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class SimpleDisposable
/*     */     extends AtomicBoolean
/*     */     implements Disposable
/*     */   {
/*     */     public void dispose() {
/* 350 */       set(true);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 355 */       return get();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AlwaysDisposable
/*     */     implements Disposable
/*     */   {
/*     */     public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 372 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class NeverDisposable
/*     */     implements Disposable
/*     */   {
/*     */     public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 389 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 400 */   static final Disposable DISPOSED = disposed();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> boolean set(AtomicReferenceFieldUpdater<T, Disposable> updater, T holder, @Nullable Disposable newValue) {
/*     */     while (true) {
/* 412 */       Disposable current = updater.get(holder);
/* 413 */       if (current == DISPOSED) {
/* 414 */         if (newValue != null) {
/* 415 */           newValue.dispose();
/*     */         }
/* 417 */         return false;
/*     */       } 
/* 419 */       if (updater.compareAndSet(holder, current, newValue)) {
/* 420 */         if (current != null) {
/* 421 */           current.dispose();
/*     */         }
/* 423 */         return true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> boolean replace(AtomicReferenceFieldUpdater<T, Disposable> updater, T holder, @Nullable Disposable newValue) {
/*     */     while (true) {
/* 440 */       Disposable current = updater.get(holder);
/* 441 */       if (current == DISPOSED) {
/* 442 */         if (newValue != null) {
/* 443 */           newValue.dispose();
/*     */         }
/* 445 */         return false;
/*     */       } 
/* 447 */       if (updater.compareAndSet(holder, current, newValue)) {
/* 448 */         return true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> boolean dispose(AtomicReferenceFieldUpdater<T, Disposable> updater, T holder) {
/* 461 */     Disposable current = updater.get(holder);
/* 462 */     Disposable d = DISPOSED;
/* 463 */     if (current != d) {
/* 464 */       current = updater.getAndSet(holder, d);
/* 465 */       if (current != d) {
/* 466 */         if (current != null) {
/* 467 */           current.dispose();
/*     */         }
/* 469 */         return true;
/*     */       } 
/*     */     } 
/* 472 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isDisposed(Disposable d) {
/* 482 */     return (d == DISPOSED);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\Disposables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */