/*     */ package reactor.core;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface Disposable
/*     */ {
/*     */   void dispose();
/*     */   
/*     */   default boolean isDisposed() {
/*  48 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Composite
/*     */     extends Disposable
/*     */   {
/*     */     boolean add(Disposable param1Disposable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default boolean addAll(Collection<? extends Disposable> ds) {
/* 114 */       boolean abort = isDisposed();
/* 115 */       for (Disposable d : ds) {
/* 116 */         if (abort) {
/*     */           
/* 118 */           d.dispose();
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 124 */         abort = !add(d);
/*     */       } 
/*     */       
/* 127 */       return !abort;
/*     */     }
/*     */     
/*     */     void dispose();
/*     */     
/*     */     boolean isDisposed();
/*     */     
/*     */     boolean remove(Disposable param1Disposable);
/*     */     
/*     */     int size();
/*     */   }
/*     */   
/*     */   public static interface Swap extends Disposable, Supplier<Disposable> {
/*     */     boolean update(@Nullable Disposable param1Disposable);
/*     */     
/*     */     boolean replace(@Nullable Disposable param1Disposable);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\Disposable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */