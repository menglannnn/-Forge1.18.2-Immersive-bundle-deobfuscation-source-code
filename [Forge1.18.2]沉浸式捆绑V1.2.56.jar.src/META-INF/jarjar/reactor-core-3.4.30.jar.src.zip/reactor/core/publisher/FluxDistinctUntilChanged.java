/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDistinctUntilChanged<T, K>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Function<? super T, K> keyExtractor;
/*     */   final BiPredicate<? super K, ? super K> keyComparator;
/*     */   
/*     */   FluxDistinctUntilChanged(Flux<? extends T> source, Function<? super T, K> keyExtractor, BiPredicate<? super K, ? super K> keyComparator) {
/*  44 */     super(source);
/*  45 */     this.keyExtractor = Objects.<Function<? super T, K>>requireNonNull(keyExtractor, "keyExtractor");
/*  46 */     this.keyComparator = Objects.<BiPredicate<? super K, ? super K>>requireNonNull(keyComparator, "keyComparator");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  52 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  53 */       return new DistinctUntilChangedConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this.keyExtractor, this.keyComparator);
/*     */     }
/*     */ 
/*     */     
/*  57 */     return new DistinctUntilChangedSubscriber<>(actual, this.keyExtractor, this.keyComparator);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  63 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  64 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DistinctUntilChangedSubscriber<T, K>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Function<? super T, K> keyExtractor;
/*     */     
/*     */     final BiPredicate<? super K, ? super K> keyComparator;
/*     */     
/*     */     Subscription s;
/*     */     boolean done;
/*     */     @Nullable
/*     */     K lastKey;
/*     */     
/*     */     DistinctUntilChangedSubscriber(CoreSubscriber<? super T> actual, Function<? super T, K> keyExtractor, BiPredicate<? super K, ? super K> keyComparator) {
/*  85 */       this.actual = actual;
/*  86 */       this.ctx = actual.currentContext();
/*  87 */       this.keyExtractor = keyExtractor;
/*  88 */       this.keyComparator = keyComparator;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  93 */       if (Operators.validate(this.s, s)) {
/*  94 */         this.s = s;
/*     */         
/*  96 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 102 */       if (!tryOnNext(t))
/* 103 */         this.s.request(1L); 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       K k;
/*     */       boolean equiv;
/* 109 */       if (this.done) {
/* 110 */         Operators.onNextDropped(t, this.ctx);
/* 111 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 117 */         k = Objects.requireNonNull(this.keyExtractor.apply(t), "The distinct extractor returned a null value.");
/*     */       
/*     */       }
/* 120 */       catch (Throwable e) {
/* 121 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 122 */         Operators.onDiscard(t, this.ctx);
/* 123 */         return true;
/*     */       } 
/*     */       
/* 126 */       if (null == this.lastKey) {
/* 127 */         this.lastKey = k;
/* 128 */         this.actual.onNext(t);
/* 129 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 135 */         equiv = this.keyComparator.test(this.lastKey, k);
/*     */       }
/* 137 */       catch (Throwable e) {
/* 138 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 139 */         Operators.onDiscard(t, this.ctx);
/* 140 */         return true;
/*     */       } 
/*     */       
/* 143 */       if (equiv) {
/* 144 */         Operators.onDiscard(t, this.ctx);
/* 145 */         return false;
/*     */       } 
/*     */       
/* 148 */       this.lastKey = k;
/* 149 */       this.actual.onNext(t);
/* 150 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 155 */       if (this.done) {
/* 156 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 159 */       this.done = true;
/* 160 */       this.lastKey = null;
/*     */       
/* 162 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 167 */       if (this.done) {
/*     */         return;
/*     */       }
/* 170 */       this.done = true;
/* 171 */       this.lastKey = null;
/*     */       
/* 173 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 179 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 180 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 181 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 183 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 188 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 193 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 198 */       this.s.cancel();
/* 199 */       this.lastKey = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DistinctUntilChangedConditionalSubscriber<T, K>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Function<? super T, K> keyExtractor;
/*     */     
/*     */     final BiPredicate<? super K, ? super K> keyComparator;
/*     */     
/*     */     Subscription s;
/*     */     boolean done;
/*     */     @Nullable
/*     */     K lastKey;
/*     */     
/*     */     DistinctUntilChangedConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, Function<? super T, K> keyExtractor, BiPredicate<? super K, ? super K> keyComparator) {
/* 221 */       this.actual = actual;
/* 222 */       this.ctx = actual.currentContext();
/* 223 */       this.keyExtractor = keyExtractor;
/* 224 */       this.keyComparator = keyComparator;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 229 */       if (Operators.validate(this.s, s)) {
/* 230 */         this.s = s;
/*     */         
/* 232 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 238 */       if (!tryOnNext(t))
/* 239 */         this.s.request(1L); 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       K k;
/*     */       boolean equiv;
/* 245 */       if (this.done) {
/* 246 */         Operators.onNextDropped(t, this.ctx);
/* 247 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 253 */         k = Objects.requireNonNull(this.keyExtractor.apply(t), "The distinct extractor returned a null value.");
/*     */       
/*     */       }
/* 256 */       catch (Throwable e) {
/* 257 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 258 */         Operators.onDiscard(t, this.ctx);
/* 259 */         return true;
/*     */       } 
/*     */       
/* 262 */       if (null == this.lastKey) {
/* 263 */         this.lastKey = k;
/* 264 */         return this.actual.tryOnNext(t);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 270 */         equiv = this.keyComparator.test(this.lastKey, k);
/*     */       }
/* 272 */       catch (Throwable e) {
/* 273 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/* 274 */         Operators.onDiscard(t, this.ctx);
/* 275 */         return true;
/*     */       } 
/*     */       
/* 278 */       if (equiv) {
/* 279 */         Operators.onDiscard(t, this.ctx);
/* 280 */         return false;
/*     */       } 
/*     */       
/* 283 */       this.lastKey = k;
/* 284 */       return this.actual.tryOnNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 289 */       if (this.done) {
/* 290 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 293 */       this.done = true;
/* 294 */       this.lastKey = null;
/*     */       
/* 296 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 301 */       if (this.done) {
/*     */         return;
/*     */       }
/* 304 */       this.done = true;
/* 305 */       this.lastKey = null;
/*     */       
/* 307 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 313 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 314 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 315 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 317 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 322 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 327 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 332 */       this.s.cancel();
/* 333 */       this.lastKey = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxDistinctUntilChanged.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */