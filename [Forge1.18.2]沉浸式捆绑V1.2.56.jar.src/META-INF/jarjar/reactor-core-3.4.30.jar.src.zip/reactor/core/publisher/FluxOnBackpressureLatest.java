/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxOnBackpressureLatest<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   FluxOnBackpressureLatest(Flux<? extends T> source) {
/*  39 */     super(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  44 */     return new LatestSubscriber<>(actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  49 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  54 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  55 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class LatestSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     volatile long requested;
/*  67 */     static final AtomicLongFieldUpdater<LatestSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(LatestSubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/*  72 */     static final AtomicIntegerFieldUpdater<LatestSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(LatestSubscriber.class, "wip");
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     Throwable error;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile T value;
/*     */     
/*  84 */     static final AtomicReferenceFieldUpdater<LatestSubscriber, Object> VALUE = AtomicReferenceFieldUpdater.newUpdater(LatestSubscriber.class, Object.class, "value");
/*     */     
/*     */     LatestSubscriber(CoreSubscriber<? super T> actual) {
/*  87 */       this.actual = actual;
/*  88 */       this.ctx = actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/*  93 */       if (Operators.validate(n)) {
/*  94 */         Operators.addCap(REQUESTED, this, n);
/*     */         
/*  96 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 102 */       if (!this.cancelled) {
/*     */         
/* 104 */         this.cancelled = true;
/*     */         
/* 106 */         this.s.cancel();
/*     */         
/* 108 */         if (WIP.getAndIncrement(this) == 0) {
/* 109 */           Object toDiscard = VALUE.getAndSet(this, null);
/* 110 */           if (toDiscard != null) {
/* 111 */             Operators.onDiscard(toDiscard, this.ctx);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 119 */       if (Operators.validate(this.s, s)) {
/* 120 */         this.s = s;
/*     */         
/* 122 */         this.actual.onSubscribe(this);
/*     */         
/* 124 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 130 */       Object toDiscard = VALUE.getAndSet(this, t);
/* 131 */       if (toDiscard != null) {
/* 132 */         Operators.onDiscard(toDiscard, this.ctx);
/*     */       }
/* 134 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 139 */       this.error = t;
/* 140 */       this.done = true;
/* 141 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 146 */       this.done = true;
/* 147 */       drain();
/*     */     }
/*     */     
/*     */     void drain() {
/* 151 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/* 154 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       
/* 156 */       int missed = 1;
/*     */ 
/*     */       
/*     */       do {
/* 160 */         if (checkTerminated(this.done, (this.value == null), (Subscriber<? super T>)coreSubscriber)) {
/*     */           return;
/*     */         }
/*     */         
/* 164 */         long r = this.requested;
/* 165 */         long e = 0L;
/*     */         
/* 167 */         while (r != e) {
/* 168 */           boolean d = this.done;
/*     */ 
/*     */           
/* 171 */           T v = (T)VALUE.getAndSet(this, null);
/*     */           
/* 173 */           boolean empty = (v == null);
/*     */           
/* 175 */           if (checkTerminated(d, empty, (Subscriber<? super T>)coreSubscriber)) {
/*     */             return;
/*     */           }
/*     */           
/* 179 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 183 */           coreSubscriber.onNext(v);
/*     */           
/* 185 */           e++;
/*     */         } 
/*     */         
/* 188 */         if (r == e && checkTerminated(this.done, (this.value == null), (Subscriber<? super T>)coreSubscriber)) {
/*     */           return;
/*     */         }
/*     */         
/* 192 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 193 */           Operators.produced(REQUESTED, this, e);
/*     */         }
/*     */         
/* 196 */         missed = WIP.addAndGet(this, -missed);
/* 197 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<? super T> a) {
/* 204 */       if (this.cancelled) {
/* 205 */         Object toDiscard = VALUE.getAndSet(this, null);
/* 206 */         if (toDiscard != null)
/* 207 */           Operators.onDiscard(toDiscard, this.ctx); 
/* 208 */         return true;
/*     */       } 
/*     */       
/* 211 */       if (d) {
/* 212 */         Throwable e = this.error;
/* 213 */         if (e != null) {
/* 214 */           Object toDiscard = VALUE.getAndSet(this, null);
/* 215 */           if (toDiscard != null) {
/* 216 */             Operators.onDiscard(toDiscard, this.ctx);
/*     */           }
/*     */           
/* 219 */           a.onError(e);
/* 220 */           return true;
/* 221 */         }  if (empty) {
/* 222 */           a.onComplete();
/* 223 */           return true;
/*     */         } 
/*     */       } 
/*     */       
/* 227 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 232 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 238 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 239 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 240 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 241 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 242 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.value != null) ? 1 : 0); 
/* 243 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 244 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 245 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 247 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxOnBackpressureLatest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */