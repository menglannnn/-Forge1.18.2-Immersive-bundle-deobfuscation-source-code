/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SinkEmptyMulticast<T>
/*     */   extends Mono<T>
/*     */   implements InternalEmptySink<T>
/*     */ {
/*     */   volatile Inner<T>[] subscribers;
/*  36 */   static final AtomicReferenceFieldUpdater<SinkEmptyMulticast, Inner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(SinkEmptyMulticast.class, (Class)Inner[].class, "subscribers");
/*     */ 
/*     */   
/*  39 */   static final Inner[] EMPTY = new Inner[0];
/*     */   
/*  41 */   static final Inner[] TERMINATED_EMPTY = new Inner[0];
/*     */   
/*  43 */   static final Inner[] TERMINATED_ERROR = new Inner[0];
/*     */   
/*     */   static final int STATE_ADDED = 0;
/*     */   
/*     */   static final int STATE_ERROR = -1;
/*     */   static final int STATE_EMPTY = -2;
/*     */   @Nullable
/*     */   Throwable error;
/*     */   
/*     */   SinkEmptyMulticast() {
/*  53 */     SUBSCRIBERS.lazySet(this, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public int currentSubscriberCount() {
/*  58 */     return this.subscribers.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<T> asMono() {
/*  63 */     return this;
/*     */   }
/*     */   
/*     */   boolean isTerminated(Inner<?>[] array) {
/*  67 */     return (array == TERMINATED_EMPTY || array == TERMINATED_ERROR);
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitEmpty() {
/*     */     Inner<T>[] array;
/*     */     do {
/*  74 */       array = this.subscribers;
/*     */       
/*  76 */       if (isTerminated((Inner<?>[])array)) {
/*  77 */         return Sinks.EmitResult.FAIL_TERMINATED;
/*     */       }
/*     */     }
/*  80 */     while (!SUBSCRIBERS.compareAndSet(this, array, TERMINATED_EMPTY));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     for (Inner<?> as : array) {
/*  86 */       as.complete();
/*     */     }
/*  88 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitError(Throwable cause) {
/*  94 */     Objects.requireNonNull(cause, "onError cannot be null");
/*     */     
/*  96 */     Inner<T>[] prevSubscribers = this.subscribers;
/*     */     
/*  98 */     if (isTerminated((Inner<?>[])prevSubscribers)) {
/*  99 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 102 */     this.error = cause;
/*     */ 
/*     */     
/* 105 */     while (!SUBSCRIBERS.compareAndSet(this, prevSubscribers, TERMINATED_ERROR)) {
/*     */ 
/*     */ 
/*     */       
/* 109 */       prevSubscribers = this.subscribers;
/* 110 */       if (isTerminated((Inner<?>[])prevSubscribers)) {
/* 111 */         return Sinks.EmitResult.FAIL_TERMINATED;
/*     */       }
/*     */     } 
/*     */     
/* 115 */     for (Inner<T> as : prevSubscribers) {
/* 116 */       as.error(cause);
/*     */     }
/*     */     
/* 119 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 124 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isTerminated((Inner<?>[])this.subscribers)); 
/* 125 */     if (key == Scannable.Attr.ERROR) return (this.subscribers == TERMINATED_ERROR) ? this.error : null; 
/* 126 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 133 */     return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */   }
/*     */   
/*     */   int add(Inner<T> ps) {
/*     */     while (true) {
/* 138 */       Inner<T>[] a = this.subscribers;
/*     */       
/* 140 */       if (a == TERMINATED_EMPTY) {
/* 141 */         return -2;
/*     */       }
/*     */       
/* 144 */       if (a == TERMINATED_ERROR) {
/* 145 */         return -1;
/*     */       }
/*     */       
/* 148 */       int n = a.length;
/* 149 */       Inner[] arrayOfInner = new Inner[n + 1];
/* 150 */       System.arraycopy(a, 0, arrayOfInner, 0, n);
/* 151 */       arrayOfInner[n] = ps;
/*     */       
/* 153 */       if (SUBSCRIBERS.compareAndSet(this, a, arrayOfInner))
/* 154 */         return 0; 
/*     */     } 
/*     */   }
/*     */   
/*     */   void remove(Inner<T> ps) {
/*     */     Inner<T>[] a;
/*     */     Inner[] arrayOfInner;
/*     */     do {
/* 162 */       a = this.subscribers;
/* 163 */       int n = a.length;
/* 164 */       if (n == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 168 */       int j = -1;
/* 169 */       for (int i = 0; i < n; i++) {
/* 170 */         if (a[i] == ps) {
/* 171 */           j = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 176 */       if (j < 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 182 */       if (n == 1) {
/* 183 */         arrayOfInner = EMPTY;
/*     */       } else {
/*     */         
/* 186 */         arrayOfInner = new Inner[n - 1];
/* 187 */         System.arraycopy(a, 0, arrayOfInner, 0, j);
/* 188 */         System.arraycopy(a, j + 1, arrayOfInner, j, n - j - 1);
/*     */       } 
/* 190 */     } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfInner));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 199 */     Inner<T> as = new VoidInner<>(actual, this);
/* 200 */     actual.onSubscribe(as);
/* 201 */     int addedState = add(as);
/* 202 */     if (addedState == 0) {
/* 203 */       if (as.isCancelled()) {
/* 204 */         remove(as);
/*     */       }
/*     */     }
/* 207 */     else if (addedState == -1) {
/* 208 */       Throwable ex = this.error;
/*     */       
/* 210 */       actual.onError(ex);
/*     */     } else {
/*     */       
/* 213 */       as.complete();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 220 */     return Stream.of((Scannable[])this.subscribers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class VoidInner<T>
/*     */     extends AtomicBoolean
/*     */     implements Inner<T>
/*     */   {
/*     */     final SinkEmptyMulticast<T> parent;
/*     */ 
/*     */ 
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */ 
/*     */ 
/*     */     
/*     */     VoidInner(CoreSubscriber<? super T> actual, SinkEmptyMulticast<T> parent) {
/* 239 */       this.actual = actual;
/* 240 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 245 */       if (getAndSet(true)) {
/*     */         return;
/*     */       }
/*     */       
/* 249 */       this.parent.remove(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCancelled() {
/* 254 */       return get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long l) {
/* 259 */       Operators.validate(l);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void complete(T value) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void complete() {
/* 269 */       if (get()) {
/*     */         return;
/*     */       }
/* 272 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable t) {
/* 277 */       if (get()) {
/* 278 */         Operators.onOperatorError(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 281 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 286 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 291 */       if (key == Scannable.Attr.PARENT) {
/* 292 */         return this.parent;
/*     */       }
/* 294 */       if (key == Scannable.Attr.CANCELLED) {
/* 295 */         return Boolean.valueOf(get());
/*     */       }
/* 297 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 298 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 300 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */   
/*     */   static interface Inner<T> extends InnerProducer<T> {
/*     */     void error(Throwable param1Throwable);
/*     */     
/*     */     void complete(T param1T);
/*     */     
/*     */     void complete();
/*     */     
/*     */     boolean isCancelled();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\SinkEmptyMulticast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */