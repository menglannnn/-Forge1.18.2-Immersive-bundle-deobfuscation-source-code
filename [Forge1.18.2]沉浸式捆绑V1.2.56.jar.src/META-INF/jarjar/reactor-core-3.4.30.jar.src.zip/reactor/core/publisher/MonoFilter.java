/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Predicate;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoFilter<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final Predicate<? super T> predicate;
/*    */   
/*    */   MonoFilter(Mono<? extends T> source, Predicate<? super T> predicate) {
/* 36 */     super(source);
/* 37 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 43 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 44 */       return new FluxFilter.FilterConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this.predicate);
/*    */     }
/* 46 */     return new FluxFilter.FilterSubscriber<>(actual, this.predicate);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 51 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 52 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */