/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoLift<I, O>
/*    */   extends InternalMonoOperator<I, O>
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   
/*    */   MonoLift(Publisher<I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 34 */     super(Mono.from(p));
/* 35 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/* 41 */     CoreSubscriber<? super I> input = this.liftFunction.lifter.apply(this.source, actual);
/*    */     
/* 43 */     Objects.requireNonNull(input, "Lifted subscriber MUST NOT be null");
/*    */     
/* 45 */     return input;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 50 */     if (this.source instanceof Scannable) {
/* 51 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 53 */     return super.stepName();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 58 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 59 */     if (key == Scannable.Attr.LIFTER) return this.liftFunction.name; 
/* 60 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoLift.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */