/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxTimeout<T, U, V>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Publisher<U> firstTimeout;
/*     */   final Function<? super T, ? extends Publisher<V>> itemTimeout;
/*     */   final Publisher<? extends T> other;
/*     */   final String timeoutDescription;
/*     */   
/*     */   FluxTimeout(Flux<? extends T> source, Publisher<U> firstTimeout, Function<? super T, ? extends Publisher<V>> itemTimeout, String timeoutDescription) {
/*  58 */     super(source);
/*  59 */     this.firstTimeout = Objects.<Publisher<U>>requireNonNull(firstTimeout, "firstTimeout");
/*  60 */     this.itemTimeout = Objects.<Function<? super T, ? extends Publisher<V>>>requireNonNull(itemTimeout, "itemTimeout");
/*  61 */     this.other = null;
/*     */     
/*  63 */     this.timeoutDescription = addNameToTimeoutDescription((Publisher<?>)source, 
/*  64 */         Objects.<String>requireNonNull(timeoutDescription, "timeoutDescription is needed when no fallback"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxTimeout(Flux<? extends T> source, Publisher<U> firstTimeout, Function<? super T, ? extends Publisher<V>> itemTimeout, Publisher<? extends T> other) {
/*  71 */     super(source);
/*  72 */     this.firstTimeout = Objects.<Publisher<U>>requireNonNull(firstTimeout, "firstTimeout");
/*  73 */     this.itemTimeout = Objects.<Function<? super T, ? extends Publisher<V>>>requireNonNull(itemTimeout, "itemTimeout");
/*  74 */     this.other = Objects.<Publisher<? extends T>>requireNonNull(other, "other");
/*  75 */     this.timeoutDescription = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  80 */     return new TimeoutMainSubscriber<>(actual, this.firstTimeout, this.itemTimeout, this.other, this.timeoutDescription);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static String addNameToTimeoutDescription(Publisher<?> source, @Nullable String timeoutDescription) {
/*  86 */     if (timeoutDescription == null) {
/*  87 */       return null;
/*     */     }
/*     */     
/*  90 */     Scannable s = Scannable.from(source);
/*  91 */     if (s.isScanAvailable()) {
/*  92 */       return timeoutDescription + " in '" + s.name() + "'";
/*     */     }
/*     */     
/*  95 */     return timeoutDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 101 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 102 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TimeoutMainSubscriber<T, V>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */   {
/*     */     final Publisher<?> firstTimeout;
/*     */     
/*     */     final Function<? super T, ? extends Publisher<V>> itemTimeout;
/*     */     
/*     */     final Publisher<? extends T> other;
/*     */     
/*     */     final String timeoutDescription;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     volatile FluxTimeout.IndexedCancellable timeout;
/*     */     
/* 121 */     static final AtomicReferenceFieldUpdater<TimeoutMainSubscriber, FluxTimeout.IndexedCancellable> TIMEOUT = AtomicReferenceFieldUpdater.newUpdater(TimeoutMainSubscriber.class, FluxTimeout.IndexedCancellable.class, "timeout");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long index;
/*     */ 
/*     */     
/* 128 */     static final AtomicLongFieldUpdater<TimeoutMainSubscriber> INDEX = AtomicLongFieldUpdater.newUpdater(TimeoutMainSubscriber.class, "index");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TimeoutMainSubscriber(CoreSubscriber<? super T> actual, Publisher<?> firstTimeout, Function<? super T, ? extends Publisher<V>> itemTimeout, @Nullable Publisher<? extends T> other, @Nullable String timeoutDescription) {
/* 137 */       super(Operators.serialize(actual));
/* 138 */       this.itemTimeout = itemTimeout;
/* 139 */       this.other = other;
/* 140 */       this.timeoutDescription = timeoutDescription;
/* 141 */       this.firstTimeout = firstTimeout;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 146 */       if (Operators.validate(this.s, s)) {
/* 147 */         this.s = s;
/*     */         
/* 149 */         set(s);
/*     */         
/* 151 */         FluxTimeout.TimeoutTimeoutSubscriber timeoutSubscriber = new FluxTimeout.TimeoutTimeoutSubscriber(this, 0L);
/* 152 */         this.timeout = timeoutSubscriber;
/*     */         
/* 154 */         this.actual.onSubscribe(this);
/* 155 */         this.firstTimeout.subscribe((Subscriber)timeoutSubscriber);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean shouldCancelCurrent() {
/* 161 */       return true;
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       Publisher<? extends V> p;
/* 166 */       this.timeout.cancel();
/*     */       
/* 168 */       long idx = this.index;
/* 169 */       if (idx == Long.MIN_VALUE) {
/* 170 */         this.s.cancel();
/* 171 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 174 */       if (!INDEX.compareAndSet(this, idx, idx + 1L)) {
/* 175 */         this.s.cancel();
/* 176 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 180 */       this.actual.onNext(t);
/*     */       
/* 182 */       producedOne();
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 187 */         p = Objects.<Publisher<? extends V>>requireNonNull(this.itemTimeout.apply(t), "The itemTimeout returned a null Publisher");
/*     */       
/*     */       }
/* 190 */       catch (Throwable e) {
/* 191 */         this.actual.onError(Operators.onOperatorError(this, e, t, this.actual
/* 192 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 196 */       FluxTimeout.TimeoutTimeoutSubscriber ts = new FluxTimeout.TimeoutTimeoutSubscriber(this, idx + 1L);
/*     */       
/* 198 */       if (!setTimeout(ts)) {
/*     */         return;
/*     */       }
/*     */       
/* 202 */       p.subscribe((Subscriber)ts);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 207 */       long idx = this.index;
/* 208 */       if (idx == Long.MIN_VALUE) {
/* 209 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 212 */       if (!INDEX.compareAndSet(this, idx, Long.MIN_VALUE)) {
/* 213 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 217 */       cancelTimeout();
/*     */       
/* 219 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 224 */       long idx = this.index;
/* 225 */       if (idx == Long.MIN_VALUE) {
/*     */         return;
/*     */       }
/* 228 */       if (!INDEX.compareAndSet(this, idx, Long.MIN_VALUE)) {
/*     */         return;
/*     */       }
/*     */       
/* 232 */       cancelTimeout();
/*     */       
/* 234 */       this.actual.onComplete();
/*     */     }
/*     */     
/*     */     void cancelTimeout() {
/* 238 */       FluxTimeout.IndexedCancellable s = this.timeout;
/* 239 */       if (s != FluxTimeout.CancelledIndexedCancellable.INSTANCE) {
/* 240 */         s = TIMEOUT.getAndSet(this, FluxTimeout.CancelledIndexedCancellable.INSTANCE);
/* 241 */         if (s != null && s != FluxTimeout.CancelledIndexedCancellable.INSTANCE) {
/* 242 */           s.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 249 */       this.index = Long.MIN_VALUE;
/* 250 */       cancelTimeout();
/* 251 */       super.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     boolean setTimeout(FluxTimeout.IndexedCancellable newTimeout) {
/*     */       while (true) {
/* 257 */         FluxTimeout.IndexedCancellable currentTimeout = this.timeout;
/*     */         
/* 259 */         if (currentTimeout == FluxTimeout.CancelledIndexedCancellable.INSTANCE) {
/* 260 */           newTimeout.cancel();
/* 261 */           return false;
/*     */         } 
/*     */         
/* 264 */         if (currentTimeout != null && currentTimeout.index() >= newTimeout.index()) {
/* 265 */           newTimeout.cancel();
/* 266 */           return false;
/*     */         } 
/*     */         
/* 269 */         if (TIMEOUT.compareAndSet(this, currentTimeout, newTimeout)) {
/* 270 */           if (currentTimeout != null) {
/* 271 */             currentTimeout.cancel();
/*     */           }
/* 273 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void doTimeout(long i) {
/* 279 */       if (this.index == i && INDEX.compareAndSet(this, i, Long.MIN_VALUE)) {
/* 280 */         handleTimeout();
/*     */       }
/*     */     }
/*     */     
/*     */     void doError(long i, Throwable e) {
/* 285 */       if (this.index == i && INDEX.compareAndSet(this, i, Long.MIN_VALUE)) {
/* 286 */         super.cancel();
/*     */         
/* 288 */         this.actual.onError(e);
/*     */       } 
/*     */     }
/*     */     
/*     */     void handleTimeout() {
/* 293 */       if (this.other == null) {
/* 294 */         super.cancel();
/* 295 */         this.actual.onError(new TimeoutException("Did not observe any item or terminal signal within " + this.timeoutDescription + " (and no fallback has been configured)"));
/*     */       }
/*     */       else {
/*     */         
/* 299 */         set(Operators.emptySubscription());
/*     */         
/* 301 */         this.other.subscribe((Subscriber)new FluxTimeout.TimeoutOtherSubscriber<>(this.actual, this));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 307 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 308 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TimeoutOtherSubscriber<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     final Operators.MultiSubscriptionSubscriber<T, T> arbiter;
/*     */     
/*     */     TimeoutOtherSubscriber(CoreSubscriber<? super T> actual, Operators.MultiSubscriptionSubscriber<T, T> arbiter) {
/* 320 */       this.actual = actual;
/* 321 */       this.arbiter = arbiter;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 326 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 331 */       this.arbiter.set(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 336 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 341 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 346 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 351 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 352 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   static interface IndexedCancellable {
/*     */     long index();
/*     */     
/*     */     void cancel();
/*     */   }
/*     */   
/*     */   enum CancelledIndexedCancellable
/*     */     implements IndexedCancellable {
/* 364 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public long index() {
/* 368 */       return Long.MAX_VALUE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class TimeoutTimeoutSubscriber
/*     */     implements InnerConsumer<Object>, IndexedCancellable
/*     */   {
/*     */     final FluxTimeout.TimeoutMainSubscriber<?, ?> main;
/*     */ 
/*     */     
/*     */     final long index;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 388 */     static final AtomicReferenceFieldUpdater<TimeoutTimeoutSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(TimeoutTimeoutSubscriber.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     TimeoutTimeoutSubscriber(FluxTimeout.TimeoutMainSubscriber<?, ?> main, long index) {
/* 393 */       this.main = main;
/* 394 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 399 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 404 */       if (!S.compareAndSet(this, null, s)) {
/* 405 */         s.cancel();
/* 406 */         if (this.s != Operators.cancelledSubscription()) {
/* 407 */           Operators.reportSubscriptionSet();
/*     */         }
/*     */       } else {
/*     */         
/* 411 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 417 */       this.s.cancel();
/*     */       
/* 419 */       this.main.doTimeout(this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 424 */       this.main.doError(this.index, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 429 */       this.main.doTimeout(this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 434 */       Subscription a = this.s;
/* 435 */       if (a != Operators.cancelledSubscription()) {
/* 436 */         a = S.getAndSet(this, Operators.cancelledSubscription());
/* 437 */         if (a != null && a != Operators.cancelledSubscription()) {
/* 438 */           a.cancel();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public long index() {
/* 445 */       return this.index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 450 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 451 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxTimeout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */