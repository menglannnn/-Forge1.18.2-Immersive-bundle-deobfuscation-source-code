/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxRepeatWhen<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Function<? super Flux<Long>, ? extends Publisher<?>> whenSourceFactory;
/*     */   
/*     */   FluxRepeatWhen(Flux<? extends T> source, Function<? super Flux<Long>, ? extends Publisher<?>> whenSourceFactory) {
/*  52 */     super(source);
/*  53 */     this
/*  54 */       .whenSourceFactory = Objects.<Function<? super Flux<Long>, ? extends Publisher<?>>>requireNonNull(whenSourceFactory, "whenSourceFactory");
/*     */   }
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*     */     Publisher<?> p;
/*  59 */     RepeatWhenOtherSubscriber other = new RepeatWhenOtherSubscriber();
/*  60 */     CoreSubscriber<T> serial = Operators.serialize(actual);
/*     */     
/*  62 */     RepeatWhenMainSubscriber<T> main = new RepeatWhenMainSubscriber<>(serial, other.completionSignal, this.source);
/*     */     
/*  64 */     other.main = main;
/*     */     
/*  66 */     serial.onSubscribe(main);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  71 */       p = Objects.<Publisher>requireNonNull(this.whenSourceFactory.apply(other), "The whenSourceFactory returned a null Publisher");
/*     */     
/*     */     }
/*  74 */     catch (Throwable e) {
/*  75 */       actual.onError(Operators.onOperatorError(e, actual.currentContext()));
/*  76 */       return null;
/*     */     } 
/*     */     
/*  79 */     p.subscribe((Subscriber)other);
/*     */     
/*  81 */     if (!main.cancelled) {
/*  82 */       return main;
/*     */     }
/*     */     
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  91 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  92 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RepeatWhenMainSubscriber<T>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */   {
/*     */     final Operators.DeferredSubscription otherArbiter;
/*     */     
/*     */     final Sinks.Many<Long> signaller;
/*     */     
/*     */     final CorePublisher<? extends T> source;
/*     */     
/*     */     volatile int wip;
/* 106 */     static final AtomicIntegerFieldUpdater<RepeatWhenMainSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(RepeatWhenMainSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     Context context;
/*     */     
/*     */     long produced;
/*     */ 
/*     */     
/*     */     RepeatWhenMainSubscriber(CoreSubscriber<? super T> actual, Sinks.Many<Long> signaller, CorePublisher<? extends T> source) {
/* 115 */       super(actual);
/* 116 */       this.signaller = signaller;
/* 117 */       this.source = source;
/* 118 */       this.otherArbiter = new Operators.DeferredSubscription();
/* 119 */       this.context = actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 124 */       return this.context;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 129 */       return Stream.of(new Scannable[] { Scannable.from(this.signaller), this.otherArbiter });
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 134 */       if (!this.cancelled) {
/* 135 */         this.otherArbiter.cancel();
/* 136 */         super.cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 142 */       this.actual.onNext(t);
/*     */       
/* 144 */       this.produced++;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 149 */       this.otherArbiter.cancel();
/*     */       
/* 151 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 156 */       long p = this.produced;
/* 157 */       if (p != 0L) {
/* 158 */         this.produced = 0L;
/* 159 */         produced(p);
/*     */       } 
/*     */       
/* 162 */       this.signaller.emitNext(Long.valueOf(p), Sinks.EmitFailureHandler.FAIL_FAST);
/*     */       
/* 164 */       this.otherArbiter.request(1L);
/*     */     }
/*     */     
/*     */     void setWhen(Subscription w) {
/* 168 */       this.otherArbiter.set(w);
/*     */     }
/*     */     
/*     */     void resubscribe(Object trigger) {
/* 172 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         do {
/* 174 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 180 */           if (trigger instanceof ContextView) {
/* 181 */             this.context = this.context.putAll((ContextView)trigger);
/*     */           }
/*     */           
/* 184 */           this.source.subscribe(this);
/*     */         
/*     */         }
/* 187 */         while (WIP.decrementAndGet(this) != 0);
/*     */       }
/*     */     }
/*     */     
/*     */     void whenError(Throwable e) {
/* 192 */       super.cancel();
/*     */       
/* 194 */       this.actual.onError(e);
/*     */     }
/*     */     
/*     */     void whenComplete() {
/* 198 */       super.cancel();
/*     */       
/* 200 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 205 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 206 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class RepeatWhenOtherSubscriber
/*     */     extends Flux<Long>
/*     */     implements InnerConsumer<Object>, OptimizableOperator<Long, Long>
/*     */   {
/*     */     FluxRepeatWhen.RepeatWhenMainSubscriber<?> main;
/* 215 */     final Sinks.Many<Long> completionSignal = Sinks.many().multicast().onBackpressureBuffer();
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 219 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 225 */       if (key == Scannable.Attr.PARENT) return this.main.otherArbiter; 
/* 226 */       if (key == Scannable.Attr.ACTUAL) return this.main; 
/* 227 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 229 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 234 */       this.main.setWhen(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 239 */       this.main.resubscribe(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 244 */       this.main.whenError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 249 */       this.main.whenComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super Long> actual) {
/* 254 */       this.completionSignal.asFlux().subscribe(actual);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Long> subscribeOrReturn(CoreSubscriber<? super Long> actual) {
/* 259 */       return actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Flux<Long> source() {
/* 264 */       return this.completionSignal.asFlux();
/*     */     }
/*     */ 
/*     */     
/*     */     public OptimizableOperator<?, ? extends Long> nextOptimizableSource() {
/* 269 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxRepeatWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */