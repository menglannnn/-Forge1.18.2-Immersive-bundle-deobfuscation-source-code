/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxCallable<T>
/*    */   extends Flux<T>
/*    */   implements Callable<T>, Fuseable, SourceProducer<T>
/*    */ {
/*    */   final Callable<T> callable;
/*    */   
/*    */   FluxCallable(Callable<T> callable) {
/* 35 */     this.callable = callable;
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 40 */     Operators.MonoSubscriber<T, T> wrapper = new Operators.MonoSubscriber<>(actual);
/* 41 */     actual.onSubscribe(wrapper);
/*    */     
/*    */     try {
/* 44 */       T v = this.callable.call();
/* 45 */       if (v == null) {
/* 46 */         wrapper.onComplete();
/*    */       } else {
/*    */         
/* 49 */         wrapper.complete(v);
/*    */       }
/*    */     
/* 52 */     } catch (Throwable ex) {
/* 53 */       actual.onError(Operators.onOperatorError(ex, actual.currentContext()));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T call() throws Exception {
/* 60 */     return this.callable.call();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 65 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxCallable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */