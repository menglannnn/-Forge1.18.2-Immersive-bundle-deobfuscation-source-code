/*       */ package reactor.core.publisher;
/*       */ 
/*       */ import java.time.Duration;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Collection;
/*       */ import java.util.Comparator;
/*       */ import java.util.HashMap;
/*       */ import java.util.List;
/*       */ import java.util.Map;
/*       */ import java.util.NoSuchElementException;
/*       */ import java.util.Objects;
/*       */ import java.util.Queue;
/*       */ import java.util.Set;
/*       */ import java.util.concurrent.Callable;
/*       */ import java.util.concurrent.TimeUnit;
/*       */ import java.util.function.BiConsumer;
/*       */ import java.util.function.BiFunction;
/*       */ import java.util.function.BiPredicate;
/*       */ import java.util.function.BooleanSupplier;
/*       */ import java.util.function.Consumer;
/*       */ import java.util.function.Function;
/*       */ import java.util.function.LongConsumer;
/*       */ import java.util.function.Predicate;
/*       */ import java.util.function.Supplier;
/*       */ import java.util.logging.Level;
/*       */ import java.util.stream.Collector;
/*       */ import java.util.stream.Stream;
/*       */ import org.reactivestreams.Publisher;
/*       */ import org.reactivestreams.Subscriber;
/*       */ import org.reactivestreams.Subscription;
/*       */ import reactor.core.CorePublisher;
/*       */ import reactor.core.CoreSubscriber;
/*       */ import reactor.core.Disposable;
/*       */ import reactor.core.Exceptions;
/*       */ import reactor.core.Fuseable;
/*       */ import reactor.core.scheduler.Scheduler;
/*       */ import reactor.core.scheduler.Schedulers;
/*       */ import reactor.util.Logger;
/*       */ import reactor.util.Metrics;
/*       */ import reactor.util.annotation.Nullable;
/*       */ import reactor.util.concurrent.Queues;
/*       */ import reactor.util.context.Context;
/*       */ import reactor.util.context.ContextView;
/*       */ import reactor.util.function.Tuple2;
/*       */ import reactor.util.function.Tuple3;
/*       */ import reactor.util.function.Tuple4;
/*       */ import reactor.util.function.Tuple5;
/*       */ import reactor.util.function.Tuple6;
/*       */ import reactor.util.function.Tuple7;
/*       */ import reactor.util.function.Tuple8;
/*       */ import reactor.util.function.Tuples;
/*       */ import reactor.util.retry.Retry;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ public abstract class Flux<T>
/*       */   implements CorePublisher<T>
/*       */ {
/*       */   @SafeVarargs
/*       */   public static <T, V> Flux<V> combineLatest(Function<Object[], V> combinator, Publisher<? extends T>... sources) {
/*   145 */     return combineLatest(combinator, Queues.XS_BUFFER_SIZE, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T, V> Flux<V> combineLatest(Function<Object[], V> combinator, int prefetch, Publisher<? extends T>... sources) {
/*   170 */     if (sources.length == 0) {
/*   171 */       return empty();
/*       */     }
/*       */     
/*   174 */     if (sources.length == 1) {
/*   175 */       Publisher<? extends T> source = sources[0];
/*   176 */       if (source instanceof Fuseable) {
/*   177 */         return onAssembly(new FluxMapFuseable<>(from(source), v -> combinator.apply(new Object[] { v })));
/*       */       }
/*       */       
/*   180 */       return onAssembly(new FluxMap<>(from(source), v -> combinator.apply(new Object[] { v })));
/*       */     } 
/*       */ 
/*       */     
/*   184 */     return onAssembly(new FluxCombineLatest<>(sources, combinator, 
/*   185 */           Queues.get(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, BiFunction<? super T1, ? super T2, ? extends V> combinator) {
/*   212 */     return combineLatest(tuple -> combinator.apply(tuple[0], tuple[1]), (Publisher<?>[])new Publisher[] { source1, source2 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Function<Object[], V> combinator) {
/*   241 */     return combineLatest(combinator, (Publisher<?>[])new Publisher[] { source1, source2, source3 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Function<Object[], V> combinator) {
/*   273 */     return combineLatest(combinator, (Publisher<?>[])new Publisher[] { source1, source2, source3, source4 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Function<Object[], V> combinator) {
/*   308 */     return combineLatest(combinator, (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, T6, V> Flux<V> combineLatest(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Publisher<? extends T6> source6, Function<Object[], V> combinator) {
/*   346 */     return combineLatest(combinator, (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5, source6 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, V> Flux<V> combineLatest(Iterable<? extends Publisher<? extends T>> sources, Function<Object[], V> combinator) {
/*   370 */     return combineLatest(sources, Queues.XS_BUFFER_SIZE, combinator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, V> Flux<V> combineLatest(Iterable<? extends Publisher<? extends T>> sources, int prefetch, Function<Object[], V> combinator) {
/*   397 */     return onAssembly(new FluxCombineLatest<>(sources, combinator, 
/*       */           
/*   399 */           Queues.get(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concat(Iterable<? extends Publisher<? extends T>> sources) {
/*   419 */     return onAssembly(new FluxConcatIterable<>(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public final Flux<T> concatWithValues(T... values) {
/*   433 */     return concatWith((Publisher<? extends T>)fromArray(values));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concat(Publisher<? extends Publisher<? extends T>> sources) {
/*   455 */     return concat(sources, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concat(Publisher<? extends Publisher<? extends T>> sources, int prefetch) {
/*   478 */     return from(sources).concatMap(identityFunction(), prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> concat(Publisher<? extends T>... sources) {
/*   499 */     return onAssembly(new FluxConcatArray<>(false, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concatDelayError(Publisher<? extends Publisher<? extends T>> sources) {
/*   522 */     return concatDelayError(sources, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concatDelayError(Publisher<? extends Publisher<? extends T>> sources, int prefetch) {
/*   545 */     return from(sources).concatMapDelayError(identityFunction(), prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> concatDelayError(Publisher<? extends Publisher<? extends T>> sources, boolean delayUntilEnd, int prefetch) {
/*   575 */     return from(sources).concatMapDelayError(identityFunction(), delayUntilEnd, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> concatDelayError(Publisher<? extends T>... sources) {
/*   599 */     return onAssembly(new FluxConcatArray<>(true, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> create(Consumer<? super FluxSink<T>> emitter) {
/*   643 */     return create(emitter, FluxSink.OverflowStrategy.BUFFER);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> create(Consumer<? super FluxSink<T>> emitter, FluxSink.OverflowStrategy backpressure) {
/*   691 */     return onAssembly(new FluxCreate<>(emitter, backpressure, FluxCreate.CreateMode.PUSH_PULL));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> push(Consumer<? super FluxSink<T>> emitter) {
/*   735 */     return push(emitter, FluxSink.OverflowStrategy.BUFFER);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> push(Consumer<? super FluxSink<T>> emitter, FluxSink.OverflowStrategy backpressure) {
/*   783 */     return onAssembly(new FluxCreate<>(emitter, backpressure, FluxCreate.CreateMode.PUSH_ONLY));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> defer(Supplier<? extends Publisher<T>> supplier) {
/*   803 */     return onAssembly(new FluxDefer<>(supplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static <T> Flux<T> deferWithContext(Function<Context, ? extends Publisher<T>> contextualPublisherFactory) {
/*   825 */     return deferContextual(view -> (Publisher)contextualPublisherFactory.apply(Context.of(view)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> deferContextual(Function<ContextView, ? extends Publisher<T>> contextualPublisherFactory) {
/*   845 */     return onAssembly(new FluxDeferContextual<>(contextualPublisherFactory));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> empty() {
/*   858 */     return FluxEmpty.instance();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> error(Throwable error) {
/*   873 */     return error(error, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> error(Supplier<? extends Throwable> errorSupplier) {
/*   889 */     return onAssembly(new FluxErrorSupplied<>(errorSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <O> Flux<O> error(Throwable throwable, boolean whenRequested) {
/*   906 */     if (whenRequested) {
/*   907 */       return onAssembly(new FluxErrorOnRequest<>(throwable));
/*       */     }
/*       */     
/*   910 */     return onAssembly(new FluxError<>(throwable));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   @Deprecated
/*       */   public static <I> Flux<I> first(Publisher<? extends I>... sources) {
/*   931 */     return firstWithSignal(sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static <I> Flux<I> first(Iterable<? extends Publisher<? extends I>> sources) {
/*   950 */     return firstWithSignal(sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> firstWithSignal(Publisher<? extends I>... sources) {
/*   968 */     return onAssembly(new FluxFirstWithSignal<>(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> firstWithSignal(Iterable<? extends Publisher<? extends I>> sources) {
/*   985 */     return onAssembly(new FluxFirstWithSignal<>(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> firstWithValue(Iterable<? extends Publisher<? extends I>> sources) {
/*  1018 */     return onAssembly(new FluxFirstWithValue<>(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> firstWithValue(Publisher<? extends I> first, Publisher<? extends I>... others) {
/*  1055 */     if (first instanceof FluxFirstWithValue) {
/*       */       
/*  1057 */       FluxFirstWithValue<I> orPublisher = (FluxFirstWithValue)first;
/*       */       
/*  1059 */       FluxFirstWithValue<I> result = orPublisher.firstValuedAdditionalSources(others);
/*  1060 */       if (result != null) {
/*  1061 */         return result;
/*       */       }
/*       */     } 
/*  1064 */     return onAssembly(new FluxFirstWithValue<>(first, others));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> from(Publisher<? extends T> source) {
/*  1082 */     if (source instanceof Flux) {
/*       */       
/*  1084 */       Flux<T> casted = (Flux)source;
/*  1085 */       return casted;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  1090 */     return onAssembly(wrap(source));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> fromArray(T[] array) {
/*  1104 */     if (array.length == 0) {
/*  1105 */       return empty();
/*       */     }
/*  1107 */     if (array.length == 1) {
/*  1108 */       return just(array[0]);
/*       */     }
/*  1110 */     return onAssembly(new FluxArray<>(array));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> fromIterable(Iterable<? extends T> it) {
/*  1136 */     return onAssembly(new FluxIterable<>(it));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> fromStream(Stream<? extends T> s) {
/*  1158 */     Objects.requireNonNull(s, "Stream s must be provided");
/*  1159 */     return onAssembly(new FluxStream<>(() -> s));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> fromStream(Supplier<Stream<? extends T>> streamSupplier) {
/*  1181 */     return onAssembly(new FluxStream<>(streamSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> generate(Consumer<SynchronousSink<T>> generator) {
/*  1197 */     Objects.requireNonNull(generator, "generator");
/*  1198 */     return onAssembly(new FluxGenerate<>(generator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, S> Flux<T> generate(Callable<S> stateSupplier, BiFunction<S, SynchronousSink<T>, S> generator) {
/*  1216 */     return onAssembly(new FluxGenerate<>(stateSupplier, generator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, S> Flux<T> generate(Callable<S> stateSupplier, BiFunction<S, SynchronousSink<T>, S> generator, Consumer<? super S> stateConsumer) {
/*  1239 */     return onAssembly(new FluxGenerate<>(stateSupplier, generator, stateConsumer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Long> interval(Duration period) {
/*  1258 */     return interval(period, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Long> interval(Duration delay, Duration period) {
/*  1279 */     return interval(delay, period, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Long> interval(Duration period, Scheduler timer) {
/*  1298 */     return interval(period, period, timer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Long> interval(Duration delay, Duration period, Scheduler timer) {
/*  1318 */     return onAssembly(new FluxInterval(delay.toNanos(), period.toNanos(), TimeUnit.NANOSECONDS, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> just(T... data) {
/*  1333 */     return fromArray(data);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> just(T data) {
/*  1347 */     return onAssembly(new FluxJust<>(data));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> merge(Publisher<? extends Publisher<? extends T>> source) {
/*  1369 */     return merge(source, Queues.SMALL_BUFFER_SIZE, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> merge(Publisher<? extends Publisher<? extends T>> source, int concurrency) {
/*  1394 */     return merge(source, concurrency, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> merge(Publisher<? extends Publisher<? extends T>> source, int concurrency, int prefetch) {
/*  1418 */     return onAssembly(new FluxFlatMap<>(
/*  1419 */           from(source), 
/*  1420 */           (Function)identityFunction(), false, concurrency, 
/*       */ 
/*       */           
/*  1423 */           Queues.get(concurrency), prefetch, 
/*       */           
/*  1425 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> merge(Iterable<? extends Publisher<? extends I>> sources) {
/*  1447 */     return merge((Publisher<? extends Publisher<? extends I>>)fromIterable(sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> merge(Publisher<? extends I>... sources) {
/*  1469 */     return merge(Queues.XS_BUFFER_SIZE, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> merge(int prefetch, Publisher<? extends I>... sources) {
/*  1492 */     return merge(prefetch, false, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> mergeDelayError(int prefetch, Publisher<? extends I>... sources) {
/*  1516 */     return merge(prefetch, true, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I extends Comparable<? super I>> Flux<I> mergePriority(Publisher<? extends I>... sources) {
/*  1539 */     return mergePriority(Queues.SMALL_BUFFER_SIZE, Comparator.naturalOrder(), sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergePriority(Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1564 */     return mergePriority(Queues.SMALL_BUFFER_SIZE, comparator, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergePriority(int prefetch, Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1591 */     if (sources.length == 0) {
/*  1592 */       return empty();
/*       */     }
/*  1594 */     if (sources.length == 1) {
/*  1595 */       return from(sources[0]);
/*       */     }
/*  1597 */     return onAssembly(new FluxMergeComparing<>(prefetch, comparator, false, false, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergePriorityDelayError(int prefetch, Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1626 */     if (sources.length == 0) {
/*  1627 */       return empty();
/*       */     }
/*  1629 */     if (sources.length == 1) {
/*  1630 */       return from(sources[0]);
/*       */     }
/*  1632 */     return onAssembly(new FluxMergeComparing<>(prefetch, comparator, true, false, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I extends Comparable<? super I>> Flux<I> mergeComparing(Publisher<? extends I>... sources) {
/*  1651 */     return mergeComparing(Queues.SMALL_BUFFER_SIZE, Comparator.naturalOrder(), sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergeComparing(Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1673 */     return mergeComparing(Queues.SMALL_BUFFER_SIZE, comparator, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergeComparing(int prefetch, Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1697 */     if (sources.length == 0) {
/*  1698 */       return empty();
/*       */     }
/*  1700 */     if (sources.length == 1) {
/*  1701 */       return from(sources[0]);
/*       */     }
/*  1703 */     return onAssembly(new FluxMergeComparing<>(prefetch, comparator, false, true, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <T> Flux<T> mergeComparingDelayError(int prefetch, Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1729 */     if (sources.length == 0) {
/*  1730 */       return empty();
/*       */     }
/*  1732 */     if (sources.length == 1) {
/*  1733 */       return from(sources[0]);
/*       */     }
/*  1735 */     return onAssembly(new FluxMergeComparing<>(prefetch, comparator, true, true, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   @Deprecated
/*       */   public static <I extends Comparable<? super I>> Flux<I> mergeOrdered(Publisher<? extends I>... sources) {
/*  1761 */     return mergeOrdered(Queues.SMALL_BUFFER_SIZE, Comparator.naturalOrder(), sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   @Deprecated
/*       */   public static <T> Flux<T> mergeOrdered(Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1789 */     return mergeOrdered(Queues.SMALL_BUFFER_SIZE, comparator, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   @Deprecated
/*       */   public static <T> Flux<T> mergeOrdered(int prefetch, Comparator<? super T> comparator, Publisher<? extends T>... sources) {
/*  1819 */     if (sources.length == 0) {
/*  1820 */       return empty();
/*       */     }
/*  1822 */     if (sources.length == 1) {
/*  1823 */       return from(sources[0]);
/*       */     }
/*  1825 */     return onAssembly(new FluxMergeComparing<>(prefetch, comparator, true, true, sources));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> mergeSequential(Publisher<? extends Publisher<? extends T>> sources) {
/*  1842 */     return mergeSequential(sources, false, Queues.SMALL_BUFFER_SIZE, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> mergeSequential(Publisher<? extends Publisher<? extends T>> sources, int maxConcurrency, int prefetch) {
/*  1863 */     return mergeSequential(sources, false, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> mergeSequentialDelayError(Publisher<? extends Publisher<? extends T>> sources, int maxConcurrency, int prefetch) {
/*  1884 */     return mergeSequential(sources, true, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> mergeSequential(Publisher<? extends I>... sources) {
/*  1901 */     return mergeSequential(Queues.XS_BUFFER_SIZE, false, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> mergeSequential(int prefetch, Publisher<? extends I>... sources) {
/*  1919 */     return mergeSequential(prefetch, false, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I> Flux<I> mergeSequentialDelayError(int prefetch, Publisher<? extends I>... sources) {
/*  1939 */     return mergeSequential(prefetch, true, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> mergeSequential(Iterable<? extends Publisher<? extends I>> sources) {
/*  1955 */     return mergeSequential(sources, false, Queues.SMALL_BUFFER_SIZE, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> mergeSequential(Iterable<? extends Publisher<? extends I>> sources, int maxConcurrency, int prefetch) {
/*  1976 */     return mergeSequential(sources, false, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <I> Flux<I> mergeSequentialDelayError(Iterable<? extends Publisher<? extends I>> sources, int maxConcurrency, int prefetch) {
/*  1998 */     return mergeSequential(sources, true, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> never() {
/*  2011 */     return FluxNever.instance();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Flux<Integer> range(int start, int count) {
/*  2027 */     if (count == 1) {
/*  2028 */       return just(Integer.valueOf(start));
/*       */     }
/*  2030 */     if (count == 0) {
/*  2031 */       return empty();
/*       */     }
/*  2033 */     return onAssembly(new FluxRange(start, count));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T> Flux<T> switchOnNext(Publisher<? extends Publisher<? extends T>> mergedPublishers) {
/*  2052 */     return switchOnNext(mergedPublishers, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public static <T> Flux<T> switchOnNext(Publisher<? extends Publisher<? extends T>> mergedPublishers, int prefetch) {
/*  2077 */     if (prefetch == 0) {
/*  2078 */       return onAssembly(new FluxSwitchMapNoPrefetch<>(from(mergedPublishers), 
/*  2079 */             (Function)identityFunction()));
/*       */     }
/*  2081 */     return onAssembly(new FluxSwitchMap<>(from(mergedPublishers), 
/*  2082 */           (Function)identityFunction(), 
/*  2083 */           Queues.unbounded(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, D> Flux<T> using(Callable<? extends D> resourceSupplier, Function<? super D, ? extends Publisher<? extends T>> sourceSupplier, Consumer<? super D> resourceCleanup) {
/*  2111 */     return using(resourceSupplier, sourceSupplier, resourceCleanup, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, D> Flux<T> using(Callable<? extends D> resourceSupplier, Function<? super D, ? extends Publisher<? extends T>> sourceSupplier, Consumer<? super D> resourceCleanup, boolean eager) {
/*  2140 */     return onAssembly(new FluxUsing<>(resourceSupplier, sourceSupplier, resourceCleanup, eager));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, D> Flux<T> usingWhen(Publisher<D> resourceSupplier, Function<? super D, ? extends Publisher<? extends T>> resourceClosure, Function<? super D, ? extends Publisher<?>> asyncCleanup) {
/*  2178 */     return usingWhen(resourceSupplier, resourceClosure, asyncCleanup, (resource, error) -> (Publisher)asyncCleanup.apply(resource), asyncCleanup);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T, D> Flux<T> usingWhen(Publisher<D> resourceSupplier, Function<? super D, ? extends Publisher<? extends T>> resourceClosure, Function<? super D, ? extends Publisher<?>> asyncComplete, BiFunction<? super D, ? super Throwable, ? extends Publisher<?>> asyncError, Function<? super D, ? extends Publisher<?>> asyncCancel) {
/*  2237 */     return onAssembly(new FluxUsingWhen<>(resourceSupplier, resourceClosure, asyncComplete, asyncError, asyncCancel));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, O> Flux<O> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, BiFunction<? super T1, ? super T2, ? extends O> combinator) {
/*  2264 */     return onAssembly(new FluxZip<>(source1, source2, combinator, 
/*       */ 
/*       */           
/*  2267 */           Queues.xs(), Queues.XS_BUFFER_SIZE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2> Flux<Tuple2<T1, T2>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2) {
/*  2288 */     return zip(source1, source2, (BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3> Flux<Tuple3<T1, T2, T3>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3) {
/*  2312 */     return zip(Tuples.fn3(), (Publisher<?>[])new Publisher[] { source1, source2, source3 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4> Flux<Tuple4<T1, T2, T3, T4>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4) {
/*  2339 */     return zip(Tuples.fn4(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5> Flux<Tuple5<T1, T2, T3, T4, T5>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5) {
/*  2369 */     return zip(Tuples.fn5(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, T6> Flux<Tuple6<T1, T2, T3, T4, T5, T6>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Publisher<? extends T6> source6) {
/*  2402 */     return zip(Tuples.fn6(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5, source6 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, T6, T7> Flux<Tuple7<T1, T2, T3, T4, T5, T6, T7>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Publisher<? extends T6> source6, Publisher<? extends T7> source7) {
/*  2438 */     return zip(Tuples.fn7(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5, source6, source7 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <T1, T2, T3, T4, T5, T6, T7, T8> Flux<Tuple8<T1, T2, T3, T4, T5, T6, T7, T8>> zip(Publisher<? extends T1> source1, Publisher<? extends T2> source2, Publisher<? extends T3> source3, Publisher<? extends T4> source4, Publisher<? extends T5> source5, Publisher<? extends T6> source6, Publisher<? extends T7> source7, Publisher<? extends T8> source8) {
/*  2477 */     return zip(Tuples.fn8(), (Publisher<?>[])new Publisher[] { source1, source2, source3, source4, source5, source6, source7, source8 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <O> Flux<O> zip(Iterable<? extends Publisher<?>> sources, Function<? super Object[], ? extends O> combinator) {
/*  2503 */     return zip(sources, Queues.XS_BUFFER_SIZE, combinator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <O> Flux<O> zip(Iterable<? extends Publisher<?>> sources, int prefetch, Function<? super Object[], ? extends O> combinator) {
/*  2531 */     return onAssembly(new FluxZip<>(sources, combinator, 
/*       */           
/*  2533 */           Queues.get(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I, O> Flux<O> zip(Function<? super Object[], ? extends O> combinator, Publisher<? extends I>... sources) {
/*  2558 */     return zip(combinator, Queues.XS_BUFFER_SIZE, sources);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public static <I, O> Flux<O> zip(Function<? super Object[], ? extends O> combinator, int prefetch, Publisher<? extends I>... sources) {
/*  2585 */     if (sources.length == 0) {
/*  2586 */       return empty();
/*       */     }
/*  2588 */     if (sources.length == 1) {
/*  2589 */       Publisher<? extends I> source = sources[0];
/*  2590 */       if (source instanceof Fuseable) {
/*  2591 */         return onAssembly(new FluxMapFuseable<>(from(source), v -> combinator.apply(new Object[] { v })));
/*       */       }
/*       */       
/*  2594 */       return onAssembly(new FluxMap<>(from(source), v -> combinator.apply(new Object[] { v })));
/*       */     } 
/*       */ 
/*       */     
/*  2598 */     return onAssembly(new FluxZip<>(sources, combinator, 
/*       */           
/*  2600 */           Queues.get(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static <TUPLE extends Tuple2, V> Flux<V> zip(Publisher<? extends Publisher<?>> sources, final Function<? super TUPLE, ? extends V> combinator) {
/*  2630 */     return onAssembly((new FluxBuffer<>(from(sources), 2147483647, (Supplier)listSupplier()))
/*  2631 */         .flatMap(new Function<List<? extends Publisher<?>>, Publisher<V>>()
/*       */           {
/*       */             public Publisher<V> apply(List<? extends Publisher<?>> publishers) {
/*  2634 */               return (Publisher)Flux.zip(Tuples.fnAny(combinator), (Publisher<?>[])publishers
/*  2635 */                   .<Publisher>toArray(
/*  2636 */                     new Publisher[publishers.size()]));
/*       */             }
/*       */           }));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Boolean> all(Predicate<? super T> predicate) {
/*  2658 */     return Mono.onAssembly(new MonoAll<>(this, predicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Boolean> any(Predicate<? super T> predicate) {
/*  2677 */     return Mono.onAssembly(new MonoAny<>(this, predicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <P> P as(Function<? super Flux<T>, P> transformer) {
/*  2694 */     return transformer.apply(this);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Nullable
/*       */   public final T blockFirst() {
/*  2714 */     BlockingFirstSubscriber<T> subscriber = new BlockingFirstSubscriber<>();
/*  2715 */     subscribe((Subscriber<? super T>)subscriber);
/*  2716 */     return subscriber.blockingGet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Nullable
/*       */   public final T blockFirst(Duration timeout) {
/*  2737 */     BlockingFirstSubscriber<T> subscriber = new BlockingFirstSubscriber<>();
/*  2738 */     subscribe((Subscriber<? super T>)subscriber);
/*  2739 */     return subscriber.blockingGet(timeout.toNanos(), TimeUnit.NANOSECONDS);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Nullable
/*       */   public final T blockLast() {
/*  2759 */     BlockingLastSubscriber<T> subscriber = new BlockingLastSubscriber<>();
/*  2760 */     subscribe((Subscriber<? super T>)subscriber);
/*  2761 */     return subscriber.blockingGet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Nullable
/*       */   public final T blockLast(Duration timeout) {
/*  2783 */     BlockingLastSubscriber<T> subscriber = new BlockingLastSubscriber<>();
/*  2784 */     subscribe((Subscriber<? super T>)subscriber);
/*  2785 */     return subscriber.blockingGet(timeout.toNanos(), TimeUnit.NANOSECONDS);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer() {
/*  2800 */     return buffer(2147483647);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(int maxSize) {
/*  2817 */     return buffer(maxSize, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> buffer(int maxSize, Supplier<C> bufferSupplier) {
/*  2837 */     return onAssembly(new FluxBuffer<>(this, maxSize, bufferSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(int maxSize, int skip) {
/*  2869 */     return buffer(maxSize, skip, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> buffer(int maxSize, int skip, Supplier<C> bufferSupplier) {
/*  2905 */     return onAssembly(new FluxBuffer<>(this, maxSize, skip, bufferSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Publisher<?> other) {
/*  2921 */     return buffer(other, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> buffer(Publisher<?> other, Supplier<C> bufferSupplier) {
/*  2941 */     return onAssembly(new FluxBufferBoundary<>(this, other, bufferSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Duration bufferingTimespan) {
/*  2957 */     return buffer(bufferingTimespan, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Duration bufferingTimespan, Duration openBufferEvery) {
/*  2987 */     return buffer(bufferingTimespan, openBufferEvery, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Duration bufferingTimespan, Scheduler timer) {
/*  3004 */     return buffer((Publisher<?>)interval(bufferingTimespan, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> buffer(Duration bufferingTimespan, Duration openBufferEvery, Scheduler timer) {
/*  3036 */     if (bufferingTimespan.equals(openBufferEvery)) {
/*  3037 */       return buffer(bufferingTimespan, timer);
/*       */     }
/*  3039 */     return bufferWhen((Publisher<Long>)interval(Duration.ZERO, openBufferEvery, timer), aLong -> Mono.delay(bufferingTimespan, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferTimeout(int maxSize, Duration maxTime) {
/*  3058 */     return bufferTimeout(maxSize, maxTime, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> bufferTimeout(int maxSize, Duration maxTime, Supplier<C> bufferSupplier) {
/*  3078 */     return bufferTimeout(maxSize, maxTime, Schedulers.parallel(), bufferSupplier);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferTimeout(int maxSize, Duration maxTime, Scheduler timer) {
/*  3098 */     return bufferTimeout(maxSize, maxTime, timer, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <C extends Collection<? super T>> Flux<C> bufferTimeout(int maxSize, Duration maxTime, Scheduler timer, Supplier<C> bufferSupplier) {
/*  3120 */     return onAssembly(new FluxBufferTimeout<>(this, maxSize, maxTime.toNanos(), TimeUnit.NANOSECONDS, timer, bufferSupplier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferUntil(Predicate<? super T> predicate) {
/*  3142 */     return onAssembly(new FluxBufferPredicate<>(this, predicate, 
/*  3143 */           listSupplier(), FluxBufferPredicate.Mode.UNTIL));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferUntil(Predicate<? super T> predicate, boolean cutBefore) {
/*  3168 */     return onAssembly(new FluxBufferPredicate<>(this, predicate, listSupplier(), cutBefore ? FluxBufferPredicate.Mode.UNTIL_CUT_BEFORE : FluxBufferPredicate.Mode.UNTIL));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<List<T>> bufferUntilChanged() {
/*  3185 */     return bufferUntilChanged(identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<List<T>> bufferUntilChanged(Function<? super T, ? extends V> keySelector) {
/*  3202 */     return bufferUntilChanged(keySelector, equalPredicate());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<List<T>> bufferUntilChanged(Function<? super T, ? extends V> keySelector, BiPredicate<? super V, ? super V> keyComparator) {
/*  3221 */     return defer(() -> bufferUntil(new FluxBufferPredicate.ChangedPredicate<>(keySelector, keyComparator), true));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<List<T>> bufferWhile(Predicate<? super T> predicate) {
/*  3246 */     return onAssembly(new FluxBufferPredicate<>(this, predicate, 
/*  3247 */           listSupplier(), FluxBufferPredicate.Mode.WHILE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V> Flux<List<T>> bufferWhen(Publisher<U> bucketOpening, Function<? super U, ? extends Publisher<V>> closeSelector) {
/*  3278 */     return bufferWhen(bucketOpening, closeSelector, listSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V, C extends Collection<? super T>> Flux<C> bufferWhen(Publisher<U> bucketOpening, Function<? super U, ? extends Publisher<V>> closeSelector, Supplier<C> bufferSupplier) {
/*  3309 */     return onAssembly(new FluxBufferWhen<>(this, bucketOpening, closeSelector, bufferSupplier, 
/*  3310 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache() {
/*  3323 */     return cache(2147483647);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(int history) {
/*  3342 */     return replay(history).autoConnect();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(Duration ttl) {
/*  3359 */     return cache(ttl, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(Duration ttl, Scheduler timer) {
/*  3377 */     return cache(2147483647, ttl, timer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(int history, Duration ttl) {
/*  3396 */     return cache(history, ttl, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cache(int history, Duration ttl, Scheduler timer) {
/*  3417 */     return replay(history, ttl, timer).autoConnect();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E> Flux<E> cast(Class<E> clazz) {
/*  3432 */     Objects.requireNonNull(clazz, "clazz");
/*  3433 */     return map(clazz::cast);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> cancelOn(Scheduler scheduler) {
/*  3449 */     return onAssembly(new FluxCancelOn<>(this, scheduler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> checkpoint() {
/*  3468 */     return checkpoint(null, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> checkpoint(String description) {
/*  3493 */     return checkpoint(Objects.<String>requireNonNull(description), false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> checkpoint(@Nullable String description, boolean forceStackTrace) {
/*       */     FluxOnAssembly.AssemblySnapshot stacktrace;
/*  3529 */     if (!forceStackTrace) {
/*  3530 */       stacktrace = new FluxOnAssembly.CheckpointLightSnapshot(description);
/*       */     } else {
/*       */       
/*  3533 */       stacktrace = new FluxOnAssembly.CheckpointHeavySnapshot(description, Traces.callSiteSupplierFactory.get());
/*       */     } 
/*       */     
/*  3536 */     return new FluxOnAssembly<>(this, stacktrace);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E> Mono<E> collect(Supplier<E> containerSupplier, BiConsumer<E, ? super T> collector) {
/*  3561 */     return Mono.onAssembly(new MonoCollect<>(this, containerSupplier, collector));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R, A> Mono<R> collect(Collector<? super T, A, ? extends R> collector) {
/*  3588 */     return Mono.onAssembly(new MonoStreamCollector<>(this, collector));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<List<T>> collectList() {
/*  3605 */     if (this instanceof Callable) {
/*  3606 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         T v;
/*  3608 */         Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)this;
/*       */ 
/*       */         
/*       */         try {
/*  3612 */           v = (T)scalarCallable.call();
/*       */         }
/*  3614 */         catch (Exception e) {
/*  3615 */           return Mono.error(Exceptions.unwrap(e));
/*       */         } 
/*  3617 */         return Mono.onAssembly(new MonoCallable<>(() -> {
/*       */                 List<T> list = listSupplier().get();
/*       */                 
/*       */                 if (v != null) {
/*       */                   list.add((T)v);
/*       */                 }
/*       */                 
/*       */                 return list;
/*       */               }));
/*       */       } 
/*  3627 */       Callable<T> thiz = (Callable<T>)this;
/*  3628 */       return Mono.onAssembly(new MonoCallable<>(() -> {
/*       */               List<T> list = listSupplier().get();
/*       */               T u = thiz.call();
/*       */               if (u != null) {
/*       */                 list.add(u);
/*       */               }
/*       */               return list;
/*       */             }));
/*       */     } 
/*  3637 */     return Mono.onAssembly(new MonoCollectList<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K> Mono<Map<K, T>> collectMap(Function<? super T, ? extends K> keyExtractor) {
/*  3661 */     return collectMap(keyExtractor, (Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Mono<Map<K, V>> collectMap(Function<? super T, ? extends K> keyExtractor, Function<? super T, ? extends V> valueExtractor) {
/*  3690 */     return collectMap(keyExtractor, valueExtractor, () -> new HashMap<>());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Mono<Map<K, V>> collectMap(Function<? super T, ? extends K> keyExtractor, Function<? super T, ? extends V> valueExtractor, Supplier<Map<K, V>> mapSupplier) {
/*  3722 */     Objects.requireNonNull(keyExtractor, "Key extractor is null");
/*  3723 */     Objects.requireNonNull(valueExtractor, "Value extractor is null");
/*  3724 */     Objects.requireNonNull(mapSupplier, "Map supplier is null");
/*  3725 */     return collect(mapSupplier, (m, d) -> m.put(keyExtractor.apply(d), valueExtractor.apply(d)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K> Mono<Map<K, Collection<T>>> collectMultimap(Function<? super T, ? extends K> keyExtractor) {
/*  3749 */     return collectMultimap(keyExtractor, (Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Mono<Map<K, Collection<V>>> collectMultimap(Function<? super T, ? extends K> keyExtractor, Function<? super T, ? extends V> valueExtractor) {
/*  3777 */     return collectMultimap(keyExtractor, valueExtractor, () -> new HashMap<>());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Mono<Map<K, Collection<V>>> collectMultimap(Function<? super T, ? extends K> keyExtractor, Function<? super T, ? extends V> valueExtractor, Supplier<Map<K, Collection<V>>> mapSupplier) {
/*  3810 */     Objects.requireNonNull(keyExtractor, "Key extractor is null");
/*  3811 */     Objects.requireNonNull(valueExtractor, "Value extractor is null");
/*  3812 */     Objects.requireNonNull(mapSupplier, "Map supplier is null");
/*  3813 */     return collect(mapSupplier, (m, d) -> {
/*       */           K key = keyExtractor.apply(d);
/*       */           Collection<V> values = m.computeIfAbsent(key, ());
/*       */           values.add(valueExtractor.apply(d));
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<List<T>> collectSortedList() {
/*  3834 */     return collectSortedList(null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<List<T>> collectSortedList(@Nullable Comparator<? super T> comparator) {
/*  3854 */     return collectList().doOnNext(list -> list.sort(comparator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMap(Function<? super T, ? extends Publisher<? extends V>> mapper) {
/*  3892 */     return concatMap(mapper, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMap(Function<? super T, ? extends Publisher<? extends V>> mapper, int prefetch) {
/*  3929 */     if (prefetch == 0) {
/*  3930 */       return onAssembly(new FluxConcatMapNoPrefetch<>(this, mapper, FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */     }
/*  3932 */     return onAssembly(new FluxConcatMap<>(this, mapper, Queues.get(prefetch), prefetch, FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMapDelayError(Function<? super T, ? extends Publisher<? extends V>> mapper) {
/*  3970 */     return concatMapDelayError(mapper, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMapDelayError(Function<? super T, ? extends Publisher<? extends V>> mapper, int prefetch) {
/*  4010 */     return concatMapDelayError(mapper, true, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> concatMapDelayError(Function<? super T, ? extends Publisher<? extends V>> mapper, boolean delayUntilEnd, int prefetch) {
/*  4051 */     FluxConcatMap.ErrorMode errorMode = delayUntilEnd ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.BOUNDARY;
/*  4052 */     if (prefetch == 0) {
/*  4053 */       return onAssembly(new FluxConcatMapNoPrefetch<>(this, mapper, errorMode));
/*       */     }
/*  4055 */     return onAssembly(new FluxConcatMap<>(this, mapper, Queues.get(prefetch), prefetch, errorMode));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> concatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper) {
/*  4094 */     return concatMapIterable(mapper, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> concatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch) {
/*  4136 */     return onAssembly(new FluxFlattenIterable<>(this, mapper, prefetch, 
/*  4137 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> concatWith(Publisher<? extends T> other) {
/*  4150 */     if (this instanceof FluxConcatArray) {
/*       */       
/*  4152 */       FluxConcatArray<T> fluxConcatArray = (FluxConcatArray<T>)this;
/*       */       
/*  4154 */       return fluxConcatArray.concatAdditionalSourceLast(other);
/*       */     } 
/*  4156 */     return concat((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> contextWrite(ContextView contextToAppend) {
/*  4178 */     return contextWrite(c -> c.putAll(contextToAppend));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> contextWrite(Function<Context, Context> contextModifier) {
/*  4202 */     return onAssembly(new FluxContextWrite<>(this, contextModifier));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Long> count() {
/*  4215 */     return Mono.onAssembly(new MonoCount<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> defaultIfEmpty(T defaultV) {
/*  4228 */     return onAssembly(new FluxDefaultIfEmpty<>(this, defaultV));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delayElements(Duration delay) {
/*  4245 */     return delayElements(delay, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delayElements(Duration delay, Scheduler timer) {
/*  4261 */     return delayUntil(d -> Mono.delay(delay, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delaySequence(Duration delay) {
/*  4292 */     return delaySequence(delay, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delaySequence(Duration delay, Scheduler timer) {
/*  4324 */     return onAssembly(new FluxDelaySequence<>(this, delay, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delayUntil(Function<? super T, ? extends Publisher<?>> triggerProvider) {
/*  4347 */     return concatMap(v -> Mono.<Object>just(v).delayUntil(triggerProvider));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delaySubscription(Duration delay) {
/*  4364 */     return delaySubscription(delay, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> delaySubscription(Duration delay, Scheduler timer) {
/*  4380 */     return delaySubscription((Publisher<Long>)Mono.delay(delay, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> delaySubscription(Publisher<U> subscriptionDelay) {
/*  4397 */     return onAssembly(new FluxDelaySubscription<>(this, subscriptionDelay));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <X> Flux<X> dematerialize() {
/*  4417 */     Flux<T> flux = this;
/*  4418 */     return onAssembly(new FluxDematerialize<>((Flux)flux));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> distinct() {
/*  4440 */     return distinct(identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<T> distinct(Function<? super T, ? extends V> keySelector) {
/*  4461 */     return distinct(keySelector, (Supplier)hashSetSupplier());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V, C extends Collection<? super V>> Flux<T> distinct(Function<? super T, ? extends V> keySelector, Supplier<C> distinctCollectionSupplier) {
/*  4489 */     return distinct(keySelector, distinctCollectionSupplier, Collection::add, Collection::clear);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V, C> Flux<T> distinct(Function<? super T, ? extends V> keySelector, Supplier<C> distinctStoreSupplier, BiPredicate<C, V> distinctPredicate, Consumer<C> cleanup) {
/*  4525 */     if (this instanceof Fuseable) {
/*  4526 */       return onAssembly(new FluxDistinctFuseable<>(this, keySelector, distinctStoreSupplier, distinctPredicate, cleanup));
/*       */     }
/*       */     
/*  4529 */     return onAssembly(new FluxDistinct<>(this, keySelector, distinctStoreSupplier, distinctPredicate, cleanup));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> distinctUntilChanged() {
/*  4553 */     return distinctUntilChanged(identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<T> distinctUntilChanged(Function<? super T, ? extends V> keySelector) {
/*  4574 */     return distinctUntilChanged(keySelector, equalPredicate());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<T> distinctUntilChanged(Function<? super T, ? extends V> keySelector, BiPredicate<? super V, ? super V> keyComparator) {
/*  4598 */     return onAssembly(new FluxDistinctUntilChanged<>(this, keySelector, keyComparator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doAfterTerminate(Runnable afterTerminate) {
/*  4615 */     Objects.requireNonNull(afterTerminate, "afterTerminate");
/*  4616 */     return doOnSignal(this, null, null, null, null, afterTerminate, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnCancel(Runnable onCancel) {
/*  4632 */     Objects.requireNonNull(onCancel, "onCancel");
/*  4633 */     return doOnSignal(this, null, null, null, null, null, null, onCancel);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnComplete(Runnable onComplete) {
/*  4649 */     Objects.requireNonNull(onComplete, "onComplete");
/*  4650 */     return doOnSignal(this, null, null, null, onComplete, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<T> doOnDiscard(Class<R> type, Consumer<? super R> discardHook) {
/*  4678 */     return subscriberContext(Operators.discardLocalAdapter(type, discardHook));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnEach(Consumer<? super Signal<T>> signalConsumer) {
/*  4704 */     if (this instanceof Fuseable) {
/*  4705 */       return onAssembly(new FluxDoOnEachFuseable<>(this, signalConsumer));
/*       */     }
/*  4707 */     return onAssembly(new FluxDoOnEach<>(this, signalConsumer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnError(Consumer<? super Throwable> onError) {
/*  4723 */     Objects.requireNonNull(onError, "onError");
/*  4724 */     return doOnSignal(this, null, null, onError, null, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> doOnError(Class<E> exceptionType, Consumer<? super E> onError) {
/*  4744 */     Objects.requireNonNull(exceptionType, "type");
/*       */     
/*  4746 */     Consumer<Throwable> handler = (Consumer)onError;
/*  4747 */     return doOnError(exceptionType::isInstance, handler);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnError(Predicate<? super Throwable> predicate, Consumer<? super Throwable> onError) {
/*  4766 */     Objects.requireNonNull(predicate, "predicate");
/*  4767 */     return doOnError(t -> {
/*       */           if (predicate.test(t)) {
/*       */             onError.accept(t);
/*       */           }
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnNext(Consumer<? super T> onNext) {
/*  4793 */     Objects.requireNonNull(onNext, "onNext");
/*  4794 */     return doOnSignal(this, null, onNext, null, null, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnRequest(LongConsumer consumer) {
/*  4815 */     Objects.requireNonNull(consumer, "consumer");
/*  4816 */     return doOnSignal(this, null, null, null, null, null, consumer, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnSubscribe(Consumer<? super Subscription> onSubscribe) {
/*  4839 */     Objects.requireNonNull(onSubscribe, "onSubscribe");
/*  4840 */     return doOnSignal(this, onSubscribe, null, null, null, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doOnTerminate(Runnable onTerminate) {
/*  4857 */     Objects.requireNonNull(onTerminate, "onTerminate");
/*  4858 */     return doOnSignal(this, null, null, e -> onTerminate.run(), onTerminate, null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doFirst(Runnable onFirst) {
/*  4901 */     Objects.requireNonNull(onFirst, "onFirst");
/*  4902 */     if (this instanceof Fuseable) {
/*  4903 */       return onAssembly(new FluxDoFirstFuseable<>(this, onFirst));
/*       */     }
/*  4905 */     return onAssembly(new FluxDoFirst<>(this, onFirst));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> doFinally(Consumer<SignalType> onFinally) {
/*  4927 */     Objects.requireNonNull(onFinally, "onFinally");
/*  4928 */     return onAssembly(new FluxDoFinally<>(this, onFinally));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> elapsed() {
/*  4945 */     return elapsed(Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> elapsed(Scheduler scheduler) {
/*  4963 */     Objects.requireNonNull(scheduler, "scheduler");
/*  4964 */     return onAssembly(new FluxElapsed<>(this, scheduler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> elementAt(int index) {
/*  4981 */     return Mono.onAssembly(new MonoElementAt<>(this, index));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> elementAt(int index, T defaultValue) {
/*  4999 */     return Mono.onAssembly(new MonoElementAt<>(this, index, defaultValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> expandDeep(Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/*  5039 */     return onAssembly(new FluxExpand<>(this, expander, false, capacityHint));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> expandDeep(Function<? super T, ? extends Publisher<? extends T>> expander) {
/*  5076 */     return expandDeep(expander, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> expand(Function<? super T, ? extends Publisher<? extends T>> expander, int capacityHint) {
/*  5116 */     return onAssembly(new FluxExpand<>(this, expander, true, capacityHint));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> expand(Function<? super T, ? extends Publisher<? extends T>> expander) {
/*  5153 */     return expand(expander, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> filter(Predicate<? super T> p) {
/*  5176 */     if (this instanceof Fuseable) {
/*  5177 */       return onAssembly(new FluxFilterFuseable<>(this, p));
/*       */     }
/*  5179 */     return onAssembly(new FluxFilter<>(this, p));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> filterWhen(Function<? super T, ? extends Publisher<Boolean>> asyncPredicate) {
/*  5204 */     return filterWhen(asyncPredicate, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> filterWhen(Function<? super T, ? extends Publisher<Boolean>> asyncPredicate, int bufferSize) {
/*  5235 */     return onAssembly(new FluxFilterWhen<>(this, asyncPredicate, bufferSize));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMap(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  5272 */     return flatMap(mapper, Queues.SMALL_BUFFER_SIZE, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> flatMap(Function<? super T, ? extends Publisher<? extends V>> mapper, int concurrency) {
/*  5316 */     return flatMap(mapper, concurrency, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> flatMap(Function<? super T, ? extends Publisher<? extends V>> mapper, int concurrency, int prefetch) {
/*  5363 */     return flatMap(mapper, false, concurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> flatMapDelayError(Function<? super T, ? extends Publisher<? extends V>> mapper, int concurrency, int prefetch) {
/*  5408 */     return flatMap(mapper, true, concurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMap(@Nullable Function<? super T, ? extends Publisher<? extends R>> mapperOnNext, @Nullable Function<? super Throwable, ? extends Publisher<? extends R>> mapperOnError, @Nullable Supplier<? extends Publisher<? extends R>> mapperOnComplete) {
/*  5446 */     return onAssembly(new FluxFlatMap<>(new FluxMapSignal<>(this, mapperOnNext, mapperOnError, mapperOnComplete), 
/*       */           
/*  5448 */           (Function)identityFunction(), false, Queues.XS_BUFFER_SIZE, 
/*       */           
/*  5450 */           Queues.xs(), Queues.XS_BUFFER_SIZE, 
/*  5451 */           Queues.xs()));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper) {
/*  5492 */     return flatMapIterable(mapper, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapIterable(Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch) {
/*  5534 */     return onAssembly(new FluxFlattenIterable<>(this, mapper, prefetch, 
/*  5535 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapSequential(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  5572 */     return flatMapSequential(mapper, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapSequential(Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency) {
/*  5613 */     return flatMapSequential(mapper, maxConcurrency, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapSequential(Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency, int prefetch) {
/*  5657 */     return flatMapSequential(mapper, false, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> flatMapSequentialDelayError(Function<? super T, ? extends Publisher<? extends R>> mapper, int maxConcurrency, int prefetch) {
/*  5702 */     return flatMapSequential(mapper, true, maxConcurrency, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getPrefetch() {
/*  5710 */     return -1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K> Flux<GroupedFlux<K, T>> groupBy(Function<? super T, ? extends K> keyMapper) {
/*  5741 */     return groupBy(keyMapper, (Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K> Flux<GroupedFlux<K, T>> groupBy(Function<? super T, ? extends K> keyMapper, int prefetch) {
/*  5773 */     return groupBy(keyMapper, (Function)identityFunction(), prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Flux<GroupedFlux<K, V>> groupBy(Function<? super T, ? extends K> keyMapper, Function<? super T, ? extends V> valueMapper) {
/*  5809 */     return groupBy(keyMapper, valueMapper, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <K, V> Flux<GroupedFlux<K, V>> groupBy(Function<? super T, ? extends K> keyMapper, Function<? super T, ? extends V> valueMapper, int prefetch) {
/*  5847 */     return onAssembly(new FluxGroupBy<>(this, keyMapper, valueMapper, 
/*  5848 */           Queues.unbounded(prefetch), 
/*  5849 */           Queues.unbounded(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <TRight, TLeftEnd, TRightEnd, R> Flux<R> groupJoin(Publisher<? extends TRight> other, Function<? super T, ? extends Publisher<TLeftEnd>> leftEnd, Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd, BiFunction<? super T, ? super Flux<TRight>, ? extends R> resultSelector) {
/*  5889 */     return onAssembly(new FluxGroupJoin<>(this, other, leftEnd, rightEnd, resultSelector, 
/*       */           
/*  5891 */           Queues.unbounded(Queues.XS_BUFFER_SIZE), 
/*  5892 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> handle(BiConsumer<? super T, SynchronousSink<R>> handler) {
/*  5912 */     if (this instanceof Fuseable) {
/*  5913 */       return onAssembly(new FluxHandleFuseable<>(this, handler));
/*       */     }
/*  5915 */     return onAssembly(new FluxHandle<>(this, handler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Boolean> hasElement(T value) {
/*  5935 */     Objects.requireNonNull(value, "value");
/*  5936 */     return any(t -> Objects.equals(value, t));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Boolean> hasElements() {
/*  5951 */     return Mono.onAssembly(new MonoHasElements<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Flux<T> hide() {
/*  5962 */     return new FluxHide<>(this);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> index() {
/*  5975 */     return index((BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <I> Flux<I> index(BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/*  5995 */     if (this instanceof Fuseable) {
/*  5996 */       return onAssembly(new FluxIndexFuseable<>(this, indexMapper));
/*       */     }
/*  5998 */     return onAssembly(new FluxIndex<>(this, indexMapper));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> ignoreElements() {
/*  6013 */     return Mono.onAssembly(new MonoIgnoreElements<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <TRight, TLeftEnd, TRightEnd, R> Flux<R> join(Publisher<? extends TRight> other, Function<? super T, ? extends Publisher<TLeftEnd>> leftEnd, Function<? super TRight, ? extends Publisher<TRightEnd>> rightEnd, BiFunction<? super T, ? super TRight, ? extends R> resultSelector) {
/*  6051 */     return onAssembly(new FluxJoin<>(this, other, leftEnd, rightEnd, resultSelector));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> last() {
/*  6068 */     if (this instanceof Callable) {
/*       */       
/*  6070 */       Callable<T> thiz = (Callable<T>)this;
/*  6071 */       Mono<T> callableMono = wrapToMono(thiz);
/*  6072 */       if (callableMono == Mono.empty()) {
/*  6073 */         return Mono.onAssembly(new MonoError<>(new NoSuchElementException("Flux#last() didn't observe any onNext signal from Callable flux")));
/*       */       }
/*  6075 */       return Mono.onAssembly(callableMono);
/*       */     } 
/*  6077 */     return Mono.onAssembly(new MonoTakeLastOne<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> last(T defaultValue) {
/*  6095 */     if (this instanceof Callable) {
/*       */       
/*  6097 */       Callable<T> thiz = (Callable<T>)this;
/*  6098 */       if (thiz instanceof Fuseable.ScalarCallable) {
/*       */         T v;
/*  6100 */         Fuseable.ScalarCallable<T> c = (Fuseable.ScalarCallable<T>)thiz;
/*       */         
/*       */         try {
/*  6103 */           v = (T)c.call();
/*       */         }
/*  6105 */         catch (Exception e) {
/*  6106 */           return Mono.error(Exceptions.unwrap(e));
/*       */         } 
/*  6108 */         if (v == null) {
/*  6109 */           return Mono.just(defaultValue);
/*       */         }
/*  6111 */         return Mono.just(v);
/*       */       } 
/*  6113 */       Mono.onAssembly(new MonoCallable(thiz));
/*       */     } 
/*  6115 */     return Mono.onAssembly(new MonoTakeLastOne<>(this, defaultValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> limitRate(int prefetchRate) {
/*  6147 */     return onAssembly(publishOn(Schedulers.immediate(), prefetchRate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> limitRate(int highTide, int lowTide) {
/*  6189 */     return onAssembly(publishOn(Schedulers.immediate(), true, highTide, lowTide));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Flux<T> limitRequest(long n) {
/*  6221 */     return take(n, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log() {
/*  6237 */     return log(null, Level.INFO, new SignalType[0]);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(String category) {
/*  6254 */     return log(category, Level.INFO, new SignalType[0]);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(@Nullable String category, Level level, SignalType... options) {
/*  6280 */     return log(category, level, false, options);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(@Nullable String category, Level level, boolean showOperatorLine, SignalType... options) {
/*  6310 */     SignalLogger<T> log = new SignalLogger<>(this, category, level, showOperatorLine, options);
/*       */ 
/*       */     
/*  6313 */     if (this instanceof Fuseable) {
/*  6314 */       return onAssembly(new FluxLogFuseable<>(this, log));
/*       */     }
/*  6316 */     return onAssembly(new FluxLog<>(this, log));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(Logger logger) {
/*  6330 */     return log(logger, Level.INFO, false, new SignalType[0]);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> log(Logger logger, Level level, boolean showOperatorLine, SignalType... options) {
/*  6357 */     SignalLogger<T> log = new SignalLogger<>(this, "IGNORED", level, showOperatorLine, s -> logger, options);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  6362 */     if (this instanceof Fuseable) {
/*  6363 */       return onAssembly(new FluxLogFuseable<>(this, log));
/*       */     }
/*  6365 */     return onAssembly(new FluxLog<>(this, log));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> map(Function<? super T, ? extends V> mapper) {
/*  6386 */     if (this instanceof Fuseable) {
/*  6387 */       return onAssembly(new FluxMapFuseable<>(this, mapper));
/*       */     }
/*  6389 */     return onAssembly(new FluxMap<>(this, mapper));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> mapNotNull(Function<? super T, ? extends V> mapper) {
/*  6413 */     return handle((t, sink) -> {
/*       */           V v = mapper.apply(t);
/*       */           if (v != null) {
/*       */             sink.next(v);
/*       */           }
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Signal<T>> materialize() {
/*  6435 */     return onAssembly(new FluxMaterialize<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Flux<T> mergeOrderedWith(Publisher<? extends T> other, Comparator<? super T> otherComparator) {
/*  6469 */     if (this instanceof FluxMergeComparing) {
/*  6470 */       FluxMergeComparing<T> fluxMerge = (FluxMergeComparing<T>)this;
/*  6471 */       return fluxMerge.mergeAdditionalSource(other, otherComparator);
/*       */     } 
/*  6473 */     return mergeOrdered(otherComparator, (Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> mergeComparingWith(Publisher<? extends T> other, Comparator<? super T> otherComparator) {
/*  6504 */     if (this instanceof FluxMergeComparing) {
/*  6505 */       FluxMergeComparing<T> fluxMerge = (FluxMergeComparing<T>)this;
/*  6506 */       return fluxMerge.mergeAdditionalSource(other, otherComparator);
/*       */     } 
/*  6508 */     return mergeComparing(otherComparator, (Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> mergeWith(Publisher<? extends T> other) {
/*  6528 */     if (this instanceof FluxMerge) {
/*  6529 */       FluxMerge<T> fluxMerge = (FluxMerge<T>)this;
/*  6530 */       return fluxMerge.mergeAdditionalSource(other, Queues::get);
/*       */     } 
/*  6532 */     return merge((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> metrics() {
/*  6556 */     if (!Metrics.isInstrumentationAvailable()) {
/*  6557 */       return this;
/*       */     }
/*       */     
/*  6560 */     if (this instanceof Fuseable) {
/*  6561 */       return onAssembly(new FluxMetricsFuseable<>(this));
/*       */     }
/*  6563 */     return onAssembly(new FluxMetrics<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> name(String name) {
/*  6580 */     return FluxName.createOrAppend(this, name);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> next() {
/*  6592 */     if (this instanceof Callable) {
/*       */       
/*  6594 */       Callable<T> m = (Callable<T>)this;
/*  6595 */       return Mono.onAssembly(wrapToMono(m));
/*       */     } 
/*  6597 */     return Mono.onAssembly(new MonoNext<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<U> ofType(Class<U> clazz) {
/*  6613 */     Objects.requireNonNull(clazz, "clazz");
/*  6614 */     return filter(o -> clazz.isAssignableFrom(o.getClass())).cast(clazz);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer() {
/*  6631 */     return onAssembly(new FluxOnBackpressureBuffer<>(this, Queues.SMALL_BUFFER_SIZE, true, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(int maxSize) {
/*  6655 */     return onAssembly(new FluxOnBackpressureBuffer<>(this, maxSize, false, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(int maxSize, Consumer<? super T> onOverflow) {
/*  6683 */     Objects.requireNonNull(onOverflow, "onOverflow");
/*  6684 */     return onAssembly(new FluxOnBackpressureBuffer<>(this, maxSize, false, onOverflow));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(int maxSize, BufferOverflowStrategy bufferOverflowStrategy) {
/*  6710 */     Objects.requireNonNull(bufferOverflowStrategy, "bufferOverflowStrategy");
/*  6711 */     return onAssembly(new FluxOnBackpressureBufferStrategy<>(this, maxSize, null, bufferOverflowStrategy));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(int maxSize, Consumer<? super T> onBufferOverflow, BufferOverflowStrategy bufferOverflowStrategy) {
/*  6746 */     Objects.requireNonNull(onBufferOverflow, "onBufferOverflow");
/*  6747 */     Objects.requireNonNull(bufferOverflowStrategy, "bufferOverflowStrategy");
/*  6748 */     return onAssembly(new FluxOnBackpressureBufferStrategy<>(this, maxSize, onBufferOverflow, bufferOverflowStrategy));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(Duration ttl, int maxSize, Consumer<? super T> onBufferEviction) {
/*  6776 */     return onBackpressureBuffer(ttl, maxSize, onBufferEviction, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureBuffer(Duration ttl, int maxSize, Consumer<? super T> onBufferEviction, Scheduler scheduler) {
/*  6803 */     Objects.requireNonNull(ttl, "ttl");
/*  6804 */     Objects.requireNonNull(onBufferEviction, "onBufferEviction");
/*  6805 */     return onAssembly(new FluxOnBackpressureBufferTimeout<>(this, ttl, scheduler, maxSize, onBufferEviction));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureDrop() {
/*  6820 */     return onAssembly(new FluxOnBackpressureDrop<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureDrop(Consumer<? super T> onDropped) {
/*  6838 */     return onAssembly(new FluxOnBackpressureDrop<>(this, onDropped));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureError() {
/*  6855 */     return onBackpressureDrop(t -> {
/*       */           throw Exceptions.failWithOverflow();
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onBackpressureLatest() {
/*  6871 */     return onAssembly(new FluxOnBackpressureLatest<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorComplete() {
/*  6885 */     return onAssembly(new FluxOnErrorReturn<>(this, null, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorComplete(Class<? extends Throwable> type) {
/*  6900 */     Objects.requireNonNull(type, "type must not be null");
/*  6901 */     return onErrorComplete(type::isInstance);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorComplete(Predicate<? super Throwable> predicate) {
/*  6916 */     Objects.requireNonNull(predicate, "predicate must not be null");
/*  6917 */     return onAssembly(new FluxOnErrorReturn<>(this, predicate, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorContinue(BiConsumer<Throwable, Object> errorConsumer) {
/*  6952 */     BiConsumer<Throwable, Object> genericConsumer = errorConsumer;
/*  6953 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*       */           
/*  6955 */           OnNextFailureStrategy.resume(genericConsumer)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorContinue(Class<E> type, BiConsumer<Throwable, Object> errorConsumer) {
/*  6993 */     return onErrorContinue(type::isInstance, errorConsumer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorContinue(Predicate<E> errorPredicate, BiConsumer<Throwable, Object> errorConsumer) {
/*  7035 */     Predicate<Throwable> genericPredicate = errorPredicate;
/*  7036 */     BiConsumer<Throwable, Object> genericErrorConsumer = errorConsumer;
/*  7037 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*       */           
/*  7039 */           OnNextFailureStrategy.resumeIf(genericPredicate, genericErrorConsumer)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorStop() {
/*  7054 */     return subscriberContext(Context.of("reactor.onNextError.localStrategy", 
/*       */           
/*  7056 */           OnNextFailureStrategy.stop()));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorMap(Function<? super Throwable, ? extends Throwable> mapper) {
/*  7070 */     return onErrorResume(e -> Mono.error(mapper.apply(e)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorMap(Class<E> type, Function<? super E, ? extends Throwable> mapper) {
/*  7088 */     Function<Throwable, Throwable> handler = (Function)mapper;
/*  7089 */     return onErrorMap(type::isInstance, handler);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorMap(Predicate<? super Throwable> predicate, Function<? super Throwable, ? extends Throwable> mapper) {
/*  7105 */     return onErrorResume(predicate, e -> Mono.error(mapper.apply(e)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorResume(Function<? super Throwable, ? extends Publisher<? extends T>> fallback) {
/*  7120 */     return onAssembly(new FluxOnErrorResume<>(this, fallback));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorResume(Class<E> type, Function<? super E, ? extends Publisher<? extends T>> fallback) {
/*  7137 */     Objects.requireNonNull(type, "type");
/*       */     
/*  7139 */     Function<? super E, ? extends Publisher<? extends T>> function = fallback;
/*       */     
/*  7141 */     return onErrorResume(type::isInstance, function);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorResume(Predicate<? super Throwable> predicate, Function<? super Throwable, ? extends Publisher<? extends T>> fallback) {
/*  7157 */     Objects.requireNonNull(predicate, "predicate");
/*  7158 */     return onErrorResume(e -> predicate.test(e) ? fallback.apply(e) : (Publisher)error(e));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorReturn(T fallbackValue) {
/*  7172 */     Objects.requireNonNull(fallbackValue, "fallbackValue must not be null");
/*  7173 */     return onAssembly(new FluxOnErrorReturn<>(this, null, fallbackValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Throwable> Flux<T> onErrorReturn(Class<E> type, T fallbackValue) {
/*  7190 */     Objects.requireNonNull(type, "type must not be null");
/*  7191 */     return onErrorReturn(type::isInstance, fallbackValue);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onErrorReturn(Predicate<? super Throwable> predicate, T fallbackValue) {
/*  7207 */     Objects.requireNonNull(predicate, "predicate must not be null");
/*  7208 */     Objects.requireNonNull(fallbackValue, "fallbackValue must not be null");
/*  7209 */     return onAssembly(new FluxOnErrorReturn<>(this, predicate, fallbackValue));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> onTerminateDetach() {
/*  7221 */     return new FluxDetach<>(this);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> or(Publisher<? extends T> other) {
/*  7239 */     if (this instanceof FluxFirstWithSignal) {
/*  7240 */       FluxFirstWithSignal<T> orPublisher = (FluxFirstWithSignal<T>)this;
/*       */       
/*  7242 */       FluxFirstWithSignal<T> result = orPublisher.orAdditionalSource(other);
/*  7243 */       if (result != null) {
/*  7244 */         return result;
/*       */       }
/*       */     } 
/*  7247 */     return firstWithSignal((Publisher<? extends T>[])new Publisher[] { (Publisher)this, other });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ParallelFlux<T> parallel() {
/*  7261 */     return parallel(Schedulers.DEFAULT_POOL_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ParallelFlux<T> parallel(int parallelism) {
/*  7278 */     return parallel(parallelism, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ParallelFlux<T> parallel(int parallelism, int prefetch) {
/*  7297 */     return ParallelFlux.from((Publisher<? extends T>)this, parallelism, prefetch, 
/*       */ 
/*       */         
/*  7300 */         Queues.get(prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> publish() {
/*  7318 */     return publish(Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> publish(int prefetch) {
/*  7337 */     return onAssembly(new FluxPublish<>(this, prefetch, 
/*  7338 */           Queues.get(prefetch), true));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> publish(Function<? super Flux<T>, ? extends Publisher<? extends R>> transform) {
/*  7353 */     return publish(transform, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <R> Flux<R> publish(Function<? super Flux<T>, ? extends Publisher<? extends R>> transform, int prefetch) {
/*  7369 */     return onAssembly(new FluxPublishMulticast<>(this, transform, prefetch, 
/*  7370 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Mono<T> publishNext() {
/*  7388 */     return shareNext();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> publishOn(Scheduler scheduler) {
/*  7412 */     return publishOn(scheduler, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> publishOn(Scheduler scheduler, int prefetch) {
/*  7437 */     return publishOn(scheduler, true, prefetch);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> publishOn(Scheduler scheduler, boolean delayError, int prefetch) {
/*  7463 */     return publishOn(scheduler, delayError, prefetch, prefetch);
/*       */   }
/*       */   
/*       */   final Flux<T> publishOn(Scheduler scheduler, boolean delayError, int prefetch, int lowTide) {
/*  7467 */     if (this instanceof Callable) {
/*  7468 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         
/*  7470 */         Fuseable.ScalarCallable<T> s = (Fuseable.ScalarCallable<T>)this;
/*       */         try {
/*  7472 */           return onAssembly(new FluxSubscribeOnValue<>((T)s.call(), scheduler));
/*       */         }
/*  7474 */         catch (Exception exception) {}
/*       */       } 
/*       */ 
/*       */ 
/*       */       
/*  7479 */       Callable<T> c = (Callable<T>)this;
/*  7480 */       return onAssembly(new FluxSubscribeOnCallable<>(c, scheduler));
/*       */     } 
/*       */     
/*  7483 */     return onAssembly(new FluxPublishOn<>(this, scheduler, delayError, prefetch, lowTide, Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> reduce(BiFunction<T, T, T> aggregator) {
/*  7504 */     if (this instanceof Callable) {
/*       */       
/*  7506 */       Callable<T> thiz = (Callable<T>)this;
/*  7507 */       return Mono.onAssembly(wrapToMono(thiz));
/*       */     } 
/*  7509 */     return Mono.onAssembly(new MonoReduce<>(this, aggregator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <A> Mono<A> reduce(A initial, BiFunction<A, ? super T, A> accumulator) {
/*  7532 */     return reduceWith(() -> initial, accumulator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <A> Mono<A> reduceWith(Supplier<A> initial, BiFunction<A, ? super T, A> accumulator) {
/*  7555 */     return Mono.onAssembly(new MonoReduceSeed<>(this, initial, accumulator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeat() {
/*  7568 */     return repeat(ALWAYS_BOOLEAN_SUPPLIER);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeat(BooleanSupplier predicate) {
/*  7582 */     return onAssembly(new FluxRepeatPredicate<>(this, predicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeat(long numRepeat) {
/*  7598 */     if (numRepeat == 0L) {
/*  7599 */       return this;
/*       */     }
/*  7601 */     return onAssembly(new FluxRepeat<>(this, numRepeat));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeat(long numRepeat, BooleanSupplier predicate) {
/*  7618 */     if (numRepeat < 0L) {
/*  7619 */       throw new IllegalArgumentException("numRepeat >= 0 required");
/*       */     }
/*  7621 */     if (numRepeat == 0L) {
/*  7622 */       return this;
/*       */     }
/*  7624 */     return defer(() -> repeat(countingBooleanSupplier(predicate, numRepeat)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> repeatWhen(Function<Flux<Long>, ? extends Publisher<?>> repeatFactory) {
/*  7662 */     return onAssembly(new FluxRepeatWhen<>(this, repeatFactory));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay() {
/*  7675 */     return replay(2147483647);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(int history) {
/*  7699 */     if (history == 0) {
/*  7700 */       return onAssembly(new FluxPublish<>(this, Queues.SMALL_BUFFER_SIZE, 
/*  7701 */             Queues.get(Queues.SMALL_BUFFER_SIZE), false));
/*       */     }
/*  7703 */     return onAssembly(new FluxReplay<>(this, history, 0L, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(Duration ttl) {
/*  7722 */     return replay(2147483647, ttl);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(int history, Duration ttl) {
/*  7742 */     return replay(history, ttl, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(Duration ttl, Scheduler timer) {
/*  7761 */     return replay(2147483647, ttl, timer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final ConnectableFlux<T> replay(int history, Duration ttl, Scheduler timer) {
/*  7781 */     Objects.requireNonNull(timer, "timer");
/*  7782 */     if (history == 0) {
/*  7783 */       return onAssembly(new FluxPublish<>(this, Queues.SMALL_BUFFER_SIZE, 
/*  7784 */             Queues.get(Queues.SMALL_BUFFER_SIZE), true));
/*       */     }
/*  7786 */     return onAssembly(new FluxReplay<>(this, history, ttl.toNanos(), timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> retry() {
/*  7797 */     return retry(Long.MAX_VALUE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> retry(long numRetries) {
/*  7814 */     return onAssembly(new FluxRetry<>(this, numRetries));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> retryWhen(Retry retrySpec) {
/*  7870 */     return onAssembly(new FluxRetryWhen<>(this, retrySpec));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> sample(Duration timespan) {
/*  7890 */     return sample((Publisher<Long>)interval(timespan));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> sample(Publisher<U> sampler) {
/*  7918 */     return onAssembly(new FluxSample<>(this, sampler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> sampleFirst(Duration timespan) {
/*  7935 */     return sampleFirst(t -> Mono.delay(timespan));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> sampleFirst(Function<? super T, ? extends Publisher<U>> samplerFactory) {
/*  7953 */     return onAssembly(new FluxSampleFirst<>(this, samplerFactory));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> sampleTimeout(Function<? super T, ? extends Publisher<U>> throttlerFactory) {
/*  7977 */     return sampleTimeout(throttlerFactory, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> sampleTimeout(Function<? super T, ? extends Publisher<U>> throttlerFactory, int maxConcurrency) {
/*  8006 */     return onAssembly(new FluxSampleTimeout<>(this, throttlerFactory, 
/*  8007 */           Queues.get(maxConcurrency)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> scan(BiFunction<T, T, T> accumulator) {
/*  8034 */     return onAssembly(new FluxScan<>(this, accumulator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <A> Flux<A> scan(A initial, BiFunction<A, ? super T, A> accumulator) {
/*  8061 */     Objects.requireNonNull(initial, "seed");
/*  8062 */     return scanWith(() -> initial, accumulator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <A> Flux<A> scanWith(Supplier<A> initial, BiFunction<A, ? super T, A> accumulator) {
/*  8092 */     return onAssembly(new FluxScanSeed<>(this, initial, accumulator));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> share() {
/*  8107 */     return onAssembly(new FluxRefCount<>(new FluxPublish<>(this, Queues.SMALL_BUFFER_SIZE, 
/*       */             
/*  8109 */             Queues.small(), true), 1));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> shareNext() {
/*  8125 */     NextProcessor<T> nextProcessor = new NextProcessor<>(this);
/*  8126 */     return Mono.onAssembly(nextProcessor);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> single() {
/*  8140 */     if (this instanceof Callable) {
/*  8141 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         T v;
/*  8143 */         Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)this;
/*       */ 
/*       */         
/*       */         try {
/*  8147 */           v = (T)scalarCallable.call();
/*       */         }
/*  8149 */         catch (Exception e) {
/*  8150 */           return Mono.error(Exceptions.unwrap(e));
/*       */         } 
/*  8152 */         if (v == null) {
/*  8153 */           return Mono.error(new NoSuchElementException("Source was a (constant) empty"));
/*       */         }
/*  8155 */         return Mono.just(v);
/*       */       } 
/*       */       
/*  8158 */       Callable<T> thiz = (Callable<T>)this;
/*  8159 */       return Mono.onAssembly(new MonoSingleCallable<>(thiz));
/*       */     } 
/*  8161 */     return Mono.onAssembly(new MonoSingle<>(this));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> single(T defaultValue) {
/*  8178 */     if (this instanceof Callable) {
/*  8179 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         T v;
/*  8181 */         Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)this;
/*       */ 
/*       */         
/*       */         try {
/*  8185 */           v = (T)scalarCallable.call();
/*       */         }
/*  8187 */         catch (Exception e) {
/*  8188 */           return Mono.error(Exceptions.unwrap(e));
/*       */         } 
/*  8190 */         if (v == null) {
/*  8191 */           return Mono.just(defaultValue);
/*       */         }
/*  8193 */         return Mono.just(v);
/*       */       } 
/*       */       
/*  8196 */       Callable<T> thiz = (Callable<T>)this;
/*  8197 */       return Mono.onAssembly(new MonoSingleCallable<>(thiz, defaultValue));
/*       */     } 
/*  8199 */     return Mono.onAssembly(new MonoSingle<>(this, defaultValue, false));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<T> singleOrEmpty() {
/*  8212 */     if (this instanceof Callable) {
/*       */       
/*  8214 */       Callable<T> thiz = (Callable<T>)this;
/*  8215 */       return Mono.onAssembly(wrapToMono(thiz));
/*       */     } 
/*  8217 */     return Mono.onAssembly(new MonoSingle<>(this, null, true));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skip(long skipped) {
/*  8235 */     if (skipped == 0L) {
/*  8236 */       return this;
/*       */     }
/*       */     
/*  8239 */     return onAssembly(new FluxSkip<>(this, skipped));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skip(Duration timespan) {
/*  8256 */     return skip(timespan, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skip(Duration timespan, Scheduler timer) {
/*  8274 */     if (!timespan.isZero()) {
/*  8275 */       return skipUntilOther((Publisher<?>)Mono.delay(timespan, timer));
/*       */     }
/*       */     
/*  8278 */     return this;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skipLast(int n) {
/*  8297 */     if (n == 0) {
/*  8298 */       return this;
/*       */     }
/*  8300 */     return onAssembly(new FluxSkipLast<>(this, n));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skipUntil(Predicate<? super T> untilPredicate) {
/*  8317 */     return onAssembly(new FluxSkipUntil<>(this, untilPredicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skipUntilOther(Publisher<?> other) {
/*  8335 */     return onAssembly(new FluxSkipUntilOther<>(this, other));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> skipWhile(Predicate<? super T> skipPredicate) {
/*  8351 */     return onAssembly(new FluxSkipWhile<>(this, skipPredicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> sort() {
/*  8370 */     return collectSortedList().flatMapIterable((Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> sort(Comparator<? super T> sortFunction) {
/*  8388 */     return collectSortedList(sortFunction).flatMapIterable((Function)identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> startWith(Iterable<? extends T> iterable) {
/*  8402 */     return startWith((Publisher<? extends T>)fromIterable(iterable));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   public final Flux<T> startWith(T... values) {
/*  8417 */     return startWith((Publisher<? extends T>)just(values));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> startWith(Publisher<? extends T> publisher) {
/*  8431 */     if (this instanceof FluxConcatArray) {
/*  8432 */       FluxConcatArray<T> fluxConcatArray = (FluxConcatArray<T>)this;
/*  8433 */       return fluxConcatArray.concatAdditionalSourceFirst(publisher);
/*       */     } 
/*  8435 */     return concat((Publisher<? extends T>[])new Publisher[] { publisher, (Publisher)this });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe() {
/*  8450 */     return subscribe(null, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe(Consumer<? super T> consumer) {
/*  8474 */     Objects.requireNonNull(consumer, "consumer");
/*  8475 */     return subscribe(consumer, null, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, Consumer<? super Throwable> errorConsumer) {
/*  8501 */     Objects.requireNonNull(errorConsumer, "errorConsumer");
/*  8502 */     return subscribe(consumer, errorConsumer, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer) {
/*  8532 */     return subscribe(consumer, errorConsumer, completeConsumer, (Context)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Consumer<? super Subscription> subscriptionConsumer) {
/*  8571 */     return subscribeWith(new LambdaSubscriber<>(consumer, errorConsumer, completeConsumer, subscriptionConsumer, null));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Disposable subscribe(@Nullable Consumer<? super T> consumer, @Nullable Consumer<? super Throwable> errorConsumer, @Nullable Runnable completeConsumer, @Nullable Context initialContext) {
/*  8608 */     return subscribeWith(new LambdaSubscriber<>(consumer, errorConsumer, completeConsumer, null, initialContext));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final void subscribe(Subscriber<? super T> actual) {
/*  8617 */     CorePublisher<T> publisher = Operators.onLastAssembly(this);
/*  8618 */     CoreSubscriber<? super T> subscriber = Operators.toCoreSubscriber(actual);
/*       */     
/*  8620 */     if (subscriber instanceof Fuseable.QueueSubscription && this != publisher && this instanceof Fuseable && !(publisher instanceof Fuseable)) {
/*  8621 */       subscriber = new FluxHide.SuppressFuseableSubscriber<>(subscriber);
/*       */     }
/*       */     
/*       */     try {
/*  8625 */       if (publisher instanceof OptimizableOperator) {
/*  8626 */         OptimizableOperator<T, T> operator = (OptimizableOperator)publisher;
/*       */         while (true) {
/*  8628 */           subscriber = operator.subscribeOrReturn(subscriber);
/*  8629 */           if (subscriber == null) {
/*       */             return;
/*       */           }
/*       */           
/*  8633 */           OptimizableOperator<?, ? extends T> newSource = operator.nextOptimizableSource();
/*  8634 */           if (newSource == null) {
/*  8635 */             publisher = (CorePublisher)operator.source();
/*       */             break;
/*       */           } 
/*  8638 */           OptimizableOperator<?, ? extends T> optimizableOperator1 = newSource;
/*       */         } 
/*       */       } 
/*       */       
/*  8642 */       publisher.subscribe(subscriber);
/*       */     }
/*  8644 */     catch (Throwable e) {
/*  8645 */       Operators.reportThrowInSubscribe(subscriber, e);
/*       */       return;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Flux<T> subscriberContext(Context mergeContext) {
/*  8684 */     return subscriberContext(c -> c.putAll(mergeContext.readOnly()));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final Flux<T> subscriberContext(Function<Context, Context> doOnContext) {
/*  8708 */     return contextWrite(doOnContext);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> subscribeOn(Scheduler scheduler) {
/*  8743 */     return subscribeOn(scheduler, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> subscribeOn(Scheduler scheduler, boolean requestOnSeparateThread) {
/*  8782 */     if (this instanceof Callable) {
/*  8783 */       if (this instanceof Fuseable.ScalarCallable) {
/*       */         try {
/*  8785 */           T value = (T)((Fuseable.ScalarCallable)this).call();
/*  8786 */           return onAssembly(new FluxSubscribeOnValue<>(value, scheduler));
/*       */         }
/*  8788 */         catch (Exception exception) {}
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*  8793 */       Callable<T> c = (Callable<T>)this;
/*  8794 */       return onAssembly(new FluxSubscribeOnCallable<>(c, scheduler));
/*       */     } 
/*  8796 */     return onAssembly(new FluxSubscribeOn<>(this, scheduler, requestOnSeparateThread));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <E extends Subscriber<? super T>> E subscribeWith(E subscriber) {
/*  8815 */     subscribe((Subscriber<? super T>)subscriber);
/*  8816 */     return subscriber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> switchOnFirst(BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends V>> transformer) {
/*  8864 */     return switchOnFirst(transformer, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> switchOnFirst(BiFunction<Signal<? extends T>, Flux<T>, Publisher<? extends V>> transformer, boolean cancelSourceOnComplete) {
/*  8913 */     return onAssembly(new FluxSwitchOnFirst<>(this, transformer, cancelSourceOnComplete));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> switchIfEmpty(Publisher<? extends T> alternate) {
/*  8926 */     return onAssembly(new FluxSwitchIfEmpty<>(this, alternate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> switchMap(Function<? super T, Publisher<? extends V>> fn) {
/*  8945 */     return switchMap(fn, Queues.XS_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*       */   public final <V> Flux<V> switchMap(Function<? super T, Publisher<? extends V>> fn, int prefetch) {
/*  8970 */     if (prefetch == 0) {
/*  8971 */       return onAssembly(new FluxSwitchMapNoPrefetch<>(this, fn));
/*       */     }
/*  8973 */     return onAssembly(new FluxSwitchMap<>(this, fn, Queues.unbounded(prefetch), prefetch));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> tag(String key, String value) {
/*  8994 */     return FluxName.createOrAppend(this, key, value);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> take(long n) {
/*  9019 */     return take(n, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> take(long n, boolean limitRequest) {
/*  9055 */     if (limitRequest) {
/*  9056 */       return onAssembly(new FluxLimitRequest<>(this, n));
/*       */     }
/*  9058 */     if (this instanceof Fuseable) {
/*  9059 */       return onAssembly(new FluxTakeFuseable<>(this, n));
/*       */     }
/*  9061 */     return onAssembly(new FluxTake<>(this, n));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> take(Duration timespan) {
/*  9079 */     return take(timespan, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> take(Duration timespan, Scheduler timer) {
/*  9099 */     if (!timespan.isZero()) {
/*  9100 */       return takeUntilOther((Publisher<?>)Mono.delay(timespan, timer));
/*       */     }
/*       */     
/*  9103 */     return take(0L);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> takeLast(int n) {
/*  9119 */     if (n == 1) {
/*  9120 */       return onAssembly(new FluxTakeLastOne<>(this));
/*       */     }
/*  9122 */     return onAssembly(new FluxTakeLast<>(this, n));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> takeUntil(Predicate<? super T> predicate) {
/*  9139 */     return onAssembly(new FluxTakeUntil<>(this, predicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> takeUntilOther(Publisher<?> other) {
/*  9154 */     return onAssembly(new FluxTakeUntilOther<>(this, other));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> takeWhile(Predicate<? super T> continuePredicate) {
/*  9171 */     return onAssembly(new FluxTakeWhile<>(this, continuePredicate));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Void> then() {
/*  9187 */     Mono<Void> then = new MonoIgnoreElements<>((Flux)this);
/*  9188 */     return Mono.onAssembly(then);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Mono<V> then(Mono<V> other) {
/*  9209 */     return Mono.onAssembly(new MonoIgnoreThen<>((Publisher<?>[])new Publisher[] { (Publisher)this }, other));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Mono<Void> thenEmpty(Publisher<Void> other) {
/*  9226 */     return then(Mono.fromDirect(other));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> thenMany(Publisher<V> other) {
/*  9246 */     if (this instanceof FluxConcatArray) {
/*       */       
/*  9248 */       FluxConcatArray<T> fluxConcatArray = (FluxConcatArray<T>)this;
/*  9249 */       return fluxConcatArray.concatAdditionalIgnoredLast(other);
/*       */     } 
/*       */ 
/*       */     
/*  9253 */     Flux<V> concat = concat((Publisher<? extends V>[])new Publisher[] { (Publisher)ignoreElements(), other });
/*  9254 */     return concat;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Timed<T>> timed() {
/*  9283 */     return timed(Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Timed<T>> timed(Scheduler clock) {
/*  9312 */     return onAssembly(new FluxTimed<>(this, clock));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> timeout(Duration timeout) {
/*  9327 */     return timeout(timeout, (Publisher<? extends T>)null, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> timeout(Duration timeout, @Nullable Publisher<? extends T> fallback) {
/*  9345 */     return timeout(timeout, fallback, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> timeout(Duration timeout, Scheduler timer) {
/*  9362 */     return timeout(timeout, (Publisher<? extends T>)null, timer);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<T> timeout(Duration timeout, @Nullable Publisher<? extends T> fallback, Scheduler timer) {
/*  9384 */     Mono<Long> _timer = Mono.delay(timeout, timer).onErrorReturn(Long.valueOf(0L));
/*  9385 */     Function<T, Publisher<Long>> rest = o -> _timer;
/*       */     
/*  9387 */     if (fallback == null) {
/*  9388 */       return timeout((Publisher<Long>)_timer, rest, timeout.toMillis() + "ms");
/*       */     }
/*  9390 */     return timeout((Publisher<Long>)_timer, rest, fallback);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U> Flux<T> timeout(Publisher<U> firstTimeout) {
/*  9410 */     return timeout(firstTimeout, t -> never());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V> Flux<T> timeout(Publisher<U> firstTimeout, Function<? super T, ? extends Publisher<V>> nextTimeoutFactory) {
/*  9434 */     return timeout(firstTimeout, nextTimeoutFactory, "first signal from a Publisher");
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   private final <U, V> Flux<T> timeout(Publisher<U> firstTimeout, Function<? super T, ? extends Publisher<V>> nextTimeoutFactory, String timeoutDescription) {
/*  9440 */     return onAssembly(new FluxTimeout<>(this, firstTimeout, nextTimeoutFactory, timeoutDescription));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V> Flux<T> timeout(Publisher<U> firstTimeout, Function<? super T, ? extends Publisher<V>> nextTimeoutFactory, Publisher<? extends T> fallback) {
/*  9465 */     return onAssembly(new FluxTimeout<>(this, firstTimeout, nextTimeoutFactory, fallback));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> timestamp() {
/*  9482 */     return timestamp(Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Tuple2<Long, T>> timestamp(Scheduler scheduler) {
/*  9504 */     Objects.requireNonNull(scheduler, "scheduler");
/*  9505 */     return map(d -> Tuples.of(Long.valueOf(scheduler.now(TimeUnit.MILLISECONDS)), d));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Iterable<T> toIterable() {
/*  9522 */     return toIterable(Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Iterable<T> toIterable(int batchSize) {
/*  9540 */     return toIterable(batchSize, null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Iterable<T> toIterable(int batchSize, @Nullable Supplier<Queue<T>> queueProvider) {
/*       */     Supplier<Queue<T>> provider;
/*  9564 */     if (queueProvider == null) {
/*  9565 */       provider = Queues.get(batchSize);
/*       */     } else {
/*       */       
/*  9568 */       provider = (() -> Hooks.wrapQueue(queueProvider.get()));
/*       */     } 
/*  9570 */     return new BlockingIterable<>(this, batchSize, provider);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Stream<T> toStream() {
/*  9587 */     return toStream(Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Stream<T> toStream(int batchSize) {
/*  9607 */     Supplier<Queue<T>> provider = Queues.get(batchSize);
/*  9608 */     return (new BlockingIterable<>(this, batchSize, provider)).stream();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> transform(Function<? super Flux<T>, ? extends Publisher<V>> transformer) {
/*  9632 */     if (Hooks.DETECT_CONTEXT_LOSS) {
/*  9633 */       transformer = (Function)new ContextTrackingFunctionWrapper<>((Function)transformer);
/*       */     }
/*  9635 */     return onAssembly(from(transformer.apply(this)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> transformDeferred(Function<? super Flux<T>, ? extends Publisher<V>> transformer) {
/*  9657 */     return defer(() -> {
/*       */           if (Hooks.DETECT_CONTEXT_LOSS) {
/*       */             ContextTrackingFunctionWrapper<T, V> wrapper = new ContextTrackingFunctionWrapper<>(transformer);
/*       */             return (Publisher)wrapper.apply((Publisher<T>)this);
/*       */           } 
/*       */           return transformer.apply(this);
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<V> transformDeferredContextual(BiFunction<? super Flux<T>, ? super ContextView, ? extends Publisher<V>> transformer) {
/*  9691 */     return deferContextual(ctxView -> {
/*       */           if (Hooks.DETECT_CONTEXT_LOSS) {
/*       */             ContextTrackingFunctionWrapper<T, V> wrapper = new ContextTrackingFunctionWrapper<>((), transformer.toString());
/*       */             return (Publisher)wrapper.apply((Publisher<T>)this);
/*       */           } 
/*       */           return transformer.apply(this, ctxView);
/*       */         });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(int maxSize) {
/*  9727 */     return onAssembly(new FluxWindow<>(this, maxSize, Queues.get(maxSize)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(int maxSize, int skip) {
/*  9764 */     return onAssembly(new FluxWindow<>(this, maxSize, skip, 
/*       */ 
/*       */           
/*  9767 */           Queues.unbounded(Queues.XS_BUFFER_SIZE), 
/*  9768 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Publisher<?> boundary) {
/*  9793 */     return onAssembly(new FluxWindowBoundary<>(this, boundary, 
/*  9794 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Duration windowingTimespan) {
/*  9820 */     return window(windowingTimespan, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Duration windowingTimespan, Duration openWindowEvery) {
/*  9862 */     return window(windowingTimespan, openWindowEvery, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Duration windowingTimespan, Scheduler timer) {
/*  9888 */     return window((Publisher<?>)interval(windowingTimespan, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> window(Duration windowingTimespan, Duration openWindowEvery, Scheduler timer) {
/*  9930 */     if (openWindowEvery.equals(windowingTimespan)) {
/*  9931 */       return window(windowingTimespan);
/*       */     }
/*  9933 */     return windowWhen((Publisher<Long>)interval(Duration.ZERO, openWindowEvery, timer), aLong -> Mono.delay(windowingTimespan, timer));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowTimeout(int maxSize, Duration maxTime) {
/*  9962 */     return windowTimeout(maxSize, maxTime, Schedulers.parallel());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowTimeout(int maxSize, Duration maxTime, boolean fairBackpressure) {
/*  9993 */     return windowTimeout(maxSize, maxTime, Schedulers.parallel(), fairBackpressure);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowTimeout(int maxSize, Duration maxTime, Scheduler timer) {
/* 10023 */     return windowTimeout(maxSize, maxTime, timer, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowTimeout(int maxSize, Duration maxTime, Scheduler timer, boolean fairBackpressure) {
/* 10055 */     return onAssembly(new FluxWindowTimeout<>(this, maxSize, maxTime.toNanos(), TimeUnit.NANOSECONDS, timer, fairBackpressure));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowUntil(Predicate<T> boundaryTrigger) {
/* 10088 */     return windowUntil(boundaryTrigger, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowUntil(Predicate<T> boundaryTrigger, boolean cutBefore) {
/* 10126 */     return windowUntil(boundaryTrigger, cutBefore, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowUntil(Predicate<T> boundaryTrigger, boolean cutBefore, int prefetch) {
/* 10166 */     return onAssembly(new FluxWindowPredicate<>(this, 
/* 10167 */           Queues.unbounded(prefetch), 
/* 10168 */           Queues.unbounded(prefetch), prefetch, boundaryTrigger, cutBefore ? FluxBufferPredicate.Mode.UNTIL_CUT_BEFORE : FluxBufferPredicate.Mode.UNTIL));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<Flux<T>> windowUntilChanged() {
/* 10196 */     return windowUntilChanged(identityFunction());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<Flux<T>> windowUntilChanged(Function<? super T, ? super V> keySelector) {
/* 10223 */     return windowUntilChanged((Function)keySelector, equalPredicate());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <V> Flux<Flux<T>> windowUntilChanged(Function<? super T, ? extends V> keySelector, BiPredicate<? super V, ? super V> keyComparator) {
/* 10253 */     return defer(() -> windowUntil(new FluxBufferPredicate.ChangedPredicate<>(keySelector, keyComparator), true));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowWhile(Predicate<T> inclusionPredicate) {
/* 10287 */     return windowWhile(inclusionPredicate, Queues.SMALL_BUFFER_SIZE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final Flux<Flux<T>> windowWhile(Predicate<T> inclusionPredicate, int prefetch) {
/* 10321 */     return onAssembly(new FluxWindowPredicate<>(this, 
/* 10322 */           Queues.unbounded(prefetch), 
/* 10323 */           Queues.unbounded(prefetch), prefetch, inclusionPredicate, FluxBufferPredicate.Mode.WHILE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, V> Flux<Flux<T>> windowWhen(Publisher<U> bucketOpening, Function<? super U, ? extends Publisher<V>> closeSelector) {
/* 10363 */     return onAssembly(new FluxWindowWhen<>(this, bucketOpening, closeSelector, 
/*       */ 
/*       */           
/* 10366 */           Queues.unbounded(Queues.XS_BUFFER_SIZE)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <U, R> Flux<R> withLatestFrom(Publisher<? extends U> other, BiFunction<? super T, ? super U, ? extends R> resultSelector) {
/* 10392 */     return onAssembly(new FluxWithLatestFrom<>(this, other, resultSelector));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2> Flux<Tuple2<T, T2>> zipWith(Publisher<? extends T2> source2) {
/* 10411 */     return zipWith(source2, (BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2, V> Flux<V> zipWith(Publisher<? extends T2> source2, BiFunction<? super T, ? super T2, ? extends V> combinator) {
/* 10434 */     if (this instanceof FluxZip) {
/*       */       
/* 10436 */       FluxZip<T, V> o = (FluxZip)this;
/* 10437 */       Flux<V> result = o.zipAdditionalSource(source2, combinator);
/* 10438 */       if (result != null) {
/* 10439 */         return result;
/*       */       }
/*       */     } 
/* 10442 */     return zip((Publisher<? extends T>)this, source2, combinator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2, V> Flux<V> zipWith(Publisher<? extends T2> source2, int prefetch, BiFunction<? super T, ? super T2, ? extends V> combinator) {
/* 10468 */     return zip(objects -> combinator.apply(objects[0], objects[1]), prefetch, (Publisher<?>[])new Publisher[] { (Publisher)this, source2 });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2> Flux<Tuple2<T, T2>> zipWith(Publisher<? extends T2> source2, int prefetch) {
/* 10491 */     return zipWith(source2, prefetch, (BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2> Flux<Tuple2<T, T2>> zipWithIterable(Iterable<? extends T2> iterable) {
/* 10509 */     return zipWithIterable(iterable, (BiFunction)tuple2Function());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public final <T2, V> Flux<V> zipWithIterable(Iterable<? extends T2> iterable, BiFunction<? super T, ? super T2, ? extends V> zipper) {
/* 10531 */     return onAssembly(new FluxZipIterable<>(this, iterable, zipper));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static <T> Flux<T> onAssembly(Flux<T> source) {
/* 10547 */     Function<Publisher, Publisher> hook = Hooks.onEachOperatorHook;
/* 10548 */     if (hook != null) {
/* 10549 */       source = (Flux<T>)hook.apply(source);
/*       */     }
/* 10551 */     if (Hooks.GLOBAL_TRACE) {
/* 10552 */       FluxOnAssembly.AssemblySnapshot stacktrace = new FluxOnAssembly.AssemblySnapshot(null, Traces.callSiteSupplierFactory.get());
/* 10553 */       source = (Flux<T>)Hooks.addAssemblyInfo(source, stacktrace);
/*       */     } 
/* 10555 */     return source;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static <T> ConnectableFlux<T> onAssembly(ConnectableFlux<T> source) {
/* 10571 */     Function<Publisher, Publisher> hook = Hooks.onEachOperatorHook;
/* 10572 */     if (hook != null) {
/* 10573 */       source = (ConnectableFlux<T>)hook.apply(source);
/*       */     }
/* 10575 */     if (Hooks.GLOBAL_TRACE) {
/* 10576 */       FluxOnAssembly.AssemblySnapshot stacktrace = new FluxOnAssembly.AssemblySnapshot(null, Traces.callSiteSupplierFactory.get());
/* 10577 */       source = (ConnectableFlux<T>)Hooks.addAssemblyInfo(source, stacktrace);
/*       */     } 
/* 10579 */     return source;
/*       */   }
/*       */ 
/*       */   
/*       */   public String toString() {
/* 10584 */     return getClass().getSimpleName();
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   final <V> Flux<V> flatMap(Function<? super T, ? extends Publisher<? extends V>> mapper, boolean delayError, int concurrency, int prefetch) {
/* 10590 */     return onAssembly(new FluxFlatMap<>(this, mapper, delayError, concurrency, 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10595 */           Queues.get(concurrency), prefetch, 
/*       */           
/* 10597 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final <R> Flux<R> flatMapSequential(Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency, int prefetch) {
/* 10604 */     return onAssembly(new FluxMergeSequential<>(this, mapper, maxConcurrency, prefetch, delayError ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static <T> Flux<T> doOnSignal(Flux<T> source, @Nullable Consumer<? super Subscription> onSubscribe, @Nullable Consumer<? super T> onNext, @Nullable Consumer<? super Throwable> onError, @Nullable Runnable onComplete, @Nullable Runnable onAfterTerminate, @Nullable LongConsumer onRequest, @Nullable Runnable onCancel) {
/* 10618 */     if (source instanceof Fuseable) {
/* 10619 */       return onAssembly(new FluxPeekFuseable<>(source, onSubscribe, onNext, onError, onComplete, onAfterTerminate, onRequest, onCancel));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10628 */     return onAssembly(new FluxPeek<>(source, onSubscribe, onNext, onError, onComplete, onAfterTerminate, onRequest, onCancel));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static <T> Mono<T> wrapToMono(Callable<T> supplier) {
/* 10647 */     if (supplier instanceof Fuseable.ScalarCallable) {
/* 10648 */       T v; Fuseable.ScalarCallable<T> scalarCallable = (Fuseable.ScalarCallable<T>)supplier;
/*       */ 
/*       */       
/*       */       try {
/* 10652 */         v = (T)scalarCallable.call();
/*       */       }
/* 10654 */       catch (Exception e) {
/* 10655 */         return new MonoError<>(Exceptions.unwrap(e));
/*       */       } 
/* 10657 */       if (v == null) {
/* 10658 */         return MonoEmpty.instance();
/*       */       }
/* 10660 */       return new MonoJust<>(v);
/*       */     } 
/* 10662 */     return new MonoCallable<>(supplier);
/*       */   }
/*       */   
/*       */   @SafeVarargs
/*       */   static <I> Flux<I> merge(int prefetch, boolean delayError, Publisher<? extends I>... sources) {
/* 10667 */     if (sources.length == 0) {
/* 10668 */       return empty();
/*       */     }
/* 10670 */     if (sources.length == 1) {
/* 10671 */       return from(sources[0]);
/*       */     }
/* 10673 */     return onAssembly(new FluxMerge<>(sources, delayError, sources.length, 
/*       */ 
/*       */           
/* 10676 */           Queues.get(sources.length), prefetch, 
/*       */           
/* 10678 */           Queues.get(prefetch)));
/*       */   }
/*       */ 
/*       */   
/*       */   @SafeVarargs
/*       */   static <I> Flux<I> mergeSequential(int prefetch, boolean delayError, Publisher<? extends I>... sources) {
/* 10684 */     if (sources.length == 0) {
/* 10685 */       return empty();
/*       */     }
/* 10687 */     if (sources.length == 1) {
/* 10688 */       return from(sources[0]);
/*       */     }
/* 10690 */     return onAssembly(new FluxMergeSequential<>(new FluxArray((Object[])sources), 
/* 10691 */           (Function)identityFunction(), sources.length, prefetch, delayError ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   static <T> Flux<T> mergeSequential(Publisher<? extends Publisher<? extends T>> sources, boolean delayError, int maxConcurrency, int prefetch) {
/* 10697 */     return onAssembly(new FluxMergeSequential<>(from(sources), 
/* 10698 */           (Function)identityFunction(), maxConcurrency, prefetch, delayError ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static <I> Flux<I> mergeSequential(Iterable<? extends Publisher<? extends I>> sources, boolean delayError, int maxConcurrency, int prefetch) {
/* 10705 */     return onAssembly(new FluxMergeSequential<>(new FluxIterable(sources), 
/* 10706 */           (Function)identityFunction(), maxConcurrency, prefetch, delayError ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.IMMEDIATE));
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   static BooleanSupplier countingBooleanSupplier(final BooleanSupplier predicate, final long max) {
/* 10712 */     if (max <= 0L) {
/* 10713 */       return predicate;
/*       */     }
/* 10715 */     return new BooleanSupplier()
/*       */       {
/*       */         long n;
/*       */         
/*       */         public boolean getAsBoolean() {
/* 10720 */           return (this.n++ < max && predicate.getAsBoolean());
/*       */         }
/*       */       };
/*       */   }
/*       */   
/*       */   static <O> Predicate<O> countingPredicate(final Predicate<O> predicate, final long max) {
/* 10726 */     if (max == 0L) {
/* 10727 */       return predicate;
/*       */     }
/* 10729 */     return new Predicate<O>()
/*       */       {
/*       */         long n;
/*       */         
/*       */         public boolean test(O o) {
/* 10734 */           return (this.n++ < max && predicate.test(o));
/*       */         }
/*       */       };
/*       */   }
/*       */ 
/*       */   
/*       */   static <O> Supplier<Set<O>> hashSetSupplier() {
/* 10741 */     return SET_SUPPLIER;
/*       */   }
/*       */ 
/*       */   
/*       */   static <O> Supplier<List<O>> listSupplier() {
/* 10746 */     return LIST_SUPPLIER;
/*       */   }
/*       */ 
/*       */   
/*       */   static <U, V> BiPredicate<U, V> equalPredicate() {
/* 10751 */     return OBJECT_EQUAL;
/*       */   }
/*       */ 
/*       */   
/*       */   static <T> Function<T, T> identityFunction() {
/* 10756 */     return IDENTITY_FUNCTION;
/*       */   }
/*       */ 
/*       */   
/*       */   static <A, B> BiFunction<A, B, Tuple2<A, B>> tuple2Function() {
/* 10761 */     return TUPLE2_BIFUNCTION;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static <I> Flux<I> wrap(Publisher<? extends I> source) {
/* 10774 */     if (source instanceof Flux) {
/* 10775 */       return (Flux)source;
/*       */     }
/*       */ 
/*       */     
/* 10779 */     if (source instanceof Fuseable.ScalarCallable) {
/*       */       
/*       */       try {
/* 10782 */         I t = (I)((Fuseable.ScalarCallable)source).call();
/* 10783 */         if (t != null) {
/* 10784 */           return new FluxJust<>(t);
/*       */         }
/* 10786 */         return FluxEmpty.instance();
/*       */       }
/* 10788 */       catch (Exception e) {
/* 10789 */         return new FluxError<>(Exceptions.unwrap(e));
/*       */       } 
/*       */     }
/*       */     
/* 10793 */     if (source instanceof Mono) {
/* 10794 */       if (source instanceof Fuseable) {
/* 10795 */         return new FluxSourceMonoFuseable<>((Mono<? extends I>)source);
/*       */       }
/* 10797 */       return new FluxSourceMono<>((Mono<? extends I>)source);
/*       */     } 
/* 10799 */     if (source instanceof Fuseable) {
/* 10800 */       return new FluxSourceFuseable<>(source);
/*       */     }
/* 10802 */     return new FluxSource<>(source);
/*       */   }
/*       */ 
/*       */   
/* 10806 */   static final BiFunction TUPLE2_BIFUNCTION = Tuples::of;
/*       */   
/* 10808 */   static final Supplier LIST_SUPPLIER = ArrayList::new;
/*       */   
/* 10810 */   static final Supplier SET_SUPPLIER = java.util.HashSet::new;
/*       */   static final BooleanSupplier ALWAYS_BOOLEAN_SUPPLIER = () -> true;
/* 10812 */   static final BiPredicate OBJECT_EQUAL = Object::equals;
/*       */   
/* 10814 */   static final Function IDENTITY_FUNCTION = Function.identity();
/*       */   
/*       */   public abstract void subscribe(CoreSubscriber<? super T> paramCoreSubscriber);
/*       */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\Flux.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */