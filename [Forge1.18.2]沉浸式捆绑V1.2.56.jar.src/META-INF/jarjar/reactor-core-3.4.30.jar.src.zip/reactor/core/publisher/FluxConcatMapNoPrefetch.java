/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxConcatMapNoPrefetch<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */   final FluxConcatMap.ErrorMode errorMode;
/*     */   
/*     */   FluxConcatMapNoPrefetch(Flux<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, FluxConcatMap.ErrorMode errorMode) {
/*  54 */     super(source);
/*  55 */     this.mapper = Objects.<Function<? super T, ? extends Publisher<? extends R>>>requireNonNull(mapper, "mapper");
/*  56 */     this.errorMode = errorMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  61 */     if (FluxFlatMap.trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, this.mapper, false, true)) {
/*  62 */       return null;
/*     */     }
/*     */     
/*  65 */     return new FluxConcatMapNoPrefetchSubscriber<>(actual, this.mapper, this.errorMode);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  70 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  71 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  76 */     return 0;
/*     */   }
/*     */   
/*     */   static final class FluxConcatMapNoPrefetchSubscriber<T, R> implements FluxConcatMap.FluxConcatMapSupport<T, R> { volatile State state;
/*     */     
/*     */     enum State {
/*  82 */       INITIAL,
/*     */ 
/*     */ 
/*     */       
/*  86 */       REQUESTED,
/*     */ 
/*     */ 
/*     */       
/*  90 */       ACTIVE,
/*     */ 
/*     */ 
/*     */       
/*  94 */       LAST_ACTIVE,
/*     */ 
/*     */ 
/*     */       
/*  98 */       TERMINATED,
/*  99 */       CANCELLED;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     static final AtomicReferenceFieldUpdater<FluxConcatMapNoPrefetchSubscriber, State> STATE = AtomicReferenceFieldUpdater.newUpdater(FluxConcatMapNoPrefetchSubscriber.class, State.class, "state");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */ 
/*     */     
/* 114 */     static final AtomicReferenceFieldUpdater<FluxConcatMapNoPrefetchSubscriber, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(FluxConcatMapNoPrefetchSubscriber.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */     
/*     */     final CoreSubscriber<? super R> actual;
/*     */ 
/*     */     
/*     */     final FluxConcatMap.ConcatMapInner<R> inner;
/*     */ 
/*     */     
/*     */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */ 
/*     */     
/*     */     final FluxConcatMap.ErrorMode errorMode;
/*     */ 
/*     */     
/*     */     Subscription upstream;
/*     */ 
/*     */ 
/*     */     
/*     */     FluxConcatMapNoPrefetchSubscriber(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper, FluxConcatMap.ErrorMode errorMode) {
/* 135 */       this.actual = actual;
/* 136 */       this.mapper = mapper;
/* 137 */       this.errorMode = errorMode;
/* 138 */       this.inner = new FluxConcatMap.ConcatMapInner<>(this);
/* 139 */       STATE.lazySet(this, State.INITIAL);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 145 */       if (key == Scannable.Attr.PARENT) return this.upstream; 
/* 146 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.state == State.TERMINATED)); 
/* 147 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.state == State.CANCELLED)); 
/* 148 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf((this.errorMode != FluxConcatMap.ErrorMode.IMMEDIATE)); 
/* 149 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 151 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 156 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 161 */       if (Operators.validate(this.upstream, s)) {
/* 162 */         this.upstream = s;
/*     */         
/* 164 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 170 */       if (!STATE.compareAndSet(this, State.REQUESTED, State.ACTIVE)) {
/* 171 */         switch (this.state) {
/*     */           case CANCELLED:
/* 173 */             Operators.onDiscard(t, currentContext());
/*     */             break;
/*     */           case TERMINATED:
/* 176 */             Operators.onNextDropped(t, currentContext());
/*     */             break;
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/* 183 */         Publisher<? extends R> p = this.mapper.apply(t);
/* 184 */         Objects.requireNonNull(p, "The mapper returned a null Publisher");
/*     */         
/* 186 */         if (p instanceof Callable) {
/*     */           
/* 188 */           Callable<R> callable = (Callable)p;
/*     */           
/* 190 */           R result = callable.call();
/* 191 */           if (result == null) {
/* 192 */             innerComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 196 */           if (this.inner.isUnbounded()) {
/* 197 */             this.actual.onNext(result);
/* 198 */             innerComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 202 */           this.inner.set(new FluxConcatMap.WeakScalarSubscription<>(result, this.inner));
/*     */           
/*     */           return;
/*     */         } 
/* 206 */         p.subscribe((Subscriber)this.inner);
/*     */       }
/* 208 */       catch (Throwable e) {
/* 209 */         Context ctx = this.actual.currentContext();
/* 210 */         Operators.onDiscard(t, ctx);
/* 211 */         if (!maybeOnError(Operators.onNextError(t, e, ctx), ctx, this.upstream)) {
/* 212 */           innerComplete();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 219 */       Context ctx = currentContext();
/* 220 */       if (!maybeOnError(t, ctx, this.inner)) {
/* 221 */         onComplete();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 227 */       for (State previousState = this.state;; previousState = this.state) {
/* 228 */         Throwable ex; switch (previousState) {
/*     */           case INITIAL:
/*     */           case REQUESTED:
/* 231 */             if (!STATE.compareAndSet(this, previousState, State.TERMINATED)) {
/*     */               break;
/*     */             }
/*     */             
/* 235 */             ex = this.error;
/* 236 */             if (ex != null) {
/* 237 */               this.actual.onError(ex);
/*     */               return;
/*     */             } 
/* 240 */             this.actual.onComplete();
/*     */             return;
/*     */           case ACTIVE:
/* 243 */             if (!STATE.compareAndSet(this, previousState, State.LAST_ACTIVE)) {
/*     */               break;
/*     */             }
/*     */             return;
/*     */           default:
/*     */             return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void innerNext(R value) {
/* 255 */       switch (this.state) {
/*     */         case ACTIVE:
/*     */         case LAST_ACTIVE:
/* 258 */           this.actual.onNext(value);
/*     */           return;
/*     */       } 
/* 261 */       Operators.onDiscard(value, currentContext());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void innerComplete() {
/* 268 */       for (State previousState = this.state;; previousState = this.state) {
/* 269 */         Throwable ex; switch (previousState) {
/*     */           case ACTIVE:
/* 271 */             if (!STATE.compareAndSet(this, previousState, State.REQUESTED)) {
/*     */               break;
/*     */             }
/* 274 */             this.upstream.request(1L);
/*     */             return;
/*     */           case LAST_ACTIVE:
/* 277 */             if (!STATE.compareAndSet(this, previousState, State.TERMINATED)) {
/*     */               break;
/*     */             }
/*     */             
/* 281 */             ex = this.error;
/* 282 */             if (ex != null) {
/* 283 */               this.actual.onError(ex);
/*     */               return;
/*     */             } 
/* 286 */             this.actual.onComplete();
/*     */             return;
/*     */           default:
/*     */             return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void innerError(Throwable e) {
/* 296 */       Context ctx = currentContext();
/* 297 */       if (!maybeOnError(Operators.onNextInnerError(e, ctx, null), ctx, this.upstream)) {
/* 298 */         innerComplete();
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean maybeOnError(@Nullable Throwable e, Context ctx, Subscription subscriptionToCancel) {
/* 303 */       if (e == null) {
/* 304 */         return false;
/*     */       }
/*     */       
/* 307 */       if (!ERROR.compareAndSet(this, null, e)) {
/* 308 */         Operators.onErrorDropped(e, ctx);
/*     */       }
/*     */       
/* 311 */       if (this.errorMode == FluxConcatMap.ErrorMode.END) {
/* 312 */         return false;
/*     */       }
/*     */       
/* 315 */       State previousState = this.state; while (true) {
/* 316 */         switch (previousState) {
/*     */           case CANCELLED:
/*     */           case TERMINATED:
/* 319 */             return true;
/*     */         } 
/* 321 */         if (!STATE.compareAndSet(this, previousState, State.TERMINATED)) {
/*     */           previousState = this.state; continue;
/*     */         } 
/* 324 */         subscriptionToCancel.cancel();
/* 325 */         synchronized (this) {
/* 326 */           this.actual.onError(this.error);
/*     */         } 
/* 328 */         return true;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 335 */       if (STATE.compareAndSet(this, State.INITIAL, State.REQUESTED)) {
/* 336 */         this.upstream.request(1L);
/*     */       }
/* 338 */       this.inner.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 343 */       switch ((State)STATE.getAndSet((T)this, (V)State.CANCELLED)) {
/*     */         case CANCELLED:
/*     */           return;
/*     */         case TERMINATED:
/* 347 */           this.inner.cancel();
/*     */       } 
/*     */       
/* 350 */       this.inner.cancel();
/* 351 */       this.upstream.cancel();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxConcatMapNoPrefetch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */