/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConnectableFluxOnAssembly<T>
/*    */   extends InternalConnectableFluxOperator<T, T>
/*    */   implements Fuseable, AssemblyOp, Scannable
/*    */ {
/*    */   final FluxOnAssembly.AssemblySnapshot stacktrace;
/*    */   
/*    */   ConnectableFluxOnAssembly(ConnectableFlux<T> source, FluxOnAssembly.AssemblySnapshot stacktrace) {
/* 53 */     super(source);
/* 54 */     this.stacktrace = stacktrace;
/*    */   }
/*    */ 
/*    */   
/*    */   public final CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 59 */     return FluxOnAssembly.wrapSubscriber(actual, this.source, (Publisher<?>)this, this.stacktrace);
/*    */   }
/*    */ 
/*    */   
/*    */   public void connect(Consumer<? super Disposable> cancelSupport) {
/* 64 */     this.source.connect(cancelSupport);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 70 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 71 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 72 */     if (key == Scannable.Attr.ACTUAL_METADATA) return Boolean.valueOf(!this.stacktrace.isCheckpoint); 
/* 73 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 75 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 80 */     return this.stacktrace.operatorAssemblyInformation();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 85 */     return this.stacktrace.operatorAssemblyInformation();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ConnectableFluxOnAssembly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */