/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoPublishOn<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */ {
/*     */   final Scheduler scheduler;
/*     */   
/*     */   MonoPublishOn(Mono<? extends T> source, Scheduler scheduler) {
/*  40 */     super(source);
/*  41 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  46 */     return new PublishOnSubscriber<>(actual, this.scheduler);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  51 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  52 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  54 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class PublishOnSubscriber<T>
/*     */     implements InnerOperator<T, T>, Runnable
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Scheduler scheduler;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     volatile Disposable future;
/*     */     
/*  70 */     static final AtomicReferenceFieldUpdater<PublishOnSubscriber, Disposable> FUTURE = AtomicReferenceFieldUpdater.newUpdater(PublishOnSubscriber.class, Disposable.class, "future");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile T value;
/*     */ 
/*     */ 
/*     */     
/*  79 */     static final AtomicReferenceFieldUpdater<PublishOnSubscriber, Object> VALUE = AtomicReferenceFieldUpdater.newUpdater(PublishOnSubscriber.class, Object.class, "value");
/*     */ 
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */ 
/*     */     
/*     */     PublishOnSubscriber(CoreSubscriber<? super T> actual, Scheduler scheduler) {
/*  87 */       this.actual = actual;
/*  88 */       this.scheduler = scheduler;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  94 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.future == OperatorDisposables.DISPOSED)); 
/*  95 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  96 */       if (key == Scannable.Attr.ERROR) return this.error; 
/*  97 */       if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  98 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 100 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 105 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 110 */       if (Operators.validate(this.s, s)) {
/* 111 */         this.s = s;
/*     */         
/* 113 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 119 */       this.value = t;
/* 120 */       trySchedule(this, null, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 125 */       this.error = t;
/* 126 */       trySchedule(null, t, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 131 */       if (this.value == null) {
/* 132 */         trySchedule(null, null, null);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void trySchedule(@Nullable Subscription subscription, @Nullable Throwable suppressed, @Nullable Object dataSignal) {
/* 141 */       if (this.future != null) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/* 146 */         this.future = this.scheduler.schedule(this);
/*     */       }
/* 148 */       catch (RejectedExecutionException ree) {
/* 149 */         this.actual.onError(Operators.onRejectedExecution(ree, subscription, suppressed, dataSignal, this.actual
/* 150 */               .currentContext()));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 156 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 161 */       Disposable c = this.future;
/* 162 */       if (c != OperatorDisposables.DISPOSED) {
/* 163 */         c = FUTURE.getAndSet(this, OperatorDisposables.DISPOSED);
/* 164 */         if (c != null && !OperatorDisposables.isDisposed(c)) {
/* 165 */           c.dispose();
/*     */         }
/* 167 */         this.value = null;
/*     */       } 
/* 169 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 175 */       if (OperatorDisposables.isDisposed(this.future)) {
/*     */         return;
/*     */       }
/* 178 */       T v = (T)VALUE.getAndSet(this, null);
/*     */       
/* 180 */       if (v != null) {
/* 181 */         this.actual.onNext(v);
/* 182 */         this.actual.onComplete();
/*     */       } else {
/*     */         
/* 185 */         Throwable e = this.error;
/* 186 */         if (e != null) {
/* 187 */           this.actual.onError(e);
/*     */         } else {
/*     */           
/* 190 */           this.actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoPublishOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */