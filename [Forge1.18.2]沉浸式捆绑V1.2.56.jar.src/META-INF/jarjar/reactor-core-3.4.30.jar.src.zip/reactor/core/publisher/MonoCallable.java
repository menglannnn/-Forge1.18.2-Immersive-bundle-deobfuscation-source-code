/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.Callable;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoCallable<T>
/*    */   extends Mono<T>
/*    */   implements Callable<T>, Fuseable, SourceProducer<T>
/*    */ {
/*    */   final Callable<? extends T> callable;
/*    */   
/*    */   MonoCallable(Callable<? extends T> callable) {
/* 42 */     this.callable = Objects.<Callable<? extends T>>requireNonNull(callable, "callable");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 48 */     Operators.MonoSubscriber<T, T> sds = new Operators.MonoSubscriber<>(actual);
/*    */     
/* 50 */     actual.onSubscribe(sds);
/*    */     
/* 52 */     if (sds.isCancelled()) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 57 */       T t = this.callable.call();
/* 58 */       if (t == null) {
/* 59 */         sds.onComplete();
/*    */       } else {
/*    */         
/* 62 */         sds.complete(t);
/*    */       }
/*    */     
/* 65 */     } catch (Throwable e) {
/* 66 */       actual.onError(Operators.onOperatorError(e, actual.currentContext()));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T block() {
/* 75 */     return block(Duration.ZERO);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T block(Duration m) {
/*    */     try {
/* 82 */       return this.callable.call();
/*    */     }
/* 84 */     catch (Throwable e) {
/* 85 */       throw Exceptions.propagate(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public T call() throws Exception {
/* 92 */     return this.callable.call();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 97 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 98 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoCallable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */