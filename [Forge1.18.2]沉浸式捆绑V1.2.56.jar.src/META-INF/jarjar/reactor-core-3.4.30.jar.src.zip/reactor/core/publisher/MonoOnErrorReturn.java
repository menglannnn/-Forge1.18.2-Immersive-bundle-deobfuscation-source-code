/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoOnErrorReturn<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   @Nullable
/*    */   final Predicate<? super Throwable> resumableErrorPredicate;
/*    */   @Nullable
/*    */   final T fallbackValue;
/*    */   
/*    */   MonoOnErrorReturn(Mono<? extends T> source, @Nullable Predicate<? super Throwable> predicate, @Nullable T value) {
/* 38 */     super(source);
/* 39 */     this.resumableErrorPredicate = predicate;
/* 40 */     this.fallbackValue = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 45 */     return new FluxOnErrorReturn.ReturnSubscriber<>(actual, this.resumableErrorPredicate, this.fallbackValue, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 50 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 51 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoOnErrorReturn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */