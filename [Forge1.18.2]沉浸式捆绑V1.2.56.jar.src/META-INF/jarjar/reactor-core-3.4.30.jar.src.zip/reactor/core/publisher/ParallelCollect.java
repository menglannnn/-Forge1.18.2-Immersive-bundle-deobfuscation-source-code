/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelCollect<T, C>
/*     */   extends ParallelFlux<C>
/*     */   implements Scannable, Fuseable
/*     */ {
/*     */   final ParallelFlux<? extends T> source;
/*     */   final Supplier<? extends C> initialCollection;
/*     */   final BiConsumer<? super C, ? super T> collector;
/*     */   
/*     */   ParallelCollect(ParallelFlux<? extends T> source, Supplier<? extends C> initialCollection, BiConsumer<? super C, ? super T> collector) {
/*  47 */     this.source = source;
/*  48 */     this.initialCollection = initialCollection;
/*  49 */     this.collector = collector;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  55 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  56 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  57 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  64 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super C>[] subscribers) {
/*  69 */     if (!validate((Subscriber<?>[])subscribers)) {
/*     */       return;
/*     */     }
/*     */     
/*  73 */     int n = subscribers.length;
/*  74 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*     */     
/*  76 */     for (int i = 0; i < n; i++) {
/*     */       C initialValue;
/*     */ 
/*     */       
/*     */       try {
/*  81 */         initialValue = Objects.requireNonNull(this.initialCollection.get(), "The initialSupplier returned a null value");
/*     */       
/*     */       }
/*  84 */       catch (Throwable ex) {
/*  85 */         reportError((Subscriber<?>[])subscribers, Operators.onOperatorError(ex, subscribers[i]
/*  86 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/*  90 */       arrayOfCoreSubscriber[i] = new ParallelCollectSubscriber<>(subscribers[i], initialValue, this.collector);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*     */   }
/*     */   
/*     */   void reportError(Subscriber<?>[] subscribers, Throwable ex) {
/*  99 */     for (Subscriber<?> s : subscribers) {
/* 100 */       Operators.error(s, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/* 106 */     return this.source.parallelism();
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ParallelCollectSubscriber<T, C>
/*     */     extends Operators.MonoSubscriber<T, C>
/*     */   {
/*     */     final BiConsumer<? super C, ? super T> collector;
/*     */     
/*     */     C collection;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     ParallelCollectSubscriber(CoreSubscriber<? super C> subscriber, C initialValue, BiConsumer<? super C, ? super T> collector) {
/* 123 */       super(subscriber);
/* 124 */       this.collection = initialValue;
/* 125 */       this.collector = collector;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 130 */       if (Operators.validate(this.s, s)) {
/* 131 */         this.s = s;
/*     */         
/* 133 */         this.actual.onSubscribe(this);
/*     */         
/* 135 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 141 */       if (this.done) {
/* 142 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/* 147 */         this.collector.accept(this.collection, t);
/*     */       }
/* 149 */       catch (Throwable ex) {
/* 150 */         onError(Operators.onOperatorError(this, ex, t, this.actual.currentContext()));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 156 */       if (this.done) {
/* 157 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 160 */       this.done = true;
/* 161 */       this.collection = null;
/* 162 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 167 */       if (this.done) {
/*     */         return;
/*     */       }
/* 170 */       this.done = true;
/* 171 */       C c = this.collection;
/* 172 */       this.collection = null;
/* 173 */       complete(c);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 178 */       super.cancel();
/* 179 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 184 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 185 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ParallelCollect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */