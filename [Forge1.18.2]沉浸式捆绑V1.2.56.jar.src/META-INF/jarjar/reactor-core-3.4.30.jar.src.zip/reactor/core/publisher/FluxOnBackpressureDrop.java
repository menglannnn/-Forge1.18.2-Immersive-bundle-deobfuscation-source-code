/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxOnBackpressureDrop<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   static final Consumer<Object> NOOP = t -> {
/*     */     
/*     */     };
/*     */   final Consumer<? super T> onDrop;
/*     */   
/*     */   FluxOnBackpressureDrop(Flux<? extends T> source) {
/*  42 */     super(source);
/*  43 */     this.onDrop = (Consumer)NOOP;
/*     */   }
/*     */ 
/*     */   
/*     */   FluxOnBackpressureDrop(Flux<? extends T> source, Consumer<? super T> onDrop) {
/*  48 */     super(source);
/*  49 */     this.onDrop = Objects.<Consumer<? super T>>requireNonNull(onDrop, "onDrop");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  54 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  59 */     return new DropSubscriber<>(actual, this.onDrop);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  64 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  65 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DropSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Consumer<? super T> onDrop;
/*     */     
/*     */     Subscription s;
/*     */     volatile long requested;
/*  80 */     static final AtomicLongFieldUpdater<DropSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(DropSubscriber.class, "requested");
/*     */     
/*     */     boolean done;
/*     */     
/*     */     DropSubscriber(CoreSubscriber<? super T> actual, Consumer<? super T> onDrop) {
/*  85 */       this.actual = actual;
/*  86 */       this.ctx = actual.currentContext();
/*  87 */       this.onDrop = onDrop;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/*  92 */       if (Operators.validate(n)) {
/*  93 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/*  99 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 104 */       if (Operators.validate(this.s, s)) {
/* 105 */         this.s = s;
/*     */         
/* 107 */         this.actual.onSubscribe(this);
/*     */         
/* 109 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 115 */       if (this.done) {
/*     */         try {
/* 117 */           this.onDrop.accept(t);
/*     */         }
/* 119 */         catch (Throwable e) {
/* 120 */           Operators.onErrorDropped(e, this.ctx);
/*     */         } 
/* 122 */         Operators.onDiscard(t, this.ctx);
/*     */         
/*     */         return;
/*     */       } 
/* 126 */       long r = this.requested;
/* 127 */       if (r != 0L) {
/* 128 */         this.actual.onNext(t);
/* 129 */         if (r != Long.MAX_VALUE) {
/* 130 */           Operators.produced(REQUESTED, this, 1L);
/*     */         }
/*     */       } else {
/*     */         
/*     */         try {
/* 135 */           this.onDrop.accept(t);
/*     */         }
/* 137 */         catch (Throwable e) {
/* 138 */           onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/*     */         } 
/* 140 */         Operators.onDiscard(t, this.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 146 */       if (this.done) {
/* 147 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 150 */       this.done = true;
/*     */       
/* 152 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 157 */       if (this.done) {
/*     */         return;
/*     */       }
/* 160 */       this.done = true;
/*     */       
/* 162 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 167 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 173 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 174 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 175 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 176 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 177 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 179 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxOnBackpressureDrop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */