/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class UnicastProcessor<T>
/*     */   extends FluxProcessor<T, T>
/*     */   implements Fuseable.QueueSubscription<T>, Fuseable, InnerOperator<T, T>, InternalManySink<T>
/*     */ {
/*     */   final Queue<T> queue;
/*     */   final Consumer<? super T> onOverflow;
/*     */   volatile Disposable onTerminate;
/*     */   
/*     */   @Deprecated
/*     */   public static <E> UnicastProcessor<E> create() {
/* 109 */     return new UnicastProcessor<>(Queues.unbounded().get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> UnicastProcessor<E> create(Queue<E> queue) {
/* 124 */     return new UnicastProcessor<>(Hooks.wrapQueue(queue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> UnicastProcessor<E> create(Queue<E> queue, Disposable endcallback) {
/* 140 */     return new UnicastProcessor<>(Hooks.wrapQueue(queue), endcallback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> UnicastProcessor<E> create(Queue<E> queue, Consumer<? super E> onOverflow, Disposable endcallback) {
/* 162 */     return new UnicastProcessor<>(Hooks.wrapQueue(queue), onOverflow, endcallback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   static final AtomicReferenceFieldUpdater<UnicastProcessor, Disposable> ON_TERMINATE = AtomicReferenceFieldUpdater.newUpdater(UnicastProcessor.class, Disposable.class, "onTerminate");
/*     */   
/*     */   volatile boolean done;
/*     */   
/*     */   Throwable error;
/*     */   
/*     */   boolean hasDownstream;
/*     */   
/*     */   volatile CoreSubscriber<? super T> actual;
/*     */   
/*     */   volatile boolean cancelled;
/*     */   
/*     */   volatile int once;
/* 184 */   static final AtomicIntegerFieldUpdater<UnicastProcessor> ONCE = AtomicIntegerFieldUpdater.newUpdater(UnicastProcessor.class, "once");
/*     */ 
/*     */   
/*     */   volatile int wip;
/*     */   
/* 189 */   static final AtomicIntegerFieldUpdater<UnicastProcessor> WIP = AtomicIntegerFieldUpdater.newUpdater(UnicastProcessor.class, "wip");
/*     */ 
/*     */   
/*     */   volatile int discardGuard;
/*     */   
/* 194 */   static final AtomicIntegerFieldUpdater<UnicastProcessor> DISCARD_GUARD = AtomicIntegerFieldUpdater.newUpdater(UnicastProcessor.class, "discardGuard");
/*     */ 
/*     */   
/*     */   volatile long requested;
/*     */   
/* 199 */   static final AtomicLongFieldUpdater<UnicastProcessor> REQUESTED = AtomicLongFieldUpdater.newUpdater(UnicastProcessor.class, "requested");
/*     */   
/*     */   boolean outputFused;
/*     */   
/*     */   public UnicastProcessor(Queue<T> queue) {
/* 204 */     this.queue = Objects.<Queue<T>>requireNonNull(queue, "queue");
/* 205 */     this.onTerminate = null;
/* 206 */     this.onOverflow = null;
/*     */   }
/*     */   
/*     */   public UnicastProcessor(Queue<T> queue, Disposable onTerminate) {
/* 210 */     this.queue = Objects.<Queue<T>>requireNonNull(queue, "queue");
/* 211 */     this.onTerminate = Objects.<Disposable>requireNonNull(onTerminate, "onTerminate");
/* 212 */     this.onOverflow = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public UnicastProcessor(Queue<T> queue, Consumer<? super T> onOverflow, Disposable onTerminate) {
/* 219 */     this.queue = Objects.<Queue<T>>requireNonNull(queue, "queue");
/* 220 */     this.onOverflow = Objects.<Consumer<? super T>>requireNonNull(onOverflow, "onOverflow");
/* 221 */     this.onTerminate = Objects.<Disposable>requireNonNull(onTerminate, "onTerminate");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBufferSize() {
/* 226 */     return Queues.capacity(this.queue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<Scannable> inners() {
/* 231 */     return this.hasDownstream ? Stream.<Scannable>of(Scannable.from(this.actual)) : Stream.<Scannable>empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 236 */     if (Scannable.Attr.ACTUAL == key) return actual(); 
/* 237 */     if (Scannable.Attr.BUFFERED == key) return Integer.valueOf(this.queue.size()); 
/* 238 */     if (Scannable.Attr.PREFETCH == key) return Integer.valueOf(2147483647); 
/* 239 */     if (Scannable.Attr.CANCELLED == key) return Boolean.valueOf(this.cancelled);
/*     */ 
/*     */     
/* 242 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 248 */     Sinks.EmitResult emitResult = tryEmitComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitComplete() {
/* 253 */     if (this.done) {
/* 254 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/* 256 */     if (this.cancelled) {
/* 257 */       return Sinks.EmitResult.FAIL_CANCELLED;
/*     */     }
/*     */     
/* 260 */     this.done = true;
/*     */     
/* 262 */     doTerminate();
/*     */     
/* 264 */     drain(null);
/* 265 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable throwable) {
/* 270 */     emitError(throwable, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitError(Throwable t) {
/* 275 */     if (this.done) {
/* 276 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/* 278 */     if (this.cancelled) {
/* 279 */       return Sinks.EmitResult.FAIL_CANCELLED;
/*     */     }
/*     */     
/* 282 */     this.error = t;
/* 283 */     this.done = true;
/*     */     
/* 285 */     doTerminate();
/*     */     
/* 287 */     drain((T)null);
/* 288 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNext(T t) {
/* 293 */     emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */   
/*     */   public void emitNext(T value, Sinks.EmitFailureHandler failureHandler) {
/* 298 */     if (this.onOverflow == null) {
/* 299 */       super.emitNext(value, failureHandler);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 304 */     super.emitNext(value, (signalType, emission) -> {
/*     */           boolean shouldRetry = failureHandler.onEmitFailure(SignalType.ON_NEXT, emission);
/*     */ 
/*     */           
/*     */           if (!shouldRetry) {
/*     */             switch (emission) {
/*     */               case FAIL_ZERO_SUBSCRIBER:
/*     */               case FAIL_OVERFLOW:
/*     */                 try {
/*     */                   this.onOverflow.accept((T)value);
/* 314 */                 } catch (Throwable e) {
/*     */                   Exceptions.throwIfFatal(e);
/*     */                   emitError(e, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */                 } 
/*     */                 break;
/*     */             } 
/*     */           }
/*     */           return shouldRetry;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitNext(T t) {
/* 328 */     if (this.done) {
/* 329 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/* 331 */     if (this.cancelled) {
/* 332 */       return Sinks.EmitResult.FAIL_CANCELLED;
/*     */     }
/*     */     
/* 335 */     if (!this.queue.offer(t)) {
/* 336 */       return (this.once > 0) ? Sinks.EmitResult.FAIL_OVERFLOW : Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER;
/*     */     }
/* 338 */     drain(t);
/* 339 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public int currentSubscriberCount() {
/* 344 */     return this.hasDownstream ? 1 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<T> asFlux() {
/* 349 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isIdentityProcessor() {
/* 354 */     return true;
/*     */   }
/*     */   
/*     */   void doTerminate() {
/* 358 */     Disposable r = this.onTerminate;
/* 359 */     if (r != null && ON_TERMINATE.compareAndSet(this, r, null)) {
/* 360 */       r.dispose();
/*     */     }
/*     */   }
/*     */   
/*     */   void drainRegular(CoreSubscriber<? super T> a) {
/* 365 */     int missed = 1;
/*     */     
/* 367 */     Queue<T> q = this.queue;
/*     */ 
/*     */     
/*     */     do {
/* 371 */       long r = this.requested;
/* 372 */       long e = 0L;
/*     */       
/* 374 */       while (r != e) {
/* 375 */         boolean d = this.done;
/*     */         
/* 377 */         T t = q.poll();
/* 378 */         boolean empty = (t == null);
/*     */         
/* 380 */         if (checkTerminated(d, empty, a, q, t)) {
/*     */           return;
/*     */         }
/*     */         
/* 384 */         if (empty) {
/*     */           break;
/*     */         }
/*     */         
/* 388 */         a.onNext(t);
/*     */         
/* 390 */         e++;
/*     */       } 
/*     */       
/* 393 */       if (r == e && 
/* 394 */         checkTerminated(this.done, q.isEmpty(), a, q, (T)null)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 399 */       if (e != 0L && r != Long.MAX_VALUE) {
/* 400 */         REQUESTED.addAndGet(this, -e);
/*     */       }
/*     */       
/* 403 */       missed = WIP.addAndGet(this, -missed);
/* 404 */     } while (missed != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void drainFused(CoreSubscriber<? super T> a) {
/* 411 */     int missed = 1;
/*     */ 
/*     */     
/*     */     do {
/* 415 */       if (this.cancelled) {
/*     */ 
/*     */         
/* 418 */         clear();
/* 419 */         this.hasDownstream = false;
/*     */         
/*     */         return;
/*     */       } 
/* 423 */       boolean d = this.done;
/*     */       
/* 425 */       a.onNext(null);
/*     */       
/* 427 */       if (d) {
/* 428 */         this.hasDownstream = false;
/*     */         
/* 430 */         Throwable ex = this.error;
/* 431 */         if (ex != null) {
/* 432 */           a.onError(ex);
/*     */         } else {
/* 434 */           a.onComplete();
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 439 */       missed = WIP.addAndGet(this, -missed);
/* 440 */     } while (missed != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void drain(@Nullable T dataSignalOfferedBeforeDrain) {
/* 447 */     if (WIP.getAndIncrement(this) != 0) {
/* 448 */       if (dataSignalOfferedBeforeDrain != null) {
/* 449 */         if (this.cancelled) {
/* 450 */           Operators.onDiscard(dataSignalOfferedBeforeDrain, this.actual
/* 451 */               .currentContext());
/*     */         }
/* 453 */         else if (this.done) {
/* 454 */           Operators.onNextDropped(dataSignalOfferedBeforeDrain, 
/* 455 */               currentContext());
/*     */         } 
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 461 */     int missed = 1;
/*     */     
/*     */     do {
/* 464 */       CoreSubscriber<? super T> a = this.actual;
/* 465 */       if (a != null) {
/*     */         
/* 467 */         if (this.outputFused) {
/* 468 */           drainFused(a);
/*     */         } else {
/* 470 */           drainRegular(a);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 475 */       missed = WIP.addAndGet(this, -missed);
/* 476 */     } while (missed != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean checkTerminated(boolean d, boolean empty, CoreSubscriber<? super T> a, Queue<T> q, @Nullable T t) {
/* 483 */     if (this.cancelled) {
/* 484 */       Operators.onDiscard(t, a.currentContext());
/* 485 */       Operators.onDiscardQueueWithClear(q, a.currentContext(), null);
/* 486 */       this.hasDownstream = false;
/* 487 */       return true;
/*     */     } 
/* 489 */     if (d && empty) {
/* 490 */       Throwable e = this.error;
/* 491 */       this.hasDownstream = false;
/* 492 */       if (e != null) {
/* 493 */         a.onError(e);
/*     */       } else {
/* 495 */         a.onComplete();
/*     */       } 
/* 497 */       return true;
/*     */     } 
/*     */     
/* 500 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription s) {
/* 505 */     if (this.done || this.cancelled) {
/* 506 */       s.cancel();
/*     */     } else {
/* 508 */       s.request(Long.MAX_VALUE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 514 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 519 */     CoreSubscriber<? super T> actual = this.actual;
/* 520 */     return (actual != null) ? actual.currentContext() : Context.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 525 */     Objects.requireNonNull(actual, "subscribe");
/* 526 */     if (this.once == 0 && ONCE.compareAndSet(this, 0, 1)) {
/*     */       
/* 528 */       this.hasDownstream = true;
/* 529 */       actual.onSubscribe(this);
/* 530 */       this.actual = actual;
/* 531 */       if (this.cancelled) {
/* 532 */         this.hasDownstream = false;
/*     */       } else {
/* 534 */         drain((T)null);
/*     */       } 
/*     */     } else {
/* 537 */       Operators.error((Subscriber<?>)actual, new IllegalStateException("UnicastProcessor allows only a single Subscriber"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void request(long n) {
/* 544 */     if (Operators.validate(n)) {
/* 545 */       Operators.addCap(REQUESTED, this, n);
/* 546 */       drain((T)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 552 */     if (this.cancelled) {
/*     */       return;
/*     */     }
/* 555 */     this.cancelled = true;
/*     */     
/* 557 */     doTerminate();
/*     */     
/* 559 */     if (WIP.getAndIncrement(this) == 0) {
/* 560 */       if (!this.outputFused)
/*     */       {
/*     */         
/* 563 */         Operators.onDiscardQueueWithClear(this.queue, currentContext(), null);
/*     */       }
/* 565 */       this.hasDownstream = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T poll() {
/* 572 */     return this.queue.poll();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 577 */     return this.queue.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 582 */     return this.queue.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 590 */     if (DISCARD_GUARD.getAndIncrement(this) != 0) {
/*     */       return;
/*     */     }
/*     */     
/* 594 */     int missed = 1;
/*     */     
/*     */     while (true) {
/* 597 */       Operators.onDiscardQueueWithClear(this.queue, currentContext(), null);
/*     */       
/* 599 */       int dg = this.discardGuard;
/* 600 */       if (missed == dg) {
/* 601 */         missed = DISCARD_GUARD.addAndGet(this, -missed);
/* 602 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */         continue;
/*     */       } 
/* 607 */       missed = dg;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int requestFusion(int requestedMode) {
/* 614 */     if ((requestedMode & 0x2) != 0) {
/* 615 */       this.outputFused = true;
/* 616 */       return 2;
/*     */     } 
/* 618 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 623 */     return (this.cancelled || this.done);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 628 */     return this.done;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getError() {
/* 634 */     return this.error;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> actual() {
/* 639 */     return this.actual;
/*     */   }
/*     */ 
/*     */   
/*     */   public long downstreamCount() {
/* 644 */     return hasDownstreams() ? 1L : 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasDownstreams() {
/* 649 */     return this.hasDownstream;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\UnicastProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */