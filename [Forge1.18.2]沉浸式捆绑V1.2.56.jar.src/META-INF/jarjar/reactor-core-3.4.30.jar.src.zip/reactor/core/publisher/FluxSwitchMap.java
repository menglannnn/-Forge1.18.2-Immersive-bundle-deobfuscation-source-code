/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSwitchMap<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */   final Supplier<? extends Queue<Object>> queueSupplier;
/*     */   final int prefetch;
/*  56 */   static final SwitchMapInner<Object> CANCELLED_INNER = new SwitchMapInner(null, 0, Long.MAX_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FluxSwitchMap(Flux<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper, Supplier<? extends Queue<Object>> queueSupplier, int prefetch) {
/*  63 */     super(source);
/*  64 */     if (prefetch <= 0) {
/*  65 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*     */     
/*  68 */     this.mapper = Objects.<Function<? super T, ? extends Publisher<? extends R>>>requireNonNull(mapper, "mapper");
/*  69 */     this.queueSupplier = Objects.<Supplier<? extends Queue<Object>>>requireNonNull(queueSupplier, "queueSupplier");
/*  70 */     this.prefetch = prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  75 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  81 */     if (FluxFlatMap.trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, this.mapper, false, false)) {
/*  82 */       return null;
/*     */     }
/*     */     
/*  85 */     return new SwitchMapMain<>(actual, this.mapper, this.queueSupplier
/*     */         
/*  87 */         .get(), this.prefetch);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  92 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  93 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SwitchMapMain<T, R>
/*     */     implements InnerOperator<T, R>
/*     */   {
/*     */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */     
/*     */     final Queue<Object> queue;
/*     */     
/*     */     final BiPredicate<Object, Object> queueBiAtomic;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     Subscription s;
/*     */     volatile boolean done;
/*     */     volatile Throwable error;
/* 113 */     static final AtomicReferenceFieldUpdater<SwitchMapMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(SwitchMapMain.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     volatile boolean cancelled;
/*     */ 
/*     */     
/*     */     volatile int once;
/*     */ 
/*     */     
/* 122 */     static final AtomicIntegerFieldUpdater<SwitchMapMain> ONCE = AtomicIntegerFieldUpdater.newUpdater(SwitchMapMain.class, "once");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 127 */     static final AtomicLongFieldUpdater<SwitchMapMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(SwitchMapMain.class, "requested");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/* 132 */     static final AtomicIntegerFieldUpdater<SwitchMapMain> WIP = AtomicIntegerFieldUpdater.newUpdater(SwitchMapMain.class, "wip");
/*     */ 
/*     */     
/*     */     volatile FluxSwitchMap.SwitchMapInner<R> inner;
/*     */     
/* 137 */     static final AtomicReferenceFieldUpdater<SwitchMapMain, FluxSwitchMap.SwitchMapInner> INNER = AtomicReferenceFieldUpdater.newUpdater(SwitchMapMain.class, FluxSwitchMap.SwitchMapInner.class, "inner");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long index;
/*     */ 
/*     */     
/* 144 */     static final AtomicLongFieldUpdater<SwitchMapMain> INDEX = AtomicLongFieldUpdater.newUpdater(SwitchMapMain.class, "index");
/*     */ 
/*     */     
/*     */     volatile int active;
/*     */     
/* 149 */     static final AtomicIntegerFieldUpdater<SwitchMapMain> ACTIVE = AtomicIntegerFieldUpdater.newUpdater(SwitchMapMain.class, "active");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SwitchMapMain(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper, Queue<Object> queue, int prefetch) {
/* 156 */       this.actual = actual;
/* 157 */       this.mapper = mapper;
/* 158 */       this.queue = queue;
/* 159 */       this.prefetch = prefetch;
/* 160 */       this.active = 1;
/* 161 */       if (queue instanceof BiPredicate) {
/* 162 */         this.queueBiAtomic = (BiPredicate)queue;
/*     */       } else {
/*     */         
/* 165 */         this.queueBiAtomic = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super R> actual() {
/* 171 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 177 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 178 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 179 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 180 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 181 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 182 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 183 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 184 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 186 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 191 */       return Stream.of(this.inner);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 196 */       if (Operators.validate(this.s, s)) {
/* 197 */         this.s = s;
/*     */         
/* 199 */         this.actual.onSubscribe(this);
/*     */         
/* 201 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       Publisher<? extends R> p;
/* 207 */       if (this.done) {
/* 208 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 212 */       long idx = INDEX.incrementAndGet(this);
/*     */       
/* 214 */       FluxSwitchMap.SwitchMapInner<R> si = this.inner;
/* 215 */       if (si != null) {
/* 216 */         si.deactivate();
/* 217 */         si.cancel();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 223 */         p = Objects.<Publisher<? extends R>>requireNonNull(this.mapper.apply(t), "The mapper returned a null publisher");
/*     */       
/*     */       }
/* 226 */       catch (Throwable e) {
/* 227 */         onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 231 */       FluxSwitchMap.SwitchMapInner<R> innerSubscriber = new FluxSwitchMap.SwitchMapInner<>(this, this.prefetch, idx);
/*     */ 
/*     */       
/* 234 */       if (INNER.compareAndSet(this, si, innerSubscriber)) {
/* 235 */         ACTIVE.getAndIncrement(this);
/* 236 */         p.subscribe((Subscriber)innerSubscriber);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 242 */       if (this.done) {
/* 243 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 247 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/*     */         
/* 249 */         if (ONCE.compareAndSet(this, 0, 1)) {
/* 250 */           deactivate();
/*     */         }
/*     */         
/* 253 */         cancelInner();
/* 254 */         this.done = true;
/* 255 */         drain();
/*     */       } else {
/*     */         
/* 258 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 264 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */       
/* 268 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 269 */         deactivate();
/*     */       }
/*     */       
/* 272 */       this.done = true;
/* 273 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 278 */       if (Operators.validate(n)) {
/* 279 */         Operators.addCap(REQUESTED, this, n);
/* 280 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 286 */       if (!this.cancelled) {
/* 287 */         this.cancelled = true;
/*     */         
/* 289 */         if (WIP.getAndIncrement(this) == 0) {
/* 290 */           cancelAndCleanup(this.queue);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void deactivate() {
/* 296 */       ACTIVE.decrementAndGet(this);
/*     */     }
/*     */     
/*     */     void cancelInner() {
/* 300 */       FluxSwitchMap.SwitchMapInner<?> si = INNER.getAndSet(this, FluxSwitchMap.CANCELLED_INNER);
/* 301 */       if (si != null && si != FluxSwitchMap.CANCELLED_INNER) {
/* 302 */         si.cancel();
/* 303 */         si.deactivate();
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelAndCleanup(Queue<?> q) {
/* 308 */       this.s.cancel();
/*     */       
/* 310 */       cancelInner();
/*     */       
/* 312 */       q.clear();
/*     */     }
/*     */     
/*     */     void drain() {
/* 316 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 320 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/* 321 */       Queue<Object> q = this.queue;
/*     */       
/* 323 */       int missed = 1;
/*     */ 
/*     */       
/*     */       do {
/* 327 */         long r = this.requested;
/* 328 */         long e = 0L;
/*     */         
/* 330 */         while (r != e) {
/* 331 */           boolean d = (this.active == 0);
/*     */ 
/*     */           
/* 334 */           FluxSwitchMap.SwitchMapInner<R> si = (FluxSwitchMap.SwitchMapInner<R>)q.poll();
/*     */           
/* 336 */           boolean empty = (si == null);
/*     */           
/* 338 */           if (checkTerminated(d, empty, (Subscriber<?>)coreSubscriber, q)) {
/*     */             return;
/*     */           }
/*     */           
/* 342 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/*     */           Object second;
/*     */           
/* 348 */           while ((second = q.poll()) == null);
/*     */ 
/*     */           
/* 351 */           if (this.index == si.index) {
/*     */             
/* 353 */             R v = (R)second;
/*     */             
/* 355 */             coreSubscriber.onNext(v);
/*     */             
/* 357 */             si.requestOne();
/*     */             
/* 359 */             e++;
/*     */           } 
/*     */         } 
/*     */         
/* 363 */         if (r == e && 
/* 364 */           checkTerminated((this.active == 0), q.isEmpty(), (Subscriber<?>)coreSubscriber, q)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 369 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 370 */           REQUESTED.addAndGet(this, -e);
/*     */         }
/*     */         
/* 373 */         missed = WIP.addAndGet(this, -missed);
/* 374 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, Queue<?> q) {
/* 381 */       if (this.cancelled) {
/* 382 */         cancelAndCleanup(q);
/* 383 */         return true;
/*     */       } 
/*     */       
/* 386 */       if (d) {
/* 387 */         Throwable e = Exceptions.terminate(ERROR, this);
/* 388 */         if (e != null && e != Exceptions.TERMINATED) {
/* 389 */           cancelAndCleanup(q);
/*     */           
/* 391 */           a.onError(e);
/* 392 */           return true;
/*     */         } 
/* 394 */         if (empty) {
/* 395 */           a.onComplete();
/* 396 */           return true;
/*     */         } 
/*     */       } 
/*     */       
/* 400 */       return false;
/*     */     }
/*     */     
/*     */     void innerNext(FluxSwitchMap.SwitchMapInner<R> inner, R value) {
/* 404 */       if (this.queueBiAtomic != null) {
/*     */         
/* 406 */         this.queueBiAtomic.test(inner, value);
/*     */       }
/*     */       else {
/*     */         
/* 410 */         this.queue.offer(inner);
/* 411 */         this.queue.offer(value);
/*     */       } 
/* 413 */       drain();
/*     */     }
/*     */     
/*     */     void innerError(FluxSwitchMap.SwitchMapInner<R> inner, Throwable e) {
/* 417 */       if (Exceptions.addThrowable(ERROR, this, e)) {
/* 418 */         this.s.cancel();
/*     */         
/* 420 */         if (ONCE.compareAndSet(this, 0, 1)) {
/* 421 */           deactivate();
/*     */         }
/* 423 */         inner.deactivate();
/* 424 */         drain();
/*     */       } else {
/*     */         
/* 427 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void innerComplete(FluxSwitchMap.SwitchMapInner<R> inner) {
/* 432 */       inner.deactivate();
/* 433 */       drain();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SwitchMapInner<R>
/*     */     implements InnerConsumer<R>, Subscription
/*     */   {
/*     */     final FluxSwitchMap.SwitchMapMain<?, R> parent;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final long index;
/*     */     
/*     */     volatile int once;
/* 450 */     static final AtomicIntegerFieldUpdater<SwitchMapInner> ONCE = AtomicIntegerFieldUpdater.newUpdater(SwitchMapInner.class, "once");
/*     */ 
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 455 */     static final AtomicReferenceFieldUpdater<SwitchMapInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(SwitchMapInner.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     int produced;
/*     */ 
/*     */     
/*     */     SwitchMapInner(FluxSwitchMap.SwitchMapMain<?, R> parent, int prefetch, long index) {
/* 462 */       this.parent = parent;
/* 463 */       this.prefetch = prefetch;
/* 464 */       this.limit = Operators.unboundedOrLimit(prefetch);
/* 465 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 470 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 476 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 477 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 478 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 479 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 480 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 482 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 487 */       Subscription a = this.s;
/* 488 */       if (a == Operators.cancelledSubscription()) {
/* 489 */         s.cancel();
/*     */       }
/* 491 */       if (a != null) {
/* 492 */         s.cancel();
/*     */         
/* 494 */         Operators.reportSubscriptionSet();
/*     */         
/*     */         return;
/*     */       } 
/* 498 */       if (S.compareAndSet(this, null, s)) {
/* 499 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */         return;
/*     */       } 
/* 502 */       a = this.s;
/* 503 */       if (a != Operators.cancelledSubscription()) {
/* 504 */         s.cancel();
/*     */         
/* 506 */         Operators.reportSubscriptionSet();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(R t) {
/* 512 */       this.parent.innerNext(this, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 517 */       this.parent.innerError(this, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 522 */       this.parent.innerComplete(this);
/*     */     }
/*     */     
/*     */     void deactivate() {
/* 526 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 527 */         this.parent.deactivate();
/*     */       }
/*     */     }
/*     */     
/*     */     void requestOne() {
/* 532 */       int p = this.produced + 1;
/* 533 */       if (p == this.limit) {
/* 534 */         this.produced = 0;
/* 535 */         this.s.request(p);
/*     */       } else {
/*     */         
/* 538 */         this.produced = p;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 544 */       long p = this.produced + n;
/* 545 */       if (p >= this.limit) {
/* 546 */         this.produced = 0;
/* 547 */         this.s.request(p);
/*     */       } else {
/*     */         
/* 550 */         this.produced = (int)p;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 556 */       Subscription a = this.s;
/* 557 */       if (a != Operators.cancelledSubscription()) {
/* 558 */         a = S.getAndSet(this, Operators.cancelledSubscription());
/* 559 */         if (a != null && a != Operators.cancelledSubscription())
/* 560 */           a.cancel(); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxSwitchMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */