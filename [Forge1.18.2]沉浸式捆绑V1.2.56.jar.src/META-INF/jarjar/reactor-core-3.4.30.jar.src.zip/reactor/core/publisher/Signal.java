/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Signal<T>
/*     */   extends Supplier<T>, Consumer<Subscriber<? super T>>
/*     */ {
/*     */   static <T> Signal<T> complete() {
/*  50 */     return ImmutableSignal.onComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Signal<T> complete(Context context) {
/*  63 */     if (context.isEmpty()) {
/*  64 */       return ImmutableSignal.onComplete();
/*     */     }
/*  66 */     return new ImmutableSignal<>((ContextView)context, SignalType.ON_COMPLETE, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Signal<T> error(Throwable e) {
/*  81 */     return error(e, Context.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Signal<T> error(Throwable e, Context context) {
/*  95 */     return new ImmutableSignal<>((ContextView)context, SignalType.ON_ERROR, null, e, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Signal<T> next(T t) {
/* 110 */     return next(t, Context.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Signal<T> next(T t, Context context) {
/* 124 */     return new ImmutableSignal<>((ContextView)context, SignalType.ON_NEXT, t, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Signal<T> subscribe(Subscription subscription) {
/* 138 */     return subscribe(subscription, Context.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Signal<T> subscribe(Subscription subscription, Context context) {
/* 152 */     return new ImmutableSignal<>((ContextView)context, SignalType.ON_SUBSCRIBE, null, null, subscription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isComplete(Object o) {
/* 162 */     return (o == ImmutableSignal.onComplete() || (o instanceof Signal && ((Signal)o)
/* 163 */       .getType() == SignalType.ON_COMPLETE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isError(Object o) {
/* 173 */     return (o instanceof Signal && ((Signal)o).getType() == SignalType.ON_ERROR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean hasValue() {
/* 210 */     return (isOnNext() && get() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean hasError() {
/* 219 */     return (isOnError() && getThrowable() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Context getContext() {
/* 240 */     return Context.of(getContextView());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isOnError() {
/* 258 */     return (getType() == SignalType.ON_ERROR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isOnComplete() {
/* 268 */     return (getType() == SignalType.ON_COMPLETE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isOnSubscribe() {
/* 278 */     return (getType() == SignalType.ON_SUBSCRIBE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isOnNext() {
/* 287 */     return (getType() == SignalType.ON_NEXT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void accept(Subscriber<? super T> observer) {
/* 298 */     if (isOnNext()) {
/* 299 */       observer.onNext(get());
/*     */     }
/* 301 */     else if (isOnComplete()) {
/* 302 */       observer.onComplete();
/*     */     }
/* 304 */     else if (isOnError()) {
/* 305 */       observer.onError(getThrowable());
/*     */     }
/* 307 */     else if (isOnSubscribe()) {
/* 308 */       observer.onSubscribe(getSubscription());
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   Throwable getThrowable();
/*     */   
/*     */   @Nullable
/*     */   Subscription getSubscription();
/*     */   
/*     */   @Nullable
/*     */   T get();
/*     */   
/*     */   SignalType getType();
/*     */   
/*     */   ContextView getContextView();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\Signal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */