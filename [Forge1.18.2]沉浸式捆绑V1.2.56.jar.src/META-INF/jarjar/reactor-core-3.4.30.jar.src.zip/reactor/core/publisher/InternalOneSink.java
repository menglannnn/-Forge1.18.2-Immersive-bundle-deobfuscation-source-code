/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface InternalOneSink<T>
/*    */   extends Sinks.One<T>, InternalEmptySink<T>
/*    */ {
/*    */   default void emitValue(@Nullable T value, Sinks.EmitFailureHandler failureHandler) {
/*    */     Sinks.EmitResult emitResult;
/* 27 */     if (value == null) {
/* 28 */       emitEmpty(failureHandler);
/*    */       
/*    */       return;
/*    */     } 
/*    */     while (true) {
/* 33 */       emitResult = tryEmitValue(value);
/* 34 */       if (emitResult.isSuccess()) {
/*    */         return;
/*    */       }
/*    */       
/* 38 */       boolean shouldRetry = failureHandler.onEmitFailure(SignalType.ON_NEXT, emitResult);
/*    */       
/* 40 */       if (shouldRetry)
/*    */         continue; 
/*    */       break;
/*    */     } 
/* 44 */     switch (emitResult) {
/*    */       case FAIL_ZERO_SUBSCRIBER:
/*    */         return;
/*    */ 
/*    */       
/*    */       case FAIL_OVERFLOW:
/* 50 */         Operators.onDiscard(value, currentContext());
/*    */         
/* 52 */         emitError(Exceptions.failWithOverflow("Backpressure overflow during Sinks.One#emitValue"), failureHandler);
/*    */         return;
/*    */       
/*    */       case FAIL_CANCELLED:
/* 56 */         Operators.onDiscard(value, currentContext());
/*    */         return;
/*    */       case FAIL_TERMINATED:
/* 59 */         Operators.onNextDropped(value, currentContext());
/*    */         return;
/*    */       case FAIL_NON_SERIALIZED:
/* 62 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*    */     } 
/*    */ 
/*    */     
/* 66 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\InternalOneSink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */