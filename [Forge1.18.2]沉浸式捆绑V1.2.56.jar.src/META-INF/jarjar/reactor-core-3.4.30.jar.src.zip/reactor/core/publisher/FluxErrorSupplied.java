/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Supplier;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxErrorSupplied<T>
/*    */   extends Flux<T>
/*    */   implements Fuseable.ScalarCallable, SourceProducer<T>
/*    */ {
/*    */   final Supplier<? extends Throwable> errorSupplier;
/*    */   
/*    */   FluxErrorSupplied(Supplier<? extends Throwable> errorSupplier) {
/* 39 */     this.errorSupplier = Objects.<Supplier<? extends Throwable>>requireNonNull(errorSupplier, "errorSupplier");
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 44 */     Throwable error = Objects.<Throwable>requireNonNull(this.errorSupplier.get(), "errorSupplier produced a null Throwable");
/* 45 */     Operators.error((Subscriber<?>)actual, error);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object call() throws Exception {
/* 50 */     Throwable error = Objects.<Throwable>requireNonNull(this.errorSupplier.get(), "errorSupplier produced a null Throwable");
/* 51 */     if (error instanceof Exception) {
/* 52 */       throw (Exception)error;
/*    */     }
/* 54 */     throw Exceptions.propagate(error);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 59 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 60 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxErrorSupplied.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */