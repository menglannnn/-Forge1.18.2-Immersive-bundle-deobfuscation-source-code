/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Hooks
/*     */ {
/*     */   static Function<Publisher, Publisher> onEachOperatorHook;
/*     */   static volatile Function<Publisher, Publisher> onLastOperatorHook;
/*     */   static volatile BiFunction<? super Throwable, Object, ? extends Throwable> onOperatorErrorHook;
/*     */   static volatile Consumer<? super Throwable> onErrorDroppedHook;
/*     */   static volatile Consumer<Object> onNextDroppedHook;
/*     */   static volatile OnNextFailureStrategy onNextErrorHook;
/*     */   private static final LinkedHashMap<String, Function<? super Publisher<Object>, ? extends Publisher<Object>>> onEachOperatorHooks;
/*     */   private static final LinkedHashMap<String, Function<? super Publisher<Object>, ? extends Publisher<Object>>> onLastOperatorHooks;
/*     */   private static final LinkedHashMap<String, BiFunction<? super Throwable, Object, ? extends Throwable>> onOperatorErrorHooks;
/*     */   
/*     */   public static <T> Flux<T> convertToFluxBypassingHooks(Publisher<T> publisher) {
/*  49 */     return Flux.wrap(publisher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Mono<T> convertToMonoBypassingHooks(Publisher<T> publisher, boolean enforceMonoContract) {
/*  64 */     return Mono.wrap(publisher, enforceMonoContract);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onEachOperator(Function<? super Publisher<Object>, ? extends Publisher<Object>> onEachOperator) {
/*  96 */     onEachOperator(onEachOperator.toString(), onEachOperator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onEachOperator(String key, Function<? super Publisher<Object>, ? extends Publisher<Object>> onEachOperator) {
/* 129 */     Objects.requireNonNull(key, "key");
/* 130 */     Objects.requireNonNull(onEachOperator, "onEachOperator");
/* 131 */     log.debug("Hooking onEachOperator: {}", new Object[] { key });
/*     */     
/* 133 */     synchronized (log) {
/* 134 */       onEachOperatorHooks.put(key, onEachOperator);
/* 135 */       onEachOperatorHook = createOrUpdateOpHook(onEachOperatorHooks.values());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnEachOperator(String key) {
/* 147 */     Objects.requireNonNull(key, "key");
/* 148 */     log.debug("Reset onEachOperator: {}", new Object[] { key });
/*     */     
/* 150 */     synchronized (log) {
/* 151 */       onEachOperatorHooks.remove(key);
/* 152 */       onEachOperatorHook = createOrUpdateOpHook(onEachOperatorHooks.values());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnEachOperator() {
/* 160 */     log.debug("Reset to factory defaults : onEachOperator");
/* 161 */     synchronized (log) {
/* 162 */       onEachOperatorHooks.clear();
/* 163 */       onEachOperatorHook = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onErrorDropped(Consumer<? super Throwable> c) {
/* 176 */     Objects.requireNonNull(c, "onErrorDroppedHook");
/* 177 */     log.debug("Hooking new default : onErrorDropped");
/*     */     
/* 179 */     synchronized (log) {
/* 180 */       if (onErrorDroppedHook != null) {
/*     */         
/* 182 */         Consumer<Throwable> _c = (Consumer)onErrorDroppedHook.andThen(c);
/* 183 */         onErrorDroppedHook = _c;
/*     */       } else {
/*     */         
/* 186 */         onErrorDroppedHook = c;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onLastOperator(Function<? super Publisher<Object>, ? extends Publisher<Object>> onLastOperator) {
/* 217 */     onLastOperator(onLastOperator.toString(), onLastOperator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onLastOperator(String key, Function<? super Publisher<Object>, ? extends Publisher<Object>> onLastOperator) {
/* 250 */     Objects.requireNonNull(key, "key");
/* 251 */     Objects.requireNonNull(onLastOperator, "onLastOperator");
/* 252 */     log.debug("Hooking onLastOperator: {}", new Object[] { key });
/*     */     
/* 254 */     synchronized (log) {
/* 255 */       onLastOperatorHooks.put(key, onLastOperator);
/* 256 */       onLastOperatorHook = createOrUpdateOpHook(onLastOperatorHooks.values());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnLastOperator(String key) {
/* 268 */     Objects.requireNonNull(key, "key");
/* 269 */     log.debug("Reset onLastOperator: {}", new Object[] { key });
/*     */     
/* 271 */     synchronized (log) {
/* 272 */       onLastOperatorHooks.remove(key);
/* 273 */       onLastOperatorHook = createOrUpdateOpHook(onLastOperatorHooks.values());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnLastOperator() {
/* 281 */     log.debug("Reset to factory defaults : onLastOperator");
/* 282 */     synchronized (log) {
/* 283 */       onLastOperatorHooks.clear();
/* 284 */       onLastOperatorHook = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onNextDropped(Consumer<Object> c) {
/* 298 */     Objects.requireNonNull(c, "onNextDroppedHook");
/* 299 */     log.debug("Hooking new default : onNextDropped");
/*     */     
/* 301 */     synchronized (log) {
/* 302 */       if (onNextDroppedHook != null) {
/* 303 */         onNextDroppedHook = onNextDroppedHook.andThen(c);
/*     */       } else {
/*     */         
/* 306 */         onNextDroppedHook = c;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onNextDroppedFail() {
/* 318 */     log.debug("Enabling failure mode for onNextDropped");
/*     */     
/* 320 */     synchronized (log) {
/* 321 */       onNextDroppedHook = (n -> {
/*     */           throw Exceptions.failWithCancel();
/*     */         });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onOperatorDebug() {
/* 335 */     log.debug("Enabling stacktrace debugging via onOperatorDebug");
/* 336 */     GLOBAL_TRACE = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnOperatorDebug() {
/* 343 */     GLOBAL_TRACE = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onNextError(BiFunction<? super Throwable, Object, ? extends Throwable> onNextError) {
/* 361 */     Objects.requireNonNull(onNextError, "onNextError");
/* 362 */     log.debug("Hooking new default : onNextError");
/*     */     
/* 364 */     if (onNextError instanceof OnNextFailureStrategy) {
/* 365 */       synchronized (log) {
/* 366 */         onNextErrorHook = (OnNextFailureStrategy)onNextError;
/*     */       } 
/*     */     } else {
/*     */       
/* 370 */       synchronized (log) {
/* 371 */         onNextErrorHook = new OnNextFailureStrategy.LambdaOnNextErrorStrategy(onNextError);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onOperatorError(BiFunction<? super Throwable, Object, ? extends Throwable> onOperatorError) {
/* 397 */     onOperatorError(onOperatorError.toString(), onOperatorError);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void onOperatorError(String key, BiFunction<? super Throwable, Object, ? extends Throwable> onOperatorError) {
/* 424 */     Objects.requireNonNull(key, "key");
/* 425 */     Objects.requireNonNull(onOperatorError, "onOperatorError");
/* 426 */     log.debug("Hooking onOperatorError: {}", new Object[] { key });
/* 427 */     synchronized (log) {
/* 428 */       onOperatorErrorHooks.put(key, onOperatorError);
/* 429 */       onOperatorErrorHook = createOrUpdateOpErrorHook(onOperatorErrorHooks.values());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnOperatorError(String key) {
/* 441 */     Objects.requireNonNull(key, "key");
/* 442 */     log.debug("Reset onOperatorError: {}", new Object[] { key });
/* 443 */     synchronized (log) {
/* 444 */       onOperatorErrorHooks.remove(key);
/* 445 */       onOperatorErrorHook = createOrUpdateOpErrorHook(onOperatorErrorHooks.values());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnOperatorError() {
/* 456 */     log.debug("Reset to factory defaults : onOperatorError");
/* 457 */     synchronized (log) {
/* 458 */       onOperatorErrorHooks.clear();
/* 459 */       onOperatorErrorHook = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnErrorDropped() {
/* 467 */     log.debug("Reset to factory defaults : onErrorDropped");
/* 468 */     synchronized (log) {
/* 469 */       onErrorDroppedHook = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnNextDropped() {
/* 478 */     log.debug("Reset to factory defaults : onNextDropped");
/* 479 */     synchronized (log) {
/* 480 */       onNextDroppedHook = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetOnNextError() {
/* 489 */     log.debug("Reset to factory defaults : onNextError");
/* 490 */     synchronized (log) {
/* 491 */       onNextErrorHook = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void enableContextLossTracking() {
/* 503 */     DETECT_CONTEXT_LOSS = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void disableContextLossTracking() {
/* 512 */     DETECT_CONTEXT_LOSS = false;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static Function<Publisher, Publisher> createOrUpdateOpHook(Collection<Function<? super Publisher<Object>, ? extends Publisher<Object>>> hooks) {
/*     */     Function<? super Publisher<Object>, ? extends Publisher<Object>> function;
/* 518 */     Function<Publisher, Publisher> composite = null;
/* 519 */     for (Function<? super Publisher<Object>, ? extends Publisher<Object>> function1 : hooks) {
/* 520 */       Function<? super Publisher<Object>, ? extends Publisher<Object>> function2 = function1;
/* 521 */       if (composite != null) {
/* 522 */         composite = composite.andThen((Function)function2);
/*     */         continue;
/*     */       } 
/* 525 */       function = function2;
/*     */     } 
/*     */     
/* 528 */     return (Function)function;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static BiFunction<? super Throwable, Object, ? extends Throwable> createOrUpdateOpErrorHook(Collection<BiFunction<? super Throwable, Object, ? extends Throwable>> hooks) {
/* 533 */     BiFunction<? super Throwable, Object, ? extends Throwable> composite = null;
/* 534 */     for (Iterator<BiFunction<? super Throwable, Object, ? extends Throwable>> iterator = hooks.iterator(); iterator.hasNext(); ) { BiFunction<? super Throwable, Object, ? extends Throwable> function = iterator.next();
/* 535 */       if (composite != null) {
/* 536 */         BiFunction<? super Throwable, Object, ? extends Throwable> ff = composite;
/* 537 */         composite = ((e, data) -> (Throwable)function.apply(ff.apply(e, data), data));
/*     */         continue;
/*     */       } 
/* 540 */       composite = function; }
/*     */ 
/*     */     
/* 543 */     return composite;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 565 */   private static final LinkedHashMap<String, Function<Queue<?>, Queue<?>>> QUEUE_WRAPPERS = new LinkedHashMap<>(1);
/*     */   
/* 567 */   private static Function<Queue<?>, Queue<?>> QUEUE_WRAPPER = Function.identity();
/*     */ 
/*     */   
/*     */   static final Map<String, Function<? super Publisher<Object>, ? extends Publisher<Object>>> getOnEachOperatorHooks() {
/* 571 */     return Collections.unmodifiableMap(onEachOperatorHooks);
/*     */   }
/*     */   static final Map<String, Function<? super Publisher<Object>, ? extends Publisher<Object>>> getOnLastOperatorHooks() {
/* 574 */     return Collections.unmodifiableMap(onLastOperatorHooks);
/*     */   }
/*     */   static final Map<String, BiFunction<? super Throwable, Object, ? extends Throwable>> getOnOperatorErrorHooks() {
/* 577 */     return Collections.unmodifiableMap(onOperatorErrorHooks);
/*     */   }
/*     */   
/* 580 */   static final Logger log = Loggers.getLogger(Hooks.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String KEY_ON_ERROR_DROPPED = "reactor.onErrorDropped.local";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String KEY_ON_NEXT_DROPPED = "reactor.onNextDropped.local";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String KEY_ON_OPERATOR_ERROR = "reactor.onOperatorError.local";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String KEY_ON_DISCARD = "reactor.onDiscard.local";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String KEY_ON_REJECTED_EXECUTION = "reactor.onRejectedExecution.local";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 611 */   static boolean GLOBAL_TRACE = initStaticGlobalTrace();
/*     */   
/*     */   static boolean DETECT_CONTEXT_LOSS = false;
/*     */ 
/*     */   
/*     */   static {
/* 617 */     onEachOperatorHooks = new LinkedHashMap<>(1);
/* 618 */     onLastOperatorHooks = new LinkedHashMap<>(1);
/* 619 */     onOperatorErrorHooks = new LinkedHashMap<>(1);
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean initStaticGlobalTrace() {
/* 624 */     return Boolean.parseBoolean(System.getProperty("reactor.trace.operatorStacktrace", "false"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public static <T, P extends Publisher<T>> Publisher<T> addReturnInfo(@Nullable P publisher, String method) {
/* 638 */     if (publisher == null) {
/* 639 */       return null;
/*     */     }
/* 641 */     return addAssemblyInfo(publisher, new FluxOnAssembly.MethodReturnSnapshot(method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public static <T, P extends Publisher<T>> Publisher<T> addCallSiteInfo(@Nullable P publisher, String callSite) {
/* 651 */     if (publisher == null) {
/* 652 */       return null;
/*     */     }
/* 654 */     return addAssemblyInfo(publisher, new FluxOnAssembly.AssemblySnapshot(callSite));
/*     */   }
/*     */   
/*     */   static <T, P extends Publisher<T>> Publisher<T> addAssemblyInfo(P publisher, FluxOnAssembly.AssemblySnapshot stacktrace) {
/* 658 */     if (publisher instanceof java.util.concurrent.Callable) {
/* 659 */       if (publisher instanceof Mono) {
/* 660 */         return (Publisher<T>)new MonoCallableOnAssembly((Mono)publisher, stacktrace);
/*     */       }
/* 662 */       return (Publisher<T>)new FluxCallableOnAssembly((Flux)publisher, stacktrace);
/*     */     } 
/* 664 */     if (publisher instanceof Mono) {
/* 665 */       return (Publisher<T>)new MonoOnAssembly((Mono)publisher, stacktrace);
/*     */     }
/* 667 */     if (publisher instanceof ParallelFlux) {
/* 668 */       return (Publisher<T>)new ParallelFluxOnAssembly((ParallelFlux)publisher, stacktrace);
/*     */     }
/* 670 */     if (publisher instanceof ConnectableFlux) {
/* 671 */       return (Publisher<T>)new ConnectableFluxOnAssembly((ConnectableFlux)publisher, stacktrace);
/*     */     }
/* 673 */     return (Publisher<T>)new FluxOnAssembly((Flux)publisher, stacktrace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addQueueWrapper(String key, Function<Queue<?>, Queue<?>> decorator) {
/* 687 */     synchronized (QUEUE_WRAPPERS) {
/* 688 */       QUEUE_WRAPPERS.put(key, decorator);
/* 689 */       Function<Queue<?>, Queue<?>> newHook = null;
/* 690 */       for (Function<Queue<?>, Queue<?>> function : QUEUE_WRAPPERS.values()) {
/* 691 */         if (newHook == null) {
/* 692 */           newHook = function;
/*     */           continue;
/*     */         } 
/* 695 */         newHook = newHook.andThen(function);
/*     */       } 
/*     */       
/* 698 */       QUEUE_WRAPPER = newHook;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeQueueWrapper(String key) {
/* 708 */     synchronized (QUEUE_WRAPPERS) {
/* 709 */       QUEUE_WRAPPERS.remove(key);
/* 710 */       if (QUEUE_WRAPPERS.isEmpty()) {
/* 711 */         QUEUE_WRAPPER = Function.identity();
/*     */       } else {
/*     */         
/* 714 */         Function<Queue<?>, Queue<?>> newHook = null;
/* 715 */         for (Function<Queue<?>, Queue<?>> function : QUEUE_WRAPPERS.values()) {
/* 716 */           if (newHook == null) {
/* 717 */             newHook = function;
/*     */             continue;
/*     */           } 
/* 720 */           newHook = newHook.andThen(function);
/*     */         } 
/*     */         
/* 723 */         QUEUE_WRAPPER = newHook;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeQueueWrappers() {
/* 735 */     synchronized (QUEUE_WRAPPERS) {
/* 736 */       QUEUE_WRAPPERS.clear();
/* 737 */       QUEUE_WRAPPER = Function.identity();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Queue<T> wrapQueue(Queue<T> queue) {
/* 753 */     return (Queue<T>)QUEUE_WRAPPER.apply(queue);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\Hooks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */