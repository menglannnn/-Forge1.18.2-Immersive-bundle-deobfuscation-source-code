/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoLiftFuseable<I, O>
/*    */   extends InternalMonoOperator<I, O>
/*    */   implements Fuseable
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   
/*    */   MonoLiftFuseable(Publisher<I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 37 */     super(Mono.from(p));
/* 38 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 43 */     if (this.source instanceof Scannable) {
/* 44 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 46 */     return super.stepName();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 51 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 52 */     if (key == Scannable.Attr.LIFTER) return this.liftFunction.name; 
/* 53 */     return super.scanUnsafe(key);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/* 59 */     CoreSubscriber<? super I> input = this.liftFunction.lifter.apply(this.source, actual);
/*    */     
/* 61 */     Objects.requireNonNull(input, "Lifted subscriber MUST NOT be null");
/*    */     
/* 63 */     if (actual instanceof Fuseable.QueueSubscription && !(input instanceof Fuseable.QueueSubscription))
/*    */     {
/*    */       
/* 66 */       input = new FluxHide.SuppressFuseableSubscriber<>(input);
/*    */     }
/*    */     
/* 69 */     return input;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoLiftFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */