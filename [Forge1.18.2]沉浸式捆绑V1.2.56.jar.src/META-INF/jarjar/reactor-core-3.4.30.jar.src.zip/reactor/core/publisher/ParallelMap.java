/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParallelMap<T, R>
/*    */   extends ParallelFlux<R>
/*    */   implements Scannable
/*    */ {
/*    */   final ParallelFlux<T> source;
/*    */   final Function<? super T, ? extends R> mapper;
/*    */   
/*    */   ParallelMap(ParallelFlux<T> source, Function<? super T, ? extends R> mapper) {
/* 39 */     this.source = source;
/* 40 */     this.mapper = mapper;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 46 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 47 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 48 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 50 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super R>[] subscribers) {
/* 56 */     if (!validate((Subscriber<?>[])subscribers)) {
/*    */       return;
/*    */     }
/*    */     
/* 60 */     int n = subscribers.length;
/* 61 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*    */     
/* 63 */     boolean conditional = subscribers[0] instanceof Fuseable.ConditionalSubscriber;
/*    */     
/* 65 */     for (int i = 0; i < n; i++) {
/* 66 */       if (conditional) {
/* 67 */         arrayOfCoreSubscriber[i] = new FluxMap.MapConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super R>)subscribers[i], this.mapper);
/*    */       
/*    */       }
/*    */       else {
/*    */         
/* 72 */         arrayOfCoreSubscriber[i] = new FluxMap.MapSubscriber<>(subscribers[i], this.mapper);
/*    */       } 
/*    */     } 
/*    */     
/* 76 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*    */   }
/*    */ 
/*    */   
/*    */   public int parallelism() {
/* 81 */     return this.source.parallelism();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ParallelMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */