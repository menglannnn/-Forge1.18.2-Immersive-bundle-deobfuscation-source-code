/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import reactor.core.Exceptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface InternalManySink<T>
/*     */   extends Sinks.Many<T>, ContextHolder
/*     */ {
/*     */   default void emitNext(T value, Sinks.EmitFailureHandler failureHandler) {
/*     */     Sinks.EmitResult emitResult;
/*     */     while (true) {
/*  27 */       emitResult = tryEmitNext(value);
/*  28 */       if (emitResult.isSuccess()) {
/*     */         return;
/*     */       }
/*     */       
/*  32 */       boolean shouldRetry = failureHandler.onEmitFailure(SignalType.ON_NEXT, emitResult);
/*     */       
/*  34 */       if (shouldRetry)
/*     */         continue; 
/*     */       break;
/*     */     } 
/*  38 */     switch (emitResult) {
/*     */       case FAIL_ZERO_SUBSCRIBER:
/*     */         return;
/*     */ 
/*     */       
/*     */       case FAIL_OVERFLOW:
/*  44 */         Operators.onDiscard(value, currentContext());
/*     */         
/*  46 */         emitError(Exceptions.failWithOverflow("Backpressure overflow during Sinks.Many#emitNext"), failureHandler);
/*     */         return;
/*     */       
/*     */       case FAIL_CANCELLED:
/*  50 */         Operators.onDiscard(value, currentContext());
/*     */         return;
/*     */       case FAIL_TERMINATED:
/*  53 */         Operators.onNextDropped(value, currentContext());
/*     */         return;
/*     */       case FAIL_NON_SERIALIZED:
/*  56 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*     */     } 
/*     */ 
/*     */     
/*  60 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default void emitComplete(Sinks.EmitFailureHandler failureHandler) {
/*     */     Sinks.EmitResult emitResult;
/*     */     while (true) {
/*  68 */       emitResult = tryEmitComplete();
/*  69 */       if (emitResult.isSuccess()) {
/*     */         return;
/*     */       }
/*     */       
/*  73 */       boolean shouldRetry = failureHandler.onEmitFailure(SignalType.ON_COMPLETE, emitResult);
/*     */       
/*  75 */       if (shouldRetry)
/*     */         continue; 
/*     */       break;
/*     */     } 
/*  79 */     switch (emitResult) {
/*     */       case FAIL_ZERO_SUBSCRIBER:
/*     */       case FAIL_OVERFLOW:
/*     */       case FAIL_CANCELLED:
/*     */       case FAIL_TERMINATED:
/*     */         return;
/*     */       case FAIL_NON_SERIALIZED:
/*  86 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*     */     } 
/*     */ 
/*     */     
/*  90 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default void emitError(Throwable error, Sinks.EmitFailureHandler failureHandler) {
/*     */     Sinks.EmitResult emitResult;
/*     */     while (true) {
/*  98 */       emitResult = tryEmitError(error);
/*  99 */       if (emitResult.isSuccess()) {
/*     */         return;
/*     */       }
/*     */       
/* 103 */       boolean shouldRetry = failureHandler.onEmitFailure(SignalType.ON_ERROR, emitResult);
/*     */       
/* 105 */       if (shouldRetry)
/*     */         continue; 
/*     */       break;
/*     */     } 
/* 109 */     switch (emitResult) {
/*     */       case FAIL_ZERO_SUBSCRIBER:
/*     */       case FAIL_OVERFLOW:
/*     */       case FAIL_CANCELLED:
/*     */         return;
/*     */       case FAIL_TERMINATED:
/* 115 */         Operators.onErrorDropped(error, currentContext());
/*     */         return;
/*     */       case FAIL_NON_SERIALIZED:
/* 118 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*     */     } 
/*     */ 
/*     */     
/* 122 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\InternalManySink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */