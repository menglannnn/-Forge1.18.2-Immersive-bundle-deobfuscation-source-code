/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GroupedLift<K, I, O>
/*    */   extends GroupedFlux<K, O>
/*    */   implements Scannable
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   final GroupedFlux<K, I> source;
/*    */   
/*    */   GroupedLift(GroupedFlux<K, I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 36 */     this.source = Objects.<GroupedFlux<K, I>>requireNonNull(p, "source");
/* 37 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 42 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   public K key() {
/* 47 */     return this.source.key();
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 53 */     if (key == Scannable.Attr.PARENT) {
/* 54 */       return this.source;
/*    */     }
/* 56 */     if (key == Scannable.Attr.PREFETCH) {
/* 57 */       return Integer.valueOf(getPrefetch());
/*    */     }
/* 59 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 60 */       return Scannable.from(this.source).scanUnsafe(key);
/*    */     }
/* 62 */     if (key == Scannable.Attr.LIFTER) {
/* 63 */       return this.liftFunction.name;
/*    */     }
/*    */     
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 71 */     if (this.source instanceof Scannable) {
/* 72 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 74 */     return super.stepName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super O> actual) {
/* 80 */     CoreSubscriber<? super I> input = this.liftFunction.lifter.apply(this.source, actual);
/*    */     
/* 82 */     Objects.requireNonNull(input, "Lifted subscriber MUST NOT be null");
/*    */     
/* 84 */     this.source.subscribe(input);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\GroupedLift.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */