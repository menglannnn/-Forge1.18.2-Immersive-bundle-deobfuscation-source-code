/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoCancelOn<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final Scheduler scheduler;
/*    */   
/*    */   MonoCancelOn(Mono<T> source, Scheduler scheduler) {
/* 27 */     super(source);
/* 28 */     this.scheduler = scheduler;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 33 */     return new FluxCancelOn.CancelSubscriber<>(actual, this.scheduler);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 38 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/* 39 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*    */     
/* 41 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoCancelOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */