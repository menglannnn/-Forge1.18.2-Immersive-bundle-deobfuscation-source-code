/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import io.micrometer.core.instrument.Clock;
/*     */ import io.micrometer.core.instrument.MeterRegistry;
/*     */ import io.micrometer.core.instrument.Tags;
/*     */ import io.micrometer.core.instrument.Timer;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.Metrics;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMetricsFuseable<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */   implements Fuseable
/*     */ {
/*     */   final String name;
/*     */   final Tags tags;
/*     */   final MeterRegistry registryCandidate;
/*     */   
/*     */   FluxMetricsFuseable(Flux<? extends T> flux) {
/*  49 */     super(flux);
/*     */     
/*  51 */     this.name = FluxMetrics.resolveName((Publisher<?>)flux);
/*  52 */     this.tags = FluxMetrics.resolveTags((Publisher<?>)flux, FluxMetrics.DEFAULT_TAGS_FLUX);
/*  53 */     this.registryCandidate = Metrics.MicrometerConfiguration.getRegistry();
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  58 */     return new MetricsFuseableSubscriber<>(actual, this.registryCandidate, Clock.SYSTEM, this.name, this.tags);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  63 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  64 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MetricsFuseableSubscriber<T>
/*     */     extends FluxMetrics.MetricsSubscriber<T>
/*     */     implements Fuseable, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     int mode;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MetricsFuseableSubscriber(CoreSubscriber<? super T> actual, MeterRegistry registry, Clock clock, String sequenceName, Tags sequenceTags) {
/*  87 */       super(actual, registry, clock, sequenceName, sequenceTags);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/*  92 */       if (this.qs != null) {
/*  93 */         this.qs.clear();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/*  99 */       return (this.qs == null || this.qs.isEmpty());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 104 */       if (this.mode == 2) {
/* 105 */         this.actual.onNext(null);
/*     */         
/*     */         return;
/*     */       } 
/* 109 */       if (this.done) {
/* 110 */         FluxMetrics.recordMalformed(this.sequenceName, this.commonTags, this.registry);
/* 111 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 116 */       long last = this.lastNextEventNanos;
/* 117 */       this.lastNextEventNanos = this.clock.monotonicTime();
/* 118 */       this.onNextIntervalTimer.record(this.lastNextEventNanos - last, TimeUnit.NANOSECONDS);
/*     */       
/* 120 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 126 */       if (this.qs == null) {
/* 127 */         return null;
/*     */       }
/*     */       try {
/* 130 */         T v = (T)this.qs.poll();
/*     */         
/* 132 */         if (v == null && this.mode == 1) {
/* 133 */           if (this.onNextIntervalTimer.count() == 0L) {
/* 134 */             FluxMetrics.recordOnCompleteEmpty(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */           } else {
/* 136 */             FluxMetrics.recordOnComplete(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample);
/*     */           } 
/*     */         }
/* 139 */         if (v != null) {
/*     */ 
/*     */           
/* 142 */           long last = this.lastNextEventNanos;
/* 143 */           this.lastNextEventNanos = this.clock.monotonicTime();
/* 144 */           this.onNextIntervalTimer.record(this.lastNextEventNanos - last, TimeUnit.NANOSECONDS);
/*     */         } 
/* 146 */         return v;
/*     */       }
/* 148 */       catch (Throwable e) {
/* 149 */         FluxMetrics.recordOnError(this.sequenceName, this.commonTags, this.registry, this.subscribeToTerminateSample, e);
/* 150 */         throw e;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 156 */       if (Operators.validate(this.s, s)) {
/* 157 */         FluxMetrics.recordOnSubscribe(this.sequenceName, this.commonTags, this.registry);
/* 158 */         this.subscribeToTerminateSample = Timer.start(this.clock);
/* 159 */         this.lastNextEventNanos = this.clock.monotonicTime();
/* 160 */         this.qs = Operators.as(s);
/* 161 */         this.s = s;
/* 162 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int mode) {
/* 169 */       if (this.qs != null) {
/* 170 */         this.mode = this.qs.requestFusion(mode);
/* 171 */         return this.mode;
/*     */       } 
/* 173 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 178 */       return (this.qs == null) ? 0 : this.qs.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxMetricsFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */