/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.RejectedExecutionException;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSubscribeOnValue<T>
/*    */   extends Mono<T>
/*    */   implements Scannable
/*    */ {
/*    */   final T value;
/*    */   final Scheduler scheduler;
/*    */   
/*    */   MonoSubscribeOnValue(@Nullable T value, Scheduler scheduler) {
/* 41 */     this.value = value;
/* 42 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler, "scheduler");
/*    */   }
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 47 */     T v = this.value;
/* 48 */     if (v == null) {
/* 49 */       FluxSubscribeOnValue.ScheduledEmpty parent = new FluxSubscribeOnValue.ScheduledEmpty((Subscriber<?>)actual);
/* 50 */       actual.onSubscribe((Subscription)parent);
/*    */       try {
/* 52 */         parent.setFuture(this.scheduler.schedule(parent));
/*    */       }
/* 54 */       catch (RejectedExecutionException ree) {
/* 55 */         if (parent.future != OperatorDisposables.DISPOSED) {
/* 56 */           actual.onError(Operators.onRejectedExecution(ree, actual
/* 57 */                 .currentContext()));
/*    */         }
/*    */       } 
/*    */     } else {
/*    */       
/* 62 */       actual.onSubscribe(new FluxSubscribeOnValue.ScheduledScalar<>(actual, v, this.scheduler));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 68 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/* 69 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*    */     
/* 71 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoSubscribeOnValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */