/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoPeekTerminal<T>
/*     */   extends InternalMonoOperator<T, T>
/*     */   implements Fuseable
/*     */ {
/*     */   final BiConsumer<? super T, Throwable> onAfterTerminateCall;
/*     */   final Consumer<? super T> onSuccessCall;
/*     */   final Consumer<? super Throwable> onErrorCall;
/*     */   
/*     */   MonoPeekTerminal(Mono<? extends T> source, @Nullable Consumer<? super T> onSuccessCall, @Nullable Consumer<? super Throwable> onErrorCall, @Nullable BiConsumer<? super T, Throwable> onAfterTerminateCall) {
/*  48 */     super(source);
/*  49 */     this.onAfterTerminateCall = onAfterTerminateCall;
/*  50 */     this.onSuccessCall = onSuccessCall;
/*  51 */     this.onErrorCall = onErrorCall;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  57 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  58 */       return new MonoTerminalPeekSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this);
/*     */     }
/*     */     
/*  61 */     return new MonoTerminalPeekSubscriber<>(actual, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  67 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MonoTerminalPeekSubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final Fuseable.ConditionalSubscriber<? super T> actualConditional;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final MonoPeekTerminal<T> parent;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Fuseable.QueueSubscription<T> queueSubscription;
/*     */ 
/*     */ 
/*     */     
/*     */     int sourceMode;
/*     */ 
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */ 
/*     */ 
/*     */     
/*     */     boolean valued;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MonoTerminalPeekSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, MonoPeekTerminal<T> parent) {
/* 115 */       this.actualConditional = actual;
/* 116 */       this.actual = (CoreSubscriber<? super T>)actual;
/* 117 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     MonoTerminalPeekSubscriber(CoreSubscriber<? super T> actual, MonoPeekTerminal<T> parent) {
/* 122 */       this.actual = actual;
/* 123 */       this.actualConditional = null;
/* 124 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 130 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 131 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 132 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 134 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 139 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 144 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 149 */       this.s = s;
/* 150 */       this.queueSubscription = Operators.as(s);
/*     */       
/* 152 */       this.actual.onSubscribe(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 157 */       if (this.sourceMode == 2) {
/* 158 */         this.actual.onNext(null);
/*     */       } else {
/*     */         
/* 161 */         if (this.done) {
/* 162 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 167 */         this.valued = true;
/*     */         
/* 169 */         if (this.parent.onSuccessCall != null) {
/*     */           try {
/* 171 */             this.parent.onSuccessCall.accept(t);
/*     */           }
/* 173 */           catch (Throwable e) {
/* 174 */             onError(Operators.onOperatorError(this.s, e, t, this.actual
/* 175 */                   .currentContext()));
/*     */             
/*     */             return;
/*     */           } 
/*     */         }
/* 180 */         this.actual.onNext(t);
/*     */         
/* 182 */         if (this.parent.onAfterTerminateCall != null) {
/*     */           try {
/* 184 */             this.parent.onAfterTerminateCall.accept(t, null);
/*     */           }
/* 186 */           catch (Throwable e) {
/*     */             
/* 188 */             Operators.onErrorDropped(Operators.onOperatorError(this.s, e, t, this.actual
/* 189 */                   .currentContext()), this.actual
/* 190 */                 .currentContext());
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 198 */       if (this.done) {
/* 199 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 200 */         return false;
/*     */       } 
/* 202 */       if (this.actualConditional == null) {
/* 203 */         onNext(t);
/* 204 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 209 */       this.valued = true;
/*     */       
/* 211 */       if (this.parent.onSuccessCall != null) {
/*     */         try {
/* 213 */           this.parent.onSuccessCall.accept(t);
/*     */         }
/* 215 */         catch (Throwable e) {
/* 216 */           onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/* 217 */           return false;
/*     */         } 
/*     */       }
/*     */       
/* 221 */       boolean r = this.actualConditional.tryOnNext(t);
/*     */       
/* 223 */       if (this.parent.onAfterTerminateCall != null) {
/*     */         try {
/* 225 */           this.parent.onAfterTerminateCall.accept(t, null);
/*     */         }
/* 227 */         catch (Throwable e) {
/*     */           
/* 229 */           Operators.onErrorDropped(Operators.onOperatorError(this.s, e, t, this.actual
/* 230 */                 .currentContext()), this.actual
/* 231 */               .currentContext());
/*     */         } 
/*     */       }
/*     */       
/* 235 */       return r;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 240 */       if (this.done) {
/* 241 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 244 */       this.done = true;
/*     */       
/* 246 */       Consumer<? super Throwable> onError = this.parent.onErrorCall;
/*     */       
/* 248 */       if (!this.valued && onError != null) {
/*     */         try {
/* 250 */           onError.accept(t);
/*     */         }
/* 252 */         catch (Throwable e) {
/* 253 */           t = Operators.onOperatorError(null, e, t, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */       
/*     */       try {
/* 258 */         this.actual.onError(t);
/*     */       }
/* 260 */       catch (UnsupportedOperationException use) {
/* 261 */         if (onError == null || (
/* 262 */           !Exceptions.isErrorCallbackNotImplemented(use) && use.getCause() != t)) {
/* 263 */           throw use;
/*     */         }
/*     */       } 
/*     */       
/* 267 */       if (!this.valued && this.parent.onAfterTerminateCall != null) {
/*     */         try {
/* 269 */           this.parent.onAfterTerminateCall.accept(null, t);
/*     */         }
/* 271 */         catch (Throwable e) {
/*     */           
/* 273 */           Operators.onErrorDropped(Operators.onOperatorError(e, this.actual
/* 274 */                 .currentContext()), this.actual
/* 275 */               .currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 282 */       if (this.done) {
/*     */         return;
/*     */       }
/* 285 */       if (this.sourceMode == 0 && !this.valued)
/*     */       {
/* 287 */         if (this.parent.onSuccessCall != null) {
/*     */           try {
/* 289 */             this.parent.onSuccessCall.accept(null);
/*     */           }
/* 291 */           catch (Throwable e) {
/* 292 */             onError(Operators.onOperatorError(this.s, e, this.actual.currentContext()));
/*     */             return;
/*     */           } 
/*     */         }
/*     */       }
/* 297 */       this.done = true;
/*     */       
/* 299 */       this.actual.onComplete();
/*     */       
/* 301 */       if (this.sourceMode == 0 && !this.valued && this.parent.onAfterTerminateCall != null) {
/*     */         try {
/* 303 */           this.parent.onAfterTerminateCall.accept(null, null);
/*     */         }
/* 305 */         catch (Throwable e) {
/*     */           
/* 307 */           Operators.onErrorDropped(Operators.onOperatorError(e, this.actual
/* 308 */                 .currentContext()), this.actual
/* 309 */               .currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 316 */       return this.actual;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/*     */       T v;
/* 322 */       assert this.queueSubscription != null;
/* 323 */       boolean d = this.done;
/*     */       
/*     */       try {
/* 326 */         v = (T)this.queueSubscription.poll();
/*     */       }
/* 328 */       catch (Throwable pe) {
/* 329 */         if (this.parent.onErrorCall != null) {
/*     */           try {
/* 331 */             this.parent.onErrorCall.accept(pe);
/*     */           }
/* 333 */           catch (Throwable t) {
/* 334 */             t = Operators.onOperatorError(null, pe, t, this.actual.currentContext());
/* 335 */             throw Exceptions.propagate(t);
/*     */           } 
/*     */         }
/* 338 */         throw pe;
/*     */       } 
/* 340 */       if (!this.valued && (v != null || d || this.sourceMode == 1)) {
/* 341 */         this.valued = true;
/*     */         
/* 343 */         if (this.parent.onSuccessCall != null) {
/*     */           try {
/* 345 */             this.parent.onSuccessCall.accept(v);
/*     */           }
/* 347 */           catch (Throwable e) {
/* 348 */             throw Exceptions.propagate(Operators.onOperatorError(this.s, e, v, this.actual
/* 349 */                   .currentContext()));
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 355 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 360 */       return (this.queueSubscription == null || this.queueSubscription.isEmpty());
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 365 */       assert this.queueSubscription != null;
/* 366 */       this.queueSubscription.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/*     */       int m;
/* 372 */       if (this.queueSubscription == null || this.parent.onAfterTerminateCall != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 379 */         m = 0;
/*     */       }
/* 381 */       else if ((requestedMode & 0x4) != 0) {
/* 382 */         m = 0;
/*     */       } else {
/*     */         
/* 385 */         m = this.queueSubscription.requestFusion(requestedMode);
/*     */       } 
/* 387 */       this.sourceMode = m;
/* 388 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 393 */       return (this.queueSubscription == null) ? 0 : this.queueSubscription.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoPeekTerminal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */