/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoSingleCallable<T>
/*     */   extends Mono<T>
/*     */   implements Callable<T>, SourceProducer<T>
/*     */ {
/*     */   final Callable<? extends T> callable;
/*     */   @Nullable
/*     */   final T defaultValue;
/*     */   
/*     */   MonoSingleCallable(Callable<? extends T> source) {
/*  43 */     this.callable = Objects.<Callable<? extends T>>requireNonNull(source, "source");
/*  44 */     this.defaultValue = null;
/*     */   }
/*     */   
/*     */   MonoSingleCallable(Callable<? extends T> source, T defaultValue) {
/*  48 */     this.callable = Objects.<Callable<? extends T>>requireNonNull(source, "source");
/*  49 */     this.defaultValue = Objects.requireNonNull(defaultValue, "defaultValue");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  55 */     Operators.MonoInnerProducerBase<T> sds = new Operators.MonoInnerProducerBase<>(actual);
/*     */     
/*  57 */     actual.onSubscribe(sds);
/*     */     
/*  59 */     if (sds.isCancelled()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  64 */       T t = this.callable.call();
/*  65 */       if (t == null && this.defaultValue == null) {
/*  66 */         actual.onError(new NoSuchElementException("Source was empty"));
/*     */       }
/*  68 */       else if (t == null) {
/*  69 */         sds.complete(this.defaultValue);
/*     */       } else {
/*     */         
/*  72 */         sds.complete(t);
/*     */       }
/*     */     
/*  75 */     } catch (Throwable e) {
/*  76 */       actual.onError(Operators.onOperatorError(e, actual.currentContext()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T block() {
/*  84 */     return block(Duration.ZERO);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T block(Duration m) {
/*     */     T v;
/*     */     try {
/*  92 */       v = this.callable.call();
/*     */     }
/*  94 */     catch (Throwable e) {
/*  95 */       throw Exceptions.propagate(e);
/*     */     } 
/*     */     
/*  98 */     if (v == null && this.defaultValue == null) {
/*  99 */       throw new NoSuchElementException("Source was empty");
/*     */     }
/* 101 */     if (v == null) {
/* 102 */       return this.defaultValue;
/*     */     }
/*     */     
/* 105 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   public T call() throws Exception {
/* 110 */     T v = this.callable.call();
/*     */     
/* 112 */     if (v == null && this.defaultValue == null) {
/* 113 */       throw new NoSuchElementException("Source was empty");
/*     */     }
/* 115 */     if (v == null) {
/* 116 */       return this.defaultValue;
/*     */     }
/*     */     
/* 119 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 124 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 125 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoSingleCallable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */