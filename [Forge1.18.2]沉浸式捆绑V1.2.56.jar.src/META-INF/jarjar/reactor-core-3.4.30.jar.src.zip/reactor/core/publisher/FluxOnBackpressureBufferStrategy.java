/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxOnBackpressureBufferStrategy<O>
/*     */   extends InternalFluxOperator<O, O>
/*     */ {
/*     */   final Consumer<? super O> onBufferOverflow;
/*     */   final int bufferSize;
/*     */   final boolean delayError;
/*     */   final BufferOverflowStrategy bufferOverflowStrategy;
/*     */   
/*     */   FluxOnBackpressureBufferStrategy(Flux<? extends O> source, int bufferSize, @Nullable Consumer<? super O> onBufferOverflow, BufferOverflowStrategy bufferOverflowStrategy) {
/*  50 */     super(source);
/*  51 */     if (bufferSize < 1) {
/*  52 */       throw new IllegalArgumentException("Buffer Size must be strictly positive");
/*     */     }
/*     */     
/*  55 */     this.bufferSize = bufferSize;
/*  56 */     this.onBufferOverflow = onBufferOverflow;
/*  57 */     this.bufferOverflowStrategy = bufferOverflowStrategy;
/*  58 */     this.delayError = (onBufferOverflow != null || bufferOverflowStrategy == BufferOverflowStrategy.ERROR);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super O> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/*  63 */     return new BackpressureBufferDropOldestSubscriber<>(actual, this.bufferSize, this.delayError, this.onBufferOverflow, this.bufferOverflowStrategy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  70 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  75 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  76 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BackpressureBufferDropOldestSubscriber<T>
/*     */     extends ArrayDeque<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final int bufferSize;
/*     */     
/*     */     final Consumer<? super T> onOverflow;
/*     */     
/*     */     final boolean delayError;
/*     */     final BufferOverflowStrategy overflowStrategy;
/*     */     Subscription s;
/*     */     volatile boolean cancelled;
/*     */     volatile boolean done;
/*     */     Throwable error;
/*     */     volatile int wip;
/*  99 */     static final AtomicIntegerFieldUpdater<BackpressureBufferDropOldestSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(BackpressureBufferDropOldestSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 104 */     static final AtomicLongFieldUpdater<BackpressureBufferDropOldestSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(BackpressureBufferDropOldestSubscriber.class, "requested");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BackpressureBufferDropOldestSubscriber(CoreSubscriber<? super T> actual, int bufferSize, boolean delayError, @Nullable Consumer<? super T> onOverflow, BufferOverflowStrategy overflowStrategy) {
/* 113 */       this.actual = actual;
/* 114 */       this.ctx = actual.currentContext();
/* 115 */       this.delayError = delayError;
/* 116 */       this.onOverflow = onOverflow;
/* 117 */       this.overflowStrategy = overflowStrategy;
/* 118 */       this.bufferSize = bufferSize;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 124 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 125 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 126 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && isEmpty())); 
/* 127 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 128 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(size()); 
/* 129 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 130 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 131 */       if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 132 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 134 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 139 */       if (Operators.validate(this.s, s)) {
/* 140 */         this.s = s;
/* 141 */         this.actual.onSubscribe(this);
/* 142 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 148 */       if (this.done) {
/* 149 */         Operators.onNextDropped(t, this.ctx);
/*     */         
/*     */         return;
/*     */       } 
/* 153 */       boolean callOnOverflow = false;
/* 154 */       boolean callOnError = false;
/* 155 */       T overflowElement = t;
/* 156 */       synchronized (this) {
/* 157 */         if (size() == this.bufferSize) {
/* 158 */           callOnOverflow = true;
/* 159 */           switch (this.overflowStrategy) {
/*     */             case DROP_OLDEST:
/* 161 */               overflowElement = pollFirst();
/* 162 */               offer(t);
/*     */               break;
/*     */             
/*     */             case DROP_LATEST:
/*     */               break;
/*     */             
/*     */             default:
/* 169 */               callOnError = true;
/*     */               break;
/*     */           } 
/*     */         
/*     */         } else {
/* 174 */           offer(t);
/*     */         } 
/*     */       } 
/*     */       
/* 178 */       if (callOnOverflow) {
/* 179 */         if (this.onOverflow != null) {
/*     */           try {
/* 181 */             this.onOverflow.accept(overflowElement);
/*     */           }
/* 183 */           catch (Throwable e) {
/* 184 */             Throwable ex = Operators.onOperatorError(this.s, e, overflowElement, this.ctx);
/* 185 */             onError(ex);
/*     */             
/*     */             return;
/*     */           } finally {
/* 189 */             Operators.onDiscard(overflowElement, this.ctx);
/*     */           } 
/*     */         } else {
/*     */           
/* 193 */           Operators.onDiscard(overflowElement, this.ctx);
/*     */         } 
/*     */       }
/*     */       
/* 197 */       if (callOnError) {
/* 198 */         Throwable ex = Operators.onOperatorError(this.s, Exceptions.failWithOverflow(), overflowElement, this.ctx);
/* 199 */         onError(ex);
/*     */       } 
/*     */       
/* 202 */       if (!callOnError && !callOnOverflow) {
/* 203 */         drain();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 209 */       if (this.done) {
/* 210 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 213 */       this.error = t;
/* 214 */       this.done = true;
/* 215 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 220 */       if (this.done) {
/*     */         return;
/*     */       }
/* 223 */       this.done = true;
/* 224 */       drain();
/*     */     }
/*     */     
/*     */     void drain() {
/* 228 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 232 */       int missed = 1;
/*     */       
/*     */       do {
/* 235 */         CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */         
/* 237 */         if (coreSubscriber != null) {
/* 238 */           innerDrain((Subscriber<? super T>)coreSubscriber);
/*     */           
/*     */           return;
/*     */         } 
/* 242 */         missed = WIP.addAndGet(this, -missed);
/* 243 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void innerDrain(Subscriber<? super T> a) {
/* 250 */       int missed = 1;
/*     */ 
/*     */       
/*     */       do {
/* 254 */         long r = this.requested;
/* 255 */         long e = 0L;
/*     */         
/* 257 */         while (r != e) {
/* 258 */           T t; boolean d = this.done;
/*     */ 
/*     */           
/* 261 */           synchronized (this) {
/* 262 */             t = poll();
/*     */           } 
/* 264 */           boolean empty = (t == null);
/*     */           
/* 266 */           if (checkTerminated(d, empty, a)) {
/*     */             return;
/*     */           }
/*     */           
/* 270 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 274 */           a.onNext(t);
/*     */           
/* 276 */           e++;
/*     */         } 
/*     */         
/* 279 */         if (r == e) {
/*     */           boolean empty;
/* 281 */           synchronized (this) {
/* 282 */             empty = isEmpty();
/*     */           } 
/* 284 */           if (checkTerminated(this.done, empty, a)) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */         
/* 289 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 290 */           Operators.produced(REQUESTED, this, e);
/*     */         }
/*     */         
/* 293 */         missed = WIP.addAndGet(this, -missed);
/* 294 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 302 */       if (Operators.validate(n)) {
/* 303 */         Operators.addCap(REQUESTED, this, n);
/* 304 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 310 */       if (!this.cancelled) {
/* 311 */         this.cancelled = true;
/*     */         
/* 313 */         this.s.cancel();
/*     */         
/* 315 */         if (WIP.getAndIncrement(this) == 0) {
/* 316 */           synchronized (this) {
/* 317 */             clear();
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 325 */       return this.actual;
/*     */     }
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<? super T> a) {
/* 329 */       if (this.cancelled) {
/* 330 */         this.s.cancel();
/* 331 */         synchronized (this) {
/* 332 */           clear();
/*     */         } 
/* 334 */         return true;
/*     */       } 
/* 336 */       if (d) {
/* 337 */         if (this.delayError) {
/* 338 */           if (empty) {
/* 339 */             Throwable e = this.error;
/* 340 */             if (e != null) {
/* 341 */               a.onError(e);
/*     */             } else {
/*     */               
/* 344 */               a.onComplete();
/*     */             } 
/* 346 */             return true;
/*     */           } 
/*     */         } else {
/*     */           
/* 350 */           Throwable e = this.error;
/* 351 */           if (e != null) {
/* 352 */             synchronized (this) {
/* 353 */               clear();
/*     */             } 
/* 355 */             a.onError(e);
/* 356 */             return true;
/*     */           } 
/* 358 */           if (empty) {
/* 359 */             a.onComplete();
/* 360 */             return true;
/*     */           } 
/*     */         } 
/*     */       }
/* 364 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 369 */       Operators.onDiscardMultiple(this, this.ctx);
/* 370 */       super.clear();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxOnBackpressureBufferStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */