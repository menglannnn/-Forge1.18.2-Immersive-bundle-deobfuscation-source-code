/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SinkManyBestEffort<T>
/*     */   extends Flux<T>
/*     */   implements InternalManySink<T>, Scannable, DirectInnerContainer<T>
/*     */ {
/*  39 */   static final DirectInner[] EMPTY = new DirectInner[0];
/*  40 */   static final DirectInner[] TERMINATED = new DirectInner[0]; final boolean allOrNothing;
/*     */   
/*     */   static final <T> SinkManyBestEffort<T> createBestEffort() {
/*  43 */     return new SinkManyBestEffort<>(false);
/*     */   }
/*     */   Throwable error; volatile DirectInner<T>[] subscribers;
/*     */   static final <T> SinkManyBestEffort<T> createAllOrNothing() {
/*  47 */     return new SinkManyBestEffort<>(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   static final AtomicReferenceFieldUpdater<SinkManyBestEffort, DirectInner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(SinkManyBestEffort.class, (Class)DirectInner[].class, "subscribers");
/*     */   
/*     */   SinkManyBestEffort(boolean allOrNothing) {
/*  63 */     this.allOrNothing = allOrNothing;
/*  64 */     SUBSCRIBERS.lazySet(this, EMPTY);
/*     */   }
/*     */   
/*     */   public Context currentContext() {
/*  68 */     return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/*  73 */     return Stream.of((Scannable[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  79 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.subscribers == TERMINATED)); 
/*  80 */     if (key == Scannable.Attr.ERROR) return this.error;
/*     */     
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitNext(T t) {
/*  87 */     Objects.requireNonNull(t, "tryEmitNext(null) is forbidden");
/*     */     
/*  89 */     DirectInner<T>[] subs = this.subscribers;
/*     */     
/*  91 */     if (subs == EMPTY) {
/*  92 */       return Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER;
/*     */     }
/*  94 */     if (subs == TERMINATED) {
/*  95 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/*  98 */     int expectedEmitted = subs.length;
/*  99 */     int cancelledCount = 0;
/* 100 */     if (this.allOrNothing) {
/* 101 */       long commonRequest = Long.MAX_VALUE;
/* 102 */       for (DirectInner<T> sub : subs) {
/* 103 */         long subRequest = sub.requested;
/* 104 */         if (sub.isCancelled()) {
/* 105 */           cancelledCount++;
/*     */         
/*     */         }
/* 108 */         else if (subRequest < commonRequest) {
/* 109 */           commonRequest = subRequest;
/*     */         } 
/*     */       } 
/* 112 */       if (commonRequest == 0L) {
/* 113 */         return Sinks.EmitResult.FAIL_OVERFLOW;
/*     */       }
/* 115 */       if (cancelledCount == expectedEmitted) {
/* 116 */         return Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER;
/*     */       }
/*     */     } 
/*     */     
/* 120 */     int emittedCount = 0;
/* 121 */     cancelledCount = 0;
/* 122 */     for (DirectInner<T> sub : subs) {
/* 123 */       if (sub.isCancelled()) {
/* 124 */         cancelledCount++;
/*     */       
/*     */       }
/* 127 */       else if (sub.tryEmitNext(t)) {
/* 128 */         emittedCount++;
/*     */       }
/* 130 */       else if (sub.isCancelled()) {
/* 131 */         cancelledCount++;
/*     */       } 
/*     */     } 
/* 134 */     if (cancelledCount == expectedEmitted) {
/* 135 */       return Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER;
/*     */     }
/* 137 */     if (cancelledCount + emittedCount == expectedEmitted) {
/* 138 */       return Sinks.EmitResult.OK;
/*     */     }
/* 140 */     if (emittedCount > 0 && !this.allOrNothing) {
/* 141 */       return Sinks.EmitResult.OK;
/*     */     }
/*     */     
/* 144 */     return Sinks.EmitResult.FAIL_OVERFLOW;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitComplete() {
/* 151 */     DirectInner[] arrayOfDirectInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/*     */     
/* 153 */     if (arrayOfDirectInner == TERMINATED) {
/* 154 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 157 */     for (DirectInner<?> s : arrayOfDirectInner) {
/* 158 */       s.emitComplete();
/*     */     }
/* 160 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitError(Throwable error) {
/* 165 */     Objects.requireNonNull(error, "tryEmitError(null) is forbidden");
/*     */     
/* 167 */     DirectInner[] arrayOfDirectInner = SUBSCRIBERS.getAndSet(this, TERMINATED);
/*     */     
/* 169 */     if (arrayOfDirectInner == TERMINATED) {
/* 170 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 173 */     this.error = error;
/*     */     
/* 175 */     for (DirectInner<?> s : arrayOfDirectInner) {
/* 176 */       s.emitError(error);
/*     */     }
/* 178 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public int currentSubscriberCount() {
/* 183 */     return this.subscribers.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<T> asFlux() {
/* 188 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 193 */     Objects.requireNonNull(actual, "subscribe(null) is forbidden");
/*     */     
/* 195 */     DirectInner<T> p = new DirectInner<>(actual, this);
/* 196 */     actual.onSubscribe(p);
/*     */     
/* 198 */     if (p.isCancelled()) {
/*     */       return;
/*     */     }
/*     */     
/* 202 */     if (add(p)) {
/* 203 */       if (p.isCancelled()) {
/* 204 */         remove(p);
/*     */       }
/*     */     } else {
/*     */       
/* 208 */       Throwable e = this.error;
/* 209 */       if (e != null) {
/* 210 */         actual.onError(e);
/*     */       } else {
/*     */         
/* 213 */         actual.onComplete();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(DirectInner<T> s) {
/* 220 */     DirectInner<T>[] a = this.subscribers;
/* 221 */     if (a == TERMINATED) {
/* 222 */       return false;
/*     */     }
/*     */     
/*     */     while (true) {
/* 226 */       a = this.subscribers;
/* 227 */       if (a == TERMINATED) {
/* 228 */         return false;
/*     */       }
/* 230 */       int len = a.length;
/*     */ 
/*     */       
/* 233 */       DirectInner[] arrayOfDirectInner = new DirectInner[len + 1];
/* 234 */       System.arraycopy(a, 0, arrayOfDirectInner, 0, len);
/* 235 */       arrayOfDirectInner[len] = s;
/*     */       
/* 237 */       if (SUBSCRIBERS.compareAndSet(this, a, arrayOfDirectInner)) {
/* 238 */         return true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(DirectInner<T> s) {
/*     */     DirectInner[] arrayOfDirectInner;
/* 246 */     DirectInner<T>[] a = this.subscribers;
/* 247 */     if (a == TERMINATED || a == EMPTY) {
/*     */       return;
/*     */     }
/*     */     
/*     */     do {
/* 252 */       a = this.subscribers;
/* 253 */       if (a == TERMINATED || a == EMPTY) {
/*     */         return;
/*     */       }
/* 256 */       int len = a.length;
/*     */       
/* 258 */       int j = -1;
/*     */       
/* 260 */       for (int i = 0; i < len; i++) {
/* 261 */         if (a[i] == s) {
/* 262 */           j = i;
/*     */           break;
/*     */         } 
/*     */       } 
/* 266 */       if (j < 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 271 */       if (len == 1) {
/* 272 */         arrayOfDirectInner = EMPTY;
/*     */       } else {
/* 274 */         arrayOfDirectInner = new DirectInner[len - 1];
/* 275 */         System.arraycopy(a, 0, arrayOfDirectInner, 0, j);
/* 276 */         System.arraycopy(a, j + 1, arrayOfDirectInner, j, len - j - 1);
/*     */       }
/*     */     
/* 279 */     } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfDirectInner));
/*     */   }
/*     */ 
/*     */   
/*     */   static class DirectInner<T>
/*     */     extends AtomicBoolean
/*     */     implements InnerProducer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final DirectInnerContainer<T> parent;
/*     */     
/*     */     volatile long requested;
/* 292 */     static final AtomicLongFieldUpdater<DirectInner> REQUESTED = AtomicLongFieldUpdater.newUpdater(DirectInner.class, "requested");
/*     */ 
/*     */     
/*     */     DirectInner(CoreSubscriber<? super T> actual, DirectInnerContainer<T> parent) {
/* 296 */       this.actual = actual;
/* 297 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 302 */       if (Operators.validate(n)) {
/* 303 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 309 */       if (compareAndSet(false, true)) {
/* 310 */         this.parent.remove(this);
/*     */       }
/*     */     }
/*     */     
/*     */     boolean isCancelled() {
/* 315 */       return get();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 321 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 322 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled());
/*     */       
/* 324 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 329 */       return this.actual;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean tryEmitNext(T value) {
/* 338 */       if (this.requested != 0L) {
/* 339 */         if (isCancelled()) {
/* 340 */           return false;
/*     */         }
/* 342 */         this.actual.onNext(value);
/* 343 */         if (this.requested != Long.MAX_VALUE) {
/* 344 */           REQUESTED.decrementAndGet(this);
/*     */         }
/* 346 */         return true;
/*     */       } 
/* 348 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void directEmitNext(T value) {
/* 358 */       if (this.requested != 0L) {
/* 359 */         this.actual.onNext(value);
/* 360 */         if (this.requested != Long.MAX_VALUE) {
/* 361 */           REQUESTED.decrementAndGet(this);
/*     */         }
/*     */         return;
/*     */       } 
/* 365 */       this.parent.remove(this);
/* 366 */       this.actual.onError(Exceptions.failWithOverflow("Can't deliver value due to lack of requests"));
/*     */     }
/*     */     
/*     */     void emitError(Throwable e) {
/* 370 */       if (isCancelled()) {
/*     */         return;
/*     */       }
/* 373 */       this.actual.onError(e);
/*     */     }
/*     */     
/*     */     void emitComplete() {
/* 377 */       if (isCancelled()) {
/*     */         return;
/*     */       }
/* 380 */       this.actual.onComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\SinkManyBestEffort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */