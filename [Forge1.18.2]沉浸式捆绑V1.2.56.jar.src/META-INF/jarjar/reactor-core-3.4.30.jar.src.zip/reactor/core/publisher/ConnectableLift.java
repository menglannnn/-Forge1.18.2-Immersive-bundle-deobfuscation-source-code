/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConnectableLift<I, O>
/*    */   extends InternalConnectableFluxOperator<I, O>
/*    */   implements Scannable
/*    */ {
/*    */   final Operators.LiftFunction<I, O> liftFunction;
/*    */   
/*    */   ConnectableLift(ConnectableFlux<I> p, Operators.LiftFunction<I, O> liftFunction) {
/* 36 */     super(Objects.<ConnectableFlux<I>>requireNonNull(p, "source"));
/* 37 */     this.liftFunction = liftFunction;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 42 */     return this.source.getPrefetch();
/*    */   }
/*    */ 
/*    */   
/*    */   public void connect(Consumer<? super Disposable> cancelSupport) {
/* 47 */     this.source.connect(cancelSupport);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 53 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.source.getPrefetch()); 
/* 54 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 55 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 56 */     if (key == Scannable.Attr.LIFTER) return this.liftFunction.name; 
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 62 */     if (this.source instanceof Scannable) {
/* 63 */       return Scannable.from(this.source).stepName();
/*    */     }
/* 65 */     return super.stepName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/* 71 */     CoreSubscriber<? super I> input = this.liftFunction.lifter.apply(this.source, actual);
/*    */     
/* 73 */     Objects.requireNonNull(input, "Lifted subscriber MUST NOT be null");
/*    */     
/* 75 */     return input;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ConnectableLift.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */