/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoDeferContextual<T>
/*    */   extends Mono<T>
/*    */   implements SourceProducer<T>
/*    */ {
/*    */   final Function<ContextView, ? extends Mono<? extends T>> contextualMonoFactory;
/*    */   
/*    */   MonoDeferContextual(Function<ContextView, ? extends Mono<? extends T>> contextualMonoFactory) {
/* 38 */     this.contextualMonoFactory = Objects.<Function<ContextView, ? extends Mono<? extends T>>>requireNonNull(contextualMonoFactory, "contextualMonoFactory");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/*    */     Mono<? extends T> p;
/* 45 */     Context ctx = actual.currentContext();
/*    */     try {
/* 47 */       p = Objects.<Mono<? extends T>>requireNonNull(this.contextualMonoFactory.apply(ctx), "The Mono returned by the contextualMonoFactory is null");
/*    */     
/*    */     }
/* 50 */     catch (Throwable e) {
/* 51 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, ctx));
/*    */       
/*    */       return;
/*    */     } 
/* 55 */     p.subscribe(actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 60 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 61 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoDeferContextual.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */