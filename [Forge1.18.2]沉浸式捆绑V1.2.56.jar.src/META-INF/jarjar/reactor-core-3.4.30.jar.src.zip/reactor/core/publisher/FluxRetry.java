/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import reactor.core.CorePublisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxRetry<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final long times;
/*     */   
/*     */   FluxRetry(Flux<? extends T> source, long times) {
/*  38 */     super(source);
/*  39 */     if (times < 0L) {
/*  40 */       throw new IllegalArgumentException("times >= 0 required but it was " + times);
/*     */     }
/*  42 */     this.times = times;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  47 */     RetrySubscriber<T> parent = new RetrySubscriber<>(this.source, actual, this.times);
/*     */     
/*  49 */     actual.onSubscribe(parent);
/*     */     
/*  51 */     if (!parent.isCancelled()) {
/*  52 */       parent.resubscribe();
/*     */     }
/*  54 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  59 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  60 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RetrySubscriber<T>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */   {
/*     */     final CorePublisher<? extends T> source;
/*     */     
/*     */     long remaining;
/*     */     
/*     */     volatile int wip;
/*     */     
/*  73 */     static final AtomicIntegerFieldUpdater<RetrySubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(RetrySubscriber.class, "wip");
/*     */     
/*     */     long produced;
/*     */     
/*     */     RetrySubscriber(CorePublisher<? extends T> source, CoreSubscriber<? super T> actual, long remaining) {
/*  78 */       super(actual);
/*  79 */       this.source = source;
/*  80 */       this.remaining = remaining;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  85 */       this.produced++;
/*     */       
/*  87 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*  92 */       long r = this.remaining;
/*  93 */       if (r != Long.MAX_VALUE) {
/*  94 */         if (r == 0L) {
/*  95 */           this.actual.onError(t);
/*     */           return;
/*     */         } 
/*  98 */         this.remaining = r - 1L;
/*     */       } 
/*     */       
/* 101 */       resubscribe();
/*     */     }
/*     */     
/*     */     void resubscribe() {
/* 105 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         do {
/* 107 */           if (isCancelled()) {
/*     */             return;
/*     */           }
/*     */           
/* 111 */           long c = this.produced;
/* 112 */           if (c != 0L) {
/* 113 */             this.produced = 0L;
/* 114 */             produced(c);
/*     */           } 
/*     */           
/* 117 */           this.source.subscribe(this);
/*     */         }
/* 119 */         while (WIP.decrementAndGet(this) != 0);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 125 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 126 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxRetry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */