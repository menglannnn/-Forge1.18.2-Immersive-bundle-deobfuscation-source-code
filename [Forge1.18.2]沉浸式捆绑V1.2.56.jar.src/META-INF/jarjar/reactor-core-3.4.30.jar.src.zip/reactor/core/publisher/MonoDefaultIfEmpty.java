/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoDefaultIfEmpty<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final T defaultValue;
/*    */   
/*    */   MonoDefaultIfEmpty(Mono<? extends T> source, T defaultValue) {
/* 31 */     super(source);
/* 32 */     this.defaultValue = Objects.requireNonNull(defaultValue, "defaultValue");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 37 */     return new FluxDefaultIfEmpty.DefaultIfEmptySubscriber<>(actual, this.defaultValue);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 42 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 43 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoDefaultIfEmpty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */