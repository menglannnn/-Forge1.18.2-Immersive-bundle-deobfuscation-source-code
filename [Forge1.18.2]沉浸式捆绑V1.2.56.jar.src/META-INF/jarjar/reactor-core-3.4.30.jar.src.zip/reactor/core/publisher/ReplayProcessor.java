/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class ReplayProcessor<T>
/*     */   extends FluxProcessor<T, T>
/*     */   implements Fuseable, InternalManySink<T>
/*     */ {
/*     */   final FluxReplay.ReplayBuffer<T> buffer;
/*     */   Subscription subscription;
/*     */   volatile FluxReplay.ReplaySubscription<T>[] subscribers;
/*     */   
/*     */   @Deprecated
/*     */   public static <T> ReplayProcessor<T> cacheLast() {
/*  74 */     return cacheLastOrDefault((T)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> ReplayProcessor<T> cacheLastOrDefault(@Nullable T value) {
/*  97 */     ReplayProcessor<T> b = create(1);
/*  98 */     if (value != null) {
/*  99 */       b.onNext(value);
/*     */     }
/* 101 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> ReplayProcessor<E> create() {
/* 117 */     return create(Queues.SMALL_BUFFER_SIZE, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> ReplayProcessor<E> create(int historySize) {
/* 134 */     return create(historySize, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> ReplayProcessor<E> create(int historySize, boolean unbounded) {
/*     */     FluxReplay.ReplayBuffer<E> buffer;
/* 154 */     if (unbounded) {
/* 155 */       buffer = new FluxReplay.UnboundedReplayBuffer<>(historySize);
/*     */     } else {
/*     */       
/* 158 */       buffer = new FluxReplay.SizeBoundReplayBuffer<>(historySize);
/*     */     } 
/* 160 */     return new ReplayProcessor<>(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> ReplayProcessor<T> createTimeout(Duration maxAge) {
/* 193 */     return createTimeout(maxAge, Schedulers.parallel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> ReplayProcessor<T> createTimeout(Duration maxAge, Scheduler scheduler) {
/* 226 */     return createSizeAndTimeout(2147483647, maxAge, scheduler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> ReplayProcessor<T> createSizeAndTimeout(int size, Duration maxAge) {
/* 262 */     return createSizeAndTimeout(size, maxAge, Schedulers.parallel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> ReplayProcessor<T> createSizeAndTimeout(int size, Duration maxAge, Scheduler scheduler) {
/* 300 */     Objects.requireNonNull(scheduler, "scheduler is null");
/* 301 */     if (size <= 0) {
/* 302 */       throw new IllegalArgumentException("size > 0 required but it was " + size);
/*     */     }
/* 304 */     return new ReplayProcessor<>(new FluxReplay.SizeAndTimeBoundReplayBuffer<>(size, maxAge
/* 305 */           .toNanos(), scheduler));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 316 */   static final AtomicReferenceFieldUpdater<ReplayProcessor, FluxReplay.ReplaySubscription[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(ReplayProcessor.class, (Class)FluxReplay.ReplaySubscription[].class, "subscribers");
/*     */ 
/*     */ 
/*     */   
/*     */   ReplayProcessor(FluxReplay.ReplayBuffer<T> buffer) {
/* 321 */     this.buffer = buffer;
/* 322 */     SUBSCRIBERS.lazySet(this, FluxReplay.ReplaySubscriber.EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 327 */     Objects.requireNonNull(actual, "subscribe");
/* 328 */     FluxReplay.ReplaySubscription<T> rs = new ReplayInner<>(actual, this);
/* 329 */     actual.onSubscribe(rs);
/*     */     
/* 331 */     if (add(rs) && 
/* 332 */       rs.isCancelled()) {
/* 333 */       remove(rs);
/*     */       
/*     */       return;
/*     */     } 
/* 337 */     this.buffer.replay(rs);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getError() {
/* 343 */     return this.buffer.getError();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 349 */     if (key == Scannable.Attr.PARENT) {
/* 350 */       return this.subscription;
/*     */     }
/* 352 */     if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(this.buffer.capacity());
/*     */     
/* 354 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 359 */     return Stream.of((Scannable[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   public long downstreamCount() {
/* 364 */     return this.subscribers.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 369 */     return this.buffer.isDone();
/*     */   }
/*     */   
/*     */   boolean add(FluxReplay.ReplaySubscription<T> rs) {
/*     */     while (true) {
/* 374 */       FluxReplay.ReplaySubscription<T>[] a = this.subscribers;
/* 375 */       if (a == FluxReplay.ReplaySubscriber.TERMINATED) {
/* 376 */         return false;
/*     */       }
/* 378 */       int n = a.length;
/*     */       
/* 380 */       ReplayInner[] arrayOfReplayInner = new ReplayInner[n + 1];
/*     */       
/* 382 */       System.arraycopy(a, 0, arrayOfReplayInner, 0, n);
/* 383 */       arrayOfReplayInner[n] = (ReplayInner)rs;
/* 384 */       if (SUBSCRIBERS.compareAndSet(this, a, arrayOfReplayInner)) {
/* 385 */         return true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void remove(FluxReplay.ReplaySubscription<T> rs) {
/*     */     label20: while (true) {
/* 394 */       FluxReplay.ReplaySubscription<T>[] a = this.subscribers;
/* 395 */       if (a == FluxReplay.ReplaySubscriber.TERMINATED || a == FluxReplay.ReplaySubscriber.EMPTY) {
/*     */         return;
/*     */       }
/* 398 */       int n = a.length;
/*     */       
/* 400 */       for (int i = 0; i < n; i++) {
/* 401 */         if (a[i] == rs) {
/*     */           ReplayInner[] arrayOfReplayInner;
/*     */           
/* 404 */           if (n == 1) {
/* 405 */             FluxReplay.ReplaySubscription[] arrayOfReplaySubscription = FluxReplay.ReplaySubscriber.EMPTY;
/*     */           } else {
/*     */             
/* 408 */             arrayOfReplayInner = new ReplayInner[n - 1];
/* 409 */             System.arraycopy(a, 0, arrayOfReplayInner, 0, i);
/* 410 */             System.arraycopy(a, i + 1, arrayOfReplayInner, i, n - i - 1);
/*     */           } 
/*     */           
/* 413 */           if (SUBSCRIBERS.compareAndSet(this, a, arrayOfReplayInner)) {
/*     */             return;
/*     */           }
/*     */           continue label20;
/*     */         } 
/*     */       } 
/*     */       break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription s) {
/* 427 */     if (this.buffer.isDone()) {
/* 428 */       s.cancel();
/*     */     }
/* 430 */     else if (Operators.validate(this.subscription, s)) {
/* 431 */       this.subscription = s;
/* 432 */       s.request(Long.MAX_VALUE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 438 */     return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 443 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 449 */     Sinks.EmitResult emitResult = tryEmitComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitComplete() {
/* 454 */     FluxReplay.ReplayBuffer<T> b = this.buffer;
/* 455 */     if (b.isDone()) {
/* 456 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 459 */     b.onComplete();
/*     */ 
/*     */     
/* 462 */     FluxReplay.ReplaySubscription[] arrayOfReplaySubscription = SUBSCRIBERS.getAndSet(this, FluxReplay.ReplaySubscriber.TERMINATED);
/*     */     
/* 464 */     for (FluxReplay.ReplaySubscription<T> rs : arrayOfReplaySubscription) {
/* 465 */       b.replay(rs);
/*     */     }
/* 467 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable throwable) {
/* 472 */     emitError(throwable, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitError(Throwable t) {
/* 477 */     FluxReplay.ReplayBuffer<T> b = this.buffer;
/* 478 */     if (b.isDone()) {
/* 479 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 482 */     b.onError(t);
/*     */ 
/*     */     
/* 485 */     FluxReplay.ReplaySubscription[] arrayOfReplaySubscription = SUBSCRIBERS.getAndSet(this, FluxReplay.ReplaySubscriber.TERMINATED);
/*     */     
/* 487 */     for (FluxReplay.ReplaySubscription<T> rs : arrayOfReplaySubscription) {
/* 488 */       b.replay(rs);
/*     */     }
/* 490 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNext(T t) {
/* 495 */     emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitNext(T t) {
/* 500 */     FluxReplay.ReplayBuffer<T> b = this.buffer;
/* 501 */     if (b.isDone()) {
/* 502 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */ 
/*     */     
/* 506 */     b.add(t);
/* 507 */     for (FluxReplay.ReplaySubscription<T> rs : this.subscribers) {
/* 508 */       b.replay(rs);
/*     */     }
/* 510 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public int currentSubscriberCount() {
/* 515 */     return this.subscribers.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<T> asFlux() {
/* 520 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isIdentityProcessor() {
/* 525 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ReplayInner<T>
/*     */     implements FluxReplay.ReplaySubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final ReplayProcessor<T> parent;
/*     */     
/*     */     final FluxReplay.ReplayBuffer<T> buffer;
/*     */     
/*     */     int index;
/*     */     
/*     */     int tailIndex;
/*     */     
/*     */     Object node;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 546 */     static final AtomicIntegerFieldUpdater<ReplayInner> WIP = AtomicIntegerFieldUpdater.newUpdater(ReplayInner.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 552 */     static final AtomicLongFieldUpdater<ReplayInner> REQUESTED = AtomicLongFieldUpdater.newUpdater(ReplayInner.class, "requested");
/*     */ 
/*     */     
/*     */     int fusionMode;
/*     */ 
/*     */     
/*     */     ReplayInner(CoreSubscriber<? super T> actual, ReplayProcessor<T> parent) {
/* 559 */       this.actual = actual;
/* 560 */       this.parent = parent;
/* 561 */       this.buffer = parent.buffer;
/*     */     }
/*     */ 
/*     */     
/*     */     public long requested() {
/* 566 */       return this.requested;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCancelled() {
/* 571 */       return (this.requested == Long.MIN_VALUE);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 576 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 581 */       if ((requestedMode & 0x2) != 0) {
/* 582 */         this.fusionMode = 2;
/* 583 */         return 2;
/*     */       } 
/* 585 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 591 */       return this.buffer.poll(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 596 */       this.buffer.clear(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 601 */       return this.buffer.isEmpty(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 606 */       return this.buffer.size(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 611 */       if (Operators.validate(n)) {
/* 612 */         if (fusionMode() == 0) {
/* 613 */           Operators.addCapCancellable(REQUESTED, this, n);
/*     */         }
/* 615 */         this.buffer.replay(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void requestMore(int index) {
/* 621 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 626 */       if (REQUESTED.getAndSet(this, Long.MIN_VALUE) != Long.MIN_VALUE) {
/* 627 */         this.parent.remove(this);
/*     */         
/* 629 */         if (enter()) {
/* 630 */           this.node = null;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void node(@Nullable Object node) {
/* 637 */       this.node = node;
/*     */     }
/*     */ 
/*     */     
/*     */     public int fusionMode() {
/* 642 */       return this.fusionMode;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object node() {
/* 648 */       return this.node;
/*     */     }
/*     */ 
/*     */     
/*     */     public int index() {
/* 653 */       return this.index;
/*     */     }
/*     */ 
/*     */     
/*     */     public void index(int index) {
/* 658 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public int tailIndex() {
/* 663 */       return this.tailIndex;
/*     */     }
/*     */ 
/*     */     
/*     */     public void tailIndex(int tailIndex) {
/* 668 */       this.tailIndex = tailIndex;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean enter() {
/* 673 */       return (WIP.getAndIncrement(this) == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public int leave(int missed) {
/* 678 */       return WIP.addAndGet(this, -missed);
/*     */     }
/*     */ 
/*     */     
/*     */     public void produced(long n) {
/* 683 */       REQUESTED.addAndGet(this, -n);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ReplayProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */