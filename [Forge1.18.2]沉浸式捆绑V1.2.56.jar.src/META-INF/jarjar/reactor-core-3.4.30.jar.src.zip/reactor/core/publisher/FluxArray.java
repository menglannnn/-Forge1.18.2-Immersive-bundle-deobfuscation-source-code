/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxArray<T>
/*     */   extends Flux<T>
/*     */   implements Fuseable, SourceProducer<T>
/*     */ {
/*     */   final T[] array;
/*     */   
/*     */   @SafeVarargs
/*     */   public FluxArray(T... array) {
/*  40 */     this.array = (T[])Objects.<Object[]>requireNonNull((Object[])array, "array");
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> void subscribe(CoreSubscriber<? super T> s, T[] array) {
/*  45 */     if (array.length == 0) {
/*  46 */       Operators.complete((Subscriber<?>)s);
/*     */       return;
/*     */     } 
/*  49 */     if (s instanceof Fuseable.ConditionalSubscriber) {
/*  50 */       s.onSubscribe(new ArrayConditionalSubscription<>((Fuseable.ConditionalSubscriber<? super T>)s, array));
/*     */     } else {
/*     */       
/*  53 */       s.onSubscribe(new ArraySubscription<>(s, array));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  59 */     subscribe(actual, this.array);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  65 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.array.length); 
/*  66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ArraySubscription<T>
/*     */     implements InnerProducer<T>, Fuseable.SynchronousSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final T[] array;
/*     */     
/*     */     int index;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile long requested;
/*     */     
/*  85 */     static final AtomicLongFieldUpdater<ArraySubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(ArraySubscription.class, "requested");
/*     */     
/*     */     ArraySubscription(CoreSubscriber<? super T> actual, T[] array) {
/*  88 */       this.actual = actual;
/*  89 */       this.array = array;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/*  94 */       if (Operators.validate(n) && 
/*  95 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/*  96 */         if (n == Long.MAX_VALUE) {
/*  97 */           fastPath();
/*     */         } else {
/*     */           
/* 100 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void slowPath(long n) {
/* 107 */       T[] a = this.array;
/* 108 */       int len = a.length;
/* 109 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       
/* 111 */       int i = this.index;
/* 112 */       int e = 0;
/*     */       
/*     */       while (true) {
/* 115 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 119 */         while (i != len && e != n) {
/* 120 */           T t = a[i];
/*     */           
/* 122 */           if (t == null) {
/* 123 */             coreSubscriber.onError(new NullPointerException("The " + i + "th array element was null"));
/*     */             
/*     */             return;
/*     */           } 
/* 127 */           coreSubscriber.onNext(t);
/*     */           
/* 129 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 133 */           i++;
/* 134 */           e++;
/*     */         } 
/*     */         
/* 137 */         if (i == len) {
/* 138 */           coreSubscriber.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 142 */         n = this.requested;
/*     */         
/* 144 */         if (n == e) {
/* 145 */           this.index = i;
/* 146 */           n = REQUESTED.addAndGet(this, -e);
/* 147 */           if (n == 0L) {
/*     */             return;
/*     */           }
/* 150 */           e = 0;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void fastPath() {
/* 156 */       T[] a = this.array;
/* 157 */       int len = a.length;
/* 158 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       
/* 160 */       for (int i = this.index; i != len; i++) {
/* 161 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 165 */         T t = a[i];
/*     */         
/* 167 */         if (t == null) {
/* 168 */           coreSubscriber.onError(new NullPointerException("The " + i + "th array element was null"));
/*     */           
/*     */           return;
/*     */         } 
/* 172 */         coreSubscriber.onNext(t);
/*     */       } 
/* 174 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 177 */       coreSubscriber.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 182 */       this.cancelled = true;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 188 */       int i = this.index;
/* 189 */       T[] a = this.array;
/* 190 */       if (i != a.length) {
/* 191 */         T t = a[i];
/* 192 */         Objects.requireNonNull(t);
/* 193 */         this.index = i + 1;
/* 194 */         return t;
/*     */       } 
/* 196 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 201 */       return (this.index == this.array.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 206 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 211 */       this.index = this.array.length;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 216 */       return this.array.length - this.index;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 222 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isEmpty()); 
/* 223 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(size()); 
/* 224 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 225 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested);
/*     */       
/* 227 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ArrayConditionalSubscription<T>
/*     */     implements InnerProducer<T>, Fuseable.SynchronousSubscription<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final T[] array;
/*     */     
/*     */     int index;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile long requested;
/*     */     
/* 245 */     static final AtomicLongFieldUpdater<ArrayConditionalSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(ArrayConditionalSubscription.class, "requested");
/*     */ 
/*     */     
/*     */     ArrayConditionalSubscription(Fuseable.ConditionalSubscriber<? super T> actual, T[] array) {
/* 249 */       this.actual = actual;
/* 250 */       this.array = array;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 255 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 260 */       if (Operators.validate(n) && 
/* 261 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/* 262 */         if (n == Long.MAX_VALUE) {
/* 263 */           fastPath();
/*     */         } else {
/*     */           
/* 266 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void slowPath(long n) {
/* 273 */       T[] a = this.array;
/* 274 */       int len = a.length;
/* 275 */       Fuseable.ConditionalSubscriber<? super T> s = this.actual;
/*     */       
/* 277 */       int i = this.index;
/* 278 */       int e = 0;
/*     */       
/*     */       while (true) {
/* 281 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 285 */         while (i != len && e != n) {
/* 286 */           T t = a[i];
/*     */           
/* 288 */           if (t == null) {
/* 289 */             s.onError(new NullPointerException("The " + i + "th array element was null"));
/*     */             
/*     */             return;
/*     */           } 
/* 293 */           boolean b = s.tryOnNext(t);
/*     */           
/* 295 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 299 */           i++;
/* 300 */           if (b) {
/* 301 */             e++;
/*     */           }
/*     */         } 
/*     */         
/* 305 */         if (i == len) {
/* 306 */           s.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 310 */         n = this.requested;
/*     */         
/* 312 */         if (n == e) {
/* 313 */           this.index = i;
/* 314 */           n = REQUESTED.addAndGet(this, -e);
/* 315 */           if (n == 0L) {
/*     */             return;
/*     */           }
/* 318 */           e = 0;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void fastPath() {
/* 324 */       T[] a = this.array;
/* 325 */       int len = a.length;
/* 326 */       Fuseable.ConditionalSubscriber<? super T> conditionalSubscriber = this.actual;
/*     */       
/* 328 */       for (int i = this.index; i != len; i++) {
/* 329 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 333 */         T t = a[i];
/*     */         
/* 335 */         if (t == null) {
/* 336 */           conditionalSubscriber.onError(new NullPointerException("The " + i + "th array element was null"));
/*     */           
/*     */           return;
/*     */         } 
/* 340 */         conditionalSubscriber.onNext(t);
/*     */       } 
/* 342 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 345 */       conditionalSubscriber.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 350 */       this.cancelled = true;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 356 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isEmpty()); 
/* 357 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(size()); 
/* 358 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 359 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested);
/*     */       
/* 361 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 367 */       int i = this.index;
/* 368 */       T[] a = this.array;
/* 369 */       if (i != a.length) {
/* 370 */         T t = Objects.requireNonNull(a[i], "Array returned null value");
/* 371 */         this.index = i + 1;
/* 372 */         return t;
/*     */       } 
/* 374 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 379 */       return (this.index == this.array.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 384 */       this.index = this.array.length;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 389 */       return this.array.length - this.index;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */