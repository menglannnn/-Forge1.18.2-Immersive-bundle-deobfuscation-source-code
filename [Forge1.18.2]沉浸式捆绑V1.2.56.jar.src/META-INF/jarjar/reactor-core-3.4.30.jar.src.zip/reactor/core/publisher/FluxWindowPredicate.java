/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxWindowPredicate<T>
/*     */   extends InternalFluxOperator<T, Flux<T>>
/*     */   implements Fuseable
/*     */ {
/*     */   final Supplier<? extends Queue<T>> groupQueueSupplier;
/*     */   final Supplier<? extends Queue<Flux<T>>> mainQueueSupplier;
/*     */   final FluxBufferPredicate.Mode mode;
/*     */   final Predicate<? super T> predicate;
/*     */   final int prefetch;
/*     */   
/*     */   FluxWindowPredicate(Flux<? extends T> source, Supplier<? extends Queue<Flux<T>>> mainQueueSupplier, Supplier<? extends Queue<T>> groupQueueSupplier, int prefetch, Predicate<? super T> predicate, FluxBufferPredicate.Mode mode) {
/*  77 */     super(source);
/*  78 */     if (prefetch <= 0) {
/*  79 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  81 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*  82 */     this
/*  83 */       .mainQueueSupplier = Objects.<Supplier<? extends Queue<Flux<T>>>>requireNonNull(mainQueueSupplier, "mainQueueSupplier");
/*  84 */     this
/*  85 */       .groupQueueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(groupQueueSupplier, "groupQueueSupplier");
/*  86 */     this.mode = mode;
/*  87 */     this.prefetch = prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Flux<T>> actual) {
/*  92 */     return new WindowPredicateMain<>(actual, this.mainQueueSupplier
/*  93 */         .get(), this.groupQueueSupplier, this.prefetch, this.predicate, this.mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 102 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 107 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 108 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowPredicateMain<T>
/*     */     implements Fuseable.QueueSubscription<Flux<T>>, InnerOperator<T, Flux<T>>
/*     */   {
/*     */     final CoreSubscriber<? super Flux<T>> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Supplier<? extends Queue<T>> groupQueueSupplier;
/*     */     
/*     */     final FluxBufferPredicate.Mode mode;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final Queue<Flux<T>> queue;
/*     */     
/*     */     FluxWindowPredicate.WindowFlux<T> window;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 133 */     static final AtomicIntegerFieldUpdater<WindowPredicateMain> WIP = AtomicIntegerFieldUpdater.newUpdater(WindowPredicateMain.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 138 */     static final AtomicLongFieldUpdater<WindowPredicateMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(WindowPredicateMain.class, "requested");
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 144 */     static final AtomicReferenceFieldUpdater<WindowPredicateMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(WindowPredicateMain.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile int cancelled;
/*     */ 
/*     */     
/* 151 */     static final AtomicIntegerFieldUpdater<WindowPredicateMain> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(WindowPredicateMain.class, "cancelled");
/*     */ 
/*     */     
/*     */     volatile int windowCount;
/*     */ 
/*     */     
/* 157 */     static final AtomicIntegerFieldUpdater<WindowPredicateMain> WINDOW_COUNT = AtomicIntegerFieldUpdater.newUpdater(WindowPredicateMain.class, "windowCount");
/*     */ 
/*     */ 
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     volatile boolean outputFused;
/*     */ 
/*     */ 
/*     */     
/*     */     WindowPredicateMain(CoreSubscriber<? super Flux<T>> actual, Queue<Flux<T>> queue, Supplier<? extends Queue<T>> groupQueueSupplier, int prefetch, Predicate<? super T> predicate, FluxBufferPredicate.Mode mode) {
/* 169 */       this.actual = actual;
/* 170 */       this.ctx = actual.currentContext();
/* 171 */       this.queue = queue;
/* 172 */       this.groupQueueSupplier = groupQueueSupplier;
/* 173 */       this.prefetch = prefetch;
/* 174 */       this.predicate = predicate;
/* 175 */       this.mode = mode;
/* 176 */       WINDOW_COUNT.lazySet(this, 2);
/* 177 */       initializeWindow();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 182 */       if (Operators.validate(this.s, s)) {
/* 183 */         this.s = s;
/* 184 */         this.actual.onSubscribe(this);
/* 185 */         if (this.cancelled == 0) {
/* 186 */           s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void initializeWindow() {
/* 193 */       FluxWindowPredicate.WindowFlux<T> g = new FluxWindowPredicate.WindowFlux<>(this.groupQueueSupplier.get(), this);
/*     */       
/* 195 */       this.window = g;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     FluxWindowPredicate.WindowFlux<T> newWindowDeferred() {
/* 200 */       if (this.cancelled == 0) {
/* 201 */         WINDOW_COUNT.getAndIncrement(this);
/*     */         
/* 203 */         FluxWindowPredicate.WindowFlux<T> g = new FluxWindowPredicate.WindowFlux<>(this.groupQueueSupplier.get(), this);
/* 204 */         this.window = g;
/* 205 */         return g;
/*     */       } 
/* 207 */       return null;
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       boolean match;
/* 212 */       if (this.done) {
/* 213 */         Operators.onNextDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 216 */       FluxWindowPredicate.WindowFlux<T> g = this.window;
/*     */ 
/*     */       
/*     */       try {
/* 220 */         match = this.predicate.test(t);
/*     */       }
/* 222 */       catch (Throwable e) {
/* 223 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 228 */       if (!handleDeferredWindow(g, t)) {
/*     */         return;
/*     */       }
/* 231 */       drain();
/*     */       
/* 233 */       if (this.mode == FluxBufferPredicate.Mode.UNTIL && match) {
/* 234 */         if (g.cancelled) {
/*     */           
/* 236 */           Operators.onDiscard(t, this.ctx);
/* 237 */           this.s.request(1L);
/*     */         } else {
/* 239 */           g.onNext(t);
/*     */         } 
/* 241 */         g.onComplete();
/* 242 */         newWindowDeferred();
/* 243 */         this.s.request(1L);
/*     */       }
/* 245 */       else if (this.mode == FluxBufferPredicate.Mode.UNTIL_CUT_BEFORE && match) {
/* 246 */         g.onComplete();
/* 247 */         g = newWindowDeferred();
/* 248 */         if (g != null) {
/* 249 */           g.onNext(t);
/* 250 */           handleDeferredWindow(g, t);
/* 251 */           drain();
/*     */         }
/*     */       
/* 254 */       } else if (this.mode == FluxBufferPredicate.Mode.WHILE && !match) {
/* 255 */         g.onComplete();
/* 256 */         newWindowDeferred();
/* 257 */         Operators.onDiscard(t, this.ctx);
/*     */         
/* 259 */         this.s.request(1L);
/*     */       }
/* 261 */       else if (g.cancelled) {
/* 262 */         Operators.onDiscard(t, this.ctx);
/* 263 */         this.s.request(1L);
/*     */       } else {
/*     */         
/* 266 */         g.onNext(t);
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean handleDeferredWindow(@Nullable FluxWindowPredicate.WindowFlux<T> window, T signal) {
/* 271 */       if (window != null && window.deferred) {
/* 272 */         window.deferred = false;
/* 273 */         if (!this.queue.offer(window)) {
/* 274 */           onError(Operators.onOperatorError(this, 
/* 275 */                 Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), signal, this.ctx));
/*     */ 
/*     */           
/* 278 */           return false;
/*     */         } 
/*     */       } 
/* 281 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 286 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 287 */         this.done = true;
/* 288 */         cleanup();
/* 289 */         drain();
/*     */       } else {
/*     */         
/* 292 */         Operators.onErrorDropped(t, this.ctx);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 298 */       if (this.done) {
/*     */         return;
/*     */       }
/* 301 */       cleanup();
/*     */       
/* 303 */       FluxWindowPredicate.WindowFlux<T> g = this.window;
/* 304 */       if (g != null) {
/* 305 */         g.onComplete();
/*     */       }
/* 307 */       this.window = null;
/* 308 */       this.done = true;
/* 309 */       WINDOW_COUNT.decrementAndGet(this);
/* 310 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     void cleanup() {
/* 315 */       if (this.predicate instanceof Disposable) {
/* 316 */         ((Disposable)this.predicate).dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 323 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 324 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled == 1)); 
/* 325 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 326 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 327 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 328 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 329 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 330 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 332 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 337 */       return (this.window == null) ? Stream.<Scannable>empty() : Stream.<Scannable>of(this.window);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Flux<T>> actual() {
/* 342 */       return this.actual;
/*     */     }
/*     */     
/*     */     void signalAsyncError() {
/* 346 */       Throwable e = Exceptions.terminate(ERROR, this);
/* 347 */       this.windowCount = 0;
/* 348 */       FluxWindowPredicate.WindowFlux<T> g = this.window;
/* 349 */       if (g != null) {
/* 350 */         g.onError(e);
/*     */       }
/* 352 */       this.actual.onError(e);
/* 353 */       this.window = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 358 */       if (Operators.validate(n)) {
/* 359 */         Operators.addCap(REQUESTED, this, n);
/* 360 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 366 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 367 */         if (WINDOW_COUNT.decrementAndGet(this) == 0) {
/* 368 */           this.s.cancel();
/* 369 */           cleanup();
/*     */         }
/* 371 */         else if (!this.outputFused && 
/* 372 */           WIP.getAndIncrement(this) == 0) {
/*     */ 
/*     */           
/* 375 */           FluxWindowPredicate.WindowFlux<T> w = this.window; Flux<T> g;
/* 376 */           while ((g = this.queue.poll()) != null) {
/* 377 */             ((FluxWindowPredicate.WindowFlux)g).cancel();
/*     */           }
/* 379 */           if (w != null && w.deferred) {
/* 380 */             w.cancel();
/*     */           }
/*     */           
/* 383 */           if (WIP.decrementAndGet(this) == 0) {
/* 384 */             if (!this.done && WINDOW_COUNT.get(this) == 0) {
/* 385 */               this.s.cancel();
/* 386 */               cleanup();
/*     */             } else {
/*     */               
/* 389 */               CANCELLED.set(this, 2);
/*     */             } 
/*     */             
/*     */             return;
/*     */           } 
/* 394 */           CANCELLED.set(this, 2);
/*     */           
/* 396 */           drainLoop();
/*     */         }
/*     */       
/*     */       }
/* 400 */       else if (CANCELLED.get(this) == 2) {
/*     */         
/* 402 */         if (WINDOW_COUNT.get(this) == 0) {
/* 403 */           this.s.cancel();
/* 404 */           cleanup();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void groupTerminated() {
/* 411 */       if (this.windowCount == 0) {
/*     */         return;
/*     */       }
/* 414 */       this.window = null;
/* 415 */       if (WINDOW_COUNT.decrementAndGet(this) == 0) {
/* 416 */         this.s.cancel();
/* 417 */         cleanup();
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 422 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 426 */       if (this.outputFused) {
/* 427 */         drainFused();
/*     */       } else {
/*     */         
/* 430 */         drainLoop();
/*     */       } 
/*     */     }
/*     */     
/*     */     void drainFused() {
/* 435 */       int missed = 1;
/*     */       
/* 437 */       CoreSubscriber<? super Flux<T>> coreSubscriber = this.actual;
/* 438 */       Queue<Flux<T>> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 442 */         if (this.cancelled != 0) {
/* 443 */           q.clear();
/*     */           
/*     */           return;
/*     */         } 
/* 447 */         boolean d = this.done;
/*     */         
/* 449 */         coreSubscriber.onNext(null);
/*     */         
/* 451 */         if (d) {
/* 452 */           Throwable ex = this.error;
/* 453 */           if (ex != null) {
/* 454 */             signalAsyncError();
/*     */           } else {
/*     */             
/* 457 */             coreSubscriber.onComplete();
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 462 */         missed = WIP.addAndGet(this, -missed);
/* 463 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drainLoop() {
/* 471 */       int missed = 1;
/*     */       
/* 473 */       CoreSubscriber<? super Flux<T>> coreSubscriber = this.actual;
/* 474 */       Queue<Flux<T>> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 478 */         long r = this.requested;
/* 479 */         long e = 0L;
/*     */         
/* 481 */         while (e != r) {
/* 482 */           boolean d = this.done;
/* 483 */           Flux<T> v = q.poll();
/* 484 */           boolean empty = (v == null);
/*     */           
/* 486 */           if (checkTerminated(d, empty, (Subscriber<?>)coreSubscriber, q)) {
/*     */             return;
/*     */           }
/*     */           
/* 490 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 494 */           coreSubscriber.onNext(v);
/*     */           
/* 496 */           e++;
/*     */         } 
/*     */         
/* 499 */         if (e == r && 
/* 500 */           checkTerminated(this.done, q.isEmpty(), (Subscriber<?>)coreSubscriber, q)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 505 */         if (e != 0L) {
/*     */           
/* 507 */           this.s.request(e);
/*     */           
/* 509 */           if (r != Long.MAX_VALUE) {
/* 510 */             REQUESTED.addAndGet(this, -e);
/*     */           }
/*     */         } 
/*     */         
/* 514 */         missed = WIP.addAndGet(this, -missed);
/* 515 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, Queue<Flux<T>> q) {
/* 526 */       if (this.cancelled != 0) {
/* 527 */         q.clear();
/* 528 */         return true;
/*     */       } 
/* 530 */       if (d) {
/* 531 */         Throwable e = this.error;
/* 532 */         if (e != null && e != Exceptions.TERMINATED) {
/* 533 */           this.queue.clear();
/* 534 */           signalAsyncError();
/* 535 */           return true;
/*     */         } 
/* 537 */         if (empty) {
/* 538 */           a.onComplete();
/* 539 */           return true;
/*     */         } 
/*     */       } 
/*     */       
/* 543 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Flux<T> poll() {
/* 549 */       return this.queue.poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 554 */       return this.queue.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 559 */       return this.queue.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 564 */       this.queue.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 569 */       if ((requestedMode & 0x2) != 0) {
/* 570 */         this.outputFused = true;
/* 571 */         return 2;
/*     */       } 
/* 573 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class WindowFlux<T>
/*     */     extends Flux<T>
/*     */     implements Fuseable, Fuseable.QueueSubscription<T>, InnerOperator<T, T>
/*     */   {
/*     */     final Queue<T> queue;
/*     */     
/*     */     volatile FluxWindowPredicate.WindowPredicateMain<T> parent;
/* 585 */     static final AtomicReferenceFieldUpdater<WindowFlux, FluxWindowPredicate.WindowPredicateMain> PARENT = AtomicReferenceFieldUpdater.newUpdater(WindowFlux.class, FluxWindowPredicate.WindowPredicateMain.class, "parent");
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */ 
/*     */     
/*     */     Throwable error;
/*     */     
/*     */     volatile CoreSubscriber<? super T> actual;
/*     */     
/* 595 */     static final AtomicReferenceFieldUpdater<WindowFlux, CoreSubscriber> ACTUAL = AtomicReferenceFieldUpdater.newUpdater(WindowFlux.class, CoreSubscriber.class, "actual");
/*     */ 
/*     */ 
/*     */     
/* 599 */     volatile Context ctx = Context.empty();
/*     */ 
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile int once;
/*     */     
/* 606 */     static final AtomicIntegerFieldUpdater<WindowFlux> ONCE = AtomicIntegerFieldUpdater.newUpdater(WindowFlux.class, "once");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/* 611 */     static final AtomicIntegerFieldUpdater<WindowFlux> WIP = AtomicIntegerFieldUpdater.newUpdater(WindowFlux.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 616 */     static final AtomicLongFieldUpdater<WindowFlux> REQUESTED = AtomicLongFieldUpdater.newUpdater(WindowFlux.class, "requested");
/*     */ 
/*     */     
/*     */     volatile boolean enableOperatorFusion;
/*     */     
/*     */     int produced;
/*     */     
/*     */     boolean deferred;
/*     */ 
/*     */     
/*     */     WindowFlux(Queue<T> queue, FluxWindowPredicate.WindowPredicateMain<T> parent) {
/* 627 */       this.queue = queue;
/* 628 */       this.parent = parent;
/* 629 */       this.deferred = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 634 */       return this.actual;
/*     */     }
/*     */     
/*     */     void propagateTerminate() {
/* 638 */       FluxWindowPredicate.WindowPredicateMain<T> r = this.parent;
/* 639 */       if (r != null && PARENT.compareAndSet(this, r, null)) {
/* 640 */         r.groupTerminated();
/*     */       }
/*     */     }
/*     */     
/*     */     void drainRegular(Subscriber<? super T> a) {
/* 645 */       int missed = 1;
/*     */       
/* 647 */       Queue<T> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 651 */         long r = this.requested;
/* 652 */         long e = 0L;
/*     */         
/* 654 */         while (r != e) {
/* 655 */           boolean d = this.done;
/*     */           
/* 657 */           T t = q.poll();
/* 658 */           boolean empty = (t == null);
/*     */           
/* 660 */           if (checkTerminated(d, empty, a, q)) {
/*     */             return;
/*     */           }
/*     */           
/* 664 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 668 */           a.onNext(t);
/*     */           
/* 670 */           e++;
/*     */         } 
/*     */         
/* 673 */         if (r == e && 
/* 674 */           checkTerminated(this.done, q.isEmpty(), a, q)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 679 */         if (e != 0L) {
/* 680 */           FluxWindowPredicate.WindowPredicateMain<T> main = this.parent;
/* 681 */           if (main != null) {
/* 682 */             main.s.request(e);
/*     */           }
/* 684 */           if (r != Long.MAX_VALUE) {
/* 685 */             REQUESTED.addAndGet(this, -e);
/*     */           }
/*     */         } 
/*     */         
/* 689 */         missed = WIP.addAndGet(this, -missed);
/* 690 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drainFused(Subscriber<? super T> a) {
/* 697 */       int missed = 1;
/*     */       
/* 699 */       Queue<T> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 703 */         if (this.cancelled) {
/* 704 */           Operators.onDiscardQueueWithClear(q, this.ctx, null);
/* 705 */           this.ctx = Context.empty();
/* 706 */           this.actual = null;
/*     */           
/*     */           return;
/*     */         } 
/* 710 */         boolean d = this.done;
/*     */         
/* 712 */         a.onNext(null);
/*     */         
/* 714 */         if (d) {
/* 715 */           this.ctx = Context.empty();
/* 716 */           this.actual = null;
/*     */           
/* 718 */           Throwable ex = this.error;
/* 719 */           if (ex != null) {
/* 720 */             a.onError(ex);
/*     */           } else {
/*     */             
/* 723 */             a.onComplete();
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 728 */         missed = WIP.addAndGet(this, -missed);
/* 729 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drain() {
/* 736 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 737 */       if (coreSubscriber != null) {
/* 738 */         if (WIP.getAndIncrement(this) != 0) {
/*     */           return;
/*     */         }
/*     */         
/* 742 */         if (this.enableOperatorFusion) {
/* 743 */           drainFused((Subscriber<? super T>)coreSubscriber);
/*     */         } else {
/*     */           
/* 746 */           drainRegular((Subscriber<? super T>)coreSubscriber);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, Queue<?> q) {
/* 752 */       if (this.cancelled) {
/* 753 */         Operators.onDiscardQueueWithClear(q, this.ctx, null);
/* 754 */         this.ctx = Context.empty();
/* 755 */         this.actual = null;
/* 756 */         return true;
/*     */       } 
/* 758 */       if (d && empty) {
/* 759 */         Throwable e = this.error;
/* 760 */         this.ctx = Context.empty();
/* 761 */         this.actual = null;
/* 762 */         if (e != null) {
/* 763 */           a.onError(e);
/*     */         } else {
/*     */           
/* 766 */           a.onComplete();
/*     */         } 
/* 768 */         return true;
/*     */       } 
/*     */       
/* 771 */       return false;
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/* 775 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */       
/* 777 */       if (!this.queue.offer(t)) {
/* 778 */         onError(Operators.onOperatorError(this, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, this.ctx));
/*     */         
/*     */         return;
/*     */       } 
/* 782 */       if (this.enableOperatorFusion) {
/* 783 */         if (coreSubscriber != null) {
/* 784 */           coreSubscriber.onNext(null);
/*     */         }
/*     */       } else {
/*     */         
/* 788 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 799 */       this.error = t;
/* 800 */       this.done = true;
/*     */       
/* 802 */       propagateTerminate();
/*     */       
/* 804 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 809 */       this.done = true;
/* 810 */       propagateTerminate();
/*     */       
/* 812 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super T> actual) {
/* 817 */       if (this.once == 0 && ONCE.compareAndSet(this, 0, 1)) {
/* 818 */         actual.onSubscribe(this);
/* 819 */         ACTUAL.lazySet(this, actual);
/* 820 */         this.ctx = actual.currentContext();
/* 821 */         drain();
/*     */       } else {
/*     */         
/* 824 */         actual.onError(new IllegalStateException("This processor allows only a single Subscriber"));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 831 */       if (Operators.validate(n)) {
/* 832 */         Operators.addCap(REQUESTED, this, n);
/* 833 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 839 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 842 */       this.cancelled = true;
/*     */       
/* 844 */       FluxWindowPredicate.WindowPredicateMain<T> r = this.parent;
/* 845 */       if (r != null && PARENT
/* 846 */         .compareAndSet(this, r, null))
/*     */       {
/* 848 */         if (FluxWindowPredicate.WindowPredicateMain.WINDOW_COUNT.decrementAndGet(r) == 0) {
/* 849 */           r.cancel();
/*     */         } else {
/*     */           
/* 852 */           r.s.request(1L);
/*     */         } 
/*     */       }
/*     */       
/* 856 */       if (!this.enableOperatorFusion && 
/* 857 */         WIP.getAndIncrement(this) == 0) {
/* 858 */         Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 867 */       T v = this.queue.poll();
/* 868 */       if (v != null) {
/* 869 */         this.produced++;
/*     */       } else {
/*     */         
/* 872 */         int p = this.produced;
/* 873 */         if (p != 0) {
/* 874 */           this.produced = 0;
/* 875 */           FluxWindowPredicate.WindowPredicateMain<T> main = this.parent;
/* 876 */           if (main != null) {
/* 877 */             main.s.request(p);
/*     */           }
/*     */         } 
/*     */       } 
/* 881 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 886 */       return this.queue.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 891 */       return this.queue.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 896 */       Operators.onDiscardQueueWithClear(this.queue, this.ctx, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 901 */       if ((requestedMode & 0x2) != 0) {
/* 902 */         this.enableOperatorFusion = true;
/* 903 */         return 2;
/*     */       } 
/* 905 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 911 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 912 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 913 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 914 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue == null) ? 0 : this.queue.size()); 
/* 915 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 916 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 917 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 919 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxWindowPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */