/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxRange
/*     */   extends Flux<Integer>
/*     */   implements Fuseable, SourceProducer<Integer>
/*     */ {
/*     */   final long start;
/*     */   final long end;
/*     */   
/*     */   FluxRange(int start, int count) {
/*  39 */     if (count < 0) {
/*  40 */       throw new IllegalArgumentException("count >= required but it was " + count);
/*     */     }
/*  42 */     long e = start + count;
/*  43 */     if (e - 1L > 2147483647L) {
/*  44 */       throw new IllegalArgumentException("start + count must be less than Integer.MAX_VALUE + 1");
/*     */     }
/*     */     
/*  47 */     this.start = start;
/*  48 */     this.end = e;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Integer> actual) {
/*  54 */     long st = this.start;
/*  55 */     long en = this.end;
/*  56 */     if (st == en) {
/*  57 */       Operators.complete((Subscriber<?>)actual);
/*     */       return;
/*     */     } 
/*  60 */     if (st + 1L == en) {
/*  61 */       actual.onSubscribe(Operators.scalarSubscription(actual, Integer.valueOf((int)st)));
/*     */       
/*     */       return;
/*     */     } 
/*  65 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  66 */       actual.onSubscribe(new RangeSubscriptionConditional((Fuseable.ConditionalSubscriber<? super Integer>)actual, st, en));
/*     */       return;
/*     */     } 
/*  69 */     actual.onSubscribe(new RangeSubscription(actual, st, en));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  74 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RangeSubscription
/*     */     implements InnerProducer<Integer>, Fuseable.SynchronousSubscription<Integer>
/*     */   {
/*     */     final CoreSubscriber<? super Integer> actual;
/*     */     
/*     */     final long end;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     long index;
/*     */     
/*     */     volatile long requested;
/*  91 */     static final AtomicLongFieldUpdater<RangeSubscription> REQUESTED = AtomicLongFieldUpdater.newUpdater(RangeSubscription.class, "requested");
/*     */     
/*     */     RangeSubscription(CoreSubscriber<? super Integer> actual, long start, long end) {
/*  94 */       this.actual = actual;
/*  95 */       this.index = start;
/*  96 */       this.end = end;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Integer> actual() {
/* 101 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 106 */       if (Operators.validate(n) && 
/* 107 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/* 108 */         if (n == Long.MAX_VALUE) {
/* 109 */           fastPath();
/*     */         } else {
/* 111 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 119 */       this.cancelled = true;
/*     */     }
/*     */     
/*     */     void fastPath() {
/* 123 */       long e = this.end;
/* 124 */       CoreSubscriber<? super Integer> coreSubscriber = this.actual;
/*     */       long i;
/* 126 */       for (i = this.index; i != e; i++) {
/* 127 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 131 */         coreSubscriber.onNext(Integer.valueOf((int)i));
/*     */       } 
/*     */       
/* 134 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/*     */       
/* 138 */       coreSubscriber.onComplete();
/*     */     }
/*     */     
/*     */     void slowPath(long n) {
/* 142 */       CoreSubscriber<? super Integer> coreSubscriber = this.actual;
/*     */       
/* 144 */       long f = this.end;
/* 145 */       long e = 0L;
/* 146 */       long i = this.index;
/*     */ 
/*     */       
/*     */       while (true) {
/* 150 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 154 */         while (e != n && i != f) {
/*     */           
/* 156 */           coreSubscriber.onNext(Integer.valueOf((int)i));
/*     */           
/* 158 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 162 */           e++;
/* 163 */           i++;
/*     */         } 
/*     */         
/* 166 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 170 */         if (i == f) {
/* 171 */           coreSubscriber.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 175 */         n = this.requested;
/* 176 */         if (n == e) {
/* 177 */           this.index = i;
/* 178 */           n = REQUESTED.addAndGet(this, -e);
/* 179 */           if (n == 0L) {
/*     */             return;
/*     */           }
/* 182 */           e = 0L;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 190 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 191 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 192 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isEmpty()); 
/* 193 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 195 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Integer poll() {
/* 201 */       long i = this.index;
/* 202 */       if (i == this.end) {
/* 203 */         return null;
/*     */       }
/* 205 */       this.index = i + 1L;
/* 206 */       return Integer.valueOf((int)i);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 211 */       return (this.index == this.end);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 216 */       this.index = this.end;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 221 */       return (int)(this.end - this.index);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class RangeSubscriptionConditional
/*     */     implements InnerProducer<Integer>, Fuseable.SynchronousSubscription<Integer>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super Integer> actual;
/*     */     
/*     */     final long end;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     long index;
/*     */     
/*     */     volatile long requested;
/*     */     
/* 239 */     static final AtomicLongFieldUpdater<RangeSubscriptionConditional> REQUESTED = AtomicLongFieldUpdater.newUpdater(RangeSubscriptionConditional.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     RangeSubscriptionConditional(Fuseable.ConditionalSubscriber<? super Integer> actual, long start, long end) {
/* 244 */       this.actual = actual;
/* 245 */       this.index = start;
/* 246 */       this.end = end;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Integer> actual() {
/* 251 */       return (CoreSubscriber<? super Integer>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 256 */       if (Operators.validate(n) && 
/* 257 */         Operators.addCap(REQUESTED, this, n) == 0L) {
/* 258 */         if (n == Long.MAX_VALUE) {
/* 259 */           fastPath();
/*     */         } else {
/* 261 */           slowPath(n);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 269 */       this.cancelled = true;
/*     */     }
/*     */     
/*     */     void fastPath() {
/* 273 */       long e = this.end;
/* 274 */       Fuseable.ConditionalSubscriber<? super Integer> a = this.actual;
/*     */       long i;
/* 276 */       for (i = this.index; i != e; i++) {
/* 277 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 281 */         a.tryOnNext(Integer.valueOf((int)i));
/*     */       } 
/*     */       
/* 284 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/*     */       
/* 288 */       a.onComplete();
/*     */     }
/*     */     
/*     */     void slowPath(long n) {
/* 292 */       Fuseable.ConditionalSubscriber<? super Integer> a = this.actual;
/*     */       
/* 294 */       long f = this.end;
/* 295 */       long e = 0L;
/* 296 */       long i = this.index;
/*     */ 
/*     */       
/*     */       while (true) {
/* 300 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 304 */         while (e != n && i != f) {
/*     */           
/* 306 */           boolean b = a.tryOnNext(Integer.valueOf((int)i));
/*     */           
/* 308 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 312 */           if (b) {
/* 313 */             e++;
/*     */           }
/* 315 */           i++;
/*     */         } 
/*     */         
/* 318 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/*     */         
/* 322 */         if (i == f) {
/* 323 */           a.onComplete();
/*     */           
/*     */           return;
/*     */         } 
/* 327 */         n = this.requested;
/* 328 */         if (n == e) {
/* 329 */           this.index = i;
/* 330 */           n = REQUESTED.addAndGet(this, -e);
/* 331 */           if (n == 0L) {
/*     */             return;
/*     */           }
/* 334 */           e = 0L;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 341 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 342 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 343 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isEmpty()); 
/* 344 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 346 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Integer poll() {
/* 352 */       long i = this.index;
/* 353 */       if (i == this.end) {
/* 354 */         return null;
/*     */       }
/* 356 */       this.index = i + 1L;
/* 357 */       return Integer.valueOf((int)i);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 362 */       return (this.index == this.end);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 367 */       this.index = this.end;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 372 */       return (int)(this.end - this.index);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */