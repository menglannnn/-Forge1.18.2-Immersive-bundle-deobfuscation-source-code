/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxContextWrite<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */   implements Fuseable
/*     */ {
/*     */   final Function<Context, Context> doOnContext;
/*     */   
/*     */   FluxContextWrite(Flux<? extends T> source, Function<Context, Context> doOnContext) {
/*  36 */     super(source);
/*  37 */     this.doOnContext = Objects.<Function<Context, Context>>requireNonNull(doOnContext, "doOnContext");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  42 */     Context c = this.doOnContext.apply(actual.currentContext());
/*     */     
/*  44 */     return new ContextWriteSubscriber<>(actual, c);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  49 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  50 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ContextWriteSubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Fuseable.ConditionalSubscriber<? super T> actualConditional;
/*     */     
/*     */     final Context context;
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     Subscription s;
/*     */     
/*     */     ContextWriteSubscriber(CoreSubscriber<? super T> actual, Context context) {
/*  66 */       this.actual = actual;
/*  67 */       this.context = context;
/*  68 */       if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  69 */         this.actualConditional = (Fuseable.ConditionalSubscriber<? super T>)actual;
/*     */       } else {
/*     */         
/*  72 */         this.actualConditional = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  79 */       if (key == Scannable.Attr.PARENT) {
/*  80 */         return this.s;
/*     */       }
/*  82 */       if (key == Scannable.Attr.RUN_STYLE) {
/*  83 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*  85 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/*  90 */       return this.context;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  96 */       if (Operators.validate(this.s, s)) {
/*  97 */         this.s = s;
/*  98 */         if (s instanceof Fuseable.QueueSubscription) {
/*  99 */           this.qs = (Fuseable.QueueSubscription<T>)s;
/*     */         }
/* 101 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 107 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 112 */       if (this.actualConditional != null) {
/* 113 */         return this.actualConditional.tryOnNext(t);
/*     */       }
/* 115 */       this.actual.onNext(t);
/* 116 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 121 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 126 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 131 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 136 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 141 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 146 */       if (this.qs == null) {
/* 147 */         return 0;
/*     */       }
/* 149 */       return this.qs.requestFusion(requestedMode);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 155 */       if (this.qs != null) {
/* 156 */         return (T)this.qs.poll();
/*     */       }
/* 158 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 163 */       return (this.qs == null || this.qs.isEmpty());
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 168 */       if (this.qs != null) {
/* 169 */         this.qs.clear();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 175 */       return (this.qs != null) ? this.qs.size() : 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxContextWrite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */