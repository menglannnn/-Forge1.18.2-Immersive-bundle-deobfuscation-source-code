/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.Spliterator;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxFlattenIterable<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Function<? super T, ? extends Iterable<? extends R>> mapper;
/*     */   final int prefetch;
/*     */   final Supplier<Queue<T>> queueSupplier;
/*     */   
/*     */   FluxFlattenIterable(Flux<? extends T> source, Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch, Supplier<Queue<T>> queueSupplier) {
/*  60 */     super(source);
/*  61 */     if (prefetch <= 0) {
/*  62 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  64 */     this.mapper = Objects.<Function<? super T, ? extends Iterable<? extends R>>>requireNonNull(mapper, "mapper");
/*  65 */     this.prefetch = prefetch;
/*  66 */     this.queueSupplier = Objects.<Supplier<Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  71 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) throws Exception {
/*  78 */     if (this.source instanceof Callable) {
/*  79 */       Spliterator<? extends R> sp; boolean knownToBeFinite; T v = ((Callable)this.source).call();
/*     */       
/*  81 */       if (v == null) {
/*  82 */         Operators.complete((Subscriber<?>)actual);
/*  83 */         return null;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  89 */         Iterable<? extends R> iter = this.mapper.apply(v);
/*  90 */         sp = iter.spliterator();
/*  91 */         knownToBeFinite = FluxIterable.checkFinite(sp);
/*     */       }
/*  93 */       catch (Throwable ex) {
/*  94 */         Context ctx = actual.currentContext();
/*  95 */         Throwable e_ = Operators.onNextError(v, ex, ctx);
/*  96 */         Operators.onDiscard(v, ctx);
/*  97 */         if (e_ != null) {
/*  98 */           Operators.error((Subscriber<?>)actual, e_);
/*     */         } else {
/*     */           
/* 101 */           Operators.complete((Subscriber<?>)actual);
/*     */         } 
/* 103 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 107 */       FluxIterable.subscribe(actual, sp, knownToBeFinite);
/* 108 */       return null;
/*     */     } 
/* 110 */     return new FlattenIterableSubscriber<>(actual, this.mapper, this.prefetch, this.queueSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 118 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 119 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FlattenIterableSubscriber<T, R>
/*     */     implements InnerOperator<T, R>, Fuseable.QueueSubscription<R>, Consumer<R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final Function<? super T, ? extends Iterable<? extends R>> mapper;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final Supplier<Queue<T>> queueSupplier;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 138 */     static final AtomicIntegerFieldUpdater<FlattenIterableSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(FlattenIterableSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 144 */     static final AtomicLongFieldUpdater<FlattenIterableSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(FlattenIterableSubscriber.class, "requested");
/*     */ 
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     Queue<T> queue;
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 159 */     static final AtomicReferenceFieldUpdater<FlattenIterableSubscriber, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(FlattenIterableSubscriber.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Spliterator<? extends R> current;
/*     */ 
/*     */     
/*     */     boolean currentKnownToBeFinite;
/*     */ 
/*     */     
/*     */     boolean valueReady = false;
/*     */     
/*     */     R nextElement;
/*     */     
/*     */     int consumed;
/*     */     
/*     */     int fusionMode;
/*     */ 
/*     */     
/*     */     FlattenIterableSubscriber(CoreSubscriber<? super R> actual, Function<? super T, ? extends Iterable<? extends R>> mapper, int prefetch, Supplier<Queue<T>> queueSupplier) {
/* 179 */       this.actual = actual;
/* 180 */       this.mapper = mapper;
/* 181 */       this.prefetch = prefetch;
/* 182 */       this.queueSupplier = queueSupplier;
/* 183 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 189 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 190 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 191 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 192 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 193 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 194 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 195 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 196 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 198 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 203 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 208 */       if (Operators.validate(this.s, s)) {
/* 209 */         this.s = s;
/*     */         
/* 211 */         if (s instanceof Fuseable.QueueSubscription) {
/* 212 */           Fuseable.QueueSubscription<T> qs = (Fuseable.QueueSubscription<T>)s;
/*     */ 
/*     */           
/* 215 */           int m = qs.requestFusion(3);
/*     */           
/* 217 */           if (m == 1) {
/* 218 */             this.fusionMode = m;
/* 219 */             this.queue = (Queue<T>)qs;
/* 220 */             this.done = true;
/*     */             
/* 222 */             this.actual.onSubscribe(this);
/*     */             
/*     */             return;
/*     */           } 
/* 226 */           if (m == 2) {
/* 227 */             this.fusionMode = m;
/* 228 */             this.queue = (Queue<T>)qs;
/*     */             
/* 230 */             this.actual.onSubscribe(this);
/*     */             
/* 232 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 237 */         this.queue = this.queueSupplier.get();
/*     */         
/* 239 */         this.actual.onSubscribe(this);
/*     */         
/* 241 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 247 */       if (this.fusionMode != 2 && 
/* 248 */         !this.queue.offer(t)) {
/* 249 */         Context ctx = this.actual.currentContext();
/* 250 */         onError(Operators.onOperatorError(this.s, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), ctx));
/*     */         
/* 252 */         Operators.onDiscard(t, ctx);
/*     */         
/*     */         return;
/*     */       } 
/* 256 */       drain(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 261 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 262 */         this.done = true;
/* 263 */         drain(null);
/*     */       } else {
/*     */         
/* 266 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 272 */       this.done = true;
/* 273 */       drain(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(R t) {
/* 278 */       this.valueReady = true;
/* 279 */       this.nextElement = t;
/*     */     }
/*     */     
/*     */     boolean hasNext(Spliterator<? extends R> spliterator) {
/* 283 */       if (!this.valueReady)
/* 284 */         spliterator.tryAdvance(this); 
/* 285 */       return this.valueReady;
/*     */     }
/*     */     
/*     */     R next(Spliterator<? extends R> spliterator) {
/* 289 */       if (!this.valueReady && !hasNext(spliterator)) {
/* 290 */         throw new NoSuchElementException();
/*     */       }
/* 292 */       this.valueReady = false;
/* 293 */       R t = this.nextElement;
/* 294 */       this.nextElement = null;
/* 295 */       return t;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 301 */       if (Operators.validate(n)) {
/* 302 */         Operators.addCap(REQUESTED, this, n);
/* 303 */         drain(null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 309 */       if (!this.cancelled) {
/* 310 */         this.cancelled = true;
/*     */         
/* 312 */         this.s.cancel();
/*     */         
/* 314 */         if (WIP.getAndIncrement(this) == 0) {
/* 315 */           Context context = this.actual.currentContext();
/* 316 */           Operators.onDiscardQueueWithClear(this.queue, context, null);
/* 317 */           Operators.onDiscard(this.nextElement, context);
/* 318 */           Operators.onDiscardMultiple(this.current, this.currentKnownToBeFinite, context);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     final void resetCurrent() {
/* 325 */       this.current = null;
/* 326 */       this.currentKnownToBeFinite = false;
/*     */     }
/*     */     
/*     */     void drainAsync() {
/* 330 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/* 331 */       Queue<T> q = this.queue;
/*     */       
/* 333 */       int missed = 1;
/* 334 */       Spliterator<? extends R> sp = this.current;
/* 335 */       boolean itFinite = this.currentKnownToBeFinite;
/*     */ 
/*     */       
/*     */       while (true) {
/* 339 */         if (sp == null) {
/*     */           T t;
/* 341 */           if (this.cancelled) {
/* 342 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/*     */             
/*     */             return;
/*     */           } 
/* 346 */           Throwable ex = this.error;
/* 347 */           if (ex != null) {
/* 348 */             ex = Exceptions.terminate(ERROR, this);
/* 349 */             resetCurrent();
/* 350 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/* 351 */             coreSubscriber.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/* 355 */           boolean d = this.done;
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 360 */             t = q.poll();
/* 361 */           } catch (Throwable pollEx) {
/* 362 */             resetCurrent();
/* 363 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/* 364 */             coreSubscriber.onError(pollEx);
/*     */             
/*     */             return;
/*     */           } 
/* 368 */           boolean empty = (t == null);
/*     */           
/* 370 */           if (d && empty) {
/* 371 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 375 */           if (!empty) {
/*     */             boolean isEmpty;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 381 */               Iterable<? extends R> iterable = this.mapper.apply(t);
/* 382 */               sp = iterable.spliterator();
/* 383 */               itFinite = FluxIterable.checkFinite(sp);
/*     */               
/* 385 */               isEmpty = itFinite ? ((sp.estimateSize() == 0L)) : (!hasNext(sp));
/*     */             }
/* 387 */             catch (Throwable exc) {
/* 388 */               sp = null;
/* 389 */               itFinite = false;
/* 390 */               Context ctx = this.actual.currentContext();
/* 391 */               Throwable e_ = Operators.onNextError(t, exc, ctx, this.s);
/* 392 */               Operators.onDiscard(t, ctx);
/* 393 */               if (e_ != null) {
/* 394 */                 onError(e_);
/*     */               }
/*     */               
/*     */               continue;
/*     */             } 
/* 399 */             if (isEmpty) {
/* 400 */               sp = null;
/* 401 */               itFinite = false;
/* 402 */               int c = this.consumed + 1;
/* 403 */               if (c == this.limit) {
/* 404 */                 this.consumed = 0;
/* 405 */                 this.s.request(c);
/*     */                 continue;
/*     */               } 
/* 408 */               this.consumed = c;
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 415 */         if (sp != null) {
/* 416 */           long r = this.requested;
/* 417 */           long l1 = 0L;
/*     */           
/* 419 */           while (l1 != r) {
/* 420 */             R v; boolean b; if (this.cancelled) {
/* 421 */               resetCurrent();
/* 422 */               Context context = this.actual.currentContext();
/* 423 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 424 */               Operators.onDiscard(this.nextElement, context);
/* 425 */               Operators.onDiscardMultiple(sp, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 429 */             Throwable ex = this.error;
/* 430 */             if (ex != null) {
/* 431 */               Throwable throwable = Exceptions.terminate(ERROR, this);
/* 432 */               resetCurrent();
/* 433 */               Context context = this.actual.currentContext();
/* 434 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 435 */               Operators.onDiscard(this.nextElement, context);
/* 436 */               Operators.onDiscardMultiple(sp, itFinite, context);
/* 437 */               coreSubscriber.onError(throwable);
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/*     */             try {
/* 444 */               v = Objects.requireNonNull(next(sp), "iterator returned null");
/*     */             
/*     */             }
/* 447 */             catch (Throwable exc) {
/* 448 */               onError(Operators.onOperatorError(this.s, exc, this.actual
/* 449 */                     .currentContext()));
/*     */               
/*     */               continue;
/*     */             } 
/* 453 */             coreSubscriber.onNext(v);
/*     */             
/* 455 */             if (this.cancelled) {
/* 456 */               resetCurrent();
/* 457 */               Context context = this.actual.currentContext();
/* 458 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 459 */               Operators.onDiscard(this.nextElement, context);
/* 460 */               Operators.onDiscardMultiple(sp, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 464 */             l1 = l1 + 1L;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 469 */               b = hasNext(sp);
/*     */             }
/* 471 */             catch (Throwable exc) {
/* 472 */               onError(Operators.onOperatorError(this.s, exc, this.actual
/* 473 */                     .currentContext()));
/*     */               
/*     */               continue;
/*     */             } 
/* 477 */             if (!b) {
/* 478 */               int c = this.consumed + 1;
/* 479 */               if (c == this.limit) {
/* 480 */                 this.consumed = 0;
/* 481 */                 this.s.request(c);
/*     */               } else {
/*     */                 
/* 484 */                 this.consumed = c;
/*     */               } 
/* 486 */               sp = null;
/* 487 */               itFinite = false;
/* 488 */               resetCurrent();
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 493 */           if (l1 == r) {
/* 494 */             if (this.cancelled) {
/* 495 */               resetCurrent();
/* 496 */               Context context = this.actual.currentContext();
/* 497 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 498 */               Operators.onDiscard(this.nextElement, context);
/* 499 */               Operators.onDiscardMultiple(sp, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 503 */             Throwable ex = this.error;
/* 504 */             if (ex != null) {
/* 505 */               ex = Exceptions.terminate(ERROR, this);
/* 506 */               resetCurrent();
/* 507 */               Context context = this.actual.currentContext();
/* 508 */               Operators.onDiscardQueueWithClear(q, context, null);
/* 509 */               Operators.onDiscard(this.nextElement, context);
/* 510 */               Operators.onDiscardMultiple(sp, itFinite, context);
/* 511 */               coreSubscriber.onError(ex);
/*     */               
/*     */               return;
/*     */             } 
/* 515 */             boolean d = this.done;
/* 516 */             boolean empty = (q.isEmpty() && sp == null);
/*     */             
/* 518 */             if (d && empty) {
/* 519 */               resetCurrent();
/* 520 */               coreSubscriber.onComplete();
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 525 */           if (l1 != 0L && 
/* 526 */             r != Long.MAX_VALUE) {
/* 527 */             REQUESTED.addAndGet(this, -l1);
/*     */           }
/*     */ 
/*     */           
/* 531 */           if (sp == null) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 536 */         this.current = sp;
/* 537 */         this.currentKnownToBeFinite = itFinite;
/* 538 */         missed = WIP.addAndGet(this, -missed);
/* 539 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void drainSync() {
/* 546 */       CoreSubscriber<? super R> coreSubscriber = this.actual;
/*     */       
/* 548 */       int missed = 1;
/* 549 */       Spliterator<? extends R> sp = this.current;
/* 550 */       boolean itFinite = this.currentKnownToBeFinite;
/*     */       
/*     */       while (true) {
/* 553 */         if (sp == null) {
/*     */           T t;
/* 555 */           if (this.cancelled) {
/* 556 */             Operators.onDiscardQueueWithClear(this.queue, this.actual.currentContext(), null);
/*     */             
/*     */             return;
/*     */           } 
/* 560 */           boolean d = this.done;
/*     */ 
/*     */           
/* 563 */           Queue<T> q = this.queue;
/*     */           
/*     */           try {
/* 566 */             t = q.poll();
/* 567 */           } catch (Throwable pollEx) {
/* 568 */             resetCurrent();
/* 569 */             Operators.onDiscardQueueWithClear(q, this.actual.currentContext(), null);
/* 570 */             coreSubscriber.onError(pollEx);
/*     */             
/*     */             return;
/*     */           } 
/* 574 */           boolean empty = (t == null);
/*     */           
/* 576 */           if (d && empty) {
/* 577 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 581 */           if (!empty) {
/*     */             boolean isEmpty;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 587 */               Iterable<? extends R> iterable = this.mapper.apply(t);
/* 588 */               sp = iterable.spliterator();
/* 589 */               itFinite = FluxIterable.checkFinite(sp);
/*     */               
/* 591 */               isEmpty = itFinite ? ((sp.estimateSize() == 0L)) : (!hasNext(sp));
/*     */             }
/* 593 */             catch (Throwable exc) {
/* 594 */               resetCurrent();
/* 595 */               Context ctx = this.actual.currentContext();
/* 596 */               Throwable e_ = Operators.onNextError(t, exc, ctx, this.s);
/*     */ 
/*     */               
/* 599 */               Operators.onDiscard(t, ctx);
/* 600 */               if (e_ != null) {
/* 601 */                 coreSubscriber.onError(e_);
/*     */                 
/*     */                 return;
/*     */               } 
/*     */               continue;
/*     */             } 
/* 607 */             if (isEmpty) {
/* 608 */               sp = null;
/* 609 */               itFinite = false;
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/*     */         } 
/* 615 */         if (sp != null) {
/* 616 */           long r = this.requested;
/* 617 */           long e = 0L;
/*     */           
/* 619 */           while (e != r) {
/* 620 */             R v; boolean b; if (this.cancelled) {
/* 621 */               resetCurrent();
/* 622 */               Context context = this.actual.currentContext();
/* 623 */               Operators.onDiscardQueueWithClear(this.queue, context, null);
/* 624 */               Operators.onDiscard(this.nextElement, context);
/* 625 */               Operators.onDiscardMultiple(sp, itFinite, context);
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/*     */             try {
/* 632 */               v = Objects.requireNonNull(next(sp), "iterator returned null");
/*     */             }
/* 634 */             catch (Throwable exc) {
/* 635 */               Throwable throwable1; resetCurrent();
/* 636 */               coreSubscriber.onError(Operators.onOperatorError(this.s, throwable1, this.actual.currentContext()));
/*     */               
/*     */               return;
/*     */             } 
/* 640 */             coreSubscriber.onNext(v);
/*     */             
/* 642 */             if (this.cancelled) {
/* 643 */               resetCurrent();
/* 644 */               Context context = this.actual.currentContext();
/* 645 */               Operators.onDiscardQueueWithClear(this.queue, context, null);
/* 646 */               Operators.onDiscard(this.nextElement, context);
/* 647 */               Operators.onDiscardMultiple(sp, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 651 */             e++;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 656 */               b = hasNext(sp);
/*     */             }
/* 658 */             catch (Throwable exc) {
/* 659 */               resetCurrent();
/* 660 */               coreSubscriber.onError(Operators.onOperatorError(this.s, exc, this.actual.currentContext()));
/*     */               
/*     */               return;
/*     */             } 
/* 664 */             if (!b) {
/* 665 */               sp = null;
/* 666 */               itFinite = false;
/* 667 */               resetCurrent();
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 672 */           if (e == r) {
/* 673 */             if (this.cancelled) {
/* 674 */               resetCurrent();
/* 675 */               Context context = this.actual.currentContext();
/* 676 */               Operators.onDiscardQueueWithClear(this.queue, context, null);
/* 677 */               Operators.onDiscard(this.nextElement, context);
/* 678 */               Operators.onDiscardMultiple(sp, itFinite, context);
/*     */               
/*     */               return;
/*     */             } 
/* 682 */             boolean d = this.done;
/* 683 */             boolean empty = (this.queue.isEmpty() && sp == null);
/*     */             
/* 685 */             if (d && empty) {
/* 686 */               resetCurrent();
/* 687 */               coreSubscriber.onComplete();
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 692 */           if (e != 0L && 
/* 693 */             r != Long.MAX_VALUE) {
/* 694 */             REQUESTED.addAndGet(this, -e);
/*     */           }
/*     */ 
/*     */           
/* 698 */           if (sp == null) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 703 */         this.current = sp;
/* 704 */         this.currentKnownToBeFinite = itFinite;
/* 705 */         missed = WIP.addAndGet(this, -missed);
/* 706 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain(@Nullable T dataSignal) {
/* 713 */       if (WIP.getAndIncrement(this) != 0) {
/* 714 */         if (dataSignal != null && this.cancelled) {
/* 715 */           Operators.onDiscard(dataSignal, this.actual.currentContext());
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 720 */       if (this.fusionMode == 1) {
/* 721 */         drainSync();
/*     */       } else {
/*     */         
/* 724 */         drainAsync();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 730 */       Context context = this.actual.currentContext();
/* 731 */       Operators.onDiscard(this.nextElement, context);
/* 732 */       Operators.onDiscardMultiple(this.current, this.currentKnownToBeFinite, context);
/* 733 */       resetCurrent();
/* 734 */       Operators.onDiscardQueueWithClear(this.queue, context, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 739 */       Spliterator<? extends R> sp = this.current;
/* 740 */       if (sp != null) {
/* 741 */         return !hasNext(sp);
/*     */       }
/* 743 */       return this.queue.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R poll() {
/* 749 */       Spliterator<? extends R> sp = this.current;
/*     */       
/*     */       label23: while (true) {
/* 752 */         while (sp == null) {
/* 753 */           boolean itFinite; T v = this.queue.poll();
/* 754 */           if (v == null) {
/* 755 */             return null;
/*     */           }
/*     */ 
/*     */           
/*     */           try {
/* 760 */             Iterable<? extends R> iterable = this.mapper.apply(v);
/* 761 */             sp = iterable.spliterator();
/* 762 */             itFinite = FluxIterable.checkFinite(sp);
/*     */           }
/* 764 */           catch (Throwable error) {
/* 765 */             Operators.onDiscard(v, this.actual.currentContext());
/* 766 */             throw error;
/*     */           } 
/*     */           
/* 769 */           if (!hasNext(sp)) {
/*     */             continue;
/*     */           }
/* 772 */           this.current = sp;
/* 773 */           this.currentKnownToBeFinite = itFinite; break label23;
/*     */         } 
/* 775 */         if (!hasNext(sp)) {
/* 776 */           sp = null; continue;
/*     */         } 
/*     */         break;
/*     */       } 
/* 780 */       R r = Objects.requireNonNull(next(sp), "iterator returned null");
/*     */       
/* 782 */       if (!hasNext(sp)) {
/* 783 */         resetCurrent();
/*     */       }
/*     */       
/* 786 */       return r;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 792 */       if ((requestedMode & 0x1) != 0 && this.fusionMode == 1) {
/* 793 */         return 1;
/*     */       }
/* 795 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 800 */       return this.queue.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxFlattenIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */