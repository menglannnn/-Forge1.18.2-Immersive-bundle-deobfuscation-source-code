/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoZip<T, R>
/*     */   extends Mono<R>
/*     */   implements SourceProducer<R>
/*     */ {
/*     */   final boolean delayError;
/*     */   final Publisher<?>[] sources;
/*     */   final Iterable<? extends Publisher<?>> sourcesIterable;
/*     */   final Function<? super Object[], ? extends R> zipper;
/*     */   
/*     */   <U> MonoZip(boolean delayError, Publisher<? extends T> p1, Publisher<? extends U> p2, BiFunction<? super T, ? super U, ? extends R> zipper2) {
/*  56 */     this(delayError, new FluxZip.PairwiseZipper<>(new BiFunction[] {
/*     */             
/*  58 */             Objects.<BiFunction>requireNonNull(zipper2, "zipper2") }), (Publisher<?>[])new Publisher[] {
/*  59 */           Objects.<Publisher>requireNonNull(p1, "p1"), 
/*  60 */           Objects.<Publisher>requireNonNull(p2, "p2")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   MonoZip(boolean delayError, Function<? super Object[], ? extends R> zipper, Publisher<?>... sources) {
/*  66 */     this.delayError = delayError;
/*  67 */     this.zipper = Objects.<Function<? super Object[], ? extends R>>requireNonNull(zipper, "zipper");
/*  68 */     this.sources = (Publisher<?>[])Objects.requireNonNull(sources, "sources");
/*  69 */     this.sourcesIterable = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   MonoZip(boolean delayError, Function<? super Object[], ? extends R> zipper, Iterable<? extends Publisher<?>> sourcesIterable) {
/*  75 */     this.delayError = delayError;
/*  76 */     this.zipper = Objects.<Function<? super Object[], ? extends R>>requireNonNull(zipper, "zipper");
/*  77 */     this.sources = null;
/*  78 */     this.sourcesIterable = Objects.<Iterable<? extends Publisher<?>>>requireNonNull(sourcesIterable, "sourcesIterable");
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Mono<R> zipAdditionalSource(Publisher source, BiFunction zipper) {
/*  84 */     Publisher<?>[] arrayOfPublisher = this.sources;
/*  85 */     if (arrayOfPublisher != null && this.zipper instanceof FluxZip.PairwiseZipper) {
/*  86 */       int oldLen = arrayOfPublisher.length;
/*  87 */       Publisher[] arrayOfPublisher1 = new Publisher[oldLen + 1];
/*  88 */       System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, oldLen);
/*  89 */       arrayOfPublisher1[oldLen] = source;
/*     */ 
/*     */       
/*  92 */       Function<Object[], R> z = ((FluxZip.PairwiseZipper)this.zipper).then(zipper);
/*     */       
/*  94 */       return new MonoZip(this.delayError, z, (Publisher<?>[])arrayOfPublisher1);
/*     */     } 
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super R> actual) {
/*     */     Publisher[] arrayOfPublisher;
/* 103 */     int n = 0;
/* 104 */     if (this.sources != null) {
/* 105 */       Publisher<?>[] a = this.sources;
/* 106 */       n = a.length;
/*     */     } else {
/*     */       
/* 109 */       arrayOfPublisher = new Publisher[8];
/* 110 */       for (Publisher<?> m : this.sourcesIterable) {
/* 111 */         if (n == arrayOfPublisher.length) {
/* 112 */           Publisher[] arrayOfPublisher1 = new Publisher[n + (n >> 2)];
/* 113 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/* 114 */           arrayOfPublisher = arrayOfPublisher1;
/*     */         } 
/* 116 */         arrayOfPublisher[n++] = m;
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     if (n == 0) {
/* 121 */       Operators.complete((Subscriber<?>)actual);
/*     */       
/*     */       return;
/*     */     } 
/* 125 */     ZipCoordinator<R> parent = new ZipCoordinator<>(actual, n, this.delayError, this.zipper);
/* 126 */     actual.onSubscribe(parent);
/* 127 */     ZipInner<R>[] subs = parent.subscribers;
/* 128 */     for (int i = 0; i < n; i++) {
/* 129 */       arrayOfPublisher[i].subscribe((Subscriber)subs[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 135 */     if (key == Scannable.Attr.DELAY_ERROR) return Boolean.valueOf(this.delayError); 
/* 136 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 137 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ZipCoordinator<R>
/*     */     extends Operators.MonoSubscriber<Object, R>
/*     */   {
/*     */     final MonoZip.ZipInner<R>[] subscribers;
/*     */     
/*     */     final boolean delayError;
/*     */     
/*     */     final Function<? super Object[], ? extends R> zipper;
/*     */     
/*     */     volatile int done;
/* 151 */     static final AtomicIntegerFieldUpdater<ZipCoordinator> DONE = AtomicIntegerFieldUpdater.newUpdater(ZipCoordinator.class, "done");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ZipCoordinator(CoreSubscriber<? super R> subscriber, int n, boolean delayError, Function<? super Object[], ? extends R> zipper) {
/* 158 */       super(subscriber);
/* 159 */       this.delayError = delayError;
/* 160 */       this.zipper = zipper;
/* 161 */       this.subscribers = (MonoZip.ZipInner<R>[])new MonoZip.ZipInner[n];
/* 162 */       for (int i = 0; i < n; i++) {
/* 163 */         this.subscribers[i] = new MonoZip.ZipInner<>(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 170 */       if (key == Scannable.Attr.TERMINATED) {
/* 171 */         return Boolean.valueOf((this.done == this.subscribers.length));
/*     */       }
/* 173 */       if (key == Scannable.Attr.BUFFERED) {
/* 174 */         return Integer.valueOf(this.subscribers.length);
/*     */       }
/* 176 */       if (key == Scannable.Attr.DELAY_ERROR) {
/* 177 */         return Boolean.valueOf(this.delayError);
/*     */       }
/* 179 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 180 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 183 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 188 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean signal() {
/* 193 */       MonoZip.ZipInner<R>[] a = this.subscribers;
/* 194 */       int n = a.length;
/* 195 */       int state = DONE.incrementAndGet(this);
/* 196 */       if (state <= 0) {
/* 197 */         return false;
/*     */       }
/*     */       
/* 200 */       if (state != n) {
/* 201 */         return true;
/*     */       }
/*     */       
/* 204 */       Object[] o = new Object[n];
/* 205 */       Throwable error = null;
/* 206 */       Throwable compositeError = null;
/* 207 */       boolean hasEmpty = false;
/*     */       
/* 209 */       for (int i = 0; i < a.length; i++) {
/* 210 */         MonoZip.ZipInner<R> m = a[i];
/* 211 */         Object v = m.value;
/* 212 */         if (v != null) {
/* 213 */           o[i] = v;
/*     */         } else {
/*     */           
/* 216 */           Throwable e = m.error;
/* 217 */           if (e != null) {
/* 218 */             if (compositeError != null) {
/*     */               
/* 220 */               compositeError.addSuppressed(e);
/*     */             }
/* 222 */             else if (error != null) {
/* 223 */               compositeError = Exceptions.multiple(new Throwable[] { error, e });
/*     */             } else {
/*     */               
/* 226 */               error = e;
/*     */             } 
/*     */           } else {
/*     */             
/* 230 */             hasEmpty = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 235 */       if (compositeError != null) {
/* 236 */         this.actual.onError(compositeError);
/*     */       }
/* 238 */       else if (error != null) {
/* 239 */         this.actual.onError(error);
/*     */       }
/* 241 */       else if (hasEmpty) {
/* 242 */         this.actual.onComplete();
/*     */       } else {
/*     */         R r;
/*     */         
/*     */         try {
/* 247 */           r = Objects.requireNonNull(this.zipper.apply(o), "zipper produced a null value");
/*     */         
/*     */         }
/* 250 */         catch (Throwable t) {
/* 251 */           Operators.onDiscardMultiple(Arrays.asList(o), this.actual.currentContext());
/* 252 */           this.actual.onError(Operators.onOperatorError(null, t, o, this.actual
/*     */ 
/*     */                 
/* 255 */                 .currentContext()));
/* 256 */           return true;
/*     */         } 
/* 258 */         complete(r);
/*     */       } 
/*     */       
/* 261 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 266 */       if (DONE.getAndSet(this, -2147483648) < 0) {
/*     */         return;
/*     */       }
/*     */       
/* 270 */       super.cancel();
/* 271 */       for (MonoZip.ZipInner<R> ms : this.subscribers) {
/* 272 */         ms.cancel();
/*     */       }
/*     */     }
/*     */     
/*     */     void cancelExcept(MonoZip.ZipInner<R> source) {
/* 277 */       if (!isCancelled()) {
/* 278 */         super.cancel();
/* 279 */         for (MonoZip.ZipInner<R> ms : this.subscribers) {
/* 280 */           if (ms != source) {
/* 281 */             ms.cancel();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ZipInner<R>
/*     */     implements InnerConsumer<Object>
/*     */   {
/*     */     final MonoZip.ZipCoordinator<R> parent;
/*     */     
/*     */     volatile Subscription s;
/* 295 */     static final AtomicReferenceFieldUpdater<ZipInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ZipInner.class, Subscription.class, "s");
/*     */     
/*     */     Object value;
/*     */     
/*     */     Throwable error;
/*     */ 
/*     */     
/*     */     ZipInner(MonoZip.ZipCoordinator<R> parent) {
/* 303 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 309 */       if (key == Scannable.Attr.CANCELLED) {
/* 310 */         return Boolean.valueOf((this.s == Operators.cancelledSubscription()));
/*     */       }
/* 312 */       if (key == Scannable.Attr.PARENT) {
/* 313 */         return this.s;
/*     */       }
/* 315 */       if (key == Scannable.Attr.ACTUAL) {
/* 316 */         return this.parent;
/*     */       }
/* 318 */       if (key == Scannable.Attr.ERROR) {
/* 319 */         return this.error;
/*     */       }
/* 321 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 322 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/*     */       
/* 325 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 330 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 335 */       if (Operators.setOnce(S, this, s)) {
/* 336 */         s.request(Long.MAX_VALUE);
/*     */       } else {
/*     */         
/* 339 */         s.cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Object t) {
/* 345 */       if (this.value == null) {
/* 346 */         this.value = t;
/* 347 */         if (!this.parent.signal()) {
/* 348 */           Operators.onDiscard(t, this.parent.actual.currentContext());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 355 */       this.error = t;
/* 356 */       if (this.parent.delayError) {
/* 357 */         this.parent.signal();
/*     */       } else {
/*     */         
/* 360 */         int n = this.parent.subscribers.length;
/* 361 */         if (MonoZip.ZipCoordinator.DONE.getAndSet(this.parent, n) != n) {
/* 362 */           this.parent.cancelExcept(this);
/* 363 */           this.parent.actual.onError(t);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 370 */       if (this.value == null) {
/* 371 */         if (this.parent.delayError) {
/* 372 */           this.parent.signal();
/*     */         } else {
/*     */           
/* 375 */           int n = this.parent.subscribers.length;
/* 376 */           if (MonoZip.ZipCoordinator.DONE.getAndSet(this.parent, n) != n) {
/* 377 */             this.parent.cancelExcept(this);
/* 378 */             this.parent.actual.onComplete();
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     void cancel() {
/* 385 */       Operators.terminate(S, this);
/* 386 */       Object v = this.value;
/* 387 */       if (v != null)
/* 388 */         Operators.onDiscard(v, currentContext()); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoZip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */