/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.AbstractQueue;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMaterialize<T>
/*     */   extends InternalFluxOperator<T, Signal<T>>
/*     */ {
/*     */   FluxMaterialize(Flux<T> source) {
/*  35 */     super(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Signal<T>> actual) {
/*  40 */     return new MaterializeSubscriber<>(actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  45 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  46 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MaterializeSubscriber<T>
/*     */     extends AbstractQueue<Signal<T>>
/*     */     implements InnerOperator<T, Signal<T>>, BooleanSupplier
/*     */   {
/*     */     final CoreSubscriber<? super Signal<T>> actual;
/*     */     
/*     */     final Context cachedContext;
/*     */     
/*     */     Signal<T> terminalSignal;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile long requested;
/*  63 */     static final AtomicLongFieldUpdater<MaterializeSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(MaterializeSubscriber.class, "requested");
/*     */     
/*     */     long produced;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     MaterializeSubscriber(CoreSubscriber<? super Signal<T>> subscriber) {
/*  70 */       this.actual = subscriber;
/*  71 */       this.cachedContext = this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/*  76 */       return this.cachedContext;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  82 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  83 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.terminalSignal != null)); 
/*  84 */       if (key == Scannable.Attr.ERROR) return (this.terminalSignal != null) ? this.terminalSignal.getThrowable() : null; 
/*  85 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(getAsBoolean()); 
/*  86 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/*  87 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(size()); 
/*  88 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  90 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Signal<T>> actual() {
/*  95 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 100 */       if (Operators.validate(this.s, s)) {
/* 101 */         this.s = s;
/*     */         
/* 103 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T ev) {
/* 109 */       if (this.terminalSignal != null) {
/* 110 */         Operators.onNextDropped(ev, this.cachedContext);
/*     */         return;
/*     */       } 
/* 113 */       this.produced++;
/* 114 */       this.actual.onNext(Signal.next(ev, this.cachedContext));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable ev) {
/* 119 */       if (this.terminalSignal != null) {
/* 120 */         Operators.onErrorDropped(ev, this.cachedContext);
/*     */         return;
/*     */       } 
/* 123 */       this.terminalSignal = Signal.error(ev, this.cachedContext);
/* 124 */       long p = this.produced;
/* 125 */       if (p != 0L) {
/* 126 */         Operators.addCap(REQUESTED, this, -p);
/*     */       }
/* 128 */       DrainUtils.postComplete(this.actual, this, REQUESTED, this, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 133 */       if (this.terminalSignal != null) {
/*     */         return;
/*     */       }
/* 136 */       this.terminalSignal = Signal.complete(this.cachedContext);
/* 137 */       long p = this.produced;
/* 138 */       if (p != 0L) {
/* 139 */         Operators.addCap(REQUESTED, this, -p);
/*     */       }
/* 141 */       DrainUtils.postComplete(this.actual, this, REQUESTED, this, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 146 */       if (Operators.validate(n) && 
/* 147 */         !DrainUtils.postCompleteRequest(n, (Subscriber<? super Signal<T>>)this.actual, this, REQUESTED, this, this)) {
/* 148 */         this.s.request(n);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 155 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 158 */       this.cancelled = true;
/* 159 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getAsBoolean() {
/* 164 */       return this.cancelled;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean offer(Signal<T> e) {
/* 169 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Signal<T> poll() {
/* 176 */       Signal<T> v = this.terminalSignal;
/* 177 */       if (v != null && v != empty) {
/* 178 */         this.terminalSignal = empty;
/* 179 */         return v;
/*     */       } 
/* 181 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Signal<T> peek() {
/* 187 */       return (empty == this.terminalSignal) ? null : this.terminalSignal;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Signal<T>> iterator() {
/* 192 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 197 */       return (this.terminalSignal == null || this.terminalSignal == empty) ? 0 : 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 202 */       return "MaterializeSubscriber";
/*     */     }
/*     */     
/* 205 */     static final Signal empty = new ImmutableSignal((ContextView)Context.empty(), SignalType.ON_NEXT, null, null, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxMaterialize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */