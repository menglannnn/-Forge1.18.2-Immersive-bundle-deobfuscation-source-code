/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoFlatMapMany<T, R>
/*     */   extends FluxFromMonoOperator<T, R>
/*     */ {
/*     */   final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */   
/*     */   MonoFlatMapMany(Mono<? extends T> source, Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  40 */     super(source);
/*  41 */     this.mapper = mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  49 */     if (FluxFlatMap.trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, this.mapper, false, false)) {
/*  50 */       return null;
/*     */     }
/*  52 */     return new FlatMapManyMain<>(actual, this.mapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  57 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  58 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FlatMapManyMain<T, R>
/*     */     implements InnerOperator<T, R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final Function<? super T, ? extends Publisher<? extends R>> mapper;
/*     */     
/*     */     Subscription main;
/*     */     
/*     */     volatile Subscription inner;
/*  72 */     static final AtomicReferenceFieldUpdater<FlatMapManyMain, Subscription> INNER = AtomicReferenceFieldUpdater.newUpdater(FlatMapManyMain.class, Subscription.class, "inner");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/*  79 */     static final AtomicLongFieldUpdater<FlatMapManyMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(FlatMapManyMain.class, "requested");
/*     */     
/*     */     boolean hasValue;
/*     */ 
/*     */     
/*     */     FlatMapManyMain(CoreSubscriber<? super R> actual, Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  85 */       this.actual = actual;
/*  86 */       this.mapper = mapper;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  92 */       if (key == Scannable.Attr.PARENT) return this.main; 
/*  93 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  95 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 100 */       return Stream.of(Scannable.from(this.inner));
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 105 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 110 */       Subscription a = this.inner;
/* 111 */       if (a != null) {
/* 112 */         a.request(n);
/*     */       
/*     */       }
/* 115 */       else if (Operators.validate(n)) {
/* 116 */         Operators.addCap(REQUESTED, this, n);
/* 117 */         a = this.inner;
/* 118 */         if (a != null) {
/* 119 */           n = REQUESTED.getAndSet(this, 0L);
/* 120 */           if (n != 0L) {
/* 121 */             a.request(n);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 130 */       this.main.cancel();
/* 131 */       Operators.terminate(INNER, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 136 */       if (Operators.validate(this.main, s)) {
/* 137 */         this.main = s;
/*     */         
/* 139 */         this.actual.onSubscribe(this);
/*     */         
/* 141 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */     
/*     */     void onSubscribeInner(Subscription s) {
/* 146 */       if (Operators.setOnce(INNER, this, s)) {
/*     */         
/* 148 */         long r = REQUESTED.getAndSet(this, 0L);
/* 149 */         if (r != 0L) {
/* 150 */           s.request(r);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*     */       Publisher<? extends R> p;
/* 158 */       this.hasValue = true;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 163 */         p = Objects.<Publisher<? extends R>>requireNonNull(this.mapper.apply(t), "The mapper returned a null Publisher.");
/*     */       
/*     */       }
/* 166 */       catch (Throwable ex) {
/*     */         
/* 168 */         this.actual.onError(Operators.onOperatorError(this, ex, t, this.actual
/* 169 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 173 */       if (p instanceof Callable) {
/*     */         R v;
/*     */         
/*     */         try {
/* 177 */           v = ((Callable)p).call();
/*     */         }
/* 179 */         catch (Throwable ex) {
/* 180 */           this.actual.onError(Operators.onOperatorError(this, ex, t, this.actual
/* 181 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 185 */         if (v == null) {
/* 186 */           this.actual.onComplete();
/*     */         } else {
/*     */           
/* 189 */           onSubscribeInner(Operators.scalarSubscription(this.actual, v));
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 195 */       p.subscribe((Subscriber)new MonoFlatMapMany.FlatMapManyInner<>(this, this.actual));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 200 */       if (this.hasValue) {
/* 201 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 204 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 209 */       if (!this.hasValue) {
/* 210 */         this.actual.onComplete();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FlatMapManyInner<R>
/*     */     implements InnerConsumer<R>
/*     */   {
/*     */     final MonoFlatMapMany.FlatMapManyMain<?, R> parent;
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     FlatMapManyInner(MonoFlatMapMany.FlatMapManyMain<?, R> parent, CoreSubscriber<? super R> actual) {
/* 223 */       this.parent = parent;
/* 224 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 229 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 235 */       if (key == Scannable.Attr.PARENT) return this.parent.inner; 
/* 236 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 237 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.parent.requested); 
/* 238 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 240 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 245 */       this.parent.onSubscribeInner(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(R t) {
/* 250 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 255 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 260 */       this.actual.onComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoFlatMapMany.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */