/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.LongConsumer;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface MonoSink<T>
/*    */ {
/*    */   void success();
/*    */   
/*    */   void success(@Nullable T paramT);
/*    */   
/*    */   void error(Throwable paramThrowable);
/*    */   
/*    */   @Deprecated
/*    */   Context currentContext();
/*    */   
/*    */   default ContextView contextView() {
/* 87 */     return (ContextView)currentContext();
/*    */   }
/*    */   
/*    */   MonoSink<T> onRequest(LongConsumer paramLongConsumer);
/*    */   
/*    */   MonoSink<T> onCancel(Disposable paramDisposable);
/*    */   
/*    */   MonoSink<T> onDispose(Disposable paramDisposable);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoSink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */