/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxElapsed<T>
/*     */   extends InternalFluxOperator<T, Tuple2<Long, T>>
/*     */   implements Fuseable
/*     */ {
/*     */   final Scheduler scheduler;
/*     */   
/*     */   FluxElapsed(Flux<T> source, Scheduler scheduler) {
/*  37 */     super(source);
/*  38 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Tuple2<Long, T>> actual) {
/*  43 */     return new ElapsedSubscriber<>(actual, this.scheduler);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  48 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  49 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  51 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ElapsedSubscriber<T>
/*     */     implements InnerOperator<T, Tuple2<Long, T>>, Fuseable.QueueSubscription<Tuple2<Long, T>>
/*     */   {
/*     */     final CoreSubscriber<? super Tuple2<Long, T>> actual;
/*     */     
/*     */     final Scheduler scheduler;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     long lastTime;
/*     */     
/*     */     ElapsedSubscriber(CoreSubscriber<? super Tuple2<Long, T>> actual, Scheduler scheduler) {
/*  68 */       this.actual = actual;
/*  69 */       this.scheduler = scheduler;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  75 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  76 */       if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  77 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  79 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  84 */       if (Operators.validate(this.s, s)) {
/*  85 */         this.lastTime = this.scheduler.now(TimeUnit.MILLISECONDS);
/*  86 */         this.s = s;
/*  87 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super Tuple2<Long, T>> actual() {
/*  93 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  98 */       if (t == null) {
/*  99 */         this.actual.onNext(null);
/*     */         return;
/*     */       } 
/* 102 */       this.actual.onNext(snapshot(t));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 107 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 112 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 117 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 122 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 127 */       Fuseable.QueueSubscription<T> qs = Operators.as(this.s);
/* 128 */       if (qs != null) {
/* 129 */         this.qs = qs;
/* 130 */         return qs.requestFusion(requestedMode);
/*     */       } 
/* 132 */       return 0;
/*     */     }
/*     */     
/*     */     Tuple2<Long, T> snapshot(T data) {
/* 136 */       long now = this.scheduler.now(TimeUnit.MILLISECONDS);
/* 137 */       long last = this.lastTime;
/* 138 */       this.lastTime = now;
/* 139 */       long delta = now - last;
/* 140 */       return Tuples.of(Long.valueOf(delta), data);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Tuple2<Long, T> poll() {
/* 146 */       T data = (T)this.qs.poll();
/* 147 */       if (data != null) {
/* 148 */         return snapshot(data);
/*     */       }
/* 150 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 155 */       return this.qs.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 160 */       return this.qs.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 165 */       this.qs.clear();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxElapsed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */