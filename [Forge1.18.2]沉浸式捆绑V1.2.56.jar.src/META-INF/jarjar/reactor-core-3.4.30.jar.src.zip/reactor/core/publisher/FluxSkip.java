/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSkip<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final long n;
/*     */   
/*     */   FluxSkip(Flux<? extends T> source, long n) {
/*  36 */     super(source);
/*  37 */     if (n < 0L) {
/*  38 */       throw new IllegalArgumentException("n >= 0 required but it was " + n);
/*     */     }
/*  40 */     this.n = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  45 */     return new SkipSubscriber<>(actual, this.n);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  50 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  51 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SkipSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     long remaining;
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     SkipSubscriber(CoreSubscriber<? super T> actual, long n) {
/*  68 */       this.actual = actual;
/*  69 */       this.ctx = actual.currentContext();
/*  70 */       this.remaining = n;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  75 */       if (Operators.validate(this.s, s)) {
/*  76 */         this.s = s;
/*  77 */         long n = this.remaining;
/*  78 */         this.actual.onSubscribe(this);
/*  79 */         s.request(n);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  85 */       long r = this.remaining;
/*  86 */       if (r == 0L) {
/*  87 */         this.actual.onNext(t);
/*     */       } else {
/*     */         
/*  90 */         Operators.onDiscard(t, this.ctx);
/*  91 */         this.remaining = r - 1L;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*  97 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 102 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 108 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 109 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 111 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 116 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 121 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 126 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxSkip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */