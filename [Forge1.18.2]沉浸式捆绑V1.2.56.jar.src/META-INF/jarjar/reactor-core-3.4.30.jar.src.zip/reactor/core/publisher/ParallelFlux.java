/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.LongConsumer;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.logging.Level;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CorePublisher;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Disposables;
/*      */ import reactor.core.scheduler.Scheduler;
/*      */ import reactor.core.scheduler.Schedulers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.concurrent.Queues;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ParallelFlux<T>
/*      */   implements CorePublisher<T>
/*      */ {
/*      */   public static <T> ParallelFlux<T> from(Publisher<? extends T> source) {
/*   89 */     return from(source, Schedulers.DEFAULT_POOL_SIZE, Queues.SMALL_BUFFER_SIZE, 
/*   90 */         Queues.small());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ParallelFlux<T> from(Publisher<? extends T> source, int parallelism) {
/*  105 */     return from(source, parallelism, Queues.SMALL_BUFFER_SIZE, 
/*      */         
/*  107 */         Queues.small());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ParallelFlux<T> from(Publisher<? extends T> source, int parallelism, int prefetch, Supplier<Queue<T>> queueSupplier) {
/*  128 */     Objects.requireNonNull(queueSupplier, "queueSupplier");
/*  129 */     Objects.requireNonNull(source, "source");
/*      */     
/*  131 */     return onAssembly(new ParallelSource<>(source, parallelism, prefetch, queueSupplier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> ParallelFlux<T> from(Publisher<T>... publishers) {
/*  147 */     return onAssembly(new ParallelArraySource<>(publishers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> U as(Function<? super ParallelFlux<T>, U> converter) {
/*  160 */     return converter.apply(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> checkpoint() {
/*  179 */     FluxOnAssembly.AssemblySnapshot stacktrace = new FluxOnAssembly.CheckpointHeavySnapshot(null, Traces.callSiteSupplierFactory.get());
/*  180 */     return new ParallelFluxOnAssembly<>(this, stacktrace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> checkpoint(String description) {
/*  205 */     return new ParallelFluxOnAssembly<>(this, new FluxOnAssembly.CheckpointLightSnapshot(description));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> checkpoint(String description, boolean forceStackTrace) {
/*      */     FluxOnAssembly.AssemblySnapshot stacktrace;
/*  241 */     if (!forceStackTrace) {
/*  242 */       stacktrace = new FluxOnAssembly.CheckpointLightSnapshot(description);
/*      */     } else {
/*      */       
/*  245 */       stacktrace = new FluxOnAssembly.CheckpointHeavySnapshot(description, Traces.callSiteSupplierFactory.get());
/*      */     } 
/*      */     
/*  248 */     return new ParallelFluxOnAssembly<>(this, stacktrace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <C> ParallelFlux<C> collect(Supplier<? extends C> collectionSupplier, BiConsumer<? super C, ? super T> collector) {
/*  265 */     return onAssembly(new ParallelCollect<>(this, collectionSupplier, collector));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<List<T>> collectSortedList(Comparator<? super T> comparator) {
/*  279 */     return collectSortedList(comparator, 16);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<List<T>> collectSortedList(Comparator<? super T> comparator, int capacityHint) {
/*  295 */     int ch = capacityHint / parallelism() + 1;
/*      */     
/*  297 */     ParallelFlux<List<T>> railReduced = reduce(() -> new ArrayList(ch), (a, b) -> {
/*      */           a.add(b);
/*      */           return a;
/*      */         });
/*  301 */     ParallelFlux<List<T>> railSorted = railReduced.map(list -> {
/*      */           list.sort(comparator);
/*      */           
/*      */           return list;
/*      */         });
/*  306 */     Mono<List<T>> merged = railSorted.reduce((a, b) -> sortedMerger(a, b, comparator));
/*      */     
/*  308 */     return merged;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> ParallelFlux<R> concatMap(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  322 */     return concatMap(mapper, 2, FluxConcatMap.ErrorMode.IMMEDIATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> ParallelFlux<R> concatMap(Function<? super T, ? extends Publisher<? extends R>> mapper, int prefetch) {
/*  338 */     return concatMap(mapper, prefetch, FluxConcatMap.ErrorMode.IMMEDIATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> ParallelFlux<R> concatMapDelayError(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  353 */     return concatMap(mapper, 2, FluxConcatMap.ErrorMode.END);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doAfterTerminate(Runnable afterTerminate) {
/*  364 */     Objects.requireNonNull(afterTerminate, "afterTerminate");
/*  365 */     return doOnSignal(this, null, null, null, null, afterTerminate, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doOnCancel(Runnable onCancel) {
/*  376 */     Objects.requireNonNull(onCancel, "onCancel");
/*  377 */     return doOnSignal(this, null, null, null, null, null, null, null, onCancel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doOnComplete(Runnable onComplete) {
/*  388 */     Objects.requireNonNull(onComplete, "onComplete");
/*  389 */     return doOnSignal(this, null, null, null, onComplete, null, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doOnEach(Consumer<? super Signal<T>> signalConsumer) {
/*  416 */     Objects.requireNonNull(signalConsumer, "signalConsumer");
/*  417 */     return onAssembly(new ParallelDoOnEach<>(this, (ctx, v) -> signalConsumer.accept(Signal.next(v, ctx)), (ctx, e) -> signalConsumer.accept(Signal.error(e, ctx)), ctx -> signalConsumer.accept(Signal.complete(ctx))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doOnError(Consumer<? super Throwable> onError) {
/*  433 */     Objects.requireNonNull(onError, "onError");
/*  434 */     return doOnSignal(this, null, null, onError, null, null, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doOnSubscribe(Consumer<? super Subscription> onSubscribe) {
/*  450 */     Objects.requireNonNull(onSubscribe, "onSubscribe");
/*  451 */     return doOnSignal(this, null, null, null, null, null, onSubscribe, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doOnNext(Consumer<? super T> onNext) {
/*  462 */     Objects.requireNonNull(onNext, "onNext");
/*  463 */     return doOnSignal(this, onNext, null, null, null, null, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doOnRequest(LongConsumer onRequest) {
/*  475 */     Objects.requireNonNull(onRequest, "onRequest");
/*  476 */     return doOnSignal(this, null, null, null, null, null, null, onRequest, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> doOnTerminate(Runnable onTerminate) {
/*  486 */     Objects.requireNonNull(onTerminate, "onTerminate");
/*  487 */     return doOnSignal(this, null, null, e -> onTerminate.run(), onTerminate, null, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> filter(Predicate<? super T> predicate) {
/*  509 */     Objects.requireNonNull(predicate, "predicate");
/*  510 */     return onAssembly(new ParallelFilter<>(this, predicate));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> ParallelFlux<R> flatMap(Function<? super T, ? extends Publisher<? extends R>> mapper) {
/*  525 */     return flatMap(mapper, false, 2147483647, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> ParallelFlux<R> flatMap(Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError) {
/*  544 */     return flatMap(mapper, delayError, 2147483647, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> ParallelFlux<R> flatMap(Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency) {
/*  567 */     return flatMap(mapper, delayError, maxConcurrency, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> ParallelFlux<R> flatMap(Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayError, int maxConcurrency, int prefetch) {
/*  591 */     return onAssembly(new ParallelFlatMap<>(this, mapper, delayError, maxConcurrency, 
/*      */ 
/*      */ 
/*      */           
/*  595 */           Queues.get(maxConcurrency), prefetch, 
/*  596 */           Queues.get(prefetch)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<GroupedFlux<Integer, T>> groups() {
/*  609 */     return Flux.onAssembly(new ParallelGroup<>(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> hide() {
/*  619 */     return new ParallelFluxHide<>(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> log() {
/*  635 */     return log(null, Level.INFO, new SignalType[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> log(@Nullable String category) {
/*  653 */     return log(category, Level.INFO, new SignalType[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> log(@Nullable String category, Level level, SignalType... options) {
/*  683 */     return log(category, level, false, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> log(@Nullable String category, Level level, boolean showOperatorLine, SignalType... options) {
/*  716 */     return onAssembly(new ParallelLog<>(this, new SignalLogger<>(this, category, level, showOperatorLine, options)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> ParallelFlux<U> map(Function<? super T, ? extends U> mapper) {
/*  731 */     Objects.requireNonNull(mapper, "mapper");
/*  732 */     return onAssembly(new ParallelMap<>(this, mapper));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> name(String name) {
/*  743 */     return ParallelFluxName.createOrAppend(this, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> ordered(Comparator<? super T> comparator) {
/*  759 */     return ordered(comparator, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> ordered(Comparator<? super T> comparator, int prefetch) {
/*  774 */     return new ParallelMergeOrdered<>(this, prefetch, comparator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<T> reduce(BiFunction<T, T, T> reducer) {
/*  797 */     Objects.requireNonNull(reducer, "reducer");
/*  798 */     return Mono.onAssembly(new ParallelMergeReduce<>(this, reducer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <R> ParallelFlux<R> reduce(Supplier<R> initialSupplier, BiFunction<R, ? super T, R> reducer) {
/*  818 */     Objects.requireNonNull(initialSupplier, "initialSupplier");
/*  819 */     Objects.requireNonNull(reducer, "reducer");
/*  820 */     return onAssembly(new ParallelReduceSeed<>(this, initialSupplier, reducer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> runOn(Scheduler scheduler) {
/*  845 */     return runOn(scheduler, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> runOn(Scheduler scheduler, int prefetch) {
/*  871 */     Objects.requireNonNull(scheduler, "scheduler");
/*  872 */     return onAssembly(new ParallelRunOn<>(this, scheduler, prefetch, 
/*      */ 
/*      */           
/*  875 */           Queues.get(prefetch)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> sequential() {
/*  891 */     return sequential(Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> sequential(int prefetch) {
/*  904 */     return Flux.onAssembly(new ParallelMergeSequential<>(this, prefetch, 
/*      */           
/*  906 */           Queues.get(prefetch)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> sorted(Comparator<? super T> comparator) {
/*  920 */     return sorted(comparator, 16);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Flux<T> sorted(Comparator<? super T> comparator, int capacityHint) {
/*  935 */     int ch = capacityHint / parallelism() + 1;
/*  936 */     ParallelFlux<List<T>> railReduced = reduce(() -> new ArrayList(ch), (a, b) -> {
/*      */           a.add(b);
/*      */           return a;
/*      */         });
/*  940 */     ParallelFlux<List<T>> railSorted = railReduced.map(list -> {
/*      */           list.sort(comparator);
/*      */           
/*      */           return list;
/*      */         });
/*  945 */     return Flux.onAssembly(new ParallelMergeSort<>(railSorted, comparator));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe() {
/*  962 */     return subscribe(null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(Consumer<? super T> onNext) {
/*  972 */     return subscribe(onNext, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> onNext, Consumer<? super Throwable> onError) {
/*  984 */     return subscribe(onNext, onError, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> onNext, @Nullable Consumer<? super Throwable> onError, @Nullable Runnable onComplete) {
/*  999 */     return subscribe(onNext, onError, onComplete, null, (Context)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void subscribe(CoreSubscriber<? super T> s) {
/* 1006 */     FluxHide.SuppressFuseableSubscriber<T> subscriber = new FluxHide.SuppressFuseableSubscriber<>(Operators.toCoreSubscriber((Subscriber<? super T>)s));
/*      */     
/* 1008 */     sequential().subscribe(Operators.toCoreSubscriber((Subscriber<? super T>)subscriber));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> onNext, @Nullable Consumer<? super Throwable> onError, @Nullable Runnable onComplete, @Nullable Consumer<? super Subscription> onSubscribe) {
/* 1026 */     return subscribe(onNext, onError, onComplete, onSubscribe, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Disposable subscribe(@Nullable Consumer<? super T> onNext, @Nullable Consumer<? super Throwable> onError, @Nullable Runnable onComplete, @Nullable Context initialContext) {
/* 1044 */     return subscribe(onNext, onError, onComplete, null, initialContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Disposable subscribe(@Nullable Consumer<? super T> onNext, @Nullable Consumer<? super Throwable> onError, @Nullable Runnable onComplete, @Nullable Consumer<? super Subscription> onSubscribe, @Nullable Context initialContext) {
/* 1053 */     CorePublisher<T> publisher = Operators.onLastAssembly(this);
/* 1054 */     if (publisher instanceof ParallelFlux) {
/*      */       
/* 1056 */       LambdaSubscriber[] arrayOfLambdaSubscriber = new LambdaSubscriber[parallelism()];
/*      */       
/* 1058 */       int i = 0;
/* 1059 */       while (i < arrayOfLambdaSubscriber.length) {
/* 1060 */         arrayOfLambdaSubscriber[i++] = new LambdaSubscriber<>(onNext, onError, onComplete, onSubscribe, initialContext);
/*      */       }
/*      */ 
/*      */       
/* 1064 */       ((ParallelFlux)publisher).subscribe((CoreSubscriber[])arrayOfLambdaSubscriber);
/*      */       
/* 1066 */       return (Disposable)Disposables.composite((Disposable[])arrayOfLambdaSubscriber);
/*      */     } 
/*      */     
/* 1069 */     LambdaSubscriber<? super T> subscriber = new LambdaSubscriber<>(onNext, onError, onComplete, onSubscribe, initialContext);
/*      */ 
/*      */     
/* 1072 */     publisher.subscribe(Operators.toCoreSubscriber((Subscriber<?>)new FluxHide.SuppressFuseableSubscriber<>(subscriber)));
/*      */     
/* 1074 */     return subscriber;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void subscribe(Subscriber<? super T> s) {
/* 1088 */     FluxHide.SuppressFuseableSubscriber<T> subscriber = new FluxHide.SuppressFuseableSubscriber<>(Operators.toCoreSubscriber(s));
/*      */     
/* 1090 */     Operators.<T>onLastAssembly(sequential()).subscribe(Operators.toCoreSubscriber((Subscriber<? super T>)subscriber));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParallelFlux<T> tag(String key, String value) {
/* 1105 */     return ParallelFluxName.createOrAppend(this, key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Mono<Void> then() {
/* 1117 */     return Mono.onAssembly(new ParallelThen(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> ParallelFlux<U> transform(Function<? super ParallelFlux<T>, ParallelFlux<U>> composer) {
/* 1131 */     return onAssembly(as(composer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <U> ParallelFlux<U> transformGroups(Function<? super GroupedFlux<Integer, T>, ? extends Publisher<? extends U>> composer) {
/* 1150 */     if (getPrefetch() > -1) {
/* 1151 */       return from((Publisher)groups().flatMap(composer::apply), 
/* 1152 */           parallelism(), getPrefetch(), 
/* 1153 */           Queues.small());
/*      */     }
/*      */     
/* 1156 */     return from((Publisher)groups().flatMap(composer::apply), parallelism());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1162 */     return getClass().getSimpleName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean validate(Subscriber<?>[] subscribers) {
/* 1174 */     int p = parallelism();
/* 1175 */     if (subscribers.length != p) {
/* 1176 */       IllegalArgumentException iae = new IllegalArgumentException("parallelism = " + p + ", subscribers = " + subscribers.length);
/*      */       
/* 1178 */       for (Subscriber<?> s : subscribers) {
/* 1179 */         Operators.error(s, iae);
/*      */       }
/* 1181 */       return false;
/*      */     } 
/* 1183 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final <R> ParallelFlux<R> concatMap(Function<? super T, ? extends Publisher<? extends R>> mapper, int prefetch, FluxConcatMap.ErrorMode errorMode) {
/* 1201 */     return onAssembly(new ParallelConcatMap<>(this, mapper, 
/*      */           
/* 1203 */           Queues.get(prefetch), prefetch, errorMode));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final <R> ParallelFlux<R> concatMapDelayError(Function<? super T, ? extends Publisher<? extends R>> mapper, boolean delayUntilEnd, int prefetch) {
/* 1224 */     return concatMap(mapper, prefetch, delayUntilEnd ? FluxConcatMap.ErrorMode.END : FluxConcatMap.ErrorMode.BOUNDARY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final <R> ParallelFlux<R> concatMapDelayError(Function<? super T, ? extends Publisher<? extends R>> mapper, int prefetch) {
/* 1240 */     return concatMap(mapper, prefetch, FluxConcatMap.ErrorMode.END);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPrefetch() {
/* 1249 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static <T> ParallelFlux<T> onAssembly(ParallelFlux<T> source) {
/* 1264 */     Function<Publisher, Publisher> hook = Hooks.onEachOperatorHook;
/* 1265 */     if (hook != null) {
/* 1266 */       source = (ParallelFlux<T>)hook.apply(source);
/*      */     }
/* 1268 */     if (Hooks.GLOBAL_TRACE) {
/* 1269 */       FluxOnAssembly.AssemblySnapshot stacktrace = new FluxOnAssembly.AssemblySnapshot(null, Traces.callSiteSupplierFactory.get());
/* 1270 */       source = (ParallelFlux<T>)Hooks.addAssemblyInfo(source, stacktrace);
/*      */     } 
/* 1272 */     return source;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> ParallelFlux<T> doOnSignal(ParallelFlux<T> source, @Nullable Consumer<? super T> onNext, @Nullable Consumer<? super T> onAfterNext, @Nullable Consumer<? super Throwable> onError, @Nullable Runnable onComplete, @Nullable Runnable onAfterTerminate, @Nullable Consumer<? super Subscription> onSubscribe, @Nullable LongConsumer onRequest, @Nullable Runnable onCancel) {
/* 1285 */     return onAssembly(new ParallelPeek<>(source, onNext, onAfterNext, onError, onComplete, onAfterTerminate, onSubscribe, onRequest, onCancel));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final <T> List<T> sortedMerger(List<T> a, List<T> b, Comparator<? super T> comparator) {
/* 1297 */     int n = a.size() + b.size();
/* 1298 */     if (n == 0) {
/* 1299 */       return new ArrayList<>();
/*      */     }
/* 1301 */     List<T> both = new ArrayList<>(n);
/*      */     
/* 1303 */     Iterator<T> at = a.iterator();
/* 1304 */     Iterator<T> bt = b.iterator();
/*      */     
/* 1306 */     E e1 = at.hasNext() ? (E)at.next() : null;
/* 1307 */     E e2 = bt.hasNext() ? (E)bt.next() : null;
/*      */     
/* 1309 */     while (e1 != null && e2 != null) {
/* 1310 */       if (comparator.compare((T)e1, (T)e2) < 0) {
/* 1311 */         both.add((T)e1);
/* 1312 */         e1 = at.hasNext() ? (E)at.next() : null;
/*      */         continue;
/*      */       } 
/* 1315 */       both.add((T)e2);
/* 1316 */       e2 = bt.hasNext() ? (E)bt.next() : null;
/*      */     } 
/*      */ 
/*      */     
/* 1320 */     if (e1 != null) {
/* 1321 */       both.add((T)e1);
/* 1322 */       while (at.hasNext()) {
/* 1323 */         both.add(at.next());
/*      */       }
/*      */     }
/* 1326 */     else if (e2 != null) {
/* 1327 */       both.add((T)e2);
/* 1328 */       while (bt.hasNext()) {
/* 1329 */         both.add(bt.next());
/*      */       }
/*      */     } 
/*      */     
/* 1333 */     return both;
/*      */   }
/*      */   
/*      */   public abstract int parallelism();
/*      */   
/*      */   public abstract void subscribe(CoreSubscriber<? super T>[] paramArrayOfCoreSubscriber);
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ParallelFlux.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */