/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SinkManySerialized<T>
/*     */   extends SinksSpecs.AbstractSerializedSink
/*     */   implements InternalManySink<T>, Scannable
/*     */ {
/*     */   final Sinks.Many<T> sink;
/*     */   final ContextHolder contextHolder;
/*     */   
/*     */   SinkManySerialized(Sinks.Many<T> sink, ContextHolder contextHolder) {
/*  33 */     this.sink = sink;
/*  34 */     this.contextHolder = contextHolder;
/*     */   }
/*     */ 
/*     */   
/*     */   public int currentSubscriberCount() {
/*  39 */     return this.sink.currentSubscriberCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<T> asFlux() {
/*  44 */     return this.sink.asFlux();
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/*  49 */     return this.contextHolder.currentContext();
/*     */   }
/*     */   
/*     */   public boolean isCancelled() {
/*  53 */     return ((Boolean)Scannable.from(this.sink).scanOrDefault(Scannable.Attr.CANCELLED, Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Sinks.EmitResult tryEmitComplete() {
/*  58 */     Thread currentThread = Thread.currentThread();
/*  59 */     if (!tryAcquire(currentThread)) {
/*  60 */       return Sinks.EmitResult.FAIL_NON_SERIALIZED;
/*     */     }
/*     */     
/*     */     try {
/*  64 */       return this.sink.tryEmitComplete();
/*     */     } finally {
/*  66 */       if (WIP.decrementAndGet(this) == 0) {
/*  67 */         LOCKED_AT.compareAndSet(this, currentThread, null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final Sinks.EmitResult tryEmitError(Throwable t) {
/*  74 */     Objects.requireNonNull(t, "t is null in sink.error(t)");
/*     */     
/*  76 */     Thread currentThread = Thread.currentThread();
/*  77 */     if (!tryAcquire(currentThread)) {
/*  78 */       return Sinks.EmitResult.FAIL_NON_SERIALIZED;
/*     */     }
/*     */     
/*     */     try {
/*  82 */       return this.sink.tryEmitError(t);
/*     */     } finally {
/*  84 */       if (WIP.decrementAndGet(this) == 0) {
/*  85 */         LOCKED_AT.compareAndSet(this, currentThread, null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final Sinks.EmitResult tryEmitNext(T t) {
/*  92 */     Objects.requireNonNull(t, "t is null in sink.next(t)");
/*     */     
/*  94 */     Thread currentThread = Thread.currentThread();
/*  95 */     if (!tryAcquire(currentThread)) {
/*  96 */       return Sinks.EmitResult.FAIL_NON_SERIALIZED;
/*     */     }
/*     */     
/*     */     try {
/* 100 */       return this.sink.tryEmitNext(t);
/*     */     } finally {
/* 102 */       if (WIP.decrementAndGet(this) == 0) {
/* 103 */         LOCKED_AT.compareAndSet(this, currentThread, null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 111 */     return this.sink.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 116 */     return Scannable.from(this.sink).inners();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     return this.sink.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\SinkManySerialized.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */