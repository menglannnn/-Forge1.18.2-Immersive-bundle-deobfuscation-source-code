/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxFilterFuseable<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */   implements Fuseable
/*     */ {
/*     */   final Predicate<? super T> predicate;
/*     */   
/*     */   FluxFilterFuseable(Flux<? extends T> source, Predicate<? super T> predicate) {
/*  41 */     super(source);
/*  42 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  47 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  48 */       return new FilterFuseableConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)actual, this.predicate);
/*     */     }
/*     */     
/*  51 */     return new FilterFuseableSubscriber<>(actual, this.predicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  56 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  57 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FilterFuseableSubscriber<T>
/*     */     implements InnerOperator<T, T>, Fuseable.QueueSubscription<T>, Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     FilterFuseableSubscriber(CoreSubscriber<? super T> actual, Predicate<? super T> predicate) {
/*  77 */       this.actual = actual;
/*  78 */       this.ctx = actual.currentContext();
/*  79 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  85 */       if (Operators.validate((Subscription)this.s, s)) {
/*  86 */         this.s = (Fuseable.QueueSubscription<T>)s;
/*  87 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  93 */       if (this.sourceMode == 2) {
/*  94 */         this.actual.onNext(null);
/*     */       } else {
/*     */         boolean b;
/*  97 */         if (this.done) {
/*  98 */           Operators.onNextDropped(t, this.ctx);
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/*     */         try {
/* 104 */           b = this.predicate.test(t);
/*     */         }
/* 106 */         catch (Throwable e) {
/* 107 */           Throwable e_ = Operators.onNextError(t, e, this.ctx, (Subscription)this.s);
/* 108 */           if (e_ != null) {
/* 109 */             onError(e_);
/*     */           } else {
/*     */             
/* 112 */             this.s.request(1L);
/*     */           } 
/* 114 */           Operators.onDiscard(t, this.ctx);
/*     */           return;
/*     */         } 
/* 117 */         if (b) {
/* 118 */           this.actual.onNext(t);
/*     */         } else {
/*     */           
/* 121 */           this.s.request(1L);
/* 122 */           Operators.onDiscard(t, this.ctx);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       boolean b;
/* 129 */       if (this.done) {
/* 130 */         Operators.onNextDropped(t, this.ctx);
/* 131 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 137 */         b = this.predicate.test(t);
/*     */       }
/* 139 */       catch (Throwable e) {
/* 140 */         Throwable e_ = Operators.onNextError(t, e, this.ctx, (Subscription)this.s);
/* 141 */         if (e_ != null) {
/* 142 */           onError(e_);
/*     */         }
/* 144 */         Operators.onDiscard(t, this.ctx);
/* 145 */         return false;
/*     */       } 
/* 147 */       if (b) {
/* 148 */         this.actual.onNext(t);
/* 149 */         return true;
/*     */       } 
/* 151 */       Operators.onDiscard(t, this.ctx);
/* 152 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 157 */       if (this.done) {
/* 158 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 161 */       this.done = true;
/* 162 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 167 */       if (this.done) {
/*     */         return;
/*     */       }
/* 170 */       this.done = true;
/* 171 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 177 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 178 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 179 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 181 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 186 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 191 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 196 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 202 */       if (this.sourceMode == 2) {
/* 203 */         long dropped = 0L;
/*     */         while (true) {
/* 205 */           T v = (T)this.s.poll();
/*     */           
/*     */           try {
/* 208 */             if (v == null || this.predicate.test(v)) {
/* 209 */               if (dropped != 0L) {
/* 210 */                 request(dropped);
/*     */               }
/* 212 */               return v;
/*     */             } 
/* 214 */             Operators.onDiscard(v, this.ctx);
/* 215 */             dropped++;
/*     */           }
/* 217 */           catch (Throwable e) {
/* 218 */             RuntimeException e_ = Operators.onNextPollError(v, e, currentContext());
/* 219 */             Operators.onDiscard(v, this.ctx);
/* 220 */             if (e_ != null) {
/* 221 */               throw e_;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       while (true) {
/* 229 */         T v = (T)this.s.poll();
/*     */         
/*     */         try {
/* 232 */           if (v == null || this.predicate.test(v)) {
/* 233 */             return v;
/*     */           }
/* 235 */           Operators.onDiscard(v, this.ctx);
/*     */         }
/* 237 */         catch (Throwable e) {
/* 238 */           RuntimeException e_ = Operators.onNextPollError(v, e, currentContext());
/* 239 */           Operators.onDiscard(v, this.ctx);
/* 240 */           if (e_ != null) {
/* 241 */             throw e_;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 251 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 256 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 262 */       if ((requestedMode & 0x4) != 0) {
/* 263 */         return 0;
/*     */       }
/*     */       
/* 266 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 268 */       this.sourceMode = m;
/* 269 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 274 */       return this.s.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FilterFuseableConditionalSubscriber<T>
/*     */     implements InnerOperator<T, T>, Fuseable.ConditionalSubscriber<T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     FilterFuseableConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, Predicate<? super T> predicate) {
/* 295 */       this.actual = actual;
/* 296 */       this.ctx = actual.currentContext();
/* 297 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 303 */       if (Operators.validate((Subscription)this.s, s)) {
/* 304 */         this.s = (Fuseable.QueueSubscription<T>)s;
/* 305 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 312 */       if (this.sourceMode == 2) {
/* 313 */         this.actual.onNext(null);
/*     */       } else {
/*     */         boolean b;
/* 316 */         if (this.done) {
/* 317 */           Operators.onNextDropped(t, this.ctx);
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/*     */         try {
/* 323 */           b = this.predicate.test(t);
/*     */         }
/* 325 */         catch (Throwable e) {
/* 326 */           Throwable e_ = Operators.onNextError(t, e, this.ctx, (Subscription)this.s);
/* 327 */           if (e_ != null) {
/* 328 */             onError(e_);
/*     */           } else {
/*     */             
/* 331 */             this.s.request(1L);
/*     */           } 
/* 333 */           Operators.onDiscard(t, this.ctx);
/*     */           return;
/*     */         } 
/* 336 */         if (b) {
/* 337 */           this.actual.onNext(t);
/*     */         } else {
/*     */           
/* 340 */           this.s.request(1L);
/* 341 */           Operators.onDiscard(t, this.ctx);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       boolean b;
/* 348 */       if (this.done) {
/* 349 */         Operators.onNextDropped(t, this.ctx);
/* 350 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 356 */         b = this.predicate.test(t);
/*     */       }
/* 358 */       catch (Throwable e) {
/* 359 */         Throwable e_ = Operators.onNextError(t, e, this.ctx, (Subscription)this.s);
/* 360 */         if (e_ != null) {
/* 361 */           onError(e_);
/*     */         }
/* 363 */         Operators.onDiscard(t, this.ctx);
/* 364 */         return false;
/*     */       } 
/* 366 */       if (b) {
/* 367 */         return this.actual.tryOnNext(t);
/*     */       }
/*     */       
/* 370 */       Operators.onDiscard(t, this.ctx);
/* 371 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 377 */       if (this.done) {
/* 378 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 381 */       this.done = true;
/* 382 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 387 */       if (this.done) {
/*     */         return;
/*     */       }
/* 390 */       this.done = true;
/* 391 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 397 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 398 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 399 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 401 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 406 */       return (CoreSubscriber<? super T>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 411 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 416 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 422 */       if (this.sourceMode == 2) {
/* 423 */         long dropped = 0L;
/*     */         while (true) {
/* 425 */           T v = (T)this.s.poll();
/*     */           try {
/* 427 */             if (v == null || this.predicate.test(v)) {
/* 428 */               if (dropped != 0L) {
/* 429 */                 request(dropped);
/*     */               }
/* 431 */               return v;
/*     */             } 
/* 433 */             Operators.onDiscard(v, this.ctx);
/* 434 */             dropped++;
/*     */           }
/* 436 */           catch (Throwable e) {
/* 437 */             RuntimeException e_ = Operators.onNextPollError(v, e, this.ctx);
/* 438 */             Operators.onDiscard(v, this.ctx);
/* 439 */             if (e_ != null) {
/* 440 */               throw e_;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       while (true) {
/* 448 */         T v = (T)this.s.poll();
/*     */         
/*     */         try {
/* 451 */           if (v == null || this.predicate.test(v)) {
/* 452 */             return v;
/*     */           }
/* 454 */           Operators.onDiscard(v, this.ctx);
/*     */         }
/* 456 */         catch (Throwable e) {
/* 457 */           RuntimeException e_ = Operators.onNextPollError(v, e, this.ctx);
/* 458 */           Operators.onDiscard(v, this.ctx);
/* 459 */           if (e_ != null) {
/* 460 */             throw e_;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 470 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 475 */       this.s.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 480 */       return this.s.size();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 486 */       if ((requestedMode & 0x4) != 0) {
/* 487 */         return 0;
/*     */       }
/*     */       
/* 490 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 492 */       this.sourceMode = m;
/* 493 */       return m;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxFilterFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */