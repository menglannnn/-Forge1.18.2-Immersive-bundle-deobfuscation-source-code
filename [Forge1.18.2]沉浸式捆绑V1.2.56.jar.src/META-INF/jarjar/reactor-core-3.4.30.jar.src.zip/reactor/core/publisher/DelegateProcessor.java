/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ final class DelegateProcessor<IN, OUT>
/*     */   extends FluxProcessor<IN, OUT>
/*     */ {
/*     */   final Publisher<OUT> downstream;
/*     */   final Subscriber<IN> upstream;
/*     */   
/*     */   DelegateProcessor(Publisher<OUT> downstream, Subscriber<IN> upstream) {
/*  42 */     this.downstream = Objects.<Publisher<OUT>>requireNonNull(downstream, "Downstream must not be null");
/*  43 */     this.upstream = Objects.<Subscriber<IN>>requireNonNull(upstream, "Upstream must not be null");
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/*  48 */     if (this.upstream instanceof CoreSubscriber) {
/*  49 */       return ((CoreSubscriber)this.upstream).currentContext();
/*     */     }
/*  51 */     return Context.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/*  56 */     this.upstream.onComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable t) {
/*  61 */     this.upstream.onError(t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNext(IN in) {
/*  66 */     this.upstream.onNext(in);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription s) {
/*  71 */     this.upstream.onSubscribe(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super OUT> actual) {
/*  76 */     Objects.requireNonNull(actual, "subscribe");
/*  77 */     this.downstream.subscribe((Subscriber)actual);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSerialized() {
/*  83 */     return (this.upstream instanceof SerializedSubscriber || (this.upstream instanceof FluxProcessor && ((FluxProcessor)this.upstream)
/*     */       
/*  85 */       .isSerialized()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/*  91 */     return Scannable.from(this.upstream)
/*  92 */       .inners();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBufferSize() {
/*  98 */     return ((Integer)Scannable.from(this.upstream)
/*  99 */       .scanOrDefault(Scannable.Attr.CAPACITY, Integer.valueOf(super.getBufferSize()))).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getError() {
/* 106 */     return (Throwable)Scannable.from(this.upstream)
/* 107 */       .scanOrDefault(Scannable.Attr.ERROR, super.getError());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 113 */     return ((Boolean)Scannable.from(this.upstream)
/* 114 */       .scanOrDefault(Scannable.Attr.TERMINATED, Boolean.valueOf(super.isTerminated()))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 120 */     if (key == Scannable.Attr.PARENT) {
/* 121 */       return this.downstream;
/*     */     }
/*     */     
/* 124 */     return Scannable.from(this.upstream)
/* 125 */       .scanUnsafe(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\DelegateProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */