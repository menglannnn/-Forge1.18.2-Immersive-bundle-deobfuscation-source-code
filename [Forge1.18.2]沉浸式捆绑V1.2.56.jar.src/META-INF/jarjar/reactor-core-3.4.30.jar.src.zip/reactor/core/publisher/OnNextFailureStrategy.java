/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Predicate;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface OnNextFailureStrategy
/*     */   extends BiFunction<Throwable, Object, Throwable>, BiPredicate<Throwable, Object>
/*     */ {
/*     */   public static final String KEY_ON_NEXT_ERROR_STRATEGY = "reactor.onNextError.localStrategy";
/*     */   
/*     */   @Nullable
/*     */   default Throwable apply(Throwable throwable, @Nullable Object o) {
/*  52 */     return process(throwable, o, Context.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OnNextFailureStrategy stop() {
/*  81 */     return STOP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OnNextFailureStrategy resumeDrop() {
/*  91 */     return RESUME_DROP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OnNextFailureStrategy resumeDropIf(Predicate<Throwable> causePredicate) {
/* 105 */     return new ResumeDropStrategy(causePredicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OnNextFailureStrategy resume(BiConsumer<Throwable, Object> errorConsumer) {
/* 121 */     return new ResumeStrategy(null, errorConsumer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OnNextFailureStrategy resumeIf(Predicate<Throwable> causePredicate, BiConsumer<Throwable, Object> errorConsumer) {
/* 142 */     return new ResumeStrategy(causePredicate, errorConsumer);
/*     */   }
/*     */ 
/*     */   
/* 146 */   public static final OnNextFailureStrategy STOP = new OnNextFailureStrategy()
/*     */     {
/*     */       public boolean test(Throwable error, @Nullable Object value)
/*     */       {
/* 150 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public Throwable process(Throwable error, @Nullable Object value, Context context) {
/* 155 */         Exceptions.throwIfFatal(error);
/* 156 */         Throwable iee = new IllegalStateException("STOP strategy cannot process errors");
/* 157 */         iee.addSuppressed(error);
/* 158 */         return iee;
/*     */       }
/*     */     };
/*     */   
/* 162 */   public static final OnNextFailureStrategy RESUME_DROP = new ResumeDropStrategy(null);
/*     */   boolean test(Throwable paramThrowable, @Nullable Object paramObject);
/*     */   
/*     */   @Nullable
/*     */   Throwable process(Throwable paramThrowable, @Nullable Object paramObject, Context paramContext);
/*     */   
/*     */   public static final class ResumeStrategy implements OnNextFailureStrategy { final Predicate<Throwable> errorPredicate;
/*     */     
/*     */     ResumeStrategy(@Nullable Predicate<Throwable> errorPredicate, BiConsumer<Throwable, Object> errorConsumer) {
/* 171 */       this.errorPredicate = errorPredicate;
/* 172 */       this.errorConsumer = errorConsumer;
/*     */     }
/*     */     final BiConsumer<Throwable, Object> errorConsumer;
/*     */     
/*     */     public boolean test(Throwable error, @Nullable Object value) {
/* 177 */       return (this.errorPredicate == null || this.errorPredicate.test(error));
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Throwable process(Throwable error, @Nullable Object value, Context context) {
/* 183 */       if (this.errorPredicate == null) {
/* 184 */         Exceptions.throwIfFatal(error);
/*     */       }
/* 186 */       else if (!this.errorPredicate.test(error)) {
/* 187 */         Exceptions.throwIfFatal(error);
/* 188 */         return error;
/*     */       } 
/*     */       try {
/* 191 */         this.errorConsumer.accept(error, value);
/* 192 */         return null;
/*     */       }
/* 194 */       catch (Throwable e) {
/* 195 */         return Exceptions.addSuppressed(e, error);
/*     */       } 
/*     */     } }
/*     */ 
/*     */   
/*     */   public static final class ResumeDropStrategy
/*     */     implements OnNextFailureStrategy {
/*     */     final Predicate<Throwable> errorPredicate;
/*     */     
/*     */     ResumeDropStrategy(@Nullable Predicate<Throwable> errorPredicate) {
/* 205 */       this.errorPredicate = errorPredicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(Throwable error, @Nullable Object value) {
/* 210 */       return (this.errorPredicate == null || this.errorPredicate.test(error));
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Throwable process(Throwable error, @Nullable Object value, Context context) {
/* 216 */       if (this.errorPredicate == null) {
/* 217 */         Exceptions.throwIfFatal(error);
/*     */       }
/* 219 */       else if (!this.errorPredicate.test(error)) {
/* 220 */         Exceptions.throwIfFatal(error);
/* 221 */         return error;
/*     */       } 
/*     */       try {
/* 224 */         if (value != null) {
/* 225 */           Operators.onNextDropped(value, context);
/*     */         }
/* 227 */         Operators.onErrorDropped(error, context);
/* 228 */         return null;
/*     */       }
/* 230 */       catch (Throwable e) {
/* 231 */         return Exceptions.addSuppressed(e, error);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class LambdaOnNextErrorStrategy
/*     */     implements OnNextFailureStrategy
/*     */   {
/*     */     private final BiFunction<? super Throwable, Object, ? extends Throwable> delegateProcessor;
/*     */     private final BiPredicate<? super Throwable, Object> delegatePredicate;
/*     */     
/*     */     public LambdaOnNextErrorStrategy(BiFunction<? super Throwable, Object, ? extends Throwable> delegateProcessor) {
/* 244 */       this.delegateProcessor = delegateProcessor;
/* 245 */       if (delegateProcessor instanceof BiPredicate) {
/* 246 */         this.delegatePredicate = (BiPredicate)delegateProcessor;
/*     */       } else {
/*     */         
/* 249 */         this.delegatePredicate = ((e, v) -> true);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(Throwable error, @Nullable Object value) {
/* 255 */       return this.delegatePredicate.test(error, value);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Throwable process(Throwable error, @Nullable Object value, Context ignored) {
/* 261 */       return this.delegateProcessor.apply(error, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\OnNextFailureStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */