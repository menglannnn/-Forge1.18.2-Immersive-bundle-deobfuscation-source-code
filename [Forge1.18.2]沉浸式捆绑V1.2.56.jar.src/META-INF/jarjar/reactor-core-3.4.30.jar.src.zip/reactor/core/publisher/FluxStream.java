/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.Spliterator;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Stream;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxStream<T>
/*    */   extends Flux<T>
/*    */   implements Fuseable, SourceProducer<T>
/*    */ {
/*    */   final Supplier<? extends Stream<? extends T>> streamSupplier;
/*    */   
/*    */   FluxStream(Supplier<? extends Stream<? extends T>> streamSupplier) {
/* 39 */     this.streamSupplier = Objects.<Supplier<? extends Stream<? extends T>>>requireNonNull(streamSupplier, "streamSupplier");
/*    */   }
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/*    */     Stream<? extends T> stream;
/*    */     Spliterator<? extends T> sp;
/*    */     boolean knownToBeFinite;
/*    */     try {
/* 46 */       stream = Objects.<Stream<? extends T>>requireNonNull(this.streamSupplier.get(), "The stream supplier returned a null Stream");
/*    */     
/*    */     }
/* 49 */     catch (Throwable e) {
/* 50 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*    */ 
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/*    */     try {
/* 57 */       Spliterator<? extends T> spliterator = Objects.<Spliterator<? extends T>>requireNonNull(stream.spliterator(), "The stream returned a null Spliterator");
/*    */       
/* 59 */       knownToBeFinite = spliterator.hasCharacteristics(64);
/* 60 */       sp = spliterator;
/*    */     }
/* 62 */     catch (Throwable e) {
/* 63 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*    */ 
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 69 */     FluxIterable.subscribe(actual, sp, knownToBeFinite, stream::close);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 74 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */