/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxGroupBy<T, K, V>
/*     */   extends InternalFluxOperator<T, GroupedFlux<K, V>>
/*     */   implements Fuseable
/*     */ {
/*     */   final Function<? super T, ? extends K> keySelector;
/*     */   final Function<? super T, ? extends V> valueSelector;
/*     */   final Supplier<? extends Queue<V>> groupQueueSupplier;
/*     */   final Supplier<? extends Queue<GroupedFlux<K, V>>> mainQueueSupplier;
/*     */   final int prefetch;
/*     */   
/*     */   FluxGroupBy(Flux<? extends T> source, Function<? super T, ? extends K> keySelector, Function<? super T, ? extends V> valueSelector, Supplier<? extends Queue<GroupedFlux<K, V>>> mainQueueSupplier, Supplier<? extends Queue<V>> groupQueueSupplier, int prefetch) {
/*  67 */     super(source);
/*  68 */     if (prefetch <= 0) {
/*  69 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  71 */     this.keySelector = Objects.<Function<? super T, ? extends K>>requireNonNull(keySelector, "keySelector");
/*  72 */     this.valueSelector = Objects.<Function<? super T, ? extends V>>requireNonNull(valueSelector, "valueSelector");
/*  73 */     this
/*  74 */       .mainQueueSupplier = Objects.<Supplier<? extends Queue<GroupedFlux<K, V>>>>requireNonNull(mainQueueSupplier, "mainQueueSupplier");
/*  75 */     this
/*  76 */       .groupQueueSupplier = Objects.<Supplier<? extends Queue<V>>>requireNonNull(groupQueueSupplier, "groupQueueSupplier");
/*  77 */     this.prefetch = prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super GroupedFlux<K, V>> actual) {
/*  82 */     return new GroupByMain<>(actual, this.mainQueueSupplier
/*  83 */         .get(), this.groupQueueSupplier, this.prefetch, this.keySelector, this.valueSelector);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  91 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  96 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  97 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class GroupByMain<T, K, V>
/*     */     implements Fuseable.QueueSubscription<GroupedFlux<K, V>>, InnerOperator<T, GroupedFlux<K, V>>
/*     */   {
/*     */     final Function<? super T, ? extends K> keySelector;
/*     */     
/*     */     final Function<? super T, ? extends V> valueSelector;
/*     */     
/*     */     final Queue<GroupedFlux<K, V>> queue;
/*     */     
/*     */     final Supplier<? extends Queue<V>> groupQueueSupplier;
/*     */     
/*     */     final int prefetch;
/*     */     final Map<K, FluxGroupBy.UnicastGroupedFlux<K, V>> groupMap;
/*     */     final CoreSubscriber<? super GroupedFlux<K, V>> actual;
/*     */     volatile int wip;
/* 116 */     static final AtomicIntegerFieldUpdater<GroupByMain> WIP = AtomicIntegerFieldUpdater.newUpdater(GroupByMain.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 121 */     static final AtomicLongFieldUpdater<GroupByMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(GroupByMain.class, "requested");
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     volatile Throwable error;
/*     */     
/* 127 */     static final AtomicReferenceFieldUpdater<GroupByMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(GroupByMain.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile int cancelled;
/*     */ 
/*     */     
/* 134 */     static final AtomicIntegerFieldUpdater<GroupByMain> CANCELLED = AtomicIntegerFieldUpdater.newUpdater(GroupByMain.class, "cancelled");
/*     */ 
/*     */     
/*     */     volatile int groupCount;
/*     */     
/* 139 */     static final AtomicIntegerFieldUpdater<GroupByMain> GROUP_COUNT = AtomicIntegerFieldUpdater.newUpdater(GroupByMain.class, "groupCount");
/*     */ 
/*     */ 
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     volatile boolean enableAsyncFusion;
/*     */ 
/*     */ 
/*     */     
/*     */     GroupByMain(CoreSubscriber<? super GroupedFlux<K, V>> actual, Queue<GroupedFlux<K, V>> queue, Supplier<? extends Queue<V>> groupQueueSupplier, int prefetch, Function<? super T, ? extends K> keySelector, Function<? super T, ? extends V> valueSelector) {
/* 151 */       this.actual = actual;
/* 152 */       this.queue = queue;
/* 153 */       this.groupQueueSupplier = groupQueueSupplier;
/* 154 */       this.prefetch = prefetch;
/* 155 */       this.groupMap = new ConcurrentHashMap<>();
/* 156 */       this.keySelector = keySelector;
/* 157 */       this.valueSelector = valueSelector;
/* 158 */       GROUP_COUNT.lazySet(this, 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super GroupedFlux<K, V>> actual() {
/* 163 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 168 */       if (Operators.validate(this.s, s)) {
/* 169 */         this.s = s;
/* 170 */         this.actual.onSubscribe(this);
/* 171 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */     public void onNext(T t) {
/*     */       K key;
/*     */       V value;
/* 177 */       if (this.done) {
/* 178 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 186 */         key = Objects.requireNonNull(this.keySelector.apply(t), "The keySelector returned a null value");
/* 187 */         value = Objects.requireNonNull(this.valueSelector.apply(t), "The valueSelector returned a null value");
/*     */       }
/* 189 */       catch (Throwable ex) {
/* 190 */         onError(Operators.onOperatorError(this.s, ex, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 194 */       FluxGroupBy.UnicastGroupedFlux<K, V> g = this.groupMap.get(key);
/*     */       
/* 196 */       if (g == null) {
/*     */         
/* 198 */         if (this.cancelled == 0) {
/* 199 */           Queue<V> q = this.groupQueueSupplier.get();
/*     */           
/* 201 */           GROUP_COUNT.getAndIncrement(this);
/* 202 */           g = new FluxGroupBy.UnicastGroupedFlux<>(key, q, this, this.prefetch);
/* 203 */           g.onNext(value);
/* 204 */           this.groupMap.put(key, g);
/*     */           
/* 206 */           this.queue.offer(g);
/* 207 */           drain();
/*     */         } 
/*     */       } else {
/*     */         
/* 211 */         g.onNext(value);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 217 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/* 218 */         this.done = true;
/* 219 */         drain();
/*     */       } else {
/*     */         
/* 222 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 228 */       if (this.done) {
/*     */         return;
/*     */       }
/* 231 */       for (FluxGroupBy.UnicastGroupedFlux<K, V> g : this.groupMap.values()) {
/* 232 */         g.onComplete();
/*     */       }
/* 234 */       this.groupMap.clear();
/* 235 */       this.done = true;
/* 236 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 242 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 243 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 244 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 245 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 246 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.queue.size()); 
/* 247 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.cancelled == 1)); 
/* 248 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 249 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 251 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 256 */       return this.groupMap.values().stream();
/*     */     }
/*     */     
/*     */     void signalAsyncError() {
/* 260 */       Throwable e = Exceptions.terminate(ERROR, this);
/* 261 */       if (e == null) {
/* 262 */         e = new IllegalStateException("FluxGroupBy.signalAsyncError called without error set");
/*     */       }
/* 264 */       this.groupCount = 0;
/* 265 */       for (FluxGroupBy.UnicastGroupedFlux<K, V> g : this.groupMap.values()) {
/* 266 */         g.onError(e);
/*     */       }
/* 268 */       this.actual.onError(e);
/* 269 */       this.groupMap.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 274 */       if (Operators.validate(n)) {
/* 275 */         Operators.addCap(REQUESTED, this, n);
/* 276 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 282 */       if (CANCELLED.compareAndSet(this, 0, 1)) {
/* 283 */         if (GROUP_COUNT.decrementAndGet(this) == 0) {
/* 284 */           this.s.cancel();
/*     */         }
/* 286 */         else if (!this.enableAsyncFusion && 
/* 287 */           WIP.getAndIncrement(this) == 0) {
/*     */           GroupedFlux<K, V> g;
/*     */           
/* 290 */           while ((g = this.queue.poll()) != null) {
/* 291 */             ((FluxGroupBy.UnicastGroupedFlux)g).cancel();
/*     */           }
/*     */           
/* 294 */           if (WIP.decrementAndGet(this) == 0) {
/*     */             return;
/*     */           }
/*     */           
/* 298 */           drainLoop();
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void groupTerminated(K key) {
/* 305 */       if (this.groupCount == 0) {
/*     */         return;
/*     */       }
/* 308 */       this.groupMap.remove(key);
/* 309 */       int groupRemaining = GROUP_COUNT.decrementAndGet(this);
/* 310 */       if (groupRemaining == 0) {
/* 311 */         this.s.cancel();
/*     */       }
/* 313 */       else if (groupRemaining == 1) {
/*     */ 
/*     */         
/* 316 */         this.s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */     
/*     */     void drain() {
/* 321 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 325 */       if (this.enableAsyncFusion) {
/* 326 */         drainFused();
/*     */       } else {
/*     */         
/* 329 */         drainLoop();
/*     */       } 
/*     */     }
/*     */     
/*     */     void drainFused() {
/* 334 */       int missed = 1;
/*     */       
/* 336 */       CoreSubscriber<? super GroupedFlux<K, V>> coreSubscriber = this.actual;
/* 337 */       Queue<GroupedFlux<K, V>> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 341 */         if (this.cancelled != 0) {
/* 342 */           q.clear();
/*     */           
/*     */           return;
/*     */         } 
/* 346 */         boolean d = this.done;
/*     */         
/* 348 */         coreSubscriber.onNext(null);
/*     */         
/* 350 */         if (d) {
/* 351 */           Throwable ex = this.error;
/* 352 */           if (ex != null) {
/* 353 */             signalAsyncError();
/*     */           } else {
/*     */             
/* 356 */             coreSubscriber.onComplete();
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 361 */         missed = WIP.addAndGet(this, -missed);
/* 362 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drainLoop() {
/* 370 */       int missed = 1;
/*     */       
/* 372 */       CoreSubscriber<? super GroupedFlux<K, V>> coreSubscriber = this.actual;
/* 373 */       Queue<GroupedFlux<K, V>> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 377 */         long r = this.requested;
/* 378 */         long e = 0L;
/*     */         
/* 380 */         while (e != r) {
/* 381 */           boolean d = this.done;
/* 382 */           GroupedFlux<K, V> v = q.poll();
/* 383 */           boolean empty = (v == null);
/*     */           
/* 385 */           if (checkTerminated(d, empty, (Subscriber<?>)coreSubscriber, q)) {
/*     */             return;
/*     */           }
/*     */           
/* 389 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 393 */           coreSubscriber.onNext(v);
/*     */           
/* 395 */           e++;
/*     */         } 
/*     */         
/* 398 */         if (e == r && 
/* 399 */           checkTerminated(this.done, q.isEmpty(), (Subscriber<?>)coreSubscriber, q)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 404 */         if (e != 0L) {
/* 405 */           this.s.request(e);
/*     */           
/* 407 */           if (r != Long.MAX_VALUE) {
/* 408 */             REQUESTED.addAndGet(this, -e);
/*     */           }
/*     */         } 
/*     */         
/* 412 */         missed = WIP.addAndGet(this, -missed);
/* 413 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, Queue<GroupedFlux<K, V>> q) {
/* 423 */       if (d) {
/* 424 */         Throwable e = this.error;
/* 425 */         if (e != null && e != Exceptions.TERMINATED) {
/* 426 */           q.clear();
/* 427 */           signalAsyncError();
/* 428 */           return true;
/*     */         } 
/* 430 */         if (empty) {
/* 431 */           a.onComplete();
/* 432 */           return true;
/*     */         } 
/*     */       } 
/*     */       
/* 436 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public GroupedFlux<K, V> poll() {
/* 442 */       return this.queue.poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 447 */       return this.queue.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 452 */       return this.queue.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 457 */       this.queue.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 462 */       if ((requestedMode & 0x2) != 0) {
/* 463 */         this.enableAsyncFusion = true;
/* 464 */         return 2;
/*     */       } 
/* 466 */       return 0;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class UnicastGroupedFlux<K, V>
/*     */     extends GroupedFlux<K, V>
/*     */     implements Fuseable, Fuseable.QueueSubscription<V>, InnerProducer<V>
/*     */   {
/*     */     final K key;
/*     */     final int limit;
/*     */     final Context context;
/*     */     final Queue<V> queue;
/*     */     volatile FluxGroupBy.GroupByMain<?, K, V> parent;
/*     */     
/*     */     public K key() {
/* 481 */       return this.key;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 489 */     static final AtomicReferenceFieldUpdater<UnicastGroupedFlux, FluxGroupBy.GroupByMain> PARENT = AtomicReferenceFieldUpdater.newUpdater(UnicastGroupedFlux.class, FluxGroupBy.GroupByMain.class, "parent");
/*     */ 
/*     */     
/*     */     volatile boolean done;
/*     */ 
/*     */     
/*     */     Throwable error;
/*     */     
/*     */     volatile CoreSubscriber<? super V> actual;
/*     */     
/* 499 */     static final AtomicReferenceFieldUpdater<UnicastGroupedFlux, CoreSubscriber> ACTUAL = AtomicReferenceFieldUpdater.newUpdater(UnicastGroupedFlux.class, CoreSubscriber.class, "actual");
/*     */ 
/*     */     
/*     */     volatile boolean cancelled;
/*     */ 
/*     */     
/*     */     volatile int once;
/*     */ 
/*     */     
/* 508 */     static final AtomicIntegerFieldUpdater<UnicastGroupedFlux> ONCE = AtomicIntegerFieldUpdater.newUpdater(UnicastGroupedFlux.class, "once");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */     
/* 513 */     static final AtomicIntegerFieldUpdater<UnicastGroupedFlux> WIP = AtomicIntegerFieldUpdater.newUpdater(UnicastGroupedFlux.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 518 */     static final AtomicLongFieldUpdater<UnicastGroupedFlux> REQUESTED = AtomicLongFieldUpdater.newUpdater(UnicastGroupedFlux.class, "requested");
/*     */ 
/*     */     
/*     */     volatile boolean outputFused;
/*     */     
/*     */     int produced;
/*     */     
/*     */     boolean isFirstRequest = true;
/*     */ 
/*     */     
/*     */     UnicastGroupedFlux(K key, Queue<V> queue, FluxGroupBy.GroupByMain<?, K, V> parent, int prefetch) {
/* 529 */       this.key = key;
/* 530 */       this.queue = queue;
/* 531 */       this.context = parent.currentContext();
/* 532 */       this.parent = parent;
/* 533 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*     */     }
/*     */     
/*     */     void doTerminate() {
/* 537 */       FluxGroupBy.GroupByMain<?, K, V> r = this.parent;
/* 538 */       if (r != null && PARENT.compareAndSet(this, r, null)) {
/* 539 */         r.groupTerminated(this.key);
/*     */       }
/*     */     }
/*     */     
/*     */     void drainRegular(Subscriber<? super V> a) {
/* 544 */       int missed = 1;
/*     */       
/* 546 */       Queue<V> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 550 */         long r = this.requested;
/* 551 */         long e = 0L;
/*     */         
/* 553 */         while (r != e) {
/* 554 */           boolean d = this.done;
/*     */           
/* 556 */           V t = q.poll();
/* 557 */           boolean empty = (t == null);
/*     */           
/* 559 */           if (checkTerminated(d, empty, a, q)) {
/*     */             return;
/*     */           }
/*     */           
/* 563 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 567 */           a.onNext(t);
/*     */           
/* 569 */           e++;
/*     */         } 
/*     */         
/* 572 */         if (r == e && 
/* 573 */           checkTerminated(this.done, q.isEmpty(), a, q)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 578 */         if (e != 0L) {
/* 579 */           FluxGroupBy.GroupByMain<?, K, V> main = this.parent;
/* 580 */           if (main != null) {
/* 581 */             if (this.isFirstRequest) {
/* 582 */               this.isFirstRequest = false;
/* 583 */               long toRequest = e - 1L;
/*     */               
/* 585 */               if (toRequest > 0L) {
/* 586 */                 main.s.request(toRequest);
/*     */               }
/*     */             } else {
/* 589 */               main.s.request(e);
/*     */             } 
/*     */           }
/* 592 */           if (r != Long.MAX_VALUE) {
/* 593 */             REQUESTED.addAndGet(this, -e);
/*     */           }
/*     */         } 
/*     */         
/* 597 */         missed = WIP.addAndGet(this, -missed);
/* 598 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drainFused(Subscriber<? super V> a) {
/* 605 */       int missed = 1;
/*     */       
/* 607 */       Queue<V> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 611 */         if (this.cancelled) {
/* 612 */           q.clear();
/* 613 */           this.actual = null;
/*     */           
/*     */           return;
/*     */         } 
/* 617 */         boolean d = this.done;
/*     */         
/* 619 */         a.onNext(null);
/*     */         
/* 621 */         if (d) {
/* 622 */           this.actual = null;
/*     */           
/* 624 */           Throwable ex = this.error;
/* 625 */           if (ex != null) {
/* 626 */             a.onError(ex);
/*     */           } else {
/*     */             
/* 629 */             a.onComplete();
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 634 */         missed = WIP.addAndGet(this, -missed);
/* 635 */       } while (missed != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void drain() {
/* 642 */       CoreSubscriber<? super V> coreSubscriber = this.actual;
/* 643 */       if (coreSubscriber != null) {
/* 644 */         if (WIP.getAndIncrement(this) != 0) {
/*     */           return;
/*     */         }
/*     */         
/* 648 */         if (this.outputFused) {
/* 649 */           drainFused((Subscriber<? super V>)coreSubscriber);
/*     */         } else {
/*     */           
/* 652 */           drainRegular((Subscriber<? super V>)coreSubscriber);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean checkTerminated(boolean d, boolean empty, Subscriber<?> a, Queue<?> q) {
/* 658 */       if (this.cancelled) {
/* 659 */         q.clear();
/* 660 */         this.actual = null;
/* 661 */         return true;
/*     */       } 
/* 663 */       if (d && empty) {
/* 664 */         Throwable e = this.error;
/* 665 */         this.actual = null;
/* 666 */         if (e != null) {
/* 667 */           a.onError(e);
/*     */         } else {
/*     */           
/* 670 */           a.onComplete();
/*     */         } 
/* 672 */         return true;
/*     */       } 
/*     */       
/* 675 */       return false;
/*     */     }
/*     */     
/*     */     public void onNext(V t) {
/* 679 */       CoreSubscriber<? super V> coreSubscriber = this.actual;
/*     */       
/* 681 */       if (!this.queue.offer(t)) {
/* 682 */         onError(Operators.onOperatorError(this, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, this.actual
/* 683 */               .currentContext()));
/*     */         return;
/*     */       } 
/* 686 */       if (this.outputFused) {
/* 687 */         if (coreSubscriber != null) {
/* 688 */           coreSubscriber.onNext(null);
/*     */         }
/*     */       } else {
/*     */         
/* 692 */         drain();
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onError(Throwable t) {
/* 697 */       this.error = t;
/* 698 */       this.done = true;
/*     */       
/* 700 */       doTerminate();
/*     */       
/* 702 */       drain();
/*     */     }
/*     */     
/*     */     public void onComplete() {
/* 706 */       this.done = true;
/*     */       
/* 708 */       doTerminate();
/*     */       
/* 710 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super V> actual) {
/* 715 */       if (this.once == 0 && ONCE.compareAndSet(this, 0, 1)) {
/* 716 */         actual.onSubscribe(this);
/* 717 */         ACTUAL.lazySet(this, actual);
/* 718 */         drain();
/*     */       } else {
/*     */         
/* 721 */         actual.onError(new IllegalStateException("GroupedFlux allows only one Subscriber"));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 728 */       if (Operators.validate(n)) {
/* 729 */         Operators.addCap(REQUESTED, this, n);
/* 730 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 736 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/* 739 */       this.cancelled = true;
/*     */       
/* 741 */       doTerminate();
/*     */       
/* 743 */       if (!this.outputFused && 
/* 744 */         WIP.getAndIncrement(this) == 0) {
/* 745 */         this.queue.clear();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public V poll() {
/* 753 */       V v = this.queue.poll();
/* 754 */       if (v != null) {
/* 755 */         this.produced++;
/*     */       } else {
/*     */         
/* 758 */         tryReplenish();
/*     */       } 
/* 760 */       return v;
/*     */     }
/*     */     
/*     */     void tryReplenish() {
/* 764 */       int p = this.produced;
/* 765 */       if (p != 0) {
/* 766 */         this.produced = 0;
/* 767 */         FluxGroupBy.GroupByMain<?, K, V> main = this.parent;
/* 768 */         if (main != null) {
/* 769 */           if (this.isFirstRequest) {
/* 770 */             this.isFirstRequest = false;
/* 771 */             p--;
/*     */             
/* 773 */             if (p > 0) {
/* 774 */               main.s.request(p);
/*     */             }
/*     */           } else {
/* 777 */             main.s.request(p);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 785 */       return this.queue.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 790 */       if (this.queue.isEmpty()) {
/* 791 */         tryReplenish();
/* 792 */         return true;
/*     */       } 
/* 794 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 799 */       this.queue.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 804 */       if ((requestedMode & 0x2) != 0) {
/* 805 */         this.outputFused = true;
/* 806 */         return 2;
/*     */       } 
/* 808 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 814 */       if (key == Scannable.Attr.PARENT) return this.parent; 
/* 815 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 816 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 817 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 818 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 819 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 820 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 822 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super V> actual() {
/* 827 */       return this.actual;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxGroupBy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */