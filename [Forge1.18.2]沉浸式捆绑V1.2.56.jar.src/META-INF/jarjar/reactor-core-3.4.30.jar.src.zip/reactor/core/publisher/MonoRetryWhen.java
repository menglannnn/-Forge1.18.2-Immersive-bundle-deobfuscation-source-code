/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.retry.Retry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoRetryWhen<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final Retry whenSourceFactory;
/*    */   
/*    */   MonoRetryWhen(Mono<? extends T> source, Retry whenSourceFactory) {
/* 40 */     super(source);
/* 41 */     this.whenSourceFactory = Objects.<Retry>requireNonNull(whenSourceFactory, "whenSourceFactory");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 46 */     FluxRetryWhen.subscribe(actual, this.whenSourceFactory, this.source);
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 52 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 53 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoRetryWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */