/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxIndex<T, I>
/*     */   extends InternalFluxOperator<T, I>
/*     */ {
/*     */   private final BiFunction<? super Long, ? super T, ? extends I> indexMapper;
/*     */   
/*     */   FluxIndex(Flux<T> source, BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/*  43 */     super(source);
/*  44 */     this.indexMapper = NullSafeIndexMapper.create(Objects.<BiFunction<? super Long, ? super T, ? extends I>>requireNonNull(indexMapper, "indexMapper must be non null"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super I> actual) {
/*  50 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  51 */       Fuseable.ConditionalSubscriber<? super I> cs = (Fuseable.ConditionalSubscriber<? super I>)actual;
/*     */       
/*  53 */       return new IndexConditionalSubscriber<>(cs, this.indexMapper);
/*     */     } 
/*     */     
/*  56 */     return new IndexSubscriber<>(actual, this.indexMapper);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  62 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  63 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class IndexSubscriber<T, I>
/*     */     implements InnerOperator<T, I>
/*     */   {
/*     */     final CoreSubscriber<? super I> actual;
/*     */     final BiFunction<? super Long, ? super T, ? extends I> indexMapper;
/*     */     boolean done;
/*     */     Subscription s;
/*  73 */     long index = 0L;
/*     */ 
/*     */     
/*     */     IndexSubscriber(CoreSubscriber<? super I> actual, BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/*  77 */       this.actual = actual;
/*  78 */       this.indexMapper = indexMapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  83 */       if (Operators.validate(this.s, s)) {
/*  84 */         this.s = s;
/*     */         
/*  86 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  92 */       if (this.done) {
/*  93 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*  97 */       long i = this.index;
/*     */       try {
/*  99 */         I typedIndex = this.indexMapper.apply(Long.valueOf(i), t);
/* 100 */         this.index = i + 1L;
/* 101 */         this.actual.onNext(typedIndex);
/*     */       }
/* 103 */       catch (Throwable e) {
/* 104 */         onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 110 */       if (this.done) {
/* 111 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 115 */       this.done = true;
/*     */       
/* 117 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 122 */       if (this.done) {
/*     */         return;
/*     */       }
/* 125 */       this.done = true;
/*     */       
/* 127 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super I> actual() {
/* 132 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 137 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 142 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 148 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 149 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 150 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 152 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class IndexConditionalSubscriber<T, I>
/*     */     implements InnerOperator<T, I>, Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super I> actual;
/*     */     
/*     */     final BiFunction<? super Long, ? super T, ? extends I> indexMapper;
/*     */     
/*     */     Subscription s;
/*     */     boolean done;
/*     */     long index;
/*     */     
/*     */     IndexConditionalSubscriber(Fuseable.ConditionalSubscriber<? super I> cs, BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/* 169 */       this.actual = cs;
/* 170 */       this.indexMapper = indexMapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 175 */       if (Operators.validate(this.s, s)) {
/* 176 */         this.s = s;
/* 177 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       I typedIndex;
/* 183 */       if (this.done) {
/* 184 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 185 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 189 */       long i = this.index;
/*     */       try {
/* 191 */         typedIndex = this.indexMapper.apply(Long.valueOf(i), t);
/* 192 */         this.index = i + 1L;
/*     */       }
/* 194 */       catch (Throwable e) {
/* 195 */         onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/* 196 */         return true;
/*     */       } 
/*     */       
/* 199 */       return this.actual.tryOnNext(typedIndex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 204 */       if (this.done) {
/* 205 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 209 */       long i = this.index;
/*     */       try {
/* 211 */         I typedIndex = this.indexMapper.apply(Long.valueOf(i), t);
/* 212 */         this.index = i + 1L;
/* 213 */         this.actual.onNext(typedIndex);
/*     */       }
/* 215 */       catch (Throwable e) {
/* 216 */         onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 222 */       if (this.done) {
/* 223 */         Operators.onErrorDropped(throwable, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 227 */       this.done = true;
/*     */       
/* 229 */       this.actual.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 234 */       if (this.done) {
/*     */         return;
/*     */       }
/* 237 */       this.done = true;
/*     */       
/* 239 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super I> actual() {
/* 244 */       return (CoreSubscriber<? super I>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 249 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 254 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 260 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 261 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 262 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 264 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */   
/*     */   static class NullSafeIndexMapper<T, I>
/*     */     implements BiFunction<Long, T, I> {
/*     */     private final BiFunction<? super Long, ? super T, ? extends I> indexMapper;
/*     */     
/*     */     private NullSafeIndexMapper(BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/* 273 */       this.indexMapper = indexMapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public I apply(Long i, T t) {
/* 278 */       I typedIndex = this.indexMapper.apply(i, t);
/* 279 */       if (typedIndex == null) {
/* 280 */         throw new NullPointerException("indexMapper returned a null value at raw index " + i + " for value " + t);
/*     */       }
/*     */       
/* 283 */       return typedIndex;
/*     */     }
/*     */ 
/*     */     
/*     */     static <T, I> BiFunction<? super Long, ? super T, ? extends I> create(BiFunction<? super Long, ? super T, ? extends I> indexMapper) {
/* 288 */       if (indexMapper == Flux.TUPLE2_BIFUNCTION)
/*     */       {
/*     */         
/* 291 */         return indexMapper;
/*     */       }
/* 293 */       return new NullSafeIndexMapper<>(indexMapper);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxIndex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */