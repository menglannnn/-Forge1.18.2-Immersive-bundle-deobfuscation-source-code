/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelMergeSequential<T>
/*     */   extends Flux<T>
/*     */   implements Scannable
/*     */ {
/*     */   final ParallelFlux<? extends T> source;
/*     */   final int prefetch;
/*     */   final Supplier<Queue<T>> queueSupplier;
/*     */   
/*     */   ParallelMergeSequential(ParallelFlux<? extends T> source, int prefetch, Supplier<Queue<T>> queueSupplier) {
/*  46 */     if (prefetch <= 0) {
/*  47 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  49 */     this.source = source;
/*  50 */     this.prefetch = prefetch;
/*  51 */     this.queueSupplier = queueSupplier;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  57 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  58 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  59 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  66 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  72 */     MergeSequentialMain<T> parent = new MergeSequentialMain<>(actual, this.source.parallelism(), this.prefetch, this.queueSupplier);
/*  73 */     actual.onSubscribe(parent);
/*  74 */     this.source.subscribe((CoreSubscriber<? super T>[])parent.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MergeSequentialMain<T>
/*     */     implements InnerProducer<T>
/*     */   {
/*     */     final ParallelMergeSequential.MergeSequentialInner<T>[] subscribers;
/*     */     
/*     */     final Supplier<Queue<T>> queueSupplier;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*  86 */     static final AtomicReferenceFieldUpdater<MergeSequentialMain, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(MergeSequentialMain.class, Throwable.class, "error");
/*     */ 
/*     */     
/*     */     volatile int wip;
/*     */ 
/*     */     
/*  92 */     static final AtomicIntegerFieldUpdater<MergeSequentialMain> WIP = AtomicIntegerFieldUpdater.newUpdater(MergeSequentialMain.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/*  97 */     static final AtomicLongFieldUpdater<MergeSequentialMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(MergeSequentialMain.class, "requested");
/*     */ 
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile int done;
/*     */     
/* 104 */     static final AtomicIntegerFieldUpdater<MergeSequentialMain> DONE = AtomicIntegerFieldUpdater.newUpdater(MergeSequentialMain.class, "done");
/*     */     
/*     */     volatile Throwable error;
/*     */ 
/*     */     
/*     */     MergeSequentialMain(CoreSubscriber<? super T> actual, int n, int prefetch, Supplier<Queue<T>> queueSupplier) {
/* 110 */       this.actual = actual;
/* 111 */       this.queueSupplier = queueSupplier;
/*     */       
/* 113 */       ParallelMergeSequential.MergeSequentialInner[] arrayOfMergeSequentialInner = new ParallelMergeSequential.MergeSequentialInner[n];
/*     */       
/* 115 */       for (int i = 0; i < n; i++) {
/* 116 */         arrayOfMergeSequentialInner[i] = new ParallelMergeSequential.MergeSequentialInner<>(this, prefetch);
/*     */       }
/*     */       
/* 119 */       this.subscribers = (ParallelMergeSequential.MergeSequentialInner<T>[])arrayOfMergeSequentialInner;
/* 120 */       DONE.lazySet(this, n);
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 125 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 131 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 132 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 133 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done == 0)); 
/* 134 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 135 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 137 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 142 */       return Stream.of((Scannable[])this.subscribers);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 147 */       if (Operators.validate(n)) {
/* 148 */         Operators.addCap(REQUESTED, this, n);
/* 149 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 155 */       if (!this.cancelled) {
/* 156 */         this.cancelled = true;
/*     */         
/* 158 */         cancelAll();
/*     */         
/* 160 */         if (WIP.getAndIncrement(this) == 0) {
/* 161 */           cleanup();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void cancelAll() {
/* 167 */       for (ParallelMergeSequential.MergeSequentialInner<T> s : this.subscribers) {
/* 168 */         s.cancel();
/*     */       }
/*     */     }
/*     */     
/*     */     void cleanup() {
/* 173 */       for (ParallelMergeSequential.MergeSequentialInner<T> s : this.subscribers) {
/* 174 */         s.queue = null;
/*     */       }
/*     */     }
/*     */     
/*     */     void onNext(ParallelMergeSequential.MergeSequentialInner<T> inner, T value) {
/* 179 */       if (this.wip == 0 && WIP.compareAndSet(this, 0, 1)) {
/* 180 */         if (this.requested != 0L) {
/* 181 */           this.actual.onNext(value);
/* 182 */           if (this.requested != Long.MAX_VALUE) {
/* 183 */             REQUESTED.decrementAndGet(this);
/*     */           }
/* 185 */           inner.requestOne();
/*     */         } else {
/* 187 */           Queue<T> q = inner.getQueue(this.queueSupplier);
/*     */           
/* 189 */           if (!q.offer(value)) {
/* 190 */             onError(Operators.onOperatorError(this, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), value, this.actual
/* 191 */                   .currentContext()));
/*     */             return;
/*     */           } 
/*     */         } 
/* 195 */         if (WIP.decrementAndGet(this) == 0) {
/*     */           return;
/*     */         }
/*     */       } else {
/* 199 */         Queue<T> q = inner.getQueue(this.queueSupplier);
/*     */         
/* 201 */         if (!q.offer(value)) {
/* 202 */           onError(Operators.onOperatorError(this, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), value, this.actual
/* 203 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 207 */         if (WIP.getAndIncrement(this) != 0) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */       
/* 212 */       drainLoop();
/*     */     }
/*     */     
/*     */     void onError(Throwable ex) {
/* 216 */       if (ERROR.compareAndSet(this, null, ex)) {
/* 217 */         cancelAll();
/* 218 */         drain();
/*     */       }
/* 220 */       else if (this.error != ex) {
/* 221 */         Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */     
/*     */     void onComplete() {
/* 226 */       if (DONE.decrementAndGet(this) < 0) {
/*     */         return;
/*     */       }
/* 229 */       drain();
/*     */     }
/*     */     
/*     */     void drain() {
/* 233 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 237 */       drainLoop();
/*     */     }
/*     */     
/*     */     void drainLoop() {
/* 241 */       int missed = 1;
/*     */       
/* 243 */       ParallelMergeSequential.MergeSequentialInner<T>[] s = this.subscribers;
/* 244 */       int n = s.length;
/* 245 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*     */ 
/*     */       
/*     */       while (true) {
/* 249 */         long r = this.requested;
/* 250 */         long e = 0L;
/*     */ 
/*     */         
/* 253 */         label70: while (e != r) {
/* 254 */           if (this.cancelled) {
/* 255 */             cleanup();
/*     */             
/*     */             return;
/*     */           } 
/* 259 */           Throwable ex = this.error;
/* 260 */           if (ex != null) {
/* 261 */             cleanup();
/* 262 */             coreSubscriber.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/* 266 */           boolean d = (this.done == 0);
/*     */           
/* 268 */           boolean empty = true;
/*     */           
/* 270 */           for (int i = 0; i < n; i++) {
/* 271 */             ParallelMergeSequential.MergeSequentialInner<T> inner = s[i];
/*     */             
/* 273 */             Queue<T> q = inner.queue;
/* 274 */             if (q != null) {
/* 275 */               T v = q.poll();
/*     */ 
/*     */               
/* 278 */               empty = false;
/* 279 */               coreSubscriber.onNext(v);
/* 280 */               inner.requestOne();
/* 281 */               if (v != null && ++e == r) {
/*     */                 break label70;
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 288 */           if (d && empty) {
/* 289 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/* 293 */           if (empty) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 298 */         if (e == r) {
/* 299 */           if (this.cancelled) {
/* 300 */             cleanup();
/*     */             
/*     */             return;
/*     */           } 
/* 304 */           Throwable ex = this.error;
/* 305 */           if (ex != null) {
/* 306 */             cleanup();
/* 307 */             coreSubscriber.onError(ex);
/*     */             
/*     */             return;
/*     */           } 
/* 311 */           boolean d = (this.done == 0);
/*     */           
/* 313 */           boolean empty = true;
/*     */           
/* 315 */           for (int i = 0; i < n; i++) {
/* 316 */             ParallelMergeSequential.MergeSequentialInner<T> inner = s[i];
/*     */             
/* 318 */             Queue<T> q = inner.queue;
/* 319 */             if (q != null && !q.isEmpty()) {
/* 320 */               empty = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 325 */           if (d && empty) {
/* 326 */             coreSubscriber.onComplete();
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 331 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 332 */           REQUESTED.addAndGet(this, -e);
/*     */         }
/*     */         
/* 335 */         int w = this.wip;
/* 336 */         if (w == missed) {
/* 337 */           missed = WIP.addAndGet(this, -missed);
/* 338 */           if (missed == 0)
/*     */             break; 
/*     */           continue;
/*     */         } 
/* 342 */         missed = w;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MergeSequentialInner<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final ParallelMergeSequential.MergeSequentialMain<T> parent;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     long produced;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/* 361 */     static final AtomicReferenceFieldUpdater<MergeSequentialInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(MergeSequentialInner.class, Subscription.class, "s");
/*     */     
/*     */     volatile Queue<T> queue;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     MergeSequentialInner(ParallelMergeSequential.MergeSequentialMain<T> parent, int prefetch) {
/* 368 */       this.parent = parent;
/* 369 */       this.prefetch = prefetch;
/* 370 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 376 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 377 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 378 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 379 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 380 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 381 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 382 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 384 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 389 */       return this.parent.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 394 */       if (Operators.setOnce(S, this, s)) {
/* 395 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 401 */       this.parent.onNext(this, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 406 */       this.parent.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 411 */       this.parent.onComplete();
/*     */     }
/*     */     
/*     */     void requestOne() {
/* 415 */       long p = this.produced + 1L;
/* 416 */       if (p == this.limit) {
/* 417 */         this.produced = 0L;
/* 418 */         this.s.request(p);
/*     */       } else {
/* 420 */         this.produced = p;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void cancel() {
/* 425 */       Operators.terminate(S, this);
/*     */     }
/*     */     
/*     */     Queue<T> getQueue(Supplier<Queue<T>> queueSupplier) {
/* 429 */       Queue<T> q = this.queue;
/* 430 */       if (q == null) {
/* 431 */         q = queueSupplier.get();
/* 432 */         this.queue = q;
/*     */       } 
/* 434 */       return q;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ParallelMergeSequential.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */