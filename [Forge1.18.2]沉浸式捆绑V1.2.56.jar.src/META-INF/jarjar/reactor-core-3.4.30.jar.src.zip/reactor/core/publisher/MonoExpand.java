/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoExpand<T>
/*    */   extends FluxFromMonoOperator<T, T>
/*    */ {
/*    */   final boolean breadthFirst;
/*    */   final Function<? super T, ? extends Publisher<? extends T>> expander;
/*    */   final int capacityHint;
/*    */   
/*    */   MonoExpand(Mono<T> source, Function<? super T, ? extends Publisher<? extends T>> expander, boolean breadthFirst, int capacityHint) {
/* 41 */     super(source);
/* 42 */     this.expander = expander;
/* 43 */     this.breadthFirst = breadthFirst;
/* 44 */     this.capacityHint = capacityHint;
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> s) {
/* 49 */     if (this.breadthFirst) {
/* 50 */       FluxExpand.ExpandBreathSubscriber<T> parent = new FluxExpand.ExpandBreathSubscriber<>(s, this.expander, this.capacityHint);
/*    */       
/* 52 */       parent.queue.offer(this.source);
/* 53 */       s.onSubscribe(parent);
/* 54 */       parent.drainQueue();
/*    */     } else {
/*    */       
/* 57 */       FluxExpand.ExpandDepthSubscription<T> parent = new FluxExpand.ExpandDepthSubscription<>(s, this.expander, this.capacityHint);
/*    */       
/* 59 */       parent.source = this.source;
/* 60 */       s.onSubscribe(parent);
/*    */     } 
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 67 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 68 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoExpand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */