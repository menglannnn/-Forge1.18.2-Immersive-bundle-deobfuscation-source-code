/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoContextWrite<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<Context, Context> doOnContext;
/*    */   
/*    */   MonoContextWrite(Mono<? extends T> source, Function<Context, Context> doOnContext) {
/* 32 */     super(source);
/* 33 */     this.doOnContext = Objects.<Function<Context, Context>>requireNonNull(doOnContext, "doOnContext");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 38 */     Context c = this.doOnContext.apply(actual.currentContext());
/*    */     
/* 40 */     return new FluxContextWrite.ContextWriteSubscriber<>(actual, c);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 45 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 46 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoContextWrite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */