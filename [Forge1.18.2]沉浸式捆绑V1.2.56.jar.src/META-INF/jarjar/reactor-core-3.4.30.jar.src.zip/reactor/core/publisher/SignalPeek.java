/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongConsumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface SignalPeek<T>
/*     */   extends Scannable
/*     */ {
/*     */   @Nullable
/*     */   Consumer<? super Subscription> onSubscribeCall();
/*     */   
/*     */   @Nullable
/*     */   Consumer<? super T> onNextCall();
/*     */   
/*     */   @Nullable
/*     */   Consumer<? super Throwable> onErrorCall();
/*     */   
/*     */   @Nullable
/*     */   Runnable onCompleteCall();
/*     */   
/*     */   @Nullable
/*     */   Runnable onAfterTerminateCall();
/*     */   
/*     */   @Nullable
/*     */   LongConsumer onRequestCall();
/*     */   
/*     */   @Nullable
/*     */   Runnable onCancelCall();
/*     */   
/*     */   @Nullable
/*     */   default Consumer<? super T> onAfterNextCall() {
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default Consumer<? super Context> onCurrentContextCall() {
/* 108 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\SignalPeek.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */