/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import sun.misc.JavaLangAccess;
/*     */ import sun.misc.SharedSecrets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Traces
/*     */ {
/*  40 */   static final boolean full = Boolean.parseBoolean(System.getProperty("reactor.trace.assembly.fullstacktrace", "false"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String CALL_SITE_GLUE = " ⇢ ";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Supplier<Supplier<String>> callSiteSupplierFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  57 */     String[] strategyClasses = { Traces.class.getName() + "$StackWalkerCallSiteSupplierFactory", Traces.class.getName() + "$SharedSecretsCallSiteSupplierFactory", Traces.class.getName() + "$ExceptionCallSiteSupplierFactory" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     callSiteSupplierFactory = (Supplier<Supplier<String>>)Stream.<String>of(strategyClasses).flatMap(className -> { try { Class<?> clazz = Class.forName(className); Supplier<Supplier<String>> function = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]); return Stream.of(function); } catch (LinkageError e) { return Stream.empty(); } catch (Throwable e) { return Stream.empty(); }  }).findFirst().orElseThrow(() -> new IllegalStateException("Valid strategy not found"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class StackWalkerCallSiteSupplierFactory
/*     */     implements Supplier<Supplier<String>>
/*     */   {
/*     */     static {
/*  93 */       StackWalker.getInstance();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Supplier<String> get() {
/* 105 */       StackWalker.StackFrame[] stack = StackWalker.getInstance().<StackWalker.StackFrame[]>walk(s -> {
/*     */             StackWalker.StackFrame[] result = new StackWalker.StackFrame[10];
/*     */             
/*     */             Iterator<StackWalker.StackFrame> iterator = s.iterator();
/*     */             
/*     */             iterator.next();
/*     */             
/*     */             int i = 0;
/*     */             
/*     */             while (iterator.hasNext()) {
/*     */               StackWalker.StackFrame frame = iterator.next();
/*     */               
/*     */               if (i >= result.length) {
/*     */                 return new StackWalker.StackFrame[0];
/*     */               }
/*     */               result[i++] = frame;
/*     */               if (Traces.isUserCode(frame.getClassName())) {
/*     */                 break;
/*     */               }
/*     */             } 
/*     */             StackWalker.StackFrame[] copy = new StackWalker.StackFrame[i];
/*     */             System.arraycopy(result, 0, copy, 0, i);
/*     */             return copy;
/*     */           });
/* 129 */       if (stack.length == 0) {
/* 130 */         return () -> "";
/*     */       }
/*     */       
/* 133 */       if (stack.length == 1) {
/* 134 */         return () -> "\t" + stack[0].toString() + "\n";
/*     */       }
/*     */       
/* 137 */       return () -> {
/*     */           StringBuilder sb = new StringBuilder();
/*     */           for (int j = stack.length - 2; j > 0; j--) {
/*     */             StackWalker.StackFrame previous = stack[j];
/*     */             if (!Traces.full) {
/*     */               if (previous.isNativeMethod()) {
/*     */                 continue;
/*     */               }
/*     */               String previousRow = previous.getClassName() + "." + previous.getMethodName();
/*     */               if (Traces.shouldSanitize(previousRow)) {
/*     */                 continue;
/*     */               }
/*     */             } 
/*     */             sb.append("\t").append(previous.toString()).append("\n");
/*     */           } 
/*     */           sb.append("\t").append(stack[stack.length - 1].toString()).append("\n");
/*     */           return sb.toString();
/*     */         };
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class SharedSecretsCallSiteSupplierFactory
/*     */     implements Supplier<Supplier<String>>
/*     */   {
/*     */     public Supplier<String> get() {
/* 173 */       return new TracingException();
/*     */     }
/*     */     
/*     */     static class TracingException
/*     */       extends Throwable implements Supplier<String> {
/* 178 */       static final JavaLangAccess javaLangAccess = SharedSecrets.getJavaLangAccess();
/*     */ 
/*     */       
/*     */       public String get() {
/* 182 */         int stackTraceDepth = javaLangAccess.getStackTraceDepth(this);
/*     */         
/* 184 */         StackTraceElement previousElement = null;
/*     */         
/* 186 */         for (int i = 2; i < stackTraceDepth; i++) {
/* 187 */           StackTraceElement e = javaLangAccess.getStackTraceElement(this, i);
/*     */           
/* 189 */           String className = e.getClassName();
/* 190 */           if (Traces.isUserCode(className)) {
/* 191 */             StringBuilder sb = new StringBuilder();
/*     */             
/* 193 */             if (previousElement != null) {
/* 194 */               sb.append("\t").append(previousElement.toString()).append("\n");
/*     */             }
/* 196 */             sb.append("\t").append(e.toString()).append("\n");
/* 197 */             return sb.toString();
/*     */           } 
/*     */           
/* 200 */           if (Traces.full || e.getLineNumber() > 1) {
/*     */ 
/*     */ 
/*     */             
/* 204 */             String classAndMethod = className + "." + e.getMethodName();
/* 205 */             if (Traces.full || !Traces.shouldSanitize(classAndMethod))
/*     */             {
/*     */               
/* 208 */               previousElement = e;
/*     */             }
/*     */           } 
/*     */         } 
/* 212 */         return "";
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class ExceptionCallSiteSupplierFactory
/*     */     implements Supplier<Supplier<String>>
/*     */   {
/*     */     public Supplier<String> get() {
/* 222 */       return new TracingException();
/*     */     }
/*     */     
/*     */     static class TracingException
/*     */       extends Throwable
/*     */       implements Supplier<String> {
/*     */       public String get() {
/* 229 */         StackTraceElement previousElement = null;
/* 230 */         StackTraceElement[] stackTrace = getStackTrace();
/*     */         
/* 232 */         for (int i = 2; i < stackTrace.length; i++) {
/* 233 */           StackTraceElement e = stackTrace[i];
/*     */           
/* 235 */           String className = e.getClassName();
/* 236 */           if (Traces.isUserCode(className)) {
/* 237 */             StringBuilder sb = new StringBuilder();
/*     */             
/* 239 */             if (previousElement != null) {
/* 240 */               sb.append("\t").append(previousElement.toString()).append("\n");
/*     */             }
/* 242 */             sb.append("\t").append(e.toString()).append("\n");
/* 243 */             return sb.toString();
/*     */           } 
/*     */           
/* 246 */           if (Traces.full || e.getLineNumber() > 1) {
/*     */ 
/*     */ 
/*     */             
/* 250 */             String classAndMethod = className + "." + e.getMethodName();
/* 251 */             if (Traces.full || !Traces.shouldSanitize(classAndMethod))
/*     */             {
/*     */               
/* 254 */               previousElement = e;
/*     */             }
/*     */           } 
/*     */         } 
/* 258 */         return "";
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean shouldSanitize(String stackTraceRow) {
/* 271 */     return (stackTraceRow.startsWith("java.util.function") || stackTraceRow
/* 272 */       .startsWith("reactor.core.publisher.Mono.onAssembly") || stackTraceRow
/* 273 */       .equals("reactor.core.publisher.Mono.onAssembly") || stackTraceRow
/* 274 */       .equals("reactor.core.publisher.Flux.onAssembly") || stackTraceRow
/* 275 */       .equals("reactor.core.publisher.ParallelFlux.onAssembly") || stackTraceRow
/* 276 */       .startsWith("reactor.core.publisher.SignalLogger") || stackTraceRow
/* 277 */       .startsWith("reactor.core.publisher.FluxOnAssembly") || stackTraceRow
/* 278 */       .startsWith("reactor.core.publisher.MonoOnAssembly.") || stackTraceRow
/* 279 */       .startsWith("reactor.core.publisher.MonoCallableOnAssembly.") || stackTraceRow
/* 280 */       .startsWith("reactor.core.publisher.FluxCallableOnAssembly.") || stackTraceRow
/* 281 */       .startsWith("reactor.core.publisher.Hooks") || stackTraceRow
/* 282 */       .startsWith("sun.reflect") || stackTraceRow
/* 283 */       .startsWith("java.util.concurrent.ThreadPoolExecutor") || stackTraceRow
/* 284 */       .startsWith("java.lang.reflect"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String extractOperatorAssemblyInformation(String source) {
/* 309 */     String[] parts = extractOperatorAssemblyInformationParts(source);
/* 310 */     switch (parts.length) {
/*     */       case 0:
/* 312 */         return "[no operator assembly information]";
/*     */     } 
/* 314 */     return String.join(" ⇢ ", (CharSequence[])parts);
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isUserCode(String line) {
/* 319 */     return (!line.startsWith("reactor.core.publisher") || line.contains("Test"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String[] extractOperatorAssemblyInformationParts(String source) {
/* 345 */     String userCodeLine, uncleanTraces[] = source.split("\n");
/*     */ 
/*     */ 
/*     */     
/* 349 */     List<String> traces = (List<String>)Stream.<String>of(uncleanTraces).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
/*     */     
/* 351 */     if (traces.isEmpty()) {
/* 352 */       return new String[0];
/*     */     }
/*     */     
/* 355 */     int i = 0;
/* 356 */     while (i < traces.size() && !isUserCode(traces.get(i))) {
/* 357 */       i++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 362 */     if (i == 0) {
/*     */       
/* 364 */       apiLine = "";
/* 365 */       userCodeLine = traces.get(0);
/*     */     }
/* 367 */     else if (i == traces.size()) {
/*     */       
/* 369 */       apiLine = "";
/* 370 */       userCodeLine = ((String)traces.get(i - 1)).replaceFirst("reactor.core.publisher.", "");
/*     */     }
/*     */     else {
/*     */       
/* 374 */       apiLine = traces.get(i - 1);
/* 375 */       userCodeLine = traces.get(i);
/*     */     } 
/*     */ 
/*     */     
/* 379 */     if (apiLine.isEmpty()) return new String[] { userCodeLine };
/*     */     
/* 381 */     int linePartIndex = apiLine.indexOf('(');
/* 382 */     if (linePartIndex > 0) {
/* 383 */       apiLine = apiLine.substring(0, linePartIndex);
/*     */     }
/* 385 */     String apiLine = apiLine.replaceFirst("reactor.core.publisher.", "");
/*     */     
/* 387 */     return new String[] { apiLine, "at " + userCodeLine };
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\Traces.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */