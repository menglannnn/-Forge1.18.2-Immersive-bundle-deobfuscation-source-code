/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongArray;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelSource<T>
/*     */   extends ParallelFlux<T>
/*     */   implements Scannable
/*     */ {
/*     */   final Publisher<? extends T> source;
/*     */   final int parallelism;
/*     */   final int prefetch;
/*     */   final Supplier<Queue<T>> queueSupplier;
/*     */   
/*     */   ParallelSource(Publisher<? extends T> source, int parallelism, int prefetch, Supplier<Queue<T>> queueSupplier) {
/*  51 */     if (parallelism <= 0) {
/*  52 */       throw new IllegalArgumentException("parallelism > 0 required but it was " + parallelism);
/*     */     }
/*  54 */     if (prefetch <= 0) {
/*  55 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*     */     }
/*  57 */     this.source = source;
/*  58 */     this.parallelism = parallelism;
/*  59 */     this.prefetch = prefetch;
/*  60 */     this.queueSupplier = queueSupplier;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  65 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/*  70 */     return this.parallelism;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  76 */     if (key == Scannable.Attr.PARENT) return this.source; 
/*  77 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/*  78 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/*  85 */     if (!validate((Subscriber<?>[])subscribers)) {
/*     */       return;
/*     */     }
/*     */     
/*  89 */     this.source.subscribe((Subscriber)new ParallelSourceMain<>(subscribers, this.prefetch, this.queueSupplier));
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ParallelSourceMain<T>
/*     */     implements InnerConsumer<T>
/*     */   {
/*     */     final CoreSubscriber<? super T>[] subscribers;
/*     */     
/*     */     final AtomicLongArray requests;
/*     */     
/*     */     final long[] emissions;
/*     */     
/*     */     final int prefetch;
/*     */     
/*     */     final int limit;
/*     */     
/*     */     final Supplier<Queue<T>> queueSupplier;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     Queue<T> queue;
/*     */     
/*     */     Throwable error;
/*     */     
/*     */     volatile boolean done;
/*     */     
/*     */     int index;
/*     */     
/*     */     volatile boolean cancelled;
/*     */     
/*     */     volatile int wip;
/* 121 */     static final AtomicIntegerFieldUpdater<ParallelSourceMain> WIP = AtomicIntegerFieldUpdater.newUpdater(ParallelSourceMain.class, "wip");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile int subscriberCount;
/*     */ 
/*     */ 
/*     */     
/* 130 */     static final AtomicIntegerFieldUpdater<ParallelSourceMain> SUBSCRIBER_COUNT = AtomicIntegerFieldUpdater.newUpdater(ParallelSourceMain.class, "subscriberCount");
/*     */     
/*     */     int produced;
/*     */     
/*     */     int sourceMode;
/*     */ 
/*     */     
/*     */     ParallelSourceMain(CoreSubscriber<? super T>[] subscribers, int prefetch, Supplier<Queue<T>> queueSupplier) {
/* 138 */       this.subscribers = subscribers;
/* 139 */       this.prefetch = prefetch;
/* 140 */       this.queueSupplier = queueSupplier;
/* 141 */       this.limit = Operators.unboundedOrLimit(prefetch);
/* 142 */       this.requests = new AtomicLongArray(subscribers.length);
/* 143 */       this.emissions = new long[subscribers.length];
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 149 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 150 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 151 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 152 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/* 153 */       if (key == Scannable.Attr.ERROR) return this.error; 
/* 154 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 155 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 157 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/* 162 */       return Stream.<CoreSubscriber<? super T>>of(this.subscribers).map(Scannable::from);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 167 */       return this.subscribers[0].currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 172 */       if (Operators.validate(this.s, s)) {
/* 173 */         this.s = s;
/*     */         
/* 175 */         if (s instanceof Fuseable.QueueSubscription) {
/*     */           
/* 177 */           Fuseable.QueueSubscription<T> qs = (Fuseable.QueueSubscription<T>)s;
/*     */           
/* 179 */           int m = qs.requestFusion(7);
/*     */           
/* 181 */           if (m == 1) {
/* 182 */             this.sourceMode = m;
/* 183 */             this.queue = (Queue<T>)qs;
/* 184 */             this.done = true;
/* 185 */             setupSubscribers();
/* 186 */             drain();
/*     */             return;
/*     */           } 
/* 189 */           if (m == 2) {
/* 190 */             this.sourceMode = m;
/* 191 */             this.queue = (Queue<T>)qs;
/*     */             
/* 193 */             setupSubscribers();
/*     */             
/* 195 */             s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */         
/* 201 */         this.queue = this.queueSupplier.get();
/*     */         
/* 203 */         setupSubscribers();
/*     */         
/* 205 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */       } 
/*     */     }
/*     */     
/*     */     void setupSubscribers() {
/* 210 */       int m = this.subscribers.length;
/*     */       
/* 212 */       for (int i = 0; i < m; i++) {
/* 213 */         if (this.cancelled) {
/*     */           return;
/*     */         }
/* 216 */         int j = i;
/*     */         
/* 218 */         SUBSCRIBER_COUNT.lazySet(this, i + 1);
/*     */         
/* 220 */         this.subscribers[i].onSubscribe(new ParallelSourceInner<>(this, j, m));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 226 */       if (this.done) {
/* 227 */         Operators.onNextDropped(t, currentContext());
/*     */         return;
/*     */       } 
/* 230 */       if (this.sourceMode == 0 && 
/* 231 */         !this.queue.offer(t)) {
/* 232 */         onError(Operators.onOperatorError(this.s, Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 236 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 241 */       if (this.done) {
/* 242 */         Operators.onErrorDropped(t, currentContext());
/*     */         return;
/*     */       } 
/* 245 */       this.error = t;
/* 246 */       this.done = true;
/* 247 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 252 */       if (this.done) {
/*     */         return;
/*     */       }
/* 255 */       this.done = true;
/* 256 */       drain();
/*     */     }
/*     */     
/*     */     void cancel() {
/* 260 */       if (!this.cancelled) {
/* 261 */         this.cancelled = true;
/* 262 */         this.s.cancel();
/*     */         
/* 264 */         if (WIP.getAndIncrement(this) == 0) {
/* 265 */           this.queue.clear();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void drainAsync() {
/* 271 */       int missed = 1;
/*     */       
/* 273 */       Queue<T> q = this.queue;
/* 274 */       CoreSubscriber<? super T>[] a = this.subscribers;
/* 275 */       AtomicLongArray r = this.requests;
/* 276 */       long[] e = this.emissions;
/* 277 */       int n = e.length;
/* 278 */       int idx = this.index;
/* 279 */       int consumed = this.produced;
/*     */ 
/*     */       
/*     */       while (true) {
/* 283 */         int notReady = 0;
/*     */         
/*     */         do {
/* 286 */           if (this.cancelled) {
/* 287 */             q.clear();
/*     */             
/*     */             return;
/*     */           } 
/* 291 */           boolean d = this.done;
/* 292 */           if (d) {
/* 293 */             Throwable ex = this.error;
/* 294 */             if (ex != null) {
/* 295 */               q.clear();
/* 296 */               for (CoreSubscriber<? super T> coreSubscriber : a) {
/* 297 */                 coreSubscriber.onError(ex);
/*     */               }
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 303 */           boolean empty = q.isEmpty();
/*     */           
/* 305 */           if (d && empty) {
/* 306 */             for (CoreSubscriber<? super T> coreSubscriber : a) {
/* 307 */               coreSubscriber.onComplete();
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/* 312 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 316 */           long ridx = r.get(idx);
/* 317 */           long eidx = e[idx];
/* 318 */           if (ridx != eidx) {
/*     */             T v;
/*     */ 
/*     */             
/*     */             try {
/* 323 */               v = q.poll();
/* 324 */             } catch (Throwable ex) {
/* 325 */               ex = Operators.onOperatorError(this.s, ex, a[idx].currentContext());
/* 326 */               for (CoreSubscriber<? super T> coreSubscriber : a) {
/* 327 */                 coreSubscriber.onError(ex);
/*     */               }
/*     */               
/*     */               return;
/*     */             } 
/* 332 */             if (v == null) {
/*     */               break;
/*     */             }
/*     */             
/* 336 */             a[idx].onNext(v);
/*     */             
/* 338 */             e[idx] = eidx + 1L;
/*     */             
/* 340 */             int c = ++consumed;
/* 341 */             if (c == this.limit) {
/* 342 */               consumed = 0;
/* 343 */               this.s.request(c);
/*     */             } 
/* 345 */             notReady = 0;
/*     */           } else {
/* 347 */             notReady++;
/*     */           } 
/*     */           
/* 350 */           idx++;
/* 351 */           if (idx != n)
/* 352 */             continue;  idx = 0;
/*     */         
/*     */         }
/* 355 */         while (notReady != n);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 360 */         int w = this.wip;
/* 361 */         if (w == missed) {
/* 362 */           this.index = idx;
/* 363 */           this.produced = consumed;
/* 364 */           missed = WIP.addAndGet(this, -missed);
/* 365 */           if (missed == 0)
/*     */             break; 
/*     */           continue;
/*     */         } 
/* 369 */         missed = w;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void drainSync() {
/* 375 */       int missed = 1;
/*     */       
/* 377 */       Queue<T> q = this.queue;
/* 378 */       CoreSubscriber<? super T>[] a = this.subscribers;
/* 379 */       AtomicLongArray r = this.requests;
/* 380 */       long[] e = this.emissions;
/* 381 */       int n = e.length;
/* 382 */       int idx = this.index;
/*     */ 
/*     */       
/*     */       while (true) {
/* 386 */         int notReady = 0;
/*     */         
/*     */         do {
/* 389 */           if (this.cancelled) {
/* 390 */             q.clear();
/*     */             
/*     */             return;
/*     */           } 
/* 394 */           if (q.isEmpty()) {
/* 395 */             for (CoreSubscriber<? super T> coreSubscriber : a) {
/* 396 */               coreSubscriber.onComplete();
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/* 401 */           long ridx = r.get(idx);
/* 402 */           long eidx = e[idx];
/* 403 */           if (ridx != eidx) {
/*     */             T v;
/*     */ 
/*     */             
/*     */             try {
/* 408 */               v = q.poll();
/* 409 */             } catch (Throwable ex) {
/* 410 */               ex = Operators.onOperatorError(this.s, ex, a[idx].currentContext());
/* 411 */               for (CoreSubscriber<? super T> coreSubscriber : a) {
/* 412 */                 coreSubscriber.onError(ex);
/*     */               }
/*     */               
/*     */               return;
/*     */             } 
/* 417 */             if (v == null) {
/* 418 */               for (CoreSubscriber<? super T> coreSubscriber : a) {
/* 419 */                 coreSubscriber.onComplete();
/*     */               }
/*     */               
/*     */               return;
/*     */             } 
/* 424 */             a[idx].onNext(v);
/*     */             
/* 426 */             e[idx] = eidx + 1L;
/*     */             
/* 428 */             notReady = 0;
/*     */           } else {
/* 430 */             notReady++;
/*     */           } 
/*     */           
/* 433 */           idx++;
/* 434 */           if (idx != n)
/* 435 */             continue;  idx = 0;
/*     */         
/*     */         }
/* 438 */         while (notReady != n);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 443 */         int w = this.wip;
/* 444 */         if (w == missed) {
/* 445 */           this.index = idx;
/* 446 */           missed = WIP.addAndGet(this, -missed);
/* 447 */           if (missed == 0)
/*     */             break; 
/*     */           continue;
/*     */         } 
/* 451 */         missed = w;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void drain() {
/* 457 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 461 */       if (this.sourceMode == 1) {
/* 462 */         drainSync();
/*     */       } else {
/* 464 */         drainAsync();
/*     */       } 
/*     */     }
/*     */     
/*     */     static final class ParallelSourceInner<T>
/*     */       implements InnerProducer<T>
/*     */     {
/*     */       final ParallelSource.ParallelSourceMain<T> parent;
/*     */       final int index;
/*     */       final int length;
/*     */       
/*     */       ParallelSourceInner(ParallelSource.ParallelSourceMain<T> parent, int index, int length) {
/* 476 */         this.index = index;
/* 477 */         this.length = length;
/* 478 */         this.parent = parent;
/*     */       }
/*     */ 
/*     */       
/*     */       public CoreSubscriber<? super T> actual() {
/* 483 */         return this.parent.subscribers[this.index];
/*     */       }
/*     */ 
/*     */       
/*     */       @Nullable
/*     */       public Object scanUnsafe(Scannable.Attr key) {
/* 489 */         if (key == Scannable.Attr.PARENT) return this.parent; 
/* 490 */         if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */         
/* 492 */         return super.scanUnsafe(key);
/*     */       }
/*     */ 
/*     */       
/*     */       public void request(long n) {
/* 497 */         if (Operators.validate(n)) {
/* 498 */           long r, u; AtomicLongArray ra = this.parent.requests;
/*     */           do {
/* 500 */             r = ra.get(this.index);
/* 501 */             if (r == Long.MAX_VALUE) {
/*     */               return;
/*     */             }
/* 504 */             u = Operators.addCap(r, n);
/* 505 */           } while (!ra.compareAndSet(this.index, r, u));
/*     */ 
/*     */ 
/*     */           
/* 509 */           if (this.parent.subscriberCount == this.length) {
/* 510 */             this.parent.drain();
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public void cancel() {
/* 517 */         this.parent.cancel();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ParallelSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */