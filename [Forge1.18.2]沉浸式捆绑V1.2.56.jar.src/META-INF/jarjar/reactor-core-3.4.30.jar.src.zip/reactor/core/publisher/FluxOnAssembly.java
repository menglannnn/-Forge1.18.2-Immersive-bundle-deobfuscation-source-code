/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxOnAssembly<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */   implements Fuseable, AssemblyOp
/*     */ {
/*     */   final AssemblySnapshot snapshotStack;
/*     */   
/*     */   FluxOnAssembly(Flux<? extends T> source, AssemblySnapshot snapshotStack) {
/*  72 */     super(source);
/*  73 */     this.snapshotStack = snapshotStack;
/*     */   }
/*     */ 
/*     */   
/*     */   public String stepName() {
/*  78 */     return this.snapshotStack.operatorAssemblyInformation();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  83 */     if (key == Scannable.Attr.ACTUAL_METADATA) return Boolean.valueOf(!this.snapshotStack.isCheckpoint); 
/*  84 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  86 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  91 */     return this.snapshotStack.operatorAssemblyInformation();
/*     */   }
/*     */   
/*     */   static void fillStacktraceHeader(StringBuilder sb, Class<?> sourceClass, @Nullable String description) {
/*  95 */     sb.append("\nAssembly trace from producer [")
/*  96 */       .append(sourceClass.getName())
/*  97 */       .append("]");
/*     */     
/*  99 */     if (description != null) {
/* 100 */       sb.append(", described as [")
/* 101 */         .append(description)
/* 102 */         .append("]");
/*     */     }
/* 104 */     sb.append(" :\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> CoreSubscriber<? super T> wrapSubscriber(CoreSubscriber<? super T> actual, Flux<? extends T> source, Publisher<?> current, @Nullable AssemblySnapshot snapshotStack) {
/* 112 */     if (snapshotStack != null) {
/* 113 */       if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 114 */         Fuseable.ConditionalSubscriber<? super T> cs = (Fuseable.ConditionalSubscriber<? super T>)actual;
/* 115 */         return new OnAssemblyConditionalSubscriber<>(cs, snapshotStack, (Publisher<?>)source, current);
/*     */       } 
/*     */       
/* 118 */       return new OnAssemblySubscriber<>(actual, snapshotStack, (Publisher<?>)source, current);
/*     */     } 
/*     */ 
/*     */     
/* 122 */     return actual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 129 */     return wrapSubscriber(actual, this.source, (Publisher<?>)this, this.snapshotStack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class AssemblySnapshot
/*     */   {
/*     */     final boolean isCheckpoint;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     final String description;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     final Supplier<String> assemblyInformationSupplier;
/*     */     
/*     */     String cached;
/*     */ 
/*     */     
/*     */     AssemblySnapshot(@Nullable String description, Supplier<String> assemblyInformationSupplier) {
/* 150 */       this((description != null), description, assemblyInformationSupplier);
/*     */     }
/*     */     
/*     */     AssemblySnapshot(String assemblyInformation) {
/* 154 */       this.isCheckpoint = false;
/* 155 */       this.description = null;
/* 156 */       this.assemblyInformationSupplier = null;
/* 157 */       this.cached = assemblyInformation;
/*     */     }
/*     */ 
/*     */     
/*     */     private AssemblySnapshot(boolean isCheckpoint, @Nullable String description, @Nullable Supplier<String> assemblyInformationSupplier) {
/* 162 */       this.isCheckpoint = isCheckpoint;
/* 163 */       this.description = description;
/* 164 */       this.assemblyInformationSupplier = assemblyInformationSupplier;
/*     */     }
/*     */     
/*     */     public boolean hasDescription() {
/* 168 */       return (this.description != null);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String getDescription() {
/* 173 */       return this.description;
/*     */     }
/*     */     
/*     */     public boolean isCheckpoint() {
/* 177 */       return this.isCheckpoint;
/*     */     }
/*     */     
/*     */     public boolean isLight() {
/* 181 */       return false;
/*     */     }
/*     */     
/*     */     public String lightPrefix() {
/* 185 */       return "";
/*     */     }
/*     */     
/*     */     String toAssemblyInformation() {
/* 189 */       if (this.cached == null) {
/* 190 */         if (this.assemblyInformationSupplier == null) {
/* 191 */           throw new IllegalStateException("assemblyInformation must either be supplied or resolvable");
/*     */         }
/* 193 */         this.cached = this.assemblyInformationSupplier.get();
/*     */       } 
/* 195 */       return this.cached;
/*     */     }
/*     */     
/*     */     String operatorAssemblyInformation() {
/* 199 */       return Traces.extractOperatorAssemblyInformation(toAssemblyInformation());
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CheckpointLightSnapshot
/*     */     extends AssemblySnapshot {
/*     */     CheckpointLightSnapshot(@Nullable String description) {
/* 206 */       super(true, description, null);
/* 207 */       this.cached = "checkpoint(\"" + ((description == null) ? "" : description) + "\")";
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isLight() {
/* 212 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public String lightPrefix() {
/* 217 */       return "checkpoint";
/*     */     }
/*     */ 
/*     */     
/*     */     String operatorAssemblyInformation() {
/* 222 */       return this.cached;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CheckpointHeavySnapshot
/*     */     extends AssemblySnapshot
/*     */   {
/*     */     CheckpointHeavySnapshot(@Nullable String description, Supplier<String> assemblyInformationSupplier) {
/* 230 */       super(true, description, assemblyInformationSupplier);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String lightPrefix() {
/* 239 */       return "checkpoint(" + ((this.description == null) ? "" : this.description) + ")";
/*     */     }
/*     */   }
/*     */   
/*     */   static final class MethodReturnSnapshot
/*     */     extends AssemblySnapshot {
/*     */     MethodReturnSnapshot(String method) {
/* 246 */       super(false, method, null);
/* 247 */       this.cached = method;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isLight() {
/* 252 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     String operatorAssemblyInformation() {
/* 257 */       return this.cached;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ObservedAtInformationNode
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     final int id;
/*     */     final String operator;
/*     */     final String message;
/*     */     int occurrenceCounter;
/*     */     @Nullable
/*     */     ObservedAtInformationNode parent;
/*     */     Set<ObservedAtInformationNode> children;
/*     */     
/*     */     ObservedAtInformationNode(int id, String operator, String message) {
/* 275 */       this.id = id;
/* 276 */       this.operator = operator;
/* 277 */       this.message = message;
/* 278 */       this.occurrenceCounter = 0;
/* 279 */       this.children = new LinkedHashSet<>();
/*     */     }
/*     */     
/*     */     void incrementCount() {
/* 283 */       this.occurrenceCounter++;
/*     */     }
/*     */     
/*     */     void addNode(ObservedAtInformationNode node) {
/* 287 */       if (this == node) {
/*     */         return;
/*     */       }
/* 290 */       if (this.children.add(node)) {
/* 291 */         node.parent = this;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 297 */       if (this == o) {
/* 298 */         return true;
/*     */       }
/* 300 */       if (o == null || getClass() != o.getClass()) {
/* 301 */         return false;
/*     */       }
/* 303 */       ObservedAtInformationNode node = (ObservedAtInformationNode)o;
/* 304 */       return (this.id == node.id && this.operator.equals(node.operator) && this.message.equals(node.message));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 309 */       return Objects.hash(new Object[] { Integer.valueOf(this.id), this.operator, this.message });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 314 */       return this.operator + "{@" + this.id + (
/*     */         
/* 316 */         this.children.isEmpty() ? "" : (", " + this.children.size() + " children")) + '}';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class OnAssemblyException
/*     */     extends RuntimeException
/*     */   {
/*     */     private static final long serialVersionUID = -6342981676020433721L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     final Map<Integer, FluxOnAssembly.ObservedAtInformationNode> nodesPerId = new HashMap<>();
/* 336 */     final FluxOnAssembly.ObservedAtInformationNode root = new FluxOnAssembly.ObservedAtInformationNode(-1, "ROOT", "ROOT");
/* 337 */     int maxOperatorSize = 0;
/*     */     
/*     */     OnAssemblyException(String message) {
/* 340 */       super(message);
/*     */     }
/*     */ 
/*     */     
/*     */     public Throwable fillInStackTrace() {
/* 345 */       return this;
/*     */     }
/*     */     
/*     */     void add(Publisher<?> parent, Publisher<?> current, FluxOnAssembly.AssemblySnapshot snapshot) {
/* 349 */       if (snapshot.isCheckpoint()) {
/* 350 */         if (snapshot.isLight()) {
/* 351 */           add(parent, current, snapshot.lightPrefix(), Objects.<String>requireNonNull(snapshot.getDescription()));
/*     */         } else {
/*     */           
/* 354 */           String assemblyInformation = snapshot.toAssemblyInformation();
/* 355 */           String[] parts = Traces.extractOperatorAssemblyInformationParts(assemblyInformation);
/*     */           
/* 357 */           if (parts.length > 0) {
/*     */             
/* 359 */             String line = parts[parts.length - 1];
/* 360 */             add(parent, current, snapshot.lightPrefix(), line);
/*     */           }
/*     */           else {
/*     */             
/* 364 */             add(parent, current, snapshot.lightPrefix(), Objects.<String>requireNonNull(snapshot.getDescription()));
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 369 */         String assemblyInformation = snapshot.toAssemblyInformation();
/* 370 */         String[] parts = Traces.extractOperatorAssemblyInformationParts(assemblyInformation);
/* 371 */         if (parts.length > 0) {
/* 372 */           String prefix = (parts.length > 1) ? parts[0] : "";
/* 373 */           String line = parts[parts.length - 1];
/*     */           
/* 375 */           add(parent, current, prefix, line);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void add(Publisher<?> operator, Publisher<?> currentAssembly, String prefix, String line) {
/* 385 */       Scannable parentAssembly = Scannable.from(currentAssembly).parents().filter(s -> s instanceof AssemblyOp).findFirst().orElse(null);
/*     */       
/* 387 */       int thisId = System.identityHashCode(currentAssembly);
/* 388 */       int parentId = System.identityHashCode(parentAssembly);
/*     */ 
/*     */       
/* 391 */       synchronized (this.nodesPerId) {
/* 392 */         FluxOnAssembly.ObservedAtInformationNode thisNode = this.nodesPerId.get(Integer.valueOf(thisId));
/* 393 */         if (thisNode != null) {
/* 394 */           thisNode.incrementCount();
/*     */         } else {
/*     */           
/* 397 */           thisNode = new FluxOnAssembly.ObservedAtInformationNode(thisId, prefix, line);
/* 398 */           this.nodesPerId.put(Integer.valueOf(thisId), thisNode);
/*     */         } 
/*     */         
/* 401 */         if (parentAssembly == null) {
/* 402 */           this.root.addNode(thisNode);
/*     */         } else {
/*     */           
/* 405 */           FluxOnAssembly.ObservedAtInformationNode parentNode = this.nodesPerId.get(Integer.valueOf(parentId));
/* 406 */           if (parentNode != null) {
/* 407 */             parentNode.addNode(thisNode);
/*     */           } else {
/*     */             
/* 410 */             this.root.addNode(thisNode);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 415 */         int length = thisNode.operator.length();
/* 416 */         if (length > this.maxOperatorSize) {
/* 417 */           this.maxOperatorSize = length;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void findPathToLeaves(FluxOnAssembly.ObservedAtInformationNode node, List<List<FluxOnAssembly.ObservedAtInformationNode>> rootPaths) {
/* 423 */       if (node.children.isEmpty()) {
/* 424 */         List<FluxOnAssembly.ObservedAtInformationNode> pathForLeaf = new LinkedList<>();
/* 425 */         FluxOnAssembly.ObservedAtInformationNode traversed = node;
/* 426 */         while (traversed != null && traversed != this.root) {
/* 427 */           pathForLeaf.add(0, traversed);
/* 428 */           traversed = traversed.parent;
/*     */         } 
/* 430 */         rootPaths.add(pathForLeaf);
/*     */         return;
/*     */       } 
/* 433 */       node.children.forEach(n -> findPathToLeaves(n, rootPaths));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getMessage() {
/* 439 */       synchronized (this.nodesPerId) {
/* 440 */         if (this.root.children.isEmpty()) {
/* 441 */           return super.getMessage();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 447 */         StringBuilder sb = (new StringBuilder(super.getMessage())).append(System.lineSeparator()).append("Error has been observed at the following site(s):").append(System.lineSeparator());
/*     */         
/* 449 */         List<List<FluxOnAssembly.ObservedAtInformationNode>> rootPaths = new ArrayList<>();
/* 450 */         this.root.children.forEach(actualRoot -> findPathToLeaves(actualRoot, rootPaths));
/*     */         
/* 452 */         rootPaths.forEach(path -> path.forEach(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 475 */         sb.append("Original Stack Trace:");
/* 476 */         return sb.toString();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 482 */       String message = getLocalizedMessage();
/* 483 */       if (message == null) {
/* 484 */         return "The stacktrace should have been enhanced by Reactor, but there was no message in OnAssemblyException";
/*     */       }
/* 486 */       return "The stacktrace has been enhanced by Reactor, refer to additional information below: " + message;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class OnAssemblySubscriber<T>
/*     */     implements InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final FluxOnAssembly.AssemblySnapshot snapshotStack;
/*     */     
/*     */     final Publisher<?> parent;
/*     */     
/*     */     final Publisher<?> current;
/*     */     
/*     */     final CoreSubscriber<? super T> actual;
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     Subscription s;
/*     */     int fusionMode;
/*     */     
/*     */     OnAssemblySubscriber(CoreSubscriber<? super T> actual, FluxOnAssembly.AssemblySnapshot snapshotStack, Publisher<?> parent, Publisher<?> current) {
/* 506 */       this.actual = actual;
/* 507 */       this.snapshotStack = snapshotStack;
/* 508 */       this.parent = parent;
/* 509 */       this.current = current;
/*     */     }
/*     */ 
/*     */     
/*     */     public final CoreSubscriber<? super T> actual() {
/* 514 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 520 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 521 */       if (key == Scannable.Attr.ACTUAL_METADATA) return Boolean.valueOf(!this.snapshotStack.isCheckpoint); 
/* 522 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 524 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 529 */       return this.snapshotStack.operatorAssemblyInformation();
/*     */     }
/*     */ 
/*     */     
/*     */     public String stepName() {
/* 534 */       return toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onNext(T t) {
/* 539 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onError(Throwable t) {
/* 544 */       this.actual.onError(fail(t));
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onComplete() {
/* 549 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public final int requestFusion(int requestedMode) {
/* 554 */       Fuseable.QueueSubscription<T> qs = this.qs;
/* 555 */       if (qs != null) {
/* 556 */         int m = qs.requestFusion(requestedMode);
/* 557 */         if (m != 0) {
/* 558 */           this.fusionMode = m;
/*     */         }
/* 560 */         return m;
/*     */       } 
/* 562 */       return 0;
/*     */     }
/*     */     
/*     */     final Throwable fail(Throwable t) {
/* 566 */       boolean lightCheckpoint = this.snapshotStack.isLight();
/*     */       
/* 568 */       FluxOnAssembly.OnAssemblyException onAssemblyException = null;
/* 569 */       for (Throwable e : t.getSuppressed()) {
/* 570 */         if (e instanceof FluxOnAssembly.OnAssemblyException) {
/* 571 */           onAssemblyException = (FluxOnAssembly.OnAssemblyException)e;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 576 */       if (onAssemblyException == null) {
/* 577 */         if (lightCheckpoint) {
/* 578 */           onAssemblyException = new FluxOnAssembly.OnAssemblyException("");
/*     */         } else {
/*     */           
/* 581 */           StringBuilder sb = new StringBuilder();
/* 582 */           FluxOnAssembly.fillStacktraceHeader(sb, this.parent.getClass(), this.snapshotStack.getDescription());
/* 583 */           sb.append(this.snapshotStack.toAssemblyInformation().replaceFirst("\\n$", ""));
/* 584 */           String description = sb.toString();
/* 585 */           onAssemblyException = new FluxOnAssembly.OnAssemblyException(description);
/*     */         } 
/*     */         
/* 588 */         t = Exceptions.addSuppressed(t, onAssemblyException);
/* 589 */         StackTraceElement[] stackTrace = t.getStackTrace();
/* 590 */         if (stackTrace.length > 0) {
/* 591 */           StackTraceElement[] newStackTrace = new StackTraceElement[stackTrace.length];
/* 592 */           int i = 0;
/* 593 */           for (StackTraceElement stackTraceElement : stackTrace) {
/* 594 */             String className = stackTraceElement.getClassName();
/*     */             
/* 596 */             if (!className.startsWith("reactor.core.publisher.") || !className.contains("OnAssembly")) {
/*     */ 
/*     */ 
/*     */               
/* 600 */               newStackTrace[i] = stackTraceElement;
/* 601 */               i++;
/*     */             } 
/* 603 */           }  newStackTrace = Arrays.<StackTraceElement>copyOf(newStackTrace, i);
/*     */           
/* 605 */           onAssemblyException.setStackTrace(newStackTrace);
/* 606 */           t.setStackTrace(new StackTraceElement[] { stackTrace[0] });
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 612 */       onAssemblyException.add(this.parent, this.current, this.snapshotStack);
/*     */       
/* 614 */       return t;
/*     */     }
/*     */ 
/*     */     
/*     */     public final boolean isEmpty() {
/*     */       try {
/* 620 */         return this.qs.isEmpty();
/*     */       }
/* 622 */       catch (Throwable ex) {
/* 623 */         Exceptions.throwIfFatal(ex);
/* 624 */         throw Exceptions.propagate(fail(ex));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public final void onSubscribe(Subscription s) {
/* 630 */       if (Operators.validate(this.s, s)) {
/* 631 */         this.s = s;
/* 632 */         this.qs = Operators.as(s);
/* 633 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public final int size() {
/* 639 */       return this.qs.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public final void clear() {
/* 644 */       this.qs.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public final void request(long n) {
/* 649 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public final void cancel() {
/* 654 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public final T poll() {
/*     */       try {
/* 661 */         return (T)this.qs.poll();
/*     */       }
/* 663 */       catch (Throwable ex) {
/* 664 */         Exceptions.throwIfFatal(ex);
/* 665 */         throw Exceptions.propagate(fail(ex));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class OnAssemblyConditionalSubscriber<T>
/*     */     extends OnAssemblySubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super T> actualCS;
/*     */     
/*     */     OnAssemblyConditionalSubscriber(Fuseable.ConditionalSubscriber<? super T> actual, FluxOnAssembly.AssemblySnapshot stacktrace, Publisher<?> parent, Publisher<?> current) {
/* 677 */       super((CoreSubscriber<? super T>)actual, stacktrace, parent, current);
/* 678 */       this.actualCS = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 683 */       return this.actualCS.tryOnNext(t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxOnAssembly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */