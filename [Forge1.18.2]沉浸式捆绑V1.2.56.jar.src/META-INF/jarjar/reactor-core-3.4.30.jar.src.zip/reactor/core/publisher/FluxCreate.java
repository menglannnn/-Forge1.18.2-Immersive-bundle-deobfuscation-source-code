/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.LongConsumer;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Disposables;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.concurrent.Queues;
/*      */ import reactor.util.context.Context;
/*      */ import reactor.util.context.ContextView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class FluxCreate<T>
/*      */   extends Flux<T>
/*      */   implements SourceProducer<T>
/*      */ {
/*      */   final Consumer<? super FluxSink<T>> source;
/*      */   final FluxSink.OverflowStrategy backpressure;
/*      */   final CreateMode createMode;
/*      */   
/*      */   enum CreateMode
/*      */   {
/*   51 */     PUSH_ONLY, PUSH_PULL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   FluxCreate(Consumer<? super FluxSink<T>> source, FluxSink.OverflowStrategy backpressure, CreateMode createMode) {
/*   63 */     this.source = Objects.<Consumer<? super FluxSink<T>>>requireNonNull(source, "source");
/*   64 */     this.backpressure = Objects.<FluxSink.OverflowStrategy>requireNonNull(backpressure, "backpressure");
/*   65 */     this.createMode = createMode;
/*      */   }
/*      */ 
/*      */   
/*      */   static <T> BaseSink<T> createSink(CoreSubscriber<? super T> t, FluxSink.OverflowStrategy backpressure) {
/*   70 */     switch (backpressure) {
/*      */       case IGNORE:
/*   72 */         return new IgnoreSink<>(t);
/*      */       
/*      */       case ERROR:
/*   75 */         return new ErrorAsyncSink<>(t);
/*      */       
/*      */       case DROP:
/*   78 */         return new DropAsyncSink<>(t);
/*      */       
/*      */       case LATEST:
/*   81 */         return new LatestAsyncSink<>(t);
/*      */     } 
/*      */     
/*   84 */     return new BufferAsyncSink<>(t, Queues.SMALL_BUFFER_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void subscribe(CoreSubscriber<? super T> actual) {
/*   91 */     BaseSink<T> sink = createSink(actual, this.backpressure);
/*      */     
/*   93 */     actual.onSubscribe(sink);
/*      */     try {
/*   95 */       this.source.accept((this.createMode == CreateMode.PUSH_PULL) ? new SerializedFluxSink<>(sink) : sink);
/*      */ 
/*      */     
/*      */     }
/*   99 */     catch (Throwable ex) {
/*  100 */       Exceptions.throwIfFatal(ex);
/*  101 */       sink.error(Operators.onOperatorError(ex, actual.currentContext()));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/*  107 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC; 
/*  108 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class SerializedFluxSink<T>
/*      */     implements FluxSink<T>, Scannable
/*      */   {
/*      */     final FluxCreate.BaseSink<T> sink;
/*      */ 
/*      */     
/*      */     volatile Throwable error;
/*      */ 
/*      */     
/*  123 */     static final AtomicReferenceFieldUpdater<SerializedFluxSink, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(SerializedFluxSink.class, Throwable.class, "error");
/*      */ 
/*      */ 
/*      */     
/*      */     volatile int wip;
/*      */ 
/*      */     
/*  130 */     static final AtomicIntegerFieldUpdater<SerializedFluxSink> WIP = AtomicIntegerFieldUpdater.newUpdater(SerializedFluxSink.class, "wip");
/*      */     
/*      */     final Queue<T> mpscQueue;
/*      */     
/*      */     volatile boolean done;
/*      */     
/*      */     SerializedFluxSink(FluxCreate.BaseSink<T> sink) {
/*  137 */       this.sink = sink;
/*  138 */       this.mpscQueue = Queues.unboundedMultiproducer().get();
/*      */     }
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public Context currentContext() {
/*  144 */       return this.sink.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public ContextView contextView() {
/*  149 */       return this.sink.contextView();
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> next(T t) {
/*  154 */       Objects.requireNonNull(t, "t is null in sink.next(t)");
/*  155 */       if (this.sink.isTerminated() || this.done) {
/*  156 */         Operators.onNextDropped(t, this.sink.currentContext());
/*  157 */         return this;
/*      */       } 
/*  159 */       if (WIP.get(this) == 0 && WIP.compareAndSet(this, 0, 1)) {
/*      */         try {
/*  161 */           this.sink.next(t);
/*      */         }
/*  163 */         catch (Throwable ex) {
/*  164 */           Operators.onOperatorError(this.sink, ex, t, this.sink.currentContext());
/*      */         } 
/*  166 */         if (WIP.decrementAndGet(this) == 0) {
/*  167 */           return this;
/*      */         }
/*      */       } else {
/*      */         
/*  171 */         this.mpscQueue.offer(t);
/*  172 */         if (WIP.getAndIncrement(this) != 0) {
/*  173 */           return this;
/*      */         }
/*      */       } 
/*  176 */       drainLoop();
/*  177 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public void error(Throwable t) {
/*  182 */       Objects.requireNonNull(t, "t is null in sink.error(t)");
/*  183 */       if (this.sink.isTerminated() || this.done) {
/*  184 */         Operators.onOperatorError(t, this.sink.currentContext());
/*      */         return;
/*      */       } 
/*  187 */       if (Exceptions.addThrowable(ERROR, this, t)) {
/*  188 */         this.done = true;
/*  189 */         drain();
/*      */       } else {
/*      */         
/*  192 */         Context ctx = this.sink.currentContext();
/*  193 */         Operators.onDiscardQueueWithClear(this.mpscQueue, ctx, null);
/*  194 */         Operators.onOperatorError(t, ctx);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void complete() {
/*  200 */       if (this.sink.isTerminated() || this.done) {
/*      */         return;
/*      */       }
/*  203 */       this.done = true;
/*  204 */       drain();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void drain() {
/*  212 */       if (WIP.getAndIncrement(this) == 0) {
/*  213 */         drainLoop();
/*      */       }
/*      */     }
/*      */     
/*      */     void drainLoop() {
/*  218 */       Context ctx = this.sink.currentContext();
/*  219 */       FluxCreate.BaseSink<T> e = this.sink;
/*  220 */       Queue<T> q = this.mpscQueue;
/*      */ 
/*      */       
/*      */       while (true) {
/*  224 */         while (e.isCancelled()) {
/*  225 */           Operators.onDiscardQueueWithClear(q, ctx, null);
/*  226 */           if (WIP.decrementAndGet(this) == 0) {
/*      */             return;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  234 */         if (ERROR.get(this) != null) {
/*  235 */           Operators.onDiscardQueueWithClear(q, ctx, null);
/*      */           
/*  237 */           e.error(Exceptions.terminate(ERROR, this));
/*      */           
/*      */           return;
/*      */         } 
/*  241 */         boolean d = this.done;
/*  242 */         T v = q.poll();
/*      */         
/*  244 */         boolean empty = (v == null);
/*      */         
/*  246 */         if (d && empty) {
/*  247 */           e.complete();
/*      */           
/*      */           return;
/*      */         } 
/*  251 */         if (empty) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  263 */           if (WIP.decrementAndGet(this) == 0)
/*      */             break;  continue;
/*      */         } 
/*      */         try {
/*      */           e.next(v);
/*      */         } catch (Throwable ex) {
/*      */           Operators.onOperatorError(this.sink, ex, v, this.sink.currentContext());
/*      */         } 
/*  271 */       }  } public FluxSink<T> onRequest(LongConsumer consumer) { this.sink.onRequest(consumer, consumer, this.sink.requested);
/*  272 */       return this; }
/*      */ 
/*      */ 
/*      */     
/*      */     public FluxSink<T> onCancel(Disposable d) {
/*  277 */       this.sink.onCancel(d);
/*  278 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> onDispose(Disposable d) {
/*  283 */       this.sink.onDispose(d);
/*  284 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public long requestedFromDownstream() {
/*  289 */       return this.sink.requestedFromDownstream();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isCancelled() {
/*  294 */       return this.sink.isCancelled();
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  300 */       if (key == Scannable.Attr.BUFFERED) {
/*  301 */         return Integer.valueOf(this.mpscQueue.size());
/*      */       }
/*  303 */       if (key == Scannable.Attr.ERROR) {
/*  304 */         return this.error;
/*      */       }
/*  306 */       if (key == Scannable.Attr.TERMINATED) {
/*  307 */         return Boolean.valueOf(this.done);
/*      */       }
/*      */       
/*  310 */       return this.sink.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  315 */       return this.sink.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class SerializeOnRequestSink<T>
/*      */     implements FluxSink<T>, Scannable
/*      */   {
/*      */     final FluxCreate.BaseSink<T> baseSink;
/*      */     
/*      */     FluxCreate.SerializedFluxSink<T> serializedSink;
/*      */     
/*      */     FluxSink<T> sink;
/*      */ 
/*      */     
/*      */     SerializeOnRequestSink(FluxCreate.BaseSink<T> sink) {
/*  332 */       this.baseSink = sink;
/*  333 */       this.sink = sink;
/*      */     }
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public Context currentContext() {
/*  339 */       return this.sink.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public ContextView contextView() {
/*  344 */       return this.sink.contextView();
/*      */     }
/*      */ 
/*      */     
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  349 */       return (this.serializedSink != null) ? this.serializedSink.scanUnsafe(key) : this.baseSink
/*  350 */         .scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void complete() {
/*  355 */       this.sink.complete();
/*      */     }
/*      */ 
/*      */     
/*      */     public void error(Throwable e) {
/*  360 */       this.sink.error(e);
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> next(T t) {
/*  365 */       this.sink.next(t);
/*  366 */       return (this.serializedSink == null) ? this : this.serializedSink;
/*      */     }
/*      */ 
/*      */     
/*      */     public long requestedFromDownstream() {
/*  371 */       return this.sink.requestedFromDownstream();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isCancelled() {
/*  376 */       return this.sink.isCancelled();
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> onRequest(LongConsumer consumer) {
/*  381 */       if (this.serializedSink == null) {
/*  382 */         this.serializedSink = new FluxCreate.SerializedFluxSink<>(this.baseSink);
/*  383 */         this.sink = this.serializedSink;
/*      */       } 
/*  385 */       return this.sink.onRequest(consumer);
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> onCancel(Disposable d) {
/*  390 */       this.sink.onCancel(d);
/*  391 */       return this.sink;
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> onDispose(Disposable d) {
/*  396 */       this.sink.onDispose(d);
/*  397 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  402 */       return this.baseSink.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract class BaseSink<T>
/*      */     extends AtomicBoolean
/*      */     implements FluxSink<T>, InnerProducer<T> {
/*  409 */     static final Disposable TERMINATED = OperatorDisposables.DISPOSED;
/*  410 */     static final Disposable CANCELLED = Disposables.disposed();
/*      */     
/*      */     final CoreSubscriber<? super T> actual;
/*      */     
/*      */     final Context ctx;
/*      */     
/*      */     volatile Disposable disposable;
/*      */     
/*  418 */     static final AtomicReferenceFieldUpdater<BaseSink, Disposable> DISPOSABLE = AtomicReferenceFieldUpdater.newUpdater(BaseSink.class, Disposable.class, "disposable");
/*      */ 
/*      */ 
/*      */     
/*      */     volatile long requested;
/*      */ 
/*      */     
/*  425 */     static final AtomicLongFieldUpdater<BaseSink> REQUESTED = AtomicLongFieldUpdater.newUpdater(BaseSink.class, "requested");
/*      */ 
/*      */     
/*      */     volatile LongConsumer requestConsumer;
/*      */     
/*  430 */     static final AtomicReferenceFieldUpdater<BaseSink, LongConsumer> REQUEST_CONSUMER = AtomicReferenceFieldUpdater.newUpdater(BaseSink.class, LongConsumer.class, "requestConsumer");
/*      */ 
/*      */ 
/*      */     
/*      */     BaseSink(CoreSubscriber<? super T> actual) {
/*  435 */       this.actual = actual;
/*  436 */       this.ctx = actual.currentContext();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public Context currentContext() {
/*  444 */       return this.actual.currentContext();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ContextView contextView() {
/*  451 */       return (ContextView)this.actual.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public void complete() {
/*  456 */       if (isTerminated()) {
/*      */         return;
/*      */       }
/*      */       try {
/*  460 */         this.actual.onComplete();
/*      */       } finally {
/*      */         
/*  463 */         disposeResource(false);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void error(Throwable e) {
/*  469 */       if (isTerminated()) {
/*  470 */         Operators.onOperatorError(e, this.ctx);
/*      */         return;
/*      */       } 
/*      */       try {
/*  474 */         this.actual.onError(e);
/*      */       } finally {
/*      */         
/*  477 */         disposeResource(false);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void cancel() {
/*  483 */       disposeResource(true);
/*  484 */       onCancel();
/*      */     }
/*      */     
/*      */     void disposeResource(boolean isCancel) {
/*  488 */       Disposable disposed = isCancel ? CANCELLED : TERMINATED;
/*  489 */       Disposable d = this.disposable;
/*  490 */       if (d != TERMINATED && d != CANCELLED) {
/*  491 */         d = DISPOSABLE.getAndSet(this, disposed);
/*  492 */         if (d != null && d != TERMINATED && d != CANCELLED) {
/*  493 */           if (isCancel && d instanceof FluxCreate.SinkDisposable) {
/*  494 */             ((FluxCreate.SinkDisposable)d).cancel();
/*      */           }
/*  496 */           d.dispose();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public long requestedFromDownstream() {
/*  503 */       return this.requested;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void onCancel() {}
/*      */ 
/*      */     
/*      */     public final boolean isCancelled() {
/*  512 */       return (this.disposable == CANCELLED);
/*      */     }
/*      */     
/*      */     final boolean isTerminated() {
/*  516 */       return (this.disposable == TERMINATED);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void request(long n) {
/*  521 */       if (Operators.validate(n)) {
/*  522 */         Operators.addCap(REQUESTED, this, n);
/*      */         
/*  524 */         LongConsumer consumer = this.requestConsumer;
/*  525 */         if (n > 0L && consumer != null && !isCancelled()) {
/*  526 */           consumer.accept(n);
/*      */         }
/*  528 */         onRequestedFromDownstream();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void onRequestedFromDownstream() {}
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super T> actual() {
/*  538 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> onRequest(LongConsumer consumer) {
/*  543 */       Objects.requireNonNull(consumer, "onRequest");
/*  544 */       onRequest(consumer, n -> {  }Long.MAX_VALUE);
/*      */       
/*  546 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void onRequest(LongConsumer initialRequestConsumer, LongConsumer requestConsumer, long value) {
/*  552 */       if (!REQUEST_CONSUMER.compareAndSet(this, null, requestConsumer)) {
/*  553 */         throw new IllegalStateException("A consumer has already been assigned to consume requests");
/*      */       }
/*      */       
/*  556 */       if (value > 0L) {
/*  557 */         initialRequestConsumer.accept(value);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public final FluxSink<T> onCancel(Disposable d) {
/*  563 */       Objects.requireNonNull(d, "onCancel");
/*  564 */       FluxCreate.SinkDisposable sd = new FluxCreate.SinkDisposable(null, d);
/*  565 */       if (!DISPOSABLE.compareAndSet(this, null, sd)) {
/*  566 */         Disposable c = this.disposable;
/*  567 */         if (c == CANCELLED) {
/*  568 */           d.dispose();
/*      */         }
/*  570 */         else if (c instanceof FluxCreate.SinkDisposable) {
/*  571 */           FluxCreate.SinkDisposable current = (FluxCreate.SinkDisposable)c;
/*  572 */           if (current.onCancel == null) {
/*  573 */             current.onCancel = d;
/*      */           } else {
/*      */             
/*  576 */             d.dispose();
/*      */           } 
/*      */         } 
/*      */       } 
/*  580 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final FluxSink<T> onDispose(Disposable d) {
/*  585 */       Objects.requireNonNull(d, "onDispose");
/*  586 */       FluxCreate.SinkDisposable sd = new FluxCreate.SinkDisposable(d, null);
/*  587 */       if (!DISPOSABLE.compareAndSet(this, null, sd)) {
/*  588 */         Disposable c = this.disposable;
/*  589 */         if (c == TERMINATED || c == CANCELLED) {
/*  590 */           d.dispose();
/*      */         }
/*  592 */         else if (c instanceof FluxCreate.SinkDisposable) {
/*  593 */           FluxCreate.SinkDisposable current = (FluxCreate.SinkDisposable)c;
/*  594 */           if (current.disposable == null) {
/*  595 */             current.disposable = d;
/*      */           } else {
/*      */             
/*  598 */             d.dispose();
/*      */           } 
/*      */         } 
/*      */       } 
/*  602 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  608 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.disposable == TERMINATED)); 
/*  609 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.disposable == CANCELLED)); 
/*  610 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/*  611 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*      */       
/*  613 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  618 */       return "FluxSink";
/*      */     }
/*      */   }
/*      */   
/*      */   static final class IgnoreSink<T>
/*      */     extends BaseSink<T> {
/*      */     IgnoreSink(CoreSubscriber<? super T> actual) {
/*  625 */       super(actual);
/*      */     }
/*      */     
/*      */     public FluxSink<T> next(T t) {
/*      */       long r;
/*  630 */       if (isTerminated()) {
/*  631 */         Operators.onNextDropped(t, this.ctx);
/*  632 */         return this;
/*      */       } 
/*  634 */       if (isCancelled()) {
/*  635 */         Operators.onDiscard(t, this.ctx);
/*  636 */         return this;
/*      */       } 
/*      */       
/*  639 */       this.actual.onNext(t);
/*      */       
/*      */       do {
/*  642 */         r = this.requested;
/*  643 */       } while (r != 0L && !REQUESTED.compareAndSet(this, r, r - 1L));
/*  644 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  651 */       return "FluxSink(" + FluxSink.OverflowStrategy.IGNORE + ")";
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract class NoOverflowBaseAsyncSink<T>
/*      */     extends BaseSink<T> {
/*      */     NoOverflowBaseAsyncSink(CoreSubscriber<? super T> actual) {
/*  658 */       super(actual);
/*      */     }
/*      */ 
/*      */     
/*      */     public final FluxSink<T> next(T t) {
/*  663 */       if (isTerminated()) {
/*  664 */         Operators.onNextDropped(t, this.ctx);
/*  665 */         return this;
/*      */       } 
/*      */       
/*  668 */       if (this.requested != 0L) {
/*  669 */         this.actual.onNext(t);
/*  670 */         Operators.produced(REQUESTED, this, 1L);
/*      */       } else {
/*      */         
/*  673 */         onOverflow();
/*  674 */         Operators.onDiscard(t, this.ctx);
/*      */       } 
/*  676 */       return this;
/*      */     }
/*      */     
/*      */     abstract void onOverflow();
/*      */   }
/*      */   
/*      */   static final class DropAsyncSink<T>
/*      */     extends NoOverflowBaseAsyncSink<T> {
/*      */     DropAsyncSink(CoreSubscriber<? super T> actual) {
/*  685 */       super(actual);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void onOverflow() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  695 */       return "FluxSink(" + FluxSink.OverflowStrategy.DROP + ")";
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ErrorAsyncSink<T>
/*      */     extends NoOverflowBaseAsyncSink<T>
/*      */   {
/*      */     ErrorAsyncSink(CoreSubscriber<? super T> actual) {
/*  703 */       super(actual);
/*      */     }
/*      */ 
/*      */     
/*      */     void onOverflow() {
/*  708 */       error(Exceptions.failWithOverflow());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  714 */       return "FluxSink(" + FluxSink.OverflowStrategy.ERROR + ")";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class BufferAsyncSink<T>
/*      */     extends BaseSink<T>
/*      */   {
/*      */     final Queue<T> queue;
/*      */     
/*      */     Throwable error;
/*      */     
/*      */     volatile boolean done;
/*      */     
/*      */     volatile int wip;
/*  729 */     static final AtomicIntegerFieldUpdater<BufferAsyncSink> WIP = AtomicIntegerFieldUpdater.newUpdater(BufferAsyncSink.class, "wip");
/*      */     
/*      */     BufferAsyncSink(CoreSubscriber<? super T> actual, int capacityHint) {
/*  732 */       super(actual);
/*  733 */       this.queue = Queues.unbounded(capacityHint).get();
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> next(T t) {
/*  738 */       this.queue.offer(t);
/*  739 */       drain();
/*  740 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public void error(Throwable e) {
/*  745 */       this.error = e;
/*  746 */       this.done = true;
/*  747 */       drain();
/*      */     }
/*      */ 
/*      */     
/*      */     public void complete() {
/*  752 */       this.done = true;
/*  753 */       drain();
/*      */     }
/*      */ 
/*      */     
/*      */     void onRequestedFromDownstream() {
/*  758 */       drain();
/*      */     }
/*      */ 
/*      */     
/*      */     void onCancel() {
/*  763 */       drain();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void drain() {
/*  771 */       if (WIP.getAndIncrement(this) != 0) {
/*      */         return;
/*      */       }
/*      */       
/*  775 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*  776 */       Queue<T> q = this.queue;
/*      */       
/*      */       while (true) {
/*  779 */         long r = this.requested;
/*  780 */         long e = 0L;
/*      */         
/*  782 */         while (e != r) {
/*  783 */           if (isCancelled()) {
/*  784 */             Operators.onDiscardQueueWithClear(q, this.ctx, null);
/*  785 */             if (WIP.decrementAndGet(this) != 0) {
/*      */               continue;
/*      */             }
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  793 */           boolean d = this.done;
/*      */           
/*  795 */           T o = q.poll();
/*      */           
/*  797 */           boolean empty = (o == null);
/*      */           
/*  799 */           if (d && empty) {
/*  800 */             Throwable ex = this.error;
/*  801 */             if (ex != null) {
/*  802 */               super.error(ex);
/*      */             } else {
/*      */               
/*  805 */               super.complete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*  810 */           if (empty) {
/*      */             break;
/*      */           }
/*      */           
/*  814 */           coreSubscriber.onNext(o);
/*      */           
/*  816 */           e++;
/*      */         } 
/*      */         
/*  819 */         if (e == r) {
/*  820 */           if (isCancelled()) {
/*  821 */             Operators.onDiscardQueueWithClear(q, this.ctx, null);
/*  822 */             if (WIP.decrementAndGet(this) != 0) {
/*      */               continue;
/*      */             }
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  830 */           boolean d = this.done;
/*      */           
/*  832 */           boolean empty = q.isEmpty();
/*      */           
/*  834 */           if (d && empty) {
/*  835 */             Throwable ex = this.error;
/*  836 */             if (ex != null) {
/*  837 */               super.error(ex);
/*      */             } else {
/*      */               
/*  840 */               super.complete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/*  846 */         if (e != 0L) {
/*  847 */           Operators.produced(REQUESTED, this, e);
/*      */         }
/*      */         
/*  850 */         if (WIP.decrementAndGet(this) == 0) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  859 */       if (key == Scannable.Attr.BUFFERED) {
/*  860 */         return Integer.valueOf(this.queue.size());
/*      */       }
/*  862 */       if (key == Scannable.Attr.TERMINATED) {
/*  863 */         return Boolean.valueOf(this.done);
/*      */       }
/*  865 */       if (key == Scannable.Attr.ERROR) {
/*  866 */         return this.error;
/*      */       }
/*      */       
/*  869 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  874 */       return "FluxSink(" + FluxSink.OverflowStrategy.BUFFER + ")";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class LatestAsyncSink<T>
/*      */     extends BaseSink<T>
/*      */   {
/*      */     final AtomicReference<T> queue;
/*      */     
/*      */     Throwable error;
/*      */     
/*      */     volatile boolean done;
/*      */     volatile int wip;
/*  888 */     static final AtomicIntegerFieldUpdater<LatestAsyncSink> WIP = AtomicIntegerFieldUpdater.newUpdater(LatestAsyncSink.class, "wip");
/*      */     
/*      */     LatestAsyncSink(CoreSubscriber<? super T> actual) {
/*  891 */       super(actual);
/*  892 */       this.queue = new AtomicReference<>();
/*      */     }
/*      */ 
/*      */     
/*      */     public FluxSink<T> next(T t) {
/*  897 */       T old = this.queue.getAndSet(t);
/*  898 */       Operators.onDiscard(old, this.ctx);
/*  899 */       drain();
/*  900 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public void error(Throwable e) {
/*  905 */       this.error = e;
/*  906 */       this.done = true;
/*  907 */       drain();
/*      */     }
/*      */ 
/*      */     
/*      */     public void complete() {
/*  912 */       this.done = true;
/*  913 */       drain();
/*      */     }
/*      */ 
/*      */     
/*      */     void onRequestedFromDownstream() {
/*  918 */       drain();
/*      */     }
/*      */ 
/*      */     
/*      */     void onCancel() {
/*  923 */       drain();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void drain() {
/*  931 */       if (WIP.getAndIncrement(this) != 0) {
/*      */         return;
/*      */       }
/*      */       
/*  935 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*  936 */       AtomicReference<T> q = this.queue;
/*      */       
/*      */       while (true) {
/*  939 */         long r = this.requested;
/*  940 */         long e = 0L;
/*      */         
/*  942 */         while (e != r) {
/*  943 */           if (isCancelled()) {
/*  944 */             T old = q.getAndSet(null);
/*  945 */             Operators.onDiscard(old, this.ctx);
/*  946 */             if (WIP.decrementAndGet(this) != 0) {
/*      */               continue;
/*      */             }
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  954 */           boolean d = this.done;
/*      */           
/*  956 */           T o = q.getAndSet(null);
/*      */           
/*  958 */           boolean empty = (o == null);
/*      */           
/*  960 */           if (d && empty) {
/*  961 */             Throwable ex = this.error;
/*  962 */             if (ex != null) {
/*  963 */               super.error(ex);
/*      */             } else {
/*      */               
/*  966 */               super.complete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*  971 */           if (empty) {
/*      */             break;
/*      */           }
/*      */           
/*  975 */           coreSubscriber.onNext(o);
/*      */           
/*  977 */           e++;
/*      */         } 
/*      */         
/*  980 */         if (e == r) {
/*  981 */           if (isCancelled()) {
/*  982 */             T old = q.getAndSet(null);
/*  983 */             Operators.onDiscard(old, this.ctx);
/*  984 */             if (WIP.decrementAndGet(this) != 0) {
/*      */               continue;
/*      */             }
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  992 */           boolean d = this.done;
/*      */           
/*  994 */           boolean empty = (q.get() == null);
/*      */           
/*  996 */           if (d && empty) {
/*  997 */             Throwable ex = this.error;
/*  998 */             if (ex != null) {
/*  999 */               super.error(ex);
/*      */             } else {
/*      */               
/* 1002 */               super.complete();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/* 1008 */         if (e != 0L) {
/* 1009 */           Operators.produced(REQUESTED, this, e);
/*      */         }
/*      */         
/* 1012 */         if (WIP.decrementAndGet(this) == 0) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1021 */       if (key == Scannable.Attr.BUFFERED) {
/* 1022 */         return Integer.valueOf((this.queue.get() == null) ? 0 : 1);
/*      */       }
/* 1024 */       if (key == Scannable.Attr.TERMINATED) {
/* 1025 */         return Boolean.valueOf(this.done);
/*      */       }
/* 1027 */       if (key == Scannable.Attr.ERROR) {
/* 1028 */         return this.error;
/*      */       }
/*      */       
/* 1031 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1036 */       return "FluxSink(" + FluxSink.OverflowStrategy.LATEST + ")";
/*      */     }
/*      */   }
/*      */   
/*      */   static final class SinkDisposable
/*      */     implements Disposable
/*      */   {
/*      */     Disposable onCancel;
/*      */     Disposable disposable;
/*      */     
/*      */     SinkDisposable(@Nullable Disposable disposable, @Nullable Disposable onCancel) {
/* 1047 */       this.disposable = disposable;
/* 1048 */       this.onCancel = onCancel;
/*      */     }
/*      */ 
/*      */     
/*      */     public void dispose() {
/* 1053 */       if (this.disposable != null) {
/* 1054 */         this.disposable.dispose();
/*      */       }
/*      */     }
/*      */     
/*      */     public void cancel() {
/* 1059 */       if (this.onCancel != null)
/* 1060 */         this.onCancel.dispose(); 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxCreate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */