/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoUsingWhen<T, S>
/*     */   extends Mono<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final Publisher<S> resourceSupplier;
/*     */   final Function<? super S, ? extends Mono<? extends T>> resourceClosure;
/*     */   final Function<? super S, ? extends Publisher<?>> asyncComplete;
/*     */   final BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError;
/*     */   @Nullable
/*     */   final Function<? super S, ? extends Publisher<?>> asyncCancel;
/*     */   
/*     */   MonoUsingWhen(Publisher<S> resourceSupplier, Function<? super S, ? extends Mono<? extends T>> resourceClosure, Function<? super S, ? extends Publisher<?>> asyncComplete, BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super S, ? extends Publisher<?>> asyncCancel) {
/*  60 */     this.resourceSupplier = Objects.<Publisher<S>>requireNonNull(resourceSupplier, "resourceSupplier");
/*  61 */     this.resourceClosure = Objects.<Function<? super S, ? extends Mono<? extends T>>>requireNonNull(resourceClosure, "resourceClosure");
/*  62 */     this.asyncComplete = Objects.<Function<? super S, ? extends Publisher<?>>>requireNonNull(asyncComplete, "asyncComplete");
/*  63 */     this.asyncError = Objects.<BiFunction<? super S, ? super Throwable, ? extends Publisher<?>>>requireNonNull(asyncError, "asyncError");
/*  64 */     this.asyncCancel = asyncCancel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  70 */     if (this.resourceSupplier instanceof Callable) {
/*     */       try {
/*  72 */         Callable<S> resourceCallable = (Callable<S>)this.resourceSupplier;
/*  73 */         S resource = resourceCallable.call();
/*     */         
/*  75 */         if (resource == null) {
/*  76 */           Operators.complete((Subscriber<?>)actual);
/*     */         } else {
/*     */           
/*  79 */           Mono<? extends T> p = deriveMonoFromResource(resource, this.resourceClosure);
/*  80 */           FluxUsingWhen.UsingWhenSubscriber<? super T, S> subscriber = prepareSubscriberForResource(resource, actual, this.asyncComplete, this.asyncError, this.asyncCancel, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  87 */           p.subscribe(subscriber);
/*     */         }
/*     */       
/*  90 */       } catch (Throwable e) {
/*  91 */         Operators.error((Subscriber<?>)actual, e);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     this.resourceSupplier.subscribe((Subscriber)new ResourceSubscriber<>(actual, this.resourceClosure, this.asyncComplete, this.asyncError, this.asyncCancel, this.resourceSupplier instanceof Mono));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 103 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <RESOURCE, T> Mono<? extends T> deriveMonoFromResource(RESOURCE resource, Function<? super RESOURCE, ? extends Mono<? extends T>> resourceClosure) {
/*     */     Mono<? extends T> p;
/*     */     try {
/* 114 */       p = Objects.<Mono<? extends T>>requireNonNull(resourceClosure.apply(resource), "The resourceClosure function returned a null value");
/*     */     
/*     */     }
/* 117 */     catch (Throwable e) {
/* 118 */       p = Mono.error(e);
/*     */     } 
/*     */     
/* 121 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <RESOURCE, T> MonoUsingWhenSubscriber<? super T, RESOURCE> prepareSubscriberForResource(RESOURCE resource, CoreSubscriber<? super T> actual, Function<? super RESOURCE, ? extends Publisher<?>> asyncComplete, BiFunction<? super RESOURCE, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super RESOURCE, ? extends Publisher<?>> asyncCancel, @Nullable Operators.DeferredSubscription arbiter) {
/* 132 */     return new MonoUsingWhenSubscriber<>(actual, resource, asyncComplete, asyncError, asyncCancel, arbiter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class ResourceSubscriber<S, T>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerConsumer<S>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Function<? super S, ? extends Mono<? extends T>> resourceClosure;
/*     */     
/*     */     final Function<? super S, ? extends Publisher<?>> asyncComplete;
/*     */     
/*     */     final BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError;
/*     */     
/*     */     @Nullable
/*     */     final Function<? super S, ? extends Publisher<?>> asyncCancel;
/*     */     
/*     */     final boolean isMonoSource;
/*     */     
/*     */     Subscription resourceSubscription;
/*     */     
/*     */     boolean resourceProvided;
/*     */ 
/*     */     
/*     */     ResourceSubscriber(CoreSubscriber<? super T> actual, Function<? super S, ? extends Mono<? extends T>> resourceClosure, Function<? super S, ? extends Publisher<?>> asyncComplete, BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super S, ? extends Publisher<?>> asyncCancel, boolean isMonoSource) {
/* 160 */       this.actual = Objects.<CoreSubscriber<? super T>>requireNonNull(actual, "actual");
/* 161 */       this.resourceClosure = Objects.<Function<? super S, ? extends Mono<? extends T>>>requireNonNull(resourceClosure, "resourceClosure");
/* 162 */       this.asyncComplete = Objects.<Function<? super S, ? extends Publisher<?>>>requireNonNull(asyncComplete, "asyncComplete");
/* 163 */       this.asyncError = Objects.<BiFunction<? super S, ? super Throwable, ? extends Publisher<?>>>requireNonNull(asyncError, "asyncError");
/* 164 */       this.asyncCancel = asyncCancel;
/* 165 */       this.isMonoSource = isMonoSource;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 170 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(S resource) {
/* 175 */       if (this.resourceProvided) {
/* 176 */         Operators.onNextDropped(resource, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 179 */       this.resourceProvided = true;
/*     */       
/* 181 */       Mono<? extends T> p = MonoUsingWhen.deriveMonoFromResource((RESOURCE)resource, this.resourceClosure);
/*     */       
/* 183 */       p.subscribe(MonoUsingWhen.prepareSubscriberForResource((RESOURCE)resource, this.actual, this.asyncComplete, this.asyncError, this.asyncCancel, this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       if (!this.isMonoSource) {
/* 191 */         this.resourceSubscription.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 197 */       if (this.resourceProvided) {
/* 198 */         Operators.onErrorDropped(throwable, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 203 */       this.actual.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 208 */       if (this.resourceProvided) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 213 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 218 */       if (Operators.validate(this.resourceSubscription, s)) {
/* 219 */         this.resourceSubscription = s;
/* 220 */         this.actual.onSubscribe(this);
/* 221 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 227 */       if (!this.resourceProvided) {
/* 228 */         this.resourceSubscription.cancel();
/*     */       }
/*     */       
/* 231 */       super.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 236 */       if (key == Scannable.Attr.PARENT) return this.resourceSubscription; 
/* 237 */       if (key == Scannable.Attr.ACTUAL) return this.actual; 
/* 238 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 239 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.resourceProvided); 
/* 240 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 242 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class MonoUsingWhenSubscriber<T, S>
/*     */     extends FluxUsingWhen.UsingWhenSubscriber<T, S>
/*     */   {
/*     */     T value;
/*     */ 
/*     */     
/*     */     MonoUsingWhenSubscriber(CoreSubscriber<? super T> actual, S resource, Function<? super S, ? extends Publisher<?>> asyncComplete, BiFunction<? super S, ? super Throwable, ? extends Publisher<?>> asyncError, @Nullable Function<? super S, ? extends Publisher<?>> asyncCancel, @Nullable Operators.DeferredSubscription arbiter) {
/* 254 */       super(actual, resource, asyncComplete, asyncError, asyncCancel, arbiter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T value) {
/* 261 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void deferredComplete() {
/* 266 */       this.error = Exceptions.TERMINATED;
/* 267 */       if (this.value != null) {
/* 268 */         this.actual.onNext(this.value);
/*     */       }
/* 270 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void deferredError(Throwable error) {
/* 275 */       Operators.onDiscard(this.value, this.actual.currentContext());
/* 276 */       this.error = error;
/* 277 */       this.actual.onError(error);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoUsingWhen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */