/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoFlatMap<T, R>
/*     */   extends InternalMonoOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Function<? super T, ? extends Mono<? extends R>> mapper;
/*     */   
/*     */   MonoFlatMap(Mono<? extends T> source, Function<? super T, ? extends Mono<? extends R>> mapper) {
/*  46 */     super(source);
/*  47 */     this.mapper = Objects.<Function<? super T, ? extends Mono<? extends R>>>requireNonNull(mapper, "mapper");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  53 */     if (FluxFlatMap.trySubscribeScalarMap((Publisher<? extends T>)this.source, actual, (Function)this.mapper, true, false)) {
/*  54 */       return null;
/*     */     }
/*     */     
/*  57 */     FlatMapMain<T, R> manager = new FlatMapMain<>(actual, this.mapper);
/*  58 */     actual.onSubscribe(manager);
/*     */     
/*  60 */     return manager;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  65 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  66 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FlatMapMain<T, R>
/*     */     extends Operators.MonoSubscriber<T, R>
/*     */   {
/*     */     final Function<? super T, ? extends Mono<? extends R>> mapper;
/*     */     
/*     */     final MonoFlatMap.FlatMapInner<R> second;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     volatile Subscription s;
/*  80 */     static final AtomicReferenceFieldUpdater<FlatMapMain, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(FlatMapMain.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FlatMapMain(CoreSubscriber<? super R> subscriber, Function<? super T, ? extends Mono<? extends R>> mapper) {
/*  86 */       super(subscriber);
/*  87 */       this.mapper = mapper;
/*  88 */       this.second = new MonoFlatMap.FlatMapInner<>(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<? extends Scannable> inners() {
/*  93 */       return Stream.of(this.second);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  99 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 100 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 101 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 102 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 104 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 109 */       if (Operators.setOnce(S, this, s)) {
/* 110 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       Mono<? extends R> m;
/* 116 */       if (this.done) {
/* 117 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 120 */       this.done = true;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 125 */         m = Objects.<Mono<? extends R>>requireNonNull(this.mapper.apply(t), "The mapper returned a null Mono");
/*     */       
/*     */       }
/* 128 */       catch (Throwable ex) {
/* 129 */         this.actual.onError(Operators.onOperatorError(this.s, ex, t, this.actual
/* 130 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 134 */       if (m instanceof Callable) {
/* 135 */         R v; Callable<R> c = (Callable)m;
/*     */ 
/*     */         
/*     */         try {
/* 139 */           v = c.call();
/*     */         }
/* 141 */         catch (Throwable ex) {
/* 142 */           this.actual.onError(Operators.onOperatorError(this.s, ex, t, this.actual
/* 143 */                 .currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/* 147 */         if (v == null) {
/* 148 */           this.actual.onComplete();
/*     */         } else {
/*     */           
/* 151 */           complete(v);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/* 157 */         m.subscribe(this.second);
/*     */       }
/* 159 */       catch (Throwable e) {
/* 160 */         this.actual.onError(Operators.onOperatorError(this, e, t, this.actual
/* 161 */               .currentContext()));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 167 */       if (this.done) {
/* 168 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 171 */       this.done = true;
/* 172 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 177 */       if (this.done) {
/*     */         return;
/*     */       }
/* 180 */       this.done = true;
/* 181 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 186 */       super.cancel();
/* 187 */       Operators.terminate(S, this);
/* 188 */       this.second.cancel();
/*     */     }
/*     */     
/*     */     void secondError(Throwable ex) {
/* 192 */       this.actual.onError(ex);
/*     */     }
/*     */     
/*     */     void secondComplete() {
/* 196 */       this.actual.onComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FlatMapInner<R>
/*     */     implements InnerConsumer<R>
/*     */   {
/*     */     final MonoFlatMap.FlatMapMain<?, R> parent;
/*     */     
/*     */     volatile Subscription s;
/* 207 */     static final AtomicReferenceFieldUpdater<FlatMapInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(FlatMapInner.class, Subscription.class, "s");
/*     */ 
/*     */     
/*     */     boolean done;
/*     */ 
/*     */     
/*     */     FlatMapInner(MonoFlatMap.FlatMapMain<?, R> parent) {
/* 214 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 220 */       return this.parent.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 226 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 227 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 228 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 229 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 230 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 232 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 237 */       if (Operators.setOnce(S, this, s)) {
/* 238 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(R t) {
/* 244 */       if (this.done) {
/* 245 */         Operators.onNextDropped(t, this.parent.currentContext());
/*     */         return;
/*     */       } 
/* 248 */       this.done = true;
/* 249 */       this.parent.complete(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 254 */       if (this.done) {
/* 255 */         Operators.onErrorDropped(t, this.parent.currentContext());
/*     */         return;
/*     */       } 
/* 258 */       this.done = true;
/* 259 */       this.parent.secondError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 264 */       if (this.done) {
/*     */         return;
/*     */       }
/* 267 */       this.done = true;
/* 268 */       this.parent.secondComplete();
/*     */     }
/*     */     
/*     */     void cancel() {
/* 272 */       Operators.terminate(S, this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoFlatMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */