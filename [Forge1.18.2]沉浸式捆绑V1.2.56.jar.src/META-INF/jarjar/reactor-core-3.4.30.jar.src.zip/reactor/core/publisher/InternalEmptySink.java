/*    */ package reactor.core.publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface InternalEmptySink<T>
/*    */   extends Sinks.Empty<T>, ContextHolder
/*    */ {
/*    */   default void emitEmpty(Sinks.EmitFailureHandler failureHandler) {
/*    */     Sinks.EmitResult emitResult;
/*    */     while (true) {
/* 26 */       emitResult = tryEmitEmpty();
/* 27 */       if (emitResult.isSuccess()) {
/*    */         return;
/*    */       }
/*    */       
/* 31 */       boolean shouldRetry = failureHandler.onEmitFailure(SignalType.ON_COMPLETE, emitResult);
/*    */       
/* 33 */       if (shouldRetry)
/*    */         continue; 
/*    */       break;
/*    */     } 
/* 37 */     switch (emitResult) {
/*    */       case FAIL_ZERO_SUBSCRIBER:
/*    */       case FAIL_OVERFLOW:
/*    */       case FAIL_CANCELLED:
/*    */       case FAIL_TERMINATED:
/*    */         return;
/*    */       case FAIL_NON_SERIALIZED:
/* 44 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*    */     } 
/*    */ 
/*    */     
/* 48 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   default void emitError(Throwable error, Sinks.EmitFailureHandler failureHandler) {
/*    */     Sinks.EmitResult emitResult;
/*    */     while (true) {
/* 56 */       emitResult = tryEmitError(error);
/* 57 */       if (emitResult.isSuccess()) {
/*    */         return;
/*    */       }
/*    */       
/* 61 */       boolean shouldRetry = failureHandler.onEmitFailure(SignalType.ON_ERROR, emitResult);
/*    */       
/* 63 */       if (shouldRetry)
/*    */         continue; 
/*    */       break;
/*    */     } 
/* 67 */     switch (emitResult) {
/*    */       case FAIL_ZERO_SUBSCRIBER:
/*    */       case FAIL_OVERFLOW:
/*    */       case FAIL_CANCELLED:
/*    */         return;
/*    */       case FAIL_TERMINATED:
/* 73 */         Operators.onErrorDropped(error, currentContext());
/*    */         return;
/*    */       case FAIL_NON_SERIALIZED:
/* 76 */         throw new Sinks.EmissionException(emitResult, "Spec. Rule 1.3 - onSubscribe, onNext, onError and onComplete signaled to a Subscriber MUST be signaled serially.");
/*    */     } 
/*    */ 
/*    */     
/* 80 */     throw new Sinks.EmissionException(emitResult, "Unknown emitResult value");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\InternalEmptySink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */