/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoAll<T>
/*     */   extends MonoFromFluxOperator<T, Boolean>
/*     */   implements Fuseable
/*     */ {
/*     */   final Predicate<? super T> predicate;
/*     */   
/*     */   MonoAll(Flux<? extends T> source, Predicate<? super T> predicate) {
/*  43 */     super(source);
/*  44 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super Boolean> actual) {
/*  49 */     return new AllSubscriber<>(actual, this.predicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  54 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  55 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class AllSubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, Boolean>
/*     */   {
/*     */     final Predicate<? super T> predicate;
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     AllSubscriber(CoreSubscriber<? super Boolean> actual, Predicate<? super T> predicate) {
/*  66 */       super(actual);
/*  67 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  73 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  74 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  75 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  77 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/*  82 */       this.s.cancel();
/*  83 */       super.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  88 */       if (Operators.validate(this.s, s)) {
/*  89 */         this.s = s;
/*  90 */         this.actual.onSubscribe(this);
/*     */         
/*  92 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*     */       boolean b;
/*  99 */       if (this.done) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 106 */         b = this.predicate.test(t);
/* 107 */       } catch (Throwable e) {
/* 108 */         this.done = true;
/* 109 */         this.actual.onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         return;
/*     */       } 
/* 112 */       if (!b) {
/* 113 */         this.done = true;
/* 114 */         this.s.cancel();
/*     */         
/* 116 */         complete(Boolean.valueOf(false));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 122 */       if (this.done) {
/* 123 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 126 */       this.done = true;
/*     */       
/* 128 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 133 */       if (this.done) {
/*     */         return;
/*     */       }
/* 136 */       this.done = true;
/* 137 */       complete(Boolean.valueOf(true));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoAll.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */