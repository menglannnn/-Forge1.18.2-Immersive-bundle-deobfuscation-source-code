/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSkipWhile<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Predicate<? super T> predicate;
/*     */   
/*     */   FluxSkipWhile(Flux<? extends T> source, Predicate<? super T> predicate) {
/*  40 */     super(source);
/*  41 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  46 */     return new SkipWhileSubscriber<>(actual, this.predicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  51 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  52 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SkipWhileSubscriber<T>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     Subscription s;
/*     */     boolean done;
/*     */     boolean skipped;
/*     */     
/*     */     SkipWhileSubscriber(CoreSubscriber<? super T> actual, Predicate<? super T> predicate) {
/*  69 */       this.actual = actual;
/*  70 */       this.ctx = actual.currentContext();
/*  71 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  76 */       if (Operators.validate(this.s, s)) {
/*  77 */         this.s = s;
/*  78 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       boolean b;
/*  84 */       if (this.done) {
/*  85 */         Operators.onNextDropped(t, this.ctx);
/*     */         
/*     */         return;
/*     */       } 
/*  89 */       if (this.skipped) {
/*  90 */         this.actual.onNext(t);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/*  96 */         b = this.predicate.test(t);
/*     */       }
/*  98 */       catch (Throwable e) {
/*  99 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/*     */         
/*     */         return;
/*     */       } 
/* 103 */       if (b) {
/* 104 */         Operators.onDiscard(t, this.ctx);
/* 105 */         this.s.request(1L);
/*     */         
/*     */         return;
/*     */       } 
/* 109 */       this.skipped = true;
/* 110 */       this.actual.onNext(t);
/*     */     }
/*     */     
/*     */     public boolean tryOnNext(T t) {
/*     */       boolean b;
/* 115 */       if (this.done) {
/* 116 */         Operators.onNextDropped(t, this.ctx);
/* 117 */         return true;
/*     */       } 
/*     */       
/* 120 */       if (this.skipped) {
/* 121 */         this.actual.onNext(t);
/* 122 */         return true;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 127 */         b = this.predicate.test(t);
/*     */       }
/* 129 */       catch (Throwable e) {
/* 130 */         onError(Operators.onOperatorError(this.s, e, t, this.ctx));
/*     */         
/* 132 */         return true;
/*     */       } 
/*     */       
/* 135 */       if (b) {
/* 136 */         Operators.onDiscard(t, this.ctx);
/* 137 */         return false;
/*     */       } 
/*     */       
/* 140 */       this.skipped = true;
/* 141 */       this.actual.onNext(t);
/* 142 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 147 */       if (this.done) {
/* 148 */         Operators.onErrorDropped(t, this.ctx);
/*     */         return;
/*     */       } 
/* 151 */       this.done = true;
/*     */       
/* 153 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 158 */       if (this.done) {
/*     */         return;
/*     */       }
/* 161 */       this.done = true;
/*     */       
/* 163 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 169 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 170 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 171 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 173 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 178 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 183 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 188 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxSkipWhile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */