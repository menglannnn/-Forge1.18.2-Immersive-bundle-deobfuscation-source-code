/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxConcatIterable<T>
/*     */   extends Flux<T>
/*     */   implements SourceProducer<T>
/*     */ {
/*     */   final Iterable<? extends Publisher<? extends T>> iterable;
/*     */   
/*     */   FluxConcatIterable(Iterable<? extends Publisher<? extends T>> iterable) {
/*  38 */     this.iterable = Objects.<Iterable<? extends Publisher<? extends T>>>requireNonNull(iterable, "iterable");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     Iterator<? extends Publisher<? extends T>> it;
/*     */     try {
/*  47 */       it = Objects.<Iterator<? extends Publisher<? extends T>>>requireNonNull(this.iterable.iterator(), "The Iterator returned is null");
/*     */     
/*     */     }
/*  50 */     catch (Throwable e) {
/*  51 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*     */       
/*     */       return;
/*     */     } 
/*  55 */     ConcatIterableSubscriber<T> parent = new ConcatIterableSubscriber<>(actual, it);
/*     */     
/*  57 */     actual.onSubscribe(parent);
/*     */     
/*  59 */     if (!parent.isCancelled()) {
/*  60 */       parent.onComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  66 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ConcatIterableSubscriber<T>
/*     */     extends Operators.MultiSubscriptionSubscriber<T, T>
/*     */   {
/*     */     final Iterator<? extends Publisher<? extends T>> it;
/*     */     
/*     */     volatile int wip;
/*     */     
/*  78 */     static final AtomicIntegerFieldUpdater<ConcatIterableSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(ConcatIterableSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     long produced;
/*     */ 
/*     */     
/*     */     ConcatIterableSubscriber(CoreSubscriber<? super T> actual, Iterator<? extends Publisher<? extends T>> it) {
/*  85 */       super(actual);
/*  86 */       this.it = it;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  91 */       this.produced++;
/*     */       
/*  93 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/*  98 */       if (WIP.getAndIncrement(this) == 0) {
/*  99 */         Iterator<? extends Publisher<? extends T>> a = this.it; do {
/*     */           boolean b; Publisher<? extends T> p;
/* 101 */           if (isCancelled()) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 108 */             b = a.hasNext();
/*     */           }
/* 110 */           catch (Throwable e) {
/* 111 */             onError(Operators.onOperatorError(this, e, this.actual
/* 112 */                   .currentContext()));
/*     */             
/*     */             return;
/*     */           } 
/* 116 */           if (isCancelled()) {
/*     */             return;
/*     */           }
/*     */           
/* 120 */           if (!b) {
/* 121 */             this.actual.onComplete();
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           try {
/* 128 */             p = Objects.<Publisher<? extends T>>requireNonNull(this.it.next(), "The Publisher returned by the iterator is null");
/*     */           
/*     */           }
/* 131 */           catch (Throwable e) {
/* 132 */             this.actual.onError(Operators.onOperatorError(this, e, this.actual
/* 133 */                   .currentContext()));
/*     */             
/*     */             return;
/*     */           } 
/* 137 */           if (isCancelled()) {
/*     */             return;
/*     */           }
/*     */           
/* 141 */           long c = this.produced;
/* 142 */           if (c != 0L) {
/* 143 */             this.produced = 0L;
/* 144 */             produced(c);
/*     */           } 
/*     */           
/* 147 */           p.subscribe((Subscriber)this);
/*     */           
/* 149 */           if (isCancelled())
/*     */           {
/*     */             return;
/*     */           }
/*     */         }
/* 154 */         while (WIP.decrementAndGet(this) != 0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 161 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 162 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxConcatIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */