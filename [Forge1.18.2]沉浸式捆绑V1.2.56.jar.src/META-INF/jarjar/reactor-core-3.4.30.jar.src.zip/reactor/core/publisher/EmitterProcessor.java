/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class EmitterProcessor<T>
/*     */   extends FluxProcessor<T, T>
/*     */   implements InternalManySink<T>, Sinks.ManyWithUpstream<T>
/*     */ {
/*  74 */   static final FluxPublish.PubSubInner[] EMPTY = (FluxPublish.PubSubInner[])new FluxPublish.PublishInner[0];
/*     */ 
/*     */   
/*     */   final int prefetch;
/*     */ 
/*     */   
/*     */   final boolean autoCancel;
/*     */ 
/*     */   
/*     */   volatile Subscription s;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> EmitterProcessor<E> create() {
/*  88 */     return create(Queues.SMALL_BUFFER_SIZE, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> EmitterProcessor<E> create(boolean autoCancel) {
/* 105 */     return create(Queues.SMALL_BUFFER_SIZE, autoCancel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> EmitterProcessor<E> create(int bufferSize) {
/* 120 */     return create(bufferSize, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <E> EmitterProcessor<E> create(int bufferSize, boolean autoCancel) {
/* 136 */     return new EmitterProcessor<>(autoCancel, bufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   static final AtomicReferenceFieldUpdater<EmitterProcessor, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(EmitterProcessor.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */   
/*     */   volatile FluxPublish.PubSubInner<T>[] subscribers;
/*     */ 
/*     */ 
/*     */   
/* 154 */   static final AtomicReferenceFieldUpdater<EmitterProcessor, FluxPublish.PubSubInner[]> SUBSCRIBERS = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(EmitterProcessor.class, (Class)FluxPublish.PubSubInner[].class, "subscribers");
/*     */ 
/*     */ 
/*     */   
/*     */   volatile EmitterDisposable upstreamDisposable;
/*     */ 
/*     */   
/* 161 */   static final AtomicReferenceFieldUpdater<EmitterProcessor, EmitterDisposable> UPSTREAM_DISPOSABLE = AtomicReferenceFieldUpdater.newUpdater(EmitterProcessor.class, EmitterDisposable.class, "upstreamDisposable");
/*     */ 
/*     */ 
/*     */   
/*     */   volatile int wip;
/*     */ 
/*     */ 
/*     */   
/* 169 */   static final AtomicIntegerFieldUpdater<EmitterProcessor> WIP = AtomicIntegerFieldUpdater.newUpdater(EmitterProcessor.class, "wip");
/*     */ 
/*     */   
/*     */   volatile Queue<T> queue;
/*     */ 
/*     */   
/*     */   int sourceMode;
/*     */   
/*     */   volatile boolean done;
/*     */   
/*     */   volatile Throwable error;
/*     */   
/* 181 */   static final AtomicReferenceFieldUpdater<EmitterProcessor, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(EmitterProcessor.class, Throwable.class, "error");
/*     */ 
/*     */ 
/*     */   
/*     */   EmitterProcessor(boolean autoCancel, int prefetch) {
/* 186 */     if (prefetch < 1) {
/* 187 */       throw new IllegalArgumentException("bufferSize must be strictly positive, was: " + prefetch);
/*     */     }
/* 189 */     this.autoCancel = autoCancel;
/* 190 */     this.prefetch = prefetch;
/*     */ 
/*     */     
/* 193 */     SUBSCRIBERS.lazySet(this, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 198 */     return Stream.of((Scannable[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 203 */     return Operators.multiSubscribersContext((InnerProducer<?>[])this.subscribers);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isDetached() {
/* 208 */     return (this.s == Operators.cancelledSubscription() && this.done && this.error instanceof CancellationException);
/*     */   }
/*     */   
/*     */   private boolean detach() {
/* 212 */     if (Operators.terminate(S, this)) {
/* 213 */       this.done = true;
/* 214 */       CancellationException detachException = new CancellationException("the ManyWithUpstream sink had a Subscription to an upstream which has been manually cancelled");
/* 215 */       if (ERROR.compareAndSet(this, null, detachException)) {
/* 216 */         Queue<T> q = this.queue;
/* 217 */         if (q != null) {
/* 218 */           q.clear();
/*     */         }
/* 220 */         for (FluxPublish.PubSubInner<T> inner : terminate()) {
/* 221 */           inner.actual.onError(detachException);
/*     */         }
/* 223 */         return true;
/*     */       } 
/*     */     } 
/* 226 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable subscribeTo(Publisher<? extends T> upstream) {
/* 231 */     EmitterDisposable ed = new EmitterDisposable(this);
/* 232 */     if (UPSTREAM_DISPOSABLE.compareAndSet(this, null, ed)) {
/* 233 */       upstream.subscribe((Subscriber)this);
/* 234 */       return ed;
/*     */     } 
/* 236 */     throw new IllegalStateException("A Sinks.ManyWithUpstream must be subscribed to a source only once");
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 241 */     Objects.requireNonNull(actual, "subscribe");
/* 242 */     EmitterInner<T> inner = new EmitterInner<>(actual, this);
/* 243 */     actual.onSubscribe(inner);
/*     */     
/* 245 */     if (inner.isCancelled()) {
/*     */       return;
/*     */     }
/*     */     
/* 249 */     if (add(inner)) {
/* 250 */       if (inner.isCancelled()) {
/* 251 */         remove(inner);
/*     */       }
/* 253 */       drain();
/*     */     } else {
/*     */       
/* 256 */       Throwable e = this.error;
/* 257 */       if (e != null) {
/* 258 */         inner.actual.onError(e);
/*     */       } else {
/*     */         
/* 261 */         inner.actual.onComplete();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 269 */     Sinks.EmitResult emitResult = tryEmitComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitComplete() {
/* 274 */     if (this.done) {
/* 275 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/* 277 */     this.done = true;
/* 278 */     drain();
/* 279 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable throwable) {
/* 284 */     emitError(throwable, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitError(Throwable t) {
/* 289 */     Objects.requireNonNull(t, "onError");
/* 290 */     if (this.done) {
/* 291 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/* 293 */     if (Exceptions.addThrowable(ERROR, this, t)) {
/* 294 */       this.done = true;
/* 295 */       drain();
/* 296 */       return Sinks.EmitResult.OK;
/*     */     } 
/*     */     
/* 299 */     return Sinks.EmitResult.FAIL_TERMINATED;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNext(T t) {
/* 305 */     if (this.sourceMode == 2) {
/* 306 */       drain();
/*     */       return;
/*     */     } 
/* 309 */     emitNext(t, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitNext(T t) {
/* 314 */     if (this.done) {
/* 315 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/* 318 */     Objects.requireNonNull(t, "onNext");
/*     */     
/* 320 */     Queue<T> q = this.queue;
/*     */     
/* 322 */     if (q == null) {
/* 323 */       if (Operators.setOnce(S, this, Operators.emptySubscription())) {
/* 324 */         q = Queues.get(this.prefetch).get();
/* 325 */         this.queue = q;
/*     */       } else {
/*     */         
/*     */         do {
/* 329 */           if (isCancelled()) {
/* 330 */             return Sinks.EmitResult.FAIL_CANCELLED;
/*     */           }
/* 332 */           q = this.queue;
/* 333 */         } while (q == null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     if (!q.offer(t)) {
/* 341 */       return (this.subscribers == EMPTY) ? Sinks.EmitResult.FAIL_ZERO_SUBSCRIBER : Sinks.EmitResult.FAIL_OVERFLOW;
/*     */     }
/* 343 */     drain();
/* 344 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public int currentSubscriberCount() {
/* 349 */     return this.subscribers.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<T> asFlux() {
/* 354 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isIdentityProcessor() {
/* 359 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPending() {
/* 368 */     Queue<T> q = this.queue;
/* 369 */     return (q != null) ? q.size() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 374 */     return (isTerminated() || isCancelled());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription s) {
/* 381 */     if (Operators.setOnce(S, this, s)) {
/* 382 */       if (s instanceof Fuseable.QueueSubscription) {
/* 383 */         Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*     */ 
/*     */         
/* 386 */         int m = f.requestFusion(3);
/* 387 */         if (m == 1) {
/* 388 */           this.sourceMode = m;
/* 389 */           this.queue = (Queue<T>)f;
/* 390 */           drain();
/*     */           return;
/*     */         } 
/* 393 */         if (m == 2) {
/* 394 */           this.sourceMode = m;
/* 395 */           this.queue = (Queue<T>)f;
/* 396 */           s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 401 */       this.queue = Queues.get(this.prefetch).get();
/*     */       
/* 403 */       s.request(Operators.unboundedOrPrefetch(this.prefetch));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getError() {
/* 410 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCancelled() {
/* 417 */     return (Operators.cancelledSubscription() == this.s);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getBufferSize() {
/* 422 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 427 */     return (this.done && getPending() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 432 */     return this.prefetch;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 438 */     if (key == Scannable.Attr.PARENT) return this.s; 
/* 439 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(getPending()); 
/* 440 */     if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isCancelled()); 
/* 441 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch());
/*     */     
/* 443 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   final void drain() {
/* 447 */     if (WIP.getAndIncrement(this) != 0) {
/*     */       return;
/*     */     }
/*     */     
/* 451 */     int missed = 1;
/*     */ 
/*     */     
/*     */     while (true) {
/* 455 */       boolean d = this.done;
/*     */       
/* 457 */       Queue<T> q = this.queue;
/*     */       
/* 459 */       boolean empty = (q == null || q.isEmpty());
/*     */       
/* 461 */       if (checkTerminated(d, empty)) {
/*     */         return;
/*     */       }
/*     */       
/* 465 */       FluxPublish.PubSubInner<T>[] a = this.subscribers;
/*     */       
/* 467 */       if (a != EMPTY && !empty) {
/* 468 */         long maxRequested = Long.MAX_VALUE;
/*     */         
/* 470 */         int len = a.length;
/* 471 */         int cancel = 0;
/*     */         
/* 473 */         for (FluxPublish.PubSubInner<T> inner : a) {
/* 474 */           long r = inner.requested;
/* 475 */           if (r >= 0L) {
/* 476 */             maxRequested = Math.min(maxRequested, r);
/*     */           } else {
/*     */             
/* 479 */             cancel++;
/*     */           } 
/*     */         } 
/*     */         
/* 483 */         if (len == cancel) {
/*     */           T v;
/*     */           
/*     */           try {
/* 487 */             v = q.poll();
/*     */           }
/* 489 */           catch (Throwable ex) {
/* 490 */             Exceptions.addThrowable(ERROR, this, 
/* 491 */                 Operators.onOperatorError(this.s, ex, currentContext()));
/* 492 */             d = true;
/* 493 */             v = null;
/*     */           } 
/* 495 */           if (checkTerminated(d, (v == null))) {
/*     */             return;
/*     */           }
/* 498 */           if (this.sourceMode != 1) {
/* 499 */             this.s.request(1L);
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 504 */         int e = 0;
/*     */         
/* 506 */         while (e < maxRequested && cancel != Integer.MIN_VALUE) {
/* 507 */           T v; d = this.done;
/*     */ 
/*     */           
/*     */           try {
/* 511 */             v = q.poll();
/*     */           }
/* 513 */           catch (Throwable ex) {
/* 514 */             Exceptions.addThrowable(ERROR, this, 
/* 515 */                 Operators.onOperatorError(this.s, ex, currentContext()));
/* 516 */             d = true;
/* 517 */             v = null;
/*     */           } 
/*     */           
/* 520 */           empty = (v == null);
/*     */           
/* 522 */           if (checkTerminated(d, empty)) {
/*     */             return;
/*     */           }
/*     */           
/* 526 */           if (empty) {
/*     */             
/* 528 */             if (this.sourceMode == 1) {
/*     */               
/* 530 */               this.done = true;
/* 531 */               checkTerminated(true, true);
/*     */             } 
/*     */             
/*     */             break;
/*     */           } 
/* 536 */           for (FluxPublish.PubSubInner<T> inner : a) {
/* 537 */             inner.actual.onNext(v);
/* 538 */             if (Operators.producedCancellable(FluxPublish.PublishInner.REQUESTED, inner, 1L) == Long.MIN_VALUE)
/*     */             {
/*     */               
/* 541 */               cancel = Integer.MIN_VALUE;
/*     */             }
/*     */           } 
/*     */           
/* 545 */           e++;
/*     */         } 
/*     */         
/* 548 */         if (e != 0 && this.sourceMode != 1) {
/* 549 */           this.s.request(e);
/*     */         }
/*     */         
/* 552 */         if (maxRequested != 0L && !empty) {
/*     */           continue;
/*     */         }
/*     */       }
/* 556 */       else if (this.sourceMode == 1) {
/* 557 */         this.done = true;
/* 558 */         if (checkTerminated(true, empty)) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 563 */       missed = WIP.addAndGet(this, -missed);
/* 564 */       if (missed == 0) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   FluxPublish.PubSubInner<T>[] terminate() {
/* 572 */     return (FluxPublish.PubSubInner<T>[])SUBSCRIBERS.getAndSet(this, FluxPublish.PublishSubscriber.TERMINATED);
/*     */   }
/*     */   
/*     */   boolean checkTerminated(boolean d, boolean empty) {
/* 576 */     if (this.s == Operators.cancelledSubscription()) {
/* 577 */       if (this.autoCancel) {
/* 578 */         terminate();
/* 579 */         Queue<T> q = this.queue;
/* 580 */         if (q != null) {
/* 581 */           q.clear();
/*     */         }
/*     */       } 
/* 584 */       return true;
/*     */     } 
/* 586 */     if (d) {
/* 587 */       Throwable e = this.error;
/* 588 */       if (e != null && e != Exceptions.TERMINATED) {
/* 589 */         Queue<T> q = this.queue;
/* 590 */         if (q != null) {
/* 591 */           q.clear();
/*     */         }
/* 593 */         for (FluxPublish.PubSubInner<T> inner : terminate()) {
/* 594 */           inner.actual.onError(e);
/*     */         }
/* 596 */         return true;
/*     */       } 
/* 598 */       if (empty) {
/* 599 */         for (FluxPublish.PubSubInner<T> inner : terminate()) {
/* 600 */           inner.actual.onComplete();
/*     */         }
/* 602 */         return true;
/*     */       } 
/*     */     } 
/* 605 */     return false;
/*     */   }
/*     */   
/*     */   final boolean add(EmitterInner<T> inner) {
/*     */     while (true) {
/* 610 */       FluxPublish.PubSubInner<T>[] a = this.subscribers;
/* 611 */       if (a == FluxPublish.PublishSubscriber.TERMINATED) {
/* 612 */         return false;
/*     */       }
/* 614 */       int n = a.length;
/* 615 */       FluxPublish.PubSubInner[] arrayOfPubSubInner = new FluxPublish.PubSubInner[n + 1];
/* 616 */       System.arraycopy(a, 0, arrayOfPubSubInner, 0, n);
/* 617 */       arrayOfPubSubInner[n] = inner;
/* 618 */       if (SUBSCRIBERS.compareAndSet(this, a, arrayOfPubSubInner))
/* 619 */         return true; 
/*     */     } 
/*     */   }
/*     */   final void remove(FluxPublish.PubSubInner<T> inner) {
/*     */     FluxPublish.PubSubInner<T>[] a;
/*     */     FluxPublish.PubSubInner[] arrayOfPubSubInner;
/*     */     do {
/* 626 */       a = this.subscribers;
/* 627 */       if (a == FluxPublish.PublishSubscriber.TERMINATED || a == EMPTY) {
/*     */         return;
/*     */       }
/* 630 */       int n = a.length;
/* 631 */       int j = -1;
/* 632 */       for (int i = 0; i < n; i++) {
/* 633 */         if (a[i] == inner) {
/* 634 */           j = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 639 */       if (j < 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 644 */       if (n == 1) {
/* 645 */         arrayOfPubSubInner = EMPTY;
/*     */       } else {
/*     */         
/* 648 */         arrayOfPubSubInner = new FluxPublish.PubSubInner[n - 1];
/* 649 */         System.arraycopy(a, 0, arrayOfPubSubInner, 0, j);
/* 650 */         System.arraycopy(a, j + 1, arrayOfPubSubInner, j, n - j - 1);
/*     */       } 
/* 652 */     } while (!SUBSCRIBERS.compareAndSet(this, a, arrayOfPubSubInner));
/*     */ 
/*     */     
/* 655 */     if (this.autoCancel && arrayOfPubSubInner == EMPTY && Operators.terminate(S, this)) {
/* 656 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/* 659 */       terminate();
/* 660 */       Queue<T> q = this.queue;
/* 661 */       if (q != null) {
/* 662 */         q.clear();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long downstreamCount() {
/* 672 */     return this.subscribers.length;
/*     */   }
/*     */   
/*     */   static final class EmitterInner<T>
/*     */     extends FluxPublish.PubSubInner<T> {
/*     */     final EmitterProcessor<T> parent;
/*     */     
/*     */     EmitterInner(CoreSubscriber<? super T> actual, EmitterProcessor<T> parent) {
/* 680 */       super(actual);
/* 681 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     void drainParent() {
/* 686 */       this.parent.drain();
/*     */     }
/*     */ 
/*     */     
/*     */     void removeAndDrainParent() {
/* 691 */       this.parent.remove(this);
/* 692 */       this.parent.drain();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class EmitterDisposable
/*     */     implements Disposable {
/*     */     @Nullable
/*     */     EmitterProcessor<?> target;
/*     */     
/*     */     public EmitterDisposable(EmitterProcessor<?> emitterProcessor) {
/* 702 */       this.target = emitterProcessor;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 707 */       return (this.target == null || this.target.isDetached());
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 712 */       EmitterProcessor<?> t = this.target;
/* 713 */       if (t == null) {
/*     */         return;
/*     */       }
/* 716 */       if (t.detach() || t.isDetached())
/* 717 */         this.target = null; 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\EmitterProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */