/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSubscribeOnCallable<T>
/*     */   extends Flux<T>
/*     */   implements Fuseable, Scannable
/*     */ {
/*     */   final Callable<? extends T> callable;
/*     */   final Scheduler scheduler;
/*     */   
/*     */   FluxSubscribeOnCallable(Callable<? extends T> callable, Scheduler scheduler) {
/*  45 */     this.callable = Objects.<Callable<? extends T>>requireNonNull(callable, "callable");
/*  46 */     this.scheduler = Objects.<Scheduler>requireNonNull(scheduler, "scheduler");
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*  51 */     CallableSubscribeOnSubscription<T> parent = new CallableSubscribeOnSubscription<>(actual, this.callable, this.scheduler);
/*     */     
/*  53 */     actual.onSubscribe(parent);
/*     */     
/*     */     try {
/*  56 */       Disposable f = this.scheduler.schedule(parent);
/*  57 */       parent.setMainFuture(f);
/*     */     }
/*  59 */     catch (RejectedExecutionException ree) {
/*  60 */       if (parent.state != 4) {
/*  61 */         actual.onError(Operators.onRejectedExecution(ree, actual.currentContext()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  68 */     if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/*  69 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CallableSubscribeOnSubscription<T>
/*     */     implements Fuseable.QueueSubscription<T>, InnerProducer<T>, Runnable
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Callable<? extends T> callable;
/*     */     
/*     */     final Scheduler scheduler;
/*     */     
/*     */     volatile int state;
/*     */     
/*  86 */     static final AtomicIntegerFieldUpdater<CallableSubscribeOnSubscription> STATE = AtomicIntegerFieldUpdater.newUpdater(CallableSubscribeOnSubscription.class, "state");
/*     */     
/*     */     T value;
/*     */     
/*     */     static final int NO_REQUEST_HAS_VALUE = 1;
/*     */     
/*     */     static final int HAS_REQUEST_NO_VALUE = 2;
/*     */     
/*     */     static final int HAS_REQUEST_HAS_VALUE = 3;
/*     */     
/*     */     static final int HAS_CANCELLED = 4;
/*     */     
/*     */     int fusionState;
/*     */     
/*     */     static final int NO_VALUE = 1;
/*     */     static final int HAS_VALUE = 2;
/*     */     static final int COMPLETE = 3;
/*     */     volatile Disposable mainFuture;
/* 104 */     static final AtomicReferenceFieldUpdater<CallableSubscribeOnSubscription, Disposable> MAIN_FUTURE = AtomicReferenceFieldUpdater.newUpdater(CallableSubscribeOnSubscription.class, Disposable.class, "mainFuture");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile Disposable requestFuture;
/*     */ 
/*     */ 
/*     */     
/* 112 */     static final AtomicReferenceFieldUpdater<CallableSubscribeOnSubscription, Disposable> REQUEST_FUTURE = AtomicReferenceFieldUpdater.newUpdater(CallableSubscribeOnSubscription.class, Disposable.class, "requestFuture");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CallableSubscribeOnSubscription(CoreSubscriber<? super T> actual, Callable<? extends T> callable, Scheduler scheduler) {
/* 120 */       this.actual = actual;
/* 121 */       this.callable = callable;
/* 122 */       this.scheduler = scheduler;
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 127 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 133 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.state == 4)); 
/* 134 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.value != null) ? 1 : 0); 
/* 135 */       if (key == Scannable.Attr.RUN_ON) return this.scheduler; 
/* 136 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */       
/* 138 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 143 */       this.state = 4;
/* 144 */       this.fusionState = 3;
/* 145 */       Disposable a = this.mainFuture;
/* 146 */       if (a != OperatorDisposables.DISPOSED) {
/* 147 */         a = MAIN_FUTURE.getAndSet(this, OperatorDisposables.DISPOSED);
/* 148 */         if (a != null && a != OperatorDisposables.DISPOSED) {
/* 149 */           a.dispose();
/*     */         }
/*     */       } 
/* 152 */       a = this.requestFuture;
/* 153 */       if (a != OperatorDisposables.DISPOSED) {
/* 154 */         a = REQUEST_FUTURE.getAndSet(this, OperatorDisposables.DISPOSED);
/* 155 */         if (a != null && a != OperatorDisposables.DISPOSED) {
/* 156 */           a.dispose();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 163 */       this.value = null;
/* 164 */       this.fusionState = 3;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 169 */       return (this.fusionState == 3);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 175 */       if (this.fusionState == 2) {
/* 176 */         this.fusionState = 3;
/* 177 */         return this.value;
/*     */       } 
/* 179 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 184 */       if ((requestedMode & 0x2) != 0 && (requestedMode & 0x4) == 0) {
/* 185 */         this.fusionState = 1;
/* 186 */         return 2;
/*     */       } 
/* 188 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 193 */       return isEmpty() ? 0 : 1;
/*     */     }
/*     */     void setMainFuture(Disposable c) {
/*     */       Disposable a;
/*     */       do {
/* 198 */         a = this.mainFuture;
/* 199 */         if (a == OperatorDisposables.DISPOSED) {
/* 200 */           c.dispose();
/*     */           return;
/*     */         } 
/* 203 */       } while (!MAIN_FUTURE.compareAndSet(this, a, c));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void setRequestFuture(Disposable c) {
/*     */       Disposable a;
/*     */       do {
/* 211 */         a = this.requestFuture;
/* 212 */         if (a == OperatorDisposables.DISPOSED) {
/* 213 */           c.dispose();
/*     */           return;
/*     */         } 
/* 216 */       } while (!REQUEST_FUTURE.compareAndSet(this, a, c));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       T v;
/*     */       int s;
/*     */       try {
/* 227 */         v = this.callable.call();
/*     */       }
/* 229 */       catch (Throwable ex) {
/* 230 */         this.actual.onError(Operators.onOperatorError(this, ex, this.actual
/* 231 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 235 */       if (v == null) {
/* 236 */         this.fusionState = 3;
/* 237 */         this.actual.onComplete();
/*     */         
/*     */         return;
/*     */       } 
/*     */       do {
/* 242 */         s = this.state;
/* 243 */         if (s == 4 || s == 3 || s == 1) {
/*     */           return;
/*     */         }
/* 246 */         if (s == 2) {
/* 247 */           if (this.fusionState == 1) {
/* 248 */             this.value = v;
/* 249 */             this.fusionState = 2;
/*     */           } 
/* 251 */           this.actual.onNext(v);
/* 252 */           if (this.state != 4) {
/* 253 */             this.actual.onComplete();
/*     */           }
/*     */           return;
/*     */         } 
/* 257 */         this.value = v;
/* 258 */       } while (!STATE.compareAndSet(this, s, 1));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 266 */       if (Operators.validate(n)) {
/*     */         int s; do {
/* 268 */           s = this.state;
/* 269 */           if (s == 4 || s == 2 || s == 3) {
/*     */             return;
/*     */           }
/* 272 */           if (s == 1) {
/* 273 */             if (STATE.compareAndSet(this, s, 3)) {
/*     */               try {
/* 275 */                 Disposable f = this.scheduler.schedule(this::emitValue);
/* 276 */                 setRequestFuture(f);
/*     */               }
/* 278 */               catch (RejectedExecutionException ree) {
/* 279 */                 this.actual.onError(Operators.onRejectedExecution(ree, this.actual
/* 280 */                       .currentContext()));
/*     */               } 
/*     */             }
/*     */             return;
/*     */           } 
/* 285 */         } while (!STATE.compareAndSet(this, s, 2));
/*     */         return;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void emitValue() {
/* 293 */       if (this.fusionState == 1) {
/* 294 */         this.fusionState = 2;
/*     */       }
/* 296 */       T v = this.value;
/* 297 */       clear();
/* 298 */       if (v != null) {
/* 299 */         this.actual.onNext(v);
/*     */       }
/* 301 */       if (this.state != 4)
/* 302 */         this.actual.onComplete(); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxSubscribeOnCallable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */