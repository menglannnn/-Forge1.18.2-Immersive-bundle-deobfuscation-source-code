/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Fuseable;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoMapFuseable<T, R>
/*    */   extends InternalMonoOperator<T, R>
/*    */   implements Fuseable
/*    */ {
/*    */   final Function<? super T, ? extends R> mapper;
/*    */   
/*    */   MonoMapFuseable(Mono<? extends T> source, Function<? super T, ? extends R> mapper) {
/* 47 */     super(source);
/* 48 */     this.mapper = Objects.<Function<? super T, ? extends R>>requireNonNull(mapper, "mapper");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/* 54 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/* 55 */       Fuseable.ConditionalSubscriber<? super R> cs = (Fuseable.ConditionalSubscriber<? super R>)actual;
/* 56 */       return new FluxMapFuseable.MapFuseableConditionalSubscriber<>(cs, this.mapper);
/*    */     } 
/* 58 */     return new FluxMapFuseable.MapFuseableSubscriber<>(actual, this.mapper);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 63 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 64 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoMapFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */