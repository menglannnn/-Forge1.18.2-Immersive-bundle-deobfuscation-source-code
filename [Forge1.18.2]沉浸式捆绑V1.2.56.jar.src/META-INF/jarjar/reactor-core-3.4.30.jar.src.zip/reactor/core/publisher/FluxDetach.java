/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDetach<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   FluxDetach(Flux<? extends T> source) {
/*  38 */     super(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  43 */     return new DetachSubscriber<>(actual);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  48 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  49 */     return super.scanUnsafe(key);
/*     */   }
/*     */   
/*     */   static final class DetachSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     CoreSubscriber<? super T> actual;
/*     */     Subscription s;
/*     */     
/*     */     DetachSubscriber(CoreSubscriber<? super T> actual) {
/*  59 */       this.actual = actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/*  64 */       return (this.actual == null) ? Context.empty() : this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  70 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  71 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.actual == null)); 
/*  72 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.actual == null && this.s == null)); 
/*  73 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  75 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  80 */       if (Operators.validate(this.s, s)) {
/*  81 */         this.s = s;
/*     */         
/*  83 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  89 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*  90 */       if (coreSubscriber != null) {
/*  91 */         coreSubscriber.onNext(t);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*  97 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/*  98 */       if (coreSubscriber != null) {
/*  99 */         this.actual = null;
/* 100 */         this.s = null;
/*     */         
/* 102 */         coreSubscriber.onError(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 108 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 113 */       CoreSubscriber<? super T> coreSubscriber = this.actual;
/* 114 */       if (coreSubscriber != null) {
/* 115 */         this.actual = null;
/* 116 */         this.s = null;
/*     */         
/* 118 */         coreSubscriber.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 124 */       Subscription a = this.s;
/* 125 */       if (a != null) {
/* 126 */         a.request(n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 132 */       Subscription a = this.s;
/* 133 */       if (a != null) {
/* 134 */         this.actual = null;
/* 135 */         this.s = null;
/*     */         
/* 137 */         a.cancel();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxDetach.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */