/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoReduceSeed<T, R>
/*     */   extends MonoFromFluxOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Supplier<R> initialSupplier;
/*     */   final BiFunction<R, ? super T, R> accumulator;
/*     */   
/*     */   MonoReduceSeed(Flux<? extends T> source, Supplier<R> initialSupplier, BiFunction<R, ? super T, R> accumulator) {
/*  47 */     super(source);
/*  48 */     this.initialSupplier = Objects.<Supplier<R>>requireNonNull(initialSupplier, "initialSupplier");
/*  49 */     this.accumulator = Objects.<BiFunction<R, ? super T, R>>requireNonNull(accumulator, "accumulator");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  54 */     R initialValue = Objects.requireNonNull(this.initialSupplier.get(), "The initial value supplied is null");
/*     */ 
/*     */     
/*  57 */     return new ReduceSeedSubscriber<>(actual, this.accumulator, initialValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  62 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  63 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ReduceSeedSubscriber<T, R>
/*     */     extends Operators.MonoSubscriber<T, R>
/*     */   {
/*     */     final BiFunction<R, ? super T, R> accumulator;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     ReduceSeedSubscriber(CoreSubscriber<? super R> actual, BiFunction<R, ? super T, R> accumulator, R value) {
/*  77 */       super(actual);
/*  78 */       this.accumulator = accumulator;
/*     */       
/*  80 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  86 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/*  87 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  88 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  90 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/*  95 */       super.cancel();
/*  96 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValue(R value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 108 */       if (Operators.validate(this.s, s)) {
/* 109 */         this.s = s;
/*     */         
/* 111 */         this.actual.onSubscribe(this);
/*     */         
/* 113 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 119 */       R v = this.value;
/*     */ 
/*     */       
/* 122 */       if (v != null) {
/*     */         R accumulated; try {
/* 124 */           accumulated = Objects.requireNonNull(this.accumulator.apply(v, t), "The accumulator returned a null value");
/*     */ 
/*     */         
/*     */         }
/* 128 */         catch (Throwable e) {
/* 129 */           onError(Operators.onOperatorError(this, e, t, this.actual.currentContext()));
/*     */           return;
/*     */         } 
/* 132 */         if (STATE.get(this) == 4) {
/* 133 */           discard(accumulated);
/* 134 */           this.value = null;
/*     */         }
/*     */         else {
/*     */           
/* 138 */           this.value = accumulated;
/*     */         } 
/*     */       } else {
/* 141 */         Operators.onDiscard(t, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 147 */       if (this.done) {
/* 148 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 151 */       this.done = true;
/* 152 */       discard(this.value);
/* 153 */       this.value = null;
/*     */       
/* 155 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 160 */       if (this.done) {
/*     */         return;
/*     */       }
/* 163 */       this.done = true;
/*     */       
/* 165 */       complete(this.value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoReduceSeed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */