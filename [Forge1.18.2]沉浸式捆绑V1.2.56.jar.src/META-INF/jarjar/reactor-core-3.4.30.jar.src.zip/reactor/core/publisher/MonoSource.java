/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import reactor.core.CorePublisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSource<I>
/*    */   extends Mono<I>
/*    */   implements Scannable, SourceProducer<I>, OptimizableOperator<I, I>
/*    */ {
/*    */   final Publisher<? extends I> source;
/*    */   @Nullable
/*    */   final OptimizableOperator<?, I> optimizableOperator;
/*    */   
/*    */   MonoSource(Publisher<? extends I> source) {
/* 50 */     this.source = Objects.<Publisher<? extends I>>requireNonNull(source);
/* 51 */     if (source instanceof OptimizableOperator) {
/*    */       
/* 53 */       OptimizableOperator<?, I> optimSource = (OptimizableOperator)source;
/* 54 */       this.optimizableOperator = optimSource;
/*    */     } else {
/*    */       
/* 57 */       this.optimizableOperator = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super I> actual) {
/* 69 */     this.source.subscribe((Subscriber)actual);
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super I> actual) {
/* 74 */     return actual;
/*    */   }
/*    */ 
/*    */   
/*    */   public final CorePublisher<? extends I> source() {
/* 79 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final OptimizableOperator<?, ? extends I> nextOptimizableSource() {
/* 84 */     return this.optimizableOperator;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 90 */     if (key == Scannable.Attr.PARENT) {
/* 91 */       return this.source;
/*    */     }
/* 93 */     if (key == Scannable.Attr.RUN_STYLE) {
/* 94 */       return Scannable.from(this.source).scanUnsafe(key);
/*    */     }
/* 96 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */