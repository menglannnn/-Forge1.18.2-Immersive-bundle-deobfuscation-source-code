/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FluxSourceMono<I>
/*    */   extends FluxFromMonoOperator<I, I>
/*    */ {
/*    */   FluxSourceMono(Mono<? extends I> source) {
/* 37 */     super(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public String stepName() {
/* 42 */     if (this.source instanceof Scannable) {
/* 43 */       return "FluxFromMono(" + Scannable.from(this.source).stepName() + ")";
/*    */     }
/* 45 */     return "FluxFromMono(" + this.source.toString() + ")";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super I> subscribeOrReturn(CoreSubscriber<? super I> actual) {
/* 55 */     return actual;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 60 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.from(this.source).scanUnsafe(key); 
/* 61 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxSourceMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */