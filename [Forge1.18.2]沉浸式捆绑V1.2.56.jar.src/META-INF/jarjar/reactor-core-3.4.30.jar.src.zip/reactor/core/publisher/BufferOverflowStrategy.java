/*    */ package reactor.core.publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BufferOverflowStrategy
/*    */ {
/* 31 */   ERROR,
/*    */ 
/*    */ 
/*    */   
/* 35 */   DROP_LATEST,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   DROP_OLDEST;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\BufferOverflowStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */