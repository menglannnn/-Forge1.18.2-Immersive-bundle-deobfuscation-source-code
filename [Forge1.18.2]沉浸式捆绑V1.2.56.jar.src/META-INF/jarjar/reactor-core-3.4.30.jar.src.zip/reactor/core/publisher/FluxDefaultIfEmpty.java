/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxDefaultIfEmpty<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final T value;
/*     */   
/*     */   FluxDefaultIfEmpty(Flux<? extends T> source, T value) {
/*  37 */     super(source);
/*  38 */     this.value = Objects.requireNonNull(value, "value");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  43 */     return new DefaultIfEmptySubscriber<>(actual, this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  48 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  49 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DefaultIfEmptySubscriber<T>
/*     */     extends Operators.MonoSubscriber<T, T>
/*     */   {
/*     */     Subscription s;
/*     */     boolean hasValue;
/*     */     
/*     */     DefaultIfEmptySubscriber(CoreSubscriber<? super T> actual, T value) {
/*  60 */       super(actual);
/*     */       
/*  62 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  68 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  69 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/*  71 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/*  76 */       super.request(n);
/*  77 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/*  82 */       super.cancel();
/*  83 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  88 */       if (Operators.validate(this.s, s)) {
/*  89 */         this.s = s;
/*     */         
/*  91 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  97 */       if (!this.hasValue) {
/*  98 */         this.hasValue = true;
/*     */       }
/*     */       
/* 101 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 106 */       if (this.hasValue) {
/* 107 */         this.actual.onComplete();
/*     */       } else {
/* 109 */         complete(this.value);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValue(T value) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 121 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxDefaultIfEmpty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */