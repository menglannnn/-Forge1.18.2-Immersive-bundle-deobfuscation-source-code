package reactor.core.publisher;

import reactor.core.CoreSubscriber;
import reactor.core.Scannable;

interface InnerConsumer<I> extends CoreSubscriber<I>, Scannable {}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\InnerConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */