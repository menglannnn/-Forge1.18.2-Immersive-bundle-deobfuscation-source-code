/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SinkOneMulticast<O>
/*     */   extends SinkEmptyMulticast<O>
/*     */   implements InternalOneSink<O>
/*     */ {
/*  29 */   static final SinkEmptyMulticast.Inner[] TERMINATED_VALUE = new SinkEmptyMulticast.Inner[0];
/*     */   
/*     */   static final int STATE_VALUE = 1;
/*     */   
/*     */   @Nullable
/*     */   O value;
/*     */ 
/*     */   
/*     */   boolean isTerminated(SinkEmptyMulticast.Inner<?>[] array) {
/*  38 */     return (array == TERMINATED_VALUE || super.isTerminated(array));
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.EmitResult tryEmitValue(@Nullable O value) {
/*  43 */     SinkEmptyMulticast.Inner<O>[] prevSubscribers = this.subscribers;
/*     */     
/*  45 */     if (isTerminated((SinkEmptyMulticast.Inner<?>[])prevSubscribers)) {
/*  46 */       return Sinks.EmitResult.FAIL_TERMINATED;
/*     */     }
/*     */     
/*  49 */     if (value == null) {
/*  50 */       return tryEmitEmpty();
/*     */     }
/*     */     
/*  53 */     this.value = value;
/*     */ 
/*     */     
/*  56 */     while (!SUBSCRIBERS.compareAndSet(this, prevSubscribers, TERMINATED_VALUE)) {
/*     */ 
/*     */ 
/*     */       
/*  60 */       prevSubscribers = this.subscribers;
/*  61 */       if (isTerminated((SinkEmptyMulticast.Inner<?>[])prevSubscribers)) {
/*  62 */         return Sinks.EmitResult.FAIL_TERMINATED;
/*     */       }
/*     */     } 
/*     */     
/*  66 */     for (SinkEmptyMulticast.Inner<O> as : prevSubscribers) {
/*  67 */       as.complete(value);
/*     */     }
/*     */     
/*  70 */     return Sinks.EmitResult.OK;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  75 */     if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(isTerminated((SinkEmptyMulticast.Inner<?>[])this.subscribers)); 
/*  76 */     if (key == Scannable.Attr.ERROR) return (this.subscribers == TERMINATED_ERROR) ? this.error : null; 
/*  77 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super O> actual) {
/*  84 */     NextInner<O> as = new NextInner<>(actual, this);
/*  85 */     actual.onSubscribe(as);
/*  86 */     int addState = add(as);
/*  87 */     if (addState == 0) {
/*  88 */       if (as.isCancelled()) {
/*  89 */         remove(as);
/*     */       }
/*     */     }
/*  92 */     else if (addState == -1) {
/*  93 */       actual.onError(this.error);
/*     */     }
/*  95 */     else if (addState == -2) {
/*  96 */       as.complete();
/*     */     } else {
/*     */       
/*  99 */       as.complete(this.value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   int add(SinkEmptyMulticast.Inner<O> ps) {
/*     */     while (true) {
/* 106 */       SinkEmptyMulticast.Inner<O>[] a = this.subscribers;
/*     */       
/* 108 */       if (a == TERMINATED_EMPTY) {
/* 109 */         return -2;
/*     */       }
/*     */       
/* 112 */       if (a == TERMINATED_ERROR) {
/* 113 */         return -1;
/*     */       }
/*     */       
/* 116 */       if (a == TERMINATED_VALUE) {
/* 117 */         return 1;
/*     */       }
/*     */       
/* 120 */       int n = a.length;
/* 121 */       SinkEmptyMulticast.Inner[] arrayOfInner = new SinkEmptyMulticast.Inner[n + 1];
/* 122 */       System.arraycopy(a, 0, arrayOfInner, 0, n);
/* 123 */       arrayOfInner[n] = ps;
/*     */       
/* 125 */       if (SUBSCRIBERS.compareAndSet(this, a, arrayOfInner)) {
/* 126 */         return 0;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public O block(Duration timeout) {
/* 134 */     if (timeout.isNegative()) {
/* 135 */       return super.block(Duration.ZERO);
/*     */     }
/* 137 */     return super.block(timeout);
/*     */   }
/*     */   
/*     */   static final class NextInner<T>
/*     */     extends Operators.MonoInnerProducerBase<T> implements SinkEmptyMulticast.Inner<T> {
/*     */     final SinkOneMulticast<T> parent;
/*     */     
/*     */     NextInner(CoreSubscriber<? super T> actual, SinkOneMulticast<T> parent) {
/* 145 */       super(actual);
/* 146 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void doOnCancel() {
/* 151 */       this.parent.remove(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(Throwable t) {
/* 156 */       if (!isCancelled()) {
/* 157 */         actual().onError(t);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 163 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 164 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 166 */       return super.scanUnsafe(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\SinkOneMulticast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */