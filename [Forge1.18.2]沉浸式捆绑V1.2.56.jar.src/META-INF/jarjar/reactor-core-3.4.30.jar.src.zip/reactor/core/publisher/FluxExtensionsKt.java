/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import kotlin.Deprecated;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.ReplaceWith;
/*     */ import kotlin.collections.ArraysKt;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.jvm.functions.Function0;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.markers.KMappedMarker;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.sequences.Sequence;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.reactivestreams.Publisher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 2, d1 = {"\000\001\n\000\n\002\030\002\n\000\n\002\020\000\n\002\b\002\n\002\020\003\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\020\034\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\020\021\n\000\n\002\020\013\n\002\020\030\n\002\020\005\n\002\020\022\n\002\020\006\n\002\020\023\n\002\020\007\n\002\020\024\n\002\020\b\n\002\020\025\n\002\020\t\n\002\020\026\n\002\020\n\n\002\020\027\n\002\020(\n\002\030\002\n\000\n\002\b\003*\001/\032#\020\000\032\b\022\004\022\002H\0020\001\"\n\b\000\020\002\030\001*\0020\003*\006\022\002\b\0030\001H\b\032J\020\004\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002\"\b\b\001\020\005*\0020\006*\b\022\004\022\002H\0020\0012\f\020\007\032\b\022\004\022\002H\0050\b2\022\020\t\032\016\022\004\022\002H\005\022\004\022\0020\0130\nH\007\032#\020\f\032\b\022\004\022\002H\0020\001\"\n\b\000\020\002\030\001*\0020\003*\006\022\002\b\0030\001H\b\032J\020\r\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002\"\b\b\001\020\005*\0020\006*\b\022\004\022\002H\0020\0012\f\020\007\032\b\022\004\022\002H\0050\b2\022\020\016\032\016\022\004\022\002H\005\022\004\022\0020\0060\nH\007\032T\020\017\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003\"\b\b\001\020\005*\0020\006*\b\022\004\022\002H\0020\0012\f\020\007\032\b\022\004\022\002H\0050\b2\030\020\020\032\024\022\004\022\002H\005\022\n\022\b\022\004\022\002H\0020\0210\nH\007\032G\020\022\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003\"\b\b\001\020\005*\0020\006*\b\022\004\022\002H\0020\0012\f\020\007\032\b\022\004\022\002H\0050\b2\006\020\023\032\002H\002H\007¢\006\002\020\024\032*\020\025\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003*\020\022\f\b\001\022\b\022\004\022\002H\0020\0260\001H\007\0322\020\027\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0012\022\020\030\032\016\022\n\022\b\022\004\022\002H\0020\0210\031H\007\032\"\020\032\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003*\b\022\004\022\002H\0020\033H\007\032%\020\032\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\n\022\006\b\001\022\002H\0020\034H\007¢\006\002\020\035\032\022\020\032\032\b\022\004\022\0020\0360\001*\0020\037H\007\032\022\020\032\032\b\022\004\022\0020 0\001*\0020!H\007\032\022\020\032\032\b\022\004\022\0020\"0\001*\0020#H\007\032\022\020\032\032\b\022\004\022\0020$0\001*\0020%H\007\032\022\020\032\032\b\022\004\022\0020&0\001*\0020'H\007\032\022\020\032\032\b\022\004\022\0020(0\001*\0020)H\007\032\022\020\032\032\b\022\004\022\0020*0\001*\0020+H\007\032\030\020\032\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\0020\006H\007\032\"\020\032\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003*\b\022\004\022\002H\0020\026H\007\032\"\020\032\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003*\b\022\004\022\002H\0020,H\007\032\"\020\032\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003*\b\022\004\022\002H\0020-H\007\032\"\020\032\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003*\b\022\004\022\002H\0020\021H\007\032#\020.\032\b\022\004\022\002H\0020/\"\004\b\000\020\002*\b\022\004\022\002H\0020,H\002¢\006\002\0200¨\0061"}, d2 = {"cast", "Lreactor/core/publisher/Flux;", "T", "", "doOnError", "E", "", "exceptionType", "Lkotlin/reflect/KClass;", "onError", "Lkotlin/Function1;", "", "ofType", "onErrorMap", "mapper", "onErrorResume", "fallback", "Lorg/reactivestreams/Publisher;", "onErrorReturn", "value", "(Lreactor/core/publisher/Flux;Lkotlin/reflect/KClass;Ljava/lang/Object;)Lreactor/core/publisher/Flux;", "split", "", "switchIfEmpty", "s", "Lkotlin/Function0;", "toFlux", "Ljava/util/stream/Stream;", "", "([Ljava/lang/Object;)Lreactor/core/publisher/Flux;", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "Lkotlin/sequences/Sequence;", "toIterable", "reactor/core/publisher/FluxExtensionsKt$toIterable$1", "(Ljava/util/Iterator;)Lreactor/core/publisher/FluxExtensionsKt$toIterable$1;", "reactor-core"})
/*     */ public final class FluxExtensionsKt
/*     */ {
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> toFlux(@NotNull Publisher<?> $this$toFlux) {
/*  37 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); Intrinsics.checkExpressionValueIsNotNull(Flux.from($this$toFlux), "Flux.from(this)"); return (Flux)Flux.from($this$toFlux);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> toFlux(@NotNull Iterator<?> $this$toFlux) {
/*  47 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); return toFlux(toIterable($this$toFlux));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> toFlux(@NotNull Iterable<?> $this$toFlux) {
/*  57 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); Intrinsics.checkExpressionValueIsNotNull(Flux.fromIterable($this$toFlux), "Flux.fromIterable(this)"); return (Flux)Flux.fromIterable($this$toFlux);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> toFlux(@NotNull Sequence<? extends T> $this$toFlux)
/*     */   {
/*  67 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); Intrinsics.checkExpressionValueIsNotNull(Flux.fromIterable(new FluxExtensionsKt$toFlux$1($this$toFlux)), "Flux.fromIterable(object…this@toFlux.iterator()\n})"); return (Flux)Flux.fromIterable(new FluxExtensionsKt$toFlux$1($this$toFlux)); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 1, d1 = {"\000\021\n\000\n\002\020\034\n\000\n\002\020(\n\000*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\017\020\002\032\b\022\004\022\0028\0000\003H\002¨\006\004"}, d2 = {"reactor/core/publisher/FluxExtensionsKt$toFlux$1", "", "iterator", "", "reactor-core"}) public static final class FluxExtensionsKt$toFlux$1 implements Iterable<T>, KMappedMarker { @NotNull
/*  68 */     public Iterator<T> iterator() { return this.$this_toFlux.iterator(); }
/*     */ 
/*     */ 
/*     */     
/*     */     FluxExtensionsKt$toFlux$1(Sequence $receiver) {} }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> toFlux(@NotNull Stream<?> $this$toFlux) {
/*  79 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); Intrinsics.checkExpressionValueIsNotNull(Flux.fromStream($this$toFlux), "Flux.fromStream(this)"); return (Flux)Flux.fromStream($this$toFlux);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final Flux<Boolean> toFlux(@NotNull boolean[] $this$toFlux) {
/*  89 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); return toFlux(ArraysKt.toList($this$toFlux));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final Flux<Byte> toFlux(@NotNull byte[] $this$toFlux) {
/*  99 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); return toFlux(ArraysKt.toList($this$toFlux));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final Flux<Short> toFlux(@NotNull short[] $this$toFlux) {
/* 109 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); return toFlux(ArraysKt.toList($this$toFlux));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final Flux<Integer> toFlux(@NotNull int[] $this$toFlux) {
/* 119 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); return toFlux(ArraysKt.toList($this$toFlux));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final Flux<Long> toFlux(@NotNull long[] $this$toFlux) {
/* 129 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); return toFlux(ArraysKt.toList($this$toFlux));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final Flux<Float> toFlux(@NotNull float[] $this$toFlux) {
/* 139 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); return toFlux(ArraysKt.toList($this$toFlux));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final Flux<Double> toFlux(@NotNull double[] $this$toFlux) {
/* 149 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); return toFlux(ArraysKt.toList($this$toFlux));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux()"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> toFlux(@NotNull Object[] $this$toFlux) {
/* 159 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); Intrinsics.checkExpressionValueIsNotNull(Flux.fromArray($this$toFlux), "Flux.fromArray(this)"); return Flux.fromArray($this$toFlux);
/*     */   }
/* 161 */   private static final <T> FluxExtensionsKt$toIterable$1 toIterable(Iterator<? extends T> $this$toIterable) { return new FluxExtensionsKt$toIterable$1($this$toIterable); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 1, d1 = {"\000\021\n\000\n\002\020\034\n\000\n\002\020(\n\000*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\017\020\002\032\b\022\004\022\0028\0000\003H\002¨\006\004"}, d2 = {"reactor/core/publisher/FluxExtensionsKt$toIterable$1", "", "iterator", "", "reactor-core"}) public static final class FluxExtensionsKt$toIterable$1 implements Iterable<T>, KMappedMarker { @NotNull
/* 162 */     public Iterator<T> iterator() { return this.$this_toIterable; }
/*     */ 
/*     */ 
/*     */     
/*     */     FluxExtensionsKt$toIterable$1(Iterator $receiver) {} }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.toFlux"}, expression = "toFlux<T>()"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> toFlux(@NotNull Throwable $this$toFlux) {
/* 173 */     Intrinsics.checkParameterIsNotNull($this$toFlux, "$this$toFlux"); Intrinsics.checkExpressionValueIsNotNull(Flux.error($this$toFlux), "Flux.error(this)"); return (Flux)Flux.error($this$toFlux);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.doOnError"}, expression = "doOnError(exceptionType, onError)"))
/*     */   @NotNull
/*     */   public static final <T, E extends Throwable> Flux<T> doOnError(@NotNull Flux $this$doOnError, @NotNull KClass exceptionType, @NotNull Function1 onError)
/*     */   {
/* 195 */     Intrinsics.checkParameterIsNotNull($this$doOnError, "$this$doOnError"); Intrinsics.checkParameterIsNotNull(exceptionType, "exceptionType"); Intrinsics.checkParameterIsNotNull(onError, "onError"); Intrinsics.checkExpressionValueIsNotNull($this$doOnError.doOnError(JvmClassMappingKt.getJavaClass(exceptionType), new FluxExtensionsKt$doOnError$1(onError)), "doOnError(exceptionType.java) { onError(it) }"); return $this$doOnError.doOnError(JvmClassMappingKt.getJavaClass(exceptionType), new FluxExtensionsKt$doOnError$1(onError)); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\022\n\000\n\002\020\002\n\002\b\002\n\002\020\003\n\002\b\004\020\000\032\0020\001\"\004\b\000\020\002\"\b\b\001\020\003*\0020\0042\016\020\005\032\n \006*\004\030\001H\003H\003H\n¢\006\004\b\007\020\b"}, d2 = {"<anonymous>", "", "T", "E", "", "it", "kotlin.jvm.PlatformType", "accept", "(Ljava/lang/Throwable;)V"}) static final class FluxExtensionsKt$doOnError$1<T> implements Consumer { public final void accept(Throwable it) { Intrinsics.checkExpressionValueIsNotNull(it, "it"); this.$onError.invoke(it); }
/*     */ 
/*     */ 
/*     */     
/*     */     FluxExtensionsKt$doOnError$1(Function1 param1Function1) {} }
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.onErrorMap"}, expression = "onErrorMap(exceptionType, mapper)"))
/*     */   @NotNull
/*     */   public static final <T, E extends Throwable> Flux<T> onErrorMap(@NotNull Flux $this$onErrorMap, @NotNull KClass exceptionType, @NotNull Function1 mapper)
/*     */   {
/* 206 */     Intrinsics.checkParameterIsNotNull($this$onErrorMap, "$this$onErrorMap"); Intrinsics.checkParameterIsNotNull(exceptionType, "exceptionType"); Intrinsics.checkParameterIsNotNull(mapper, "mapper"); Intrinsics.checkExpressionValueIsNotNull($this$onErrorMap.onErrorMap(JvmClassMappingKt.getJavaClass(exceptionType), new FluxExtensionsKt$onErrorMap$1<>(mapper)), "onErrorMap(exceptionType.java) { mapper(it) }"); return $this$onErrorMap.onErrorMap(JvmClassMappingKt.getJavaClass(exceptionType), new FluxExtensionsKt$onErrorMap$1<>(mapper)); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\n\n\000\n\002\020\003\n\002\b\006\020\000\032\0020\001\"\004\b\000\020\002\"\b\b\001\020\003*\0020\0012\016\020\004\032\n \005*\004\030\001H\003H\003H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "T", "E", "it", "kotlin.jvm.PlatformType", "apply", "(Ljava/lang/Throwable;)Ljava/lang/Throwable;"}) static final class FluxExtensionsKt$onErrorMap$1<T, R> implements Function { @NotNull public final Throwable apply(Throwable it) { Intrinsics.checkExpressionValueIsNotNull(it, "it"); return (Throwable)this.$mapper.invoke(it); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FluxExtensionsKt$onErrorMap$1(Function1 param1Function1) {} }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.onErrorResume"}, expression = "onErrorResume(exceptionType, fallback)"))
/*     */   @NotNull
/*     */   public static final <T, E extends Throwable> Flux<T> onErrorResume(@NotNull Flux $this$onErrorResume, @NotNull KClass exceptionType, @NotNull Function1 fallback)
/*     */   {
/* 227 */     Intrinsics.checkParameterIsNotNull($this$onErrorResume, "$this$onErrorResume"); Intrinsics.checkParameterIsNotNull(exceptionType, "exceptionType"); Intrinsics.checkParameterIsNotNull(fallback, "fallback"); Intrinsics.checkExpressionValueIsNotNull($this$onErrorResume.onErrorResume(JvmClassMappingKt.getJavaClass(exceptionType), new FluxExtensionsKt$onErrorResume$1<>(fallback)), "onErrorResume(exceptionType.java) { fallback(it) }"); return $this$onErrorResume.onErrorResume(JvmClassMappingKt.getJavaClass(exceptionType), new FluxExtensionsKt$onErrorResume$1<>(fallback)); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\026\n\000\n\002\030\002\n\000\n\002\020\000\n\000\n\002\020\003\n\002\b\004\020\000\032\b\022\004\022\002H\0020\001\"\b\b\000\020\002*\0020\003\"\b\b\001\020\004*\0020\0052\016\020\006\032\n \007*\004\030\001H\004H\004H\n¢\006\004\b\b\020\t"}, d2 = {"<anonymous>", "Lorg/reactivestreams/Publisher;", "T", "", "E", "", "it", "kotlin.jvm.PlatformType", "apply", "(Ljava/lang/Throwable;)Lorg/reactivestreams/Publisher;"}) static final class FluxExtensionsKt$onErrorResume$1<T, R> implements Function { @NotNull public final Publisher<T> apply(Throwable it) { Intrinsics.checkExpressionValueIsNotNull(it, "it"); return (Publisher<T>)this.$fallback.invoke(it); }
/*     */ 
/*     */ 
/*     */     
/*     */     FluxExtensionsKt$onErrorResume$1(Function1 param1Function1) {} }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.onErrorReturn"}, expression = "onErrorReturn(exceptionType, value)"))
/*     */   @NotNull
/*     */   public static final <T, E extends Throwable> Flux<T> onErrorReturn(@NotNull Flux $this$onErrorReturn, @NotNull KClass exceptionType, @NotNull Object value) {
/* 238 */     Intrinsics.checkParameterIsNotNull($this$onErrorReturn, "$this$onErrorReturn"); Intrinsics.checkParameterIsNotNull(exceptionType, "exceptionType"); Intrinsics.checkParameterIsNotNull(value, "value"); Intrinsics.checkExpressionValueIsNotNull($this$onErrorReturn.onErrorReturn(JvmClassMappingKt.getJavaClass(exceptionType), value), "onErrorReturn(exceptionType.java, value)"); return $this$onErrorReturn.onErrorReturn(JvmClassMappingKt.getJavaClass(exceptionType), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.split"}, expression = "split()"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> split(@NotNull Flux $this$split)
/*     */   {
/* 248 */     Intrinsics.checkParameterIsNotNull($this$split, "$this$split"); Intrinsics.checkExpressionValueIsNotNull($this$split.flatMapIterable(FluxExtensionsKt$split$1.INSTANCE), "this.flatMapIterable { it }"); return $this$split.flatMapIterable(FluxExtensionsKt$split$1.INSTANCE); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\022\n\000\n\002\020\034\n\002\b\002\n\002\020\000\n\002\b\002\020\000\032\026\022\004\022\002H\002 \003*\n\022\004\022\002H\002\030\0010\0010\001\"\b\b\000\020\002*\0020\0042\032\020\005\032\026\022\004\022\002H\002 \003*\n\022\004\022\002H\002\030\0010\0010\001H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "T", "kotlin.jvm.PlatformType", "", "it", "apply"}) static final class FluxExtensionsKt$split$1<T, R> implements Function { public final Iterable<T> apply(Iterable<T> it) { return it; }
/*     */ 
/*     */ 
/*     */     
/*     */     public static final FluxExtensionsKt$split$1 INSTANCE = new FluxExtensionsKt$split$1(); }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "To be removed in 3.3.0.RELEASE, replaced by module reactor-kotlin-extensions", replaceWith = @ReplaceWith(imports = {"reactor.kotlin.core.publisher.switchIfEmpty"}, expression = "switchIfEmpty(s)"))
/*     */   @NotNull
/*     */   public static final <T> Flux<T> switchIfEmpty(@NotNull Flux $this$switchIfEmpty, @NotNull Function0 s) {
/* 259 */     Intrinsics.checkParameterIsNotNull($this$switchIfEmpty, "$this$switchIfEmpty"); Intrinsics.checkParameterIsNotNull(s, "s"); Intrinsics.checkExpressionValueIsNotNull($this$switchIfEmpty.switchIfEmpty((Publisher)Flux.defer(new FluxExtensionsKt$switchIfEmpty$1(s))), "this.switchIfEmpty(Flux.defer { s() })"); return $this$switchIfEmpty.switchIfEmpty((Publisher)Flux.defer(new FluxExtensionsKt$switchIfEmpty$1(s))); } @Metadata(mv = {1, 1, 18}, bv = {1, 0, 3}, k = 3, d1 = {"\000\n\n\000\n\002\030\002\n\002\b\002\020\000\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "Lorg/reactivestreams/Publisher;", "T", "get"}) static final class FluxExtensionsKt$switchIfEmpty$1<T> implements Supplier { @NotNull public final Publisher<T> get() { return (Publisher<T>)this.$s.invoke(); }
/*     */ 
/*     */     
/*     */     FluxExtensionsKt$switchIfEmpty$1(Function0 param1Function0) {} }
/*     */ 
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */