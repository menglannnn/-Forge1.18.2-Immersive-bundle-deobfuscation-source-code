/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxOnBackpressureBufferTimeout<O>
/*     */   extends InternalFluxOperator<O, O>
/*     */ {
/*  52 */   private static final Logger LOGGER = Loggers.getLogger(FluxOnBackpressureBufferTimeout.class);
/*     */   
/*     */   final Duration ttl;
/*     */   
/*     */   final Scheduler ttlScheduler;
/*     */   
/*     */   final int bufferSize;
/*     */   
/*     */   final Consumer<? super O> onBufferEviction;
/*     */ 
/*     */   
/*     */   FluxOnBackpressureBufferTimeout(Flux<? extends O> source, Duration ttl, Scheduler ttlScheduler, int bufferSize, Consumer<? super O> onBufferEviction) {
/*  64 */     super(source);
/*  65 */     this.ttl = ttl;
/*  66 */     this.ttlScheduler = ttlScheduler;
/*  67 */     this.bufferSize = bufferSize;
/*  68 */     this.onBufferEviction = onBufferEviction;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super O> subscribeOrReturn(CoreSubscriber<? super O> actual) {
/*  73 */     return new BackpressureBufferTimeoutSubscriber<>(actual, this.ttl, this.ttlScheduler, this.bufferSize, this.onBufferEviction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  82 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  87 */     if (key == Scannable.Attr.RUN_ON) return this.ttlScheduler; 
/*  88 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.ASYNC;
/*     */     
/*  90 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BackpressureBufferTimeoutSubscriber<T>
/*     */     extends ArrayDeque<Object>
/*     */     implements InnerOperator<T, T>, Runnable
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final Duration ttl;
/*     */     
/*     */     final Scheduler ttlScheduler;
/*     */     final Scheduler.Worker worker;
/*     */     final int bufferSizeDouble;
/*     */     final Consumer<? super T> onBufferEviction;
/*     */     Subscription s;
/*     */     volatile boolean cancelled;
/*     */     volatile boolean done;
/*     */     Throwable error;
/*     */     volatile int wip;
/* 113 */     static final AtomicIntegerFieldUpdater<BackpressureBufferTimeoutSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(BackpressureBufferTimeoutSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */     
/* 118 */     static final AtomicLongFieldUpdater<BackpressureBufferTimeoutSubscriber> REQUESTED = AtomicLongFieldUpdater.newUpdater(BackpressureBufferTimeoutSubscriber.class, "requested");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BackpressureBufferTimeoutSubscriber(CoreSubscriber<? super T> actual, Duration ttl, Scheduler ttlScheduler, int bufferSize, Consumer<? super T> onBufferEviction) {
/* 127 */       this.actual = actual;
/* 128 */       this.ctx = actual.currentContext();
/* 129 */       this.onBufferEviction = Objects.<Consumer<? super T>>requireNonNull(onBufferEviction, "buffer eviction callback must not be null");
/*     */       
/* 131 */       this.bufferSizeDouble = bufferSize << 1;
/* 132 */       this.ttl = ttl;
/* 133 */       this.ttlScheduler = Objects.<Scheduler>requireNonNull(ttlScheduler, "ttl Scheduler must not be null");
/*     */       
/* 135 */       this.worker = ttlScheduler.createWorker();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 141 */       if (key == Scannable.Attr.PARENT) {
/* 142 */         return this.s;
/*     */       }
/* 144 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/* 145 */         return Long.valueOf(this.requested);
/*     */       }
/* 147 */       if (key == Scannable.Attr.TERMINATED) {
/* 148 */         return Boolean.valueOf((this.done && isEmpty()));
/*     */       }
/* 150 */       if (key == Scannable.Attr.CANCELLED) {
/* 151 */         return Boolean.valueOf(this.cancelled);
/*     */       }
/* 153 */       if (key == Scannable.Attr.BUFFERED) {
/* 154 */         return Integer.valueOf(size());
/*     */       }
/* 156 */       if (key == Scannable.Attr.ERROR) {
/* 157 */         return this.error;
/*     */       }
/* 159 */       if (key == Scannable.Attr.PREFETCH) {
/* 160 */         return Integer.valueOf(2147483647);
/*     */       }
/* 162 */       if (key == Scannable.Attr.DELAY_ERROR) {
/* 163 */         return Boolean.valueOf(false);
/*     */       }
/* 165 */       if (key == Scannable.Attr.RUN_ON) {
/* 166 */         return this.ttlScheduler;
/*     */       }
/* 168 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 169 */         return Scannable.Attr.RunStyle.ASYNC;
/*     */       }
/*     */       
/* 172 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 177 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 182 */       if (Operators.validate(n)) {
/* 183 */         Operators.addCap(REQUESTED, this, n);
/* 184 */         drain();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 190 */       this.cancelled = true;
/* 191 */       this.s.cancel();
/* 192 */       this.worker.dispose();
/*     */       
/* 194 */       if (WIP.getAndIncrement(this) == 0) {
/* 195 */         clearQueue();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void clearQueue() {
/*     */       while (true) {
/*     */         T evicted;
/* 203 */         synchronized (this) {
/* 204 */           if (isEmpty()) {
/*     */             break;
/*     */           }
/*     */           
/* 208 */           poll();
/* 209 */           evicted = (T)poll();
/*     */         } 
/*     */         
/* 212 */         evict(evicted);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 218 */       if (Operators.validate(this.s, s)) {
/* 219 */         this.s = s;
/*     */         
/* 221 */         this.actual.onSubscribe(this);
/*     */         
/* 223 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 230 */       T evicted = null;
/* 231 */       synchronized (this) {
/* 232 */         if (size() == this.bufferSizeDouble) {
/* 233 */           poll();
/* 234 */           evicted = (T)poll();
/*     */         } 
/* 236 */         offer(Long.valueOf(this.ttlScheduler.now(TimeUnit.NANOSECONDS)));
/* 237 */         offer(t);
/*     */       } 
/* 239 */       evict(evicted);
/*     */       try {
/* 241 */         this.worker.schedule(this, this.ttl.toNanos(), TimeUnit.NANOSECONDS);
/*     */       }
/* 243 */       catch (RejectedExecutionException re) {
/* 244 */         this.done = true;
/* 245 */         this.error = Operators.onRejectedExecution(re, this, null, t, this.actual
/* 246 */             .currentContext());
/*     */       } 
/* 248 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 253 */       this.error = t;
/* 254 */       this.done = true;
/* 255 */       drain();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 260 */       this.done = true;
/* 261 */       drain();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 268 */       while (!this.cancelled) {
/*     */ 
/*     */ 
/*     */         
/* 272 */         boolean empty, d = this.done;
/*     */         
/* 274 */         T evicted = null;
/*     */         
/* 276 */         synchronized (this) {
/* 277 */           Long ts = (Long)peek();
/* 278 */           empty = (ts == null);
/* 279 */           if (!empty) {
/* 280 */             if (ts.longValue() <= this.ttlScheduler.now(TimeUnit.NANOSECONDS) - this.ttl.toNanos()) {
/* 281 */               poll();
/* 282 */               evicted = (T)poll();
/*     */             } else {
/*     */               break;
/*     */             } 
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 290 */         evict(evicted);
/*     */         
/* 292 */         if (empty) {
/* 293 */           if (d) {
/* 294 */             drain();
/*     */           }
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void evict(@Nullable T evicted) {
/* 302 */       if (evicted != null) {
/*     */         try {
/* 304 */           this.onBufferEviction.accept(evicted);
/*     */         }
/* 306 */         catch (Throwable ex) {
/* 307 */           if (FluxOnBackpressureBufferTimeout.LOGGER.isDebugEnabled()) {
/* 308 */             FluxOnBackpressureBufferTimeout.LOGGER.debug("value [{}] couldn't be evicted due to a callback error. This error will be dropped: {}", new Object[] { evicted, ex });
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 313 */           Operators.onErrorDropped(ex, this.actual.currentContext());
/*     */         } 
/* 315 */         Operators.onDiscard(evicted, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void drain() {
/* 321 */       if (WIP.getAndIncrement(this) != 0) {
/*     */         return;
/*     */       }
/*     */       
/* 325 */       int missed = 1;
/*     */       
/*     */       do {
/* 328 */         long r = this.requested;
/* 329 */         long e = 0L;
/*     */         
/* 331 */         while (e != r) {
/* 332 */           T v; if (this.cancelled) {
/* 333 */             clearQueue();
/*     */             
/*     */             return;
/*     */           } 
/* 337 */           boolean d = this.done;
/*     */ 
/*     */           
/* 340 */           synchronized (this) {
/* 341 */             if (poll() != null) {
/* 342 */               v = (T)poll();
/*     */             } else {
/*     */               
/* 345 */               v = null;
/*     */             } 
/*     */           } 
/*     */           
/* 349 */           boolean empty = (v == null);
/*     */           
/* 351 */           if (d && empty) {
/* 352 */             Throwable ex = this.error;
/* 353 */             if (ex != null) {
/* 354 */               this.actual.onError(ex);
/*     */             } else {
/*     */               
/* 357 */               this.actual.onComplete();
/*     */             } 
/*     */             
/* 360 */             this.worker.dispose();
/*     */             
/*     */             return;
/*     */           } 
/* 364 */           if (empty) {
/*     */             break;
/*     */           }
/*     */           
/* 368 */           this.actual.onNext(v);
/*     */           
/* 370 */           e++;
/*     */         } 
/*     */         
/* 373 */         if (e == r) {
/* 374 */           boolean empty; if (this.cancelled) {
/* 375 */             clearQueue();
/*     */             
/*     */             return;
/*     */           } 
/* 379 */           boolean d = this.done;
/*     */           
/* 381 */           synchronized (this) {
/* 382 */             empty = isEmpty();
/*     */           } 
/*     */           
/* 385 */           if (d && empty) {
/* 386 */             Throwable ex = this.error;
/* 387 */             if (ex != null) {
/* 388 */               this.actual.onError(ex);
/*     */             } else {
/*     */               
/* 391 */               this.actual.onComplete();
/*     */             } 
/*     */             
/* 394 */             this.worker.dispose();
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 399 */         if (e != 0L && r != Long.MAX_VALUE) {
/* 400 */           REQUESTED.addAndGet(this, -e);
/*     */         }
/*     */         
/* 403 */         missed = WIP.addAndGet(this, -missed);
/* 404 */       } while (missed != 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxOnBackpressureBufferTimeout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */