/*      */ package reactor.core.publisher;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.Objects;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Stream;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscriber;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CoreSubscriber;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Fuseable;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class FluxZip<T, R>
/*      */   extends Flux<R>
/*      */   implements SourceProducer<R>
/*      */ {
/*      */   final Publisher<? extends T>[] sources;
/*      */   final Iterable<? extends Publisher<? extends T>> sourcesIterable;
/*      */   final Function<? super Object[], ? extends R> zipper;
/*      */   final Supplier<? extends Queue<T>> queueSupplier;
/*      */   final int prefetch;
/*      */   
/*      */   <U> FluxZip(Publisher<? extends T> p1, Publisher<? extends U> p2, BiFunction<? super T, ? super U, ? extends R> zipper2, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/*   71 */     this((Publisher<? extends T>[])new Publisher[] { Objects.<Publisher>requireNonNull(p1, "p1"), 
/*   72 */           Objects.<Publisher>requireNonNull(p2, "p2") }new PairwiseZipper<>(new BiFunction[] {
/*      */             
/*   74 */             Objects.<BiFunction>requireNonNull(zipper2, "zipper2") }), queueSupplier, prefetch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   FluxZip(Publisher<? extends T>[] sources, Function<? super Object[], ? extends R> zipper, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/*   83 */     if (prefetch <= 0) {
/*   84 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*      */     }
/*   86 */     this.sources = Objects.<Publisher<? extends T>[]>requireNonNull(sources, "sources");
/*   87 */     if (sources.length == 0) {
/*   88 */       throw new IllegalArgumentException("at least one source is required");
/*      */     }
/*   90 */     this.sourcesIterable = null;
/*   91 */     this.zipper = Objects.<Function<? super Object[], ? extends R>>requireNonNull(zipper, "zipper");
/*   92 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*   93 */     this.prefetch = prefetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   FluxZip(Iterable<? extends Publisher<? extends T>> sourcesIterable, Function<? super Object[], ? extends R> zipper, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/*  100 */     if (prefetch <= 0) {
/*  101 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*      */     }
/*  103 */     this.sources = null;
/*  104 */     this.sourcesIterable = Objects.<Iterable<? extends Publisher<? extends T>>>requireNonNull(sourcesIterable, "sourcesIterable");
/*  105 */     this.zipper = Objects.<Function<? super Object[], ? extends R>>requireNonNull(zipper, "zipper");
/*  106 */     this.queueSupplier = Objects.<Supplier<? extends Queue<T>>>requireNonNull(queueSupplier, "queueSupplier");
/*  107 */     this.prefetch = prefetch;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPrefetch() {
/*  112 */     return this.prefetch;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   FluxZip<T, R> zipAdditionalSource(Publisher source, BiFunction zipper) {
/*  118 */     Publisher<? extends T>[] arrayOfPublisher = this.sources;
/*  119 */     if (arrayOfPublisher != null && this.zipper instanceof PairwiseZipper) {
/*  120 */       int oldLen = arrayOfPublisher.length;
/*  121 */       Publisher[] arrayOfPublisher1 = new Publisher[oldLen + 1];
/*  122 */       System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, oldLen);
/*  123 */       arrayOfPublisher1[oldLen] = source;
/*      */       
/*  125 */       Function<Object[], R> z = ((PairwiseZipper)this.zipper).then(zipper);
/*      */       
/*  127 */       return new FluxZip((Publisher<? extends T>[])arrayOfPublisher1, z, this.queueSupplier, this.prefetch);
/*      */     } 
/*  129 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void subscribe(CoreSubscriber<? super R> actual) {
/*  134 */     Publisher<? extends T>[] srcs = this.sources;
/*      */     try {
/*  136 */       if (srcs != null) {
/*  137 */         handleArrayMode(actual, srcs);
/*      */       } else {
/*      */         
/*  140 */         handleIterableMode(actual, this.sourcesIterable);
/*      */       }
/*      */     
/*  143 */     } catch (Throwable e) {
/*  144 */       Operators.reportThrowInSubscribe(actual, e);
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void handleIterableMode(CoreSubscriber<? super R> s, Iterable<? extends Publisher<? extends T>> sourcesIterable) {
/*  152 */     Object[] scalars = new Object[8];
/*  153 */     Publisher[] arrayOfPublisher = new Publisher[8];
/*      */     
/*  155 */     int n = 0;
/*  156 */     int sc = 0;
/*      */     
/*  158 */     for (Publisher<? extends T> p : sourcesIterable) {
/*  159 */       if (p == null) {
/*  160 */         Operators.error((Subscriber<?>)s, 
/*  161 */             Operators.onOperatorError(new NullPointerException("The sourcesIterable returned a null Publisher"), s
/*      */               
/*  163 */               .currentContext()));
/*      */         
/*      */         return;
/*      */       } 
/*  167 */       if (p instanceof Callable) {
/*  168 */         T v; Callable<T> callable = (Callable)p;
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  173 */           v = callable.call();
/*      */         }
/*  175 */         catch (Throwable e) {
/*  176 */           Operators.error((Subscriber<?>)s, Operators.onOperatorError(e, s
/*  177 */                 .currentContext()));
/*      */           
/*      */           return;
/*      */         } 
/*  181 */         if (v == null) {
/*  182 */           Operators.complete((Subscriber<?>)s);
/*      */           
/*      */           return;
/*      */         } 
/*  186 */         if (n == scalars.length) {
/*  187 */           Object[] b = new Object[n + (n >> 1)];
/*  188 */           System.arraycopy(scalars, 0, b, 0, n);
/*      */           
/*  190 */           Publisher[] arrayOfPublisher1 = new Publisher[b.length];
/*      */           
/*  192 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/*      */           
/*  194 */           scalars = b;
/*  195 */           arrayOfPublisher = arrayOfPublisher1;
/*      */         } 
/*      */         
/*  198 */         scalars[n] = v;
/*  199 */         sc++;
/*      */       } else {
/*      */         
/*  202 */         if (n == arrayOfPublisher.length) {
/*  203 */           Object[] b = new Object[n + (n >> 1)];
/*  204 */           System.arraycopy(scalars, 0, b, 0, n);
/*      */           
/*  206 */           Publisher[] arrayOfPublisher1 = new Publisher[b.length];
/*      */           
/*  208 */           System.arraycopy(arrayOfPublisher, 0, arrayOfPublisher1, 0, n);
/*      */           
/*  210 */           scalars = b;
/*  211 */           arrayOfPublisher = arrayOfPublisher1;
/*      */         } 
/*  213 */         arrayOfPublisher[n] = p;
/*      */       } 
/*  215 */       n++;
/*      */     } 
/*      */     
/*  218 */     if (n == 0) {
/*  219 */       Operators.complete((Subscriber<?>)s);
/*      */       
/*      */       return;
/*      */     } 
/*  223 */     if (n < scalars.length) {
/*  224 */       scalars = Arrays.copyOfRange(scalars, 0, n, (Class)scalars.getClass());
/*      */     }
/*      */     
/*  227 */     handleBoth(s, (Publisher<? extends T>[])arrayOfPublisher, scalars, n, sc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void handleArrayMode(CoreSubscriber<? super R> s, Publisher<? extends T>[] srcs) {
/*  233 */     Object[] scalars = null;
/*  234 */     int n = srcs.length;
/*      */     
/*  236 */     int sc = 0;
/*      */     
/*  238 */     for (int j = 0; j < n; j++) {
/*  239 */       Publisher<? extends T> p = srcs[j];
/*      */       
/*  241 */       if (p == null) {
/*  242 */         Operators.error((Subscriber<?>)s, new NullPointerException("The sources contained a null Publisher"));
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  247 */       if (p instanceof Callable) {
/*      */         Object v;
/*      */         
/*      */         try {
/*  251 */           v = ((Callable)p).call();
/*      */         }
/*  253 */         catch (Throwable e) {
/*  254 */           Operators.error((Subscriber<?>)s, Operators.onOperatorError(e, s
/*  255 */                 .currentContext()));
/*      */           
/*      */           return;
/*      */         } 
/*  259 */         if (v == null) {
/*  260 */           Operators.complete((Subscriber<?>)s);
/*      */           
/*      */           return;
/*      */         } 
/*  264 */         if (scalars == null) {
/*  265 */           scalars = new Object[n];
/*      */         }
/*      */         
/*  268 */         scalars[j] = v;
/*  269 */         sc++;
/*      */       } 
/*      */     } 
/*      */     
/*  273 */     handleBoth(s, srcs, scalars, n, sc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleBoth(CoreSubscriber<? super R> s, Publisher<? extends T>[] srcs, @Nullable Object[] scalars, int n, int sc) {
/*  297 */     if (sc != 0 && scalars != null) {
/*  298 */       if (n != sc) {
/*  299 */         ZipSingleCoordinator<T, R> coordinator = new ZipSingleCoordinator<>(s, scalars, n, sc, this.zipper);
/*      */ 
/*      */         
/*  302 */         s.onSubscribe(coordinator);
/*      */         
/*  304 */         coordinator.subscribe(n, srcs);
/*      */       } else {
/*      */         R r;
/*  307 */         Operators.MonoSubscriber<R, R> sds = new Operators.MonoSubscriber<>(s);
/*      */         
/*  309 */         s.onSubscribe(sds);
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  314 */           r = Objects.requireNonNull(this.zipper.apply(scalars), "The zipper returned a null value");
/*      */         
/*      */         }
/*  317 */         catch (Throwable e) {
/*  318 */           s.onError(Operators.onOperatorError(e, s.currentContext()));
/*      */           
/*      */           return;
/*      */         } 
/*  322 */         sds.complete(r);
/*      */       } 
/*      */     } else {
/*      */       
/*  326 */       ZipCoordinator<T, R> coordinator = new ZipCoordinator<>(s, this.zipper, n, this.queueSupplier, this.prefetch);
/*      */ 
/*      */       
/*  329 */       s.onSubscribe(coordinator);
/*      */       
/*  331 */       coordinator.subscribe(srcs, n);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Object scanUnsafe(Scannable.Attr key) {
/*  337 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/*  338 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  339 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   static final class ZipSingleCoordinator<T, R>
/*      */     extends Operators.MonoSubscriber<R, R>
/*      */   {
/*      */     final Function<? super Object[], ? extends R> zipper;
/*      */     
/*      */     final Object[] scalars;
/*      */     
/*      */     final FluxZip.ZipSingleSubscriber<T>[] subscribers;
/*      */     
/*      */     volatile int wip;
/*  353 */     static final AtomicIntegerFieldUpdater<ZipSingleCoordinator> WIP = AtomicIntegerFieldUpdater.newUpdater(ZipSingleCoordinator.class, "wip");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ZipSingleCoordinator(CoreSubscriber<? super R> subscriber, Object[] scalars, int n, int sc, Function<? super Object[], ? extends R> zipper) {
/*  361 */       super(subscriber);
/*  362 */       this.zipper = zipper;
/*  363 */       this.scalars = scalars;
/*  364 */       FluxZip.ZipSingleSubscriber[] arrayOfZipSingleSubscriber = new FluxZip.ZipSingleSubscriber[n];
/*  365 */       for (int i = 0; i < n; i++) {
/*  366 */         if (scalars[i] == null) {
/*  367 */           arrayOfZipSingleSubscriber[i] = new FluxZip.ZipSingleSubscriber<>(this, i);
/*      */         }
/*      */       } 
/*  370 */       this.subscribers = (FluxZip.ZipSingleSubscriber<T>[])arrayOfZipSingleSubscriber;
/*  371 */       WIP.lazySet(this, n - sc);
/*      */     }
/*      */     
/*      */     void subscribe(int n, Publisher<? extends T>[] sources) {
/*  375 */       FluxZip.ZipSingleSubscriber<T>[] a = this.subscribers;
/*  376 */       for (int i = 0; i < n && 
/*  377 */         this.wip > 0 && !isCancelled(); i++) {
/*      */ 
/*      */         
/*  380 */         FluxZip.ZipSingleSubscriber<T> s = a[i];
/*  381 */         if (s != null) {
/*      */           try {
/*  383 */             sources[i].subscribe((Subscriber)s);
/*      */           }
/*  385 */           catch (Throwable e) {
/*  386 */             Operators.reportThrowInSubscribe(s, e);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     void next(T value, int index) {
/*  393 */       Object[] a = this.scalars;
/*  394 */       a[index] = value;
/*  395 */       int wip = WIP.decrementAndGet(this);
/*  396 */       if (wip == 0) {
/*      */         R r;
/*      */         
/*      */         try {
/*  400 */           r = Objects.requireNonNull(this.zipper.apply(a), "The zipper returned a null value");
/*      */         
/*      */         }
/*  403 */         catch (Throwable e) {
/*  404 */           this.actual.onError(Operators.onOperatorError(this, e, value, this.actual
/*  405 */                 .currentContext()));
/*      */           
/*      */           return;
/*      */         } 
/*  409 */         complete(r);
/*  410 */       } else if (wip < 0) {
/*  411 */         Operators.onDiscard(value, this.actual.currentContext());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void error(Throwable e, int index) {
/*  418 */       if (WIP.getAndSet(this, 0) > 0) {
/*  419 */         cancelAll();
/*  420 */         this.actual.onError(e);
/*      */       } else {
/*      */         
/*  423 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*      */       } 
/*      */     }
/*      */     
/*      */     void complete(int index) {
/*  428 */       if (WIP.getAndSet(this, 0) > 0) {
/*  429 */         cancelAll();
/*  430 */         this.actual.onComplete();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  436 */       super.cancel();
/*  437 */       if (WIP.getAndSet(this, 0) > 0) {
/*  438 */         cancelAll();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     protected void discard(R v) {
/*  444 */       if (v != null) {
/*  445 */         if (v instanceof Iterable) {
/*  446 */           Operators.onDiscardMultiple(((Iterable)v).iterator(), true, this.actual.currentContext());
/*      */         }
/*  448 */         else if (v.getClass()
/*  449 */           .isArray()) {
/*  450 */           Operators.onDiscardMultiple(Arrays.asList((Object[])v), this.actual.currentContext());
/*      */         } else {
/*      */           
/*  453 */           Operators.onDiscard(v, this.actual.currentContext());
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  461 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.wip == 0 && !isCancelled())); 
/*  462 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.wip > 0) ? this.scalars.length : 0); 
/*  463 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/*  465 */       return super.scanUnsafe(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<? extends Scannable> inners() {
/*  470 */       return Stream.of((Scannable[])this.subscribers);
/*      */     }
/*      */     
/*      */     void cancelAll() {
/*  474 */       for (FluxZip.ZipSingleSubscriber<T> s : this.subscribers) {
/*  475 */         if (s != null) {
/*  476 */           s.dispose();
/*      */         }
/*      */       } 
/*  479 */       Object[] scalars = this.scalars;
/*  480 */       Operators.onDiscardMultiple(Arrays.asList(scalars), this.actual.currentContext());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class ZipSingleSubscriber<T>
/*      */     implements InnerConsumer<T>, Disposable
/*      */   {
/*      */     final FluxZip.ZipSingleCoordinator<T, ?> parent;
/*      */     
/*      */     final int index;
/*      */     
/*      */     volatile Subscription s;
/*      */     
/*  494 */     static final AtomicReferenceFieldUpdater<ZipSingleSubscriber, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ZipSingleSubscriber.class, Subscription.class, "s");
/*      */     
/*      */     boolean done;
/*      */     
/*      */     boolean hasFirstValue;
/*      */ 
/*      */     
/*      */     ZipSingleSubscriber(FluxZip.ZipSingleCoordinator<T, ?> parent, int index) {
/*  502 */       this.parent = parent;
/*  503 */       this.index = index;
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/*  508 */       return this.parent.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  514 */       if (key == Scannable.Attr.PARENT) return this.s; 
/*  515 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done || this.hasFirstValue)); 
/*  516 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/*  517 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/*  518 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.parent.scalars[this.index] == null) ? 0 : 1); 
/*  519 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/*  521 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  526 */       if (Operators.setOnce(S, this, s)) {
/*  527 */         this.s = s;
/*  528 */         s.request(Long.MAX_VALUE);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/*  534 */       if (this.done) {
/*  535 */         Operators.onNextDropped(t, this.parent.currentContext());
/*      */       }
/*      */       
/*  538 */       if (this.hasFirstValue) {
/*  539 */         Operators.onDiscard(t, this.parent.currentContext());
/*      */         
/*      */         return;
/*      */       } 
/*  543 */       this.hasFirstValue = true;
/*  544 */       Operators.terminate(S, this);
/*  545 */       this.parent.next(t, this.index);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/*  550 */       if (this.hasFirstValue || this.done) {
/*  551 */         Operators.onErrorDropped(t, this.parent.currentContext());
/*      */         return;
/*      */       } 
/*  554 */       this.done = true;
/*  555 */       this.parent.error(t, this.index);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/*  560 */       if (this.hasFirstValue || this.done) {
/*      */         return;
/*      */       }
/*  563 */       this.done = true;
/*  564 */       this.parent.complete(this.index);
/*      */     }
/*      */ 
/*      */     
/*      */     public void dispose() {
/*  569 */       Operators.terminate(S, this);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class ZipCoordinator<T, R>
/*      */     implements InnerProducer<R>
/*      */   {
/*      */     final CoreSubscriber<? super R> actual;
/*      */     
/*      */     final FluxZip.ZipInner<T>[] subscribers;
/*      */     
/*      */     final Function<? super Object[], ? extends R> zipper;
/*      */     
/*      */     volatile int wip;
/*      */     
/*  585 */     static final AtomicIntegerFieldUpdater<ZipCoordinator> WIP = AtomicIntegerFieldUpdater.newUpdater(ZipCoordinator.class, "wip");
/*      */ 
/*      */     
/*      */     volatile long requested;
/*      */     
/*  590 */     static final AtomicLongFieldUpdater<ZipCoordinator> REQUESTED = AtomicLongFieldUpdater.newUpdater(ZipCoordinator.class, "requested");
/*      */ 
/*      */     
/*      */     volatile Throwable error;
/*      */     
/*  595 */     static final AtomicReferenceFieldUpdater<ZipCoordinator, Throwable> ERROR = AtomicReferenceFieldUpdater.newUpdater(ZipCoordinator.class, Throwable.class, "error");
/*      */ 
/*      */ 
/*      */     
/*      */     volatile boolean cancelled;
/*      */ 
/*      */ 
/*      */     
/*      */     final Object[] current;
/*      */ 
/*      */ 
/*      */     
/*      */     ZipCoordinator(CoreSubscriber<? super R> actual, Function<? super Object[], ? extends R> zipper, int n, Supplier<? extends Queue<T>> queueSupplier, int prefetch) {
/*  608 */       this.actual = actual;
/*  609 */       this.zipper = zipper;
/*  610 */       FluxZip.ZipInner[] arrayOfZipInner = new FluxZip.ZipInner[n];
/*  611 */       for (int i = 0; i < n; i++) {
/*  612 */         arrayOfZipInner[i] = new FluxZip.ZipInner<>(this, prefetch, i, queueSupplier);
/*      */       }
/*  614 */       this.current = new Object[n];
/*  615 */       this.subscribers = (FluxZip.ZipInner<T>[])arrayOfZipInner;
/*      */     }
/*      */     
/*      */     void subscribe(Publisher<? extends T>[] sources, int n) {
/*  619 */       FluxZip.ZipInner<T>[] a = this.subscribers;
/*  620 */       for (int i = 0; i < n; i++) {
/*  621 */         if (this.cancelled || this.error != null) {
/*      */           return;
/*      */         }
/*  624 */         FluxZip.ZipInner<T> s = a[i];
/*      */         try {
/*  626 */           sources[i].subscribe((Subscriber)s);
/*      */         }
/*  628 */         catch (Throwable e) {
/*  629 */           Operators.reportThrowInSubscribe(s, e);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void request(long n) {
/*  636 */       if (Operators.validate(n)) {
/*  637 */         Operators.addCap(REQUESTED, this, n);
/*  638 */         drain(null, null);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void cancel() {
/*  644 */       if (!this.cancelled) {
/*  645 */         this.cancelled = true;
/*      */         
/*  647 */         cancelAll();
/*      */         
/*  649 */         if (WIP.getAndIncrement(this) == 0) {
/*  650 */           discardAll(1);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public CoreSubscriber<? super R> actual() {
/*  657 */       return this.actual;
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<? extends Scannable> inners() {
/*  662 */       return Stream.of((Scannable[])this.subscribers);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/*  668 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/*  669 */       if (key == Scannable.Attr.ERROR) return this.error; 
/*  670 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(this.cancelled); 
/*  671 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/*  673 */       return super.scanUnsafe(key);
/*      */     }
/*      */     
/*      */     void error(Throwable e, int index) {
/*  677 */       if (Exceptions.addThrowable(ERROR, this, e)) {
/*  678 */         drain(null, null);
/*      */       } else {
/*      */         
/*  681 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*      */       } 
/*      */     }
/*      */     
/*      */     void cancelAll() {
/*  686 */       for (FluxZip.ZipInner<T> s : this.subscribers) {
/*  687 */         s.cancel();
/*      */       }
/*      */     }
/*      */     
/*      */     void discardAll(int m) {
/*  692 */       Context context = this.actual.currentContext();
/*  693 */       Object[] values = this.current;
/*  694 */       Operators.onDiscardMultiple(Arrays.asList(values), context);
/*  695 */       Arrays.fill(values, (Object)null);
/*      */       
/*      */       while (true) {
/*  698 */         for (FluxZip.ZipInner<T> s : this.subscribers) {
/*  699 */           Queue<T> queue = s.queue;
/*  700 */           int sourceMode = s.sourceMode;
/*      */           
/*  702 */           if (queue != null) {
/*  703 */             if (sourceMode == 2) {
/*      */               
/*  705 */               queue.clear();
/*      */             } else {
/*      */               
/*  708 */               Operators.onDiscardQueueWithClear(queue, context, null);
/*      */             } 
/*      */           }
/*      */         } 
/*      */         
/*  713 */         int missed = this.wip;
/*  714 */         if (m == missed) {
/*  715 */           if (WIP.compareAndSet(this, m, -2147483648)) {
/*      */             return;
/*      */           }
/*  718 */           m = this.wip;
/*      */           continue;
/*      */         } 
/*  721 */         m = missed;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void drain(@Nullable FluxZip.ZipInner<T> callerInner, @Nullable Object dataSignal) {
/*  727 */       int previousWork = addWork(this);
/*  728 */       if (previousWork != 0) {
/*  729 */         if (callerInner != null) {
/*  730 */           if (callerInner.sourceMode == 2 && previousWork == Integer.MIN_VALUE) {
/*  731 */             callerInner.queue.clear();
/*      */           }
/*  733 */           else if (dataSignal != null && this.cancelled) {
/*      */             
/*  735 */             Operators.onDiscard(dataSignal, this.actual.currentContext());
/*      */           } 
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*  741 */       CoreSubscriber<? super R> a = this.actual;
/*  742 */       FluxZip.ZipInner<T>[] qs = this.subscribers;
/*  743 */       int n = qs.length;
/*  744 */       Object[] values = this.current;
/*      */       
/*  746 */       int missed = 1;
/*      */ 
/*      */       
/*      */       do {
/*  750 */         long r = this.requested;
/*  751 */         long e = 0L;
/*      */         
/*  753 */         while (r != e) {
/*      */           R v;
/*  755 */           if (this.cancelled) {
/*  756 */             discardAll(missed);
/*      */             
/*      */             return;
/*      */           } 
/*  760 */           if (this.error != null) {
/*  761 */             cancelAll();
/*  762 */             discardAll(missed);
/*      */             
/*  764 */             Throwable ex = Exceptions.terminate(ERROR, this);
/*      */             
/*  766 */             a.onError(ex);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  771 */           boolean empty = false;
/*      */           
/*  773 */           for (int j = 0; j < n; j++) {
/*  774 */             FluxZip.ZipInner<T> inner = qs[j];
/*  775 */             if (values[j] == null) {
/*      */               try {
/*  777 */                 boolean d = inner.done;
/*  778 */                 Queue<T> q = inner.queue;
/*      */                 
/*  780 */                 E e1 = (q != null) ? (E)q.poll() : null;
/*      */                 
/*  782 */                 boolean sourceEmpty = (e1 == null);
/*  783 */                 if (d && sourceEmpty) {
/*  784 */                   cancelAll();
/*  785 */                   discardAll(missed);
/*      */                   
/*  787 */                   a.onComplete();
/*      */                   return;
/*      */                 } 
/*  790 */                 if (!sourceEmpty) {
/*  791 */                   values[j] = e1;
/*      */                 } else {
/*      */                   
/*  794 */                   empty = true;
/*      */                 }
/*      */               
/*  797 */               } catch (Throwable ex) {
/*  798 */                 ex = Operators.onOperatorError(ex, this.actual
/*  799 */                     .currentContext());
/*      */                 
/*  801 */                 cancelAll();
/*  802 */                 discardAll(missed);
/*      */                 
/*  804 */                 Exceptions.addThrowable(ERROR, this, ex);
/*      */                 
/*  806 */                 ex = Exceptions.terminate(ERROR, this);
/*      */                 
/*  808 */                 a.onError(ex);
/*      */                 
/*      */                 return;
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*  815 */           if (empty) {
/*      */             break;
/*      */           }
/*      */ 
/*      */           
/*      */           try {
/*  821 */             v = Objects.requireNonNull(this.zipper.apply((Object[])values.clone()), "The zipper returned a null value");
/*      */           
/*      */           }
/*  824 */           catch (Throwable ex) {
/*      */             
/*  826 */             ex = Operators.onOperatorError(null, ex, values.clone(), this.actual
/*  827 */                 .currentContext());
/*  828 */             cancelAll();
/*  829 */             discardAll(missed);
/*      */             
/*  831 */             Exceptions.addThrowable(ERROR, this, ex);
/*      */             
/*  833 */             ex = Exceptions.terminate(ERROR, this);
/*      */             
/*  835 */             a.onError(ex);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  840 */           a.onNext(v);
/*      */           
/*  842 */           e++;
/*      */           
/*  844 */           Arrays.fill(values, (Object)null);
/*      */         } 
/*      */         
/*  847 */         if (r == e) {
/*  848 */           if (this.cancelled) {
/*      */             return;
/*      */           }
/*      */           
/*  852 */           if (this.error != null) {
/*  853 */             cancelAll();
/*  854 */             discardAll(missed);
/*      */             
/*  856 */             Throwable ex = Exceptions.terminate(ERROR, this);
/*      */             
/*  858 */             a.onError(ex);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  863 */           for (int j = 0; j < n; j++) {
/*  864 */             FluxZip.ZipInner<T> inner = qs[j];
/*  865 */             if (values[j] == null) {
/*      */               try {
/*  867 */                 boolean d = inner.done;
/*  868 */                 Queue<T> q = inner.queue;
/*  869 */                 E e1 = (q != null) ? (E)q.poll() : null;
/*      */                 
/*  871 */                 boolean empty = (e1 == null);
/*  872 */                 if (d && empty) {
/*  873 */                   cancelAll();
/*  874 */                   discardAll(missed);
/*      */                   
/*  876 */                   a.onComplete();
/*      */                   return;
/*      */                 } 
/*  879 */                 if (!empty) {
/*  880 */                   values[j] = e1;
/*      */                 }
/*      */               }
/*  883 */               catch (Throwable ex) {
/*  884 */                 ex = Operators.onOperatorError(null, ex, values, this.actual
/*  885 */                     .currentContext());
/*      */                 
/*  887 */                 cancelAll();
/*  888 */                 discardAll(missed);
/*      */                 
/*  890 */                 Exceptions.addThrowable(ERROR, this, ex);
/*      */                 
/*  892 */                 ex = Exceptions.terminate(ERROR, this);
/*      */                 
/*  894 */                 a.onError(ex);
/*      */ 
/*      */                 
/*      */                 return;
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  903 */         if (e != 0L) {
/*      */           
/*  905 */           for (int j = 0; j < n; j++) {
/*  906 */             FluxZip.ZipInner<T> inner = qs[j];
/*  907 */             inner.request(e);
/*      */           } 
/*      */           
/*  910 */           if (r != Long.MAX_VALUE) {
/*  911 */             REQUESTED.addAndGet(this, -e);
/*      */           }
/*      */         } 
/*      */         
/*  915 */         missed = WIP.addAndGet(this, -missed);
/*  916 */       } while (missed != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static int addWork(ZipCoordinator<?, ?> instance) {
/*      */       while (true) {
/*  924 */         int state = instance.wip;
/*      */         
/*  926 */         if (state == Integer.MIN_VALUE) {
/*  927 */           return Integer.MIN_VALUE;
/*      */         }
/*      */         
/*  930 */         if (WIP.compareAndSet(instance, state, state + 1)) {
/*  931 */           return state;
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class ZipInner<T>
/*      */     implements InnerConsumer<T>
/*      */   {
/*      */     final FluxZip.ZipCoordinator<T, ?> parent;
/*      */     
/*      */     final int prefetch;
/*      */     
/*      */     final int limit;
/*      */     
/*      */     final int index;
/*      */     
/*      */     final Supplier<? extends Queue<T>> queueSupplier;
/*      */     
/*      */     volatile Queue<T> queue;
/*      */     
/*      */     volatile Subscription s;
/*      */     
/*  955 */     static final AtomicReferenceFieldUpdater<ZipInner, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(ZipInner.class, Subscription.class, "s");
/*      */ 
/*      */     
/*      */     long produced;
/*      */ 
/*      */     
/*      */     volatile boolean done;
/*      */ 
/*      */     
/*      */     int sourceMode;
/*      */ 
/*      */ 
/*      */     
/*      */     ZipInner(FluxZip.ZipCoordinator<T, ?> parent, int prefetch, int index, Supplier<? extends Queue<T>> queueSupplier) {
/*  969 */       this.parent = parent;
/*  970 */       this.prefetch = prefetch;
/*  971 */       this.index = index;
/*  972 */       this.queueSupplier = queueSupplier;
/*  973 */       this.limit = Operators.unboundedOrLimit(prefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onSubscribe(Subscription s) {
/*  979 */       if (Operators.setOnce(S, this, s)) {
/*  980 */         if (s instanceof Fuseable.QueueSubscription) {
/*  981 */           Fuseable.QueueSubscription<T> f = (Fuseable.QueueSubscription<T>)s;
/*      */           
/*  983 */           int m = f.requestFusion(7);
/*      */           
/*  985 */           if (m == 1) {
/*  986 */             this.sourceMode = 1;
/*  987 */             this.queue = (Queue<T>)f;
/*  988 */             this.done = true;
/*  989 */             this.parent.drain(this, null);
/*      */             return;
/*      */           } 
/*  992 */           if (m == 2) {
/*  993 */             this.sourceMode = 2;
/*  994 */             this.queue = (Queue<T>)f;
/*      */           } else {
/*      */             
/*  997 */             this.queue = this.queueSupplier.get();
/*      */           } 
/*      */         } else {
/*      */           
/* 1001 */           this.queue = this.queueSupplier.get();
/*      */         } 
/* 1003 */         s.request(Operators.unboundedOrPrefetch(this.prefetch));
/* 1004 */         this.parent.drain(this, null);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void onNext(T t) {
/* 1010 */       if (this.sourceMode != 2 && 
/* 1011 */         !this.queue.offer(t)) {
/* 1012 */         Operators.onDiscard(t, currentContext());
/* 1013 */         onError(Operators.onOperatorError(this.s, 
/* 1014 */               Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), currentContext()));
/*      */         
/*      */         return;
/*      */       } 
/* 1018 */       this.parent.drain(this, t);
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/* 1023 */       return this.parent.actual.currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onError(Throwable t) {
/* 1028 */       if (this.done) {
/* 1029 */         Operators.onErrorDropped(t, currentContext());
/*      */         return;
/*      */       } 
/* 1032 */       this.done = true;
/* 1033 */       this.parent.error(t, this.index);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onComplete() {
/* 1038 */       this.done = true;
/* 1039 */       this.parent.drain(this, null);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1045 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 1046 */       if (key == Scannable.Attr.ACTUAL) return this.parent; 
/* 1047 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 1048 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf((this.queue != null) ? this.queue.size() : 0); 
/* 1049 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf((this.done && this.s != Operators.cancelledSubscription())); 
/* 1050 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 1051 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*      */       
/* 1053 */       return null;
/*      */     }
/*      */     
/*      */     void cancel() {
/* 1057 */       Operators.terminate(S, this);
/*      */     }
/*      */     
/*      */     void request(long n) {
/* 1061 */       if (this.sourceMode != 1) {
/* 1062 */         long p = this.produced + n;
/* 1063 */         if (p >= this.limit) {
/* 1064 */           this.produced = 0L;
/* 1065 */           this.s.request(p);
/*      */         } else {
/*      */           
/* 1068 */           this.produced = p;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static final class PairwiseZipper<R>
/*      */     implements Function<Object[], R>
/*      */   {
/*      */     final BiFunction[] zippers;
/*      */     
/*      */     PairwiseZipper(BiFunction[] zippers) {
/* 1080 */       this.zippers = zippers;
/*      */     }
/*      */ 
/*      */     
/*      */     public R apply(Object[] args) {
/* 1085 */       Object o = this.zippers[0].apply(args[0], args[1]);
/* 1086 */       for (int i = 1; i < this.zippers.length; i++) {
/* 1087 */         o = this.zippers[i].apply(o, args[i + 1]);
/*      */       }
/* 1089 */       return (R)o;
/*      */     }
/*      */     
/*      */     public PairwiseZipper then(BiFunction zipper) {
/* 1093 */       BiFunction[] zippers = this.zippers;
/* 1094 */       int n = zippers.length;
/* 1095 */       BiFunction[] newZippers = new BiFunction[n + 1];
/* 1096 */       System.arraycopy(zippers, 0, newZippers, 0, n);
/* 1097 */       newZippers[n] = zipper;
/*      */       
/* 1099 */       return new PairwiseZipper(newZippers);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxZip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */