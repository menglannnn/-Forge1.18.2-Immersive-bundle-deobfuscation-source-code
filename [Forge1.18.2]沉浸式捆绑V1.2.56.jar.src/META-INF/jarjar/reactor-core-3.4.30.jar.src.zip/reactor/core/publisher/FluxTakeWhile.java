/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxTakeWhile<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final Predicate<? super T> predicate;
/*     */   
/*     */   FluxTakeWhile(Flux<? extends T> source, Predicate<? super T> predicate) {
/*  38 */     super(source);
/*  39 */     this.predicate = Objects.<Predicate<? super T>>requireNonNull(predicate, "predicate");
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  44 */     return new TakeWhileSubscriber<>(actual, this.predicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  49 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  50 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TakeWhileSubscriber<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Predicate<? super T> predicate;
/*     */     Subscription s;
/*     */     boolean done;
/*     */     
/*     */     TakeWhileSubscriber(CoreSubscriber<? super T> actual, Predicate<? super T> predicate) {
/*  64 */       this.actual = actual;
/*  65 */       this.predicate = predicate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  70 */       if (Operators.validate(this.s, s)) {
/*  71 */         this.s = s;
/*  72 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void onNext(T t) {
/*     */       boolean b;
/*  78 */       if (this.done) {
/*  79 */         Operators.onNextDropped(t, this.actual.currentContext());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       try {
/*  86 */         b = this.predicate.test(t);
/*  87 */       } catch (Throwable e) {
/*  88 */         onError(Operators.onOperatorError(this.s, e, t, this.actual.currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  93 */       if (!b) {
/*  94 */         this.s.cancel();
/*     */         
/*  96 */         onComplete();
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 101 */       this.actual.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 106 */       if (this.done) {
/* 107 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 110 */       this.done = true;
/*     */       
/* 112 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 117 */       if (this.done) {
/*     */         return;
/*     */       }
/* 120 */       this.done = true;
/*     */       
/* 122 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 128 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 129 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 130 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 132 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 137 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 142 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 147 */       this.s.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxTakeWhile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */