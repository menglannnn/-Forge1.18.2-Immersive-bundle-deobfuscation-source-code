/*    */ package reactor.core.publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SignalType
/*    */ {
/* 28 */   SUBSCRIBE,
/*    */ 
/*    */ 
/*    */   
/* 32 */   REQUEST,
/*    */ 
/*    */ 
/*    */   
/* 36 */   CANCEL,
/*    */ 
/*    */ 
/*    */   
/* 40 */   ON_SUBSCRIBE,
/*    */ 
/*    */ 
/*    */   
/* 44 */   ON_NEXT,
/*    */ 
/*    */ 
/*    */   
/* 48 */   ON_ERROR,
/*    */ 
/*    */ 
/*    */   
/* 52 */   ON_COMPLETE,
/*    */ 
/*    */ 
/*    */   
/* 56 */   AFTER_TERMINATE,
/*    */ 
/*    */ 
/*    */   
/* 60 */   CURRENT_CONTEXT,
/*    */ 
/*    */ 
/*    */   
/* 64 */   ON_CONTEXT;
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     switch (this) {
/*    */       case ON_SUBSCRIBE:
/* 70 */         return "onSubscribe";
/*    */       case ON_NEXT:
/* 72 */         return "onNext";
/*    */       case ON_ERROR:
/* 74 */         return "onError";
/*    */       case ON_COMPLETE:
/* 76 */         return "onComplete";
/*    */       case REQUEST:
/* 78 */         return "request";
/*    */       case CANCEL:
/* 80 */         return "cancel";
/*    */       case CURRENT_CONTEXT:
/* 82 */         return "currentContext";
/*    */       case ON_CONTEXT:
/* 84 */         return "onContextUpdate";
/*    */       case AFTER_TERMINATE:
/* 86 */         return "afterTerminate";
/*    */     } 
/* 88 */     return "subscribe";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\SignalType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */