/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxMapFuseable<T, R>
/*     */   extends InternalFluxOperator<T, R>
/*     */   implements Fuseable
/*     */ {
/*     */   final Function<? super T, ? extends R> mapper;
/*     */   
/*     */   FluxMapFuseable(Flux<? extends T> source, Function<? super T, ? extends R> mapper) {
/*  52 */     super(source);
/*  53 */     this.mapper = Objects.<Function<? super T, ? extends R>>requireNonNull(mapper, "mapper");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super R> actual) {
/*  59 */     if (actual instanceof Fuseable.ConditionalSubscriber) {
/*  60 */       Fuseable.ConditionalSubscriber<? super R> cs = (Fuseable.ConditionalSubscriber<? super R>)actual;
/*  61 */       return new MapFuseableConditionalSubscriber<>(cs, this.mapper);
/*     */     } 
/*  63 */     return new MapFuseableSubscriber<>(actual, this.mapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  68 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  69 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MapFuseableSubscriber<T, R>
/*     */     implements InnerOperator<T, R>, Fuseable.QueueSubscription<R>
/*     */   {
/*     */     final CoreSubscriber<? super R> actual;
/*     */     
/*     */     final Function<? super T, ? extends R> mapper;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     MapFuseableSubscriber(CoreSubscriber<? super R> actual, Function<? super T, ? extends R> mapper) {
/*  87 */       this.actual = actual;
/*  88 */       this.mapper = mapper;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  94 */       if (Operators.validate((Subscription)this.s, s)) {
/*  95 */         this.s = (Fuseable.QueueSubscription<T>)s;
/*  96 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 102 */       if (this.sourceMode == 2) {
/* 103 */         this.actual.onNext(null);
/*     */       } else {
/*     */         R v;
/* 106 */         if (this.done) {
/* 107 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/*     */         try {
/* 113 */           v = this.mapper.apply(t);
/* 114 */           if (v == null) {
/* 115 */             throw new NullPointerException("The mapper [" + this.mapper.getClass().getName() + "] returned a null value.");
/*     */           }
/*     */         }
/* 118 */         catch (Throwable e) {
/* 119 */           Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 120 */           if (e_ != null) {
/* 121 */             onError(e_);
/*     */           } else {
/*     */             
/* 124 */             this.s.request(1L);
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 129 */         this.actual.onNext(v);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 135 */       if (this.done) {
/* 136 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 140 */       this.done = true;
/*     */       
/* 142 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 147 */       if (this.done) {
/*     */         return;
/*     */       }
/* 150 */       this.done = true;
/*     */       
/* 152 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 157 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 158 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 159 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 161 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 166 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 171 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 176 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R poll() {
/*     */       while (true) {
/* 183 */         T v = (T)this.s.poll();
/* 184 */         if (v != null) {
/*     */           try {
/* 186 */             return Objects.requireNonNull(this.mapper.apply(v));
/*     */           }
/* 188 */           catch (Throwable t) {
/* 189 */             RuntimeException e_ = Operators.onNextPollError(v, t, currentContext());
/* 190 */             if (e_ != null) {
/* 191 */               throw e_;
/*     */             }
/*     */             continue;
/*     */           } 
/*     */         }
/*     */         break;
/*     */       } 
/* 198 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 204 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 209 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 215 */       if ((requestedMode & 0x4) != 0) {
/* 216 */         return 0;
/*     */       }
/*     */       
/* 219 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 221 */       this.sourceMode = m;
/* 222 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 227 */       return this.s.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MapFuseableConditionalSubscriber<T, R>
/*     */     implements Fuseable.ConditionalSubscriber<T>, InnerOperator<T, R>, Fuseable.QueueSubscription<R>
/*     */   {
/*     */     final Fuseable.ConditionalSubscriber<? super R> actual;
/*     */     
/*     */     final Function<? super T, ? extends R> mapper;
/*     */     
/*     */     boolean done;
/*     */     
/*     */     Fuseable.QueueSubscription<T> s;
/*     */     
/*     */     int sourceMode;
/*     */     
/*     */     MapFuseableConditionalSubscriber(Fuseable.ConditionalSubscriber<? super R> actual, Function<? super T, ? extends R> mapper) {
/* 246 */       this.actual = actual;
/* 247 */       this.mapper = mapper;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 253 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 254 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(this.done); 
/* 255 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 257 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 263 */       if (Operators.validate((Subscription)this.s, s)) {
/* 264 */         this.s = (Fuseable.QueueSubscription<T>)s;
/* 265 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 271 */       if (this.sourceMode == 2) {
/* 272 */         this.actual.onNext(null);
/*     */       } else {
/*     */         R v;
/* 275 */         if (this.done) {
/* 276 */           Operators.onNextDropped(t, this.actual.currentContext());
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/*     */         try {
/* 283 */           v = this.mapper.apply(t);
/* 284 */           if (v == null) {
/* 285 */             throw new NullPointerException("The mapper [" + this.mapper.getClass().getName() + "] returned a null value.");
/*     */           }
/*     */         }
/* 288 */         catch (Throwable e) {
/* 289 */           Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 290 */           if (e_ != null) {
/* 291 */             onError(e_);
/*     */           } else {
/*     */             
/* 294 */             this.s.request(1L);
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 299 */         this.actual.onNext(v);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryOnNext(T t) {
/* 305 */       if (this.done) {
/* 306 */         Operators.onNextDropped(t, this.actual.currentContext());
/* 307 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 313 */         R v = this.mapper.apply(t);
/* 314 */         if (v == null) {
/* 315 */           throw new NullPointerException("The mapper [" + this.mapper.getClass().getName() + "] returned a null value.");
/*     */         }
/* 317 */         return this.actual.tryOnNext(v);
/*     */       }
/* 319 */       catch (Throwable e) {
/* 320 */         Throwable e_ = Operators.onNextError(t, e, this.actual.currentContext(), (Subscription)this.s);
/* 321 */         if (e_ != null) {
/* 322 */           onError(e_);
/* 323 */           return true;
/*     */         } 
/*     */         
/* 326 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 333 */       if (this.done) {
/* 334 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         
/*     */         return;
/*     */       } 
/* 338 */       this.done = true;
/*     */       
/* 340 */       this.actual.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 345 */       if (this.done) {
/*     */         return;
/*     */       }
/* 348 */       this.done = true;
/*     */       
/* 350 */       this.actual.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super R> actual() {
/* 355 */       return (CoreSubscriber<? super R>)this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 360 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 365 */       this.s.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public R poll() {
/*     */       while (true) {
/* 372 */         T v = (T)this.s.poll();
/* 373 */         if (v != null) {
/*     */           try {
/* 375 */             return Objects.requireNonNull(this.mapper.apply(v));
/*     */           }
/* 377 */           catch (Throwable t) {
/* 378 */             RuntimeException e_ = Operators.onNextPollError(v, t, currentContext());
/* 379 */             if (e_ != null) {
/* 380 */               throw e_;
/*     */             }
/*     */             continue;
/*     */           } 
/*     */         }
/*     */         break;
/*     */       } 
/* 387 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 393 */       return this.s.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 398 */       this.s.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 404 */       if ((requestedMode & 0x4) != 0) {
/* 405 */         return 0;
/*     */       }
/*     */       
/* 408 */       int m = this.s.requestFusion(requestedMode);
/*     */       
/* 410 */       this.sourceMode = m;
/* 411 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 416 */       return this.s.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxMapFuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */