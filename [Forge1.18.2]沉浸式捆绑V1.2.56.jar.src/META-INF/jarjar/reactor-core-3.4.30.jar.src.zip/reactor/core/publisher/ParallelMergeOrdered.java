/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParallelMergeOrdered<T>
/*    */   extends Flux<T>
/*    */   implements Scannable
/*    */ {
/*    */   final ParallelFlux<? extends T> source;
/*    */   final int prefetch;
/*    */   final Comparator<? super T> valueComparator;
/*    */   
/*    */   ParallelMergeOrdered(ParallelFlux<? extends T> source, int prefetch, Comparator<? super T> valueComparator) {
/* 41 */     if (prefetch <= 0) {
/* 42 */       throw new IllegalArgumentException("prefetch > 0 required but it was " + prefetch);
/*    */     }
/* 44 */     this.source = source;
/* 45 */     this.prefetch = prefetch;
/* 46 */     this.valueComparator = valueComparator;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPrefetch() {
/* 51 */     return this.prefetch;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 57 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 58 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.prefetch); 
/* 59 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*    */     
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void subscribe(CoreSubscriber<? super T> actual) {
/* 67 */     FluxMergeComparing.MergeOrderedMainProducer<T> main = new FluxMergeComparing.MergeOrderedMainProducer<>(actual, this.valueComparator, this.prefetch, this.source.parallelism(), true, true);
/* 68 */     actual.onSubscribe(main);
/* 69 */     this.source.subscribe((CoreSubscriber<? super T>[])main.subscribers);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ParallelMergeOrdered.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */