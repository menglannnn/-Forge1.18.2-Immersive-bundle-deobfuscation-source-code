/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoUsing<T, S>
/*     */   extends Mono<T>
/*     */   implements Fuseable, SourceProducer<T>
/*     */ {
/*     */   final Callable<S> resourceSupplier;
/*     */   final Function<? super S, ? extends Mono<? extends T>> sourceFactory;
/*     */   final Consumer<? super S> resourceCleanup;
/*     */   final boolean eager;
/*     */   
/*     */   MonoUsing(Callable<S> resourceSupplier, Function<? super S, ? extends Mono<? extends T>> sourceFactory, Consumer<? super S> resourceCleanup, boolean eager) {
/*  63 */     this
/*  64 */       .resourceSupplier = Objects.<Callable<S>>requireNonNull(resourceSupplier, "resourceSupplier");
/*  65 */     this.sourceFactory = Objects.<Function<? super S, ? extends Mono<? extends T>>>requireNonNull(sourceFactory, "sourceFactory");
/*  66 */     this.resourceCleanup = Objects.<Consumer<? super S>>requireNonNull(resourceCleanup, "resourceCleanup");
/*  67 */     this.eager = eager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T> actual) {
/*     */     S resource;
/*     */     Mono<? extends T> p;
/*     */     try {
/*  75 */       resource = this.resourceSupplier.call();
/*     */     }
/*  77 */     catch (Throwable e) {
/*  78 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/*  85 */       p = Objects.<Mono<? extends T>>requireNonNull(this.sourceFactory.apply(resource), "The sourceFactory returned a null value");
/*     */     
/*     */     }
/*  88 */     catch (Throwable e) {
/*     */       
/*     */       try {
/*  91 */         this.resourceCleanup.accept(resource);
/*     */       }
/*  93 */       catch (Throwable ex) {
/*  94 */         e = Exceptions.addSuppressed(ex, Operators.onOperatorError(e, actual.currentContext()));
/*     */       } 
/*     */       
/*  97 */       Operators.error((Subscriber<?>)actual, Operators.onOperatorError(e, actual.currentContext()));
/*     */       
/*     */       return;
/*     */     } 
/* 101 */     if (p instanceof Fuseable) {
/* 102 */       p.subscribe(new MonoUsingSubscriber<>(actual, this.resourceCleanup, resource, this.eager, true));
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 109 */       p.subscribe(new MonoUsingSubscriber<>(actual, this.resourceCleanup, resource, this.eager, false));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 119 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class MonoUsingSubscriber<T, S>
/*     */     implements InnerOperator<T, T>, Fuseable.QueueSubscription<T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final Consumer<? super S> resourceCleanup;
/*     */     
/*     */     final S resource;
/*     */     
/*     */     final boolean eager;
/*     */     
/*     */     final boolean allowFusion;
/*     */     
/*     */     Subscription s;
/*     */     
/*     */     @Nullable
/*     */     Fuseable.QueueSubscription<T> qs;
/*     */     volatile int wip;
/* 142 */     static final AtomicIntegerFieldUpdater<MonoUsingSubscriber> WIP = AtomicIntegerFieldUpdater.newUpdater(MonoUsingSubscriber.class, "wip");
/*     */ 
/*     */     
/*     */     int mode;
/*     */ 
/*     */     
/*     */     boolean valued;
/*     */ 
/*     */     
/*     */     MonoUsingSubscriber(CoreSubscriber<? super T> actual, Consumer<? super S> resourceCleanup, S resource, boolean eager, boolean allowFusion) {
/* 152 */       this.actual = actual;
/* 153 */       this.resourceCleanup = resourceCleanup;
/* 154 */       this.resource = resource;
/* 155 */       this.eager = eager;
/* 156 */       this.allowFusion = allowFusion;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 162 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED)
/* 163 */         return Boolean.valueOf((this.wip == 1)); 
/* 164 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 165 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 167 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 172 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 177 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 182 */       if (WIP.compareAndSet(this, 0, 1)) {
/* 183 */         this.s.cancel();
/*     */         
/* 185 */         cleanup();
/*     */       } 
/*     */     }
/*     */     
/*     */     void cleanup() {
/*     */       try {
/* 191 */         this.resourceCleanup.accept(this.resource);
/*     */       }
/* 193 */       catch (Throwable e) {
/* 194 */         Operators.onErrorDropped(e, this.actual.currentContext());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 201 */       if (Operators.validate(this.s, s)) {
/* 202 */         this.s = s;
/* 203 */         if (s instanceof Fuseable.QueueSubscription) {
/* 204 */           this.qs = (Fuseable.QueueSubscription<T>)s;
/*     */         }
/*     */         
/* 207 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 213 */       if (this.mode == 2) {
/* 214 */         this.actual.onNext(null);
/*     */         return;
/*     */       } 
/* 217 */       this.valued = true;
/*     */       
/* 219 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 221 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 223 */         catch (Throwable e) {
/* 224 */           Context ctx = this.actual.currentContext();
/* 225 */           this.actual.onError(Operators.onOperatorError(e, ctx));
/* 226 */           Operators.onDiscard(t, ctx);
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/* 231 */       this.actual.onNext(t);
/* 232 */       this.actual.onComplete();
/*     */       
/* 234 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 236 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 238 */         catch (Throwable e) {
/* 239 */           Operators.onErrorDropped(e, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 246 */       if (this.valued && this.mode != 2) {
/* 247 */         Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         return;
/*     */       } 
/* 250 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 252 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 254 */         catch (Throwable e) {
/* 255 */           Throwable _e = Operators.onOperatorError(e, this.actual.currentContext());
/* 256 */           t = Exceptions.addSuppressed(_e, t);
/*     */         } 
/*     */       }
/*     */       
/* 260 */       this.actual.onError(t);
/*     */       
/* 262 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/* 263 */         cleanup();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 269 */       if (this.valued && this.mode != 2) {
/*     */         return;
/*     */       }
/*     */       
/* 273 */       if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 275 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 277 */         catch (Throwable e) {
/* 278 */           this.actual.onError(Operators.onOperatorError(e, this.actual.currentContext()));
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/* 283 */       this.actual.onComplete();
/*     */       
/* 285 */       if (!this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 287 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 289 */         catch (Throwable e) {
/* 290 */           Operators.onErrorDropped(e, this.actual.currentContext());
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 297 */       if (this.qs != null) {
/* 298 */         this.qs.clear();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 304 */       return (this.qs == null || this.qs.isEmpty());
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public T poll() {
/* 310 */       if (this.mode == 0 || this.qs == null) {
/* 311 */         return null;
/*     */       }
/*     */       
/* 314 */       T v = (T)this.qs.poll();
/*     */       
/* 316 */       if (v != null) {
/* 317 */         this.valued = true;
/* 318 */         if (this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */           try {
/* 320 */             this.resourceCleanup.accept(this.resource);
/*     */           }
/* 322 */           catch (Throwable t) {
/* 323 */             Operators.onDiscard(v, this.actual.currentContext());
/* 324 */             throw t;
/*     */           }
/*     */         
/*     */         }
/* 328 */       } else if (this.mode == 1 && 
/* 329 */         !this.eager && WIP.compareAndSet(this, 0, 1)) {
/*     */         try {
/* 331 */           this.resourceCleanup.accept(this.resource);
/*     */         }
/* 333 */         catch (Throwable t) {
/* 334 */           if (!this.valued) throw t; 
/* 335 */           Operators.onErrorDropped(t, this.actual.currentContext());
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 340 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public int requestFusion(int requestedMode) {
/* 345 */       if (this.qs == null) {
/* 346 */         this.mode = 0;
/* 347 */         return 0;
/*     */       } 
/* 349 */       int m = this.qs.requestFusion(requestedMode);
/* 350 */       this.mode = m;
/* 351 */       return m;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 356 */       if (this.qs == null) {
/* 357 */         return 0;
/*     */       }
/* 359 */       return this.qs.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoUsing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */