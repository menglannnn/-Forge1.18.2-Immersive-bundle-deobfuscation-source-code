/*    */ package reactor.core.publisher;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.CoreSubscriber;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MonoSwitchIfEmpty<T>
/*    */   extends InternalMonoOperator<T, T>
/*    */ {
/*    */   final Mono<? extends T> other;
/*    */   
/*    */   MonoSwitchIfEmpty(Mono<? extends T> source, Mono<? extends T> other) {
/* 34 */     super(source);
/* 35 */     this.other = Objects.<Mono<? extends T>>requireNonNull(other, "other");
/*    */   }
/*    */ 
/*    */   
/*    */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/* 40 */     FluxSwitchIfEmpty.SwitchIfEmptySubscriber<T> parent = new FluxSwitchIfEmpty.SwitchIfEmptySubscriber<>(actual, (Publisher<? extends T>)this.other);
/*    */ 
/*    */     
/* 43 */     actual.onSubscribe(parent);
/*    */     
/* 45 */     return parent;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 50 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/* 51 */     return super.scanUnsafe(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\MonoSwitchIfEmpty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */