/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxBufferBoundary<T, U, C extends Collection<? super T>>
/*     */   extends InternalFluxOperator<T, C>
/*     */ {
/*     */   final Publisher<U> other;
/*     */   final Supplier<C> bufferSupplier;
/*     */   
/*     */   FluxBufferBoundary(Flux<? extends T> source, Publisher<U> other, Supplier<C> bufferSupplier) {
/*  55 */     super(source);
/*  56 */     this.other = Objects.<Publisher<U>>requireNonNull(other, "other");
/*  57 */     this.bufferSupplier = Objects.<Supplier<C>>requireNonNull(bufferSupplier, "bufferSupplier");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/*  62 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super C> actual) {
/*  67 */     Collection collection = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null buffer");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     BufferBoundaryMain<T, U, C> parent = new BufferBoundaryMain<>((this.source instanceof FluxInterval) ? actual : Operators.<C>serialize(actual), (C)collection, this.bufferSupplier);
/*     */ 
/*     */     
/*  76 */     actual.onSubscribe(parent);
/*     */     
/*  78 */     this.other.subscribe((Subscriber)parent.other);
/*     */     
/*  80 */     return parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  85 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  86 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class BufferBoundaryMain<T, U, C extends Collection<? super T>>
/*     */     implements InnerOperator<T, C>
/*     */   {
/*     */     final Supplier<C> bufferSupplier;
/*     */     
/*     */     final CoreSubscriber<? super C> actual;
/*     */     
/*     */     final Context ctx;
/*     */     
/*     */     final FluxBufferBoundary.BufferBoundaryOther<U> other;
/*     */     
/*     */     C buffer;
/*     */     
/*     */     volatile Subscription s;
/* 104 */     static final AtomicReferenceFieldUpdater<BufferBoundaryMain, Subscription> S = AtomicReferenceFieldUpdater.newUpdater(BufferBoundaryMain.class, Subscription.class, "s");
/*     */ 
/*     */ 
/*     */     
/*     */     volatile long requested;
/*     */ 
/*     */     
/* 111 */     static final AtomicLongFieldUpdater<BufferBoundaryMain> REQUESTED = AtomicLongFieldUpdater.newUpdater(BufferBoundaryMain.class, "requested");
/*     */ 
/*     */ 
/*     */     
/*     */     BufferBoundaryMain(CoreSubscriber<? super C> actual, C buffer, Supplier<C> bufferSupplier) {
/* 116 */       this.actual = actual;
/* 117 */       this.ctx = actual.currentContext();
/* 118 */       this.buffer = buffer;
/* 119 */       this.bufferSupplier = bufferSupplier;
/* 120 */       this.other = new FluxBufferBoundary.BufferBoundaryOther<>(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super C> actual() {
/* 125 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 131 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 132 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf((this.s == Operators.cancelledSubscription())); 
/* 133 */       if (key == Scannable.Attr.CAPACITY) {
/* 134 */         C buffer = this.buffer;
/* 135 */         return Integer.valueOf((buffer != null) ? buffer.size() : 0);
/*     */       } 
/* 137 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(2147483647); 
/* 138 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Long.valueOf(this.requested); 
/* 139 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 141 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 146 */       if (Operators.validate(n)) {
/* 147 */         Operators.addCap(REQUESTED, this, n);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 153 */       Operators.terminate(S, this);
/* 154 */       Operators.onDiscardMultiple((Collection<?>)this.buffer, this.ctx);
/* 155 */       this.other.cancel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 160 */       if (Operators.setOnce(S, this, s)) {
/* 161 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 167 */       synchronized (this) {
/* 168 */         C b = this.buffer;
/* 169 */         if (b != null) {
/* 170 */           b.add(t);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 175 */       Operators.onNextDropped(t, this.ctx);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 180 */       if (Operators.terminate(S, this)) {
/*     */         C b;
/* 182 */         synchronized (this) {
/* 183 */           b = this.buffer;
/* 184 */           this.buffer = null;
/*     */         } 
/*     */         
/* 187 */         this.other.cancel();
/* 188 */         this.actual.onError(t);
/* 189 */         Operators.onDiscardMultiple((Collection<?>)b, this.ctx);
/*     */         return;
/*     */       } 
/* 192 */       Operators.onErrorDropped(t, this.ctx);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 197 */       if (Operators.terminate(S, this)) {
/*     */         C b;
/* 199 */         synchronized (this) {
/* 200 */           b = this.buffer;
/* 201 */           this.buffer = null;
/*     */         } 
/*     */         
/* 204 */         this.other.cancel();
/* 205 */         if (!b.isEmpty()) {
/* 206 */           if (emit(b)) {
/* 207 */             this.actual.onComplete();
/*     */           }
/*     */         } else {
/*     */           
/* 211 */           this.actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     void otherComplete() {
/* 216 */       Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 217 */       if (s != Operators.cancelledSubscription()) {
/*     */         C b;
/* 219 */         synchronized (this) {
/* 220 */           b = this.buffer;
/* 221 */           this.buffer = null;
/*     */         } 
/*     */         
/* 224 */         if (s != null) {
/* 225 */           s.cancel();
/*     */         }
/*     */         
/* 228 */         if (b != null && !b.isEmpty()) {
/* 229 */           if (emit(b)) {
/* 230 */             this.actual.onComplete();
/*     */           }
/*     */         } else {
/*     */           
/* 234 */           this.actual.onComplete();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void otherError(Throwable t) {
/* 240 */       Subscription s = S.getAndSet(this, Operators.cancelledSubscription());
/* 241 */       if (s != Operators.cancelledSubscription()) {
/*     */         C b;
/* 243 */         synchronized (this) {
/* 244 */           b = this.buffer;
/* 245 */           this.buffer = null;
/*     */         } 
/*     */         
/* 248 */         if (s != null) {
/* 249 */           s.cancel();
/*     */         }
/*     */         
/* 252 */         this.actual.onError(t);
/* 253 */         Operators.onDiscardMultiple((Collection<?>)b, this.ctx);
/*     */         return;
/*     */       } 
/* 256 */       Operators.onErrorDropped(t, this.ctx);
/*     */     }
/*     */     
/*     */     void otherNext() {
/*     */       Collection collection;
/*     */       C b;
/*     */       try {
/* 263 */         collection = Objects.<Collection>requireNonNull((Collection)this.bufferSupplier.get(), "The bufferSupplier returned a null buffer");
/*     */       
/*     */       }
/* 266 */       catch (Throwable e) {
/* 267 */         otherError(Operators.onOperatorError(this.other, e, this.ctx));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 272 */       synchronized (this) {
/* 273 */         b = this.buffer;
/* 274 */         this.buffer = (C)collection;
/*     */       } 
/*     */       
/* 277 */       if (b == null || b.isEmpty()) {
/*     */         return;
/*     */       }
/*     */       
/* 281 */       emit(b);
/*     */     }
/*     */     
/*     */     boolean emit(C b) {
/* 285 */       long r = this.requested;
/* 286 */       if (r != 0L) {
/* 287 */         this.actual.onNext(b);
/* 288 */         if (r != Long.MAX_VALUE) {
/* 289 */           REQUESTED.decrementAndGet(this);
/*     */         }
/* 291 */         return true;
/*     */       } 
/*     */       
/* 294 */       this.actual.onError(Operators.onOperatorError(this, 
/* 295 */             Exceptions.failWithOverflow(), b, this.ctx));
/* 296 */       Operators.onDiscardMultiple((Collection<?>)b, this.ctx);
/* 297 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class BufferBoundaryOther<U>
/*     */     extends Operators.DeferredSubscription
/*     */     implements InnerConsumer<U>
/*     */   {
/*     */     final FluxBufferBoundary.BufferBoundaryMain<?, U, ?> main;
/*     */     
/*     */     BufferBoundaryOther(FluxBufferBoundary.BufferBoundaryMain<?, U, ?> main) {
/* 308 */       this.main = main;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 313 */       if (set(s)) {
/* 314 */         s.request(Long.MAX_VALUE);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 320 */       return this.main.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 326 */       if (key == Scannable.Attr.ACTUAL) {
/* 327 */         return this.main;
/*     */       }
/* 329 */       if (key == Scannable.Attr.RUN_STYLE) {
/* 330 */         return Scannable.Attr.RunStyle.SYNC;
/*     */       }
/* 332 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(U t) {
/* 337 */       this.main.otherNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 342 */       this.main.otherError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 347 */       this.main.otherComplete();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxBufferBoundary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */