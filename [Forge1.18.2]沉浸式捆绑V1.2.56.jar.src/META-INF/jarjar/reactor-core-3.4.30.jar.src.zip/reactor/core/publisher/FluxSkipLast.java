/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxSkipLast<T>
/*     */   extends InternalFluxOperator<T, T>
/*     */ {
/*     */   final int n;
/*     */   
/*     */   FluxSkipLast(Flux<? extends T> source, int n) {
/*  36 */     super(source);
/*  37 */     if (n < 0) {
/*  38 */       throw new IllegalArgumentException("n >= 0 required but it was " + n);
/*     */     }
/*  40 */     this.n = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<? super T> subscribeOrReturn(CoreSubscriber<? super T> actual) {
/*  45 */     return new SkipLastSubscriber<>(actual, this.n);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/*  50 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC; 
/*  51 */     return super.scanUnsafe(key);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SkipLastSubscriber<T>
/*     */     extends ArrayDeque<T>
/*     */     implements InnerOperator<T, T>
/*     */   {
/*     */     final CoreSubscriber<? super T> actual;
/*     */     
/*     */     final int n;
/*     */     
/*     */     Subscription s;
/*     */ 
/*     */     
/*     */     SkipLastSubscriber(CoreSubscriber<? super T> actual, int n) {
/*  67 */       this.actual = actual;
/*  68 */       this.n = n;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/*  73 */       if (Operators.validate(this.s, s)) {
/*  74 */         this.s = s;
/*     */         
/*  76 */         this.actual.onSubscribe(this);
/*     */         
/*  78 */         s.request(this.n);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/*  84 */       if (size() == this.n) {
/*  85 */         this.actual.onNext(pollFirst());
/*     */       }
/*  87 */       offerLast(t);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/*  93 */       this.actual.onError(t);
/*  94 */       Operators.onDiscardQueueWithClear(this, this.actual.currentContext(), null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/*  99 */       this.actual.onComplete();
/* 100 */       Operators.onDiscardQueueWithClear(this, this.actual.currentContext(), null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 107 */       if (key == Scannable.Attr.PARENT) return this.s; 
/* 108 */       if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(this.n); 
/* 109 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(size()); 
/* 110 */       if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */       
/* 112 */       return super.scanUnsafe(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public CoreSubscriber<? super T> actual() {
/* 117 */       return this.actual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 122 */       this.s.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 127 */       this.s.cancel();
/* 128 */       Operators.onDiscardQueueWithClear(this, this.actual.currentContext(), null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\FluxSkipLast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */