/*     */ package reactor.core.publisher;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.LongConsumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelPeek<T>
/*     */   extends ParallelFlux<T>
/*     */   implements SignalPeek<T>
/*     */ {
/*     */   final ParallelFlux<T> source;
/*     */   final Consumer<? super T> onNext;
/*     */   final Consumer<? super T> onAfterNext;
/*     */   final Consumer<? super Throwable> onError;
/*     */   final Runnable onComplete;
/*     */   final Runnable onAfterTerminated;
/*     */   final Consumer<? super Subscription> onSubscribe;
/*     */   final LongConsumer onRequest;
/*     */   final Runnable onCancel;
/*     */   
/*     */   ParallelPeek(ParallelFlux<T> source, @Nullable Consumer<? super T> onNext, @Nullable Consumer<? super T> onAfterNext, @Nullable Consumer<? super Throwable> onError, @Nullable Runnable onComplete, @Nullable Runnable onAfterTerminated, @Nullable Consumer<? super Subscription> onSubscribe, @Nullable LongConsumer onRequest, @Nullable Runnable onCancel) {
/*  55 */     this.source = source;
/*     */     
/*  57 */     this.onNext = onNext;
/*  58 */     this.onAfterNext = onAfterNext;
/*  59 */     this.onError = onError;
/*  60 */     this.onComplete = onComplete;
/*  61 */     this.onAfterTerminated = onAfterTerminated;
/*  62 */     this.onSubscribe = onSubscribe;
/*  63 */     this.onRequest = onRequest;
/*  64 */     this.onCancel = onCancel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super T>[] subscribers) {
/*  70 */     if (!validate((Subscriber<?>[])subscribers)) {
/*     */       return;
/*     */     }
/*     */     
/*  74 */     int n = subscribers.length;
/*     */     
/*  76 */     CoreSubscriber[] arrayOfCoreSubscriber = new CoreSubscriber[n];
/*     */     
/*  78 */     boolean conditional = subscribers[0] instanceof Fuseable.ConditionalSubscriber;
/*     */     
/*  80 */     for (int i = 0; i < n; i++) {
/*  81 */       if (conditional) {
/*  82 */         arrayOfCoreSubscriber[i] = new FluxPeekFuseable.PeekConditionalSubscriber<>((Fuseable.ConditionalSubscriber<? super T>)subscribers[i], this);
/*     */       }
/*     */       else {
/*     */         
/*  86 */         arrayOfCoreSubscriber[i] = new FluxPeek.PeekSubscriber<>(subscribers[i], this);
/*     */       } 
/*     */     } 
/*     */     
/*  90 */     this.source.subscribe((CoreSubscriber<? super T>[])arrayOfCoreSubscriber);
/*     */   }
/*     */ 
/*     */   
/*     */   public int parallelism() {
/*  95 */     return this.source.parallelism();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrefetch() {
/* 100 */     return this.source.getPrefetch();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Subscription> onSubscribeCall() {
/* 106 */     return this.onSubscribe;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super T> onNextCall() {
/* 112 */     return this.onNext;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super Throwable> onErrorCall() {
/* 118 */     return this.onError;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCompleteCall() {
/* 124 */     return this.onComplete;
/*     */   }
/*     */ 
/*     */   
/*     */   public Runnable onAfterTerminateCall() {
/* 129 */     return this.onAfterTerminated;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LongConsumer onRequestCall() {
/* 135 */     return this.onRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Runnable onCancelCall() {
/* 141 */     return this.onCancel;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Consumer<? super T> onAfterNextCall() {
/* 147 */     return this.onAfterNext;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 153 */     if (key == Scannable.Attr.PARENT) return this.source; 
/* 154 */     if (key == Scannable.Attr.PREFETCH) return Integer.valueOf(getPrefetch()); 
/* 155 */     if (key == Scannable.Attr.RUN_STYLE) return Scannable.Attr.RunStyle.SYNC;
/*     */     
/* 157 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\publisher\ParallelPeek.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */