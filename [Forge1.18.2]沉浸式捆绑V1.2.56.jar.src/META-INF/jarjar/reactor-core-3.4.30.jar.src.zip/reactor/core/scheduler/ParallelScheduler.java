/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParallelScheduler
/*     */   implements Scheduler, Supplier<ScheduledExecutorService>, SchedulerState.DisposeAwaiter<ScheduledExecutorService[]>, Scannable
/*     */ {
/*     */   static final ScheduledExecutorService TERMINATED;
/*  46 */   static final ScheduledExecutorService[] SHUTDOWN = new ScheduledExecutorService[0]; final int n;
/*  47 */   static final AtomicLong COUNTER = new AtomicLong(); final ThreadFactory factory;
/*     */   
/*     */   static {
/*  50 */     TERMINATED = Executors.newSingleThreadScheduledExecutor();
/*  51 */     TERMINATED.shutdownNow();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     STATE = AtomicReferenceFieldUpdater.newUpdater(ParallelScheduler.class, SchedulerState.class, "state");
/*     */   }
/*     */   volatile SchedulerState<ScheduledExecutorService[]> state;
/*     */   private static final AtomicReferenceFieldUpdater<ParallelScheduler, SchedulerState> STATE;
/*     */   int roundRobin;
/*     */   
/*     */   ParallelScheduler(int n, ThreadFactory factory) {
/*  67 */     if (n <= 0) {
/*  68 */       throw new IllegalArgumentException("n > 0 required but it was " + n);
/*     */     }
/*  70 */     this.n = n;
/*  71 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService get() {
/*  80 */     ScheduledThreadPoolExecutor poolExecutor = new ScheduledThreadPoolExecutor(1, this.factory);
/*  81 */     poolExecutor.setMaximumPoolSize(1);
/*  82 */     poolExecutor.setRemoveOnCancelPolicy(true);
/*  83 */     return poolExecutor;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  88 */     SchedulerState<ScheduledExecutorService[]> current = this.state;
/*  89 */     return (current != null && current.currentResource == SHUTDOWN);
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/*  94 */     SchedulerState<ScheduledExecutorService[]> a = this.state;
/*  95 */     if (a != null) {
/*  96 */       if (a.currentResource == SHUTDOWN) {
/*  97 */         throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     SchedulerState<ScheduledExecutorService[]> b = (SchedulerState)SchedulerState.init(new ScheduledExecutorService[this.n]);
/*     */     
/* 108 */     for (int i = 0; i < this.n; i++) {
/* 109 */       ((ScheduledExecutorService[])b.currentResource)[i] = Schedulers.decorateExecutorService(this, get());
/*     */     }
/*     */     
/* 112 */     if (!STATE.compareAndSet(this, null, b)) {
/* 113 */       for (ScheduledExecutorService exec : (ScheduledExecutorService[])b.currentResource) {
/* 114 */         exec.shutdownNow();
/*     */       }
/* 116 */       if (isDisposed()) {
/* 117 */         throw new IllegalStateException("Initializing a disposed scheduler is not permitted");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 126 */     SchedulerState<ScheduledExecutorService[]> a = this.state;
/*     */     
/* 128 */     if (a != null && a.currentResource != SHUTDOWN) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 133 */     SchedulerState<ScheduledExecutorService[]> b = (SchedulerState)SchedulerState.init(new ScheduledExecutorService[this.n]);
/* 134 */     for (int i = 0; i < this.n; i++) {
/* 135 */       ((ScheduledExecutorService[])b.currentResource)[i] = Schedulers.decorateExecutorService(this, get());
/*     */     }
/*     */     
/* 138 */     if (STATE.compareAndSet(this, a, b)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 143 */     for (ScheduledExecutorService exec : (ScheduledExecutorService[])b.currentResource) {
/* 144 */       exec.shutdownNow();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean await(ScheduledExecutorService[] resource, long timeout, TimeUnit timeUnit) throws InterruptedException {
/* 150 */     for (ScheduledExecutorService executor : resource) {
/* 151 */       if (!executor.awaitTermination(timeout, timeUnit)) {
/* 152 */         return false;
/*     */       }
/*     */     } 
/* 155 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 160 */     SchedulerState<ScheduledExecutorService[]> previous = this.state;
/*     */     
/* 162 */     if (previous != null && previous.currentResource == SHUTDOWN) {
/* 163 */       if (previous.initialResource != null) {
/* 164 */         for (ScheduledExecutorService executor : (ScheduledExecutorService[])previous.initialResource) {
/* 165 */           executor.shutdownNow();
/*     */         }
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 171 */     SchedulerState<ScheduledExecutorService[]> shutdown = (SchedulerState)SchedulerState.transition((previous == null) ? null : (ScheduledExecutorService[])previous.currentResource, SHUTDOWN, this);
/*     */ 
/*     */ 
/*     */     
/* 175 */     STATE.compareAndSet(this, previous, shutdown);
/*     */ 
/*     */ 
/*     */     
/* 179 */     if (shutdown.initialResource != null) {
/* 180 */       for (ScheduledExecutorService executor : (ScheduledExecutorService[])shutdown.initialResource) {
/* 181 */         executor.shutdownNow();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeGracefully() {
/* 188 */     return Mono.defer(() -> {
/*     */           SchedulerState<ScheduledExecutorService[]> previous = this.state;
/*     */           if (previous != null && previous.currentResource == SHUTDOWN) {
/*     */             return previous.onDispose;
/*     */           }
/*     */           SchedulerState<ScheduledExecutorService[]> shutdown = (SchedulerState)SchedulerState.transition((previous == null) ? null : (ScheduledExecutorService[])previous.currentResource, SHUTDOWN, this);
/*     */           STATE.compareAndSet(this, previous, shutdown);
/*     */           if (shutdown.initialResource != null) {
/*     */             for (ScheduledExecutorService executor : (ScheduledExecutorService[])shutdown.initialResource) {
/*     */               executor.shutdown();
/*     */             }
/*     */           }
/*     */           return shutdown.onDispose;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ScheduledExecutorService pick() {
/* 213 */     SchedulerState<ScheduledExecutorService[]> a = this.state;
/* 214 */     if (a == null) {
/* 215 */       init();
/* 216 */       a = this.state;
/* 217 */       if (a == null) {
/* 218 */         throw new IllegalStateException("executors uninitialized after implicit init()");
/*     */       }
/*     */     } 
/* 221 */     if (a.currentResource != SHUTDOWN) {
/*     */       
/* 223 */       int idx = this.roundRobin;
/* 224 */       if (idx == this.n) {
/* 225 */         idx = 0;
/* 226 */         this.roundRobin = 1;
/*     */       } else {
/*     */         
/* 229 */         this.roundRobin = idx + 1;
/*     */       } 
/* 231 */       return ((ScheduledExecutorService[])a.currentResource)[idx];
/*     */     } 
/* 233 */     return TERMINATED;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/* 238 */     return Schedulers.directSchedule(pick(), task, null, 0L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 243 */     return Schedulers.directSchedule(pick(), task, null, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 251 */     return Schedulers.directSchedulePeriodically(pick(), task, initialDelay, period, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 261 */     StringBuilder ts = (new StringBuilder("parallel")).append('(').append(this.n);
/* 262 */     if (this.factory instanceof ReactorThreadFactory) {
/* 263 */       ts.append(",\"").append(((ReactorThreadFactory)this.factory).get()).append('"');
/*     */     }
/* 265 */     ts.append(')');
/* 266 */     return ts.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 271 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 272 */     if (key == Scannable.Attr.CAPACITY || key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.n); 
/* 273 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 275 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<? extends Scannable> inners() {
/* 280 */     return Stream.<Object>of((Object[])this.state.currentResource)
/* 281 */       .map(exec -> ());
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/* 286 */     return new ExecutorServiceWorker(pick());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\scheduler\ParallelScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */