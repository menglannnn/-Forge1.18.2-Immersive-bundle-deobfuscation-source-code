/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ExecutorScheduler
/*     */   implements Scheduler, Scannable
/*     */ {
/*     */   final Executor executor;
/*     */   final boolean trampoline;
/*     */   volatile boolean terminated;
/*     */   
/*     */   ExecutorScheduler(Executor executor, boolean trampoline) {
/*  50 */     this.executor = executor;
/*  51 */     this.trampoline = trampoline;
/*     */   }
/*     */ 
/*     */   
/*     */   public Disposable schedule(Runnable task) {
/*  56 */     if (this.terminated) {
/*  57 */       throw Exceptions.failWithRejected();
/*     */     }
/*  59 */     Objects.requireNonNull(task, "task");
/*     */     
/*  61 */     task = Schedulers.onSchedule(task);
/*     */     
/*  63 */     ExecutorPlainRunnable r = new ExecutorPlainRunnable(task);
/*     */ 
/*     */     
/*     */     try {
/*  67 */       this.executor.execute(r);
/*     */     }
/*  69 */     catch (Throwable ex) {
/*  70 */       if (this.executor instanceof ExecutorService && ((ExecutorService)this.executor).isShutdown()) {
/*  71 */         this.terminated = true;
/*     */       }
/*  73 */       Schedulers.handleError(ex);
/*  74 */       throw Exceptions.failWithRejected(ex);
/*     */     } 
/*  76 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  81 */     this.terminated = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  86 */     return this.terminated;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler.Worker createWorker() {
/*  91 */     return this.trampoline ? new ExecutorSchedulerTrampolineWorker(this.executor) : new ExecutorSchedulerWorker(this.executor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     StringBuilder ts = (new StringBuilder("fromExecutor")).append('(').append(this.executor);
/*  99 */     if (this.trampoline) ts.append(",trampolining"); 
/* 100 */     ts.append(')');
/*     */     
/* 102 */     return ts.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 107 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 108 */     if (key == Scannable.Attr.NAME) return toString();
/*     */     
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ExecutorPlainRunnable
/*     */     extends AtomicBoolean
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private static final long serialVersionUID = 5116223460201378097L;
/*     */ 
/*     */     
/*     */     final Runnable task;
/*     */ 
/*     */ 
/*     */     
/*     */     ExecutorPlainRunnable(Runnable task) {
/* 128 */       this.task = task;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 133 */       if (!get()) {
/*     */         try {
/* 135 */           this.task.run();
/*     */         }
/* 137 */         catch (Throwable ex) {
/* 138 */           Schedulers.handleError(ex);
/*     */         } finally {
/*     */           
/* 141 */           lazySet(true);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 148 */       return get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 153 */       set(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static interface WorkerDelete
/*     */   {
/*     */     void delete(ExecutorScheduler.ExecutorTrackedRunnable param1ExecutorTrackedRunnable);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ExecutorTrackedRunnable
/*     */     extends AtomicBoolean
/*     */     implements Runnable, Disposable
/*     */   {
/*     */     private static final long serialVersionUID = 3503344795919906192L;
/*     */ 
/*     */     
/*     */     final Runnable task;
/*     */ 
/*     */     
/*     */     final ExecutorScheduler.WorkerDelete parent;
/*     */ 
/*     */     
/*     */     final boolean callRemoveOnFinish;
/*     */ 
/*     */     
/*     */     ExecutorTrackedRunnable(Runnable task, ExecutorScheduler.WorkerDelete parent, boolean callRemoveOnFinish) {
/* 183 */       this.task = task;
/* 184 */       this.parent = parent;
/* 185 */       this.callRemoveOnFinish = callRemoveOnFinish;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 190 */       if (!get()) {
/*     */         try {
/* 192 */           this.task.run();
/*     */         }
/* 194 */         catch (Throwable ex) {
/* 195 */           Schedulers.handleError(ex);
/*     */         } finally {
/*     */           
/* 198 */           if (this.callRemoveOnFinish) {
/* 199 */             dispose();
/*     */           } else {
/*     */             
/* 202 */             lazySet(true);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 210 */       if (compareAndSet(false, true)) {
/* 211 */         this.parent.delete(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 217 */       return get();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ExecutorSchedulerWorker
/*     */     implements Scheduler.Worker, WorkerDelete, Scannable
/*     */   {
/*     */     private final boolean wrapSchedule;
/*     */     
/*     */     final Executor executor;
/*     */     
/*     */     final Disposable.Composite tasks;
/*     */ 
/*     */     
/*     */     ExecutorSchedulerWorker(Executor executor) {
/* 233 */       this.executor = executor;
/* 234 */       this.wrapSchedule = !(executor instanceof Scheduler);
/* 235 */       this.tasks = Disposables.composite();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task) {
/* 240 */       Objects.requireNonNull(task, "task");
/*     */       
/* 242 */       if (this.wrapSchedule) {
/* 243 */         task = Schedulers.onSchedule(task);
/*     */       }
/*     */       
/* 246 */       ExecutorScheduler.ExecutorTrackedRunnable r = new ExecutorScheduler.ExecutorTrackedRunnable(task, this, true);
/* 247 */       if (!this.tasks.add(r)) {
/* 248 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/*     */       try {
/* 252 */         this.executor.execute(r);
/*     */       }
/* 254 */       catch (Throwable ex) {
/* 255 */         this.tasks.remove(r);
/* 256 */         Schedulers.handleError(ex);
/* 257 */         throw Exceptions.failWithRejected(ex);
/*     */       } 
/*     */       
/* 260 */       return r;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 265 */       this.tasks.dispose();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 270 */       return this.tasks.isDisposed();
/*     */     }
/*     */ 
/*     */     
/*     */     public void delete(ExecutorScheduler.ExecutorTrackedRunnable r) {
/* 275 */       this.tasks.remove(r);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 280 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 281 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.tasks.size()); 
/* 282 */       if (key == Scannable.Attr.PARENT) return (this.executor instanceof Scannable) ? this.executor : null; 
/* 283 */       if (key == Scannable.Attr.NAME) {
/*     */         
/* 285 */         if (this.executor instanceof SingleWorkerScheduler) return this.executor + ".worker"; 
/* 286 */         return "fromExecutor(" + this.executor + ").worker";
/*     */       } 
/*     */       
/* 289 */       return Schedulers.scanExecutor(this.executor, key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ExecutorSchedulerTrampolineWorker
/*     */     implements Scheduler.Worker, WorkerDelete, Runnable, Scannable
/*     */   {
/*     */     private final boolean wrapSchedule;
/*     */ 
/*     */     
/*     */     final Executor executor;
/*     */     
/*     */     final Queue<ExecutorScheduler.ExecutorTrackedRunnable> queue;
/*     */     
/*     */     volatile boolean terminated;
/*     */     
/*     */     volatile int wip;
/*     */     
/* 309 */     static final AtomicIntegerFieldUpdater<ExecutorSchedulerTrampolineWorker> WIP = AtomicIntegerFieldUpdater.newUpdater(ExecutorSchedulerTrampolineWorker.class, "wip");
/*     */ 
/*     */     
/*     */     ExecutorSchedulerTrampolineWorker(Executor executor) {
/* 313 */       this.executor = executor;
/* 314 */       this.wrapSchedule = !(executor instanceof Scheduler);
/* 315 */       this.queue = new ConcurrentLinkedQueue<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public Disposable schedule(Runnable task) {
/* 320 */       Objects.requireNonNull(task, "task");
/* 321 */       if (this.terminated) {
/* 322 */         throw Exceptions.failWithRejected();
/*     */       }
/*     */       
/* 325 */       if (this.wrapSchedule) {
/* 326 */         task = Schedulers.onSchedule(task);
/*     */       }
/*     */       
/* 329 */       ExecutorScheduler.ExecutorTrackedRunnable r = new ExecutorScheduler.ExecutorTrackedRunnable(task, this, false);
/* 330 */       synchronized (this) {
/* 331 */         if (this.terminated) {
/* 332 */           throw Exceptions.failWithRejected();
/*     */         }
/* 334 */         this.queue.offer(r);
/*     */       } 
/*     */       
/* 337 */       if (WIP.getAndIncrement(this) == 0) {
/*     */         try {
/* 339 */           this.executor.execute(this);
/*     */         }
/* 341 */         catch (Throwable ex) {
/* 342 */           r.dispose();
/* 343 */           Schedulers.handleError(ex);
/* 344 */           throw Exceptions.failWithRejected(ex);
/*     */         } 
/*     */       }
/*     */       
/* 348 */       return r;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 353 */       if (this.terminated) {
/*     */         return;
/*     */       }
/* 356 */       this.terminated = true;
/* 357 */       Queue<ExecutorScheduler.ExecutorTrackedRunnable> q = this.queue;
/*     */       
/*     */       ExecutorScheduler.ExecutorTrackedRunnable r;
/*     */       
/* 361 */       while ((r = q.poll()) != null && !q.isEmpty()) {
/* 362 */         r.dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisposed() {
/* 368 */       return this.terminated;
/*     */     }
/*     */ 
/*     */     
/*     */     public void delete(ExecutorScheduler.ExecutorTrackedRunnable r) {
/* 373 */       synchronized (this) {
/* 374 */         if (!this.terminated) {
/* 375 */           this.queue.remove(r);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       int e;
/* 382 */       Queue<ExecutorScheduler.ExecutorTrackedRunnable> q = this.queue;
/*     */ 
/*     */       
/*     */       do {
/* 386 */         e = 0;
/* 387 */         int r = this.wip;
/*     */         
/* 389 */         while (e != r) {
/* 390 */           if (this.terminated) {
/*     */             return;
/*     */           }
/* 393 */           ExecutorScheduler.ExecutorTrackedRunnable task = q.poll();
/*     */           
/* 395 */           if (task == null) {
/*     */             break;
/*     */           }
/*     */           
/* 399 */           task.run();
/*     */           
/* 401 */           e++;
/*     */         } 
/*     */         
/* 404 */         if (e == r && this.terminated) {
/*     */           return;
/*     */         }
/*     */       }
/* 408 */       while (WIP.addAndGet(this, -e) != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 416 */       if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 417 */       if (key == Scannable.Attr.PARENT) return (this.executor instanceof Scannable) ? this.executor : null; 
/* 418 */       if (key == Scannable.Attr.NAME) return "fromExecutor(" + this.executor + ",trampolining).worker"; 
/* 419 */       if (key == Scannable.Attr.BUFFERED || key == Scannable.Attr.LARGE_BUFFERED) return Integer.valueOf(this.queue.size());
/*     */       
/* 421 */       return Schedulers.scanExecutor(this.executor, key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\scheduler\ExecutorScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */