/*     */ package reactor.core.scheduler;
/*     */ 
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.FluxSink;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SchedulerState<T>
/*     */ {
/*     */   @Nullable
/*     */   final T initialResource;
/*     */   final T currentResource;
/*     */   final Mono<Void> onDispose;
/*     */   
/*     */   private SchedulerState(@Nullable T initialResource, T currentResource, Mono<Void> onDispose) {
/*  38 */     this.initialResource = initialResource;
/*  39 */     this.currentResource = currentResource;
/*  40 */     this.onDispose = onDispose;
/*     */   }
/*     */   
/*     */   static <T> SchedulerState<T> init(T resource) {
/*  44 */     return new SchedulerState<>(resource, resource, Mono.empty());
/*     */   }
/*     */   
/*     */   static <T> SchedulerState<T> transition(@Nullable T initial, T next, DisposeAwaiter<T> awaiter) {
/*  48 */     return new SchedulerState<>(initial, next, (initial == null) ? 
/*     */ 
/*     */         
/*  51 */         Mono.empty() : 
/*  52 */         Flux.create(sink -> DisposeAwaiterRunnable.awaitInPool(awaiter, initial, sink, 100))
/*  53 */         .replay()
/*  54 */         .refCount()
/*  55 */         .next());
/*     */   }
/*     */   
/*     */   static class DisposeAwaiterRunnable<T>
/*     */     implements Runnable {
/*     */     static final ScheduledExecutorService TRANSITION_AWAIT_POOL;
/*     */     private final SchedulerState.DisposeAwaiter<T> awaiter;
/*     */     private final T initial;
/*     */     private final int awaitMs;
/*     */     private final FluxSink<Void> sink;
/*     */     volatile boolean cancelled;
/*     */     
/*     */     static {
/*  68 */       ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(0);
/*  69 */       executor.setKeepAliveTime(10L, TimeUnit.SECONDS);
/*  70 */       executor.allowCoreThreadTimeOut(true);
/*  71 */       executor.setMaximumPoolSize(Schedulers.DEFAULT_POOL_SIZE);
/*  72 */       TRANSITION_AWAIT_POOL = executor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static <R> void awaitInPool(SchedulerState.DisposeAwaiter<R> awaiter, R initial, FluxSink<Void> sink, int awaitMs) {
/*  83 */       DisposeAwaiterRunnable<R> poller = new DisposeAwaiterRunnable<>(awaiter, initial, sink, awaitMs);
/*  84 */       TRANSITION_AWAIT_POOL.submit(poller);
/*     */     }
/*     */     
/*     */     DisposeAwaiterRunnable(SchedulerState.DisposeAwaiter<T> awaiter, T initial, FluxSink<Void> sink, int awaitMs) {
/*  88 */       this.awaiter = awaiter;
/*  89 */       this.initial = initial;
/*  90 */       this.sink = sink;
/*  91 */       this.awaitMs = awaitMs;
/*     */       
/*  93 */       sink.onCancel(this::cancel);
/*     */     }
/*     */     
/*     */     void cancel() {
/*  97 */       this.cancelled = true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 103 */       if (this.cancelled) {
/*     */         return;
/*     */       }
/*     */       try {
/* 107 */         if (this.awaiter.await(this.initial, this.awaitMs, TimeUnit.MILLISECONDS)) {
/* 108 */           this.sink.complete();
/*     */         } else {
/*     */           
/* 111 */           if (this.cancelled) {
/*     */             return;
/*     */           }
/*     */           
/* 115 */           TRANSITION_AWAIT_POOL.submit(this);
/*     */         }
/*     */       
/* 118 */       } catch (InterruptedException interruptedException) {}
/*     */     }
/*     */   }
/*     */   
/*     */   static interface DisposeAwaiter<T> {
/*     */     boolean await(T param1T, long param1Long, TimeUnit param1TimeUnit) throws InterruptedException;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\scheduler\SchedulerState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */