/*    */ package reactor.core.scheduler;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.FutureTask;
/*    */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PeriodicSchedulerTask
/*    */   implements Runnable, Disposable, Callable<Void>
/*    */ {
/*    */   final Runnable task;
/* 31 */   static final Future<Void> CANCELLED = new FutureTask<>(() -> null);
/*    */   
/*    */   volatile Future<?> future;
/*    */   
/* 35 */   static final AtomicReferenceFieldUpdater<PeriodicSchedulerTask, Future> FUTURE = AtomicReferenceFieldUpdater.newUpdater(PeriodicSchedulerTask.class, Future.class, "future");
/*    */   
/*    */   Thread thread;
/*    */   
/*    */   PeriodicSchedulerTask(Runnable task) {
/* 40 */     this.task = task;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Void call() {
/* 46 */     this.thread = Thread.currentThread();
/*    */     try {
/*    */       try {
/* 49 */         this.task.run();
/*    */       }
/* 51 */       catch (Throwable ex) {
/* 52 */         Schedulers.handleError(ex);
/*    */       } 
/*    */     } finally {
/*    */       
/* 56 */       this.thread = null;
/*    */     } 
/* 58 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 63 */     call();
/*    */   }
/*    */   void setFuture(Future<?> f) {
/*    */     Future<?> o;
/*    */     do {
/* 68 */       o = this.future;
/* 69 */       if (o == CANCELLED) {
/* 70 */         f.cancel((this.thread != Thread.currentThread()));
/*    */         return;
/*    */       } 
/* 73 */     } while (!FUTURE.compareAndSet(this, o, f));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isDisposed() {
/* 81 */     return (this.future == CANCELLED);
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {
/*    */     while (true) {
/* 87 */       Future<?> f = this.future;
/* 88 */       if (f == CANCELLED) {
/*    */         break;
/*    */       }
/* 91 */       if (FUTURE.compareAndSet(this, f, CANCELLED)) {
/* 92 */         if (f != null)
/* 93 */           f.cancel((this.thread != Thread.currentThread())); 
/*    */         break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\scheduler\PeriodicSchedulerTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */