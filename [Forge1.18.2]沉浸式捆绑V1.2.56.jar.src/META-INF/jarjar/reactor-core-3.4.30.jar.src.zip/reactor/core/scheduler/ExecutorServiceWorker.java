/*    */ package reactor.core.scheduler;
/*    */ 
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Disposables;
/*    */ import reactor.core.Scannable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExecutorServiceWorker
/*    */   implements Scheduler.Worker, Disposable, Scannable
/*    */ {
/*    */   final ScheduledExecutorService exec;
/*    */   final Disposable.Composite disposables;
/*    */   
/*    */   ExecutorServiceWorker(ScheduledExecutorService exec) {
/* 44 */     this.exec = exec;
/* 45 */     this.disposables = Disposables.composite();
/*    */   }
/*    */ 
/*    */   
/*    */   public Disposable schedule(Runnable task) {
/* 50 */     return Schedulers.workerSchedule(this.exec, this.disposables, task, 0L, TimeUnit.MILLISECONDS);
/*    */   }
/*    */ 
/*    */   
/*    */   public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 55 */     return Schedulers.workerSchedule(this.exec, this.disposables, task, delay, unit);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 63 */     return Schedulers.workerSchedulePeriodically(this.exec, this.disposables, task, initialDelay, period, unit);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 72 */     this.disposables.dispose();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDisposed() {
/* 77 */     return this.disposables.isDisposed();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object scanUnsafe(Scannable.Attr key) {
/* 82 */     if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(this.disposables.size()); 
/* 83 */     if (key == Scannable.Attr.TERMINATED || key == Scannable.Attr.CANCELLED) return Boolean.valueOf(isDisposed()); 
/* 84 */     if (key == Scannable.Attr.NAME) return "ExecutorServiceWorker";
/*    */     
/* 86 */     return Schedulers.scanExecutor(this.exec, key);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\scheduler\ExecutorServiceWorker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */