/*      */ package reactor.core.scheduler;
/*      */ 
/*      */ import java.util.Collection;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.Exceptions;
/*      */ import reactor.core.Scannable;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.Metrics;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Schedulers
/*      */ {
/*   79 */   public static final int DEFAULT_POOL_SIZE = ((Integer)Optional.<String>ofNullable(System.getProperty("reactor.schedulers.defaultPoolSize"))
/*   80 */     .map(Integer::parseInt)
/*   81 */     .orElseGet(() -> Integer.valueOf(Runtime.getRuntime().availableProcessors()))).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   92 */   public static final int DEFAULT_BOUNDED_ELASTIC_SIZE = ((Integer)Optional.<String>ofNullable(System.getProperty("reactor.schedulers.defaultBoundedElasticSize"))
/*   93 */     .map(Integer::parseInt)
/*   94 */     .orElseGet(() -> Integer.valueOf(10 * Runtime.getRuntime().availableProcessors()))).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  104 */   public static final int DEFAULT_BOUNDED_ELASTIC_QUEUESIZE = ((Integer)Optional.<String>ofNullable(System.getProperty("reactor.schedulers.defaultBoundedElasticQueueSize"))
/*  105 */     .map(Integer::parseInt)
/*  106 */     .orElse(Integer.valueOf(100000))).intValue();
/*      */   
/*      */   static final String ELASTIC = "elastic";
/*      */   
/*      */   static final String BOUNDED_ELASTIC = "boundedElastic";
/*      */   
/*      */   static final String PARALLEL = "parallel";
/*      */   
/*      */   static final String SINGLE = "single";
/*      */   
/*      */   static final String IMMEDIATE = "immediate";
/*      */   static final String FROM_EXECUTOR = "fromExecutor";
/*      */   static final String FROM_EXECUTOR_SERVICE = "fromExecutorService";
/*      */   
/*      */   public static Scheduler fromExecutor(Executor executor) {
/*  121 */     return fromExecutor(executor, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler fromExecutor(Executor executor, boolean trampoline) {
/*  139 */     if (!trampoline && executor instanceof ExecutorService) {
/*  140 */       return fromExecutorService((ExecutorService)executor);
/*      */     }
/*  142 */     ExecutorScheduler scheduler = new ExecutorScheduler(executor, trampoline);
/*  143 */     scheduler.init();
/*  144 */     return scheduler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler fromExecutorService(ExecutorService executorService) {
/*  159 */     String executorServiceHashcode = Integer.toHexString(System.identityHashCode(executorService));
/*  160 */     return fromExecutorService(executorService, "anonymousExecutor@" + executorServiceHashcode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler fromExecutorService(ExecutorService executorService, String executorName) {
/*  172 */     DelegateServiceScheduler scheduler = new DelegateServiceScheduler(executorName, executorService);
/*  173 */     scheduler.init();
/*  174 */     return scheduler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler elastic() {
/*  194 */     return cache(CACHED_ELASTIC, "elastic", ELASTIC_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler boundedElastic() {
/*  231 */     return cache(CACHED_BOUNDED_ELASTIC, "boundedElastic", BOUNDED_ELASTIC_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler parallel() {
/*  249 */     return cache(CACHED_PARALLEL, "parallel", PARALLEL_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler immediate() {
/*  263 */     return ImmediateScheduler.instance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler newElastic(String name) {
/*  285 */     return newElastic(name, 60);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler newElastic(String name, int ttlSeconds) {
/*  305 */     return newElastic(name, ttlSeconds, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler newElastic(String name, int ttlSeconds, boolean daemon) {
/*  327 */     return newElastic(ttlSeconds, new ReactorThreadFactory(name, ElasticScheduler.COUNTER, daemon, false, Schedulers::defaultUncaughtException));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scheduler newElastic(int ttlSeconds, ThreadFactory threadFactory) {
/*  349 */     Scheduler fromFactory = factory.newElastic(ttlSeconds, threadFactory);
/*  350 */     fromFactory.init();
/*  351 */     return fromFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, String name) {
/*  387 */     return newBoundedElastic(threadCap, queuedTaskCap, name, 60, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, String name, int ttlSeconds) {
/*  423 */     return newBoundedElastic(threadCap, queuedTaskCap, name, ttlSeconds, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, String name, int ttlSeconds, boolean daemon) {
/*  461 */     return newBoundedElastic(threadCap, queuedTaskCap, new ReactorThreadFactory(name, ElasticScheduler.COUNTER, daemon, false, Schedulers::defaultUncaughtException), ttlSeconds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, ThreadFactory threadFactory, int ttlSeconds) {
/*  501 */     Scheduler fromFactory = factory.newBoundedElastic(threadCap, queuedTaskCap, threadFactory, ttlSeconds);
/*      */ 
/*      */ 
/*      */     
/*  505 */     fromFactory.init();
/*  506 */     return fromFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newParallel(String name) {
/*  520 */     return newParallel(name, DEFAULT_POOL_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newParallel(String name, int parallelism) {
/*  535 */     return newParallel(name, parallelism, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newParallel(String name, int parallelism, boolean daemon) {
/*  552 */     return newParallel(parallelism, new ReactorThreadFactory(name, ParallelScheduler.COUNTER, daemon, true, Schedulers::defaultUncaughtException));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newParallel(int parallelism, ThreadFactory threadFactory) {
/*  569 */     Scheduler fromFactory = factory.newParallel(parallelism, threadFactory);
/*  570 */     fromFactory.init();
/*  571 */     return fromFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newSingle(String name) {
/*  584 */     return newSingle(name, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newSingle(String name, boolean daemon) {
/*  599 */     return newSingle(new ReactorThreadFactory(name, SingleScheduler.COUNTER, daemon, true, Schedulers::defaultUncaughtException));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler newSingle(ThreadFactory threadFactory) {
/*  613 */     Scheduler fromFactory = factory.newSingle(threadFactory);
/*  614 */     fromFactory.init();
/*  615 */     return fromFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onHandleError(BiConsumer<Thread, ? super Throwable> subHook) {
/*  632 */     Objects.requireNonNull(subHook, "onHandleError");
/*  633 */     if (LOGGER.isDebugEnabled()) {
/*  634 */       LOGGER.debug("Hooking onHandleError anonymous part");
/*      */     }
/*  636 */     synchronized (LOGGER) {
/*  637 */       onHandleErrorHooks.put(Schedulers.class.getName() + ".ON_HANDLE_ERROR_ANONYMOUS_PART", subHook);
/*  638 */       onHandleErrorHook = createOrAppendHandleError(onHandleErrorHooks.values());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onHandleError(String key, BiConsumer<Thread, ? super Throwable> subHook) {
/*  658 */     Objects.requireNonNull(key, "key");
/*  659 */     Objects.requireNonNull(subHook, "onHandleError");
/*  660 */     if (LOGGER.isDebugEnabled()) {
/*  661 */       LOGGER.debug("Hooking onHandleError part with key {}", new Object[] { key });
/*      */     }
/*  663 */     synchronized (LOGGER) {
/*  664 */       onHandleErrorHooks.put(key, subHook);
/*  665 */       onHandleErrorHook = createOrAppendHandleError(onHandleErrorHooks.values());
/*      */     } 
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private static BiConsumer<Thread, ? super Throwable> createOrAppendHandleError(Collection<BiConsumer<Thread, Throwable>> subHooks) {
/*  671 */     BiConsumer<Thread, Throwable> composite = null;
/*  672 */     for (BiConsumer<Thread, Throwable> value : subHooks) {
/*  673 */       if (composite != null) {
/*  674 */         composite = composite.andThen(value);
/*      */         continue;
/*      */       } 
/*  677 */       composite = value;
/*      */     } 
/*      */     
/*  680 */     return composite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isInNonBlockingThread() {
/*  691 */     return Thread.currentThread() instanceof NonBlocking;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNonBlockingThread(Thread t) {
/*  702 */     return t instanceof NonBlocking;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void enableMetrics() {
/*  720 */     if (Metrics.isInstrumentationAvailable()) {
/*  721 */       addExecutorServiceDecorator("reactor.metrics.decorator", new SchedulerMetricDecorator());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void disableMetrics() {
/*  730 */     removeExecutorServiceDecorator("reactor.metrics.decorator");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetFactory() {
/*  737 */     setFactory(DEFAULT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Snapshot setFactoryWithSnapshot(Factory newFactory) {
/*  758 */     Snapshot snapshot = new Snapshot(CACHED_ELASTIC.getAndSet(null), CACHED_BOUNDED_ELASTIC.getAndSet(null), CACHED_PARALLEL.getAndSet(null), CACHED_SINGLE.getAndSet(null), factory);
/*      */     
/*  760 */     setFactory(newFactory);
/*  761 */     return snapshot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetFrom(@Nullable Snapshot snapshot) {
/*  771 */     if (snapshot == null) {
/*  772 */       resetFactory();
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  777 */     CachedScheduler oldElastic = CACHED_ELASTIC.getAndSet(snapshot.oldElasticScheduler);
/*  778 */     CachedScheduler oldBoundedElastic = CACHED_BOUNDED_ELASTIC.getAndSet(snapshot.oldBoundedElasticScheduler);
/*  779 */     CachedScheduler oldParallel = CACHED_PARALLEL.getAndSet(snapshot.oldParallelScheduler);
/*  780 */     CachedScheduler oldSingle = CACHED_SINGLE.getAndSet(snapshot.oldSingleScheduler);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  785 */     factory = snapshot.oldFactory;
/*      */ 
/*      */     
/*  788 */     if (oldElastic != null) oldElastic._dispose(); 
/*  789 */     if (oldBoundedElastic != null) oldBoundedElastic._dispose(); 
/*  790 */     if (oldParallel != null) oldParallel._dispose(); 
/*  791 */     if (oldSingle != null) oldSingle._dispose();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetOnHandleError() {
/*  802 */     if (LOGGER.isDebugEnabled()) {
/*  803 */       LOGGER.debug("Reset to factory defaults: onHandleError");
/*      */     }
/*  805 */     synchronized (LOGGER) {
/*  806 */       onHandleErrorHooks.clear();
/*  807 */       onHandleErrorHook = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetOnHandleError(String key) {
/*  816 */     if (LOGGER.isDebugEnabled()) {
/*  817 */       LOGGER.debug("Remove onHandleError sub-hook {}", new Object[] { key });
/*      */     }
/*  819 */     synchronized (LOGGER) {
/*      */ 
/*      */       
/*  822 */       if (onHandleErrorHooks.remove(key) != null) {
/*  823 */         onHandleErrorHook = createOrAppendHandleError(onHandleErrorHooks.values());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setFactory(Factory factoryInstance) {
/*  840 */     Objects.requireNonNull(factoryInstance, "factoryInstance");
/*  841 */     shutdownNow();
/*  842 */     factory = factoryInstance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean addExecutorServiceDecorator(String key, BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> decorator) {
/*  862 */     synchronized (DECORATORS) {
/*  863 */       return (DECORATORS.putIfAbsent(key, decorator) == null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setExecutorServiceDecorator(String key, BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> decorator) {
/*  882 */     synchronized (DECORATORS) {
/*  883 */       DECORATORS.put(key, decorator);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> removeExecutorServiceDecorator(String key) {
/*      */     BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> removed;
/*  901 */     synchronized (DECORATORS) {
/*  902 */       removed = DECORATORS.remove(key);
/*      */     } 
/*  904 */     if (removed instanceof Disposable) {
/*  905 */       ((Disposable)removed).dispose();
/*      */     }
/*  907 */     return removed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ScheduledExecutorService decorateExecutorService(Scheduler owner, ScheduledExecutorService original) {
/*  928 */     synchronized (DECORATORS) {
/*  929 */       for (BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService> decorator : DECORATORS.values()) {
/*  930 */         original = decorator.apply(owner, original);
/*      */       }
/*      */     } 
/*      */     
/*  934 */     return original;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void onScheduleHook(String key, Function<Runnable, Runnable> decorator) {
/*  951 */     synchronized (onScheduleHooks) {
/*  952 */       onScheduleHooks.put(key, decorator);
/*  953 */       Function<Runnable, Runnable> newHook = null;
/*  954 */       for (Function<Runnable, Runnable> function : onScheduleHooks.values()) {
/*  955 */         if (newHook == null) {
/*  956 */           newHook = function;
/*      */           continue;
/*      */         } 
/*  959 */         newHook = newHook.andThen(function);
/*      */       } 
/*      */       
/*  962 */       onScheduleHook = newHook;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetOnScheduleHook(String key) {
/*  975 */     synchronized (onScheduleHooks) {
/*  976 */       onScheduleHooks.remove(key);
/*  977 */       if (onScheduleHooks.isEmpty()) {
/*  978 */         onScheduleHook = Function.identity();
/*      */       } else {
/*      */         
/*  981 */         Function<Runnable, Runnable> newHook = null;
/*  982 */         for (Function<Runnable, Runnable> function : onScheduleHooks.values()) {
/*  983 */           if (newHook == null) {
/*  984 */             newHook = function;
/*      */             continue;
/*      */           } 
/*  987 */           newHook = newHook.andThen(function);
/*      */         } 
/*      */         
/*  990 */         onScheduleHook = newHook;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetOnScheduleHooks() {
/* 1002 */     synchronized (onScheduleHooks) {
/* 1003 */       onScheduleHooks.clear();
/* 1004 */       onScheduleHook = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Runnable onSchedule(Runnable runnable) {
/* 1015 */     Function<Runnable, Runnable> hook = onScheduleHook;
/* 1016 */     if (hook != null) {
/* 1017 */       return hook.apply(runnable);
/*      */     }
/*      */     
/* 1020 */     return runnable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shutdownNow() {
/* 1028 */     CachedScheduler oldElastic = CACHED_ELASTIC.getAndSet(null);
/* 1029 */     CachedScheduler oldBoundedElastic = CACHED_BOUNDED_ELASTIC.getAndSet(null);
/* 1030 */     CachedScheduler oldParallel = CACHED_PARALLEL.getAndSet(null);
/* 1031 */     CachedScheduler oldSingle = CACHED_SINGLE.getAndSet(null);
/*      */     
/* 1033 */     if (oldElastic != null) oldElastic._dispose(); 
/* 1034 */     if (oldBoundedElastic != null) oldBoundedElastic._dispose(); 
/* 1035 */     if (oldParallel != null) oldParallel._dispose(); 
/* 1036 */     if (oldSingle != null) oldSingle._dispose();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler single() {
/* 1054 */     return cache(CACHED_SINGLE, "single", SINGLE_SUPPLIER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scheduler single(Scheduler original) {
/* 1073 */     return new SingleWorkerScheduler(original);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Factory
/*      */   {
/*      */     @Deprecated
/*      */     default Scheduler newElastic(int ttlSeconds, ThreadFactory threadFactory) {
/* 1096 */       return new ElasticScheduler(threadFactory, ttlSeconds);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default Scheduler newBoundedElastic(int threadCap, int queuedTaskCap, ThreadFactory threadFactory, int ttlSeconds) {
/* 1115 */       return new BoundedElasticScheduler(threadCap, queuedTaskCap, threadFactory, ttlSeconds);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default Scheduler newParallel(int parallelism, ThreadFactory threadFactory) {
/* 1130 */       return new ParallelScheduler(parallelism, threadFactory);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     default Scheduler newSingle(ThreadFactory threadFactory) {
/* 1143 */       return new SingleScheduler(threadFactory);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Snapshot
/*      */     implements Disposable
/*      */   {
/*      */     @Nullable
/*      */     final Schedulers.CachedScheduler oldElasticScheduler;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     final Schedulers.CachedScheduler oldBoundedElasticScheduler;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     final Schedulers.CachedScheduler oldParallelScheduler;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     final Schedulers.CachedScheduler oldSingleScheduler;
/*      */     
/*      */     final Schedulers.Factory oldFactory;
/*      */ 
/*      */     
/*      */     private Snapshot(@Nullable Schedulers.CachedScheduler oldElasticScheduler, @Nullable Schedulers.CachedScheduler oldBoundedElasticScheduler, @Nullable Schedulers.CachedScheduler oldParallelScheduler, @Nullable Schedulers.CachedScheduler oldSingleScheduler, Schedulers.Factory factory) {
/* 1171 */       this.oldElasticScheduler = oldElasticScheduler;
/* 1172 */       this.oldBoundedElasticScheduler = oldBoundedElasticScheduler;
/* 1173 */       this.oldParallelScheduler = oldParallelScheduler;
/* 1174 */       this.oldSingleScheduler = oldSingleScheduler;
/* 1175 */       this.oldFactory = factory;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDisposed() {
/* 1180 */       return ((this.oldElasticScheduler == null || this.oldElasticScheduler
/* 1181 */         .isDisposed()) && (this.oldBoundedElasticScheduler == null || this.oldBoundedElasticScheduler
/* 1182 */         .isDisposed()) && (this.oldParallelScheduler == null || this.oldParallelScheduler
/* 1183 */         .isDisposed()) && (this.oldSingleScheduler == null || this.oldSingleScheduler
/* 1184 */         .isDisposed()));
/*      */     }
/*      */ 
/*      */     
/*      */     public void dispose() {
/* 1189 */       if (this.oldElasticScheduler != null) this.oldElasticScheduler._dispose(); 
/* 1190 */       if (this.oldBoundedElasticScheduler != null) this.oldBoundedElasticScheduler._dispose(); 
/* 1191 */       if (this.oldParallelScheduler != null) this.oldParallelScheduler._dispose(); 
/* 1192 */       if (this.oldSingleScheduler != null) this.oldSingleScheduler._dispose();
/*      */     
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1207 */   static AtomicReference<CachedScheduler> CACHED_ELASTIC = new AtomicReference<>();
/* 1208 */   static AtomicReference<CachedScheduler> CACHED_BOUNDED_ELASTIC = new AtomicReference<>();
/* 1209 */   static AtomicReference<CachedScheduler> CACHED_PARALLEL = new AtomicReference<>();
/* 1210 */   static AtomicReference<CachedScheduler> CACHED_SINGLE = new AtomicReference<>();
/*      */ 
/*      */   
/*      */   static final Supplier<Scheduler> ELASTIC_SUPPLIER = () -> newElastic("elastic", 60, true);
/*      */ 
/*      */   
/*      */   static final Supplier<Scheduler> BOUNDED_ELASTIC_SUPPLIER = () -> newBoundedElastic(DEFAULT_BOUNDED_ELASTIC_SIZE, DEFAULT_BOUNDED_ELASTIC_QUEUESIZE, "boundedElastic", 60, true);
/*      */ 
/*      */   
/*      */   static final Supplier<Scheduler> PARALLEL_SUPPLIER = () -> newParallel("parallel", DEFAULT_POOL_SIZE, true);
/*      */ 
/*      */   
/*      */   static final Supplier<Scheduler> SINGLE_SUPPLIER = () -> newSingle("single", true);
/*      */   
/* 1224 */   static final Factory DEFAULT = new Factory() {
/*      */     
/*      */     };
/* 1227 */   static final Map<String, BiFunction<Scheduler, ScheduledExecutorService, ScheduledExecutorService>> DECORATORS = new LinkedHashMap<>();
/*      */   
/* 1229 */   static volatile Factory factory = DEFAULT;
/*      */   
/* 1231 */   private static final LinkedHashMap<String, BiConsumer<Thread, Throwable>> onHandleErrorHooks = new LinkedHashMap<>(1);
/*      */   
/*      */   @Nullable
/*      */   static BiConsumer<Thread, ? super Throwable> onHandleErrorHook;
/*      */   
/* 1236 */   private static final LinkedHashMap<String, Function<Runnable, Runnable>> onScheduleHooks = new LinkedHashMap<>(1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private static Function<Runnable, Runnable> onScheduleHook;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static CachedScheduler cache(AtomicReference<CachedScheduler> reference, String key, Supplier<Scheduler> supplier) {
/* 1254 */     CachedScheduler s = reference.get();
/* 1255 */     if (s != null) {
/* 1256 */       return s;
/*      */     }
/* 1258 */     s = new CachedScheduler(key, supplier.get());
/* 1259 */     if (reference.compareAndSet(null, s)) {
/* 1260 */       return s;
/*      */     }
/*      */ 
/*      */     
/* 1264 */     s._dispose();
/* 1265 */     return reference.get();
/*      */   }
/*      */   
/* 1268 */   static final Logger LOGGER = Loggers.getLogger(Schedulers.class);
/*      */   
/*      */   static final void defaultUncaughtException(Thread t, Throwable e) {
/* 1271 */     LOGGER.error("Scheduler worker in group " + t.getThreadGroup().getName() + " failed with an uncaught exception", e);
/*      */   }
/*      */ 
/*      */   
/*      */   static void handleError(Throwable ex) {
/* 1276 */     Thread thread = Thread.currentThread();
/* 1277 */     Throwable t = Exceptions.unwrap(ex);
/* 1278 */     Thread.UncaughtExceptionHandler x = thread.getUncaughtExceptionHandler();
/* 1279 */     if (x != null) {
/* 1280 */       x.uncaughtException(thread, t);
/*      */     } else {
/*      */       
/* 1283 */       LOGGER.error("Scheduler worker failed with an uncaught exception", t);
/*      */     } 
/* 1285 */     BiConsumer<Thread, ? super Throwable> hook = onHandleErrorHook;
/* 1286 */     if (hook != null)
/* 1287 */       hook.accept(thread, t); 
/*      */   }
/*      */   
/*      */   static class CachedScheduler
/*      */     implements Scheduler, Supplier<Scheduler>, Scannable
/*      */   {
/*      */     final Scheduler cached;
/*      */     final String stringRepresentation;
/*      */     
/*      */     CachedScheduler(String key, Scheduler cached) {
/* 1297 */       this.cached = cached;
/* 1298 */       this.stringRepresentation = "Schedulers." + key + "()";
/*      */     }
/*      */ 
/*      */     
/*      */     public Disposable schedule(Runnable task) {
/* 1303 */       return this.cached.schedule(task);
/*      */     }
/*      */ 
/*      */     
/*      */     public Disposable schedule(Runnable task, long delay, TimeUnit unit) {
/* 1308 */       return this.cached.schedule(task, delay, unit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Disposable schedulePeriodically(Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 1316 */       return this.cached.schedulePeriodically(task, initialDelay, period, unit);
/*      */     }
/*      */ 
/*      */     
/*      */     public Scheduler.Worker createWorker() {
/* 1321 */       return this.cached.createWorker();
/*      */     }
/*      */ 
/*      */     
/*      */     public long now(TimeUnit unit) {
/* 1326 */       return this.cached.now(unit);
/*      */     }
/*      */ 
/*      */     
/*      */     public void start() {
/* 1331 */       this.cached.start();
/*      */     }
/*      */ 
/*      */     
/*      */     public void init() {
/* 1336 */       this.cached.init();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void dispose() {}
/*      */ 
/*      */     
/*      */     public boolean isDisposed() {
/* 1345 */       return this.cached.isDisposed();
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1350 */       return this.stringRepresentation;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object scanUnsafe(Scannable.Attr key) {
/* 1355 */       if (Scannable.Attr.NAME == key) return this.stringRepresentation; 
/* 1356 */       return Scannable.from(this.cached).scanUnsafe(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Scheduler get() {
/* 1367 */       return this.cached;
/*      */     }
/*      */     
/*      */     void _dispose() {
/* 1371 */       this.cached.dispose();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Disposable directSchedule(ScheduledExecutorService exec, Runnable task, @Nullable Disposable parent, long delay, TimeUnit unit) {
/*      */     Future<?> f;
/* 1380 */     task = onSchedule(task);
/* 1381 */     SchedulerTask sr = new SchedulerTask(task, parent);
/*      */     
/* 1383 */     if (delay <= 0L) {
/* 1384 */       f = exec.submit(sr);
/*      */     } else {
/*      */       
/* 1387 */       f = exec.schedule(sr, delay, unit);
/*      */     } 
/* 1389 */     sr.setFuture(f);
/*      */     
/* 1391 */     return sr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Disposable directSchedulePeriodically(ScheduledExecutorService exec, Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 1399 */     task = onSchedule(task);
/*      */     
/* 1401 */     if (period <= 0L) {
/* 1402 */       Future<?> future; InstantPeriodicWorkerTask isr = new InstantPeriodicWorkerTask(task, exec);
/*      */ 
/*      */       
/* 1405 */       if (initialDelay <= 0L) {
/* 1406 */         future = exec.submit(isr);
/*      */       } else {
/*      */         
/* 1409 */         future = exec.schedule(isr, initialDelay, unit);
/*      */       } 
/* 1411 */       isr.setFirst(future);
/*      */       
/* 1413 */       return isr;
/*      */     } 
/*      */     
/* 1416 */     PeriodicSchedulerTask sr = new PeriodicSchedulerTask(task);
/* 1417 */     Future<?> f = exec.scheduleAtFixedRate(sr, initialDelay, period, unit);
/* 1418 */     sr.setFuture(f);
/*      */     
/* 1420 */     return sr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Disposable workerSchedule(ScheduledExecutorService exec, Disposable.Composite tasks, Runnable task, long delay, TimeUnit unit) {
/* 1429 */     task = onSchedule(task);
/*      */     
/* 1431 */     WorkerTask sr = new WorkerTask(task, tasks);
/* 1432 */     if (!tasks.add(sr)) {
/* 1433 */       throw Exceptions.failWithRejected();
/*      */     }
/*      */     
/*      */     try {
/*      */       Future<?> f;
/* 1438 */       if (delay <= 0L) {
/* 1439 */         f = exec.submit(sr);
/*      */       } else {
/*      */         
/* 1442 */         f = exec.schedule(sr, delay, unit);
/*      */       } 
/* 1444 */       sr.setFuture(f);
/*      */     }
/* 1446 */     catch (RejectedExecutionException ex) {
/* 1447 */       sr.dispose();
/*      */       
/* 1449 */       throw ex;
/*      */     } 
/*      */     
/* 1452 */     return sr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Disposable workerSchedulePeriodically(ScheduledExecutorService exec, Disposable.Composite tasks, Runnable task, long initialDelay, long period, TimeUnit unit) {
/* 1461 */     task = onSchedule(task);
/*      */     
/* 1463 */     if (period <= 0L) {
/* 1464 */       InstantPeriodicWorkerTask isr = new InstantPeriodicWorkerTask(task, exec, tasks);
/*      */       
/* 1466 */       if (!tasks.add(isr)) {
/* 1467 */         throw Exceptions.failWithRejected();
/*      */       }
/*      */       try {
/*      */         Future<?> f;
/* 1471 */         if (initialDelay <= 0L) {
/* 1472 */           f = exec.submit(isr);
/*      */         } else {
/*      */           
/* 1475 */           f = exec.schedule(isr, initialDelay, unit);
/*      */         } 
/* 1477 */         isr.setFirst(f);
/*      */       }
/* 1479 */       catch (RejectedExecutionException ex) {
/* 1480 */         isr.dispose();
/*      */         
/* 1482 */         throw ex;
/*      */       }
/* 1484 */       catch (IllegalArgumentException|NullPointerException ex) {
/* 1485 */         isr.dispose();
/*      */         
/* 1487 */         throw new RejectedExecutionException(ex);
/*      */       } 
/*      */       
/* 1490 */       return isr;
/*      */     } 
/*      */     
/* 1493 */     PeriodicWorkerTask sr = new PeriodicWorkerTask(task, tasks);
/* 1494 */     if (!tasks.add(sr)) {
/* 1495 */       throw Exceptions.failWithRejected();
/*      */     }
/*      */     
/*      */     try {
/* 1499 */       Future<?> f = exec.scheduleAtFixedRate(sr, initialDelay, period, unit);
/* 1500 */       sr.setFuture(f);
/*      */     }
/* 1502 */     catch (RejectedExecutionException ex) {
/* 1503 */       sr.dispose();
/*      */       
/* 1505 */       throw ex;
/*      */     }
/* 1507 */     catch (IllegalArgumentException|NullPointerException ex) {
/* 1508 */       sr.dispose();
/*      */       
/* 1510 */       throw new RejectedExecutionException(ex);
/*      */     } 
/*      */     
/* 1513 */     return sr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   static final Object scanExecutor(Executor executor, Scannable.Attr key) {
/* 1532 */     if (executor instanceof DelegateServiceScheduler.UnsupportedScheduledExecutorService) {
/* 1533 */       executor = ((DelegateServiceScheduler.UnsupportedScheduledExecutorService)executor).get();
/*      */     }
/* 1535 */     if (executor instanceof Scannable) {
/* 1536 */       return ((Scannable)executor).scanUnsafe(key);
/*      */     }
/*      */     
/* 1539 */     if (executor instanceof ExecutorService) {
/* 1540 */       ExecutorService service = (ExecutorService)executor;
/* 1541 */       if (key == Scannable.Attr.TERMINATED) return Boolean.valueOf(service.isTerminated()); 
/* 1542 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(service.isShutdown());
/*      */     
/*      */     } 
/* 1545 */     if (executor instanceof ThreadPoolExecutor) {
/* 1546 */       ThreadPoolExecutor poolExecutor = (ThreadPoolExecutor)executor;
/* 1547 */       if (key == Scannable.Attr.CAPACITY) return Integer.valueOf(poolExecutor.getMaximumPoolSize()); 
/* 1548 */       if (key == Scannable.Attr.BUFFERED) return Integer.valueOf(Long.valueOf(poolExecutor.getTaskCount() - poolExecutor.getCompletedTaskCount()).intValue()); 
/* 1549 */       if (key == Scannable.Attr.LARGE_BUFFERED) return Long.valueOf(poolExecutor.getTaskCount() - poolExecutor.getCompletedTaskCount());
/*      */     
/*      */     } 
/* 1552 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\scheduler\Schedulers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */