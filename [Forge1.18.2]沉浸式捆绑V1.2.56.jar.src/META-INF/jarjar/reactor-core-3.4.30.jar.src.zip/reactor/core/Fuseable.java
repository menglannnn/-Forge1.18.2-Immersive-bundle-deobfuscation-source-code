/*     */ package reactor.core;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Fuseable
/*     */ {
/*     */   public static final int NONE = 0;
/*     */   public static final int SYNC = 1;
/*     */   public static final int ASYNC = 2;
/*     */   public static final int ANY = 3;
/*     */   public static final int THREAD_BARRIER = 4;
/*     */   
/*     */   static String fusionModeName(int mode) {
/*  69 */     return fusionModeName(mode, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String fusionModeName(int mode, boolean ignoreThreadBarrier) {
/*  90 */     int evaluated = mode;
/*  91 */     String threadBarrierSuffix = "";
/*  92 */     if (mode >= 0) {
/*  93 */       evaluated = mode & 0xFFFFFFFB;
/*  94 */       if (!ignoreThreadBarrier && (mode & 0x4) == 4) {
/*  95 */         threadBarrierSuffix = "+THREAD_BARRIER";
/*     */       }
/*     */     } 
/*     */     
/*  99 */     switch (evaluated) {
/*     */       case -1:
/* 101 */         return "Disabled";
/*     */       case 0:
/* 103 */         return "NONE" + threadBarrierSuffix;
/*     */       case 1:
/* 105 */         return "SYNC" + threadBarrierSuffix;
/*     */       case 2:
/* 107 */         return "ASYNC" + threadBarrierSuffix;
/*     */     } 
/* 109 */     return "Unknown(" + evaluated + ")" + threadBarrierSuffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface ConditionalSubscriber<T>
/*     */     extends CoreSubscriber<T>
/*     */   {
/*     */     boolean tryOnNext(T param1T);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface QueueSubscription<T>
/*     */     extends Queue<T>, Subscription
/*     */   {
/*     */     public static final String NOT_SUPPORTED_MESSAGE = "Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int requestFusion(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     default T peek() {
/* 176 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default boolean add(@Nullable T t) {
/* 181 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default boolean offer(@Nullable T t) {
/* 186 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default T remove() {
/* 191 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default T element() {
/* 196 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default boolean contains(@Nullable Object o) {
/* 201 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default Iterator<T> iterator() {
/* 206 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default Object[] toArray() {
/* 211 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default <T1> T1[] toArray(T1[] a) {
/* 216 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default boolean remove(@Nullable Object o) {
/* 221 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default boolean containsAll(Collection<?> c) {
/* 226 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default boolean addAll(Collection<? extends T> c) {
/* 231 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default boolean removeAll(Collection<?> c) {
/* 236 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */ 
/*     */     
/*     */     default boolean retainAll(Collection<?> c) {
/* 241 */       throw new UnsupportedOperationException("Although QueueSubscription extends Queue it is purely internal and only guarantees support for poll/clear/size/isEmpty. Instances shouldn't be used/exposed as Queue outside of Reactor operators.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface SynchronousSubscription<T>
/*     */     extends QueueSubscription<T>
/*     */   {
/*     */     default int requestFusion(int requestedMode) {
/* 256 */       if ((requestedMode & 0x1) != 0) {
/* 257 */         return 1;
/*     */       }
/* 259 */       return 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface ScalarCallable<T> extends Callable<T> {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\core\Fuseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */