/*     */ package reactor.adapter;
/*     */ 
/*     */ import java.util.concurrent.Flow;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JdkFlowAdapter
/*     */ {
/*     */   public static <T> Flow.Publisher<T> publisherToFlowPublisher(Publisher<T> publisher) {
/*  45 */     return new PublisherAsFlowPublisher<>(publisher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Flux<T> flowPublisherToFlux(Flow.Publisher<T> publisher) {
/*  56 */     return new FlowPublisherAsFlux<>(publisher);
/*     */   }
/*     */   
/*     */   private static class FlowPublisherAsFlux<T> extends Flux<T> implements Scannable {
/*     */     private final Flow.Publisher<T> pub;
/*     */     
/*     */     private FlowPublisherAsFlux(Flow.Publisher<T> pub) {
/*  63 */       this.pub = pub;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super T> actual) {
/*  68 */       this.pub.subscribe(new JdkFlowAdapter.SubscriberToRS<>((Subscriber<? super T>)actual));
/*     */     }
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/*  73 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PublisherAsFlowPublisher<T> implements Flow.Publisher<T> {
/*     */     private final Publisher<T> pub;
/*     */     
/*     */     private PublisherAsFlowPublisher(Publisher<T> pub) {
/*  81 */       this.pub = pub;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(Flow.Subscriber<? super T> subscriber) {
/*  86 */       this.pub.subscribe((Subscriber)new JdkFlowAdapter.FlowSubscriber<>(subscriber));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FlowSubscriber<T>
/*     */     implements CoreSubscriber<T>, Flow.Subscription
/*     */   {
/*     */     private final Flow.Subscriber<? super T> subscriber;
/*     */     Subscription subscription;
/*     */     
/*     */     public FlowSubscriber(Flow.Subscriber<? super T> subscriber) {
/*  97 */       this.subscriber = subscriber;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 102 */       this.subscription = s;
/* 103 */       this.subscriber.onSubscribe(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T o) {
/* 108 */       this.subscriber.onNext(o);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 113 */       this.subscriber.onError(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 118 */       this.subscriber.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 123 */       this.subscription.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 128 */       this.subscription.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SubscriberToRS<T>
/*     */     implements Flow.Subscriber<T>, Subscription
/*     */   {
/*     */     private final Subscriber<? super T> s;
/*     */     Flow.Subscription subscription;
/*     */     
/*     */     public SubscriberToRS(Subscriber<? super T> s) {
/* 139 */       this.s = s;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Flow.Subscription subscription) {
/* 144 */       this.subscription = subscription;
/* 145 */       this.s.onSubscribe(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T o) {
/* 150 */       this.s.onNext(o);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 155 */       this.s.onError(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 160 */       this.s.onComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 165 */       this.subscription.request(n);
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 170 */       this.subscription.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-core-3.4.30.jar!\reactor\adapter\JdkFlowAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */