/*     */ package reactor.netty.udp;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFactory;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.socket.nio.NioDatagramChannel;
/*     */ import io.netty.channel.unix.DomainDatagramChannel;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.channel.MicrometerChannelMetricsRecorder;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.ClientTransportConfig;
/*     */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UdpClientConfig
/*     */   extends ClientTransportConfig<UdpClientConfig>
/*     */ {
/*     */   InternetProtocolFamily family;
/*     */   static final ChannelOperations.OnSetup DEFAULT_OPS;
/*     */   
/*     */   public final ChannelOperations.OnSetup channelOperationsProvider() {
/*  53 */     return DEFAULT_OPS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final InternetProtocolFamily family() {
/*  63 */     return this.family;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   UdpClientConfig(ConnectionProvider connectionProvider, Map<ChannelOption<?>, ?> options, Supplier<? extends SocketAddress> remoteAddress) {
/*  73 */     super(connectionProvider, options, remoteAddress);
/*     */   }
/*     */   
/*     */   UdpClientConfig(UdpClientConfig parent) {
/*  77 */     super(parent);
/*  78 */     this.family = parent.family;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<? extends Channel> channelType(boolean isDomainSocket) {
/*  83 */     return isDomainSocket ? (Class)DomainDatagramChannel.class : (Class)DatagramChannel.class;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelFactory<? extends Channel> connectionFactory(EventLoopGroup elg, boolean isDomainSocket) {
/*  88 */     if (isPreferNative()) {
/*  89 */       return super.connectionFactory(elg, isDomainSocket);
/*     */     }
/*     */     
/*  92 */     return () -> new NioDatagramChannel(family());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AddressResolverGroup<?> defaultAddressResolverGroup() {
/* 105 */     return UdpResources.get().getOrCreateDefaultResolver();
/*     */   }
/*     */ 
/*     */   
/*     */   protected LoggingHandler defaultLoggingHandler() {
/* 110 */     return LOGGING_HANDLER;
/*     */   }
/*     */ 
/*     */   
/*     */   protected LoopResources defaultLoopResources() {
/* 115 */     return UdpResources.get();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelMetricsRecorder defaultMetricsRecorder() {
/* 120 */     return (ChannelMetricsRecorder)MicrometerUdpClientMetricsRecorder.INSTANCE;
/*     */   }
/*     */   static {
/* 123 */     DEFAULT_OPS = ((ch, c, msg) -> new UdpOperations(ch, c));
/*     */   }
/* 125 */   static final LoggingHandler LOGGING_HANDLER = AdvancedByteBufFormat.HEX_DUMP
/*     */     
/* 127 */     .toLoggingHandler(UdpClient.class.getName(), LogLevel.DEBUG, Charset.defaultCharset());
/*     */   
/*     */   static final class MicrometerUdpClientMetricsRecorder
/*     */     extends MicrometerChannelMetricsRecorder {
/* 131 */     static final MicrometerUdpClientMetricsRecorder INSTANCE = new MicrometerUdpClientMetricsRecorder();
/*     */     
/*     */     MicrometerUdpClientMetricsRecorder() {
/* 134 */       super("reactor.netty.udp.client", "udp");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpClientConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */