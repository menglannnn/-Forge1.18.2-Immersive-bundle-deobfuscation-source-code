/*    */ package reactor.netty.udp;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.NetworkInterface;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface UdpConnection
/*    */ {
/*    */   default Mono<Void> join(InetAddress multicastAddress) {
/* 38 */     return join(multicastAddress, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Mono<Void> join(InetAddress paramInetAddress, @Nullable NetworkInterface paramNetworkInterface);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Mono<Void> leave(InetAddress multicastAddress) {
/* 60 */     return leave(multicastAddress, null);
/*    */   }
/*    */   
/*    */   Mono<Void> leave(InetAddress paramInetAddress, @Nullable NetworkInterface paramNetworkInterface);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */