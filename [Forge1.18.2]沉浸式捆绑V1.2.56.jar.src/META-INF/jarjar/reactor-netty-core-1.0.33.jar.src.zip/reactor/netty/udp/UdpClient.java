/*     */ package reactor.netty.udp;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.ClientTransport;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UdpClient
/*     */   extends ClientTransport<UdpClient, UdpClientConfig>
/*     */ {
/*     */   public static UdpClient create() {
/*  72 */     return UdpClientConnect.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public final <A> UdpClient attr(AttributeKey<A> key, @Nullable A value) {
/*  77 */     return (UdpClient)super.attr(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient bindAddress(Supplier<? extends SocketAddress> bindAddressSupplier) {
/*  82 */     return (UdpClient)super.bindAddress(bindAddressSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<? extends Connection> connect() {
/*  87 */     return super.connect();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Connection connectNow() {
/*  92 */     return super.connectNow();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Connection connectNow(Duration timeout) {
/*  97 */     return super.connectNow(timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient doOnConnect(Consumer<? super UdpClientConfig> doOnConnect) {
/* 102 */     return (UdpClient)super.doOnConnect(doOnConnect);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient doOnConnected(Consumer<? super Connection> doOnConnected) {
/* 107 */     return (UdpClient)super.doOnConnected(doOnConnected);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient doOnDisconnected(Consumer<? super Connection> doOnDisconnected) {
/* 112 */     return (UdpClient)super.doOnDisconnected(doOnDisconnected);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpClient handle(BiFunction<? super UdpInbound, ? super UdpOutbound, ? extends Publisher<Void>> handler) {
/* 124 */     Objects.requireNonNull(handler, "handler");
/* 125 */     return doOnConnected(new OnConnectedHandle(handler));
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient host(String host) {
/* 130 */     return (UdpClient)super.host(host);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient metrics(boolean enable) {
/* 135 */     return (UdpClient)super.metrics(enable);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/* 140 */     return (UdpClient)super.metrics(enable, recorder);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient observe(ConnectionObserver observer) {
/* 145 */     return (UdpClient)super.observe(observer);
/*     */   }
/*     */ 
/*     */   
/*     */   public final <O> UdpClient option(ChannelOption<O> key, @Nullable O value) {
/* 150 */     return (UdpClient)super.option(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient port(int port) {
/* 155 */     return (UdpClient)super.port(port);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient remoteAddress(Supplier<? extends SocketAddress> remoteAddressSupplier) {
/* 160 */     return (UdpClient)super.remoteAddress(remoteAddressSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient runOn(EventLoopGroup eventLoopGroup) {
/* 165 */     return (UdpClient)super.runOn(eventLoopGroup);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient runOn(LoopResources channelResources) {
/* 170 */     return (UdpClient)super.runOn(channelResources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpClient runOn(LoopResources loopResources, boolean preferNative) {
/* 182 */     Objects.requireNonNull(loopResources, "loopResources");
/* 183 */     UdpClient dup = (UdpClient)super.runOn(loopResources, preferNative);
/* 184 */     ((UdpClientConfig)dup.configuration()).family = null;
/* 185 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpClient runOn(LoopResources loopResources, InternetProtocolFamily family) {
/* 196 */     Objects.requireNonNull(loopResources, "loopResources");
/* 197 */     Objects.requireNonNull(family, "family");
/* 198 */     UdpClient dup = (UdpClient)super.runOn(loopResources, false);
/* 199 */     ((UdpClientConfig)dup.configuration()).family = family;
/* 200 */     return dup;
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient wiretap(boolean enable) {
/* 205 */     return (UdpClient)super.wiretap(enable);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient wiretap(String category) {
/* 210 */     return (UdpClient)super.wiretap(category);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpClient wiretap(String category, LogLevel level) {
/* 215 */     return (UdpClient)super.wiretap(category, level);
/*     */   }
/*     */   
/* 218 */   static final Logger log = Loggers.getLogger(UdpClient.class);
/*     */   
/*     */   static final class OnConnectedHandle
/*     */     implements Consumer<Connection> {
/*     */     final BiFunction<? super UdpInbound, ? super UdpOutbound, ? extends Publisher<Void>> handler;
/*     */     
/*     */     OnConnectedHandle(BiFunction<? super UdpInbound, ? super UdpOutbound, ? extends Publisher<Void>> handler) {
/* 225 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Connection c) {
/* 230 */       if (UdpClient.log.isDebugEnabled()) {
/* 231 */         UdpClient.log.debug(ReactorNetty.format(c.channel(), "Handler is being applied: {}"), new Object[] { this.handler });
/*     */       }
/*     */       
/* 234 */       Mono.fromDirect(this.handler.apply((UdpInbound)c, (UdpOutbound)c))
/* 235 */         .subscribe(c.disposeSubscriber());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */