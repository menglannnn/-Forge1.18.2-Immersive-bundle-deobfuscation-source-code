/*    */ package reactor.netty.udp;
/*    */ 
/*    */ import io.netty.channel.ChannelOption;
/*    */ import io.netty.util.NetUtil;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.Collections;
/*    */ import org.reactivestreams.Subscription;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty.Connection;
/*    */ import reactor.netty.ConnectionObserver;
/*    */ import reactor.netty.resources.ConnectionProvider;
/*    */ import reactor.netty.transport.Transport;
/*    */ import reactor.netty.transport.TransportConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class UdpServerBind
/*    */   extends UdpServer
/*    */ {
/* 36 */   static final UdpServerBind INSTANCE = new UdpServerBind();
/*    */   
/*    */   final UdpServerConfig config;
/*    */   
/*    */   UdpServerBind() {
/* 41 */     this
/* 42 */       .config = new UdpServerConfig(Collections.singletonMap(ChannelOption.AUTO_READ, Boolean.valueOf(false)), () -> new InetSocketAddress(NetUtil.LOCALHOST, DEFAULT_PORT));
/*    */   }
/*    */ 
/*    */   
/*    */   UdpServerBind(UdpServerConfig config) {
/* 47 */     this.config = config;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<? extends Connection> bind() {
/* 52 */     UdpServerConfig conf = configuration();
/*    */     
/* 54 */     ConnectionObserver observer = this.config.defaultConnectionObserver().then(this.config.connectionObserver());
/*    */ 
/*    */     
/* 57 */     Mono<? extends Connection> mono = ConnectionProvider.newConnection().acquire(conf, observer, null, null);
/* 58 */     if (conf.doOnBind() != null) {
/* 59 */       mono = mono.doOnSubscribe(s -> conf.doOnBind().accept(conf));
/*    */     }
/* 61 */     return mono;
/*    */   }
/*    */ 
/*    */   
/*    */   public UdpServerConfig configuration() {
/* 66 */     return this.config;
/*    */   }
/*    */ 
/*    */   
/*    */   protected UdpServer duplicate() {
/* 71 */     return new UdpServerBind(new UdpServerConfig(this.config));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 78 */   static final int DEFAULT_PORT = (System.getenv("PORT") != null) ? Integer.parseInt(System.getenv("PORT")) : 12012;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpServerBind.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */