/*     */ package reactor.netty.udp;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.resolver.dns.DnsAddressResolverGroup;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.NameResolverProvider;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UdpResources
/*     */   implements LoopResources
/*     */ {
/*     */   final LoopResources defaultLoops;
/*     */   final AtomicReference<AddressResolverGroup<?>> defaultResolver;
/*     */   
/*     */   public static UdpResources get() {
/*  49 */     return getOrCreate(null, ON_UDP_NEW, "udp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UdpResources reset() {
/*  58 */     shutdown();
/*  59 */     return getOrCreate(null, ON_UDP_NEW, "udp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UdpResources set(LoopResources loops) {
/*  70 */     return getOrCreate(loops, ON_UDP_NEW, "udp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown() {
/*  82 */     UdpResources resources = udpResources.getAndSet(null);
/*  83 */     if (resources != null) {
/*  84 */       resources._dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> shutdownLater() {
/*  97 */     return shutdownLater(Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_QUIET_PERIOD), 
/*  98 */         Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_TIMEOUT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> shutdownLater(Duration quietPeriod, Duration timeout) {
/* 116 */     Objects.requireNonNull(quietPeriod, "quietPeriod");
/* 117 */     Objects.requireNonNull(timeout, "timeout");
/* 118 */     return Mono.defer(() -> {
/*     */           UdpResources resources = udpResources.getAndSet(null);
/*     */           return (resources != null) ? resources._disposeLater(quietPeriod, timeout) : Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UdpResources(LoopResources defaultLoops) {
/* 131 */     this.defaultLoops = defaultLoops;
/* 132 */     this.defaultResolver = new AtomicReference<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean daemon() {
/* 137 */     return this.defaultLoops.daemon();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeLater() {
/* 158 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeLater(Duration quietPeriod, Duration timeout) {
/* 170 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 175 */     return this.defaultLoops.isDisposed();
/*     */   }
/*     */ 
/*     */   
/*     */   public <CHANNEL extends io.netty.channel.Channel> CHANNEL onChannel(Class<CHANNEL> channelType, EventLoopGroup group) {
/* 180 */     Objects.requireNonNull(channelType, "channelType");
/* 181 */     Objects.requireNonNull(group, "group");
/* 182 */     return (CHANNEL)this.defaultLoops.onChannel(channelType, group);
/*     */   }
/*     */ 
/*     */   
/*     */   public <CHANNEL extends io.netty.channel.Channel> Class<? extends CHANNEL> onChannelClass(Class<CHANNEL> channelType, EventLoopGroup group) {
/* 187 */     Objects.requireNonNull(channelType, "channelType");
/* 188 */     Objects.requireNonNull(group, "group");
/* 189 */     return this.defaultLoops.onChannelClass(channelType, group);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onClient(boolean useNative) {
/* 194 */     return this.defaultLoops.onClient(useNative);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onServer(boolean useNative) {
/* 199 */     return this.defaultLoops.onServer(useNative);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onServerSelect(boolean useNative) {
/* 204 */     return this.defaultLoops.onServerSelect(useNative);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _dispose() {
/* 211 */     _disposeResolver();
/* 212 */     this.defaultLoops.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> _disposeLater(Duration quietPeriod, Duration timeout) {
/* 227 */     return Mono.when(new Publisher[] { (Publisher)_disposeResolverLater(), (Publisher)this.defaultLoops.disposeLater(quietPeriod, timeout) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AddressResolverGroup<?> getOrCreateDefaultResolver() {
/* 239 */     AddressResolverGroup<?> resolverGroup = this.defaultResolver.get();
/* 240 */     if (resolverGroup == null) {
/*     */       
/* 242 */       DnsAddressResolverGroup dnsAddressResolverGroup = DEFAULT_NAME_RESOLVER_PROVIDER.newNameResolverGroup(this.defaultLoops, LoopResources.DEFAULT_NATIVE);
/* 243 */       if (!this.defaultResolver.compareAndSet(null, dnsAddressResolverGroup)) {
/* 244 */         dnsAddressResolverGroup.close();
/*     */       }
/* 246 */       resolverGroup = getOrCreateDefaultResolver();
/*     */     } 
/* 248 */     return resolverGroup;
/*     */   }
/*     */   
/*     */   void _disposeResolver() {
/* 252 */     AddressResolverGroup<?> addressResolverGroup = this.defaultResolver.get();
/* 253 */     if (addressResolverGroup != null) {
/* 254 */       addressResolverGroup.close();
/*     */     }
/*     */   }
/*     */   
/*     */   Mono<Void> _disposeResolverLater() {
/* 259 */     Mono<Void> disposeResolver = Mono.empty();
/* 260 */     AddressResolverGroup<?> addressResolverGroup = this.defaultResolver.get();
/* 261 */     if (addressResolverGroup != null) {
/* 262 */       Objects.requireNonNull(addressResolverGroup); disposeResolver = Mono.fromRunnable(addressResolverGroup::close);
/*     */     } 
/* 264 */     return disposeResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static UdpResources getOrCreate(@Nullable LoopResources loops, Function<LoopResources, UdpResources> onNew, String name) {
/*     */     UdpResources resources;
/*     */     while (true) {
/* 280 */       resources = udpResources.get();
/* 281 */       if (resources == null || loops != null) {
/* 282 */         UdpResources update = create(resources, loops, name, onNew);
/* 283 */         if (udpResources.compareAndSet(resources, update)) {
/* 284 */           if (resources != null) {
/* 285 */             if (log.isWarnEnabled()) {
/* 286 */               log.warn("[{}] resources will use a new LoopResources: {},the previous LoopResources will be disposed", new Object[] { name, loops });
/*     */             }
/*     */             
/* 289 */             resources._disposeResolver();
/* 290 */             resources.defaultLoops.dispose();
/*     */           } else {
/*     */             
/* 293 */             String loopType = (loops == null) ? "default" : "provided";
/* 294 */             if (log.isDebugEnabled()) {
/* 295 */               log.debug("[{}] resources will use the {} LoopResources: {}", new Object[] { name, loopType, update.defaultLoops });
/*     */             }
/*     */           } 
/* 298 */           return update;
/*     */         } 
/*     */         
/* 301 */         update._dispose(); continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 305 */     return resources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends UdpResources> T create(@Nullable T previous, @Nullable LoopResources loops, String name, Function<LoopResources, T> onNew) {
/* 314 */     if (previous == null) {
/* 315 */       loops = (loops == null) ? LoopResources.create(name, DEFAULT_UDP_THREAD_COUNT, true) : loops;
/*     */     } else {
/*     */       
/* 318 */       loops = (loops == null) ? ((UdpResources)previous).defaultLoops : loops;
/*     */     } 
/* 320 */     return onNew.apply(loops);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 327 */   static final int DEFAULT_UDP_THREAD_COUNT = Integer.parseInt(System.getProperty("reactor.netty.udp.ioThreadCount", "" + Schedulers.DEFAULT_POOL_SIZE));
/*     */ 
/*     */   
/*     */   static final NameResolverProvider DEFAULT_NAME_RESOLVER_PROVIDER;
/*     */ 
/*     */   
/* 333 */   static final Logger log = Loggers.getLogger(UdpResources.class);
/*     */   
/*     */   static final Function<LoopResources, UdpResources> ON_UDP_NEW;
/*     */   
/*     */   static final AtomicReference<UdpResources> udpResources;
/*     */   
/*     */   static {
/* 340 */     DEFAULT_NAME_RESOLVER_PROVIDER = NameResolverProvider.builder().build();
/* 341 */     ON_UDP_NEW = UdpResources::new;
/* 342 */     udpResources = new AtomicReference<>();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */