/*    */ package reactor.netty.udp;
/*    */ 
/*    */ import io.netty.channel.ChannelOption;
/*    */ import io.netty.util.NetUtil;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.Collections;
/*    */ import reactor.netty.resources.ConnectionProvider;
/*    */ import reactor.netty.transport.Transport;
/*    */ import reactor.netty.transport.TransportConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class UdpClientConnect
/*    */   extends UdpClient
/*    */ {
/* 33 */   static final UdpClientConnect INSTANCE = new UdpClientConnect();
/*    */   
/*    */   final UdpClientConfig config;
/*    */   
/*    */   UdpClientConnect() {
/* 38 */     this
/*    */       
/* 40 */       .config = new UdpClientConfig(ConnectionProvider.newConnection(), Collections.singletonMap(ChannelOption.AUTO_READ, Boolean.valueOf(false)), () -> new InetSocketAddress(NetUtil.LOCALHOST, DEFAULT_PORT));
/*    */   }
/*    */ 
/*    */   
/*    */   UdpClientConnect(UdpClientConfig config) {
/* 45 */     this.config = config;
/*    */   }
/*    */ 
/*    */   
/*    */   public UdpClientConfig configuration() {
/* 50 */     return this.config;
/*    */   }
/*    */ 
/*    */   
/*    */   protected UdpClient duplicate() {
/* 55 */     return new UdpClientConnect(new UdpClientConfig(this.config));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   static final int DEFAULT_PORT = (System.getenv("PORT") != null) ? Integer.parseInt(System.getenv("PORT")) : 12012;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpClientConnect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */