/*     */ package reactor.netty.udp;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.AddressUtils;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UdpServer
/*     */   extends Transport<UdpServer, UdpServerConfig>
/*     */ {
/*     */   public static UdpServer create() {
/*  73 */     return UdpServerBind.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public final <A> UdpServer attr(AttributeKey<A> key, @Nullable A value) {
/*  78 */     return (UdpServer)super.attr(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer bindAddress(Supplier<? extends SocketAddress> bindAddressSupplier) {
/*  93 */     return (UdpServer)super.bindAddress(bindAddressSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Connection bindNow() {
/* 105 */     return bindNow(Duration.ofSeconds(45L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Connection bindNow(Duration timeout) {
/* 118 */     Objects.requireNonNull(timeout, "timeout");
/*     */     try {
/* 120 */       return Objects.<Connection>requireNonNull((Connection)bind().block(timeout), "aborted");
/*     */     }
/* 122 */     catch (IllegalStateException e) {
/* 123 */       if (e.getMessage().contains("blocking read")) {
/* 124 */         throw new IllegalStateException("UdpServer couldn't be started within " + timeout.toMillis() + "ms");
/*     */       }
/* 126 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer doOnBind(Consumer<? super UdpServerConfig> doOnBind) {
/* 137 */     Objects.requireNonNull(doOnBind, "doOnBind");
/* 138 */     UdpServer dup = (UdpServer)duplicate();
/*     */     
/* 140 */     Consumer<? super UdpServerConfig> consumer = ((UdpServerConfig)dup.configuration()).doOnBind;
/* 141 */     ((UdpServerConfig)dup.configuration()).doOnBind = (consumer == null) ? doOnBind : consumer.andThen(doOnBind);
/* 142 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer doOnBound(Consumer<? super Connection> doOnBound) {
/* 152 */     Objects.requireNonNull(doOnBound, "doOnBound");
/* 153 */     UdpServer dup = (UdpServer)duplicate();
/*     */     
/* 155 */     Consumer<? super Connection> consumer = ((UdpServerConfig)dup.configuration()).doOnBound;
/* 156 */     ((UdpServerConfig)dup.configuration()).doOnBound = (consumer == null) ? doOnBound : consumer.andThen(doOnBound);
/* 157 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer doOnUnbound(Consumer<? super Connection> doOnUnbound) {
/* 167 */     Objects.requireNonNull(doOnUnbound, "doOnUnbound");
/* 168 */     UdpServer dup = (UdpServer)duplicate();
/*     */     
/* 170 */     Consumer<? super Connection> consumer = ((UdpServerConfig)dup.configuration()).doOnUnbound;
/* 171 */     ((UdpServerConfig)dup.configuration()).doOnUnbound = (consumer == null) ? doOnUnbound : consumer.andThen(doOnUnbound);
/* 172 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer handle(BiFunction<? super UdpInbound, ? super UdpOutbound, ? extends Publisher<Void>> handler) {
/* 184 */     Objects.requireNonNull(handler, "handler");
/* 185 */     return doOnBound(new OnBoundHandle(handler));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer host(String host) {
/* 195 */     return bindAddress(() -> AddressUtils.updateHost(((UdpServerConfig)configuration()).bindAddress(), host));
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpServer metrics(boolean enable) {
/* 200 */     return (UdpServer)super.metrics(enable);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpServer metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/* 205 */     return (UdpServer)super.metrics(enable, recorder);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpServer observe(ConnectionObserver observer) {
/* 210 */     return (UdpServer)super.observe(observer);
/*     */   }
/*     */ 
/*     */   
/*     */   public final <O> UdpServer option(ChannelOption<O> key, @Nullable O value) {
/* 215 */     return (UdpServer)super.option(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer port(int port) {
/* 225 */     return bindAddress(() -> AddressUtils.updatePort(((UdpServerConfig)configuration()).bindAddress(), port));
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpServer runOn(EventLoopGroup eventLoopGroup) {
/* 230 */     return (UdpServer)super.runOn(eventLoopGroup);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpServer runOn(LoopResources channelResources) {
/* 235 */     return (UdpServer)super.runOn(channelResources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer runOn(LoopResources loopResources, boolean preferNative) {
/* 247 */     Objects.requireNonNull(loopResources, "loopResources");
/* 248 */     UdpServer dup = (UdpServer)super.runOn(loopResources, preferNative);
/* 249 */     ((UdpServerConfig)dup.configuration()).family = null;
/* 250 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UdpServer runOn(LoopResources loopResources, InternetProtocolFamily family) {
/* 261 */     Objects.requireNonNull(loopResources, "loopResources");
/* 262 */     Objects.requireNonNull(family, "family");
/* 263 */     UdpServer dup = (UdpServer)super.runOn(loopResources, false);
/* 264 */     ((UdpServerConfig)dup.configuration()).family = family;
/* 265 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Void> warmup() {
/* 280 */     return Mono.fromRunnable(() -> ((UdpServerConfig)configuration()).eventLoopGroup());
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpServer wiretap(boolean enable) {
/* 285 */     return (UdpServer)super.wiretap(enable);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpServer wiretap(String category) {
/* 290 */     return (UdpServer)super.wiretap(category);
/*     */   }
/*     */ 
/*     */   
/*     */   public final UdpServer wiretap(String category, LogLevel level) {
/* 295 */     return (UdpServer)super.wiretap(category, level);
/*     */   }
/*     */   
/* 298 */   static final Logger log = Loggers.getLogger(UdpServer.class);
/*     */   
/*     */   public abstract Mono<? extends Connection> bind();
/*     */   
/*     */   static final class OnBoundHandle
/*     */     implements Consumer<Connection> {
/*     */     OnBoundHandle(BiFunction<? super UdpInbound, ? super UdpOutbound, ? extends Publisher<Void>> handler) {
/* 305 */       this.handler = handler;
/*     */     }
/*     */     final BiFunction<? super UdpInbound, ? super UdpOutbound, ? extends Publisher<Void>> handler;
/*     */     
/*     */     public void accept(Connection c) {
/* 310 */       if (UdpServer.log.isDebugEnabled()) {
/* 311 */         UdpServer.log.debug(ReactorNetty.format(c.channel(), "Handler is being applied: {}"), new Object[] { this.handler });
/*     */       }
/*     */       
/* 314 */       Mono.fromDirect(this.handler.apply((UdpInbound)c, (UdpOutbound)c))
/* 315 */         .subscribe(c.disposeSubscriber());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */