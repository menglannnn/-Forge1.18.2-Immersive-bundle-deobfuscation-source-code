/*     */ package reactor.netty.udp;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFactory;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.group.ChannelGroup;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.channel.socket.nio.NioDatagramChannel;
/*     */ import io.netty.channel.unix.DomainDatagramChannel;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.channel.MicrometerChannelMetricsRecorder;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UdpServerConfig
/*     */   extends TransportConfig
/*     */ {
/*     */   Consumer<? super UdpServerConfig> doOnBind;
/*     */   Consumer<? super Connection> doOnBound;
/*     */   Consumer<? super Connection> doOnUnbound;
/*     */   InternetProtocolFamily family;
/*     */   static final ChannelOperations.OnSetup DEFAULT_OPS;
/*     */   
/*     */   public ChannelOperations.OnSetup channelOperationsProvider() {
/*  56 */     return DEFAULT_OPS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super UdpServerConfig> doOnBind() {
/*  66 */     return this.doOnBind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super Connection> doOnBound() {
/*  76 */     return this.doOnBound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super Connection> doOnUnbound() {
/*  86 */     return this.doOnUnbound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final InternetProtocolFamily family() {
/*  96 */     return this.family;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   UdpServerConfig(Map<ChannelOption<?>, ?> options, Supplier<? extends SocketAddress> bindAddress) {
/* 108 */     super(options, bindAddress);
/*     */   }
/*     */   
/*     */   UdpServerConfig(UdpServerConfig parent) {
/* 112 */     super(parent);
/* 113 */     this.doOnBind = parent.doOnBind;
/* 114 */     this.doOnBound = parent.doOnBound;
/* 115 */     this.doOnUnbound = parent.doOnUnbound;
/* 116 */     this.family = parent.family;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<? extends Channel> channelType(boolean isDomainSocket) {
/* 121 */     return isDomainSocket ? (Class)DomainDatagramChannel.class : (Class)DatagramChannel.class;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelFactory<? extends Channel> connectionFactory(EventLoopGroup elg, boolean isDomainSocket) {
/* 126 */     if (isPreferNative()) {
/* 127 */       return super.connectionFactory(elg, isDomainSocket);
/*     */     }
/*     */     
/* 130 */     return () -> new NioDatagramChannel(family());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConnectionObserver defaultConnectionObserver() {
/* 136 */     if (channelGroup() == null && doOnBound() == null && doOnUnbound() == null) {
/* 137 */       return ConnectionObserver.emptyListener();
/*     */     }
/* 139 */     return new UdpServerDoOn(channelGroup(), doOnBound(), doOnUnbound());
/*     */   }
/*     */ 
/*     */   
/*     */   protected LoggingHandler defaultLoggingHandler() {
/* 144 */     return LOGGING_HANDLER;
/*     */   }
/*     */ 
/*     */   
/*     */   protected LoopResources defaultLoopResources() {
/* 149 */     return UdpResources.get();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelMetricsRecorder defaultMetricsRecorder() {
/* 154 */     return (ChannelMetricsRecorder)MicrometerUdpServerMetricsRecorder.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelPipelineConfigurer defaultOnChannelInit() {
/* 159 */     return ChannelPipelineConfigurer.emptyConfigurer();
/*     */   }
/*     */ 
/*     */   
/*     */   protected EventLoopGroup eventLoopGroup() {
/* 164 */     return loopResources().onClient(isPreferNative());
/*     */   }
/*     */   static {
/* 167 */     DEFAULT_OPS = ((ch, c, msg) -> new UdpOperations(ch, c));
/*     */   }
/* 169 */   static final LoggingHandler LOGGING_HANDLER = AdvancedByteBufFormat.HEX_DUMP
/*     */     
/* 171 */     .toLoggingHandler(UdpServer.class.getName(), LogLevel.DEBUG, Charset.defaultCharset());
/*     */   
/*     */   static final class MicrometerUdpServerMetricsRecorder
/*     */     extends MicrometerChannelMetricsRecorder {
/* 175 */     static final MicrometerUdpServerMetricsRecorder INSTANCE = new MicrometerUdpServerMetricsRecorder();
/*     */     
/*     */     MicrometerUdpServerMetricsRecorder() {
/* 178 */       super("reactor.netty.udp.server", "udp");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class UdpServerDoOn
/*     */     implements ConnectionObserver
/*     */   {
/*     */     final ChannelGroup channelGroup;
/*     */     final Consumer<? super Connection> doOnBound;
/*     */     final Consumer<? super Connection> doOnUnbound;
/*     */     
/*     */     UdpServerDoOn(@Nullable ChannelGroup channelGroup, @Nullable Consumer<? super Connection> doOnBound, @Nullable Consumer<? super Connection> doOnUnbound) {
/* 191 */       this.channelGroup = channelGroup;
/* 192 */       this.doOnBound = doOnBound;
/* 193 */       this.doOnUnbound = doOnUnbound;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 198 */       if (this.channelGroup != null && newState == ConnectionObserver.State.CONNECTED) {
/* 199 */         this.channelGroup.add(connection.channel());
/*     */         return;
/*     */       } 
/* 202 */       if (this.doOnBound != null && newState == ConnectionObserver.State.CONFIGURED) {
/* 203 */         this.doOnBound.accept(connection);
/*     */         return;
/*     */       } 
/* 206 */       if (this.doOnUnbound != null && newState == ConnectionObserver.State.DISCONNECTING)
/* 207 */         connection.onDispose(() -> this.doOnUnbound.accept(connection)); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpServerConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */