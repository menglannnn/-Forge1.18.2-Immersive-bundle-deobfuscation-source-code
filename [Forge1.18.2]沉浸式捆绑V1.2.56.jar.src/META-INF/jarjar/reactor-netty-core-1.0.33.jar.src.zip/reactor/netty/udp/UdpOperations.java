/*     */ package reactor.netty.udp;
/*     */ 
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.FutureMono;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UdpOperations
/*     */   extends ChannelOperations<UdpInbound, UdpOutbound>
/*     */   implements UdpInbound, UdpOutbound
/*     */ {
/*     */   UdpOperations(Connection c, ConnectionObserver listener) {
/*  43 */     super(c, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> join(InetAddress multicastAddress, @Nullable NetworkInterface iface) {
/*     */     ChannelFuture future;
/*  55 */     if (!(connection().channel() instanceof DatagramChannel)) {
/*  56 */       throw new UnsupportedOperationException();
/*     */     }
/*  58 */     DatagramChannel datagramChannel = (DatagramChannel)connection().channel();
/*  59 */     if (null == iface && null != datagramChannel.config().getNetworkInterface()) {
/*  60 */       iface = datagramChannel.config().getNetworkInterface();
/*     */     }
/*     */ 
/*     */     
/*  64 */     if (null != iface) {
/*  65 */       future = datagramChannel.joinGroup(new InetSocketAddress(multicastAddress, datagramChannel
/*  66 */             .localAddress()
/*  67 */             .getPort()), iface);
/*     */     } else {
/*     */       
/*  70 */       future = datagramChannel.joinGroup(multicastAddress);
/*     */     } 
/*     */     
/*  73 */     return FutureMono.from((Future)future)
/*  74 */       .doOnSuccess(v -> {
/*     */           if (log.isInfoEnabled()) {
/*     */             log.info(ReactorNetty.format(future.channel(), "JOIN {}"), new Object[] { multicastAddress });
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> leave(InetAddress multicastAddress, @Nullable NetworkInterface iface) {
/*     */     ChannelFuture future;
/*  90 */     if (!(connection().channel() instanceof DatagramChannel)) {
/*  91 */       throw new UnsupportedOperationException();
/*     */     }
/*  93 */     DatagramChannel datagramChannel = (DatagramChannel)connection().channel();
/*  94 */     if (null == iface && null != datagramChannel.config().getNetworkInterface()) {
/*  95 */       iface = datagramChannel.config().getNetworkInterface();
/*     */     }
/*     */ 
/*     */     
/*  99 */     if (null != iface) {
/* 100 */       future = datagramChannel.leaveGroup(new InetSocketAddress(multicastAddress, datagramChannel
/* 101 */             .localAddress()
/* 102 */             .getPort()), iface);
/*     */     } else {
/*     */       
/* 105 */       future = datagramChannel.leaveGroup(multicastAddress);
/*     */     } 
/*     */     
/* 108 */     return FutureMono.from((Future)future)
/* 109 */       .doOnSuccess(v -> {
/*     */           if (log.isInfoEnabled()) {
/*     */             log.info(ReactorNetty.format(future.channel(), "JOIN {}"), new Object[] { multicastAddress });
/*     */           }
/*     */         });
/*     */   }
/*     */   
/* 116 */   static final Logger log = Loggers.getLogger(UdpOperations.class);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\nett\\udp\UdpOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */