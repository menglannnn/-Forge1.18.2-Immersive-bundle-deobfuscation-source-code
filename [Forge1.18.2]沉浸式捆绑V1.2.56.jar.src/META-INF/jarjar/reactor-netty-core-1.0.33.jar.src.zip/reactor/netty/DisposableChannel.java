/*     */ package reactor.netty;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface DisposableChannel
/*     */   extends Disposable
/*     */ {
/*     */   default SocketAddress address() {
/*  47 */     Channel c = channel();
/*  48 */     if (c instanceof io.netty.channel.socket.DatagramChannel || c instanceof io.netty.channel.unix.DomainDatagramChannel) {
/*  49 */       SocketAddress a = c.remoteAddress();
/*  50 */       return (a != null) ? a : c.localAddress();
/*     */     } 
/*     */     
/*  53 */     return c.remoteAddress();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Channel channel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void dispose() {
/*  72 */     channel().close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void disposeNow() {
/*  80 */     disposeNow(Duration.ofSeconds(3L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void disposeNow(Duration timeout) {
/*  90 */     if (isDisposed()) {
/*     */       return;
/*     */     }
/*     */     
/*  94 */     Objects.requireNonNull(timeout, "timeout");
/*     */     
/*  96 */     dispose();
/*     */     try {
/*  98 */       onDispose().block(timeout);
/*     */     }
/* 100 */     catch (IllegalStateException e) {
/* 101 */       if (e.getMessage()
/* 102 */         .contains("blocking read")) {
/* 103 */         throw new IllegalStateException("Socket couldn't be stopped within " + timeout.toMillis() + "ms");
/*     */       }
/* 105 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default CoreSubscriber<Void> disposeSubscriber() {
/* 113 */     return (CoreSubscriber<Void>)new ReactorNetty.ChannelDisposer(this);
/*     */   }
/*     */ 
/*     */   
/*     */   default boolean isDisposed() {
/* 118 */     return !channel().isActive();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> onDispose() {
/* 128 */     return FutureMono.from(channel().closeFuture());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default DisposableChannel onDispose(Disposable onDispose) {
/* 139 */     Objects.requireNonNull(onDispose, "onDispose");
/* 140 */     Objects.requireNonNull(onDispose); onDispose().subscribe(null, e -> onDispose.dispose(), onDispose::dispose);
/* 141 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\DisposableChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */