/*     */ package reactor.netty;
/*     */ 
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandler;
/*     */ import java.util.function.BiConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface NettyPipeline
/*     */ {
/*     */   public static final String LEFT = "reactor.left.";
/*     */   public static final String RIGHT = "reactor.right.";
/*     */   public static final String AccessLogHandler = "reactor.left.accessLogHandler";
/*     */   public static final String ChannelMetricsHandler = "reactor.left.channelMetricsHandler";
/*     */   public static final String ChunkedWriter = "reactor.left.chunkedWriter";
/*     */   public static final String CompressionHandler = "reactor.left.compressionHandler";
/*     */   public static final String ConnectMetricsHandler = "reactor.left.connectMetricsHandler";
/*     */   public static final String H2CUpgradeHandler = "reactor.left.h2cUpgradeHandler";
/*     */   public static final String H2Flush = "reactor.left.h2Flush";
/*     */   public static final String H2MultiplexHandler = "reactor.left.h2MultiplexHandler";
/*     */   public static final String H2OrHttp11Codec = "reactor.left.h2OrHttp11Codec";
/*     */   public static final String H2ToHttp11Codec = "reactor.left.h2ToHttp11Codec";
/*     */   public static final String HttpAggregator = "reactor.left.httpAggregator";
/*     */   public static final String HttpCodec = "reactor.left.httpCodec";
/*     */   public static final String HttpDecompressor = "reactor.left.httpDecompressor";
/*     */   public static final String HttpMetricsHandler = "reactor.left.httpMetricsHandler";
/*     */   public static final String HttpTrafficHandler = "reactor.left.httpTrafficHandler";
/*     */   public static final String IdleTimeoutHandler = "reactor.left.idleTimeoutHandler";
/*     */   public static final String LoggingHandler = "reactor.left.loggingHandler";
/*     */   public static final String NonSslRedirectDetector = "reactor.left.nonSslRedirectDetector";
/*     */   public static final String NonSslRedirectHandler = "reactor.left.nonSslRedirectHandler";
/*     */   public static final String OnChannelReadIdle = "reactor.left.onChannelReadIdle";
/*     */   public static final String OnChannelWriteIdle = "reactor.left.onChannelWriteIdle";
/*     */   public static final String ProxyHandler = "reactor.left.proxyHandler";
/*     */   public static final String UnvoidHandler = "reactor.left.unvoidHandler";
/*     */   public static final String ProxyLoggingHandler = "reactor.left.proxyLoggingHandler";
/*     */   public static final String ProxyProtocolDecoder = "reactor.left.proxyProtocolDecoder";
/*     */   public static final String ProxyProtocolReader = "reactor.left.proxyProtocolReader";
/*     */   public static final String ResponseTimeoutHandler = "reactor.left.responseTimeoutHandler";
/*     */   public static final String SslHandler = "reactor.left.sslHandler";
/*     */   public static final String SslLoggingHandler = "reactor.left.sslLoggingHandler";
/*     */   public static final String SslReader = "reactor.left.sslReader";
/*     */   public static final String TlsMetricsHandler = "reactor.left.tlsMetricsHandler";
/*     */   public static final String WsCompressionHandler = "reactor.left.wsCompressionHandler";
/*     */   public static final String WsFrameAggregator = "reactor.left.wsFrameAggregator";
/*     */   public static final String ReactiveBridge = "reactor.right.reactiveBridge";
/*     */   
/*     */   static ChannelInboundHandler inboundHandler(BiConsumer<? super ChannelHandlerContext, Object> handler) {
/* 135 */     return (ChannelInboundHandler)new ReactorNetty.ExtractorHandler(handler);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\NettyPipeline.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */