/*    */ package reactor.netty.tcp;
/*    */ 
/*    */ import io.netty.channel.ChannelOption;
/*    */ import io.netty.util.NetUtil;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.Collections;
/*    */ import reactor.netty.resources.ConnectionProvider;
/*    */ import reactor.netty.transport.AddressUtils;
/*    */ import reactor.netty.transport.Transport;
/*    */ import reactor.netty.transport.TransportConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TcpClientConnect
/*    */   extends TcpClient
/*    */ {
/*    */   final TcpClientConfig config;
/*    */   
/*    */   TcpClientConnect(ConnectionProvider provider) {
/* 36 */     this
/*    */       
/* 38 */       .config = new TcpClientConfig(provider, Collections.singletonMap(ChannelOption.AUTO_READ, Boolean.valueOf(false)), () -> AddressUtils.createUnresolved(NetUtil.LOCALHOST.getHostAddress(), DEFAULT_PORT));
/*    */   }
/*    */ 
/*    */   
/*    */   TcpClientConnect(TcpClientConfig config) {
/* 43 */     this.config = config;
/*    */   }
/*    */ 
/*    */   
/*    */   public TcpClientConfig configuration() {
/* 48 */     return this.config;
/*    */   }
/*    */ 
/*    */   
/*    */   protected TcpClient duplicate() {
/* 53 */     return new TcpClientConnect(new TcpClientConfig(this.config));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   static final int DEFAULT_PORT = (System.getenv("PORT") != null) ? Integer.parseInt(System.getenv("PORT")) : 12012;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpClientConnect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */