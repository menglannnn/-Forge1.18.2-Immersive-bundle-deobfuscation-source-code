/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.bootstrap.Bootstrap;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.ssl.OpenSsl;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.ClientTransport;
/*     */ import reactor.netty.transport.ProxyProvider;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TcpClient
/*     */   extends ClientTransport<TcpClient, TcpClientConfig>
/*     */ {
/*     */   public static TcpClient create() {
/*  82 */     return create(TcpResources.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpClient create(ConnectionProvider provider) {
/*  94 */     Objects.requireNonNull(provider, "provider");
/*  95 */     return new TcpClientConnect(provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpClient newConnection() {
/* 104 */     return create(ConnectionProvider.newConnection());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final TcpClient addressSupplier(Supplier<? extends SocketAddress> connectAddressSupplier) {
/* 118 */     return remoteAddress(connectAddressSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A> TcpClient attr(AttributeKey<A> key, @Nullable A value) {
/* 123 */     return (TcpClient)super.attr(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient bindAddress(Supplier<? extends SocketAddress> bindAddressSupplier) {
/* 128 */     return (TcpClient)super.bindAddress(bindAddressSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final TcpClient bootstrap(Function<? super Bootstrap, ? extends Bootstrap> bootstrapMapper) {
/* 184 */     Objects.requireNonNull(bootstrapMapper, "bootstrapMapper");
/* 185 */     TcpClientBootstrap tcpClientBootstrap = new TcpClientBootstrap(this);
/*     */     
/* 187 */     bootstrapMapper.apply(tcpClientBootstrap);
/* 188 */     return tcpClientBootstrap.tcpClient;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<? extends Connection> connect() {
/* 193 */     return super.connect();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Connection connectNow() {
/* 198 */     return super.connectNow();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Connection connectNow(Duration timeout) {
/* 203 */     return super.connectNow(timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient doOnConnect(Consumer<? super TcpClientConfig> doOnConnect) {
/* 208 */     return (TcpClient)super.doOnConnect(doOnConnect);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient doOnConnected(Consumer<? super Connection> doOnConnected) {
/* 213 */     return (TcpClient)super.doOnConnected(doOnConnected);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient doOnDisconnected(Consumer<? super Connection> doOnDisconnected) {
/* 218 */     return (TcpClient)super.doOnDisconnected(doOnDisconnected);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpClient handle(BiFunction<? super NettyInbound, ? super NettyOutbound, ? extends Publisher<Void>> handler) {
/* 230 */     Objects.requireNonNull(handler, "handler");
/* 231 */     return doOnConnected(new OnConnectedHandle(handler));
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient host(String host) {
/* 236 */     return (TcpClient)super.host(host);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient metrics(boolean enable) {
/* 241 */     return (TcpClient)super.metrics(enable);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/* 246 */     return (TcpClient)super.metrics(enable, recorder);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient noProxy() {
/* 251 */     return (TcpClient)super.noProxy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpClient noSSL() {
/* 260 */     if (((TcpClientConfig)configuration()).isSecure()) {
/* 261 */       TcpClient dup = (TcpClient)duplicate();
/* 262 */       ((TcpClientConfig)dup.configuration()).sslProvider = null;
/* 263 */       return dup;
/*     */     } 
/* 265 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient observe(ConnectionObserver observer) {
/* 270 */     return (TcpClient)super.observe(observer);
/*     */   }
/*     */ 
/*     */   
/*     */   public <O> TcpClient option(ChannelOption<O> key, @Nullable O value) {
/* 275 */     return (TcpClient)super.option(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient port(int port) {
/* 280 */     return (TcpClient)super.port(port);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient proxy(Consumer<? super ProxyProvider.TypeSpec> proxyOptions) {
/* 285 */     return (TcpClient)super.proxy(proxyOptions);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient remoteAddress(Supplier<? extends SocketAddress> remoteAddressSupplier) {
/* 290 */     return (TcpClient)super.remoteAddress(remoteAddressSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient resolver(AddressResolverGroup<?> resolver) {
/* 295 */     return (TcpClient)super.resolver(resolver);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient runOn(EventLoopGroup eventLoopGroup) {
/* 300 */     return (TcpClient)super.runOn(eventLoopGroup);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient runOn(LoopResources channelResources) {
/* 305 */     return (TcpClient)super.runOn(channelResources);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient runOn(LoopResources loopResources, boolean preferNative) {
/* 310 */     return (TcpClient)super.runOn(loopResources, preferNative);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpClient secure() {
/* 322 */     TcpClient dup = (TcpClient)duplicate();
/* 323 */     ((TcpClientConfig)dup.configuration()).sslProvider = SslProvider.defaultClientProvider();
/* 324 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpClient secure(Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder) {
/* 338 */     Objects.requireNonNull(sslProviderBuilder, "sslProviderBuilder");
/* 339 */     TcpClient dup = (TcpClient)duplicate();
/* 340 */     SslProvider.SslContextSpec builder = SslProvider.builder();
/* 341 */     sslProviderBuilder.accept(builder);
/* 342 */     ((TcpClientConfig)dup.configuration()).sslProvider = ((SslProvider.Builder)builder).build();
/* 343 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpClient secure(SslProvider sslProvider) {
/* 354 */     Objects.requireNonNull(sslProvider, "sslProvider");
/* 355 */     TcpClient dup = (TcpClient)duplicate();
/* 356 */     ((TcpClientConfig)dup.configuration()).sslProvider = sslProvider;
/* 357 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> warmup() {
/* 375 */     return Mono.when(new Publisher[] { (Publisher)super
/* 376 */           .warmup(), 
/* 377 */           (Publisher)Mono.fromRunnable(() -> {
/*     */               SslProvider provider = ((TcpClientConfig)configuration()).sslProvider();
/*     */               if (provider != null && !(provider.getSslContext() instanceof io.netty.handler.ssl.JdkSslContext)) {
/*     */                 OpenSsl.version();
/*     */               }
/*     */             }) });
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient wiretap(boolean enable) {
/* 387 */     return (TcpClient)super.wiretap(enable);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient wiretap(String category) {
/* 392 */     return (TcpClient)super.wiretap(category);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpClient wiretap(String category, LogLevel level) {
/* 397 */     return (TcpClient)super.wiretap(category, level);
/*     */   }
/*     */   
/* 400 */   static final Logger log = Loggers.getLogger(TcpClient.class);
/*     */   
/*     */   static final class OnConnectedHandle
/*     */     implements Consumer<Connection> {
/*     */     final BiFunction<? super NettyInbound, ? super NettyOutbound, ? extends Publisher<Void>> handler;
/*     */     
/*     */     OnConnectedHandle(BiFunction<? super NettyInbound, ? super NettyOutbound, ? extends Publisher<Void>> handler) {
/* 407 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Connection c) {
/* 412 */       if (TcpClient.log.isDebugEnabled()) {
/* 413 */         TcpClient.log.debug(ReactorNetty.format(c.channel(), "Handler is being applied: {}"), new Object[] { this.handler });
/*     */       }
/*     */       
/* 416 */       Mono.fromDirect(this.handler.apply((NettyInbound)c, (NettyOutbound)c))
/* 417 */         .subscribe(c.disposeSubscriber());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */