/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.channel.MicrometerChannelMetricsRecorder;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.ServerTransportConfig;
/*     */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TcpServerConfig
/*     */   extends ServerTransportConfig<TcpServerConfig>
/*     */ {
/*     */   SslProvider sslProvider;
/*     */   static final ChannelOperations.OnSetup DEFAULT_OPS;
/*     */   
/*     */   public ChannelOperations.OnSetup channelOperationsProvider() {
/*  48 */     return DEFAULT_OPS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSecure() {
/*  57 */     return (this.sslProvider != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SslProvider sslProvider() {
/*  69 */     return this.sslProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TcpServerConfig(Map<ChannelOption<?>, ?> options, Map<ChannelOption<?>, ?> childOptions, Supplier<? extends SocketAddress> localAddress) {
/*  79 */     super(options, childOptions, localAddress);
/*     */   }
/*     */   
/*     */   TcpServerConfig(TcpServerConfig parent) {
/*  83 */     super(parent);
/*  84 */     this.sslProvider = parent.sslProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   protected LoggingHandler defaultLoggingHandler() {
/*  89 */     return LOGGING_HANDLER;
/*     */   }
/*     */ 
/*     */   
/*     */   protected LoopResources defaultLoopResources() {
/*  94 */     return TcpResources.get();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelMetricsRecorder defaultMetricsRecorder() {
/*  99 */     return (ChannelMetricsRecorder)MicrometerTcpServerMetricsRecorder.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelPipelineConfigurer defaultOnChannelInit() {
/* 104 */     ChannelPipelineConfigurer _default = super.defaultOnChannelInit();
/* 105 */     if (this.sslProvider != null) {
/* 106 */       return _default.then(new TcpServerChannelInitializer(this.sslProvider));
/*     */     }
/*     */     
/* 109 */     return _default;
/*     */   }
/*     */   
/*     */   static {
/* 113 */     DEFAULT_OPS = ((ch, c, msg) -> new ChannelOperations(ch, c));
/*     */   }
/* 115 */   static final LoggingHandler LOGGING_HANDLER = AdvancedByteBufFormat.HEX_DUMP
/*     */     
/* 117 */     .toLoggingHandler(TcpServer.class.getName(), LogLevel.DEBUG, Charset.defaultCharset());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   static final boolean SSL_DEBUG = Boolean.parseBoolean(System.getProperty("reactor.netty.tcp.ssl.server.debug", "false"));
/*     */   
/*     */   static final class MicrometerTcpServerMetricsRecorder
/*     */     extends MicrometerChannelMetricsRecorder {
/* 127 */     static final MicrometerTcpServerMetricsRecorder INSTANCE = new MicrometerTcpServerMetricsRecorder();
/*     */     
/*     */     MicrometerTcpServerMetricsRecorder() {
/* 130 */       super("reactor.netty.tcp.server", "tcp");
/*     */     }
/*     */   }
/*     */   
/*     */   static final class TcpServerChannelInitializer
/*     */     implements ChannelPipelineConfigurer {
/*     */     final SslProvider sslProvider;
/*     */     
/*     */     TcpServerChannelInitializer(SslProvider sslProvider) {
/* 139 */       this.sslProvider = sslProvider;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChannelInit(ConnectionObserver connectionObserver, Channel channel, @Nullable SocketAddress remoteAddress) {
/* 144 */       this.sslProvider.addSslHandler(channel, remoteAddress, TcpServerConfig.SSL_DEBUG);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpServerConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */