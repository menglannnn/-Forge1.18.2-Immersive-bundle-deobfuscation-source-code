/*    */ package reactor.netty.tcp;
/*    */ 
/*    */ import io.netty.handler.ssl.SslContext;
/*    */ import io.netty.handler.ssl.SslContextBuilder;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import javax.net.ssl.SSLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractProtocolSslContextSpec<T extends AbstractProtocolSslContextSpec<T>>
/*    */   implements SslProvider.ProtocolSslContextSpec, Supplier<T>
/*    */ {
/*    */   final SslContextBuilder sslContextBuilder;
/*    */   
/*    */   protected AbstractProtocolSslContextSpec(SslContextBuilder sslContextBuilder) {
/* 38 */     this.sslContextBuilder = sslContextBuilder;
/* 39 */     configure(defaultConfiguration());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T configure(Consumer<SslContextBuilder> sslCtxBuilder) {
/* 46 */     Objects.requireNonNull(sslCtxBuilder, "sslCtxBuilder");
/* 47 */     sslCtxBuilder.accept(this.sslContextBuilder);
/* 48 */     return get();
/*    */   }
/*    */ 
/*    */   
/*    */   public SslContext sslContext() throws SSLException {
/* 53 */     return this.sslContextBuilder.build();
/*    */   }
/*    */   
/*    */   protected abstract Consumer<SslContextBuilder> defaultConfiguration();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\AbstractProtocolSslContextSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */