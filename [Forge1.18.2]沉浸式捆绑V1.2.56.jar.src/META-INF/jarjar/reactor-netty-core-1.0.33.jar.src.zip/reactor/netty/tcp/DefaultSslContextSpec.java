/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.handler.ssl.SslContextBuilder;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.function.Consumer;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultSslContextSpec
/*     */   extends AbstractProtocolSslContextSpec<DefaultSslContextSpec>
/*     */ {
/*     */   public static DefaultSslContextSpec forClient() {
/*  43 */     return new DefaultSslContextSpec(SslContextBuilder.forClient());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(File keyCertChainFile, File keyFile) {
/*  52 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(keyCertChainFile, keyFile));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(File keyCertChainFile, File keyFile, String keyPassword) {
/*  61 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(keyCertChainFile, keyFile, keyPassword));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(InputStream keyCertChainInputStream, InputStream keyInputStream) {
/*  70 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(keyCertChainInputStream, keyInputStream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(InputStream keyCertChainInputStream, InputStream keyInputStream, String keyPassword) {
/*  80 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(keyCertChainInputStream, keyInputStream, keyPassword));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(KeyManager keyManager) {
/*  89 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(keyManager));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(KeyManagerFactory keyManagerFactory) {
/*  98 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(keyManagerFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(PrivateKey key, Iterable<? extends X509Certificate> keyCertChain) {
/* 107 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(key, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(PrivateKey key, String keyPassword, Iterable<? extends X509Certificate> keyCertChain) {
/* 117 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(key, keyPassword, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(PrivateKey key, String keyPassword, X509Certificate... keyCertChain) {
/* 126 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(key, keyPassword, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultSslContextSpec forServer(PrivateKey key, X509Certificate... keyCertChain) {
/* 135 */     return new DefaultSslContextSpec(SslContextBuilder.forServer(key, keyCertChain));
/*     */   }
/*     */   
/*     */   DefaultSslContextSpec(SslContextBuilder sslContextBuilder) {
/* 139 */     super(sslContextBuilder);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultSslContextSpec get() {
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Consumer<SslContextBuilder> defaultConfiguration() {
/* 149 */     return DEFAULT_CONFIGURATOR;
/*     */   }
/*     */   
/*     */   static final Consumer<SslContextBuilder> DEFAULT_CONFIGURATOR = sslCtxBuilder -> {
/*     */     
/*     */     };
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\DefaultSslContextSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */