/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.channel.MicrometerChannelMetricsRecorder;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.ClientTransportConfig;
/*     */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TcpClientConfig
/*     */   extends ClientTransportConfig<TcpClientConfig>
/*     */ {
/*     */   SslProvider sslProvider;
/*     */   static final ChannelOperations.OnSetup DEFAULT_OPS;
/*     */   
/*     */   public int channelHash() {
/*  51 */     int result = super.channelHash();
/*  52 */     result = 31 * result + Objects.hashCode(this.sslProvider);
/*  53 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelOperations.OnSetup channelOperationsProvider() {
/*  58 */     return DEFAULT_OPS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSecure() {
/*  67 */     return (this.sslProvider != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SslProvider sslProvider() {
/*  79 */     return this.sslProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TcpClientConfig(ConnectionProvider connectionProvider, Map<ChannelOption<?>, ?> options, Supplier<? extends SocketAddress> remoteAddress) {
/*  89 */     super(connectionProvider, options, remoteAddress);
/*     */   }
/*     */   
/*     */   TcpClientConfig(TcpClientConfig parent) {
/*  93 */     super(parent);
/*  94 */     this.sslProvider = parent.sslProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AddressResolverGroup<?> defaultAddressResolverGroup() {
/* 106 */     return TcpResources.get().getOrCreateDefaultResolver();
/*     */   }
/*     */ 
/*     */   
/*     */   protected LoggingHandler defaultLoggingHandler() {
/* 111 */     return LOGGING_HANDLER;
/*     */   }
/*     */ 
/*     */   
/*     */   protected LoopResources defaultLoopResources() {
/* 116 */     return TcpResources.get();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelMetricsRecorder defaultMetricsRecorder() {
/* 121 */     return (ChannelMetricsRecorder)MicrometerTcpClientMetricsRecorder.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelPipelineConfigurer defaultOnChannelInit() {
/* 126 */     ChannelPipelineConfigurer _default = super.defaultOnChannelInit();
/* 127 */     if (this.sslProvider != null) {
/* 128 */       return _default.then(new TcpClientChannelInitializer(this.sslProvider));
/*     */     }
/*     */     
/* 131 */     return _default;
/*     */   }
/*     */   
/*     */   static {
/* 135 */     DEFAULT_OPS = ((ch, c, msg) -> new ChannelOperations(ch, c));
/*     */   }
/* 137 */   static final LoggingHandler LOGGING_HANDLER = AdvancedByteBufFormat.HEX_DUMP
/*     */     
/* 139 */     .toLoggingHandler(TcpClient.class.getName(), LogLevel.DEBUG, Charset.defaultCharset());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   static final boolean SSL_DEBUG = Boolean.parseBoolean(System.getProperty("reactor.netty.tcp.ssl.client.debug", "false"));
/*     */   
/*     */   static final class MicrometerTcpClientMetricsRecorder
/*     */     extends MicrometerChannelMetricsRecorder {
/* 149 */     static final MicrometerTcpClientMetricsRecorder INSTANCE = new MicrometerTcpClientMetricsRecorder();
/*     */     
/*     */     MicrometerTcpClientMetricsRecorder() {
/* 152 */       super("reactor.netty.tcp.client", "tcp");
/*     */     }
/*     */   }
/*     */   
/*     */   static final class TcpClientChannelInitializer
/*     */     implements ChannelPipelineConfigurer {
/*     */     final SslProvider sslProvider;
/*     */     
/*     */     TcpClientChannelInitializer(SslProvider sslProvider) {
/* 161 */       this.sslProvider = sslProvider;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChannelInit(ConnectionObserver connectionObserver, Channel channel, @Nullable SocketAddress remoteAddress) {
/* 166 */       this.sslProvider.addSslHandler(channel, remoteAddress, TcpClientConfig.SSL_DEBUG);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpClientConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */