/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.group.ChannelGroup;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.ssl.OpenSsl;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.DisposableServer;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.ServerTransport;
/*     */ import reactor.netty.transport.Transport;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TcpServer
/*     */   extends ServerTransport<TcpServer, TcpServerConfig>
/*     */ {
/*     */   public static TcpServer create() {
/*  74 */     return TcpServerBind.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer bindAddress(Supplier<? extends SocketAddress> bindAddressSupplier) {
/*  79 */     return (TcpServer)super.bindAddress(bindAddressSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer channelGroup(ChannelGroup channelGroup) {
/*  84 */     return (TcpServer)super.channelGroup(channelGroup);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnBind(Consumer<? super TcpServerConfig> doOnBind) {
/*  89 */     return (TcpServer)super.doOnBind(doOnBind);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnBound(Consumer<? super DisposableServer> doOnBound) {
/*  94 */     return (TcpServer)super.doOnBound(doOnBound);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnConnection(Consumer<? super Connection> doOnConnection) {
/*  99 */     return (TcpServer)super.doOnConnection(doOnConnection);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer doOnUnbound(Consumer<? super DisposableServer> doOnUnbound) {
/* 104 */     return (TcpServer)super.doOnUnbound(doOnUnbound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpServer handle(BiFunction<? super NettyInbound, ? super NettyOutbound, ? extends Publisher<Void>> handler) {
/* 116 */     Objects.requireNonNull(handler, "handler");
/* 117 */     return doOnConnection(new OnConnectionHandle(handler));
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer host(String host) {
/* 122 */     return (TcpServer)super.host(host);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer metrics(boolean enable) {
/* 127 */     return (TcpServer)super.metrics(enable);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/* 132 */     return (TcpServer)super.metrics(enable, recorder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpServer noSSL() {
/* 141 */     if (((TcpServerConfig)configuration()).isSecure()) {
/* 142 */       TcpServer dup = (TcpServer)duplicate();
/* 143 */       ((TcpServerConfig)dup.configuration()).sslProvider = null;
/* 144 */       return dup;
/*     */     } 
/* 146 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer port(int port) {
/* 151 */     return (TcpServer)super.port(port);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer runOn(EventLoopGroup eventLoopGroup) {
/* 156 */     return (TcpServer)super.runOn(eventLoopGroup);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer runOn(LoopResources channelResources) {
/* 161 */     return (TcpServer)super.runOn(channelResources);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer runOn(LoopResources loopResources, boolean preferNative) {
/* 166 */     return (TcpServer)super.runOn(loopResources, preferNative);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpServer secure(Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder) {
/* 190 */     Objects.requireNonNull(sslProviderBuilder, "sslProviderBuilder");
/* 191 */     TcpServer dup = (TcpServer)duplicate();
/* 192 */     SslProvider.SslContextSpec builder = SslProvider.builder();
/* 193 */     sslProviderBuilder.accept(builder);
/* 194 */     ((TcpServerConfig)dup.configuration()).sslProvider = ((SslProvider.Builder)builder).build();
/* 195 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TcpServer secure(SslProvider sslProvider) {
/* 217 */     Objects.requireNonNull(sslProvider, "sslProvider");
/* 218 */     TcpServer dup = (TcpServer)duplicate();
/* 219 */     ((TcpServerConfig)dup.configuration()).sslProvider = sslProvider;
/* 220 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> warmup() {
/* 237 */     return Mono.when(new Publisher[] { (Publisher)super
/* 238 */           .warmup(), 
/* 239 */           (Publisher)Mono.fromRunnable(() -> {
/*     */               SslProvider provider = ((TcpServerConfig)configuration()).sslProvider();
/*     */               if (provider != null && !(provider.getSslContext() instanceof io.netty.handler.ssl.JdkSslContext)) {
/*     */                 OpenSsl.version();
/*     */               }
/*     */             }) });
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer wiretap(boolean enable) {
/* 249 */     return (TcpServer)super.wiretap(enable);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer wiretap(String category) {
/* 254 */     return (TcpServer)super.wiretap(category);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpServer wiretap(String category, LogLevel level) {
/* 259 */     return (TcpServer)super.wiretap(category, level);
/*     */   }
/*     */   
/* 262 */   static final Logger log = Loggers.getLogger(TcpServer.class);
/*     */   
/*     */   static final class OnConnectionHandle
/*     */     implements Consumer<Connection> {
/*     */     final BiFunction<? super NettyInbound, ? super NettyOutbound, ? extends Publisher<Void>> handler;
/*     */     
/*     */     OnConnectionHandle(BiFunction<? super NettyInbound, ? super NettyOutbound, ? extends Publisher<Void>> handler) {
/* 269 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Connection c) {
/* 274 */       if (TcpServer.log.isDebugEnabled()) {
/* 275 */         TcpServer.log.debug(ReactorNetty.format(c.channel(), "Handler is being applied: {}"), new Object[] { this.handler });
/*     */       }
/* 277 */       Mono.fromDirect(this.handler.apply(c.inbound(), c.outbound()))
/* 278 */         .subscribe(c.disposeSubscriber());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */