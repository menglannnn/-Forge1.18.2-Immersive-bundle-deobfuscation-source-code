/*    */ package reactor.netty.tcp;
/*    */ 
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TcpClientSecure
/*    */ {
/* 29 */   private static final Logger log = Loggers.getLogger(TcpClientSecure.class);
/*    */ 
/*    */ 
/*    */   
/*    */   static final SslProvider DEFAULT_SSL_PROVIDER;
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     try {
/* 39 */       sslProvider = SslProvider.builder().sslContext(TcpSslContextSpec.forClient()).build();
/*    */     }
/* 41 */     catch (Exception e) {
/* 42 */       log.error("Failed to build default ssl provider", e);
/* 43 */       sslProvider = null;
/*    */     } 
/* 45 */     DEFAULT_SSL_PROVIDER = sslProvider;
/*    */   }
/*    */   
/*    */   static {
/*    */     SslProvider sslProvider;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpClientSecure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */