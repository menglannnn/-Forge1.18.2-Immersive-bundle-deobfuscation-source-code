/*    */ package reactor.netty.tcp;
/*    */ 
/*    */ import io.netty.channel.ChannelOption;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty.DisposableServer;
/*    */ import reactor.netty.internal.util.MapUtils;
/*    */ import reactor.netty.transport.Transport;
/*    */ import reactor.netty.transport.TransportConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TcpServerBind
/*    */   extends TcpServer
/*    */ {
/* 36 */   static final TcpServerBind INSTANCE = new TcpServerBind();
/*    */   final TcpServerConfig config;
/*    */   static final int DEFAULT_PORT = 0;
/*    */   
/*    */   TcpServerBind() {
/* 41 */     Map<ChannelOption<?>, Boolean> childOptions = new HashMap<>(MapUtils.calculateInitialCapacity(2));
/* 42 */     childOptions.put(ChannelOption.AUTO_READ, Boolean.valueOf(false));
/* 43 */     childOptions.put(ChannelOption.TCP_NODELAY, Boolean.valueOf(true));
/* 44 */     this
/* 45 */       .config = new TcpServerConfig(Collections.singletonMap(ChannelOption.SO_REUSEADDR, Boolean.valueOf(true)), childOptions, () -> new InetSocketAddress(0));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   TcpServerBind(TcpServerConfig config) {
/* 51 */     this.config = config;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<? extends DisposableServer> bind() {
/* 57 */     if (this.config.sslProvider != null && this.config.sslProvider.getDefaultConfigurationType() == null) {
/* 58 */       this.config.sslProvider = SslProvider.updateDefaultConfiguration(this.config.sslProvider, SslProvider.DefaultConfigurationType.TCP);
/*    */     }
/* 60 */     return super.bind();
/*    */   }
/*    */ 
/*    */   
/*    */   public TcpServerConfig configuration() {
/* 65 */     return this.config;
/*    */   }
/*    */ 
/*    */   
/*    */   protected TcpServer duplicate() {
/* 70 */     return new TcpServerBind(new TcpServerConfig(this.config));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpServerBind.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */