/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.bootstrap.AbstractBootstrap;
/*     */ import io.netty.bootstrap.Bootstrap;
/*     */ import io.netty.bootstrap.ChannelFactory;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFactory;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.internal.SocketUtils;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ final class TcpClientBootstrap
/*     */   extends Bootstrap
/*     */ {
/*     */   TcpClient tcpClient;
/*     */   
/*     */   TcpClientBootstrap(TcpClient tcpClient) {
/*  45 */     this.tcpClient = tcpClient;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Bootstrap attr(AttributeKey<T> key, T value) {
/*  50 */     this.tcpClient = this.tcpClient.attr(key, value);
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture bind() {
/*  56 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture bind(InetAddress inetHost, int inetPort) {
/*  61 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture bind(int inetPort) {
/*  66 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture bind(SocketAddress localAddress) {
/*  71 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture bind(String inetHost, int inetPort) {
/*  76 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap channel(Class<? extends Channel> channelClass) {
/*  81 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Bootstrap channelFactory(ChannelFactory<? extends Channel> channelFactory) {
/*  87 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap channelFactory(ChannelFactory<? extends Channel> channelFactory) {
/*  92 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap clone() {
/*  97 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap clone(EventLoopGroup group) {
/* 102 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture connect() {
/* 107 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture connect(InetAddress inetHost, int inetPort) {
/* 112 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture connect(SocketAddress remoteAddress) {
/* 117 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
/* 122 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture connect(String inetHost, int inetPort) {
/* 127 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 132 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() {
/* 137 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap group(EventLoopGroup group) {
/* 142 */     this.tcpClient = this.tcpClient.runOn(group);
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap handler(ChannelHandler handler) {
/* 148 */     this.tcpClient = (TcpClient)this.tcpClient.doOnChannelInit((connectionObserver, channel, remoteAddress) -> channel.pipeline().addBefore("reactor.right.reactiveBridge", null, handler));
/*     */     
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 155 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap localAddress(InetAddress inetHost, int inetPort) {
/* 160 */     this.tcpClient = this.tcpClient.bindAddress(() -> new InetSocketAddress(inetHost, inetPort));
/* 161 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap localAddress(int inetPort) {
/* 166 */     this.tcpClient = this.tcpClient.bindAddress(() -> new InetSocketAddress(inetPort));
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap localAddress(SocketAddress localAddress) {
/* 172 */     this.tcpClient = this.tcpClient.bindAddress(() -> localAddress);
/* 173 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap localAddress(String inetHost, int inetPort) {
/* 178 */     this.tcpClient = this.tcpClient.bindAddress(() -> SocketUtils.socketAddress(inetHost, inetPort));
/* 179 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Bootstrap option(ChannelOption<T> option, T value) {
/* 184 */     this.tcpClient = this.tcpClient.option(option, value);
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register() {
/* 190 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap remoteAddress(InetAddress inetHost, int inetPort) {
/* 195 */     this.tcpClient = this.tcpClient.remoteAddress(() -> new InetSocketAddress(inetHost, inetPort));
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap remoteAddress(SocketAddress remoteAddress) {
/* 201 */     this.tcpClient = this.tcpClient.remoteAddress(() -> remoteAddress);
/* 202 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap remoteAddress(String inetHost, int inetPort) {
/* 207 */     this.tcpClient = this.tcpClient.host(inetHost).port(inetPort);
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap resolver(AddressResolverGroup<?> resolver) {
/* 213 */     this.tcpClient = this.tcpClient.resolver(resolver);
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 219 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bootstrap validate() {
/* 224 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpClientBootstrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */