/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.handler.ssl.CipherSuiteFilter;
/*     */ import io.netty.handler.ssl.IdentityCipherSuiteFilter;
/*     */ import io.netty.handler.ssl.OpenSsl;
/*     */ import io.netty.handler.ssl.SslContextBuilder;
/*     */ import io.netty.handler.ssl.SslProvider;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.function.Consumer;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TcpSslContextSpec
/*     */   extends AbstractProtocolSslContextSpec<TcpSslContextSpec>
/*     */ {
/*     */   static final Consumer<SslContextBuilder> DEFAULT_CONFIGURATOR;
/*     */   
/*     */   public static TcpSslContextSpec forClient() {
/*  54 */     return new TcpSslContextSpec(SslContextBuilder.forClient());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(File keyCertChainFile, File keyFile) {
/*  63 */     return new TcpSslContextSpec(SslContextBuilder.forServer(keyCertChainFile, keyFile));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(File keyCertChainFile, File keyFile, String keyPassword) {
/*  72 */     return new TcpSslContextSpec(SslContextBuilder.forServer(keyCertChainFile, keyFile, keyPassword));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(InputStream keyCertChainInputStream, InputStream keyInputStream) {
/*  81 */     return new TcpSslContextSpec(SslContextBuilder.forServer(keyCertChainInputStream, keyInputStream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(InputStream keyCertChainInputStream, InputStream keyInputStream, String keyPassword) {
/*  91 */     return new TcpSslContextSpec(SslContextBuilder.forServer(keyCertChainInputStream, keyInputStream, keyPassword));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(KeyManager keyManager) {
/* 100 */     return new TcpSslContextSpec(SslContextBuilder.forServer(keyManager));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(KeyManagerFactory keyManagerFactory) {
/* 109 */     return new TcpSslContextSpec(SslContextBuilder.forServer(keyManagerFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(PrivateKey key, Iterable<? extends X509Certificate> keyCertChain) {
/* 118 */     return new TcpSslContextSpec(SslContextBuilder.forServer(key, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(PrivateKey key, String keyPassword, Iterable<? extends X509Certificate> keyCertChain) {
/* 128 */     return new TcpSslContextSpec(SslContextBuilder.forServer(key, keyPassword, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(PrivateKey key, String keyPassword, X509Certificate... keyCertChain) {
/* 137 */     return new TcpSslContextSpec(SslContextBuilder.forServer(key, keyPassword, keyCertChain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpSslContextSpec forServer(PrivateKey key, X509Certificate... keyCertChain) {
/* 146 */     return new TcpSslContextSpec(SslContextBuilder.forServer(key, keyCertChain));
/*     */   }
/*     */   
/*     */   TcpSslContextSpec(SslContextBuilder sslContextBuilder) {
/* 150 */     super(sslContextBuilder);
/*     */   }
/*     */ 
/*     */   
/*     */   public TcpSslContextSpec get() {
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Consumer<SslContextBuilder> defaultConfiguration() {
/* 160 */     return DEFAULT_CONFIGURATOR;
/*     */   }
/*     */   static {
/* 163 */     DEFAULT_CONFIGURATOR = (sslCtxBuilder -> sslCtxBuilder.sslProvider(OpenSsl.isAvailable() ? SslProvider.OPENSSL : SslProvider.JDK).ciphers(null, (CipherSuiteFilter)IdentityCipherSuiteFilter.INSTANCE).applicationProtocolConfig(null));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpSslContextSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */