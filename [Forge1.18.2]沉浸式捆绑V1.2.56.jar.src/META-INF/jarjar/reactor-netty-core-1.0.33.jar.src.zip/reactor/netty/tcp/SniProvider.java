/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.handler.codec.DecoderException;
/*     */ import io.netty.handler.ssl.AbstractSniHandler;
/*     */ import io.netty.handler.ssl.SslHandler;
/*     */ import io.netty.util.AsyncMapping;
/*     */ import io.netty.util.DomainWildcardMappingBuilder;
/*     */ import io.netty.util.Mapping;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SniProvider
/*     */ {
/*     */   final AsyncMapping<String, SslProvider> mappings;
/*     */   
/*     */   void addSniHandler(Channel channel, boolean sslDebug) {
/*  50 */     ChannelPipeline pipeline = channel.pipeline();
/*  51 */     if (pipeline.get("reactor.left.nonSslRedirectDetector") != null) {
/*  52 */       pipeline.addAfter("reactor.left.nonSslRedirectDetector", "reactor.left.sslHandler", (ChannelHandler)newSniHandler());
/*     */     } else {
/*     */       
/*  55 */       pipeline.addFirst("reactor.left.sslHandler", (ChannelHandler)newSniHandler());
/*     */     } 
/*  57 */     SslProvider.addSslReadHandler(pipeline, sslDebug);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   SniProvider(AsyncMapping<String, SslProvider> mappings) {
/*  63 */     this.mappings = mappings;
/*     */   }
/*     */   
/*     */   SniProvider(Map<String, SslProvider> confPerDomainName, SslProvider defaultSslProvider) {
/*  67 */     DomainWildcardMappingBuilder<SslProvider> mappingsSslProviderBuilder = new DomainWildcardMappingBuilder(defaultSslProvider);
/*     */     
/*  69 */     Objects.requireNonNull(mappingsSslProviderBuilder); confPerDomainName.forEach(mappingsSslProviderBuilder::add);
/*  70 */     this.mappings = new AsyncMappingAdapter(mappingsSslProviderBuilder.build());
/*     */   }
/*     */   
/*     */   SniHandler newSniHandler() {
/*  74 */     return new SniHandler(this.mappings);
/*     */   }
/*     */   
/*     */   static final class AsyncMappingAdapter
/*     */     implements AsyncMapping<String, SslProvider> {
/*     */     final Mapping<String, SslProvider> mapping;
/*     */     
/*     */     AsyncMappingAdapter(Mapping<String, SslProvider> mapping) {
/*  82 */       this.mapping = mapping;
/*     */     }
/*     */ 
/*     */     
/*     */     public Future<SslProvider> map(String input, Promise<SslProvider> promise) {
/*     */       try {
/*  88 */         return (Future<SslProvider>)promise.setSuccess(this.mapping.map(input));
/*     */       }
/*  90 */       catch (Throwable cause) {
/*  91 */         return (Future<SslProvider>)promise.setFailure(cause);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SniHandler
/*     */     extends AbstractSniHandler<SslProvider> {
/*     */     final AsyncMapping<String, SslProvider> mappings;
/*     */     
/*     */     SniHandler(AsyncMapping<String, SslProvider> mappings) {
/* 101 */       this.mappings = mappings;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Future<SslProvider> lookup(ChannelHandlerContext ctx, String hostname) {
/* 106 */       return this.mappings.map(hostname, ctx.executor().newPromise());
/*     */     }
/*     */ 
/*     */     
/*     */     protected void onLookupComplete(ChannelHandlerContext ctx, String hostname, Future<SslProvider> future) {
/* 111 */       if (!future.isSuccess()) {
/* 112 */         Throwable cause = future.cause();
/* 113 */         if (cause instanceof Error) {
/* 114 */           throw (Error)cause;
/*     */         }
/* 116 */         throw new DecoderException("failed to get the SslContext for " + hostname, cause);
/*     */       } 
/*     */       
/* 119 */       SslProvider sslProvider = (SslProvider)future.getNow();
/* 120 */       SslHandler sslHandler = null;
/*     */       try {
/* 122 */         sslHandler = sslProvider.getSslContext().newHandler(ctx.alloc());
/* 123 */         sslProvider.configure(sslHandler);
/* 124 */         ctx.pipeline().replace((ChannelHandler)this, SslHandler.class.getName(), (ChannelHandler)sslHandler);
/* 125 */         sslHandler = null;
/*     */       }
/* 127 */       catch (Throwable cause) {
/* 128 */         PlatformDependent.throwException(cause);
/*     */       } finally {
/*     */         
/* 131 */         if (sslHandler != null)
/* 132 */           ReferenceCountUtil.safeRelease(sslHandler.engine()); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\SniProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */