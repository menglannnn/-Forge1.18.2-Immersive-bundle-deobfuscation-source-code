/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.resolver.dns.DnsAddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.NameResolverProvider;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TcpResources
/*     */   implements ConnectionProvider, LoopResources
/*     */ {
/*     */   final LoopResources defaultLoops;
/*     */   final ConnectionProvider defaultProvider;
/*     */   final AtomicReference<AddressResolverGroup<?>> defaultResolver;
/*     */   static final NameResolverProvider DEFAULT_NAME_RESOLVER_PROVIDER;
/*     */   
/*     */   public static void disposeLoopsAndConnections() {
/*  58 */     TcpResources resources = tcpResources.getAndSet(null);
/*  59 */     if (resources != null) {
/*  60 */       resources._dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> disposeLoopsAndConnectionsLater() {
/*  73 */     return disposeLoopsAndConnectionsLater(Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_QUIET_PERIOD), 
/*  74 */         Duration.ofSeconds(LoopResources.DEFAULT_SHUTDOWN_TIMEOUT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Void> disposeLoopsAndConnectionsLater(Duration quietPeriod, Duration timeout) {
/*  92 */     Objects.requireNonNull(quietPeriod, "quietPeriod");
/*  93 */     Objects.requireNonNull(timeout, "timeout");
/*  94 */     return Mono.defer(() -> {
/*     */           TcpResources resources = tcpResources.getAndSet(null);
/*     */           return (resources != null) ? resources._disposeLater(quietPeriod, timeout) : Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpResources get() {
/* 109 */     return getOrCreate(tcpResources, null, null, ON_TCP_NEW, "tcp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpResources reset() {
/* 118 */     disposeLoopsAndConnections();
/* 119 */     return getOrCreate(tcpResources, null, null, ON_TCP_NEW, "tcp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpResources set(ConnectionProvider provider) {
/* 130 */     return getOrCreate(tcpResources, null, provider, ON_TCP_NEW, "tcp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TcpResources set(LoopResources loops) {
/* 141 */     return getOrCreate(tcpResources, loops, null, ON_TCP_NEW, "tcp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TcpResources(LoopResources defaultLoops, ConnectionProvider defaultProvider) {
/* 149 */     this.defaultLoops = defaultLoops;
/* 150 */     this.defaultProvider = defaultProvider;
/* 151 */     this.defaultResolver = new AtomicReference<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<? extends Connection> acquire(TransportConfig config, ConnectionObserver observer, @Nullable Supplier<? extends SocketAddress> remoteAddress, @Nullable AddressResolverGroup<?> resolverGroup) {
/* 159 */     Objects.requireNonNull(config, "config");
/* 160 */     Objects.requireNonNull(observer, "observer");
/* 161 */     return this.defaultProvider.acquire(config, observer, remoteAddress, resolverGroup);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean daemon() {
/* 166 */     return this.defaultLoops.daemon();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeLater() {
/* 191 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeLater(Duration quietPeriod, Duration timeout) {
/* 204 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disposeWhen(SocketAddress remoteAddress) {
/* 219 */     this.defaultProvider.disposeWhen(remoteAddress);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 224 */     return (this.defaultLoops.isDisposed() && this.defaultProvider.isDisposed());
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxConnections() {
/* 229 */     return this.defaultProvider.maxConnections();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<SocketAddress, Integer> maxConnectionsPerHost() {
/* 234 */     return this.defaultProvider.maxConnectionsPerHost();
/*     */   }
/*     */ 
/*     */   
/*     */   public ConnectionProvider.Builder mutate() {
/* 239 */     return this.defaultProvider.mutate();
/*     */   }
/*     */ 
/*     */   
/*     */   public String name() {
/* 244 */     return this.defaultProvider.name();
/*     */   }
/*     */ 
/*     */   
/*     */   public <CHANNEL extends io.netty.channel.Channel> CHANNEL onChannel(Class<CHANNEL> channelType, EventLoopGroup group) {
/* 249 */     Objects.requireNonNull(channelType, "channelType");
/* 250 */     Objects.requireNonNull(group, "group");
/* 251 */     return (CHANNEL)this.defaultLoops.onChannel(channelType, group);
/*     */   }
/*     */ 
/*     */   
/*     */   public <CHANNEL extends io.netty.channel.Channel> Class<? extends CHANNEL> onChannelClass(Class<CHANNEL> channelType, EventLoopGroup group) {
/* 256 */     Objects.requireNonNull(channelType, "channelType");
/* 257 */     Objects.requireNonNull(group, "group");
/* 258 */     return this.defaultLoops.onChannelClass(channelType, group);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onClient(boolean useNative) {
/* 263 */     return this.defaultLoops.onClient(useNative);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onServer(boolean useNative) {
/* 268 */     return this.defaultLoops.onServer(useNative);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onServerSelect(boolean useNative) {
/* 273 */     return this.defaultLoops.onServerSelect(useNative);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _dispose() {
/* 280 */     this.defaultProvider.dispose();
/* 281 */     _disposeResolver();
/* 282 */     this.defaultLoops.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> _disposeLater(Duration quietPeriod, Duration timeout) {
/* 297 */     return Mono.when(new Publisher[] { (Publisher)
/* 298 */           _disposeResolverLater(), (Publisher)this.defaultLoops
/* 299 */           .disposeLater(quietPeriod, timeout), (Publisher)this.defaultProvider
/* 300 */           .disposeLater() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AddressResolverGroup<?> getOrCreateDefaultResolver() {
/* 312 */     AddressResolverGroup<?> resolverGroup = this.defaultResolver.get();
/* 313 */     if (resolverGroup == null) {
/*     */       
/* 315 */       DnsAddressResolverGroup dnsAddressResolverGroup = DEFAULT_NAME_RESOLVER_PROVIDER.newNameResolverGroup(this.defaultLoops, LoopResources.DEFAULT_NATIVE);
/* 316 */       if (!this.defaultResolver.compareAndSet(null, dnsAddressResolverGroup)) {
/* 317 */         dnsAddressResolverGroup.close();
/*     */       }
/* 319 */       resolverGroup = getOrCreateDefaultResolver();
/*     */     } 
/* 321 */     return resolverGroup;
/*     */   }
/*     */   
/*     */   void _disposeResolver() {
/* 325 */     AddressResolverGroup<?> addressResolverGroup = this.defaultResolver.get();
/* 326 */     if (addressResolverGroup != null) {
/* 327 */       addressResolverGroup.close();
/*     */     }
/*     */   }
/*     */   
/*     */   Mono<Void> _disposeResolverLater() {
/* 332 */     Mono<Void> disposeResolver = Mono.empty();
/* 333 */     AddressResolverGroup<?> addressResolverGroup = this.defaultResolver.get();
/* 334 */     if (addressResolverGroup != null) {
/* 335 */       Objects.requireNonNull(addressResolverGroup); disposeResolver = Mono.fromRunnable(addressResolverGroup::close);
/*     */     } 
/* 337 */     return disposeResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <T extends TcpResources> T getOrCreate(AtomicReference<T> ref, @Nullable LoopResources loops, @Nullable ConnectionProvider provider, BiFunction<LoopResources, ConnectionProvider, T> onNew, String name) {
/*     */     TcpResources tcpResources;
/*     */     while (true) {
/* 359 */       tcpResources = (TcpResources)ref.get();
/* 360 */       if (tcpResources == null || loops != null || provider != null) {
/* 361 */         T update = create((T)tcpResources, loops, provider, name, onNew);
/* 362 */         if (ref.compareAndSet((T)tcpResources, update)) {
/* 363 */           if (tcpResources != null) {
/* 364 */             if (loops != null) {
/* 365 */               if (log.isWarnEnabled()) {
/* 366 */                 log.warn("[{}] resources will use a new LoopResources: {}, the previous LoopResources will be disposed", new Object[] { name, loops });
/*     */               }
/*     */               
/* 369 */               tcpResources._disposeResolver();
/* 370 */               tcpResources.defaultLoops.dispose();
/*     */             } 
/* 372 */             if (provider != null) {
/* 373 */               if (log.isWarnEnabled()) {
/* 374 */                 log.warn("[{}] resources will use a new ConnectionProvider: {}, the previous ConnectionProvider will be disposed", new Object[] { name, provider });
/*     */               }
/*     */               
/* 377 */               tcpResources.defaultProvider.dispose();
/*     */             } 
/*     */           } else {
/*     */             
/* 381 */             String loopType = (loops == null) ? "default" : "provided";
/* 382 */             if (log.isDebugEnabled()) {
/* 383 */               log.debug("[{}] resources will use the {} LoopResources: {}", new Object[] { name, loopType, ((TcpResources)update).defaultLoops });
/*     */             }
/* 385 */             String poolType = (provider == null) ? "default" : "provided";
/* 386 */             if (log.isDebugEnabled()) {
/* 387 */               log.debug("[{}] resources will use the {} ConnectionProvider: {}", new Object[] { name, poolType, ((TcpResources)update).defaultProvider });
/*     */             }
/*     */           } 
/* 390 */           return update;
/*     */         } 
/*     */         
/* 393 */         update._dispose(); continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 397 */     return (T)tcpResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends TcpResources> T create(@Nullable T previous, @Nullable LoopResources loops, @Nullable ConnectionProvider provider, String name, BiFunction<LoopResources, ConnectionProvider, T> onNew) {
/* 406 */     if (previous == null) {
/* 407 */       loops = (loops == null) ? LoopResources.create("reactor-" + name) : loops;
/* 408 */       provider = (provider == null) ? ConnectionProvider.create(name, 500) : provider;
/*     */     } else {
/*     */       
/* 411 */       loops = (loops == null) ? ((TcpResources)previous).defaultLoops : loops;
/* 412 */       provider = (provider == null) ? ((TcpResources)previous).defaultProvider : provider;
/*     */     } 
/* 414 */     return onNew.apply(loops, provider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 419 */   static final Logger log = Loggers.getLogger(TcpResources.class);
/*     */   
/*     */   static final BiFunction<LoopResources, ConnectionProvider, TcpResources> ON_TCP_NEW;
/*     */   
/*     */   static final AtomicReference<TcpResources> tcpResources;
/*     */   
/*     */   static {
/* 426 */     DEFAULT_NAME_RESOLVER_PROVIDER = NameResolverProvider.builder().build();
/* 427 */     ON_TCP_NEW = TcpResources::new;
/* 428 */     tcpResources = new AtomicReference<>();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\TcpResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */