/*     */ package reactor.netty.tcp;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import io.netty.handler.ssl.ApplicationProtocolConfig;
/*     */ import io.netty.handler.ssl.CipherSuiteFilter;
/*     */ import io.netty.handler.ssl.IdentityCipherSuiteFilter;
/*     */ import io.netty.handler.ssl.OpenSsl;
/*     */ import io.netty.handler.ssl.SslContext;
/*     */ import io.netty.handler.ssl.SslContextBuilder;
/*     */ import io.netty.handler.ssl.SslHandler;
/*     */ import io.netty.handler.ssl.SslHandshakeCompletionEvent;
/*     */ import io.netty.handler.ssl.SupportedCipherSuiteFilter;
/*     */ import io.netty.util.AsyncMapping;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import javax.net.ssl.SNIServerName;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.SSLParameters;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SslProvider
/*     */ {
/*     */   final SslContext sslContext;
/*     */   final SslContextBuilder sslContextBuilder;
/*     */   final DefaultConfigurationType type;
/*     */   final long handshakeTimeoutMillis;
/*     */   final long closeNotifyFlushTimeoutMillis;
/*     */   final long closeNotifyReadTimeoutMillis;
/*     */   final Consumer<? super SslHandler> handlerConfigurator;
/*     */   final int builderHashCode;
/*     */   final SniProvider sniProvider;
/*     */   final Map<String, SslProvider> confPerDomainName;
/*     */   final AsyncMapping<String, SslProvider> sniMappings;
/*     */   
/*     */   public static SslContextSpec builder() {
/*  73 */     return new Build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslProvider addHandlerConfigurator(SslProvider provider, Consumer<? super SslHandler> handlerConfigurator) {
/*  85 */     Objects.requireNonNull(provider, "provider");
/*  86 */     Objects.requireNonNull(handlerConfigurator, "handlerConfigurator");
/*  87 */     return new SslProvider(provider, handlerConfigurator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static SslProvider updateDefaultConfiguration(SslProvider provider, DefaultConfigurationType type) {
/*  97 */     Objects.requireNonNull(provider, "provider");
/*  98 */     Objects.requireNonNull(type, "type");
/*  99 */     return new SslProvider(provider, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SslProvider defaultClientProvider() {
/* 108 */     return TcpClientSecure.DEFAULT_SSL_PROVIDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public enum DefaultConfigurationType
/*     */   {
/* 291 */     NONE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 296 */     TCP,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     H2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SslProvider(Build builder) {
/* 363 */     this.sslContextBuilder = builder.sslCtxBuilder;
/* 364 */     this.type = builder.type;
/* 365 */     if (builder.sslContext == null) {
/* 366 */       if (this.sslContextBuilder != null) {
/* 367 */         if (this.type != null) {
/* 368 */           updateDefaultConfiguration();
/*     */         }
/*     */         try {
/* 371 */           this.sslContext = this.sslContextBuilder.build();
/*     */         }
/* 373 */         catch (SSLException e) {
/* 374 */           throw Exceptions.propagate(e);
/*     */         }
/*     */       
/* 377 */       } else if (builder.protocolSslContextSpec != null) {
/*     */         try {
/* 379 */           this.sslContext = builder.protocolSslContextSpec.sslContext();
/*     */         }
/* 381 */         catch (SSLException e) {
/* 382 */           throw Exceptions.propagate(e);
/*     */         } 
/*     */       } else {
/*     */         
/* 386 */         throw new IllegalArgumentException("Neither SslContextBuilder nor SslContext is specified");
/*     */       } 
/*     */     } else {
/*     */       
/* 390 */       this.sslContext = builder.sslContext;
/*     */     } 
/* 392 */     if (builder.serverNames != null) {
/* 393 */       Consumer<SslHandler> configurator = h -> {
/*     */           SSLEngine engine = h.engine();
/*     */           
/*     */           SSLParameters sslParameters = engine.getSSLParameters();
/*     */           sslParameters.setServerNames(builder.serverNames);
/*     */           engine.setSSLParameters(sslParameters);
/*     */         };
/* 400 */       this
/* 401 */         .handlerConfigurator = (builder.handlerConfigurator == null) ? configurator : configurator.andThen(builder.handlerConfigurator);
/*     */     } else {
/*     */       
/* 404 */       this.handlerConfigurator = builder.handlerConfigurator;
/*     */     } 
/* 406 */     this.handshakeTimeoutMillis = builder.handshakeTimeoutMillis;
/* 407 */     this.closeNotifyFlushTimeoutMillis = builder.closeNotifyFlushTimeoutMillis;
/* 408 */     this.closeNotifyReadTimeoutMillis = builder.closeNotifyReadTimeoutMillis;
/* 409 */     this.builderHashCode = builder.hashCode();
/* 410 */     this.confPerDomainName = builder.confPerDomainName;
/* 411 */     this.sniMappings = builder.sniMappings;
/* 412 */     if (!this.confPerDomainName.isEmpty()) {
/* 413 */       if (this.type != null) {
/* 414 */         this.sniProvider = updateAllSslProviderConfiguration(this.confPerDomainName, this, this.type);
/*     */       } else {
/*     */         
/* 417 */         this.sniProvider = new SniProvider(this.confPerDomainName, this);
/*     */       }
/*     */     
/* 420 */     } else if (this.sniMappings != null) {
/* 421 */       this.sniProvider = new SniProvider(this.sniMappings);
/*     */     } else {
/*     */       
/* 424 */       this.sniProvider = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   SslProvider(SslProvider from, Consumer<? super SslHandler> handlerConfigurator) {
/* 429 */     this.sslContext = from.sslContext;
/* 430 */     this.sslContextBuilder = from.sslContextBuilder;
/* 431 */     this.type = from.type;
/* 432 */     if (from.handlerConfigurator == null) {
/* 433 */       this.handlerConfigurator = handlerConfigurator;
/*     */     } else {
/*     */       
/* 436 */       this.handlerConfigurator = (h -> {
/*     */           handlerConfigurator.accept(h);
/*     */           from.handlerConfigurator.accept(h);
/*     */         });
/*     */     } 
/* 441 */     this.handshakeTimeoutMillis = from.handshakeTimeoutMillis;
/* 442 */     this.closeNotifyFlushTimeoutMillis = from.closeNotifyFlushTimeoutMillis;
/* 443 */     this.closeNotifyReadTimeoutMillis = from.closeNotifyReadTimeoutMillis;
/* 444 */     this.builderHashCode = from.builderHashCode;
/* 445 */     this.confPerDomainName = from.confPerDomainName;
/* 446 */     this.sniMappings = from.sniMappings;
/* 447 */     this.sniProvider = from.sniProvider;
/*     */   }
/*     */   
/*     */   SslProvider(SslProvider from, DefaultConfigurationType type) {
/* 451 */     this.sslContextBuilder = from.sslContextBuilder;
/* 452 */     this.type = type;
/* 453 */     if (this.sslContextBuilder != null) {
/* 454 */       updateDefaultConfiguration();
/*     */       try {
/* 456 */         this.sslContext = this.sslContextBuilder.build();
/*     */       }
/* 458 */       catch (SSLException e) {
/* 459 */         throw Exceptions.propagate(e);
/*     */       } 
/*     */     } else {
/*     */       
/* 463 */       this.sslContext = from.sslContext;
/*     */     } 
/* 465 */     this.handlerConfigurator = from.handlerConfigurator;
/* 466 */     this.handshakeTimeoutMillis = from.handshakeTimeoutMillis;
/* 467 */     this.closeNotifyFlushTimeoutMillis = from.closeNotifyFlushTimeoutMillis;
/* 468 */     this.closeNotifyReadTimeoutMillis = from.closeNotifyReadTimeoutMillis;
/* 469 */     this.builderHashCode = from.builderHashCode;
/* 470 */     this.confPerDomainName = from.confPerDomainName;
/* 471 */     this.sniMappings = from.sniMappings;
/* 472 */     if (from.sniProvider != null) {
/* 473 */       if (!this.confPerDomainName.isEmpty()) {
/* 474 */         this.sniProvider = updateAllSslProviderConfiguration(this.confPerDomainName, this, type);
/*     */       } else {
/*     */         
/* 477 */         this.sniProvider = new SniProvider(this.sniMappings);
/*     */       } 
/*     */     } else {
/*     */       
/* 481 */       this.sniProvider = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   SniProvider updateAllSslProviderConfiguration(Map<String, SslProvider> confPerDomainName, SslProvider defaultSslProvider, DefaultConfigurationType type) {
/* 487 */     Map<String, SslProvider> config = new HashMap<>();
/* 488 */     confPerDomainName.forEach((s, sslProvider) -> (SslProvider)config.put(s, updateDefaultConfiguration(sslProvider, type)));
/*     */     
/* 490 */     return new SniProvider(config, defaultSslProvider);
/*     */   }
/*     */   
/*     */   void updateDefaultConfiguration() {
/* 494 */     switch (this.type) {
/*     */       case H2:
/* 496 */         this.sslContextBuilder.sslProvider(
/* 497 */             io.netty.handler.ssl.SslProvider.isAlpnSupported(io.netty.handler.ssl.SslProvider.OPENSSL) ? 
/* 498 */             io.netty.handler.ssl.SslProvider.OPENSSL : 
/* 499 */             io.netty.handler.ssl.SslProvider.JDK)
/* 500 */           .ciphers(HTTP2_CIPHERS, (CipherSuiteFilter)SupportedCipherSuiteFilter.INSTANCE)
/* 501 */           .applicationProtocolConfig(new ApplicationProtocolConfig(ApplicationProtocolConfig.Protocol.ALPN, ApplicationProtocolConfig.SelectorFailureBehavior.NO_ADVERTISE, ApplicationProtocolConfig.SelectedListenerFailureBehavior.ACCEPT, new String[] { "h2", "http/1.1" }));
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case TCP:
/* 509 */         this.sslContextBuilder.sslProvider(
/* 510 */             OpenSsl.isAvailable() ? 
/* 511 */             io.netty.handler.ssl.SslProvider.OPENSSL : 
/* 512 */             io.netty.handler.ssl.SslProvider.JDK)
/* 513 */           .ciphers(null, (CipherSuiteFilter)IdentityCipherSuiteFilter.INSTANCE)
/* 514 */           .applicationProtocolConfig(null);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SslContext getSslContext() {
/* 527 */     return this.sslContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DefaultConfigurationType getDefaultConfigurationType() {
/* 537 */     return this.type;
/*     */   }
/*     */   
/*     */   public void configure(SslHandler sslHandler) {
/* 541 */     Objects.requireNonNull(sslHandler, "sslHandler");
/* 542 */     sslHandler.setHandshakeTimeoutMillis(this.handshakeTimeoutMillis);
/* 543 */     sslHandler.setCloseNotifyFlushTimeoutMillis(this.closeNotifyFlushTimeoutMillis);
/* 544 */     sslHandler.setCloseNotifyReadTimeoutMillis(this.closeNotifyReadTimeoutMillis);
/* 545 */     if (this.handlerConfigurator != null)
/* 546 */       this.handlerConfigurator.accept(sslHandler); 
/*     */   }
/*     */   
/*     */   public void addSslHandler(Channel channel, @Nullable SocketAddress remoteAddress, boolean sslDebug) {
/*     */     SslHandler sslHandler;
/* 551 */     Objects.requireNonNull(channel, "channel");
/* 552 */     if (this.sniProvider != null) {
/* 553 */       this.sniProvider.addSniHandler(channel, sslDebug);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 559 */     if (remoteAddress instanceof InetSocketAddress) {
/* 560 */       InetSocketAddress sniInfo = (InetSocketAddress)remoteAddress;
/*     */       
/* 562 */       sslHandler = getSslContext().newHandler(channel.alloc(), sniInfo.getHostString(), sniInfo.getPort());
/*     */       
/* 564 */       if (log.isDebugEnabled()) {
/* 565 */         log.debug(ReactorNetty.format(channel, "SSL enabled using engine {} and SNI {}"), new Object[] { sslHandler.engine(), sniInfo });
/*     */       }
/*     */     } else {
/*     */       
/* 569 */       sslHandler = getSslContext().newHandler(channel.alloc());
/*     */       
/* 571 */       if (log.isDebugEnabled()) {
/* 572 */         log.debug(ReactorNetty.format(channel, "SSL enabled using engine {}"), new Object[] { sslHandler.engine() });
/*     */       }
/*     */     } 
/*     */     
/* 576 */     configure(sslHandler);
/*     */     
/* 578 */     ChannelPipeline pipeline = channel.pipeline();
/* 579 */     if (pipeline.get("reactor.left.proxyHandler") != null) {
/* 580 */       pipeline.addAfter("reactor.left.proxyHandler", "reactor.left.sslHandler", (ChannelHandler)sslHandler);
/*     */     }
/* 582 */     else if (pipeline.get("reactor.left.nonSslRedirectDetector") != null) {
/* 583 */       pipeline.addAfter("reactor.left.nonSslRedirectDetector", "reactor.left.sslHandler", (ChannelHandler)sslHandler);
/*     */     } else {
/*     */       
/* 586 */       pipeline.addFirst("reactor.left.sslHandler", (ChannelHandler)sslHandler);
/*     */     } 
/*     */     
/* 589 */     addSslReadHandler(pipeline, sslDebug);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 594 */     return "SslProvider {type=" + this.type + ", handshakeTimeoutMillis=" + this.handshakeTimeoutMillis + ", closeNotifyFlushTimeoutMillis=" + this.closeNotifyFlushTimeoutMillis + ", closeNotifyReadTimeoutMillis=" + this.closeNotifyReadTimeoutMillis + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 604 */     if (this == o) {
/* 605 */       return true;
/*     */     }
/* 607 */     if (o == null || getClass() != o.getClass()) {
/* 608 */       return false;
/*     */     }
/* 610 */     SslProvider that = (SslProvider)o;
/* 611 */     return (this.builderHashCode == that.builderHashCode);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 616 */     return this.builderHashCode;
/*     */   }
/*     */   
/*     */   static void addSslReadHandler(ChannelPipeline pipeline, boolean sslDebug) {
/* 620 */     if (pipeline.get("reactor.left.loggingHandler") != null) {
/* 621 */       pipeline.addAfter("reactor.left.loggingHandler", "reactor.left.sslReader", (ChannelHandler)new SslReadHandler());
/* 622 */       if (sslDebug) {
/* 623 */         pipeline.addBefore("reactor.left.sslHandler", "reactor.left.sslLoggingHandler", (ChannelHandler)LOGGING_HANDLER);
/*     */       }
/*     */     } else {
/*     */       
/* 627 */       pipeline.addAfter("reactor.left.sslHandler", "reactor.left.sslReader", (ChannelHandler)new SslReadHandler());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Build
/*     */     implements SslContextSpec, DefaultConfigurationSpec, Builder
/*     */   {
/* 637 */     static final long DEFAULT_SSL_HANDSHAKE_TIMEOUT = Long.parseLong(System.getProperty("reactor.netty.tcp.sslHandshakeTimeout", "10000"));
/*     */     
/*     */     SslContextBuilder sslCtxBuilder;
/*     */     
/*     */     SslProvider.ProtocolSslContextSpec protocolSslContextSpec;
/*     */     
/*     */     SslProvider.DefaultConfigurationType type;
/*     */     SslContext sslContext;
/*     */     Consumer<? super SslHandler> handlerConfigurator;
/* 646 */     long handshakeTimeoutMillis = DEFAULT_SSL_HANDSHAKE_TIMEOUT;
/* 647 */     long closeNotifyFlushTimeoutMillis = 3000L;
/*     */     long closeNotifyReadTimeoutMillis;
/*     */     List<SNIServerName> serverNames;
/* 650 */     final Map<String, SslProvider> confPerDomainName = new HashMap<>();
/*     */ 
/*     */     
/*     */     AsyncMapping<String, SslProvider> sniMappings;
/*     */ 
/*     */     
/*     */     public SslProvider.Builder sslContext(SslProvider.ProtocolSslContextSpec protocolSslContextSpec) {
/* 657 */       this.protocolSslContextSpec = protocolSslContextSpec;
/* 658 */       this.type = SslProvider.DefaultConfigurationType.NONE;
/* 659 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder sslContext(SslContext sslContext) {
/* 664 */       this.sslContext = Objects.<SslContext>requireNonNull(sslContext, "sslContext");
/* 665 */       this.type = SslProvider.DefaultConfigurationType.NONE;
/* 666 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final SslProvider.DefaultConfigurationSpec sslContext(SslContextBuilder sslCtxBuilder) {
/* 671 */       this.sslCtxBuilder = Objects.<SslContextBuilder>requireNonNull(sslCtxBuilder, "sslCtxBuilder");
/* 672 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder defaultConfiguration(SslProvider.DefaultConfigurationType type) {
/* 679 */       this.type = Objects.<SslProvider.DefaultConfigurationType>requireNonNull(type, "type");
/* 680 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder handshakeTimeout(Duration handshakeTimeout) {
/* 687 */       Objects.requireNonNull(handshakeTimeout, "handshakeTimeout");
/* 688 */       return handshakeTimeoutMillis(handshakeTimeout.toMillis());
/*     */     }
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder handlerConfigurator(Consumer<? super SslHandler> handlerConfigurator) {
/* 693 */       Objects.requireNonNull(handlerConfigurator, "handshakeTimeout");
/* 694 */       this.handlerConfigurator = handlerConfigurator;
/* 695 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder handshakeTimeoutMillis(long handshakeTimeoutMillis) {
/* 700 */       if (handshakeTimeoutMillis < 0L) {
/* 701 */         throw new IllegalArgumentException("ssl handshake timeout must be positive was: " + handshakeTimeoutMillis);
/*     */       }
/*     */       
/* 704 */       this.handshakeTimeoutMillis = handshakeTimeoutMillis;
/* 705 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder closeNotifyFlushTimeout(Duration closeNotifyFlushTimeout) {
/* 710 */       Objects.requireNonNull(closeNotifyFlushTimeout, "closeNotifyFlushTimeout");
/* 711 */       return closeNotifyFlushTimeoutMillis(closeNotifyFlushTimeout.toMillis());
/*     */     }
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder closeNotifyFlushTimeoutMillis(long closeNotifyFlushTimeoutMillis) {
/* 716 */       if (closeNotifyFlushTimeoutMillis < 0L) {
/* 717 */         throw new IllegalArgumentException("ssl close_notify flush timeout must be positive, was: " + closeNotifyFlushTimeoutMillis);
/*     */       }
/*     */       
/* 720 */       this.closeNotifyFlushTimeoutMillis = closeNotifyFlushTimeoutMillis;
/* 721 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder closeNotifyReadTimeout(Duration closeNotifyReadTimeout) {
/* 726 */       Objects.requireNonNull(closeNotifyReadTimeout, "closeNotifyReadTimeout");
/* 727 */       return closeNotifyReadTimeoutMillis(closeNotifyReadTimeout.toMillis());
/*     */     }
/*     */ 
/*     */     
/*     */     public final SslProvider.Builder closeNotifyReadTimeoutMillis(long closeNotifyReadTimeoutMillis) {
/* 732 */       if (closeNotifyReadTimeoutMillis < 0L) {
/* 733 */         throw new IllegalArgumentException("ssl close_notify read timeout must be positive, was: " + closeNotifyReadTimeoutMillis);
/*     */       }
/*     */       
/* 736 */       this.closeNotifyReadTimeoutMillis = closeNotifyReadTimeoutMillis;
/* 737 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SslProvider.Builder addSniMapping(String domainName, Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder) {
/* 742 */       addInternal(domainName, sslProviderBuilder);
/* 743 */       this.sniMappings = null;
/* 744 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SslProvider.Builder addSniMappings(Map<String, Consumer<? super SslProvider.SslContextSpec>> confPerDomainName) {
/* 749 */       Objects.requireNonNull(confPerDomainName);
/* 750 */       confPerDomainName.forEach(this::addInternal);
/* 751 */       this.sniMappings = null;
/* 752 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SslProvider.Builder setSniMappings(Map<String, Consumer<? super SslProvider.SslContextSpec>> confPerDomainName) {
/* 757 */       Objects.requireNonNull(confPerDomainName);
/* 758 */       this.confPerDomainName.clear();
/* 759 */       confPerDomainName.forEach(this::addInternal);
/* 760 */       this.sniMappings = null;
/* 761 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SslProvider.Builder setSniAsyncMappings(AsyncMapping<String, SslProvider> mappings) {
/* 766 */       this.sniMappings = Objects.<AsyncMapping<String, SslProvider>>requireNonNull(mappings);
/* 767 */       this.confPerDomainName.clear();
/* 768 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SslProvider.Builder serverNames(SNIServerName... serverNames) {
/* 773 */       Objects.requireNonNull(serverNames);
/* 774 */       this.serverNames = Arrays.asList(serverNames);
/* 775 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SslProvider build() {
/* 780 */       return new SslProvider(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 785 */       if (this == o) {
/* 786 */         return true;
/*     */       }
/* 788 */       if (!(o instanceof Build)) {
/* 789 */         return false;
/*     */       }
/* 791 */       Build build = (Build)o;
/* 792 */       return (this.handshakeTimeoutMillis == build.handshakeTimeoutMillis && this.closeNotifyFlushTimeoutMillis == build.closeNotifyFlushTimeoutMillis && this.closeNotifyReadTimeoutMillis == build.closeNotifyReadTimeoutMillis && 
/*     */ 
/*     */         
/* 795 */         Objects.equals(this.sslCtxBuilder, build.sslCtxBuilder) && this.type == build.type && 
/*     */         
/* 797 */         Objects.equals(this.sslContext, build.sslContext) && 
/* 798 */         Objects.equals(this.handlerConfigurator, build.handlerConfigurator) && 
/* 799 */         Objects.equals(this.serverNames, build.serverNames) && this.confPerDomainName
/* 800 */         .equals(build.confPerDomainName) && 
/* 801 */         Objects.equals(this.protocolSslContextSpec, build.protocolSslContextSpec));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 806 */       int result = 1;
/* 807 */       result = 31 * result + Objects.hashCode(this.sslCtxBuilder);
/* 808 */       result = 31 * result + Objects.hashCode(this.type);
/* 809 */       result = 31 * result + Objects.hashCode(this.sslContext);
/* 810 */       result = 31 * result + Objects.hashCode(this.handlerConfigurator);
/* 811 */       result = 31 * result + Long.hashCode(this.handshakeTimeoutMillis);
/* 812 */       result = 31 * result + Long.hashCode(this.closeNotifyFlushTimeoutMillis);
/* 813 */       result = 31 * result + Long.hashCode(this.closeNotifyReadTimeoutMillis);
/* 814 */       result = 31 * result + Objects.hashCode(this.serverNames);
/* 815 */       result = 31 * result + Objects.hashCode(this.confPerDomainName);
/* 816 */       result = 31 * result + Objects.hashCode(this.protocolSslContextSpec);
/* 817 */       return result;
/*     */     }
/*     */     
/*     */     void addInternal(String domainName, Consumer<? super SslProvider.SslContextSpec> sslProviderBuilder) {
/* 821 */       Objects.requireNonNull(domainName, "domainName");
/* 822 */       Objects.requireNonNull(sslProviderBuilder, "sslProviderBuilder");
/* 823 */       SslProvider.SslContextSpec builder = SslProvider.builder();
/* 824 */       sslProviderBuilder.accept(builder);
/* 825 */       this.confPerDomainName.put(domainName, ((SslProvider.Builder)builder).build());
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SslReadHandler
/*     */     extends ChannelInboundHandlerAdapter {
/*     */     boolean handshakeDone;
/*     */     
/*     */     public void channelActive(ChannelHandlerContext ctx) {
/* 834 */       ctx.read();
/*     */     }
/*     */ 
/*     */     
/*     */     public void channelReadComplete(ChannelHandlerContext ctx) {
/* 839 */       if (!this.handshakeDone) {
/* 840 */         ctx.read();
/*     */       }
/* 842 */       ctx.fireChannelReadComplete();
/*     */     }
/*     */ 
/*     */     
/*     */     public void userEventTriggered(ChannelHandlerContext ctx, Object evt) {
/* 847 */       if (evt instanceof SslHandshakeCompletionEvent) {
/* 848 */         this.handshakeDone = true;
/* 849 */         if (ctx.pipeline()
/* 850 */           .context((ChannelHandler)this) != null) {
/* 851 */           ctx.pipeline()
/* 852 */             .remove((ChannelHandler)this);
/*     */         }
/* 854 */         SslHandshakeCompletionEvent handshake = (SslHandshakeCompletionEvent)evt;
/* 855 */         if (handshake.isSuccess()) {
/* 856 */           ctx.fireChannelActive();
/*     */         } else {
/*     */           
/* 859 */           ctx.fireExceptionCaught(handshake.cause());
/*     */         } 
/*     */       } 
/* 862 */       ctx.fireUserEventTriggered(evt);
/*     */     }
/*     */   }
/*     */   
/* 866 */   static final Logger log = Loggers.getLogger(SslProvider.class);
/*     */   
/* 868 */   static final LoggingHandler LOGGING_HANDLER = AdvancedByteBufFormat.HEX_DUMP
/*     */     
/* 870 */     .toLoggingHandler("reactor.netty.tcp.ssl", LogLevel.DEBUG, Charset.defaultCharset());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 879 */   static final List<String> HTTP2_CIPHERS = Collections.unmodifiableList(Arrays.asList(new String[] { "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256", "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256", "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384", "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384", "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256", "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256", "TLS_AES_128_GCM_SHA256", "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256" }));
/*     */   
/*     */   public static interface ProtocolSslContextSpec {
/*     */     ProtocolSslContextSpec configure(Consumer<SslContextBuilder> param1Consumer);
/*     */     
/*     */     SslContext sslContext() throws SSLException;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static interface DefaultConfigurationSpec {
/*     */     SslProvider.Builder defaultConfiguration(SslProvider.DefaultConfigurationType param1DefaultConfigurationType);
/*     */   }
/*     */   
/*     */   public static interface SslContextSpec {
/*     */     SslProvider.Builder sslContext(SslProvider.ProtocolSslContextSpec param1ProtocolSslContextSpec);
/*     */     
/*     */     SslProvider.Builder sslContext(SslContext param1SslContext);
/*     */     
/*     */     @Deprecated
/*     */     SslProvider.DefaultConfigurationSpec sslContext(SslContextBuilder param1SslContextBuilder);
/*     */   }
/*     */   
/*     */   public static interface Builder {
/*     */     Builder handlerConfigurator(Consumer<? super SslHandler> param1Consumer);
/*     */     
/*     */     Builder handshakeTimeout(Duration param1Duration);
/*     */     
/*     */     Builder handshakeTimeoutMillis(long param1Long);
/*     */     
/*     */     Builder closeNotifyFlushTimeout(Duration param1Duration);
/*     */     
/*     */     Builder closeNotifyFlushTimeoutMillis(long param1Long);
/*     */     
/*     */     Builder closeNotifyReadTimeout(Duration param1Duration);
/*     */     
/*     */     Builder closeNotifyReadTimeoutMillis(long param1Long);
/*     */     
/*     */     Builder addSniMapping(String param1String, Consumer<? super SslProvider.SslContextSpec> param1Consumer);
/*     */     
/*     */     Builder addSniMappings(Map<String, Consumer<? super SslProvider.SslContextSpec>> param1Map);
/*     */     
/*     */     Builder setSniMappings(Map<String, Consumer<? super SslProvider.SslContextSpec>> param1Map);
/*     */     
/*     */     Builder setSniAsyncMappings(AsyncMapping<String, SslProvider> param1AsyncMapping);
/*     */     
/*     */     Builder serverNames(SNIServerName... param1VarArgs);
/*     */     
/*     */     SslProvider build();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\tcp\SslProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */