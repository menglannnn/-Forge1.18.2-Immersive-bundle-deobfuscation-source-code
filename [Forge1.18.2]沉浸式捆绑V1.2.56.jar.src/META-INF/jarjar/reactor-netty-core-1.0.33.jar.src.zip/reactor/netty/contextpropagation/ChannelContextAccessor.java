/*    */ package reactor.netty.contextpropagation;
/*    */ 
/*    */ import io.micrometer.context.ContextAccessor;
/*    */ import io.netty.channel.Channel;
/*    */ import java.util.Map;
/*    */ import java.util.function.Predicate;
/*    */ import reactor.netty.ReactorNetty;
/*    */ import reactor.util.annotation.Nullable;
/*    */ import reactor.util.context.Context;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChannelContextAccessor
/*    */   implements ContextAccessor<Channel, Channel>
/*    */ {
/*    */   public Class<? extends Channel> readableType() {
/* 43 */     return Channel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void readValues(Channel sourceContext, Predicate<Object> keyPredicate, Map<Object, Object> readValues) {
/* 48 */     ContextView contextView = ReactorNetty.getChannelContext(sourceContext);
/* 49 */     if (contextView != null) {
/* 50 */       contextView.forEach((k, v) -> {
/*    */             if (keyPredicate.test(k)) {
/*    */               readValues.put(k, v);
/*    */             }
/*    */           });
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T readValue(Channel sourceContext, Object key) {
/* 62 */     ContextView contextView = ReactorNetty.getChannelContext(sourceContext);
/* 63 */     if (contextView != null) {
/* 64 */       return (T)contextView.getOrDefault(key, null);
/*    */     }
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<? extends Channel> writeableType() {
/* 71 */     return Channel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Channel writeValues(Map<Object, Object> valuesToWrite, Channel targetContext) {
/* 76 */     if (!valuesToWrite.isEmpty()) {
/* 77 */       ContextView contextView = ReactorNetty.getChannelContext(targetContext);
/* 78 */       ReactorNetty.setChannelContext(targetContext, (contextView != null) ? 
/* 79 */           (ContextView)Context.of(contextView).putAllMap(valuesToWrite) : (ContextView)Context.of(valuesToWrite));
/*    */     } 
/* 81 */     return targetContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\contextpropagation\ChannelContextAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */