/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ContextAwareChannelMetricsRecorder
/*     */   implements ChannelMetricsRecorder
/*     */ {
/*     */   public abstract void incrementErrorsCount(ContextView paramContextView, SocketAddress paramSocketAddress);
/*     */   
/*     */   public abstract void recordConnectTime(ContextView paramContextView, SocketAddress paramSocketAddress, Duration paramDuration, String paramString);
/*     */   
/*     */   public abstract void recordDataReceived(ContextView paramContextView, SocketAddress paramSocketAddress, long paramLong);
/*     */   
/*     */   public abstract void recordDataSent(ContextView paramContextView, SocketAddress paramSocketAddress, long paramLong);
/*     */   
/*     */   public abstract void recordTlsHandshakeTime(ContextView paramContextView, SocketAddress paramSocketAddress, Duration paramDuration, String paramString);
/*     */   
/*     */   public void incrementErrorsCount(SocketAddress remoteAddress) {
/*  81 */     incrementErrorsCount((ContextView)Context.empty(), remoteAddress);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordConnectTime(SocketAddress remoteAddress, Duration time, String status) {
/*  86 */     recordConnectTime((ContextView)Context.empty(), remoteAddress, time, status);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataReceived(SocketAddress remoteAddress, long bytes) {
/*  91 */     recordDataReceived((ContextView)Context.empty(), remoteAddress, bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataSent(SocketAddress remoteAddress, long bytes) {
/*  96 */     recordDataSent((ContextView)Context.empty(), remoteAddress, bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordTlsHandshakeTime(SocketAddress remoteAddress, Duration time, String status) {
/* 101 */     recordTlsHandshakeTime((ContextView)Context.empty(), remoteAddress, time, status);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\ContextAwareChannelMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */