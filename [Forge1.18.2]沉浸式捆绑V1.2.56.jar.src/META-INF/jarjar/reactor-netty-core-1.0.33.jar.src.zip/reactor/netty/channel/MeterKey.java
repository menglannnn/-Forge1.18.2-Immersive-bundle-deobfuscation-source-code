/*    */ package reactor.netty.channel;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MeterKey
/*    */ {
/*    */   private final String uri;
/*    */   private final String remoteAddress;
/*    */   private final String method;
/*    */   private final String status;
/*    */   
/*    */   public MeterKey(@Nullable String uri, @Nullable String remoteAddress, @Nullable String method, @Nullable String status) {
/* 37 */     this.uri = uri;
/* 38 */     this.remoteAddress = remoteAddress;
/* 39 */     this.method = method;
/* 40 */     this.status = status;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 45 */     if (this == o) {
/* 46 */       return true;
/*    */     }
/* 48 */     if (o == null || getClass() != o.getClass()) {
/* 49 */       return false;
/*    */     }
/* 51 */     MeterKey meterKey = (MeterKey)o;
/* 52 */     return (Objects.equals(this.uri, meterKey.uri) && 
/* 53 */       Objects.equals(this.remoteAddress, meterKey.remoteAddress) && 
/* 54 */       Objects.equals(this.method, meterKey.method) && 
/* 55 */       Objects.equals(this.status, meterKey.status));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 60 */     int result = 1;
/* 61 */     result = 31 * result + Objects.hashCode(this.uri);
/* 62 */     result = 31 * result + Objects.hashCode(this.remoteAddress);
/* 63 */     result = 31 * result + Objects.hashCode(this.method);
/* 64 */     result = 31 * result + Objects.hashCode(this.status);
/* 65 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\MeterKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */