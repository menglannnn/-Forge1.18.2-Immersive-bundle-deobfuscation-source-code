/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.netty.ByteBufFlux;
/*     */ import reactor.netty.ChannelOperationsId;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.DisposableChannel;
/*     */ import reactor.netty.FutureMono;
/*     */ import reactor.netty.NettyInbound;
/*     */ import reactor.netty.NettyOutbound;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelOperations<INBOUND extends NettyInbound, OUTBOUND extends NettyOutbound>
/*     */   implements NettyInbound, NettyOutbound, Connection, CoreSubscriber<Void>, ChannelOperationsId
/*     */ {
/*     */   final Connection connection;
/*     */   final FluxReceive inbound;
/*     */   final ConnectionObserver listener;
/*     */   final Sinks.Empty<Void> onTerminate;
/*     */   final String shortId;
/*     */   volatile Subscription outboundSubscription;
/*     */   boolean localActive;
/*     */   String longId;
/*     */   
/*     */   public static void addReactiveBridge(Channel ch, OnSetup opsFactory, ConnectionObserver listener) {
/*  76 */     Objects.requireNonNull(ch, "channel");
/*  77 */     Objects.requireNonNull(opsFactory, "opsFactory");
/*  78 */     Objects.requireNonNull(listener, "listener");
/*  79 */     ch.pipeline()
/*  80 */       .addLast("reactor.right.reactiveBridge", (ChannelHandler)new ChannelOperationsHandler(opsFactory, listener));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addMetricsHandler(Channel ch, ChannelMetricsRecorder recorder, @Nullable SocketAddress remoteAddress, boolean onServer) {
/*  93 */     Objects.requireNonNull(ch, "channel");
/*  94 */     Objects.requireNonNull(recorder, "recorder");
/*  95 */     SocketAddress remote = remoteAddress;
/*  96 */     if (remote == null) {
/*  97 */       remote = ch.remoteAddress();
/*     */     }
/*     */ 
/*     */     
/* 101 */     ChannelHandler handler = (recorder instanceof ContextAwareChannelMetricsRecorder) ? (ChannelHandler)new ContextAwareChannelMetricsHandler((ContextAwareChannelMetricsRecorder)recorder, remote, onServer) : (ChannelHandler)new ChannelMetricsHandler(recorder, remote, onServer);
/* 102 */     ch.pipeline()
/* 103 */       .addFirst("reactor.left.channelMetricsHandler", handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static ChannelOperations<?, ?> get(Channel ch) {
/* 115 */     return (ChannelOperations<?, ?>)Connection.from(ch)
/* 116 */       .as(ChannelOperations.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ChannelOperations(ChannelOperations<INBOUND, OUTBOUND> replaced) {
/* 131 */     this.connection = replaced.connection;
/* 132 */     this.listener = replaced.listener;
/* 133 */     this.onTerminate = replaced.onTerminate;
/* 134 */     this.inbound = new FluxReceive(this);
/* 135 */     this.shortId = replaced.shortId;
/* 136 */     this.longId = replaced.longId;
/* 137 */     this.localActive = replaced.localActive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelOperations(Connection connection, ConnectionObserver listener) {
/* 147 */     this.connection = Objects.<Connection>requireNonNull(connection, "connection");
/* 148 */     this.listener = Objects.<ConnectionObserver>requireNonNull(listener, "listener");
/* 149 */     this.onTerminate = Sinks.unsafe().empty();
/* 150 */     this.inbound = new FluxReceive(this);
/* 151 */     this.shortId = initShortId();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T extends Connection> T as(Class<T> clazz) {
/* 157 */     if (clazz == ChannelOperations.class)
/*     */     {
/* 159 */       return (T)this;
/*     */     }
/*     */     
/* 162 */     return (T)super.as(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBufAllocator alloc() {
/* 167 */     return this.connection.channel()
/* 168 */       .alloc();
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyInbound inbound() {
/* 173 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyOutbound outbound() {
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Channel channel() {
/* 183 */     return this.connection.channel();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelOperations<INBOUND, OUTBOUND> withConnection(Consumer<? super Connection> withConnection) {
/* 188 */     Objects.requireNonNull(withConnection, "withConnection");
/* 189 */     withConnection.accept(this);
/* 190 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 195 */     if (log.isTraceEnabled()) {
/* 196 */       log.trace(ReactorNetty.format(channel(), "Disposing ChannelOperation from a channel"), new Exception("ChannelOperation dispose stack"));
/*     */     }
/*     */     
/* 199 */     OUTBOUND_CLOSE.set(this, Operators.cancelledSubscription());
/* 200 */     if (!this.inbound.isDisposed()) {
/* 201 */       discard();
/*     */     }
/* 203 */     this.connection.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   public CoreSubscriber<Void> disposeSubscriber() {
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isDisposed() {
/* 213 */     return (!channel().isActive() || isSubscriptionDisposed());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSubscriptionDisposed() {
/* 222 */     return (OUTBOUND_CLOSE.get(this) == Operators.cancelledSubscription());
/*     */   }
/*     */ 
/*     */   
/*     */   public final Mono<Void> onDispose() {
/* 227 */     return this.connection.onDispose();
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection onDispose(Disposable onDispose) {
/* 232 */     this.connection.onDispose(onDispose);
/* 233 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onComplete() {
/* 238 */     if (isDisposed()) {
/*     */       return;
/*     */     }
/* 241 */     OUTBOUND_CLOSE.set(this, Operators.cancelledSubscription());
/* 242 */     onOutboundComplete();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void onError(Throwable t) {
/* 247 */     if (isDisposed()) {
/* 248 */       if (log.isDebugEnabled()) {
/* 249 */         log.debug(ReactorNetty.format(channel(), "An outbound error could not be processed"), t);
/*     */       }
/*     */       return;
/*     */     } 
/* 253 */     OUTBOUND_CLOSE.set(this, Operators.cancelledSubscription());
/* 254 */     onOutboundError(t);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void onNext(Void aVoid) {}
/*     */ 
/*     */   
/*     */   public final void onSubscribe(Subscription s) {
/* 263 */     if (Operators.setOnce(OUTBOUND_CLOSE, this, s)) {
/* 264 */       s.request(Long.MAX_VALUE);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<?> receiveObject() {
/* 270 */     return this.inbound;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBufFlux receive() {
/* 275 */     return ByteBufFlux.fromInbound((Publisher)receiveObject(), this.connection.channel()
/* 276 */         .alloc());
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyOutbound send(Publisher<? extends ByteBuf> dataStream, Predicate<ByteBuf> predicate) {
/* 281 */     Objects.requireNonNull(predicate, "predicate");
/* 282 */     if (!channel().isActive()) {
/* 283 */       return then((Publisher)Mono.error(AbortedException.beforeSend()));
/*     */     }
/* 285 */     if (dataStream instanceof Mono) {
/* 286 */       return then((Publisher)((Mono)dataStream).flatMap(m -> FutureMono.from((Future)channel().writeAndFlush(m)))
/* 287 */           .doOnDiscard(ByteBuf.class, ReferenceCounted::release));
/*     */     }
/* 289 */     return then((Publisher)MonoSendMany.byteBufSource(dataStream, channel(), predicate));
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyOutbound sendObject(Publisher<?> dataStream, Predicate<Object> predicate) {
/* 294 */     Objects.requireNonNull(predicate, "predicate");
/* 295 */     if (!channel().isActive()) {
/* 296 */       return then((Publisher)Mono.error(AbortedException.beforeSend()));
/*     */     }
/* 298 */     if (dataStream instanceof Mono) {
/* 299 */       return then((Publisher)((Mono)dataStream).flatMap(m -> FutureMono.from((Future)channel().writeAndFlush(m)))
/* 300 */           .doOnDiscard(ReferenceCounted.class, ReferenceCounted::release));
/*     */     }
/* 302 */     return then((Publisher)MonoSendMany.objectSource(dataStream, channel(), predicate));
/*     */   }
/*     */ 
/*     */   
/*     */   public NettyOutbound sendObject(Object message) {
/* 307 */     if (!channel().isActive()) {
/* 308 */       ReactorNetty.safeRelease(message);
/* 309 */       return then((Publisher)Mono.error(AbortedException.beforeSend()));
/*     */     } 
/* 311 */     return then((Publisher)FutureMono.deferFuture(() -> this.connection.channel().writeAndFlush(message)), () -> ReactorNetty.safeRelease(message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <S> NettyOutbound sendUsing(Callable<? extends S> sourceInput, BiFunction<? super Connection, ? super S, ?> mappedInput, Consumer<? super S> sourceCleanup) {
/* 320 */     Objects.requireNonNull(sourceInput, "sourceInput");
/* 321 */     Objects.requireNonNull(mappedInput, "mappedInput");
/* 322 */     Objects.requireNonNull(sourceCleanup, "sourceCleanup");
/*     */     
/* 324 */     return then((Publisher)Mono.using(sourceInput, s -> FutureMono.from((Future)this.connection.channel().writeAndFlush(mappedInput.apply(this, s))), sourceCleanup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Void> onTerminate() {
/* 339 */     if (!isPersistent()) {
/* 340 */       return this.connection.onDispose();
/*     */     }
/* 342 */     return this.onTerminate.asMono().or(this.connection.onDispose());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConnectionObserver listener() {
/* 353 */     return this.listener;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 358 */     return "ChannelOperations{" + this.connection.toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void discard() {
/* 366 */     this.inbound.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void discardWhenNoReceiver() {
/* 374 */     if (this.inbound.receiver == null) {
/* 375 */       discard();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isInboundCancelled() {
/* 385 */     return this.inbound.isCancelled();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isInboundDisposed() {
/* 394 */     return this.inbound.isDisposed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInboundNext(ChannelHandlerContext ctx, Object msg) {
/* 404 */     this.inbound.onInboundNext(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInboundCancel() {
/* 411 */     if (log.isDebugEnabled()) {
/*     */ 
/*     */       
/* 414 */       String info = isDisposed() ? (!channel().isActive() ? "channel disconnected" : "subscription disposed") : "operation cancelled";
/* 415 */       log.debug(ReactorNetty.format(channel(), "[{}] Channel inbound receiver cancelled ({})."), new Object[] { formatName(), info });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInboundComplete() {
/* 424 */     this.inbound.onInboundComplete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterInboundComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInboundClose() {
/* 438 */     discardWhenNoReceiver();
/* 439 */     terminate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onOutboundComplete() {
/* 446 */     if (log.isDebugEnabled()) {
/* 447 */       log.debug(ReactorNetty.format(channel(), "[{}] User Handler requesting close connection"), new Object[] { formatName() });
/*     */     }
/* 449 */     markPersistent(false);
/* 450 */     terminate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onOutboundError(Throwable err) {
/* 459 */     markPersistent(false);
/* 460 */     terminate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void terminate() {
/* 468 */     if (rebind(this.connection)) {
/* 469 */       if (log.isTraceEnabled()) {
/* 470 */         log.trace(ReactorNetty.format(channel(), "Disposing ChannelOperation from a channel"), new Exception("ChannelOperation terminal stack"));
/*     */       }
/*     */ 
/*     */       
/* 474 */       Operators.terminate(OUTBOUND_CLOSE, this);
/*     */ 
/*     */ 
/*     */       
/* 478 */       onInboundComplete();
/* 479 */       afterInboundComplete();
/*     */ 
/*     */       
/* 482 */       this.onTerminate.tryEmitEmpty();
/* 483 */       this.listener.onStateChange(this, ConnectionObserver.State.DISCONNECTING);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void onInboundError(Throwable err) {
/* 493 */     this.inbound.onInboundError(err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Connection connection() {
/* 502 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String formatName() {
/* 511 */     return getClass().getSimpleName()
/* 512 */       .replace("Operations", "");
/*     */   }
/*     */   
/*     */   protected String initShortId() {
/* 516 */     return channel().id().asShortText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Throwable wrapInboundError(Throwable err) {
/* 525 */     if (err instanceof java.nio.channels.ClosedChannelException) {
/* 526 */       return new AbortedException(err);
/*     */     }
/* 528 */     if (err instanceof OutOfMemoryError) {
/* 529 */       return ReactorNetty.wrapException(err);
/*     */     }
/*     */     
/* 532 */     return err;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String asDebugLogMessage(Object o) {
/* 544 */     return o.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPersistent() {
/* 549 */     return this.connection.isPersistent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 554 */     return this.listener.currentContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public String asShortText() {
/* 559 */     return this.shortId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String asLongText() {
/* 564 */     boolean active = channel().isActive();
/* 565 */     if (this.localActive == active && this.longId != null) {
/* 566 */       return this.longId;
/*     */     }
/*     */     
/* 569 */     SocketAddress remoteAddress = channel().remoteAddress();
/* 570 */     SocketAddress localAddress = channel().localAddress();
/* 571 */     String shortText = asShortText();
/* 572 */     if (remoteAddress != null) {
/* 573 */       String localAddressStr = String.valueOf(localAddress);
/* 574 */       String remoteAddressStr = String.valueOf(remoteAddress);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 582 */       StringBuilder buf = (new StringBuilder(shortText.length() + 4 + localAddressStr.length() + 3 + 2 + remoteAddressStr.length())).append(shortText).append(", L:").append(localAddressStr).append(active ? " - " : " ! ").append("R:").append(remoteAddressStr);
/* 583 */       this.longId = buf.toString();
/*     */     }
/* 585 */     else if (localAddress != null) {
/* 586 */       String localAddressStr = String.valueOf(localAddress);
/*     */ 
/*     */ 
/*     */       
/* 590 */       StringBuilder buf = (new StringBuilder(shortText.length() + 4 + localAddressStr.length())).append(shortText).append(", L:").append(localAddressStr);
/* 591 */       this.longId = buf.toString();
/*     */     } else {
/*     */       
/* 594 */       this.longId = shortText;
/*     */     } 
/*     */     
/* 597 */     this.localActive = active;
/* 598 */     return this.longId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface OnSetup
/*     */   {
/*     */     static OnSetup empty() {
/* 613 */       return ChannelOperations.EMPTY_SETUP;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     ChannelOperations<?, ?> create(Connection param1Connection, ConnectionObserver param1ConnectionObserver, @Nullable Object param1Object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 631 */   static final Logger log = Loggers.getLogger(ChannelOperations.class);
/*     */   
/* 633 */   static final Object TERMINATED_OPS = new Object();
/*     */ 
/*     */   
/*     */   static final OnSetup EMPTY_SETUP = (c, l, msg) -> null;
/*     */ 
/*     */   
/* 639 */   static final AtomicReferenceFieldUpdater<ChannelOperations, Subscription> OUTBOUND_CLOSE = AtomicReferenceFieldUpdater.newUpdater(ChannelOperations.class, Subscription.class, "outboundSubscription");
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\ChannelOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */