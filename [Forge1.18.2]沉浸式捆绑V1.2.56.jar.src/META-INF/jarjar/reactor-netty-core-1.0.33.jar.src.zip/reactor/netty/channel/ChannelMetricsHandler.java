/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelOutboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.ssl.SslHandler;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelMetricsHandler
/*     */   extends AbstractChannelMetricsHandler
/*     */ {
/*     */   final ChannelMetricsRecorder recorder;
/*     */   
/*     */   ChannelMetricsHandler(ChannelMetricsRecorder recorder, @Nullable SocketAddress remoteAddress, boolean onServer) {
/*  42 */     super(remoteAddress, onServer);
/*  43 */     this.recorder = recorder;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelHandler connectMetricsHandler() {
/*  48 */     return (ChannelHandler)new ConnectMetricsHandler(recorder());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelHandler tlsMetricsHandler() {
/*  53 */     return (ChannelHandler)new TlsMetricsHandler(this.recorder);
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelMetricsRecorder recorder() {
/*  58 */     return this.recorder;
/*     */   }
/*     */   
/*     */   static final class ConnectMetricsHandler
/*     */     extends ChannelOutboundHandlerAdapter {
/*     */     final ChannelMetricsRecorder recorder;
/*     */     
/*     */     ConnectMetricsHandler(ChannelMetricsRecorder recorder) {
/*  66 */       this.recorder = recorder;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void connect(ChannelHandlerContext ctx, SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) throws Exception {
/*  72 */       long connectTimeStart = System.nanoTime();
/*  73 */       super.connect(ctx, remoteAddress, localAddress, promise);
/*  74 */       promise.addListener(future -> {
/*     */             ctx.pipeline().remove((ChannelHandler)this);
/*     */             this.recorder.recordConnectTime(remoteAddress, Duration.ofNanos(System.nanoTime() - connectTimeStart), future.isSuccess() ? "SUCCESS" : "ERROR");
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class TlsMetricsHandler
/*     */     extends ChannelInboundHandlerAdapter
/*     */   {
/*     */     protected final ChannelMetricsRecorder recorder;
/*     */     
/*     */     TlsMetricsHandler(ChannelMetricsRecorder recorder) {
/*  88 */       this.recorder = recorder;
/*     */     }
/*     */ 
/*     */     
/*     */     public void channelActive(ChannelHandlerContext ctx) {
/*  93 */       long tlsHandshakeTimeStart = System.nanoTime();
/*  94 */       ((SslHandler)ctx.pipeline().get(SslHandler.class))
/*  95 */         .handshakeFuture()
/*  96 */         .addListener(f -> {
/*     */             ctx.pipeline().remove((ChannelHandler)this);
/*     */             recordTlsHandshakeTime(ctx, tlsHandshakeTimeStart, f.isSuccess() ? "SUCCESS" : "ERROR");
/*     */           });
/* 100 */       ctx.fireChannelActive();
/*     */     }
/*     */     
/*     */     protected void recordTlsHandshakeTime(ChannelHandlerContext ctx, long tlsHandshakeTimeStart, String status) {
/* 104 */       this.recorder.recordTlsHandshakeTime(ctx
/* 105 */           .channel().remoteAddress(), 
/* 106 */           Duration.ofNanos(System.nanoTime() - tlsHandshakeTimeStart), status);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\ChannelMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */