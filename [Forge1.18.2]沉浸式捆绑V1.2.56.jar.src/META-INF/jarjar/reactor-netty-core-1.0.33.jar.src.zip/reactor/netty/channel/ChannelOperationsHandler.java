/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.handler.codec.DecoderResult;
/*     */ import io.netty.handler.codec.DecoderResultProvider;
/*     */ import io.netty.handler.ssl.SslCloseCompletionEvent;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ChannelOperationsHandler
/*     */   extends ChannelInboundHandlerAdapter
/*     */ {
/*     */   final ConnectionObserver listener;
/*     */   final ChannelOperations.OnSetup opsFactory;
/*     */   
/*     */   ChannelOperationsHandler(ChannelOperations.OnSetup opsFactory, ConnectionObserver listener) {
/*  48 */     this.listener = listener;
/*  49 */     this.opsFactory = opsFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelActive(ChannelHandlerContext ctx) {
/*  56 */     if (ctx.channel().isActive()) {
/*  57 */       Connection c = Connection.from(ctx.channel());
/*  58 */       this.listener.onStateChange(c, ConnectionObserver.State.CONNECTED);
/*  59 */       ChannelOperations<?, ?> ops = this.opsFactory.create(c, this.listener, null);
/*  60 */       if (ops != null) {
/*  61 */         ops.bind();
/*  62 */         this.listener.onStateChange(ops, ConnectionObserver.State.CONFIGURED);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void channelInactive(ChannelHandlerContext ctx) {
/*     */     try {
/*  70 */       Connection connection = Connection.from(ctx.channel());
/*  71 */       ChannelOperations<?, ?> ops = (ChannelOperations<?, ?>)connection.as(ChannelOperations.class);
/*  72 */       if (ops != null) {
/*  73 */         ops.onInboundClose();
/*     */       } else {
/*     */         
/*  76 */         this.listener.onStateChange(connection, ConnectionObserver.State.DISCONNECTING);
/*     */       }
/*     */     
/*  79 */     } catch (Throwable err) {
/*  80 */       exceptionCaught(ctx, err);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void userEventTriggered(ChannelHandlerContext ctx, Object evt) {
/*  87 */     if (evt instanceof SslCloseCompletionEvent) {
/*  88 */       SslCloseCompletionEvent sslCloseCompletionEvent = (SslCloseCompletionEvent)evt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       if (sslCloseCompletionEvent.isSuccess() && ctx.channel().isActive()) {
/*  96 */         if (log.isDebugEnabled()) {
/*  97 */           log.debug(ReactorNetty.format(ctx.channel(), "Received a TLS close_notify, closing the channel now."));
/*     */         }
/*  99 */         ctx.close();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 107 */     if (msg == null || msg == Unpooled.EMPTY_BUFFER || msg instanceof io.netty.buffer.EmptyByteBuf) {
/*     */       return;
/*     */     }
/*     */     try {
/* 111 */       ChannelOperations<?, ?> ops = ChannelOperations.get(ctx.channel());
/* 112 */       if (ops != null) {
/* 113 */         ops.onInboundNext(ctx, msg);
/*     */       } else {
/*     */         
/* 116 */         if (log.isDebugEnabled()) {
/* 117 */           if (msg instanceof DecoderResultProvider) {
/* 118 */             DecoderResult decoderResult = ((DecoderResultProvider)msg).decoderResult();
/* 119 */             if (decoderResult.isFailure()) {
/* 120 */               log.debug(ReactorNetty.format(ctx.channel(), "Decoding failed."), decoderResult.cause());
/*     */             }
/*     */           } 
/*     */           
/* 124 */           log.debug(ReactorNetty.format(ctx.channel(), "No ChannelOperation attached."));
/*     */         } 
/* 126 */         ReferenceCountUtil.release(msg);
/*     */       }
/*     */     
/* 129 */     } catch (Throwable err) {
/* 130 */       safeRelease(msg);
/* 131 */       log.error(ReactorNetty.format(ctx.channel(), "Error was received while reading the incoming data. The connection will be closed."), err);
/*     */ 
/*     */       
/* 134 */       ctx.close();
/* 135 */       exceptionCaught(ctx, err);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void exceptionCaught(ChannelHandlerContext ctx, Throwable err) {
/* 141 */     Connection connection = Connection.from(ctx.channel());
/* 142 */     ChannelOperations<?, ?> ops = (ChannelOperations<?, ?>)connection.as(ChannelOperations.class);
/* 143 */     if (ops != null) {
/* 144 */       ops.onInboundError(err);
/*     */     } else {
/*     */       
/* 147 */       this.listener.onUncaughtException(connection, err);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void safeRelease(Object msg) {
/* 152 */     if (msg instanceof ReferenceCounted) {
/* 153 */       ReferenceCounted referenceCounted = (ReferenceCounted)msg;
/* 154 */       if (referenceCounted.refCnt() > 0) {
/*     */         try {
/* 156 */           referenceCounted.release();
/*     */         }
/* 158 */         catch (IllegalReferenceCountException e) {
/* 159 */           if (log.isDebugEnabled()) {
/* 160 */             log.debug("", (Throwable)e);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/* 167 */   static final Logger log = Loggers.getLogger(ChannelOperationsHandler.class);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\ChannelOperationsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */