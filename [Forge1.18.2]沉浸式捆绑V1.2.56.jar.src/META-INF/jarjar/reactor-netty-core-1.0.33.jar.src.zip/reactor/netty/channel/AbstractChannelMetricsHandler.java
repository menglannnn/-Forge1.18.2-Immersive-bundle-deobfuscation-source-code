/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelDuplexHandler;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.socket.DatagramPacket;
/*     */ import java.net.SocketAddress;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractChannelMetricsHandler
/*     */   extends ChannelDuplexHandler
/*     */ {
/*  41 */   private static final Logger log = Loggers.getLogger(AbstractChannelMetricsHandler.class);
/*     */   
/*     */   final SocketAddress remoteAddress;
/*     */   
/*     */   final boolean onServer;
/*     */   
/*     */   protected AbstractChannelMetricsHandler(@Nullable SocketAddress remoteAddress, boolean onServer) {
/*  48 */     this.remoteAddress = remoteAddress;
/*  49 */     this.onServer = onServer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelActive(ChannelHandlerContext ctx) {
/*  54 */     if (this.onServer) {
/*     */       try {
/*  56 */         recorder().recordServerConnectionOpened(ctx.channel().localAddress());
/*     */       }
/*  58 */       catch (RuntimeException e) {
/*  59 */         if (log.isWarnEnabled()) {
/*  60 */           log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  65 */     ctx.fireChannelActive();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelInactive(ChannelHandlerContext ctx) {
/*  70 */     if (this.onServer) {
/*     */       try {
/*  72 */         recorder().recordServerConnectionClosed(ctx.channel().localAddress());
/*     */       }
/*  74 */       catch (RuntimeException e) {
/*  75 */         if (log.isWarnEnabled()) {
/*  76 */           log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  81 */     ctx.fireChannelInactive();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRegistered(ChannelHandlerContext ctx) {
/*  86 */     if (!this.onServer) {
/*  87 */       ctx.pipeline()
/*  88 */         .addAfter("reactor.left.channelMetricsHandler", "reactor.left.connectMetricsHandler", 
/*     */           
/*  90 */           connectMetricsHandler());
/*     */     }
/*  92 */     if (ctx.pipeline().get("reactor.left.sslHandler") != null) {
/*  93 */       ctx.pipeline()
/*  94 */         .addBefore("reactor.left.sslHandler", "reactor.left.tlsMetricsHandler", 
/*     */           
/*  96 */           tlsMetricsHandler());
/*     */     }
/*     */     
/*  99 */     ctx.fireChannelRegistered();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) {
/*     */     try {
/* 105 */       if (msg instanceof ByteBuf) {
/* 106 */         ByteBuf buffer = (ByteBuf)msg;
/* 107 */         if (buffer.readableBytes() > 0) {
/* 108 */           recordRead(ctx, this.remoteAddress, buffer.readableBytes());
/*     */         }
/*     */       }
/* 111 */       else if (msg instanceof DatagramPacket) {
/* 112 */         DatagramPacket p = (DatagramPacket)msg;
/* 113 */         ByteBuf buffer = (ByteBuf)p.content();
/* 114 */         if (buffer.readableBytes() > 0) {
/* 115 */           recordRead(ctx, (this.remoteAddress != null) ? this.remoteAddress : p.sender(), buffer.readableBytes());
/*     */         }
/*     */       }
/*     */     
/* 119 */     } catch (RuntimeException e) {
/* 120 */       if (log.isWarnEnabled()) {
/* 121 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 126 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/*     */     try {
/* 133 */       if (msg instanceof ByteBuf) {
/* 134 */         ByteBuf buffer = (ByteBuf)msg;
/* 135 */         if (buffer.readableBytes() > 0) {
/* 136 */           recordWrite(ctx, this.remoteAddress, buffer.readableBytes());
/*     */         }
/*     */       }
/* 139 */       else if (msg instanceof DatagramPacket) {
/* 140 */         DatagramPacket p = (DatagramPacket)msg;
/* 141 */         ByteBuf buffer = (ByteBuf)p.content();
/* 142 */         if (buffer.readableBytes() > 0) {
/* 143 */           recordWrite(ctx, (this.remoteAddress != null) ? this.remoteAddress : p.recipient(), buffer.readableBytes());
/*     */         }
/*     */       }
/*     */     
/* 147 */     } catch (RuntimeException e) {
/* 148 */       if (log.isWarnEnabled()) {
/* 149 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 155 */     ctx.write(msg, promise);
/*     */   }
/*     */ 
/*     */   
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
/*     */     try {
/* 161 */       recordException(ctx, (this.remoteAddress != null) ? this.remoteAddress : ctx.channel().remoteAddress());
/*     */     }
/* 163 */     catch (RuntimeException e) {
/* 164 */       if (log.isWarnEnabled()) {
/* 165 */         log.warn(ReactorNetty.format(ctx.channel(), "Exception caught while recording metrics."), e);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 170 */     ctx.fireExceptionCaught(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ChannelHandler connectMetricsHandler();
/*     */ 
/*     */   
/*     */   protected void recordException(ChannelHandlerContext ctx, SocketAddress address) {
/* 179 */     recorder().incrementErrorsCount(address);
/*     */   } public abstract ChannelHandler tlsMetricsHandler();
/*     */   public abstract ChannelMetricsRecorder recorder();
/*     */   protected void recordRead(ChannelHandlerContext ctx, SocketAddress address, long bytes) {
/* 183 */     recorder().recordDataReceived(address, bytes);
/*     */   }
/*     */   
/*     */   protected void recordWrite(ChannelHandlerContext ctx, SocketAddress address, long bytes) {
/* 187 */     recorder().recordDataSent(address, bytes);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\AbstractChannelMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */