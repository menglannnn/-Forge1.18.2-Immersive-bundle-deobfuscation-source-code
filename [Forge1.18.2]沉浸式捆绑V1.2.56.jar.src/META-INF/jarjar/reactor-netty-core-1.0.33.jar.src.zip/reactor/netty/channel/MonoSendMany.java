/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.DefaultChannelPromise;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.ToIntFunction;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MonoSendMany<I, O>
/*     */   extends MonoSend<I, O>
/*     */   implements Scannable
/*     */ {
/*     */   static final Object KEY_ON_DISCARD;
/*     */   final Publisher<? extends I> source;
/*     */   final Predicate<I> predicate;
/*     */   
/*     */   static {
/*  62 */     Context context = Operators.enableOnDiscard(null, o -> {
/*     */         
/*     */         });
/*     */     
/*  66 */     Map.Entry<Object, Object> entry = context.stream().findAny().orElse(null);
/*     */     
/*  68 */     if (entry != null) {
/*  69 */       KEY_ON_DISCARD = entry.getKey();
/*     */     } else {
/*     */       
/*  72 */       KEY_ON_DISCARD = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static MonoSendMany<ByteBuf, ByteBuf> byteBufSource(Publisher<? extends ByteBuf> source, Channel channel, Predicate<ByteBuf> predicate) {
/*  79 */     return new MonoSendMany<>(source, channel, predicate, TRANSFORMATION_FUNCTION_BB, CONSUMER_NOCHECK_CLEANUP, SIZE_OF_BB);
/*     */   }
/*     */   
/*     */   static MonoSendMany<?, ?> objectSource(Publisher<?> source, Channel channel, Predicate<Object> predicate) {
/*  83 */     return new MonoSendMany<>(source, channel, predicate, TRANSFORMATION_FUNCTION, CONSUMER_NOCHECK_CLEANUP, SIZE_OF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MonoSendMany(Publisher<? extends I> source, Channel channel, Predicate<I> predicate, Function<? super I, ? extends O> transformer, Consumer<? super I> sourceCleanup, ToIntFunction<O> sizeOf) {
/*  95 */     super(channel, transformer, sourceCleanup, sizeOf);
/*  96 */     this.source = Objects.<Publisher<? extends I>>requireNonNull(source, "source publisher cannot be null");
/*  97 */     this.predicate = Objects.<Predicate<I>>requireNonNull(predicate, "predicate cannot be null");
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Void> destination) {
/* 102 */     this.source.subscribe((Subscriber)new SendManyInner<>(this, destination));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key) {
/* 109 */     if (key == Scannable.Attr.PREFETCH) {
/* 110 */       return Integer.valueOf(128);
/*     */     }
/* 112 */     if (key == Scannable.Attr.PARENT) {
/* 113 */       return this.source;
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SendManyInner<I, O>
/*     */     implements CoreSubscriber<I>, Subscription, Fuseable, Context, Consumer<I>, ChannelFutureListener, Runnable, Scannable, ChannelPromise
/*     */   {
/*     */     final ChannelHandlerContext ctx;
/*     */     
/*     */     final EventLoop eventLoop;
/*     */     
/*     */     final MonoSendMany<I, O> parent;
/*     */     
/*     */     final CoreSubscriber<? super Void> actual;
/*     */     
/*     */     final Context actualContext;
/*     */     
/*     */     final Runnable asyncFlush;
/*     */     
/*     */     volatile Subscription s;
/*     */     
/*     */     volatile int wip;
/*     */     Queue<I> queue;
/*     */     int pending;
/*     */     int requested;
/*     */     int sourceMode;
/*     */     boolean needFlush;
/*     */     Throwable terminalSignal;
/*     */     int nextRequest;
/*     */     
/*     */     SendManyInner(MonoSendMany<I, O> parent, CoreSubscriber<? super Void> actual) {
/* 146 */       this.parent = parent;
/* 147 */       this.actual = actual;
/* 148 */       this.actualContext = actual.currentContext();
/* 149 */       this.requested = 128;
/* 150 */       this.ctx = parent.ctx;
/* 151 */       this.eventLoop = this.ctx.channel().eventLoop();
/*     */       
/* 153 */       this.asyncFlush = new AsyncFlush();
/*     */ 
/*     */       
/* 156 */       this.ctx.channel()
/* 157 */         .closeFuture()
/* 158 */         .addListener((GenericFutureListener)this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 163 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 168 */       if (!Operators.terminate(SUBSCRIPTION, this)) {
/*     */         return;
/*     */       }
/*     */       
/* 172 */       int wip = MonoSendMany.wipIncrement(WIP, this);
/* 173 */       if (wip == 0) {
/* 174 */         onInterruptionCleanup();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 180 */       if (this.terminalSignal != null) {
/*     */         return;
/*     */       }
/* 183 */       this.terminalSignal = MonoSendMany.Completion.INSTANCE;
/* 184 */       trySchedule();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 189 */       if (this.terminalSignal != null) {
/* 190 */         Operators.onErrorDropped(t, this.actualContext);
/*     */         
/*     */         return;
/*     */       } 
/* 194 */       if (t instanceof java.nio.channels.ClosedChannelException) {
/* 195 */         t = new AbortedException(t);
/*     */       }
/*     */       
/* 198 */       this.terminalSignal = t;
/* 199 */       trySchedule();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(I t) {
/* 204 */       if (this.sourceMode == 2) {
/* 205 */         trySchedule();
/*     */         
/*     */         return;
/*     */       } 
/* 209 */       if (this.terminalSignal != null) {
/* 210 */         this.parent.sourceCleanup.accept(t);
/* 211 */         Operators.onDiscard(t, this.actualContext);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 216 */       if (!this.queue.offer(t)) {
/* 217 */         onError(Operators.onOperatorError(this.s, 
/* 218 */               Exceptions.failWithOverflow("Queue is full: Reactive Streams source doesn't respect backpressure"), t, this.actualContext));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 223 */       trySchedule();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 228 */       if (Operators.setOnce(SUBSCRIPTION, this, s)) {
/* 229 */         if (s instanceof Fuseable.QueueSubscription) {
/* 230 */           Fuseable.QueueSubscription<I> f = (Fuseable.QueueSubscription<I>)s;
/*     */ 
/*     */           
/* 233 */           int m = f.requestFusion(7);
/*     */           
/* 235 */           if (m == 1) {
/* 236 */             this.sourceMode = 1;
/* 237 */             this.queue = (Queue<I>)f;
/* 238 */             this.terminalSignal = MonoSendMany.Completion.INSTANCE;
/* 239 */             this.actual.onSubscribe(this);
/* 240 */             trySchedule();
/*     */             return;
/*     */           } 
/* 243 */           if (m == 2) {
/* 244 */             this.sourceMode = 2;
/* 245 */             this.queue = (Queue<I>)f;
/* 246 */             this.actual.onSubscribe(this);
/* 247 */             s.request(128L);
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 252 */         this.queue = Queues.get(128).get();
/* 253 */         this.actual.onSubscribe(this);
/* 254 */         s.request(128L);
/*     */       } else {
/*     */         
/* 257 */         this.queue = Queues.empty().get();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void operationComplete(ChannelFuture future) {
/* 268 */       if (Operators.terminate(SUBSCRIPTION, this)) {
/* 269 */         int wip = MonoSendMany.wipIncrement(WIP, this);
/* 270 */         if (wip == 0) {
/* 271 */           onInterruptionCleanup();
/*     */         }
/*     */         
/* 274 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 281 */       Queue<I> queue = this.queue;
/*     */       try {
/* 283 */         int missed = 1;
/*     */         do {
/* 285 */           int r = this.requested;
/*     */           
/* 287 */           while (Integer.MAX_VALUE == r || r-- > 0) {
/* 288 */             I sourceMessage = queue.poll();
/*     */             
/* 290 */             if (sourceMessage == null) {
/*     */               break;
/*     */             }
/*     */             
/* 294 */             if (this.s == Operators.cancelledSubscription()) {
/* 295 */               this.parent.sourceCleanup.accept(sourceMessage);
/* 296 */               Operators.onDiscard(sourceMessage, this.actualContext);
/* 297 */               onInterruptionCleanup();
/*     */               
/*     */               return;
/*     */             } 
/* 301 */             O encodedMessage = this.parent.transformer.apply(sourceMessage);
/* 302 */             if (encodedMessage == null) {
/* 303 */               if (this.parent.predicate.test(sourceMessage)) {
/* 304 */                 this.nextRequest++;
/* 305 */                 this.needFlush = false;
/* 306 */                 this.ctx.flush();
/*     */               } 
/*     */               
/*     */               continue;
/*     */             } 
/* 311 */             int readableBytes = this.parent.sizeOf.applyAsInt(encodedMessage);
/*     */ 
/*     */             
/* 314 */             if (readableBytes == 0 && !(encodedMessage instanceof io.netty.buffer.ByteBufHolder)) {
/* 315 */               ReferenceCountUtil.release(encodedMessage);
/* 316 */               this.nextRequest++;
/*     */               continue;
/*     */             } 
/* 319 */             this.pending++;
/*     */             
/* 321 */             this.ctx.write(encodedMessage, this);
/*     */             
/* 323 */             if (this.parent.predicate.test(sourceMessage) || !this.ctx.channel().isWritable() || readableBytes > this.ctx.channel().bytesBeforeUnwritable()) {
/* 324 */               this.needFlush = false;
/* 325 */               this.ctx.flush();
/*     */               continue;
/*     */             } 
/* 328 */             this.needFlush = true;
/*     */           } 
/*     */ 
/*     */           
/* 332 */           if (this.needFlush && this.pending != 0) {
/* 333 */             this.needFlush = false;
/* 334 */             this.eventLoop.execute(this.asyncFlush);
/*     */           } 
/*     */           
/* 337 */           if (Operators.cancelledSubscription() == this.s) {
/* 338 */             onInterruptionCleanup();
/*     */             
/*     */             return;
/*     */           } 
/* 342 */           if (checkTerminated() && queue.isEmpty()) {
/* 343 */             this.ctx.channel()
/* 344 */               .closeFuture()
/* 345 */               .removeListener((GenericFutureListener)this);
/*     */             
/* 347 */             Throwable t = this.terminalSignal;
/* 348 */             if (t == MonoSendMany.Completion.INSTANCE) {
/* 349 */               this.actual.onComplete();
/*     */             } else {
/*     */               
/* 352 */               this.actual.onError(t);
/*     */             } 
/*     */             
/* 355 */             if (this.sourceMode == 2)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 363 */               queue.clear();
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/* 368 */           int nextRequest = this.nextRequest;
/* 369 */           if (this.terminalSignal == null && nextRequest != 0) {
/* 370 */             this.nextRequest = 0;
/* 371 */             this.s.request(nextRequest);
/*     */           } 
/*     */           
/* 374 */           missed = WIP.addAndGet(this, -missed);
/* 375 */         } while (missed != 0);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 380 */       catch (Throwable t) {
/* 381 */         onInterruptionCleanup();
/* 382 */         if (Operators.terminate(SUBSCRIPTION, this)) {
/* 383 */           this.actual.onError(t);
/*     */         } else {
/*     */           
/* 386 */           Operators.onErrorDropped(t, this.actualContext);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void onInterruptionCleanup() {
/* 394 */       this.ctx.channel()
/* 395 */         .closeFuture()
/* 396 */         .removeListener((GenericFutureListener)this);
/*     */       
/* 398 */       Queue<I> queue = this.queue;
/* 399 */       if (queue == null) {
/*     */         return;
/*     */       }
/*     */       
/* 403 */       if (this.sourceMode == 2) {
/*     */ 
/*     */         
/* 406 */         MonoSendMany.discardAsyncWithTermination(WIP, this, queue);
/*     */       } else {
/*     */         
/* 409 */         Context context = currentContext();
/* 410 */         MonoSendMany.discardWithTermination(WIP, this, queue, context);
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean checkTerminated() {
/* 415 */       return (this.pending == 0 && this.terminalSignal != null);
/*     */     }
/*     */     
/*     */     void trySchedule() {
/* 419 */       int wip = MonoSendMany.wipIncrement(WIP, this);
/* 420 */       if (wip != 0) {
/* 421 */         if (wip == Integer.MIN_VALUE) {
/* 422 */           if (this.sourceMode == 2) {
/* 423 */             this.queue.clear();
/*     */           } else {
/*     */             
/* 426 */             Operators.onDiscardQueueWithClear(this.queue, currentContext(), null);
/*     */           } 
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/* 433 */         if (this.eventLoop.inEventLoop()) {
/* 434 */           run();
/*     */           return;
/*     */         } 
/* 437 */         this.eventLoop.execute(this);
/*     */       }
/* 439 */       catch (Throwable t) {
/* 440 */         if (Operators.terminate(SUBSCRIPTION, this)) {
/* 441 */           onInterruptionCleanup();
/* 442 */           this.actual.onError(Operators.onRejectedExecution(t, null, null, null, this.actualContext));
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 450 */       if (key == Scannable.Attr.PARENT) {
/* 451 */         return this.s;
/*     */       }
/* 453 */       if (key == Scannable.Attr.ACTUAL) {
/* 454 */         return this.actual;
/*     */       }
/* 456 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) {
/* 457 */         return Integer.valueOf(this.requested);
/*     */       }
/* 459 */       if (key == Scannable.Attr.CANCELLED) {
/* 460 */         return Boolean.valueOf((Operators.cancelledSubscription() == this.s));
/*     */       }
/* 462 */       if (key == Scannable.Attr.TERMINATED) {
/* 463 */         return Boolean.valueOf((this.terminalSignal != null));
/*     */       }
/* 465 */       if (key == Scannable.Attr.BUFFERED) {
/* 466 */         return Integer.valueOf((this.queue != null) ? this.queue.size() : 0);
/*     */       }
/* 468 */       if (key == Scannable.Attr.ERROR) {
/* 469 */         return !hasOnComplete() ? this.terminalSignal : null;
/*     */       }
/* 471 */       if (key == Scannable.Attr.PREFETCH) {
/* 472 */         return Integer.valueOf(128);
/*     */       }
/* 474 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Channel channel() {
/* 479 */       return this.ctx.channel();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise setSuccess(Void result) {
/* 484 */       trySuccess((Void)null);
/* 485 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise setSuccess() {
/* 490 */       trySuccess((Void)null);
/* 491 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean trySuccess() {
/* 496 */       trySuccess((Void)null);
/* 497 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise setFailure(Throwable cause) {
/* 502 */       if (tryFailure(cause)) {
/* 503 */         return this;
/*     */       }
/* 505 */       Operators.onErrorDropped(cause, this.actualContext);
/* 506 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise addListener(GenericFutureListener<? extends Future<? super Void>> listener) {
/* 511 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelPromise addListeners(GenericFutureListener<? extends Future<? super Void>>... listeners) {
/* 517 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise removeListener(GenericFutureListener<? extends Future<? super Void>> listener) {
/* 522 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelPromise removeListeners(GenericFutureListener<? extends Future<? super Void>>... listeners) {
/* 528 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise sync() {
/* 533 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise syncUninterruptibly() {
/* 538 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise await() {
/* 543 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise awaitUninterruptibly() {
/* 548 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise unvoid() {
/* 553 */       return (ChannelPromise)new DefaultChannelPromise(this.ctx.channel())
/*     */         {
/*     */           public ChannelPromise setSuccess(Void result) {
/* 556 */             super.trySuccess(null);
/* 557 */             MonoSendMany.SendManyInner.this.trySuccess((Void)null);
/* 558 */             return (ChannelPromise)this;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean trySuccess(Void result) {
/* 563 */             super.trySuccess(null);
/* 564 */             return MonoSendMany.SendManyInner.this.trySuccess((Void)null);
/*     */           }
/*     */ 
/*     */           
/*     */           public ChannelPromise setFailure(Throwable cause) {
/* 569 */             super.tryFailure(cause);
/* 570 */             MonoSendMany.SendManyInner.this.tryFailure(cause);
/* 571 */             return (ChannelPromise)this;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean tryFailure(Throwable cause) {
/* 576 */             super.tryFailure(cause);
/* 577 */             return MonoSendMany.SendManyInner.this.tryFailure(cause);
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isVoid() {
/* 584 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean trySuccess(Void result) {
/* 589 */       this.requested--;
/* 590 */       this.pending--;
/*     */       
/* 592 */       if (checkTerminated()) {
/* 593 */         if (this.sourceMode == 1 && this.requested <= 64) {
/* 594 */           int u = 128 - this.requested;
/* 595 */           this.requested += u;
/* 596 */           this.nextRequest += u;
/*     */         } 
/* 598 */         trySchedule();
/* 599 */         return true;
/*     */       } 
/*     */       
/* 602 */       if (this.requested <= 64) {
/* 603 */         int u = 128 - this.requested;
/* 604 */         this.requested += u;
/* 605 */         this.nextRequest += u;
/* 606 */         trySchedule();
/*     */       } 
/* 608 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryFailure(Throwable cause) {
/* 613 */       if (Operators.terminate(SUBSCRIPTION, this)) {
/* 614 */         int wip = MonoSendMany.wipIncrement(WIP, this);
/* 615 */         if (wip == 0) {
/* 616 */           onInterruptionCleanup();
/*     */         }
/* 618 */         this.actual.onError(cause);
/*     */       } 
/* 620 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setUncancellable() {
/* 625 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSuccess() {
/* 630 */       return (hasOnComplete() && this.queue.isEmpty());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCancellable() {
/* 635 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Throwable cause() {
/* 641 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean await(long timeout, TimeUnit unit) {
/* 646 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean await(long timeoutMillis) {
/* 651 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean awaitUninterruptibly(long timeout, TimeUnit unit) {
/* 656 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean awaitUninterruptibly(long timeoutMillis) {
/* 661 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Void getNow() {
/* 666 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean cancel(boolean mayInterruptIfRunning) {
/* 671 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCancelled() {
/* 676 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDone() {
/* 681 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Void get() {
/* 686 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Void get(long timeout, TimeUnit unit) {
/* 691 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void accept(I i) {
/*     */       try {
/* 698 */         this.parent.sourceCleanup.accept(i);
/*     */       }
/* 700 */       catch (IllegalReferenceCountException illegalReferenceCountException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 705 */       Operators.onDiscard(i, this.actualContext);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> T get(Object key) {
/* 712 */       if (MonoSendMany.KEY_ON_DISCARD == key) {
/* 713 */         return (T)this;
/*     */       }
/*     */       
/* 716 */       return (T)this.actualContext.get(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasKey(Object key) {
/* 721 */       if (MonoSendMany.KEY_ON_DISCARD == key) {
/* 722 */         return true;
/*     */       }
/*     */       
/* 725 */       return this.actualContext.hasKey(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context put(Object key, Object value) {
/* 730 */       Context context = this.actualContext;
/*     */       
/* 732 */       if (context.isEmpty()) {
/* 733 */         if (key == MonoSendMany.KEY_ON_DISCARD) {
/* 734 */           return Context.of(key, value);
/*     */         }
/*     */         
/* 737 */         return Context.of(MonoSendMany.KEY_ON_DISCARD, this, key, value);
/*     */       } 
/*     */       
/* 740 */       return context.put(MonoSendMany.KEY_ON_DISCARD, this)
/* 741 */         .put(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context delete(Object key) {
/* 746 */       Context context = this.actualContext;
/*     */       
/* 748 */       if (context.isEmpty()) {
/* 749 */         if (key == MonoSendMany.KEY_ON_DISCARD) {
/* 750 */           return Context.empty();
/*     */         }
/*     */         
/* 753 */         return this;
/*     */       } 
/*     */ 
/*     */       
/* 757 */       return context.put(MonoSendMany.KEY_ON_DISCARD, this)
/* 758 */         .delete(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void forEach(BiConsumer<Object, Object> action) {
/* 763 */       action.accept(MonoSendMany.KEY_ON_DISCARD, this);
/* 764 */       this.actualContext.delete(MonoSendMany.KEY_ON_DISCARD).forEach(action);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 769 */       Context context = this.actualContext;
/* 770 */       if (context.hasKey(MonoSendMany.KEY_ON_DISCARD)) {
/* 771 */         return context.size();
/*     */       }
/*     */       
/* 774 */       return context.size() + 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public Stream<Map.Entry<Object, Object>> stream() {
/* 779 */       Context context = this.actualContext;
/*     */       
/* 781 */       if (context.isEmpty()) {
/* 782 */         return Stream.of(new AbstractMap.SimpleEntry<>(MonoSendMany.KEY_ON_DISCARD, this));
/*     */       }
/*     */       
/* 785 */       return context.put(MonoSendMany.KEY_ON_DISCARD, this)
/* 786 */         .stream();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 791 */     static final AtomicIntegerFieldUpdater<SendManyInner> WIP = AtomicIntegerFieldUpdater.newUpdater(SendManyInner.class, "wip");
/*     */ 
/*     */     
/* 794 */     static final AtomicReferenceFieldUpdater<SendManyInner, Subscription> SUBSCRIPTION = AtomicReferenceFieldUpdater.newUpdater(SendManyInner.class, Subscription.class, "s");
/*     */     
/*     */     final class AsyncFlush
/*     */       implements Runnable {
/*     */       public void run() {
/* 799 */         if (MonoSendMany.SendManyInner.this.pending != 0) {
/* 800 */           MonoSendMany.SendManyInner.this.ctx.flush();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     boolean hasOnComplete() {
/* 806 */       return (this.terminalSignal == MonoSendMany.Completion.INSTANCE);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class Completion
/*     */     extends Exception {
/* 812 */     static final Completion INSTANCE = new Completion();
/*     */     private static final long serialVersionUID = 8284666103614054915L;
/*     */     
/*     */     public synchronized Throwable fillInStackTrace() {
/* 816 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> int wipIncrement(AtomicIntegerFieldUpdater<T> updater, T instance) {
/*     */     while (true) {
/* 824 */       int wip = updater.get(instance);
/*     */       
/* 826 */       if (wip == Integer.MIN_VALUE) {
/* 827 */         return Integer.MIN_VALUE;
/*     */       }
/*     */       
/* 830 */       if (updater.compareAndSet(instance, wip, wip + 1)) {
/* 831 */         return wip;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void discardWithTermination(AtomicIntegerFieldUpdater<T> updater, T instance, Queue<?> q, Context context) {
/*     */     int wip;
/*     */     do {
/* 843 */       wip = updater.get(instance);
/*     */ 
/*     */ 
/*     */       
/* 847 */       Operators.onDiscardQueueWithClear(q, context, null);
/*     */     }
/* 849 */     while (!updater.compareAndSet(instance, wip, -2147483648));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void discardAsyncWithTermination(AtomicIntegerFieldUpdater<T> updater, T instance, Queue<?> q) {
/*     */     int wip;
/*     */     do {
/* 860 */       wip = updater.get(instance);
/*     */ 
/*     */       
/* 863 */       q.clear();
/*     */     }
/* 865 */     while (!updater.compareAndSet(instance, wip, -2147483648));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\MonoSendMany.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */