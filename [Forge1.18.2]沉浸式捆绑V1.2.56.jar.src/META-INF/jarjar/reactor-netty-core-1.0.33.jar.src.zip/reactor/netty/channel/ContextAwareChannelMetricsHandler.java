/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelOutboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ContextAwareChannelMetricsHandler
/*     */   extends AbstractChannelMetricsHandler
/*     */ {
/*     */   final ContextAwareChannelMetricsRecorder recorder;
/*     */   
/*     */   ContextAwareChannelMetricsHandler(ContextAwareChannelMetricsRecorder recorder, @Nullable SocketAddress remoteAddress, boolean onServer) {
/*  42 */     super(remoteAddress, onServer);
/*  43 */     this.recorder = recorder;
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelHandler connectMetricsHandler() {
/*  48 */     return (ChannelHandler)new ContextAwareConnectMetricsHandler(recorder());
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelHandler tlsMetricsHandler() {
/*  53 */     return (ChannelHandler)new TlsMetricsHandler(this.recorder);
/*     */   }
/*     */ 
/*     */   
/*     */   public ContextAwareChannelMetricsRecorder recorder() {
/*  58 */     return this.recorder;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void recordException(ChannelHandlerContext ctx, SocketAddress address) {
/*  63 */     Connection connection = Connection.from(ctx.channel());
/*  64 */     ChannelOperations<?, ?> ops = (ChannelOperations<?, ?>)connection.as(ChannelOperations.class);
/*  65 */     if (ops != null) {
/*  66 */       recorder().incrementErrorsCount((ContextView)ops.currentContext(), address);
/*     */     }
/*  68 */     else if (connection instanceof ConnectionObserver) {
/*  69 */       recorder().incrementErrorsCount((ContextView)((ConnectionObserver)connection).currentContext(), address);
/*     */     } else {
/*     */       
/*  72 */       super.recordException(ctx, address);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void recordRead(ChannelHandlerContext ctx, SocketAddress address, long bytes) {
/*  78 */     ChannelOperations<?, ?> ops = ChannelOperations.get(ctx.channel());
/*  79 */     if (ops != null) {
/*  80 */       recorder().recordDataReceived((ContextView)ops.currentContext(), address, bytes);
/*     */     } else {
/*     */       
/*  83 */       super.recordRead(ctx, address, bytes);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void recordWrite(ChannelHandlerContext ctx, SocketAddress address, long bytes) {
/*  89 */     ChannelOperations<?, ?> ops = ChannelOperations.get(ctx.channel());
/*  90 */     if (ops != null) {
/*  91 */       recorder().recordDataSent((ContextView)ops.currentContext(), address, bytes);
/*     */     } else {
/*     */       
/*  94 */       super.recordWrite(ctx, address, bytes);
/*     */     } 
/*     */   }
/*     */   
/*     */   static final class ContextAwareConnectMetricsHandler
/*     */     extends ChannelOutboundHandlerAdapter {
/*     */     final ContextAwareChannelMetricsRecorder recorder;
/*     */     
/*     */     ContextAwareConnectMetricsHandler(ContextAwareChannelMetricsRecorder recorder) {
/* 103 */       this.recorder = recorder;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void connect(ChannelHandlerContext ctx, SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) throws Exception {
/* 109 */       long connectTimeStart = System.nanoTime();
/* 110 */       super.connect(ctx, remoteAddress, localAddress, promise);
/* 111 */       promise.addListener(future -> {
/*     */             ctx.pipeline().remove((ChannelHandler)this);
/*     */             recordConnectTime(ctx, remoteAddress, connectTimeStart, future.isSuccess() ? "SUCCESS" : "ERROR");
/*     */           });
/*     */     }
/*     */     
/*     */     void recordConnectTime(ChannelHandlerContext ctx, SocketAddress address, long connectTimeStart, String status) {
/* 118 */       Connection connection = Connection.from(ctx.channel());
/* 119 */       if (connection instanceof ConnectionObserver) {
/* 120 */         this.recorder.recordConnectTime((ContextView)((ConnectionObserver)connection)
/* 121 */             .currentContext(), address, 
/*     */             
/* 123 */             Duration.ofNanos(System.nanoTime() - connectTimeStart), status);
/*     */       }
/*     */       else {
/*     */         
/* 127 */         this.recorder.recordConnectTime(address, Duration.ofNanos(System.nanoTime() - connectTimeStart), status);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class TlsMetricsHandler extends ChannelMetricsHandler.TlsMetricsHandler {
/*     */     TlsMetricsHandler(ContextAwareChannelMetricsRecorder recorder) {
/* 134 */       super(recorder);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void recordTlsHandshakeTime(ChannelHandlerContext ctx, long tlsHandshakeTimeStart, String status) {
/* 139 */       Connection connection = Connection.from(ctx.channel());
/* 140 */       if (connection instanceof ConnectionObserver)
/* 141 */         ((ContextAwareChannelMetricsRecorder)this.recorder).recordTlsHandshakeTime((ContextView)((ConnectionObserver)connection)
/* 142 */             .currentContext(), ctx
/* 143 */             .channel().remoteAddress(), 
/* 144 */             Duration.ofNanos(System.nanoTime() - tlsHandshakeTimeStart), status); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\ContextAwareChannelMetricsHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */