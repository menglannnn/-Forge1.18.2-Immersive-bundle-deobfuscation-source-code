/*    */ package reactor.netty.channel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbortedException
/*    */   extends RuntimeException
/*    */ {
/*    */   static final String CONNECTION_CLOSED_BEFORE_SEND = "Connection has been closed BEFORE send operation";
/*    */   private static final long serialVersionUID = 6091789064032301718L;
/*    */   
/*    */   public AbortedException(String message) {
/* 31 */     super(message);
/*    */   }
/*    */   
/*    */   public AbortedException(Throwable throwable) {
/* 35 */     super(throwable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isConnectionReset(Throwable err) {
/* 47 */     return ((err instanceof AbortedException && "Connection has been closed BEFORE send operation".equals(err.getMessage())) || (err instanceof java.io.IOException && (err
/* 48 */       .getMessage() == null || err
/* 49 */       .getMessage()
/* 50 */       .contains("Broken pipe") || err
/* 51 */       .getMessage()
/* 52 */       .contains("Connection reset by peer"))) || (err instanceof java.net.SocketException && err
/* 53 */       .getMessage() != null && err
/* 54 */       .getMessage()
/* 55 */       .contains("Connection reset by peer")));
/*    */   }
/*    */   
/*    */   public static AbortedException beforeSend() {
/* 59 */     return new AbortedException("Connection has been closed BEFORE send operation");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\AbortedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */