package reactor.netty.channel;

import java.net.SocketAddress;
import java.time.Duration;

public interface ChannelMetricsRecorder {
  void recordDataReceived(SocketAddress paramSocketAddress, long paramLong);
  
  void recordDataSent(SocketAddress paramSocketAddress, long paramLong);
  
  void incrementErrorsCount(SocketAddress paramSocketAddress);
  
  void recordTlsHandshakeTime(SocketAddress paramSocketAddress, Duration paramDuration, String paramString);
  
  void recordConnectTime(SocketAddress paramSocketAddress, Duration paramDuration, String paramString);
  
  void recordResolveAddressTime(SocketAddress paramSocketAddress, Duration paramDuration, String paramString);
  
  default void recordServerConnectionOpened(SocketAddress localAddress) {}
  
  default void recordServerConnectionClosed(SocketAddress localAddress) {}
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\ChannelMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */