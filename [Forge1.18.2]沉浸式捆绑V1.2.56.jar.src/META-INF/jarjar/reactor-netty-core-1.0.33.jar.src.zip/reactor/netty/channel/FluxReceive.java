/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.IntConsumer;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FluxReceive
/*     */   extends Flux<Object>
/*     */   implements Subscription, Disposable
/*     */ {
/*     */   static final int QUEUE_LOW_LIMIT = 32;
/*     */   final Channel channel;
/*     */   final ChannelOperations<?, ?> parent;
/*     */   final EventLoop eventLoop;
/*     */   CoreSubscriber<? super Object> receiver;
/*     */   boolean receiverFastpath;
/*     */   long receiverDemand;
/*     */   Queue<Object> receiverQueue;
/*     */   boolean needRead = true;
/*     */   volatile boolean inboundDone;
/*     */   Throwable inboundError;
/*     */   volatile IntConsumer receiverCancel;
/*     */   boolean subscribedOnce;
/*     */   int wip;
/*     */   
/*     */   FluxReceive(ChannelOperations<?, ?> parent) {
/*  78 */     this.parent = parent;
/*  79 */     this.channel = parent.channel();
/*  80 */     this.eventLoop = this.channel.eventLoop();
/*  81 */     this.channel.config()
/*  82 */       .setAutoRead(false);
/*  83 */     CANCEL.lazySet(this, state -> {
/*     */           if (this.eventLoop.inEventLoop()) {
/*     */             if (state == 1) {
/*     */               disposeAndUnsubscribeReceiver();
/*     */             } else {
/*     */               unsubscribeReceiver();
/*     */             } 
/*     */           } else if (state == 1) {
/*     */             this.eventLoop.execute(this::disposeAndUnsubscribeReceiver);
/*     */           } else {
/*     */             this.eventLoop.execute(this::unsubscribeReceiver);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 105 */     doCancel(0);
/*     */   }
/*     */   
/*     */   final long getPending() {
/* 109 */     return (this.receiverQueue != null) ? this.receiverQueue.size() : 0L;
/*     */   }
/*     */   
/*     */   final boolean isCancelled() {
/* 113 */     return (this.receiverCancel == CANCELLED);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 118 */     doCancel(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 123 */     return (this.inboundDone && (this.receiverQueue == null || this.receiverQueue.isEmpty()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void request(long n) {
/* 128 */     if (Operators.validate(n)) {
/* 129 */       if (this.eventLoop.inEventLoop()) {
/* 130 */         this.receiverDemand = Operators.addCap(this.receiverDemand, n);
/* 131 */         drainReceiver();
/*     */       } else {
/*     */         
/* 134 */         this.eventLoop.execute(() -> {
/*     */               this.receiverDemand = Operators.addCap(this.receiverDemand, n);
/*     */               drainReceiver();
/*     */             });
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Object> s) {
/* 144 */     if (this.eventLoop.inEventLoop()) {
/* 145 */       startReceiver(s);
/*     */     } else {
/*     */       
/* 148 */       this.eventLoop.execute(() -> startReceiver(s));
/*     */     } 
/*     */   }
/*     */   
/*     */   final void startReceiver(CoreSubscriber<? super Object> s) {
/* 153 */     if (!this.subscribedOnce) {
/* 154 */       this.subscribedOnce = true;
/* 155 */       if (log.isDebugEnabled()) {
/* 156 */         log.debug(ReactorNetty.format(this.channel, "{}: subscribing inbound receiver"), new Object[] { this });
/*     */       }
/* 158 */       if ((this.inboundDone && getPending() == 0L) || isCancelled()) {
/* 159 */         if (this.inboundError != null) {
/* 160 */           Operators.error((Subscriber)s, this.inboundError);
/*     */           
/*     */           return;
/*     */         } 
/* 164 */         Operators.complete((Subscriber)s);
/*     */         
/*     */         return;
/*     */       } 
/* 168 */       this.receiver = s;
/*     */       
/* 170 */       s.onSubscribe(this);
/*     */     
/*     */     }
/* 173 */     else if (this.inboundDone && getPending() == 0L) {
/* 174 */       if (this.inboundError != null) {
/* 175 */         Operators.error((Subscriber)s, this.inboundError);
/*     */         
/*     */         return;
/*     */       } 
/* 179 */       Operators.complete((Subscriber)s);
/*     */     } else {
/*     */       
/* 182 */       if (log.isDebugEnabled()) {
/* 183 */         log.debug(ReactorNetty.format(this.channel, "{}: Rejecting additional inbound receiver."), new Object[] { this });
/*     */       }
/*     */       
/* 186 */       String msg = "Rejecting additional inbound receiver. State=" + toString(false);
/*     */       
/* 188 */       IllegalStateException ex = (this.inboundError == null) ? new IllegalStateException(msg) : new IllegalStateException(msg, this.inboundError);
/* 189 */       Operators.error((Subscriber)s, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   final void cancelReceiver(int cancelCode) {
/* 195 */     IntConsumer c = this.receiverCancel;
/* 196 */     if (c != CANCELLED) {
/* 197 */       c = CANCEL.getAndSet(this, CANCELLED);
/* 198 */       if (c != CANCELLED) {
/* 199 */         c.accept(cancelCode);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   final void doCancel(int cancelCode) {
/* 205 */     cancelReceiver(cancelCode);
/* 206 */     if (this.eventLoop.inEventLoop()) {
/* 207 */       drainReceiver();
/*     */     } else {
/*     */       
/* 210 */       this.eventLoop.execute(this::drainReceiver);
/*     */     } 
/*     */   }
/*     */   
/*     */   final void cleanQueue(@Nullable Queue<Object> q) {
/* 215 */     if (q != null) {
/*     */       Object o;
/* 217 */       while ((o = q.poll()) != null) {
/* 218 */         if (log.isDebugEnabled()) {
/* 219 */           log.debug(ReactorNetty.format(this.channel, "{}: dropping frame {}"), new Object[] { this, this.parent.asDebugLogMessage(o) });
/*     */         }
/* 221 */         ReferenceCountUtil.release(o);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   final void drainReceiver() {
/* 228 */     if (this.wip++ != 0) {
/*     */       return;
/*     */     }
/* 231 */     int missed = 1;
/*     */     while (true) {
/* 233 */       Queue<Object> q = this.receiverQueue;
/* 234 */       CoreSubscriber<? super Object> a = this.receiver;
/* 235 */       boolean d = this.inboundDone;
/*     */       
/* 237 */       if (a == null) {
/* 238 */         if (isCancelled()) {
/* 239 */           cleanQueue(q);
/*     */           return;
/*     */         } 
/* 242 */         if (d && getPending() == 0L) {
/* 243 */           Throwable ex = this.inboundError;
/* 244 */           if (ex != null) {
/* 245 */             this.parent.listener.onUncaughtException(this.parent, ex);
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/* 250 */         missed = this.wip -= missed;
/*     */         
/* 252 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 258 */       long r = this.receiverDemand;
/* 259 */       long e = 0L;
/*     */       
/* 261 */       while (e != r) {
/* 262 */         if (isCancelled()) {
/* 263 */           cleanQueue(q);
/* 264 */           terminateReceiver(q, a);
/*     */           
/*     */           return;
/*     */         } 
/* 268 */         d = this.inboundDone;
/* 269 */         Object v = (q != null) ? q.poll() : null;
/* 270 */         boolean empty = (v == null);
/*     */         
/* 272 */         if (d && empty) {
/* 273 */           terminateReceiver(q, a);
/*     */           
/*     */           return;
/*     */         } 
/* 277 */         if (empty) {
/*     */           break;
/*     */         }
/*     */         
/*     */         try {
/* 282 */           if (logLeakDetection.isDebugEnabled()) {
/* 283 */             if (v instanceof ByteBuf) {
/* 284 */               ((ByteBuf)v).touch(ReactorNetty.format(this.channel, "Receiver " + a.getClass().getName() + " will handle the message from this point"));
/*     */             
/*     */             }
/* 287 */             else if (v instanceof ByteBufHolder) {
/* 288 */               ((ByteBufHolder)v).touch(ReactorNetty.format(this.channel, "Receiver " + a.getClass().getName() + " will handle the message from this point"));
/*     */             } 
/*     */           }
/*     */           
/* 292 */           a.onNext(v);
/*     */         } finally {
/*     */           
/*     */           try {
/* 296 */             ReferenceCountUtil.release(v);
/*     */           }
/* 298 */           catch (Throwable t) {
/* 299 */             this.inboundError = t;
/* 300 */             cleanQueue(q);
/* 301 */             terminateReceiver(q, a);
/*     */           } 
/*     */         } 
/*     */         
/* 305 */         e++;
/*     */       } 
/*     */       
/* 308 */       if (isCancelled()) {
/* 309 */         cleanQueue(q);
/* 310 */         terminateReceiver(q, a);
/*     */         
/*     */         return;
/*     */       } 
/* 314 */       if (this.inboundDone && (q == null || q.isEmpty())) {
/* 315 */         terminateReceiver(q, a);
/*     */         
/*     */         return;
/*     */       } 
/* 319 */       if (r == Long.MAX_VALUE) {
/* 320 */         this.receiverFastpath = true;
/* 321 */         if (this.needRead) {
/* 322 */           this.needRead = false;
/* 323 */           this.channel.config()
/* 324 */             .setAutoRead(true);
/*     */         } 
/*     */         
/* 327 */         missed = this.wip -= missed;
/*     */         
/* 329 */         if (missed == 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 334 */       if ((this.receiverDemand -= e) > 0L || (e > 0L && q.size() < 32)) {
/* 335 */         if (this.needRead) {
/* 336 */           this.needRead = false;
/* 337 */           this.channel.config()
/* 338 */             .setAutoRead(true);
/*     */         }
/*     */       
/* 341 */       } else if (!this.needRead) {
/* 342 */         this.needRead = true;
/* 343 */         this.channel.config()
/* 344 */           .setAutoRead(false);
/*     */       } 
/*     */ 
/*     */       
/* 348 */       missed = this.wip -= missed;
/*     */       
/* 350 */       if (missed == 0) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   final void onInboundNext(Object msg) {
/* 357 */     if (this.inboundDone || isCancelled()) {
/* 358 */       if (log.isDebugEnabled()) {
/* 359 */         log.debug(ReactorNetty.format(this.channel, "{}: dropping frame {}"), new Object[] { this, this.parent.asDebugLogMessage(msg) });
/*     */       }
/* 361 */       ReferenceCountUtil.release(msg);
/*     */       
/*     */       return;
/*     */     } 
/* 365 */     if (this.receiverFastpath && this.receiver != null) {
/*     */       try {
/* 367 */         if (logLeakDetection.isDebugEnabled()) {
/* 368 */           if (msg instanceof ByteBuf) {
/* 369 */             ((ByteBuf)msg).touch(ReactorNetty.format(this.channel, "Receiver " + this.receiver.getClass().getName() + " will handle the message from this point"));
/*     */           
/*     */           }
/* 372 */           else if (msg instanceof ByteBufHolder) {
/* 373 */             ((ByteBufHolder)msg).touch(ReactorNetty.format(this.channel, "Receiver " + this.receiver.getClass().getName() + " will handle the message from this point"));
/*     */           } 
/*     */         }
/*     */         
/* 377 */         this.receiver.onNext(msg);
/*     */       } finally {
/*     */         
/* 380 */         ReferenceCountUtil.release(msg);
/*     */       } 
/*     */     } else {
/*     */       
/* 384 */       Queue<Object> q = this.receiverQueue;
/* 385 */       if (q == null) {
/*     */ 
/*     */ 
/*     */         
/* 389 */         q = new ArrayDeque();
/* 390 */         this.receiverQueue = q;
/*     */       } 
/* 392 */       if (logLeakDetection.isDebugEnabled()) {
/* 393 */         if (msg instanceof ByteBuf) {
/* 394 */           ((ByteBuf)msg).touch(ReactorNetty.format(this.channel, "Buffered ByteBuf in the inbound buffer queue"));
/*     */         }
/* 396 */         else if (msg instanceof ByteBufHolder) {
/* 397 */           ((ByteBufHolder)msg).touch(ReactorNetty.format(this.channel, "Buffered ByteBufHolder in the inbound buffer queue"));
/*     */         } 
/*     */       }
/* 400 */       q.offer(msg);
/* 401 */       drainReceiver();
/*     */     } 
/*     */   }
/*     */   
/*     */   final void onInboundComplete() {
/* 406 */     if (this.inboundDone) {
/*     */       return;
/*     */     }
/* 409 */     this.inboundDone = true;
/* 410 */     if (this.receiverFastpath) {
/* 411 */       CoreSubscriber<?> receiver = this.receiver;
/* 412 */       if (receiver != null) {
/* 413 */         receiver.onComplete();
/*     */       }
/*     */       return;
/*     */     } 
/* 417 */     drainReceiver();
/*     */   }
/*     */   
/*     */   final void onInboundError(Throwable err) {
/* 421 */     if (isCancelled() || this.inboundDone) {
/* 422 */       if (log.isDebugEnabled()) {
/* 423 */         if (AbortedException.isConnectionReset(err)) {
/* 424 */           log.debug(ReactorNetty.format(this.channel, "Connection reset has been observed post termination"), err);
/*     */         } else {
/*     */           
/* 427 */           log.warn(ReactorNetty.format(this.channel, "An exception has been observed post termination"), err);
/*     */         }
/*     */       
/* 430 */       } else if (log.isWarnEnabled() && !AbortedException.isConnectionReset(err)) {
/* 431 */         log.warn(ReactorNetty.format(this.channel, "An exception has been observed post termination, use DEBUG level to see the full stack: {}"), new Object[] { err.toString() });
/*     */       } 
/*     */       return;
/*     */     } 
/* 435 */     CoreSubscriber<?> receiver = this.receiver;
/* 436 */     this.inboundDone = true;
/* 437 */     if (this.channel.isActive()) {
/* 438 */       this.parent.markPersistent(false);
/*     */     }
/*     */     
/* 441 */     if (err instanceof OutOfMemoryError) {
/* 442 */       this.inboundError = this.parent.wrapInboundError(err);
/*     */       try {
/* 444 */         if (receiver != null)
/*     */         {
/* 446 */           receiver.onError(this.inboundError);
/*     */         
/*     */         }
/*     */       }
/*     */       finally {
/*     */         
/* 452 */         this.parent.terminate();
/*     */       }
/*     */     
/* 455 */     } else if (err instanceof java.nio.channels.ClosedChannelException) {
/* 456 */       this.inboundError = this.parent.wrapInboundError(err);
/*     */     } else {
/*     */       
/* 459 */       this.inboundError = err;
/*     */     } 
/*     */     
/* 462 */     if (this.receiverFastpath && receiver != null) {
/* 463 */       receiver.onError(this.inboundError);
/*     */     } else {
/*     */       
/* 466 */       drainReceiver();
/*     */     } 
/*     */   }
/*     */   
/*     */   final void terminateReceiver(@Nullable Queue<?> q, CoreSubscriber<?> a) {
/* 471 */     if (q != null) {
/* 472 */       q.clear();
/*     */     }
/* 474 */     Throwable ex = this.inboundError;
/* 475 */     this.receiver = null;
/* 476 */     if (ex != null) {
/*     */       
/* 478 */       a.onError(ex);
/*     */     } else {
/*     */       
/* 481 */       a.onComplete();
/*     */     } 
/*     */   }
/*     */   
/*     */   final void disposeAndUnsubscribeReceiver() {
/* 486 */     CoreSubscriber<? super Object> a = this.receiver;
/* 487 */     this.receiverDemand = 0L;
/* 488 */     this.receiver = null;
/* 489 */     if (isCancelled()) {
/* 490 */       this.parent.onInboundCancel();
/*     */     }
/*     */     
/* 493 */     if (a != null) {
/* 494 */       Throwable ex = this.inboundError;
/* 495 */       if (ex != null) {
/* 496 */         a.onError(ex);
/*     */       } else {
/*     */         
/* 499 */         a.onComplete();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   final void unsubscribeReceiver() {
/* 505 */     this.receiverDemand = 0L;
/* 506 */     this.receiver = null;
/* 507 */     if (isCancelled()) {
/* 508 */       this.parent.onInboundCancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 514 */     return toString(true);
/*     */   }
/*     */   
/*     */   final String toString(boolean logErrorMessage) {
/* 518 */     return "[terminated=" + this.inboundDone + ", cancelled=" + 
/*     */       
/* 520 */       isCancelled() + ", pending=" + 
/* 521 */       getPending() + ", error=" + (
/* 522 */       logErrorMessage ? (String)this.inboundError : (String)Boolean.valueOf((this.inboundError != null))) + ']';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 527 */   static final AtomicReferenceFieldUpdater<FluxReceive, IntConsumer> CANCEL = AtomicReferenceFieldUpdater.newUpdater(FluxReceive.class, IntConsumer.class, "receiverCancel");
/*     */ 
/*     */   
/*     */   static final IntConsumer CANCELLED = __ -> {
/*     */     
/*     */     };
/*     */   
/* 534 */   static final Logger log = Loggers.getLogger(FluxReceive.class);
/*     */   
/* 536 */   static final Logger logLeakDetection = Loggers.getLogger("_reactor.netty.channel.LeakDetection");
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\FluxReceive.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */