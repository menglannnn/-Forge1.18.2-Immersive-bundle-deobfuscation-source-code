/*    */ package reactor.netty.channel;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.ByteBufHolder;
/*    */ import io.netty.channel.Channel;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.util.ReferenceCountUtil;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.ToIntFunction;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.netty.ReactorNetty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MonoSend<I, O>
/*    */   extends Mono<Void>
/*    */ {
/*    */   final ChannelHandlerContext ctx;
/*    */   final Function<? super I, ? extends O> transformer;
/*    */   final Consumer<? super I> sourceCleanup;
/*    */   final ToIntFunction<? super O> sizeOf;
/*    */   static final int MAX_SIZE = 128;
/*    */   static final int REFILL_SIZE = 64;
/*    */   static final Function<ByteBuf, ByteBuf> TRANSFORMATION_FUNCTION_BB;
/*    */   
/*    */   MonoSend(Channel channel, Function<? super I, ? extends O> transformer, Consumer<? super I> sourceCleanup, ToIntFunction<? super O> sizeOf) {
/* 46 */     this.transformer = Objects.<Function<? super I, ? extends O>>requireNonNull(transformer, "source transformer cannot be null");
/* 47 */     this.sourceCleanup = Objects.<Consumer<? super I>>requireNonNull(sourceCleanup, "source cleanup handler cannot be null");
/* 48 */     this.sizeOf = Objects.<ToIntFunction<? super O>>requireNonNull(sizeOf, "message size mapper cannot be null");
/*    */     
/* 50 */     this.ctx = Objects.<ChannelHandlerContext>requireNonNull(channel.pipeline().lastContext(), "reactiveBridge is not installed");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static <O> ToIntFunction<O> defaultSizeOf() {
/* 56 */     return (ToIntFunction)SIZE_OF;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/* 63 */     TRANSFORMATION_FUNCTION_BB = (msg -> ReactorNetty.PREDICATE_GROUP_FLUSH.test(msg) ? null : msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   static final Function<Object, Object> TRANSFORMATION_FUNCTION = Function.identity();
/*    */   
/* 73 */   static final Consumer<Object> CONSUMER_NOCHECK_CLEANUP = ReferenceCountUtil::release;
/*    */   
/* 75 */   static final ToIntFunction<ByteBuf> SIZE_OF_BB = ByteBuf::readableBytes;
/*    */   static {
/* 77 */     SIZE_OF = (msg -> (msg instanceof ByteBufHolder) ? ((ByteBufHolder)msg).content().readableBytes() : ((msg instanceof ByteBuf) ? ((ByteBuf)msg).readableBytes() : ((msg instanceof io.netty.channel.FileRegion) ? 0 : -1)));
/*    */   }
/*    */   
/*    */   static final ToIntFunction<Object> SIZE_OF;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\MonoSend.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */