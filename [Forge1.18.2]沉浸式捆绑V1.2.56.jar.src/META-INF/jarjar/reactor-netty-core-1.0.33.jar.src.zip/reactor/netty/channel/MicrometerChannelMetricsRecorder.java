/*     */ package reactor.netty.channel;
/*     */ 
/*     */ import io.micrometer.core.instrument.Counter;
/*     */ import io.micrometer.core.instrument.DistributionSummary;
/*     */ import io.micrometer.core.instrument.Gauge;
/*     */ import io.micrometer.core.instrument.Timer;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.LongAdder;
/*     */ import reactor.netty.Metrics;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MicrometerChannelMetricsRecorder
/*     */   implements ChannelMetricsRecorder
/*     */ {
/*     */   static final String ADDRESS_RESOLVER_TIME_DESCRIPTION = "Time spent for resolving the address";
/*     */   protected static final String BYTES_UNIT = "bytes";
/*     */   static final String CONNECT_TIME_DESCRIPTION = "Time spent for connecting to the remote address";
/*     */   protected static final String DATA_RECEIVED_DESCRIPTION = "Amount of the data received, in bytes";
/*     */   protected static final String DATA_SENT_DESCRIPTION = "Amount of the data sent, in bytes";
/*     */   protected static final String ERRORS_DESCRIPTION = "Number of errors that occurred";
/*     */   static final String TLS_HANDSHAKE_TIME_DESCRIPTION = "Time spent for TLS handshake";
/*     */   static final String TOTAL_CONNECTIONS_DESCRIPTION = "The number of all opened connections";
/*  62 */   final ConcurrentMap<String, DistributionSummary> dataReceivedCache = new ConcurrentHashMap<>();
/*     */   
/*  64 */   final ConcurrentMap<String, DistributionSummary> dataSentCache = new ConcurrentHashMap<>();
/*     */   
/*  66 */   final ConcurrentMap<String, Counter> errorsCache = new ConcurrentHashMap<>();
/*     */   
/*  68 */   final ConcurrentMap<MeterKey, Timer> connectTimeCache = new ConcurrentHashMap<>();
/*     */   
/*  70 */   final ConcurrentMap<MeterKey, Timer> tlsHandshakeTimeCache = new ConcurrentHashMap<>();
/*     */   
/*  72 */   final ConcurrentMap<MeterKey, Timer> addressResolverTimeCache = new ConcurrentHashMap<>();
/*     */   
/*  74 */   final ConcurrentMap<String, LongAdder> totalConnectionsCache = new ConcurrentHashMap<>();
/*  75 */   final LongAdder totalConnectionsAdder = new LongAdder();
/*     */   final String name;
/*     */   final String protocol;
/*     */   
/*     */   public MicrometerChannelMetricsRecorder(String name, String protocol) {
/*  80 */     this.name = name;
/*  81 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataReceived(SocketAddress remoteAddress, long bytes) {
/*  86 */     String address = Metrics.formatSocketAddress(remoteAddress);
/*  87 */     DistributionSummary ds = (DistributionSummary)MapUtils.computeIfAbsent(this.dataReceivedCache, address, key -> (DistributionSummary)filter(DistributionSummary.builder(this.name + ".data.received").baseUnit("bytes").description("Amount of the data received, in bytes").tags(new String[] { "uri", this.protocol, "remote.address", address }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     if (ds != null) {
/*  94 */       ds.record(bytes);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordDataSent(SocketAddress remoteAddress, long bytes) {
/* 100 */     String address = Metrics.formatSocketAddress(remoteAddress);
/* 101 */     DistributionSummary ds = (DistributionSummary)MapUtils.computeIfAbsent(this.dataSentCache, address, key -> (DistributionSummary)filter(DistributionSummary.builder(this.name + ".data.sent").baseUnit("bytes").description("Amount of the data sent, in bytes").tags(new String[] { "uri", this.protocol, "remote.address", address }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     if (ds != null) {
/* 108 */       ds.record(bytes);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void incrementErrorsCount(SocketAddress remoteAddress) {
/* 114 */     String address = Metrics.formatSocketAddress(remoteAddress);
/* 115 */     Counter c = (Counter)MapUtils.computeIfAbsent(this.errorsCache, address, key -> (Counter)filter(Counter.builder(this.name + ".errors").description("Number of errors that occurred").tags(new String[] { "uri", this.protocol, "remote.address", address }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (c != null) {
/* 121 */       c.increment();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordTlsHandshakeTime(SocketAddress remoteAddress, Duration time, String status) {
/* 127 */     String address = Metrics.formatSocketAddress(remoteAddress);
/* 128 */     MeterKey meterKey = new MeterKey(null, address, null, status);
/* 129 */     Timer timer = (Timer)MapUtils.computeIfAbsent(this.tlsHandshakeTimeCache, meterKey, key -> (Timer)filter(Timer.builder(this.name + ".tls.handshake.time").description("Time spent for TLS handshake").tags(new String[] { "remote.address", address, "status", status }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (timer != null) {
/* 135 */       timer.record(time);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordConnectTime(SocketAddress remoteAddress, Duration time, String status) {
/* 141 */     String address = Metrics.formatSocketAddress(remoteAddress);
/* 142 */     MeterKey meterKey = new MeterKey(null, address, null, status);
/* 143 */     Timer timer = (Timer)MapUtils.computeIfAbsent(this.connectTimeCache, meterKey, key -> (Timer)filter(Timer.builder(this.name + ".connect.time").description("Time spent for connecting to the remote address").tags(new String[] { "remote.address", address, "status", status }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     if (timer != null) {
/* 149 */       timer.record(time);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordResolveAddressTime(SocketAddress remoteAddress, Duration time, String status) {
/* 155 */     String address = Metrics.formatSocketAddress(remoteAddress);
/* 156 */     MeterKey meterKey = new MeterKey(null, address, null, status);
/* 157 */     Timer timer = (Timer)MapUtils.computeIfAbsent(this.addressResolverTimeCache, meterKey, key -> (Timer)filter(Timer.builder(this.name + ".address.resolver").description("Time spent for resolving the address").tags(new String[] { "remote.address", address, "status", status }).register(Metrics.REGISTRY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     if (timer != null) {
/* 163 */       timer.record(time);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordServerConnectionOpened(SocketAddress serverAddress) {
/* 169 */     LongAdder totalConnectionAdder = getTotalConnectionsAdder(serverAddress);
/* 170 */     if (totalConnectionAdder != null) {
/* 171 */       totalConnectionAdder.increment();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordServerConnectionClosed(SocketAddress serverAddress) {
/* 177 */     LongAdder totalConnectionAdder = getTotalConnectionsAdder(serverAddress);
/* 178 */     if (totalConnectionAdder != null) {
/* 179 */       totalConnectionAdder.decrement();
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected static <M extends io.micrometer.core.instrument.Meter> M filter(M meter) {
/* 185 */     if (meter instanceof io.micrometer.core.instrument.noop.NoopMeter) {
/* 186 */       return null;
/*     */     }
/*     */     
/* 189 */     return meter;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String name() {
/* 194 */     return this.name;
/*     */   }
/*     */   
/*     */   protected String protocol() {
/* 198 */     return this.protocol;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private LongAdder getTotalConnectionsAdder(SocketAddress serverAddress) {
/* 203 */     String address = Metrics.formatSocketAddress(serverAddress);
/* 204 */     return (LongAdder)MapUtils.computeIfAbsent(this.totalConnectionsCache, address, key -> {
/*     */           Gauge gauge = filter(Gauge.builder(this.name + ".connections.total", this.totalConnectionsAdder, LongAdder::longValue).description("The number of all opened connections").tags(new String[] { "uri", this.protocol, "local.address", address }).register(Metrics.REGISTRY));
/*     */           return (gauge != null) ? this.totalConnectionsAdder : null;
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\channel\MicrometerChannelMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */