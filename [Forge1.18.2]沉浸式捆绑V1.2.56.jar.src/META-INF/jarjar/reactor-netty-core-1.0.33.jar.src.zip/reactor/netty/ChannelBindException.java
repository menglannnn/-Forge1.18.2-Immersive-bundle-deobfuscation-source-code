/*    */ package reactor.netty;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.Objects;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelBindException
/*    */   extends RuntimeException
/*    */ {
/*    */   final String localHost;
/*    */   final int localPort;
/*    */   private static final long serialVersionUID = 1718814250958680216L;
/*    */   
/*    */   public static ChannelBindException fail(SocketAddress bindAddress, @Nullable Throwable cause) {
/* 41 */     Objects.requireNonNull(bindAddress, "bindAddress");
/* 42 */     if (cause instanceof java.net.BindException || (cause instanceof java.io.IOException && cause
/*    */ 
/*    */       
/* 45 */       .getMessage() != null && cause
/* 46 */       .getMessage().contains("bind(..)"))) {
/* 47 */       cause = null;
/*    */     }
/* 49 */     if (!(bindAddress instanceof InetSocketAddress)) {
/* 50 */       return new ChannelBindException(bindAddress.toString(), cause);
/*    */     }
/* 52 */     InetSocketAddress address = (InetSocketAddress)bindAddress;
/*    */     
/* 54 */     return new ChannelBindException(address.getHostString(), address.getPort(), cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ChannelBindException(String localHost, int localPort, @Nullable Throwable cause) {
/* 62 */     super("Failed to bind on [" + localHost + ":" + localPort + "]", cause);
/* 63 */     this.localHost = localHost;
/* 64 */     this.localPort = localPort;
/*    */   }
/*    */   
/*    */   protected ChannelBindException(String localHost, @Nullable Throwable cause) {
/* 68 */     super("Failed to bind on [" + localHost + "]", cause);
/* 69 */     this.localHost = localHost;
/* 70 */     this.localPort = -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized Throwable fillInStackTrace() {
/* 75 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String localHost() {
/* 84 */     return this.localHost;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int localPort() {
/* 93 */     return this.localPort;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\ChannelBindException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */