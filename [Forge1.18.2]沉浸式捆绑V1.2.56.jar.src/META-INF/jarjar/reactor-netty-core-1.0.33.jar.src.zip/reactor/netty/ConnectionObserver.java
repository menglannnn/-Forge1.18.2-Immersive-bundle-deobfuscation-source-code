/*     */ package reactor.netty;
/*     */ 
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface ConnectionObserver
/*     */ {
/*     */   static ConnectionObserver emptyListener() {
/*  41 */     return ReactorNetty.NOOP_LISTENER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Context currentContext() {
/*  50 */     return Context.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void onUncaughtException(Connection connection, Throwable error) {
/*  62 */     onStateChange(connection, State.DISCONNECTING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void onStateChange(Connection paramConnection, State paramState);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ConnectionObserver then(ConnectionObserver other) {
/*  81 */     return ReactorNetty.compositeConnectionObserver(this, other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface State
/*     */   {
/*  96 */     public static final State CONNECTED = ReactorNetty.CONNECTED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     public static final State CONFIGURED = ReactorNetty.CONFIGURED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     public static final State ACQUIRED = ReactorNetty.ACQUIRED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     public static final State RELEASED = ReactorNetty.RELEASED;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     public static final State DISCONNECTING = ReactorNetty.DISCONNECTING;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\ConnectionObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */