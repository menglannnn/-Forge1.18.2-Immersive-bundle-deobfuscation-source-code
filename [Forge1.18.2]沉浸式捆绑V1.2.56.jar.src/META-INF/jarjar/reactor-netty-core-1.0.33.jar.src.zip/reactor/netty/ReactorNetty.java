/*      */ package reactor.netty;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.buffer.ByteBufHolder;
/*      */ import io.netty.buffer.ByteBufUtil;
/*      */ import io.netty.buffer.Unpooled;
/*      */ import io.netty.channel.Channel;
/*      */ import io.netty.channel.ChannelHandler;
/*      */ import io.netty.channel.ChannelHandler.Sharable;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*      */ import io.netty.channel.ChannelPipeline;
/*      */ import io.netty.handler.ssl.SslHandler;
/*      */ import io.netty.handler.stream.ChunkedWriteHandler;
/*      */ import io.netty.handler.timeout.IdleState;
/*      */ import io.netty.handler.timeout.IdleStateEvent;
/*      */ import io.netty.handler.timeout.IdleStateHandler;
/*      */ import io.netty.util.AttributeKey;
/*      */ import io.netty.util.ReferenceCounted;
/*      */ import java.net.SocketAddress;
/*      */ import java.nio.channels.FileChannel;
/*      */ import java.nio.file.Path;
/*      */ import java.time.ZoneId;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BiFunction;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.CorePublisher;
/*      */ import reactor.core.Disposable;
/*      */ import reactor.core.publisher.BaseSubscriber;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.core.publisher.SignalType;
/*      */ import reactor.util.Logger;
/*      */ import reactor.util.Loggers;
/*      */ import reactor.util.annotation.Nullable;
/*      */ import reactor.util.context.Context;
/*      */ import reactor.util.context.ContextView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ReactorNetty
/*      */ {
/*   84 */   static final boolean LOG_CHANNEL_INFO = Boolean.parseBoolean(System.getProperty("reactor.netty.logChannelInfo", "true"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String IO_WORKER_COUNT = "reactor.netty.ioWorkerCount";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String IO_SELECT_COUNT = "reactor.netty.ioSelectCount";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String UDP_IO_THREAD_COUNT = "reactor.netty.udp.ioThreadCount";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SHUTDOWN_QUIET_PERIOD = "reactor.netty.ioShutdownQuietPeriod";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SHUTDOWN_TIMEOUT = "reactor.netty.ioShutdownTimeout";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String NATIVE = "reactor.netty.native";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String POOL_MAX_CONNECTIONS = "reactor.netty.pool.maxConnections";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String POOL_ACQUIRE_TIMEOUT = "reactor.netty.pool.acquireTimeout";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String POOL_MAX_IDLE_TIME = "reactor.netty.pool.maxIdleTime";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String POOL_MAX_LIFE_TIME = "reactor.netty.pool.maxLifeTime";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String POOL_LEASING_STRATEGY = "reactor.netty.pool.leasingStrategy";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String POOL_GET_PERMITS_SAMPLING_RATE = "reactor.netty.pool.getPermitsSamplingRate";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String POOL_RETURN_PERMITS_SAMPLING_RATE = "reactor.netty.pool.returnPermitsSamplingRate";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SSL_HANDSHAKE_TIMEOUT = "reactor.netty.tcp.sslHandshakeTimeout";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SSL_CLIENT_DEBUG = "reactor.netty.tcp.ssl.client.debug";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SSL_SERVER_DEBUG = "reactor.netty.tcp.ssl.server.debug";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String ACCESS_LOG_ENABLED = "reactor.netty.http.server.accessLogEnabled";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  199 */   public static final ZoneId ZONE_ID_SYSTEM = ZoneId.systemDefault();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void safeRelease(Object msg) {
/*  207 */     if (msg instanceof ReferenceCounted) {
/*  208 */       ReferenceCounted referenceCounted = (ReferenceCounted)msg;
/*  209 */       if (referenceCounted.refCnt() > 0) {
/*  210 */         referenceCounted.release();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String format(Channel channel, String msg) {
/*  222 */     Objects.requireNonNull(channel, "channel");
/*  223 */     Objects.requireNonNull(msg, "msg");
/*  224 */     if (LOG_CHANNEL_INFO) {
/*      */       StringBuilder result;
/*      */       
/*  227 */       Connection connection = Connection.from(channel);
/*  228 */       if (connection instanceof ChannelOperationsId) {
/*  229 */         String str = ((ChannelOperationsId)connection).asLongText();
/*  230 */         if (str.charAt(0) != '(') {
/*      */ 
/*      */ 
/*      */           
/*  234 */           result = (new StringBuilder(1 + str.length() + 2 + msg.length())).append('[').append(str).append("] ");
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  239 */           result = (new StringBuilder(str.length() + 1 + msg.length())).append(str).append(' ');
/*      */         } 
/*  241 */         return result.append(msg)
/*  242 */           .toString();
/*      */       } 
/*      */       
/*  245 */       String channelStr = channel.toString();
/*  246 */       if (channelStr.charAt(0) == '[') {
/*  247 */         channelStr = channelStr.substring(ORIGINAL_CHANNEL_ID_PREFIX_LENGTH);
/*      */ 
/*      */         
/*  250 */         result = (new StringBuilder(1 + channelStr.length() + 1 + msg.length())).append('[').append(channelStr);
/*      */       } else {
/*      */         
/*  253 */         int ind = channelStr.indexOf("[id: 0x");
/*      */ 
/*      */ 
/*      */         
/*  257 */         result = (new StringBuilder(1 + channelStr.length() - ORIGINAL_CHANNEL_ID_PREFIX_LENGTH + 1 + msg.length())).append(channelStr.substring(0, ind)).append('[').append(channelStr.substring(ind + ORIGINAL_CHANNEL_ID_PREFIX_LENGTH));
/*      */       } 
/*  259 */       return result.append(' ')
/*  260 */         .append(msg)
/*  261 */         .toString();
/*      */     } 
/*      */ 
/*      */     
/*  265 */     return msg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toPrettyHexDump(Object msg) {
/*      */     String result;
/*  273 */     Objects.requireNonNull(msg, "msg");
/*      */     
/*  275 */     if (msg instanceof ByteBufHolder && 
/*  276 */       !Objects.equals(Unpooled.EMPTY_BUFFER, ((ByteBufHolder)msg).content())) {
/*  277 */       ByteBuf buffer = ((ByteBufHolder)msg).content();
/*  278 */       result = "\n" + ByteBufUtil.prettyHexDump(buffer);
/*      */     }
/*  280 */     else if (msg instanceof ByteBuf) {
/*  281 */       result = "\n" + ByteBufUtil.prettyHexDump((ByteBuf)msg);
/*      */     } else {
/*      */       
/*  284 */       result = msg.toString();
/*      */     } 
/*  286 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static ContextView getChannelContext(Channel channel) {
/*  298 */     return (ContextView)channel.attr(CONTEXT_VIEW).get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setChannelContext(Channel channel, @Nullable ContextView contextView) {
/*  310 */     channel.attr(CONTEXT_VIEW).set(contextView);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RuntimeException wrapException(Throwable throwable) {
/*  319 */     return new InternalNettyException(Objects.<Throwable>requireNonNull(throwable));
/*      */   }
/*      */   
/*      */   static void addChunkedWriter(Connection c) {
/*  323 */     if (c.channel()
/*  324 */       .pipeline()
/*  325 */       .get(ChunkedWriteHandler.class) == null) {
/*  326 */       c.addHandlerLast("reactor.left.chunkedWriter", (ChannelHandler)new ChunkedWriteHandler());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void addHandlerBeforeReactorEndHandlers(Connection context, String name, ChannelHandler handler) {
/*  345 */     Objects.requireNonNull(name, "name");
/*  346 */     Objects.requireNonNull(handler, "handler");
/*      */     
/*  348 */     Channel channel = context.channel();
/*  349 */     boolean exists = (channel.pipeline().get(name) != null);
/*      */     
/*  351 */     if (exists) {
/*  352 */       if (log.isDebugEnabled()) {
/*  353 */         log.debug(format(channel, "Handler [{}] already exists in the pipeline, decoder has been skipped"), new Object[] { name });
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  360 */     String before = null;
/*  361 */     for (String s : channel.pipeline().names()) {
/*  362 */       if (s.startsWith("reactor.right.")) {
/*  363 */         before = s;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  368 */     if (before == null) {
/*  369 */       channel.pipeline().addLast(name, handler);
/*      */     } else {
/*      */       
/*  372 */       channel.pipeline().addBefore(before, name, handler);
/*      */     } 
/*      */     
/*  375 */     registerForClose(context.isPersistent(), name, context);
/*      */     
/*  377 */     if (log.isDebugEnabled()) {
/*  378 */       log.debug(format(channel, "Added decoder [{}] at the end of the user pipeline, full pipeline: {}"), new Object[] { name, channel
/*      */             
/*  380 */             .pipeline().names() });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void addHandlerAfterReactorCodecs(Connection context, String name, ChannelHandler handler) {
/*  400 */     Objects.requireNonNull(name, "name");
/*  401 */     Objects.requireNonNull(handler, "handler");
/*      */     
/*  403 */     Channel channel = context.channel();
/*  404 */     boolean exists = (channel.pipeline().get(name) != null);
/*      */     
/*  406 */     if (exists) {
/*  407 */       if (log.isDebugEnabled()) {
/*  408 */         log.debug(format(channel, "Handler [{}] already exists in the pipeline, encoder has been skipped"), new Object[] { name });
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  415 */     String after = null;
/*  416 */     for (String s : channel.pipeline().names()) {
/*  417 */       if (s.startsWith("reactor.left.")) {
/*  418 */         after = s;
/*      */       }
/*      */     } 
/*      */     
/*  422 */     if (after == null) {
/*  423 */       channel.pipeline().addFirst(name, handler);
/*      */     } else {
/*      */       
/*  426 */       channel.pipeline().addAfter(after, name, handler);
/*      */     } 
/*      */     
/*  429 */     registerForClose(context.isPersistent(), name, context);
/*      */     
/*  431 */     if (log.isDebugEnabled()) {
/*  432 */       log.debug(format(channel, "Added encoder [{}] at the beginning of the user pipeline, full pipeline: {}"), new Object[] { name, channel
/*      */             
/*  434 */             .pipeline().names() });
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean mustChunkFileTransfer(Connection c, Path file) {
/*  440 */     if (c.channel().parent() != null && c.channel().parent().pipeline().get("reactor.left.h2MultiplexHandler") != null) {
/*  441 */       return true;
/*      */     }
/*  443 */     ChannelPipeline p = c.channel().pipeline();
/*  444 */     return (p.get(SslHandler.class) != null || p
/*  445 */       .get("reactor.left.compressionHandler") != null || (
/*  446 */       !(c.channel().eventLoop() instanceof io.netty.channel.nio.NioEventLoop) && 
/*  447 */       !"file".equals(file.toUri().getScheme())));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void registerForClose(boolean shouldCleanupOnClose, String name, Connection context) {
/*  453 */     if (!shouldCleanupOnClose) {
/*      */       return;
/*      */     }
/*      */     
/*  457 */     context.onTerminate().subscribe(null, null, () -> context.removeHandler(name));
/*      */   }
/*      */   
/*      */   static void removeHandler(Channel channel, String name) {
/*  461 */     if (channel.isActive() && channel.pipeline()
/*  462 */       .context(name) != null) {
/*  463 */       channel.pipeline()
/*  464 */         .remove(name);
/*  465 */       if (log.isDebugEnabled()) {
/*  466 */         log.debug(format(channel, "Removed handler: {}, pipeline: {}"), new Object[] { name, channel
/*      */               
/*  468 */               .pipeline() });
/*      */       }
/*      */     }
/*  471 */     else if (log.isDebugEnabled()) {
/*  472 */       log.debug(format(channel, "Non Removed handler: {}, context: {}, pipeline: {}"), new Object[] { name, channel
/*      */             
/*  474 */             .pipeline()
/*  475 */             .context(name), channel
/*  476 */             .pipeline() });
/*      */     } 
/*      */   }
/*      */   
/*      */   static void replaceHandler(Channel channel, String name, ChannelHandler handler) {
/*  481 */     if (channel.isActive() && channel.pipeline()
/*  482 */       .context(name) != null) {
/*  483 */       channel.pipeline()
/*  484 */         .replace(name, name, handler);
/*  485 */       if (log.isDebugEnabled()) {
/*  486 */         log.debug(format(channel, "Replaced handler: {}, pipeline: {}"), new Object[] { name, channel
/*      */               
/*  488 */               .pipeline() });
/*      */       }
/*      */     }
/*  491 */     else if (log.isDebugEnabled()) {
/*  492 */       log.debug(format(channel, "Non Replaced handler: {}, context: {}, pipeline: {}"), new Object[] { name, channel
/*      */             
/*  494 */             .pipeline()
/*  495 */             .context(name), channel
/*  496 */             .pipeline() });
/*      */     } 
/*      */   }
/*      */   
/*      */   static ConnectionObserver compositeConnectionObserver(ConnectionObserver observer, ConnectionObserver other) {
/*      */     ConnectionObserver[] thizObservers, otherObservers;
/*      */     int pos;
/*  503 */     if (observer == ConnectionObserver.emptyListener()) {
/*  504 */       return other;
/*      */     }
/*      */     
/*  507 */     if (other == ConnectionObserver.emptyListener()) {
/*  508 */       return observer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  514 */     int length = 2;
/*      */     
/*  516 */     if (observer instanceof CompositeConnectionObserver) {
/*  517 */       thizObservers = ((CompositeConnectionObserver)observer).observers;
/*  518 */       length += thizObservers.length - 1;
/*      */     } else {
/*      */       
/*  521 */       thizObservers = null;
/*      */     } 
/*      */     
/*  524 */     if (other instanceof CompositeConnectionObserver) {
/*  525 */       otherObservers = ((CompositeConnectionObserver)other).observers;
/*  526 */       length += otherObservers.length - 1;
/*      */     } else {
/*      */       
/*  529 */       otherObservers = null;
/*      */     } 
/*      */     
/*  532 */     ConnectionObserver[] newObservers = new ConnectionObserver[length];
/*      */ 
/*      */     
/*  535 */     if (thizObservers != null) {
/*  536 */       pos = thizObservers.length;
/*  537 */       System.arraycopy(thizObservers, 0, newObservers, 0, pos);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  542 */       pos = 1;
/*  543 */       newObservers[0] = observer;
/*      */     } 
/*      */     
/*  546 */     if (otherObservers != null) {
/*  547 */       System.arraycopy(otherObservers, 0, newObservers, pos, otherObservers.length);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  552 */       newObservers[pos] = other;
/*      */     } 
/*      */     
/*  555 */     return new CompositeConnectionObserver(newObservers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, V> CorePublisher<V> publisherOrScalarMap(Publisher<T> publisher, Function<? super T, ? extends V> mapper) {
/*  562 */     if (publisher instanceof Callable) {
/*  563 */       return (CorePublisher<V>)Mono.fromCallable(new ScalarMap<>(publisher, mapper));
/*      */     }
/*  565 */     if (publisher instanceof Mono) {
/*  566 */       return (CorePublisher<V>)((Mono)publisher).map(mapper);
/*      */     }
/*      */     
/*  569 */     return (CorePublisher<V>)Flux.from(publisher)
/*  570 */       .map(mapper);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T, V> CorePublisher<V> publisherOrScalarMap(Publisher<T> publisher, Function<? super T, ? extends V> monoMapper, Function<? super List<T>, ? extends V> fluxMapper) {
/*  578 */     if (publisher instanceof Callable) {
/*  579 */       return (CorePublisher<V>)Mono.fromCallable(new ScalarMap<>(publisher, monoMapper));
/*      */     }
/*  581 */     if (publisher instanceof Mono) {
/*  582 */       return (CorePublisher<V>)((Mono)publisher).map(monoMapper);
/*      */     }
/*      */     
/*  585 */     return (CorePublisher<V>)Flux.from(publisher)
/*  586 */       .collectList()
/*  587 */       .map(fluxMapper);
/*      */   }
/*      */ 
/*      */   
/*      */   static final class ScalarMap<T, V>
/*      */     implements Callable<V>
/*      */   {
/*      */     final Callable<T> source;
/*      */     
/*      */     final Function<? super T, ? extends V> mapper;
/*      */ 
/*      */     
/*      */     ScalarMap(Publisher<T> source, Function<? super T, ? extends V> mapper) {
/*  600 */       this.source = (Callable<T>)source;
/*  601 */       this.mapper = mapper;
/*      */     }
/*      */ 
/*      */     
/*      */     public V call() throws Exception {
/*  606 */       T called = this.source.call();
/*  607 */       if (called == null) {
/*  608 */         return null;
/*      */       }
/*  610 */       return this.mapper.apply(called);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class CompositeChannelPipelineConfigurer
/*      */     implements ChannelPipelineConfigurer {
/*      */     final ChannelPipelineConfigurer[] configurers;
/*      */     
/*      */     CompositeChannelPipelineConfigurer(ChannelPipelineConfigurer[] configurers) {
/*  619 */       this.configurers = configurers;
/*      */     }
/*      */ 
/*      */     
/*      */     public void onChannelInit(ConnectionObserver connectionObserver, Channel channel, @Nullable SocketAddress remoteAddress) {
/*  624 */       for (ChannelPipelineConfigurer configurer : this.configurers) {
/*  625 */         configurer.onChannelInit(connectionObserver, channel, remoteAddress);
/*      */       }
/*      */     }
/*      */     
/*      */     static ChannelPipelineConfigurer compositeChannelPipelineConfigurer(ChannelPipelineConfigurer configurer, ChannelPipelineConfigurer other) {
/*      */       ChannelPipelineConfigurer[] thizConfigurers, otherConfigurers;
/*      */       int pos;
/*  632 */       if (configurer == ChannelPipelineConfigurer.emptyConfigurer()) {
/*  633 */         return other;
/*      */       }
/*      */       
/*  636 */       if (other == ChannelPipelineConfigurer.emptyConfigurer()) {
/*  637 */         return configurer;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  643 */       int length = 2;
/*      */       
/*  645 */       if (configurer instanceof CompositeChannelPipelineConfigurer) {
/*  646 */         thizConfigurers = ((CompositeChannelPipelineConfigurer)configurer).configurers;
/*  647 */         length += thizConfigurers.length - 1;
/*      */       } else {
/*      */         
/*  650 */         thizConfigurers = null;
/*      */       } 
/*      */       
/*  653 */       if (other instanceof CompositeChannelPipelineConfigurer) {
/*  654 */         otherConfigurers = ((CompositeChannelPipelineConfigurer)other).configurers;
/*  655 */         length += otherConfigurers.length - 1;
/*      */       } else {
/*      */         
/*  658 */         otherConfigurers = null;
/*      */       } 
/*      */       
/*  661 */       ChannelPipelineConfigurer[] newConfigurers = new ChannelPipelineConfigurer[length];
/*      */ 
/*      */       
/*  664 */       if (thizConfigurers != null) {
/*  665 */         pos = thizConfigurers.length;
/*  666 */         System.arraycopy(thizConfigurers, 0, newConfigurers, 0, pos);
/*      */       } else {
/*      */         
/*  669 */         pos = 1;
/*  670 */         newConfigurers[0] = configurer;
/*      */       } 
/*      */       
/*  673 */       if (otherConfigurers != null) {
/*  674 */         System.arraycopy(otherConfigurers, 0, newConfigurers, pos, otherConfigurers.length);
/*      */       } else {
/*      */         
/*  677 */         newConfigurers[pos] = other;
/*      */       } 
/*      */       
/*  680 */       return new CompositeChannelPipelineConfigurer(newConfigurers);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class CompositeConnectionObserver
/*      */     implements ConnectionObserver {
/*      */     final ConnectionObserver[] observers;
/*      */     
/*      */     CompositeConnectionObserver(ConnectionObserver[] observers) {
/*  689 */       this.observers = observers;
/*      */     }
/*      */ 
/*      */     
/*      */     public Context currentContext() {
/*  694 */       return this.observers[this.observers.length - 1].currentContext();
/*      */     }
/*      */ 
/*      */     
/*      */     public void onUncaughtException(Connection connection, Throwable error) {
/*  699 */       for (ConnectionObserver observer : this.observers) {
/*  700 */         observer.onUncaughtException(connection, error);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/*  706 */       for (ConnectionObserver observer : this.observers) {
/*  707 */         observer.onStateChange(connection, newState);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class OutboundThen
/*      */     implements NettyOutbound
/*      */   {
/*      */     final NettyOutbound source;
/*      */     
/*      */     final Mono<Void> thenMono;
/*      */     
/*      */     static final Runnable EMPTY_CLEANUP = () -> {
/*      */       
/*      */       };
/*      */     
/*      */     OutboundThen(NettyOutbound source, Publisher<Void> thenPublisher) {
/*  725 */       this(source, thenPublisher, EMPTY_CLEANUP);
/*      */     }
/*      */     
/*      */     OutboundThen(NettyOutbound source, Publisher<Void> thenPublisher, Runnable onCleanup) {
/*  729 */       this.source = source;
/*  730 */       Objects.requireNonNull(onCleanup, "onCleanup");
/*      */       
/*  732 */       Mono<Void> parentMono = source.then();
/*      */       
/*  734 */       if (parentMono == Mono.empty()) {
/*  735 */         if (onCleanup == EMPTY_CLEANUP) {
/*  736 */           this.thenMono = Mono.from(thenPublisher);
/*      */         } else {
/*      */           
/*  739 */           this
/*      */             
/*  741 */             .thenMono = Mono.from(thenPublisher).doOnCancel(onCleanup).doOnError(t -> onCleanup.run());
/*      */         }
/*      */       
/*      */       }
/*  745 */       else if (onCleanup == EMPTY_CLEANUP) {
/*  746 */         this.thenMono = parentMono.thenEmpty(thenPublisher);
/*      */       } else {
/*      */         
/*  749 */         this
/*      */           
/*  751 */           .thenMono = parentMono.thenEmpty(thenPublisher).doOnCancel(onCleanup).doOnError(t -> onCleanup.run());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <S> NettyOutbound sendUsing(Callable<? extends S> sourceInput, BiFunction<? super Connection, ? super S, ?> mappedInput, Consumer<? super S> sourceCleanup) {
/*  760 */       return then(this.source.sendUsing(sourceInput, mappedInput, sourceCleanup));
/*      */     }
/*      */ 
/*      */     
/*      */     public ByteBufAllocator alloc() {
/*  765 */       return this.source.alloc();
/*      */     }
/*      */ 
/*      */     
/*      */     public NettyOutbound withConnection(Consumer<? super Connection> withConnection) {
/*  770 */       return this.source.withConnection(withConnection);
/*      */     }
/*      */ 
/*      */     
/*      */     public NettyOutbound send(Publisher<? extends ByteBuf> dataStream, Predicate<ByteBuf> predicate) {
/*  775 */       return then(this.source.send(dataStream, predicate));
/*      */     }
/*      */ 
/*      */     
/*      */     public NettyOutbound sendObject(Publisher<?> dataStream, Predicate<Object> predicate) {
/*  780 */       return then(this.source.sendObject(dataStream, predicate));
/*      */     }
/*      */ 
/*      */     
/*      */     public NettyOutbound sendObject(Object message) {
/*  785 */       return then(this.source.sendObject(message), () -> ReactorNetty.safeRelease(message));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Mono<Void> then() {
/*  791 */       return this.thenMono;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class OutboundIdleStateHandler
/*      */     extends IdleStateHandler {
/*      */     final Runnable onWriteIdle;
/*      */     
/*      */     OutboundIdleStateHandler(long idleTimeout, Runnable onWriteIdle) {
/*  800 */       super(0L, idleTimeout, 0L, TimeUnit.MILLISECONDS);
/*  801 */       this.onWriteIdle = Objects.<Runnable>requireNonNull(onWriteIdle, "onWriteIdle");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void channelIdle(ChannelHandlerContext ctx, IdleStateEvent evt) throws Exception {
/*  807 */       if (evt.state() == IdleState.WRITER_IDLE) {
/*  808 */         this.onWriteIdle.run();
/*      */       }
/*  810 */       super.channelIdle(ctx, evt);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class InboundIdleStateHandler
/*      */     extends IdleStateHandler {
/*      */     final Runnable onReadIdle;
/*      */     
/*      */     InboundIdleStateHandler(long idleTimeout, Runnable onReadIdle) {
/*  819 */       super(idleTimeout, 0L, 0L, TimeUnit.MILLISECONDS);
/*  820 */       this.onReadIdle = Objects.<Runnable>requireNonNull(onReadIdle, "onReadIdle");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void channelIdle(ChannelHandlerContext ctx, IdleStateEvent evt) throws Exception {
/*  826 */       if (evt.state() == IdleState.READER_IDLE) {
/*  827 */         this.onReadIdle.run();
/*      */       }
/*  829 */       super.channelIdle(ctx, evt);
/*      */     }
/*      */   }
/*      */   
/*  833 */   static final ConnectionObserver.State CONNECTED = new ConnectionObserver.State()
/*      */     {
/*      */       public String toString() {
/*  836 */         return "[connected]";
/*      */       }
/*      */     };
/*      */   
/*  840 */   static final ConnectionObserver.State ACQUIRED = new ConnectionObserver.State()
/*      */     {
/*      */       public String toString() {
/*  843 */         return "[acquired]";
/*      */       }
/*      */     };
/*      */   
/*  847 */   static final ConnectionObserver.State CONFIGURED = new ConnectionObserver.State()
/*      */     {
/*      */       public String toString() {
/*  850 */         return "[configured]";
/*      */       }
/*      */     };
/*      */   
/*  854 */   static final ConnectionObserver.State RELEASED = new ConnectionObserver.State()
/*      */     {
/*      */       public String toString() {
/*  857 */         return "[released]";
/*      */       }
/*      */     };
/*      */   
/*  861 */   static final ConnectionObserver.State DISCONNECTING = new ConnectionObserver.State()
/*      */     {
/*      */       public String toString() {
/*  864 */         return "[disconnecting]";
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Sharable
/*      */   static final class ExtractorHandler
/*      */     extends ChannelInboundHandlerAdapter
/*      */   {
/*      */     final BiConsumer<? super ChannelHandlerContext, Object> extractor;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ExtractorHandler(BiConsumer<? super ChannelHandlerContext, Object> extractor) {
/*  881 */       this.extractor = Objects.<BiConsumer<? super ChannelHandlerContext, Object>>requireNonNull(extractor, "extractor");
/*      */     }
/*      */ 
/*      */     
/*      */     public void channelRead(ChannelHandlerContext ctx, Object msg) {
/*  886 */       this.extractor.accept(ctx, msg);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ChannelDisposer
/*      */     extends BaseSubscriber<Void> {
/*      */     final DisposableChannel channelDisposable;
/*      */     
/*      */     ChannelDisposer(DisposableChannel channelDisposable) {
/*  895 */       this.channelDisposable = channelDisposable;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void hookOnSubscribe(Subscription subscription) {
/*  900 */       request(Long.MAX_VALUE);
/*  901 */       this.channelDisposable.onDispose((Disposable)this);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void hookFinally(SignalType type) {
/*  906 */       if (type != SignalType.CANCEL)
/*  907 */         this.channelDisposable.dispose(); 
/*      */     }
/*      */   }
/*      */   
/*      */   static final class SimpleConnection
/*      */     extends AtomicLong
/*      */     implements Connection {
/*      */     final Channel channel;
/*      */     
/*      */     SimpleConnection(Channel channel) {
/*  917 */       this.channel = Objects.<Channel>requireNonNull(channel, "channel");
/*      */     }
/*      */ 
/*      */     
/*      */     public Channel channel() {
/*  922 */       return this.channel;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  927 */       return "SimpleConnection{channel=" + this.channel + '}';
/*      */     }
/*      */   }
/*      */   
/*      */   static NettyInbound unavailableInbound(final Connection c) {
/*  932 */     return new NettyInbound()
/*      */       {
/*      */         public ByteBufFlux receive() {
/*  935 */           return ByteBufFlux.fromInbound((Publisher<?>)Mono.error(new IllegalStateException("Receiver Unavailable")));
/*      */         }
/*      */ 
/*      */         
/*      */         public Flux<?> receiveObject() {
/*  940 */           return Flux.error(new IllegalStateException("Receiver Unavailable"));
/*      */         }
/*      */ 
/*      */         
/*      */         public NettyInbound withConnection(Consumer<? super Connection> withConnection) {
/*  945 */           withConnection.accept(c);
/*  946 */           return this;
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   static NettyOutbound unavailableOutbound(final Connection c) {
/*  952 */     return new NettyOutbound()
/*      */       {
/*      */         public ByteBufAllocator alloc() {
/*  955 */           return c.channel().alloc();
/*      */         }
/*      */ 
/*      */         
/*      */         public NettyOutbound send(Publisher<? extends ByteBuf> dataStream, Predicate<ByteBuf> predicate) {
/*  960 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public NettyOutbound sendObject(Publisher<?> dataStream, Predicate<Object> predicate) {
/*  965 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public NettyOutbound sendObject(Object message) {
/*  970 */           return this;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public <S> NettyOutbound sendUsing(Callable<? extends S> sourceInput, BiFunction<? super Connection, ? super S, ?> mappedInput, Consumer<? super S> sourceCleanup) {
/*  977 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public NettyOutbound withConnection(Consumer<? super Connection> withConnection) {
/*  982 */           withConnection.accept(c);
/*  983 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public Mono<Void> then() {
/*  988 */           return Mono.error(new IllegalStateException("Sender Unavailable"));
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   static final class InternalNettyException
/*      */     extends RuntimeException {
/*      */     InternalNettyException(Throwable cause) {
/*  996 */       super(cause);
/*      */     }
/*      */     private static final long serialVersionUID = 6643227207055930902L;
/*      */     
/*      */     public synchronized Throwable fillInStackTrace() {
/* 1001 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   static final ChannelPipelineConfigurer NOOP_CONFIGURER = (observer, ch, address) -> {
/*      */     
/*      */     };
/*      */   static final ConnectionObserver NOOP_LISTENER = (connection, newState) -> {
/*      */     
/*      */     };
/* 1011 */   static final Logger log = Loggers.getLogger(ReactorNetty.class);
/* 1012 */   static final AttributeKey<Boolean> PERSISTENT_CHANNEL = AttributeKey.valueOf("$PERSISTENT_CHANNEL");
/*      */   
/* 1014 */   static final AttributeKey<Connection> CONNECTION = AttributeKey.valueOf("$CONNECTION");
/*      */   
/* 1016 */   static final AttributeKey<ContextView> CONTEXT_VIEW = AttributeKey.valueOf("$CONTEXT_VIEW");
/*      */   static {
/* 1018 */     fileCloser = (fc -> {
/*      */         
/*      */         try {
/*      */           fc.close();
/* 1022 */         } catch (Throwable e) {
/*      */           if (log.isTraceEnabled()) {
/*      */             log.trace("", e);
/*      */           }
/*      */         } 
/*      */       });
/*      */   }
/*      */ 
/*      */   
/*      */   static final Consumer<? super FileChannel> fileCloser;
/*      */   static final Predicate<ByteBuf> PREDICATE_BB_FLUSH = b -> false;
/*      */   static final Predicate<Object> PREDICATE_FLUSH = o -> false;
/* 1034 */   static final ByteBuf BOUNDARY = Unpooled.EMPTY_BUFFER;
/*      */   
/*      */   static final char CHANNEL_ID_PREFIX = '[';
/*      */   static final String CHANNEL_ID_SUFFIX_1 = "] ";
/*      */   static final char CHANNEL_ID_SUFFIX_2 = ' ';
/*      */   static final String ORIGINAL_CHANNEL_ID_PREFIX = "[id: 0x";
/* 1040 */   static final int ORIGINAL_CHANNEL_ID_PREFIX_LENGTH = "[id: 0x".length();
/*      */   static final char TRACE_ID_PREFIX = '(';
/*      */   public static final Predicate<ByteBuf> PREDICATE_GROUP_FLUSH;
/*      */   
/*      */   static {
/* 1045 */     PREDICATE_GROUP_FLUSH = (b -> (b == BOUNDARY));
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\ReactorNetty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */