/*     */ package reactor.netty;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.ByteBufInputStream;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoOperator;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteBufMono
/*     */   extends MonoOperator<ByteBuf, ByteBuf>
/*     */ {
/*     */   public final Mono<ByteBuffer> asByteBuffer() {
/*  50 */     return handle((bb, sink) -> {
/*     */           
/*     */           try {
/*     */             sink.next(bb.nioBuffer());
/*  54 */           } catch (IllegalReferenceCountException e) {
/*     */             sink.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<byte[]> asByteArray() {
/*  66 */     return handle((bb, sink) -> {
/*     */           try {
/*     */             byte[] bytes = new byte[bb.readableBytes()];
/*     */             
/*     */             bb.readBytes(bytes);
/*     */             sink.next(bytes);
/*  72 */           } catch (IllegalReferenceCountException e) {
/*     */             sink.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<String> asString() {
/*  84 */     return asString(Charset.defaultCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<String> asString(Charset charset) {
/*  95 */     Objects.requireNonNull(charset, "charset");
/*  96 */     return handle((bb, sink) -> {
/*     */           
/*     */           try {
/*     */             sink.next(bb.readCharSequence(bb.readableBytes(), charset).toString());
/* 100 */           } catch (IllegalReferenceCountException e) {
/*     */             sink.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<InputStream> asInputStream() {
/* 116 */     return handle((bb, sink) -> {
/*     */           
/*     */           try {
/*     */             sink.next(new ReleasingInputStream(bb));
/* 120 */           } catch (IllegalReferenceCountException e) {
/*     */             sink.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufMono fromString(Publisher<? extends String> source) {
/* 133 */     return fromString(source, Charset.defaultCharset(), ByteBufAllocator.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufMono fromString(Publisher<? extends String> source, Charset charset, ByteBufAllocator allocator) {
/* 145 */     Objects.requireNonNull(allocator, "allocator");
/* 146 */     Objects.requireNonNull(charset, "charset");
/* 147 */     return maybeFuse(
/* 148 */         Mono.from((Publisher)ReactorNetty.publisherOrScalarMap(source, s -> {
/*     */               ByteBuf buffer = allocator.buffer();
/*     */               buffer.writeCharSequence(s, charset);
/*     */               return buffer;
/*     */             }l -> {
/*     */               ByteBuf buffer = allocator.buffer();
/*     */               for (String s : l) {
/*     */                 buffer.writeCharSequence(s, charset);
/*     */               }
/*     */               return buffer;
/*     */             })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBufMono retain() {
/* 171 */     return maybeFuse(doOnNext(ByteBuf::retain));
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super ByteBuf> actual) {
/* 176 */     this.source.subscribe(actual);
/*     */   }
/*     */   
/*     */   ByteBufMono(Mono<?> source) {
/* 180 */     super(source.map(ByteBufFlux.bytebufExtractor));
/*     */   }
/*     */   
/*     */   static ByteBufMono maybeFuse(Mono<?> source) {
/* 184 */     if (source instanceof Fuseable) {
/* 185 */       return new ByteBufMonoFuseable(source);
/*     */     }
/* 187 */     return new ByteBufMono(source);
/*     */   }
/*     */   
/*     */   static final class ByteBufMonoFuseable
/*     */     extends ByteBufMono implements Fuseable {
/*     */     ByteBufMonoFuseable(Mono<?> source) {
/* 193 */       super(source);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ReleasingInputStream
/*     */     extends ByteBufInputStream
/*     */   {
/*     */     final ByteBuf bb;
/*     */     
/*     */     volatile int closed;
/* 204 */     static final AtomicIntegerFieldUpdater<ReleasingInputStream> CLOSE = AtomicIntegerFieldUpdater.newUpdater(ReleasingInputStream.class, "closed");
/*     */     
/*     */     ReleasingInputStream(ByteBuf bb) {
/* 207 */       super(bb.retain());
/* 208 */       this.bb = bb;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 213 */       if (CLOSE.compareAndSet(this, 0, 1))
/*     */         try {
/* 215 */           super.close();
/*     */         } finally {
/*     */           
/* 218 */           this.bb.release();
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\ByteBufMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */