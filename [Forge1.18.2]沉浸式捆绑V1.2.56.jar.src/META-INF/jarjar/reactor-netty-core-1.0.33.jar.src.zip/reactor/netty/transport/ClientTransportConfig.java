/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.group.ChannelGroup;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.channel.unix.DomainSocketChannel;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.resolver.dns.DnsAddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClientTransportConfig<CONF extends TransportConfig>
/*     */   extends TransportConfig
/*     */ {
/*     */   final ConnectionProvider connectionProvider;
/*     */   Consumer<? super CONF> doOnConnect;
/*     */   Consumer<? super Connection> doOnConnected;
/*     */   Consumer<? super Connection> doOnDisconnected;
/*     */   Consumer<? super Connection> doOnResolve;
/*     */   BiConsumer<? super Connection, ? super SocketAddress> doAfterResolve;
/*     */   BiConsumer<? super Connection, ? super Throwable> doOnResolveError;
/*     */   NameResolverProvider nameResolverProvider;
/*     */   ProxyProvider proxyProvider;
/*     */   Supplier<? extends SocketAddress> remoteAddress;
/*     */   AddressResolverGroup<?> resolver;
/*     */   
/*     */   public int channelHash() {
/*  55 */     int result = super.channelHash();
/*  56 */     result = 31 * result + Objects.hashCode(this.proxyProvider);
/*  57 */     result = 31 * result + Objects.hashCode(this.resolver);
/*  58 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionProvider connectionProvider() {
/*  67 */     return this.connectionProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super CONF> doOnConnect() {
/*  77 */     return this.doOnConnect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super Connection> doOnConnected() {
/*  87 */     return this.doOnConnected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super Connection> doOnDisconnected() {
/*  97 */     return this.doOnDisconnected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasProxy() {
/* 106 */     return (this.proxyProvider != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public NameResolverProvider getNameResolverProvider() {
/* 116 */     return this.nameResolverProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final ProxyProvider proxyProvider() {
/* 126 */     return this.proxyProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Supplier<? extends SocketAddress> remoteAddress() {
/* 135 */     return this.remoteAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final AddressResolverGroup<?> resolver() {
/* 146 */     return this.resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClientTransportConfig(ConnectionProvider connectionProvider, Map<ChannelOption<?>, ?> options, Supplier<? extends SocketAddress> remoteAddress) {
/* 167 */     super(options);
/* 168 */     this.connectionProvider = Objects.<ConnectionProvider>requireNonNull(connectionProvider, "connectionProvider");
/* 169 */     this.remoteAddress = Objects.<Supplier<? extends SocketAddress>>requireNonNull(remoteAddress, "remoteAddress");
/*     */   }
/*     */   
/*     */   protected ClientTransportConfig(ClientTransportConfig<CONF> parent) {
/* 173 */     super(parent);
/* 174 */     this.connectionProvider = parent.connectionProvider;
/* 175 */     this.doOnConnect = parent.doOnConnect;
/* 176 */     this.doOnConnected = parent.doOnConnected;
/* 177 */     this.doOnDisconnected = parent.doOnDisconnected;
/* 178 */     this.doOnResolve = parent.doOnResolve;
/* 179 */     this.doAfterResolve = parent.doAfterResolve;
/* 180 */     this.doOnResolveError = parent.doOnResolveError;
/* 181 */     this.nameResolverProvider = parent.nameResolverProvider;
/* 182 */     this.proxyProvider = parent.proxyProvider;
/* 183 */     this.remoteAddress = parent.remoteAddress;
/* 184 */     this.resolver = parent.resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<? extends Channel> channelType(boolean isDomainSocket) {
/* 189 */     return isDomainSocket ? (Class)DomainSocketChannel.class : (Class)SocketChannel.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract AddressResolverGroup<?> defaultAddressResolverGroup();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConnectionObserver defaultConnectionObserver() {
/* 201 */     if (channelGroup() == null && doOnConnected() == null && doOnDisconnected() == null) {
/* 202 */       return ConnectionObserver.emptyListener();
/*     */     }
/* 204 */     return new ClientTransportDoOn(channelGroup(), doOnConnected(), doOnDisconnected());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelPipelineConfigurer defaultOnChannelInit() {
/* 209 */     if (this.proxyProvider != null) {
/* 210 */       return new ClientTransportChannelInitializer(this.proxyProvider);
/*     */     }
/*     */     
/* 213 */     return ChannelPipelineConfigurer.emptyConfigurer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected EventLoopGroup eventLoopGroup() {
/* 219 */     return loopResources().onClient(isPreferNative());
/*     */   }
/*     */   
/*     */   protected void proxyProvider(@Nullable ProxyProvider proxyProvider) {
/* 223 */     this.proxyProvider = proxyProvider;
/*     */   }
/*     */   
/*     */   protected AddressResolverGroup<?> resolverInternal() {
/* 227 */     AddressResolverGroup<?> resolverGroup = (this.resolver != null) ? this.resolver : defaultAddressResolverGroup();
/* 228 */     if (this.metricsRecorder != null) {
/* 229 */       return AddressResolverGroupMetrics.getOrCreate(resolverGroup, this.metricsRecorder);
/*     */     }
/*     */     
/* 232 */     return resolverGroup;
/*     */   }
/*     */ 
/*     */   
/* 236 */   static final ConcurrentMap<Integer, DnsAddressResolverGroup> RESOLVERS_CACHE = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DnsAddressResolverGroup getOrCreateResolver(NameResolverProvider nameResolverProvider, LoopResources loopResources, boolean preferNative) {
/* 242 */     return (DnsAddressResolverGroup)MapUtils.computeIfAbsent(RESOLVERS_CACHE, Integer.valueOf(Objects.hash(new Object[] { nameResolverProvider, loopResources, Boolean.valueOf(preferNative) }, )), key -> nameResolverProvider.newNameResolverGroup(loopResources, preferNative));
/*     */   }
/*     */ 
/*     */   
/* 246 */   static final NameResolverProvider DEFAULT_NAME_RESOLVER_PROVIDER = NameResolverProvider.builder().build();
/*     */   
/*     */   static final class ClientTransportChannelInitializer
/*     */     implements ChannelPipelineConfigurer {
/*     */     final ProxyProvider proxyProvider;
/*     */     
/*     */     ClientTransportChannelInitializer(ProxyProvider proxyProvider) {
/* 253 */       this.proxyProvider = proxyProvider;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChannelInit(ConnectionObserver connectionObserver, Channel channel, SocketAddress remoteAddress) {
/* 258 */       if (this.proxyProvider.shouldProxy(remoteAddress)) {
/* 259 */         this.proxyProvider.addProxyHandler(channel);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ClientTransportDoOn
/*     */     implements ConnectionObserver
/*     */   {
/*     */     final ChannelGroup channelGroup;
/*     */     final Consumer<? super Connection> doOnConnected;
/*     */     final Consumer<? super Connection> doOnDisconnected;
/*     */     
/*     */     ClientTransportDoOn(@Nullable ChannelGroup channelGroup, @Nullable Consumer<? super Connection> doOnConnected, @Nullable Consumer<? super Connection> doOnDisconnected) {
/* 273 */       this.channelGroup = channelGroup;
/* 274 */       this.doOnConnected = doOnConnected;
/* 275 */       this.doOnDisconnected = doOnDisconnected;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 280 */       if (this.channelGroup != null && newState == ConnectionObserver.State.CONNECTED) {
/* 281 */         this.channelGroup.add(connection.channel());
/*     */         return;
/*     */       } 
/* 284 */       if (this.doOnConnected != null && newState == ConnectionObserver.State.CONFIGURED) {
/* 285 */         this.doOnConnected.accept(connection);
/*     */         return;
/*     */       } 
/* 288 */       if (this.doOnDisconnected != null)
/* 289 */         if (newState == ConnectionObserver.State.DISCONNECTING) {
/* 290 */           connection.onDispose(() -> this.doOnDisconnected.accept(connection));
/*     */         }
/* 292 */         else if (newState == ConnectionObserver.State.RELEASED) {
/* 293 */           this.doOnDisconnected.accept(connection);
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\ClientTransportConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */