/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFactory;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.DefaultChannelPromise;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.resolver.AddressResolver;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TransportConnector
/*     */ {
/*     */   public static Mono<Channel> bind(TransportConfig config, ChannelInitializer<Channel> channelInitializer, SocketAddress bindAddress, boolean isDomainSocket) {
/*  83 */     Objects.requireNonNull(config, "config");
/*  84 */     Objects.requireNonNull(bindAddress, "bindAddress");
/*  85 */     Objects.requireNonNull(channelInitializer, "channelInitializer");
/*     */     
/*  87 */     return doInitAndRegister(config, channelInitializer, isDomainSocket, config.eventLoopGroup().next())
/*  88 */       .flatMap(channel -> {
/*     */           MonoChannelPromise promise = new MonoChannelPromise(channel);
/*     */           channel.eventLoop().execute(());
/*     */           return promise;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Channel> connect(TransportConfig config, SocketAddress remoteAddress, AddressResolverGroup<?> resolverGroup, ChannelInitializer<Channel> channelInitializer) {
/* 107 */     return connect(config, remoteAddress, resolverGroup, channelInitializer, config.eventLoopGroup().next(), (ContextView)Context.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Channel> connect(TransportConfig config, SocketAddress remoteAddress, AddressResolverGroup<?> resolverGroup, ChannelInitializer<Channel> channelInitializer, ContextView contextView) {
/* 123 */     return connect(config, remoteAddress, resolverGroup, channelInitializer, config.eventLoopGroup().next(), contextView);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Channel> connect(TransportConfig config, SocketAddress remoteAddress, AddressResolverGroup<?> resolverGroup, ChannelInitializer<Channel> channelInitializer, EventLoop eventLoop) {
/* 138 */     return connect(config, remoteAddress, resolverGroup, channelInitializer, eventLoop, (ContextView)Context.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mono<Channel> connect(TransportConfig config, SocketAddress remoteAddress, AddressResolverGroup<?> resolverGroup, ChannelInitializer<Channel> channelInitializer, EventLoop eventLoop, ContextView contextView) {
/* 156 */     Objects.requireNonNull(config, "config");
/* 157 */     Objects.requireNonNull(remoteAddress, "remoteAddress");
/* 158 */     Objects.requireNonNull(resolverGroup, "resolverGroup");
/* 159 */     Objects.requireNonNull(channelInitializer, "channelInitializer");
/* 160 */     Objects.requireNonNull(eventLoop, "eventLoop");
/* 161 */     Objects.requireNonNull(contextView, "contextView");
/*     */     
/* 163 */     boolean isDomainAddress = remoteAddress instanceof io.netty.channel.unix.DomainSocketAddress;
/* 164 */     return doInitAndRegister(config, channelInitializer, isDomainAddress, eventLoop)
/* 165 */       .flatMap(channel -> doResolveAndConnect(channel, config, remoteAddress, resolverGroup, contextView).onErrorResume(RetryConnectException.class, ()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setAttributes(Channel channel, Map<AttributeKey<?>, ?> attrs) {
/* 190 */     for (Map.Entry<AttributeKey<?>, ?> e : attrs.entrySet()) {
/* 191 */       channel.attr(e.getKey()).set(e.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setChannelOptions(Channel channel, Map<ChannelOption<?>, ?> options, boolean isDomainSocket) {
/* 203 */     for (Map.Entry<ChannelOption<?>, ?> e : options.entrySet()) {
/* 204 */       if (isDomainSocket && (ChannelOption.SO_REUSEADDR
/* 205 */         .equals(e.getKey()) || ChannelOption.TCP_NODELAY.equals(e.getKey()))) {
/*     */         continue;
/*     */       }
/*     */       try {
/* 209 */         if (!channel.config().setOption(e.getKey(), e.getValue()) && 
/* 210 */           log.isWarnEnabled()) {
/* 211 */           log.warn(ReactorNetty.format(channel, "Unknown channel option '{}' for channel '{}'"), new Object[] { e.getKey(), channel });
/*     */         
/*     */         }
/*     */       }
/* 215 */       catch (Throwable t) {
/* 216 */         if (log.isWarnEnabled()) {
/* 217 */           log.warn(ReactorNetty.format(channel, "Failed to set channel option '{}' with value '{}' for channel '{}'"), new Object[] { e
/* 218 */                 .getKey(), e.getValue(), channel, t });
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void doConnect(List<SocketAddress> addresses, @Nullable Supplier<? extends SocketAddress> bindAddress, ChannelPromise connectPromise, int index) {
/* 230 */     Channel channel = connectPromise.channel();
/* 231 */     channel.eventLoop().execute(() -> {
/*     */           ChannelFuture f;
/*     */           SocketAddress remoteAddress = addresses.get(index);
/*     */           if (log.isDebugEnabled()) {
/*     */             log.debug(ReactorNetty.format(channel, "Connecting to [" + remoteAddress + "]."));
/*     */           }
/*     */           if (bindAddress == null) {
/*     */             f = channel.connect(remoteAddress);
/*     */           } else {
/*     */             SocketAddress local = Objects.<SocketAddress>requireNonNull(bindAddress.get(), "bindAddress");
/*     */             f = channel.connect(remoteAddress, local);
/*     */           } 
/*     */           f.addListener(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Mono<Channel> doInitAndRegister(TransportConfig config, ChannelInitializer<Channel> channelInitializer, boolean isDomainSocket, EventLoop eventLoop) {
/* 278 */     ChannelFactory<? extends Channel> channelFactory = config.connectionFactory(config.eventLoopGroup(), isDomainSocket);
/*     */     
/* 280 */     Channel channel = null;
/*     */     try {
/* 282 */       channel = channelFactory.newChannel();
/* 283 */       if (channelInitializer instanceof ServerTransport.AcceptorInitializer) {
/* 284 */         ((ServerTransport.AcceptorInitializer)channelInitializer).acceptor.enableAutoReadTask(channel);
/*     */       }
/* 286 */       channel.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)channelInitializer });
/* 287 */       setChannelOptions(channel, config.options, isDomainSocket);
/* 288 */       setAttributes(channel, config.attrs);
/*     */     }
/* 290 */     catch (Throwable t) {
/* 291 */       if (channel != null) {
/* 292 */         channel.unsafe().closeForcibly();
/*     */       }
/* 294 */       return Mono.error(t);
/*     */     } 
/*     */     
/* 297 */     MonoChannelPromise monoChannelPromise = new MonoChannelPromise(channel);
/*     */     
/* 299 */     channel.unsafe().register(eventLoop, monoChannelPromise);
/* 300 */     Throwable cause = monoChannelPromise.cause();
/* 301 */     if (cause != null) {
/* 302 */       if (channel.isRegistered()) {
/*     */         
/* 304 */         channel.close();
/*     */       } else {
/*     */         
/* 307 */         channel.unsafe().closeForcibly();
/*     */       } 
/*     */     }
/*     */     
/* 311 */     return monoChannelPromise;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Mono<Channel> doResolveAndConnect(Channel channel, TransportConfig config, SocketAddress remoteAddress, AddressResolverGroup<?> resolverGroup, ContextView contextView) {
/*     */     try {
/*     */       AddressResolver<SocketAddress> resolver;
/*     */       try {
/* 320 */         resolver = resolverGroup.getResolver((EventExecutor)channel.eventLoop());
/*     */       }
/* 322 */       catch (Throwable t) {
/*     */         
/* 324 */         channel.close();
/* 325 */         return Mono.error(t);
/*     */       } 
/*     */       
/* 328 */       if (!contextView.isEmpty()) {
/* 329 */         ReactorNetty.setChannelContext(channel, contextView);
/*     */       }
/*     */       
/* 332 */       Supplier<? extends SocketAddress> bindAddress = config.bindAddress();
/* 333 */       if (!resolver.isSupported(remoteAddress) || resolver.isResolved(remoteAddress)) {
/* 334 */         MonoChannelPromise monoChannelPromise1 = new MonoChannelPromise(channel);
/* 335 */         doConnect(Collections.singletonList(remoteAddress), bindAddress, monoChannelPromise1, 0);
/* 336 */         return monoChannelPromise1;
/*     */       } 
/*     */       
/* 339 */       if (config instanceof ClientTransportConfig) {
/* 340 */         ClientTransportConfig<?> clientTransportConfig = (ClientTransportConfig)config;
/* 341 */         if (clientTransportConfig.doOnResolve != null) {
/* 342 */           clientTransportConfig.doOnResolve.accept(Connection.from(channel));
/*     */         }
/*     */       } 
/*     */       
/* 346 */       Future<List<SocketAddress>> resolveFuture = resolver.resolveAll(remoteAddress);
/*     */       
/* 348 */       if (config instanceof ClientTransportConfig) {
/* 349 */         ClientTransportConfig<?> clientTransportConfig = (ClientTransportConfig)config;
/*     */         
/* 351 */         if (clientTransportConfig.doOnResolveError != null) {
/* 352 */           resolveFuture.addListener((GenericFutureListener)(future -> {
/*     */                 if (future.cause() != null) {
/*     */                   clientTransportConfig.doOnResolveError.accept(Connection.from(channel), future.cause());
/*     */                 }
/*     */               }));
/*     */         }
/*     */         
/* 359 */         if (clientTransportConfig.doAfterResolve != null) {
/* 360 */           resolveFuture.addListener((GenericFutureListener)(future -> {
/*     */                 if (future.isSuccess()) {
/*     */                   clientTransportConfig.doAfterResolve.accept(Connection.from(channel), ((List<SocketAddress>)future.getNow()).get(0));
/*     */                 }
/*     */               }));
/*     */         }
/*     */       } 
/*     */       
/* 368 */       if (resolveFuture.isDone()) {
/* 369 */         Throwable cause = resolveFuture.cause();
/* 370 */         if (cause != null) {
/*     */           
/* 372 */           channel.close();
/* 373 */           return Mono.error(cause);
/*     */         } 
/*     */         
/* 376 */         MonoChannelPromise monoChannelPromise1 = new MonoChannelPromise(channel);
/* 377 */         doConnect((List<SocketAddress>)resolveFuture.getNow(), bindAddress, monoChannelPromise1, 0);
/* 378 */         return monoChannelPromise1;
/*     */       } 
/*     */ 
/*     */       
/* 382 */       MonoChannelPromise monoChannelPromise = new MonoChannelPromise(channel);
/* 383 */       resolveFuture.addListener((GenericFutureListener)(future -> {
/*     */             if (future.cause() != null) {
/*     */               channel.close();
/*     */               
/*     */               monoChannelPromise.tryFailure(future.cause());
/*     */             } else {
/*     */               doConnect((List<SocketAddress>)future.getNow(), bindAddress, monoChannelPromise, 0);
/*     */             } 
/*     */           }));
/*     */       
/* 393 */       return monoChannelPromise;
/*     */     }
/* 395 */     catch (Throwable t) {
/* 396 */       AddressResolver<SocketAddress> resolver; return Mono.error((Throwable)resolver);
/*     */     } 
/*     */   }
/*     */   
/*     */   static final class MonoChannelPromise
/*     */     extends Mono<Channel>
/*     */     implements ChannelPromise, Subscription {
/*     */     final Channel channel;
/*     */     CoreSubscriber<? super Channel> actual;
/*     */     
/*     */     MonoChannelPromise(Channel channel) {
/* 407 */       this.channel = channel;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise addListener(GenericFutureListener<? extends Future<? super Void>> listener) {
/* 412 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelPromise addListeners(GenericFutureListener<? extends Future<? super Void>>... listeners) {
/* 418 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise await() {
/* 423 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean await(long timeoutMillis) {
/* 428 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean await(long timeout, TimeUnit unit) {
/* 433 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise awaitUninterruptibly() {
/* 438 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean awaitUninterruptibly(long timeoutMillis) {
/* 443 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean awaitUninterruptibly(long timeout, TimeUnit unit) {
/* 448 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 455 */       this.channel.close();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean cancel(boolean mayInterruptIfRunning) {
/* 460 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Throwable cause() {
/* 465 */       Object result = this.result;
/* 466 */       return (result == SUCCESS) ? null : (Throwable)result;
/*     */     }
/*     */ 
/*     */     
/*     */     public Channel channel() {
/* 471 */       return this.channel;
/*     */     }
/*     */ 
/*     */     
/*     */     public Void get() {
/* 476 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Void get(long timeout, TimeUnit unit) {
/* 481 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Void getNow() {
/* 486 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCancellable() {
/* 491 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCancelled() {
/* 496 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDone() {
/* 501 */       Object result = this.result;
/* 502 */       return (result != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSuccess() {
/* 507 */       Object result = this.result;
/* 508 */       return (result == SUCCESS);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isVoid() {
/* 513 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise removeListener(GenericFutureListener<? extends Future<? super Void>> listener) {
/* 518 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelPromise removeListeners(GenericFutureListener<? extends Future<? super Void>>... listeners) {
/* 524 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelPromise setFailure(Throwable cause) {
/* 534 */       tryFailure(cause);
/* 535 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise setSuccess() {
/* 540 */       trySuccess((Void)null);
/* 541 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise setSuccess(Void result) {
/* 546 */       trySuccess((Void)null);
/* 547 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setUncancellable() {
/* 552 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super Channel> actual) {
/* 557 */       EventLoop eventLoop = this.channel.eventLoop();
/* 558 */       if (eventLoop.inEventLoop()) {
/* 559 */         _subscribe(actual);
/*     */       } else {
/*     */         
/* 562 */         eventLoop.execute(() -> _subscribe(actual));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise sync() {
/* 568 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise syncUninterruptibly() {
/* 573 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryFailure(Throwable cause) {
/* 578 */       if (RESULT_UPDATER.compareAndSet(this, null, cause)) {
/* 579 */         if (this.actual != null) {
/* 580 */           this.actual.onError(cause);
/*     */         }
/* 582 */         return true;
/*     */       } 
/* 584 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean trySuccess() {
/* 589 */       return trySuccess((Void)null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean trySuccess(Void result) {
/* 594 */       if (RESULT_UPDATER.compareAndSet(this, null, SUCCESS)) {
/* 595 */         if (this.actual != null) {
/* 596 */           this.actual.onNext(this.channel);
/* 597 */           this.actual.onComplete();
/*     */         } 
/* 599 */         return true;
/*     */       } 
/* 601 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise unvoid() {
/* 606 */       return (ChannelPromise)new DefaultChannelPromise(this.channel)
/*     */         {
/*     */           public ChannelPromise setSuccess(Void result)
/*     */           {
/* 610 */             super.trySuccess(null);
/* 611 */             TransportConnector.MonoChannelPromise.this.trySuccess((Void)null);
/* 612 */             return (ChannelPromise)this;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean trySuccess(Void result) {
/* 617 */             super.trySuccess(null);
/* 618 */             return TransportConnector.MonoChannelPromise.this.trySuccess((Void)null);
/*     */           }
/*     */ 
/*     */           
/*     */           public ChannelPromise setFailure(Throwable cause) {
/* 623 */             super.tryFailure(cause);
/* 624 */             TransportConnector.MonoChannelPromise.this.tryFailure(cause);
/* 625 */             return (ChannelPromise)this;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean tryFailure(Throwable cause) {
/* 630 */             super.tryFailure(cause);
/* 631 */             return TransportConnector.MonoChannelPromise.this.tryFailure(cause);
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     void _subscribe(CoreSubscriber<? super Channel> actual) {
/* 637 */       this.actual = actual;
/* 638 */       actual.onSubscribe(this);
/*     */       
/* 640 */       if (isDone()) {
/* 641 */         if (isSuccess()) {
/* 642 */           actual.onNext(this.channel);
/* 643 */           actual.onComplete();
/*     */         } else {
/*     */           
/* 646 */           actual.onError(cause());
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/* 651 */     static final Object SUCCESS = new Object();
/*     */     
/* 653 */     static final AtomicReferenceFieldUpdater<MonoChannelPromise, Object> RESULT_UPDATER = AtomicReferenceFieldUpdater.newUpdater(MonoChannelPromise.class, Object.class, "result");
/*     */     volatile Object result;
/*     */   }
/*     */   
/*     */   static final class RetryConnectException extends RuntimeException {
/*     */     final List<SocketAddress> addresses;
/*     */     private static final long serialVersionUID = -207274323623692199L;
/*     */     
/*     */     RetryConnectException(List<SocketAddress> addresses) {
/* 662 */       this.addresses = addresses;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized Throwable fillInStackTrace() {
/* 668 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 674 */   static final Logger log = Loggers.getLogger(TransportConnector.class);
/*     */   static {
/* 676 */     RETRY_PREDICATE = (t -> t instanceof RetryConnectException);
/*     */   }
/*     */   
/*     */   static final Predicate<Throwable> RETRY_PREDICATE;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\TransportConnector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */