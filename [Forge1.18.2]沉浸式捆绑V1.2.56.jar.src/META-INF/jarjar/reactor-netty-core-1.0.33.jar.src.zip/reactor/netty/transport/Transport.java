/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.group.ChannelGroup;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.Metrics;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Transport<T extends Transport<T, C>, C extends TransportConfig>
/*     */ {
/*     */   public <A> T attr(AttributeKey<A> key, @Nullable A value) {
/*  62 */     Objects.requireNonNull(key, "key");
/*  63 */     T dup = duplicate();
/*  64 */     ((TransportConfig)dup.configuration()).attrs = TransportConfig.updateMap(((TransportConfig)configuration()).attrs, key, value);
/*  65 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T bindAddress(Supplier<? extends SocketAddress> bindAddressSupplier) {
/*  75 */     Objects.requireNonNull(bindAddressSupplier, "bindAddressSupplier");
/*  76 */     T dup = duplicate();
/*  77 */     ((TransportConfig)dup.configuration()).bindAddress = bindAddressSupplier;
/*  78 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T channelGroup(ChannelGroup channelGroup) {
/*  94 */     Objects.requireNonNull(channelGroup, "channelGroup");
/*  95 */     T dup = duplicate();
/*  96 */     ((TransportConfig)dup.configuration()).channelGroup = channelGroup;
/*  97 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doOnChannelInit(ChannelPipelineConfigurer doOnChannelInit) {
/* 114 */     Objects.requireNonNull(doOnChannelInit, "doOnChannelInit");
/* 115 */     T dup = duplicate();
/* 116 */     ChannelPipelineConfigurer current = ((TransportConfig)configuration()).doOnChannelInit;
/* 117 */     ((TransportConfig)dup.configuration()).doOnChannelInit = (current == null) ? doOnChannelInit : current.then(doOnChannelInit);
/* 118 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T metrics(boolean enable) {
/* 137 */     if (enable) {
/* 138 */       if (!Metrics.isInstrumentationAvailable()) {
/* 139 */         throw new UnsupportedOperationException("To enable metrics, you must add the dependency `io.micrometer:micrometer-core` to the class path first");
/*     */       }
/*     */ 
/*     */       
/* 143 */       T dup = duplicate();
/* 144 */       dup.configuration().metricsRecorder(() -> configuration().defaultMetricsRecorder());
/* 145 */       return dup;
/*     */     } 
/* 147 */     if (((TransportConfig)configuration()).metricsRecorder != null) {
/* 148 */       T dup = duplicate();
/* 149 */       dup.configuration().metricsRecorder(null);
/* 150 */       return dup;
/*     */     } 
/*     */ 
/*     */     
/* 154 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T metrics(boolean enable, Supplier<? extends ChannelMetricsRecorder> recorder) {
/* 170 */     if (enable) {
/* 171 */       T dup = duplicate();
/* 172 */       dup.configuration().metricsRecorder(recorder);
/* 173 */       return dup;
/*     */     } 
/* 175 */     if (((TransportConfig)configuration()).metricsRecorder != null) {
/* 176 */       T dup = duplicate();
/* 177 */       dup.configuration().metricsRecorder(null);
/* 178 */       return dup;
/*     */     } 
/*     */ 
/*     */     
/* 182 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T observe(ConnectionObserver observer) {
/* 194 */     Objects.requireNonNull(observer, "observer");
/* 195 */     T dup = duplicate();
/* 196 */     ConnectionObserver current = ((TransportConfig)configuration()).observer;
/* 197 */     ((TransportConfig)dup.configuration()).observer = (current == null) ? observer : current.then(observer);
/* 198 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <O> T option(ChannelOption<O> key, @Nullable O value) {
/* 212 */     Objects.requireNonNull(key, "key");
/*     */     
/* 214 */     if (ChannelOption.AUTO_READ == key) {
/* 215 */       if (value instanceof Boolean && Boolean.TRUE.equals(value)) {
/* 216 */         log.error("ChannelOption.AUTO_READ is configured to be [false], it cannot be set to [true]");
/*     */       }
/*     */       
/* 219 */       return (T)this;
/*     */     } 
/*     */     
/* 222 */     T dup = duplicate();
/* 223 */     ((TransportConfig)dup.configuration()).options = TransportConfig.updateMap(((TransportConfig)configuration()).options, key, value);
/* 224 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T runOn(EventLoopGroup eventLoopGroup) {
/* 234 */     Objects.requireNonNull(eventLoopGroup, "eventLoopGroup");
/* 235 */     return runOn(preferNative -> eventLoopGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T runOn(LoopResources channelResources) {
/* 248 */     Objects.requireNonNull(channelResources, "channelResources");
/* 249 */     return runOn(channelResources, LoopResources.DEFAULT_NATIVE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T runOn(LoopResources loopResources, boolean preferNative) {
/* 260 */     Objects.requireNonNull(loopResources, "loopResources");
/* 261 */     T dup = duplicate();
/* 262 */     TransportConfig c = (TransportConfig)dup.configuration();
/* 263 */     c.loopResources = loopResources;
/* 264 */     c.preferNative = preferNative;
/* 265 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T wiretap(boolean enable) {
/* 277 */     if (enable) {
/* 278 */       T dup = duplicate();
/* 279 */       ((TransportConfig)dup.configuration()).loggingHandler = configuration().defaultLoggingHandler();
/* 280 */       return dup;
/*     */     } 
/* 282 */     if (((TransportConfig)configuration()).loggingHandler != null) {
/* 283 */       T dup = duplicate();
/* 284 */       ((TransportConfig)dup.configuration()).loggingHandler = null;
/* 285 */       return dup;
/*     */     } 
/*     */ 
/*     */     
/* 289 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T wiretap(String category) {
/* 303 */     Objects.requireNonNull(category, "category");
/* 304 */     return wiretap(category, LogLevel.DEBUG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T wiretap(String category, LogLevel level) {
/* 317 */     Objects.requireNonNull(category, "category");
/* 318 */     Objects.requireNonNull(level, "level");
/* 319 */     return wiretap(category, level, AdvancedByteBufFormat.HEX_DUMP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T wiretap(String category, LogLevel level, AdvancedByteBufFormat format) {
/* 341 */     Objects.requireNonNull(category, "category");
/* 342 */     Objects.requireNonNull(level, "level");
/* 343 */     Objects.requireNonNull(format, "format");
/* 344 */     return wiretap(category, level, format, Charset.defaultCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T wiretap(String category, LogLevel level, AdvancedByteBufFormat format, Charset charset) {
/* 368 */     Objects.requireNonNull(category, "category");
/* 369 */     Objects.requireNonNull(level, "level");
/* 370 */     Objects.requireNonNull(format, "format");
/* 371 */     Objects.requireNonNull(charset, "charset");
/* 372 */     LoggingHandler loggingHandler = format.toLoggingHandler(category, level, charset);
/* 373 */     if (loggingHandler.equals(((TransportConfig)configuration()).loggingHandler))
/*     */     {
/* 375 */       return (T)this;
/*     */     }
/*     */     
/* 378 */     T dup = duplicate();
/* 379 */     ((TransportConfig)dup.configuration()).loggingHandler = loggingHandler;
/* 380 */     return dup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 391 */   static final Logger log = Loggers.getLogger(Transport.class);
/*     */   
/*     */   public abstract C configuration();
/*     */   
/*     */   protected abstract T duplicate();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\Transport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */