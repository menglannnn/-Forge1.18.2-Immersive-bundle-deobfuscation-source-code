/*    */ package reactor.netty.transport;
/*    */ 
/*    */ import io.micrometer.core.instrument.Gauge;
/*    */ import io.micrometer.core.instrument.Tags;
/*    */ import io.netty.buffer.ByteBufAllocator;
/*    */ import io.netty.buffer.ByteBufAllocatorMetric;
/*    */ import io.netty.buffer.PooledByteBufAllocator;
/*    */ import io.netty.buffer.PooledByteBufAllocatorMetric;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import reactor.netty.Metrics;
/*    */ import reactor.netty.internal.util.MapUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ByteBufAllocatorMetrics
/*    */ {
/*    */   static final String CHUNK_SIZE_DESCRIPTION = "The chunk size for an arena.";
/*    */   static final String DIRECT_ARENAS_DESCRIPTION = "The number of direct arenas.";
/*    */   static final String HEAP_ARENAS_DESCRIPTION = "The number of heap arenas.";
/*    */   static final String NORMAL_CACHE_SIZE_DESCRIPTION = "The size of the normal cache.";
/*    */   static final String SMALL_CACHE_SIZE_DESCRIPTION = "The size of the small cache.";
/*    */   static final String THREAD_LOCAL_CACHES_DESCRIPTION = "The number of thread local caches.";
/*    */   static final String USED_DIRECT_MEMORY_DESCRIPTION = "The number of bytes reserved by direct buffer allocator.";
/*    */   static final String USED_HEAP_MEMORY_DESCRIPTION = "The number of bytes reserved by heap buffer allocator.";
/*    */   static final String ACTIVE_DIRECT_MEMORY_DESCRIPTION = "The actual bytes consumed by in-use buffers allocated from heap buffer pools.";
/*    */   static final String ACTIVE_HEAP_MEMORY_DESCRIPTION = "The actual bytes consumed by in-use buffers allocated from direct buffer pools.";
/* 60 */   static final ByteBufAllocatorMetrics INSTANCE = new ByteBufAllocatorMetrics();
/*    */   
/* 62 */   final ConcurrentMap<String, ByteBufAllocatorMetric> cache = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void registerMetrics(String allocType, ByteBufAllocatorMetric metrics, ByteBufAllocator alloc) {
/* 68 */     MapUtils.computeIfAbsent(this.cache, metrics.hashCode() + "", key -> {
/*    */           Tags tags = Tags.of(new String[] { "id", key, "type", allocType });
/*    */           Gauge.builder("reactor.netty.bytebuf.allocator.used.heap.memory", metrics, ByteBufAllocatorMetric::usedHeapMemory).description("The number of bytes reserved by heap buffer allocator.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */           Gauge.builder("reactor.netty.bytebuf.allocator.used.direct.memory", metrics, ByteBufAllocatorMetric::usedDirectMemory).description("The number of bytes reserved by direct buffer allocator.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */           if (metrics instanceof PooledByteBufAllocatorMetric) {
/*    */             PooledByteBufAllocatorMetric pooledMetrics = (PooledByteBufAllocatorMetric)metrics;
/*    */             PooledByteBufAllocator pooledAlloc = (PooledByteBufAllocator)alloc;
/*    */             Gauge.builder("reactor.netty.bytebuf.allocator.heap.arenas", pooledMetrics, PooledByteBufAllocatorMetric::numHeapArenas).description("The number of heap arenas.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */             Gauge.builder("reactor.netty.bytebuf.allocator.direct.arenas", pooledMetrics, PooledByteBufAllocatorMetric::numDirectArenas).description("The number of direct arenas.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */             Gauge.builder("reactor.netty.bytebuf.allocator.threadlocal.caches", pooledMetrics, PooledByteBufAllocatorMetric::numThreadLocalCaches).description("The number of thread local caches.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */             Gauge.builder("reactor.netty.bytebuf.allocator.small.cache.size", pooledMetrics, PooledByteBufAllocatorMetric::smallCacheSize).description("The size of the small cache.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */             Gauge.builder("reactor.netty.bytebuf.allocator.normal.cache.size", pooledMetrics, PooledByteBufAllocatorMetric::normalCacheSize).description("The size of the normal cache.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */             Gauge.builder("reactor.netty.bytebuf.allocator.chunk.size", pooledMetrics, PooledByteBufAllocatorMetric::chunkSize).description("The chunk size for an arena.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */             Gauge.builder("reactor.netty.bytebuf.allocator.active.heap.memory", pooledAlloc, PooledByteBufAllocator::pinnedHeapMemory).description("The actual bytes consumed by in-use buffers allocated from direct buffer pools.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */             Gauge.builder("reactor.netty.bytebuf.allocator.active.direct.memory", pooledAlloc, PooledByteBufAllocator::pinnedDirectMemory).description("The actual bytes consumed by in-use buffers allocated from heap buffer pools.").tags((Iterable)tags).register(Metrics.REGISTRY);
/*    */           } 
/*    */           return metrics;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\ByteBufAllocatorMetrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */