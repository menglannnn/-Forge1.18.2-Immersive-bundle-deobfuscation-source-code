/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.group.ChannelGroup;
/*     */ import io.netty.channel.socket.ServerSocketChannel;
/*     */ import io.netty.channel.unix.ServerDomainSocketChannel;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.DisposableServer;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ServerTransportConfig<CONF extends TransportConfig>
/*     */   extends TransportConfig
/*     */ {
/*     */   Map<AttributeKey<?>, ?> childAttrs;
/*     */   ConnectionObserver childObserver;
/*     */   Map<ChannelOption<?>, ?> childOptions;
/*     */   Consumer<? super CONF> doOnBind;
/*     */   Consumer<? super DisposableServer> doOnBound;
/*     */   Consumer<? super Connection> doOnConnection;
/*     */   Consumer<? super DisposableServer> doOnUnbound;
/*     */   
/*     */   public final Map<AttributeKey<?>, ?> childAttributes() {
/*  56 */     if (this.childAttrs == null) {
/*  57 */       return Collections.emptyMap();
/*     */     }
/*  59 */     return Collections.unmodifiableMap(this.childAttrs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConnectionObserver childObserver() {
/*  70 */     return this.childObserver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Map<ChannelOption<?>, ?> childOptions() {
/*  79 */     if (this.childOptions == null) {
/*  80 */       return Collections.emptyMap();
/*     */     }
/*  82 */     return Collections.unmodifiableMap(this.childOptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super CONF> doOnBind() {
/*  92 */     return this.doOnBind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super DisposableServer> doOnBound() {
/* 102 */     return this.doOnBound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super Connection> doOnConnection() {
/* 112 */     return this.doOnConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Consumer<? super DisposableServer> doOnUnbound() {
/* 122 */     return this.doOnUnbound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServerTransportConfig(Map<ChannelOption<?>, ?> options, Map<ChannelOption<?>, ?> childOptions, Supplier<? extends SocketAddress> bindAddress) {
/* 145 */     super(options, bindAddress);
/* 146 */     this.childAttrs = Collections.emptyMap();
/* 147 */     this.childObserver = ConnectionObserver.emptyListener();
/* 148 */     this.childOptions = Objects.<Map<ChannelOption<?>, ?>>requireNonNull(childOptions, "childOptions");
/*     */   }
/*     */   
/*     */   protected ServerTransportConfig(ServerTransportConfig<CONF> parent) {
/* 152 */     super(parent);
/* 153 */     this.childAttrs = parent.childAttrs;
/* 154 */     this.childObserver = parent.childObserver;
/* 155 */     this.childOptions = parent.childOptions;
/* 156 */     this.doOnBind = parent.doOnBind;
/* 157 */     this.doOnBound = parent.doOnBound;
/* 158 */     this.doOnConnection = parent.doOnConnection;
/* 159 */     this.doOnUnbound = parent.doOnUnbound;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<? extends Channel> channelType(boolean isDomainSocket) {
/* 164 */     return isDomainSocket ? (Class)ServerDomainSocketChannel.class : (Class)ServerSocketChannel.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConnectionObserver defaultChildObserver() {
/* 173 */     if (channelGroup() == null && doOnConnection() == null) {
/* 174 */       return ConnectionObserver.emptyListener();
/*     */     }
/*     */     
/* 177 */     return new ServerTransportDoOnConnection(channelGroup(), doOnConnection());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConnectionObserver defaultConnectionObserver() {
/* 183 */     if (doOnBound() == null && doOnUnbound() == null) {
/* 184 */       return ConnectionObserver.emptyListener();
/*     */     }
/* 186 */     return new ServerTransportDoOn(doOnBound(), doOnUnbound());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelPipelineConfigurer defaultOnChannelInit() {
/* 191 */     return ChannelPipelineConfigurer.emptyConfigurer();
/*     */   }
/*     */ 
/*     */   
/*     */   protected final EventLoopGroup eventLoopGroup() {
/* 196 */     return loopResources().onServerSelect(isPreferNative());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final EventLoopGroup childEventLoopGroup() {
/* 205 */     return loopResources().onServer(isPreferNative());
/*     */   }
/*     */   
/*     */   static final class ServerTransportDoOn
/*     */     implements ConnectionObserver
/*     */   {
/*     */     final Consumer<? super DisposableServer> doOnBound;
/*     */     final Consumer<? super DisposableServer> doOnUnbound;
/*     */     
/*     */     ServerTransportDoOn(@Nullable Consumer<? super DisposableServer> doOnBound, @Nullable Consumer<? super DisposableServer> doOnUnbound) {
/* 215 */       this.doOnBound = doOnBound;
/* 216 */       this.doOnUnbound = doOnUnbound;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 221 */       if (newState == ConnectionObserver.State.CONNECTED) {
/* 222 */         if (this.doOnBound != null) {
/* 223 */           this.doOnBound.accept((DisposableServer)connection);
/*     */         }
/* 225 */         if (this.doOnUnbound != null)
/* 226 */           connection.channel()
/* 227 */             .closeFuture()
/* 228 */             .addListener(f -> this.doOnUnbound.accept((DisposableServer)connection)); 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ServerTransportDoOnConnection
/*     */     implements ConnectionObserver
/*     */   {
/*     */     final ChannelGroup channelGroup;
/*     */     final Consumer<? super Connection> doOnConnection;
/*     */     
/*     */     ServerTransportDoOnConnection(@Nullable ChannelGroup channelGroup, @Nullable Consumer<? super Connection> doOnConnection) {
/* 240 */       this.channelGroup = channelGroup;
/* 241 */       this.doOnConnection = doOnConnection;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 247 */       if (this.channelGroup != null && newState == ConnectionObserver.State.CONNECTED) {
/* 248 */         this.channelGroup.add(connection.channel());
/*     */         return;
/*     */       } 
/* 251 */       if (this.doOnConnection != null && newState == ConnectionObserver.State.CONFIGURED)
/*     */         try {
/* 253 */           this.doOnConnection.accept(connection);
/*     */         }
/* 255 */         catch (Throwable t) {
/* 256 */           TransportConfig.log.error(ReactorNetty.format(connection.channel(), ""), t);
/*     */           
/* 258 */           connection.channel().close();
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\ServerTransportConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */