/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelConfig;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.unix.DomainSocketAddress;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.netty.ChannelBindException;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.DisposableServer;
/*     */ import reactor.netty.FutureMono;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.AbortedException;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ServerTransport<T extends ServerTransport<T, CONF>, CONF extends ServerTransportConfig<CONF>>
/*     */   extends Transport<T, CONF>
/*     */ {
/*     */   public Mono<? extends DisposableServer> bind() {
/*  88 */     ServerTransportConfig serverTransportConfig = (ServerTransportConfig)configuration();
/*  89 */     Objects.requireNonNull(serverTransportConfig.bindAddress(), "bindAddress");
/*     */     
/*  91 */     Mono<? extends DisposableServer> mono = Mono.create(sink -> {
/*     */           DisposableBind disposableServer;
/*     */           
/*     */           SocketAddress local = Objects.<SocketAddress>requireNonNull(config.bindAddress().get(), "Bind Address supplier returned null");
/*     */           
/*     */           if (local instanceof InetSocketAddress) {
/*     */             InetSocketAddress localInet = (InetSocketAddress)local;
/*     */             
/*     */             if (localInet.isUnresolved()) {
/*     */               local = AddressUtils.createResolved(localInet.getHostName(), localInet.getPort());
/*     */             }
/*     */           } 
/*     */           
/*     */           boolean isDomainSocket = false;
/*     */           
/*     */           if (local instanceof DomainSocketAddress) {
/*     */             isDomainSocket = true;
/*     */             
/*     */             disposableServer = new UdsDisposableBind(sink, config, local);
/*     */           } else {
/*     */             disposableServer = new InetDisposableBind(sink, config, local);
/*     */           } 
/*     */           
/*     */           ConnectionObserver childObs = new ChildObserver(config.defaultChildObserver().then(config.childObserver()));
/*     */           
/*     */           Acceptor acceptor = new Acceptor(config.childEventLoopGroup(), (ChannelHandler)config.channelInitializer(childObs, null, true), config.childOptions, config.childAttrs, isDomainSocket);
/*     */           TransportConnector.bind(config, new AcceptorInitializer(acceptor), local, isDomainSocket).subscribe(disposableServer);
/*     */         });
/* 119 */     if (serverTransportConfig.doOnBind() != null) {
/* 120 */       mono = mono.doOnSubscribe(s -> config.doOnBind().accept(config));
/*     */     }
/* 122 */     return mono;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DisposableServer bindNow() {
/* 134 */     return bindNow(Duration.ofSeconds(45L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DisposableServer bindNow(Duration timeout) {
/* 147 */     Objects.requireNonNull(timeout, "timeout");
/*     */     try {
/* 149 */       return Objects.<DisposableServer>requireNonNull((DisposableServer)bind().block(timeout), "aborted");
/*     */     }
/* 151 */     catch (IllegalStateException e) {
/* 152 */       if (e.getMessage()
/* 153 */         .contains("blocking read")) {
/* 154 */         throw new IllegalStateException(getClass().getSimpleName() + " couldn't be started within " + timeout.toMillis() + "ms");
/*     */       }
/* 156 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void bindUntilJavaShutdown(Duration timeout, @Nullable Consumer<DisposableServer> onStart) {
/* 174 */     Objects.requireNonNull(timeout, "timeout");
/* 175 */     DisposableServer facade = Objects.<DisposableServer>requireNonNull(bindNow(), "facade");
/*     */     
/* 177 */     if (onStart != null) {
/* 178 */       onStart.accept(facade);
/*     */     }
/*     */     
/* 181 */     Runtime.getRuntime()
/* 182 */       .addShutdownHook(new Thread(() -> facade.disposeNow(timeout)));
/*     */     
/* 184 */     facade.onDispose()
/* 185 */       .block();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A> T childAttr(AttributeKey<A> key, @Nullable A value) {
/* 201 */     Objects.requireNonNull(key, "key");
/* 202 */     ServerTransport serverTransport = (ServerTransport)duplicate();
/* 203 */     ((ServerTransportConfig)serverTransport.configuration()).childAttrs = TransportConfig.updateMap(((ServerTransportConfig)configuration()).childAttrs, key, value);
/* 204 */     return (T)serverTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T childObserve(ConnectionObserver observer) {
/* 214 */     Objects.requireNonNull(observer, "observer");
/* 215 */     ServerTransport serverTransport = (ServerTransport)duplicate();
/* 216 */     ConnectionObserver current = ((ServerTransportConfig)configuration()).childObserver;
/* 217 */     ((ServerTransportConfig)serverTransport.configuration()).childObserver = (current == null) ? observer : current.then(observer);
/* 218 */     return (T)serverTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A> T childOption(ChannelOption<A> key, @Nullable A value) {
/* 236 */     Objects.requireNonNull(key, "key");
/*     */     
/* 238 */     if (ChannelOption.AUTO_READ == key) {
/* 239 */       if (value instanceof Boolean && Boolean.TRUE.equals(value)) {
/* 240 */         log.error("ChannelOption.AUTO_READ is configured to be [false], it cannot be set to [true]");
/*     */       }
/*     */       
/* 243 */       return (T)this;
/*     */     } 
/*     */     
/* 246 */     ServerTransport serverTransport = (ServerTransport)duplicate();
/* 247 */     ((ServerTransportConfig)serverTransport.configuration()).childOptions = TransportConfig.updateMap(((ServerTransportConfig)configuration()).childOptions, key, value);
/* 248 */     return (T)serverTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doOnBind(Consumer<? super CONF> doOnBind) {
/* 258 */     Objects.requireNonNull(doOnBind, "doOnBind");
/* 259 */     ServerTransport serverTransport = (ServerTransport)duplicate();
/*     */     
/* 261 */     Consumer<CONF> current = ((ServerTransportConfig)configuration()).doOnBind;
/* 262 */     ((ServerTransportConfig)serverTransport.configuration()).doOnBind = (current == null) ? doOnBind : current.andThen(doOnBind);
/* 263 */     return (T)serverTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doOnBound(Consumer<? super DisposableServer> doOnBound) {
/* 273 */     Objects.requireNonNull(doOnBound, "doOnBound");
/* 274 */     ServerTransport serverTransport = (ServerTransport)duplicate();
/*     */     
/* 276 */     Consumer<? super DisposableServer> consumer = ((ServerTransportConfig)configuration()).doOnBound;
/* 277 */     ((ServerTransportConfig)serverTransport.configuration()).doOnBound = (consumer == null) ? doOnBound : consumer.andThen(doOnBound);
/* 278 */     return (T)serverTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doOnConnection(Consumer<? super Connection> doOnConnection) {
/* 288 */     Objects.requireNonNull(doOnConnection, "doOnConnected");
/* 289 */     ServerTransport serverTransport = (ServerTransport)duplicate();
/*     */     
/* 291 */     Consumer<? super Connection> consumer = ((ServerTransportConfig)configuration()).doOnConnection;
/* 292 */     ((ServerTransportConfig)serverTransport.configuration()).doOnConnection = (consumer == null) ? doOnConnection : consumer.andThen(doOnConnection);
/* 293 */     return (T)serverTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doOnUnbound(Consumer<? super DisposableServer> doOnUnbound) {
/* 303 */     Objects.requireNonNull(doOnUnbound, "doOnUnbound");
/* 304 */     ServerTransport serverTransport = (ServerTransport)duplicate();
/*     */     
/* 306 */     Consumer<? super DisposableServer> consumer = ((ServerTransportConfig)configuration()).doOnUnbound;
/* 307 */     ((ServerTransportConfig)serverTransport.configuration()).doOnUnbound = (consumer == null) ? doOnUnbound : consumer.andThen(doOnUnbound);
/* 308 */     return (T)serverTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T host(String host) {
/* 318 */     Objects.requireNonNull(host, "host");
/* 319 */     return bindAddress(() -> AddressUtils.updateHost(((ServerTransportConfig)configuration()).bindAddress(), host));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T port(int port) {
/* 329 */     return bindAddress(() -> AddressUtils.updatePort(((ServerTransportConfig)configuration()).bindAddress(), port));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> warmup() {
/* 344 */     return Mono.fromRunnable(() -> {
/*     */           ((ServerTransportConfig)configuration()).childEventLoopGroup();
/*     */           ((ServerTransportConfig)configuration()).eventLoopGroup();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 353 */   static final Logger log = Loggers.getLogger(ServerTransport.class);
/*     */ 
/*     */   
/*     */   static class Acceptor
/*     */     extends ChannelInboundHandlerAdapter
/*     */   {
/*     */     final EventLoopGroup childGroup;
/*     */     
/*     */     final ChannelHandler childHandler;
/*     */     final Map<ChannelOption<?>, ?> childOptions;
/*     */     final Map<AttributeKey<?>, ?> childAttrs;
/*     */     final boolean isDomainSocket;
/*     */     Runnable enableAutoReadTask;
/*     */     
/*     */     Acceptor(EventLoopGroup childGroup, ChannelHandler childHandler, Map<ChannelOption<?>, ?> childOptions, Map<AttributeKey<?>, ?> childAttrs, boolean isDomainSocket) {
/* 368 */       this.childGroup = childGroup;
/* 369 */       this.childHandler = childHandler;
/* 370 */       this.childOptions = childOptions;
/* 371 */       this.childAttrs = childAttrs;
/* 372 */       this.isDomainSocket = isDomainSocket;
/*     */     }
/*     */ 
/*     */     
/*     */     public void channelRead(ChannelHandlerContext ctx, Object msg) {
/* 377 */       Channel child = (Channel)msg;
/*     */       
/* 379 */       child.pipeline().addLast(new ChannelHandler[] { this.childHandler });
/*     */       
/* 381 */       TransportConnector.setChannelOptions(child, this.childOptions, this.isDomainSocket);
/* 382 */       TransportConnector.setAttributes(child, this.childAttrs);
/*     */       
/*     */       try {
/* 385 */         this.childGroup.register(child).addListener((GenericFutureListener)(future -> {
/*     */               
/*     */               if (!future.isSuccess()) {
/*     */                 forceClose(child, future.cause());
/*     */               }
/*     */             }));
/* 391 */       } catch (Throwable t) {
/* 392 */         forceClose(child, t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
/* 398 */       ChannelConfig config = ctx.channel().config();
/* 399 */       if (config.isAutoRead()) {
/*     */ 
/*     */         
/* 402 */         config.setAutoRead(false);
/* 403 */         ctx.channel()
/* 404 */           .eventLoop()
/* 405 */           .schedule(this.enableAutoReadTask, 1L, TimeUnit.SECONDS)
/* 406 */           .addListener(future -> {
/*     */               if (!future.isSuccess() && ServerTransport.log.isDebugEnabled()) {
/*     */                 ServerTransport.log.debug(ReactorNetty.format(ctx.channel(), "Cannot enable auto-read"), future.cause());
/*     */               }
/*     */             });
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void enableAutoReadTask(Channel channel) {
/* 421 */       this.enableAutoReadTask = (() -> channel.config().setAutoRead(true));
/*     */     }
/*     */     
/*     */     static void forceClose(Channel child, Throwable t) {
/* 425 */       child.unsafe().closeForcibly();
/* 426 */       if (ServerTransport.log.isWarnEnabled())
/* 427 */         ServerTransport.log.warn(ReactorNetty.format(child, "Failed to register an accepted channel: {}"), new Object[] { child, t }); 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class AcceptorInitializer
/*     */     extends ChannelInitializer<Channel>
/*     */   {
/*     */     final ServerTransport.Acceptor acceptor;
/*     */     
/*     */     AcceptorInitializer(ServerTransport.Acceptor acceptor) {
/* 437 */       this.acceptor = acceptor;
/*     */     }
/*     */ 
/*     */     
/*     */     public void initChannel(Channel ch) {
/* 442 */       ch.eventLoop().execute(() -> ch.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)this.acceptor }));
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ChildObserver
/*     */     implements ConnectionObserver {
/*     */     final ConnectionObserver childObs;
/*     */     
/*     */     ChildObserver(ConnectionObserver childObs) {
/* 451 */       this.childObs = childObs;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onUncaughtException(Connection connection, Throwable error) {
/* 456 */       ChannelOperations<?, ?> ops = ChannelOperations.get(connection.channel());
/* 457 */       if (ops == null && (error instanceof java.io.IOException || AbortedException.isConnectionReset(error) || error instanceof io.netty.handler.codec.DecoderException)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 463 */         if (ServerTransport.log.isDebugEnabled()) {
/* 464 */           ServerTransport.log.debug(ReactorNetty.format(connection.channel(), "onUncaughtException(" + connection + ")"), error);
/*     */         }
/*     */       } else {
/*     */         
/* 468 */         ServerTransport.log.error(ReactorNetty.format(connection.channel(), "onUncaughtException(" + connection + ")"), error);
/*     */       } 
/* 470 */       connection.dispose();
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 475 */       if (newState == ConnectionObserver.State.DISCONNECTING && 
/* 476 */         connection.channel().isActive() && !connection.isPersistent()) {
/* 477 */         connection.dispose();
/*     */       }
/*     */ 
/*     */       
/* 481 */       this.childObs.onStateChange(connection, newState);
/*     */     }
/*     */   }
/*     */   
/*     */   static class DisposableBind
/*     */     implements CoreSubscriber<Channel>, DisposableServer, Connection
/*     */   {
/*     */     final MonoSink<DisposableServer> sink;
/*     */     final Context currentContext;
/*     */     final TransportConfig config;
/*     */     final SocketAddress bindAddress;
/*     */     Channel channel;
/*     */     Subscription subscription;
/*     */     
/*     */     DisposableBind(MonoSink<DisposableServer> sink, TransportConfig config, SocketAddress bindAddress) {
/* 496 */       this.sink = sink;
/* 497 */       this.currentContext = Context.of(sink.contextView());
/* 498 */       this.config = config;
/* 499 */       this.bindAddress = bindAddress;
/*     */     }
/*     */ 
/*     */     
/*     */     public Channel channel() {
/* 504 */       return this.channel;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 509 */       return this.currentContext;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void dispose() {
/* 515 */       if (this.channel != null) {
/* 516 */         if (this.channel.isActive()) {
/*     */           
/* 518 */           this.channel.close();
/*     */           
/* 520 */           LoopResources loopResources = this.config.loopResources();
/* 521 */           if (loopResources instanceof ConnectionProvider) {
/* 522 */             ((ConnectionProvider)loopResources).disposeWhen(this.bindAddress);
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 527 */         this.subscription.cancel();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void disposeNow(Duration timeout) {
/* 534 */       if (isDisposed()) {
/* 535 */         if (ServerTransport.log.isDebugEnabled()) {
/* 536 */           ServerTransport.log.debug(ReactorNetty.format(channel(), "Server has been disposed"));
/*     */         }
/*     */         return;
/*     */       } 
/* 540 */       if (ServerTransport.log.isDebugEnabled()) {
/* 541 */         ServerTransport.log.debug(ReactorNetty.format(channel(), "Server is about to be disposed with timeout: {}"), new Object[] { timeout });
/*     */       }
/* 543 */       dispose();
/* 544 */       Mono<Void> terminateSignals = Mono.empty();
/* 545 */       if (this.config.channelGroup != null && this.config.channelGroup.size() > 0) {
/*     */         
/* 547 */         HashMap<Channel, List<Mono<Void>>> channelsToMono = new HashMap<>(MapUtils.calculateInitialCapacity(this.config.channelGroup.size()));
/*     */         
/* 549 */         for (Channel channel : this.config.channelGroup) {
/* 550 */           Channel parent = channel.parent();
/*     */           
/* 552 */           boolean isParentServerChannel = parent instanceof io.netty.channel.ServerChannel;
/*     */           
/* 554 */           List<Mono<Void>> monos = (List<Mono<Void>>)MapUtils.computeIfAbsent(channelsToMono, 
/* 555 */               isParentServerChannel ? channel : parent, key -> new ArrayList());
/*     */           
/* 557 */           if (monos.isEmpty() && !isParentServerChannel)
/*     */           {
/*     */ 
/*     */             
/* 561 */             monos.add(FutureMono.from((Future)parent.close()));
/*     */           }
/* 563 */           ChannelOperations<?, ?> ops = ChannelOperations.get(channel);
/* 564 */           if (ops != null) {
/* 565 */             monos.add(ops.onTerminate().doFinally(sig -> ops.dispose()));
/*     */           }
/*     */         } 
/* 568 */         for (Map.Entry<Channel, List<Mono<Void>>> entry : channelsToMono.entrySet()) {
/* 569 */           Channel channel = entry.getKey();
/* 570 */           List<Mono<Void>> monos = entry.getValue();
/* 571 */           if (monos.isEmpty()) {
/*     */ 
/*     */ 
/*     */             
/* 575 */             channel.close();
/*     */             continue;
/*     */           } 
/* 578 */           terminateSignals = Mono.when(monos).and((Publisher)terminateSignals);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 584 */         onDispose().then(terminateSignals)
/* 585 */           .block(timeout);
/*     */       }
/* 587 */       catch (IllegalStateException e) {
/* 588 */         if (e.getMessage()
/* 589 */           .contains("blocking read")) {
/* 590 */           throw new IllegalStateException("Socket couldn't be stopped within " + timeout.toMillis() + "ms");
/*     */         }
/* 592 */         throw e;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 602 */       this.sink.error((Throwable)ChannelBindException.fail(this.bindAddress, t));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Channel channel) {
/* 607 */       this.channel = channel;
/* 608 */       if (ServerTransport.log.isDebugEnabled()) {
/* 609 */         ServerTransport.log.debug(ReactorNetty.format(channel, "Bound new server"));
/*     */       }
/* 611 */       this.sink.success(this);
/* 612 */       this.config.defaultConnectionObserver()
/* 613 */         .then(this.config.connectionObserver())
/* 614 */         .onStateChange(this, ConnectionObserver.State.CONNECTED);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 619 */       if (Operators.validate(this.subscription, s)) {
/* 620 */         this.subscription = s;
/* 621 */         this.sink.onCancel((Disposable)this);
/* 622 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class InetDisposableBind
/*     */     extends DisposableBind {
/*     */     InetDisposableBind(MonoSink<DisposableServer> sink, TransportConfig config, SocketAddress bindAddress) {
/* 630 */       super(sink, config, bindAddress);
/*     */     }
/*     */ 
/*     */     
/*     */     public InetSocketAddress address() {
/* 635 */       return (InetSocketAddress)channel().localAddress();
/*     */     }
/*     */ 
/*     */     
/*     */     public String host() {
/* 640 */       return address().getHostString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int port() {
/* 645 */       return address().getPort();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class UdsDisposableBind
/*     */     extends DisposableBind {
/*     */     UdsDisposableBind(MonoSink<DisposableServer> sink, TransportConfig config, SocketAddress bindAddress) {
/* 652 */       super(sink, config, bindAddress);
/*     */     }
/*     */ 
/*     */     
/*     */     public DomainSocketAddress address() {
/* 657 */       return (DomainSocketAddress)channel().localAddress();
/*     */     }
/*     */ 
/*     */     
/*     */     public String path() {
/* 662 */       return address().path();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\ServerTransport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */