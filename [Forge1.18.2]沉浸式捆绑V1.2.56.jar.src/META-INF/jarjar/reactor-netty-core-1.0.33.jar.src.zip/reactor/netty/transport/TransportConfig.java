/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.ByteBufAllocatorMetric;
/*     */ import io.netty.buffer.PooledByteBufAllocator;
/*     */ import io.netty.buffer.UnpooledByteBufAllocator;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFactory;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.group.ChannelGroup;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.ChannelPipelineConfigurer;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.Metrics;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransportConfig
/*     */ {
/*     */   Map<AttributeKey<?>, ?> attrs;
/*     */   Supplier<? extends SocketAddress> bindAddress;
/*     */   ChannelGroup channelGroup;
/*     */   ChannelPipelineConfigurer doOnChannelInit;
/*     */   LoggingHandler loggingHandler;
/*     */   LoopResources loopResources;
/*     */   ChannelMetricsRecorder metricsRecorder;
/*     */   ConnectionObserver observer;
/*     */   Map<ChannelOption<?>, ?> options;
/*     */   boolean preferNative;
/*     */   
/*     */   public final Map<AttributeKey<?>, ?> attributes() {
/*  67 */     if (this.attrs.isEmpty()) {
/*  68 */       return Collections.emptyMap();
/*     */     }
/*  70 */     return Collections.unmodifiableMap(this.attrs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Supplier<? extends SocketAddress> bindAddress() {
/*  80 */     return this.bindAddress;
/*     */   }
/*     */   
/*     */   public int channelHash() {
/*  84 */     int result = 1;
/*  85 */     result = 31 * result + Objects.hashCode(this.attrs);
/*  86 */     result = 31 * result + ((this.bindAddress != null) ? Objects.hashCode(this.bindAddress.get()) : 0);
/*  87 */     result = 31 * result + Objects.hashCode(this.channelGroup);
/*  88 */     result = 31 * result + Objects.hashCode(this.doOnChannelInit);
/*  89 */     result = 31 * result + Objects.hashCode(this.loggingHandler);
/*  90 */     result = 31 * result + Objects.hashCode(this.loopResources);
/*  91 */     result = 31 * result + Objects.hashCode(this.metricsRecorder);
/*  92 */     result = 31 * result + Objects.hashCode(this.observer);
/*  93 */     result = 31 * result + Objects.hashCode(this.options);
/*  94 */     result = 31 * result + Boolean.hashCode(this.preferNative);
/*  95 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final ChannelGroup channelGroup() {
/* 105 */     return this.channelGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChannelInitializer<Channel> channelInitializer(ConnectionObserver connectionObserver, @Nullable SocketAddress remoteAddress, boolean onServer) {
/* 118 */     Objects.requireNonNull(connectionObserver, "connectionObserver");
/* 119 */     return new TransportChannelInitializer(this, connectionObserver, remoteAddress, onServer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelOperations.OnSetup channelOperationsProvider() {
/* 128 */     return ChannelOperations.OnSetup.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConnectionObserver connectionObserver() {
/* 137 */     return this.observer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChannelPipelineConfigurer doOnChannelInit() {
/* 146 */     return this.doOnChannelInit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isPreferNative() {
/* 155 */     return this.preferNative;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final LoggingHandler loggingHandler() {
/* 165 */     return this.loggingHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LoopResources loopResources() {
/* 174 */     return (this.loopResources != null) ? this.loopResources : defaultLoopResources();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Supplier<? extends ChannelMetricsRecorder> metricsRecorder() {
/* 184 */     return (this.metricsRecorder != null) ? (() -> this.metricsRecorder) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Map<ChannelOption<?>, ?> options() {
/* 193 */     if (this.options.isEmpty()) {
/* 194 */       return Collections.emptyMap();
/*     */     }
/* 196 */     return Collections.unmodifiableMap(this.options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TransportConfig(Map<ChannelOption<?>, ?> options) {
/* 217 */     this.attrs = Collections.emptyMap();
/* 218 */     this.doOnChannelInit = ChannelPipelineConfigurer.emptyConfigurer();
/* 219 */     this.observer = ConnectionObserver.emptyListener();
/* 220 */     this.options = Objects.<Map<ChannelOption<?>, ?>>requireNonNull(options, "options");
/* 221 */     this.preferNative = LoopResources.DEFAULT_NATIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TransportConfig(Map<ChannelOption<?>, ?> options, Supplier<? extends SocketAddress> bindAddress) {
/* 228 */     this.attrs = Collections.emptyMap();
/* 229 */     this.bindAddress = Objects.<Supplier<? extends SocketAddress>>requireNonNull(bindAddress, "bindAddress");
/* 230 */     this.doOnChannelInit = ChannelPipelineConfigurer.emptyConfigurer();
/* 231 */     this.observer = ConnectionObserver.emptyListener();
/* 232 */     this.options = Objects.<Map<ChannelOption<?>, ?>>requireNonNull(options, "options");
/* 233 */     this.preferNative = LoopResources.DEFAULT_NATIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TransportConfig(TransportConfig parent) {
/* 240 */     this.attrs = parent.attrs;
/* 241 */     this.bindAddress = parent.bindAddress;
/* 242 */     this.channelGroup = parent.channelGroup;
/* 243 */     this.doOnChannelInit = parent.doOnChannelInit;
/* 244 */     this.loggingHandler = parent.loggingHandler;
/* 245 */     this.loopResources = parent.loopResources;
/* 246 */     this.metricsRecorder = parent.metricsRecorder;
/* 247 */     this.observer = parent.observer;
/* 248 */     this.options = parent.options;
/* 249 */     this.preferNative = parent.preferNative;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ChannelFactory<? extends Channel> connectionFactory(EventLoopGroup elg, boolean isDomainSocket) {
/* 277 */     return () -> loopResources().onChannel(channelType(isDomainSocket), elg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loggingHandler(LoggingHandler loggingHandler) {
/* 323 */     this.loggingHandler = loggingHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void metricsRecorder(@Nullable Supplier<? extends ChannelMetricsRecorder> metricsRecorderSupplier) {
/* 332 */     this.metricsRecorder = (metricsRecorderSupplier != null) ? metricsRecorderSupplier.get() : null;
/*     */   }
/*     */   
/*     */   protected ChannelMetricsRecorder metricsRecorderInternal() {
/* 336 */     return this.metricsRecorder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <K, V> Map<K, V> updateMap(Map<K, V> parentMap, Object key, @Nullable Object value) {
/* 351 */     if (parentMap.isEmpty()) {
/* 352 */       return (value == null) ? parentMap : Collections.<K, V>singletonMap((K)key, (V)value);
/*     */     }
/*     */     
/* 355 */     Map<K, V> attrs = new HashMap<>(MapUtils.calculateInitialCapacity(parentMap.size() + 1));
/* 356 */     attrs.putAll(parentMap);
/* 357 */     if (value == null) {
/* 358 */       attrs.remove(key);
/*     */     } else {
/*     */       
/* 361 */       attrs.put((K)key, (V)value);
/*     */     } 
/* 363 */     return attrs;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class TransportChannelInitializer
/*     */     extends ChannelInitializer<Channel>
/*     */   {
/*     */     final TransportConfig config;
/*     */     final ConnectionObserver connectionObserver;
/*     */     final boolean onServer;
/*     */     final SocketAddress remoteAddress;
/*     */     
/*     */     TransportChannelInitializer(TransportConfig config, ConnectionObserver connectionObserver, @Nullable SocketAddress remoteAddress, boolean onServer) {
/* 376 */       this.config = config;
/* 377 */       this.connectionObserver = connectionObserver;
/* 378 */       this.onServer = onServer;
/* 379 */       this.remoteAddress = remoteAddress;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void initChannel(Channel channel) {
/* 384 */       ChannelPipeline pipeline = channel.pipeline();
/*     */       
/* 386 */       if (this.config.metricsRecorder != null) {
/* 387 */         ChannelOperations.addMetricsHandler(channel, this.config.metricsRecorder, this.remoteAddress, this.onServer);
/*     */         
/* 389 */         if (Metrics.isInstrumentationAvailable()) {
/*     */           try {
/* 391 */             ByteBufAllocator alloc = channel.alloc();
/* 392 */             if (alloc instanceof PooledByteBufAllocator) {
/* 393 */               ByteBufAllocatorMetrics.INSTANCE.registerMetrics("pooled", (ByteBufAllocatorMetric)((PooledByteBufAllocator)alloc).metric(), alloc);
/*     */             }
/* 395 */             else if (alloc instanceof UnpooledByteBufAllocator) {
/* 396 */               ByteBufAllocatorMetrics.INSTANCE.registerMetrics("unpooled", ((UnpooledByteBufAllocator)alloc).metric(), alloc);
/*     */             } 
/*     */             
/* 399 */             MicrometerEventLoopMeterRegistrar.INSTANCE.registerMetrics(channel.eventLoop());
/*     */           }
/* 401 */           catch (RuntimeException e) {
/* 402 */             if (TransportConfig.log.isWarnEnabled()) {
/* 403 */               TransportConfig.log.warn(ReactorNetty.format(channel, "Exception caught while recording metrics."), e);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 410 */       if (this.config.loggingHandler != null) {
/* 411 */         pipeline.addFirst("reactor.left.loggingHandler", (ChannelHandler)this.config.loggingHandler);
/*     */       }
/*     */       
/* 414 */       ChannelOperations.addReactiveBridge(channel, this.config.channelOperationsProvider(), this.connectionObserver);
/*     */       
/* 416 */       this.config.defaultOnChannelInit()
/* 417 */         .then(this.config.doOnChannelInit)
/* 418 */         .onChannelInit(this.connectionObserver, channel, this.remoteAddress);
/*     */       
/* 420 */       pipeline.remove((ChannelHandler)this);
/*     */       
/* 422 */       if (TransportConfig.log.isDebugEnabled()) {
/* 423 */         TransportConfig.log.debug(ReactorNetty.format(channel, "Initialized pipeline {}"), new Object[] { pipeline.toString() });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 428 */   static final Logger log = Loggers.getLogger(TransportConfig.class);
/*     */   
/*     */   protected abstract Class<? extends Channel> channelType(boolean paramBoolean);
/*     */   
/*     */   protected abstract ConnectionObserver defaultConnectionObserver();
/*     */   
/*     */   protected abstract LoggingHandler defaultLoggingHandler();
/*     */   
/*     */   protected abstract LoopResources defaultLoopResources();
/*     */   
/*     */   protected abstract ChannelMetricsRecorder defaultMetricsRecorder();
/*     */   
/*     */   protected abstract ChannelPipelineConfigurer defaultOnChannelInit();
/*     */   
/*     */   protected abstract EventLoopGroup eventLoopGroup();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\TransportConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */