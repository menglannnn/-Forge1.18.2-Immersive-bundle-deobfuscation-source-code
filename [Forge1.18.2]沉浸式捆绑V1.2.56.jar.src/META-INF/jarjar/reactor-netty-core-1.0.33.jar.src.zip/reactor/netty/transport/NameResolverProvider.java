/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.resolver.HostsFileEntriesResolver;
/*     */ import io.netty.resolver.ResolvedAddressTypes;
/*     */ import io.netty.resolver.dns.DnsAddressResolverGroup;
/*     */ import io.netty.resolver.dns.DnsCache;
/*     */ import io.netty.resolver.dns.DnsNameResolverBuilder;
/*     */ import io.netty.resolver.dns.DnsQueryLifecycleObserverFactory;
/*     */ import io.netty.resolver.dns.LoggingDnsQueryLifeCycleObserverFactory;
/*     */ import io.netty.resolver.dns.RoundRobinDnsAddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NameResolverProvider
/*     */ {
/*     */   final Duration cacheMaxTimeToLive;
/*     */   final Duration cacheMinTimeToLive;
/*     */   final Duration cacheNegativeTimeToLive;
/*     */   final boolean completeOncePreferredResolved;
/*     */   final boolean disableRecursionDesired;
/*     */   final boolean disableOptionalRecord;
/*     */   final HostsFileEntriesResolver hostsFileEntriesResolver;
/*     */   final DnsQueryLifecycleObserverFactory loggingFactory;
/*     */   final LoopResources loopResources;
/*     */   final int maxPayloadSize;
/*     */   final int maxQueriesPerResolve;
/*     */   final int ndots;
/*     */   final boolean preferNative;
/*     */   final Duration queryTimeout;
/*     */   final ResolvedAddressTypes resolvedAddressTypes;
/*     */   final DnsCache resolveCache;
/*     */   final Supplier<? extends SocketAddress> bindAddressSupplier;
/*     */   final boolean roundRobinSelection;
/*     */   final Iterable<String> searchDomains;
/*     */   
/*     */   public static NameResolverSpec builder() {
/* 268 */     return new Build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration cacheMaxTimeToLive() {
/* 277 */     return this.cacheMaxTimeToLive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration cacheMinTimeToLive() {
/* 286 */     return this.cacheMinTimeToLive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration cacheNegativeTimeToLive() {
/* 295 */     return this.cacheNegativeTimeToLive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public HostsFileEntriesResolver hostsFileEntriesResolver() {
/* 306 */     return this.hostsFileEntriesResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompleteOncePreferredResolved() {
/* 317 */     return this.completeOncePreferredResolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisableOptionalRecord() {
/* 326 */     return this.disableOptionalRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisableRecursionDesired() {
/* 335 */     return this.disableRecursionDesired;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPreferNative() {
/* 344 */     return this.preferNative;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRoundRobinSelection() {
/* 353 */     return this.roundRobinSelection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LoopResources loopResources() {
/* 363 */     return this.loopResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxPayloadSize() {
/* 372 */     return this.maxPayloadSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxQueriesPerResolve() {
/* 381 */     return this.maxQueriesPerResolve;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ndots() {
/* 390 */     return this.ndots;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration queryTimeout() {
/* 399 */     return this.queryTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResolvedAddressTypes resolvedAddressTypes() {
/* 409 */     return this.resolvedAddressTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DnsCache resolveCache() {
/* 420 */     return this.resolveCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Supplier<? extends SocketAddress> bindAddressSupplier() {
/* 431 */     return this.bindAddressSupplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Iterable<String> searchDomains() {
/* 441 */     return this.searchDomains;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 447 */     if (this == o) {
/* 448 */       return true;
/*     */     }
/* 450 */     if (!(o instanceof NameResolverProvider)) {
/* 451 */       return false;
/*     */     }
/* 453 */     NameResolverProvider that = (NameResolverProvider)o;
/* 454 */     return (this.completeOncePreferredResolved == that.completeOncePreferredResolved && this.disableRecursionDesired == that.disableRecursionDesired && this.disableOptionalRecord == that.disableOptionalRecord && this.maxPayloadSize == that.maxPayloadSize && this.maxQueriesPerResolve == that.maxQueriesPerResolve && this.ndots == that.ndots && this.preferNative == that.preferNative && this.roundRobinSelection == that.roundRobinSelection && 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 462 */       Objects.equals(this.loggingFactory, that.loggingFactory) && this.cacheMaxTimeToLive
/* 463 */       .equals(that.cacheMaxTimeToLive) && this.cacheMinTimeToLive
/* 464 */       .equals(that.cacheMinTimeToLive) && this.cacheNegativeTimeToLive
/* 465 */       .equals(that.cacheNegativeTimeToLive) && 
/* 466 */       Objects.equals(this.loopResources, that.loopResources) && this.queryTimeout
/* 467 */       .equals(that.queryTimeout) && this.resolvedAddressTypes == that.resolvedAddressTypes && 
/*     */       
/* 469 */       Objects.equals(this.resolveCache, that.resolveCache) && 
/* 470 */       Objects.equals(this.bindAddressSupplier, that.bindAddressSupplier) && 
/*     */       
/* 472 */       Objects.equals(this.searchDomains, that.searchDomains));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 477 */     int result = 1;
/* 478 */     result = 31 * result + Objects.hashCode(this.cacheMaxTimeToLive);
/* 479 */     result = 31 * result + Objects.hashCode(this.cacheMinTimeToLive);
/* 480 */     result = 31 * result + Objects.hashCode(this.cacheNegativeTimeToLive);
/* 481 */     result = 31 * result + Boolean.hashCode(this.completeOncePreferredResolved);
/* 482 */     result = 31 * result + Boolean.hashCode(this.disableRecursionDesired);
/* 483 */     result = 31 * result + Boolean.hashCode(this.disableOptionalRecord);
/* 484 */     result = 31 * result + Objects.hashCode(this.loggingFactory);
/* 485 */     result = 31 * result + Objects.hashCode(this.loopResources);
/* 486 */     result = 31 * result + this.maxPayloadSize;
/* 487 */     result = 31 * result + this.maxQueriesPerResolve;
/* 488 */     result = 31 * result + this.ndots;
/* 489 */     result = 31 * result + Boolean.hashCode(this.preferNative);
/* 490 */     result = 31 * result + Objects.hashCode(this.queryTimeout);
/* 491 */     result = 31 * result + Objects.hashCode(this.resolvedAddressTypes);
/* 492 */     result = 31 * result + Objects.hashCode(this.resolveCache);
/* 493 */     result = 31 * result + Objects.hashCode(this.bindAddressSupplier);
/* 494 */     result = 31 * result + Boolean.hashCode(this.roundRobinSelection);
/* 495 */     result = 31 * result + Objects.hashCode(this.searchDomains);
/* 496 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DnsAddressResolverGroup newNameResolverGroup(LoopResources defaultLoopResources, boolean defaultPreferNative) {
/*     */     LoopResources loop;
/*     */     EventLoopGroup group;
/* 506 */     Objects.requireNonNull(defaultLoopResources, "defaultLoopResources");
/*     */ 
/*     */     
/* 509 */     if (this.loopResources == null) {
/* 510 */       loop = defaultLoopResources;
/* 511 */       group = loop.onClient(defaultPreferNative);
/*     */     } else {
/*     */       
/* 514 */       loop = this.loopResources;
/* 515 */       group = loop.onClient(this.preferNative);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 529 */     DnsNameResolverBuilder builder = (new DnsNameResolverBuilder()).ttl(Math.toIntExact(this.cacheMinTimeToLive.getSeconds()), Math.toIntExact(this.cacheMaxTimeToLive.getSeconds())).negativeTtl(Math.toIntExact(this.cacheNegativeTimeToLive.getSeconds())).completeOncePreferredResolved(this.completeOncePreferredResolved).optResourceEnabled(!this.disableOptionalRecord).recursionDesired(!this.disableRecursionDesired).maxPayloadSize(this.maxPayloadSize).maxQueriesPerResolve(this.maxQueriesPerResolve).ndots(this.ndots).queryTimeoutMillis(this.queryTimeout.toMillis()).eventLoop(group.next()).channelFactory(() -> (DatagramChannel)loop.onChannel(DatagramChannel.class, group)).socketChannelFactory(() -> (SocketChannel)loop.onChannel(SocketChannel.class, group));
/* 530 */     if (this.hostsFileEntriesResolver != null) {
/* 531 */       builder.hostsFileEntriesResolver(this.hostsFileEntriesResolver);
/*     */     }
/* 533 */     if (this.loggingFactory != null) {
/* 534 */       builder.dnsQueryLifecycleObserverFactory(this.loggingFactory);
/*     */     }
/* 536 */     if (this.resolvedAddressTypes != null) {
/* 537 */       builder.resolvedAddressTypes(this.resolvedAddressTypes);
/*     */     }
/* 539 */     if (this.resolveCache != null) {
/* 540 */       builder.resolveCache(this.resolveCache);
/*     */     }
/* 542 */     if (this.bindAddressSupplier != null)
/*     */     {
/*     */       
/* 545 */       builder.localAddress(this.bindAddressSupplier.get());
/*     */     }
/* 547 */     if (this.searchDomains != null) {
/* 548 */       builder.searchDomains(this.searchDomains);
/*     */     }
/* 550 */     return this.roundRobinSelection ? (DnsAddressResolverGroup)new RoundRobinDnsAddressResolverGroup(builder) : new DnsAddressResolverGroup(builder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NameResolverProvider(Build build) {
/* 574 */     this.cacheMaxTimeToLive = build.cacheMaxTimeToLive;
/* 575 */     this.cacheMinTimeToLive = build.cacheMinTimeToLive;
/* 576 */     this.cacheNegativeTimeToLive = build.cacheNegativeTimeToLive;
/* 577 */     this.completeOncePreferredResolved = build.completeOncePreferredResolved;
/* 578 */     this.disableOptionalRecord = build.disableOptionalRecord;
/* 579 */     this.disableRecursionDesired = build.disableRecursionDesired;
/* 580 */     this.hostsFileEntriesResolver = build.hostsFileEntriesResolver;
/* 581 */     this.loggingFactory = build.loggingFactory;
/* 582 */     this.loopResources = build.loopResources;
/* 583 */     this.maxPayloadSize = build.maxPayloadSize;
/* 584 */     this.maxQueriesPerResolve = build.maxQueriesPerResolve;
/* 585 */     this.ndots = build.ndots;
/* 586 */     this.preferNative = build.preferNative;
/* 587 */     this.queryTimeout = build.queryTimeout;
/* 588 */     this.resolvedAddressTypes = build.resolvedAddressTypes;
/* 589 */     this.resolveCache = build.resolveCache;
/* 590 */     this.bindAddressSupplier = build.bindAddressSupplier;
/* 591 */     this.roundRobinSelection = build.roundRobinSelection;
/* 592 */     this.searchDomains = build.searchDomains;
/*     */   }
/*     */   
/*     */   static final class Build implements NameResolverSpec {
/* 596 */     static final Duration DEFAULT_CACHE_MAX_TIME_TO_LIVE = Duration.ofSeconds(2147483647L);
/* 597 */     static final Duration DEFAULT_CACHE_MIN_TIME_TO_LIVE = Duration.ofSeconds(0L);
/* 598 */     static final Duration DEFAULT_CACHE_NEGATIVE_TIME_TO_LIVE = Duration.ofSeconds(0L);
/*     */     static final boolean DEFAULT_COMPLETE_ONCE_PREFERRED_RESOLVED = true;
/*     */     static final int DEFAULT_MAX_PAYLOAD_SIZE = 4096;
/*     */     static final int DEFAULT_MAX_QUERIES_PER_RESOLVE = 16;
/*     */     static final int DEFAULT_NDOTS = -1;
/* 603 */     static final Duration DEFAULT_QUERY_TIMEOUT = Duration.ofSeconds(5L);
/*     */     
/* 605 */     Duration cacheMaxTimeToLive = DEFAULT_CACHE_MAX_TIME_TO_LIVE;
/* 606 */     Duration cacheMinTimeToLive = DEFAULT_CACHE_MIN_TIME_TO_LIVE;
/* 607 */     Duration cacheNegativeTimeToLive = DEFAULT_CACHE_NEGATIVE_TIME_TO_LIVE;
/*     */     boolean completeOncePreferredResolved = true;
/*     */     boolean disableOptionalRecord;
/*     */     boolean disableRecursionDesired;
/*     */     HostsFileEntriesResolver hostsFileEntriesResolver;
/*     */     DnsQueryLifecycleObserverFactory loggingFactory;
/*     */     LoopResources loopResources;
/* 614 */     int maxPayloadSize = 4096;
/* 615 */     int maxQueriesPerResolve = 16;
/* 616 */     int ndots = -1;
/* 617 */     boolean preferNative = LoopResources.DEFAULT_NATIVE;
/* 618 */     Duration queryTimeout = DEFAULT_QUERY_TIMEOUT;
/*     */     
/*     */     ResolvedAddressTypes resolvedAddressTypes;
/*     */     DnsCache resolveCache;
/*     */     Supplier<? extends SocketAddress> bindAddressSupplier;
/*     */     boolean roundRobinSelection;
/*     */     Iterable<String> searchDomains;
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec cacheMaxTimeToLive(Duration cacheMaxTimeToLive) {
/* 627 */       this.cacheMaxTimeToLive = Objects.<Duration>requireNonNull(cacheMaxTimeToLive);
/* 628 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec cacheMinTimeToLive(Duration cacheMinTimeToLive) {
/* 633 */       this.cacheMinTimeToLive = Objects.<Duration>requireNonNull(cacheMinTimeToLive);
/* 634 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec cacheNegativeTimeToLive(Duration cacheNegativeTimeToLive) {
/* 639 */       this.cacheNegativeTimeToLive = Objects.<Duration>requireNonNull(cacheNegativeTimeToLive);
/* 640 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec completeOncePreferredResolved(boolean enable) {
/* 645 */       this.completeOncePreferredResolved = enable;
/* 646 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec disableOptionalRecord(boolean disable) {
/* 651 */       this.disableOptionalRecord = disable;
/* 652 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec disableRecursionDesired(boolean disable) {
/* 657 */       this.disableRecursionDesired = disable;
/* 658 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec hostsFileEntriesResolver(HostsFileEntriesResolver hostsFileEntriesResolver) {
/* 663 */       this.hostsFileEntriesResolver = Objects.<HostsFileEntriesResolver>requireNonNull(hostsFileEntriesResolver);
/* 664 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec maxPayloadSize(int maxPayloadSize) {
/* 669 */       if (maxPayloadSize < 1) {
/* 670 */         throw new IllegalArgumentException("maxPayloadSize must be positive");
/*     */       }
/* 672 */       this.maxPayloadSize = maxPayloadSize;
/* 673 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec maxQueriesPerResolve(int maxQueriesPerResolve) {
/* 678 */       if (maxQueriesPerResolve < 1) {
/* 679 */         throw new IllegalArgumentException("maxQueriesPerResolve must be positive");
/*     */       }
/* 681 */       this.maxQueriesPerResolve = maxQueriesPerResolve;
/* 682 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec ndots(int ndots) {
/* 687 */       if (ndots < -1) {
/* 688 */         throw new IllegalArgumentException("ndots must be greater or equal to -1");
/*     */       }
/* 690 */       this.ndots = ndots;
/* 691 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec queryTimeout(Duration queryTimeout) {
/* 696 */       this.queryTimeout = Objects.<Duration>requireNonNull(queryTimeout, "queryTimeout");
/* 697 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec resolvedAddressTypes(ResolvedAddressTypes resolvedAddressTypes) {
/* 702 */       this.resolvedAddressTypes = Objects.<ResolvedAddressTypes>requireNonNull(resolvedAddressTypes);
/* 703 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec resolveCache(DnsCache resolveCache) {
/* 708 */       this.resolveCache = Objects.<DnsCache>requireNonNull(resolveCache);
/* 709 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec bindAddressSupplier(Supplier<? extends SocketAddress> bindAddressSupplier) {
/* 715 */       Objects.requireNonNull(bindAddressSupplier, "bindAddressSupplier");
/* 716 */       this.bindAddressSupplier = bindAddressSupplier;
/* 717 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec roundRobinSelection(boolean enable) {
/* 722 */       this.roundRobinSelection = enable;
/* 723 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec runOn(EventLoopGroup eventLoopGroup) {
/* 728 */       Objects.requireNonNull(eventLoopGroup, "eventLoopGroup");
/* 729 */       return runOn(preferNative -> eventLoopGroup);
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec runOn(LoopResources loopResources) {
/* 734 */       Objects.requireNonNull(loopResources, "loopResources");
/* 735 */       return runOn(loopResources, LoopResources.DEFAULT_NATIVE);
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec runOn(LoopResources loopResources, boolean preferNative) {
/* 740 */       Objects.requireNonNull(loopResources, "loopResources");
/* 741 */       this.loopResources = loopResources;
/* 742 */       this.preferNative = preferNative;
/* 743 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec searchDomains(List<String> searchDomains) {
/* 748 */       this.searchDomains = Objects.<Iterable<String>>requireNonNull(searchDomains, "searchDomains");
/* 749 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider.NameResolverSpec trace(String category, LogLevel level) {
/* 754 */       Objects.requireNonNull(category, "category");
/* 755 */       Objects.requireNonNull(level, "level");
/* 756 */       this.loggingFactory = (DnsQueryLifecycleObserverFactory)new LoggingDnsQueryLifeCycleObserverFactory(category, level);
/* 757 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NameResolverProvider build() {
/* 762 */       return new NameResolverProvider(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface NameResolverSpec {
/*     */     NameResolverProvider build();
/*     */     
/*     */     NameResolverSpec cacheMaxTimeToLive(Duration param1Duration);
/*     */     
/*     */     NameResolverSpec cacheMinTimeToLive(Duration param1Duration);
/*     */     
/*     */     NameResolverSpec cacheNegativeTimeToLive(Duration param1Duration);
/*     */     
/*     */     NameResolverSpec completeOncePreferredResolved(boolean param1Boolean);
/*     */     
/*     */     NameResolverSpec disableOptionalRecord(boolean param1Boolean);
/*     */     
/*     */     NameResolverSpec disableRecursionDesired(boolean param1Boolean);
/*     */     
/*     */     NameResolverSpec hostsFileEntriesResolver(HostsFileEntriesResolver param1HostsFileEntriesResolver);
/*     */     
/*     */     NameResolverSpec maxPayloadSize(int param1Int);
/*     */     
/*     */     NameResolverSpec maxQueriesPerResolve(int param1Int);
/*     */     
/*     */     NameResolverSpec ndots(int param1Int);
/*     */     
/*     */     NameResolverSpec queryTimeout(Duration param1Duration);
/*     */     
/*     */     NameResolverSpec resolvedAddressTypes(ResolvedAddressTypes param1ResolvedAddressTypes);
/*     */     
/*     */     NameResolverSpec resolveCache(DnsCache param1DnsCache);
/*     */     
/*     */     NameResolverSpec bindAddressSupplier(Supplier<? extends SocketAddress> param1Supplier);
/*     */     
/*     */     NameResolverSpec roundRobinSelection(boolean param1Boolean);
/*     */     
/*     */     NameResolverSpec runOn(EventLoopGroup param1EventLoopGroup);
/*     */     
/*     */     NameResolverSpec runOn(LoopResources param1LoopResources);
/*     */     
/*     */     NameResolverSpec runOn(LoopResources param1LoopResources, boolean param1Boolean);
/*     */     
/*     */     NameResolverSpec searchDomains(List<String> param1List);
/*     */     
/*     */     NameResolverSpec trace(String param1String, LogLevel param1LogLevel);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\NameResolverProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */