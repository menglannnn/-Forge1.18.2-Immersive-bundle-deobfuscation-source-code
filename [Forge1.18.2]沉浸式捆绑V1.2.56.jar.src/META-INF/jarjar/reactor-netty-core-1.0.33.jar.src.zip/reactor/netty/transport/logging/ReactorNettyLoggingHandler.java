/*     */ package reactor.netty.transport.logging;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.logging.ByteBufFormat;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Objects;
/*     */ import reactor.netty.ChannelOperationsId;
/*     */ import reactor.netty.Connection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ReactorNettyLoggingHandler
/*     */   extends LoggingHandler
/*     */ {
/*     */   private final AdvancedByteBufFormat byteBufFormat;
/*     */   private final Charset charset;
/*     */   private final String name;
/*     */   static final char CHANNEL_ID_PREFIX = '[';
/*     */   static final char CHANNEL_ID_SUFFIX = ']';
/*     */   static final String ORIGINAL_CHANNEL_ID_PREFIX = "[id: 0x";
/*     */   
/*     */   ReactorNettyLoggingHandler(String name, LogLevel level, AdvancedByteBufFormat byteBufFormat) {
/*  65 */     super(name, level, (byteBufFormat == AdvancedByteBufFormat.SIMPLE) ? ByteBufFormat.SIMPLE : ByteBufFormat.HEX_DUMP);
/*  66 */     this.byteBufFormat = byteBufFormat;
/*  67 */     this.charset = null;
/*  68 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReactorNettyLoggingHandler(String name, LogLevel level, Charset charset) {
/*  80 */     super(name, level);
/*  81 */     this.byteBufFormat = AdvancedByteBufFormat.TEXTUAL;
/*  82 */     this.charset = Objects.<Charset>requireNonNull(charset, "charset");
/*  83 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBufFormat byteBufFormat() {
/*  92 */     if (this.byteBufFormat == AdvancedByteBufFormat.SIMPLE) {
/*  93 */       return ByteBufFormat.SIMPLE;
/*     */     }
/*  95 */     if (this.byteBufFormat == AdvancedByteBufFormat.HEX_DUMP) {
/*  96 */       return ByteBufFormat.HEX_DUMP;
/*     */     }
/*  98 */     throw new UnsupportedOperationException("ReactorNettyLoggingHandler isn't using the classic ByteBufFormat.");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 103 */     if (this == o) {
/* 104 */       return true;
/*     */     }
/* 106 */     if (!(o instanceof ReactorNettyLoggingHandler)) {
/* 107 */       return false;
/*     */     }
/* 109 */     ReactorNettyLoggingHandler that = (ReactorNettyLoggingHandler)o;
/* 110 */     return (this.byteBufFormat == that.byteBufFormat && 
/* 111 */       Objects.equals(this.charset, that.charset) && 
/* 112 */       level() == that.level() && this.name
/* 113 */       .equals(that.name));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 118 */     int result = 1;
/* 119 */     result = 31 * result + Objects.hashCode(this.byteBufFormat);
/* 120 */     result = 31 * result + Objects.hashCode(this.charset);
/* 121 */     result = 31 * result + Objects.hashCode(level());
/* 122 */     result = 31 * result + Objects.hashCode(this.name);
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String format(ChannelHandlerContext ctx, String eventName) {
/* 128 */     String chStr = channelString(ctx.channel());
/* 129 */     return (new StringBuilder(chStr.length() + 1 + eventName.length()))
/* 130 */       .append(chStr)
/* 131 */       .append(' ')
/* 132 */       .append(eventName)
/* 133 */       .toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String format(ChannelHandlerContext ctx, String eventName, Object arg) {
/* 138 */     if (arg instanceof ByteBuf) {
/* 139 */       return formatByteBuf(ctx, eventName, (ByteBuf)arg);
/*     */     }
/* 141 */     if (arg instanceof ByteBufHolder) {
/* 142 */       return formatByteBufHolder(ctx, eventName, (ByteBufHolder)arg);
/*     */     }
/*     */     
/* 145 */     return formatSimple(ctx, eventName, arg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String format(ChannelHandlerContext ctx, String eventName, Object firstArg, Object secondArg) {
/* 151 */     if (secondArg == null) {
/* 152 */       return formatSimple(ctx, eventName, firstArg);
/*     */     }
/*     */     
/* 155 */     String chStr = channelString(ctx.channel());
/* 156 */     String arg1Str = String.valueOf(firstArg);
/* 157 */     String arg2Str = secondArg.toString();
/* 158 */     return (new StringBuilder(chStr.length() + 1 + eventName.length() + 2 + arg1Str.length() + 2 + arg2Str.length()))
/* 159 */       .append(chStr)
/* 160 */       .append(' ')
/* 161 */       .append(eventName)
/* 162 */       .append(": ")
/* 163 */       .append(arg1Str)
/* 164 */       .append(", ")
/* 165 */       .append(arg2Str)
/* 166 */       .toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private String channelString(Channel channel) {
/*     */     StringBuilder result;
/* 172 */     Connection connection = Connection.from(channel);
/* 173 */     if (connection instanceof ChannelOperationsId) {
/* 174 */       String channelStr = ((ChannelOperationsId)connection).asLongText();
/* 175 */       if (channelStr.charAt(0) != '(') {
/*     */ 
/*     */ 
/*     */         
/* 179 */         result = (new StringBuilder(1 + channelStr.length() + 1)).append('[').append(channelStr).append(']');
/*     */       } else {
/*     */         
/* 182 */         result = new StringBuilder(channelStr);
/*     */       } 
/*     */     } else {
/*     */       
/* 186 */       String channelStr = channel.toString();
/* 187 */       if (channelStr.charAt(0) == '[') {
/* 188 */         channelStr = channelStr.substring(ORIGINAL_CHANNEL_ID_PREFIX_LENGTH);
/*     */ 
/*     */         
/* 191 */         result = (new StringBuilder(1 + channelStr.length())).append('[').append(channelStr);
/*     */       } else {
/*     */         
/* 194 */         int ind = channelStr.indexOf("[id: 0x");
/*     */ 
/*     */ 
/*     */         
/* 198 */         result = (new StringBuilder(1 + channelStr.length() - ORIGINAL_CHANNEL_ID_PREFIX_LENGTH)).append(channelStr.substring(0, ind)).append('[').append(channelStr.substring(ind + ORIGINAL_CHANNEL_ID_PREFIX_LENGTH));
/*     */       } 
/*     */     } 
/* 201 */     return result.toString();
/*     */   }
/*     */   
/*     */   private String formatByteBuf(ChannelHandlerContext ctx, String eventName, ByteBuf msg) {
/* 205 */     String chStr = channelString(ctx.channel());
/* 206 */     int length = msg.readableBytes();
/* 207 */     if (length == 0) {
/* 208 */       return (new StringBuilder(chStr.length() + 1 + eventName.length() + 4))
/* 209 */         .append(chStr)
/* 210 */         .append(' ')
/* 211 */         .append(eventName)
/* 212 */         .append(": 0B")
/* 213 */         .toString();
/*     */     }
/*     */     
/* 216 */     int outputLength = chStr.length() + 1 + eventName.length() + 2 + 10 + 1;
/* 217 */     String message = "";
/* 218 */     if (this.byteBufFormat == AdvancedByteBufFormat.HEX_DUMP) {
/* 219 */       int rows = length / 16 + ((length % 15 == 0) ? 0 : 1) + 4;
/* 220 */       int hexDumpLength = 2 + rows * 80;
/* 221 */       outputLength += hexDumpLength;
/*     */     }
/* 223 */     else if (this.byteBufFormat == AdvancedByteBufFormat.TEXTUAL) {
/* 224 */       message = msg.toString(this.charset);
/* 225 */       outputLength += message.length() + 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     StringBuilder buf = (new StringBuilder(outputLength)).append(chStr).append(' ').append(eventName).append(": ").append(length).append('B');
/* 234 */     if (this.byteBufFormat == AdvancedByteBufFormat.HEX_DUMP) {
/* 235 */       buf.append(StringUtil.NEWLINE);
/* 236 */       ByteBufUtil.appendPrettyHexDump(buf, msg);
/*     */     }
/* 238 */     else if (this.byteBufFormat == AdvancedByteBufFormat.TEXTUAL) {
/* 239 */       buf.append(' ').append(message);
/*     */     } 
/*     */     
/* 242 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private String formatByteBufHolder(ChannelHandlerContext ctx, String eventName, ByteBufHolder msg) {
/*     */     StringBuilder buf;
/* 247 */     String chStr = channelString(ctx.channel());
/* 248 */     String msgStr = msg.toString();
/* 249 */     ByteBuf content = msg.content();
/* 250 */     int length = content.readableBytes();
/* 251 */     if (length == 0) {
/* 252 */       return (new StringBuilder(chStr.length() + 1 + eventName.length() + 2 + msgStr.length() + 4))
/* 253 */         .append(chStr)
/* 254 */         .append(' ')
/* 255 */         .append(eventName)
/* 256 */         .append(", ")
/* 257 */         .append(msgStr)
/* 258 */         .append(", 0B")
/* 259 */         .toString();
/*     */     }
/*     */ 
/*     */     
/* 263 */     if (this.byteBufFormat != AdvancedByteBufFormat.TEXTUAL) {
/* 264 */       int outputLength = chStr.length() + 1 + eventName.length() + 2 + msgStr.length() + 2 + 10 + 1;
/* 265 */       if (this.byteBufFormat == AdvancedByteBufFormat.HEX_DUMP) {
/* 266 */         int rows = length / 16 + ((length % 15 == 0) ? 0 : 1) + 4;
/* 267 */         int hexDumpLength = 2 + rows * 80;
/* 268 */         outputLength += hexDumpLength;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 278 */       buf = (new StringBuilder(outputLength)).append(chStr).append(' ').append(eventName).append(": ").append(msgStr).append(", ").append(length).append('B');
/* 279 */       if (this.byteBufFormat == AdvancedByteBufFormat.HEX_DUMP) {
/* 280 */         buf.append(StringUtil.NEWLINE);
/* 281 */         ByteBufUtil.appendPrettyHexDump(buf, content);
/*     */       } 
/*     */     } else {
/*     */       
/* 285 */       String message = content.toString(this.charset);
/* 286 */       int outputLength = chStr.length() + 1 + eventName.length() + 2 + 10 + 2 + message.length();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 294 */       buf = (new StringBuilder(outputLength)).append(chStr).append(' ').append(eventName).append(": ").append(length).append("B ").append(message);
/*     */     } 
/*     */     
/* 297 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private String formatSimple(ChannelHandlerContext ctx, String eventName, Object msg) {
/* 302 */     String chStr = channelString(ctx.channel());
/* 303 */     String msgStr = String.valueOf(msg);
/* 304 */     return (new StringBuilder(chStr.length() + 1 + eventName.length() + 2 + msgStr.length()))
/* 305 */       .append(chStr)
/* 306 */       .append(' ')
/* 307 */       .append(eventName)
/* 308 */       .append(": ")
/* 309 */       .append(msgStr)
/* 310 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 316 */   static final int ORIGINAL_CHANNEL_ID_PREFIX_LENGTH = "[id: 0x".length();
/*     */   static final char TRACE_ID_PREFIX = '(';
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\logging\ReactorNettyLoggingHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */