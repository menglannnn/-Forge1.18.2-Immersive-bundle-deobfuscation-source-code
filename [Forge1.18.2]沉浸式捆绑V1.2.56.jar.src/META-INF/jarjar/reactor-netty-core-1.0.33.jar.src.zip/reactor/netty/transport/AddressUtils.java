/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.util.NetUtil;
/*     */ import java.net.Inet4Address;
/*     */ import java.net.Inet6Address;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AddressUtils
/*     */ {
/*     */   public static InetSocketAddress createInetSocketAddress(String hostname, int port, boolean resolve) {
/*  55 */     Objects.requireNonNull(hostname, "hostname");
/*  56 */     InetSocketAddress inetAddressForIpString = createForIpString(hostname, port);
/*  57 */     if (inetAddressForIpString != null) {
/*  58 */       return inetAddressForIpString;
/*     */     }
/*     */     
/*  61 */     return resolve ? new InetSocketAddress(hostname, port) : InetSocketAddress.createUnresolved(hostname, port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetSocketAddress createResolved(String hostname, int port) {
/*  74 */     return createInetSocketAddress(hostname, port, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetSocketAddress createUnresolved(String hostname, int port) {
/*  86 */     return createInetSocketAddress(hostname, port, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetSocketAddress parseAddress(String address, int defaultPort) {
/*  97 */     return parseAddress(address, defaultPort, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetSocketAddress parseAddress(String address, int defaultPort, boolean strict) {
/* 112 */     Objects.requireNonNull(address, "address");
/* 113 */     String host = address;
/* 114 */     int port = defaultPort;
/* 115 */     int separatorIdx = address.lastIndexOf(':');
/* 116 */     int ipV6HostSeparatorIdx = address.lastIndexOf(']');
/* 117 */     if (separatorIdx > ipV6HostSeparatorIdx) {
/* 118 */       if (separatorIdx == address.indexOf(':') || ipV6HostSeparatorIdx > -1) {
/* 119 */         host = address.substring(0, separatorIdx);
/* 120 */         String portStr = address.substring(separatorIdx + 1);
/* 121 */         if (!portStr.isEmpty()) {
/* 122 */           if (portStr.chars().allMatch(Character::isDigit)) {
/* 123 */             port = Integer.parseInt(portStr);
/*     */           }
/* 125 */           else if (strict) {
/* 126 */             throw new IllegalArgumentException("Failed to parse a port from " + address);
/*     */           }
/*     */         
/*     */         }
/* 130 */       } else if (strict) {
/* 131 */         throw new IllegalArgumentException("Invalid IPv4 address " + address);
/*     */       } 
/*     */     }
/* 134 */     return createUnresolved(host, port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetSocketAddress replaceUnresolvedNumericIp(InetSocketAddress inetSocketAddress) {
/* 145 */     Objects.requireNonNull(inetSocketAddress, "inetSocketAddress");
/* 146 */     if (!inetSocketAddress.isUnresolved()) {
/* 147 */       return inetSocketAddress;
/*     */     }
/* 149 */     InetSocketAddress inetAddressForIpString = createForIpString(inetSocketAddress
/* 150 */         .getHostString(), inetSocketAddress.getPort());
/* 151 */     if (inetAddressForIpString != null) {
/* 152 */       return inetAddressForIpString;
/*     */     }
/*     */     
/* 155 */     return inetSocketAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InetSocketAddress replaceWithResolved(InetSocketAddress inetSocketAddress) {
/* 167 */     Objects.requireNonNull(inetSocketAddress, "inetSocketAddress");
/* 168 */     if (!inetSocketAddress.isUnresolved()) {
/* 169 */       return inetSocketAddress;
/*     */     }
/* 171 */     inetSocketAddress = replaceUnresolvedNumericIp(inetSocketAddress);
/* 172 */     if (!inetSocketAddress.isUnresolved()) {
/* 173 */       return inetSocketAddress;
/*     */     }
/*     */     
/* 176 */     return new InetSocketAddress(inetSocketAddress.getHostString(), inetSocketAddress.getPort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SocketAddress updateHost(@Nullable Supplier<? extends SocketAddress> address, String host) {
/* 188 */     if (address == null) {
/* 189 */       return createUnresolved(host, 0);
/*     */     }
/*     */     
/* 192 */     SocketAddress socketAddress = address.get();
/* 193 */     if (socketAddress instanceof io.netty.channel.unix.DomainSocketAddress) {
/* 194 */       throw new IllegalArgumentException("Cannot update DomainSocketAddress with host name [" + host + "].");
/*     */     }
/*     */     
/* 197 */     if (!(socketAddress instanceof InetSocketAddress)) {
/* 198 */       return createUnresolved(host, 0);
/*     */     }
/*     */     
/* 201 */     InetSocketAddress inet = (InetSocketAddress)socketAddress;
/*     */     
/* 203 */     return createUnresolved(host, inet.getPort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SocketAddress updatePort(@Nullable Supplier<? extends SocketAddress> address, int port) {
/* 214 */     if (address == null) {
/* 215 */       return createUnresolved(NetUtil.LOCALHOST.getHostAddress(), port);
/*     */     }
/*     */     
/* 218 */     SocketAddress socketAddress = address.get();
/* 219 */     if (socketAddress instanceof io.netty.channel.unix.DomainSocketAddress) {
/* 220 */       throw new IllegalArgumentException("Cannot update DomainSocketAddress with post number [" + port + "].");
/*     */     }
/*     */     
/* 223 */     if (!(address.get() instanceof InetSocketAddress)) {
/* 224 */       return createUnresolved(NetUtil.LOCALHOST.getHostAddress(), port);
/*     */     }
/*     */     
/* 227 */     InetSocketAddress inet = (InetSocketAddress)address.get();
/*     */     
/* 229 */     InetAddress addr = inet.getAddress();
/*     */     
/* 231 */     String host = (addr == null) ? inet.getHostName() : addr.getHostAddress();
/*     */     
/* 233 */     return createUnresolved(host, port);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static InetAddress attemptParsingIpString(String hostname) {
/* 238 */     byte[] ipAddressBytes = NetUtil.createByteArrayFromIpAddressString(hostname);
/*     */     
/* 240 */     if (ipAddressBytes != null) {
/*     */       try {
/* 242 */         if (ipAddressBytes.length == 4) {
/* 243 */           return Inet4Address.getByAddress(ipAddressBytes);
/*     */         }
/*     */         
/* 246 */         return Inet6Address.getByAddress((String)null, ipAddressBytes, -1);
/*     */       
/*     */       }
/* 249 */       catch (UnknownHostException e) {
/* 250 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */     
/* 254 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static InetSocketAddress createForIpString(String hostname, int port) {
/* 259 */     InetAddress inetAddressForIpString = attemptParsingIpString(hostname);
/* 260 */     if (inetAddressForIpString != null) {
/* 261 */       return new InetSocketAddress(inetAddressForIpString, port);
/*     */     }
/* 263 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\AddressUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */