/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelOutboundHandlerAdapter;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.DefaultHttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.handler.logging.LoggingHandler;
/*     */ import io.netty.handler.proxy.HttpProxyHandler;
/*     */ import io.netty.handler.proxy.ProxyHandler;
/*     */ import io.netty.handler.proxy.Socks4ProxyHandler;
/*     */ import io.netty.handler.proxy.Socks5ProxyHandler;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.regex.Pattern;
/*     */ import reactor.netty.transport.logging.AdvancedByteBufFormat;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProxyProvider
/*     */ {
/*     */   final String username;
/*     */   final Function<? super String, ? extends String> password;
/*     */   final Supplier<? extends InetSocketAddress> address;
/*     */   final Predicate<SocketAddress> nonProxyHostPredicate;
/*     */   final Supplier<? extends HttpHeaders> httpHeaders;
/*     */   final Proxy type;
/*     */   final long connectTimeoutMillis;
/*     */   
/*     */   public static TypeSpec builder() {
/*  60 */     return new Build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ProxyProvider(Build builder) {
/*  72 */     this.username = builder.username;
/*  73 */     this.password = builder.password;
/*  74 */     this.nonProxyHostPredicate = builder.nonProxyHostPredicate;
/*  75 */     if (Objects.isNull(builder.address)) {
/*  76 */       if (builder.host != null) {
/*  77 */         this.address = (() -> AddressUtils.createResolved(builder.host, builder.port));
/*     */       } else {
/*     */         
/*  80 */         throw new IllegalArgumentException("Neither address nor host is specified");
/*     */       } 
/*     */     } else {
/*     */       
/*  84 */       this.address = builder.address;
/*     */     } 
/*  86 */     this.httpHeaders = builder.httpHeaders;
/*  87 */     this.type = builder.type;
/*  88 */     this.connectTimeoutMillis = builder.connectTimeoutMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Proxy getType() {
/*  97 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Supplier<? extends InetSocketAddress> getAddress() {
/* 106 */     return this.address;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Predicate<SocketAddress> getNonProxyHostsPredicate() {
/* 118 */     return this.nonProxyHostPredicate;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ProxyHandler newProxyHandler() {
/*     */     HttpProxyHandler httpProxyHandler;
/*     */     Socks4ProxyHandler socks4ProxyHandler;
/*     */     Socks5ProxyHandler socks5ProxyHandler;
/* 127 */     InetSocketAddress proxyAddr = this.address.get();
/*     */     
/* 129 */     boolean b = (Objects.nonNull(this.username) && Objects.nonNull(this.password));
/*     */     
/* 131 */     String username = this.username;
/* 132 */     String password = b ? this.password.apply(username) : null;
/*     */ 
/*     */     
/* 135 */     switch (this.type) {
/*     */ 
/*     */       
/*     */       case HTTP:
/* 139 */         httpProxyHandler = b ? new HttpProxyHandler(proxyAddr, username, password, this.httpHeaders.get()) : new HttpProxyHandler(proxyAddr, this.httpHeaders.get());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 153 */         httpProxyHandler.setConnectTimeoutMillis(this.connectTimeoutMillis);
/* 154 */         return (ProxyHandler)httpProxyHandler;case SOCKS4: socks4ProxyHandler = Objects.nonNull(username) ? new Socks4ProxyHandler(proxyAddr, username) : new Socks4ProxyHandler(proxyAddr); socks4ProxyHandler.setConnectTimeoutMillis(this.connectTimeoutMillis); return (ProxyHandler)socks4ProxyHandler;case SOCKS5: socks5ProxyHandler = b ? new Socks5ProxyHandler(proxyAddr, username, password) : new Socks5ProxyHandler(proxyAddr); socks5ProxyHandler.setConnectTimeoutMillis(this.connectTimeoutMillis); return (ProxyHandler)socks5ProxyHandler;
/*     */     } 
/*     */     throw new IllegalArgumentException("Proxy type unsupported : " + this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldProxy(SocketAddress address) {
/* 165 */     return (address instanceof InetSocketAddress && !this.nonProxyHostPredicate.test(address));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Proxy
/*     */   {
/* 172 */     HTTP, SOCKS4, SOCKS5;
/*     */   }
/*     */   
/*     */   public void addProxyHandler(Channel channel) {
/* 176 */     Objects.requireNonNull(channel, "channel");
/* 177 */     ChannelPipeline pipeline = channel.pipeline();
/* 178 */     pipeline.addFirst("reactor.left.proxyHandler", (ChannelHandler)newProxyHandler());
/*     */ 
/*     */ 
/*     */     
/* 182 */     if (this.type == Proxy.SOCKS4 || this.type == Proxy.SOCKS5) {
/* 183 */       pipeline.addAfter("reactor.left.proxyHandler", "reactor.left.unvoidHandler", (ChannelHandler)new ChannelOutboundHandlerAdapter()
/*     */           {
/*     */             public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise)
/*     */             {
/* 187 */               ctx.write(msg, promise.unvoid());
/*     */             }
/*     */           });
/*     */     }
/*     */     
/* 192 */     if (pipeline.get("reactor.left.loggingHandler") != null) {
/* 193 */       pipeline.addBefore("reactor.left.proxyHandler", "reactor.left.proxyLoggingHandler", (ChannelHandler)LOGGING_HANDLER);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 201 */     return "ProxyProvider {address=" + this.address
/* 202 */       .get() + ", nonProxyHosts=" + this.nonProxyHostPredicate + ", type=" + this.type + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 210 */     if (this == o) {
/* 211 */       return true;
/*     */     }
/* 213 */     if (o == null || getClass() != o.getClass()) {
/* 214 */       return false;
/*     */     }
/* 216 */     ProxyProvider that = (ProxyProvider)o;
/* 217 */     return (Objects.equals(this.username, that.username) && 
/* 218 */       Objects.equals(getPasswordValue(), that.getPasswordValue()) && 
/* 219 */       Objects.equals(getAddress().get(), that.getAddress().get()) && 
/* 220 */       getNonProxyHostsValue() == that.getNonProxyHostsValue() && 
/* 221 */       Objects.equals(this.httpHeaders.get(), that.httpHeaders.get()) && 
/* 222 */       getType() == that.getType() && this.connectTimeoutMillis == that.connectTimeoutMillis);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 228 */     int result = 1;
/* 229 */     result = 31 * result + Objects.hashCode(this.username);
/* 230 */     result = 31 * result + Objects.hashCode(getPasswordValue());
/* 231 */     result = 31 * result + Objects.hashCode(getAddress().get());
/* 232 */     result = 31 * result + Boolean.hashCode(getNonProxyHostsValue());
/* 233 */     result = 31 * result + Objects.hashCode(this.httpHeaders.get());
/* 234 */     result = 31 * result + Objects.hashCode(getType());
/* 235 */     result = 31 * result + Long.hashCode(this.connectTimeoutMillis);
/* 236 */     return result;
/*     */   }
/*     */   
/*     */   private boolean getNonProxyHostsValue() {
/* 240 */     return this.nonProxyHostPredicate.test(getAddress().get());
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String getPasswordValue() {
/* 245 */     if (this.username == null || this.password == null) {
/* 246 */       return null;
/*     */     }
/* 248 */     return this.password.apply(this.username);
/*     */   }
/*     */   
/* 251 */   static final LoggingHandler LOGGING_HANDLER = AdvancedByteBufFormat.HEX_DUMP
/*     */     
/* 253 */     .toLoggingHandler("reactor.netty.proxy", LogLevel.DEBUG, Charset.defaultCharset());
/*     */   
/*     */   static final String HTTP_PROXY_HOST = "http.proxyHost";
/*     */   
/*     */   static final String HTTP_PROXY_PORT = "http.proxyPort";
/*     */   static final String HTTP_PROXY_USER = "http.proxyUser";
/*     */   static final String HTTP_PROXY_PASSWORD = "http.proxyPassword";
/*     */   static final String HTTPS_PROXY_HOST = "https.proxyHost";
/*     */   static final String HTTPS_PROXY_PORT = "https.proxyPort";
/*     */   static final String HTTPS_PROXY_USER = "https.proxyUser";
/*     */   static final String HTTPS_PROXY_PASSWORD = "https.proxyPassword";
/*     */   static final String HTTP_NON_PROXY_HOSTS = "http.nonProxyHosts";
/*     */   static final String DEFAULT_NON_PROXY_HOSTS = "localhost|127.*|[::1]";
/*     */   static final String SOCKS_PROXY_HOST = "socksProxyHost";
/*     */   static final String SOCKS_PROXY_PORT = "socksProxyPort";
/*     */   static final String SOCKS_VERSION = "socksProxyVersion";
/*     */   static final String SOCKS_VERSION_5 = "5";
/*     */   static final String SOCKS_VERSION_4 = "4";
/*     */   static final String SOCKS_USERNAME = "java.net.socks.username";
/*     */   static final String SOCKS_PASSWORD = "java.net.socks.password";
/*     */   
/*     */   @Nullable
/*     */   static ProxyProvider createFrom(Properties properties) {
/* 276 */     Objects.requireNonNull(properties, "properties");
/*     */     
/* 278 */     if (properties.containsKey("http.proxyHost") || properties.containsKey("https.proxyHost")) {
/* 279 */       return createHttpProxyFrom(properties);
/*     */     }
/* 281 */     if (properties.containsKey("socksProxyHost")) {
/* 282 */       return createSocksProxyFrom(properties);
/*     */     }
/*     */     
/* 285 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ProxyProvider createHttpProxyFrom(Properties properties) {
/*     */     String hostProperty, portProperty, userProperty, passwordProperty, defaultPort;
/* 297 */     if (properties.containsKey("https.proxyHost")) {
/* 298 */       hostProperty = "https.proxyHost";
/* 299 */       portProperty = "https.proxyPort";
/* 300 */       userProperty = "https.proxyUser";
/* 301 */       passwordProperty = "https.proxyPassword";
/* 302 */       defaultPort = "443";
/*     */     } else {
/*     */       
/* 305 */       hostProperty = "http.proxyHost";
/* 306 */       portProperty = "http.proxyPort";
/* 307 */       userProperty = "http.proxyUser";
/* 308 */       passwordProperty = "http.proxyPassword";
/* 309 */       defaultPort = "80";
/*     */     } 
/*     */     
/* 312 */     String hostname = Objects.<String>requireNonNull(properties.getProperty(hostProperty), hostProperty);
/* 313 */     int port = parsePort(properties.getProperty(portProperty, defaultPort), portProperty);
/*     */     
/* 315 */     String nonProxyHosts = properties.getProperty("http.nonProxyHosts", "localhost|127.*|[::1]");
/* 316 */     RegexShouldProxyPredicate transformedNonProxyHosts = RegexShouldProxyPredicate.fromWildcardedPattern(nonProxyHosts);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 322 */     Builder proxy = builder().type(Proxy.HTTP).host(hostname).port(port).nonProxyHostsPredicate(transformedNonProxyHosts);
/*     */     
/* 324 */     if (properties.containsKey(userProperty)) {
/* 325 */       proxy = proxy.username(properties.getProperty(userProperty));
/*     */       
/* 327 */       if (properties.containsKey(passwordProperty)) {
/* 328 */         proxy = proxy.password(u -> properties.getProperty(passwordProperty));
/*     */       } else {
/*     */         
/* 331 */         throw new NullPointerException("Proxy username is set via '" + userProperty + "', but '" + passwordProperty + "' is not set.");
/*     */       } 
/*     */     } 
/*     */     
/* 335 */     return proxy.build();
/*     */   }
/*     */   
/*     */   static ProxyProvider createSocksProxyFrom(Properties properties) {
/* 339 */     String hostname = Objects.<String>requireNonNull(properties.getProperty("socksProxyHost"), "socksProxyHost");
/* 340 */     String version = properties.getProperty("socksProxyVersion", "5");
/* 341 */     if (!"5".equals(version) && !"4".equals(version)) {
/* 342 */       String message = "only socks versions 4 and 5 supported but got " + version;
/* 343 */       throw new IllegalArgumentException(message);
/*     */     } 
/*     */     
/* 346 */     Proxy type = "5".equals(version) ? Proxy.SOCKS5 : Proxy.SOCKS4;
/* 347 */     int port = parsePort(properties.getProperty("socksProxyPort", "1080"), "socksProxyPort");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 352 */     Builder proxy = builder().type(type).host(hostname).port(port);
/*     */     
/* 354 */     if (properties.containsKey("java.net.socks.username")) {
/* 355 */       proxy = proxy.username(properties.getProperty("java.net.socks.username"));
/*     */     }
/* 357 */     if (properties.containsKey("java.net.socks.password")) {
/* 358 */       proxy = proxy.password(u -> properties.getProperty("java.net.socks.password"));
/*     */     }
/*     */     
/* 361 */     return proxy.build();
/*     */   }
/*     */   
/*     */   static int parsePort(String port, String propertyName) {
/* 365 */     Objects.requireNonNull(port, "port");
/* 366 */     Objects.requireNonNull(propertyName, "propertyName");
/*     */     
/* 368 */     if (port.isEmpty()) {
/* 369 */       String message = "expected system property " + propertyName + " to be a number but got empty string";
/* 370 */       throw new IllegalArgumentException(message);
/*     */     } 
/* 372 */     if (!port.chars().allMatch(Character::isDigit)) {
/* 373 */       String message = "expected system property " + propertyName + " to be a number but got " + port;
/* 374 */       throw new IllegalArgumentException(message);
/*     */     } 
/*     */     
/* 377 */     return Integer.parseInt(port);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class Build
/*     */     implements TypeSpec, AddressSpec, Builder
/*     */   {
/*     */     static final Supplier<? extends HttpHeaders> NO_HTTP_HEADERS = () -> null;
/*     */     
/*     */     static final Predicate<SocketAddress> ALWAYS_PROXY = a -> false;
/*     */     
/*     */     String username;
/*     */     Function<? super String, ? extends String> password;
/*     */     String host;
/*     */     int port;
/*     */     Supplier<? extends InetSocketAddress> address;
/* 393 */     Predicate<SocketAddress> nonProxyHostPredicate = ALWAYS_PROXY;
/* 394 */     Supplier<? extends HttpHeaders> httpHeaders = NO_HTTP_HEADERS;
/*     */     ProxyProvider.Proxy type;
/* 396 */     long connectTimeoutMillis = 10000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final ProxyProvider.Builder username(String username) {
/* 403 */       this.username = username;
/* 404 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final ProxyProvider.Builder password(Function<? super String, ? extends String> password) {
/* 409 */       this.password = password;
/* 410 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final ProxyProvider.Builder host(String host) {
/* 415 */       this.host = Objects.<String>requireNonNull(host, "host");
/* 416 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final ProxyProvider.Builder port(int port) {
/* 421 */       this.port = port;
/* 422 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final ProxyProvider.Builder address(InetSocketAddress address) {
/* 427 */       Objects.requireNonNull(address, "address");
/* 428 */       this.address = (() -> AddressUtils.replaceWithResolved(address));
/* 429 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final ProxyProvider.Builder address(Supplier<? extends InetSocketAddress> addressSupplier) {
/* 434 */       this.address = Objects.<Supplier<? extends InetSocketAddress>>requireNonNull(addressSupplier, "addressSupplier");
/* 435 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final ProxyProvider.Builder nonProxyHosts(String nonProxyHostsPattern) {
/* 440 */       return StringUtil.isNullOrEmpty(nonProxyHostsPattern) ? 
/* 441 */         nonProxyHostsPredicate(ALWAYS_PROXY) : 
/* 442 */         nonProxyHostsPredicate(new ProxyProvider.RegexShouldProxyPredicate(nonProxyHostsPattern));
/*     */     }
/*     */ 
/*     */     
/*     */     public final ProxyProvider.Builder nonProxyHostsPredicate(Predicate<SocketAddress> nonProxyHostsPredicate) {
/* 447 */       this.nonProxyHostPredicate = Objects.<Predicate<SocketAddress>>requireNonNull(nonProxyHostsPredicate, "nonProxyHostsPredicate");
/* 448 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ProxyProvider.Builder httpHeaders(final Consumer<HttpHeaders> headers) {
/* 453 */       if (headers != null) {
/* 454 */         this.httpHeaders = (() -> new DefaultHttpHeaders()
/*     */           {
/*     */           
/*     */           });
/*     */       }
/*     */       
/* 460 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final ProxyProvider.AddressSpec type(ProxyProvider.Proxy type) {
/* 465 */       this.type = Objects.<ProxyProvider.Proxy>requireNonNull(type, "type");
/* 466 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ProxyProvider.Builder connectTimeoutMillis(long connectTimeoutMillis) {
/* 471 */       this.connectTimeoutMillis = connectTimeoutMillis;
/* 472 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ProxyProvider build() {
/* 477 */       return new ProxyProvider(this);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class RegexShouldProxyPredicate
/*     */     implements Predicate<SocketAddress> {
/* 483 */     public static final RegexShouldProxyPredicate DEFAULT_NON_PROXY = fromWildcardedPattern("localhost|127.*|[::1]|0.0.0.0|[::0]");
/*     */ 
/*     */ 
/*     */     
/*     */     private final String regex;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Pattern pattern;
/*     */ 
/*     */ 
/*     */     
/*     */     public static RegexShouldProxyPredicate fromWildcardedPattern(String pattern) {
/*     */       String transformed;
/* 497 */       if (StringUtil.isNullOrEmpty(pattern)) {
/* 498 */         transformed = "$^";
/*     */       } else {
/*     */         
/* 501 */         String[] parts = pattern.split("\\|");
/* 502 */         for (int i = 0; i < parts.length; i++) {
/* 503 */           parts[i] = transformWildcardComponent(parts[i]);
/*     */         }
/* 505 */         transformed = String.join("|", (CharSequence[])parts);
/*     */       } 
/* 507 */       return new RegexShouldProxyPredicate(transformed);
/*     */     }
/*     */     
/*     */     private static String transformWildcardComponent(String in) {
/* 511 */       String[] parts = { "", "", "" };
/* 512 */       if (in.startsWith("*")) {
/* 513 */         parts[0] = ".*";
/* 514 */         in = in.substring(1);
/*     */       } 
/* 516 */       if (in.endsWith("*")) {
/* 517 */         parts[2] = ".*";
/* 518 */         in = in.substring(0, in.length() - 1);
/*     */       } 
/* 520 */       parts[1] = Pattern.quote(in);
/* 521 */       return String.join("", (CharSequence[])parts);
/*     */     }
/*     */     
/*     */     private RegexShouldProxyPredicate(String pattern) {
/* 525 */       this.regex = pattern;
/* 526 */       this.pattern = Pattern.compile(this.regex, 2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean test(SocketAddress socketAddress) {
/* 538 */       if (!(socketAddress instanceof InetSocketAddress)) {
/* 539 */         return false;
/*     */       }
/* 541 */       InetSocketAddress isa = (InetSocketAddress)socketAddress;
/* 542 */       String hostString = isa.getHostString();
/* 543 */       return (hostString != null && this.pattern.matcher(hostString).matches());
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 548 */       return this.regex;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Builder {
/*     */     Builder username(String param1String);
/*     */     
/*     */     Builder password(Function<? super String, ? extends String> param1Function);
/*     */     
/*     */     Builder port(int param1Int);
/*     */     
/*     */     Builder nonProxyHosts(String param1String);
/*     */     
/*     */     Builder nonProxyHostsPredicate(Predicate<SocketAddress> param1Predicate);
/*     */     
/*     */     Builder httpHeaders(Consumer<HttpHeaders> param1Consumer);
/*     */     
/*     */     Builder connectTimeoutMillis(long param1Long);
/*     */     
/*     */     ProxyProvider build();
/*     */   }
/*     */   
/*     */   public static interface AddressSpec {
/*     */     ProxyProvider.Builder host(String param1String);
/*     */     
/*     */     ProxyProvider.Builder address(InetSocketAddress param1InetSocketAddress);
/*     */     
/*     */     ProxyProvider.Builder address(Supplier<? extends InetSocketAddress> param1Supplier);
/*     */   }
/*     */   
/*     */   public static interface TypeSpec {
/*     */     ProxyProvider.AddressSpec type(ProxyProvider.Proxy param1Proxy);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\ProxyProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */