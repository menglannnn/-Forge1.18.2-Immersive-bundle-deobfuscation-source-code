/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.resolver.AddressResolver;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.netty.channel.ChannelMetricsRecorder;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AddressResolverGroupMetrics<T extends SocketAddress>
/*     */   extends AddressResolverGroup<T>
/*     */ {
/*  44 */   private static final Logger log = Loggers.getLogger(AddressResolverGroupMetrics.class);
/*     */   
/*  46 */   static final ConcurrentMap<Integer, AddressResolverGroupMetrics<?>> cache = new ConcurrentHashMap<>();
/*     */   final AddressResolverGroup<T> resolverGroup;
/*     */   
/*     */   static AddressResolverGroupMetrics<?> getOrCreate(AddressResolverGroup<?> resolverGroup, ChannelMetricsRecorder recorder) {
/*  50 */     return (AddressResolverGroupMetrics)MapUtils.computeIfAbsent(cache, Integer.valueOf(Objects.hash(new Object[] { resolverGroup, recorder }, )), key -> new AddressResolverGroupMetrics<>(resolverGroup, recorder));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final ChannelMetricsRecorder recorder;
/*     */ 
/*     */   
/*     */   private AddressResolverGroupMetrics(AddressResolverGroup<T> resolverGroup, ChannelMetricsRecorder recorder) {
/*  59 */     this.resolverGroup = resolverGroup;
/*  60 */     this.recorder = recorder;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AddressResolver<T> newResolver(EventExecutor executor) {
/*  65 */     final AddressResolver<T> resolver = this.resolverGroup.getResolver(executor);
/*     */     
/*  67 */     return new AddressResolver<T>()
/*     */       {
/*     */         public boolean isSupported(SocketAddress address)
/*     */         {
/*  71 */           return resolver.isSupported(address);
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isResolved(SocketAddress address) {
/*  76 */           return resolver.isResolved(address);
/*     */         }
/*     */ 
/*     */         
/*     */         public Future<T> resolve(SocketAddress address) {
/*  81 */           return resolveInternal(address, () -> resolver.resolve(address));
/*     */         }
/*     */ 
/*     */         
/*     */         public Future<T> resolve(SocketAddress address, Promise<T> promise) {
/*  86 */           return resolveInternal(address, () -> resolver.resolve(address, promise));
/*     */         }
/*     */ 
/*     */         
/*     */         public Future<List<T>> resolveAll(SocketAddress address) {
/*  91 */           return resolveAllInternal(address, () -> resolver.resolveAll(address));
/*     */         }
/*     */ 
/*     */         
/*     */         public Future<List<T>> resolveAll(SocketAddress address, Promise<List<T>> promise) {
/*  96 */           return resolveAllInternal(address, () -> resolver.resolveAll(address, promise));
/*     */         }
/*     */ 
/*     */         
/*     */         public void close() {
/* 101 */           resolver.close();
/*     */         }
/*     */         
/*     */         Future<T> resolveInternal(SocketAddress address, Supplier<Future<T>> resolver) {
/* 105 */           long resolveTimeStart = System.nanoTime();
/* 106 */           return ((Future)resolver.get())
/* 107 */             .addListener(future -> record(resolveTimeStart, future.isSuccess() ? "SUCCESS" : "ERROR", address));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         Future<List<T>> resolveAllInternal(SocketAddress address, Supplier<Future<List<T>>> resolver) {
/* 114 */           long resolveTimeStart = System.nanoTime();
/* 115 */           return ((Future)resolver.get())
/* 116 */             .addListener(future -> record(resolveTimeStart, future.isSuccess() ? "SUCCESS" : "ERROR", address));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         void record(long resolveTimeStart, String status, SocketAddress remoteAddress) {
/*     */           try {
/* 124 */             AddressResolverGroupMetrics.this.recorder.recordResolveAddressTime(remoteAddress, 
/*     */                 
/* 126 */                 Duration.ofNanos(System.nanoTime() - resolveTimeStart), status);
/*     */           
/*     */           }
/* 129 */           catch (RuntimeException e) {
/* 130 */             if (AddressResolverGroupMetrics.log.isWarnEnabled())
/* 131 */               AddressResolverGroupMetrics.log.warn("Exception caught while recording metrics.", e); 
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\AddressResolverGroupMetrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */