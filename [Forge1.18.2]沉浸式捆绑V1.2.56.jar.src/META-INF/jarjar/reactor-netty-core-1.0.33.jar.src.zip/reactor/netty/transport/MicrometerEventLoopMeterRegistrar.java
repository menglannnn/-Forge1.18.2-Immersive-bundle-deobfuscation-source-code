/*    */ package reactor.netty.transport;
/*    */ 
/*    */ import io.micrometer.core.instrument.Gauge;
/*    */ import io.netty.channel.EventLoop;
/*    */ import io.netty.util.concurrent.SingleThreadEventExecutor;
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import reactor.netty.Metrics;
/*    */ import reactor.netty.internal.util.MapUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MicrometerEventLoopMeterRegistrar
/*    */ {
/*    */   static final String PENDING_TASKS_DESCRIPTION = "Event loop pending scheduled tasks.";
/* 42 */   static final MicrometerEventLoopMeterRegistrar INSTANCE = new MicrometerEventLoopMeterRegistrar();
/*    */   
/* 44 */   private final ConcurrentMap<String, EventLoop> cache = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */   
/*    */   void registerMetrics(EventLoop eventLoop) {
/* 49 */     if (eventLoop instanceof SingleThreadEventExecutor) {
/* 50 */       SingleThreadEventExecutor singleThreadEventExecutor = (SingleThreadEventExecutor)eventLoop;
/* 51 */       String executorName = singleThreadEventExecutor.threadProperties().name();
/* 52 */       MapUtils.computeIfAbsent(this.cache, executorName, key -> {
/*    */             Objects.requireNonNull(singleThreadEventExecutor);
/*    */             Gauge.builder("reactor.netty.eventloop.pending.tasks", singleThreadEventExecutor::pendingTasks).description("Event loop pending scheduled tasks.").tag("name", executorName).register(Metrics.REGISTRY);
/*    */             return eventLoop;
/*    */           });
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\MicrometerEventLoopMeterRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */