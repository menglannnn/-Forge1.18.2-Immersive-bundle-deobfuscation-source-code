/*     */ package reactor.netty.transport;
/*     */ 
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.resolver.NoopAddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClientTransport<T extends ClientTransport<T, CONF>, CONF extends ClientTransportConfig<CONF>>
/*     */   extends Transport<T, CONF>
/*     */ {
/*     */   protected Mono<? extends Connection> connect() {
/*  55 */     ClientTransportConfig clientTransportConfig = (ClientTransportConfig)configuration();
/*     */     
/*  57 */     ConnectionObserver observer = clientTransportConfig.defaultConnectionObserver().then(clientTransportConfig.observer);
/*     */     
/*  59 */     AddressResolverGroup<?> resolver = clientTransportConfig.resolverInternal();
/*     */ 
/*     */     
/*  62 */     Mono<? extends Connection> mono = clientTransportConfig.connectionProvider().acquire(clientTransportConfig, observer, clientTransportConfig.remoteAddress, resolver);
/*  63 */     if (clientTransportConfig.doOnConnect != null) {
/*  64 */       mono = mono.doOnSubscribe(s -> config.doOnConnect.accept(config));
/*     */     }
/*  66 */     return mono;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection connectNow() {
/*  77 */     return connectNow(Duration.ofSeconds(45L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection connectNow(Duration timeout) {
/*  88 */     Objects.requireNonNull(timeout, "timeout");
/*     */     try {
/*  90 */       return Objects.<Connection>requireNonNull((Connection)connect().block(timeout), "aborted");
/*     */     }
/*  92 */     catch (IllegalStateException e) {
/*  93 */       if (e.getMessage().contains("blocking read")) {
/*  94 */         throw new IllegalStateException(getClass().getSimpleName() + " couldn't be started within " + timeout.toMillis() + "ms");
/*     */       }
/*  96 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doOnConnect(Consumer<? super CONF> doOnConnect) {
/* 107 */     Objects.requireNonNull(doOnConnect, "doOnConnect");
/* 108 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/*     */     
/* 110 */     Consumer<CONF> current = ((ClientTransportConfig)configuration()).doOnConnect;
/* 111 */     ((ClientTransportConfig)clientTransport.configuration()).doOnConnect = (current == null) ? doOnConnect : current.andThen(doOnConnect);
/* 112 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doOnConnected(Consumer<? super Connection> doOnConnected) {
/* 122 */     Objects.requireNonNull(doOnConnected, "doOnConnected");
/* 123 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/*     */     
/* 125 */     Consumer<? super Connection> consumer = ((ClientTransportConfig)configuration()).doOnConnected;
/* 126 */     ((ClientTransportConfig)clientTransport.configuration()).doOnConnected = (consumer == null) ? doOnConnected : consumer.andThen(doOnConnected);
/* 127 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doOnDisconnected(Consumer<? super Connection> doOnDisconnected) {
/* 137 */     Objects.requireNonNull(doOnDisconnected, "doOnDisconnected");
/* 138 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/*     */     
/* 140 */     Consumer<? super Connection> consumer = ((ClientTransportConfig)configuration()).doOnDisconnected;
/* 141 */     ((ClientTransportConfig)clientTransport.configuration()).doOnDisconnected = (consumer == null) ? doOnDisconnected : consumer.andThen(doOnDisconnected);
/* 142 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T doOnResolve(Consumer<? super Connection> doOnResolve) {
/* 153 */     Objects.requireNonNull(doOnResolve, "doOnResolve");
/* 154 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/*     */     
/* 156 */     Consumer<? super Connection> consumer = ((ClientTransportConfig)configuration()).doOnResolve;
/* 157 */     ((ClientTransportConfig)clientTransport.configuration()).doOnResolve = (consumer == null) ? doOnResolve : consumer.andThen(doOnResolve);
/* 158 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T doAfterResolve(BiConsumer<? super Connection, ? super SocketAddress> doAfterResolve) {
/* 169 */     Objects.requireNonNull(doAfterResolve, "doAfterResolve");
/* 170 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/*     */ 
/*     */     
/* 173 */     BiConsumer<? super Connection, ? super SocketAddress> biConsumer = ((ClientTransportConfig)configuration()).doAfterResolve;
/* 174 */     ((ClientTransportConfig)clientTransport.configuration()).doAfterResolve = (biConsumer == null) ? doAfterResolve : biConsumer.andThen(doAfterResolve);
/* 175 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T doOnResolveError(BiConsumer<? super Connection, ? super Throwable> doOnResolveError) {
/* 186 */     Objects.requireNonNull(doOnResolveError, "doOnResolveError");
/* 187 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/*     */ 
/*     */     
/* 190 */     BiConsumer<? super Connection, ? super Throwable> biConsumer = ((ClientTransportConfig)configuration()).doOnResolveError;
/* 191 */     ((ClientTransportConfig)clientTransport.configuration()).doOnResolveError = (biConsumer == null) ? doOnResolveError : biConsumer.andThen(doOnResolveError);
/* 192 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T host(String host) {
/* 202 */     Objects.requireNonNull(host, "host");
/* 203 */     return remoteAddress(() -> AddressUtils.updateHost(((ClientTransportConfig)configuration()).remoteAddress(), host));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T noProxy() {
/* 212 */     if (((ClientTransportConfig)configuration()).hasProxy()) {
/* 213 */       ClientTransport clientTransport = (ClientTransport)duplicate();
/* 214 */       ((ClientTransportConfig)clientTransport.configuration()).proxyProvider = null;
/* 215 */       if (((ClientTransportConfig)clientTransport.configuration()).resolver == NoopAddressResolverGroup.INSTANCE) {
/* 216 */         ((ClientTransportConfig)clientTransport.configuration()).resolver = null;
/*     */       }
/* 218 */       return (T)clientTransport;
/*     */     } 
/*     */     
/* 221 */     return (T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T port(int port) {
/* 232 */     return remoteAddress(() -> AddressUtils.updatePort(((ClientTransportConfig)configuration()).remoteAddress(), port));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T proxy(Consumer<? super ProxyProvider.TypeSpec> proxyOptions) {
/* 242 */     Objects.requireNonNull(proxyOptions, "proxyOptions");
/* 243 */     ProxyProvider.Build builder = (ProxyProvider.Build)ProxyProvider.builder();
/* 244 */     proxyOptions.accept(builder);
/* 245 */     return proxyWithProxyProvider(builder.build());
/*     */   }
/*     */   
/*     */   final T proxyWithProxyProvider(ProxyProvider proxy) {
/* 249 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/* 250 */     ClientTransportConfig clientTransportConfig = (ClientTransportConfig)clientTransport.configuration();
/* 251 */     clientTransportConfig.proxyProvider = proxy;
/* 252 */     if (clientTransportConfig.resolver == null) {
/* 253 */       clientTransportConfig.resolver = (AddressResolverGroup<?>)NoopAddressResolverGroup.INSTANCE;
/*     */     }
/* 255 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T proxyWithSystemProperties() {
/* 279 */     return proxyWithSystemProperties(System.getProperties());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final T proxyWithSystemProperties(Properties properties) {
/* 288 */     ProxyProvider proxy = ProxyProvider.createFrom(properties);
/* 289 */     return (proxy == null) ? noProxy() : proxyWithProxyProvider(proxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T remoteAddress(Supplier<? extends SocketAddress> remoteAddressSupplier) {
/* 299 */     Objects.requireNonNull(remoteAddressSupplier, "remoteAddressSupplier");
/* 300 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/* 301 */     ((ClientTransportConfig)clientTransport.configuration()).remoteAddress = remoteAddressSupplier;
/* 302 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T resolver(AddressResolverGroup<?> resolver) {
/* 312 */     Objects.requireNonNull(resolver, "resolver");
/* 313 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/* 314 */     ((ClientTransportConfig)clientTransport.configuration()).resolver = resolver;
/* 315 */     ((ClientTransportConfig)clientTransport.configuration()).nameResolverProvider = null;
/* 316 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T resolver(Consumer<NameResolverProvider.NameResolverSpec> nameResolverSpec) {
/* 326 */     Objects.requireNonNull(nameResolverSpec, "nameResolverSpec");
/* 327 */     NameResolverProvider.Build builder = new NameResolverProvider.Build();
/* 328 */     nameResolverSpec.accept(builder);
/* 329 */     NameResolverProvider provider = builder.build();
/* 330 */     if (provider.equals(((ClientTransportConfig)configuration()).nameResolverProvider))
/*     */     {
/* 332 */       return (T)this;
/*     */     }
/*     */     
/* 335 */     ClientTransport clientTransport = (ClientTransport)duplicate();
/* 336 */     ClientTransportConfig clientTransportConfig = (ClientTransportConfig)clientTransport.configuration();
/* 337 */     clientTransportConfig.nameResolverProvider = provider;
/* 338 */     clientTransportConfig.resolver = (AddressResolverGroup<?>)provider.newNameResolverGroup(clientTransportConfig.loopResources(), clientTransportConfig.preferNative);
/* 339 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */   
/*     */   public T runOn(LoopResources loopResources, boolean preferNative) {
/* 344 */     ClientTransport clientTransport = (ClientTransport)super.runOn(loopResources, preferNative);
/* 345 */     ClientTransportConfig clientTransportConfig = (ClientTransportConfig)clientTransport.configuration();
/* 346 */     if (clientTransportConfig.nameResolverProvider != null) {
/* 347 */       clientTransportConfig.resolver = (AddressResolverGroup<?>)ClientTransportConfig.getOrCreateResolver(clientTransportConfig.nameResolverProvider, clientTransportConfig
/* 348 */           .loopResources(), clientTransportConfig.preferNative);
/*     */     }
/* 350 */     else if (clientTransportConfig.resolver == null) {
/* 351 */       clientTransportConfig.nameResolverProvider = ClientTransportConfig.DEFAULT_NAME_RESOLVER_PROVIDER;
/* 352 */       clientTransportConfig.resolver = (AddressResolverGroup<?>)ClientTransportConfig.getOrCreateResolver(ClientTransportConfig.DEFAULT_NAME_RESOLVER_PROVIDER, clientTransportConfig
/* 353 */           .loopResources(), clientTransportConfig.preferNative);
/*     */     } 
/* 355 */     return (T)clientTransport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> warmup() {
/* 372 */     return Mono.fromRunnable(() -> {
/*     */           ((ClientTransportConfig)configuration()).eventLoopGroup();
/*     */           ((ClientTransportConfig)configuration()).resolverInternal();
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\transport\ClientTransport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */