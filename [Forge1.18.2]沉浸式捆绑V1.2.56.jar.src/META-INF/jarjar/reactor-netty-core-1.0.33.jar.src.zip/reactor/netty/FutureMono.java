/*     */ package reactor.netty;
/*     */ 
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.netty.channel.AbortedException;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FutureMono
/*     */   extends Mono<Void>
/*     */ {
/*     */   public static <F extends Future<Void>> Mono<Void> from(F future) {
/*  49 */     Objects.requireNonNull(future, "future");
/*  50 */     if (future.isDone()) {
/*  51 */       if (!future.isSuccess()) {
/*  52 */         return Mono.error(FutureSubscription.wrapError(future.cause()));
/*     */       }
/*  54 */       return Mono.empty();
/*     */     } 
/*  56 */     return new ImmediateFutureMono<>(future);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <F extends Future<Void>> Mono<Void> deferFuture(Supplier<F> deferredFuture) {
/*  70 */     return new DeferredFutureMono<>(deferredFuture);
/*     */   }
/*     */   
/*     */   static final class ImmediateFutureMono<F extends Future<Void>>
/*     */     extends FutureMono {
/*     */     final F future;
/*     */     
/*     */     ImmediateFutureMono(F future) {
/*  78 */       this.future = (F)Objects.<Future>requireNonNull((Future)future, "future");
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super Void> s) {
/*  83 */       doSubscribe(s, this.future);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class DeferredFutureMono<F extends Future<Void>>
/*     */     extends FutureMono {
/*     */     final Supplier<F> deferredFuture;
/*     */     
/*     */     DeferredFutureMono(Supplier<F> deferredFuture) {
/*  92 */       this
/*  93 */         .deferredFuture = Objects.<Supplier<F>>requireNonNull(deferredFuture, "deferredFuture");
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super Void> s) {
/*     */       Future future;
/*     */       try {
/* 100 */         future = (Future)this.deferredFuture.get();
/*     */       }
/* 102 */       catch (Throwable t) {
/* 103 */         Operators.error((Subscriber)s, t);
/*     */         
/*     */         return;
/*     */       } 
/* 107 */       if (future == null) {
/* 108 */         Operators.error((Subscriber)s, 
/* 109 */             Operators.onOperatorError(new NullPointerException("Deferred supplied null"), s
/* 110 */               .currentContext()));
/*     */         
/*     */         return;
/*     */       } 
/* 114 */       doSubscribe(s, future);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static <F extends Future<Void>> void doSubscribe(CoreSubscriber<? super Void> s, F future) {
/* 120 */     if (future.isDone()) {
/* 121 */       if (future.isSuccess()) {
/* 122 */         Operators.complete((Subscriber)s);
/*     */       } else {
/*     */         
/* 125 */         Operators.error((Subscriber)s, FutureSubscription.wrapError(future.cause()));
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 130 */     FutureSubscription<F> fs = new FutureSubscription<>(future, s);
/*     */ 
/*     */     
/* 133 */     s.onSubscribe(fs);
/*     */ 
/*     */     
/* 136 */     if (fs.cancelled) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     future.addListener(fs);
/*     */ 
/*     */ 
/*     */     
/* 148 */     if (fs.cancelled)
/*     */     {
/* 150 */       future.removeListener(fs);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FutureSubscription<F extends Future<Void>>
/*     */     implements GenericFutureListener<F>, Subscription, Supplier<Context>
/*     */   {
/*     */     final CoreSubscriber<? super Void> s;
/*     */     
/*     */     final F future;
/*     */     boolean cancelled;
/*     */     
/*     */     FutureSubscription(F future, CoreSubscriber<? super Void> s) {
/* 164 */       this.s = s;
/* 165 */       this.future = future;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void request(long n) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Context get() {
/* 175 */       return this.s.currentContext();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 185 */       this.cancelled = true;
/*     */       
/* 187 */       this.future.removeListener(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void operationComplete(F future) {
/* 192 */       if (!future.isSuccess()) {
/* 193 */         this.s.onError(wrapError(future.cause()));
/*     */       } else {
/*     */         
/* 196 */         this.s.onComplete();
/*     */       } 
/*     */     }
/*     */     
/*     */     private static Throwable wrapError(Throwable error) {
/* 201 */       if (error instanceof java.nio.channels.ClosedChannelException) {
/* 202 */         return (Throwable)new AbortedException(error);
/*     */       }
/*     */       
/* 205 */       return error;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\FutureMono.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */