/*     */ package reactor.netty;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.ByteBufHolder;
/*     */ import io.netty.buffer.CompositeByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Path;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Fuseable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.FluxOperator;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteBufFlux
/*     */   extends FluxOperator<ByteBuf, ByteBuf>
/*     */ {
/*     */   final ByteBufAllocator alloc;
/*     */   static final Function<Object, ByteBuf> bytebufExtractor;
/*     */   static final int MAX_CHUNK_SIZE = 524288;
/*     */   
/*     */   public static ByteBufFlux fromInbound(Publisher<?> source) {
/*  58 */     return fromInbound(source, ByteBufAllocator.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufFlux fromInbound(Publisher<?> source, ByteBufAllocator allocator) {
/*  70 */     Objects.requireNonNull(allocator, "allocator");
/*  71 */     return maybeFuse(Flux.from((Publisher)ReactorNetty.publisherOrScalarMap(source, bytebufExtractor)), allocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufFlux fromString(Publisher<? extends String> source) {
/*  82 */     return fromString(source, Charset.defaultCharset(), ByteBufAllocator.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufFlux fromString(Publisher<? extends String> source, Charset charset, ByteBufAllocator allocator) {
/*  94 */     Objects.requireNonNull(allocator, "allocator");
/*  95 */     Objects.requireNonNull(charset, "charset");
/*  96 */     return maybeFuse(
/*  97 */         Flux.from((Publisher)ReactorNetty.publisherOrScalarMap(source, s -> { ByteBuf buffer = allocator.buffer(); buffer.writeCharSequence(s, charset); return buffer; })), allocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufFlux fromPath(Path path) {
/* 115 */     return fromPath(path, 524288);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufFlux fromPath(Path path, int maxChunkSize) {
/* 128 */     return fromPath(path, maxChunkSize, ByteBufAllocator.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufFlux fromPath(Path path, ByteBufAllocator allocator) {
/* 142 */     return fromPath(path, 524288, allocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBufFlux fromPath(Path path, int maxChunkSize, ByteBufAllocator allocator) {
/* 159 */     Objects.requireNonNull(path, "path");
/* 160 */     Objects.requireNonNull(allocator, "allocator");
/* 161 */     if (maxChunkSize < 1) {
/* 162 */       throw new IllegalArgumentException("chunk size must be strictly positive, was: " + maxChunkSize);
/*     */     }
/* 164 */     return maybeFuse(
/* 165 */         Flux.generate(() -> FileChannel.open(path, new java.nio.file.OpenOption[0]), (fc, sink) -> {
/*     */             ByteBuf buf = allocator.buffer();
/*     */ 
/*     */             
/*     */             try {
/*     */               if (buf.writeBytes(fc, maxChunkSize) < 0) {
/*     */                 buf.release();
/*     */                 
/*     */                 sink.complete();
/*     */               } else {
/*     */                 sink.next(buf);
/*     */               } 
/* 177 */             } catch (IOException e) {
/*     */               buf.release();
/*     */               sink.error(e);
/*     */             } 
/*     */             return fc;
/*     */           }ReactorNetty.fileCloser), allocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<ByteBuffer> asByteBuffer() {
/* 193 */     return handle((bb, sink) -> {
/*     */           
/*     */           try {
/*     */             sink.next(bb.nioBuffer());
/* 197 */           } catch (IllegalReferenceCountException e) {
/*     */             sink.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<byte[]> asByteArray() {
/* 209 */     return handle((bb, sink) -> {
/*     */           try {
/*     */             byte[] bytes = new byte[bb.readableBytes()];
/*     */             
/*     */             bb.readBytes(bytes);
/*     */             sink.next(bytes);
/* 215 */           } catch (IllegalReferenceCountException e) {
/*     */             sink.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<InputStream> asInputStream() {
/* 231 */     return handle((bb, sink) -> {
/*     */           
/*     */           try {
/*     */             sink.next(new ByteBufMono.ReleasingInputStream(bb));
/* 235 */           } catch (IllegalReferenceCountException e) {
/*     */             sink.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<String> asString() {
/* 247 */     return asString(Charset.defaultCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Flux<String> asString(Charset charset) {
/* 258 */     Objects.requireNonNull(charset, "charset");
/* 259 */     return handle((bb, sink) -> {
/*     */           
/*     */           try {
/*     */             sink.next(bb.readCharSequence(bb.readableBytes(), charset).toString());
/* 263 */           } catch (IllegalReferenceCountException e) {
/*     */             sink.complete();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBufMono aggregate() {
/* 275 */     return (ByteBufMono)Mono.defer(() -> {
/*     */           CompositeByteBuf output = this.alloc.compositeBuffer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return doOnNext(ByteBuf::retain).collectList().doOnDiscard(ByteBuf.class, ByteBufFlux::safeRelease).handle(()).doFinally(());
/* 300 */         }).as(ByteBufMono::maybeFuse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBufMono multicast() {
/* 311 */     throw new UnsupportedOperationException("Not yet implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBufFlux retain() {
/* 321 */     return maybeFuse(doOnNext(ByteBuf::retain), this.alloc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ByteBufFlux(Flux<ByteBuf> source, ByteBufAllocator allocator) {
/* 327 */     super(source);
/* 328 */     this.alloc = allocator;
/*     */   }
/*     */   
/*     */   static final class ByteBufFluxFuseable
/*     */     extends ByteBufFlux implements Fuseable {
/*     */     ByteBufFluxFuseable(Flux<ByteBuf> source, ByteBufAllocator allocator) {
/* 334 */       super(source, allocator);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super ByteBuf> s) {
/* 340 */     this.source.subscribe(s);
/*     */   }
/*     */   
/*     */   static ByteBufFlux maybeFuse(Flux<ByteBuf> source, ByteBufAllocator allocator) {
/* 344 */     if (source instanceof Fuseable) {
/* 345 */       return new ByteBufFluxFuseable(source, allocator);
/*     */     }
/* 347 */     return new ByteBufFlux(source, allocator);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 353 */     bytebufExtractor = (o -> {
/*     */         if (o instanceof ByteBuf) {
/*     */           return (ByteBuf)o;
/*     */         }
/*     */         if (o instanceof ByteBufHolder) {
/*     */           return ((ByteBufHolder)o).content();
/*     */         }
/*     */         if (o instanceof byte[]) {
/*     */           return Unpooled.wrappedBuffer((byte[])o);
/*     */         }
/*     */         throw new IllegalArgumentException("Object " + o + " of type " + o.getClass() + " cannot be converted to ByteBuf");
/*     */       });
/*     */   }
/*     */ 
/*     */   
/* 368 */   static final Logger log = Loggers.getLogger(ByteBufFlux.class);
/*     */   
/*     */   static void safeRelease(ByteBuf byteBuf) {
/* 371 */     if (byteBuf.refCnt() > 0)
/*     */       try {
/* 373 */         byteBuf.release();
/*     */       }
/* 375 */       catch (IllegalReferenceCountException e) {
/* 376 */         if (log.isDebugEnabled())
/* 377 */           log.debug("", (Throwable)e); 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\ByteBufFlux.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */