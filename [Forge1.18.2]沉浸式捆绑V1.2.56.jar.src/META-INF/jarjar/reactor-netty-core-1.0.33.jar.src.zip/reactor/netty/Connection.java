/*     */ package reactor.netty;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import java.util.Objects;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface Connection
/*     */   extends DisposableChannel
/*     */ {
/*     */   static Connection from(Channel channel) {
/*  44 */     Objects.requireNonNull(channel, "channel");
/*  45 */     if (channel.hasAttr(ReactorNetty.CONNECTION)) {
/*  46 */       return (Connection)channel.attr(ReactorNetty.CONNECTION)
/*  47 */         .get();
/*     */     }
/*  49 */     return (new ReactorNetty.SimpleConnection(channel)).bind();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default <T extends Connection> T as(Class<T> clazz) {
/*  62 */     Objects.requireNonNull(clazz, "clazz");
/*  63 */     if (clazz.isAssignableFrom(getClass()))
/*     */     {
/*  65 */       return (T)this;
/*     */     }
/*     */     
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Connection addHandler(ChannelHandler handler) {
/*  92 */     return addHandler(handler.getClass().getSimpleName(), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   default Connection addHandler(String name, ChannelHandler handler) {
/* 117 */     if (handler instanceof io.netty.channel.ChannelOutboundHandler) {
/* 118 */       addHandlerFirst(name, handler);
/*     */     } else {
/*     */       
/* 121 */       addHandlerLast(name, handler);
/*     */     } 
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection addHandlerLast(ChannelHandler handler) {
/* 144 */     return addHandlerLast(handler.getClass().getSimpleName(), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection addHandlerLast(String name, ChannelHandler handler) {
/* 165 */     ReactorNetty.addHandlerBeforeReactorEndHandlers(this, name, handler);
/* 166 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection addHandlerFirst(ChannelHandler handler) {
/* 186 */     return addHandlerFirst(handler.getClass().getSimpleName(), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection addHandlerFirst(String name, ChannelHandler handler) {
/* 207 */     ReactorNetty.addHandlerAfterReactorCodecs(this, name, handler);
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection bind() {
/* 219 */     channel().attr(ReactorNetty.CONNECTION)
/* 220 */       .set(this);
/* 221 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyInbound inbound() {
/* 232 */     return ReactorNetty.unavailableInbound(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isPersistent() {
/* 247 */     return (!channel().hasAttr(ReactorNetty.PERSISTENT_CHANNEL) || ((Boolean)
/* 248 */       channel().attr(ReactorNetty.PERSISTENT_CHANNEL).get()).booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection markPersistent(boolean persist) {
/* 265 */     if (persist && !channel().hasAttr(ReactorNetty.PERSISTENT_CHANNEL)) {
/* 266 */       return this;
/*     */     }
/*     */     
/* 269 */     channel().attr(ReactorNetty.PERSISTENT_CHANNEL)
/* 270 */       .set(Boolean.valueOf(persist));
/*     */     
/* 272 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   default Connection onDispose(Disposable onDispose) {
/* 277 */     super.onDispose(onDispose);
/* 278 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection onReadIdle(long idleTimeout, Runnable onReadIdle) {
/* 291 */     return removeHandler("reactor.left.onChannelReadIdle")
/* 292 */       .addHandlerFirst("reactor.left.onChannelReadIdle", (ChannelHandler)new ReactorNetty.InboundIdleStateHandler(idleTimeout, onReadIdle));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> onTerminate() {
/* 304 */     return onDispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection onWriteIdle(long idleTimeout, Runnable onWriteIdle) {
/* 317 */     return removeHandler("reactor.left.onChannelWriteIdle")
/* 318 */       .addHandlerFirst("reactor.left.onChannelWriteIdle", (ChannelHandler)new ReactorNetty.OutboundIdleStateHandler(idleTimeout, onWriteIdle));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound outbound() {
/* 330 */     return ReactorNetty.unavailableOutbound(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean rebind(@Nullable Connection connection) {
/* 343 */     return channel().attr(ReactorNetty.CONNECTION)
/* 344 */       .compareAndSet(this, connection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection removeHandler(String name) {
/* 355 */     ReactorNetty.removeHandler(channel(), name);
/* 356 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Connection replaceHandler(String name, ChannelHandler handler) {
/* 372 */     ReactorNetty.replaceHandler(channel(), name, handler);
/* 373 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\Connection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */