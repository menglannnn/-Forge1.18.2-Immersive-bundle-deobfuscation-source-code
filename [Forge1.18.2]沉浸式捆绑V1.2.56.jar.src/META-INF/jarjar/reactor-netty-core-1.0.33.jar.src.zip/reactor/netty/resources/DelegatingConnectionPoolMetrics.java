/*    */ package reactor.netty.resources;
/*    */ 
/*    */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DelegatingConnectionPoolMetrics
/*    */   implements ConnectionPoolMetrics
/*    */ {
/*    */   private final InstrumentedPool.PoolMetrics delegate;
/*    */   
/*    */   DelegatingConnectionPoolMetrics(InstrumentedPool.PoolMetrics delegate) {
/* 25 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public int acquiredSize() {
/* 30 */     return this.delegate.acquiredSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public int allocatedSize() {
/* 35 */     return this.delegate.allocatedSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public int idleSize() {
/* 40 */     return this.delegate.idleSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public int pendingAcquireSize() {
/* 45 */     return this.delegate.pendingAcquireSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public int maxAllocatedSize() {
/* 50 */     return this.delegate.getMaxAllocatedSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public int maxPendingAcquireSize() {
/* 55 */     return this.delegate.getMaxPendingAcquireSize();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DelegatingConnectionPoolMetrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */