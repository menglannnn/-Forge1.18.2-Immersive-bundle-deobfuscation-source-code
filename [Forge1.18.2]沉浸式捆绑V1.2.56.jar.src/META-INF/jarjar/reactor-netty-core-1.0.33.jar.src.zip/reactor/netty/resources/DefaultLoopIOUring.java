/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.ServerSocketChannel;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.incubator.channel.uring.IOUring;
/*     */ import io.netty.incubator.channel.uring.IOUringDatagramChannel;
/*     */ import io.netty.incubator.channel.uring.IOUringEventLoopGroup;
/*     */ import io.netty.incubator.channel.uring.IOUringServerSocketChannel;
/*     */ import io.netty.incubator.channel.uring.IOUringSocketChannel;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultLoopIOUring
/*     */   implements DefaultLoop
/*     */ {
/*     */   public <CHANNEL extends io.netty.channel.Channel> CHANNEL getChannel(Class<CHANNEL> channelClass) {
/*  43 */     if (channelClass.equals(SocketChannel.class)) {
/*  44 */       return (CHANNEL)new IOUringSocketChannel();
/*     */     }
/*  46 */     if (channelClass.equals(ServerSocketChannel.class)) {
/*  47 */       return (CHANNEL)new IOUringServerSocketChannel();
/*     */     }
/*  49 */     if (channelClass.equals(DatagramChannel.class)) {
/*  50 */       return (CHANNEL)new IOUringDatagramChannel();
/*     */     }
/*  52 */     throw new IllegalArgumentException("Unsupported channel type: " + channelClass.getSimpleName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <CHANNEL extends io.netty.channel.Channel> Class<? extends CHANNEL> getChannelClass(Class<CHANNEL> channelClass) {
/*  58 */     if (channelClass.equals(SocketChannel.class)) {
/*  59 */       return (Class)IOUringSocketChannel.class;
/*     */     }
/*  61 */     if (channelClass.equals(ServerSocketChannel.class)) {
/*  62 */       return (Class)IOUringServerSocketChannel.class;
/*     */     }
/*  64 */     if (channelClass.equals(DatagramChannel.class)) {
/*  65 */       return (Class)IOUringDatagramChannel.class;
/*     */     }
/*  67 */     throw new IllegalArgumentException("Unsupported channel type: " + channelClass.getSimpleName());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  72 */     return "io_uring";
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup newEventLoopGroup(int threads, ThreadFactory factory) {
/*  77 */     return (EventLoopGroup)new IOUringEventLoopGroup(threads, factory);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportGroup(EventLoopGroup group) {
/*  82 */     if (group instanceof ColocatedEventLoopGroup) {
/*  83 */       group = ((ColocatedEventLoopGroup)group).get();
/*     */     }
/*  85 */     return group instanceof IOUringEventLoopGroup;
/*     */   }
/*     */   
/*  88 */   static final Logger log = Loggers.getLogger(DefaultLoopIOUring.class);
/*     */   
/*     */   static final boolean isIoUringAvailable;
/*     */   
/*     */   static {
/*  93 */     boolean ioUringCheck = false;
/*     */     try {
/*  95 */       Class.forName("io.netty.incubator.channel.uring.IOUring");
/*  96 */       ioUringCheck = IOUring.isAvailable();
/*     */     }
/*  98 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 101 */     isIoUringAvailable = ioUringCheck;
/* 102 */     if (log.isDebugEnabled())
/* 103 */       log.debug("Default io_uring support : " + isIoUringAvailable); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DefaultLoopIOUring.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */