/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface LoopResources
/*     */   extends Disposable
/*     */ {
/*  41 */   public static final int DEFAULT_IO_WORKER_COUNT = Integer.parseInt(System.getProperty("reactor.netty.ioWorkerCount", "" + 
/*     */         
/*  43 */         Math.max(Runtime.getRuntime().availableProcessors(), 4)));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final int DEFAULT_IO_SELECT_COUNT = Integer.parseInt(System.getProperty("reactor.netty.ioSelectCount", "-1"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final boolean DEFAULT_NATIVE = Boolean.parseBoolean(System.getProperty("reactor.netty.native", "true"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final long DEFAULT_SHUTDOWN_QUIET_PERIOD = Long.parseLong(System.getProperty("reactor.netty.ioShutdownQuietPeriod", "2"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final long DEFAULT_SHUTDOWN_TIMEOUT = Long.parseLong(System.getProperty("reactor.netty.ioShutdownTimeout", "15"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static EventLoopGroup colocate(EventLoopGroup group) {
/*  86 */     Objects.requireNonNull(group, "group");
/*  87 */     return new ColocatedEventLoopGroup(group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static LoopResources create(String prefix) {
/*  99 */     if (((String)Objects.<String>requireNonNull(prefix, "prefix")).isEmpty()) {
/* 100 */       throw new IllegalArgumentException("Cannot use empty prefix");
/*     */     }
/* 102 */     return new DefaultLoopResources(prefix, DEFAULT_IO_SELECT_COUNT, DEFAULT_IO_WORKER_COUNT, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static LoopResources create(String prefix, int workerCount, boolean daemon) {
/* 116 */     if (((String)Objects.<String>requireNonNull(prefix, "prefix")).isEmpty()) {
/* 117 */       throw new IllegalArgumentException("Cannot use empty prefix");
/*     */     }
/* 119 */     if (workerCount < 1) {
/* 120 */       throw new IllegalArgumentException("Must provide a strictly positive worker threads number, was: " + workerCount);
/*     */     }
/* 122 */     return new DefaultLoopResources(prefix, workerCount, daemon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static LoopResources create(String prefix, int selectCount, int workerCount, boolean daemon) {
/* 137 */     if (((String)Objects.<String>requireNonNull(prefix, "prefix")).isEmpty()) {
/* 138 */       throw new IllegalArgumentException("Cannot use empty prefix");
/*     */     }
/* 140 */     if (workerCount < 1) {
/* 141 */       throw new IllegalArgumentException("Must provide a strictly positive worker threads number, was: " + workerCount);
/*     */     }
/* 143 */     if (selectCount < 1) {
/* 144 */       throw new IllegalArgumentException("Must provide a strictly positive selector threads number, was: " + selectCount);
/*     */     }
/* 146 */     return new DefaultLoopResources(prefix, selectCount, workerCount, daemon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static LoopResources create(String prefix, int selectCount, int workerCount, boolean daemon, boolean colocate) {
/* 166 */     if (((String)Objects.<String>requireNonNull(prefix, "prefix")).isEmpty()) {
/* 167 */       throw new IllegalArgumentException("Cannot use empty prefix");
/*     */     }
/* 169 */     if (workerCount < 1) {
/* 170 */       throw new IllegalArgumentException("Must provide a strictly positive worker threads number, was: " + workerCount);
/*     */     }
/* 172 */     if (selectCount < 1 && selectCount != -1) {
/* 173 */       throw new IllegalArgumentException("Must provide a strictly positive selector threads number or -1, was: " + selectCount);
/*     */     }
/* 175 */     return new DefaultLoopResources(prefix, selectCount, workerCount, daemon, colocate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean daemon() {
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void dispose() {
/* 198 */     disposeLater().subscribe();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> disposeLater() {
/* 208 */     return disposeLater(Duration.ofSeconds(DEFAULT_SHUTDOWN_QUIET_PERIOD), 
/* 209 */         Duration.ofSeconds(DEFAULT_SHUTDOWN_TIMEOUT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> disposeLater(Duration quietPeriod, Duration timeout) {
/* 226 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <CHANNEL extends io.netty.channel.Channel> CHANNEL onChannel(Class<CHANNEL> channelType, EventLoopGroup group) {
/* 241 */     DefaultLoop channelFactory = DefaultLoopNativeDetector.INSTANCE.supportGroup(group) ? DefaultLoopNativeDetector.INSTANCE : DefaultLoopNativeDetector.NIO;
/*     */     
/* 243 */     return channelFactory.getChannel(channelType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <CHANNEL extends io.netty.channel.Channel> Class<? extends CHANNEL> onChannelClass(Class<CHANNEL> channelType, EventLoopGroup group) {
/* 258 */     DefaultLoop channelFactory = DefaultLoopNativeDetector.INSTANCE.supportGroup(group) ? DefaultLoopNativeDetector.INSTANCE : DefaultLoopNativeDetector.NIO;
/*     */     
/* 260 */     return channelFactory.getChannelClass(channelType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default EventLoopGroup onClient(boolean useNative) {
/* 270 */     return onServer(useNative);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EventLoopGroup onServer(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default EventLoopGroup onServerSelect(boolean useNative) {
/* 290 */     return onServer(useNative);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean hasNativeSupport() {
/* 299 */     return (DefaultLoopNativeDetector.INSTANCE != DefaultLoopNativeDetector.NIO);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\LoopResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */