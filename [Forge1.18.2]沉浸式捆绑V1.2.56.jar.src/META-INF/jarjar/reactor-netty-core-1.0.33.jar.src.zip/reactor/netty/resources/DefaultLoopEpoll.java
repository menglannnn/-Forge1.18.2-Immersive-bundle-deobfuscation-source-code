/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.epoll.Epoll;
/*     */ import io.netty.channel.epoll.EpollDatagramChannel;
/*     */ import io.netty.channel.epoll.EpollDomainDatagramChannel;
/*     */ import io.netty.channel.epoll.EpollDomainSocketChannel;
/*     */ import io.netty.channel.epoll.EpollEventLoopGroup;
/*     */ import io.netty.channel.epoll.EpollServerDomainSocketChannel;
/*     */ import io.netty.channel.epoll.EpollServerSocketChannel;
/*     */ import io.netty.channel.epoll.EpollSocketChannel;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.ServerSocketChannel;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.channel.unix.DomainDatagramChannel;
/*     */ import io.netty.channel.unix.DomainSocketChannel;
/*     */ import io.netty.channel.unix.ServerDomainSocketChannel;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultLoopEpoll
/*     */   implements DefaultLoop
/*     */ {
/*     */   public <CHANNEL extends io.netty.channel.Channel> CHANNEL getChannel(Class<CHANNEL> channelClass) {
/*  50 */     if (channelClass.equals(SocketChannel.class)) {
/*  51 */       return (CHANNEL)new EpollSocketChannel();
/*     */     }
/*  53 */     if (channelClass.equals(ServerSocketChannel.class)) {
/*  54 */       return (CHANNEL)new EpollServerSocketChannel();
/*     */     }
/*  56 */     if (channelClass.equals(DatagramChannel.class)) {
/*  57 */       return (CHANNEL)new EpollDatagramChannel();
/*     */     }
/*  59 */     if (channelClass.equals(DomainSocketChannel.class)) {
/*  60 */       return (CHANNEL)new EpollDomainSocketChannel();
/*     */     }
/*  62 */     if (channelClass.equals(ServerDomainSocketChannel.class)) {
/*  63 */       return (CHANNEL)new EpollServerDomainSocketChannel();
/*     */     }
/*  65 */     if (channelClass.equals(DomainDatagramChannel.class)) {
/*  66 */       return (CHANNEL)new EpollDomainDatagramChannel();
/*     */     }
/*  68 */     throw new IllegalArgumentException("Unsupported channel type: " + channelClass.getSimpleName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <CHANNEL extends io.netty.channel.Channel> Class<? extends CHANNEL> getChannelClass(Class<CHANNEL> channelClass) {
/*  74 */     if (channelClass.equals(SocketChannel.class)) {
/*  75 */       return (Class)EpollSocketChannel.class;
/*     */     }
/*  77 */     if (channelClass.equals(ServerSocketChannel.class)) {
/*  78 */       return (Class)EpollServerSocketChannel.class;
/*     */     }
/*  80 */     if (channelClass.equals(DatagramChannel.class)) {
/*  81 */       return (Class)EpollDatagramChannel.class;
/*     */     }
/*  83 */     throw new IllegalArgumentException("Unsupported channel type: " + channelClass.getSimpleName());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  88 */     return "epoll";
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup newEventLoopGroup(int threads, ThreadFactory factory) {
/*  93 */     return (EventLoopGroup)new EpollEventLoopGroup(threads, factory);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportGroup(EventLoopGroup group) {
/*  98 */     if (group instanceof ColocatedEventLoopGroup) {
/*  99 */       group = ((ColocatedEventLoopGroup)group).get();
/*     */     }
/* 101 */     return group instanceof EpollEventLoopGroup;
/*     */   }
/*     */   
/* 104 */   static final Logger log = Loggers.getLogger(DefaultLoopEpoll.class);
/*     */   
/*     */   static final boolean isEpollAvailable;
/*     */   
/*     */   static {
/* 109 */     boolean epollCheck = false;
/*     */     try {
/* 111 */       Class.forName("io.netty.channel.epoll.Epoll");
/* 112 */       epollCheck = Epoll.isAvailable();
/*     */     }
/* 114 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 117 */     isEpollAvailable = epollCheck;
/* 118 */     if (log.isDebugEnabled())
/* 119 */       log.debug("Default Epoll support : " + isEpollAvailable); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DefaultLoopEpoll.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */