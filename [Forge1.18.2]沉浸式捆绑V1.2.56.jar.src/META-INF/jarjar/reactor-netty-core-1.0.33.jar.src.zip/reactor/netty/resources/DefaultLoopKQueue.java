/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.kqueue.KQueue;
/*     */ import io.netty.channel.kqueue.KQueueDatagramChannel;
/*     */ import io.netty.channel.kqueue.KQueueDomainDatagramChannel;
/*     */ import io.netty.channel.kqueue.KQueueDomainSocketChannel;
/*     */ import io.netty.channel.kqueue.KQueueEventLoopGroup;
/*     */ import io.netty.channel.kqueue.KQueueServerDomainSocketChannel;
/*     */ import io.netty.channel.kqueue.KQueueServerSocketChannel;
/*     */ import io.netty.channel.kqueue.KQueueSocketChannel;
/*     */ import io.netty.channel.socket.DatagramChannel;
/*     */ import io.netty.channel.socket.ServerSocketChannel;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.channel.unix.DomainDatagramChannel;
/*     */ import io.netty.channel.unix.DomainSocketChannel;
/*     */ import io.netty.channel.unix.ServerDomainSocketChannel;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultLoopKQueue
/*     */   implements DefaultLoop
/*     */ {
/*     */   public <CHANNEL extends io.netty.channel.Channel> CHANNEL getChannel(Class<CHANNEL> channelClass) {
/*  49 */     if (channelClass.equals(SocketChannel.class)) {
/*  50 */       return (CHANNEL)new KQueueSocketChannel();
/*     */     }
/*  52 */     if (channelClass.equals(ServerSocketChannel.class)) {
/*  53 */       return (CHANNEL)new KQueueServerSocketChannel();
/*     */     }
/*  55 */     if (channelClass.equals(DatagramChannel.class)) {
/*  56 */       return (CHANNEL)new KQueueDatagramChannel();
/*     */     }
/*  58 */     if (channelClass.equals(DomainSocketChannel.class)) {
/*  59 */       return (CHANNEL)new KQueueDomainSocketChannel();
/*     */     }
/*  61 */     if (channelClass.equals(ServerDomainSocketChannel.class)) {
/*  62 */       return (CHANNEL)new KQueueServerDomainSocketChannel();
/*     */     }
/*  64 */     if (channelClass.equals(DomainDatagramChannel.class)) {
/*  65 */       return (CHANNEL)new KQueueDomainDatagramChannel();
/*     */     }
/*  67 */     throw new IllegalArgumentException("Unsupported channel type: " + channelClass.getSimpleName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <CHANNEL extends io.netty.channel.Channel> Class<? extends CHANNEL> getChannelClass(Class<CHANNEL> channelClass) {
/*  73 */     if (channelClass.equals(SocketChannel.class)) {
/*  74 */       return (Class)KQueueSocketChannel.class;
/*     */     }
/*  76 */     if (channelClass.equals(ServerSocketChannel.class)) {
/*  77 */       return (Class)KQueueServerSocketChannel.class;
/*     */     }
/*  79 */     if (channelClass.equals(DatagramChannel.class)) {
/*  80 */       return (Class)KQueueDatagramChannel.class;
/*     */     }
/*  82 */     throw new IllegalArgumentException("Unsupported channel type: " + channelClass.getSimpleName());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  87 */     return "kqueue";
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup newEventLoopGroup(int threads, ThreadFactory factory) {
/*  92 */     return (EventLoopGroup)new KQueueEventLoopGroup(threads, factory);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportGroup(EventLoopGroup group) {
/*  97 */     if (group instanceof ColocatedEventLoopGroup) {
/*  98 */       group = ((ColocatedEventLoopGroup)group).get();
/*     */     }
/* 100 */     return group instanceof KQueueEventLoopGroup;
/*     */   }
/*     */   
/* 103 */   static final Logger log = Loggers.getLogger(DefaultLoopKQueue.class);
/*     */   
/*     */   static final boolean isKqueueAvailable;
/*     */   
/*     */   static {
/* 108 */     boolean kqueueCheck = false;
/*     */     try {
/* 110 */       Class.forName("io.netty.channel.kqueue.KQueue");
/* 111 */       kqueueCheck = KQueue.isAvailable();
/*     */     }
/* 113 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 116 */     isKqueueAvailable = kqueueCheck;
/* 117 */     if (log.isDebugEnabled())
/* 118 */       log.debug("Default KQueue support : " + isKqueueAvailable); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DefaultLoopKQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */