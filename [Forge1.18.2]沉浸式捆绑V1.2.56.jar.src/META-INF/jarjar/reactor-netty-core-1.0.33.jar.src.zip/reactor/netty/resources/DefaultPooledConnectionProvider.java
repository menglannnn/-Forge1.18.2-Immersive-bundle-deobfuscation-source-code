/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.io.IOException;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Clock;
/*     */ import java.time.Duration;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.FutureMono;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.channel.ChannelOperations;
/*     */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PooledRef;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PooledRefMetadata;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.netty.transport.TransportConnector;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultPooledConnectionProvider
/*     */   extends PooledConnectionProvider<DefaultPooledConnectionProvider.PooledConnection>
/*     */ {
/*     */   DefaultPooledConnectionProvider(ConnectionProvider.Builder builder) {
/*  70 */     this(builder, null);
/*     */   }
/*     */ 
/*     */   
/*     */   DefaultPooledConnectionProvider(ConnectionProvider.Builder builder, @Nullable Clock clock) {
/*  75 */     super(builder, clock);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CoreSubscriber<PooledRef<PooledConnection>> createDisposableAcquire(TransportConfig config, ConnectionObserver connectionObserver, long pendingAcquireTimeout, InstrumentedPool<PooledConnection> pool, MonoSink<Connection> sink) {
/*  85 */     return new DisposableAcquire(connectionObserver, config.channelOperationsProvider(), pendingAcquireTimeout, pool, sink);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InstrumentedPool<PooledConnection> createPool(TransportConfig config, PooledConnectionProvider.PoolFactory<PooledConnection> poolFactory, SocketAddress remoteAddress, AddressResolverGroup<?> resolverGroup) {
/*  95 */     return (new PooledConnectionAllocator(config, poolFactory, remoteAddress, resolverGroup)).pool;
/*     */   }
/*     */   
/*  98 */   static final Logger log = Loggers.getLogger(DefaultPooledConnectionProvider.class);
/*     */   
/* 100 */   static final AttributeKey<ConnectionObserver> OWNER = AttributeKey.valueOf("connectionOwner");
/*     */ 
/*     */   
/*     */   static final class DisposableAcquire
/*     */     implements ConnectionObserver, Runnable, CoreSubscriber<PooledRef<PooledConnection>>, Disposable
/*     */   {
/*     */     final Disposable.Composite cancellations;
/*     */     
/*     */     final Context currentContext;
/*     */     
/*     */     final ConnectionObserver obs;
/*     */     
/*     */     final ChannelOperations.OnSetup opsFactory;
/*     */     
/*     */     final long pendingAcquireTimeout;
/*     */     final InstrumentedPool<DefaultPooledConnectionProvider.PooledConnection> pool;
/*     */     final boolean retried;
/*     */     final MonoSink<Connection> sink;
/*     */     PooledRef<DefaultPooledConnectionProvider.PooledConnection> pooledRef;
/*     */     Subscription subscription;
/*     */     
/*     */     DisposableAcquire(ConnectionObserver obs, ChannelOperations.OnSetup opsFactory, long pendingAcquireTimeout, InstrumentedPool<DefaultPooledConnectionProvider.PooledConnection> pool, MonoSink<Connection> sink) {
/* 122 */       this.cancellations = Disposables.composite();
/* 123 */       this.currentContext = Context.of(sink.contextView());
/* 124 */       this.obs = obs;
/* 125 */       this.opsFactory = opsFactory;
/* 126 */       this.pendingAcquireTimeout = pendingAcquireTimeout;
/* 127 */       this.pool = pool;
/* 128 */       this.retried = false;
/* 129 */       this.sink = sink;
/*     */     }
/*     */     
/*     */     DisposableAcquire(DisposableAcquire parent) {
/* 133 */       this.cancellations = parent.cancellations;
/* 134 */       this.currentContext = parent.currentContext;
/* 135 */       this.obs = parent.obs;
/* 136 */       this.opsFactory = parent.opsFactory;
/* 137 */       this.pendingAcquireTimeout = parent.pendingAcquireTimeout;
/* 138 */       this.pool = parent.pool;
/* 139 */       this.retried = true;
/* 140 */       this.sink = parent.sink;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 145 */       return this.currentContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 150 */       this.subscription.cancel();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 160 */       this.sink.error(throwable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(PooledRef<DefaultPooledConnectionProvider.PooledConnection> value) {
/* 165 */       this.pooledRef = value;
/*     */       
/* 167 */       DefaultPooledConnectionProvider.PooledConnection pooledConnection = (DefaultPooledConnectionProvider.PooledConnection)value.poolable();
/* 168 */       pooledConnection.pooledRef = this.pooledRef;
/*     */       
/* 170 */       Channel c = pooledConnection.channel;
/*     */       
/* 172 */       if (!this.currentContext.isEmpty()) {
/* 173 */         ReactorNetty.setChannelContext(c, (ContextView)this.currentContext);
/*     */       }
/*     */       
/* 176 */       if (c.eventLoop().inEventLoop()) {
/* 177 */         run();
/*     */       } else {
/*     */         
/* 180 */         c.eventLoop().execute(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 186 */       if (newState == ConnectionObserver.State.CONFIGURED)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 191 */         this.sink.success(connection);
/*     */       }
/* 193 */       this.obs.onStateChange(connection, newState);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 198 */       if (Operators.validate(this.subscription, s)) {
/* 199 */         this.subscription = s;
/* 200 */         this.cancellations.add(this);
/* 201 */         if (!this.retried) {
/* 202 */           this.sink.onCancel((Disposable)this.cancellations);
/*     */         }
/* 204 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onUncaughtException(Connection connection, Throwable error) {
/* 210 */       this.sink.error(error);
/* 211 */       this.obs.onUncaughtException(connection, error);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 216 */       DefaultPooledConnectionProvider.PooledConnection pooledConnection = (DefaultPooledConnectionProvider.PooledConnection)this.pooledRef.poolable();
/* 217 */       Channel c = pooledConnection.channel;
/*     */ 
/*     */       
/* 220 */       if (!c.isActive()) {
/* 221 */         this.pooledRef.invalidate()
/* 222 */           .subscribe(null, null, () -> {
/*     */               if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/*     */                 PooledConnectionProvider.logPoolState(c, (InstrumentedPool)this.pool, "Channel closed");
/*     */               }
/*     */             });
/* 227 */         if (!this.retried) {
/* 228 */           if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/* 229 */             DefaultPooledConnectionProvider.log.debug(ReactorNetty.format(c, "Immediately aborted pooled channel, re-acquiring new channel"));
/*     */           }
/* 231 */           this.pool.acquire(Duration.ofMillis(this.pendingAcquireTimeout))
/* 232 */             .contextWrite(ctx -> ctx.put("callereventloop", c.eventLoop()))
/* 233 */             .subscribe(new DisposableAcquire(this));
/*     */         } else {
/*     */           
/* 236 */           this.sink.error(new IOException("Error while acquiring from " + this.pool));
/*     */         } 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 243 */       ConnectionObserver current = (ConnectionObserver)c.attr(DefaultPooledConnectionProvider.OWNER).getAndSet(this);
/*     */       
/* 245 */       if (current instanceof DefaultPooledConnectionProvider.PendingConnectionObserver) {
/* 246 */         DefaultPooledConnectionProvider.PendingConnectionObserver pending = (DefaultPooledConnectionProvider.PendingConnectionObserver)current;
/*     */         
/* 248 */         current = null;
/* 249 */         registerClose(this.pooledRef, this.pool);
/*     */         DefaultPooledConnectionProvider.PendingConnectionObserver.Pending p;
/* 251 */         while ((p = pending.pendingQueue.poll()) != null) {
/* 252 */           if (p.error != null) {
/* 253 */             onUncaughtException(p.connection, p.error); continue;
/*     */           } 
/* 255 */           if (p.state != null) {
/* 256 */             onStateChange(p.connection, p.state);
/*     */           }
/*     */         }
/*     */       
/* 260 */       } else if (current == null) {
/* 261 */         registerClose(this.pooledRef, this.pool);
/*     */       } 
/*     */ 
/*     */       
/* 265 */       if (current != null) {
/* 266 */         if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/* 267 */           PooledConnectionProvider.logPoolState(c, (InstrumentedPool)this.pool, "Channel acquired");
/*     */         }
/* 269 */         this.obs.onStateChange(pooledConnection, ConnectionObserver.State.ACQUIRED);
/*     */         
/* 271 */         ChannelOperations<?, ?> ops = this.opsFactory.create(pooledConnection, pooledConnection, null);
/* 272 */         if (ops != null) {
/* 273 */           if (c.pipeline().get("reactor.left.h2MultiplexHandler") == null) {
/* 274 */             ops.bind();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 279 */             this.sink.success(ops);
/* 280 */             this.obs.onStateChange((Connection)ops, ConnectionObserver.State.CONFIGURED);
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 287 */             this.sink.success(ops);
/* 288 */             this.obs.onStateChange(pooledConnection, ConnectionObserver.State.CONFIGURED);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 293 */           this.sink.success(pooledConnection);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 299 */       if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/* 300 */         PooledConnectionProvider.logPoolState(c, (InstrumentedPool)this.pool, "Channel connected");
/*     */       }
/* 302 */       if (this.opsFactory == ChannelOperations.OnSetup.empty()) {
/* 303 */         this.sink.success(Connection.from(c));
/*     */       }
/*     */     }
/*     */     
/*     */     void registerClose(PooledRef<DefaultPooledConnectionProvider.PooledConnection> pooledRef, InstrumentedPool<DefaultPooledConnectionProvider.PooledConnection> pool) {
/* 308 */       Channel channel = ((DefaultPooledConnectionProvider.PooledConnection)pooledRef.poolable()).channel;
/* 309 */       if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/* 310 */         DefaultPooledConnectionProvider.log.debug(ReactorNetty.format(channel, "Registering pool release on close event for channel"));
/*     */       }
/* 312 */       channel.closeFuture()
/* 313 */         .addListener(ff -> {
/*     */             ConnectionObserver owner = (ConnectionObserver)channel.attr(DefaultPooledConnectionProvider.OWNER).get();
/*     */             if (owner instanceof DisposableAcquire) {
/*     */               ((DisposableAcquire)owner).pooledRef.invalidate().subscribe(null, null, ());
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class PendingConnectionObserver
/*     */     implements ConnectionObserver
/*     */   {
/* 330 */     final Queue<Pending> pendingQueue = Queues.unbounded(4).get();
/*     */     final Context context;
/*     */     
/*     */     public PendingConnectionObserver() {
/* 334 */       this(Context.empty());
/*     */     }
/*     */     
/*     */     public PendingConnectionObserver(Context context) {
/* 338 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 343 */       this.pendingQueue.add(new Pending(connection, null, newState));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onUncaughtException(Connection connection, Throwable error) {
/* 348 */       this.pendingQueue.add(new Pending(connection, error, null));
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 353 */       return this.context;
/*     */     }
/*     */     
/*     */     static class Pending {
/*     */       final Connection connection;
/*     */       final Throwable error;
/*     */       final ConnectionObserver.State state;
/*     */       
/*     */       Pending(Connection connection, @Nullable Throwable error, @Nullable ConnectionObserver.State state) {
/* 362 */         this.connection = connection;
/* 363 */         this.error = error;
/* 364 */         this.state = state;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static final class PooledConnection
/*     */     extends AtomicLong implements Connection, ConnectionObserver {
/*     */     final Channel channel;
/*     */     final Sinks.Empty<Void> onTerminate;
/*     */     final InstrumentedPool<PooledConnection> pool;
/*     */     PooledRef<PooledConnection> pooledRef;
/*     */     
/*     */     PooledConnection(Channel channel, InstrumentedPool<PooledConnection> pool) {
/* 377 */       this.channel = channel;
/* 378 */       this.onTerminate = Sinks.unsafe().empty();
/* 379 */       this.pool = pool;
/*     */     }
/*     */ 
/*     */     
/*     */     public Channel channel() {
/* 384 */       return this.channel;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 389 */       return owner().currentContext();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 395 */       if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/* 396 */         DefaultPooledConnectionProvider.log.debug(ReactorNetty.format(connection.channel(), "onStateChange({}, {})"), new Object[] { connection, newState });
/*     */       }
/*     */       
/* 399 */       if (newState == ConnectionObserver.State.DISCONNECTING) {
/* 400 */         if (!isPersistent() && this.channel.isActive()) {
/*     */ 
/*     */           
/* 403 */           this.channel.close();
/* 404 */           owner().onStateChange(connection, ConnectionObserver.State.DISCONNECTING);
/*     */           
/*     */           return;
/*     */         } 
/* 408 */         if (!this.channel.isActive()) {
/* 409 */           owner().onStateChange(connection, ConnectionObserver.State.DISCONNECTING);
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 414 */         if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/* 415 */           DefaultPooledConnectionProvider.log.debug(ReactorNetty.format(connection.channel(), "Releasing channel"));
/*     */         }
/*     */ 
/*     */         
/* 419 */         ConnectionObserver obs = (ConnectionObserver)this.channel.attr(DefaultPooledConnectionProvider.OWNER).getAndSet(ConnectionObserver.emptyListener());
/*     */         
/* 421 */         if (ReactorNetty.getChannelContext(this.channel) != null) {
/* 422 */           ReactorNetty.setChannelContext(this.channel, null);
/*     */         }
/*     */         
/* 425 */         if (this.pooledRef == null) {
/*     */           return;
/*     */         }
/*     */         
/* 429 */         this.pooledRef.release()
/* 430 */           .subscribe(null, t -> {
/*     */               if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/*     */                 PooledConnectionProvider.logPoolState(((PooledConnection)this.pooledRef.poolable()).channel, (InstrumentedPool)this.pool, "Failed cleaning the channel from pool", t);
/*     */               }
/*     */ 
/*     */               
/*     */               this.onTerminate.tryEmitEmpty();
/*     */ 
/*     */               
/*     */               obs.onStateChange(connection, ConnectionObserver.State.RELEASED);
/*     */             }() -> {
/*     */               if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/*     */                 PooledConnectionProvider.logPoolState(((PooledConnection)this.pooledRef.poolable()).channel, (InstrumentedPool)this.pool, "Channel cleaned");
/*     */               }
/*     */ 
/*     */               
/*     */               this.onTerminate.tryEmitEmpty();
/*     */               
/*     */               obs.onStateChange(connection, ConnectionObserver.State.RELEASED);
/*     */             });
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 454 */       owner().onStateChange(connection, newState);
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> onTerminate() {
/* 459 */       return this.onTerminate.asMono().or(onDispose());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onUncaughtException(Connection connection, Throwable error) {
/* 464 */       owner().onUncaughtException(connection, error);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 469 */       return "PooledConnection{channel=" + this.channel + '}';
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConnectionObserver owner() {
/*     */       while (true) {
/* 477 */         ConnectionObserver obs = (ConnectionObserver)this.channel.attr(DefaultPooledConnectionProvider.OWNER).get();
/* 478 */         if (obs == null) {
/* 479 */           obs = new DefaultPooledConnectionProvider.PendingConnectionObserver();
/*     */         } else {
/*     */           
/* 482 */           return obs;
/*     */         } 
/* 484 */         if (this.channel.attr(DefaultPooledConnectionProvider.OWNER)
/* 485 */           .compareAndSet(null, obs)) {
/* 486 */           return obs;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class PooledConnectionAllocator
/*     */   {
/*     */     final TransportConfig config;
/*     */     final InstrumentedPool<DefaultPooledConnectionProvider.PooledConnection> pool;
/*     */     final SocketAddress remoteAddress;
/*     */     final AddressResolverGroup<?> resolver;
/*     */     static final BiPredicate<DefaultPooledConnectionProvider.PooledConnection, PooledRefMetadata> DEFAULT_EVICTION_PREDICATE;
/*     */     static final Function<DefaultPooledConnectionProvider.PooledConnection, Publisher<Void>> DEFAULT_DESTROY_HANDLER;
/*     */     
/*     */     PooledConnectionAllocator(TransportConfig config, PooledConnectionProvider.PoolFactory<DefaultPooledConnectionProvider.PooledConnection> provider, SocketAddress remoteAddress, AddressResolverGroup<?> resolver) {
/* 503 */       this.config = config;
/* 504 */       this.remoteAddress = remoteAddress;
/* 505 */       this.resolver = resolver;
/* 506 */       this.pool = provider.newPool(connectChannel(), null, DEFAULT_DESTROY_HANDLER, DEFAULT_EVICTION_PREDICATE);
/*     */     }
/*     */     
/*     */     Publisher<DefaultPooledConnectionProvider.PooledConnection> connectChannel() {
/* 510 */       return (Publisher<DefaultPooledConnectionProvider.PooledConnection>)Mono.create(sink -> {
/*     */             PooledConnectionInitializer initializer = new PooledConnectionInitializer(sink);
/*     */             EventLoop callerEventLoop = sink.contextView().hasKey("callereventloop") ? (EventLoop)sink.contextView().get("callereventloop") : null;
/*     */             if (callerEventLoop != null) {
/*     */               TransportConnector.connect(this.config, this.remoteAddress, this.resolver, initializer, callerEventLoop, sink.contextView()).subscribe(initializer);
/*     */             } else {
/*     */               TransportConnector.connect(this.config, this.remoteAddress, this.resolver, initializer, sink.contextView()).subscribe(initializer);
/*     */             } 
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     final class PooledConnectionInitializer
/*     */       extends ChannelInitializer<Channel>
/*     */       implements CoreSubscriber<Channel>
/*     */     {
/*     */       final MonoSink<DefaultPooledConnectionProvider.PooledConnection> sink;
/*     */       DefaultPooledConnectionProvider.PooledConnection pooledConnection;
/*     */       
/*     */       PooledConnectionInitializer(MonoSink<DefaultPooledConnectionProvider.PooledConnection> sink) {
/* 530 */         this.sink = sink;
/*     */       }
/*     */ 
/*     */       
/*     */       protected void initChannel(Channel ch) {
/* 535 */         if (DefaultPooledConnectionProvider.log.isDebugEnabled()) {
/* 536 */           PooledConnectionProvider.logPoolState(ch, (InstrumentedPool)DefaultPooledConnectionProvider.PooledConnectionAllocator.this.pool, "Created a new pooled channel");
/*     */         }
/*     */         
/* 539 */         DefaultPooledConnectionProvider.PooledConnection pooledConnection = new DefaultPooledConnectionProvider.PooledConnection(ch, DefaultPooledConnectionProvider.PooledConnectionAllocator.this.pool);
/*     */         
/* 541 */         this.pooledConnection = pooledConnection;
/*     */         
/* 543 */         ch.attr(DefaultPooledConnectionProvider.OWNER).compareAndSet(null, new DefaultPooledConnectionProvider.PendingConnectionObserver(Context.of(this.sink.contextView())));
/* 544 */         ch.pipeline().remove((ChannelHandler)this);
/* 545 */         ch.pipeline()
/* 546 */           .addFirst(new ChannelHandler[] { (ChannelHandler)this.this$0.config.channelInitializer(pooledConnection, this.this$0.remoteAddress, false) });
/*     */         
/* 548 */         pooledConnection.bind();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void onComplete() {}
/*     */ 
/*     */ 
/*     */       
/*     */       public void onError(Throwable t) {
/* 558 */         this.sink.error(t);
/*     */       }
/*     */ 
/*     */       
/*     */       public void onNext(Channel channel) {
/* 563 */         this.sink.success(this.pooledConnection);
/*     */       }
/*     */ 
/*     */       
/*     */       public void onSubscribe(Subscription s) {
/* 568 */         s.request(Long.MAX_VALUE);
/*     */       } }
/*     */     
/*     */     static {
/* 572 */       DEFAULT_EVICTION_PREDICATE = ((pooledConnection, metadata) -> 
/* 573 */         (!pooledConnection.channel.isActive() || !pooledConnection.isPersistent()));
/*     */       
/* 575 */       DEFAULT_DESTROY_HANDLER = (pooledConnection -> !pooledConnection.channel.isActive() ? Mono.empty() : FutureMono.from((Future)pooledConnection.channel.close()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DefaultPooledConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */