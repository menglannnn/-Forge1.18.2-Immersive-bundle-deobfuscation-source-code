/*    */ package reactor.netty.resources;
/*    */ 
/*    */ import io.netty.channel.EventLoopGroup;
/*    */ import io.netty.channel.socket.DatagramChannel;
/*    */ import io.netty.channel.socket.ServerSocketChannel;
/*    */ import io.netty.channel.socket.SocketChannel;
/*    */ import io.netty.channel.socket.nio.NioDatagramChannel;
/*    */ import io.netty.channel.socket.nio.NioServerSocketChannel;
/*    */ import io.netty.channel.socket.nio.NioSocketChannel;
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultLoopNIO
/*    */   implements DefaultLoop
/*    */ {
/*    */   public <CHANNEL extends io.netty.channel.Channel> CHANNEL getChannel(Class<CHANNEL> channelClass) {
/* 41 */     if (channelClass.equals(SocketChannel.class)) {
/* 42 */       return (CHANNEL)new NioSocketChannel();
/*    */     }
/* 44 */     if (channelClass.equals(ServerSocketChannel.class)) {
/* 45 */       return (CHANNEL)new NioServerSocketChannel();
/*    */     }
/* 47 */     if (channelClass.equals(DatagramChannel.class)) {
/* 48 */       return (CHANNEL)new NioDatagramChannel();
/*    */     }
/* 50 */     throw new IllegalArgumentException("Unsupported channel type: " + channelClass.getSimpleName());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <CHANNEL extends io.netty.channel.Channel> Class<? extends CHANNEL> getChannelClass(Class<CHANNEL> channelClass) {
/* 56 */     if (channelClass.equals(SocketChannel.class)) {
/* 57 */       return (Class)NioSocketChannel.class;
/*    */     }
/* 59 */     if (channelClass.equals(ServerSocketChannel.class)) {
/* 60 */       return (Class)NioServerSocketChannel.class;
/*    */     }
/* 62 */     if (channelClass.equals(DatagramChannel.class)) {
/* 63 */       return (Class)NioDatagramChannel.class;
/*    */     }
/* 65 */     throw new IllegalArgumentException("Unsupported channel type: " + channelClass.getSimpleName());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 70 */     return "nio";
/*    */   }
/*    */ 
/*    */   
/*    */   public EventLoopGroup newEventLoopGroup(int threads, ThreadFactory factory) {
/* 75 */     throw new IllegalStateException("Missing Epoll/KQueue on current system");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supportGroup(EventLoopGroup group) {
/* 80 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DefaultLoopNIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */