/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.nio.NioEventLoopGroup;
/*     */ import io.netty.util.concurrent.FastThreadLocalThread;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.NonBlocking;
/*     */ import reactor.netty.FutureMono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultLoopResources
/*     */   extends AtomicLong
/*     */   implements LoopResources
/*     */ {
/*     */   final String prefix;
/*     */   final boolean daemon;
/*     */   final int selectCount;
/*     */   final int workerCount;
/*     */   final AtomicReference<EventLoopGroup> serverLoops;
/*     */   final AtomicReference<EventLoopGroup> clientLoops;
/*     */   final AtomicReference<EventLoopGroup> serverSelectLoops;
/*     */   final AtomicReference<EventLoopGroup> cacheNativeClientLoops;
/*     */   final AtomicReference<EventLoopGroup> cacheNativeServerLoops;
/*     */   final AtomicReference<EventLoopGroup> cacheNativeSelectLoops;
/*     */   final AtomicBoolean running;
/*     */   final boolean colocate;
/*     */   
/*     */   DefaultLoopResources(String prefix, int workerCount, boolean daemon) {
/*  54 */     this(prefix, -1, workerCount, daemon);
/*     */   }
/*     */   
/*     */   DefaultLoopResources(String prefix, int selectCount, int workerCount, boolean daemon) {
/*  58 */     this(prefix, selectCount, workerCount, daemon, true);
/*     */   }
/*     */   
/*     */   DefaultLoopResources(String prefix, int selectCount, int workerCount, boolean daemon, boolean colocate) {
/*  62 */     this.running = new AtomicBoolean(true);
/*  63 */     this.daemon = daemon;
/*  64 */     this.workerCount = workerCount;
/*  65 */     this.prefix = prefix;
/*  66 */     this.colocate = colocate;
/*     */     
/*  68 */     this.serverLoops = new AtomicReference<>();
/*  69 */     this.clientLoops = new AtomicReference<>();
/*     */     
/*  71 */     this.cacheNativeClientLoops = new AtomicReference<>();
/*  72 */     this.cacheNativeServerLoops = new AtomicReference<>();
/*     */     
/*  74 */     if (selectCount == -1) {
/*  75 */       this.selectCount = workerCount;
/*  76 */       this.serverSelectLoops = this.serverLoops;
/*  77 */       this.cacheNativeSelectLoops = this.cacheNativeServerLoops;
/*     */     } else {
/*     */       
/*  80 */       this.selectCount = selectCount;
/*  81 */       this.serverSelectLoops = new AtomicReference<>();
/*  82 */       this.cacheNativeSelectLoops = new AtomicReference<>();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeLater(Duration quietPeriod, Duration timeout) {
/*  89 */     return Mono.defer(() -> {
/*     */           long quietPeriodMillis = quietPeriod.toMillis();
/*     */           long timeoutMillis = timeout.toMillis();
/*     */           EventLoopGroup serverLoopsGroup = this.serverLoops.get();
/*     */           EventLoopGroup clientLoopsGroup = this.clientLoops.get();
/*     */           EventLoopGroup serverSelectLoopsGroup = this.serverSelectLoops.get();
/*     */           EventLoopGroup cacheNativeClientGroup = this.cacheNativeClientLoops.get();
/*     */           EventLoopGroup cacheNativeSelectGroup = this.cacheNativeSelectLoops.get();
/*     */           EventLoopGroup cacheNativeServerGroup = this.cacheNativeServerLoops.get();
/*     */           Mono<?> clMono = Mono.empty();
/*     */           Mono<?> sslMono = Mono.empty();
/*     */           Mono<?> slMono = Mono.empty();
/*     */           Mono<?> cnclMono = Mono.empty();
/*     */           Mono<?> cnslMono = Mono.empty();
/*     */           Mono<?> cnsrvlMono = Mono.empty();
/*     */           if (this.running.compareAndSet(true, false)) {
/*     */             if (clientLoopsGroup != null) {
/*     */               clMono = FutureMono.from(clientLoopsGroup.shutdownGracefully(quietPeriodMillis, timeoutMillis, TimeUnit.MILLISECONDS));
/*     */             }
/*     */             if (serverSelectLoopsGroup != null) {
/*     */               sslMono = FutureMono.from(serverSelectLoopsGroup.shutdownGracefully(quietPeriodMillis, timeoutMillis, TimeUnit.MILLISECONDS));
/*     */             }
/*     */             if (serverLoopsGroup != null) {
/*     */               slMono = FutureMono.from(serverLoopsGroup.shutdownGracefully(quietPeriodMillis, timeoutMillis, TimeUnit.MILLISECONDS));
/*     */             }
/*     */             if (cacheNativeClientGroup != null) {
/*     */               cnclMono = FutureMono.from(cacheNativeClientGroup.shutdownGracefully(quietPeriodMillis, timeoutMillis, TimeUnit.MILLISECONDS));
/*     */             }
/*     */             if (cacheNativeSelectGroup != null) {
/*     */               cnslMono = FutureMono.from(cacheNativeSelectGroup.shutdownGracefully(quietPeriodMillis, timeoutMillis, TimeUnit.MILLISECONDS));
/*     */             }
/*     */             if (cacheNativeServerGroup != null) {
/*     */               cnsrvlMono = FutureMono.from(cacheNativeServerGroup.shutdownGracefully(quietPeriodMillis, timeoutMillis, TimeUnit.MILLISECONDS));
/*     */             }
/*     */           } 
/*     */           return Mono.when(new Publisher[] { (Publisher)clMono, (Publisher)sslMono, (Publisher)slMono, (Publisher)cnclMono, (Publisher)cnslMono, (Publisher)cnsrvlMono });
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 139 */     return !this.running.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onClient(boolean useNative) {
/* 144 */     if (useNative && LoopResources.hasNativeSupport()) {
/* 145 */       return cacheNativeClientLoops();
/*     */     }
/* 147 */     return cacheNioClientLoops();
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onServer(boolean useNative) {
/* 152 */     if (useNative && LoopResources.hasNativeSupport()) {
/* 153 */       return cacheNativeServerLoops();
/*     */     }
/* 155 */     return cacheNioServerLoops();
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup onServerSelect(boolean useNative) {
/* 160 */     if (useNative && LoopResources.hasNativeSupport()) {
/* 161 */       return cacheNativeSelectLoops();
/*     */     }
/* 163 */     return cacheNioSelectLoops();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 168 */     return "DefaultLoopResources {prefix=" + this.prefix + ", daemon=" + this.daemon + ", selectCount=" + this.selectCount + ", workerCount=" + this.workerCount + '}';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EventLoopGroup cacheNioClientLoops() {
/* 177 */     EventLoopGroup eventLoopGroup = this.clientLoops.get();
/* 178 */     if (null == eventLoopGroup) {
/*     */       
/* 180 */       EventLoopGroup newEventLoopGroup = this.colocate ? LoopResources.colocate(cacheNioServerLoops()) : cacheNioServerLoops();
/* 181 */       if (!this.clientLoops.compareAndSet(null, newEventLoopGroup));
/*     */ 
/*     */       
/* 184 */       eventLoopGroup = cacheNioClientLoops();
/*     */     } 
/* 186 */     return eventLoopGroup;
/*     */   }
/*     */ 
/*     */   
/*     */   EventLoopGroup cacheNioSelectLoops() {
/* 191 */     if (this.serverSelectLoops == this.serverLoops) {
/* 192 */       return cacheNioServerLoops();
/*     */     }
/*     */     
/* 195 */     EventLoopGroup eventLoopGroup = this.serverSelectLoops.get();
/* 196 */     if (null == eventLoopGroup) {
/*     */       
/* 198 */       NioEventLoopGroup nioEventLoopGroup = new NioEventLoopGroup(this.selectCount, threadFactory(this, "select-nio"));
/* 199 */       if (!this.serverSelectLoops.compareAndSet(null, nioEventLoopGroup))
/*     */       {
/* 201 */         nioEventLoopGroup.shutdownGracefully(0L, 0L, TimeUnit.MILLISECONDS);
/*     */       }
/* 203 */       eventLoopGroup = cacheNioSelectLoops();
/*     */     } 
/* 205 */     return eventLoopGroup;
/*     */   }
/*     */ 
/*     */   
/*     */   EventLoopGroup cacheNioServerLoops() {
/* 210 */     EventLoopGroup eventLoopGroup = this.serverLoops.get();
/* 211 */     if (null == eventLoopGroup) {
/*     */       
/* 213 */       NioEventLoopGroup nioEventLoopGroup = new NioEventLoopGroup(this.workerCount, threadFactory(this, "nio"));
/* 214 */       if (!this.serverLoops.compareAndSet(null, nioEventLoopGroup))
/*     */       {
/* 216 */         nioEventLoopGroup.shutdownGracefully(0L, 0L, TimeUnit.MILLISECONDS);
/*     */       }
/* 218 */       eventLoopGroup = cacheNioServerLoops();
/*     */     } 
/* 220 */     return eventLoopGroup;
/*     */   }
/*     */   
/*     */   EventLoopGroup cacheNativeClientLoops() {
/* 224 */     EventLoopGroup eventLoopGroup = this.cacheNativeClientLoops.get();
/* 225 */     if (null == eventLoopGroup) {
/*     */       
/* 227 */       EventLoopGroup newEventLoopGroup = this.colocate ? LoopResources.colocate(cacheNativeServerLoops()) : cacheNativeServerLoops();
/* 228 */       if (!this.cacheNativeClientLoops.compareAndSet(null, newEventLoopGroup));
/*     */ 
/*     */       
/* 231 */       eventLoopGroup = cacheNativeClientLoops();
/*     */     } 
/* 233 */     return eventLoopGroup;
/*     */   }
/*     */ 
/*     */   
/*     */   EventLoopGroup cacheNativeSelectLoops() {
/* 238 */     if (this.cacheNativeSelectLoops == this.cacheNativeServerLoops) {
/* 239 */       return cacheNativeServerLoops();
/*     */     }
/*     */     
/* 242 */     EventLoopGroup eventLoopGroup = this.cacheNativeSelectLoops.get();
/* 243 */     if (null == eventLoopGroup) {
/* 244 */       DefaultLoop defaultLoop = DefaultLoopNativeDetector.INSTANCE;
/* 245 */       EventLoopGroup newEventLoopGroup = defaultLoop.newEventLoopGroup(this.selectCount, 
/*     */           
/* 247 */           threadFactory(this, "select-" + defaultLoop.getName()));
/* 248 */       if (!this.cacheNativeSelectLoops.compareAndSet(null, newEventLoopGroup))
/*     */       {
/* 250 */         newEventLoopGroup.shutdownGracefully(0L, 0L, TimeUnit.MILLISECONDS);
/*     */       }
/* 252 */       eventLoopGroup = cacheNativeSelectLoops();
/*     */     } 
/* 254 */     return eventLoopGroup;
/*     */   }
/*     */ 
/*     */   
/*     */   EventLoopGroup cacheNativeServerLoops() {
/* 259 */     EventLoopGroup eventLoopGroup = this.cacheNativeServerLoops.get();
/* 260 */     if (null == eventLoopGroup) {
/* 261 */       DefaultLoop defaultLoop = DefaultLoopNativeDetector.INSTANCE;
/* 262 */       EventLoopGroup newEventLoopGroup = defaultLoop.newEventLoopGroup(this.workerCount, 
/*     */           
/* 264 */           threadFactory(this, defaultLoop.getName()));
/* 265 */       if (!this.cacheNativeServerLoops.compareAndSet(null, newEventLoopGroup))
/*     */       {
/* 267 */         newEventLoopGroup.shutdownGracefully(0L, 0L, TimeUnit.MILLISECONDS);
/*     */       }
/* 269 */       eventLoopGroup = cacheNativeServerLoops();
/*     */     } 
/* 271 */     return eventLoopGroup;
/*     */   }
/*     */   
/*     */   static ThreadFactory threadFactory(DefaultLoopResources parent, String prefix) {
/* 275 */     return new EventLoopFactory(parent.daemon, parent.prefix + "-" + prefix, parent);
/*     */   }
/*     */   
/*     */   static final class EventLoop
/*     */     extends FastThreadLocalThread implements NonBlocking {
/*     */     EventLoop(Runnable target) {
/* 281 */       super(target);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class EventLoopFactory
/*     */     implements ThreadFactory {
/*     */     final boolean daemon;
/*     */     final AtomicLong counter;
/*     */     final String prefix;
/*     */     
/*     */     EventLoopFactory(boolean daemon, String prefix, AtomicLong counter) {
/* 292 */       this.daemon = daemon;
/* 293 */       this.counter = counter;
/* 294 */       this.prefix = prefix;
/*     */     }
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable r) {
/* 299 */       DefaultLoopResources.EventLoop eventLoop = new DefaultLoopResources.EventLoop(r);
/* 300 */       eventLoop.setDaemon(this.daemon);
/* 301 */       eventLoop.setName(this.prefix + "-" + this.counter.incrementAndGet());
/* 302 */       return (Thread)eventLoop;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DefaultLoopResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */