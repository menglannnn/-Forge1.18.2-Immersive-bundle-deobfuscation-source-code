/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Clock;
/*     */ import java.time.Duration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.internal.shaded.reactor.pool.AllocationStrategy;
/*     */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*     */ import reactor.netty.internal.shaded.reactor.pool.Pool;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PoolBuilder;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PoolConfig;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PooledRef;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PooledRefMetadata;
/*     */ import reactor.netty.internal.shaded.reactor.pool.decorators.GracefulShutdownInstrumentedPool;
/*     */ import reactor.netty.internal.shaded.reactor.pool.decorators.InstrumentedPoolDecorators;
/*     */ import reactor.netty.internal.shaded.reactor.pool.introspection.SamplingAllocationStrategy;
/*     */ import reactor.netty.internal.util.MapUtils;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.Metrics;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PooledConnectionProvider<T extends Connection>
/*     */   implements ConnectionProvider
/*     */ {
/*     */   protected static final String CONTEXT_CALLER_EVENTLOOP = "callereventloop";
/*     */   final PoolFactory<T> defaultPoolFactory;
/*  82 */   final Map<SocketAddress, PoolFactory<T>> poolFactoryPerRemoteHost = new HashMap<>();
/*     */   
/*  84 */   final ConcurrentMap<PoolKey, InstrumentedPool<T>> channelPools = new ConcurrentHashMap<>();
/*     */   
/*     */   final ConnectionProvider.Builder builder;
/*     */   final String name;
/*     */   final Duration inactivePoolDisposeInterval;
/*     */   final Duration poolInactivity;
/*     */   final Duration disposeTimeout;
/*  91 */   final Map<SocketAddress, Integer> maxConnections = new HashMap<>();
/*     */   Mono<Void> onDispose;
/*     */   
/*     */   protected PooledConnectionProvider(ConnectionProvider.Builder builder) {
/*  95 */     this(builder, null);
/*     */   }
/*     */ 
/*     */   
/*     */   PooledConnectionProvider(ConnectionProvider.Builder builder, @Nullable Clock clock) {
/* 100 */     this.builder = builder;
/* 101 */     this.name = builder.name;
/* 102 */     this.inactivePoolDisposeInterval = builder.inactivePoolDisposeInterval;
/* 103 */     this.poolInactivity = builder.poolInactivity;
/* 104 */     this.disposeTimeout = builder.disposeTimeout;
/* 105 */     this.defaultPoolFactory = new PoolFactory<>(builder, builder.disposeTimeout, clock);
/* 106 */     for (Map.Entry<SocketAddress, ConnectionProvider.ConnectionPoolSpec<?>> entry : builder.confPerRemoteHost.entrySet()) {
/* 107 */       this.poolFactoryPerRemoteHost.put(entry.getKey(), new PoolFactory<>(entry.getValue(), builder.disposeTimeout));
/* 108 */       this.maxConnections.put(entry.getKey(), Integer.valueOf(((ConnectionProvider.ConnectionPoolSpec)entry.getValue()).maxConnections));
/*     */     } 
/* 110 */     this.onDispose = Mono.empty();
/* 111 */     scheduleInactivePoolsDisposal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<? extends Connection> acquire(TransportConfig config, ConnectionObserver connectionObserver, @Nullable Supplier<? extends SocketAddress> remote, @Nullable AddressResolverGroup<?> resolverGroup) {
/* 120 */     Objects.requireNonNull(config, "config");
/* 121 */     Objects.requireNonNull(connectionObserver, "connectionObserver");
/* 122 */     Objects.requireNonNull(remote, "remoteAddress");
/* 123 */     Objects.requireNonNull(resolverGroup, "resolverGroup");
/* 124 */     return Mono.create(sink -> {
/*     */           EventLoop eventLoop;
/*     */           SocketAddress remoteAddress = Objects.<SocketAddress>requireNonNull(remote.get(), "Remote Address supplier returned null");
/*     */           PoolKey holder = new PoolKey(remoteAddress, config.channelHash());
/*     */           PoolFactory<T> poolFactory = poolFactory(remoteAddress);
/*     */           InstrumentedPool<T> pool = (InstrumentedPool<T>)MapUtils.computeIfAbsent(this.channelPools, holder, ());
/*     */           if (sink.contextView().hasKey("callereventloop")) {
/*     */             eventLoop = (EventLoop)sink.contextView().get("callereventloop");
/*     */           } else {
/*     */             EventLoopGroup group = config.loopResources().onClient(config.isPreferNative());
/*     */             if (group instanceof ColocatedEventLoopGroup) {
/*     */               eventLoop = ((ColocatedEventLoopGroup)group).nextInternal();
/*     */             } else {
/*     */               eventLoop = null;
/*     */             } 
/*     */           } 
/*     */           Mono<PooledRef<T>> mono = pool.acquire(Duration.ofMillis(poolFactory.pendingAcquireTimeout));
/*     */           if (eventLoop != null) {
/*     */             mono = mono.contextWrite(());
/*     */           }
/*     */           mono.subscribe(createDisposableAcquire(config, connectionObserver, poolFactory.pendingAcquireTimeout, pool, sink));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Mono<Void> disposeLater() {
/* 177 */     return Mono.defer(() -> {
/*     */           List<Mono<Void>> pools = (List<Mono<Void>>)this.channelPools.entrySet().stream().map(()).collect(Collectors.toList());
/*     */           if (pools.isEmpty()) {
/*     */             return this.onDispose;
/*     */           }
/*     */           this.channelPools.clear();
/*     */           return this.onDispose.and((Publisher)Mono.when(pools));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void disposeWhen(SocketAddress address) {
/* 228 */     List<Map.Entry<PoolKey, InstrumentedPool<T>>> toDispose = (List<Map.Entry<PoolKey, InstrumentedPool<T>>>)this.channelPools.entrySet().stream().filter(p -> compareAddresses(((PoolKey)p.getKey()).holder, address)).collect(Collectors.toList());
/*     */     
/* 230 */     toDispose.forEach(e -> {
/*     */           if (this.channelPools.remove(e.getKey(), e.getValue())) {
/*     */             if (log.isDebugEnabled()) {
/*     */               log.debug("ConnectionProvider[name={}]: Disposing pool for [{}]", new Object[] { this.name, ((PoolKey)e.getKey()).holder });
/*     */             }
/*     */             String id = ((PoolKey)e.getKey()).hashCode() + "";
/*     */             PoolFactory<T> poolFactory = poolFactory(address);
/*     */             ((InstrumentedPool)e.getValue()).disposeLater().then(Mono.fromRunnable(())).subscribe();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDisposed() {
/* 253 */     return (this.channelPools.isEmpty() || this.channelPools.values()
/* 254 */       .stream()
/* 255 */       .allMatch(Disposable::isDisposed));
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxConnections() {
/* 260 */     return this.defaultPoolFactory.maxConnections;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<SocketAddress, Integer> maxConnectionsPerHost() {
/* 265 */     return this.maxConnections;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConnectionProvider.Builder mutate() {
/* 270 */     return new ConnectionProvider.Builder(this.builder);
/*     */   }
/*     */ 
/*     */   
/*     */   public String name() {
/* 275 */     return this.name;
/*     */   }
/*     */   
/*     */   public void onDispose(Mono<Void> disposeMono) {
/* 279 */     this.onDispose = this.onDispose.and((Publisher)disposeMono);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PoolFactory<T> poolFactory(SocketAddress remoteAddress) {
/* 296 */     return this.poolFactoryPerRemoteHost.getOrDefault(remoteAddress, this.defaultPoolFactory);
/*     */   }
/*     */   
/*     */   protected void registerDefaultMetrics(String id, SocketAddress remoteAddress, InstrumentedPool.PoolMetrics metrics) {
/* 300 */     MicrometerPooledConnectionProviderMeterRegistrar.INSTANCE.registerMetrics(this.name, id, remoteAddress, metrics);
/*     */   }
/*     */   
/*     */   protected void deRegisterDefaultMetrics(String id, SocketAddress remoteAddress) {
/* 304 */     MicrometerPooledConnectionProviderMeterRegistrar.INSTANCE.deRegisterMetrics(this.name, id, remoteAddress);
/*     */   }
/*     */   
/*     */   final boolean compareAddresses(SocketAddress origin, SocketAddress target) {
/* 308 */     if (origin.equals(target)) {
/* 309 */       return true;
/*     */     }
/* 311 */     if (origin instanceof InetSocketAddress && target instanceof InetSocketAddress) {
/* 312 */       InetSocketAddress isaOrigin = (InetSocketAddress)origin;
/* 313 */       InetSocketAddress isaTarget = (InetSocketAddress)target;
/* 314 */       if (isaOrigin.getPort() == isaTarget.getPort()) {
/* 315 */         InetAddress iaTarget = isaTarget.getAddress();
/* 316 */         return ((iaTarget != null && iaTarget.isAnyLocalAddress()) || 
/* 317 */           Objects.equals(isaOrigin.getHostString(), isaTarget.getHostString()));
/*     */       } 
/*     */     } 
/* 320 */     return false;
/*     */   }
/*     */   
/*     */   protected static void logPoolState(Channel channel, InstrumentedPool<? extends Connection> pool, String msg) {
/* 324 */     logPoolState(channel, pool, msg, null);
/*     */   }
/*     */   
/*     */   protected static void logPoolState(Channel channel, InstrumentedPool<? extends Connection> pool, String msg, @Nullable Throwable t) {
/* 328 */     InstrumentedPool.PoolMetrics metrics = pool.metrics();
/* 329 */     log.debug(ReactorNetty.format(channel, "{}, now: {} active connections, {} inactive connections and {} pending acquire requests."), new Object[] { msg, 
/*     */           
/* 331 */           Integer.valueOf(metrics.acquiredSize()), 
/* 332 */           Integer.valueOf(metrics.idleSize()), 
/* 333 */           Integer.valueOf(metrics.pendingAcquireSize()), 
/* 334 */           (t == null) ? "" : t });
/*     */   }
/*     */   
/*     */   final void scheduleInactivePoolsDisposal() {
/* 338 */     if (!this.inactivePoolDisposeInterval.isZero()) {
/* 339 */       Schedulers.parallel()
/* 340 */         .schedule(this::disposeInactivePoolsInBackground, this.inactivePoolDisposeInterval.toMillis(), TimeUnit.MILLISECONDS);
/*     */     }
/*     */   }
/*     */   
/*     */   final void disposeInactivePoolsInBackground() {
/* 345 */     if (!this.channelPools.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 351 */       List<Map.Entry<PoolKey, InstrumentedPool<T>>> toDispose = (List<Map.Entry<PoolKey, InstrumentedPool<T>>>)this.channelPools.entrySet().stream().filter(p -> ((InstrumentedPool)p.getValue()).metrics().isInactiveForMoreThan(this.poolInactivity)).collect(Collectors.toList());
/*     */       
/* 353 */       toDispose.forEach(e -> {
/*     */             if (this.channelPools.remove(e.getKey(), e.getValue())) {
/*     */               if (log.isDebugEnabled()) {
/*     */                 log.debug("ConnectionProvider[name={}]: Disposing inactive pool for [{}]", new Object[] { this.name, ((PoolKey)e.getKey()).holder });
/*     */               }
/*     */               ((InstrumentedPool)e.getValue()).dispose();
/*     */             } 
/*     */           });
/*     */     } 
/* 362 */     scheduleInactivePoolsDisposal();
/*     */   }
/*     */   
/* 365 */   static final Logger log = Loggers.getLogger(PooledConnectionProvider.class);
/*     */   protected abstract CoreSubscriber<PooledRef<T>> createDisposableAcquire(TransportConfig paramTransportConfig, ConnectionObserver paramConnectionObserver, long paramLong, InstrumentedPool<T> paramInstrumentedPool, MonoSink<Connection> paramMonoSink);
/*     */   protected abstract InstrumentedPool<T> createPool(TransportConfig paramTransportConfig, PoolFactory<T> paramPoolFactory, SocketAddress paramSocketAddress, AddressResolverGroup<?> paramAddressResolverGroup);
/*     */   protected static final class PoolFactory<T extends Connection> { static final double DEFAULT_POOL_GET_PERMITS_SAMPLING_RATE;
/*     */     
/*     */     static {
/* 371 */       double getPermitsSamplingRate = Double.parseDouble(System.getProperty("reactor.netty.pool.getPermitsSamplingRate", "0"));
/* 372 */       if (getPermitsSamplingRate > 1.0D) {
/* 373 */         DEFAULT_POOL_GET_PERMITS_SAMPLING_RATE = 0.0D;
/* 374 */         if (PooledConnectionProvider.log.isWarnEnabled()) {
/* 375 */           PooledConnectionProvider.log.warn("Invalid configuration [reactor.netty.pool.getPermitsSamplingRate=" + getPermitsSamplingRate + "], the value must be between 0d and 1d (percentage). SamplingAllocationStrategy in not enabled.");
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 380 */         DEFAULT_POOL_GET_PERMITS_SAMPLING_RATE = getPermitsSamplingRate;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 387 */       double returnPermitsSamplingRate = Double.parseDouble(System.getProperty("reactor.netty.pool.returnPermitsSamplingRate", "0"));
/* 388 */       if (returnPermitsSamplingRate > 1.0D) {
/* 389 */         DEFAULT_POOL_RETURN_PERMITS_SAMPLING_RATE = 0.0D;
/* 390 */         if (PooledConnectionProvider.log.isWarnEnabled()) {
/* 391 */           PooledConnectionProvider.log.warn("Invalid configuration [reactor.netty.pool.returnPermitsSamplingRate=" + returnPermitsSamplingRate + "], the value must be between 0d and 1d (percentage). SamplingAllocationStrategy is enabled.");
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 396 */         DEFAULT_POOL_RETURN_PERMITS_SAMPLING_RATE = returnPermitsSamplingRate;
/*     */       } 
/*     */     }
/*     */     static final double DEFAULT_POOL_RETURN_PERMITS_SAMPLING_RATE;
/*     */     final Duration evictionInterval;
/*     */     final String leasingStrategy;
/*     */     final int maxConnections;
/*     */     final long maxIdleTime;
/*     */     final long maxLifeTime;
/*     */     final boolean metricsEnabled;
/*     */     final int pendingAcquireMaxCount;
/*     */     final long pendingAcquireTimeout;
/*     */     final Supplier<? extends ConnectionProvider.MeterRegistrar> registrar;
/*     */     final Clock clock;
/*     */     final Duration disposeTimeout;
/*     */     final BiFunction<Runnable, Duration, Disposable> pendingAcquireTimer;
/*     */     final ConnectionProvider.AllocationStrategy<?> allocationStrategy;
/*     */     final BiPredicate<Connection, ConnectionProvider.ConnectionMetadata> evictionPredicate;
/*     */     
/*     */     PoolFactory(ConnectionProvider.ConnectionPoolSpec<?> conf, Duration disposeTimeout) {
/* 416 */       this(conf, disposeTimeout, null);
/*     */     }
/*     */ 
/*     */     
/*     */     PoolFactory(ConnectionProvider.ConnectionPoolSpec<?> conf, Duration disposeTimeout, @Nullable Clock clock) {
/* 421 */       this.evictionInterval = conf.evictionInterval;
/* 422 */       this.leasingStrategy = conf.leasingStrategy;
/* 423 */       this.maxConnections = conf.maxConnections;
/* 424 */       this.maxIdleTime = (conf.maxIdleTime != null) ? conf.maxIdleTime.toMillis() : -1L;
/* 425 */       this.maxLifeTime = (conf.maxLifeTime != null) ? conf.maxLifeTime.toMillis() : -1L;
/* 426 */       this.metricsEnabled = conf.metricsEnabled;
/* 427 */       this
/* 428 */         .pendingAcquireMaxCount = (conf.pendingAcquireMaxCount == -2) ? (2 * conf.maxConnections) : conf.pendingAcquireMaxCount;
/* 429 */       this.pendingAcquireTimeout = conf.pendingAcquireTimeout.toMillis();
/* 430 */       this.registrar = conf.registrar;
/* 431 */       this.clock = clock;
/* 432 */       this.disposeTimeout = disposeTimeout;
/* 433 */       this.pendingAcquireTimer = conf.pendingAcquireTimer;
/* 434 */       this.allocationStrategy = conf.allocationStrategy;
/* 435 */       this.evictionPredicate = conf.evictionPredicate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InstrumentedPool<T> newPool(Publisher<T> allocator, @Nullable AllocationStrategy allocationStrategy, Function<T, Publisher<Void>> destroyHandler, BiPredicate<T, PooledRefMetadata> evictionPredicate) {
/* 443 */       if (this.disposeTimeout != null) {
/* 444 */         return newPoolInternal(allocator, destroyHandler, evictionPredicate)
/* 445 */           .buildPoolAndDecorateWith(InstrumentedPoolDecorators::gracefulShutdown);
/*     */       }
/* 447 */       return newPoolInternal(allocator, destroyHandler, evictionPredicate).buildPool();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InstrumentedPool<T> newPool(Publisher<T> allocator, @Nullable AllocationStrategy allocationStrategy, Function<T, Publisher<Void>> destroyHandler, BiPredicate<T, PooledRefMetadata> defaultEvictionPredicate, Function<PoolConfig<T>, InstrumentedPool<T>> poolFactory) {
/* 456 */       if (this.disposeTimeout != null) {
/* 457 */         return (InstrumentedPool<T>)newPoolInternal(allocator, destroyHandler, defaultEvictionPredicate)
/* 458 */           .build(poolFactory.andThen(InstrumentedPoolDecorators::gracefulShutdown));
/*     */       }
/* 460 */       return (InstrumentedPool<T>)newPoolInternal(allocator, destroyHandler, defaultEvictionPredicate).build(poolFactory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PoolBuilder<T, PoolConfig<T>> newPoolInternal(Publisher<T> allocator, Function<T, Publisher<Void>> destroyHandler, BiPredicate<T, PooledRefMetadata> defaultEvictionPredicate) {
/* 471 */       PoolBuilder<T, PoolConfig<T>> poolBuilder = PoolBuilder.from(allocator).destroyHandler(destroyHandler).maxPendingAcquire(this.pendingAcquireMaxCount).evictInBackground(this.evictionInterval);
/*     */       
/* 473 */       if (this.evictionPredicate != null) {
/* 474 */         poolBuilder = poolBuilder.evictionPredicate((poolable, meta) -> this.evictionPredicate.test(poolable, new PooledConnectionProvider.PooledConnectionMetadata(meta)));
/*     */       }
/*     */       else {
/*     */         
/* 478 */         poolBuilder = poolBuilder.evictionPredicate(defaultEvictionPredicate.or((poolable, meta) -> 
/* 479 */               ((this.maxIdleTime != -1L && meta.idleTime() >= this.maxIdleTime) || (this.maxLifeTime != -1L && meta.lifeTime() >= this.maxLifeTime))));
/*     */       } 
/*     */ 
/*     */       
/* 483 */       if (DEFAULT_POOL_GET_PERMITS_SAMPLING_RATE > 0.0D && DEFAULT_POOL_GET_PERMITS_SAMPLING_RATE <= 1.0D && DEFAULT_POOL_RETURN_PERMITS_SAMPLING_RATE > 0.0D && DEFAULT_POOL_RETURN_PERMITS_SAMPLING_RATE <= 1.0D) {
/*     */         
/* 485 */         poolBuilder = poolBuilder.allocationStrategy((AllocationStrategy)SamplingAllocationStrategy.sizeBetweenWithSampling(0, this.maxConnections, DEFAULT_POOL_GET_PERMITS_SAMPLING_RATE, DEFAULT_POOL_RETURN_PERMITS_SAMPLING_RATE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 492 */       else if (this.allocationStrategy == null) {
/* 493 */         poolBuilder = poolBuilder.sizeBetween(0, this.maxConnections);
/*     */       } else {
/*     */         
/* 496 */         poolBuilder = poolBuilder.allocationStrategy(new DelegatingAllocationStrategy((ConnectionProvider.AllocationStrategy<?>)this.allocationStrategy.copy()));
/*     */       } 
/*     */ 
/*     */       
/* 500 */       if (this.pendingAcquireTimer != null) {
/* 501 */         poolBuilder = poolBuilder.pendingAcquireTimer(this.pendingAcquireTimer);
/*     */       }
/*     */       
/* 504 */       if (this.clock != null) {
/* 505 */         poolBuilder = poolBuilder.clock(this.clock);
/*     */       }
/*     */       
/* 508 */       if ("fifo".equals(this.leasingStrategy)) {
/* 509 */         poolBuilder = poolBuilder.idleResourceReuseLruOrder();
/*     */       } else {
/*     */         
/* 512 */         poolBuilder = poolBuilder.idleResourceReuseMruOrder();
/*     */       } 
/*     */       
/* 515 */       return poolBuilder;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public ConnectionProvider.AllocationStrategy<?> allocationStrategy() {
/* 520 */       return this.allocationStrategy;
/*     */     }
/*     */     
/*     */     public long maxIdleTime() {
/* 524 */       return this.maxIdleTime;
/*     */     }
/*     */     
/*     */     public long maxLifeTime() {
/* 528 */       return this.maxLifeTime;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 533 */       return "PoolFactory{evictionInterval=" + this.evictionInterval + ", leasingStrategy=" + this.leasingStrategy + ", maxConnections=" + this.maxConnections + ", maxIdleTime=" + this.maxIdleTime + ", maxLifeTime=" + this.maxLifeTime + ", metricsEnabled=" + this.metricsEnabled + ", pendingAcquireMaxCount=" + this.pendingAcquireMaxCount + ", pendingAcquireTimeout=" + this.pendingAcquireTimeout + '}';
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static final class DelegatingAllocationStrategy
/*     */       implements AllocationStrategy
/*     */     {
/*     */       final ConnectionProvider.AllocationStrategy<?> delegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       DelegatingAllocationStrategy(ConnectionProvider.AllocationStrategy<?> delegate) {
/* 550 */         this.delegate = delegate;
/*     */       }
/*     */ 
/*     */       
/*     */       public int estimatePermitCount() {
/* 555 */         return this.delegate.estimatePermitCount();
/*     */       }
/*     */ 
/*     */       
/*     */       public int getPermits(int desired) {
/* 560 */         return this.delegate.getPermits(desired);
/*     */       }
/*     */ 
/*     */       
/*     */       public int permitGranted() {
/* 565 */         return this.delegate.permitGranted();
/*     */       }
/*     */ 
/*     */       
/*     */       public int permitMinimum() {
/* 570 */         return this.delegate.permitMinimum();
/*     */       }
/*     */ 
/*     */       
/*     */       public int permitMaximum() {
/* 575 */         return this.delegate.permitMaximum();
/*     */       }
/*     */ 
/*     */       
/*     */       public void returnPermits(int returned) {
/* 580 */         this.delegate.returnPermits(returned);
/*     */       }
/*     */     } }
/*     */ 
/*     */   
/*     */   static final class PooledConnectionMetadata
/*     */     implements ConnectionProvider.ConnectionMetadata {
/*     */     final PooledRefMetadata delegate;
/*     */     
/*     */     PooledConnectionMetadata(PooledRefMetadata delegate) {
/* 590 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public int acquireCount() {
/* 595 */       return this.delegate.acquireCount();
/*     */     }
/*     */ 
/*     */     
/*     */     public long idleTime() {
/* 600 */       return this.delegate.idleTime();
/*     */     }
/*     */ 
/*     */     
/*     */     public long lifeTime() {
/* 605 */       return this.delegate.lifeTime();
/*     */     }
/*     */ 
/*     */     
/*     */     public long releaseTimestamp() {
/* 610 */       return this.delegate.releaseTimestamp();
/*     */     }
/*     */ 
/*     */     
/*     */     public long allocationTimestamp() {
/* 615 */       return this.delegate.allocationTimestamp();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class PoolKey {
/*     */     final String fqdn;
/*     */     final SocketAddress holder;
/*     */     final int pipelineKey;
/*     */     
/*     */     PoolKey(SocketAddress holder, int pipelineKey) {
/* 625 */       String fqdn = null;
/* 626 */       if (holder instanceof InetSocketAddress) {
/* 627 */         InetSocketAddress inetSocketAddress = (InetSocketAddress)holder;
/* 628 */         if (!inetSocketAddress.isUnresolved())
/*     */         {
/* 630 */           fqdn = inetSocketAddress.getHostString().toLowerCase();
/*     */         }
/*     */       } 
/* 633 */       this.fqdn = fqdn;
/* 634 */       this.holder = holder;
/* 635 */       this.pipelineKey = pipelineKey;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 640 */       if (this == o) {
/* 641 */         return true;
/*     */       }
/* 643 */       if (o == null || getClass() != o.getClass()) {
/* 644 */         return false;
/*     */       }
/* 646 */       PoolKey poolKey = (PoolKey)o;
/* 647 */       return (Objects.equals(this.fqdn, poolKey.fqdn) && 
/* 648 */         Objects.equals(this.holder, poolKey.holder) && this.pipelineKey == poolKey.pipelineKey);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 654 */       int result = 1;
/* 655 */       result = 31 * result + Objects.hashCode(this.fqdn);
/* 656 */       result = 31 * result + Objects.hashCode(this.holder);
/* 657 */       result = 31 * result + this.pipelineKey;
/* 658 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\PooledConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */