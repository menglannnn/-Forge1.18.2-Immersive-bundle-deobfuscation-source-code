package reactor.netty.resources;

import io.netty.channel.EventLoopGroup;
import java.util.concurrent.ThreadFactory;

interface DefaultLoop {
  <CHANNEL extends io.netty.channel.Channel> CHANNEL getChannel(Class<CHANNEL> paramClass);
  
  <CHANNEL extends io.netty.channel.Channel> Class<? extends CHANNEL> getChannelClass(Class<CHANNEL> paramClass);
  
  String getName();
  
  EventLoopGroup newEventLoopGroup(int paramInt, ThreadFactory paramThreadFactory);
  
  boolean supportGroup(EventLoopGroup paramEventLoopGroup);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DefaultLoop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */