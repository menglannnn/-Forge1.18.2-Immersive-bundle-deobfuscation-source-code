/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import java.net.SocketAddress;
/*     */ import java.time.Duration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.util.Metrics;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface ConnectionProvider
/*     */   extends Disposable
/*     */ {
/*  55 */   public static final int DEFAULT_POOL_MAX_CONNECTIONS = Integer.parseInt(System.getProperty("reactor.netty.pool.maxConnections", "" + (
/*  56 */         Math.max(Runtime.getRuntime().availableProcessors(), 8) * 2)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final long DEFAULT_POOL_ACQUIRE_TIMEOUT = Long.parseLong(System.getProperty("reactor.netty.pool.acquireTimeout", "45000"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final long DEFAULT_POOL_MAX_IDLE_TIME = Long.parseLong(System.getProperty("reactor.netty.pool.maxIdleTime", "-1"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public static final long DEFAULT_POOL_MAX_LIFE_TIME = Long.parseLong(System.getProperty("reactor.netty.pool.maxLifeTime", "-1"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LEASING_STRATEGY_FIFO = "fifo";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LEASING_STRATEGY_LIFO = "lifo";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public static final String DEFAULT_POOL_LEASING_STRATEGY = System.getProperty("reactor.netty.pool.leasingStrategy", "fifo")
/*  99 */     .toLowerCase(Locale.ENGLISH);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Builder builder(String name) {
/* 109 */     return new Builder(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConnectionProvider newConnection() {
/* 120 */     return NewConnectionProvider.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConnectionProvider create(String name) {
/* 138 */     return builder(name).maxConnections(DEFAULT_POOL_MAX_CONNECTIONS)
/* 139 */       .pendingAcquireMaxCount(500)
/* 140 */       .pendingAcquireTimeout(Duration.ofMillis(DEFAULT_POOL_ACQUIRE_TIMEOUT))
/* 141 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConnectionProvider create(String name, int maxConnections) {
/* 160 */     return builder(name).maxConnections(maxConnections)
/* 161 */       .pendingAcquireTimeout(Duration.ofMillis(DEFAULT_POOL_ACQUIRE_TIMEOUT))
/* 162 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConnectionProvider create(String name, int maxConnections, boolean metricsEnabled) {
/* 182 */     return builder(name).maxConnections(maxConnections)
/* 183 */       .pendingAcquireTimeout(Duration.ofMillis(DEFAULT_POOL_ACQUIRE_TIMEOUT))
/* 184 */       .metrics(metricsEnabled)
/* 185 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<? extends Connection> acquire(TransportConfig paramTransportConfig, ConnectionObserver paramConnectionObserver, @Nullable Supplier<? extends SocketAddress> paramSupplier, @Nullable AddressResolverGroup<?> paramAddressResolverGroup);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void disposeWhen(SocketAddress remoteAddress) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void dispose() {
/* 225 */     disposeLater().subscribe();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> disposeLater() {
/* 238 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int maxConnections() {
/* 247 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default Map<SocketAddress, Integer> maxConnectionsPerHost() {
/* 257 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default Builder mutate() {
/* 268 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default String name() {
/* 279 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface ConnectionMetadata
/*     */   {
/*     */     int acquireCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     long idleTime();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     long lifeTime();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     long releaseTimestamp();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     long allocationTimestamp();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface AllocationStrategy<A extends AllocationStrategy<A>>
/*     */   {
/*     */     A copy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int estimatePermitCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int getPermits(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int permitGranted();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int permitMinimum();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int permitMaximum();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void returnPermits(int param1Int);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */     extends ConnectionPoolSpec<Builder>
/*     */   {
/* 396 */     static final Duration DISPOSE_INACTIVE_POOLS_IN_BACKGROUND_DISABLED = Duration.ZERO;
/*     */     
/*     */     String name;
/* 399 */     Duration inactivePoolDisposeInterval = DISPOSE_INACTIVE_POOLS_IN_BACKGROUND_DISABLED;
/*     */     Duration poolInactivity;
/*     */     Duration disposeTimeout;
/* 402 */     final Map<SocketAddress, ConnectionProvider.ConnectionPoolSpec<?>> confPerRemoteHost = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder(String name) {
/* 411 */       name(name);
/*     */     }
/*     */     
/*     */     Builder(Builder copy) {
/* 415 */       super(copy);
/* 416 */       this.name = copy.name;
/* 417 */       this.inactivePoolDisposeInterval = copy.inactivePoolDisposeInterval;
/* 418 */       this.poolInactivity = copy.poolInactivity;
/* 419 */       this.disposeTimeout = copy.disposeTimeout;
/* 420 */       copy.confPerRemoteHost.forEach((address, spec) -> (ConnectionProvider.ConnectionPoolSpec)this.confPerRemoteHost.put(address, new ConnectionProvider.ConnectionPoolSpec(spec)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder name(String name) {
/* 431 */       this.name = Objects.<String>requireNonNull(name, "name");
/* 432 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder disposeInactivePoolsInBackground(Duration disposeInterval, Duration poolInactivity) {
/* 450 */       this.inactivePoolDisposeInterval = Objects.<Duration>requireNonNull(disposeInterval, "disposeInterval");
/* 451 */       this.poolInactivity = Objects.<Duration>requireNonNull(poolInactivity, "poolInactivity");
/* 452 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder disposeTimeout(Duration timeout) {
/* 470 */       this.disposeTimeout = Objects.<Duration>requireNonNull(timeout, "disposeTimeout");
/* 471 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder forRemoteHost(SocketAddress remoteHost, Consumer<ConnectionProvider.HostSpecificSpec> spec) {
/* 483 */       Objects.requireNonNull(remoteHost, "remoteHost");
/* 484 */       Objects.requireNonNull(spec, "spec");
/* 485 */       ConnectionProvider.HostSpecificSpec builder = new ConnectionProvider.HostSpecificSpec();
/* 486 */       spec.accept(builder);
/* 487 */       this.confPerRemoteHost.put(remoteHost, builder);
/* 488 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConnectionProvider build() {
/* 497 */       return new DefaultPooledConnectionProvider(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ConnectionPoolSpec<SPEC extends ConnectionPoolSpec<SPEC>>
/*     */     implements Supplier<SPEC>
/*     */   {
/* 508 */     static final Duration EVICT_IN_BACKGROUND_DISABLED = Duration.ZERO;
/*     */     
/*     */     static final int PENDING_ACQUIRE_MAX_COUNT_NOT_SPECIFIED = -2;
/* 511 */     Duration evictionInterval = EVICT_IN_BACKGROUND_DISABLED;
/* 512 */     int maxConnections = ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS;
/* 513 */     int pendingAcquireMaxCount = -2;
/* 514 */     Duration pendingAcquireTimeout = Duration.ofMillis(ConnectionProvider.DEFAULT_POOL_ACQUIRE_TIMEOUT);
/*     */     Duration maxIdleTime;
/*     */     Duration maxLifeTime;
/*     */     boolean metricsEnabled;
/* 518 */     String leasingStrategy = ConnectionProvider.DEFAULT_POOL_LEASING_STRATEGY;
/*     */     
/*     */     Supplier<? extends ConnectionProvider.MeterRegistrar> registrar;
/*     */     
/*     */     BiFunction<Runnable, Duration, Disposable> pendingAcquireTimer;
/*     */     
/*     */     ConnectionProvider.AllocationStrategy<?> allocationStrategy;
/*     */     BiPredicate<Connection, ConnectionProvider.ConnectionMetadata> evictionPredicate;
/*     */     
/*     */     private ConnectionPoolSpec() {
/* 528 */       if (ConnectionProvider.DEFAULT_POOL_MAX_IDLE_TIME > -1L) {
/* 529 */         maxIdleTime(Duration.ofMillis(ConnectionProvider.DEFAULT_POOL_MAX_IDLE_TIME));
/*     */       }
/* 531 */       if (ConnectionProvider.DEFAULT_POOL_MAX_LIFE_TIME > -1L) {
/* 532 */         maxLifeTime(Duration.ofMillis(ConnectionProvider.DEFAULT_POOL_MAX_LIFE_TIME));
/*     */       }
/*     */     }
/*     */     
/*     */     ConnectionPoolSpec(ConnectionPoolSpec<SPEC> copy) {
/* 537 */       this.evictionInterval = copy.evictionInterval;
/* 538 */       this.maxConnections = copy.maxConnections;
/* 539 */       this.pendingAcquireMaxCount = copy.pendingAcquireMaxCount;
/* 540 */       this.pendingAcquireTimeout = copy.pendingAcquireTimeout;
/* 541 */       this.maxIdleTime = copy.maxIdleTime;
/* 542 */       this.maxLifeTime = copy.maxLifeTime;
/* 543 */       this.metricsEnabled = copy.metricsEnabled;
/* 544 */       this.leasingStrategy = copy.leasingStrategy;
/* 545 */       this.registrar = copy.registrar;
/* 546 */       this.pendingAcquireTimer = copy.pendingAcquireTimer;
/* 547 */       this.allocationStrategy = copy.allocationStrategy;
/* 548 */       this.evictionPredicate = copy.evictionPredicate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC pendingAcquireTimeout(Duration pendingAcquireTimeout) {
/* 561 */       this.pendingAcquireTimeout = Objects.<Duration>requireNonNull(pendingAcquireTimeout, "pendingAcquireTimeout");
/* 562 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC maxConnections(int maxConnections) {
/* 577 */       if (maxConnections <= 0) {
/* 578 */         throw new IllegalArgumentException("Max Connections value must be strictly positive");
/*     */       }
/* 580 */       this.maxConnections = maxConnections;
/* 581 */       this.allocationStrategy = null;
/* 582 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC pendingAcquireMaxCount(int pendingAcquireMaxCount) {
/* 597 */       if (pendingAcquireMaxCount != -1 && pendingAcquireMaxCount <= 0) {
/* 598 */         throw new IllegalArgumentException("Pending acquire max count must be strictly positive");
/*     */       }
/* 600 */       this.pendingAcquireMaxCount = pendingAcquireMaxCount;
/* 601 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC maxIdleTime(Duration maxIdleTime) {
/* 615 */       this.maxIdleTime = Objects.<Duration>requireNonNull(maxIdleTime);
/* 616 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC maxLifeTime(Duration maxLifeTime) {
/* 630 */       this.maxLifeTime = Objects.<Duration>requireNonNull(maxLifeTime);
/* 631 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC evictionPredicate(BiPredicate<Connection, ConnectionProvider.ConnectionMetadata> evictionPredicate) {
/* 648 */       this.evictionPredicate = Objects.<BiPredicate<Connection, ConnectionProvider.ConnectionMetadata>>requireNonNull(evictionPredicate);
/* 649 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC metrics(boolean metricsEnabled) {
/* 669 */       if (metricsEnabled && 
/* 670 */         !Metrics.isInstrumentationAvailable()) {
/* 671 */         throw new UnsupportedOperationException("To enable metrics, you must add the dependency `io.micrometer:micrometer-core` to the class path first");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 676 */       this.metricsEnabled = metricsEnabled;
/* 677 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC metrics(boolean metricsEnabled, Supplier<? extends ConnectionProvider.MeterRegistrar> registrar) {
/* 691 */       this.metricsEnabled = metricsEnabled;
/* 692 */       this.registrar = Objects.<Supplier<? extends ConnectionProvider.MeterRegistrar>>requireNonNull(registrar);
/* 693 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC lifo() {
/* 706 */       this.leasingStrategy = "lifo";
/* 707 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC fifo() {
/* 720 */       this.leasingStrategy = "fifo";
/* 721 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC evictInBackground(Duration evictionInterval) {
/* 737 */       this.evictionInterval = Objects.<Duration>requireNonNull(evictionInterval, "evictionInterval");
/* 738 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC pendingAcquireTimer(BiFunction<Runnable, Duration, Disposable> pendingAcquireTimer) {
/* 774 */       this.pendingAcquireTimer = Objects.<BiFunction<Runnable, Duration, Disposable>>requireNonNull(pendingAcquireTimer, "pendingAcquireTimer");
/* 775 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final SPEC allocationStrategy(ConnectionProvider.AllocationStrategy<?> allocationStrategy) {
/* 790 */       this.allocationStrategy = Objects.<ConnectionProvider.AllocationStrategy>requireNonNull(allocationStrategy, "allocationStrategy");
/* 791 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SPEC get() {
/* 797 */       return (SPEC)this;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class HostSpecificSpec extends ConnectionPoolSpec<HostSpecificSpec> {}
/*     */   
/*     */   public static interface MeterRegistrar {
/*     */     void registerMetrics(String param1String1, String param1String2, SocketAddress param1SocketAddress, ConnectionPoolMetrics param1ConnectionPoolMetrics);
/*     */     
/*     */     default void deRegisterMetrics(String poolName, String id, SocketAddress remoteAddress) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\ConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */