/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.EventLoop;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.FastThreadLocal;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.ScheduledFuture;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ColocatedEventLoopGroup
/*     */   implements EventLoopGroup, Supplier<EventLoopGroup>
/*     */ {
/*     */   final EventLoopGroup eventLoopGroup;
/*  44 */   final FastThreadLocal<EventLoop> localLoop = new FastThreadLocal();
/*     */ 
/*     */   
/*     */   ColocatedEventLoopGroup(EventLoopGroup eventLoopGroup) {
/*  48 */     this.eventLoopGroup = eventLoopGroup;
/*  49 */     for (EventExecutor ex : eventLoopGroup) {
/*  50 */       if (ex instanceof EventLoop) {
/*  51 */         EventLoop eventLoop = (EventLoop)ex;
/*  52 */         if (eventLoop.inEventLoop()) {
/*  53 */           if (!this.localLoop.isSet()) {
/*  54 */             this.localLoop.set(eventLoop);
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/*  59 */         eventLoop.submit(() -> {
/*     */               if (!this.localLoop.isSet()) {
/*     */                 this.localLoop.set(eventLoop);
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/*  71 */     return this.eventLoopGroup.awaitTermination(timeout, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(Runnable command) {
/*  76 */     next().execute(command);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoopGroup get() {
/*  81 */     return this.eventLoopGroup;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
/*  86 */     return next().invokeAll(tasks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
/*  92 */     return next().invokeAll(tasks, timeout, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
/*  97 */     return (T)next().invokeAny(tasks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 103 */     return (T)next().invokeAny(tasks, timeout, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShutdown() {
/* 108 */     return this.eventLoopGroup.isShutdown();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShuttingDown() {
/* 113 */     return this.eventLoopGroup.isShuttingDown();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 118 */     return this.eventLoopGroup.isTerminated();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<EventExecutor> iterator() {
/* 123 */     return this.eventLoopGroup.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public EventLoop next() {
/* 128 */     EventLoop loop = nextInternal();
/* 129 */     return (loop != null) ? loop : this.eventLoopGroup.next();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register(Channel channel) {
/* 134 */     return next().register(channel);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ChannelFuture register(Channel channel, ChannelPromise promise) {
/* 140 */     return next().register(channel, promise);
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture register(ChannelPromise promise) {
/* 145 */     return next().register(promise);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
/* 150 */     return next().schedule(callable, delay, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
/* 155 */     return next().schedule(command, delay, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
/* 160 */     return next().scheduleAtFixedRate(command, initialDelay, period, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
/* 165 */     return next().scheduleWithFixedDelay(command, initialDelay, delay, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void shutdown() {
/* 173 */     shutdownGracefully();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> shutdownGracefully() {
/* 178 */     clean();
/* 179 */     return this.eventLoopGroup.shutdownGracefully();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> shutdownGracefully(long quietPeriod, long timeout, TimeUnit unit) {
/* 184 */     clean();
/* 185 */     return this.eventLoopGroup.shutdownGracefully(quietPeriod, timeout, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public List<Runnable> shutdownNow() {
/* 191 */     clean();
/* 192 */     return this.eventLoopGroup.shutdownNow();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 197 */     return next().submit(task);
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> submit(Runnable task) {
/* 202 */     return next().submit(task);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Runnable task, T result) {
/* 207 */     return next().submit(task, result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> terminationFuture() {
/* 212 */     return this.eventLoopGroup.terminationFuture();
/*     */   }
/*     */   
/*     */   void clean() {
/* 216 */     for (EventExecutor ex : this.eventLoopGroup) {
/* 217 */       ex.execute(() -> this.localLoop.set(null));
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   EventLoop nextInternal() {
/* 223 */     return this.localLoop.isSet() ? (EventLoop)this.localLoop.get() : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\ColocatedEventLoopGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */