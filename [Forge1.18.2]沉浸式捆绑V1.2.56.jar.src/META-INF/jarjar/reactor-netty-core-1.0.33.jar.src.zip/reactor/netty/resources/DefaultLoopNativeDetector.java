/*    */ package reactor.netty.resources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultLoopNativeDetector
/*    */ {
/*    */   static final DefaultLoop INSTANCE;
/* 30 */   static final DefaultLoop NIO = new DefaultLoopNIO();
/*    */   static {
/* 32 */     if (DefaultLoopIOUring.isIoUringAvailable) {
/* 33 */       INSTANCE = new DefaultLoopIOUring();
/*    */     }
/* 35 */     else if (DefaultLoopEpoll.isEpollAvailable) {
/* 36 */       INSTANCE = new DefaultLoopEpoll();
/*    */     }
/* 38 */     else if (DefaultLoopKQueue.isKqueueAvailable) {
/* 39 */       INSTANCE = new DefaultLoopKQueue();
/*    */     } else {
/*    */       
/* 42 */       INSTANCE = NIO;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\DefaultLoopNativeDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */