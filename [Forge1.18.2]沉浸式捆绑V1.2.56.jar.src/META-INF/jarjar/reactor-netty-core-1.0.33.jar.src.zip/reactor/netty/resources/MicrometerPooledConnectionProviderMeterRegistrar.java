/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.micrometer.core.instrument.Gauge;
/*     */ import io.micrometer.core.instrument.Meter;
/*     */ import io.micrometer.core.instrument.Tags;
/*     */ import java.net.SocketAddress;
/*     */ import reactor.netty.Metrics;
/*     */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MicrometerPooledConnectionProviderMeterRegistrar
/*     */ {
/*     */   static final String ACTIVE_CONNECTIONS_DESCRIPTION = "The number of the connections that have been successfully acquired and are in active use";
/*     */   static final String IDLE_CONNECTIONS_DESCRIPTION = "The number of the idle connections";
/*     */   static final String MAX_CONNECTIONS_DESCRIPTIONS = "The maximum number of active connections that are allowed";
/*     */   static final String MAX_PENDING_CONNECTIONS_DESCRIPTIONS = "The maximum number of requests that will be queued while waiting for a ready connection";
/*     */   static final String PENDING_CONNECTIONS_DESCRIPTION = "The number of the request, that are pending acquire a connection";
/*     */   static final String TOTAL_CONNECTIONS_DESCRIPTION = "The number of all connections, active or idle.";
/*  59 */   static final MicrometerPooledConnectionProviderMeterRegistrar INSTANCE = new MicrometerPooledConnectionProviderMeterRegistrar();
/*     */ 
/*     */ 
/*     */   
/*     */   void registerMetrics(String poolName, String id, SocketAddress remoteAddress, InstrumentedPool.PoolMetrics metrics) {
/*  64 */     String addressAsString = Metrics.formatSocketAddress(remoteAddress);
/*  65 */     Tags tags = Tags.of(new String[] { "id", id, "remote.address", addressAsString, "name", poolName });
/*  66 */     Gauge.builder("reactor.netty.connection.provider.total.connections", metrics, InstrumentedPool.PoolMetrics::allocatedSize)
/*  67 */       .description("The number of all connections, active or idle.")
/*  68 */       .tags((Iterable)tags)
/*  69 */       .register(Metrics.REGISTRY);
/*     */     
/*  71 */     Gauge.builder("reactor.netty.connection.provider.active.connections", metrics, InstrumentedPool.PoolMetrics::acquiredSize)
/*  72 */       .description("The number of the connections that have been successfully acquired and are in active use")
/*  73 */       .tags((Iterable)tags)
/*  74 */       .register(Metrics.REGISTRY);
/*     */     
/*  76 */     Gauge.builder("reactor.netty.connection.provider.idle.connections", metrics, InstrumentedPool.PoolMetrics::idleSize)
/*  77 */       .description("The number of the idle connections")
/*  78 */       .tags((Iterable)tags)
/*  79 */       .register(Metrics.REGISTRY);
/*     */     
/*  81 */     Gauge.builder("reactor.netty.connection.provider.pending.connections", metrics, InstrumentedPool.PoolMetrics::pendingAcquireSize)
/*  82 */       .description("The number of the request, that are pending acquire a connection")
/*  83 */       .tags((Iterable)tags)
/*  84 */       .register(Metrics.REGISTRY);
/*     */     
/*  86 */     Gauge.builder("reactor.netty.connection.provider.max.connections", metrics, InstrumentedPool.PoolMetrics::getMaxAllocatedSize)
/*  87 */       .description("The maximum number of active connections that are allowed")
/*  88 */       .tags((Iterable)tags)
/*  89 */       .register(Metrics.REGISTRY);
/*     */     
/*  91 */     Gauge.builder("reactor.netty.connection.provider.max.pending.connections", metrics, InstrumentedPool.PoolMetrics::getMaxPendingAcquireSize)
/*  92 */       .description("The maximum number of requests that will be queued while waiting for a ready connection")
/*  93 */       .tags((Iterable)tags)
/*  94 */       .register(Metrics.REGISTRY);
/*     */   }
/*     */   
/*     */   void deRegisterMetrics(String poolName, String id, SocketAddress remoteAddress) {
/*  98 */     String addressAsString = Metrics.formatSocketAddress(remoteAddress);
/*  99 */     Tags tags = Tags.of(new String[] { "id", id, "remote.address", addressAsString, "name", poolName });
/*     */     
/* 101 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.total.connections", tags, null, null, Meter.Type.GAUGE));
/* 102 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.active.connections", tags, null, null, Meter.Type.GAUGE));
/* 103 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.idle.connections", tags, null, null, Meter.Type.GAUGE));
/* 104 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.pending.connections", tags, null, null, Meter.Type.GAUGE));
/* 105 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.max.connections", tags, null, null, Meter.Type.GAUGE));
/* 106 */     Metrics.REGISTRY.remove(new Meter.Id("reactor.netty.connection.provider.max.pending.connections", tags, null, null, Meter.Type.GAUGE));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\MicrometerPooledConnectionProviderMeterRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */