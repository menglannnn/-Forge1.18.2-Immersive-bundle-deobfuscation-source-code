/*     */ package reactor.netty.resources;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.resolver.AddressResolverGroup;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.netty.ChannelBindException;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.ReactorNetty;
/*     */ import reactor.netty.transport.AddressUtils;
/*     */ import reactor.netty.transport.TransportConfig;
/*     */ import reactor.netty.transport.TransportConnector;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NewConnectionProvider
/*     */   implements ConnectionProvider
/*     */ {
/*  54 */   static final Logger log = Loggers.getLogger(NewConnectionProvider.class);
/*     */   
/*  56 */   static final NewConnectionProvider INSTANCE = new NewConnectionProvider();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<? extends Connection> acquire(TransportConfig config, ConnectionObserver observer, @Nullable Supplier<? extends SocketAddress> remoteAddress, @Nullable AddressResolverGroup<?> resolverGroup) {
/*  63 */     return Mono.create(sink -> {
/*     */           SocketAddress remote = null;
/*     */           if (remoteAddress != null) {
/*     */             remote = Objects.<SocketAddress>requireNonNull(remoteAddress.get(), "Remote Address supplier returned null");
/*     */           }
/*     */           ConnectionObserver connectionObserver = new NewConnectionObserver(sink, observer);
/*     */           DisposableConnect disposableConnect = new DisposableConnect(sink, config.bindAddress());
/*     */           if (remote != null && resolverGroup != null) {
/*     */             ChannelInitializer<Channel> channelInitializer = config.channelInitializer(connectionObserver, remote, false);
/*     */             TransportConnector.connect(config, remote, resolverGroup, channelInitializer, sink.contextView()).subscribe(disposableConnect);
/*     */           } else {
/*     */             Objects.requireNonNull(config.bindAddress(), "bindAddress");
/*     */             SocketAddress local = Objects.<SocketAddress>requireNonNull(config.bindAddress().get(), "Bind Address supplier returned null");
/*     */             if (local instanceof InetSocketAddress) {
/*     */               InetSocketAddress localInet = (InetSocketAddress)local;
/*     */               if (localInet.isUnresolved()) {
/*     */                 local = AddressUtils.createResolved(localInet.getHostName(), localInet.getPort());
/*     */               }
/*     */             } 
/*     */             ChannelInitializer<Channel> channelInitializer = config.channelInitializer(connectionObserver, null, true);
/*     */             TransportConnector.bind(config, channelInitializer, local, local instanceof io.netty.channel.unix.DomainSocketAddress).subscribe(disposableConnect);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxConnections() {
/* 100 */     return 1;
/*     */   }
/*     */   
/*     */   static final class DisposableConnect
/*     */     implements CoreSubscriber<Channel>, Disposable {
/*     */     final MonoSink<Connection> sink;
/*     */     final Context currentContext;
/*     */     final Supplier<? extends SocketAddress> bindAddress;
/*     */     Subscription subscription;
/*     */     
/*     */     DisposableConnect(MonoSink<Connection> sink, @Nullable Supplier<? extends SocketAddress> bindAddress) {
/* 111 */       this.sink = sink;
/* 112 */       this.currentContext = Context.of(sink.contextView());
/* 113 */       this.bindAddress = bindAddress;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 118 */       return this.currentContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 123 */       this.subscription.cancel();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {}
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 132 */       if (this.bindAddress != null && (t instanceof java.net.BindException || (t instanceof java.io.IOException && t
/*     */ 
/*     */         
/* 135 */         .getMessage() != null && t
/* 136 */         .getMessage().contains("bind(..)")))) {
/* 137 */         this.sink.error((Throwable)ChannelBindException.fail(this.bindAddress.get(), null));
/*     */       } else {
/*     */         
/* 140 */         this.sink.error(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(Channel channel) {
/* 146 */       if (NewConnectionProvider.log.isDebugEnabled()) {
/* 147 */         NewConnectionProvider.log.debug(ReactorNetty.format(channel, "Connected new channel"));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 153 */       if (Operators.validate(this.subscription, s)) {
/* 154 */         this.subscription = s;
/* 155 */         this.sink.onCancel(this);
/* 156 */         s.request(Long.MAX_VALUE);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class NewConnectionObserver
/*     */     implements ConnectionObserver {
/*     */     final MonoSink<Connection> sink;
/*     */     final Context currentContext;
/*     */     final ConnectionObserver obs;
/*     */     
/*     */     NewConnectionObserver(MonoSink<Connection> sink, ConnectionObserver obs) {
/* 168 */       this.sink = sink;
/* 169 */       this.currentContext = Context.of(sink.contextView());
/* 170 */       this.obs = obs;
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 175 */       return this.currentContext;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onStateChange(Connection connection, ConnectionObserver.State newState) {
/* 181 */       if (NewConnectionProvider.log.isDebugEnabled()) {
/* 182 */         NewConnectionProvider.log.debug(ReactorNetty.format(connection.channel(), "onStateChange({}, {})"), new Object[] { newState, connection });
/*     */       }
/* 184 */       if (newState == ConnectionObserver.State.CONFIGURED) {
/* 185 */         this.sink.success(connection);
/*     */       }
/* 187 */       else if (newState == ConnectionObserver.State.DISCONNECTING && connection.channel()
/* 188 */         .isActive()) {
/*     */         
/* 190 */         connection.channel()
/* 191 */           .close();
/*     */       } 
/* 193 */       this.obs.onStateChange(connection, newState);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onUncaughtException(Connection c, Throwable error) {
/* 198 */       this.sink.error(error);
/* 199 */       this.obs.onUncaughtException(c, error);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\resources\NewConnectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */