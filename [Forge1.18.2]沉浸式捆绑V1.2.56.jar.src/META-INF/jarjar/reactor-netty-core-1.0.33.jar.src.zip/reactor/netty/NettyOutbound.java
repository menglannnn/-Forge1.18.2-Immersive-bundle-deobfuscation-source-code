/*     */ package reactor.netty;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.DefaultFileRegion;
/*     */ import io.netty.handler.stream.ChunkedNioFile;
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.OpenOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.StandardOpenOption;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface NettyOutbound
/*     */   extends Publisher<Void>
/*     */ {
/*     */   default Mono<Void> neverComplete() {
/*  71 */     return then((Publisher<Void>)Mono.never()).then();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound send(Publisher<? extends ByteBuf> dataStream) {
/*  86 */     return send(dataStream, ReactorNetty.PREDICATE_BB_FLUSH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound sendByteArray(Publisher<? extends byte[]> dataStream) {
/* 115 */     return send((Publisher)ReactorNetty.publisherOrScalarMap(dataStream, Unpooled::wrappedBuffer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound sendFile(Path file) {
/*     */     try {
/* 141 */       return sendFile(file, 0L, Files.size(file));
/*     */     }
/* 143 */     catch (IOException e) {
/* 144 */       return then((Publisher<Void>)Mono.error(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound sendFile(Path file, long position, long count) {
/* 167 */     Objects.requireNonNull(file, "filepath");
/*     */     
/* 169 */     return sendUsing(() -> FileChannel.open(file, new OpenOption[] { StandardOpenOption.READ }), (c, fc) -> {
/*     */           if (ReactorNetty.mustChunkFileTransfer(c, file)) {
/*     */             ReactorNetty.addChunkedWriter(c);
/*     */ 
/*     */             
/*     */             try {
/*     */               return new ChunkedNioFile(fc, position, count, 1024);
/* 176 */             } catch (Exception ioe) {
/*     */               throw Exceptions.propagate(ioe);
/*     */             } 
/*     */           } 
/*     */           return new DefaultFileRegion(fc, position, count);
/*     */         }ReactorNetty.fileCloser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound sendFileChunked(Path file, long position, long count) {
/* 200 */     Objects.requireNonNull(file, "filepath");
/*     */     
/* 202 */     return sendUsing(() -> FileChannel.open(file, new OpenOption[] { StandardOpenOption.READ }), (c, fc) -> {
/*     */           ReactorNetty.addChunkedWriter(c);
/*     */ 
/*     */           
/*     */           try {
/*     */             return new ChunkedNioFile(fc, position, count, 1024);
/* 208 */           } catch (Exception e) {
/*     */             throw Exceptions.propagate(e);
/*     */           } 
/*     */         }ReactorNetty.fileCloser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound sendGroups(Publisher<? extends Publisher<? extends ByteBuf>> dataStreams) {
/* 227 */     return send(
/* 228 */         (Publisher<? extends ByteBuf>)Flux.from(dataStreams)
/* 229 */         .concatMap(p -> Flux.from(p).concatWith((Publisher)Mono.just(ReactorNetty.BOUNDARY)), 32), ReactorNetty.PREDICATE_GROUP_FLUSH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound sendObject(Publisher<?> dataStream) {
/* 246 */     return sendObject(dataStream, ReactorNetty.PREDICATE_FLUSH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound sendString(Publisher<? extends String> dataStream) {
/* 287 */     return sendString(dataStream, Charset.defaultCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound sendString(Publisher<? extends String> dataStream, Charset charset) {
/* 304 */     Objects.requireNonNull(charset, "charset");
/* 305 */     return send((Publisher)ReactorNetty.publisherOrScalarMap(dataStream, s -> {
/*     */             ByteBuf buffer = alloc().buffer();
/*     */             buffer.writeCharSequence(s, charset);
/*     */             return buffer;
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void subscribe(Subscriber<? super Void> s) {
/* 336 */     then().subscribe(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Void> then() {
/* 345 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound then(Publisher<Void> other) {
/* 358 */     return new ReactorNetty.OutboundThen(this, other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default NettyOutbound then(Publisher<Void> other, Runnable onCleanup) {
/* 372 */     return new ReactorNetty.OutboundThen(this, other, onCleanup);
/*     */   }
/*     */   
/*     */   ByteBufAllocator alloc();
/*     */   
/*     */   NettyOutbound send(Publisher<? extends ByteBuf> paramPublisher, Predicate<ByteBuf> paramPredicate);
/*     */   
/*     */   NettyOutbound sendObject(Publisher<?> paramPublisher, Predicate<Object> paramPredicate);
/*     */   
/*     */   NettyOutbound sendObject(Object paramObject);
/*     */   
/*     */   <S> NettyOutbound sendUsing(Callable<? extends S> paramCallable, BiFunction<? super Connection, ? super S, ?> paramBiFunction, Consumer<? super S> paramConsumer);
/*     */   
/*     */   NettyOutbound withConnection(Consumer<? super Connection> paramConsumer);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\NettyOutbound.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */