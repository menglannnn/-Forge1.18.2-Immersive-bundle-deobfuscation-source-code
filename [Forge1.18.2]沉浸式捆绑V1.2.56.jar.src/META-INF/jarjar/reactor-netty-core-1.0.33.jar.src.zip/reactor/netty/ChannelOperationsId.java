package reactor.netty;

public interface ChannelOperationsId {
  String asShortText();
  
  String asLongText();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\ChannelOperationsId.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */