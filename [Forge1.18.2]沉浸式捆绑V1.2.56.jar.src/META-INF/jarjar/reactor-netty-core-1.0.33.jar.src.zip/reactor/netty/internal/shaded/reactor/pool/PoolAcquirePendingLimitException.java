/*    */ package reactor.netty.internal.shaded.reactor.pool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PoolAcquirePendingLimitException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final int maxPending;
/*    */   
/*    */   public PoolAcquirePendingLimitException(int maxPending) {
/* 32 */     super("Pending acquire queue has reached its maximum size of " + maxPending);
/* 33 */     this.maxPending = maxPending;
/*    */   }
/*    */   
/*    */   public PoolAcquirePendingLimitException(int maxPending, String message) {
/* 37 */     super(message);
/* 38 */     this.maxPending = maxPending;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getAcquirePendingLimit() {
/* 45 */     return this.maxPending;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\PoolAcquirePendingLimitException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */