/*     */ package reactor.netty.internal.shaded.reactor.pool;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedDeque;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.function.BiPredicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.publisher.Signal;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleDequePool<POOLABLE>
/*     */   extends AbstractPool<POOLABLE>
/*     */ {
/*  64 */   private static final ConcurrentLinkedDeque TERMINATED = new ConcurrentLinkedDeque();
/*     */   
/*     */   final boolean idleResourceLeastRecentlyUsed;
/*     */   
/*     */   final boolean pendingBorrowerFirstInFirstServed;
/*     */   
/*     */   volatile Deque<QueuePooledRef<POOLABLE>> idleResources;
/*     */   
/*  72 */   protected static final AtomicReferenceFieldUpdater<SimpleDequePool, Deque> IDLE_RESOURCES = AtomicReferenceFieldUpdater.newUpdater(SimpleDequePool.class, Deque.class, "idleResources");
/*     */ 
/*     */   
/*     */   volatile int acquired;
/*     */   
/*  77 */   private static final AtomicIntegerFieldUpdater<SimpleDequePool> ACQUIRED = AtomicIntegerFieldUpdater.newUpdater(SimpleDequePool.class, "acquired");
/*     */ 
/*     */   
/*     */   volatile int wip;
/*     */ 
/*     */   
/*  83 */   private static final AtomicIntegerFieldUpdater<SimpleDequePool> WIP = AtomicIntegerFieldUpdater.newUpdater(SimpleDequePool.class, "wip");
/*     */ 
/*     */   
/*     */   volatile ConcurrentLinkedDeque<AbstractPool.Borrower<POOLABLE>> pending;
/*     */   
/*  88 */   private static final AtomicReferenceFieldUpdater<SimpleDequePool, ConcurrentLinkedDeque> PENDING = AtomicReferenceFieldUpdater.newUpdater(SimpleDequePool.class, ConcurrentLinkedDeque.class, "pending");
/*     */ 
/*     */   
/*     */   volatile int pendingSize;
/*     */   
/*  93 */   private static final AtomicIntegerFieldUpdater<SimpleDequePool> PENDING_SIZE = AtomicIntegerFieldUpdater.newUpdater(SimpleDequePool.class, "pendingSize");
/*     */ 
/*     */   
/*     */   volatile int idleSize;
/*     */   
/*  98 */   private static final AtomicIntegerFieldUpdater<SimpleDequePool> IDLE_SIZE = AtomicIntegerFieldUpdater.newUpdater(SimpleDequePool.class, "idleSize");
/*     */   
/*     */   Disposable evictionTask;
/*     */   
/*     */   SimpleDequePool(PoolConfig<POOLABLE> poolConfig, boolean pendingBorrowerFirstInFirstServed) {
/* 103 */     super(poolConfig, Loggers.getLogger(SimpleDequePool.class));
/* 104 */     this.idleResourceLeastRecentlyUsed = poolConfig.reuseIdleResourcesInLruOrder();
/* 105 */     this.pendingBorrowerFirstInFirstServed = pendingBorrowerFirstInFirstServed;
/* 106 */     this.pending = new ConcurrentLinkedDeque<>();
/* 107 */     this.idleResources = new ConcurrentLinkedDeque<>();
/* 108 */     recordInteractionTimestamp();
/*     */     
/* 110 */     scheduleEviction();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<PooledRef<POOLABLE>> acquire() {
/* 115 */     return new QueueBorrowerMono<>(this, Duration.ZERO);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<PooledRef<POOLABLE>> acquire(Duration timeout) {
/* 121 */     return new QueueBorrowerMono<>(this, timeout);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int acquiredSize() {
/* 127 */     return this.acquired;
/*     */   }
/*     */ 
/*     */   
/*     */   void scheduleEviction() {
/* 132 */     if (!this.poolConfig.evictInBackgroundInterval().isZero()) {
/* 133 */       long nanosEvictionInterval = this.poolConfig.evictInBackgroundInterval().toNanos();
/* 134 */       this.evictionTask = this.poolConfig.evictInBackgroundScheduler().schedule(this::evictInBackground, nanosEvictionInterval, TimeUnit.NANOSECONDS);
/*     */     } else {
/*     */       
/* 137 */       this.evictionTask = Disposables.disposed();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void evictInBackground() {
/* 143 */     Queue<QueuePooledRef<POOLABLE>> e = IDLE_RESOURCES.get(this);
/* 144 */     if (e == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 149 */     if (WIP.getAndIncrement(this) == 0) {
/* 150 */       if (this.pendingSize == 0) {
/* 151 */         BiPredicate<POOLABLE, PooledRefMetadata> evictionPredicate = this.poolConfig.evictionPredicate();
/*     */ 
/*     */         
/* 154 */         Iterator<QueuePooledRef<POOLABLE>> iterator = e.iterator();
/* 155 */         while (iterator.hasNext()) {
/* 156 */           QueuePooledRef<POOLABLE> pooledRef = iterator.next();
/* 157 */           if (evictionPredicate.test((POOLABLE)pooledRef.poolable, pooledRef))
/*     */           {
/* 159 */             if (pooledRef.markDestroy()) {
/* 160 */               recordInteractionTimestamp();
/* 161 */               iterator.remove();
/* 162 */               decrementIdle();
/* 163 */               destroyPoolable(pooledRef).subscribe(v -> {
/*     */                   
/*     */                   }destroyError -> this.logger.warn("Error while destroying resource in background eviction:", destroyError));
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/* 170 */       if (WIP.decrementAndGet(this) > 0) {
/* 171 */         drainLoop();
/*     */       }
/*     */     } 
/*     */     
/* 175 */     scheduleEviction();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeLater() {
/* 180 */     return Mono.defer(() -> {
/*     */           recordInteractionTimestamp();
/*     */           ConcurrentLinkedDeque<AbstractPool.Borrower<POOLABLE>> q = PENDING.getAndSet(this, TERMINATED);
/*     */           if (q != TERMINATED) {
/*     */             this.evictionTask.dispose();
/*     */             AbstractPool.Borrower<POOLABLE> p;
/*     */             while ((p = q.pollFirst()) != null) {
/*     */               p.fail(new PoolShutdownException());
/*     */             }
/*     */             PENDING_SIZE.set(this, 0);
/*     */             Queue<QueuePooledRef<POOLABLE>> e = IDLE_RESOURCES.getAndSet(this, null);
/*     */             if (e != null) {
/*     */               Mono<Void> destroyMonos = Mono.empty();
/*     */               while (!e.isEmpty()) {
/*     */                 QueuePooledRef<POOLABLE> ref = e.poll();
/*     */                 if (ref.markDestroy()) {
/*     */                   decrementIdle();
/*     */                   destroyMonos = destroyMonos.and((Publisher)destroyPoolable(ref));
/*     */                 } 
/*     */               } 
/*     */               return destroyMonos;
/*     */             } 
/*     */           } 
/*     */           return Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int idleSize() {
/* 223 */     return this.idleSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Integer> warmup() {
/* 228 */     if (this.poolConfig.allocationStrategy()
/* 229 */       .permitMinimum() > 0) {
/* 230 */       return Mono.deferContextual(ctx -> {
/*     */             recordInteractionTimestamp();
/*     */ 
/*     */ 
/*     */             
/*     */             int initSize = this.poolConfig.allocationStrategy().getPermits(0);
/*     */ 
/*     */ 
/*     */             
/*     */             Mono[] arrayOfMono = new Mono[initSize];
/*     */ 
/*     */ 
/*     */             
/*     */             for (int i = 0; i < initSize; i++) {
/*     */               long start = this.clock.millis();
/*     */ 
/*     */ 
/*     */               
/*     */               arrayOfMono[i] = this.poolConfig.allocator().contextWrite(ctx).doOnNext(()).doOnError(());
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/*     */             return Flux.concat((Publisher[])arrayOfMono).reduce(Integer.valueOf(0), ());
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 259 */     return Mono.just(Integer.valueOf(0));
/*     */   }
/*     */ 
/*     */   
/*     */   void decrementIdle() {
/* 264 */     if (IDLE_SIZE.decrementAndGet(this) < 0) {
/* 265 */       System.err.println("unexpected decrement below 0");
/*     */     }
/*     */   }
/*     */   
/*     */   void incrementIdle() {
/* 270 */     if (IDLE_SIZE.incrementAndGet(this) == 0) {
/* 271 */       System.err.println("unexpected increment from below 0");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void cancelAcquire(AbstractPool.Borrower<POOLABLE> borrower) {
/* 277 */     if (!isDisposed()) {
/* 278 */       ConcurrentLinkedDeque<AbstractPool.Borrower<POOLABLE>> q = this.pending;
/* 279 */       if (q.remove(borrower)) {
/* 280 */         PENDING_SIZE.decrementAndGet(this);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   QueuePooledRef<POOLABLE> createSlot(POOLABLE element) {
/* 286 */     return new QueuePooledRef<>(this, element);
/*     */   }
/*     */ 
/*     */   
/*     */   void doAcquire(AbstractPool.Borrower<POOLABLE> borrower) {
/* 291 */     if (isDisposed()) {
/* 292 */       borrower.fail(new PoolShutdownException());
/*     */       
/*     */       return;
/*     */     } 
/* 296 */     pendingOffer(borrower);
/* 297 */     drain();
/*     */   }
/*     */   
/*     */   void drain() {
/* 301 */     if (WIP.getAndIncrement(this) == 0) {
/* 302 */       drainLoop();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void drainLoop() {
/* 308 */     recordInteractionTimestamp();
/* 309 */     int maxPending = this.poolConfig.maxPending();
/*     */ 
/*     */     
/*     */     while (true) {
/* 313 */       Deque<QueuePooledRef<POOLABLE>> resources = IDLE_RESOURCES.get(this);
/*     */       
/* 315 */       ConcurrentLinkedDeque<AbstractPool.Borrower<POOLABLE>> borrowers = PENDING.get(this);
/* 316 */       if (resources == null || borrowers == TERMINATED) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 321 */       int borrowersCount = this.pendingSize;
/* 322 */       int resourcesCount = this.idleSize;
/*     */       
/* 324 */       if (borrowersCount != 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 331 */         if (resourcesCount > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 336 */           QueuePooledRef<POOLABLE> slot = this.idleResourceLeastRecentlyUsed ? resources.pollFirst() : resources.pollLast();
/* 337 */           if (slot == null) {
/*     */             continue;
/*     */           }
/* 340 */           decrementIdle();
/*     */           
/* 342 */           if (this.poolConfig.evictionPredicate().test(slot.poolable, slot)) {
/* 343 */             if (slot.markDestroy()) {
/* 344 */               destroyPoolable(slot).subscribe(null, error -> drain(), this::drain);
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 350 */           AbstractPool.Borrower<POOLABLE> borrower = pendingPoll(borrowers);
/* 351 */           if (borrower == null) {
/* 352 */             if (this.idleResourceLeastRecentlyUsed) {
/* 353 */               resources.offerFirst(slot);
/*     */             } else {
/*     */               
/* 356 */               resources.offerLast(slot);
/*     */             } 
/* 358 */             incrementIdle();
/*     */             
/*     */             continue;
/*     */           } 
/* 362 */           if (isDisposed()) {
/* 363 */             slot.invalidate().subscribe();
/* 364 */             borrower.fail(new PoolShutdownException());
/*     */             return;
/*     */           } 
/* 367 */           borrower.stopPendingCountdown();
/* 368 */           ACQUIRED.incrementAndGet(this);
/* 369 */           this.poolConfig.acquisitionScheduler()
/* 370 */             .schedule(() -> borrower.deliver(slot));
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 377 */           int permits = this.poolConfig.allocationStrategy().getPermits(1);
/* 378 */           if (permits <= 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 384 */             if (maxPending >= 0) {
/* 385 */               borrowersCount = this.pendingSize;
/* 386 */               int toCull = borrowersCount - maxPending;
/* 387 */               for (int i = 0; i < toCull; i++) {
/* 388 */                 AbstractPool.Borrower<POOLABLE> extraneous = pendingPoll(borrowers);
/* 389 */                 if (extraneous != null)
/*     */                 {
/* 391 */                   if (maxPending == 0) {
/* 392 */                     extraneous.fail(new PoolAcquirePendingLimitException(0, "No pending allowed and pool has reached allocation limit"));
/*     */                   } else {
/*     */                     
/* 395 */                     extraneous.fail(new PoolAcquirePendingLimitException(maxPending));
/*     */                   }
/*     */                 
/*     */                 }
/*     */               }
/*     */             
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 405 */             AbstractPool.Borrower<POOLABLE> borrower = pendingPoll(borrowers);
/* 406 */             if (borrower == null) {
/*     */               continue;
/*     */             }
/* 409 */             if (isDisposed()) {
/* 410 */               borrower.fail(new PoolShutdownException());
/*     */               return;
/*     */             } 
/* 413 */             borrower.stopPendingCountdown();
/* 414 */             long start = this.clock.millis();
/* 415 */             Mono<POOLABLE> allocator = allocatorWithScheduler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 433 */             Mono<POOLABLE> primary = allocator.doOnEach(sig -> { if (sig.isOnNext()) { POOLABLE newInstance = (POOLABLE)sig.get(); assert newInstance != null; ACQUIRED.incrementAndGet(this); this.metricsRecorder.recordAllocationSuccessAndLatency(this.clock.millis() - start); borrower.deliver(createSlot(newInstance)); } else if (sig.isOnError()) { Throwable error = sig.getThrowable(); assert error != null; this.metricsRecorder.recordAllocationFailureAndLatency(this.clock.millis() - start); this.poolConfig.allocationStrategy().returnPermits(1); borrower.fail(error); }  }).contextWrite((ContextView)borrower.currentContext());
/*     */             
/* 435 */             if (permits == 1) {
/*     */               
/* 437 */               primary.subscribe(alreadyPropagated -> {  }alreadyPropagatedOrLogged -> drain(), this::drain);
/*     */             
/*     */             }
/*     */             else {
/*     */ 
/*     */               
/* 443 */               int toWarmup = permits - 1;
/* 444 */               this.logger.debug("should warm up {} extra resources", new Object[] { Integer.valueOf(toWarmup) });
/*     */               
/* 446 */               long startWarmupIteration = this.clock.millis();
/*     */ 
/*     */               
/* 449 */               Flux<Void> warmupFlux = Flux.range(1, toWarmup).flatMap(i -> warmupMono(i.intValue(), toWarmup, startWarmupIteration, allocator));
/*     */               
/* 451 */               primary.onErrorResume(e -> Mono.empty())
/* 452 */                 .thenMany((Publisher)warmupFlux)
/* 453 */                 .subscribe(aVoid -> {
/*     */                   
/*     */                   }alreadyPropagatedOrLogged -> drain(), this::drain);
/*     */             } 
/*     */           } 
/*     */         }  } 
/* 459 */       if (WIP.decrementAndGet(this) == 0) {
/* 460 */         recordInteractionTimestamp();
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Mono<POOLABLE> allocatorWithScheduler() {
/* 467 */     Scheduler s = this.poolConfig.acquisitionScheduler();
/* 468 */     if (s != Schedulers.immediate()) {
/* 469 */       return this.poolConfig.allocator().publishOn(s);
/*     */     }
/* 471 */     return this.poolConfig.allocator();
/*     */   }
/*     */   
/*     */   Mono<Void> warmupMono(int index, int max, long startWarmupIteration, Mono<POOLABLE> allocator) {
/* 475 */     return allocator.flatMap(poolable -> {
/*     */           this.logger.debug("warmed up extra resource {}/{}", new Object[] { Integer.valueOf(index), Integer.valueOf(max) });
/*     */           
/*     */           this.metricsRecorder.recordAllocationSuccessAndLatency(this.clock.millis() - startWarmupIteration);
/*     */           
/*     */           if (!elementOffer((POOLABLE)poolable)) {
/*     */             QueuePooledRef<POOLABLE> tempRef = createSlot((POOLABLE)poolable);
/*     */             
/*     */             tempRef.markDestroy();
/*     */             return destroyPoolable(tempRef);
/*     */           } 
/*     */           return Mono.empty();
/* 487 */         }).onErrorResume(warmupError -> {
/*     */           this.logger.debug("failed to warm up extra resource {}/{}: {}", new Object[] { Integer.valueOf(index), Integer.valueOf(max), warmupError.toString() });
/*     */           this.metricsRecorder.recordAllocationFailureAndLatency(this.clock.millis() - startWarmupIteration);
/*     */           this.poolConfig.allocationStrategy().returnPermits(1);
/*     */           return Mono.empty();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int pendingAcquireSize() {
/* 501 */     return this.pendingSize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean elementOffer(POOLABLE element) {
/* 507 */     Deque<QueuePooledRef<POOLABLE>> irq = IDLE_RESOURCES.get(this);
/* 508 */     if (irq == null) {
/* 509 */       return false;
/*     */     }
/* 511 */     if (irq.offer(createSlot(element))) {
/* 512 */       incrementIdle();
/* 513 */       return true;
/*     */     } 
/* 515 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   final void maybeRecycleAndDrain(QueuePooledRef<POOLABLE> poolSlot, CoreSubscriber<? super Void> actual) {
/* 520 */     if (!isDisposed()) {
/* 521 */       recordInteractionTimestamp();
/*     */       
/* 523 */       if (!this.poolConfig.evictionPredicate().test(poolSlot.poolable, poolSlot)) {
/* 524 */         this.metricsRecorder.recordRecycled();
/*     */         
/* 526 */         Deque<QueuePooledRef<POOLABLE>> irq = IDLE_RESOURCES.get(this);
/* 527 */         if (irq != null) {
/* 528 */           QueuePooledRef<POOLABLE> slot = recycleSlot(poolSlot);
/* 529 */           boolean addedIdle = irq.offerLast(slot);
/* 530 */           if (addedIdle) {
/* 531 */             incrementIdle();
/*     */           }
/* 533 */           actual.onComplete();
/* 534 */           drain();
/* 535 */           if (isDisposed() && slot.markDestroy()) {
/* 536 */             if (addedIdle) {
/* 537 */               decrementIdle();
/*     */             }
/* 539 */             destroyPoolable(slot).subscribe();
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 547 */     if (poolSlot.markDestroy()) {
/* 548 */       destroyPoolable(poolSlot).subscribe(null, e -> {
/*     */             actual.onError(e);
/*     */ 
/*     */             
/*     */             drain();
/*     */           }() -> {
/*     */             actual.onComplete();
/*     */             
/*     */             drain();
/*     */           });
/*     */     } else {
/* 559 */       actual.onComplete();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void pendingOffer(AbstractPool.Borrower<POOLABLE> pending) {
/* 567 */     int maxPending = this.poolConfig.maxPending();
/* 568 */     ConcurrentLinkedDeque<AbstractPool.Borrower<POOLABLE>> pendingQueue = this.pending;
/* 569 */     if (pendingQueue == TERMINATED) {
/*     */       return;
/*     */     }
/* 572 */     int postOffer = this.pendingSize;
/* 573 */     if (pendingQueue.offerLast(pending)) {
/* 574 */       postOffer = PENDING_SIZE.incrementAndGet(this);
/*     */     }
/*     */     
/* 577 */     if (WIP.getAndIncrement(this) == 0) {
/* 578 */       if (maxPending >= 0 && postOffer > maxPending && this.idleSize == 0 && this.poolConfig.allocationStrategy().estimatePermitCount() == 0) {
/*     */         
/* 580 */         AbstractPool.Borrower<POOLABLE> toCull = pendingQueue.pollLast();
/* 581 */         if (toCull != null) {
/* 582 */           PENDING_SIZE.decrementAndGet(this);
/* 583 */           if (maxPending == 0) {
/* 584 */             toCull.fail(new PoolAcquirePendingLimitException(0, "No pending allowed and pool has reached allocation limit"));
/*     */           } else {
/*     */             
/* 587 */             toCull.fail(new PoolAcquirePendingLimitException(maxPending));
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 592 */         if (WIP.decrementAndGet(this) > 0) {
/* 593 */           drainLoop();
/*     */         }
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 600 */       drainLoop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   AbstractPool.Borrower<POOLABLE> pendingPoll(Deque<AbstractPool.Borrower<POOLABLE>> borrowers) {
/* 611 */     AbstractPool.Borrower<POOLABLE> b = this.pendingBorrowerFirstInFirstServed ? borrowers.pollFirst() : borrowers.pollLast();
/* 612 */     if (b != null) {
/* 613 */       PENDING_SIZE.decrementAndGet(this);
/*     */     }
/* 615 */     return b;
/*     */   }
/*     */   
/*     */   QueuePooledRef<POOLABLE> recycleSlot(QueuePooledRef<POOLABLE> slot) {
/* 619 */     return new QueuePooledRef<>(slot);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 624 */     return (PENDING.get(this) == TERMINATED || IDLE_RESOURCES.get(this) == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class QueuePooledRef<T>
/*     */     extends AbstractPool.AbstractPooledRef<T>
/*     */   {
/*     */     final SimpleDequePool<T> pool;
/*     */ 
/*     */ 
/*     */     
/*     */     QueuePooledRef(SimpleDequePool<T> pool, T poolable) {
/* 638 */       super(poolable, pool.metricsRecorder, pool.clock);
/* 639 */       this.pool = pool;
/*     */     }
/*     */     
/*     */     QueuePooledRef(QueuePooledRef<T> oldRef) {
/* 643 */       super(oldRef);
/* 644 */       this.pool = oldRef.pool;
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> invalidate() {
/* 649 */       return Mono.defer(() -> {
/*     */             if (markSoftInvalidate()) {
/*     */               SimpleDequePool.ACQUIRED.decrementAndGet((SimpleDequePool)this.pool);
/*     */               return this.pool.destroyPoolable(this).doFinally(());
/*     */             } 
/*     */             return Mono.empty();
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Mono<Void> release() {
/* 665 */       return Mono.defer(() -> {
/*     */             Publisher<Void> cleaner;
/*     */ 
/*     */ 
/*     */             
/*     */             if (STATE.get(this) == 2) {
/*     */               return Mono.empty();
/*     */             }
/*     */ 
/*     */             
/*     */             if (this.pool.isDisposed()) {
/*     */               SimpleDequePool.ACQUIRED.decrementAndGet((SimpleDequePool)this.pool);
/*     */ 
/*     */               
/*     */               return markDestroy() ? this.pool.destroyPoolable(this) : Mono.empty();
/*     */             } 
/*     */ 
/*     */             
/*     */             try {
/*     */               cleaner = this.pool.poolConfig.releaseHandler().apply(this.poolable);
/* 685 */             } catch (Throwable releaseError) {
/*     */               SimpleDequePool.ACQUIRED.decrementAndGet((SimpleDequePool)this.pool);
/*     */               return markDestroy() ? this.pool.destroyPoolable(this).onErrorResume(()).then(Mono.error(new IllegalStateException("Couldn't apply releaseHandler, resource destroyed", releaseError))).doFinally(()) : Mono.error(new IllegalStateException("Couldn't apply releaseHandler", releaseError));
/*     */             } 
/*     */             return new SimpleDequePool.QueuePoolRecyclerMono<>(cleaner, this);
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class QueueBorrowerMono<T>
/*     */     extends Mono<PooledRef<T>>
/*     */   {
/*     */     final SimpleDequePool<T> parent;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final Duration acquireTimeout;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     QueueBorrowerMono(SimpleDequePool<T> pool, Duration acquireTimeout) {
/* 712 */       this.parent = pool;
/* 713 */       this.acquireTimeout = acquireTimeout;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super PooledRef<T>> actual) {
/* 718 */       Objects.requireNonNull(actual, "subscribing with null");
/* 719 */       AbstractPool.Borrower<T> borrower = new AbstractPool.Borrower<>((CoreSubscriber)actual, this.parent, this.acquireTimeout);
/* 720 */       actual.onSubscribe(borrower);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class QueuePoolRecyclerInner<T>
/*     */     implements CoreSubscriber<Void>, Scannable, Subscription
/*     */   {
/*     */     final CoreSubscriber<? super Void> actual;
/*     */     
/*     */     final SimpleDequePool<T> pool;
/*     */     
/*     */     SimpleDequePool.QueuePooledRef<T> pooledRef;
/*     */     
/*     */     Subscription upstream;
/*     */     long start;
/*     */     volatile int once;
/*     */     
/*     */     QueuePoolRecyclerInner(CoreSubscriber<? super Void> actual, SimpleDequePool.QueuePooledRef<T> pooledRef) {
/* 739 */       this.actual = actual;
/* 740 */       this.pooledRef = Objects.<SimpleDequePool.QueuePooledRef<T>>requireNonNull(pooledRef, "pooledRef");
/* 741 */       this.pool = pooledRef.pool;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void cancel() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 751 */       SimpleDequePool.QueuePooledRef<T> slot = this.pooledRef;
/* 752 */       this.pooledRef = null;
/* 753 */       if (slot == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 759 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 760 */         SimpleDequePool.ACQUIRED.decrementAndGet((SimpleDequePool)this.pool);
/*     */       }
/*     */       
/* 763 */       this.pool.metricsRecorder.recordResetLatency(this.pool.clock.millis() - this.start);
/*     */       
/* 765 */       this.pool.maybeRecycleAndDrain(slot, this.actual);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable throwable) {
/* 770 */       SimpleDequePool.QueuePooledRef<T> slot = this.pooledRef;
/* 771 */       this.pooledRef = null;
/* 772 */       if (slot == null) {
/* 773 */         Operators.onErrorDropped(throwable, this.actual.currentContext());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 779 */       if (ONCE.compareAndSet(this, 0, 1)) {
/* 780 */         SimpleDequePool.ACQUIRED.decrementAndGet((SimpleDequePool)this.pool);
/*     */       }
/*     */ 
/*     */       
/* 784 */       this.pool.metricsRecorder.recordResetLatency(this.pool.clock.millis() - this.start);
/*     */       
/* 786 */       if (slot.markDestroy()) {
/* 787 */         this.pool.destroyPoolable(slot)
/* 788 */           .subscribe(null, null, this.pool::drain);
/*     */       }
/*     */       
/* 791 */       this.actual.onError(throwable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Void o) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 801 */       if (Operators.validate(this.upstream, s)) {
/* 802 */         this.start = this.pool.clock.millis();
/* 803 */         this.upstream = s;
/* 804 */         this.actual.onSubscribe(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long l) {
/* 810 */       if (Operators.validate(l)) {
/* 811 */         this.upstream.request(l);
/*     */         
/* 813 */         if (ONCE.compareAndSet(this, 0, 1)) {
/* 814 */           SimpleDequePool.ACQUIRED.decrementAndGet((SimpleDequePool)this.pool);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 822 */       if (key == Scannable.Attr.ACTUAL) {
/* 823 */         return this.actual;
/*     */       }
/* 825 */       if (key == Scannable.Attr.PARENT) {
/* 826 */         return this.upstream;
/*     */       }
/* 828 */       if (key == Scannable.Attr.CANCELLED) {
/* 829 */         return Boolean.valueOf(false);
/*     */       }
/* 831 */       if (key == Scannable.Attr.TERMINATED) {
/* 832 */         return Boolean.valueOf((this.pooledRef == null));
/*     */       }
/* 834 */       if (key == Scannable.Attr.BUFFERED) {
/* 835 */         return Integer.valueOf((this.pooledRef == null) ? 0 : 1);
/*     */       }
/* 837 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 841 */     static final AtomicIntegerFieldUpdater<QueuePoolRecyclerInner> ONCE = AtomicIntegerFieldUpdater.newUpdater(QueuePoolRecyclerInner.class, "once");
/*     */   }
/*     */   
/*     */   private static final class QueuePoolRecyclerMono<T>
/*     */     extends Mono<Void>
/*     */     implements Scannable {
/*     */     final Publisher<Void> source;
/*     */     final AtomicReference<SimpleDequePool.QueuePooledRef<T>> slotRef;
/*     */     
/*     */     QueuePoolRecyclerMono(Publisher<Void> source, SimpleDequePool.QueuePooledRef<T> poolSlot) {
/* 851 */       this.source = source;
/* 852 */       this.slotRef = new AtomicReference<>(poolSlot);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 859 */       if (key == Scannable.Attr.PREFETCH) {
/* 860 */         return Integer.valueOf(2147483647);
/*     */       }
/* 862 */       if (key == Scannable.Attr.PARENT) {
/* 863 */         return this.source;
/*     */       }
/* 865 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void subscribe(CoreSubscriber<? super Void> actual) {
/* 870 */       SimpleDequePool.QueuePooledRef<T> slot = this.slotRef.getAndSet(null);
/* 871 */       if (slot == null || !slot.markReleased()) {
/* 872 */         Operators.complete((Subscriber)actual);
/*     */       } else {
/*     */         
/* 875 */         SimpleDequePool.QueuePoolRecyclerInner<T> qpr = new SimpleDequePool.QueuePoolRecyclerInner<>(actual, slot);
/*     */         
/* 877 */         this.source.subscribe((Subscriber)qpr);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\SimpleDequePool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */