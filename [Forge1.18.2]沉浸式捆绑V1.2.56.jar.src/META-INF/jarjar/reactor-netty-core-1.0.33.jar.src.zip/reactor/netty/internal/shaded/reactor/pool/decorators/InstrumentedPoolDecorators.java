/*    */ package reactor.netty.internal.shaded.reactor.pool.decorators;
/*    */ 
/*    */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InstrumentedPoolDecorators
/*    */ {
/*    */   public static <T> GracefulShutdownInstrumentedPool<T> gracefulShutdown(InstrumentedPool<T> pool) {
/* 42 */     return new GracefulShutdownInstrumentedPool<>(pool);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\decorators\InstrumentedPoolDecorators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */