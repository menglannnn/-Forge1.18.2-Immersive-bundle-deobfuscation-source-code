/*     */ package reactor.netty.internal.shaded.reactor.pool.introspection;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Objects;
/*     */ import java.util.Random;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.netty.internal.shaded.reactor.pool.AllocationStrategy;
/*     */ import reactor.netty.internal.shaded.reactor.pool.Pool;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PoolBuilder;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PoolConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SamplingAllocationStrategy
/*     */   implements AllocationStrategy
/*     */ {
/*     */   public final AllocationStrategy delegate;
/*     */   public final LinkedList<Throwable> gettingSamples;
/*     */   public final double gettingSamplingRate;
/*     */   final BitSet gettingSampleDecisions;
/*     */   public final LinkedList<Throwable> returningSamples;
/*     */   public final double returningSamplingRate;
/*     */   final BitSet returningSampleDecisions;
/*     */   
/*     */   static AllocationStrategy sizeBetweenHelper(int min, int max) {
/*  48 */     AllocationStrategy[] as = new AllocationStrategy[1];
/*  49 */     PoolBuilder.from((Publisher)Mono.empty())
/*  50 */       .sizeBetween(min, max)
/*  51 */       .build(config -> {
/*     */           as[0] = config.allocationStrategy();
/*     */           return null;
/*     */         });
/*  55 */     return as[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SamplingAllocationStrategy sizeBetweenWithSampling(int min, int max, double getPermitsSamplingRate, double returnPermitsSamplingRate) {
/*  69 */     return new SamplingAllocationStrategy(sizeBetweenHelper(min, max), getPermitsSamplingRate, returnPermitsSamplingRate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SamplingAllocationStrategy withSampling(AllocationStrategy delegate, double getPermitsSamplingRate, double returnPermitsSamplingRate) {
/*  87 */     return new SamplingAllocationStrategy(delegate, getPermitsSamplingRate, returnPermitsSamplingRate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   long countGetting = 0L;
/* 118 */   long countReturning = 0L;
/*     */   
/*     */   SamplingAllocationStrategy(AllocationStrategy delegate, double gettingSamplingRate, double returningSamplingRate) {
/* 121 */     if (gettingSamplingRate < 0.0D || gettingSamplingRate > 1.0D) {
/* 122 */       throw new IllegalArgumentException("gettingSamplingRate must be between 0d and 1d (percentage)");
/*     */     }
/* 124 */     if (returningSamplingRate < 0.0D || returningSamplingRate > 1.0D) {
/* 125 */       throw new IllegalArgumentException("returningSamplingRate must be between 0d and 1d (percentage)");
/*     */     }
/* 127 */     this.delegate = Objects.<AllocationStrategy>requireNonNull(delegate, "delegate");
/*     */     
/* 129 */     this.gettingSamples = new LinkedList<>();
/* 130 */     this.gettingSamplingRate = gettingSamplingRate;
/* 131 */     int percentOfGetting = (int)(this.gettingSamplingRate * 100.0D);
/* 132 */     this.gettingSampleDecisions = sampleBitSet(percentOfGetting);
/*     */     
/* 134 */     this.returningSamples = new LinkedList<>();
/* 135 */     this.returningSamplingRate = returningSamplingRate;
/* 136 */     int percentOfReturning = (int)(this.returningSamplingRate * 100.0D);
/* 137 */     this.returningSampleDecisions = sampleBitSet(percentOfReturning);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BitSet sampleBitSet(int selectedOutOf100) {
/* 148 */     int size = 100;
/* 149 */     Random rnd = new Random();
/* 150 */     BitSet result = new BitSet(size);
/* 151 */     int[] chosen = new int[selectedOutOf100];
/*     */     int i;
/* 153 */     for (i = 0; i < selectedOutOf100; i++) {
/* 154 */       chosen[i] = i;
/* 155 */       result.set(i);
/*     */     } 
/* 157 */     for (; i < size; i++) {
/* 158 */       int j = rnd.nextInt(i + 1);
/* 159 */       if (j < selectedOutOf100) {
/* 160 */         result.clear(chosen[j]);
/* 161 */         result.set(i);
/* 162 */         chosen[j] = i;
/*     */       } 
/*     */     } 
/* 165 */     return result;
/*     */   }
/*     */   void sampleGetting(int desired) {
/*     */     boolean doSample;
/* 169 */     if (this.gettingSamplingRate == 0.0D) {
/*     */       return;
/*     */     }
/* 172 */     long c = this.countGetting++;
/*     */     
/* 174 */     if (this.gettingSamplingRate == 1.0D) {
/* 175 */       doSample = true;
/*     */     } else {
/*     */       
/* 178 */       long cMod = c % 100L;
/* 179 */       doSample = this.gettingSampleDecisions.get((int)cMod);
/*     */     } 
/*     */     
/* 182 */     if (doSample)
/* 183 */       synchronized (this.gettingSamples) {
/* 184 */         this.gettingSamples.add(new RuntimeException("sample #" + c + ", getPermits(" + desired + ")"));
/*     */       }  
/*     */   }
/*     */   
/*     */   void sampleReturning(int returned) {
/*     */     boolean doSample;
/* 190 */     if (this.returningSamplingRate == 0.0D) {
/*     */       return;
/*     */     }
/* 193 */     long c = this.countReturning++;
/*     */     
/* 195 */     if (this.returningSamplingRate == 1.0D) {
/* 196 */       doSample = true;
/*     */     } else {
/*     */       
/* 199 */       long cMod = c % 100L;
/* 200 */       doSample = this.returningSampleDecisions.get((int)cMod);
/*     */     } 
/*     */     
/* 203 */     if (doSample) {
/* 204 */       synchronized (this.gettingSamples) {
/* 205 */         this.returningSamples.add(new RuntimeException("sample #" + c + ", returnPermits(" + returned + ") while granted=" + permitGranted()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPermits(int desired) {
/* 212 */     sampleGetting(desired);
/* 213 */     return this.delegate.getPermits(desired);
/*     */   }
/*     */ 
/*     */   
/*     */   public void returnPermits(int returned) {
/*     */     try {
/* 219 */       this.delegate.returnPermits(returned);
/*     */       
/* 221 */       sampleReturning(returned);
/*     */     }
/* 223 */     catch (Throwable permitError) {
/* 224 */       RuntimeException cause = Exceptions.multiple(this.gettingSamples);
/* 225 */       throw new IllegalArgumentException(
/* 226 */           String.format("Return permits failed, see cause for %d getPermits samples (%d%% of %d calls) and %d returnPermits samples (%d%% of %d calls). Reason: %s", new Object[] {
/* 227 */               Integer.valueOf(this.gettingSamples.size()), Integer.valueOf((int)(this.gettingSamplingRate * 100.0D)), Long.valueOf(this.countGetting), 
/* 228 */               Integer.valueOf(this.returningSamples.size()), Integer.valueOf((int)(this.returningSamplingRate * 100.0D)), Long.valueOf(this.countReturning), permitError
/* 229 */               .getMessage()
/*     */             }), cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int estimatePermitCount() {
/* 236 */     return this.delegate.estimatePermitCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public int permitGranted() {
/* 241 */     return this.delegate.permitGranted();
/*     */   }
/*     */ 
/*     */   
/*     */   public int permitMinimum() {
/* 246 */     return this.delegate.permitMinimum();
/*     */   }
/*     */ 
/*     */   
/*     */   public int permitMaximum() {
/* 251 */     return this.delegate.permitMaximum();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\introspection\SamplingAllocationStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */