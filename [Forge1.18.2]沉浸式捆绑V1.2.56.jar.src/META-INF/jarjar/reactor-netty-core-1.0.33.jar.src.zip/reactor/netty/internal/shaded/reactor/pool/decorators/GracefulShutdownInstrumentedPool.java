/*     */ package reactor.netty.internal.shaded.reactor.pool.decorators;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.netty.internal.shaded.reactor.pool.InstrumentedPool;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PoolConfig;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PoolShutdownException;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PooledRef;
/*     */ import reactor.netty.internal.shaded.reactor.pool.PooledRefMetadata;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GracefulShutdownInstrumentedPool<T>
/*     */   implements InstrumentedPool<T>
/*     */ {
/*  55 */   private static final Logger LOGGER = Loggers.getLogger(GracefulShutdownInstrumentedPool.class);
/*     */   
/*     */   final AtomicLong acquireTracker;
/*     */   final AtomicInteger isGracefulShutdown;
/*     */   final Sinks.Empty<Void> gracefulNotifier;
/*     */   final InstrumentedPool<T> originalPool;
/*     */   final Scheduler timeoutScheduler;
/*     */   Disposable timeout;
/*     */   
/*     */   GracefulShutdownInstrumentedPool(InstrumentedPool<T> originalPool) {
/*     */     Scheduler forTimeout;
/*  66 */     this.originalPool = Objects.<InstrumentedPool<T>>requireNonNull(originalPool, "originalPool");
/*  67 */     this.acquireTracker = new AtomicLong();
/*  68 */     this.isGracefulShutdown = new AtomicInteger();
/*  69 */     this.gracefulNotifier = Sinks.empty();
/*     */ 
/*     */ 
/*     */     
/*  73 */     this.timeout = Disposables.single();
/*     */ 
/*     */     
/*     */     try {
/*  77 */       forTimeout = originalPool.config().evictInBackgroundScheduler();
/*     */       
/*  79 */       if (forTimeout == Schedulers.immediate()) {
/*  80 */         forTimeout = Schedulers.parallel();
/*     */       }
/*     */     }
/*  83 */     catch (UnsupportedOperationException uoe) {
/*     */       
/*  85 */       forTimeout = Schedulers.parallel();
/*     */     } 
/*  87 */     this.timeoutScheduler = forTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedPool<T> getOriginalPool() {
/*  98 */     return this.originalPool;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<PooledRef<T>> acquire() {
/* 103 */     if (this.isGracefulShutdown.get() > 0) {
/* 104 */       return Mono.error((Throwable)new PoolShutdownException("The pool is being gracefully shut down and won't accept new acquire calls"));
/*     */     }
/*     */     
/* 107 */     return Mono.defer(() -> {
/*     */           this.acquireTracker.incrementAndGet();
/*     */           return this.originalPool.acquire().doFinally(()).map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<PooledRef<T>> acquire(Duration timeout) {
/* 125 */     if (this.isGracefulShutdown.get() > 0) {
/* 126 */       return Mono.error((Throwable)new PoolShutdownException("The pool is being gracefully shut down and won't accept new acquire calls"));
/*     */     }
/*     */     
/* 129 */     return Mono.defer(() -> {
/*     */           this.acquireTracker.incrementAndGet();
/*     */           return this.originalPool.acquire(timeout).doFinally(()).map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeGracefully(Duration gracefulTimeout) {
/* 175 */     if (this.isGracefulShutdown.compareAndSet(0, 1)) {
/*     */       
/* 177 */       if (this.acquireTracker.get() == 0L && this.isGracefulShutdown.compareAndSet(1, 2)) {
/* 178 */         this.originalPool
/* 179 */           .disposeLater()
/* 180 */           .doFinally(st -> this.gracefulNotifier.tryEmitEmpty())
/*     */ 
/*     */ 
/*     */           
/* 184 */           .subscribe(v -> {
/*     */             
/* 186 */             }shutdownError -> LOGGER.warn("Error during the actual shutdown on idle pool", shutdownError)); return this.gracefulNotifier.asMono();
/*     */       } 
/*     */ 
/*     */       
/* 190 */       this.timeout = this.timeoutScheduler.schedule(() -> { if (this.isGracefulShutdown.compareAndSet(1, 2)) this.originalPool.disposeLater().doFinally(()).subscribe((), ());  }gracefulTimeout
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 204 */           .toMillis(), TimeUnit.MILLISECONDS);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 209 */     return this.gracefulNotifier.asMono();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGracefullyShuttingDown() {
/* 218 */     return (this.isGracefulShutdown.get() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInGracePeriod() {
/* 232 */     return (this.isGracefulShutdown.get() == 1);
/*     */   }
/*     */   
/*     */   private Mono<Void> tryGracefulDone() {
/* 236 */     if (this.isGracefulShutdown.compareAndSet(1, 2)) {
/*     */       
/* 238 */       this.timeout.dispose();
/* 239 */       return this.originalPool.disposeLater()
/* 240 */         .doFinally(st -> this.gracefulNotifier.emitEmpty(Sinks.EmitFailureHandler.FAIL_FAST));
/*     */     } 
/* 242 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public InstrumentedPool.PoolMetrics metrics() {
/* 247 */     return this.originalPool.metrics();
/*     */   }
/*     */ 
/*     */   
/*     */   public PoolConfig<T> config() {
/* 252 */     return this.originalPool.config();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Integer> warmup() {
/* 257 */     return this.originalPool.warmup();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> disposeLater() {
/* 262 */     return this.originalPool.disposeLater();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDisposed() {
/* 267 */     return this.originalPool.isDisposed();
/*     */   }
/*     */   
/*     */   final class GracefulRef
/*     */     extends AtomicBoolean implements PooledRef<T> {
/*     */     final PooledRef<T> originalRef;
/*     */     
/*     */     public GracefulRef(PooledRef<T> originalRef) {
/* 275 */       this.originalRef = originalRef;
/*     */     }
/*     */ 
/*     */     
/*     */     public T poolable() {
/* 280 */       return (T)this.originalRef.poolable();
/*     */     }
/*     */ 
/*     */     
/*     */     public PooledRefMetadata metadata() {
/* 285 */       return this.originalRef.metadata();
/*     */     }
/*     */ 
/*     */     
/*     */     public Mono<Void> invalidate() {
/* 290 */       if (get()) {
/* 291 */         return Mono.empty();
/*     */       }
/* 293 */       return Mono.defer(() -> {
/*     */             if (compareAndSet(false, true)) {
/*     */               long remaining = GracefulShutdownInstrumentedPool.this.acquireTracker.decrementAndGet();
/*     */               if (remaining > 0L) {
/*     */                 return this.originalRef.invalidate();
/*     */               }
/*     */               if (remaining == 0L) {
/*     */                 return this.originalRef.invalidate().then(Mono.defer(()));
/*     */               }
/*     */             } 
/*     */             return Mono.empty();
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Mono<Void> release() {
/* 310 */       if (get()) {
/* 311 */         return Mono.empty();
/*     */       }
/* 313 */       return Mono.defer(() -> {
/*     */             if (compareAndSet(false, true)) {
/*     */               long remaining = GracefulShutdownInstrumentedPool.this.acquireTracker.decrementAndGet();
/*     */               if (remaining > 0L)
/*     */                 return this.originalRef.release(); 
/*     */               if (remaining == 0L)
/*     */                 return this.originalRef.release().then(Mono.defer(())); 
/*     */             } 
/*     */             return Mono.empty();
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\decorators\GracefulShutdownInstrumentedPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */