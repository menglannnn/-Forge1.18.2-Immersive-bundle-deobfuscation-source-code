/*     */ package reactor.netty.internal.shaded.reactor.pool;
/*     */ 
/*     */ import java.time.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface InstrumentedPool<POOLABLE>
/*     */   extends Pool<POOLABLE>
/*     */ {
/*     */   PoolMetrics metrics();
/*     */   
/*     */   public static interface PoolMetrics
/*     */   {
/*     */     int acquiredSize();
/*     */     
/*     */     int allocatedSize();
/*     */     
/*     */     int idleSize();
/*     */     
/*     */     int pendingAcquireSize();
/*     */     
/*     */     default long secondsSinceLastInteraction() {
/* 102 */       return -1L;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default boolean isInactiveForMoreThan(Duration duration) {
/* 115 */       return (acquiredSize() == 0 && idleSize() == 0 && pendingAcquireSize() == 0 && allocatedSize() == 0 && 
/* 116 */         secondsSinceLastInteraction() >= duration.toMillis());
/*     */     }
/*     */     
/*     */     int getMaxAllocatedSize();
/*     */     
/*     */     int getMaxPendingAcquireSize();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\InstrumentedPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */