/*     */ package reactor.netty.internal.shaded.reactor.pool;
/*     */ 
/*     */ import java.time.Clock;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoolBuilder<T, CONF extends PoolConfig<T>>
/*     */ {
/*     */   final Mono<T> allocator;
/*     */   final Function<PoolConfig<T>, CONF> configModifier;
/*     */   
/*     */   public static <T> PoolBuilder<T, PoolConfig<T>> from(Publisher<? extends T> allocator) {
/*  63 */     Mono<T> source = Mono.from(allocator);
/*  64 */     return new PoolBuilder<>(source, Function.identity());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  69 */   int maxPending = -1;
/*  70 */   AllocationStrategy allocationStrategy = null;
/*  71 */   Function<T, ? extends Publisher<Void>> releaseHandler = (Function)noopHandler();
/*  72 */   Function<T, ? extends Publisher<Void>> destroyHandler = (Function)noopHandler();
/*  73 */   BiPredicate<T, PooledRefMetadata> evictionPredicate = neverPredicate();
/*  74 */   Duration evictionBackgroundInterval = Duration.ZERO;
/*  75 */   Scheduler evictionBackgroundScheduler = Schedulers.immediate();
/*  76 */   Scheduler acquisitionScheduler = Schedulers.immediate();
/*  77 */   Clock clock = Clock.systemUTC();
/*  78 */   PoolMetricsRecorder metricsRecorder = NoOpPoolMetricsRecorder.INSTANCE;
/*     */   boolean idleLruOrder = true;
/*  80 */   BiFunction<Runnable, Duration, Disposable> pendingAcquireTimer = DEFAULT_PENDING_ACQUIRE_TIMER;
/*     */   
/*     */   PoolBuilder(Mono<T> allocator, Function<PoolConfig<T>, CONF> configModifier) {
/*  83 */     this.allocator = allocator;
/*  84 */     this.configModifier = configModifier;
/*     */   }
/*     */   
/*     */   PoolBuilder(PoolBuilder<T, ?> source, Function<PoolConfig<T>, CONF> configModifier) {
/*  88 */     this.configModifier = configModifier;
/*     */     
/*  90 */     this.allocator = source.allocator;
/*  91 */     this.maxPending = source.maxPending;
/*  92 */     this.allocationStrategy = source.allocationStrategy;
/*  93 */     this.releaseHandler = source.releaseHandler;
/*  94 */     this.destroyHandler = source.destroyHandler;
/*  95 */     this.evictionPredicate = source.evictionPredicate;
/*  96 */     this.evictionBackgroundInterval = source.evictionBackgroundInterval;
/*  97 */     this.evictionBackgroundScheduler = source.evictionBackgroundScheduler;
/*  98 */     this.acquisitionScheduler = source.acquisitionScheduler;
/*  99 */     this.metricsRecorder = source.metricsRecorder;
/* 100 */     this.clock = source.clock;
/* 101 */     this.idleLruOrder = source.idleLruOrder;
/* 102 */     this.pendingAcquireTimer = source.pendingAcquireTimer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> acquisitionScheduler(Scheduler acquisitionScheduler) {
/* 116 */     this.acquisitionScheduler = Objects.<Scheduler>requireNonNull(acquisitionScheduler, "acquisitionScheduler");
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> pendingAcquireTimer(BiFunction<Runnable, Duration, Disposable> pendingAcquireTimer) {
/* 132 */     this.pendingAcquireTimer = Objects.<BiFunction<Runnable, Duration, Disposable>>requireNonNull(pendingAcquireTimer, "pendingAcquireTimer");
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> allocationStrategy(AllocationStrategy allocationStrategy) {
/* 151 */     this.allocationStrategy = Objects.<AllocationStrategy>requireNonNull(allocationStrategy, "allocationStrategy");
/* 152 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> destroyHandler(Function<T, ? extends Publisher<Void>> destroyHandler) {
/* 166 */     this.destroyHandler = Objects.<Function<T, ? extends Publisher<Void>>>requireNonNull(destroyHandler, "destroyHandler");
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> evictionIdle(Duration maxIdleTime) {
/* 185 */     return evictionPredicate(idlePredicate(maxIdleTime));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> evictionPredicate(BiPredicate<T, PooledRefMetadata> evictionPredicate) {
/* 211 */     this.evictionPredicate = Objects.<BiPredicate<T, PooledRefMetadata>>requireNonNull(evictionPredicate, "evictionPredicate");
/* 212 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> evictInBackgroundDisabled() {
/* 224 */     return evictInBackground(Duration.ZERO);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> evictInBackground(Duration evictionInterval) {
/* 243 */     if (evictionInterval == Duration.ZERO) {
/* 244 */       this.evictionBackgroundInterval = Duration.ZERO;
/* 245 */       this.evictionBackgroundScheduler = Schedulers.immediate();
/* 246 */       return this;
/*     */     } 
/* 248 */     return evictInBackground(evictionInterval, Schedulers.parallel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> evictInBackground(Duration evictionInterval, Scheduler reaperTaskScheduler) {
/* 267 */     this.evictionBackgroundInterval = evictionInterval;
/* 268 */     this.evictionBackgroundScheduler = reaperTaskScheduler;
/* 269 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> maxPendingAcquire(int maxPending) {
/* 285 */     this.maxPending = maxPending;
/* 286 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> maxPendingAcquireUnbounded() {
/* 299 */     this.maxPending = -1;
/* 300 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> clock(Clock clock) {
/* 316 */     this.clock = Objects.<Clock>requireNonNull(clock, "clock");
/* 317 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> metricsRecorder(PoolMetricsRecorder recorder) {
/* 327 */     this.metricsRecorder = Objects.<PoolMetricsRecorder>requireNonNull(recorder, "recorder");
/* 328 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> releaseHandler(Function<T, ? extends Publisher<Void>> releaseHandler) {
/* 342 */     this.releaseHandler = Objects.<Function<T, ? extends Publisher<Void>>>requireNonNull(releaseHandler, "releaseHandler");
/* 343 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> sizeBetween(int min, int max) {
/* 361 */     return allocationStrategy(new AllocationStrategies.SizeBasedAllocationStrategy(min, max));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> sizeUnbounded() {
/* 376 */     return allocationStrategy(new AllocationStrategies.UnboundedAllocationStrategy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> idleResourceReuseLruOrder() {
/* 387 */     return idleResourceReuseOrder(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> idleResourceReuseMruOrder() {
/* 398 */     return idleResourceReuseOrder(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolBuilder<T, CONF> idleResourceReuseOrder(boolean isLru) {
/* 415 */     this.idleLruOrder = isLru;
/* 416 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <CONF2 extends PoolConfig<T>> PoolBuilder<T, CONF2> extraConfiguration(Function<? super CONF, CONF2> configModifier) {
/* 430 */     return new PoolBuilder(this, this.configModifier.andThen(configModifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedPool<T> buildPool() {
/* 439 */     return new SimpleDequePool<>((PoolConfig<T>)buildConfig(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <P extends InstrumentedPool<T>> P buildPoolAndDecorateWith(Function<? super InstrumentedPool<T>, P> decorator) {
/* 451 */     return decorator.apply(buildPool());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InstrumentedPool<T> lifo() {
/* 468 */     return new SimpleDequePool<>((PoolConfig<T>)buildConfig(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InstrumentedPool<T> fifo() {
/* 484 */     return buildPool();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <POOL extends Pool<T>> POOL build(Function<? super CONF, POOL> poolFactory) {
/* 495 */     CONF config = buildConfig();
/* 496 */     return poolFactory.apply(config);
/*     */   }
/*     */ 
/*     */   
/*     */   CONF buildConfig() {
/* 501 */     PoolConfig<T> baseConfig = new DefaultPoolConfig<>(this.allocator, (this.allocationStrategy == null) ? new AllocationStrategies.UnboundedAllocationStrategy() : this.allocationStrategy, this.maxPending, this.pendingAcquireTimer, this.releaseHandler, this.destroyHandler, this.evictionPredicate, this.evictionBackgroundInterval, this.evictionBackgroundScheduler, this.acquisitionScheduler, this.metricsRecorder, this.clock, this.idleLruOrder);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 517 */     return this.configModifier.apply(baseConfig);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> Function<T, Mono<Void>> noopHandler() {
/* 522 */     return (Function)NOOP_HANDLER;
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> BiPredicate<T, PooledRefMetadata> neverPredicate() {
/* 527 */     return (BiPredicate)NEVER_PREDICATE;
/*     */   }
/*     */   
/*     */   static <T> BiPredicate<T, PooledRefMetadata> idlePredicate(Duration maxIdleTime) {
/* 531 */     return (poolable, meta) -> (meta.idleTime() >= maxIdleTime.toMillis());
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/* 536 */     DEFAULT_PENDING_ACQUIRE_TIMER = ((r, d) -> Schedulers.parallel().schedule(r, d.toNanos(), TimeUnit.NANOSECONDS));
/*     */   }
/*     */   
/*     */   static final Function<?, Mono<Void>> NOOP_HANDLER = it -> Mono.empty();
/*     */   static final BiPredicate<?, ?> NEVER_PREDICATE = (ignored1, ignored2) -> false;
/*     */   static final BiFunction<Runnable, Duration, Disposable> DEFAULT_PENDING_ACQUIRE_TIMER;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\PoolBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */