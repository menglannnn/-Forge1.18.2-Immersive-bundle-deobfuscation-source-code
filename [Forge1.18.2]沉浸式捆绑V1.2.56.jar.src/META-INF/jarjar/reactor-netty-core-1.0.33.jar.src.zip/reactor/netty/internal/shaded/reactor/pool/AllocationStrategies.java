/*     */ package reactor.netty.internal.shaded.reactor.pool;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AllocationStrategies
/*     */ {
/*     */   static final class UnboundedAllocationStrategy
/*     */     extends AtomicInteger
/*     */     implements AllocationStrategy
/*     */   {
/*     */     public int getPermits(int desired) {
/*  34 */       if (desired <= 0) {
/*  35 */         return 0;
/*     */       }
/*  37 */       int overflowCheck = addAndGet(desired);
/*  38 */       if (overflowCheck < 0) {
/*  39 */         compareAndSet(overflowCheck, 2147483647);
/*     */       }
/*  41 */       return desired;
/*     */     }
/*     */ 
/*     */     
/*     */     public int estimatePermitCount() {
/*  46 */       return Integer.MAX_VALUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public void returnPermits(int returned) {
/*  51 */       int updated = addAndGet(-returned);
/*  52 */       if (updated < 0) {
/*  53 */         compareAndSet(updated, 0);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int permitMinimum() {
/*  59 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int permitMaximum() {
/*  64 */       return Integer.MAX_VALUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public int permitGranted() {
/*  69 */       return get();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SizeBasedAllocationStrategy
/*     */     implements AllocationStrategy
/*     */   {
/*     */     final int min;
/*     */     final int max;
/*     */     volatile int permits;
/*  79 */     static final AtomicIntegerFieldUpdater<SizeBasedAllocationStrategy> PERMITS = AtomicIntegerFieldUpdater.newUpdater(SizeBasedAllocationStrategy.class, "permits");
/*     */     
/*     */     SizeBasedAllocationStrategy(int min, int max) {
/*  82 */       if (min < 0) throw new IllegalArgumentException("min must be positive or zero"); 
/*  83 */       if (max < 1) throw new IllegalArgumentException("max must be strictly positive"); 
/*  84 */       if (min > max) throw new IllegalArgumentException("min must be less than or equal to max"); 
/*  85 */       this.min = min;
/*  86 */       this.max = max;
/*  87 */       PERMITS.lazySet(this, this.max);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getPermits(int desired) {
/*  92 */       if (desired < 0) return 0;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/*  98 */         int target, p = this.permits;
/*  99 */         int granted = this.max - p;
/*     */         
/* 101 */         if (desired >= p) {
/* 102 */           target = p;
/*     */         }
/* 104 */         else if (granted < this.min) {
/* 105 */           target = Math.max(desired, this.min - granted);
/*     */         } else {
/*     */           
/* 108 */           target = desired;
/*     */         } 
/*     */         
/* 111 */         if (PERMITS.compareAndSet(this, p, p - target)) {
/* 112 */           return target;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int estimatePermitCount() {
/* 119 */       return PERMITS.get(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public int permitMinimum() {
/* 124 */       return this.min;
/*     */     }
/*     */ 
/*     */     
/*     */     public int permitMaximum() {
/* 129 */       return this.max;
/*     */     }
/*     */ 
/*     */     
/*     */     public int permitGranted() {
/* 134 */       return this.max - PERMITS.get(this);
/*     */     }
/*     */     
/*     */     public void returnPermits(int returned) {
/*     */       int p;
/*     */       do {
/* 140 */         p = PERMITS.get(this);
/* 141 */         if (p + returned > this.max) {
/* 142 */           throw new IllegalArgumentException("Too many permits returned: returned=" + returned + ", would bring to " + (p + returned) + "/" + this.max);
/*     */         }
/* 144 */       } while (!PERMITS.compareAndSet(this, p, p + returned));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\AllocationStrategies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */