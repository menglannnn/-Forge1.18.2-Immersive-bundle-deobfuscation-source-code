package reactor.netty.internal.shaded.reactor.pool;

import reactor.core.publisher.Mono;

public interface PooledRef<POOLABLE> {
  POOLABLE poolable();
  
  PooledRefMetadata metadata();
  
  Mono<Void> invalidate();
  
  Mono<Void> release();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\PooledRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */