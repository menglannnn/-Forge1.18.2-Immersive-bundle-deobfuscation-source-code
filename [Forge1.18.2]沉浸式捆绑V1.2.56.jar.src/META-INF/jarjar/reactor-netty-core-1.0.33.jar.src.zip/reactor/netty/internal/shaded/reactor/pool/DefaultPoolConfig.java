/*     */ package reactor.netty.internal.shaded.reactor.pool;
/*     */ 
/*     */ import java.time.Clock;
/*     */ import java.time.Duration;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPoolConfig<POOLABLE>
/*     */   implements PoolConfig<POOLABLE>
/*     */ {
/*     */   protected final BiFunction<Runnable, Duration, Disposable> pendingAcquireTimer;
/*     */   protected final Mono<POOLABLE> allocator;
/*     */   protected final AllocationStrategy allocationStrategy;
/*     */   protected final int maxPending;
/*     */   protected final Function<POOLABLE, ? extends Publisher<Void>> releaseHandler;
/*     */   protected final Function<POOLABLE, ? extends Publisher<Void>> destroyHandler;
/*     */   protected final BiPredicate<POOLABLE, PooledRefMetadata> evictionPredicate;
/*     */   protected final Duration evictInBackgroundInterval;
/*     */   protected final Scheduler evictInBackgroundScheduler;
/*     */   protected final Scheduler acquisitionScheduler;
/*     */   protected final PoolMetricsRecorder metricsRecorder;
/*     */   protected final Clock clock;
/*     */   protected final boolean isIdleLRU;
/*     */   
/*     */   public DefaultPoolConfig(Mono<POOLABLE> allocator, AllocationStrategy allocationStrategy, int maxPending, BiFunction<Runnable, Duration, Disposable> pendingAcquireTimer, Function<POOLABLE, ? extends Publisher<Void>> releaseHandler, Function<POOLABLE, ? extends Publisher<Void>> destroyHandler, BiPredicate<POOLABLE, PooledRefMetadata> evictionPredicate, Duration evictInBackgroundInterval, Scheduler evictInBackgroundScheduler, Scheduler acquisitionScheduler, PoolMetricsRecorder metricsRecorder, Clock clock, boolean isIdleLRU) {
/*  67 */     this.pendingAcquireTimer = pendingAcquireTimer;
/*  68 */     this.allocator = allocator;
/*  69 */     this.allocationStrategy = allocationStrategy;
/*  70 */     this.maxPending = maxPending;
/*  71 */     this.releaseHandler = releaseHandler;
/*  72 */     this.destroyHandler = destroyHandler;
/*  73 */     this.evictionPredicate = evictionPredicate;
/*  74 */     this.evictInBackgroundInterval = evictInBackgroundInterval;
/*  75 */     this.evictInBackgroundScheduler = evictInBackgroundScheduler;
/*  76 */     this.acquisitionScheduler = acquisitionScheduler;
/*  77 */     this.metricsRecorder = metricsRecorder;
/*  78 */     this.clock = clock;
/*  79 */     this.isIdleLRU = isIdleLRU;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPoolConfig(Mono<POOLABLE> allocator, AllocationStrategy allocationStrategy, int maxPending, Function<POOLABLE, ? extends Publisher<Void>> releaseHandler, Function<POOLABLE, ? extends Publisher<Void>> destroyHandler, BiPredicate<POOLABLE, PooledRefMetadata> evictionPredicate, Duration evictInBackgroundInterval, Scheduler evictInBackgroundScheduler, Scheduler acquisitionScheduler, PoolMetricsRecorder metricsRecorder, Clock clock, boolean isIdleLRU) {
/*  99 */     this(allocator, allocationStrategy, maxPending, PoolBuilder.DEFAULT_PENDING_ACQUIRE_TIMER, releaseHandler, destroyHandler, evictionPredicate, evictInBackgroundInterval, evictInBackgroundScheduler, acquisitionScheduler, metricsRecorder, clock, isIdleLRU);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPoolConfig(Mono<POOLABLE> allocator, AllocationStrategy allocationStrategy, int maxPending, Function<POOLABLE, ? extends Publisher<Void>> releaseHandler, Function<POOLABLE, ? extends Publisher<Void>> destroyHandler, BiPredicate<POOLABLE, PooledRefMetadata> evictionPredicate, Scheduler acquisitionScheduler, PoolMetricsRecorder metricsRecorder, Clock clock, boolean isIdleLRU) {
/* 118 */     this(allocator, allocationStrategy, maxPending, releaseHandler, destroyHandler, evictionPredicate, Duration.ZERO, 
/* 119 */         Schedulers.immediate(), acquisitionScheduler, metricsRecorder, clock, isIdleLRU);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPoolConfig(Mono<POOLABLE> allocator, AllocationStrategy allocationStrategy, int maxPending, Function<POOLABLE, ? extends Publisher<Void>> releaseHandler, Function<POOLABLE, ? extends Publisher<Void>> destroyHandler, BiPredicate<POOLABLE, PooledRefMetadata> evictionPredicate, Scheduler acquisitionScheduler, PoolMetricsRecorder metricsRecorder, Clock clock) {
/* 137 */     this(allocator, allocationStrategy, maxPending, releaseHandler, destroyHandler, evictionPredicate, Duration.ZERO, 
/*     */         
/* 139 */         Schedulers.immediate(), acquisitionScheduler, metricsRecorder, clock, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultPoolConfig(PoolConfig<POOLABLE> toCopy) {
/* 151 */     if (toCopy instanceof DefaultPoolConfig) {
/* 152 */       DefaultPoolConfig<POOLABLE> toCopyDpc = (DefaultPoolConfig<POOLABLE>)toCopy;
/* 153 */       this.allocator = toCopyDpc.allocator;
/* 154 */       this.allocationStrategy = toCopyDpc.allocationStrategy;
/* 155 */       this.maxPending = toCopyDpc.maxPending;
/* 156 */       this.pendingAcquireTimer = toCopyDpc.pendingAcquireTimer;
/* 157 */       this.releaseHandler = toCopyDpc.releaseHandler;
/* 158 */       this.destroyHandler = toCopyDpc.destroyHandler;
/* 159 */       this.evictionPredicate = toCopyDpc.evictionPredicate;
/* 160 */       this.evictInBackgroundInterval = toCopyDpc.evictInBackgroundInterval;
/* 161 */       this.evictInBackgroundScheduler = toCopyDpc.evictInBackgroundScheduler;
/* 162 */       this.acquisitionScheduler = toCopyDpc.acquisitionScheduler;
/* 163 */       this.metricsRecorder = toCopyDpc.metricsRecorder;
/* 164 */       this.clock = toCopyDpc.clock;
/* 165 */       this.isIdleLRU = toCopyDpc.isIdleLRU;
/*     */     } else {
/*     */       
/* 168 */       this.allocator = toCopy.allocator();
/* 169 */       this.allocationStrategy = toCopy.allocationStrategy();
/* 170 */       this.maxPending = toCopy.maxPending();
/* 171 */       this.pendingAcquireTimer = toCopy.pendingAcquireTimer();
/* 172 */       this.releaseHandler = toCopy.releaseHandler();
/* 173 */       this.destroyHandler = toCopy.destroyHandler();
/* 174 */       this.evictionPredicate = toCopy.evictionPredicate();
/* 175 */       this.evictInBackgroundInterval = toCopy.evictInBackgroundInterval();
/* 176 */       this.evictInBackgroundScheduler = toCopy.evictInBackgroundScheduler();
/* 177 */       this.acquisitionScheduler = toCopy.acquisitionScheduler();
/* 178 */       this.metricsRecorder = toCopy.metricsRecorder();
/* 179 */       this.clock = toCopy.clock();
/* 180 */       this.isIdleLRU = toCopy.reuseIdleResourcesInLruOrder();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<POOLABLE> allocator() {
/* 186 */     return this.allocator;
/*     */   }
/*     */ 
/*     */   
/*     */   public AllocationStrategy allocationStrategy() {
/* 191 */     return this.allocationStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxPending() {
/* 196 */     return this.maxPending;
/*     */   }
/*     */ 
/*     */   
/*     */   public BiFunction<Runnable, Duration, Disposable> pendingAcquireTimer() {
/* 201 */     return this.pendingAcquireTimer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Function<POOLABLE, ? extends Publisher<Void>> releaseHandler() {
/* 206 */     return this.releaseHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public Function<POOLABLE, ? extends Publisher<Void>> destroyHandler() {
/* 211 */     return this.destroyHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public BiPredicate<POOLABLE, PooledRefMetadata> evictionPredicate() {
/* 216 */     return this.evictionPredicate;
/*     */   }
/*     */ 
/*     */   
/*     */   public Duration evictInBackgroundInterval() {
/* 221 */     return this.evictInBackgroundInterval;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler evictInBackgroundScheduler() {
/* 226 */     return this.evictInBackgroundScheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scheduler acquisitionScheduler() {
/* 231 */     return this.acquisitionScheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public PoolMetricsRecorder metricsRecorder() {
/* 236 */     return this.metricsRecorder;
/*     */   }
/*     */ 
/*     */   
/*     */   public Clock clock() {
/* 241 */     return this.clock;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reuseIdleResourcesInLruOrder() {
/* 246 */     return this.isIdleLRU;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\DefaultPoolConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */