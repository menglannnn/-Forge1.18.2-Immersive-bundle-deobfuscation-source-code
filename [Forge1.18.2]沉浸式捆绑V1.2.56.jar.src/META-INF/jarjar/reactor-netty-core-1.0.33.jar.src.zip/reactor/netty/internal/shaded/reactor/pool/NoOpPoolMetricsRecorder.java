/*    */ package reactor.netty.internal.shaded.reactor.pool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NoOpPoolMetricsRecorder
/*    */   implements PoolMetricsRecorder
/*    */ {
/* 26 */   static final NoOpPoolMetricsRecorder INSTANCE = new NoOpPoolMetricsRecorder();
/*    */   
/*    */   public void recordAllocationSuccessAndLatency(long latencyMs) {}
/*    */   
/*    */   public void recordAllocationFailureAndLatency(long latencyMs) {}
/*    */   
/*    */   public void recordResetLatency(long latencyMs) {}
/*    */   
/*    */   public void recordDestroyLatency(long latencyMs) {}
/*    */   
/*    */   public void recordRecycled() {}
/*    */   
/*    */   public void recordIdleTime(long millisecondsIdle) {}
/*    */   
/*    */   public void recordLifetimeDuration(long millisecondsSinceAllocation) {}
/*    */   
/*    */   public void recordSlowPath() {}
/*    */   
/*    */   public void recordFastPath() {}
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\NoOpPoolMetricsRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */