/*    */ package reactor.netty.internal.shaded.reactor.pool;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.concurrent.TimeoutException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PoolAcquireTimeoutException
/*    */   extends TimeoutException
/*    */ {
/*    */   private final Duration acquireTimeout;
/*    */   
/*    */   public PoolAcquireTimeoutException(Duration acquireTimeout) {
/* 33 */     super("Pool#acquire(Duration) has been pending for more than the configured timeout of " + acquireTimeout.toMillis() + "ms");
/* 34 */     this.acquireTimeout = acquireTimeout;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Duration getAcquireTimeout() {
/* 41 */     return this.acquireTimeout;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\PoolAcquireTimeoutException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */