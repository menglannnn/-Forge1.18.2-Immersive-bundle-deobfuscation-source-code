/*     */ package reactor.netty.internal.shaded.reactor.pool;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.time.Clock;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Disposable;
/*     */ import reactor.core.Disposables;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.core.publisher.SignalType;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractPool<POOLABLE>
/*     */   implements InstrumentedPool<POOLABLE>, InstrumentedPool.PoolMetrics
/*     */ {
/*     */   final Logger logger;
/*     */   final PoolConfig<POOLABLE> poolConfig;
/*     */   final PoolMetricsRecorder metricsRecorder;
/*     */   final Clock clock;
/*     */   long lastInteractionTimestamp;
/*     */   
/*     */   AbstractPool(PoolConfig<POOLABLE> poolConfig, Logger logger) {
/*  63 */     this.poolConfig = poolConfig;
/*  64 */     this.logger = logger;
/*  65 */     this.metricsRecorder = poolConfig.metricsRecorder();
/*  66 */     this.clock = poolConfig.clock();
/*  67 */     this.lastInteractionTimestamp = this.clock.millis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PoolConfig<POOLABLE> config() {
/*  74 */     return this.poolConfig;
/*     */   }
/*     */ 
/*     */   
/*     */   public InstrumentedPool.PoolMetrics metrics() {
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int allocatedSize() {
/*  84 */     return this.poolConfig.allocationStrategy().permitGranted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int acquiredSize() {
/*  92 */     return allocatedSize() - idleSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxAllocatedSize() {
/*  97 */     return this.poolConfig.allocationStrategy().permitMaximum();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxPendingAcquireSize() {
/* 102 */     return (this.poolConfig.maxPending() < 0) ? Integer.MAX_VALUE : this.poolConfig.maxPending();
/*     */   }
/*     */   
/*     */   void recordInteractionTimestamp() {
/* 106 */     this.lastInteractionTimestamp = this.clock.millis();
/*     */   }
/*     */ 
/*     */   
/*     */   public long secondsSinceLastInteraction() {
/* 111 */     long sinceMs = this.clock.millis() - this.lastInteractionTimestamp;
/* 112 */     return sinceMs / 1000L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInactiveForMoreThan(Duration duration) {
/* 118 */     return (idleSize() == 0 && pendingAcquireSize() == 0 && allocatedSize() == 0 && 
/* 119 */       secondsSinceLastInteraction() >= duration.getSeconds());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void defaultDestroy(@Nullable POOLABLE poolable) {
/* 135 */     if (poolable instanceof Disposable) {
/* 136 */       ((Disposable)poolable).dispose();
/*     */     }
/* 138 */     else if (poolable instanceof Closeable) {
/*     */       try {
/* 140 */         ((Closeable)poolable).close();
/* 141 */       } catch (IOException e) {
/* 142 */         this.logger.trace("Failure while discarding a released Poolable that is Closeable, could not close", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Void> destroyPoolable(AbstractPooledRef<POOLABLE> ref) {
/*     */     Mono<Void> userProvidedDestroy;
/* 158 */     if (ref.state != 3) {
/* 159 */       throw new IllegalStateException("destroying non invalidated ref " + ref);
/*     */     }
/* 161 */     POOLABLE poolable = ref.poolable();
/* 162 */     this.poolConfig.allocationStrategy().returnPermits(1);
/* 163 */     long start = this.clock.millis();
/* 164 */     this.metricsRecorder.recordLifetimeDuration(ref.lifeTime());
/* 165 */     Function<POOLABLE, ? extends Publisher<Void>> factory = this.poolConfig.destroyHandler();
/* 166 */     if (factory == PoolBuilder.NOOP_HANDLER) {
/* 167 */       return Mono.fromRunnable(() -> {
/*     */             defaultDestroy((POOLABLE)poolable);
/*     */             
/*     */             this.metricsRecorder.recordDestroyLatency(this.clock.millis() - start);
/*     */           });
/*     */     }
/*     */     
/*     */     try {
/* 175 */       userProvidedDestroy = Mono.from(factory.apply(poolable));
/*     */     }
/* 177 */     catch (Throwable destroyFunctionError) {
/* 178 */       userProvidedDestroy = Mono.error(destroyFunctionError);
/*     */     } 
/* 180 */     return userProvidedDestroy.doFinally(fin -> this.metricsRecorder.recordDestroyLatency(this.clock.millis() - start));
/*     */   }
/*     */   
/*     */   public abstract int idleSize();
/*     */   
/*     */   abstract boolean elementOffer(POOLABLE paramPOOLABLE);
/*     */   
/*     */   abstract void doAcquire(Borrower<POOLABLE> paramBorrower);
/*     */   
/*     */   abstract void cancelAcquire(Borrower<POOLABLE> paramBorrower);
/*     */   
/*     */   static abstract class AbstractPooledRef<T>
/*     */     implements PooledRef<T>, PooledRefMetadata
/*     */   {
/*     */     final long creationTimestamp;
/*     */     final PoolMetricsRecorder metricsRecorder;
/*     */     final Clock clock;
/*     */     final T poolable;
/*     */     final int acquireCount;
/*     */     long releaseTimestamp;
/*     */     volatile int state;
/* 201 */     static final AtomicIntegerFieldUpdater<AbstractPooledRef> STATE = AtomicIntegerFieldUpdater.newUpdater(AbstractPooledRef.class, "state");
/*     */     
/*     */     static final int STATE_IDLE = 0;
/*     */     
/*     */     static final int STATE_ACQUIRED = 1;
/*     */     static final int STATE_RELEASED = 2;
/*     */     static final int STATE_INVALIDATED = 3;
/*     */     
/*     */     AbstractPooledRef(T poolable, PoolMetricsRecorder metricsRecorder, Clock clock) {
/* 210 */       this.poolable = poolable;
/* 211 */       this.metricsRecorder = metricsRecorder;
/* 212 */       this.clock = clock;
/* 213 */       this.creationTimestamp = clock.millis();
/* 214 */       this.acquireCount = 0;
/* 215 */       this.releaseTimestamp = -2L;
/* 216 */       this.state = 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AbstractPooledRef(AbstractPooledRef<T> oldRef) {
/* 223 */       this.poolable = oldRef.poolable;
/* 224 */       this.metricsRecorder = oldRef.metricsRecorder;
/* 225 */       this.clock = oldRef.clock;
/* 226 */       this.creationTimestamp = oldRef.creationTimestamp;
/* 227 */       this.acquireCount = oldRef.acquireCount();
/* 228 */       this.releaseTimestamp = oldRef.releaseTimestamp;
/*     */       
/* 230 */       this.state = (oldRef.state == 3) ? 3 : 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T poolable() {
/* 237 */       return this.poolable;
/*     */     }
/*     */ 
/*     */     
/*     */     public PooledRefMetadata metadata() {
/* 242 */       return this;
/*     */     }
/*     */     
/*     */     void markAcquired() {
/* 246 */       if (STATE.compareAndSet(this, 0, 1)) {
/* 247 */         long rt = this.releaseTimestamp;
/* 248 */         if (rt > 0L) {
/* 249 */           this.metricsRecorder.recordIdleTime(this.clock.millis() - rt);
/*     */         } else {
/*     */           
/* 252 */           this.metricsRecorder.recordIdleTime(this.clock.millis() - this.creationTimestamp);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean markReleased() {
/*     */       while (true) {
/* 259 */         int s = this.state;
/* 260 */         if (s == 2 || s == 3) {
/* 261 */           return false;
/*     */         }
/* 263 */         if (STATE.compareAndSet(this, s, 2)) {
/* 264 */           this.releaseTimestamp = this.clock.millis();
/* 265 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean markSoftInvalidate() {
/*     */       while (true) {
/* 279 */         int s = this.state;
/*     */         
/* 281 */         if (s == 3 || s == 2) {
/* 282 */           return false;
/*     */         }
/* 284 */         if (STATE.compareAndSet(this, s, 3)) {
/* 285 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean markDestroy() {
/*     */       while (true) {
/* 298 */         int s = this.state;
/*     */         
/* 300 */         if (s == 3) {
/* 301 */           return false;
/*     */         }
/* 303 */         if (STATE.compareAndSet(this, s, 3)) {
/* 304 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int acquireCount() {
/* 311 */       if (STATE.get(this) == 0) {
/* 312 */         return this.acquireCount;
/*     */       }
/* 314 */       return this.acquireCount + 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public long lifeTime() {
/* 319 */       return this.clock.millis() - this.creationTimestamp;
/*     */     }
/*     */ 
/*     */     
/*     */     public long idleTime() {
/* 324 */       if (STATE.get(this) == 1) {
/* 325 */         return 0L;
/*     */       }
/* 327 */       long rt = this.releaseTimestamp;
/* 328 */       if (rt < 0L) rt = this.creationTimestamp; 
/* 329 */       return this.clock.millis() - rt;
/*     */     }
/*     */ 
/*     */     
/*     */     public long allocationTimestamp() {
/* 334 */       return this.creationTimestamp;
/*     */     }
/*     */ 
/*     */     
/*     */     public long releaseTimestamp() {
/* 339 */       if (STATE.get(this) == 1) {
/* 340 */         return 0L;
/*     */       }
/* 342 */       long rt = this.releaseTimestamp;
/* 343 */       if (rt < 0L) rt = this.creationTimestamp; 
/* 344 */       return rt;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract Mono<Void> release();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract Mono<Void> invalidate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 365 */       return "PooledRef{poolable=" + this.poolable + ", lifeTime=" + 
/*     */         
/* 367 */         lifeTime() + "ms, idleTime=" + 
/* 368 */         idleTime() + "ms, acquireCount=" + this.acquireCount + '}';
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Borrower<POOLABLE>
/*     */     extends AtomicBoolean
/*     */     implements Scannable, Subscription, Runnable
/*     */   {
/* 388 */     static final Disposable TIMEOUT_DISPOSED = Disposables.disposed();
/*     */     
/*     */     final CoreSubscriber<? super AbstractPool.AbstractPooledRef<POOLABLE>> actual;
/*     */     
/*     */     final AbstractPool<POOLABLE> pool;
/*     */     
/*     */     final Duration pendingAcquireTimeout;
/*     */     
/*     */     Disposable timeoutTask;
/*     */     
/*     */     Borrower(CoreSubscriber<? super AbstractPool.AbstractPooledRef<POOLABLE>> actual, AbstractPool<POOLABLE> pool, Duration pendingAcquireTimeout) {
/* 399 */       this.actual = actual;
/* 400 */       this.pool = pool;
/* 401 */       this.pendingAcquireTimeout = pendingAcquireTimeout;
/* 402 */       this.timeoutTask = TIMEOUT_DISPOSED;
/*     */     }
/*     */     
/*     */     Context currentContext() {
/* 406 */       return this.actual.currentContext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 411 */       if (compareAndSet(false, true)) {
/* 412 */         this.pool.cancelAcquire(this);
/* 413 */         this.actual.onError(new PoolAcquireTimeoutException(this.pendingAcquireTimeout));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void request(long n) {
/* 419 */       if (Operators.validate(n)) {
/*     */ 
/*     */         
/* 422 */         boolean noIdle = (this.pool.idleSize() == 0);
/* 423 */         boolean noPermits = (this.pool.poolConfig.allocationStrategy().estimatePermitCount() == 0);
/*     */         
/* 425 */         if (!this.pendingAcquireTimeout.isZero() && noIdle && noPermits) {
/* 426 */           this.timeoutTask = this.pool.config().pendingAcquireTimer().apply(this, this.pendingAcquireTimeout);
/*     */         }
/*     */ 
/*     */         
/* 430 */         this.pool.doAcquire(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void stopPendingCountdown() {
/* 438 */       this.timeoutTask.dispose();
/*     */     }
/*     */ 
/*     */     
/*     */     public void cancel() {
/* 443 */       set(true);
/* 444 */       this.pool.cancelAcquire(this);
/* 445 */       stopPendingCountdown();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object scanUnsafe(Scannable.Attr key) {
/* 452 */       if (key == Scannable.Attr.CANCELLED) return Boolean.valueOf(get()); 
/* 453 */       if (key == Scannable.Attr.REQUESTED_FROM_DOWNSTREAM) return Integer.valueOf(1); 
/* 454 */       if (key == Scannable.Attr.ACTUAL) return this.actual;
/*     */       
/* 456 */       return null;
/*     */     }
/*     */     
/*     */     void deliver(AbstractPool.AbstractPooledRef<POOLABLE> poolSlot) {
/* 460 */       stopPendingCountdown();
/* 461 */       if (get()) {
/*     */         
/* 463 */         poolSlot.release().subscribe(aVoid -> { 
/*     */             }e -> Operators.onErrorDropped(e, Context.empty()));
/*     */       } else {
/* 466 */         poolSlot.markAcquired();
/* 467 */         this.actual.onNext(poolSlot);
/* 468 */         this.actual.onComplete();
/*     */       } 
/*     */     }
/*     */     
/*     */     void fail(Throwable error) {
/* 473 */       stopPendingCountdown();
/* 474 */       if (!get()) {
/* 475 */         this.actual.onError(error);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 481 */       return get() ? "Borrower(cancelled)" : "Borrower";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\reactor-netty-core-1.0.33.jar!\reactor\netty\internal\shaded\reactor\pool\AbstractPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */