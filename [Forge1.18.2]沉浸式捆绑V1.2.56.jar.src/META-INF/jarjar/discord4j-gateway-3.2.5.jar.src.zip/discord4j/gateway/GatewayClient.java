/*     */ package discord4j.gateway;
/*     */ 
/*     */ import discord4j.common.close.CloseStatus;
/*     */ import discord4j.discordjson.json.gateway.Dispatch;
/*     */ import discord4j.gateway.json.GatewayPayload;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.time.Duration;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface GatewayClient
/*     */ {
/*     */   Mono<Void> execute(String paramString);
/*     */   
/*     */   Mono<CloseStatus> close(boolean paramBoolean);
/*     */   
/*     */   Flux<Dispatch> dispatch();
/*     */   
/*     */   Flux<GatewayPayload<?>> receiver();
/*     */   
/*     */   <T> Flux<T> receiver(Function<ByteBuf, Publisher<? extends T>> paramFunction);
/*     */   
/*     */   Sinks.Many<GatewayPayload<?>> sender();
/*     */   
/*     */   default Mono<Void> send(Publisher<? extends GatewayPayload<?>> publisher) {
/* 114 */     return Flux.from(publisher)
/* 115 */       .doOnNext(payload -> sender().emitNext(payload, Sinks.EmitFailureHandler.FAIL_FAST))
/* 116 */       .then();
/*     */   }
/*     */   
/*     */   Mono<Void> sendBuffer(Publisher<ByteBuf> paramPublisher);
/*     */   
/*     */   int getShardCount();
/*     */   
/*     */   String getSessionId();
/*     */   
/*     */   int getSequence();
/*     */   
/*     */   Flux<GatewayConnection.State> stateEvents();
/*     */   
/*     */   Mono<Boolean> isConnected();
/*     */   
/*     */   Duration getResponseTime();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\GatewayClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */