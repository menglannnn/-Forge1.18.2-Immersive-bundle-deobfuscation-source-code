/*    */ package discord4j.gateway.limiter;
/*    */ 
/*    */ import discord4j.common.operator.RateLimitOperator;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import java.time.Duration;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ import reactor.core.scheduler.Schedulers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RateLimitTransformer
/*    */   implements PayloadTransformer
/*    */ {
/*    */   private final RateLimitOperator<ByteBuf> operator;
/*    */   
/*    */   public RateLimitTransformer(int capacity, Duration refillPeriod) {
/* 33 */     this(capacity, refillPeriod, Schedulers.parallel());
/*    */   }
/*    */   
/*    */   public RateLimitTransformer(int capacity, Duration refillPeriod, Scheduler delayScheduler) {
/* 37 */     this.operator = new RateLimitOperator(capacity, refillPeriod, delayScheduler);
/*    */   }
/*    */ 
/*    */   
/*    */   public Publisher<ByteBuf> apply(Publisher<ByteBuf> sequence) {
/* 42 */     return this.operator.apply(sequence);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\limiter\RateLimitTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */