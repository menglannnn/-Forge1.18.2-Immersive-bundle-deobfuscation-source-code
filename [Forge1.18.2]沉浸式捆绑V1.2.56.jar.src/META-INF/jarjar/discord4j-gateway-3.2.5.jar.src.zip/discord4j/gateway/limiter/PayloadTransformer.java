package discord4j.gateway.limiter;

import io.netty.buffer.ByteBuf;
import java.util.function.Function;
import org.reactivestreams.Publisher;

@FunctionalInterface
public interface PayloadTransformer extends Function<Publisher<ByteBuf>, Publisher<ByteBuf>> {}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\limiter\PayloadTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */