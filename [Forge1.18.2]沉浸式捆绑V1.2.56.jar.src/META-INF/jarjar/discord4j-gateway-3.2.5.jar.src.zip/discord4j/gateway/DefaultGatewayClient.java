/*     */ package discord4j.gateway;
/*     */ 
/*     */ import discord4j.common.GitProperties;
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.ResettableInterval;
/*     */ import discord4j.common.close.CloseException;
/*     */ import discord4j.common.close.CloseStatus;
/*     */ import discord4j.common.close.DisconnectBehavior;
/*     */ import discord4j.common.operator.RateLimitOperator;
/*     */ import discord4j.common.retry.ReconnectContext;
/*     */ import discord4j.common.retry.ReconnectOptions;
/*     */ import discord4j.common.sinks.EmissionStrategy;
/*     */ import discord4j.discordjson.json.gateway.Dispatch;
/*     */ import discord4j.discordjson.json.gateway.Heartbeat;
/*     */ import discord4j.discordjson.json.gateway.Hello;
/*     */ import discord4j.discordjson.json.gateway.Identify;
/*     */ import discord4j.discordjson.json.gateway.IdentifyProperties;
/*     */ import discord4j.discordjson.json.gateway.ImmutableHeartbeat;
/*     */ import discord4j.discordjson.json.gateway.ImmutableIdentify;
/*     */ import discord4j.discordjson.json.gateway.ImmutableIdentifyProperties;
/*     */ import discord4j.discordjson.json.gateway.ImmutableResume;
/*     */ import discord4j.discordjson.json.gateway.InvalidSession;
/*     */ import discord4j.discordjson.json.gateway.Opcode;
/*     */ import discord4j.discordjson.json.gateway.Ready;
/*     */ import discord4j.discordjson.json.gateway.Resume;
/*     */ import discord4j.discordjson.json.gateway.Resumed;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import discord4j.gateway.intent.IntentSet;
/*     */ import discord4j.gateway.json.GatewayPayload;
/*     */ import discord4j.gateway.limiter.PayloadTransformer;
/*     */ import discord4j.gateway.payload.PayloadReader;
/*     */ import discord4j.gateway.payload.PayloadWriter;
/*     */ import discord4j.gateway.retry.GatewayException;
/*     */ import discord4j.gateway.retry.GatewayRetrySignal;
/*     */ import discord4j.gateway.retry.GatewayRetrySpec;
/*     */ import discord4j.gateway.retry.GatewayStateChange;
/*     */ import discord4j.gateway.retry.InvalidSessionException;
/*     */ import discord4j.gateway.retry.ReconnectException;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.QueryStringDecoder;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.function.TupleUtils;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.ConnectionObserver;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.http.client.WebsocketClientSpec;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.concurrent.Queues;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultGatewayClient
/*     */   implements GatewayClient
/*     */ {
/*  82 */   private static final Logger log = Loggers.getLogger(DefaultGatewayClient.class);
/*  83 */   private static final Logger senderLog = Loggers.getLogger("discord4j.gateway.protocol.sender");
/*  84 */   private static final Logger receiverLog = Loggers.getLogger("discord4j.gateway.protocol.receiver");
/*     */   
/*     */   private final GatewayReactorResources reactorResources;
/*     */   
/*     */   private final PayloadReader payloadReader;
/*     */   
/*     */   private final PayloadWriter payloadWriter;
/*     */   private final ReconnectOptions reconnectOptions;
/*     */   private final ReconnectContext reconnectContext;
/*     */   private final IdentifyOptions identifyOptions;
/*     */   private final String token;
/*     */   private final GatewayObserver observer;
/*     */   private final PayloadTransformer identifyLimiter;
/*     */   private final ResettableInterval heartbeatEmitter;
/*     */   private final int maxMissedHeartbeatAck;
/*     */   private final boolean unpooled;
/*     */   private final EmissionStrategy emissionStrategy;
/* 101 */   private final Map<Opcode<?>, PayloadHandler<?>> handlerMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpClient httpClient;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Sinks.Many<ByteBuf> receiver;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Sinks.Many<ByteBuf> sender;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Sinks.Many<Dispatch> dispatch;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Sinks.Many<GatewayPayload<?>> outbound;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Sinks.Many<GatewayPayload<Heartbeat>> heartbeats;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Sinks.Many<GatewayConnection.State> state;
/*     */ 
/*     */ 
/*     */   
/* 136 */   private final AtomicInteger sequence = new AtomicInteger(0);
/* 137 */   private final AtomicReference<String> sessionId = new AtomicReference<>("");
/* 138 */   private final AtomicReference<String> resumeUrl = new AtomicReference<>();
/* 139 */   private final AtomicLong lastSent = new AtomicLong(0L);
/* 140 */   private final AtomicLong lastAck = new AtomicLong(0L);
/* 141 */   private final AtomicInteger missedAck = new AtomicInteger(0);
/* 142 */   private volatile long responseTime = 0L;
/*     */ 
/*     */   
/*     */   private volatile Sinks.One<CloseStatus> disconnectNotifier;
/*     */   
/*     */   private volatile GatewayWebsocketHandler sessionHandler;
/*     */   
/*     */   private volatile ContextView currentContext;
/*     */   
/*     */   private static final String OUTBOUND_CAPACITY_PROPERTY = "discord4j.gateway.outbound.capacity";
/*     */ 
/*     */   
/*     */   public DefaultGatewayClient(GatewayOptions options) {
/* 155 */     this.token = Objects.<String>requireNonNull(options.getToken());
/* 156 */     this.reactorResources = Objects.<GatewayReactorResources>requireNonNull(options.getReactorResources());
/* 157 */     this.payloadReader = Objects.<PayloadReader>requireNonNull(options.getPayloadReader());
/* 158 */     this.payloadWriter = Objects.<PayloadWriter>requireNonNull(options.getPayloadWriter());
/* 159 */     this.reconnectOptions = options.getReconnectOptions();
/* 160 */     this
/* 161 */       .reconnectContext = new ReconnectContext(this.reconnectOptions.getFirstBackoff(), this.reconnectOptions.getMaxBackoffInterval());
/* 162 */     this.identifyOptions = Objects.<IdentifyOptions>requireNonNull(options.getIdentifyOptions());
/* 163 */     this.observer = options.getInitialObserver();
/* 164 */     this.identifyLimiter = Objects.<PayloadTransformer>requireNonNull(options.getIdentifyLimiter());
/* 165 */     this.maxMissedHeartbeatAck = Math.max(0, options.getMaxMissedHeartbeatAck());
/* 166 */     this.unpooled = options.isUnpooled();
/* 167 */     this.emissionStrategy = options.getEmissionStrategy();
/*     */     
/* 169 */     addHandler(Opcode.DISPATCH, this::handleDispatch);
/* 170 */     addHandler(Opcode.HEARTBEAT, this::handleHeartbeat);
/* 171 */     addHandler(Opcode.RECONNECT, this::handleReconnect);
/* 172 */     addHandler(Opcode.INVALID_SESSION, this::handleInvalidSession);
/* 173 */     addHandler(Opcode.HELLO, this::handleHello);
/* 174 */     addHandler(Opcode.HEARTBEAT_ACK, this::handleHeartbeatAck);
/*     */     
/* 176 */     this.httpClient = initHttpClient();
/* 177 */     this.receiver = newEmitterSink();
/* 178 */     this.sender = newEmitterSink();
/* 179 */     this.dispatch = newEmitterSink();
/* 180 */     this.outbound = newEmitterSink();
/* 181 */     this.heartbeats = newEmitterSink();
/*     */     
/* 183 */     this.heartbeatEmitter = new ResettableInterval(this.reactorResources.getTimerTaskScheduler());
/*     */     
/* 185 */     SessionInfo resumeSession = this.identifyOptions.getResumeSession().orElse(null);
/* 186 */     if (resumeSession != null) {
/* 187 */       this.sequence.set(resumeSession.getSequence());
/* 188 */       this.sessionId.set(resumeSession.getId());
/* 189 */       this.state = Sinks.many().replay().latestOrDefault(GatewayConnection.State.START_RESUMING);
/*     */     } else {
/* 191 */       this.state = Sinks.many().replay().latestOrDefault(GatewayConnection.State.START_IDENTIFYING);
/*     */     } 
/*     */   }
/*     */   
/*     */   private <T extends discord4j.discordjson.json.gateway.PayloadData> void addHandler(Opcode<T> op, PayloadHandler<T> handler) {
/* 196 */     this.handlerMap.put(op, handler);
/*     */   }
/*     */   
/*     */   private static <T> Sinks.Many<T> newEmitterSink() {
/* 200 */     return Sinks.many().multicast().onBackpressureBuffer(Queues.SMALL_BUFFER_SIZE, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> execute(String gatewayUrl) {
/* 205 */     return Mono.deferContextual(context -> {
/*     */           this.currentContext = context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.disconnectNotifier = Sinks.one();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.lastAck.set(0L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.lastSent.set(0L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.missedAck.set(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Sinks.Empty<Void> ping = Sinks.empty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> onConnected = this.state.asFlux().filter(()).next().then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Flux<ByteBuf> heartbeatFlux = this.heartbeats.asFlux().flatMap(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Flux<ByteBuf> identifyFlux = this.outbound.asFlux().filter(()).delayUntil(()).flatMap(()).transform((Function)this.identifyLimiter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Flux<ByteBuf> resumeFlux = this.outbound.asFlux().filter(()).flatMap(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Flux<ByteBuf> payloadFlux = this.outbound.asFlux().filter(DefaultGatewayClient::isNotStartupPayload).delayUntil(()).flatMap(()).transform(()).transform((Function)new RateLimitOperator(outboundLimiterCapacity(), Duration.ofSeconds(60L), this.reactorResources.getTimerTaskScheduler(), this.reactorResources.getPayloadSenderScheduler()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Flux<ByteBuf> outFlux = Flux.merge(new Publisher[] { (Publisher)heartbeatFlux, (Publisher)identifyFlux, (Publisher)resumeFlux, (Publisher)payloadFlux }).doOnNext(()).doOnDiscard(ByteBuf.class, DefaultGatewayClient::safeRelease);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.sessionHandler = new GatewayWebsocketHandler(this.receiver, outFlux, context);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> readyHandler = this.dispatch.asFlux().filter(DefaultGatewayClient::isReadyOrResumed).zipWith((Publisher)this.state.asFlux().next().repeat()).doOnNext(TupleUtils.consumer(())).then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Objects.requireNonNull(this.payloadReader);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> receiverFuture = this.receiver.asFlux().map(()).doOnNext(()).flatMap(this.payloadReader::read).doOnDiscard(ByteBuf.class, DefaultGatewayClient::safeRelease).doOnNext(()).map(this::updateSequence).flatMap(this::handlePayload).then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Objects.requireNonNull(this.sessionHandler);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> senderFuture = this.outbound.asFlux().doOnComplete(this.sessionHandler::close).doOnNext(()).then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> heartbeatHandler = this.heartbeatEmitter.ticks().flatMap(()).doOnNext(()).then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Objects.requireNonNull(this.sessionHandler);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Mono<Void> httpFuture = ((HttpClient.WebsocketSender)this.httpClient.websocket(((WebsocketClientSpec.Builder)WebsocketClientSpec.builder().maxFramePayloadLength(2147483647)).build()).uri(buildGatewayUrl(gatewayUrl))).handle(this.sessionHandler::handle).contextWrite(LogUtil.clearContext()).flatMap(()).then();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Objects.requireNonNull(this.heartbeatEmitter);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return Mono.zip(httpFuture, readyHandler, receiverFuture, senderFuture, heartbeatHandler).doOnError(()).doOnTerminate(this.heartbeatEmitter::stop).doOnCancel(()).then();
/* 338 */         }).contextWrite(ctx -> ctx.put("discord4j.shard", Integer.valueOf(this.identifyOptions.getShardInfo().getIndex())))
/* 339 */       .retryWhen(retryFactory())
/* 340 */       .then(Mono.defer(() -> this.disconnectNotifier.asMono().then()))
/* 341 */       .doOnSubscribe(s -> {
/*     */           if (this.disconnectNotifier != null) {
/*     */             throw new IllegalStateException("execute can only be subscribed once");
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private String buildGatewayUrl(String identifyGatewayUrl) {
/* 349 */     QueryStringDecoder query = new QueryStringDecoder(identifyGatewayUrl);
/* 350 */     return Optional.<String>ofNullable(this.resumeUrl.get())
/* 351 */       .map(url -> url + '?' + query.rawQuery())
/* 352 */       .orElse(identifyGatewayUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   private HttpClient initHttpClient() {
/* 357 */     HttpClient client = this.reactorResources.getHttpClient().headers(headers -> headers.add((CharSequence)HttpHeaderNames.USER_AGENT, initUserAgent()));
/* 358 */     if (this.observer == GatewayObserver.NOOP_LISTENER)
/*     */     {
/* 360 */       return client;
/*     */     }
/* 362 */     return client.observe((connection, newState) -> notifyObserver(newState));
/*     */   }
/*     */ 
/*     */   
/*     */   private String initUserAgent() {
/* 367 */     Properties properties = GitProperties.getProperties();
/* 368 */     String version = properties.getProperty("git.build.version", "3");
/* 369 */     String url = properties.getProperty("application.url", "https://discord4j.com");
/* 370 */     return "DiscordBot(" + url + ", " + version + ")";
/*     */   }
/*     */   
/*     */   private void notifyObserver(ConnectionObserver.State state) {
/* 374 */     this.observer.onStateChange(state, this);
/*     */   }
/*     */   
/*     */   private void logPayload(Logger logger, ContextView context, ByteBuf buf) {
/* 378 */     if (logger.isTraceEnabled()) {
/* 379 */       logger.trace(LogUtil.format(context, buf.toString(StandardCharsets.UTF_8)
/* 380 */             .replaceAll("(\"token\": ?\")([A-Za-z0-9._-]*)(\")", "$1hunter2$3")));
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean isNotStartupPayload(GatewayPayload<?> payload) {
/* 385 */     return (!Opcode.IDENTIFY.equals(payload.getOp()) && !Opcode.RESUME.equals(payload.getOp()));
/*     */   }
/*     */   
/*     */   private static boolean isReadyOrResumed(Dispatch d) {
/* 389 */     return (Ready.class.isAssignableFrom(d.getClass()) || Resumed.class.isAssignableFrom(d.getClass()));
/*     */   }
/*     */   
/*     */   private GatewayPayload<?> updateSequence(GatewayPayload<?> payload) {
/* 393 */     if (payload.getSequence() != null) {
/* 394 */       this.sequence.set(payload.getSequence().intValue());
/* 395 */       notifyObserver(GatewayObserver.SEQUENCE);
/*     */     } 
/* 397 */     return payload;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T extends discord4j.discordjson.json.gateway.PayloadData> Mono<Void> handlePayload(GatewayPayload<T> payload) {
/* 402 */     PayloadHandler<T> handler = (PayloadHandler<T>)this.handlerMap.get(payload.getOp());
/* 403 */     if (handler == null) {
/* 404 */       log.warn(LogUtil.format(this.currentContext, "Handler not found from: {}"), new Object[] { payload });
/* 405 */       return Mono.empty();
/*     */     } 
/* 407 */     return Mono.defer(() -> handler.handle(payload))
/* 408 */       .checkpoint("Dispatch handled for OP " + payload.getOp().getRawOp() + " seq " + payload
/* 409 */         .getSequence() + " type " + payload.getType());
/*     */   }
/*     */   
/*     */   private Mono<Void> handleDispatch(GatewayPayload<Dispatch> payload) {
/* 413 */     if (payload.getData() instanceof Ready) {
/* 414 */       Ready ready = (Ready)payload.getData();
/* 415 */       this.sessionId.set(ready.sessionId());
/* 416 */       this.resumeUrl.set(ready.resumeGatewayUrl());
/*     */     } 
/* 418 */     if (payload.getData() != null) {
/* 419 */       this.emissionStrategy.emitNext(this.dispatch, payload.getData());
/*     */     }
/* 421 */     return Mono.empty();
/*     */   }
/*     */   
/*     */   private Mono<Void> handleHeartbeat(GatewayPayload<Heartbeat> payload) {
/* 425 */     log.debug(LogUtil.format(this.currentContext, "Received heartbeat"));
/* 426 */     this.emissionStrategy.emitNext(this.outbound, GatewayPayload.heartbeat((Heartbeat)ImmutableHeartbeat.of(this.sequence.get())));
/* 427 */     return Mono.empty();
/*     */   }
/*     */   
/*     */   private Mono<Void> handleReconnect(GatewayPayload<?> payload) {
/* 431 */     this.sessionHandler.error((Throwable)new ReconnectException(this.currentContext, "Reconnecting due to reconnect packet received"));
/* 432 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<Void> handleInvalidSession(GatewayPayload<InvalidSession> payload) {
/* 437 */     if (((InvalidSession)payload.getData()).resumable()) {
/* 438 */       this.emissionStrategy.emitNext(this.outbound, 
/* 439 */           GatewayPayload.resume((Resume)ImmutableResume.of(this.token, this.sessionId.get(), this.sequence.get())));
/*     */     } else {
/* 441 */       this.resumeUrl.set(null);
/* 442 */       this.sessionHandler.error((Throwable)new InvalidSessionException(this.currentContext, "Reconnecting due to non-resumable session invalidation"));
/*     */     } 
/*     */     
/* 445 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<Void> handleHello(GatewayPayload<Hello> payload) {
/* 450 */     Duration interval = Duration.ofMillis(((Hello)payload.getData()).heartbeatInterval());
/* 451 */     this.heartbeatEmitter.start(Duration.ZERO, interval);
/* 452 */     return this.state.asFlux()
/* 453 */       .next()
/* 454 */       .doOnNext(state -> {
/*     */           
/*     */           if (state == GatewayConnection.State.START_RESUMING || state == GatewayConnection.State.RESUMING) {
/*     */             doResume(payload);
/*     */           } else {
/*     */             doIdentify(payload);
/*     */           } 
/* 461 */         }).then();
/*     */   }
/*     */   
/*     */   private void doResume(GatewayPayload<Hello> payload) {
/* 465 */     log.debug(LogUtil.format(this.currentContext, "Resuming Gateway session from {}"), new Object[] { Integer.valueOf(this.sequence.get()) });
/* 466 */     this.emissionStrategy.emitNext(this.outbound, 
/* 467 */         GatewayPayload.resume((Resume)ImmutableResume.of(this.token, this.sessionId.get(), this.sequence.get())));
/*     */   }
/*     */   
/*     */   private void doIdentify(GatewayPayload<Hello> payload) {
/* 471 */     ImmutableIdentifyProperties immutableIdentifyProperties = ImmutableIdentifyProperties.of(System.getProperty("os.name"), "Discord4J", "Discord4J");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 481 */     ImmutableIdentify immutableIdentify = Identify.builder().token(this.token).intents(this.identifyOptions.getIntents().<Possible>map(set -> Possible.of(Long.valueOf(set.getRawValue()))).orElse(Possible.absent())).properties((IdentifyProperties)immutableIdentifyProperties).compress(Boolean.valueOf(false)).largeThreshold(this.identifyOptions.getLargeThreshold()).shard(this.identifyOptions.getShardInfo().asArray()).presence(this.identifyOptions.getInitialStatus().<Possible>map(Possible::of).orElse(Possible.absent())).build();
/* 482 */     log.debug(LogUtil.format(this.currentContext, "Identifying to Gateway"), new Object[] { Integer.valueOf(this.sequence.get()) });
/* 483 */     this.emissionStrategy.emitNext(this.outbound, GatewayPayload.identify((Identify)immutableIdentify));
/*     */   }
/*     */   
/*     */   private Mono<Void> handleHeartbeatAck(GatewayPayload<?> context) {
/* 487 */     this.responseTime = this.lastAck.updateAndGet(x -> System.nanoTime()) - this.lastSent.get();
/* 488 */     this.missedAck.set(0);
/* 489 */     log.debug(LogUtil.format(this.currentContext, "Heartbeat acknowledged after {}"), new Object[] { getResponseTime() });
/* 490 */     return Mono.empty();
/*     */   }
/*     */   
/*     */   private Retry retryFactory() {
/* 494 */     return (Retry)GatewayRetrySpec.create(this.reconnectOptions, this.reconnectContext)
/* 495 */       .doBeforeRetry(retry -> {
/*     */           this.state.emitNext(retry.nextState(), Sinks.EmitFailureHandler.FAIL_FAST);
/*     */           long attempt = retry.iteration();
/*     */           Duration backoff = retry.nextBackoff();
/*     */           log.debug(LogUtil.format(getContextFromException(retry.failure()), "{} in {} (attempts: {})"), new Object[] { retry.nextState(), backoff, Long.valueOf(attempt) });
/*     */           if (retry.iteration() == 1L) {
/*     */             if (retry.nextState() == GatewayConnection.State.RESUMING) {
/*     */               this.emissionStrategy.emitNext(this.dispatch, GatewayStateChange.retryStarted(backoff));
/*     */               notifyObserver(GatewayObserver.RETRY_STARTED);
/*     */             } else {
/*     */               this.emissionStrategy.emitNext(this.dispatch, GatewayStateChange.retryStartedResume(backoff));
/*     */               notifyObserver(GatewayObserver.RETRY_RESUME_STARTED);
/*     */             } 
/*     */           } else {
/*     */             this.emissionStrategy.emitNext(this.dispatch, GatewayStateChange.retryFailed(attempt - 1L, backoff));
/*     */             notifyObserver(GatewayObserver.RETRY_FAILED);
/*     */           } 
/*     */           if (retry.nextState() == GatewayConnection.State.RECONNECTING) {
/*     */             this.emissionStrategy.emitNext(this.dispatch, GatewayStateChange.sessionInvalidated());
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private ContextView getContextFromException(Throwable t) {
/* 520 */     if (t instanceof CloseException) {
/* 521 */       return ((CloseException)t).getContext();
/*     */     }
/* 523 */     if (t instanceof GatewayException) {
/* 524 */       return ((GatewayException)t).getContext();
/*     */     }
/* 526 */     return (ContextView)Context.empty();
/*     */   }
/*     */   
/*     */   private Mono<CloseStatus> handleClose(DisconnectBehavior sourceBehavior, CloseStatus closeStatus) {
/* 530 */     return Mono.deferContextual(ctx -> {
/*     */           DisconnectBehavior behavior;
/*     */           if (GatewayRetrySpec.NON_RETRYABLE_STATUS_CODES.contains(Integer.valueOf(closeStatus.getCode()))) {
/*     */             behavior = DisconnectBehavior.stop(sourceBehavior.getCause());
/*     */           } else {
/*     */             behavior = sourceBehavior;
/*     */           } 
/*     */           log.debug(LogUtil.format(ctx, "Closing and {} with status {}"), new Object[] { behavior, closeStatus });
/*     */           this.state.emitNext(GatewayConnection.State.DISCONNECTING, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */           this.heartbeatEmitter.stop();
/*     */           if (behavior.getAction() == DisconnectBehavior.Action.STOP_ABRUPTLY) {
/*     */             this.emissionStrategy.emitNext(this.dispatch, GatewayStateChange.disconnectedResume());
/*     */             notifyObserver(GatewayObserver.DISCONNECTED_RESUME);
/*     */           } else if (behavior.getAction() == DisconnectBehavior.Action.STOP) {
/*     */             this.emissionStrategy.emitNext(this.dispatch, GatewayStateChange.disconnected(sourceBehavior, closeStatus));
/*     */             this.sequence.set(0);
/*     */             this.sessionId.set("");
/*     */             notifyObserver(GatewayObserver.DISCONNECTED);
/*     */           } 
/*     */           switch (behavior.getAction()) {
/*     */             case STOP_ABRUPTLY:
/*     */             case STOP:
/*     */               this.reconnectContext.clear();
/*     */               this.responseTime = 0L;
/*     */               this.lastSent.set(0L);
/*     */               this.lastAck.set(0L);
/*     */               this.state.emitNext(GatewayConnection.State.DISCONNECTED, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */               return (behavior.getCause() != null) ? Mono.just(new CloseException(closeStatus, ctx, behavior.getCause())).flatMap(()) : Mono.just(closeStatus).doOnNext(());
/*     */           } 
/*     */           return Mono.error((Throwable)new CloseException(closeStatus, ctx, behavior.getCause()));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<CloseStatus> close(boolean allowResume) {
/* 579 */     return Mono.defer(() -> {
/*     */           if (this.sessionHandler == null || this.disconnectNotifier == null) {
/*     */             return Mono.error(new IllegalStateException("Gateway client is not active!"));
/*     */           }
/*     */           if (allowResume) {
/*     */             this.sessionHandler.close(DisconnectBehavior.stopAbruptly(null));
/*     */           } else {
/*     */             this.sessionHandler.close(DisconnectBehavior.stop(null));
/*     */           } 
/*     */           return this.disconnectNotifier.asMono();
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Dispatch> dispatch() {
/* 594 */     return this.dispatch.asFlux();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GatewayPayload<?>> receiver() {
/* 599 */     Objects.requireNonNull(this.payloadReader); return receiver(this.payloadReader::read);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Flux<T> receiver(Function<ByteBuf, Publisher<? extends T>> mapper) {
/* 604 */     return this.receiver.asFlux()
/* 605 */       .map(ByteBuf::retainedDuplicate)
/* 606 */       .doOnDiscard(ByteBuf.class, DefaultGatewayClient::safeRelease)
/* 607 */       .flatMap(mapper);
/*     */   }
/*     */   
/*     */   private static void safeRelease(ByteBuf buf) {
/* 611 */     if (buf.refCnt() > 0) {
/*     */       try {
/* 613 */         buf.release();
/* 614 */       } catch (IllegalReferenceCountException e) {
/* 615 */         if (log.isDebugEnabled()) {
/* 616 */           log.debug("", (Throwable)e);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Sinks.Many<GatewayPayload<?>> sender() {
/* 624 */     return this.outbound;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> sendBuffer(Publisher<ByteBuf> publisher) {
/* 629 */     return Flux.from(publisher).doOnNext(buf -> this.emissionStrategy.emitNext(this.sender, buf)).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getShardCount() {
/* 634 */     return this.identifyOptions.getShardInfo().getCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSessionId() {
/* 639 */     return this.sessionId.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSequence() {
/* 644 */     return this.sequence.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<GatewayConnection.State> stateEvents() {
/* 649 */     return this.state.asFlux();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Boolean> isConnected() {
/* 654 */     return this.state.asFlux().next()
/* 655 */       .filter(s -> (s == GatewayConnection.State.CONNECTED))
/* 656 */       .hasElement()
/* 657 */       .defaultIfEmpty(Boolean.valueOf(false));
/*     */   }
/*     */ 
/*     */   
/*     */   public Duration getResponseTime() {
/* 662 */     return Duration.ofNanos(this.responseTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int outboundLimiterCapacity() {
/* 672 */     String capacityValue = System.getProperty("discord4j.gateway.outbound.capacity");
/* 673 */     if (capacityValue != null) {
/*     */       try {
/* 675 */         int capacity = Integer.parseInt(capacityValue);
/* 676 */         log.info("Overriding default outbound limiter capacity: {}", new Object[] { Integer.valueOf(capacity) });
/* 677 */         return capacity;
/* 678 */       } catch (NumberFormatException e) {
/* 679 */         log.warn("Invalid custom outbound limiter capacity: {}", new Object[] { capacityValue });
/*     */       } 
/*     */     }
/* 682 */     return 115;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\DefaultGatewayClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */