/*     */ package discord4j.gateway;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShardInfo
/*     */ {
/*  35 */   private static final Map<Tuple2<Integer, Integer>, ShardInfo> CACHE = new ConcurrentHashMap<>();
/*     */   
/*     */   private final int index;
/*     */   private final int count;
/*     */   
/*     */   private ShardInfo(int index, int count) {
/*  41 */     this.index = index;
/*  42 */     this.count = count;
/*     */   }
/*     */   
/*     */   @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
/*     */   public static ShardInfo create(@JsonProperty("index") int index, @JsonProperty("count") int count) {
/*  47 */     return CACHE.computeIfAbsent(Tuples.of(Integer.valueOf(index), Integer.valueOf(count)), t2 -> new ShardInfo(((Integer)t2.getT1()).intValue(), ((Integer)t2.getT2()).intValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/*  56 */     return this.index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount() {
/*  65 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] asArray() {
/*  74 */     return new int[] { this.index, this.count };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*  79 */     if (this == o) {
/*  80 */       return true;
/*     */     }
/*  82 */     if (o == null || getClass() != o.getClass()) {
/*  83 */       return false;
/*     */     }
/*  85 */     ShardInfo shardInfo = (ShardInfo)o;
/*  86 */     return (this.index == shardInfo.index && this.count == shardInfo.count);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  91 */     return Objects.hash(new Object[] { Integer.valueOf(this.index), Integer.valueOf(this.count) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String format() {
/* 100 */     return this.index + "," + this.count;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 105 */     return "ShardInfo{index=" + this.index + ", count=" + this.count + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\ShardInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */