/*     */ package discord4j.gateway;
/*     */ 
/*     */ import reactor.netty.ConnectionObserver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface GatewayObserver
/*     */ {
/*     */   public static final GatewayObserver NOOP_LISTENER = (newState, client) -> {
/*     */     
/*     */     };
/*     */   
/*     */   static GatewayObserver emptyListener() {
/*  31 */     return NOOP_LISTENER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default GatewayObserver then(GatewayObserver other) {
/*  49 */     return CompositeGatewayObserver.compose(this, other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final ConnectionObserver.State CONNECTED = new ConnectionObserver.State()
/*     */     {
/*     */       public String toString() {
/*  58 */         return "[gateway_connected]";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final ConnectionObserver.State DISCONNECTED = new ConnectionObserver.State()
/*     */     {
/*     */       public String toString() {
/*  68 */         return "[gateway_disconnected]";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public static final ConnectionObserver.State DISCONNECTED_RESUME = new ConnectionObserver.State()
/*     */     {
/*     */       public String toString() {
/*  78 */         return "[gateway_disconnected_resume]";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static final ConnectionObserver.State RETRY_RESUME_STARTED = new ConnectionObserver.State()
/*     */     {
/*     */       public String toString() {
/*  88 */         return "[retry_resume_started]";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public static final ConnectionObserver.State RETRY_STARTED = new ConnectionObserver.State()
/*     */     {
/*     */       public String toString() {
/*  98 */         return "[retry_started]";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public static final ConnectionObserver.State RETRY_SUCCEEDED = new ConnectionObserver.State()
/*     */     {
/*     */       public String toString() {
/* 108 */         return "[retry_succeeded]";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static final ConnectionObserver.State RETRY_FAILED = new ConnectionObserver.State()
/*     */     {
/*     */       public String toString() {
/* 118 */         return "[retry_failed]";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public static final ConnectionObserver.State SEQUENCE = new ConnectionObserver.State()
/*     */     {
/*     */       public String toString() {
/* 128 */         return "[sequence]";
/*     */       }
/*     */     };
/*     */   
/*     */   void onStateChange(ConnectionObserver.State paramState, GatewayClient paramGatewayClient);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\GatewayObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */