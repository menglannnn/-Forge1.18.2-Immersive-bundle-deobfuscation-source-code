/*    */ package discord4j.gateway;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.ByteBufAllocator;
/*    */ import io.netty.buffer.ByteBufUtil;
/*    */ import io.netty.buffer.CompositeByteBuf;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.zip.Inflater;
/*    */ import java.util.zip.InflaterOutputStream;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZlibDecompressor
/*    */ {
/*    */   private static final int ZLIB_SUFFIX = 65535;
/*    */   private static final Predicate<ByteBuf> windowPredicate;
/*    */   private final ByteBufAllocator allocator;
/*    */   
/*    */   static {
/* 35 */     windowPredicate = (payload -> 
/* 36 */       (payload.readableBytes() >= 4 && payload.getInt(payload.readableBytes() - 4) == 65535));
/*    */   }
/*    */   
/* 39 */   private final Inflater context = new Inflater();
/*    */   private final boolean unpooled;
/*    */   
/*    */   public ZlibDecompressor(ByteBufAllocator allocator) {
/* 43 */     this(allocator, false);
/*    */   }
/*    */   
/*    */   public ZlibDecompressor(ByteBufAllocator allocator, boolean unpooled) {
/* 47 */     this.allocator = allocator;
/* 48 */     this.unpooled = unpooled;
/*    */   }
/*    */   
/*    */   public Flux<ByteBuf> completeMessages(Flux<ByteBuf> payloads) {
/* 52 */     return payloads.windowUntil(windowPredicate)
/* 53 */       .flatMap(Flux::collectList)
/* 54 */       .map(list -> {
/*    */           CompositeByteBuf compositeByteBuf; if (list.size() == 1) {
/*    */             ByteBuf buf = list.get(0);
/*    */           } else {
/*    */             CompositeByteBuf composite = this.allocator.compositeBuffer(list.size()); for (ByteBuf component : list)
/*    */               composite.addComponent(true, component);  compositeByteBuf = composite;
/*    */           }  ByteArrayOutputStream out = new ByteArrayOutputStream(); try {
/*    */             InflaterOutputStream inflater = new InflaterOutputStream(out, this.context); 
/*    */             try { inflater.write(ByteBufUtil.getBytes((ByteBuf)compositeByteBuf, compositeByteBuf.readerIndex(), compositeByteBuf.readableBytes(), false)); ByteBuf outBuffer = this.unpooled ? Unpooled.buffer() : this.allocator.buffer();
/*    */               ByteBuf byteBuf1 = outBuffer.writeBytes(out.toByteArray()).asReadOnly();
/*    */               inflater.close();
/*    */               return byteBuf1; }
/* 66 */             catch (Throwable throwable) { try { inflater.close(); } catch (Throwable throwable1)
/*    */               { throwable.addSuppressed(throwable1); }
/*    */                throw throwable; }
/*    */           
/* 70 */           } catch (IOException e) {
/*    */             throw Exceptions.propagate(e);
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\ZlibDecompressor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */