/*    */ package discord4j.gateway;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GatewayConnection
/*    */ {
/*    */   public enum State
/*    */   {
/* 26 */     START_IDENTIFYING,
/*    */ 
/*    */ 
/*    */     
/* 30 */     START_RESUMING,
/*    */ 
/*    */ 
/*    */     
/* 34 */     CONNECTED,
/*    */ 
/*    */ 
/*    */     
/* 38 */     DISCONNECTING,
/*    */ 
/*    */ 
/*    */     
/* 42 */     RESUMING,
/*    */ 
/*    */ 
/*    */     
/* 46 */     RECONNECTING,
/*    */ 
/*    */ 
/*    */     
/* 50 */     DISCONNECTED;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\GatewayConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */