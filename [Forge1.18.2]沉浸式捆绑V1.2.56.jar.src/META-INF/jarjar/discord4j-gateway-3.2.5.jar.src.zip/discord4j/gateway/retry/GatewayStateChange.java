/*    */ package discord4j.gateway.retry;
/*    */ 
/*    */ import discord4j.common.close.CloseStatus;
/*    */ import discord4j.common.close.DisconnectBehavior;
/*    */ import discord4j.discordjson.json.gateway.Dispatch;
/*    */ import java.time.Duration;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GatewayStateChange
/*    */   implements Dispatch
/*    */ {
/*    */   private final State state;
/*    */   private final long currentAttempt;
/*    */   private final Duration backoff;
/*    */   
/*    */   public enum State
/*    */   {
/* 30 */     CONNECTED, DISCONNECTED, DISCONNECTED_RESUME, RETRY_STARTED, RETRY_RESUME_STARTED, RETRY_SUCCEEDED,
/* 31 */     RETRY_FAILED, SESSION_INVALIDATED;
/*    */   }
/*    */   
/*    */   public static GatewayStateChange connected() {
/* 35 */     return new GatewayStateChange(State.CONNECTED, 0L, null);
/*    */   }
/*    */   
/*    */   public static ClosingStateChange disconnected(DisconnectBehavior behavior, CloseStatus status) {
/* 39 */     return new ClosingStateChange(behavior, status);
/*    */   }
/*    */   
/*    */   public static GatewayStateChange disconnectedResume() {
/* 43 */     return new GatewayStateChange(State.DISCONNECTED_RESUME, 0L, null);
/*    */   }
/*    */   
/*    */   public static GatewayStateChange retryStarted(Duration nextAttemptBackoff) {
/* 47 */     return new GatewayStateChange(State.RETRY_STARTED, 1L, nextAttemptBackoff);
/*    */   }
/*    */   
/*    */   public static GatewayStateChange retryStartedResume(Duration nextAttemptBackoff) {
/* 51 */     return new GatewayStateChange(State.RETRY_RESUME_STARTED, 1L, nextAttemptBackoff);
/*    */   }
/*    */   
/*    */   public static GatewayStateChange retrySucceeded(long currentAttempt) {
/* 55 */     return new GatewayStateChange(State.RETRY_SUCCEEDED, currentAttempt, null);
/*    */   }
/*    */   
/*    */   public static GatewayStateChange retryFailed(long currentAttempt, Duration nextAttemptBackoff) {
/* 59 */     return new GatewayStateChange(State.RETRY_FAILED, currentAttempt, nextAttemptBackoff);
/*    */   }
/*    */   
/*    */   public static GatewayStateChange sessionInvalidated() {
/* 63 */     return new GatewayStateChange(State.SESSION_INVALIDATED, 0L, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected GatewayStateChange(State state, long currentAttempt, @Nullable Duration backoff) {
/* 71 */     this.state = state;
/* 72 */     this.currentAttempt = currentAttempt;
/* 73 */     this.backoff = backoff;
/*    */   }
/*    */   
/*    */   public State getState() {
/* 77 */     return this.state;
/*    */   }
/*    */   
/*    */   public long getCurrentAttempt() {
/* 81 */     return this.currentAttempt;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Duration getBackoff() {
/* 86 */     return this.backoff;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     return "GatewayStateChanged[state=" + this.state + ", currentAttempt=" + this.currentAttempt + ", backoff=" + this.backoff + ']';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\retry\GatewayStateChange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */