/*    */ package discord4j.gateway.retry;
/*    */ 
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GatewayException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final ContextView context;
/*    */   
/*    */   public GatewayException(ContextView context) {
/* 27 */     this.context = context;
/*    */   }
/*    */   
/*    */   public GatewayException(ContextView context, String message) {
/* 31 */     super(message);
/* 32 */     this.context = context;
/*    */   }
/*    */   
/*    */   public ContextView getContext() {
/* 36 */     return this.context;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\retry\GatewayException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */