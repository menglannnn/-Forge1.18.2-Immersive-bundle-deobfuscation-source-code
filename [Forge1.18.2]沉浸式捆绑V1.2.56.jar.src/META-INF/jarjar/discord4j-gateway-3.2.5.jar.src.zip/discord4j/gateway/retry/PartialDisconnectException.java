/*    */ package discord4j.gateway.retry;
/*    */ 
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PartialDisconnectException
/*    */   extends GatewayException
/*    */ {
/*    */   public PartialDisconnectException(ContextView context) {
/* 25 */     super(context);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\retry\PartialDisconnectException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */