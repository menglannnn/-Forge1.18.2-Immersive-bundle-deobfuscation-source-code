/*    */ package discord4j.gateway.retry;
/*    */ 
/*    */ import discord4j.common.close.CloseStatus;
/*    */ import discord4j.common.close.DisconnectBehavior;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClosingStateChange
/*    */   extends GatewayStateChange
/*    */ {
/*    */   private final DisconnectBehavior behavior;
/*    */   private final CloseStatus status;
/*    */   
/*    */   protected ClosingStateChange(DisconnectBehavior behavior, CloseStatus status) {
/* 28 */     super(GatewayStateChange.State.DISCONNECTED, 0L, null);
/* 29 */     this.behavior = behavior;
/* 30 */     this.status = status;
/*    */   }
/*    */   
/*    */   public DisconnectBehavior getBehavior() {
/* 34 */     return this.behavior;
/*    */   }
/*    */   
/*    */   public CloseStatus getStatus() {
/* 38 */     return this.status;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\retry\ClosingStateChange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */