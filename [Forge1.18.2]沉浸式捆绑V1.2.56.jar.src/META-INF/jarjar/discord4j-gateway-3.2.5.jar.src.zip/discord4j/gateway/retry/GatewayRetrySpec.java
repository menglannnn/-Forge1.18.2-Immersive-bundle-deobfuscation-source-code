/*     */ package discord4j.gateway.retry;
/*     */ 
/*     */ import discord4j.common.close.CloseException;
/*     */ import discord4j.common.retry.ReconnectContext;
/*     */ import discord4j.common.retry.ReconnectOptions;
/*     */ import discord4j.gateway.GatewayConnection;
/*     */ import java.time.Duration;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.function.Consumer;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.retry.Retry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GatewayRetrySpec
/*     */   extends Retry
/*     */ {
/*  38 */   public static final List<Integer> NON_RETRYABLE_STATUS_CODES = Arrays.asList(new Integer[] {
/*  39 */         Integer.valueOf(4004), 
/*  40 */         Integer.valueOf(4010), 
/*  41 */         Integer.valueOf(4011), 
/*  42 */         Integer.valueOf(4012), 
/*  43 */         Integer.valueOf(4013), 
/*  44 */         Integer.valueOf(4014)
/*     */       });
/*     */   
/*     */   private static final Consumer<GatewayRetrySignal> NO_OP_CONSUMER = retrySignal -> {
/*     */     
/*     */     };
/*     */   private final ReconnectOptions reconnectOptions;
/*     */   private final ReconnectContext reconnectContext;
/*     */   private final Consumer<GatewayRetrySignal> doPreRetry;
/*     */   
/*     */   GatewayRetrySpec(ReconnectOptions reconnectOptions, ReconnectContext reconnectContext, Consumer<GatewayRetrySignal> doPreRetry) {
/*  55 */     this.reconnectOptions = reconnectOptions;
/*  56 */     this.reconnectContext = reconnectContext;
/*  57 */     this.doPreRetry = doPreRetry;
/*     */   }
/*     */   
/*     */   public static GatewayRetrySpec create(ReconnectOptions reconnectOptions, ReconnectContext reconnectContext) {
/*  61 */     return new GatewayRetrySpec(reconnectOptions, reconnectContext, NO_OP_CONSUMER);
/*     */   }
/*     */   
/*     */   public GatewayRetrySpec doBeforeRetry(Consumer<GatewayRetrySignal> doBeforeRetry) {
/*  65 */     return new GatewayRetrySpec(this.reconnectOptions, this.reconnectContext, this.doPreRetry.andThen(doBeforeRetry));
/*     */   }
/*     */   
/*     */   private boolean isRetryable(@Nullable Throwable t) {
/*  69 */     if (t instanceof CloseException) {
/*  70 */       CloseException closeException = (CloseException)t;
/*  71 */       return !NON_RETRYABLE_STATUS_CODES.contains(Integer.valueOf(closeException.getCode()));
/*     */     } 
/*  73 */     return !(t instanceof PartialDisconnectException);
/*     */   }
/*     */   
/*     */   private boolean canResume(Throwable t) {
/*  77 */     if (t instanceof CloseException) {
/*  78 */       CloseException closeException = (CloseException)t;
/*  79 */       return (closeException.getCode() < 4000);
/*     */     } 
/*  81 */     return !(t instanceof InvalidSessionException);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Long> generateCompanion(Flux<Retry.RetrySignal> t) {
/*  86 */     return t.concatMap(retryWhenState -> {
/*     */           Duration nextBackoff;
/*     */           GatewayConnection.State nextState;
/*     */           Retry.RetrySignal copy = retryWhenState.copy();
/*     */           Throwable currentFailure = copy.failure();
/*     */           if (currentFailure == null) {
/*     */             return (Publisher)Mono.error(new IllegalStateException("Retry.RetrySignal#failure() not expected to be null"));
/*     */           }
/*     */           if (!isRetryable(currentFailure)) {
/*     */             return (Publisher)Mono.error(currentFailure);
/*     */           }
/*     */           if (currentFailure instanceof InvalidSessionException) {
/*     */             this.reconnectContext.reset();
/*     */           }
/*     */           long iteration = this.reconnectContext.getAttempts();
/*     */           if (iteration >= this.reconnectOptions.getMaxRetries()) {
/*     */             return (Publisher)Mono.error(Exceptions.retryExhausted("Retries exhausted: " + iteration + "/" + this.reconnectOptions.getMaxRetries(), copy.failure()));
/*     */           }
/*     */           Duration minBackoff = this.reconnectOptions.getFirstBackoff();
/*     */           Duration maxBackoff = this.reconnectOptions.getMaxBackoffInterval();
/*     */           if (canResume(currentFailure)) {
/*     */             if (iteration == 1L) {
/*     */               nextBackoff = Duration.ZERO;
/*     */             } else {
/*     */               nextBackoff = computeBackoff(iteration - 2L, minBackoff, maxBackoff);
/*     */             } 
/*     */             nextState = GatewayConnection.State.RESUMING;
/*     */           } else {
/*     */             nextBackoff = computeBackoff(iteration - 1L, minBackoff, maxBackoff);
/*     */             nextState = GatewayConnection.State.RECONNECTING;
/*     */           } 
/*     */           this.reconnectContext.next();
/*     */           if (nextBackoff.isZero()) {
/*     */             return (Publisher)applyHooks(new GatewayRetrySignal(copy.failure(), iteration, nextBackoff, nextState), Mono.just(Long.valueOf(iteration)), this.doPreRetry);
/*     */           }
/*     */           Duration effectiveBackoff = nextBackoff.plusMillis(computeJitter(nextBackoff, minBackoff, maxBackoff, this.reconnectOptions.getJitterFactor()));
/*     */           return (Publisher)applyHooks(new GatewayRetrySignal(copy.failure(), iteration, effectiveBackoff, nextState), Mono.delay(effectiveBackoff, this.reconnectOptions.getBackoffScheduler()), this.doPreRetry);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long computeJitter(Duration nextBackoff, Duration minBackoff, Duration maxBackoff, double factor) {
/*     */     long jitterOffset;
/* 154 */     ThreadLocalRandom random = ThreadLocalRandom.current();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 160 */       jitterOffset = nextBackoff.multipliedBy((long)(100.0D * factor)).dividedBy(100L).toMillis();
/* 161 */     } catch (ArithmeticException ae) {
/* 162 */       jitterOffset = Math.round(9.223372036854776E18D * factor);
/*     */     } 
/* 164 */     long lowBound = Math.max(minBackoff.minus(nextBackoff).toMillis(), -jitterOffset);
/* 165 */     long highBound = Math.min(maxBackoff.minus(nextBackoff).toMillis(), jitterOffset);
/*     */ 
/*     */     
/* 168 */     if (highBound == lowBound) {
/* 169 */       if (highBound == 0L) {
/* 170 */         return 0L;
/*     */       }
/* 172 */       return random.nextLong(highBound);
/*     */     } 
/*     */     
/* 175 */     return random.nextLong(lowBound, highBound);
/*     */   }
/*     */ 
/*     */   
/*     */   static Duration computeBackoff(long iteration, Duration minBackoff, Duration maxBackoff) {
/*     */     Duration nextBackoff;
/*     */     try {
/* 182 */       nextBackoff = minBackoff.multipliedBy((long)Math.pow(2.0D, iteration));
/* 183 */       if (nextBackoff.compareTo(maxBackoff) > 0) {
/* 184 */         nextBackoff = maxBackoff;
/*     */       }
/* 186 */     } catch (ArithmeticException overflow) {
/* 187 */       nextBackoff = maxBackoff;
/*     */     } 
/* 189 */     return nextBackoff;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Mono<T> applyHooks(GatewayRetrySignal retrySignal, Mono<T> originalCompanion, Consumer<GatewayRetrySignal> doPreRetry) {
/* 195 */     if (doPreRetry != NO_OP_CONSUMER) {
/*     */       try {
/* 197 */         doPreRetry.accept(retrySignal);
/* 198 */       } catch (Throwable e) {
/* 199 */         return Mono.error(e);
/*     */       } 
/*     */     }
/* 202 */     return originalCompanion;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\retry\GatewayRetrySpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */