/*    */ package discord4j.gateway.retry;
/*    */ 
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReconnectException
/*    */   extends GatewayException
/*    */ {
/*    */   public ReconnectException(ContextView context, String message) {
/* 28 */     super(context, message);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\retry\ReconnectException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */