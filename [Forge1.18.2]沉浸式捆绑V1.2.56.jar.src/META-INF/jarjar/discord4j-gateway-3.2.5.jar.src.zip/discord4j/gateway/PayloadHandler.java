package discord4j.gateway;

import discord4j.gateway.json.GatewayPayload;
import reactor.core.publisher.Mono;

@FunctionalInterface
public interface PayloadHandler<T extends discord4j.discordjson.json.gateway.PayloadData> {
  Mono<Void> handle(GatewayPayload<T> paramGatewayPayload);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\PayloadHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */