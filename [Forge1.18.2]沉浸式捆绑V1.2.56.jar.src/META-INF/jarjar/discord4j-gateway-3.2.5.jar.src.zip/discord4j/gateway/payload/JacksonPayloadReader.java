/*    */ package discord4j.gateway.payload;
/*    */ 
/*    */ import com.fasterxml.jackson.core.type.TypeReference;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import discord4j.gateway.json.GatewayPayload;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.ByteBufUtil;
/*    */ import io.netty.util.ReferenceCountUtil;
/*    */ import java.io.IOException;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.publisher.MonoSink;
/*    */ import reactor.util.Logger;
/*    */ import reactor.util.Loggers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JacksonPayloadReader
/*    */   implements PayloadReader
/*    */ {
/* 35 */   private static final Logger log = Loggers.getLogger(JacksonPayloadReader.class);
/*    */   
/*    */   private final ObjectMapper mapper;
/*    */   private final boolean lenient;
/*    */   
/*    */   public JacksonPayloadReader(ObjectMapper mapper) {
/* 41 */     this(mapper, true);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public JacksonPayloadReader(ObjectMapper mapper, boolean lenient) {
/* 46 */     this.mapper = mapper;
/* 47 */     this.lenient = lenient;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<GatewayPayload<?>> read(ByteBuf buf) {
/* 52 */     return Mono.create(sink -> {
/*    */           sink.onDispose(());
/*    */           try {
/*    */             GatewayPayload<?> value = (GatewayPayload)this.mapper.readValue(ByteBufUtil.getBytes(buf, buf.readerIndex(), buf.readableBytes(), false), new TypeReference<GatewayPayload<?>>() {
/*    */                 
/*    */                 });
/*    */             sink.success(value);
/* 59 */           } catch (IllegalArgumentException e) {
/*    */             sink.success();
/* 61 */           } catch (IOException e) {
/*    */             if (this.lenient) {
/*    */               if (buf.readableBytes() > 0)
/*    */                 log.warn("Error while decoding JSON ({}): {}", new Object[] { e.toString(), new String(ByteBufUtil.getBytes(buf), StandardCharsets.UTF_8) }); 
/*    */               sink.success();
/*    */             } else {
/*    */               sink.error(Exceptions.propagate(e));
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\payload\JacksonPayloadReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */