package discord4j.gateway.payload;

import discord4j.gateway.json.GatewayPayload;
import io.netty.buffer.ByteBuf;
import org.reactivestreams.Publisher;

public interface PayloadWriter {
  Publisher<ByteBuf> write(GatewayPayload<?> paramGatewayPayload);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\payload\PayloadWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */