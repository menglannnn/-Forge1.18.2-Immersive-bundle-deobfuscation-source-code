/*    */ package discord4j.gateway.payload;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import discord4j.gateway.json.GatewayPayload;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import org.reactivestreams.Publisher;
/*    */ import reactor.core.Exceptions;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.publisher.MonoSink;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JacksonPayloadWriter
/*    */   implements PayloadWriter
/*    */ {
/*    */   private final ObjectMapper mapper;
/*    */   
/*    */   public JacksonPayloadWriter(ObjectMapper mapper) {
/* 32 */     this.mapper = mapper;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ByteBuf> write(GatewayPayload<?> payload) {
/* 37 */     return Mono.create(sink -> sink.onRequest(()));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\payload\JacksonPayloadWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */