/*     */ package discord4j.gateway.intent;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IntentSet
/*     */   extends AbstractSet<Intent>
/*     */ {
/*     */   private static final long ALL_RAW;
/*     */   private static final long NONE_RAW = 0L;
/*     */   
/*     */   static {
/*  40 */     ALL_RAW = Arrays.<Intent>stream(Intent.values()).mapToLong(Intent::getValue).reduce(0L, (a, b) -> a | b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private static final IntentSet ALL = new IntentSet(ALL_RAW);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private static final IntentSet NONE = new IntentSet(0L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static final IntentSet NON_PRIVILEGED = ALL
/*  57 */     .andNot(of(new Intent[] { Intent.GUILD_PRESENCES, Intent.GUILD_MEMBERS, Intent.MESSAGE_CONTENT }));
/*     */ 
/*     */   
/*     */   private final long rawValue;
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntentSet all() {
/*  65 */     return ALL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntentSet none() {
/*  74 */     return NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntentSet nonPrivileged() {
/*  84 */     return NON_PRIVILEGED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntentSet of(long rawValue) {
/*  94 */     return new IntentSet(rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntentSet of(Intent... intents) {
/* 106 */     long rawValue = Arrays.<Intent>stream(intents).mapToLong(Intent::getValue).reduce(0L, (left, right) -> left | right);
/* 107 */     return new IntentSet(rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IntentSet(long rawValue) {
/* 121 */     this.rawValue = rawValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntentSet and(IntentSet other) {
/* 143 */     return of(this.rawValue & other.rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntentSet or(IntentSet other) {
/* 164 */     return of(this.rawValue | other.rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntentSet xor(IntentSet other) {
/* 185 */     return of(this.rawValue ^ other.rawValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntentSet andNot(IntentSet other) {
/* 207 */     return of(this.rawValue & (other.rawValue ^ 0xFFFFFFFFFFFFFFFFL));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntentSet not() {
/* 226 */     return of((this.rawValue ^ 0xFFFFFFFFFFFFFFFFL) & ALL_RAW);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<Intent> asEnumSet() {
/* 235 */     EnumSet<Intent> intents = EnumSet.allOf(Intent.class);
/* 236 */     intents.removeIf(intent -> !contains(intent));
/* 237 */     return intents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRawValue() {
/* 247 */     return this.rawValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 252 */     return (o instanceof Intent && (((Intent)o).getValue() & this.rawValue) > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Intent> iterator() {
/* 258 */     return Collections.<Intent>unmodifiableSet(asEnumSet()).iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 263 */     return Long.bitCount(this.rawValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 268 */     if (this == o) {
/* 269 */       return true;
/*     */     }
/* 271 */     if (o == null || getClass() != o.getClass()) {
/* 272 */       return false;
/*     */     }
/*     */     
/* 275 */     IntentSet that = (IntentSet)o;
/* 276 */     return (this.rawValue == that.rawValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 281 */     return Long.hashCode(this.rawValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 286 */     return "IntentSet{rawValue=" + this.rawValue + "} " + super
/*     */       
/* 288 */       .toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\intent\IntentSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */