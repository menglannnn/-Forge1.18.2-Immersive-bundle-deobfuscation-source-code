/*     */ package discord4j.gateway;
/*     */ 
/*     */ import discord4j.discordjson.json.gateway.StatusUpdate;
/*     */ import discord4j.gateway.intent.IntentSet;
/*     */ import java.util.Optional;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentifyOptions
/*     */ {
/*     */   private final ShardInfo shardInfo;
/*     */   @Nullable
/*     */   private final StatusUpdate initialStatus;
/*     */   @Nullable
/*     */   private final IntentSet intents;
/*     */   private final int largeThreshold;
/*     */   @Nullable
/*     */   private final SessionInfo resumeSession;
/*     */   
/*     */   protected IdentifyOptions(Builder builder) {
/*  46 */     this.shardInfo = builder.shardInfo;
/*  47 */     this.initialStatus = builder.initialStatus;
/*  48 */     this.intents = builder.intents;
/*  49 */     this.largeThreshold = builder.largeThreshold;
/*  50 */     this.resumeSession = builder.resumeSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IdentifyOptions create(int shardIndex, int shardCount) {
/*  61 */     return builder(ShardInfo.create(shardIndex, shardCount)).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IdentifyOptions create(ShardInfo shardInfo) {
/*  71 */     return builder(shardInfo).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(int shardIndex, int shardCount) {
/*  82 */     return new Builder(ShardInfo.create(shardIndex, shardCount));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(ShardInfo shardInfo) {
/*  92 */     return new Builder(shardInfo);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private final ShardInfo shardInfo;
/*     */     
/*     */     private StatusUpdate initialStatus;
/*     */     
/*     */     private IntentSet intents;
/* 103 */     private int largeThreshold = 250;
/*     */ 
/*     */ 
/*     */     
/*     */     private SessionInfo resumeSession;
/*     */ 
/*     */ 
/*     */     
/*     */     protected Builder(ShardInfo shardInfo) {
/* 112 */       this.shardInfo = ShardInfo.create(shardInfo.getIndex(), shardInfo.getCount());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder initialStatus(@Nullable StatusUpdate initialStatus) {
/* 122 */       this.initialStatus = initialStatus;
/* 123 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder intents(@Nullable IntentSet intents) {
/* 133 */       this.intents = intents;
/* 134 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder largeThreshold(int largeThreshold) {
/* 144 */       this.largeThreshold = largeThreshold;
/* 145 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder resumeSession(@Nullable SessionInfo resumeSession) {
/* 156 */       this.resumeSession = resumeSession;
/* 157 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IdentifyOptions build() {
/* 166 */       return new IdentifyOptions(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder mutate() {
/* 176 */     return (new Builder(this.shardInfo))
/* 177 */       .initialStatus(this.initialStatus)
/* 178 */       .intents(this.intents)
/* 179 */       .largeThreshold(this.largeThreshold)
/* 180 */       .resumeSession(this.resumeSession);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder mutate(ShardInfo shardInfo) {
/* 191 */     return (new Builder(shardInfo))
/* 192 */       .initialStatus(this.initialStatus)
/* 193 */       .intents(this.intents)
/* 194 */       .largeThreshold(this.largeThreshold)
/* 195 */       .resumeSession(this.resumeSession);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShardInfo getShardInfo() {
/* 204 */     return this.shardInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<StatusUpdate> getInitialStatus() {
/* 213 */     return Optional.ofNullable(this.initialStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<IntentSet> getIntents() {
/* 222 */     return Optional.ofNullable(this.intents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLargeThreshold() {
/* 232 */     return this.largeThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<SessionInfo> getResumeSession() {
/* 241 */     return Optional.ofNullable(this.resumeSession);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 246 */     return "IdentifyOptions{shardInfo=" + this.shardInfo + ", initialStatus=" + this.initialStatus + ", intents=" + this.intents + ", largeThreshold=" + this.largeThreshold + ", resumeSession=" + this.resumeSession + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\IdentifyOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */