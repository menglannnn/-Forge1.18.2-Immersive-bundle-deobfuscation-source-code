/*     */ package discord4j.gateway;
/*     */ 
/*     */ import discord4j.common.LogUtil;
/*     */ import discord4j.common.close.CloseStatus;
/*     */ import discord4j.common.close.DisconnectBehavior;
/*     */ import discord4j.common.sinks.EmissionStrategy;
/*     */ import discord4j.gateway.retry.GatewayException;
/*     */ import discord4j.gateway.retry.PartialDisconnectException;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.DefaultByteBufHolder;
/*     */ import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
/*     */ import io.netty.handler.codec.http.websocketx.WebSocketCloseStatus;
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.netty.Connection;
/*     */ import reactor.netty.http.websocket.WebsocketInbound;
/*     */ import reactor.netty.http.websocket.WebsocketOutbound;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ import reactor.util.context.ContextView;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GatewayWebsocketHandler
/*     */ {
/*  60 */   private static final Logger log = Loggers.getLogger(GatewayWebsocketHandler.class);
/*     */ 
/*     */   
/*     */   private final Sinks.Many<ByteBuf> inbound;
/*     */   
/*     */   private final Flux<ByteBuf> outbound;
/*     */   
/*     */   private final Sinks.One<DisconnectBehavior> sessionClose;
/*     */   
/*     */   private final ContextView context;
/*     */   
/*     */   private final boolean unpooled;
/*     */   
/*     */   private final EmissionStrategy emissionStrategy;
/*     */ 
/*     */   
/*     */   public GatewayWebsocketHandler(Sinks.Many<ByteBuf> inbound, Flux<ByteBuf> outbound, ContextView context) {
/*  77 */     this(inbound, outbound, context, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayWebsocketHandler(Sinks.Many<ByteBuf> inbound, Flux<ByteBuf> outbound, ContextView context, boolean unpooled) {
/*  82 */     this.inbound = inbound;
/*  83 */     this.outbound = outbound;
/*  84 */     this.sessionClose = Sinks.one();
/*  85 */     this.context = context;
/*  86 */     this.unpooled = unpooled;
/*  87 */     this.emissionStrategy = EmissionStrategy.park(Duration.ofNanos(10L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Tuple2<DisconnectBehavior, CloseStatus>> handle(WebsocketInbound in, WebsocketOutbound out) {
/* 103 */     ZlibDecompressor decompressor = new ZlibDecompressor(out.alloc());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     Mono<CloseWebSocketFrame> outboundClose = this.sessionClose.asMono().doOnNext(behavior -> log.debug(LogUtil.format(this.context, "Closing session with behavior: {}"), new Object[] { behavior })).flatMap(behavior -> { switch (behavior.getAction()) { case RETRY_ABRUPTLY: case STOP_ABRUPTLY: return Mono.error((behavior.getCause() != null) ? behavior.getCause() : (Throwable)new PartialDisconnectException(this.context)); }  return Mono.just(CloseStatus.NORMAL_CLOSE); }).map(status -> new CloseWebSocketFrame(status.getCode(), status.getReason().orElse(null)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     Mono<CloseStatus> inboundClose = in.receiveCloseStatus().map(status -> new CloseStatus(status.code(), status.reasonText())).doOnNext(status -> log.debug(LogUtil.format(this.context, "Received close status: {}"), new Object[] { status })).doOnNext(status -> close(DisconnectBehavior.retryAbruptly((Throwable)new GatewayException(this.context, "Inbound close status"))));
/*     */ 
/*     */ 
/*     */     
/* 128 */     Mono<Void> outboundEvents = out.sendObject((Publisher)Flux.merge(new Publisher[] { (Publisher)outboundClose, (Publisher)this.outbound.map(io.netty.handler.codec.http.websocketx.TextWebSocketFrame::new) })).then();
/*     */     
/* 130 */     in.withConnection(c -> c.onDispose(()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     Objects.requireNonNull(decompressor);
/*     */ 
/*     */     
/* 138 */     Mono<Void> inboundEvents = in.aggregateFrames().receiveFrames().map(DefaultByteBufHolder::content).transformDeferred(decompressor::completeMessages).doOnNext(this::emitInbound).doOnNext(this::safeRelease).then();
/*     */     
/* 140 */     return Mono.zip(outboundEvents, inboundEvents)
/* 141 */       .doOnError(this::error)
/* 142 */       .onErrorResume(t -> t.getCause() instanceof GatewayException, t -> Mono.empty())
/* 143 */       .then(Mono.zip(this.sessionClose.asMono(), inboundClose.defaultIfEmpty(CloseStatus.ABNORMAL_CLOSE)));
/*     */   }
/*     */   
/*     */   private void emitInbound(ByteBuf value) {
/* 147 */     if (!this.emissionStrategy.emitNext(this.inbound, value)) {
/* 148 */       safeRelease(value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 157 */     close(DisconnectBehavior.retry(null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close(DisconnectBehavior behavior) {
/* 166 */     this.sessionClose.emitValue(behavior, Sinks.EmitFailureHandler.FAIL_FAST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(Throwable error) {
/* 176 */     if (!(error instanceof discord4j.gateway.retry.ReconnectException)) {
/* 177 */       log.info(LogUtil.format(this.context, "Triggering error sequence: {}"), new Object[] { error.toString() });
/*     */     }
/* 179 */     close(DisconnectBehavior.retryAbruptly(error));
/*     */   }
/*     */   
/*     */   private void safeRelease(ByteBuf buf) {
/* 183 */     if (!this.unpooled && buf.refCnt() > 0)
/*     */       try {
/* 185 */         buf.release();
/* 186 */       } catch (IllegalReferenceCountException e) {
/* 187 */         if (log.isDebugEnabled())
/* 188 */           log.debug("", (Throwable)e); 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\GatewayWebsocketHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */