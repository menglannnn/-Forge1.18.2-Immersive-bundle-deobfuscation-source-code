/*     */ package discord4j.gateway;
/*     */ 
/*     */ import discord4j.common.retry.ReconnectOptions;
/*     */ import discord4j.common.sinks.EmissionStrategy;
/*     */ import discord4j.gateway.limiter.PayloadTransformer;
/*     */ import discord4j.gateway.payload.PayloadReader;
/*     */ import discord4j.gateway.payload.PayloadWriter;
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GatewayOptions
/*     */ {
/*     */   private final String token;
/*     */   private final GatewayReactorResources reactorResources;
/*     */   private final PayloadReader payloadReader;
/*     */   private final PayloadWriter payloadWriter;
/*     */   private final ReconnectOptions reconnectOptions;
/*     */   private final IdentifyOptions identifyOptions;
/*     */   private final GatewayObserver initialObserver;
/*     */   private final PayloadTransformer identifyLimiter;
/*     */   private final int maxMissedHeartbeatAck;
/*     */   private final boolean unpooled;
/*     */   private final EmissionStrategy emissionStrategy;
/*     */   
/*     */   public GatewayOptions(String token, GatewayReactorResources reactorResources, PayloadReader payloadReader, PayloadWriter payloadWriter, ReconnectOptions reconnectOptions, IdentifyOptions identifyOptions, GatewayObserver initialObserver, PayloadTransformer identifyLimiter, int maxMissedHeartbeatAck) {
/*  50 */     this(token, reactorResources, payloadReader, payloadWriter, reconnectOptions, identifyOptions, initialObserver, identifyLimiter, maxMissedHeartbeatAck, false, 
/*  51 */         EmissionStrategy.park(Duration.ofMillis(10L)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayOptions(String token, GatewayReactorResources reactorResources, PayloadReader payloadReader, PayloadWriter payloadWriter, ReconnectOptions reconnectOptions, IdentifyOptions identifyOptions, GatewayObserver initialObserver, PayloadTransformer identifyLimiter, int maxMissedHeartbeatAck, boolean unpooled, EmissionStrategy emissionStrategy) {
/*  59 */     this.token = Objects.<String>requireNonNull(token, "token");
/*  60 */     this.reactorResources = Objects.<GatewayReactorResources>requireNonNull(reactorResources, "reactorResources");
/*  61 */     this.payloadReader = Objects.<PayloadReader>requireNonNull(payloadReader, "payloadReader");
/*  62 */     this.payloadWriter = Objects.<PayloadWriter>requireNonNull(payloadWriter, "payloadWriter");
/*  63 */     this.reconnectOptions = Objects.<ReconnectOptions>requireNonNull(reconnectOptions, "reconnectOptions");
/*  64 */     this.identifyOptions = Objects.<IdentifyOptions>requireNonNull(identifyOptions, "identifyOptions");
/*  65 */     this.initialObserver = Objects.<GatewayObserver>requireNonNull(initialObserver, "initialObserver");
/*  66 */     this.identifyLimiter = Objects.<PayloadTransformer>requireNonNull(identifyLimiter, "identifyLimiter");
/*  67 */     this.maxMissedHeartbeatAck = maxMissedHeartbeatAck;
/*  68 */     this.unpooled = unpooled;
/*  69 */     this.emissionStrategy = Objects.<EmissionStrategy>requireNonNull(emissionStrategy, "emissionStrategy");
/*     */   }
/*     */   
/*     */   public String getToken() {
/*  73 */     return this.token;
/*     */   }
/*     */   
/*     */   public GatewayReactorResources getReactorResources() {
/*  77 */     return this.reactorResources;
/*     */   }
/*     */   
/*     */   public PayloadReader getPayloadReader() {
/*  81 */     return this.payloadReader;
/*     */   }
/*     */   
/*     */   public PayloadWriter getPayloadWriter() {
/*  85 */     return this.payloadWriter;
/*     */   }
/*     */   
/*     */   public ReconnectOptions getReconnectOptions() {
/*  89 */     return this.reconnectOptions;
/*     */   }
/*     */   
/*     */   public IdentifyOptions getIdentifyOptions() {
/*  93 */     return this.identifyOptions;
/*     */   }
/*     */   
/*     */   public GatewayObserver getInitialObserver() {
/*  97 */     return this.initialObserver;
/*     */   }
/*     */   
/*     */   public PayloadTransformer getIdentifyLimiter() {
/* 101 */     return this.identifyLimiter;
/*     */   }
/*     */   
/*     */   public int getMaxMissedHeartbeatAck() {
/* 105 */     return this.maxMissedHeartbeatAck;
/*     */   }
/*     */   
/*     */   public boolean isUnpooled() {
/* 109 */     return this.unpooled;
/*     */   }
/*     */   
/*     */   public EmissionStrategy getEmissionStrategy() {
/* 113 */     return this.emissionStrategy;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\GatewayOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */