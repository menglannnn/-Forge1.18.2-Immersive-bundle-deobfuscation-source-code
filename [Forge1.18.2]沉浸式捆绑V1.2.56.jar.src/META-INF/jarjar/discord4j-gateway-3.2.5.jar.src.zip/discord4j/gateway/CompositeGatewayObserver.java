/*    */ package discord4j.gateway;
/*    */ 
/*    */ import reactor.netty.ConnectionObserver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CompositeGatewayObserver
/*    */   implements GatewayObserver
/*    */ {
/*    */   private final GatewayObserver[] observers;
/*    */   
/*    */   private CompositeGatewayObserver(GatewayObserver[] observers) {
/* 27 */     this.observers = observers;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onStateChange(ConnectionObserver.State newState, GatewayClient gatewayClient) {
/* 32 */     for (GatewayObserver observer : this.observers)
/* 33 */       observer.onStateChange(newState, gatewayClient); 
/*    */   }
/*    */   static GatewayObserver compose(GatewayObserver first, GatewayObserver second) {
/*    */     GatewayObserver[] firstObservers, secondObservers;
/*    */     int pos;
/* 38 */     if (first == GatewayObserver.NOOP_LISTENER) {
/* 39 */       return second;
/*    */     }
/*    */     
/* 42 */     if (second == GatewayObserver.NOOP_LISTENER) {
/* 43 */       return first;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 49 */     int length = 2;
/*    */     
/* 51 */     if (first instanceof CompositeGatewayObserver) {
/* 52 */       firstObservers = ((CompositeGatewayObserver)first).observers;
/* 53 */       length += firstObservers.length - 1;
/*    */     } else {
/* 55 */       firstObservers = null;
/*    */     } 
/*    */     
/* 58 */     if (second instanceof CompositeGatewayObserver) {
/* 59 */       secondObservers = ((CompositeGatewayObserver)second).observers;
/* 60 */       length += secondObservers.length - 1;
/*    */     } else {
/* 62 */       secondObservers = null;
/*    */     } 
/*    */     
/* 65 */     GatewayObserver[] combinedObservers = new GatewayObserver[length];
/*    */ 
/*    */     
/* 68 */     if (firstObservers != null) {
/* 69 */       pos = firstObservers.length;
/* 70 */       System.arraycopy(firstObservers, 0, combinedObservers, 0, pos);
/*    */     } else {
/* 72 */       pos = 1;
/* 73 */       combinedObservers[0] = first;
/*    */     } 
/*    */     
/* 76 */     if (secondObservers != null) {
/* 77 */       System.arraycopy(secondObservers, 0, combinedObservers, pos, secondObservers.length);
/*    */     } else {
/* 79 */       combinedObservers[pos] = second;
/*    */     } 
/*    */     
/* 82 */     return new CompositeGatewayObserver(combinedObservers);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\CompositeGatewayObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */