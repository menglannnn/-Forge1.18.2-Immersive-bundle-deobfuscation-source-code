/*     */ package discord4j.gateway;
/*     */ 
/*     */ import discord4j.common.ReactorResources;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GatewayReactorResources
/*     */   extends ReactorResources
/*     */ {
/*     */   public static final Supplier<Scheduler> DEFAULT_PAYLOAD_SENDER_SCHEDULER = () -> Schedulers.newSingle("d4j-gateway", true);
/*     */   private final Scheduler payloadSenderScheduler;
/*     */   
/*     */   public GatewayReactorResources(ReactorResources parent) {
/*  46 */     super(parent.getHttpClient(), parent.getTimerTaskScheduler(), parent.getBlockingTaskScheduler());
/*  47 */     this.payloadSenderScheduler = DEFAULT_PAYLOAD_SENDER_SCHEDULER.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayReactorResources(ReactorResources parent, Scheduler payloadSenderScheduler) {
/*  59 */     super(parent.getHttpClient(), parent.getTimerTaskScheduler(), parent.getBlockingTaskScheduler());
/*  60 */     this.payloadSenderScheduler = payloadSenderScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GatewayReactorResources(HttpClient httpClient, Scheduler timerTaskScheduler, Scheduler blockingTaskScheduler, Scheduler payloadSenderScheduler) {
/*  77 */     super(httpClient, timerTaskScheduler, blockingTaskScheduler);
/*  78 */     this.payloadSenderScheduler = payloadSenderScheduler;
/*     */   }
/*     */   
/*     */   protected GatewayReactorResources(Builder builder) {
/*  82 */     super(builder);
/*     */     
/*  84 */     this
/*  85 */       .payloadSenderScheduler = (builder.payloadSenderScheduler == null) ? DEFAULT_PAYLOAD_SENDER_SCHEDULER.get() : builder.payloadSenderScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GatewayReactorResources create() {
/*  94 */     return new GatewayReactorResources(new ReactorResources());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 103 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder(ReactorResources reactorResources) {
/* 113 */     return builder()
/* 114 */       .httpClient(reactorResources.getHttpClient())
/* 115 */       .timerTaskScheduler(reactorResources.getTimerTaskScheduler())
/* 116 */       .blockingTaskScheduler(reactorResources.getBlockingTaskScheduler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder mutate() {
/* 126 */     return (new Builder())
/* 127 */       .httpClient(getHttpClient())
/* 128 */       .timerTaskScheduler(getTimerTaskScheduler())
/* 129 */       .blockingTaskScheduler(getBlockingTaskScheduler())
/* 130 */       .payloadSenderScheduler(getPayloadSenderScheduler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler getPayloadSenderScheduler() {
/* 139 */     return this.payloadSenderScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     extends ReactorResources.Builder
/*     */   {
/*     */     private Scheduler payloadSenderScheduler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder payloadSenderScheduler(Scheduler payloadSenderScheduler) {
/* 160 */       this.payloadSenderScheduler = payloadSenderScheduler;
/* 161 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder httpClient(HttpClient httpClient) {
/* 166 */       super.httpClient(httpClient);
/* 167 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder timerTaskScheduler(Scheduler timerTaskScheduler) {
/* 172 */       super.timerTaskScheduler(timerTaskScheduler);
/* 173 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder blockingTaskScheduler(Scheduler blockingTaskScheduler) {
/* 178 */       super.blockingTaskScheduler(blockingTaskScheduler);
/* 179 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GatewayReactorResources build() {
/* 188 */       return new GatewayReactorResources(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\GatewayReactorResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */