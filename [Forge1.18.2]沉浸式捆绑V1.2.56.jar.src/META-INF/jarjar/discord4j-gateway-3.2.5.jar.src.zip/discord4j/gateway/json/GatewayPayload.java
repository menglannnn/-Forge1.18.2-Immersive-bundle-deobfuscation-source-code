/*     */ package discord4j.gateway.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*     */ import discord4j.discordjson.json.gateway.Heartbeat;
/*     */ import discord4j.discordjson.json.gateway.Identify;
/*     */ import discord4j.discordjson.json.gateway.Opcode;
/*     */ import discord4j.discordjson.json.gateway.OpcodeConverter;
/*     */ import discord4j.discordjson.json.gateway.PayloadData;
/*     */ import discord4j.discordjson.json.gateway.RequestGuildMembers;
/*     */ import discord4j.discordjson.json.gateway.Resume;
/*     */ import discord4j.discordjson.json.gateway.StatusUpdate;
/*     */ import discord4j.discordjson.json.gateway.VoiceStateUpdate;
/*     */ import discord4j.gateway.json.jackson.PayloadDeserializer;
/*     */ import java.util.Objects;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JsonDeserialize(using = PayloadDeserializer.class)
/*     */ public class GatewayPayload<T extends PayloadData>
/*     */ {
/*     */   @JsonSerialize(converter = OpcodeConverter.class)
/*     */   private Opcode<T> op;
/*     */   @JsonProperty("d")
/*     */   @Nullable
/*     */   private T data;
/*     */   @JsonProperty("s")
/*     */   @Nullable
/*     */   private Integer sequence;
/*     */   @JsonProperty("t")
/*     */   @Nullable
/*     */   private String type;
/*     */   
/*     */   public GatewayPayload(Opcode<T> op, @Nullable T data, @Nullable Integer sequence, @Nullable String type) {
/*  49 */     this.op = op;
/*  50 */     this.data = data;
/*  51 */     this.sequence = sequence;
/*  52 */     this.type = type;
/*     */   }
/*     */   
/*     */   public static GatewayPayload<Heartbeat> heartbeat(Heartbeat data) {
/*  56 */     return new GatewayPayload<>(Opcode.HEARTBEAT, data, null, null);
/*     */   }
/*     */   
/*     */   public static GatewayPayload<Identify> identify(Identify data) {
/*  60 */     return new GatewayPayload<>(Opcode.IDENTIFY, data, null, null);
/*     */   }
/*     */   
/*     */   public static GatewayPayload<StatusUpdate> statusUpdate(StatusUpdate data) {
/*  64 */     return new GatewayPayload<>(Opcode.STATUS_UPDATE, data, null, null);
/*     */   }
/*     */   
/*     */   public static GatewayPayload<VoiceStateUpdate> voiceStateUpdate(VoiceStateUpdate data) {
/*  68 */     return new GatewayPayload<>(Opcode.VOICE_STATE_UPDATE, data, null, null);
/*     */   }
/*     */   
/*     */   public static GatewayPayload<Resume> resume(Resume data) {
/*  72 */     return new GatewayPayload<>(Opcode.RESUME, data, null, null);
/*     */   }
/*     */   
/*     */   public static GatewayPayload<RequestGuildMembers> requestGuildMembers(RequestGuildMembers data) {
/*  76 */     return new GatewayPayload<>(Opcode.REQUEST_GUILD_MEMBERS, data, null, null);
/*     */   }
/*     */   
/*     */   public Opcode<T> getOp() {
/*  80 */     return this.op;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public T getData() {
/*  85 */     return this.data;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Integer getSequence() {
/*  90 */     return this.sequence;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getType() {
/*  95 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 100 */     return Objects.hash(new Object[] { this.op, this.data, this.sequence, this.type });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/* 105 */     if (obj == null || obj.getClass() != GatewayPayload.class) {
/* 106 */       return false;
/*     */     }
/*     */     
/* 109 */     GatewayPayload<?> other = (GatewayPayload)obj;
/*     */     
/* 111 */     return (this.op == other.op && 
/* 112 */       Objects.equals(this.data, other.data) && 
/* 113 */       Objects.equals(this.sequence, other.sequence) && 
/* 114 */       Objects.equals(this.type, other.type));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 119 */     return "GatewayPayload{op=" + this.op + ", data=" + this.data + ", sequence=" + this.sequence + ", type='" + this.type + '\'' + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\json\GatewayPayload.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */