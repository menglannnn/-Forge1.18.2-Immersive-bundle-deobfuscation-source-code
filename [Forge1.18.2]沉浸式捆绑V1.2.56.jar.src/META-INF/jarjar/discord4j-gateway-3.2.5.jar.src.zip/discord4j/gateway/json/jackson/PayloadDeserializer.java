/*     */ package discord4j.gateway.json.jackson;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.TreeNode;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
/*     */ import discord4j.discordjson.json.gateway.ApplicationCommandCreate;
/*     */ import discord4j.discordjson.json.gateway.ApplicationCommandUpdate;
/*     */ import discord4j.discordjson.json.gateway.AutoModActionExecution;
/*     */ import discord4j.discordjson.json.gateway.AutoModRuleCreate;
/*     */ import discord4j.discordjson.json.gateway.ChannelPinsUpdate;
/*     */ import discord4j.discordjson.json.gateway.Dispatch;
/*     */ import discord4j.discordjson.json.gateway.GuildBanAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserRemove;
/*     */ import discord4j.discordjson.json.gateway.MessageDeleteBulk;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemoveEmoji;
/*     */ import discord4j.discordjson.json.gateway.Opcode;
/*     */ import discord4j.discordjson.json.gateway.PayloadData;
/*     */ import discord4j.discordjson.json.gateway.PresenceUpdate;
/*     */ import discord4j.discordjson.json.gateway.TypingStart;
/*     */ import discord4j.discordjson.json.gateway.UnavailableGuildCreate;
/*     */ import discord4j.discordjson.json.gateway.VoiceServerUpdate;
/*     */ import discord4j.gateway.json.GatewayPayload;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ public class PayloadDeserializer extends StdDeserializer<GatewayPayload<?>> {
/*     */   private static final String OP_FIELD = "op";
/*     */   private static final String D_FIELD = "d";
/*  39 */   private static final Map<String, Class<? extends Dispatch>> dispatchTypes = new HashMap<>(); private static final String T_FIELD = "t"; private static final String S_FIELD = "s";
/*     */   
/*     */   static {
/*  42 */     dispatchTypes.put("READY", Ready.class);
/*  43 */     dispatchTypes.put("RESUMED", Resumed.class);
/*  44 */     dispatchTypes.put("CHANNEL_CREATE", ChannelCreate.class);
/*  45 */     dispatchTypes.put("CHANNEL_UPDATE", ChannelUpdate.class);
/*  46 */     dispatchTypes.put("CHANNEL_DELETE", ChannelDelete.class);
/*  47 */     dispatchTypes.put("CHANNEL_PINS_UPDATE", ChannelPinsUpdate.class);
/*  48 */     dispatchTypes.put("GUILD_CREATE", GuildCreate.class);
/*  49 */     dispatchTypes.put("GUILD_UPDATE", GuildUpdate.class);
/*  50 */     dispatchTypes.put("GUILD_DELETE", GuildDelete.class);
/*  51 */     dispatchTypes.put("GUILD_BAN_ADD", GuildBanAdd.class);
/*  52 */     dispatchTypes.put("GUILD_BAN_REMOVE", GuildBanRemove.class);
/*  53 */     dispatchTypes.put("GUILD_EMOJIS_UPDATE", GuildEmojisUpdate.class);
/*  54 */     dispatchTypes.put("GUILD_INTEGRATIONS_UPDATE", GuildIntegrationsUpdate.class);
/*  55 */     dispatchTypes.put("GUILD_MEMBER_ADD", GuildMemberAdd.class);
/*  56 */     dispatchTypes.put("GUILD_MEMBER_REMOVE", GuildMemberRemove.class);
/*  57 */     dispatchTypes.put("GUILD_MEMBER_UPDATE", GuildMemberUpdate.class);
/*  58 */     dispatchTypes.put("GUILD_MEMBERS_CHUNK", GuildMembersChunk.class);
/*  59 */     dispatchTypes.put("GUILD_ROLE_CREATE", GuildRoleCreate.class);
/*  60 */     dispatchTypes.put("GUILD_ROLE_UPDATE", GuildRoleUpdate.class);
/*  61 */     dispatchTypes.put("GUILD_ROLE_DELETE", GuildRoleDelete.class);
/*  62 */     dispatchTypes.put("GUILD_SCHEDULED_EVENT_CREATE", GuildScheduledEventCreate.class);
/*  63 */     dispatchTypes.put("GUILD_SCHEDULED_EVENT_UPDATE", GuildScheduledEventUpdate.class);
/*  64 */     dispatchTypes.put("GUILD_SCHEDULED_EVENT_DELETE", GuildScheduledEventDelete.class);
/*  65 */     dispatchTypes.put("GUILD_SCHEDULED_EVENT_USER_ADD", GuildScheduledEventUserAdd.class);
/*  66 */     dispatchTypes.put("GUILD_SCHEDULED_EVENT_USER_REMOVE", GuildScheduledEventUserRemove.class);
/*  67 */     dispatchTypes.put("MESSAGE_CREATE", MessageCreate.class);
/*  68 */     dispatchTypes.put("MESSAGE_UPDATE", MessageUpdate.class);
/*  69 */     dispatchTypes.put("MESSAGE_DELETE", MessageDelete.class);
/*  70 */     dispatchTypes.put("MESSAGE_DELETE_BULK", MessageDeleteBulk.class);
/*  71 */     dispatchTypes.put("MESSAGE_REACTION_ADD", MessageReactionAdd.class);
/*  72 */     dispatchTypes.put("MESSAGE_REACTION_REMOVE", MessageReactionRemove.class);
/*  73 */     dispatchTypes.put("MESSAGE_REACTION_REMOVE_ALL", MessageReactionRemoveAll.class);
/*  74 */     dispatchTypes.put("MESSAGE_REACTION_REMOVE_EMOJI", MessageReactionRemoveEmoji.class);
/*  75 */     dispatchTypes.put("PRESENCE_UPDATE", PresenceUpdate.class);
/*  76 */     dispatchTypes.put("TYPING_START", TypingStart.class);
/*  77 */     dispatchTypes.put("USER_UPDATE", UserUpdate.class);
/*  78 */     dispatchTypes.put("VOICE_STATE_UPDATE", VoiceStateUpdateDispatch.class);
/*  79 */     dispatchTypes.put("VOICE_SERVER_UPDATE", VoiceServerUpdate.class);
/*  80 */     dispatchTypes.put("WEBHOOKS_UPDATE", WebhooksUpdate.class);
/*  81 */     dispatchTypes.put("INVITE_CREATE", InviteCreate.class);
/*  82 */     dispatchTypes.put("INVITE_DELETE", InviteDelete.class);
/*  83 */     dispatchTypes.put("APPLICATION_COMMAND_CREATE", ApplicationCommandCreate.class);
/*  84 */     dispatchTypes.put("APPLICATION_COMMAND_UPDATE", ApplicationCommandUpdate.class);
/*  85 */     dispatchTypes.put("APPLICATION_COMMAND_DELETE", ApplicationCommandDelete.class);
/*  86 */     dispatchTypes.put("APPLICATION_COMMAND_PERMISSIONS_UPDATE", ApplicationCommandPermissionUpdate.class);
/*  87 */     dispatchTypes.put("INTERACTION_CREATE", InteractionCreate.class);
/*  88 */     dispatchTypes.put("GUILD_AUDIT_LOG_ENTRY_CREATE", AuditLogEntryCreate.class);
/*  89 */     dispatchTypes.put("AUTO_MODERATION_RULE_CREATE", AutoModRuleCreate.class);
/*  90 */     dispatchTypes.put("AUTO_MODERATION_RULE_UPDATE", AutoModRuleUpdate.class);
/*  91 */     dispatchTypes.put("AUTO_MODERATION_RULE_DELETE", AutoModRuleDelete.class);
/*  92 */     dispatchTypes.put("AUTO_MODERATION_ACTION_EXECUTION", AutoModActionExecution.class);
/*     */ 
/*     */     
/*  95 */     dispatchTypes.put("PRESENCES_REPLACE", null);
/*  96 */     dispatchTypes.put("GIFT_CODE_UPDATE", null);
/*  97 */     dispatchTypes.put("INTEGRATION_CREATE", null);
/*  98 */     dispatchTypes.put("INTEGRATION_UPDATE", null);
/*  99 */     dispatchTypes.put("INTEGRATION_DELETE", null);
/* 100 */     dispatchTypes.put("GUILD_JOIN_REQUEST_DELETE", null);
/* 101 */     dispatchTypes.put("GUILD_JOIN_REQUEST_UPDATE", null);
/*     */   }
/*     */   
/*     */   public PayloadDeserializer() {
/* 105 */     super(GatewayPayload.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public GatewayPayload<?> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 110 */     JsonNode payload = (JsonNode)p.getCodec().readTree(p);
/*     */     
/* 112 */     int op = payload.get("op").asInt();
/* 113 */     String t = payload.get("t").asText();
/* 114 */     Integer s = payload.get("s").isNull() ? null : Integer.valueOf(payload.get("s").intValue());
/*     */     
/* 116 */     Class<? extends PayloadData> payloadType = getPayloadType(op, t);
/* 117 */     if (payloadType == GuildCreate.class) {
/* 118 */       JsonNode d = payload.get("d");
/* 119 */       JsonNode unavailable = d.get("unavailable");
/* 120 */       if (unavailable != null && unavailable.asBoolean()) {
/* 121 */         PayloadData payloadData = (PayloadData)p.getCodec().treeToValue((TreeNode)d, UnavailableGuildCreate.class);
/* 122 */         return new GatewayPayload(Opcode.forRaw(op), payloadData, s, t);
/*     */       } 
/*     */     } 
/* 125 */     PayloadData data = (payloadType == null) ? null : (PayloadData)p.getCodec().treeToValue((TreeNode)payload.get("d"), payloadType);
/*     */     
/* 127 */     return new GatewayPayload(Opcode.forRaw(op), data, s, t);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static Class<? extends PayloadData> getPayloadType(int op, String t) {
/* 132 */     if (op == Opcode.DISPATCH.getRawOp()) {
/* 133 */       if (!dispatchTypes.containsKey(t)) {
/* 134 */         throw new IllegalArgumentException("Attempt to deserialize payload with unknown event type: " + t);
/*     */       }
/* 136 */       return (Class<? extends PayloadData>)dispatchTypes.get(t);
/*     */     } 
/*     */     
/* 139 */     Opcode<?> opcode = Opcode.forRaw(op);
/* 140 */     if (opcode == null) {
/* 141 */       throw new IllegalArgumentException("Attempt to deserialize payload with unknown op: " + op);
/*     */     }
/* 143 */     return opcode.getPayloadType();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\json\jackson\PayloadDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */