/*    */ package discord4j.gateway.json;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*    */ import discord4j.discordjson.json.gateway.PayloadData;
/*    */ import discord4j.discordjson.json.gateway.RequestGuildMembers;
/*    */ import discord4j.discordjson.json.gateway.StatusUpdate;
/*    */ import discord4j.discordjson.json.gateway.VoiceStateUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShardGatewayPayload<T extends PayloadData>
/*    */   extends GatewayPayload<T>
/*    */ {
/*    */   @JsonIgnore
/*    */   private final int shardIndex;
/*    */   
/*    */   public ShardGatewayPayload(GatewayPayload<T> payload, int shardIndex) {
/* 39 */     super(payload.getOp(), payload.getData(), payload.getSequence(), payload.getType());
/* 40 */     this.shardIndex = shardIndex;
/*    */   }
/*    */   
/*    */   public static ShardGatewayPayload<StatusUpdate> statusUpdate(StatusUpdate data, int shardId) {
/* 44 */     return new ShardGatewayPayload<>(GatewayPayload.statusUpdate(data), shardId);
/*    */   }
/*    */   
/*    */   public static ShardGatewayPayload<VoiceStateUpdate> voiceStateUpdate(VoiceStateUpdate data, int shardId) {
/* 48 */     return new ShardGatewayPayload<>(GatewayPayload.voiceStateUpdate(data), shardId);
/*    */   }
/*    */   
/*    */   public static ShardGatewayPayload<RequestGuildMembers> requestGuildMembers(RequestGuildMembers data, int shardId) {
/* 52 */     return new ShardGatewayPayload<>(GatewayPayload.requestGuildMembers(data), shardId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @JsonIgnore
/*    */   public int getShardIndex() {
/* 62 */     return this.shardIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\json\ShardGatewayPayload.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */