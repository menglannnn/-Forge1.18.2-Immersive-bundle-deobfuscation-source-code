/*    */ package discord4j.gateway.json;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.Dispatch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShardAwareDispatch
/*    */   implements Dispatch
/*    */ {
/*    */   private final int shardIndex;
/*    */   private final int shardCount;
/*    */   private final Dispatch dispatch;
/*    */   
/*    */   public ShardAwareDispatch(int shardIndex, int shardCount, Dispatch dispatch) {
/* 29 */     this.shardIndex = shardIndex;
/* 30 */     this.shardCount = shardCount;
/* 31 */     this.dispatch = dispatch;
/*    */   }
/*    */   
/*    */   public int getShardIndex() {
/* 35 */     return this.shardIndex;
/*    */   }
/*    */   
/*    */   public int getShardCount() {
/* 39 */     return this.shardCount;
/*    */   }
/*    */   
/*    */   public Dispatch getDispatch() {
/* 43 */     return this.dispatch;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\json\ShardAwareDispatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */