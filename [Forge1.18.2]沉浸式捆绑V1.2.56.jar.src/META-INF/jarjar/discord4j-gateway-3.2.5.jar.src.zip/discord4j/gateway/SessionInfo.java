/*    */ package discord4j.gateway;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonCreator;
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import java.util.Objects;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionInfo
/*    */ {
/*    */   private final String id;
/*    */   private final int sequence;
/*    */   
/*    */   private SessionInfo(String id, int sequence) {
/* 35 */     this.id = Objects.<String>requireNonNull(id);
/* 36 */     this.sequence = sequence;
/*    */   }
/*    */   
/*    */   @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
/*    */   public static SessionInfo create(@JsonProperty("id") String id, @JsonProperty("sequence") int sequence) {
/* 41 */     return new SessionInfo(id, sequence);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getId() {
/* 50 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSequence() {
/* 59 */     return this.sequence;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object o) {
/* 64 */     if (this == o) {
/* 65 */       return true;
/*    */     }
/* 67 */     if (o == null || getClass() != o.getClass()) {
/* 68 */       return false;
/*    */     }
/* 70 */     SessionInfo that = (SessionInfo)o;
/* 71 */     return (Objects.equals(this.id, that.id) && 
/* 72 */       Objects.equals(Integer.valueOf(this.sequence), Integer.valueOf(that.sequence)));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 77 */     return Objects.hash(new Object[] { this.id, Integer.valueOf(this.sequence) });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 82 */     return "SessionInfo{id='" + this.id + '\'' + ", sequence=" + this.sequence + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\SessionInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */