/*     */ package discord4j.gateway.state;
/*     */ import discord4j.common.store.Store;
/*     */ import discord4j.common.store.action.gateway.GatewayActions;
/*     */ import discord4j.common.store.api.StoreAction;
/*     */ import discord4j.common.store.api.object.InvalidationCause;
/*     */ import discord4j.discordjson.json.gateway.ChannelCreate;
/*     */ import discord4j.discordjson.json.gateway.ChannelDelete;
/*     */ import discord4j.discordjson.json.gateway.ChannelUpdate;
/*     */ import discord4j.discordjson.json.gateway.Dispatch;
/*     */ import discord4j.discordjson.json.gateway.GuildCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildEmojisUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildMembersChunk;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildStickersUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildUpdate;
/*     */ import discord4j.discordjson.json.gateway.MessageCreate;
/*     */ import discord4j.discordjson.json.gateway.MessageDelete;
/*     */ import discord4j.discordjson.json.gateway.MessageDeleteBulk;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionAdd;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemove;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemoveAll;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemoveEmoji;
/*     */ import discord4j.discordjson.json.gateway.PresenceUpdate;
/*     */ import discord4j.discordjson.json.gateway.Ready;
/*     */ import discord4j.discordjson.json.gateway.UserUpdate;
/*     */ import discord4j.discordjson.json.gateway.VoiceStateUpdateDispatch;
/*     */ import discord4j.gateway.ShardInfo;
/*     */ import discord4j.gateway.json.ShardAwareDispatch;
/*     */ import discord4j.gateway.retry.GatewayStateChange;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Predicate;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ public class DispatchStoreLayer {
/*  46 */   private static final Logger log = Loggers.getLogger(DispatchStoreLayer.class);
/*  47 */   private static final Set<DispatchToAction> DISPATCH_TO_ACTION = new HashSet<>(); private final Store store; private final ShardInfo shardInfo;
/*     */   
/*     */   static {
/*  50 */     Objects.requireNonNull(ChannelCreate.class); add(ChannelCreate.class::isInstance, GatewayActions::channelCreate);
/*  51 */     Objects.requireNonNull(ChannelDelete.class); add(ChannelDelete.class::isInstance, GatewayActions::channelDelete);
/*  52 */     Objects.requireNonNull(ChannelUpdate.class); add(ChannelUpdate.class::isInstance, GatewayActions::channelUpdate);
/*  53 */     Objects.requireNonNull(GuildCreate.class); add(GuildCreate.class::isInstance, GatewayActions::guildCreate);
/*  54 */     Objects.requireNonNull(GuildDelete.class); add(GuildDelete.class::isInstance, GatewayActions::guildDelete);
/*  55 */     Objects.requireNonNull(GuildStickersUpdate.class); add(GuildStickersUpdate.class::isInstance, GatewayActions::guildStickersUpdate);
/*  56 */     Objects.requireNonNull(GuildEmojisUpdate.class); add(GuildEmojisUpdate.class::isInstance, GatewayActions::guildEmojisUpdate);
/*  57 */     Objects.requireNonNull(GuildMemberAdd.class); add(GuildMemberAdd.class::isInstance, GatewayActions::guildMemberAdd);
/*  58 */     Objects.requireNonNull(GuildMemberRemove.class); add(GuildMemberRemove.class::isInstance, GatewayActions::guildMemberRemove);
/*  59 */     Objects.requireNonNull(GuildMembersChunk.class); add(GuildMembersChunk.class::isInstance, GatewayActions::guildMembersChunk);
/*  60 */     Objects.requireNonNull(GuildMemberUpdate.class); add(GuildMemberUpdate.class::isInstance, GatewayActions::guildMemberUpdate);
/*  61 */     Objects.requireNonNull(GuildRoleCreate.class); add(GuildRoleCreate.class::isInstance, GatewayActions::guildRoleCreate);
/*  62 */     Objects.requireNonNull(GuildRoleDelete.class); add(GuildRoleDelete.class::isInstance, GatewayActions::guildRoleDelete);
/*  63 */     Objects.requireNonNull(GuildRoleUpdate.class); add(GuildRoleUpdate.class::isInstance, GatewayActions::guildRoleUpdate);
/*  64 */     Objects.requireNonNull(GuildScheduledEventCreate.class); add(GuildScheduledEventCreate.class::isInstance, GatewayActions::guildScheduledEventCreate);
/*  65 */     Objects.requireNonNull(GuildScheduledEventUpdate.class); add(GuildScheduledEventUpdate.class::isInstance, GatewayActions::guildScheduledEventUpdate);
/*  66 */     Objects.requireNonNull(GuildScheduledEventDelete.class); add(GuildScheduledEventDelete.class::isInstance, GatewayActions::guildScheduledEventDelete);
/*  67 */     Objects.requireNonNull(GuildScheduledEventUserAdd.class); add(GuildScheduledEventUserAdd.class::isInstance, GatewayActions::guildScheduledEventUserAdd);
/*  68 */     Objects.requireNonNull(GuildScheduledEventUserRemove.class); add(GuildScheduledEventUserRemove.class::isInstance, GatewayActions::guildScheduledEventUserRemove);
/*  69 */     Objects.requireNonNull(GuildUpdate.class); add(GuildUpdate.class::isInstance, GatewayActions::guildUpdate);
/*  70 */     Objects.requireNonNull(MessageCreate.class); add(MessageCreate.class::isInstance, GatewayActions::messageCreate);
/*  71 */     Objects.requireNonNull(MessageDelete.class); add(MessageDelete.class::isInstance, GatewayActions::messageDelete);
/*  72 */     Objects.requireNonNull(MessageDeleteBulk.class); add(MessageDeleteBulk.class::isInstance, GatewayActions::messageDeleteBulk);
/*  73 */     Objects.requireNonNull(MessageReactionAdd.class); add(MessageReactionAdd.class::isInstance, GatewayActions::messageReactionAdd);
/*  74 */     Objects.requireNonNull(MessageReactionRemove.class); add(MessageReactionRemove.class::isInstance, GatewayActions::messageReactionRemove);
/*  75 */     Objects.requireNonNull(MessageReactionRemoveAll.class); add(MessageReactionRemoveAll.class::isInstance, GatewayActions::messageReactionRemoveAll);
/*  76 */     Objects.requireNonNull(MessageReactionRemoveEmoji.class); add(MessageReactionRemoveEmoji.class::isInstance, GatewayActions::messageReactionRemoveEmoji);
/*  77 */     Objects.requireNonNull(MessageUpdate.class); add(MessageUpdate.class::isInstance, GatewayActions::messageUpdate);
/*  78 */     Objects.requireNonNull(PresenceUpdate.class); add(PresenceUpdate.class::isInstance, GatewayActions::presenceUpdate);
/*  79 */     Objects.requireNonNull(Ready.class); add(Ready.class::isInstance, (shard, dispatch) -> GatewayActions.ready(dispatch));
/*  80 */     Objects.requireNonNull(UserUpdate.class); add(UserUpdate.class::isInstance, GatewayActions::userUpdate);
/*  81 */     Objects.requireNonNull(VoiceStateUpdateDispatch.class); add(VoiceStateUpdateDispatch.class::isInstance, GatewayActions::voiceStateUpdateDispatch);
/*  82 */     add(dispatch -> (dispatch instanceof GatewayStateChange && ((GatewayStateChange)dispatch).getState() == GatewayStateChange.State.DISCONNECTED), (shard, dispatch) -> GatewayActions.invalidateShard(shard.intValue(), InvalidationCause.LOGOUT));
/*     */ 
/*     */     
/*  85 */     add(dispatch -> (dispatch instanceof GatewayStateChange && ((GatewayStateChange)dispatch).getState() == GatewayStateChange.State.SESSION_INVALIDATED), (shard, dispatch) -> GatewayActions.invalidateShard(shard.intValue(), InvalidationCause.HARD_RECONNECT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DispatchStoreLayer(Store store, ShardInfo shardInfo) {
/*  94 */     this.store = store;
/*  95 */     this.shardInfo = shardInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DispatchStoreLayer create(Store store, ShardInfo shardInfo) {
/* 106 */     Objects.requireNonNull(store);
/* 107 */     Objects.requireNonNull(shardInfo);
/* 108 */     return new DispatchStoreLayer(store, shardInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <D extends Dispatch> void add(Predicate<? super Dispatch> predicate, BiFunction<Integer, D, StoreAction<?>> actionFactory) {
/* 114 */     DISPATCH_TO_ACTION.add(new DispatchToAction(predicate, (shard, dispatch) -> (StoreAction)actionFactory.apply(shard, dispatch)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<StatefulDispatch<?, ?>> store(Dispatch dispatch) {
/*     */     ShardInfo shardInfo;
/*     */     Dispatch actualDispatch;
/* 131 */     Objects.requireNonNull(dispatch);
/*     */ 
/*     */     
/* 134 */     if (dispatch instanceof ShardAwareDispatch) {
/* 135 */       ShardAwareDispatch shardAwareDispatch = (ShardAwareDispatch)dispatch;
/* 136 */       shardInfo = ShardInfo.create(shardAwareDispatch.getShardIndex(), shardAwareDispatch.getShardCount());
/* 137 */       actualDispatch = shardAwareDispatch.getDispatch();
/*     */     } else {
/* 139 */       shardInfo = this.shardInfo;
/* 140 */       actualDispatch = dispatch;
/*     */     } 
/* 142 */     return Flux.fromStream(DISPATCH_TO_ACTION.stream()
/* 143 */         .filter(entry -> entry.predicate.test(actualDispatch))
/* 144 */         .map(entry -> entry.actionFactory))
/* 145 */       .singleOrEmpty()
/* 146 */       .map(actionFactory -> (StoreAction)actionFactory.apply(Integer.valueOf(shardInfo.getIndex()), actualDispatch))
/* 147 */       .flatMap(action -> Mono.from(this.store.execute(action)))
/* 148 */       .map(oldState -> StatefulDispatch.of(shardInfo, actualDispatch, oldState))
/* 149 */       .onErrorResume(t -> Mono.fromRunnable(()))
/*     */       
/* 151 */       .defaultIfEmpty(StatefulDispatch.of(shardInfo, actualDispatch, null));
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DispatchToAction
/*     */   {
/*     */     private final Predicate<? super Dispatch> predicate;
/*     */     private final BiFunction<Integer, Dispatch, StoreAction<?>> actionFactory;
/*     */     
/*     */     private DispatchToAction(Predicate<? super Dispatch> predicate, BiFunction<Integer, Dispatch, StoreAction<?>> actionFactory) {
/* 161 */       this.predicate = predicate;
/* 162 */       this.actionFactory = actionFactory;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\state\DispatchStoreLayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */