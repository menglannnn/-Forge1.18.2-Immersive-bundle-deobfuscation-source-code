/*    */ package discord4j.gateway.state;
/*    */ 
/*    */ import discord4j.gateway.ShardInfo;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatefulDispatch<D, S>
/*    */ {
/*    */   private final ShardInfo shardInfo;
/*    */   private final D dispatch;
/*    */   private final S oldState;
/*    */   
/*    */   private StatefulDispatch(ShardInfo shardInfo, D dispatch, S oldState) {
/* 31 */     this.shardInfo = shardInfo;
/* 32 */     this.dispatch = dispatch;
/* 33 */     this.oldState = oldState;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <D, S> StatefulDispatch<D, S> of(ShardInfo shardInfo, D dispatch, @Nullable S oldState) {
/* 38 */     return new StatefulDispatch<>(shardInfo, dispatch, oldState);
/*    */   }
/*    */   
/*    */   public ShardInfo getShardInfo() {
/* 42 */     return this.shardInfo;
/*    */   }
/*    */   
/*    */   public D getDispatch() {
/* 46 */     return this.dispatch;
/*    */   }
/*    */   
/*    */   public Optional<S> getOldState() {
/* 50 */     return Optional.ofNullable(this.oldState);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 55 */     return "StatefulDispatch{shardInfo=" + this.shardInfo + ", dispatch=" + this.dispatch + ", oldState=" + this.oldState + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-gateway-3.2.5.jar!\discord4j\gateway\state\StatefulDispatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */