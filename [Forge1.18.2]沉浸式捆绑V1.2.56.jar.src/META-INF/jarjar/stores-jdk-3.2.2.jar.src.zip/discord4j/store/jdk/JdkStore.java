/*     */ package discord4j.store.jdk;
/*     */ 
/*     */ import discord4j.store.api.Store;
/*     */ import discord4j.store.api.util.WithinRangePredicate;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Predicate;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.function.Tuple2;
/*     */ import reactor.util.function.Tuples;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkStore<K extends Comparable<K>, V>
/*     */   implements Store<K, V>
/*     */ {
/*     */   private final Map<K, V> map;
/*     */   
/*     */   public JdkStore(Map<K, V> map) {
/*  32 */     this.map = map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkStore(boolean persist) {
/*  42 */     if (persist) {
/*  43 */       this.map = new ConcurrentHashMap<>();
/*     */     } else {
/*  45 */       this.map = Collections.synchronizedMap(new WeakHashMap<>());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> save(K key, V value) {
/*  51 */     return Mono.fromRunnable(() -> this.map.put((K)key, (V)value));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> save(Publisher<Tuple2<K, V>> entryStream) {
/*  56 */     return Flux.from(entryStream).doOnNext(t -> this.map.put((K)t.getT1(), (V)t.getT2())).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<V> find(K id) {
/*  61 */     return Mono.defer(() -> this.map.containsKey(id) ? Mono.just(this.map.get(id)) : Mono.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<V> findInRange(K start, K end) {
/*  71 */     return keys().filter((Predicate)new WithinRangePredicate((Comparable)start, (Comparable)end)).map(this.map::get);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Long> count() {
/*  76 */     return Mono.fromSupplier(() -> Long.valueOf(this.map.size()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(K id) {
/*  81 */     return Mono.just(id).doOnNext(this.map::remove).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(Publisher<K> ids) {
/*  86 */     return Flux.from(ids).doOnNext(this.map::remove).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteInRange(K start, K end) {
/*  91 */     return keys().filter((Predicate)new WithinRangePredicate((Comparable)start, (Comparable)end)).doOnNext(this.map::remove).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteAll() {
/*  96 */     return Mono.fromRunnable(this.map::clear);
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<K> keys() {
/* 101 */     return Flux.defer(() -> Flux.fromIterable(this.map.keySet()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<V> values() {
/* 106 */     return Flux.defer(() -> Flux.fromIterable(this.map.values()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<Tuple2<K, V>> entries() {
/* 111 */     return Flux.defer(() -> Flux.fromIterable(this.map.entrySet())).map(e -> Tuples.of(e.getKey(), e.getValue()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> invalidate() {
/* 116 */     return Mono.fromRunnable(this.map::clear);
/*     */   }
/*     */   
/*     */   protected Map<K, V> getMap() {
/* 120 */     return this.map;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 125 */     return "JdkStore@" + Integer.toHexString(hashCode()) + "{map=" + this.map
/* 126 */       .getClass().getCanonicalName() + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-jdk-3.2.2.jar!\discord4j\store\jdk\JdkStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */