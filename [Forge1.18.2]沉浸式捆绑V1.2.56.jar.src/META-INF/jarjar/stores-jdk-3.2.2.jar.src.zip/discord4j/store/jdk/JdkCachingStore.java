/*     */ package discord4j.store.jdk;
/*     */ 
/*     */ import discord4j.store.api.Store;
/*     */ import java.time.Duration;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.function.Tuple2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkCachingStore<K extends Comparable<K>, V>
/*     */   implements Store<K, V>
/*     */ {
/*     */   private final Store<K, V> delegate;
/*     */   private final Function<K, Duration> ttlFactory;
/*  41 */   private final Map<K, Mono<V>> caches = new ConcurrentHashMap<>();
/*     */   
/*     */   public JdkCachingStore(Store<K, V> delegate, Function<K, Duration> ttlFactory) {
/*  44 */     this.delegate = delegate;
/*  45 */     this.ttlFactory = ttlFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<V> find(K id) {
/*  50 */     return Mono.defer(() -> (Mono)this.caches.computeIfAbsent((K)id, ()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Flux<V> findInRange(K start, K end) {
/*  58 */     return this.delegate.findInRange((Comparable)start, (Comparable)end);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Long> count() {
/*  63 */     return this.delegate.count();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<K> keys() {
/*  68 */     return this.delegate.keys();
/*     */   }
/*     */ 
/*     */   
/*     */   public Flux<V> values() {
/*  73 */     return this.delegate.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> save(K key, V value) {
/*  78 */     return this.delegate.save((Comparable)key, value).doOnTerminate(() -> (Mono)this.caches.put((K)key, Mono.just(value)));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> save(Publisher<Tuple2<K, V>> entryStream) {
/*  83 */     return Flux.from(entryStream).map(t2 -> save((K)t2.getT1(), (V)t2.getT2())).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(K id) {
/*  88 */     return this.delegate.delete((Comparable)id).doOnTerminate(() -> (Mono)this.caches.remove(id));
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> delete(Publisher<K> ids) {
/*  93 */     return Flux.from(ids).map(this::delete).then();
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteInRange(K start, K end) {
/*  98 */     return this.delegate.deleteInRange((Comparable)start, (Comparable)end);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> deleteAll() {
/* 103 */     return this.delegate.deleteAll().doOnTerminate(this.caches::clear);
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<Void> invalidate() {
/* 108 */     return this.delegate.invalidate().doOnTerminate(this.caches::clear);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-jdk-3.2.2.jar!\discord4j\store\jdk\JdkCachingStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */