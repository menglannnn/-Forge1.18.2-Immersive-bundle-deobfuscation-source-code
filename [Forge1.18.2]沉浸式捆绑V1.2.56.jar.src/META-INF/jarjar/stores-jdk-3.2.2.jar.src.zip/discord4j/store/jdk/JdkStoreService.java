/*    */ package discord4j.store.jdk;
/*    */ 
/*    */ import com.austinv11.servicer.WireService;
/*    */ import discord4j.store.api.Store;
/*    */ import discord4j.store.api.primitive.ForwardingStore;
/*    */ import discord4j.store.api.primitive.LongObjStore;
/*    */ import discord4j.store.api.service.StoreService;
/*    */ import discord4j.store.api.util.StoreContext;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WireService(StoreService.class)
/*    */ public class JdkStoreService
/*    */   implements StoreService
/*    */ {
/*    */   volatile Class<?> messageClass;
/*    */   
/*    */   public boolean hasGenericStores() {
/* 21 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <K extends Comparable<K>, V> Store<K, V> provideGenericStore(Class<K> keyClass, Class<V> valueClass) {
/* 27 */     return new JdkStore<>(!valueClass.equals(this.messageClass));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasLongObjStores() {
/* 32 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public <V> LongObjStore<V> provideLongObjStore(Class<V> valueClass) {
/* 37 */     return (LongObjStore<V>)new ForwardingStore(provideGenericStore(Long.class, valueClass));
/*    */   }
/*    */ 
/*    */   
/*    */   public void init(StoreContext context) {
/* 42 */     Object messageClass = context.getHints().get("messageClass");
/* 43 */     if (messageClass instanceof Class) {
/* 44 */       this.messageClass = (Class)messageClass;
/*    */     } else {
/* 46 */       this.messageClass = Void.class;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> dispose() {
/* 52 */     return Mono.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\stores-jdk-3.2.2.jar!\discord4j\store\jdk\JdkStoreService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */