/*     */ package io.netty.handler.codec.dns;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDnsRecordDecoder
/*     */   implements DnsRecordDecoder
/*     */ {
/*     */   static final String ROOT = ".";
/*     */   
/*     */   public final DnsQuestion decodeQuestion(ByteBuf in) throws Exception {
/*  38 */     String name = decodeName(in);
/*  39 */     DnsRecordType type = DnsRecordType.valueOf(in.readUnsignedShort());
/*  40 */     int qClass = in.readUnsignedShort();
/*  41 */     return new DefaultDnsQuestion(name, type, qClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public final <T extends DnsRecord> T decodeRecord(ByteBuf in) throws Exception {
/*  46 */     int startOffset = in.readerIndex();
/*  47 */     String name = decodeName(in);
/*     */     
/*  49 */     int endOffset = in.writerIndex();
/*  50 */     if (endOffset - in.readerIndex() < 10) {
/*     */       
/*  52 */       in.readerIndex(startOffset);
/*  53 */       return null;
/*     */     } 
/*     */     
/*  56 */     DnsRecordType type = DnsRecordType.valueOf(in.readUnsignedShort());
/*  57 */     int aClass = in.readUnsignedShort();
/*  58 */     long ttl = in.readUnsignedInt();
/*  59 */     int length = in.readUnsignedShort();
/*  60 */     int offset = in.readerIndex();
/*     */     
/*  62 */     if (endOffset - offset < length) {
/*     */       
/*  64 */       in.readerIndex(startOffset);
/*  65 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  69 */     DnsRecord dnsRecord = decodeRecord(name, type, aClass, ttl, in, offset, length);
/*  70 */     in.readerIndex(offset + length);
/*  71 */     return (T)dnsRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DnsRecord decodeRecord(String name, DnsRecordType type, int dnsClass, long timeToLive, ByteBuf in, int offset, int length) throws Exception {
/*  95 */     if (type == DnsRecordType.PTR) {
/*  96 */       return new DefaultDnsPtrRecord(name, dnsClass, timeToLive, 
/*  97 */           decodeName0(in.duplicate().setIndex(offset, offset + length)));
/*     */     }
/*  99 */     if (type == DnsRecordType.CNAME || type == DnsRecordType.NS) {
/* 100 */       return new DefaultDnsRawRecord(name, type, dnsClass, timeToLive, 
/* 101 */           DnsCodecUtil.decompressDomainName(in
/* 102 */             .duplicate().setIndex(offset, offset + length)));
/*     */     }
/* 104 */     return new DefaultDnsRawRecord(name, type, dnsClass, timeToLive, in
/* 105 */         .retainedDuplicate().setIndex(offset, offset + length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String decodeName0(ByteBuf in) {
/* 117 */     return decodeName(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decodeName(ByteBuf in) {
/* 129 */     return DnsCodecUtil.decodeDomainName(in);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DefaultDnsRecordDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */