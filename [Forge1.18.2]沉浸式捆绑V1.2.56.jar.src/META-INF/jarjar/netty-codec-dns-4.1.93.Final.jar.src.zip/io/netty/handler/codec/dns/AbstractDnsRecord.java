/*     */ package io.netty.handler.codec.dns;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.net.IDN;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDnsRecord
/*     */   implements DnsRecord
/*     */ {
/*     */   private final String name;
/*     */   private final DnsRecordType type;
/*     */   private final short dnsClass;
/*     */   private final long timeToLive;
/*     */   private int hashCode;
/*     */   
/*     */   protected AbstractDnsRecord(String name, DnsRecordType type, long timeToLive) {
/*  47 */     this(name, type, 1, timeToLive);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractDnsRecord(String name, DnsRecordType type, int dnsClass, long timeToLive) {
/*  67 */     ObjectUtil.checkPositiveOrZero(timeToLive, "timeToLive");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     this.name = appendTrailingDot(IDNtoASCII(name));
/*  73 */     this.type = (DnsRecordType)ObjectUtil.checkNotNull(type, "type");
/*  74 */     this.dnsClass = (short)dnsClass;
/*  75 */     this.timeToLive = timeToLive;
/*     */   }
/*     */   
/*     */   private static String IDNtoASCII(String name) {
/*  79 */     ObjectUtil.checkNotNull(name, "name");
/*  80 */     if (PlatformDependent.isAndroid() && ".".equals(name))
/*     */     {
/*     */ 
/*     */       
/*  84 */       return name;
/*     */     }
/*  86 */     return IDN.toASCII(name);
/*     */   }
/*     */   
/*     */   private static String appendTrailingDot(String name) {
/*  90 */     if (name.length() > 0 && name.charAt(name.length() - 1) != '.') {
/*  91 */       return name + '.';
/*     */     }
/*  93 */     return name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String name() {
/*  98 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public DnsRecordType type() {
/* 103 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public int dnsClass() {
/* 108 */     return this.dnsClass & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public long timeToLive() {
/* 113 */     return this.timeToLive;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 118 */     if (this == obj) {
/* 119 */       return true;
/*     */     }
/*     */     
/* 122 */     if (!(obj instanceof DnsRecord)) {
/* 123 */       return false;
/*     */     }
/*     */     
/* 126 */     DnsRecord that = (DnsRecord)obj;
/* 127 */     int hashCode = this.hashCode;
/* 128 */     if (hashCode != 0 && hashCode != that.hashCode()) {
/* 129 */       return false;
/*     */     }
/*     */     
/* 132 */     return (type().intValue() == that.type().intValue() && 
/* 133 */       dnsClass() == that.dnsClass() && 
/* 134 */       name().equals(that.name()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 139 */     int hashCode = this.hashCode;
/* 140 */     if (hashCode != 0) {
/* 141 */       return hashCode;
/*     */     }
/*     */     
/* 144 */     return this.hashCode = this.name.hashCode() * 31 + type().intValue() * 31 + dnsClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     StringBuilder buf = new StringBuilder(64);
/*     */     
/* 151 */     buf.append(StringUtil.simpleClassName(this))
/* 152 */       .append('(')
/* 153 */       .append(name())
/* 154 */       .append(' ')
/* 155 */       .append(timeToLive())
/* 156 */       .append(' ');
/*     */     
/* 158 */     DnsMessageUtil.appendRecordClass(buf, dnsClass())
/* 159 */       .append(' ')
/* 160 */       .append(type().name())
/* 161 */       .append(')');
/*     */     
/* 163 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\AbstractDnsRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */