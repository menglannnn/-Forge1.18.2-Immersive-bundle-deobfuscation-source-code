/*    */ package io.netty.handler.codec.dns;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.AddressedEnvelope;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.socket.DatagramPacket;
/*    */ import io.netty.handler.codec.MessageToMessageEncoder;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Sharable
/*    */ public class DatagramDnsResponseEncoder
/*    */   extends MessageToMessageEncoder<AddressedEnvelope<DnsResponse, InetSocketAddress>>
/*    */ {
/*    */   private final DnsRecordEncoder recordEncoder;
/*    */   
/*    */   public DatagramDnsResponseEncoder() {
/* 46 */     this(DnsRecordEncoder.DEFAULT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DatagramDnsResponseEncoder(DnsRecordEncoder recordEncoder) {
/* 53 */     this.recordEncoder = (DnsRecordEncoder)ObjectUtil.checkNotNull(recordEncoder, "recordEncoder");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void encode(ChannelHandlerContext ctx, AddressedEnvelope<DnsResponse, InetSocketAddress> in, List<Object> out) throws Exception {
/* 60 */     InetSocketAddress recipient = (InetSocketAddress)in.recipient();
/* 61 */     DnsResponse response = (DnsResponse)in.content();
/* 62 */     ByteBuf buf = allocateBuffer(ctx, in);
/*    */     
/* 64 */     DnsMessageUtil.encodeDnsResponse(this.recordEncoder, response, buf);
/*    */     
/* 66 */     out.add(new DatagramPacket(buf, recipient, null));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ByteBuf allocateBuffer(ChannelHandlerContext ctx, AddressedEnvelope<DnsResponse, InetSocketAddress> msg) throws Exception {
/* 76 */     return ctx.alloc().ioBuffer(1024);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DatagramDnsResponseEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */