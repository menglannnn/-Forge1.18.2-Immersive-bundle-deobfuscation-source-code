/*    */ package io.netty.handler.codec.dns;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.socket.DatagramPacket;
/*    */ import io.netty.handler.codec.CorruptedFrameException;
/*    */ import io.netty.handler.codec.MessageToMessageDecoder;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Sharable
/*    */ public class DatagramDnsResponseDecoder
/*    */   extends MessageToMessageDecoder<DatagramPacket>
/*    */ {
/*    */   private final DnsResponseDecoder<InetSocketAddress> responseDecoder;
/*    */   
/*    */   public DatagramDnsResponseDecoder() {
/* 41 */     this(DnsRecordDecoder.DEFAULT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DatagramDnsResponseDecoder(DnsRecordDecoder recordDecoder) {
/* 48 */     this.responseDecoder = new DnsResponseDecoder<InetSocketAddress>(recordDecoder)
/*    */       {
/*    */         protected DnsResponse newResponse(InetSocketAddress sender, InetSocketAddress recipient, int id, DnsOpCode opCode, DnsResponseCode responseCode)
/*    */         {
/* 52 */           return new DatagramDnsResponse(sender, recipient, id, opCode, responseCode);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   protected void decode(ChannelHandlerContext ctx, DatagramPacket packet, List<Object> out) throws Exception {
/*    */     try {
/* 60 */       out.add(decodeResponse(ctx, packet));
/* 61 */     } catch (IndexOutOfBoundsException e) {
/* 62 */       throw new CorruptedFrameException("Unable to decode response", e);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected DnsResponse decodeResponse(ChannelHandlerContext ctx, DatagramPacket packet) throws Exception {
/* 67 */     return this.responseDecoder.decode(packet.sender(), packet.recipient(), (ByteBuf)packet.content());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DatagramDnsResponseDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */