/*     */ package io.netty.handler.codec.dns;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.AddressedEnvelope;
/*     */ import io.netty.handler.codec.CorruptedFrameException;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.net.SocketAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DnsMessageUtil
/*     */ {
/*     */   static StringBuilder appendQuery(StringBuilder buf, DnsQuery query) {
/*  31 */     appendQueryHeader(buf, query);
/*  32 */     appendAllRecords(buf, query);
/*  33 */     return buf;
/*     */   }
/*     */   
/*     */   static StringBuilder appendResponse(StringBuilder buf, DnsResponse response) {
/*  37 */     appendResponseHeader(buf, response);
/*  38 */     appendAllRecords(buf, response);
/*  39 */     return buf;
/*     */   }
/*     */   
/*     */   static StringBuilder appendRecordClass(StringBuilder buf, int dnsClass) {
/*     */     String name;
/*  44 */     switch (dnsClass &= 0xFFFF) {
/*     */       case 1:
/*  46 */         name = "IN";
/*     */         break;
/*     */       case 2:
/*  49 */         name = "CSNET";
/*     */         break;
/*     */       case 3:
/*  52 */         name = "CHAOS";
/*     */         break;
/*     */       case 4:
/*  55 */         name = "HESIOD";
/*     */         break;
/*     */       case 254:
/*  58 */         name = "NONE";
/*     */         break;
/*     */       case 255:
/*  61 */         name = "ANY";
/*     */         break;
/*     */       default:
/*  64 */         name = null;
/*     */         break;
/*     */     } 
/*     */     
/*  68 */     if (name != null) {
/*  69 */       buf.append(name);
/*     */     } else {
/*  71 */       buf.append("UNKNOWN(").append(dnsClass).append(')');
/*     */     } 
/*     */     
/*  74 */     return buf;
/*     */   }
/*     */   
/*     */   private static void appendQueryHeader(StringBuilder buf, DnsQuery msg) {
/*  78 */     buf.append(StringUtil.simpleClassName(msg))
/*  79 */       .append('(');
/*     */     
/*  81 */     appendAddresses(buf, msg)
/*  82 */       .append(msg.id())
/*  83 */       .append(", ")
/*  84 */       .append(msg.opCode());
/*     */     
/*  86 */     if (msg.isRecursionDesired()) {
/*  87 */       buf.append(", RD");
/*     */     }
/*  89 */     if (msg.z() != 0) {
/*  90 */       buf.append(", Z: ")
/*  91 */         .append(msg.z());
/*     */     }
/*  93 */     buf.append(')');
/*     */   }
/*     */   
/*     */   private static void appendResponseHeader(StringBuilder buf, DnsResponse msg) {
/*  97 */     buf.append(StringUtil.simpleClassName(msg))
/*  98 */       .append('(');
/*     */     
/* 100 */     appendAddresses(buf, msg)
/* 101 */       .append(msg.id())
/* 102 */       .append(", ")
/* 103 */       .append(msg.opCode())
/* 104 */       .append(", ")
/* 105 */       .append(msg.code())
/* 106 */       .append(',');
/*     */     
/* 108 */     boolean hasComma = true;
/* 109 */     if (msg.isRecursionDesired()) {
/* 110 */       hasComma = false;
/* 111 */       buf.append(" RD");
/*     */     } 
/* 113 */     if (msg.isAuthoritativeAnswer()) {
/* 114 */       hasComma = false;
/* 115 */       buf.append(" AA");
/*     */     } 
/* 117 */     if (msg.isTruncated()) {
/* 118 */       hasComma = false;
/* 119 */       buf.append(" TC");
/*     */     } 
/* 121 */     if (msg.isRecursionAvailable()) {
/* 122 */       hasComma = false;
/* 123 */       buf.append(" RA");
/*     */     } 
/* 125 */     if (msg.z() != 0) {
/* 126 */       if (!hasComma) {
/* 127 */         buf.append(',');
/*     */       }
/* 129 */       buf.append(" Z: ")
/* 130 */         .append(msg.z());
/*     */     } 
/*     */     
/* 133 */     if (hasComma) {
/* 134 */       buf.setCharAt(buf.length() - 1, ')');
/*     */     } else {
/* 136 */       buf.append(')');
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static StringBuilder appendAddresses(StringBuilder buf, DnsMessage msg) {
/* 142 */     if (!(msg instanceof AddressedEnvelope)) {
/* 143 */       return buf;
/*     */     }
/*     */ 
/*     */     
/* 147 */     AddressedEnvelope<?, SocketAddress> envelope = (AddressedEnvelope<?, SocketAddress>)msg;
/*     */     
/* 149 */     SocketAddress addr = envelope.sender();
/* 150 */     if (addr != null) {
/* 151 */       buf.append("from: ")
/* 152 */         .append(addr)
/* 153 */         .append(", ");
/*     */     }
/*     */     
/* 156 */     addr = envelope.recipient();
/* 157 */     if (addr != null) {
/* 158 */       buf.append("to: ")
/* 159 */         .append(addr)
/* 160 */         .append(", ");
/*     */     }
/*     */     
/* 163 */     return buf;
/*     */   }
/*     */   
/*     */   private static void appendAllRecords(StringBuilder buf, DnsMessage msg) {
/* 167 */     appendRecords(buf, msg, DnsSection.QUESTION);
/* 168 */     appendRecords(buf, msg, DnsSection.ANSWER);
/* 169 */     appendRecords(buf, msg, DnsSection.AUTHORITY);
/* 170 */     appendRecords(buf, msg, DnsSection.ADDITIONAL);
/*     */   }
/*     */   
/*     */   private static void appendRecords(StringBuilder buf, DnsMessage message, DnsSection section) {
/* 174 */     int count = message.count(section);
/* 175 */     for (int i = 0; i < count; i++) {
/* 176 */       buf.append(StringUtil.NEWLINE)
/* 177 */         .append('\t')
/* 178 */         .append(message.recordAt(section, i));
/*     */     }
/*     */   }
/*     */   
/*     */   static DnsQuery decodeDnsQuery(DnsRecordDecoder decoder, ByteBuf buf, DnsQueryFactory supplier) throws Exception {
/* 183 */     DnsQuery query = newQuery(buf, supplier);
/* 184 */     boolean success = false;
/*     */     try {
/* 186 */       int questionCount = buf.readUnsignedShort();
/* 187 */       int answerCount = buf.readUnsignedShort();
/* 188 */       int authorityRecordCount = buf.readUnsignedShort();
/* 189 */       int additionalRecordCount = buf.readUnsignedShort();
/* 190 */       decodeQuestions(decoder, query, buf, questionCount);
/* 191 */       decodeRecords(decoder, query, DnsSection.ANSWER, buf, answerCount);
/* 192 */       decodeRecords(decoder, query, DnsSection.AUTHORITY, buf, authorityRecordCount);
/* 193 */       decodeRecords(decoder, query, DnsSection.ADDITIONAL, buf, additionalRecordCount);
/* 194 */       success = true;
/* 195 */       return query;
/*     */     } finally {
/* 197 */       if (!success) {
/* 198 */         query.release();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static DnsQuery newQuery(ByteBuf buf, DnsQueryFactory supplier) {
/* 204 */     int id = buf.readUnsignedShort();
/* 205 */     int flags = buf.readUnsignedShort();
/* 206 */     if (flags >> 15 == 1) {
/* 207 */       throw new CorruptedFrameException("not a query");
/*     */     }
/*     */     
/* 210 */     DnsQuery query = supplier.newQuery(id, DnsOpCode.valueOf((byte)(flags >> 11 & 0xF)));
/* 211 */     query.setRecursionDesired(((flags >> 8 & 0x1) == 1));
/* 212 */     query.setZ(flags >> 4 & 0x7);
/* 213 */     return query;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void decodeQuestions(DnsRecordDecoder decoder, DnsQuery query, ByteBuf buf, int questionCount) throws Exception {
/* 218 */     for (int i = questionCount; i > 0; i--) {
/* 219 */       query.addRecord(DnsSection.QUESTION, decoder.decodeQuestion(buf));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void decodeRecords(DnsRecordDecoder decoder, DnsQuery query, DnsSection section, ByteBuf buf, int count) throws Exception {
/* 225 */     for (int i = count; i > 0; i--) {
/* 226 */       DnsRecord r = decoder.decodeRecord(buf);
/* 227 */       if (r == null) {
/*     */         break;
/*     */       }
/* 230 */       query.addRecord(section, r);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void encodeDnsResponse(DnsRecordEncoder encoder, DnsResponse response, ByteBuf buf) throws Exception {
/* 235 */     boolean success = false;
/*     */     try {
/* 237 */       encodeHeader(response, buf);
/* 238 */       encodeQuestions(encoder, response, buf);
/* 239 */       encodeRecords(encoder, response, DnsSection.ANSWER, buf);
/* 240 */       encodeRecords(encoder, response, DnsSection.AUTHORITY, buf);
/* 241 */       encodeRecords(encoder, response, DnsSection.ADDITIONAL, buf);
/* 242 */       success = true;
/*     */     } finally {
/* 244 */       if (!success) {
/* 245 */         buf.release();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void encodeHeader(DnsResponse response, ByteBuf buf) {
/* 257 */     buf.writeShort(response.id());
/* 258 */     int flags = 32768;
/* 259 */     flags |= (response.opCode().byteValue() & 0xFF) << 11;
/* 260 */     if (response.isAuthoritativeAnswer()) {
/* 261 */       flags |= 0x400;
/*     */     }
/* 263 */     if (response.isTruncated()) {
/* 264 */       flags |= 0x200;
/*     */     }
/* 266 */     if (response.isRecursionDesired()) {
/* 267 */       flags |= 0x100;
/*     */     }
/* 269 */     if (response.isRecursionAvailable()) {
/* 270 */       flags |= 0x80;
/*     */     }
/* 272 */     flags |= response.z() << 4;
/* 273 */     flags |= response.code().intValue();
/* 274 */     buf.writeShort(flags);
/* 275 */     buf.writeShort(response.count(DnsSection.QUESTION));
/* 276 */     buf.writeShort(response.count(DnsSection.ANSWER));
/* 277 */     buf.writeShort(response.count(DnsSection.AUTHORITY));
/* 278 */     buf.writeShort(response.count(DnsSection.ADDITIONAL));
/*     */   }
/*     */   
/*     */   private static void encodeQuestions(DnsRecordEncoder encoder, DnsResponse response, ByteBuf buf) throws Exception {
/* 282 */     int count = response.count(DnsSection.QUESTION);
/* 283 */     for (int i = 0; i < count; i++) {
/* 284 */       encoder.encodeQuestion(response.<DnsQuestion>recordAt(DnsSection.QUESTION, i), buf);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void encodeRecords(DnsRecordEncoder encoder, DnsResponse response, DnsSection section, ByteBuf buf) throws Exception {
/* 290 */     int count = response.count(section);
/* 291 */     for (int i = 0; i < count; i++)
/* 292 */       encoder.encodeRecord(response.recordAt(section, i), buf); 
/*     */   }
/*     */   
/*     */   static interface DnsQueryFactory {
/*     */     DnsQuery newQuery(int param1Int, DnsOpCode param1DnsOpCode);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DnsMessageUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */