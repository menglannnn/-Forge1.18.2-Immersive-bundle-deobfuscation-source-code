/*     */ package io.netty.handler.codec.dns;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DnsOpCode
/*     */   implements Comparable<DnsOpCode>
/*     */ {
/*  31 */   public static final DnsOpCode QUERY = new DnsOpCode(0, "QUERY");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   public static final DnsOpCode IQUERY = new DnsOpCode(1, "IQUERY");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   public static final DnsOpCode STATUS = new DnsOpCode(2, "STATUS");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final DnsOpCode NOTIFY = new DnsOpCode(4, "NOTIFY");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final DnsOpCode UPDATE = new DnsOpCode(5, "UPDATE");
/*     */   private final byte byteValue;
/*     */   private final String name;
/*     */   private String text;
/*     */   
/*     */   public static DnsOpCode valueOf(int b) {
/*  57 */     switch (b) {
/*     */       case 0:
/*  59 */         return QUERY;
/*     */       case 1:
/*  61 */         return IQUERY;
/*     */       case 2:
/*  63 */         return STATUS;
/*     */       case 4:
/*  65 */         return NOTIFY;
/*     */       case 5:
/*  67 */         return UPDATE;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  72 */     return new DnsOpCode(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DnsOpCode(int byteValue) {
/*  80 */     this(byteValue, "UNKNOWN");
/*     */   }
/*     */   
/*     */   public DnsOpCode(int byteValue, String name) {
/*  84 */     this.byteValue = (byte)byteValue;
/*  85 */     this.name = (String)ObjectUtil.checkNotNull(name, "name");
/*     */   }
/*     */   
/*     */   public byte byteValue() {
/*  89 */     return this.byteValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  94 */     return this.byteValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  99 */     if (this == obj) {
/* 100 */       return true;
/*     */     }
/*     */     
/* 103 */     if (!(obj instanceof DnsOpCode)) {
/* 104 */       return false;
/*     */     }
/*     */     
/* 107 */     return (this.byteValue == ((DnsOpCode)obj).byteValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(DnsOpCode o) {
/* 112 */     return this.byteValue - o.byteValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 117 */     String text = this.text;
/* 118 */     if (text == null) {
/* 119 */       this.text = text = this.name + '(' + (this.byteValue & 0xFF) + ')';
/*     */     }
/* 121 */     return text;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DnsOpCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */