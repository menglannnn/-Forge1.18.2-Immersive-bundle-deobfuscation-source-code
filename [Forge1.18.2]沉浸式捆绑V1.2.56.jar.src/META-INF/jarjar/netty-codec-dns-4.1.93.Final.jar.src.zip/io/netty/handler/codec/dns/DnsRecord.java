package io.netty.handler.codec.dns;

public interface DnsRecord {
  public static final int CLASS_IN = 1;
  
  public static final int CLASS_CSNET = 2;
  
  public static final int CLASS_CHAOS = 3;
  
  public static final int CLASS_HESIOD = 4;
  
  public static final int CLASS_NONE = 254;
  
  public static final int CLASS_ANY = 255;
  
  String name();
  
  DnsRecordType type();
  
  int dnsClass();
  
  long timeToLive();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DnsRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */