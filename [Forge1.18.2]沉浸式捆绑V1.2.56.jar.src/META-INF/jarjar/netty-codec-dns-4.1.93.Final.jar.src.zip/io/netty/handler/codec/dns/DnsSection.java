/*    */ package io.netty.handler.codec.dns;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DnsSection
/*    */ {
/* 28 */   QUESTION,
/*    */ 
/*    */ 
/*    */   
/* 32 */   ANSWER,
/*    */ 
/*    */ 
/*    */   
/* 36 */   AUTHORITY,
/*    */ 
/*    */ 
/*    */   
/* 40 */   ADDITIONAL;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DnsSection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */