/*    */ package io.netty.handler.codec.dns;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.MessageToMessageEncoder;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Sharable
/*    */ public final class TcpDnsResponseEncoder
/*    */   extends MessageToMessageEncoder<DnsResponse>
/*    */ {
/*    */   private final DnsRecordEncoder encoder;
/*    */   
/*    */   public TcpDnsResponseEncoder() {
/* 36 */     this(DnsRecordEncoder.DEFAULT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TcpDnsResponseEncoder(DnsRecordEncoder encoder) {
/* 43 */     this.encoder = (DnsRecordEncoder)ObjectUtil.checkNotNull(encoder, "encoder");
/*    */   }
/*    */ 
/*    */   
/*    */   protected void encode(ChannelHandlerContext ctx, DnsResponse response, List<Object> out) throws Exception {
/* 48 */     ByteBuf buf = ctx.alloc().ioBuffer(1024);
/*    */     
/* 50 */     buf.writerIndex(buf.writerIndex() + 2);
/* 51 */     DnsMessageUtil.encodeDnsResponse(this.encoder, response, buf);
/* 52 */     buf.setShort(0, buf.readableBytes() - 2);
/*    */     
/* 54 */     out.add(buf);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\TcpDnsResponseEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */