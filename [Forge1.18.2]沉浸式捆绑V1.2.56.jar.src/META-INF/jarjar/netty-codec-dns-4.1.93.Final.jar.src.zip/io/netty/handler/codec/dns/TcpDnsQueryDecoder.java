/*    */ package io.netty.handler.codec.dns;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TcpDnsQueryDecoder
/*    */   extends LengthFieldBasedFrameDecoder
/*    */ {
/*    */   private final DnsRecordDecoder decoder;
/*    */   
/*    */   public TcpDnsQueryDecoder() {
/* 32 */     this(DnsRecordDecoder.DEFAULT, 65535);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TcpDnsQueryDecoder(DnsRecordDecoder decoder, int maxFrameLength) {
/* 39 */     super(maxFrameLength, 0, 2, 0, 2);
/* 40 */     this.decoder = (DnsRecordDecoder)ObjectUtil.checkNotNull(decoder, "decoder");
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object decode(ChannelHandlerContext ctx, ByteBuf in) throws Exception {
/* 45 */     ByteBuf frame = (ByteBuf)super.decode(ctx, in);
/* 46 */     if (frame == null) {
/* 47 */       return null;
/*    */     }
/*    */     
/* 50 */     return DnsMessageUtil.decodeDnsQuery(this.decoder, frame.slice(), new DnsMessageUtil.DnsQueryFactory()
/*    */         {
/*    */           public DnsQuery newQuery(int id, DnsOpCode dnsOpCode) {
/* 53 */             return new DefaultDnsQuery(id, dnsOpCode);
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\TcpDnsQueryDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */