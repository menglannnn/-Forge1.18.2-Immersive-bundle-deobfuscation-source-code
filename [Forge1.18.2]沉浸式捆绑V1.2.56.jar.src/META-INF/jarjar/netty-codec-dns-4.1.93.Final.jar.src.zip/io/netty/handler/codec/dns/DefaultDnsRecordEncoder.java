/*     */ package io.netty.handler.codec.dns;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.socket.InternetProtocolFamily;
/*     */ import io.netty.handler.codec.UnsupportedMessageTypeException;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDnsRecordEncoder
/*     */   implements DnsRecordEncoder
/*     */ {
/*     */   private static final int PREFIX_MASK = 7;
/*     */   
/*     */   public final void encodeQuestion(DnsQuestion question, ByteBuf out) throws Exception {
/*  40 */     encodeName(question.name(), out);
/*  41 */     out.writeShort(question.type().intValue());
/*  42 */     out.writeShort(question.dnsClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeRecord(DnsRecord record, ByteBuf out) throws Exception {
/*  47 */     if (record instanceof DnsQuestion) {
/*  48 */       encodeQuestion((DnsQuestion)record, out);
/*  49 */     } else if (record instanceof DnsPtrRecord) {
/*  50 */       encodePtrRecord((DnsPtrRecord)record, out);
/*  51 */     } else if (record instanceof DnsOptEcsRecord) {
/*  52 */       encodeOptEcsRecord((DnsOptEcsRecord)record, out);
/*  53 */     } else if (record instanceof DnsOptPseudoRecord) {
/*  54 */       encodeOptPseudoRecord((DnsOptPseudoRecord)record, out);
/*  55 */     } else if (record instanceof DnsRawRecord) {
/*  56 */       encodeRawRecord((DnsRawRecord)record, out);
/*     */     } else {
/*  58 */       throw new UnsupportedMessageTypeException(StringUtil.simpleClassName(record));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeRecord0(DnsRecord record, ByteBuf out) throws Exception {
/*  63 */     encodeName(record.name(), out);
/*  64 */     out.writeShort(record.type().intValue());
/*  65 */     out.writeShort(record.dnsClass());
/*  66 */     out.writeInt((int)record.timeToLive());
/*     */   }
/*     */   
/*     */   private void encodePtrRecord(DnsPtrRecord record, ByteBuf out) throws Exception {
/*  70 */     encodeRecord0(record, out);
/*  71 */     encodeName(record.hostname(), out);
/*     */   }
/*     */   
/*     */   private void encodeOptPseudoRecord(DnsOptPseudoRecord record, ByteBuf out) throws Exception {
/*  75 */     encodeRecord0(record, out);
/*  76 */     out.writeShort(0);
/*     */   }
/*     */   
/*     */   private void encodeOptEcsRecord(DnsOptEcsRecord record, ByteBuf out) throws Exception {
/*  80 */     encodeRecord0(record, out);
/*     */     
/*  82 */     int sourcePrefixLength = record.sourcePrefixLength();
/*  83 */     int scopePrefixLength = record.scopePrefixLength();
/*  84 */     int lowOrderBitsToPreserve = sourcePrefixLength & 0x7;
/*     */     
/*  86 */     byte[] bytes = record.address();
/*  87 */     int addressBits = bytes.length << 3;
/*  88 */     if (addressBits < sourcePrefixLength || sourcePrefixLength < 0) {
/*  89 */       throw new IllegalArgumentException(sourcePrefixLength + ": " + sourcePrefixLength + " (expected: 0 >= " + addressBits + ')');
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     short addressNumber = (short)((bytes.length == 4) ? InternetProtocolFamily.IPv4.addressNumber() : InternetProtocolFamily.IPv6.addressNumber());
/*  96 */     int payloadLength = calculateEcsAddressLength(sourcePrefixLength, lowOrderBitsToPreserve);
/*     */     
/*  98 */     int fullPayloadLength = 8 + payloadLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     out.writeShort(fullPayloadLength);
/* 106 */     out.writeShort(8);
/*     */     
/* 108 */     out.writeShort(fullPayloadLength - 4);
/* 109 */     out.writeShort(addressNumber);
/* 110 */     out.writeByte(sourcePrefixLength);
/* 111 */     out.writeByte(scopePrefixLength);
/*     */     
/* 113 */     if (lowOrderBitsToPreserve > 0) {
/* 114 */       int bytesLength = payloadLength - 1;
/* 115 */       out.writeBytes(bytes, 0, bytesLength);
/*     */ 
/*     */       
/* 118 */       out.writeByte(padWithZeros(bytes[bytesLength], lowOrderBitsToPreserve));
/*     */     } else {
/*     */       
/* 121 */       out.writeBytes(bytes, 0, payloadLength);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static int calculateEcsAddressLength(int sourcePrefixLength, int lowOrderBitsToPreserve) {
/* 127 */     return (sourcePrefixLength >>> 3) + ((lowOrderBitsToPreserve != 0) ? 1 : 0);
/*     */   }
/*     */   
/*     */   private void encodeRawRecord(DnsRawRecord record, ByteBuf out) throws Exception {
/* 131 */     encodeRecord0(record, out);
/*     */     
/* 133 */     ByteBuf content = record.content();
/* 134 */     int contentLen = content.readableBytes();
/*     */     
/* 136 */     out.writeShort(contentLen);
/* 137 */     out.writeBytes(content, content.readerIndex(), contentLen);
/*     */   }
/*     */   
/*     */   protected void encodeName(String name, ByteBuf buf) throws Exception {
/* 141 */     DnsCodecUtil.encodeDomainName(name, buf);
/*     */   }
/*     */   
/*     */   private static byte padWithZeros(byte b, int lowOrderBitsToPreserve) {
/* 145 */     switch (lowOrderBitsToPreserve) {
/*     */       case 0:
/* 147 */         return 0;
/*     */       case 1:
/* 149 */         return (byte)(0x80 & b);
/*     */       case 2:
/* 151 */         return (byte)(0xC0 & b);
/*     */       case 3:
/* 153 */         return (byte)(0xE0 & b);
/*     */       case 4:
/* 155 */         return (byte)(0xF0 & b);
/*     */       case 5:
/* 157 */         return (byte)(0xF8 & b);
/*     */       case 6:
/* 159 */         return (byte)(0xFC & b);
/*     */       case 7:
/* 161 */         return (byte)(0xFE & b);
/*     */       case 8:
/* 163 */         return b;
/*     */     } 
/* 165 */     throw new IllegalArgumentException("lowOrderBitsToPreserve: " + lowOrderBitsToPreserve);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DefaultDnsRecordEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */