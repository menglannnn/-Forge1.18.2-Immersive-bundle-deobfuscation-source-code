/*     */ package io.netty.handler.codec.dns;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.handler.codec.CorruptedFrameException;
/*     */ import io.netty.util.CharsetUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DnsCodecUtil
/*     */ {
/*     */   static void encodeDomainName(String name, ByteBuf buf) {
/*  32 */     if (".".equals(name)) {
/*     */       
/*  34 */       buf.writeByte(0);
/*     */       
/*     */       return;
/*     */     } 
/*  38 */     String[] labels = name.split("\\.");
/*  39 */     for (String label : labels) {
/*  40 */       int labelLen = label.length();
/*  41 */       if (labelLen == 0) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/*  46 */       buf.writeByte(labelLen);
/*  47 */       ByteBufUtil.writeAscii(buf, label);
/*     */     } 
/*     */     
/*  50 */     buf.writeByte(0);
/*     */   }
/*     */   
/*     */   static String decodeDomainName(ByteBuf in) {
/*  54 */     int position = -1;
/*  55 */     int checked = 0;
/*  56 */     int end = in.writerIndex();
/*  57 */     int readable = in.readableBytes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     if (readable == 0) {
/*  67 */       return ".";
/*     */     }
/*     */     
/*  70 */     StringBuilder name = new StringBuilder(readable << 1);
/*  71 */     while (in.isReadable()) {
/*  72 */       int len = in.readUnsignedByte();
/*  73 */       boolean pointer = ((len & 0xC0) == 192);
/*  74 */       if (pointer) {
/*  75 */         if (position == -1) {
/*  76 */           position = in.readerIndex() + 1;
/*     */         }
/*     */         
/*  79 */         if (!in.isReadable()) {
/*  80 */           throw new CorruptedFrameException("truncated pointer in a name");
/*     */         }
/*     */         
/*  83 */         int next = (len & 0x3F) << 8 | in.readUnsignedByte();
/*  84 */         if (next >= end) {
/*  85 */           throw new CorruptedFrameException("name has an out-of-range pointer");
/*     */         }
/*  87 */         in.readerIndex(next);
/*     */ 
/*     */         
/*  90 */         checked += 2;
/*  91 */         if (checked >= end)
/*  92 */           throw new CorruptedFrameException("name contains a loop.");  continue;
/*     */       } 
/*  94 */       if (len != 0) {
/*  95 */         if (!in.isReadable(len)) {
/*  96 */           throw new CorruptedFrameException("truncated label in a name");
/*     */         }
/*  98 */         name.append(in.toString(in.readerIndex(), len, CharsetUtil.UTF_8)).append('.');
/*  99 */         in.skipBytes(len);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 105 */     if (position != -1) {
/* 106 */       in.readerIndex(position);
/*     */     }
/*     */     
/* 109 */     if (name.length() == 0) {
/* 110 */       return ".";
/*     */     }
/*     */     
/* 113 */     if (name.charAt(name.length() - 1) != '.') {
/* 114 */       name.append('.');
/*     */     }
/*     */     
/* 117 */     return name.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ByteBuf decompressDomainName(ByteBuf compression) {
/* 126 */     String domainName = decodeDomainName(compression);
/* 127 */     ByteBuf result = compression.alloc().buffer(domainName.length() << 1);
/* 128 */     encodeDomainName(domainName, result);
/* 129 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DnsCodecUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */