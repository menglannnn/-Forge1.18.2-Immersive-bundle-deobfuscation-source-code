/*    */ package io.netty.handler.codec.dns;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.AddressedEnvelope;
/*    */ import io.netty.channel.ChannelHandler.Sharable;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.socket.DatagramPacket;
/*    */ import io.netty.handler.codec.MessageToMessageEncoder;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Sharable
/*    */ public class DatagramDnsQueryEncoder
/*    */   extends MessageToMessageEncoder<AddressedEnvelope<DnsQuery, InetSocketAddress>>
/*    */ {
/*    */   private final DnsQueryEncoder encoder;
/*    */   
/*    */   public DatagramDnsQueryEncoder() {
/* 43 */     this(DnsRecordEncoder.DEFAULT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DatagramDnsQueryEncoder(DnsRecordEncoder recordEncoder) {
/* 50 */     this.encoder = new DnsQueryEncoder(recordEncoder);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void encode(ChannelHandlerContext ctx, AddressedEnvelope<DnsQuery, InetSocketAddress> in, List<Object> out) throws Exception {
/* 58 */     InetSocketAddress recipient = (InetSocketAddress)in.recipient();
/* 59 */     DnsQuery query = (DnsQuery)in.content();
/* 60 */     ByteBuf buf = allocateBuffer(ctx, in);
/*    */     
/* 62 */     boolean success = false;
/*    */     try {
/* 64 */       this.encoder.encode(query, buf);
/* 65 */       success = true;
/*    */     } finally {
/* 67 */       if (!success) {
/* 68 */         buf.release();
/*    */       }
/*    */     } 
/*    */     
/* 72 */     out.add(new DatagramPacket(buf, recipient, null));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ByteBuf allocateBuffer(ChannelHandlerContext ctx, AddressedEnvelope<DnsQuery, InetSocketAddress> msg) throws Exception {
/* 82 */     return ctx.alloc().ioBuffer(1024);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DatagramDnsQueryEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */