/*    */ package io.netty.handler.codec.dns;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface DnsRecordEncoder
/*    */ {
/* 29 */   public static final DnsRecordEncoder DEFAULT = new DefaultDnsRecordEncoder();
/*    */   
/*    */   void encodeQuestion(DnsQuestion paramDnsQuestion, ByteBuf paramByteBuf) throws Exception;
/*    */   
/*    */   void encodeRecord(DnsRecord paramDnsRecord, ByteBuf paramByteBuf) throws Exception;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DnsRecordEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */