package io.netty.handler.codec.dns;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufHolder;

public interface DnsRawRecord extends DnsRecord, ByteBufHolder {
  DnsRawRecord copy();
  
  DnsRawRecord duplicate();
  
  DnsRawRecord retainedDuplicate();
  
  DnsRawRecord replace(ByteBuf paramByteBuf);
  
  DnsRawRecord retain();
  
  DnsRawRecord retain(int paramInt);
  
  DnsRawRecord touch();
  
  DnsRawRecord touch(Object paramObject);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-dns-4.1.93.Final.jar!\io\netty\handler\codec\dns\DnsRawRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */