package com.fasterxml.jackson.annotation;

public interface JacksonAnnotationValue<A extends java.lang.annotation.Annotation> {
  Class<A> valueFor();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-annotations-2.14.2.jar!\com\fasterxml\jackson\annotation\JacksonAnnotationValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */