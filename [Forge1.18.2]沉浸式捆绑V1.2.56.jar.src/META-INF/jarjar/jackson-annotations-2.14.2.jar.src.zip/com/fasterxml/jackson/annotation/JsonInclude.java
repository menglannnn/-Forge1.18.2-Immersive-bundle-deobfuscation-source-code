/*     */ package com.fasterxml.jackson.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Target({ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.TYPE, ElementType.PARAMETER})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @JacksonAnnotation
/*     */ public @interface JsonInclude
/*     */ {
/*     */   Include value() default Include.ALWAYS;
/*     */   
/*     */   Include content() default Include.ALWAYS;
/*     */   
/*     */   Class<?> valueFilter() default Void.class;
/*     */   
/*     */   Class<?> contentFilter() default Void.class;
/*     */   
/*     */   public enum Include
/*     */   {
/* 119 */     ALWAYS,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     NON_NULL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     NON_ABSENT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     NON_EMPTY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     NON_DEFAULT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     CUSTOM,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     USE_DEFAULTS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Value
/*     */     implements JacksonAnnotationValue<JsonInclude>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     protected static final Value EMPTY = new Value(JsonInclude.Include.USE_DEFAULTS, JsonInclude.Include.USE_DEFAULTS, null, null);
/*     */ 
/*     */     
/*     */     protected final JsonInclude.Include _valueInclusion;
/*     */ 
/*     */     
/*     */     protected final JsonInclude.Include _contentInclusion;
/*     */ 
/*     */     
/*     */     protected final Class<?> _valueFilter;
/*     */ 
/*     */     
/*     */     protected final Class<?> _contentFilter;
/*     */ 
/*     */ 
/*     */     
/*     */     public Value(JsonInclude src) {
/* 278 */       this(src.value(), src.content(), src
/* 279 */           .valueFilter(), src.contentFilter());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Value(JsonInclude.Include vi, JsonInclude.Include ci, Class<?> valueFilter, Class<?> contentFilter) {
/* 284 */       this._valueInclusion = (vi == null) ? JsonInclude.Include.USE_DEFAULTS : vi;
/* 285 */       this._contentInclusion = (ci == null) ? JsonInclude.Include.USE_DEFAULTS : ci;
/* 286 */       this._valueFilter = (valueFilter == Void.class) ? null : valueFilter;
/* 287 */       this._contentFilter = (contentFilter == Void.class) ? null : contentFilter;
/*     */     }
/*     */     
/*     */     public static Value empty() {
/* 291 */       return EMPTY;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value merge(Value base, Value overrides) {
/* 307 */       return (base == null) ? overrides : base
/* 308 */         .withOverrides(overrides);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value mergeAll(Value... values) {
/* 316 */       Value result = null;
/* 317 */       for (Value curr : values) {
/* 318 */         if (curr != null) {
/* 319 */           result = (result == null) ? curr : result.withOverrides(curr);
/*     */         }
/*     */       } 
/* 322 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 327 */       if (this._valueInclusion == JsonInclude.Include.USE_DEFAULTS && this._contentInclusion == JsonInclude.Include.USE_DEFAULTS && this._valueFilter == null && this._contentFilter == null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 332 */         return EMPTY;
/*     */       }
/* 334 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withOverrides(Value overrides) {
/* 344 */       if (overrides == null || overrides == EMPTY) {
/* 345 */         return this;
/*     */       }
/* 347 */       JsonInclude.Include vi = overrides._valueInclusion;
/* 348 */       JsonInclude.Include ci = overrides._contentInclusion;
/* 349 */       Class<?> vf = overrides._valueFilter;
/* 350 */       Class<?> cf = overrides._contentFilter;
/*     */       
/* 352 */       boolean viDiff = (vi != this._valueInclusion && vi != JsonInclude.Include.USE_DEFAULTS);
/* 353 */       boolean ciDiff = (ci != this._contentInclusion && ci != JsonInclude.Include.USE_DEFAULTS);
/* 354 */       boolean filterDiff = (vf != this._valueFilter || cf != this._valueFilter);
/*     */       
/* 356 */       if (viDiff) {
/* 357 */         if (ciDiff) {
/* 358 */           return new Value(vi, ci, vf, cf);
/*     */         }
/* 360 */         return new Value(vi, this._contentInclusion, vf, cf);
/* 361 */       }  if (ciDiff)
/* 362 */         return new Value(this._valueInclusion, ci, vf, cf); 
/* 363 */       if (filterDiff) {
/* 364 */         return new Value(this._valueInclusion, this._contentInclusion, vf, cf);
/*     */       }
/* 366 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(JsonInclude.Include valueIncl, JsonInclude.Include contentIncl) {
/* 373 */       if ((valueIncl == JsonInclude.Include.USE_DEFAULTS || valueIncl == null) && (contentIncl == JsonInclude.Include.USE_DEFAULTS || contentIncl == null))
/*     */       {
/* 375 */         return EMPTY;
/*     */       }
/* 377 */       return new Value(valueIncl, contentIncl, null, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(JsonInclude.Include valueIncl, JsonInclude.Include contentIncl, Class<?> valueFilter, Class<?> contentFilter) {
/* 388 */       if (valueFilter == Void.class) {
/* 389 */         valueFilter = null;
/*     */       }
/* 391 */       if (contentFilter == Void.class) {
/* 392 */         contentFilter = null;
/*     */       }
/* 394 */       if ((valueIncl == JsonInclude.Include.USE_DEFAULTS || valueIncl == null) && (contentIncl == JsonInclude.Include.USE_DEFAULTS || contentIncl == null) && valueFilter == null && contentFilter == null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 399 */         return EMPTY;
/*     */       }
/* 401 */       return new Value(valueIncl, contentIncl, valueFilter, contentFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value from(JsonInclude src) {
/* 409 */       if (src == null) {
/* 410 */         return EMPTY;
/*     */       }
/* 412 */       JsonInclude.Include vi = src.value();
/* 413 */       JsonInclude.Include ci = src.content();
/*     */       
/* 415 */       if (vi == JsonInclude.Include.USE_DEFAULTS && ci == JsonInclude.Include.USE_DEFAULTS) {
/* 416 */         return EMPTY;
/*     */       }
/* 418 */       Class<?> vf = src.valueFilter();
/* 419 */       if (vf == Void.class) {
/* 420 */         vf = null;
/*     */       }
/* 422 */       Class<?> cf = src.contentFilter();
/* 423 */       if (cf == Void.class) {
/* 424 */         cf = null;
/*     */       }
/* 426 */       return new Value(vi, ci, vf, cf);
/*     */     }
/*     */     
/*     */     public Value withValueInclusion(JsonInclude.Include incl) {
/* 430 */       return (incl == this._valueInclusion) ? this : new Value(incl, this._contentInclusion, this._valueFilter, this._contentFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withValueFilter(Class<?> filter) {
/*     */       JsonInclude.Include incl;
/* 448 */       if (filter == null || filter == Void.class) {
/* 449 */         incl = JsonInclude.Include.USE_DEFAULTS;
/* 450 */         filter = null;
/*     */       } else {
/* 452 */         incl = JsonInclude.Include.CUSTOM;
/*     */       } 
/* 454 */       return construct(incl, this._contentInclusion, filter, this._contentFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withContentFilter(Class<?> filter) {
/*     */       JsonInclude.Include incl;
/* 471 */       if (filter == null || filter == Void.class) {
/* 472 */         incl = JsonInclude.Include.USE_DEFAULTS;
/* 473 */         filter = null;
/*     */       } else {
/* 475 */         incl = JsonInclude.Include.CUSTOM;
/*     */       } 
/* 477 */       return construct(this._valueInclusion, incl, this._valueFilter, filter);
/*     */     }
/*     */     
/*     */     public Value withContentInclusion(JsonInclude.Include incl) {
/* 481 */       return (incl == this._contentInclusion) ? this : new Value(this._valueInclusion, incl, this._valueFilter, this._contentFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<JsonInclude> valueFor() {
/* 487 */       return JsonInclude.class;
/*     */     }
/*     */     
/*     */     public JsonInclude.Include getValueInclusion() {
/* 491 */       return this._valueInclusion;
/*     */     }
/*     */     
/*     */     public JsonInclude.Include getContentInclusion() {
/* 495 */       return this._contentInclusion;
/*     */     }
/*     */     
/*     */     public Class<?> getValueFilter() {
/* 499 */       return this._valueFilter;
/*     */     }
/*     */     
/*     */     public Class<?> getContentFilter() {
/* 503 */       return this._contentFilter;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 508 */       StringBuilder sb = new StringBuilder(80);
/* 509 */       sb.append("JsonInclude.Value(value=")
/* 510 */         .append(this._valueInclusion)
/* 511 */         .append(",content=")
/* 512 */         .append(this._contentInclusion);
/* 513 */       if (this._valueFilter != null) {
/* 514 */         sb.append(",valueFilter=").append(this._valueFilter.getName()).append(".class");
/*     */       }
/* 516 */       if (this._contentFilter != null) {
/* 517 */         sb.append(",contentFilter=").append(this._contentFilter.getName()).append(".class");
/*     */       }
/* 519 */       return sb.append(')').toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 524 */       return (this._valueInclusion.hashCode() << 2) + this._contentInclusion
/* 525 */         .hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 530 */       if (o == this) return true; 
/* 531 */       if (o == null) return false; 
/* 532 */       if (o.getClass() != getClass()) return false; 
/* 533 */       Value other = (Value)o;
/*     */       
/* 535 */       return (other._valueInclusion == this._valueInclusion && other._contentInclusion == this._contentInclusion && other._valueFilter == this._valueFilter && other._contentFilter == this._contentFilter);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-annotations-2.14.2.jar!\com\fasterxml\jackson\annotation\JsonInclude.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */