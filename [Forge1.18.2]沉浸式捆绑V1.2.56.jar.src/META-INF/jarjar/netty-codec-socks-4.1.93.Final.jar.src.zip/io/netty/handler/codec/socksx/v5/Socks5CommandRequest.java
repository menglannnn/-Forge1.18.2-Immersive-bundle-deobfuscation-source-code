package io.netty.handler.codec.socksx.v5;

public interface Socks5CommandRequest extends Socks5Message {
  Socks5CommandType type();
  
  Socks5AddressType dstAddrType();
  
  String dstAddr();
  
  int dstPort();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-socks-4.1.93.Final.jar!\io\netty\handler\codec\socksx\v5\Socks5CommandRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */