package io.netty.handler.codec.socksx.v5;

import io.netty.handler.codec.socksx.SocksMessage;

public interface Socks5Message extends SocksMessage {}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-socks-4.1.93.Final.jar!\io\netty\handler\codec\socksx\v5\Socks5Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */