/*    */ package io.netty.handler.codec.socksx.v4;
/*    */ 
/*    */ import io.netty.handler.codec.socksx.AbstractSocksMessage;
/*    */ import io.netty.handler.codec.socksx.SocksVersion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSocks4Message
/*    */   extends AbstractSocksMessage
/*    */   implements Socks4Message
/*    */ {
/*    */   public final SocksVersion version() {
/* 28 */     return SocksVersion.SOCKS4a;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-socks-4.1.93.Final.jar!\io\netty\handler\codec\socksx\v4\AbstractSocks4Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */