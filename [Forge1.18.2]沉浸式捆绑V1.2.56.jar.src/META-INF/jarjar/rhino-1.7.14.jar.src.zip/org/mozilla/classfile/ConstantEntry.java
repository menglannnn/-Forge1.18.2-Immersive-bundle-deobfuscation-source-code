/*    */ package org.mozilla.classfile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConstantEntry
/*    */ {
/*    */   private int type;
/*    */   private int intval;
/*    */   private long longval;
/*    */   private String str1;
/*    */   private String str2;
/*    */   private int hashcode;
/*    */   
/*    */   ConstantEntry(int type, int intval, String str1, String str2) {
/* 18 */     this.type = type;
/* 19 */     this.intval = intval;
/* 20 */     this.str1 = str1;
/* 21 */     this.str2 = str2;
/* 22 */     this.hashcode = type ^ intval + str1.hashCode() * str2.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 27 */     return this.hashcode;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 32 */     if (!(obj instanceof ConstantEntry)) {
/* 33 */       return false;
/*    */     }
/* 35 */     ConstantEntry entry = (ConstantEntry)obj;
/* 36 */     if (this.type != entry.type) {
/* 37 */       return false;
/*    */     }
/* 39 */     switch (this.type) {
/*    */       case 3:
/*    */       case 4:
/* 42 */         return (this.intval == entry.intval);
/*    */       case 5:
/*    */       case 6:
/* 45 */         return (this.longval == entry.longval);
/*    */       case 12:
/* 47 */         return (this.str1.equals(entry.str1) && this.str2.equals(entry.str2));
/*    */       case 18:
/* 49 */         return (this.intval == entry.intval && this.str1
/* 50 */           .equals(entry.str1) && this.str2
/* 51 */           .equals(entry.str2));
/*    */     } 
/* 53 */     throw new RuntimeException("unsupported constant type");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\classfile\ConstantEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */