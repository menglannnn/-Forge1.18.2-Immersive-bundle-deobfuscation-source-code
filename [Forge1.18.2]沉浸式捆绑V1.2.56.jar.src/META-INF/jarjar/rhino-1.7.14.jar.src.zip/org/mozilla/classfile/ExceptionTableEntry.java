/*    */ package org.mozilla.classfile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExceptionTableEntry
/*    */ {
/*    */   int itsStartLabel;
/*    */   int itsEndLabel;
/*    */   int itsHandlerLabel;
/*    */   short itsCatchType;
/*    */   
/*    */   ExceptionTableEntry(int startLabel, int endLabel, int handlerLabel, short catchType) {
/* 14 */     this.itsStartLabel = startLabel;
/* 15 */     this.itsEndLabel = endLabel;
/* 16 */     this.itsHandlerLabel = handlerLabel;
/* 17 */     this.itsCatchType = catchType;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\classfile\ExceptionTableEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */