/*    */ package org.mozilla.classfile;
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ClassFileField
/*    */ {
/*    */   private short itsNameIndex;
/*    */   private short itsTypeIndex;
/*    */   private short itsFlags;
/*    */   private boolean itsHasAttributes;
/*    */   
/*    */   ClassFileField(short nameIndex, short typeIndex, short flags) {
/* 13 */     this.itsNameIndex = nameIndex;
/* 14 */     this.itsTypeIndex = typeIndex;
/* 15 */     this.itsFlags = flags;
/* 16 */     this.itsHasAttributes = false;
/*    */   }
/*    */   private short itsAttr1; private short itsAttr2; private short itsAttr3; private int itsIndex;
/*    */   
/*    */   void setAttributes(short attr1, short attr2, short attr3, int index) {
/* 21 */     this.itsHasAttributes = true;
/* 22 */     this.itsAttr1 = attr1;
/* 23 */     this.itsAttr2 = attr2;
/* 24 */     this.itsAttr3 = attr3;
/* 25 */     this.itsIndex = index;
/*    */   }
/*    */ 
/*    */   
/*    */   int write(byte[] data, int offset) {
/* 30 */     offset = ClassFileWriter.putInt16(this.itsFlags, data, offset);
/* 31 */     offset = ClassFileWriter.putInt16(this.itsNameIndex, data, offset);
/* 32 */     offset = ClassFileWriter.putInt16(this.itsTypeIndex, data, offset);
/* 33 */     if (!this.itsHasAttributes) {
/*    */       
/* 35 */       offset = ClassFileWriter.putInt16(0, data, offset);
/*    */     } else {
/* 37 */       offset = ClassFileWriter.putInt16(1, data, offset);
/* 38 */       offset = ClassFileWriter.putInt16(this.itsAttr1, data, offset);
/* 39 */       offset = ClassFileWriter.putInt16(this.itsAttr2, data, offset);
/* 40 */       offset = ClassFileWriter.putInt16(this.itsAttr3, data, offset);
/* 41 */       offset = ClassFileWriter.putInt16(this.itsIndex, data, offset);
/*    */     } 
/* 43 */     return offset;
/*    */   }
/*    */ 
/*    */   
/*    */   int getWriteSize() {
/* 48 */     int size = 6;
/* 49 */     if (!this.itsHasAttributes) {
/* 50 */       size += 2;
/*    */     } else {
/* 52 */       size += 10;
/*    */     } 
/* 54 */     return size;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\classfile\ClassFileField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */