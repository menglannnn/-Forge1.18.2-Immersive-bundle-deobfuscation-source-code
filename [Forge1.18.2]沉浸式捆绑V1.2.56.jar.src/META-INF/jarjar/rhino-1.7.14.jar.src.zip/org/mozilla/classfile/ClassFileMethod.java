/*    */ package org.mozilla.classfile;
/*    */ 
/*    */ 
/*    */ final class ClassFileMethod
/*    */ {
/*    */   private String itsName;
/*    */   private String itsType;
/*    */   private short itsNameIndex;
/*    */   private short itsTypeIndex;
/*    */   private short itsFlags;
/*    */   private byte[] itsCodeAttribute;
/*    */   
/*    */   ClassFileMethod(String name, short nameIndex, String type, short typeIndex, short flags) {
/* 14 */     this.itsName = name;
/* 15 */     this.itsNameIndex = nameIndex;
/* 16 */     this.itsType = type;
/* 17 */     this.itsTypeIndex = typeIndex;
/* 18 */     this.itsFlags = flags;
/*    */   }
/*    */ 
/*    */   
/*    */   void setCodeAttribute(byte[] codeAttribute) {
/* 23 */     this.itsCodeAttribute = codeAttribute;
/*    */   }
/*    */ 
/*    */   
/*    */   int write(byte[] data, int offset) {
/* 28 */     offset = ClassFileWriter.putInt16(this.itsFlags, data, offset);
/* 29 */     offset = ClassFileWriter.putInt16(this.itsNameIndex, data, offset);
/* 30 */     offset = ClassFileWriter.putInt16(this.itsTypeIndex, data, offset);
/*    */     
/* 32 */     offset = ClassFileWriter.putInt16(1, data, offset);
/* 33 */     System.arraycopy(this.itsCodeAttribute, 0, data, offset, this.itsCodeAttribute.length);
/*    */     
/* 35 */     offset += this.itsCodeAttribute.length;
/* 36 */     return offset;
/*    */   }
/*    */ 
/*    */   
/*    */   int getWriteSize() {
/* 41 */     return 8 + this.itsCodeAttribute.length;
/*    */   }
/*    */ 
/*    */   
/*    */   String getName() {
/* 46 */     return this.itsName;
/*    */   }
/*    */ 
/*    */   
/*    */   String getType() {
/* 51 */     return this.itsType;
/*    */   }
/*    */ 
/*    */   
/*    */   short getFlags() {
/* 56 */     return this.itsFlags;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\classfile\ClassFileMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */