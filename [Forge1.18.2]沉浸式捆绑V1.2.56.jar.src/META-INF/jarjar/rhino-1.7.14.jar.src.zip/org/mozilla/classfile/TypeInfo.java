/*     */ package org.mozilla.classfile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TypeInfo
/*     */ {
/*     */   static final int TOP = 0;
/*     */   static final int INTEGER = 1;
/*     */   static final int FLOAT = 2;
/*     */   static final int DOUBLE = 3;
/*     */   static final int LONG = 4;
/*     */   static final int NULL = 5;
/*     */   static final int UNINITIALIZED_THIS = 6;
/*     */   static final int OBJECT_TAG = 7;
/*     */   static final int UNINITIALIZED_VAR_TAG = 8;
/*     */   
/*     */   static final int OBJECT(int constantPoolIndex) {
/*  29 */     return (constantPoolIndex & 0xFFFF) << 8 | 0x7;
/*     */   }
/*     */   
/*     */   static final int OBJECT(String type, ConstantPool pool) {
/*  33 */     return OBJECT(pool.addClass(type));
/*     */   }
/*     */   
/*     */   static final int UNINITIALIZED_VARIABLE(int bytecodeOffset) {
/*  37 */     return (bytecodeOffset & 0xFFFF) << 8 | 0x8;
/*     */   }
/*     */   
/*     */   static final int getTag(int typeInfo) {
/*  41 */     return typeInfo & 0xFF;
/*     */   }
/*     */   
/*     */   static final int getPayload(int typeInfo) {
/*  45 */     return typeInfo >>> 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String getPayloadAsType(int typeInfo, ConstantPool pool) {
/*  55 */     if (getTag(typeInfo) == 7) {
/*  56 */       return (String)pool.getConstantData(getPayload(typeInfo));
/*     */     }
/*  58 */     throw new IllegalArgumentException("expecting object type");
/*     */   }
/*     */ 
/*     */   
/*     */   static final int fromType(String type, ConstantPool pool) {
/*  63 */     if (type.length() == 1) {
/*  64 */       switch (type.charAt(0)) {
/*     */         case 'B':
/*     */         case 'C':
/*     */         case 'I':
/*     */         case 'S':
/*     */         case 'Z':
/*  70 */           return 1;
/*     */         case 'D':
/*  72 */           return 3;
/*     */         case 'F':
/*  74 */           return 2;
/*     */         case 'J':
/*  76 */           return 4;
/*     */       } 
/*  78 */       throw new IllegalArgumentException("bad type");
/*     */     } 
/*     */     
/*  81 */     return OBJECT(type, pool);
/*     */   }
/*     */   
/*     */   static boolean isTwoWords(int type) {
/*  85 */     return (type == 3 || type == 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int merge(int current, int incoming, ConstantPool pool) {
/* 103 */     if (current == incoming) {
/* 104 */       return current;
/*     */     }
/* 106 */     int currentTag = getTag(current);
/* 107 */     int incomingTag = getTag(incoming);
/* 108 */     boolean currentIsObject = (currentTag == 7);
/* 109 */     boolean incomingIsObject = (incomingTag == 7);
/*     */     
/* 111 */     if (currentIsObject && incoming == 5)
/* 112 */       return current; 
/* 113 */     if (currentTag == 0 || incomingTag == 0)
/* 114 */       return 0; 
/* 115 */     if (current == 5 && incomingIsObject)
/* 116 */       return incoming; 
/* 117 */     if (currentIsObject && incomingIsObject) {
/* 118 */       String currentName = getPayloadAsType(current, pool);
/* 119 */       String incomingName = getPayloadAsType(incoming, pool);
/*     */ 
/*     */ 
/*     */       
/* 123 */       String currentlyGeneratedName = (String)pool.getConstantData(2);
/* 124 */       String currentlyGeneratedSuperName = (String)pool.getConstantData(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 130 */       if (currentName.equals(currentlyGeneratedName)) {
/* 131 */         currentName = currentlyGeneratedSuperName;
/*     */       }
/* 133 */       if (incomingName.equals(currentlyGeneratedName)) {
/* 134 */         incomingName = currentlyGeneratedSuperName;
/*     */       }
/*     */       
/* 137 */       Class<?> currentClass = getClassFromInternalName(currentName);
/* 138 */       Class<?> incomingClass = getClassFromInternalName(incomingName);
/*     */       
/* 140 */       if (currentClass.isAssignableFrom(incomingClass))
/* 141 */         return current; 
/* 142 */       if (incomingClass.isAssignableFrom(currentClass))
/* 143 */         return incoming; 
/* 144 */       if (incomingClass.isInterface() || currentClass.isInterface())
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 149 */         return OBJECT("java/lang/Object", pool);
/*     */       }
/* 151 */       Class<?> commonClass = incomingClass.getSuperclass();
/* 152 */       while (commonClass != null) {
/* 153 */         if (commonClass.isAssignableFrom(currentClass)) {
/* 154 */           String name = commonClass.getName();
/* 155 */           name = ClassFileWriter.getSlashedForm(name);
/* 156 */           return OBJECT(name, pool);
/*     */         } 
/* 158 */         commonClass = commonClass.getSuperclass();
/*     */       } 
/*     */     } 
/*     */     
/* 162 */     throw new IllegalArgumentException("bad merge attempt between " + 
/*     */         
/* 164 */         toString(current, pool) + " and " + 
/*     */         
/* 166 */         toString(incoming, pool));
/*     */   }
/*     */   
/*     */   static String toString(int type, ConstantPool pool) {
/* 170 */     int tag = getTag(type);
/* 171 */     switch (tag) {
/*     */       case 0:
/* 173 */         return "top";
/*     */       case 1:
/* 175 */         return "int";
/*     */       case 2:
/* 177 */         return "float";
/*     */       case 3:
/* 179 */         return "double";
/*     */       case 4:
/* 181 */         return "long";
/*     */       case 5:
/* 183 */         return "null";
/*     */       case 6:
/* 185 */         return "uninitialized_this";
/*     */     } 
/* 187 */     if (tag == 7)
/* 188 */       return getPayloadAsType(type, pool); 
/* 189 */     if (tag == 8) {
/* 190 */       return "uninitialized";
/*     */     }
/* 192 */     throw new IllegalArgumentException("bad type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> getClassFromInternalName(String internalName) {
/*     */     try {
/* 205 */       return Class.forName(internalName.replace('/', '.'));
/* 206 */     } catch (ClassNotFoundException e) {
/* 207 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String toString(int[] types, int typesTop, ConstantPool pool) {
/* 212 */     StringBuilder sb = new StringBuilder();
/* 213 */     sb.append("[");
/* 214 */     for (int i = 0; i < typesTop; i++) {
/* 215 */       if (i > 0) {
/* 216 */         sb.append(", ");
/*     */       }
/* 218 */       sb.append(toString(types[i], pool));
/*     */     } 
/* 220 */     sb.append("]");
/* 221 */     return sb.toString();
/*     */   }
/*     */   
/*     */   static void print(int[] locals, int[] stack, ConstantPool pool) {
/* 225 */     print(locals, locals.length, stack, stack.length, pool);
/*     */   }
/*     */   
/*     */   static void print(int[] locals, int localsTop, int[] stack, int stackTop, ConstantPool pool) {
/* 229 */     System.out.print("locals: ");
/* 230 */     System.out.println(toString(locals, localsTop, pool));
/* 231 */     System.out.print("stack: ");
/* 232 */     System.out.println(toString(stack, stackTop, pool));
/* 233 */     System.out.println();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\classfile\TypeInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */