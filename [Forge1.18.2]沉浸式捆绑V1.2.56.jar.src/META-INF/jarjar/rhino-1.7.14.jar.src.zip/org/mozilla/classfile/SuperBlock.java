/*     */ package org.mozilla.classfile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SuperBlock
/*     */ {
/*     */   private int index;
/*     */   private int start;
/*     */   private int end;
/*     */   private int[] locals;
/*     */   private int[] stack;
/*     */   private boolean isInitialized;
/*     */   private boolean isInQueue;
/*     */   
/*     */   SuperBlock(int index, int start, int end, int[] initialLocals) {
/*  18 */     this.index = index;
/*  19 */     this.start = start;
/*  20 */     this.end = end;
/*  21 */     this.locals = new int[initialLocals.length];
/*  22 */     System.arraycopy(initialLocals, 0, this.locals, 0, initialLocals.length);
/*  23 */     this.stack = new int[0];
/*  24 */     this.isInitialized = false;
/*  25 */     this.isInQueue = false;
/*     */   }
/*     */   
/*     */   int getIndex() {
/*  29 */     return this.index;
/*     */   }
/*     */   
/*     */   int[] getLocals() {
/*  33 */     int[] copy = new int[this.locals.length];
/*  34 */     System.arraycopy(this.locals, 0, copy, 0, this.locals.length);
/*  35 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int[] getTrimmedLocals() {
/*  48 */     int last = this.locals.length - 1;
/*     */     
/*  50 */     while (last >= 0 && this.locals[last] == 0 && 
/*  51 */       !TypeInfo.isTwoWords(this.locals[last - 1])) {
/*  52 */       last--;
/*     */     }
/*     */ 
/*     */     
/*  56 */     int size = ++last;
/*  57 */     for (int i = 0; i < last; i++) {
/*  58 */       if (TypeInfo.isTwoWords(this.locals[i])) {
/*  59 */         size--;
/*     */       }
/*     */     } 
/*  62 */     int[] copy = new int[size];
/*  63 */     for (int k = 0, j = 0; k < size; k++, j++) {
/*  64 */       copy[k] = this.locals[j];
/*  65 */       if (TypeInfo.isTwoWords(this.locals[j])) {
/*  66 */         j++;
/*     */       }
/*     */     } 
/*  69 */     return copy;
/*     */   }
/*     */   
/*     */   int[] getStack() {
/*  73 */     int[] copy = new int[this.stack.length];
/*  74 */     System.arraycopy(this.stack, 0, copy, 0, this.stack.length);
/*  75 */     return copy;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean merge(int[] locals, int localsTop, int[] stack, int stackTop, ConstantPool pool) {
/*  80 */     if (!this.isInitialized) {
/*  81 */       System.arraycopy(locals, 0, this.locals, 0, localsTop);
/*  82 */       this.stack = new int[stackTop];
/*  83 */       System.arraycopy(stack, 0, this.stack, 0, stackTop);
/*  84 */       this.isInitialized = true;
/*  85 */       return true;
/*  86 */     }  if (this.locals.length == localsTop && this.stack.length == stackTop) {
/*     */       
/*  88 */       boolean localsChanged = mergeState(this.locals, locals, localsTop, pool);
/*     */       
/*  90 */       boolean stackChanged = mergeState(this.stack, stack, stackTop, pool);
/*     */       
/*  92 */       return (localsChanged || stackChanged);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     throw new IllegalArgumentException("bad merge attempt");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean mergeState(int[] current, int[] incoming, int size, ConstantPool pool) {
/* 115 */     boolean changed = false;
/* 116 */     for (int i = 0; i < size; i++) {
/* 117 */       int currentType = current[i];
/*     */       
/* 119 */       current[i] = TypeInfo.merge(current[i], incoming[i], pool);
/* 120 */       if (currentType != current[i]) {
/* 121 */         changed = true;
/*     */       }
/*     */     } 
/* 124 */     return changed;
/*     */   }
/*     */   
/*     */   int getStart() {
/* 128 */     return this.start;
/*     */   }
/*     */   
/*     */   int getEnd() {
/* 132 */     return this.end;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     return "sb " + this.index;
/*     */   }
/*     */   
/*     */   boolean isInitialized() {
/* 141 */     return this.isInitialized;
/*     */   }
/*     */   
/*     */   void setInitialized(boolean b) {
/* 145 */     this.isInitialized = b;
/*     */   }
/*     */   
/*     */   boolean isInQueue() {
/* 149 */     return this.isInQueue;
/*     */   }
/*     */   
/*     */   void setInQueue(boolean b) {
/* 153 */     this.isInQueue = b;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\classfile\SuperBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */