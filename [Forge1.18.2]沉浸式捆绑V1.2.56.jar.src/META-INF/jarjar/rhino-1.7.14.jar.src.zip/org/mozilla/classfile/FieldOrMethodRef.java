/*    */ package org.mozilla.classfile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FieldOrMethodRef
/*    */ {
/*    */   private String className;
/*    */   private String name;
/*    */   private String type;
/*    */   private int hashCode;
/*    */   
/*    */   FieldOrMethodRef(String className, String name, String type) {
/* 58 */     this.hashCode = -1;
/*    */     this.className = className;
/*    */     this.name = name;
/*    */     this.type = type;
/*    */   }
/*    */   
/*    */   public String getClassName() {
/*    */     return this.className;
/*    */   }
/*    */   
/*    */   public String getName() {
/*    */     return this.name;
/*    */   }
/*    */   
/*    */   public String getType() {
/*    */     return this.type;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/*    */     if (!(obj instanceof FieldOrMethodRef))
/*    */       return false; 
/*    */     FieldOrMethodRef x = (FieldOrMethodRef)obj;
/*    */     return (this.className.equals(x.className) && this.name.equals(x.name) && this.type.equals(x.type));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     if (this.hashCode == -1) {
/*    */       int h1 = this.className.hashCode();
/*    */       int h2 = this.name.hashCode();
/*    */       int h3 = this.type.hashCode();
/*    */       this.hashCode = h1 ^ h2 ^ h3;
/*    */     } 
/*    */     return this.hashCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\classfile\FieldOrMethodRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */