package org.mozilla.javascript.debug;

import org.mozilla.javascript.Context;

public interface Debugger {
  void handleCompilationDone(Context paramContext, DebuggableScript paramDebuggableScript, String paramString);
  
  DebugFrame getFrame(Context paramContext, DebuggableScript paramDebuggableScript);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\debug\Debugger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */