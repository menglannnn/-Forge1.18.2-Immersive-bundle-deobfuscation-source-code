package org.mozilla.javascript.debug;

public interface DebuggableScript {
  boolean isTopLevel();
  
  boolean isFunction();
  
  String getFunctionName();
  
  int getParamCount();
  
  int getParamAndVarCount();
  
  String getParamOrVarName(int paramInt);
  
  String getSourceName();
  
  boolean isGeneratedScript();
  
  int[] getLineNumbers();
  
  int getFunctionCount();
  
  DebuggableScript getFunction(int paramInt);
  
  DebuggableScript getParent();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\debug\DebuggableScript.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */