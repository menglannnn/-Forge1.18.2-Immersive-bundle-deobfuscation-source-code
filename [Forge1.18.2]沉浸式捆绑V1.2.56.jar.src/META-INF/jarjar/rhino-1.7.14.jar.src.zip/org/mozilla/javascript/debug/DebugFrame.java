package org.mozilla.javascript.debug;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public interface DebugFrame {
  void onEnter(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject);
  
  void onLineChange(Context paramContext, int paramInt);
  
  void onExceptionThrown(Context paramContext, Throwable paramThrowable);
  
  void onExit(Context paramContext, boolean paramBoolean, Object paramObject);
  
  void onDebuggerStatement(Context paramContext);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\debug\DebugFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */