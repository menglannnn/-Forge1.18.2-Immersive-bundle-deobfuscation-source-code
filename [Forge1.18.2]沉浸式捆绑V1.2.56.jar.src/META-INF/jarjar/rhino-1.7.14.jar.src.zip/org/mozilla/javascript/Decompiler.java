/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Decompiler
/*     */ {
/*     */   public static final int ONLY_BODY_FLAG = 1;
/*     */   public static final int TO_SOURCE_FLAG = 2;
/*     */   public static final int INITIAL_INDENT_PROP = 1;
/*     */   public static final int INDENT_GAP_PROP = 2;
/*     */   public static final int CASE_GAP_PROP = 3;
/*     */   private static final int FUNCTION_END = 174;
/*     */   
/*     */   String getEncodedSource() {
/*  60 */     return sourceToString(0);
/*     */   }
/*     */   
/*     */   int getCurrentOffset() {
/*  64 */     return this.sourceTop;
/*     */   }
/*     */   
/*     */   int markFunctionStart(int functionType) {
/*  68 */     int savedOffset = getCurrentOffset();
/*  69 */     if (functionType != 4) {
/*  70 */       addToken(113);
/*  71 */       append((char)functionType);
/*     */     } 
/*  73 */     return savedOffset;
/*     */   }
/*     */   
/*     */   int markFunctionEnd(int functionStart) {
/*  77 */     int offset = getCurrentOffset();
/*  78 */     append('®');
/*  79 */     return offset;
/*     */   }
/*     */   
/*     */   void addToken(int token) {
/*  83 */     if (0 > token || token > 173) throw new IllegalArgumentException();
/*     */     
/*  85 */     append((char)token);
/*     */   }
/*     */   
/*     */   void addEOL(int token) {
/*  89 */     if (0 > token || token > 173) throw new IllegalArgumentException();
/*     */     
/*  91 */     append((char)token);
/*  92 */     append('\001');
/*     */   }
/*     */   
/*     */   void addName(String str) {
/*  96 */     addToken(39);
/*  97 */     appendString(str);
/*     */   }
/*     */   
/*     */   void addString(String str) {
/* 101 */     addToken(41);
/* 102 */     appendString(str);
/*     */   }
/*     */   
/*     */   void addTemplateLiteral(String str) {
/* 106 */     addToken(171);
/* 107 */     appendString(str);
/*     */   }
/*     */   
/*     */   void addRegexp(String regexp, String flags) {
/* 111 */     addToken(48);
/* 112 */     appendString('/' + regexp + '/' + flags);
/*     */   }
/*     */   
/*     */   void addNumber(double n) {
/* 116 */     addToken(40);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     long lbits = (long)n;
/* 136 */     if (lbits != n) {
/*     */ 
/*     */       
/* 139 */       lbits = Double.doubleToLongBits(n);
/* 140 */       append('D');
/* 141 */       append((char)(int)(lbits >> 48L));
/* 142 */       append((char)(int)(lbits >> 32L));
/* 143 */       append((char)(int)(lbits >> 16L));
/* 144 */       append((char)(int)lbits);
/*     */     }
/*     */     else {
/*     */       
/* 148 */       if (lbits < 0L) Kit.codeBug();
/*     */ 
/*     */ 
/*     */       
/* 152 */       if (lbits <= 65535L) {
/* 153 */         append('S');
/* 154 */         append((char)(int)lbits);
/*     */       } else {
/* 156 */         append('J');
/* 157 */         append((char)(int)(lbits >> 48L));
/* 158 */         append((char)(int)(lbits >> 32L));
/* 159 */         append((char)(int)(lbits >> 16L));
/* 160 */         append((char)(int)lbits);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void addBigInt(BigInteger n) {
/* 166 */     addToken(83);
/* 167 */     appendString(n.toString());
/*     */   }
/*     */   
/*     */   private void appendString(String str) {
/* 171 */     int L = str.length();
/* 172 */     int lengthEncodingSize = 1;
/* 173 */     if (L >= 32768) {
/* 174 */       lengthEncodingSize = 2;
/*     */     }
/* 176 */     int nextTop = this.sourceTop + lengthEncodingSize + L;
/* 177 */     if (nextTop > this.sourceBuffer.length) {
/* 178 */       increaseSourceCapacity(nextTop);
/*     */     }
/* 180 */     if (L >= 32768) {
/*     */ 
/*     */       
/* 183 */       this.sourceBuffer[this.sourceTop] = (char)(0x8000 | L >>> 16);
/* 184 */       this.sourceTop++;
/*     */     } 
/* 186 */     this.sourceBuffer[this.sourceTop] = (char)L;
/* 187 */     this.sourceTop++;
/* 188 */     str.getChars(0, L, this.sourceBuffer, this.sourceTop);
/* 189 */     this.sourceTop = nextTop;
/*     */   }
/*     */   
/*     */   private void append(char c) {
/* 193 */     if (this.sourceTop == this.sourceBuffer.length) {
/* 194 */       increaseSourceCapacity(this.sourceTop + 1);
/*     */     }
/* 196 */     this.sourceBuffer[this.sourceTop] = c;
/* 197 */     this.sourceTop++;
/*     */   }
/*     */ 
/*     */   
/*     */   private void increaseSourceCapacity(int minimalCapacity) {
/* 202 */     if (minimalCapacity <= this.sourceBuffer.length) Kit.codeBug(); 
/* 203 */     int newCapacity = this.sourceBuffer.length * 2;
/* 204 */     if (newCapacity < minimalCapacity) {
/* 205 */       newCapacity = minimalCapacity;
/*     */     }
/* 207 */     char[] tmp = new char[newCapacity];
/* 208 */     System.arraycopy(this.sourceBuffer, 0, tmp, 0, this.sourceTop);
/* 209 */     this.sourceBuffer = tmp;
/*     */   }
/*     */   
/*     */   private String sourceToString(int offset) {
/* 213 */     if (offset < 0 || this.sourceTop < offset) Kit.codeBug(); 
/* 214 */     return new String(this.sourceBuffer, offset, this.sourceTop - offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decompile(String source, int flags, UintMap properties) {
/* 229 */     int topFunctionType, length = source.length();
/* 230 */     if (length == 0) {
/* 231 */       return "";
/*     */     }
/*     */     
/* 234 */     int indent = properties.getInt(1, 0);
/* 235 */     if (indent < 0) throw new IllegalArgumentException(); 
/* 236 */     int indentGap = properties.getInt(2, 4);
/* 237 */     if (indentGap < 0) throw new IllegalArgumentException(); 
/* 238 */     int caseGap = properties.getInt(3, 2);
/* 239 */     if (caseGap < 0) throw new IllegalArgumentException();
/*     */     
/* 241 */     StringBuilder result = new StringBuilder();
/* 242 */     boolean justFunctionBody = (0 != (flags & 0x1));
/* 243 */     boolean toSource = (0 != (flags & 0x2));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 271 */     int braceNesting = 0;
/* 272 */     boolean afterFirstEOL = false;
/* 273 */     int i = 0;
/*     */     
/* 275 */     if (source.charAt(i) == '') {
/* 276 */       i++;
/* 277 */       topFunctionType = -1;
/*     */     } else {
/* 279 */       topFunctionType = source.charAt(i + 1);
/*     */     } 
/*     */     
/* 282 */     if (!toSource) {
/*     */       
/* 284 */       result.append('\n');
/* 285 */       for (int j = 0; j < indent; ) { result.append(' '); j++; }
/*     */     
/* 287 */     } else if (topFunctionType == 2) {
/* 288 */       result.append('(');
/*     */     } 
/*     */ 
/*     */     
/* 292 */     while (i < length) {
/* 293 */       boolean newLine; switch (source.charAt(i)) {
/*     */         case '':
/*     */         case '':
/*     */         case '§':
/* 297 */           if (source.charAt(i) == '') {
/* 298 */             result.append("get ");
/* 299 */           } else if (source.charAt(i) == '') {
/* 300 */             result.append("set ");
/*     */           } 
/* 302 */           i++;
/* 303 */           i = printSourceString(source, i + 1, false, result);
/*     */           
/* 305 */           i++;
/*     */           break;
/*     */         
/*     */         case '\'':
/*     */         case '0':
/* 310 */           i = printSourceString(source, i + 1, false, result);
/*     */           continue;
/*     */         
/*     */         case ')':
/* 314 */           i = printSourceString(source, i + 1, true, result);
/*     */           continue;
/*     */         
/*     */         case '(':
/* 318 */           i = printSourceNumber(source, i + 1, result);
/*     */           continue;
/*     */         
/*     */         case 'S':
/* 322 */           i = printSourceBigInt(source, i + 1, result);
/*     */           continue;
/*     */         
/*     */         case '-':
/* 326 */           result.append("true");
/*     */           break;
/*     */         
/*     */         case ',':
/* 330 */           result.append("false");
/*     */           break;
/*     */         
/*     */         case '*':
/* 334 */           result.append("null");
/*     */           break;
/*     */         
/*     */         case '+':
/* 338 */           result.append("this");
/*     */           break;
/*     */         
/*     */         case 'q':
/* 342 */           i++;
/* 343 */           result.append("function ");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '®':
/*     */           break;
/*     */         
/*     */         case '\\':
/* 351 */           result.append(", ");
/*     */           break;
/*     */         
/*     */         case 'X':
/* 355 */           braceNesting++;
/* 356 */           if (1 == getNext(source, length, i)) indent += indentGap; 
/* 357 */           result.append('{');
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'Y':
/* 362 */           braceNesting--;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 367 */           if (justFunctionBody && braceNesting == 0)
/*     */             break; 
/* 369 */           result.append('}');
/* 370 */           switch (getNext(source, length, i)) {
/*     */             case 1:
/*     */             case 174:
/* 373 */               indent -= indentGap;
/*     */               break;
/*     */             case 117:
/*     */             case 121:
/* 377 */               indent -= indentGap;
/* 378 */               result.append(' ');
/*     */               break;
/*     */           } 
/*     */           
/*     */           break;
/*     */         case 'Z':
/* 384 */           result.append('(');
/*     */           break;
/*     */         
/*     */         case '[':
/* 388 */           result.append(')');
/* 389 */           if (88 == getNext(source, length, i)) result.append(' ');
/*     */           
/*     */           break;
/*     */         case 'V':
/* 393 */           result.append('[');
/*     */           break;
/*     */         
/*     */         case 'W':
/* 397 */           result.append(']');
/*     */           break;
/*     */ 
/*     */         
/*     */         case '\001':
/* 402 */           if (toSource)
/* 403 */             break;  newLine = true;
/* 404 */           if (!afterFirstEOL) {
/* 405 */             afterFirstEOL = true;
/* 406 */             if (justFunctionBody) {
/*     */ 
/*     */ 
/*     */               
/* 410 */               result.setLength(0);
/* 411 */               indent -= indentGap;
/* 412 */               newLine = false;
/*     */             } 
/*     */           } 
/* 415 */           if (newLine) {
/* 416 */             result.append('\n');
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 423 */           if (i + 1 < length) {
/* 424 */             int less = 0;
/* 425 */             int nextToken = source.charAt(i + 1);
/* 426 */             if (nextToken == 119 || nextToken == 120) {
/* 427 */               less = indentGap - caseGap;
/* 428 */             } else if (nextToken == 89) {
/* 429 */               less = indentGap;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 435 */             else if (nextToken == 39) {
/* 436 */               int afterName = getSourceStringEnd(source, i + 2);
/* 437 */               if (source.charAt(afterName) == 'k') less = indentGap;
/*     */             
/*     */             } 
/* 440 */             while (less < indent) { result.append(' '); less++; }
/*     */           
/*     */           } 
/*     */           break;
/*     */         case 'p':
/* 445 */           result.append('.');
/*     */           break;
/*     */         
/*     */         case '\036':
/* 449 */           result.append("new ");
/*     */           break;
/*     */         
/*     */         case '\037':
/* 453 */           result.append("delete ");
/*     */           break;
/*     */         
/*     */         case 't':
/* 457 */           result.append("if ");
/*     */           break;
/*     */         
/*     */         case 'u':
/* 461 */           result.append("else ");
/*     */           break;
/*     */         
/*     */         case '{':
/* 465 */           result.append("for ");
/*     */           break;
/*     */         
/*     */         case '4':
/* 469 */           result.append(" in ");
/*     */           break;
/*     */         
/*     */         case '':
/* 473 */           result.append("with ");
/*     */           break;
/*     */         
/*     */         case 'y':
/* 477 */           result.append("while ");
/*     */           break;
/*     */         
/*     */         case 'z':
/* 481 */           result.append("do ");
/*     */           break;
/*     */         
/*     */         case 'T':
/* 485 */           result.append("try ");
/*     */           break;
/*     */         
/*     */         case '':
/* 489 */           result.append("catch ");
/*     */           break;
/*     */         
/*     */         case '':
/* 493 */           result.append("finally ");
/*     */           break;
/*     */         
/*     */         case '2':
/* 497 */           result.append("throw ");
/*     */           break;
/*     */         
/*     */         case 'v':
/* 501 */           result.append("switch ");
/*     */           break;
/*     */         
/*     */         case '|':
/* 505 */           result.append("break");
/* 506 */           if (39 == getNext(source, length, i)) result.append(' ');
/*     */           
/*     */           break;
/*     */         case '}':
/* 510 */           result.append("continue");
/* 511 */           if (39 == getNext(source, length, i)) result.append(' ');
/*     */           
/*     */           break;
/*     */         case 'w':
/* 515 */           result.append("case ");
/*     */           break;
/*     */         
/*     */         case 'x':
/* 519 */           result.append("default");
/*     */           break;
/*     */         
/*     */         case '\004':
/* 523 */           result.append("return");
/* 524 */           if (85 != getNext(source, length, i)) result.append(' ');
/*     */           
/*     */           break;
/*     */         case '~':
/* 528 */           result.append("var ");
/*     */           break;
/*     */         
/*     */         case '':
/* 532 */           result.append("let ");
/*     */           break;
/*     */         
/*     */         case 'U':
/* 536 */           result.append(';');
/* 537 */           if (1 != getNext(source, length, i))
/*     */           {
/* 539 */             result.append(' ');
/*     */           }
/*     */           break;
/*     */         
/*     */         case ']':
/* 544 */           result.append(" = ");
/*     */           break;
/*     */         
/*     */         case 'd':
/* 548 */           result.append(" += ");
/*     */           break;
/*     */         
/*     */         case 'e':
/* 552 */           result.append(" -= ");
/*     */           break;
/*     */         
/*     */         case 'f':
/* 556 */           result.append(" *= ");
/*     */           break;
/*     */         
/*     */         case 'g':
/* 560 */           result.append(" /= ");
/*     */           break;
/*     */         
/*     */         case 'h':
/* 564 */           result.append(" %= ");
/*     */           break;
/*     */         
/*     */         case '^':
/* 568 */           result.append(" |= ");
/*     */           break;
/*     */         
/*     */         case '_':
/* 572 */           result.append(" ^= ");
/*     */           break;
/*     */         
/*     */         case '`':
/* 576 */           result.append(" &= ");
/*     */           break;
/*     */         
/*     */         case 'a':
/* 580 */           result.append(" <<= ");
/*     */           break;
/*     */         
/*     */         case 'b':
/* 584 */           result.append(" >>= ");
/*     */           break;
/*     */         
/*     */         case 'c':
/* 588 */           result.append(" >>>= ");
/*     */           break;
/*     */         
/*     */         case 'j':
/* 592 */           result.append(" ? ");
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 'C':
/* 601 */           result.append(": ");
/*     */           break;
/*     */         
/*     */         case 'k':
/* 605 */           if (1 == getNext(source, length, i)) {
/*     */             
/* 607 */             result.append(':');
/*     */             break;
/*     */           } 
/* 610 */           result.append(" : ");
/*     */           break;
/*     */         
/*     */         case 'l':
/* 614 */           result.append(" || ");
/*     */           break;
/*     */         
/*     */         case 'm':
/* 618 */           result.append(" && ");
/*     */           break;
/*     */         
/*     */         case '\t':
/* 622 */           result.append(" | ");
/*     */           break;
/*     */         
/*     */         case '\n':
/* 626 */           result.append(" ^ ");
/*     */           break;
/*     */         
/*     */         case '\013':
/* 630 */           result.append(" & ");
/*     */           break;
/*     */         
/*     */         case '.':
/* 634 */           result.append(" === ");
/*     */           break;
/*     */         
/*     */         case '/':
/* 638 */           result.append(" !== ");
/*     */           break;
/*     */         
/*     */         case '\f':
/* 642 */           result.append(" == ");
/*     */           break;
/*     */         
/*     */         case '\r':
/* 646 */           result.append(" != ");
/*     */           break;
/*     */         
/*     */         case '\017':
/* 650 */           result.append(" <= ");
/*     */           break;
/*     */         
/*     */         case '\016':
/* 654 */           result.append(" < ");
/*     */           break;
/*     */         
/*     */         case '\021':
/* 658 */           result.append(" >= ");
/*     */           break;
/*     */         
/*     */         case '\020':
/* 662 */           result.append(" > ");
/*     */           break;
/*     */         
/*     */         case '5':
/* 666 */           result.append(" instanceof ");
/*     */           break;
/*     */         
/*     */         case '\022':
/* 670 */           result.append(" << ");
/*     */           break;
/*     */         
/*     */         case '\023':
/* 674 */           result.append(" >> ");
/*     */           break;
/*     */         
/*     */         case '\024':
/* 678 */           result.append(" >>> ");
/*     */           break;
/*     */         
/*     */         case ' ':
/* 682 */           result.append("typeof ");
/*     */           break;
/*     */         
/*     */         case '':
/* 686 */           result.append("void ");
/*     */           break;
/*     */         
/*     */         case '':
/* 690 */           result.append("const ");
/*     */           break;
/*     */         
/*     */         case 'I':
/* 694 */           result.append("yield ");
/*     */           break;
/*     */         
/*     */         case '©':
/* 698 */           result.append("yield *");
/*     */           break;
/*     */         
/*     */         case '\032':
/* 702 */           result.append('!');
/*     */           break;
/*     */         
/*     */         case '\033':
/* 706 */           result.append('~');
/*     */           break;
/*     */         
/*     */         case '\034':
/* 710 */           result.append('+');
/*     */           break;
/*     */         
/*     */         case '\035':
/* 714 */           result.append('-');
/*     */           break;
/*     */         
/*     */         case 'n':
/* 718 */           result.append("++");
/*     */           break;
/*     */         
/*     */         case 'o':
/* 722 */           result.append("--");
/*     */           break;
/*     */         
/*     */         case '\025':
/* 726 */           result.append(" + ");
/*     */           break;
/*     */         
/*     */         case '\026':
/* 730 */           result.append(" - ");
/*     */           break;
/*     */         
/*     */         case '\027':
/* 734 */           result.append(" * ");
/*     */           break;
/*     */         
/*     */         case '\030':
/* 738 */           result.append(" / ");
/*     */           break;
/*     */         
/*     */         case '\031':
/* 742 */           result.append(" % ");
/*     */           break;
/*     */         
/*     */         case 'K':
/* 746 */           result.append(" ** ");
/*     */           break;
/*     */         
/*     */         case '':
/* 750 */           result.append("::");
/*     */           break;
/*     */         
/*     */         case '':
/* 754 */           result.append("..");
/*     */           break;
/*     */         
/*     */         case '':
/* 758 */           result.append(".(");
/*     */           break;
/*     */         
/*     */         case '':
/* 762 */           result.append('@');
/*     */           break;
/*     */         
/*     */         case '¤':
/* 766 */           result.append("debugger;\n");
/*     */           break;
/*     */         
/*     */         case '¨':
/* 770 */           result.append(" => ");
/*     */           break;
/*     */         
/*     */         case 'ª':
/* 774 */           result.append("`");
/*     */           break;
/*     */         
/*     */         case '¬':
/* 778 */           result.append("${");
/*     */           break;
/*     */         
/*     */         case '«':
/* 782 */           i = printSourceString(source, i + 1, false, result);
/*     */           continue;
/*     */ 
/*     */         
/*     */         default:
/* 787 */           throw new RuntimeException("Token: " + Token.name(source.charAt(i)));
/*     */       } 
/* 789 */       i++;
/*     */     } 
/*     */     
/* 792 */     if (!toSource) {
/*     */       
/* 794 */       if (!justFunctionBody) result.append('\n');
/*     */     
/* 796 */     } else if (topFunctionType == 2) {
/* 797 */       result.append(')');
/*     */     } 
/*     */ 
/*     */     
/* 801 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static int getNext(String source, int length, int i) {
/* 805 */     return (i + 1 < length) ? source.charAt(i + 1) : 0;
/*     */   }
/*     */   
/*     */   private static int getSourceStringEnd(String source, int offset) {
/* 809 */     return printSourceString(source, offset, false, null);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int printSourceString(String source, int offset, boolean asQuotedString, StringBuilder sb) {
/* 814 */     int length = source.charAt(offset);
/* 815 */     offset++;
/* 816 */     if ((0x8000 & length) != 0) {
/* 817 */       length = (0x7FFF & length) << 16 | source.charAt(offset);
/* 818 */       offset++;
/*     */     } 
/* 820 */     if (sb != null) {
/* 821 */       String str = source.substring(offset, offset + length);
/* 822 */       if (!asQuotedString) {
/* 823 */         sb.append(str);
/*     */       } else {
/* 825 */         sb.append('"');
/* 826 */         sb.append(ScriptRuntime.escapeString(str));
/* 827 */         sb.append('"');
/*     */       } 
/*     */     } 
/* 830 */     return offset + length;
/*     */   }
/*     */   
/*     */   private static int printSourceNumber(String source, int offset, StringBuilder sb) {
/* 834 */     double number = 0.0D;
/* 835 */     char type = source.charAt(offset);
/* 836 */     offset++;
/* 837 */     if (type == 'S') {
/* 838 */       if (sb != null) {
/* 839 */         int ival = source.charAt(offset);
/* 840 */         number = ival;
/*     */       } 
/* 842 */       offset++;
/* 843 */     } else if (type == 'J' || type == 'D') {
/* 844 */       if (sb != null) {
/*     */         
/* 846 */         long lbits = source.charAt(offset) << 48L;
/* 847 */         lbits |= source.charAt(offset + 1) << 32L;
/* 848 */         lbits |= source.charAt(offset + 2) << 16L;
/* 849 */         lbits |= source.charAt(offset + 3);
/* 850 */         if (type == 'J') {
/* 851 */           number = lbits;
/*     */         } else {
/* 853 */           number = Double.longBitsToDouble(lbits);
/*     */         } 
/*     */       } 
/* 856 */       offset += 4;
/*     */     } else {
/*     */       
/* 859 */       throw new RuntimeException();
/*     */     } 
/* 861 */     if (sb != null) {
/* 862 */       sb.append(ScriptRuntime.numberToString(number, 10));
/*     */     }
/* 864 */     return offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int printSourceBigInt(String source, int offset, StringBuilder sb) {
/* 871 */     int length = source.charAt(offset);
/* 872 */     offset++;
/* 873 */     if ((0x8000 & length) != 0) {
/* 874 */       length = (0x7FFF & length) << 16 | source.charAt(offset);
/* 875 */       offset++;
/*     */     } 
/* 877 */     if (sb != null) {
/* 878 */       String str = source.substring(offset, offset + length);
/* 879 */       sb.append(str);
/* 880 */       sb.append('n');
/*     */     } 
/* 882 */     return offset + length;
/*     */   }
/*     */   
/* 885 */   private char[] sourceBuffer = new char[128];
/*     */   private int sourceTop;
/*     */   private static final boolean printSource = false;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Decompiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */