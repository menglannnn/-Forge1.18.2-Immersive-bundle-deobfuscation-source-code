/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.function.Function;
/*     */ import org.mozilla.javascript.debug.DebuggableObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EqualObjectGraphs
/*     */ {
/*  42 */   private static final ThreadLocal<EqualObjectGraphs> instance = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */   
/*  46 */   private final Map<Object, Object> knownEquals = new IdentityHashMap<>();
/*     */   
/*  48 */   private final Map<Object, Object> currentlyCompared = new IdentityHashMap<>();
/*     */   
/*     */   static <T> T withThreadLocal(Function<EqualObjectGraphs, T> action) {
/*  51 */     EqualObjectGraphs currEq = instance.get();
/*  52 */     if (currEq == null) {
/*  53 */       EqualObjectGraphs eq = new EqualObjectGraphs();
/*  54 */       instance.set(eq);
/*     */       try {
/*  56 */         return action.apply(eq);
/*     */       } finally {
/*  58 */         instance.set(null);
/*     */       } 
/*     */     } 
/*  61 */     return action.apply(currEq);
/*     */   }
/*     */   
/*     */   boolean equalGraphs(Object o1, Object o2) {
/*  65 */     if (o1 == o2)
/*  66 */       return true; 
/*  67 */     if (o1 == null || o2 == null) {
/*  68 */       return false;
/*     */     }
/*     */     
/*  71 */     Object curr2 = this.currentlyCompared.get(o1);
/*  72 */     if (curr2 == o2)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  81 */       return true; } 
/*  82 */     if (curr2 != null)
/*     */     {
/*     */       
/*  85 */       return false;
/*     */     }
/*     */     
/*  88 */     Object prev2 = this.knownEquals.get(o1);
/*  89 */     if (prev2 == o2)
/*     */     {
/*  91 */       return true; } 
/*  92 */     if (prev2 != null)
/*     */     {
/*  94 */       return false;
/*     */     }
/*     */     
/*  97 */     Object prev1 = this.knownEquals.get(o2);
/*  98 */     assert prev1 != o1;
/*  99 */     if (prev1 != null)
/*     */     {
/* 101 */       return false;
/*     */     }
/*     */     
/* 104 */     this.currentlyCompared.put(o1, o2);
/* 105 */     boolean eq = equalGraphsNoMemo(o1, o2);
/* 106 */     if (eq) {
/* 107 */       this.knownEquals.put(o1, o2);
/* 108 */       this.knownEquals.put(o2, o1);
/*     */     } 
/* 110 */     this.currentlyCompared.remove(o1);
/* 111 */     return eq;
/*     */   }
/*     */   
/*     */   private boolean equalGraphsNoMemo(Object o1, Object o2) {
/* 115 */     if (o1 instanceof Wrapper)
/* 116 */       return (o2 instanceof Wrapper && equalGraphs(((Wrapper)o1).unwrap(), ((Wrapper)o2).unwrap())); 
/* 117 */     if (o1 instanceof Scriptable)
/* 118 */       return (o2 instanceof Scriptable && equalScriptables((Scriptable)o1, (Scriptable)o2)); 
/* 119 */     if (o1 instanceof ConsString)
/* 120 */       return ((ConsString)o1).toString().equals(o2); 
/* 121 */     if (o2 instanceof ConsString)
/* 122 */       return o1.equals(((ConsString)o2).toString()); 
/* 123 */     if (o1 instanceof SymbolKey)
/* 124 */       return (o2 instanceof SymbolKey && equalGraphs(((SymbolKey)o1).getName(), ((SymbolKey)o2).getName())); 
/* 125 */     if (o1 instanceof Object[])
/* 126 */       return (o2 instanceof Object[] && equalObjectArrays((Object[])o1, (Object[])o2)); 
/* 127 */     if (o1.getClass().isArray())
/* 128 */       return Objects.deepEquals(o1, o2); 
/* 129 */     if (o1 instanceof List)
/* 130 */       return (o2 instanceof List && equalLists((List)o1, (List)o2)); 
/* 131 */     if (o1 instanceof Map)
/* 132 */       return (o2 instanceof Map && equalMaps((Map<?, ?>)o1, (Map<?, ?>)o2)); 
/* 133 */     if (o1 instanceof Set)
/* 134 */       return (o2 instanceof Set && equalSets((Set)o1, (Set)o2)); 
/* 135 */     if (o1 instanceof NativeGlobal)
/* 136 */       return o2 instanceof NativeGlobal; 
/* 137 */     if (o1 instanceof JavaAdapter)
/* 138 */       return o2 instanceof JavaAdapter; 
/* 139 */     if (o1 instanceof NativeJavaTopPackage) {
/* 140 */       return o2 instanceof NativeJavaTopPackage;
/*     */     }
/*     */ 
/*     */     
/* 144 */     return o1.equals(o2);
/*     */   }
/*     */   
/*     */   private boolean equalScriptables(Scriptable s1, Scriptable s2) {
/* 148 */     Object[] ids1 = getSortedIds(s1);
/* 149 */     Object[] ids2 = getSortedIds(s2);
/* 150 */     if (!equalObjectArrays(ids1, ids2)) {
/* 151 */       return false;
/*     */     }
/* 153 */     int l = ids1.length;
/* 154 */     for (int i = 0; i < l; i++) {
/* 155 */       if (!equalGraphs(getValue(s1, ids1[i]), getValue(s2, ids2[i]))) {
/* 156 */         return false;
/*     */       }
/*     */     } 
/* 159 */     if (!equalGraphs(s1.getPrototype(), s2.getPrototype()))
/* 160 */       return false; 
/* 161 */     if (!equalGraphs(s1.getParentScope(), s2.getParentScope())) {
/* 162 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 166 */     if (s1 instanceof NativeContinuation)
/* 167 */       return (s2 instanceof NativeContinuation && NativeContinuation.equalImplementations((NativeContinuation)s1, (NativeContinuation)s2)); 
/* 168 */     if (s1 instanceof NativeJavaPackage)
/* 169 */       return s1.equals(s2); 
/* 170 */     if (s1 instanceof IdFunctionObject)
/* 171 */       return (s2 instanceof IdFunctionObject && IdFunctionObject.equalObjectGraphs((IdFunctionObject)s1, (IdFunctionObject)s2, this)); 
/* 172 */     if (s1 instanceof InterpretedFunction)
/* 173 */       return (s2 instanceof InterpretedFunction && equalInterpretedFunctions((InterpretedFunction)s1, (InterpretedFunction)s2)); 
/* 174 */     if (s1 instanceof ArrowFunction)
/* 175 */       return (s2 instanceof ArrowFunction && ArrowFunction.equalObjectGraphs((ArrowFunction)s1, (ArrowFunction)s2, this)); 
/* 176 */     if (s1 instanceof BoundFunction)
/* 177 */       return (s2 instanceof BoundFunction && BoundFunction.equalObjectGraphs((BoundFunction)s1, (BoundFunction)s2, this)); 
/* 178 */     if (s1 instanceof NativeSymbol) {
/* 179 */       return (s2 instanceof NativeSymbol && equalGraphs(((NativeSymbol)s1).getKey(), ((NativeSymbol)s2).getKey()));
/*     */     }
/* 181 */     return true;
/*     */   }
/*     */   
/*     */   private boolean equalObjectArrays(Object[] a1, Object[] a2) {
/* 185 */     if (a1.length != a2.length) {
/* 186 */       return false;
/*     */     }
/* 188 */     for (int i = 0; i < a1.length; i++) {
/* 189 */       if (!equalGraphs(a1[i], a2[i])) {
/* 190 */         return false;
/*     */       }
/*     */     } 
/* 193 */     return true;
/*     */   }
/*     */   
/*     */   private boolean equalLists(List<?> l1, List<?> l2) {
/* 197 */     if (l1.size() != l2.size()) {
/* 198 */       return false;
/*     */     }
/* 200 */     Iterator<?> i1 = l1.iterator();
/* 201 */     Iterator<?> i2 = l2.iterator();
/* 202 */     while (i1.hasNext() && i2.hasNext()) {
/* 203 */       if (!equalGraphs(i1.next(), i2.next())) {
/* 204 */         return false;
/*     */       }
/*     */     } 
/* 207 */     assert !i1.hasNext() && !i2.hasNext();
/* 208 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean equalMaps(Map<?, ?> m1, Map<?, ?> m2) {
/* 213 */     if (m1.size() != m2.size()) {
/* 214 */       return false;
/*     */     }
/* 216 */     Iterator<Map.Entry> i1 = sortedEntries(m1);
/* 217 */     Iterator<Map.Entry> i2 = sortedEntries(m2);
/*     */     
/* 219 */     while (i1.hasNext() && i2.hasNext()) {
/* 220 */       Map.Entry kv1 = i1.next();
/* 221 */       Map.Entry kv2 = i2.next();
/* 222 */       if (!equalGraphs(kv1.getKey(), kv2.getKey()) || !equalGraphs(kv1.getValue(), kv2.getValue())) {
/* 223 */         return false;
/*     */       }
/*     */     } 
/* 226 */     assert !i1.hasNext() && !i2.hasNext();
/*     */     
/* 228 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Iterator<Map.Entry> sortedEntries(Map<?, ?> m) {
/* 236 */     Map sortedMap = (m instanceof java.util.SortedMap) ? m : new TreeMap<>(m);
/* 237 */     return sortedMap.entrySet().iterator();
/*     */   }
/*     */   
/*     */   private boolean equalSets(Set<?> s1, Set<?> s2) {
/* 241 */     return equalObjectArrays(sortedSet(s1), sortedSet(s2));
/*     */   }
/*     */   
/*     */   private static Object[] sortedSet(Set<?> s) {
/* 245 */     Object[] a = s.toArray();
/* 246 */     Arrays.sort(a);
/* 247 */     return a;
/*     */   }
/*     */   
/*     */   private static boolean equalInterpretedFunctions(InterpretedFunction f1, InterpretedFunction f2) {
/* 251 */     return Objects.equals(f1.getEncodedSource(), f2.getEncodedSource());
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object[] getSortedIds(Scriptable s) {
/* 256 */     Object[] ids = getIds(s);
/* 257 */     Arrays.sort(ids, (a, b) -> {
/*     */           if (a instanceof Integer) {
/*     */             if (b instanceof Integer) {
/*     */               return ((Integer)a).compareTo((Integer)b);
/*     */             }
/*     */             if (b instanceof String || b instanceof Symbol) {
/*     */               return -1;
/*     */             }
/*     */           } else if (a instanceof String) {
/*     */             if (b instanceof String) {
/*     */               return ((String)a).compareTo((String)b);
/*     */             }
/*     */             if (b instanceof Integer) {
/*     */               return 1;
/*     */             }
/*     */             if (b instanceof Symbol) {
/*     */               return -1;
/*     */             }
/*     */           } else if (a instanceof Symbol) {
/*     */             if (b instanceof Symbol) {
/*     */               return getSymbolName((Symbol)a).compareTo(getSymbolName((Symbol)b));
/*     */             }
/*     */             if (b instanceof Integer || b instanceof String) {
/*     */               return 1;
/*     */             }
/*     */           } 
/*     */           throw new ClassCastException();
/*     */         });
/* 285 */     return ids;
/*     */   }
/*     */   
/*     */   private static String getSymbolName(Symbol s) {
/* 289 */     if (s instanceof SymbolKey)
/* 290 */       return ((SymbolKey)s).getName(); 
/* 291 */     if (s instanceof NativeSymbol) {
/* 292 */       return ((NativeSymbol)s).getKey().getName();
/*     */     }
/*     */     
/* 295 */     throw new ClassCastException();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object[] getIds(Scriptable s) {
/* 300 */     if (s instanceof ScriptableObject)
/*     */     {
/* 302 */       return ((ScriptableObject)s).getIds(true, true); } 
/* 303 */     if (s instanceof DebuggableObject) {
/* 304 */       return ((DebuggableObject)s).getAllIds();
/*     */     }
/* 306 */     return s.getIds();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object getValue(Scriptable s, Object id) {
/* 311 */     if (id instanceof Symbol)
/* 312 */       return ScriptableObject.getProperty(s, (Symbol)id); 
/* 313 */     if (id instanceof Integer)
/* 314 */       return ScriptableObject.getProperty(s, ((Integer)id).intValue()); 
/* 315 */     if (id instanceof String) {
/* 316 */       return ScriptableObject.getProperty(s, (String)id);
/*     */     }
/* 318 */     throw new ClassCastException();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\EqualObjectGraphs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */