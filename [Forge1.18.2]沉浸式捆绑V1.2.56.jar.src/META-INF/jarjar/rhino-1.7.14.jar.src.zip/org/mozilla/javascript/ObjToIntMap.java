/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjToIntMap
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -1542220580748809402L;
/*     */   private static final int A = -1640531527;
/*     */   
/*     */   public static class Iterator
/*     */   {
/*     */     ObjToIntMap master;
/*     */     private int cursor;
/*     */     private int remaining;
/*     */     private Object[] keys;
/*     */     private int[] values;
/*     */     
/*     */     Iterator(ObjToIntMap master) {
/*  33 */       this.master = master;
/*     */     }
/*     */     
/*     */     final void init(Object[] keys, int[] values, int keyCount) {
/*  37 */       this.keys = keys;
/*  38 */       this.values = values;
/*  39 */       this.cursor = -1;
/*  40 */       this.remaining = keyCount;
/*     */     }
/*     */     
/*     */     public void start() {
/*  44 */       this.master.initIterator(this);
/*  45 */       next();
/*     */     }
/*     */     
/*     */     public boolean done() {
/*  49 */       return (this.remaining < 0);
/*     */     }
/*     */     
/*     */     public void next() {
/*  53 */       if (this.remaining == -1) Kit.codeBug(); 
/*  54 */       if (this.remaining == 0) {
/*  55 */         this.remaining = -1;
/*  56 */         this.cursor = -1;
/*     */       } else {
/*  58 */         this.cursor++; for (;; this.cursor++) {
/*  59 */           Object key = this.keys[this.cursor];
/*  60 */           if (key != null && key != ObjToIntMap.DELETED) {
/*  61 */             this.remaining--;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public Object getKey() {
/*  69 */       Object key = this.keys[this.cursor];
/*  70 */       if (key == UniqueTag.NULL_VALUE) {
/*  71 */         key = null;
/*     */       }
/*  73 */       return key;
/*     */     }
/*     */     
/*     */     public int getValue() {
/*  77 */       return this.values[this.cursor];
/*     */     }
/*     */     
/*     */     public void setValue(int value) {
/*  81 */       this.values[this.cursor] = value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjToIntMap() {
/*  92 */     this(4);
/*     */   }
/*     */   
/*     */   public ObjToIntMap(int keyCountHint) {
/*  96 */     if (keyCountHint < 0) Kit.codeBug();
/*     */     
/*  98 */     int minimalCapacity = keyCountHint * 4 / 3;
/*     */     int i;
/* 100 */     for (i = 2; 1 << i < minimalCapacity; i++);
/* 101 */     this.power = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 106 */     return (this.keyCount == 0);
/*     */   }
/*     */   
/*     */   public int size() {
/* 110 */     return this.keyCount;
/*     */   }
/*     */   
/*     */   public boolean has(Object key) {
/* 114 */     if (key == null) {
/* 115 */       key = UniqueTag.NULL_VALUE;
/*     */     }
/* 117 */     return (0 <= findIndex(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get(Object key, int defaultValue) {
/* 126 */     if (key == null) {
/* 127 */       key = UniqueTag.NULL_VALUE;
/*     */     }
/* 129 */     int index = findIndex(key);
/* 130 */     if (0 <= index) {
/* 131 */       return this.values[index];
/*     */     }
/* 133 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExisting(Object key) {
/* 143 */     if (key == null) {
/* 144 */       key = UniqueTag.NULL_VALUE;
/*     */     }
/* 146 */     int index = findIndex(key);
/* 147 */     if (0 <= index) {
/* 148 */       return this.values[index];
/*     */     }
/*     */     
/* 151 */     Kit.codeBug();
/* 152 */     return 0;
/*     */   }
/*     */   
/*     */   public void put(Object key, int value) {
/* 156 */     if (key == null) {
/* 157 */       key = UniqueTag.NULL_VALUE;
/*     */     }
/* 159 */     int index = ensureIndex(key);
/* 160 */     this.values[index] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object intern(Object keyArg) {
/* 168 */     boolean nullKey = false;
/* 169 */     if (keyArg == null) {
/* 170 */       nullKey = true;
/* 171 */       keyArg = UniqueTag.NULL_VALUE;
/*     */     } 
/* 173 */     int index = ensureIndex(keyArg);
/* 174 */     this.values[index] = 0;
/* 175 */     return nullKey ? null : this.keys[index];
/*     */   }
/*     */   
/*     */   public void remove(Object key) {
/* 179 */     if (key == null) {
/* 180 */       key = UniqueTag.NULL_VALUE;
/*     */     }
/* 182 */     int index = findIndex(key);
/* 183 */     if (0 <= index) {
/* 184 */       this.keys[index] = DELETED;
/* 185 */       this.keyCount--;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/* 190 */     int i = this.keys.length;
/* 191 */     while (i != 0) {
/* 192 */       this.keys[--i] = null;
/*     */     }
/* 194 */     this.keyCount = 0;
/* 195 */     this.occupiedCount = 0;
/*     */   }
/*     */   
/*     */   public Iterator newIterator() {
/* 199 */     return new Iterator(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void initIterator(Iterator i) {
/* 206 */     i.init(this.keys, this.values, this.keyCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getKeys() {
/* 211 */     Object[] array = new Object[this.keyCount];
/* 212 */     getKeys(array, 0);
/* 213 */     return array;
/*     */   }
/*     */   
/*     */   public void getKeys(Object[] array, int offset) {
/* 217 */     int count = this.keyCount;
/* 218 */     for (int i = 0; count != 0; i++) {
/* 219 */       Object key = this.keys[i];
/* 220 */       if (key != null && key != DELETED) {
/* 221 */         if (key == UniqueTag.NULL_VALUE) {
/* 222 */           key = null;
/*     */         }
/* 224 */         array[offset] = key;
/* 225 */         offset++;
/* 226 */         count--;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int tableLookupStep(int fraction, int mask, int power) {
/* 232 */     int shift = 32 - 2 * power;
/* 233 */     if (shift >= 0) {
/* 234 */       return fraction >>> shift & mask | 0x1;
/*     */     }
/* 236 */     return fraction & mask >>> -shift | 0x1;
/*     */   }
/*     */   
/*     */   private int findIndex(Object key) {
/* 240 */     if (this.keys != null) {
/* 241 */       int hash = key.hashCode();
/* 242 */       int fraction = hash * -1640531527;
/* 243 */       int index = fraction >>> 32 - this.power;
/* 244 */       Object test = this.keys[index];
/* 245 */       if (test != null) {
/* 246 */         int N = 1 << this.power;
/* 247 */         if (test == key || (this.values[N + index] == hash && test.equals(key))) {
/* 248 */           return index;
/*     */         }
/*     */         
/* 251 */         int mask = N - 1;
/* 252 */         int step = tableLookupStep(fraction, mask, this.power);
/* 253 */         int n = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         while (true) {
/* 259 */           index = index + step & mask;
/* 260 */           test = this.keys[index];
/* 261 */           if (test == null) {
/*     */             break;
/*     */           }
/* 264 */           if (test == key || (this.values[N + index] == hash && test.equals(key))) {
/* 265 */             return index;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 270 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int insertNewKey(Object key, int hash) {
/* 278 */     int fraction = hash * -1640531527;
/* 279 */     int index = fraction >>> 32 - this.power;
/* 280 */     int N = 1 << this.power;
/* 281 */     if (this.keys[index] != null) {
/* 282 */       int mask = N - 1;
/* 283 */       int step = tableLookupStep(fraction, mask, this.power);
/* 284 */       int firstIndex = index;
/*     */       
/*     */       do {
/* 287 */         index = index + step & mask;
/*     */       }
/* 289 */       while (this.keys[index] != null);
/*     */     } 
/* 291 */     this.keys[index] = key;
/* 292 */     this.values[N + index] = hash;
/* 293 */     this.occupiedCount++;
/* 294 */     this.keyCount++;
/*     */     
/* 296 */     return index;
/*     */   }
/*     */   
/*     */   private void rehashTable() {
/* 300 */     if (this.keys == null) {
/*     */ 
/*     */       
/* 303 */       int N = 1 << this.power;
/* 304 */       this.keys = new Object[N];
/* 305 */       this.values = new int[2 * N];
/*     */     } else {
/*     */       
/* 308 */       if (this.keyCount * 2 >= this.occupiedCount)
/*     */       {
/* 310 */         this.power++;
/*     */       }
/* 312 */       int N = 1 << this.power;
/* 313 */       Object[] oldKeys = this.keys;
/* 314 */       int[] oldValues = this.values;
/* 315 */       int oldN = oldKeys.length;
/* 316 */       this.keys = new Object[N];
/* 317 */       this.values = new int[2 * N];
/*     */       
/* 319 */       int remaining = this.keyCount;
/* 320 */       this.occupiedCount = this.keyCount = 0;
/* 321 */       for (int i = 0; remaining != 0; i++) {
/* 322 */         Object key = oldKeys[i];
/* 323 */         if (key != null && key != DELETED) {
/* 324 */           int keyHash = oldValues[oldN + i];
/* 325 */           int index = insertNewKey(key, keyHash);
/* 326 */           this.values[index] = oldValues[i];
/* 327 */           remaining--;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int ensureIndex(Object key) {
/* 335 */     int hash = key.hashCode();
/* 336 */     int index = -1;
/* 337 */     int firstDeleted = -1;
/* 338 */     if (this.keys != null) {
/* 339 */       int fraction = hash * -1640531527;
/* 340 */       index = fraction >>> 32 - this.power;
/* 341 */       Object test = this.keys[index];
/* 342 */       if (test != null) {
/* 343 */         int N = 1 << this.power;
/* 344 */         if (test == key || (this.values[N + index] == hash && test.equals(key))) {
/* 345 */           return index;
/*     */         }
/* 347 */         if (test == DELETED) {
/* 348 */           firstDeleted = index;
/*     */         }
/*     */ 
/*     */         
/* 352 */         int mask = N - 1;
/* 353 */         int step = tableLookupStep(fraction, mask, this.power);
/* 354 */         int n = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         while (true) {
/* 360 */           index = index + step & mask;
/* 361 */           test = this.keys[index];
/* 362 */           if (test == null) {
/*     */             break;
/*     */           }
/* 365 */           if (test == key || (this.values[N + index] == hash && test.equals(key))) {
/* 366 */             return index;
/*     */           }
/* 368 */           if (test == DELETED && firstDeleted < 0) {
/* 369 */             firstDeleted = index;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 376 */     if (firstDeleted >= 0) {
/* 377 */       index = firstDeleted;
/*     */     } else {
/*     */       
/* 380 */       if (this.keys == null || this.occupiedCount * 4 >= (1 << this.power) * 3) {
/*     */         
/* 382 */         rehashTable();
/* 383 */         return insertNewKey(key, hash);
/*     */       } 
/* 385 */       this.occupiedCount++;
/*     */     } 
/* 387 */     this.keys[index] = key;
/* 388 */     this.values[(1 << this.power) + index] = hash;
/* 389 */     this.keyCount++;
/* 390 */     return index;
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 394 */     out.defaultWriteObject();
/*     */     
/* 396 */     int count = this.keyCount;
/* 397 */     for (int i = 0; count != 0; i++) {
/* 398 */       Object key = this.keys[i];
/* 399 */       if (key != null && key != DELETED) {
/* 400 */         count--;
/* 401 */         out.writeObject(key);
/* 402 */         out.writeInt(this.values[i]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 408 */     in.defaultReadObject();
/*     */     
/* 410 */     int writtenKeyCount = this.keyCount;
/* 411 */     if (writtenKeyCount != 0) {
/* 412 */       this.keyCount = 0;
/* 413 */       int N = 1 << this.power;
/* 414 */       this.keys = new Object[N];
/* 415 */       this.values = new int[2 * N];
/* 416 */       for (int i = 0; i != writtenKeyCount; i++) {
/* 417 */         Object key = in.readObject();
/* 418 */         int hash = key.hashCode();
/* 419 */         int index = insertNewKey(key, hash);
/* 420 */         this.values[index] = in.readInt();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 429 */   private static final Object DELETED = new Object();
/*     */   private transient Object[] keys;
/*     */   private transient int[] values;
/*     */   private int power;
/*     */   private int keyCount;
/*     */   private transient int occupiedCount;
/*     */   private static final boolean check = false;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ObjToIntMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */