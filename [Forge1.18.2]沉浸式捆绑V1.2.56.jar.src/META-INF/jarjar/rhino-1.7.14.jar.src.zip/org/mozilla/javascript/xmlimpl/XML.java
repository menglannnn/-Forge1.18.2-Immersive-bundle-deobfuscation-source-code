/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ import org.mozilla.javascript.xml.XMLObject;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XML
/*     */   extends XMLObjectImpl
/*     */ {
/*     */   static final long serialVersionUID = -630969919086449092L;
/*     */   private XmlNode node;
/*     */   
/*     */   XML(XMLLibImpl lib, Scriptable scope, XMLObject prototype, XmlNode node) {
/*  21 */     super(lib, scope, prototype);
/*  22 */     initialize(node);
/*     */   }
/*     */   
/*     */   void initialize(XmlNode node) {
/*  26 */     this.node = node;
/*  27 */     this.node.setXml(this);
/*     */   }
/*     */ 
/*     */   
/*     */   final XML getXML() {
/*  32 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void replaceWith(XML value) {
/*  39 */     if (this.node.parent() != null) {
/*  40 */       this.node.replaceWith(value.node);
/*     */     } else {
/*  42 */       initialize(value.node);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   XML makeXmlFromString(XMLName name, String value) {
/*     */     try {
/*  49 */       return newTextElementXML(this.node, name.toQname(), value);
/*  50 */     } catch (Exception e) {
/*  51 */       throw ScriptRuntime.typeError(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   XmlNode getAnnotation() {
/*  57 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/*  68 */     if (index == 0) {
/*  69 */       return this;
/*     */     }
/*  71 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/*  77 */     return (index == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/*  84 */     throw ScriptRuntime.typeError("Assignment to indexed XML is not allowed");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/*  89 */     if (isPrototype()) {
/*  90 */       return new Object[0];
/*     */     }
/*  92 */     return new Object[] { Integer.valueOf(0) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int index) {
/*  99 */     if (index == 0) {
/* 100 */       remove();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasXMLProperty(XMLName xmlName) {
/* 110 */     return (getPropertyList(xmlName).length() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   Object getXMLProperty(XMLName xmlName) {
/* 115 */     return getPropertyList(xmlName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlNode.QName getNodeQname() {
/* 125 */     return this.node.getQname();
/*     */   }
/*     */   
/*     */   XML[] getChildren() {
/* 129 */     if (!isElement()) return null; 
/* 130 */     XmlNode[] children = this.node.getMatchingChildren(XmlNode.Filter.TRUE);
/* 131 */     XML[] rv = new XML[children.length];
/* 132 */     for (int i = 0; i < rv.length; i++) {
/* 133 */       rv[i] = toXML(children[i]);
/*     */     }
/* 135 */     return rv;
/*     */   }
/*     */   
/*     */   XML[] getAttributes() {
/* 139 */     XmlNode[] attributes = this.node.getAttributes();
/* 140 */     XML[] rv = new XML[attributes.length];
/* 141 */     for (int i = 0; i < rv.length; i++) {
/* 142 */       rv[i] = toXML(attributes[i]);
/*     */     }
/* 144 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList getPropertyList(XMLName name) {
/* 149 */     return name.getMyValueOn(this);
/*     */   }
/*     */ 
/*     */   
/*     */   void deleteXMLProperty(XMLName name) {
/* 154 */     XMLList list = getPropertyList(name);
/* 155 */     for (int i = 0; i < list.length(); i++) {
/* 156 */       (list.item(i)).node.deleteMe();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void putXMLProperty(XMLName xmlName, Object value) {
/* 162 */     if (!isPrototype())
/*     */     {
/*     */       
/* 165 */       xmlName.setMyValueOn(this, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   boolean hasOwnProperty(XMLName xmlName) {
/* 171 */     boolean hasProperty = false;
/*     */     
/* 173 */     if (isPrototype()) {
/* 174 */       String property = xmlName.localName();
/* 175 */       hasProperty = (0 != findPrototypeId(property));
/*     */     } else {
/* 177 */       hasProperty = (getPropertyList(xmlName).length() > 0);
/*     */     } 
/*     */     
/* 180 */     return hasProperty;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object jsConstructor(Context cx, boolean inNewExpr, Object[] args) {
/* 185 */     if (args.length == 0 || args[0] == null || args[0] == Undefined.instance) {
/* 186 */       args = new Object[] { "" };
/*     */     }
/*     */     
/* 189 */     XML toXml = ecmaToXml(args[0]);
/* 190 */     if (inNewExpr) {
/* 191 */       return toXml.copy();
/*     */     }
/* 193 */     return toXml;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getExtraMethodSource(Context cx) {
/* 201 */     if (hasSimpleContent()) {
/* 202 */       String src = toString();
/* 203 */       return ScriptRuntime.toObjectOrNull(cx, src);
/*     */     } 
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeChild(int index) {
/* 213 */     this.node.removeChild(index);
/*     */   }
/*     */ 
/*     */   
/*     */   void normalize() {
/* 218 */     this.node.normalize();
/*     */   }
/*     */   
/*     */   private XML toXML(XmlNode node) {
/* 222 */     if (node.getXml() == null) {
/* 223 */       node.setXml(newXML(node));
/*     */     }
/* 225 */     return node.getXml();
/*     */   }
/*     */   
/*     */   void setAttribute(XMLName xmlName, Object value) {
/* 229 */     if (!isElement()) throw new IllegalStateException("Can only set attributes on elements.");
/*     */     
/* 231 */     if (xmlName.uri() == null && xmlName.localName().equals("*")) {
/* 232 */       throw ScriptRuntime.typeError("@* assignment not supported.");
/*     */     }
/* 234 */     this.node.setAttribute(xmlName.toQname(), ScriptRuntime.toString(value));
/*     */   }
/*     */   
/*     */   void remove() {
/* 238 */     this.node.deleteMe();
/*     */   }
/*     */ 
/*     */   
/*     */   void addMatches(XMLList rv, XMLName name) {
/* 243 */     name.addMatches(rv, this);
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList elements(XMLName name) {
/* 248 */     XMLList rv = newXMLList();
/* 249 */     rv.setTargets(this, name.toQname());
/*     */     
/* 251 */     XmlNode[] elements = this.node.getMatchingChildren(XmlNode.Filter.ELEMENT);
/* 252 */     for (int i = 0; i < elements.length; i++) {
/* 253 */       if (name.matches(toXML(elements[i]))) {
/* 254 */         rv.addToList(toXML(elements[i]));
/*     */       }
/*     */     } 
/* 257 */     return rv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XMLList child(XMLName xmlName) {
/* 264 */     XMLList rv = newXMLList();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     XmlNode[] elements = this.node.getMatchingChildren(XmlNode.Filter.ELEMENT);
/* 270 */     for (int i = 0; i < elements.length; i++) {
/* 271 */       if (xmlName.matchesElement(elements[i].getQname())) {
/* 272 */         rv.addToList(toXML(elements[i]));
/*     */       }
/*     */     } 
/* 275 */     rv.setTargets(this, xmlName.toQname());
/* 276 */     return rv;
/*     */   }
/*     */   
/*     */   XML replace(XMLName xmlName, Object xml) {
/* 280 */     putXMLProperty(xmlName, xml);
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList children() {
/* 286 */     XMLList rv = newXMLList();
/* 287 */     XMLName all = XMLName.formStar();
/* 288 */     rv.setTargets(this, all.toQname());
/* 289 */     XmlNode[] children = this.node.getMatchingChildren(XmlNode.Filter.TRUE);
/* 290 */     for (int i = 0; i < children.length; i++) {
/* 291 */       rv.addToList(toXML(children[i]));
/*     */     }
/* 293 */     return rv;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XMLList child(int index) {
/* 299 */     XMLList result = newXMLList();
/* 300 */     result.setTargets(this, null);
/* 301 */     if (index >= 0 && index < this.node.getChildCount()) {
/* 302 */       result.addToList(getXmlChild(index));
/*     */     }
/* 304 */     return result;
/*     */   }
/*     */   
/*     */   XML getXmlChild(int index) {
/* 308 */     XmlNode child = this.node.getChild(index);
/* 309 */     if (child.getXml() == null) {
/* 310 */       child.setXml(newXML(child));
/*     */     }
/* 312 */     return child.getXml();
/*     */   }
/*     */ 
/*     */   
/*     */   XML getLastXmlChild() {
/* 317 */     int pos = this.node.getChildCount() - 1;
/* 318 */     if (pos < 0) return null; 
/* 319 */     return getXmlChild(pos);
/*     */   }
/*     */   
/*     */   int childIndex() {
/* 323 */     return this.node.getChildIndex();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean contains(Object xml) {
/* 328 */     if (xml instanceof XML) {
/* 329 */       return equivalentXml(xml);
/*     */     }
/* 331 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean equivalentXml(Object target) {
/* 338 */     boolean result = false;
/*     */     
/* 340 */     if (target instanceof XML)
/*     */     {
/* 342 */       return this.node.toXmlString(getProcessor()).equals(((XML)target).node.toXmlString(getProcessor())); } 
/* 343 */     if (target instanceof XMLList) {
/*     */       
/* 345 */       XMLList otherList = (XMLList)target;
/*     */       
/* 347 */       if (otherList.length() == 1) {
/* 348 */         result = equivalentXml(otherList.getXML());
/*     */       }
/* 350 */     } else if (hasSimpleContent()) {
/* 351 */       String otherStr = ScriptRuntime.toString(target);
/*     */       
/* 353 */       result = toString().equals(otherStr);
/*     */     } 
/*     */     
/* 356 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLObjectImpl copy() {
/* 361 */     return newXML(this.node.copy());
/*     */   }
/*     */ 
/*     */   
/*     */   boolean hasSimpleContent() {
/* 366 */     if (isComment() || isProcessingInstruction()) return false; 
/* 367 */     if (isText() || this.node.isAttributeType()) return true; 
/* 368 */     return !this.node.hasChildElement();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean hasComplexContent() {
/* 373 */     return !hasSimpleContent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int length() {
/* 380 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean is(XML other) {
/* 385 */     return this.node.isSameNode(other.node);
/*     */   }
/*     */   
/*     */   Object nodeKind() {
/* 389 */     return ecmaClass();
/*     */   }
/*     */ 
/*     */   
/*     */   Object parent() {
/* 394 */     XmlNode parent = this.node.parent();
/* 395 */     if (parent == null) return null; 
/* 396 */     return newXML(this.node.parent());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean propertyIsEnumerable(Object name) {
/*     */     boolean result;
/* 403 */     if (name instanceof Integer) {
/* 404 */       result = (((Integer)name).intValue() == 0);
/* 405 */     } else if (name instanceof Number) {
/* 406 */       double x = ((Number)name).doubleValue();
/*     */       
/* 408 */       result = (x == 0.0D && 1.0D / x > 0.0D);
/*     */     } else {
/* 410 */       result = ScriptRuntime.toString(name).equals("0");
/*     */     } 
/* 412 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   Object valueOf() {
/* 417 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XMLList comments() {
/* 426 */     XMLList rv = newXMLList();
/* 427 */     this.node.addMatchingChildren(rv, XmlNode.Filter.COMMENT);
/* 428 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList text() {
/* 433 */     XMLList rv = newXMLList();
/* 434 */     this.node.addMatchingChildren(rv, XmlNode.Filter.TEXT);
/* 435 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList processingInstructions(XMLName xmlName) {
/* 440 */     XMLList rv = newXMLList();
/* 441 */     this.node.addMatchingChildren(rv, XmlNode.Filter.PROCESSING_INSTRUCTION(xmlName));
/* 442 */     return rv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XmlNode[] getNodesForInsert(Object value) {
/* 456 */     if (value instanceof XML)
/* 457 */       return new XmlNode[] { ((XML)value).node }; 
/* 458 */     if (value instanceof XMLList) {
/* 459 */       XMLList list = (XMLList)value;
/* 460 */       XmlNode[] rv = new XmlNode[list.length()];
/* 461 */       for (int i = 0; i < list.length(); i++) {
/* 462 */         rv[i] = (list.item(i)).node;
/*     */       }
/* 464 */       return rv;
/*     */     } 
/* 466 */     return new XmlNode[] {
/* 467 */         XmlNode.createText(getProcessor(), ScriptRuntime.toString(value))
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   XML replace(int index, Object xml) {
/* 473 */     XMLList xlChildToReplace = child(index);
/* 474 */     if (xlChildToReplace.length() > 0) {
/*     */       
/* 476 */       XML childToReplace = xlChildToReplace.item(0);
/* 477 */       insertChildAfter(childToReplace, xml);
/* 478 */       removeChild(index);
/*     */     } 
/* 480 */     return this;
/*     */   }
/*     */   
/*     */   XML prependChild(Object xml) {
/* 484 */     if (this.node.isParentType()) {
/* 485 */       this.node.insertChildrenAt(0, getNodesForInsert(xml));
/*     */     }
/* 487 */     return this;
/*     */   }
/*     */   
/*     */   XML appendChild(Object xml) {
/* 491 */     if (this.node.isParentType()) {
/* 492 */       XmlNode[] nodes = getNodesForInsert(xml);
/* 493 */       this.node.insertChildrenAt(this.node.getChildCount(), nodes);
/*     */     } 
/* 495 */     return this;
/*     */   }
/*     */   
/*     */   private int getChildIndexOf(XML child) {
/* 499 */     for (int i = 0; i < this.node.getChildCount(); i++) {
/* 500 */       if (this.node.getChild(i).isSameNode(child.node)) {
/* 501 */         return i;
/*     */       }
/*     */     } 
/* 504 */     return -1;
/*     */   }
/*     */   
/*     */   XML insertChildBefore(XML child, Object xml) {
/* 508 */     if (child == null) {
/*     */       
/* 510 */       appendChild(xml);
/*     */     } else {
/* 512 */       XmlNode[] toInsert = getNodesForInsert(xml);
/* 513 */       int index = getChildIndexOf(child);
/* 514 */       if (index != -1) {
/* 515 */         this.node.insertChildrenAt(index, toInsert);
/*     */       }
/*     */     } 
/*     */     
/* 519 */     return this;
/*     */   }
/*     */   
/*     */   XML insertChildAfter(XML child, Object xml) {
/* 523 */     if (child == null) {
/*     */       
/* 525 */       prependChild(xml);
/*     */     } else {
/* 527 */       XmlNode[] toInsert = getNodesForInsert(xml);
/* 528 */       int index = getChildIndexOf(child);
/* 529 */       if (index != -1) {
/* 530 */         this.node.insertChildrenAt(index + 1, toInsert);
/*     */       }
/*     */     } 
/*     */     
/* 534 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   XML setChildren(Object xml) {
/* 539 */     if (!isElement()) return this;
/*     */     
/* 541 */     while (this.node.getChildCount() > 0) {
/* 542 */       this.node.removeChild(0);
/*     */     }
/* 544 */     XmlNode[] toInsert = getNodesForInsert(xml);
/*     */     
/* 546 */     this.node.insertChildrenAt(0, toInsert);
/*     */     
/* 548 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addInScopeNamespace(Namespace ns) {
/* 556 */     if (!isElement()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 561 */     if (ns.prefix() != null) {
/* 562 */       if (ns.prefix().length() == 0 && ns.uri().length() == 0) {
/*     */         return;
/*     */       }
/* 565 */       if (this.node.getQname().getNamespace().getPrefix().equals(ns.prefix())) {
/* 566 */         this.node.invalidateNamespacePrefix();
/*     */       }
/* 568 */       this.node.declareNamespace(ns.prefix(), ns.uri());
/*     */     } else {
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   Namespace[] inScopeNamespaces() {
/* 575 */     XmlNode.Namespace[] inScope = this.node.getInScopeNamespaces();
/* 576 */     return createNamespaces(inScope);
/*     */   }
/*     */   
/*     */   private XmlNode.Namespace adapt(Namespace ns) {
/* 580 */     if (ns.prefix() == null) {
/* 581 */       return XmlNode.Namespace.create(ns.uri());
/*     */     }
/* 583 */     return XmlNode.Namespace.create(ns.prefix(), ns.uri());
/*     */   }
/*     */ 
/*     */   
/*     */   XML removeNamespace(Namespace ns) {
/* 588 */     if (!isElement()) return this; 
/* 589 */     this.node.removeNamespace(adapt(ns));
/* 590 */     return this;
/*     */   }
/*     */   
/*     */   XML addNamespace(Namespace ns) {
/* 594 */     addInScopeNamespace(ns);
/* 595 */     return this;
/*     */   }
/*     */   
/*     */   QName name() {
/* 599 */     if (isText() || isComment()) return null; 
/* 600 */     if (isProcessingInstruction()) return newQName("", this.node.getQname().getLocalName(), null); 
/* 601 */     return newQName(this.node.getQname());
/*     */   }
/*     */   
/*     */   Namespace[] namespaceDeclarations() {
/* 605 */     XmlNode.Namespace[] declarations = this.node.getNamespaceDeclarations();
/* 606 */     return createNamespaces(declarations);
/*     */   }
/*     */   
/*     */   Namespace namespace(String prefix) {
/* 610 */     if (prefix == null) {
/* 611 */       return createNamespace(this.node.getNamespaceDeclaration());
/*     */     }
/* 613 */     return createNamespace(this.node.getNamespaceDeclaration(prefix));
/*     */   }
/*     */ 
/*     */   
/*     */   String localName() {
/* 618 */     if (name() == null) return null; 
/* 619 */     return name().localName();
/*     */   }
/*     */ 
/*     */   
/*     */   void setLocalName(String localName) {
/* 624 */     if (isText() || isComment())
/* 625 */       return;  this.node.setLocalName(localName);
/*     */   }
/*     */ 
/*     */   
/*     */   void setName(QName name) {
/* 630 */     if (isText() || isComment())
/* 631 */       return;  if (isProcessingInstruction()) {
/*     */ 
/*     */       
/* 634 */       this.node.setLocalName(name.localName());
/*     */       return;
/*     */     } 
/* 637 */     this.node.renameNode(name.getDelegate());
/*     */   }
/*     */ 
/*     */   
/*     */   void setNamespace(Namespace ns) {
/* 642 */     if (isText() || isComment() || isProcessingInstruction())
/* 643 */       return;  setName(newQName(ns.uri(), localName(), ns.prefix()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String ecmaClass() {
/* 651 */     if (this.node.isTextType())
/* 652 */       return "text"; 
/* 653 */     if (this.node.isAttributeType())
/* 654 */       return "attribute"; 
/* 655 */     if (this.node.isCommentType())
/* 656 */       return "comment"; 
/* 657 */     if (this.node.isProcessingInstructionType())
/* 658 */       return "processing-instruction"; 
/* 659 */     if (this.node.isElementType()) {
/* 660 */       return "element";
/*     */     }
/* 662 */     throw new RuntimeException("Unrecognized type: " + this.node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 671 */     return "XML";
/*     */   }
/*     */   
/*     */   private String ecmaValue() {
/* 675 */     return this.node.ecmaValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private String ecmaToString() {
/* 680 */     if (isAttribute() || isText()) {
/* 681 */       return ecmaValue();
/*     */     }
/* 683 */     if (hasSimpleContent()) {
/* 684 */       StringBuilder rv = new StringBuilder();
/* 685 */       for (int i = 0; i < this.node.getChildCount(); i++) {
/* 686 */         XmlNode child = this.node.getChild(i);
/* 687 */         if (!child.isProcessingInstructionType() && 
/* 688 */           !child.isCommentType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 693 */           XML x = new XML(getLib(), getParentScope(), (XMLObject)getPrototype(), child);
/* 694 */           rv.append(x.toString());
/*     */         } 
/*     */       } 
/* 697 */       return rv.toString();
/*     */     } 
/* 699 */     return toXMLString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 704 */     return ecmaToString();
/*     */   }
/*     */ 
/*     */   
/*     */   String toSource(int indent) {
/* 709 */     return toXMLString();
/*     */   }
/*     */ 
/*     */   
/*     */   String toXMLString() {
/* 714 */     return this.node.ecmaToXMLString(getProcessor());
/*     */   }
/*     */   
/*     */   final boolean isAttribute() {
/* 718 */     return this.node.isAttributeType();
/*     */   }
/*     */   
/*     */   final boolean isComment() {
/* 722 */     return this.node.isCommentType();
/*     */   }
/*     */   
/*     */   final boolean isText() {
/* 726 */     return this.node.isTextType();
/*     */   }
/*     */   
/*     */   final boolean isElement() {
/* 730 */     return this.node.isElementType();
/*     */   }
/*     */   
/*     */   final boolean isProcessingInstruction() {
/* 734 */     return this.node.isProcessingInstructionType();
/*     */   }
/*     */ 
/*     */   
/*     */   Node toDomNode() {
/* 739 */     return this.node.toDomNode();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XML.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */