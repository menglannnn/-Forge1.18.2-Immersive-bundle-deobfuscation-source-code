/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.IdScriptableObject;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Namespace
/*     */   extends IdScriptableObject
/*     */ {
/*     */   static final long serialVersionUID = -5765755238131301744L;
/*  24 */   private static final Object NAMESPACE_TAG = "Namespace";
/*     */   
/*     */   private Namespace prototype;
/*     */   
/*     */   private XmlNode.Namespace ns;
/*     */   private static final int Id_prefix = 1;
/*     */   private static final int Id_uri = 2;
/*     */   
/*     */   static Namespace create(Scriptable scope, Namespace prototype, XmlNode.Namespace namespace) {
/*  33 */     Namespace rv = new Namespace();
/*  34 */     rv.setParentScope(scope);
/*  35 */     rv.prototype = prototype;
/*  36 */     rv.setPrototype((Scriptable)prototype);
/*  37 */     rv.ns = namespace;
/*  38 */     return rv;
/*     */   }
/*     */   private static final int MAX_INSTANCE_ID = 2; private static final int Id_constructor = 1; private static final int Id_toString = 2; private static final int Id_toSource = 3; private static final int MAX_PROTOTYPE_ID = 3;
/*     */   final XmlNode.Namespace getDelegate() {
/*  42 */     return this.ns;
/*     */   }
/*     */   
/*     */   public void exportAsJSClass(boolean sealed) {
/*  46 */     exportAsJSClass(3, getParentScope(), sealed);
/*     */   }
/*     */   
/*     */   public String uri() {
/*  50 */     return this.ns.getUri();
/*     */   }
/*     */   
/*     */   public String prefix() {
/*  54 */     return this.ns.getPrefix();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  59 */     return uri();
/*     */   }
/*     */   
/*     */   public String toLocaleString() {
/*  63 */     return toString();
/*     */   }
/*     */   
/*     */   private boolean equals(Namespace n) {
/*  67 */     return uri().equals(n.uri());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  72 */     if (!(obj instanceof Namespace)) return false; 
/*  73 */     return equals((Namespace)obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  78 */     return uri().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object equivalentValues(Object value) {
/*  83 */     if (!(value instanceof Namespace)) return Scriptable.NOT_FOUND; 
/*  84 */     boolean result = equals((Namespace)value);
/*  85 */     return result ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  90 */     return "Namespace";
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class<?> hint) {
/*  95 */     return uri();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxInstanceId() {
/* 107 */     return super.getMaxInstanceId() + 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(String s) {
/* 115 */     int attr, id = 0; String X = null;
/* 116 */     int s_length = s.length();
/* 117 */     if (s_length == 3) { X = "uri"; id = 2; }
/* 118 */     else if (s_length == 6) { X = "prefix"; id = 1; }
/* 119 */      if (X != null && X != s && !X.equals(s)) id = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     if (id == 0) return super.findInstanceIdInfo(s);
/*     */ 
/*     */     
/* 127 */     switch (id) {
/*     */       case 1:
/*     */       case 2:
/* 130 */         attr = 5;
/*     */ 
/*     */ 
/*     */         
/* 134 */         return instanceIdInfo(attr, super.getMaxInstanceId() + id);
/*     */     } 
/*     */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/* 141 */     switch (id - super.getMaxInstanceId()) { case 1:
/* 142 */         return "prefix";
/* 143 */       case 2: return "uri"; }
/*     */     
/* 145 */     return super.getInstanceIdName(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/* 151 */     switch (id - super.getMaxInstanceId()) {
/*     */       case 1:
/* 153 */         if (this.ns.getPrefix() == null) return Undefined.instance; 
/* 154 */         return this.ns.getPrefix();
/*     */       case 2:
/* 156 */         return this.ns.getUri();
/*     */     } 
/* 158 */     return super.getInstanceIdValue(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 174 */     int id = 0; String X = null;
/* 175 */     int s_length = s.length();
/* 176 */     if (s_length == 8)
/* 177 */     { int c = s.charAt(3);
/* 178 */       if (c == 111) { X = "toSource"; id = 3; }
/* 179 */       else if (c == 116) { X = "toString"; id = 2; }
/*     */        }
/* 181 */     else if (s_length == 11) { X = "constructor"; id = 1; }
/* 182 */      if (X != null && X != s && !X.equals(s)) id = 0;
/*     */ 
/*     */ 
/*     */     
/* 186 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 195 */     switch (id) { case 1:
/* 196 */         arity = 2; s = "constructor"; break;
/* 197 */       case 2: arity = 0; s = "toString"; break;
/* 198 */       case 3: arity = 0; s = "toSource"; break;
/* 199 */       default: throw new IllegalArgumentException(String.valueOf(id)); }
/*     */     
/* 201 */     initPrototypeMethod(NAMESPACE_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 211 */     if (!f.hasTag(NAMESPACE_TAG)) {
/* 212 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 214 */     int id = f.methodId();
/* 215 */     switch (id) {
/*     */       case 1:
/* 217 */         return jsConstructor(cx, (thisObj == null), args);
/*     */       case 2:
/* 219 */         return realThis(thisObj, f).toString();
/*     */       case 3:
/* 221 */         return realThis(thisObj, f).js_toSource();
/*     */     } 
/* 223 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */   
/*     */   private Namespace realThis(Scriptable thisObj, IdFunctionObject f) {
/* 227 */     return (Namespace)ensureType(thisObj, Namespace.class, f);
/*     */   }
/*     */   
/*     */   Namespace newNamespace(String uri) {
/* 231 */     Namespace prototype = (this.prototype == null) ? this : this.prototype;
/* 232 */     return create(getParentScope(), prototype, XmlNode.Namespace.create(uri));
/*     */   }
/*     */   
/*     */   Namespace newNamespace(String prefix, String uri) {
/* 236 */     if (prefix == null) return newNamespace(uri); 
/* 237 */     Namespace prototype = (this.prototype == null) ? this : this.prototype;
/* 238 */     return create(getParentScope(), prototype, XmlNode.Namespace.create(prefix, uri));
/*     */   }
/*     */ 
/*     */   
/*     */   Namespace constructNamespace(Object uriValue) {
/*     */     String prefix;
/*     */     String uri;
/* 245 */     if (uriValue instanceof Namespace) {
/* 246 */       Namespace ns = (Namespace)uriValue;
/* 247 */       prefix = ns.prefix();
/* 248 */       uri = ns.uri();
/* 249 */     } else if (uriValue instanceof QName) {
/* 250 */       QName qname = (QName)uriValue;
/* 251 */       uri = qname.uri();
/* 252 */       if (uri != null) {
/*     */         
/* 254 */         prefix = qname.prefix();
/*     */       } else {
/* 256 */         uri = qname.toString();
/* 257 */         prefix = null;
/*     */       } 
/*     */     } else {
/* 260 */       uri = ScriptRuntime.toString(uriValue);
/* 261 */       prefix = (uri.length() == 0) ? "" : null;
/*     */     } 
/*     */     
/* 264 */     return newNamespace(prefix, uri);
/*     */   }
/*     */   
/*     */   Namespace castToNamespace(Object namespaceObj) {
/* 268 */     if (namespaceObj instanceof Namespace) {
/* 269 */       return (Namespace)namespaceObj;
/*     */     }
/* 271 */     return constructNamespace(namespaceObj);
/*     */   }
/*     */ 
/*     */   
/*     */   private Namespace constructNamespace(Object prefixValue, Object uriValue) {
/*     */     String prefix;
/*     */     String uri;
/* 278 */     if (uriValue instanceof QName) {
/* 279 */       QName qname = (QName)uriValue;
/* 280 */       uri = qname.uri();
/* 281 */       if (uri == null) {
/* 282 */         uri = qname.toString();
/*     */       }
/*     */     } else {
/* 285 */       uri = ScriptRuntime.toString(uriValue);
/*     */     } 
/*     */     
/* 288 */     if (uri.length() == 0) {
/* 289 */       if (prefixValue == Undefined.instance) {
/* 290 */         prefix = "";
/*     */       } else {
/* 292 */         prefix = ScriptRuntime.toString(prefixValue);
/* 293 */         if (prefix.length() != 0) {
/* 294 */           throw ScriptRuntime.typeError("Illegal prefix '" + prefix + "' for 'no namespace'.");
/*     */         }
/*     */       }
/*     */     
/* 298 */     } else if (prefixValue == Undefined.instance) {
/* 299 */       prefix = "";
/* 300 */     } else if (!XMLName.accept(prefixValue)) {
/* 301 */       prefix = "";
/*     */     } else {
/* 303 */       prefix = ScriptRuntime.toString(prefixValue);
/*     */     } 
/*     */     
/* 306 */     return newNamespace(prefix, uri);
/*     */   }
/*     */   
/*     */   private Namespace constructNamespace() {
/* 310 */     return newNamespace("", "");
/*     */   }
/*     */ 
/*     */   
/*     */   private Object jsConstructor(Context cx, boolean inNewExpr, Object[] args) {
/* 315 */     if (!inNewExpr && args.length == 1) {
/* 316 */       return castToNamespace(args[0]);
/*     */     }
/*     */     
/* 319 */     if (args.length == 0)
/* 320 */       return constructNamespace(); 
/* 321 */     if (args.length == 1) {
/* 322 */       return constructNamespace(args[0]);
/*     */     }
/* 324 */     return constructNamespace(args[0], args[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String js_toSource() {
/* 330 */     StringBuilder sb = new StringBuilder();
/* 331 */     sb.append('(');
/* 332 */     toSourceImpl(this.ns.getPrefix(), this.ns.getUri(), sb);
/* 333 */     sb.append(')');
/* 334 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static void toSourceImpl(String prefix, String uri, StringBuilder sb) {
/* 339 */     sb.append("new Namespace(");
/* 340 */     if (uri.length() == 0) {
/* 341 */       if (!"".equals(prefix)) throw new IllegalArgumentException(prefix); 
/*     */     } else {
/* 343 */       sb.append('\'');
/* 344 */       if (prefix != null) {
/* 345 */         sb.append(ScriptRuntime.escapeString(prefix, '\''));
/* 346 */         sb.append("', '");
/*     */       } 
/* 348 */       sb.append(ScriptRuntime.escapeString(uri, '\''));
/* 349 */       sb.append('\'');
/*     */     } 
/* 351 */     sb.append(')');
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\Namespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */