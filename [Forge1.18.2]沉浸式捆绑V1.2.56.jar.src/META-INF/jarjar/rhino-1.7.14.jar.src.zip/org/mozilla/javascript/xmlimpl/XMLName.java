/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.EcmaError;
/*     */ import org.mozilla.javascript.Kit;
/*     */ import org.mozilla.javascript.Ref;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ class XMLName
/*     */   extends Ref
/*     */ {
/*     */   static final long serialVersionUID = 3832176310755686977L;
/*     */   private XmlNode.QName qname;
/*     */   private boolean isAttributeName;
/*     */   private boolean isDescendants;
/*     */   private XMLObjectImpl xmlObject;
/*     */   
/*     */   private static boolean isNCNameStartChar(int c) {
/*  20 */     if ((c & 0xFFFFFF80) == 0) {
/*     */       
/*  22 */       if (c >= 97)
/*  23 */         return (c <= 122); 
/*  24 */       if (c >= 65) {
/*  25 */         if (c <= 90) {
/*  26 */           return true;
/*     */         }
/*  28 */         return (c == 95);
/*     */       } 
/*  30 */     } else if ((c & 0xFFFFE000) == 0) {
/*  31 */       return ((192 <= c && c <= 214) || (216 <= c && c <= 246) || (248 <= c && c <= 767) || (880 <= c && c <= 893) || 895 <= c);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  37 */     return ((8204 <= c && c <= 8205) || (8304 <= c && c <= 8591) || (11264 <= c && c <= 12271) || (12289 <= c && c <= 55295) || (63744 <= c && c <= 64975) || (65008 <= c && c <= 65533) || (65536 <= c && c <= 983039));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isNCNameChar(int c) {
/*  47 */     if ((c & 0xFFFFFF80) == 0) {
/*     */       
/*  49 */       if (c >= 97)
/*  50 */         return (c <= 122); 
/*  51 */       if (c >= 65) {
/*  52 */         if (c <= 90) {
/*  53 */           return true;
/*     */         }
/*  55 */         return (c == 95);
/*  56 */       }  if (c >= 48) {
/*  57 */         return (c <= 57);
/*     */       }
/*  59 */       return (c == 45 || c == 46);
/*     */     } 
/*  61 */     if ((c & 0xFFFFE000) == 0) {
/*  62 */       return (isNCNameStartChar(c) || c == 183 || (768 <= c && c <= 879));
/*     */     }
/*     */     
/*  65 */     return (isNCNameStartChar(c) || (8255 <= c && c <= 8256));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean accept(Object nameObj) {
/*     */     String name;
/*     */     try {
/*  73 */       name = ScriptRuntime.toString(nameObj);
/*  74 */     } catch (EcmaError ee) {
/*  75 */       if ("TypeError".equals(ee.getName())) {
/*  76 */         return false;
/*     */       }
/*  78 */       throw ee;
/*     */     } 
/*     */ 
/*     */     
/*  82 */     int length = name.length();
/*  83 */     if (length != 0 && 
/*  84 */       isNCNameStartChar(name.charAt(0))) {
/*  85 */       for (int i = 1; i != length; i++) {
/*  86 */         if (!isNCNameChar(name.charAt(i))) {
/*  87 */           return false;
/*     */         }
/*     */       } 
/*  90 */       return true;
/*     */     } 
/*     */ 
/*     */     
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static XMLName formStar() {
/* 106 */     XMLName rv = new XMLName();
/* 107 */     rv.qname = XmlNode.QName.create(null, null);
/* 108 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static XMLName formProperty(XmlNode.Namespace namespace, String localName) {
/* 114 */     if (localName != null && localName.equals("*")) localName = null; 
/* 115 */     XMLName rv = new XMLName();
/* 116 */     rv.qname = XmlNode.QName.create(namespace, localName);
/* 117 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   static XMLName formProperty(String uri, String localName) {
/* 122 */     return formProperty(XmlNode.Namespace.create(uri), localName);
/*     */   }
/*     */ 
/*     */   
/*     */   static XMLName create(String defaultNamespaceUri, String name) {
/* 127 */     if (name == null) {
/* 128 */       throw new IllegalArgumentException();
/*     */     }
/* 130 */     int l = name.length();
/* 131 */     if (l != 0) {
/* 132 */       char firstChar = name.charAt(0);
/* 133 */       if (firstChar == '*') {
/* 134 */         if (l == 1) {
/* 135 */           return formStar();
/*     */         }
/* 137 */       } else if (firstChar == '@') {
/* 138 */         XMLName xmlName = formProperty("", name.substring(1));
/* 139 */         xmlName.setAttributeName();
/* 140 */         return xmlName;
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     return formProperty(defaultNamespaceUri, name);
/*     */   }
/*     */   
/*     */   static XMLName create(XmlNode.QName qname, boolean attribute, boolean descendants) {
/* 148 */     XMLName rv = new XMLName();
/* 149 */     rv.qname = qname;
/* 150 */     rv.isAttributeName = attribute;
/* 151 */     rv.isDescendants = descendants;
/* 152 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static XMLName create(XmlNode.QName qname) {
/* 158 */     return create(qname, false, false);
/*     */   }
/*     */   
/*     */   void initXMLObject(XMLObjectImpl xmlObject) {
/* 162 */     if (xmlObject == null) throw new IllegalArgumentException(); 
/* 163 */     if (this.xmlObject != null) throw new IllegalStateException(); 
/* 164 */     this.xmlObject = xmlObject;
/*     */   }
/*     */   
/*     */   String uri() {
/* 168 */     if (this.qname.getNamespace() == null) return null; 
/* 169 */     return this.qname.getNamespace().getUri();
/*     */   }
/*     */   
/*     */   String localName() {
/* 173 */     if (this.qname.getLocalName() == null) return "*"; 
/* 174 */     return this.qname.getLocalName();
/*     */   }
/*     */   
/*     */   private void addDescendantChildren(XMLList list, XML target) {
/* 178 */     XMLName xmlName = this;
/* 179 */     if (target.isElement()) {
/* 180 */       XML[] children = target.getChildren();
/* 181 */       for (int i = 0; i < children.length; i++) {
/* 182 */         if (xmlName.matches(children[i])) {
/* 183 */           list.addToList(children[i]);
/*     */         }
/* 185 */         addDescendantChildren(list, children[i]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void addMatchingAttributes(XMLList list, XML target) {
/* 191 */     XMLName name = this;
/* 192 */     if (target.isElement()) {
/* 193 */       XML[] attributes = target.getAttributes();
/* 194 */       for (int i = 0; i < attributes.length; i++) {
/* 195 */         if (name.matches(attributes[i])) {
/* 196 */           list.addToList(attributes[i]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addDescendantAttributes(XMLList list, XML target) {
/* 203 */     if (target.isElement()) {
/* 204 */       addMatchingAttributes(list, target);
/* 205 */       XML[] children = target.getChildren();
/* 206 */       for (int i = 0; i < children.length; i++) {
/* 207 */         addDescendantAttributes(list, children[i]);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   XMLList matchDescendantAttributes(XMLList rv, XML target) {
/* 213 */     rv.setTargets(target, null);
/* 214 */     addDescendantAttributes(rv, target);
/* 215 */     return rv;
/*     */   }
/*     */   
/*     */   XMLList matchDescendantChildren(XMLList rv, XML target) {
/* 219 */     rv.setTargets(target, null);
/* 220 */     addDescendantChildren(rv, target);
/* 221 */     return rv;
/*     */   }
/*     */   
/*     */   void addDescendants(XMLList rv, XML target) {
/* 225 */     XMLName xmlName = this;
/* 226 */     if (xmlName.isAttributeName()) {
/* 227 */       matchDescendantAttributes(rv, target);
/*     */     } else {
/* 229 */       matchDescendantChildren(rv, target);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addAttributes(XMLList rv, XML target) {
/* 234 */     addMatchingAttributes(rv, target);
/*     */   }
/*     */   
/*     */   void addMatches(XMLList rv, XML target) {
/* 238 */     if (isDescendants()) {
/* 239 */       addDescendants(rv, target);
/* 240 */     } else if (isAttributeName()) {
/* 241 */       addAttributes(rv, target);
/*     */     } else {
/* 243 */       XML[] children = target.getChildren();
/* 244 */       if (children != null) {
/* 245 */         for (int i = 0; i < children.length; i++) {
/* 246 */           if (matches(children[i])) {
/* 247 */             rv.addToList(children[i]);
/*     */           }
/*     */         } 
/*     */       }
/* 251 */       rv.setTargets(target, toQname());
/*     */     } 
/*     */   }
/*     */   
/*     */   XMLList getMyValueOn(XML target) {
/* 256 */     XMLList rv = target.newXMLList();
/* 257 */     addMatches(rv, target);
/* 258 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   void setMyValueOn(XML target, Object value) {
/* 263 */     if (value == null) {
/* 264 */       value = "null";
/* 265 */     } else if (value instanceof Undefined) {
/* 266 */       value = "undefined";
/*     */     } 
/*     */     
/* 269 */     XMLName xmlName = this;
/*     */     
/* 271 */     if (xmlName.isAttributeName()) {
/* 272 */       target.setAttribute(xmlName, value);
/* 273 */     } else if (xmlName.uri() == null && xmlName.localName().equals("*")) {
/* 274 */       target.setChildren(value);
/*     */     } else {
/*     */       
/* 277 */       XMLObjectImpl xmlValue = null;
/*     */       
/* 279 */       if (value instanceof XMLObjectImpl) {
/* 280 */         xmlValue = (XMLObjectImpl)value;
/*     */ 
/*     */         
/* 283 */         if (xmlValue instanceof XML && (
/* 284 */           (XML)xmlValue).isAttribute()) {
/* 285 */           xmlValue = target.makeXmlFromString(xmlName, xmlValue
/* 286 */               .toString());
/*     */         }
/*     */ 
/*     */         
/* 290 */         if (xmlValue instanceof XMLList) {
/* 291 */           for (int i = 0; i < xmlValue.length(); i++) {
/* 292 */             XML xml = ((XMLList)xmlValue).item(i);
/*     */             
/* 294 */             if (xml.isAttribute()) {
/* 295 */               ((XMLList)xmlValue).replace(i, target.makeXmlFromString(xmlName, xml.toString()));
/*     */             }
/*     */           } 
/*     */         }
/*     */       } else {
/* 300 */         xmlValue = target.makeXmlFromString(xmlName, ScriptRuntime.toString(value));
/*     */       } 
/*     */       
/* 303 */       XMLList matches = target.getPropertyList(xmlName);
/*     */       
/* 305 */       if (matches.length() == 0) {
/* 306 */         target.appendChild(xmlValue);
/*     */       } else {
/*     */         
/* 309 */         for (int i = 1; i < matches.length(); i++) {
/* 310 */           target.removeChild(matches.item(i).childIndex());
/*     */         }
/*     */ 
/*     */         
/* 314 */         XML firstMatch = matches.item(0);
/* 315 */         target.replace(firstMatch.childIndex(), xmlValue);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(Context cx) {
/* 322 */     if (this.xmlObject == null) {
/* 323 */       return false;
/*     */     }
/* 325 */     return this.xmlObject.hasXMLProperty(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Context cx) {
/* 330 */     if (this.xmlObject == null) {
/* 331 */       throw ScriptRuntime.undefReadError(Undefined.instance, 
/* 332 */           toString());
/*     */     }
/* 334 */     return this.xmlObject.getXMLProperty(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object set(Context cx, Object value) {
/* 340 */     if (this.xmlObject == null) {
/* 341 */       throw ScriptRuntime.undefWriteError(Undefined.instance, 
/* 342 */           toString(), value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 347 */     if (this.isDescendants) throw Kit.codeBug(); 
/* 348 */     this.xmlObject.putXMLProperty(this, value);
/* 349 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean delete(Context cx) {
/* 354 */     if (this.xmlObject == null) {
/* 355 */       return true;
/*     */     }
/* 357 */     this.xmlObject.deleteXMLProperty(this);
/* 358 */     return !this.xmlObject.hasXMLProperty(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 364 */     StringBuilder buff = new StringBuilder();
/* 365 */     if (this.isDescendants) buff.append(".."); 
/* 366 */     if (this.isAttributeName) buff.append('@'); 
/* 367 */     if (uri() == null) {
/* 368 */       buff.append('*');
/* 369 */       if (localName().equals("*")) {
/* 370 */         return buff.toString();
/*     */       }
/*     */     } else {
/* 373 */       buff.append('"').append(uri()).append('"');
/*     */     } 
/* 375 */     buff.append(':').append(localName());
/* 376 */     return buff.toString();
/*     */   }
/*     */   
/*     */   final XmlNode.QName toQname() {
/* 380 */     return this.qname;
/*     */   }
/*     */   
/*     */   final boolean matchesLocalName(String localName) {
/* 384 */     return (localName().equals("*") || localName().equals(localName));
/*     */   }
/*     */   
/*     */   final boolean matchesElement(XmlNode.QName qname) {
/* 388 */     if ((uri() == null || uri().equals(qname.getNamespace().getUri())) && (
/* 389 */       localName().equals("*") || localName().equals(qname.getLocalName()))) {
/* 390 */       return true;
/*     */     }
/*     */     
/* 393 */     return false;
/*     */   }
/*     */   
/*     */   final boolean matches(XML node) {
/* 397 */     XmlNode.QName qname = node.getNodeQname();
/* 398 */     String nodeUri = null;
/* 399 */     if (qname.getNamespace() != null) {
/* 400 */       nodeUri = qname.getNamespace().getUri();
/*     */     }
/* 402 */     if (this.isAttributeName) {
/* 403 */       if (node.isAttribute()) {
/* 404 */         if ((uri() == null || uri().equals(nodeUri)) && (
/* 405 */           localName().equals("*") || localName().equals(qname.getLocalName()))) {
/* 406 */           return true;
/*     */         }
/*     */         
/* 409 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 413 */       return false;
/*     */     } 
/*     */     
/* 416 */     if (uri() == null || (node.isElement() && uri().equals(nodeUri))) {
/* 417 */       if (localName().equals("*")) return true; 
/* 418 */       if (node.isElement() && 
/* 419 */         localName().equals(qname.getLocalName())) return true;
/*     */     
/*     */     } 
/* 422 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isAttributeName() {
/* 428 */     return this.isAttributeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAttributeName() {
/* 435 */     this.isAttributeName = true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isDescendants() {
/* 440 */     return this.isDescendants;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   void setIsDescendants() {
/* 448 */     this.isDescendants = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XMLName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */