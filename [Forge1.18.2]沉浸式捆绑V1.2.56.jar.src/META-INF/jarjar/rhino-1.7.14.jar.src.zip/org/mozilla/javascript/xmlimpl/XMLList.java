/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.mozilla.javascript.Callable;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Function;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ import org.mozilla.javascript.xml.XMLObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XMLList
/*     */   extends XMLObjectImpl
/*     */   implements Function
/*     */ {
/*     */   static final long serialVersionUID = -4543618751670781135L;
/*     */   private XmlNode.InternalList _annos;
/*  24 */   private XMLObjectImpl targetObject = null;
/*  25 */   private XmlNode.QName targetProperty = null;
/*     */   
/*     */   XMLList(XMLLibImpl lib, Scriptable scope, XMLObject prototype) {
/*  28 */     super(lib, scope, prototype);
/*  29 */     this._annos = new XmlNode.InternalList();
/*     */   }
/*     */ 
/*     */   
/*     */   XmlNode.InternalList getNodeList() {
/*  34 */     return this._annos;
/*     */   }
/*     */ 
/*     */   
/*     */   void setTargets(XMLObjectImpl object, XmlNode.QName property) {
/*  39 */     this.targetObject = object;
/*  40 */     this.targetProperty = property;
/*     */   }
/*     */ 
/*     */   
/*     */   private XML getXmlFromAnnotation(int index) {
/*  45 */     return getXML(this._annos, index);
/*     */   }
/*     */ 
/*     */   
/*     */   XML getXML() {
/*  50 */     if (length() == 1) return getXmlFromAnnotation(0); 
/*  51 */     return null;
/*     */   }
/*     */   
/*     */   private void internalRemoveFromList(int index) {
/*  55 */     this._annos.remove(index);
/*     */   }
/*     */   
/*     */   void replace(int index, XML xml) {
/*  59 */     if (index < length()) {
/*  60 */       XmlNode.InternalList newAnnoList = new XmlNode.InternalList();
/*  61 */       newAnnoList.add(this._annos, 0, index);
/*  62 */       newAnnoList.add(xml);
/*  63 */       newAnnoList.add(this._annos, index + 1, length());
/*  64 */       this._annos = newAnnoList;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void insert(int index, XML xml) {
/*  69 */     if (index < length()) {
/*  70 */       XmlNode.InternalList newAnnoList = new XmlNode.InternalList();
/*  71 */       newAnnoList.add(this._annos, 0, index);
/*  72 */       newAnnoList.add(xml);
/*  73 */       newAnnoList.add(this._annos, index, length());
/*  74 */       this._annos = newAnnoList;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  86 */     return "XMLList";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/*  99 */     if (index >= 0 && index < length()) {
/* 100 */       return getXmlFromAnnotation(index);
/*     */     }
/* 102 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasXMLProperty(XMLName xmlName) {
/* 109 */     return (getPropertyList(xmlName).length() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/* 114 */     return (0 <= index && index < length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void putXMLProperty(XMLName xmlName, Object value) {
/* 122 */     if (value == null) {
/* 123 */       value = "null";
/* 124 */     } else if (value instanceof Undefined) {
/* 125 */       value = "undefined";
/*     */     } 
/*     */     
/* 128 */     if (length() > 1) {
/* 129 */       throw ScriptRuntime.typeError("Assignment to lists with more than one item is not supported");
/*     */     }
/* 131 */     if (length() == 0) {
/*     */ 
/*     */       
/* 134 */       if (this.targetObject != null && this.targetProperty != null && this.targetProperty
/* 135 */         .getLocalName() != null && this.targetProperty
/* 136 */         .getLocalName().length() > 0) {
/*     */ 
/*     */ 
/*     */         
/* 140 */         XML xmlValue = newTextElementXML(null, this.targetProperty, null);
/* 141 */         addToList(xmlValue);
/*     */         
/* 143 */         if (xmlName.isAttributeName()) {
/* 144 */           setAttribute(xmlName, value);
/*     */         } else {
/* 146 */           XML xml = item(0);
/* 147 */           xml.putXMLProperty(xmlName, value);
/*     */ 
/*     */           
/* 150 */           replace(0, item(0));
/*     */         } 
/*     */ 
/*     */         
/* 154 */         XMLName name2 = XMLName.formProperty(this.targetProperty
/* 155 */             .getNamespace().getUri(), this.targetProperty
/* 156 */             .getLocalName());
/* 157 */         this.targetObject.putXMLProperty(name2, this);
/* 158 */         replace(0, this.targetObject.getXML().getLastXmlChild());
/*     */       } else {
/* 160 */         throw ScriptRuntime.typeError("Assignment to empty XMLList without targets not supported");
/*     */       }
/*     */     
/* 163 */     } else if (xmlName.isAttributeName()) {
/* 164 */       setAttribute(xmlName, value);
/*     */     } else {
/* 166 */       XML xml = item(0);
/* 167 */       xml.putXMLProperty(xmlName, value);
/*     */ 
/*     */       
/* 170 */       replace(0, item(0));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   Object getXMLProperty(XMLName name) {
/* 176 */     return getPropertyList(name);
/*     */   }
/*     */   
/*     */   private void replaceNode(XML xml, XML with) {
/* 180 */     xml.replaceWith(with);
/*     */   }
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/*     */     XMLObject xmlValue;
/* 185 */     Object parent = Undefined.instance;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     if (value == null) {
/* 191 */       value = "null";
/* 192 */     } else if (value instanceof Undefined) {
/* 193 */       value = "undefined";
/*     */     } 
/*     */     
/* 196 */     if (value instanceof XMLObject) {
/* 197 */       xmlValue = (XMLObject)value;
/*     */     }
/* 199 */     else if (this.targetProperty == null) {
/* 200 */       xmlValue = newXMLFromJs(value.toString());
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 206 */       xmlValue = item(index);
/* 207 */       if (xmlValue == null) {
/* 208 */         XML x = item(0);
/*     */ 
/*     */         
/* 211 */         xmlValue = (x == null) ? newTextElementXML(null, this.targetProperty, null) : x.copy();
/*     */       } 
/* 213 */       ((XML)xmlValue).setChildren(value);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 218 */     if (index < length()) {
/* 219 */       parent = item(index).parent();
/* 220 */     } else if (length() == 0) {
/* 221 */       parent = (this.targetObject != null) ? this.targetObject.getXML() : parent();
/*     */     } else {
/*     */       
/* 224 */       parent = parent();
/*     */     } 
/*     */     
/* 227 */     if (parent instanceof XML) {
/*     */       
/* 229 */       XML xmlParent = (XML)parent;
/*     */       
/* 231 */       if (index < length()) {
/*     */         
/* 233 */         XML xmlNode = getXmlFromAnnotation(index);
/*     */         
/* 235 */         if (xmlValue instanceof XML) {
/* 236 */           replaceNode(xmlNode, (XML)xmlValue);
/* 237 */           replace(index, xmlNode);
/* 238 */         } else if (xmlValue instanceof XMLList) {
/*     */           
/* 240 */           XMLList list = (XMLList)xmlValue;
/*     */           
/* 242 */           if (list.length() > 0) {
/* 243 */             int lastIndexAdded = xmlNode.childIndex();
/* 244 */             replaceNode(xmlNode, list.item(0));
/* 245 */             replace(index, list.item(0));
/*     */             
/* 247 */             for (int i = 1; i < list.length(); i++) {
/* 248 */               xmlParent.insertChildAfter(xmlParent.getXmlChild(lastIndexAdded), list.item(i));
/* 249 */               lastIndexAdded++;
/* 250 */               insert(index + i, list.item(i));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 256 */         xmlParent.appendChild(xmlValue);
/* 257 */         addToList(xmlParent.getLastXmlChild());
/*     */       }
/*     */     
/*     */     }
/* 261 */     else if (index < length()) {
/* 262 */       XML xmlNode = getXML(this._annos, index);
/*     */       
/* 264 */       if (xmlValue instanceof XML) {
/* 265 */         replaceNode(xmlNode, (XML)xmlValue);
/* 266 */         replace(index, xmlNode);
/* 267 */       } else if (xmlValue instanceof XMLList) {
/*     */         
/* 269 */         XMLList list = (XMLList)xmlValue;
/*     */         
/* 271 */         if (list.length() > 0) {
/* 272 */           replaceNode(xmlNode, list.item(0));
/* 273 */           replace(index, list.item(0));
/*     */           
/* 275 */           for (int i = 1; i < list.length(); i++) {
/* 276 */             insert(index + i, list.item(i));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/* 281 */       addToList(xmlValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private XML getXML(XmlNode.InternalList _annos, int index) {
/* 287 */     if (index >= 0 && index < length()) {
/* 288 */       return xmlFromNode(_annos.item(index));
/*     */     }
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void deleteXMLProperty(XMLName name) {
/* 296 */     for (int i = 0; i < length(); i++) {
/* 297 */       XML xml = getXmlFromAnnotation(i);
/*     */       
/* 299 */       if (xml.isElement()) {
/* 300 */         xml.deleteXMLProperty(name);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(int index) {
/* 307 */     if (index >= 0 && index < length()) {
/* 308 */       XML xml = getXmlFromAnnotation(index);
/*     */       
/* 310 */       xml.remove();
/*     */       
/* 312 */       internalRemoveFromList(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/*     */     Object[] enumObjs;
/* 320 */     if (isPrototype()) {
/* 321 */       enumObjs = new Object[0];
/*     */     } else {
/* 323 */       enumObjs = new Object[length()];
/*     */       
/* 325 */       for (int i = 0; i < enumObjs.length; i++) {
/* 326 */         enumObjs[i] = Integer.valueOf(i);
/*     */       }
/*     */     } 
/*     */     
/* 330 */     return enumObjs;
/*     */   }
/*     */   
/*     */   public Object[] getIdsForDebug() {
/* 334 */     return getIds();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void remove() {
/* 340 */     int nLen = length();
/* 341 */     for (int i = nLen - 1; i >= 0; i--) {
/* 342 */       XML xml = getXmlFromAnnotation(i);
/* 343 */       if (xml != null) {
/* 344 */         xml.remove();
/* 345 */         internalRemoveFromList(i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   XML item(int index) {
/* 351 */     return (this._annos != null) ? 
/* 352 */       getXmlFromAnnotation(index) : createEmptyXML();
/*     */   }
/*     */   
/*     */   private void setAttribute(XMLName xmlName, Object value) {
/* 356 */     for (int i = 0; i < length(); i++) {
/* 357 */       XML xml = getXmlFromAnnotation(i);
/* 358 */       xml.setAttribute(xmlName, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   void addToList(Object toAdd) {
/* 363 */     this._annos.addToList(toAdd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XMLList child(int index) {
/* 374 */     XMLList result = newXMLList();
/*     */     
/* 376 */     for (int i = 0; i < length(); i++) {
/* 377 */       result.addToList(getXmlFromAnnotation(i).child(index));
/*     */     }
/*     */     
/* 380 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList child(XMLName xmlName) {
/* 385 */     XMLList result = newXMLList();
/*     */     
/* 387 */     for (int i = 0; i < length(); i++) {
/* 388 */       result.addToList(getXmlFromAnnotation(i).child(xmlName));
/*     */     }
/*     */     
/* 391 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void addMatches(XMLList rv, XMLName name) {
/* 396 */     for (int i = 0; i < length(); i++) {
/* 397 */       getXmlFromAnnotation(i).addMatches(rv, name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList children() {
/* 403 */     ArrayList<XML> list = new ArrayList<>();
/*     */     
/* 405 */     for (int i = 0; i < length(); i++) {
/* 406 */       XML xml = getXmlFromAnnotation(i);
/*     */       
/* 408 */       if (xml != null) {
/* 409 */         XMLList childList = xml.children();
/*     */         
/* 411 */         int cChildren = childList.length();
/* 412 */         for (int k = 0; k < cChildren; k++) {
/* 413 */           list.add(childList.item(k));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 418 */     XMLList allChildren = newXMLList();
/* 419 */     int sz = list.size();
/*     */     
/* 421 */     for (int j = 0; j < sz; j++) {
/* 422 */       allChildren.addToList(list.get(j));
/*     */     }
/*     */     
/* 425 */     return allChildren;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList comments() {
/* 430 */     XMLList result = newXMLList();
/*     */     
/* 432 */     for (int i = 0; i < length(); i++) {
/* 433 */       XML xml = getXmlFromAnnotation(i);
/* 434 */       result.addToList(xml.comments());
/*     */     } 
/*     */     
/* 437 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList elements(XMLName name) {
/* 442 */     XMLList rv = newXMLList();
/* 443 */     for (int i = 0; i < length(); i++) {
/* 444 */       XML xml = getXmlFromAnnotation(i);
/* 445 */       rv.addToList(xml.elements(name));
/*     */     } 
/* 447 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean contains(Object xml) {
/* 452 */     boolean result = false;
/*     */     
/* 454 */     for (int i = 0; i < length(); i++) {
/* 455 */       XML member = getXmlFromAnnotation(i);
/*     */       
/* 457 */       if (member.equivalentXml(xml)) {
/* 458 */         result = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 463 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLObjectImpl copy() {
/* 468 */     XMLList result = newXMLList();
/*     */     
/* 470 */     for (int i = 0; i < length(); i++) {
/* 471 */       XML xml = getXmlFromAnnotation(i);
/* 472 */       result.addToList(xml.copy());
/*     */     } 
/*     */     
/* 475 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean hasOwnProperty(XMLName xmlName) {
/* 480 */     if (isPrototype()) {
/* 481 */       String property = xmlName.localName();
/* 482 */       return (findPrototypeId(property) != 0);
/*     */     } 
/* 484 */     return (getPropertyList(xmlName).length() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasComplexContent() {
/*     */     boolean complexContent;
/* 491 */     int length = length();
/*     */     
/* 493 */     if (length == 0) {
/* 494 */       complexContent = false;
/* 495 */     } else if (length == 1) {
/* 496 */       complexContent = getXmlFromAnnotation(0).hasComplexContent();
/*     */     } else {
/* 498 */       complexContent = false;
/*     */       
/* 500 */       for (int i = 0; i < length; i++) {
/* 501 */         XML nextElement = getXmlFromAnnotation(i);
/* 502 */         if (nextElement.isElement()) {
/* 503 */           complexContent = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 509 */     return complexContent;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean hasSimpleContent() {
/* 514 */     if (length() == 0)
/* 515 */       return true; 
/* 516 */     if (length() == 1) {
/* 517 */       return getXmlFromAnnotation(0).hasSimpleContent();
/*     */     }
/* 519 */     for (int i = 0; i < length(); i++) {
/* 520 */       XML nextElement = getXmlFromAnnotation(i);
/* 521 */       if (nextElement.isElement()) {
/* 522 */         return false;
/*     */       }
/*     */     } 
/* 525 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int length() {
/* 531 */     int result = 0;
/*     */     
/* 533 */     if (this._annos != null) {
/* 534 */       result = this._annos.length();
/*     */     }
/*     */     
/* 537 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void normalize() {
/* 542 */     for (int i = 0; i < length(); i++) {
/* 543 */       getXmlFromAnnotation(i).normalize();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object parent() {
/* 553 */     if (length() == 0) return Undefined.instance;
/*     */     
/* 555 */     XML candidateParent = null;
/*     */     
/* 557 */     for (int i = 0; i < length(); i++) {
/* 558 */       Object currParent = getXmlFromAnnotation(i).parent();
/* 559 */       if (!(currParent instanceof XML)) return Undefined.instance; 
/* 560 */       XML xml = (XML)currParent;
/* 561 */       if (i == 0) {
/*     */         
/* 563 */         candidateParent = xml;
/*     */       }
/* 565 */       else if (!candidateParent.is(xml)) {
/*     */ 
/*     */         
/* 568 */         return Undefined.instance;
/*     */       } 
/*     */     } 
/*     */     
/* 572 */     return candidateParent;
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList processingInstructions(XMLName xmlName) {
/* 577 */     XMLList result = newXMLList();
/*     */     
/* 579 */     for (int i = 0; i < length(); i++) {
/* 580 */       XML xml = getXmlFromAnnotation(i);
/*     */       
/* 582 */       result.addToList(xml.processingInstructions(xmlName));
/*     */     } 
/*     */     
/* 585 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean propertyIsEnumerable(Object name) {
/*     */     long index;
/* 591 */     if (name instanceof Integer) {
/* 592 */       index = ((Integer)name).intValue();
/* 593 */     } else if (name instanceof Number) {
/* 594 */       double x = ((Number)name).doubleValue();
/* 595 */       index = (long)x;
/* 596 */       if (index != x) {
/* 597 */         return false;
/*     */       }
/* 599 */       if (index == 0L && 1.0D / x < 0.0D)
/*     */       {
/* 601 */         return false;
/*     */       }
/*     */     } else {
/* 604 */       String s = ScriptRuntime.toString(name);
/* 605 */       index = ScriptRuntime.testUint32String(s);
/*     */     } 
/* 607 */     return (0L <= index && index < length());
/*     */   }
/*     */ 
/*     */   
/*     */   XMLList text() {
/* 612 */     XMLList result = newXMLList();
/*     */     
/* 614 */     for (int i = 0; i < length(); i++) {
/* 615 */       result.addToList(getXmlFromAnnotation(i).text());
/*     */     }
/*     */     
/* 618 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 624 */     if (hasSimpleContent()) {
/* 625 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 627 */       for (int i = 0; i < length(); i++) {
/* 628 */         XML next = getXmlFromAnnotation(i);
/* 629 */         if (!next.isComment() && !next.isProcessingInstruction())
/*     */         {
/*     */           
/* 632 */           sb.append(next.toString());
/*     */         }
/*     */       } 
/*     */       
/* 636 */       return sb.toString();
/*     */     } 
/* 638 */     return toXMLString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String toSource(int indent) {
/* 644 */     return toXMLString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String toXMLString() {
/* 650 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 652 */     for (int i = 0; i < length(); i++) {
/* 653 */       if (getProcessor().isPrettyPrinting() && i != 0) {
/* 654 */         sb.append('\n');
/*     */       }
/* 656 */       sb.append(getXmlFromAnnotation(i).toXMLString());
/*     */     } 
/* 658 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   Object valueOf() {
/* 663 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean equivalentXml(Object target) {
/* 672 */     boolean result = false;
/*     */ 
/*     */     
/* 675 */     if (target instanceof Undefined && length() == 0) {
/* 676 */       result = true;
/* 677 */     } else if (length() == 1) {
/* 678 */       result = getXmlFromAnnotation(0).equivalentXml(target);
/* 679 */     } else if (target instanceof XMLList) {
/* 680 */       XMLList otherList = (XMLList)target;
/*     */       
/* 682 */       if (otherList.length() == length()) {
/* 683 */         result = true;
/*     */         
/* 685 */         for (int i = 0; i < length(); i++) {
/* 686 */           if (!getXmlFromAnnotation(i).equivalentXml(otherList.getXmlFromAnnotation(i))) {
/* 687 */             result = false;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 694 */     return result;
/*     */   }
/*     */   
/*     */   private XMLList getPropertyList(XMLName name) {
/* 698 */     XMLList propertyList = newXMLList();
/* 699 */     XmlNode.QName qname = null;
/*     */     
/* 701 */     if (!name.isDescendants() && !name.isAttributeName())
/*     */     {
/*     */       
/* 704 */       qname = name.toQname();
/*     */     }
/*     */     
/* 707 */     propertyList.setTargets(this, qname);
/*     */     
/* 709 */     for (int i = 0; i < length(); i++) {
/* 710 */       propertyList.addToList(
/* 711 */           getXmlFromAnnotation(i).getPropertyList(name));
/*     */     }
/*     */     
/* 714 */     return propertyList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object applyOrCall(boolean isApply, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 720 */     String methodName = isApply ? "apply" : "call";
/* 721 */     if (!(thisObj instanceof XMLList) || ((XMLList)thisObj).targetProperty == null)
/*     */     {
/* 723 */       throw ScriptRuntime.typeErrorById("msg.isnt.function", new Object[] { methodName });
/*     */     }
/*     */     
/* 726 */     return ScriptRuntime.applyOrCall(isApply, cx, scope, thisObj, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object jsConstructor(Context cx, boolean inNewExpr, Object[] args) {
/* 733 */     if (args.length == 0) {
/* 734 */       return newXMLList();
/*     */     }
/* 736 */     Object arg0 = args[0];
/* 737 */     if (!inNewExpr && arg0 instanceof XMLList)
/*     */     {
/* 739 */       return arg0;
/*     */     }
/* 741 */     return newXMLListFrom(arg0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getExtraMethodSource(Context cx) {
/* 750 */     if (length() == 1) {
/* 751 */       return (Scriptable)getXmlFromAnnotation(0);
/*     */     }
/* 753 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 760 */     if (this.targetProperty == null) {
/* 761 */       throw ScriptRuntime.notFunctionError(this);
/*     */     }
/* 763 */     String methodName = this.targetProperty.getLocalName();
/*     */     
/* 765 */     boolean isApply = methodName.equals("apply");
/* 766 */     if (isApply || methodName.equals("call")) {
/* 767 */       return applyOrCall(isApply, cx, scope, thisObj, args);
/*     */     }
/* 769 */     if (!(thisObj instanceof XMLObject)) {
/* 770 */       throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { methodName });
/*     */     }
/* 772 */     Object func = null;
/* 773 */     Scriptable sobj = thisObj;
/*     */     
/* 775 */     while (sobj instanceof XMLObject) {
/* 776 */       XMLObject xmlObject = (XMLObject)sobj;
/* 777 */       func = xmlObject.getFunctionProperty(cx, methodName);
/* 778 */       if (func != Scriptable.NOT_FOUND) {
/*     */         break;
/*     */       }
/* 781 */       sobj = xmlObject.getExtraMethodSource(cx);
/* 782 */       if (sobj != null) {
/* 783 */         thisObj = sobj;
/* 784 */         if (!(sobj instanceof XMLObject)) {
/* 785 */           func = ScriptableObject.getProperty(sobj, methodName);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 790 */     if (!(func instanceof Callable)) {
/* 791 */       throw ScriptRuntime.notFunctionError(thisObj, func, methodName);
/*     */     }
/* 793 */     return ((Callable)func).call(cx, scope, thisObj, args);
/*     */   }
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/* 797 */     throw ScriptRuntime.typeErrorById("msg.not.ctor", new Object[] { "XMLList" });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XMLList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */