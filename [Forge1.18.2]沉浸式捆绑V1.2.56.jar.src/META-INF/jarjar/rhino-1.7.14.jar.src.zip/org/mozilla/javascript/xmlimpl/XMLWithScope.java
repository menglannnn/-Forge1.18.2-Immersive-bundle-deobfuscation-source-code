/*    */ package org.mozilla.javascript.xmlimpl;
/*    */ 
/*    */ import org.mozilla.javascript.NativeWith;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ import org.mozilla.javascript.xml.XMLObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XMLWithScope
/*    */   extends NativeWith
/*    */ {
/*    */   private static final long serialVersionUID = -696429282095170887L;
/*    */   private XMLLibImpl lib;
/*    */   private int _currIndex;
/*    */   private XMLList _xmlList;
/*    */   private XMLObject _dqPrototype;
/*    */   
/*    */   XMLWithScope(XMLLibImpl lib, Scriptable parent, XMLObject prototype) {
/* 24 */     super(parent, (Scriptable)prototype);
/* 25 */     this.lib = lib;
/*    */   }
/*    */ 
/*    */   
/*    */   void initAsDotQuery() {
/* 30 */     XMLObject prototype = (XMLObject)getPrototype();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 38 */     this._currIndex = 0;
/* 39 */     this._dqPrototype = prototype;
/* 40 */     if (prototype instanceof XMLList) {
/* 41 */       XMLList xl = (XMLList)prototype;
/* 42 */       if (xl.length() > 0) {
/* 43 */         setPrototype((Scriptable)xl.get(0, null));
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 48 */     this._xmlList = this.lib.newXMLList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object updateDotQuery(boolean value) {
/* 56 */     XMLObject seed = this._dqPrototype;
/* 57 */     XMLList xmlL = this._xmlList;
/*    */     
/* 59 */     if (seed instanceof XMLList) {
/*    */ 
/*    */ 
/*    */       
/* 63 */       XMLList orgXmlL = (XMLList)seed;
/*    */       
/* 65 */       int idx = this._currIndex;
/*    */       
/* 67 */       if (value) {
/* 68 */         xmlL.addToList(orgXmlL.get(idx, null));
/*    */       }
/*    */ 
/*    */       
/* 72 */       if (++idx < orgXmlL.length())
/*    */       {
/*    */ 
/*    */         
/* 76 */         this._currIndex = idx;
/* 77 */         setPrototype((Scriptable)orgXmlL.get(idx, null));
/*    */ 
/*    */         
/* 80 */         return null;
/*    */       
/*    */       }
/*    */     
/*    */     }
/* 85 */     else if (value) {
/* 86 */       xmlL.addToList(seed);
/*    */     } 
/*    */ 
/*    */     
/* 90 */     return xmlL;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XMLWithScope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */