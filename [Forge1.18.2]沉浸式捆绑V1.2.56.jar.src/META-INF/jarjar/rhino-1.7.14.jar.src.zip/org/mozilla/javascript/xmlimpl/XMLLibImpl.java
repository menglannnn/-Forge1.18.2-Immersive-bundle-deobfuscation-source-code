/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Kit;
/*     */ import org.mozilla.javascript.Ref;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ import org.mozilla.javascript.Wrapper;
/*     */ import org.mozilla.javascript.xml.XMLLib;
/*     */ import org.mozilla.javascript.xml.XMLObject;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLLibImpl
/*     */   extends XMLLib
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Scriptable globalScope;
/*     */   private XML xmlPrototype;
/*     */   private XMLList xmlListPrototype;
/*     */   private Namespace namespacePrototype;
/*     */   private QName qnamePrototype;
/*     */   
/*     */   public static Node toDomNode(Object xmlObject) {
/*  37 */     if (xmlObject instanceof XML) {
/*  38 */       return ((XML)xmlObject).toDomNode();
/*     */     }
/*  40 */     throw new IllegalArgumentException("xmlObject is not an XML object in JavaScript.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  46 */     XMLLibImpl lib = new XMLLibImpl(scope);
/*  47 */     XMLLib bound = lib.bindToScope(scope);
/*  48 */     if (bound == lib) {
/*  49 */       lib.exportToScope(sealed);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIgnoreComments(boolean b) {
/*  55 */     this.options.setIgnoreComments(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIgnoreWhitespace(boolean b) {
/*  60 */     this.options.setIgnoreWhitespace(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIgnoreProcessingInstructions(boolean b) {
/*  65 */     this.options.setIgnoreProcessingInstructions(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrettyPrinting(boolean b) {
/*  70 */     this.options.setPrettyPrinting(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrettyIndent(int i) {
/*  75 */     this.options.setPrettyIndent(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIgnoreComments() {
/*  80 */     return this.options.isIgnoreComments();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIgnoreProcessingInstructions() {
/*  85 */     return this.options.isIgnoreProcessingInstructions();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIgnoreWhitespace() {
/*  90 */     return this.options.isIgnoreWhitespace();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrettyPrinting() {
/*  95 */     return this.options.isPrettyPrinting();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrettyIndent() {
/* 100 */     return this.options.getPrettyIndent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private XmlProcessor options = new XmlProcessor();
/*     */   
/*     */   private XMLLibImpl(Scriptable globalScope) {
/* 114 */     this.globalScope = globalScope;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   QName qnamePrototype() {
/* 120 */     return this.qnamePrototype;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   Scriptable globalScope() {
/* 126 */     return this.globalScope;
/*     */   }
/*     */   
/*     */   XmlProcessor getProcessor() {
/* 130 */     return this.options;
/*     */   }
/*     */   
/*     */   private void exportToScope(boolean sealed) {
/* 134 */     this.xmlPrototype = newXML(XmlNode.createText(this.options, ""));
/* 135 */     this.xmlListPrototype = newXMLList();
/* 136 */     this.namespacePrototype = Namespace.create(this.globalScope, null, XmlNode.Namespace.GLOBAL);
/*     */     
/* 138 */     this.qnamePrototype = QName.create(this, this.globalScope, null, 
/* 139 */         XmlNode.QName.create(XmlNode.Namespace.create(""), ""));
/*     */     
/* 141 */     this.xmlPrototype.exportAsJSClass(sealed);
/* 142 */     this.xmlListPrototype.exportAsJSClass(sealed);
/* 143 */     this.namespacePrototype.exportAsJSClass(sealed);
/* 144 */     this.qnamePrototype.exportAsJSClass(sealed);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   XMLName toAttributeName(Context cx, Object nameValue) {
/* 150 */     if (nameValue instanceof XMLName)
/*     */     {
/* 152 */       return (XMLName)nameValue; } 
/* 153 */     if (nameValue instanceof QName)
/* 154 */       return XMLName.create(((QName)nameValue).getDelegate(), true, false); 
/* 155 */     if (nameValue instanceof Boolean || nameValue instanceof Number || nameValue == Undefined.instance || nameValue == null)
/*     */     {
/*     */ 
/*     */       
/* 159 */       throw badXMLName(nameValue);
/*     */     }
/*     */     
/* 162 */     String localName = null;
/* 163 */     if (nameValue instanceof String) {
/* 164 */       localName = (String)nameValue;
/*     */     } else {
/* 166 */       localName = ScriptRuntime.toString(nameValue);
/*     */     } 
/* 168 */     if (localName != null && localName.equals("*")) localName = null; 
/* 169 */     return XMLName.create(XmlNode.QName.create(
/* 170 */           XmlNode.Namespace.create(""), localName), true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static RuntimeException badXMLName(Object value) {
/*     */     String msg;
/* 177 */     if (value instanceof Number) {
/* 178 */       msg = "Can not construct XML name from number: ";
/* 179 */     } else if (value instanceof Boolean) {
/* 180 */       msg = "Can not construct XML name from boolean: ";
/* 181 */     } else if (value == Undefined.instance || value == null) {
/* 182 */       msg = "Can not construct XML name from ";
/*     */     } else {
/* 184 */       throw new IllegalArgumentException(value.toString());
/*     */     } 
/* 186 */     return (RuntimeException)ScriptRuntime.typeError(msg + ScriptRuntime.toString(value));
/*     */   }
/*     */   
/*     */   XMLName toXMLNameFromString(Context cx, String name) {
/* 190 */     return XMLName.create(getDefaultNamespaceURI(cx), name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XMLName toXMLName(Context cx, Object nameValue) {
/*     */     XMLName result;
/* 197 */     if (nameValue instanceof XMLName)
/* 198 */     { result = (XMLName)nameValue; }
/* 199 */     else if (nameValue instanceof QName)
/* 200 */     { QName qname = (QName)nameValue;
/* 201 */       result = XMLName.formProperty(qname.uri(), qname.localName()); }
/* 202 */     else if (nameValue instanceof String)
/* 203 */     { result = toXMLNameFromString(cx, (String)nameValue); }
/* 204 */     else { if (nameValue instanceof Boolean || nameValue instanceof Number || nameValue == Undefined.instance || nameValue == null)
/*     */       {
/*     */ 
/*     */         
/* 208 */         throw badXMLName(nameValue);
/*     */       }
/* 210 */       String name = ScriptRuntime.toString(nameValue);
/* 211 */       result = toXMLNameFromString(cx, name); }
/*     */ 
/*     */     
/* 214 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XMLName toXMLNameOrIndex(Context cx, Object value) {
/*     */     XMLName result;
/* 226 */     if (value instanceof XMLName) {
/* 227 */       result = (XMLName)value;
/* 228 */     } else if (value instanceof String) {
/* 229 */       String str = (String)value;
/* 230 */       long test = ScriptRuntime.testUint32String(str);
/* 231 */       if (test >= 0L) {
/* 232 */         ScriptRuntime.storeUint32Result(cx, test);
/* 233 */         result = null;
/*     */       } else {
/* 235 */         result = toXMLNameFromString(cx, str);
/*     */       } 
/* 237 */     } else if (value instanceof Number) {
/* 238 */       double d = ((Number)value).doubleValue();
/* 239 */       long l = (long)d;
/* 240 */       if (l == d && 0L <= l && l <= 4294967295L) {
/* 241 */         ScriptRuntime.storeUint32Result(cx, l);
/* 242 */         result = null;
/*     */       } else {
/* 244 */         throw badXMLName(value);
/*     */       } 
/* 246 */     } else if (value instanceof QName) {
/* 247 */       QName qname = (QName)value;
/* 248 */       String uri = qname.uri();
/* 249 */       boolean number = false;
/* 250 */       result = null;
/* 251 */       if (uri != null && uri.length() == 0) {
/*     */         
/* 253 */         long test = ScriptRuntime.testUint32String(uri);
/* 254 */         if (test >= 0L) {
/* 255 */           ScriptRuntime.storeUint32Result(cx, test);
/* 256 */           number = true;
/*     */         } 
/*     */       } 
/* 259 */       if (!number)
/* 260 */         result = XMLName.formProperty(uri, qname.localName()); 
/*     */     } else {
/* 262 */       if (value instanceof Boolean || value == Undefined.instance || value == null)
/*     */       {
/*     */ 
/*     */         
/* 266 */         throw badXMLName(value);
/*     */       }
/* 268 */       String str = ScriptRuntime.toString(value);
/* 269 */       long test = ScriptRuntime.testUint32String(str);
/* 270 */       if (test >= 0L) {
/* 271 */         ScriptRuntime.storeUint32Result(cx, test);
/* 272 */         result = null;
/*     */       } else {
/* 274 */         result = toXMLNameFromString(cx, str);
/*     */       } 
/*     */     } 
/*     */     
/* 278 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   Object addXMLObjects(Context cx, XMLObject obj1, XMLObject obj2) {
/* 283 */     XMLList listToAdd = newXMLList();
/*     */     
/* 285 */     if (obj1 instanceof XMLList) {
/* 286 */       XMLList list1 = (XMLList)obj1;
/* 287 */       if (list1.length() == 1) {
/* 288 */         listToAdd.addToList(list1.item(0));
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 293 */         listToAdd = newXMLListFrom(obj1);
/*     */       } 
/*     */     } else {
/* 296 */       listToAdd.addToList(obj1);
/*     */     } 
/*     */     
/* 299 */     if (obj2 instanceof XMLList) {
/* 300 */       XMLList list2 = (XMLList)obj2;
/* 301 */       for (int i = 0; i < list2.length(); i++) {
/* 302 */         listToAdd.addToList(list2.item(i));
/*     */       }
/* 304 */     } else if (obj2 instanceof XML) {
/* 305 */       listToAdd.addToList(obj2);
/*     */     } 
/*     */     
/* 308 */     return listToAdd;
/*     */   }
/*     */ 
/*     */   
/*     */   private Ref xmlPrimaryReference(Context cx, XMLName xmlName, Scriptable scope) {
/* 313 */     XMLObjectImpl xmlObj, firstXml = null;
/*     */ 
/*     */     
/*     */     while (true) {
/* 317 */       if (scope instanceof XMLWithScope) {
/* 318 */         xmlObj = (XMLObjectImpl)scope.getPrototype();
/* 319 */         if (xmlObj.hasXMLProperty(xmlName)) {
/*     */           break;
/*     */         }
/* 322 */         if (firstXml == null) {
/* 323 */           firstXml = xmlObj;
/*     */         }
/*     */       } 
/* 326 */       scope = scope.getParentScope();
/* 327 */       if (scope == null) {
/* 328 */         xmlObj = firstXml;
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 335 */     if (xmlObj != null) {
/* 336 */       xmlName.initXMLObject(xmlObj);
/*     */     }
/* 338 */     return xmlName;
/*     */   }
/*     */   
/*     */   Namespace castToNamespace(Context cx, Object namespaceObj) {
/* 342 */     return this.namespacePrototype.castToNamespace(namespaceObj);
/*     */   }
/*     */   
/*     */   private String getDefaultNamespaceURI(Context cx) {
/* 346 */     return getDefaultNamespace(cx).uri();
/*     */   }
/*     */   
/*     */   Namespace newNamespace(String uri) {
/* 350 */     return this.namespacePrototype.newNamespace(uri);
/*     */   }
/*     */   
/*     */   Namespace getDefaultNamespace(Context cx) {
/* 354 */     if (cx == null) {
/* 355 */       cx = Context.getCurrentContext();
/* 356 */       if (cx == null) {
/* 357 */         return this.namespacePrototype;
/*     */       }
/*     */     } 
/*     */     
/* 361 */     Object ns = ScriptRuntime.searchDefaultNamespace(cx);
/* 362 */     if (ns == null) {
/* 363 */       return this.namespacePrototype;
/*     */     }
/* 365 */     if (ns instanceof Namespace) {
/* 366 */       return (Namespace)ns;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 371 */     return this.namespacePrototype;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Namespace[] createNamespaces(XmlNode.Namespace[] declarations) {
/* 377 */     Namespace[] rv = new Namespace[declarations.length];
/* 378 */     for (int i = 0; i < declarations.length; i++) {
/* 379 */       rv[i] = this.namespacePrototype.newNamespace(declarations[i]
/* 380 */           .getPrefix(), declarations[i].getUri());
/*     */     }
/* 382 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   QName constructQName(Context cx, Object namespace, Object name) {
/* 387 */     return this.qnamePrototype.constructQName(this, cx, namespace, name);
/*     */   }
/*     */   
/*     */   QName newQName(String uri, String localName, String prefix) {
/* 391 */     return this.qnamePrototype.newQName(this, uri, localName, prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   QName constructQName(Context cx, Object nameValue) {
/* 396 */     return this.qnamePrototype.constructQName(this, cx, nameValue);
/*     */   }
/*     */   
/*     */   QName castToQName(Context cx, Object qnameValue) {
/* 400 */     return this.qnamePrototype.castToQName(this, cx, qnameValue);
/*     */   }
/*     */   
/*     */   QName newQName(XmlNode.QName qname) {
/* 404 */     return QName.create(this, this.globalScope, this.qnamePrototype, qname);
/*     */   }
/*     */   
/*     */   XML newXML(XmlNode node) {
/* 408 */     return new XML(this, this.globalScope, this.xmlPrototype, node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final XML newXMLFromJs(Object inputObject) {
/*     */     String frag;
/* 416 */     if (inputObject == null || inputObject == Undefined.instance) {
/* 417 */       frag = "";
/* 418 */     } else if (inputObject instanceof XMLObjectImpl) {
/*     */       
/* 420 */       frag = ((XMLObjectImpl)inputObject).toXMLString();
/*     */     } else {
/* 422 */       frag = ScriptRuntime.toString(inputObject);
/*     */     } 
/*     */     
/* 425 */     if (frag.trim().startsWith("<>")) {
/* 426 */       throw ScriptRuntime.typeError("Invalid use of XML object anonymous tags <></>.");
/*     */     }
/*     */     
/* 429 */     if (frag.indexOf("<") == -1)
/*     */     {
/* 431 */       return newXML(XmlNode.createText(this.options, frag));
/*     */     }
/* 433 */     return parse(frag);
/*     */   }
/*     */   
/*     */   private XML parse(String frag) {
/*     */     try {
/* 438 */       return newXML(XmlNode.createElement(this.options, 
/* 439 */             getDefaultNamespaceURI(Context.getCurrentContext()), frag));
/* 440 */     } catch (SAXException e) {
/* 441 */       throw ScriptRuntime.typeError("Cannot parse XML: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   final XML ecmaToXml(Object object) {
/* 447 */     if (object == null || object == Undefined.instance) {
/* 448 */       throw ScriptRuntime.typeError("Cannot convert " + object + " to XML");
/*     */     }
/* 450 */     if (object instanceof XML) return (XML)object; 
/* 451 */     if (object instanceof XMLList) {
/* 452 */       XMLList list = (XMLList)object;
/* 453 */       if (list.getXML() != null) {
/* 454 */         return list.getXML();
/*     */       }
/* 456 */       throw ScriptRuntime.typeError("Cannot convert list of >1 element to XML");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     if (object instanceof Wrapper) {
/* 464 */       object = ((Wrapper)object).unwrap();
/*     */     }
/* 466 */     if (object instanceof Node) {
/* 467 */       Node node = (Node)object;
/* 468 */       return newXML(XmlNode.createElementFromNode(node));
/*     */     } 
/*     */     
/* 471 */     String s = ScriptRuntime.toString(object);
/*     */     
/* 473 */     if (s.length() > 0 && s.charAt(0) == '<') {
/* 474 */       return parse(s);
/*     */     }
/* 476 */     return newXML(XmlNode.createText(this.options, s));
/*     */   }
/*     */ 
/*     */   
/*     */   final XML newTextElementXML(XmlNode reference, XmlNode.QName qname, String value) {
/* 481 */     return newXML(XmlNode.newElementWithText(this.options, reference, qname, value));
/*     */   }
/*     */   
/*     */   XMLList newXMLList() {
/* 485 */     return new XMLList(this, this.globalScope, this.xmlListPrototype);
/*     */   }
/*     */   
/*     */   final XMLList newXMLListFrom(Object inputObject) {
/* 489 */     XMLList rv = newXMLList();
/*     */     
/* 491 */     if (inputObject == null || inputObject instanceof Undefined)
/* 492 */       return rv; 
/* 493 */     if (inputObject instanceof XML) {
/* 494 */       XML xml = (XML)inputObject;
/* 495 */       rv.getNodeList().add(xml);
/* 496 */       return rv;
/* 497 */     }  if (inputObject instanceof XMLList) {
/* 498 */       XMLList xmll = (XMLList)inputObject;
/* 499 */       rv.getNodeList().add(xmll.getNodeList());
/* 500 */       return rv;
/*     */     } 
/* 502 */     String frag = ScriptRuntime.toString(inputObject).trim();
/*     */     
/* 504 */     if (!frag.startsWith("<>")) {
/* 505 */       frag = "<>" + frag + "</>";
/*     */     }
/*     */     
/* 508 */     frag = "<fragment>" + frag.substring(2);
/* 509 */     if (!frag.endsWith("</>")) {
/* 510 */       throw ScriptRuntime.typeError("XML with anonymous tag missing end anonymous tag");
/*     */     }
/*     */     
/* 513 */     frag = frag.substring(0, frag.length() - 3) + "</fragment>";
/*     */     
/* 515 */     XML orgXML = newXMLFromJs(frag);
/*     */ 
/*     */     
/* 518 */     XMLList children = orgXML.children();
/*     */     
/* 520 */     for (int i = 0; i < children.getNodeList().length(); i++)
/*     */     {
/* 522 */       rv.getNodeList().add((XML)children.item(i).copy());
/*     */     }
/* 524 */     return rv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlNode.QName toNodeQName(Context cx, Object namespaceValue, Object nameValue) {
/*     */     String localName;
/*     */     XmlNode.Namespace ns;
/* 534 */     if (nameValue instanceof QName) {
/* 535 */       QName qname = (QName)nameValue;
/* 536 */       localName = qname.localName();
/*     */     } else {
/* 538 */       localName = ScriptRuntime.toString(nameValue);
/*     */     } 
/*     */ 
/*     */     
/* 542 */     if (namespaceValue == Undefined.instance) {
/* 543 */       if ("*".equals(localName)) {
/* 544 */         ns = null;
/*     */       } else {
/* 546 */         ns = getDefaultNamespace(cx).getDelegate();
/*     */       } 
/* 548 */     } else if (namespaceValue == null) {
/* 549 */       ns = null;
/* 550 */     } else if (namespaceValue instanceof Namespace) {
/* 551 */       ns = ((Namespace)namespaceValue).getDelegate();
/*     */     } else {
/* 553 */       ns = this.namespacePrototype.constructNamespace(namespaceValue).getDelegate();
/*     */     } 
/*     */     
/* 556 */     if (localName != null && localName.equals("*")) localName = null; 
/* 557 */     return XmlNode.QName.create(ns, localName);
/*     */   }
/*     */   
/*     */   XmlNode.QName toNodeQName(Context cx, String name, boolean attribute) {
/* 561 */     XmlNode.Namespace defaultNamespace = getDefaultNamespace(cx).getDelegate();
/* 562 */     if (name != null && name.equals("*")) {
/* 563 */       return XmlNode.QName.create(null, null);
/*     */     }
/* 565 */     if (attribute) {
/* 566 */       return XmlNode.QName.create(XmlNode.Namespace.GLOBAL, name);
/*     */     }
/* 568 */     return XmlNode.QName.create(defaultNamespace, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlNode.QName toNodeQName(Context cx, Object nameValue, boolean attribute) {
/* 578 */     if (nameValue instanceof XMLName)
/* 579 */       return ((XMLName)nameValue).toQname(); 
/* 580 */     if (nameValue instanceof QName) {
/* 581 */       QName qname = (QName)nameValue;
/* 582 */       return qname.getDelegate();
/* 583 */     }  if (nameValue instanceof Boolean || nameValue instanceof Number || nameValue == Undefined.instance || nameValue == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 589 */       throw badXMLName(nameValue);
/*     */     }
/* 591 */     String local = null;
/* 592 */     if (nameValue instanceof String) {
/* 593 */       local = (String)nameValue;
/*     */     } else {
/* 595 */       local = ScriptRuntime.toString(nameValue);
/*     */     } 
/* 597 */     return toNodeQName(cx, local, attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isXMLName(Context _cx, Object nameObj) {
/* 607 */     return XMLName.accept(nameObj);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object toDefaultXmlNamespace(Context cx, Object uriValue) {
/* 612 */     return this.namespacePrototype.constructNamespace(uriValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public String escapeTextValue(Object o) {
/* 617 */     return this.options.escapeTextValue(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public String escapeAttributeValue(Object o) {
/* 622 */     return this.options.escapeAttributeValue(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ref nameRef(Context cx, Object name, Scriptable scope, int memberTypeFlags) {
/* 627 */     if ((memberTypeFlags & 0x2) == 0)
/*     */     {
/* 629 */       throw Kit.codeBug();
/*     */     }
/* 631 */     XMLName xmlName = toAttributeName(cx, name);
/* 632 */     return xmlPrimaryReference(cx, xmlName, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ref nameRef(Context cx, Object namespace, Object name, Scriptable scope, int memberTypeFlags) {
/* 637 */     XMLName xmlName = XMLName.create(toNodeQName(cx, namespace, name), false, false);
/*     */ 
/*     */     
/* 640 */     if ((memberTypeFlags & 0x2) != 0 && 
/* 641 */       !xmlName.isAttributeName()) {
/* 642 */       xmlName.setAttributeName();
/*     */     }
/*     */ 
/*     */     
/* 646 */     return xmlPrimaryReference(cx, xmlName, scope);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XMLLibImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */