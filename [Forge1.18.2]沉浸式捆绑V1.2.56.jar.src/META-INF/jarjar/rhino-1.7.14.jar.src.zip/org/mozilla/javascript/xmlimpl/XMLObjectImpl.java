/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionCall;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.Kit;
/*     */ import org.mozilla.javascript.NativeWith;
/*     */ import org.mozilla.javascript.Ref;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ import org.mozilla.javascript.xml.XMLObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class XMLObjectImpl
/*     */   extends XMLObject
/*     */ {
/*     */   private static final long serialVersionUID = -2553684605738101761L;
/*  28 */   private static final Object XMLOBJECT_TAG = "XMLObject"; private XMLLibImpl lib; private boolean prototypeFlag; private static final int Id_constructor = 1; private static final int Id_addNamespace = 2; private static final int Id_appendChild = 3; private static final int Id_attribute = 4; private static final int Id_attributes = 5; private static final int Id_child = 6; private static final int Id_childIndex = 7; private static final int Id_children = 8; private static final int Id_comments = 9; private static final int Id_contains = 10; private static final int Id_copy = 11; private static final int Id_descendants = 12; private static final int Id_elements = 13; private static final int Id_inScopeNamespaces = 14; private static final int Id_insertChildAfter = 15; private static final int Id_insertChildBefore = 16;
/*     */   private static final int Id_hasOwnProperty = 17;
/*     */   private static final int Id_hasComplexContent = 18;
/*     */   private static final int Id_hasSimpleContent = 19;
/*     */   private static final int Id_length = 20;
/*     */   
/*     */   protected XMLObjectImpl(XMLLibImpl lib, Scriptable scope, XMLObject prototype) {
/*  35 */     initialize(lib, scope, prototype);
/*     */   }
/*     */   private static final int Id_localName = 21; private static final int Id_name = 22; private static final int Id_namespace = 23; private static final int Id_namespaceDeclarations = 24; private static final int Id_nodeKind = 25; private static final int Id_normalize = 26; private static final int Id_parent = 27; private static final int Id_prependChild = 28; private static final int Id_processingInstructions = 29; private static final int Id_propertyIsEnumerable = 30;
/*     */   private static final int Id_removeNamespace = 31;
/*     */   
/*     */   final void initialize(XMLLibImpl lib, Scriptable scope, XMLObject prototype) {
/*  41 */     setParentScope(scope);
/*  42 */     setPrototype((Scriptable)prototype);
/*  43 */     this.prototypeFlag = (prototype == null);
/*  44 */     this.lib = lib;
/*     */   }
/*     */   private static final int Id_replace = 32; private static final int Id_setChildren = 33; private static final int Id_setLocalName = 34; private static final int Id_setName = 35; private static final int Id_setNamespace = 36; private static final int Id_text = 37; private static final int Id_toString = 38; private static final int Id_toSource = 39; private static final int Id_toXMLString = 40; private static final int Id_valueOf = 41; private static final int MAX_PROTOTYPE_ID = 41;
/*     */   final boolean isPrototype() {
/*  48 */     return this.prototypeFlag;
/*     */   }
/*     */   
/*     */   XMLLibImpl getLib() {
/*  52 */     return this.lib;
/*     */   }
/*     */   
/*     */   final XML newXML(XmlNode node) {
/*  56 */     return this.lib.newXML(node);
/*     */   }
/*     */   
/*     */   XML xmlFromNode(XmlNode node) {
/*  60 */     if (node.getXml() == null) {
/*  61 */       node.setXml(newXML(node));
/*     */     }
/*  63 */     return node.getXml();
/*     */   }
/*     */   
/*     */   final XMLList newXMLList() {
/*  67 */     return this.lib.newXMLList();
/*     */   }
/*     */   
/*     */   final XMLList newXMLListFrom(Object o) {
/*  71 */     return this.lib.newXMLListFrom(o);
/*     */   }
/*     */   
/*     */   final XmlProcessor getProcessor() {
/*  75 */     return this.lib.getProcessor();
/*     */   }
/*     */   
/*     */   final QName newQName(String uri, String localName, String prefix) {
/*  79 */     return this.lib.newQName(uri, localName, prefix);
/*     */   }
/*     */   
/*     */   final QName newQName(XmlNode.QName name) {
/*  83 */     return this.lib.newQName(name);
/*     */   }
/*     */   
/*     */   final Namespace createNamespace(XmlNode.Namespace declaration) {
/*  87 */     if (declaration == null) return null; 
/*  88 */     return this.lib.createNamespaces(new XmlNode.Namespace[] { declaration })[0];
/*     */   }
/*     */   
/*     */   final Namespace[] createNamespaces(XmlNode.Namespace[] declarations) {
/*  92 */     return this.lib.createNamespaces(declarations);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Scriptable getPrototype() {
/*  98 */     return super.getPrototype();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setPrototype(Scriptable prototype) {
/* 103 */     super.setPrototype(prototype);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Scriptable getParentScope() {
/* 108 */     return super.getParentScope();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setParentScope(Scriptable parent) {
/* 113 */     super.setParentScope(parent);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object getDefaultValue(Class<?> hint) {
/* 118 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasInstance(Scriptable scriptable) {
/* 123 */     return super.hasInstance(scriptable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract boolean hasXMLProperty(XMLName paramXMLName);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract Object getXMLProperty(XMLName paramXMLName);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void putXMLProperty(XMLName paramXMLName, Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void deleteXMLProperty(XMLName paramXMLName);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract boolean equivalentXml(Object paramObject);
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void addMatches(XMLList paramXMLList, XMLName paramXMLName);
/*     */ 
/*     */ 
/*     */   
/*     */   private XMLList getMatches(XMLName name) {
/* 158 */     XMLList rv = newXMLList();
/* 159 */     addMatches(rv, name);
/* 160 */     return rv;
/*     */   }
/*     */   abstract XML getXML();
/*     */   abstract XMLList child(int paramInt);
/*     */   abstract XMLList child(XMLName paramXMLName);
/*     */   abstract XMLList children();
/*     */   abstract XMLList comments();
/*     */   
/*     */   abstract boolean contains(Object paramObject);
/*     */   
/*     */   abstract XMLObjectImpl copy();
/*     */   
/*     */   abstract XMLList elements(XMLName paramXMLName);
/*     */   
/*     */   abstract boolean hasOwnProperty(XMLName paramXMLName);
/*     */   
/*     */   abstract boolean hasComplexContent();
/*     */   
/*     */   abstract boolean hasSimpleContent();
/*     */   
/*     */   abstract int length();
/*     */   
/*     */   abstract void normalize();
/*     */   
/*     */   abstract Object parent();
/*     */   
/*     */   abstract XMLList processingInstructions(XMLName paramXMLName);
/*     */   
/*     */   abstract boolean propertyIsEnumerable(Object paramObject);
/*     */   
/*     */   abstract XMLList text();
/*     */   
/*     */   public abstract String toString();
/*     */   
/*     */   abstract String toSource(int paramInt);
/*     */   
/*     */   abstract String toXMLString();
/*     */   
/*     */   abstract Object valueOf();
/*     */   
/*     */   protected abstract Object jsConstructor(Context paramContext, boolean paramBoolean, Object[] paramArrayOfObject);
/*     */   
/*     */   protected final Object equivalentValues(Object value) {
/* 203 */     boolean result = equivalentXml(value);
/* 204 */     return result ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean has(Context cx, Object id) {
/* 218 */     if (cx == null) cx = Context.getCurrentContext(); 
/* 219 */     XMLName xmlName = this.lib.toXMLNameOrIndex(cx, id);
/* 220 */     if (xmlName == null) {
/* 221 */       long index = ScriptRuntime.lastUint32Result(cx);
/*     */       
/* 223 */       return has((int)index, (Scriptable)this);
/*     */     } 
/* 225 */     return hasXMLProperty(xmlName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(String name, Scriptable start) {
/* 230 */     Context cx = Context.getCurrentContext();
/* 231 */     return hasXMLProperty(this.lib.toXMLNameFromString(cx, name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object get(Context cx, Object id) {
/* 238 */     if (cx == null) cx = Context.getCurrentContext(); 
/* 239 */     XMLName xmlName = this.lib.toXMLNameOrIndex(cx, id);
/* 240 */     if (xmlName == null) {
/* 241 */       long index = ScriptRuntime.lastUint32Result(cx);
/*     */       
/* 243 */       Object result = get((int)index, (Scriptable)this);
/* 244 */       if (result == Scriptable.NOT_FOUND) {
/* 245 */         result = Undefined.instance;
/*     */       }
/* 247 */       return result;
/*     */     } 
/* 249 */     return getXMLProperty(xmlName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String name, Scriptable start) {
/* 254 */     Context cx = Context.getCurrentContext();
/* 255 */     return getXMLProperty(this.lib.toXMLNameFromString(cx, name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void put(Context cx, Object id, Object value) {
/* 262 */     if (cx == null) cx = Context.getCurrentContext(); 
/* 263 */     XMLName xmlName = this.lib.toXMLNameOrIndex(cx, id);
/* 264 */     if (xmlName == null) {
/* 265 */       long index = ScriptRuntime.lastUint32Result(cx);
/*     */       
/* 267 */       put((int)index, (Scriptable)this, value);
/*     */       return;
/*     */     } 
/* 270 */     putXMLProperty(xmlName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String name, Scriptable start, Object value) {
/* 275 */     Context cx = Context.getCurrentContext();
/* 276 */     putXMLProperty(this.lib.toXMLNameFromString(cx, name), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean delete(Context cx, Object id) {
/* 283 */     if (cx == null) cx = Context.getCurrentContext(); 
/* 284 */     XMLName xmlName = this.lib.toXMLNameOrIndex(cx, id);
/* 285 */     if (xmlName == null) {
/* 286 */       long index = ScriptRuntime.lastUint32Result(cx);
/*     */       
/* 288 */       delete((int)index);
/* 289 */       return true;
/*     */     } 
/* 291 */     deleteXMLProperty(xmlName);
/* 292 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(String name) {
/* 298 */     Context cx = Context.getCurrentContext();
/* 299 */     deleteXMLProperty(this.lib.toXMLNameFromString(cx, name));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getFunctionProperty(Context cx, int id) {
/* 304 */     if (isPrototype()) {
/* 305 */       return get(id, (Scriptable)this);
/*     */     }
/* 307 */     Scriptable proto = getPrototype();
/* 308 */     if (proto instanceof XMLObject) {
/* 309 */       return ((XMLObject)proto).getFunctionProperty(cx, id);
/*     */     }
/*     */     
/* 312 */     return NOT_FOUND;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getFunctionProperty(Context cx, String name) {
/* 317 */     if (isPrototype()) {
/* 318 */       return super.get(name, (Scriptable)this);
/*     */     }
/* 320 */     Scriptable proto = getPrototype();
/* 321 */     if (proto instanceof XMLObject) {
/* 322 */       return ((XMLObject)proto).getFunctionProperty(cx, name);
/*     */     }
/*     */     
/* 325 */     return NOT_FOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Ref memberRef(Context cx, Object elem, int memberTypeFlags) {
/* 331 */     boolean attribute = ((memberTypeFlags & 0x2) != 0);
/* 332 */     boolean descendants = ((memberTypeFlags & 0x4) != 0);
/* 333 */     if (!attribute && !descendants)
/*     */     {
/*     */ 
/*     */       
/* 337 */       throw Kit.codeBug();
/*     */     }
/* 339 */     XmlNode.QName qname = this.lib.toNodeQName(cx, elem, attribute);
/* 340 */     XMLName rv = XMLName.create(qname, attribute, descendants);
/* 341 */     rv.initXMLObject(this);
/* 342 */     return rv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ref memberRef(Context cx, Object namespace, Object elem, int memberTypeFlags) {
/* 352 */     boolean attribute = ((memberTypeFlags & 0x2) != 0);
/* 353 */     boolean descendants = ((memberTypeFlags & 0x4) != 0);
/* 354 */     XMLName rv = XMLName.create(this.lib.toNodeQName(cx, namespace, elem), attribute, descendants);
/*     */     
/* 356 */     rv.initXMLObject(this);
/* 357 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeWith enterWith(Scriptable scope) {
/* 362 */     return new XMLWithScope(this.lib, scope, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeWith enterDotQuery(Scriptable scope) {
/* 367 */     XMLWithScope xws = new XMLWithScope(this.lib, scope, this);
/* 368 */     xws.initAsDotQuery();
/* 369 */     return xws;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object addValues(Context cx, boolean thisIsLeft, Object value) {
/* 375 */     if (value instanceof XMLObject) {
/*     */       XMLObject v1; XMLObject v2;
/* 377 */       if (thisIsLeft) {
/* 378 */         v1 = this;
/* 379 */         v2 = (XMLObject)value;
/*     */       } else {
/* 381 */         v1 = (XMLObject)value;
/* 382 */         v2 = this;
/*     */       } 
/* 384 */       return this.lib.addXMLObjects(cx, v1, v2);
/*     */     } 
/* 386 */     if (value == Undefined.instance)
/*     */     {
/* 388 */       return ScriptRuntime.toString(this);
/*     */     }
/*     */     
/* 391 */     return super.addValues(cx, thisIsLeft, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void exportAsJSClass(boolean sealed) {
/* 401 */     this.prototypeFlag = true;
/* 402 */     exportAsJSClass(41, getParentScope(), sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 456 */     int c, id = 0; String X = null;
/* 457 */     switch (s.length()) { case 4:
/* 458 */         c = s.charAt(0);
/* 459 */         if (c == 99) { X = "copy"; id = 11; break; }
/* 460 */          if (c == 110) { X = "name"; id = 22; break; }
/* 461 */          if (c == 116) { X = "text"; id = 37; }  break;
/*     */       case 5:
/* 463 */         X = "child"; id = 6; break;
/* 464 */       case 6: c = s.charAt(0);
/* 465 */         if (c == 108) { X = "length"; id = 20; break; }
/* 466 */          if (c == 112) { X = "parent"; id = 27; }  break;
/*     */       case 7:
/* 468 */         c = s.charAt(0);
/* 469 */         if (c == 114) { X = "replace"; id = 32; break; }
/* 470 */          if (c == 115) { X = "setName"; id = 35; break; }
/* 471 */          if (c == 118) { X = "valueOf"; id = 41; }  break;
/*     */       case 8:
/* 473 */         switch (s.charAt(2)) { case 'S':
/* 474 */             c = s.charAt(7);
/* 475 */             if (c == 101) { X = "toSource"; id = 39; break; }
/* 476 */              if (c == 103) { X = "toString"; id = 38; }  break;
/*     */           case 'd':
/* 478 */             X = "nodeKind"; id = 25; break;
/* 479 */           case 'e': X = "elements"; id = 13; break;
/* 480 */           case 'i': X = "children"; id = 8; break;
/* 481 */           case 'm': X = "comments"; id = 9; break;
/* 482 */           case 'n': X = "contains"; id = 10; break; }  break;
/*     */       case 9:
/* 484 */         switch (s.charAt(2)) { case 'c':
/* 485 */             X = "localName"; id = 21; break;
/* 486 */           case 'm': X = "namespace"; id = 23; break;
/* 487 */           case 'r': X = "normalize"; id = 26; break;
/* 488 */           case 't': X = "attribute"; id = 4; break; }  break;
/*     */       case 10:
/* 490 */         c = s.charAt(0);
/* 491 */         if (c == 97) { X = "attributes"; id = 5; break; }
/* 492 */          if (c == 99) { X = "childIndex"; id = 7; }  break;
/*     */       case 11:
/* 494 */         switch (s.charAt(0)) { case 'a':
/* 495 */             X = "appendChild"; id = 3; break;
/* 496 */           case 'c': X = "constructor"; id = 1; break;
/* 497 */           case 'd': X = "descendants"; id = 12; break;
/* 498 */           case 's': X = "setChildren"; id = 33; break;
/* 499 */           case 't': X = "toXMLString"; id = 40; break; }  break;
/*     */       case 12:
/* 501 */         c = s.charAt(0);
/* 502 */         if (c == 97) { X = "addNamespace"; id = 2; break; }
/* 503 */          if (c == 112) { X = "prependChild"; id = 28; break; }
/* 504 */          if (c == 115) {
/* 505 */           c = s.charAt(3);
/* 506 */           if (c == 76) { X = "setLocalName"; id = 34; break; }
/* 507 */            if (c == 78) { X = "setNamespace"; id = 36; } 
/*     */         }  break;
/*     */       case 14:
/* 510 */         X = "hasOwnProperty"; id = 17; break;
/* 511 */       case 15: X = "removeNamespace"; id = 31; break;
/* 512 */       case 16: c = s.charAt(0);
/* 513 */         if (c == 104) { X = "hasSimpleContent"; id = 19; break; }
/* 514 */          if (c == 105) { X = "insertChildAfter"; id = 15; }  break;
/*     */       case 17:
/* 516 */         c = s.charAt(3);
/* 517 */         if (c == 67) { X = "hasComplexContent"; id = 18; break; }
/* 518 */          if (c == 99) { X = "inScopeNamespaces"; id = 14; break; }
/* 519 */          if (c == 101) { X = "insertChildBefore"; id = 16; }  break;
/*     */       case 20:
/* 521 */         X = "propertyIsEnumerable"; id = 30; break;
/* 522 */       case 21: X = "namespaceDeclarations"; id = 24; break;
/* 523 */       case 22: X = "processingInstructions"; id = 29; break; }
/*     */     
/* 525 */     if (X != null && X != s && !X.equals(s)) id = 0;
/*     */ 
/*     */ 
/*     */     
/* 529 */     return id;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*     */     IdFunctionObject ctor;
/* 537 */     switch (id) {
/*     */       
/*     */       case 1:
/* 540 */         if (this instanceof XML) {
/* 541 */           ctor = new XMLCtor((XML)this, XMLOBJECT_TAG, id, 1);
/*     */         } else {
/* 543 */           ctor = new IdFunctionObject((IdFunctionCall)this, XMLOBJECT_TAG, id, 1);
/*     */         } 
/* 545 */         initPrototypeConstructor(ctor);
/*     */         return;
/*     */       
/*     */       case 2:
/* 549 */         arity = 1; s = "addNamespace"; break;
/* 550 */       case 3: arity = 1; s = "appendChild"; break;
/* 551 */       case 4: arity = 1; s = "attribute"; break;
/* 552 */       case 5: arity = 0; s = "attributes"; break;
/* 553 */       case 6: arity = 1; s = "child"; break;
/* 554 */       case 7: arity = 0; s = "childIndex"; break;
/* 555 */       case 8: arity = 0; s = "children"; break;
/* 556 */       case 9: arity = 0; s = "comments"; break;
/* 557 */       case 10: arity = 1; s = "contains"; break;
/* 558 */       case 11: arity = 0; s = "copy"; break;
/* 559 */       case 12: arity = 1; s = "descendants"; break;
/* 560 */       case 13: arity = 1; s = "elements"; break;
/* 561 */       case 18: arity = 0; s = "hasComplexContent"; break;
/* 562 */       case 17: arity = 1; s = "hasOwnProperty"; break;
/* 563 */       case 19: arity = 0; s = "hasSimpleContent"; break;
/* 564 */       case 14: arity = 0; s = "inScopeNamespaces"; break;
/* 565 */       case 15: arity = 2; s = "insertChildAfter"; break;
/* 566 */       case 16: arity = 2; s = "insertChildBefore"; break;
/* 567 */       case 20: arity = 0; s = "length"; break;
/* 568 */       case 21: arity = 0; s = "localName"; break;
/* 569 */       case 22: arity = 0; s = "name"; break;
/* 570 */       case 23: arity = 1; s = "namespace"; break;
/*     */       case 24:
/* 572 */         arity = 0; s = "namespaceDeclarations"; break;
/* 573 */       case 25: arity = 0; s = "nodeKind"; break;
/* 574 */       case 26: arity = 0; s = "normalize"; break;
/* 575 */       case 27: arity = 0; s = "parent"; break;
/* 576 */       case 28: arity = 1; s = "prependChild"; break;
/*     */       case 29:
/* 578 */         arity = 1; s = "processingInstructions"; break;
/*     */       case 30:
/* 580 */         arity = 1; s = "propertyIsEnumerable"; break;
/* 581 */       case 31: arity = 1; s = "removeNamespace"; break;
/* 582 */       case 32: arity = 2; s = "replace"; break;
/* 583 */       case 33: arity = 1; s = "setChildren"; break;
/* 584 */       case 34: arity = 1; s = "setLocalName"; break;
/* 585 */       case 35: arity = 1; s = "setName"; break;
/* 586 */       case 36: arity = 1; s = "setNamespace"; break;
/* 587 */       case 37: arity = 0; s = "text"; break;
/* 588 */       case 38: arity = 0; s = "toString"; break;
/* 589 */       case 39: arity = 1; s = "toSource"; break;
/* 590 */       case 40: arity = 1; s = "toXMLString"; break;
/* 591 */       case 41: arity = 0; s = "valueOf"; break;
/*     */       default:
/* 593 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 595 */     initPrototypeMethod(XMLOBJECT_TAG, id, s, arity);
/*     */   }
/*     */   
/*     */   private Object[] toObjectArray(Object[] typed) {
/* 599 */     Object[] rv = new Object[typed.length];
/* 600 */     for (int i = 0; i < rv.length; i++) {
/* 601 */       rv[i] = typed[i];
/*     */     }
/* 603 */     return rv;
/*     */   }
/*     */   
/*     */   private void xmlMethodNotFound(Object object, String name) {
/* 607 */     throw ScriptRuntime.notFunctionError(object, name); } public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) { Namespace namespace2; Object arg0; String prefix; Namespace array[], namespace1; XMLName xMLName2; String localName; Object arg; Namespace ns; XMLName xMLName1;
/*     */     XmlNode.QName qname;
/*     */     XMLName xmlName;
/*     */     int indent;
/*     */     Namespace rv;
/*     */     Object arg1, object1;
/*     */     QName qName;
/* 614 */     if (!f.hasTag(XMLOBJECT_TAG)) {
/* 615 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 617 */     int id = f.methodId();
/* 618 */     if (id == 1) {
/* 619 */       return jsConstructor(cx, (thisObj == null), args);
/*     */     }
/*     */ 
/*     */     
/* 623 */     XMLObjectImpl realThis = (XMLObjectImpl)ensureType(thisObj, XMLObjectImpl.class, f);
/*     */     
/* 625 */     XML xml = realThis.getXML();
/* 626 */     switch (id) {
/*     */       case 3:
/* 628 */         if (xml == null) xmlMethodNotFound(realThis, "appendChild"); 
/* 629 */         return xml.appendChild(arg(args, 0));
/*     */       
/*     */       case 2:
/* 632 */         if (xml == null) xmlMethodNotFound(realThis, "addNamespace"); 
/* 633 */         namespace2 = this.lib.castToNamespace(cx, arg(args, 0));
/* 634 */         return xml.addNamespace(namespace2);
/*     */       
/*     */       case 7:
/* 637 */         if (xml == null) xmlMethodNotFound(realThis, "childIndex"); 
/* 638 */         return ScriptRuntime.wrapInt(xml.childIndex());
/*     */       
/*     */       case 14:
/* 641 */         if (xml == null) xmlMethodNotFound(realThis, "inScopeNamespaces"); 
/* 642 */         return cx.newArray(scope, toObjectArray((Object[])xml.inScopeNamespaces()));
/*     */       
/*     */       case 15:
/* 645 */         if (xml == null) xmlMethodNotFound(realThis, "insertChildAfter"); 
/* 646 */         arg0 = arg(args, 0);
/* 647 */         if (arg0 == null || arg0 instanceof XML) {
/* 648 */           return xml.insertChildAfter((XML)arg0, arg(args, 1));
/*     */         }
/* 650 */         return Undefined.instance;
/*     */       
/*     */       case 16:
/* 653 */         if (xml == null) xmlMethodNotFound(realThis, "insertChildBefore"); 
/* 654 */         arg0 = arg(args, 0);
/* 655 */         if (arg0 == null || arg0 instanceof XML) {
/* 656 */           return xml.insertChildBefore((XML)arg0, arg(args, 1));
/*     */         }
/* 658 */         return Undefined.instance;
/*     */       
/*     */       case 21:
/* 661 */         if (xml == null) xmlMethodNotFound(realThis, "localName"); 
/* 662 */         return xml.localName();
/*     */       
/*     */       case 22:
/* 665 */         if (xml == null) xmlMethodNotFound(realThis, "name"); 
/* 666 */         return xml.name();
/*     */       
/*     */       case 23:
/* 669 */         if (xml == null) xmlMethodNotFound(realThis, "namespace"); 
/* 670 */         prefix = (args.length > 0) ? ScriptRuntime.toString(args[0]) : null;
/* 671 */         rv = xml.namespace(prefix);
/* 672 */         if (rv == null) {
/* 673 */           return Undefined.instance;
/*     */         }
/* 675 */         return rv;
/*     */ 
/*     */       
/*     */       case 24:
/* 679 */         if (xml == null) xmlMethodNotFound(realThis, "namespaceDeclarations"); 
/* 680 */         array = xml.namespaceDeclarations();
/* 681 */         return cx.newArray(scope, toObjectArray((Object[])array));
/*     */       
/*     */       case 25:
/* 684 */         if (xml == null) xmlMethodNotFound(realThis, "nodeKind"); 
/* 685 */         return xml.nodeKind();
/*     */       
/*     */       case 28:
/* 688 */         if (xml == null) xmlMethodNotFound(realThis, "prependChild"); 
/* 689 */         return xml.prependChild(arg(args, 0));
/*     */       
/*     */       case 31:
/* 692 */         if (xml == null) xmlMethodNotFound(realThis, "removeNamespace"); 
/* 693 */         namespace1 = this.lib.castToNamespace(cx, arg(args, 0));
/* 694 */         return xml.removeNamespace(namespace1);
/*     */       
/*     */       case 32:
/* 697 */         if (xml == null) xmlMethodNotFound(realThis, "replace"); 
/* 698 */         xMLName2 = this.lib.toXMLNameOrIndex(cx, arg(args, 0));
/* 699 */         arg1 = arg(args, 1);
/* 700 */         if (xMLName2 == null) {
/*     */           
/* 702 */           int index = (int)ScriptRuntime.lastUint32Result(cx);
/* 703 */           return xml.replace(index, arg1);
/*     */         } 
/* 705 */         return xml.replace(xMLName2, arg1);
/*     */ 
/*     */       
/*     */       case 33:
/* 709 */         if (xml == null) xmlMethodNotFound(realThis, "setChildren"); 
/* 710 */         return xml.setChildren(arg(args, 0));
/*     */       
/*     */       case 34:
/* 713 */         if (xml == null) xmlMethodNotFound(realThis, "setLocalName");
/*     */         
/* 715 */         object1 = arg(args, 0);
/* 716 */         if (object1 instanceof QName) {
/* 717 */           localName = ((QName)object1).localName();
/*     */         } else {
/* 719 */           localName = ScriptRuntime.toString(object1);
/*     */         } 
/* 721 */         xml.setLocalName(localName);
/* 722 */         return Undefined.instance;
/*     */       
/*     */       case 35:
/* 725 */         if (xml == null) xmlMethodNotFound(realThis, "setName"); 
/* 726 */         arg = (args.length != 0) ? args[0] : Undefined.instance;
/* 727 */         qName = this.lib.constructQName(cx, arg);
/* 728 */         xml.setName(qName);
/* 729 */         return Undefined.instance;
/*     */       
/*     */       case 36:
/* 732 */         if (xml == null) xmlMethodNotFound(realThis, "setNamespace"); 
/* 733 */         ns = this.lib.castToNamespace(cx, arg(args, 0));
/* 734 */         xml.setNamespace(ns);
/* 735 */         return Undefined.instance;
/*     */ 
/*     */       
/*     */       case 4:
/* 739 */         xMLName1 = XMLName.create(this.lib.toNodeQName(cx, arg(args, 0), true), true, false);
/* 740 */         return realThis.getMatches(xMLName1);
/*     */       
/*     */       case 5:
/* 743 */         return realThis.getMatches(XMLName.create(XmlNode.QName.create(null, null), true, false));
/*     */       case 6:
/* 745 */         xMLName1 = this.lib.toXMLNameOrIndex(cx, arg(args, 0));
/* 746 */         if (xMLName1 == null) {
/*     */           
/* 748 */           int index = (int)ScriptRuntime.lastUint32Result(cx);
/* 749 */           return realThis.child(index);
/*     */         } 
/* 751 */         return realThis.child(xMLName1);
/*     */ 
/*     */       
/*     */       case 8:
/* 755 */         return realThis.children();
/*     */       case 9:
/* 757 */         return realThis.comments();
/*     */       case 10:
/* 759 */         return ScriptRuntime.wrapBoolean(realThis
/* 760 */             .contains(arg(args, 0)));
/*     */       case 11:
/* 762 */         return realThis.copy();
/*     */       case 12:
/* 764 */         qname = (args.length == 0) ? XmlNode.QName.create(null, null) : this.lib.toNodeQName(cx, args[0], false);
/* 765 */         return realThis.getMatches(XMLName.create(qname, false, true));
/*     */ 
/*     */ 
/*     */       
/*     */       case 13:
/* 770 */         xmlName = (args.length == 0) ? XMLName.formStar() : this.lib.toXMLName(cx, args[0]);
/* 771 */         return realThis.elements(xmlName);
/*     */       
/*     */       case 17:
/* 774 */         xmlName = this.lib.toXMLName(cx, arg(args, 0));
/* 775 */         return ScriptRuntime.wrapBoolean(realThis
/* 776 */             .hasOwnProperty(xmlName));
/*     */       
/*     */       case 18:
/* 779 */         return ScriptRuntime.wrapBoolean(realThis.hasComplexContent());
/*     */       case 19:
/* 781 */         return ScriptRuntime.wrapBoolean(realThis.hasSimpleContent());
/*     */       case 20:
/* 783 */         return ScriptRuntime.wrapInt(realThis.length());
/*     */       case 26:
/* 785 */         realThis.normalize();
/* 786 */         return Undefined.instance;
/*     */       case 27:
/* 788 */         return realThis.parent();
/*     */ 
/*     */       
/*     */       case 29:
/* 792 */         xmlName = (args.length > 0) ? this.lib.toXMLName(cx, args[0]) : XMLName.formStar();
/* 793 */         return realThis.processingInstructions(xmlName);
/*     */       
/*     */       case 30:
/* 796 */         return ScriptRuntime.wrapBoolean(realThis
/* 797 */             .propertyIsEnumerable(arg(args, 0)));
/*     */       
/*     */       case 37:
/* 800 */         return realThis.text();
/*     */       case 38:
/* 802 */         return realThis.toString();
/*     */       case 39:
/* 804 */         indent = ScriptRuntime.toInt32(args, 0);
/* 805 */         return realThis.toSource(indent);
/*     */       case 40:
/* 807 */         return realThis.toXMLString();
/*     */       
/*     */       case 41:
/* 810 */         return realThis.valueOf();
/*     */     } 
/* 812 */     throw new IllegalArgumentException(String.valueOf(id)); }
/*     */ 
/*     */   
/*     */   private static Object arg(Object[] args, int i) {
/* 816 */     return (i < args.length) ? args[i] : Undefined.instance;
/*     */   }
/*     */   
/*     */   final XML newTextElementXML(XmlNode reference, XmlNode.QName qname, String value) {
/* 820 */     return this.lib.newTextElementXML(reference, qname, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final XML newXMLFromJs(Object inputObject) {
/* 825 */     return this.lib.newXMLFromJs(inputObject);
/*     */   }
/*     */   
/*     */   final XML ecmaToXml(Object object) {
/* 829 */     return this.lib.ecmaToXml(object);
/*     */   }
/*     */ 
/*     */   
/*     */   final String ecmaEscapeAttributeValue(String s) {
/* 834 */     String quoted = this.lib.escapeAttributeValue(s);
/* 835 */     return quoted.substring(1, quoted.length() - 1);
/*     */   }
/*     */   
/*     */   final XML createEmptyXML() {
/* 839 */     return newXML(XmlNode.createEmpty(getProcessor()));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XMLObjectImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */