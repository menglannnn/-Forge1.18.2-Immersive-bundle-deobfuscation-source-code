/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.LinkedBlockingDeque;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ class XmlProcessor
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6903514433204808713L;
/*     */   private boolean ignoreComments;
/*     */   private boolean ignoreProcessingInstructions;
/*     */   private boolean ignoreWhitespace;
/*  44 */   private RhinoSAXErrorHandler errorHandler = new RhinoSAXErrorHandler(); private boolean prettyPrint; private int prettyIndent; private transient DocumentBuilderFactory dom; private transient TransformerFactory xform; private transient LinkedBlockingDeque<DocumentBuilder> documentBuilderPool;
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/*  47 */     stream.defaultReadObject();
/*  48 */     this.dom = DocumentBuilderFactory.newInstance();
/*  49 */     this.dom.setNamespaceAware(true);
/*  50 */     this.dom.setIgnoringComments(false);
/*     */ 
/*     */     
/*  53 */     this.xform = TransformerFactory.newInstance();
/*  54 */     Context ctx = Context.getCurrentContext();
/*  55 */     if (ctx == null || ctx.hasFeature(20)) {
/*  56 */       configureSecureDBF(this.dom);
/*  57 */       configureSecureTF(this.xform);
/*     */     } 
/*  59 */     int poolSize = Runtime.getRuntime().availableProcessors() * 2;
/*  60 */     this.documentBuilderPool = new LinkedBlockingDeque<>(poolSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureSecureDBF(DocumentBuilderFactory dbf) {
/*     */     try {
/*  69 */       dbf.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/*     */ 
/*     */       
/*  72 */       dbf.setXIncludeAware(false);
/*  73 */     } catch (ParserConfigurationException e) {
/*  74 */       throw new RuntimeException("XML parser (DocumentBuilderFactory) cannot be securely configured.", e);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  85 */       dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
/*  86 */     } catch (ParserConfigurationException parserConfigurationException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  94 */       dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
/*  95 */     } catch (ParserConfigurationException parserConfigurationException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureSecureTF(TransformerFactory xform) {
/*     */     try {
/* 107 */       xform.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 108 */     } catch (TransformerConfigurationException e) {
/* 109 */       throw new RuntimeException("XML parser (TransformerFactory) cannot be securely configured.", e);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 116 */       xform.setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "");
/* 117 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 122 */       xform.setAttribute("http://javax.xml.XMLConstants/property/accessExternalStylesheet", "");
/* 123 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*     */   }
/*     */   
/*     */   private static class RhinoSAXErrorHandler
/*     */     implements ErrorHandler, Serializable {
/*     */     private static final long serialVersionUID = 6918417235413084055L;
/*     */     
/*     */     private RhinoSAXErrorHandler() {}
/*     */     
/*     */     private void throwError(SAXParseException e) {
/* 133 */       throw ScriptRuntime.constructError("TypeError", e.getMessage(), e.getLineNumber() - 1);
/*     */     }
/*     */     
/*     */     public void error(SAXParseException e) {
/* 137 */       throwError(e);
/*     */     }
/*     */     
/*     */     public void fatalError(SAXParseException e) {
/* 141 */       throwError(e);
/*     */     }
/*     */     
/*     */     public void warning(SAXParseException e) {
/* 145 */       Context.reportWarning(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   XmlProcessor() {
/* 150 */     setDefault();
/* 151 */     this.dom = DocumentBuilderFactory.newInstance();
/* 152 */     this.dom.setNamespaceAware(true);
/* 153 */     this.dom.setIgnoringComments(false);
/*     */ 
/*     */     
/* 156 */     this.xform = TransformerFactory.newInstance();
/* 157 */     Context ctx = Context.getCurrentContext();
/* 158 */     if (ctx == null || ctx.hasFeature(20)) {
/* 159 */       configureSecureDBF(this.dom);
/* 160 */       configureSecureTF(this.xform);
/*     */     } 
/* 162 */     int poolSize = Runtime.getRuntime().availableProcessors() * 2;
/* 163 */     this.documentBuilderPool = new LinkedBlockingDeque<>(poolSize);
/*     */   }
/*     */   
/*     */   final void setDefault() {
/* 167 */     setIgnoreComments(true);
/* 168 */     setIgnoreProcessingInstructions(true);
/* 169 */     setIgnoreWhitespace(true);
/* 170 */     setPrettyPrinting(true);
/* 171 */     setPrettyIndent(2);
/*     */   }
/*     */   
/*     */   final void setIgnoreComments(boolean b) {
/* 175 */     this.ignoreComments = b;
/*     */   }
/*     */   
/*     */   final void setIgnoreWhitespace(boolean b) {
/* 179 */     this.ignoreWhitespace = b;
/*     */   }
/*     */   
/*     */   final void setIgnoreProcessingInstructions(boolean b) {
/* 183 */     this.ignoreProcessingInstructions = b;
/*     */   }
/*     */   
/*     */   final void setPrettyPrinting(boolean b) {
/* 187 */     this.prettyPrint = b;
/*     */   }
/*     */   
/*     */   final void setPrettyIndent(int i) {
/* 191 */     this.prettyIndent = i;
/*     */   }
/*     */   
/*     */   final boolean isIgnoreComments() {
/* 195 */     return this.ignoreComments;
/*     */   }
/*     */   
/*     */   final boolean isIgnoreProcessingInstructions() {
/* 199 */     return this.ignoreProcessingInstructions;
/*     */   }
/*     */   
/*     */   final boolean isIgnoreWhitespace() {
/* 203 */     return this.ignoreWhitespace;
/*     */   }
/*     */   
/*     */   final boolean isPrettyPrinting() {
/* 207 */     return this.prettyPrint;
/*     */   }
/*     */   
/*     */   final int getPrettyIndent() {
/* 211 */     return this.prettyIndent;
/*     */   }
/*     */   
/*     */   private String toXmlNewlines(String rv) {
/* 215 */     StringBuilder nl = new StringBuilder(rv.length());
/* 216 */     for (int i = 0; i < rv.length(); i++) {
/* 217 */       char ch = rv.charAt(i);
/* 218 */       if (ch == '\r') {
/* 219 */         if (rv.charAt(i + 1) != '\n')
/*     */         {
/*     */ 
/*     */           
/* 223 */           nl.append('\n');
/*     */         }
/*     */       } else {
/* 226 */         nl.append(ch);
/*     */       } 
/*     */     } 
/* 229 */     return nl.toString();
/*     */   }
/*     */   
/*     */   private DocumentBuilderFactory getDomFactory() {
/* 233 */     return this.dom;
/*     */   }
/*     */ 
/*     */   
/*     */   private DocumentBuilder getDocumentBuilderFromPool() throws ParserConfigurationException {
/* 238 */     DocumentBuilder builder = this.documentBuilderPool.pollFirst();
/* 239 */     if (builder == null) {
/* 240 */       builder = getDomFactory().newDocumentBuilder();
/*     */     }
/* 242 */     builder.setErrorHandler(this.errorHandler);
/* 243 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void returnDocumentBuilderToPool(DocumentBuilder db) {
/*     */     try {
/* 250 */       db.reset();
/*     */ 
/*     */       
/* 253 */       if (!db.isNamespaceAware()) {
/*     */         return;
/*     */       }
/* 256 */       this.documentBuilderPool.offerFirst(db);
/* 257 */     } catch (UnsupportedOperationException unsupportedOperationException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addProcessingInstructionsTo(List<Node> list, Node node) {
/* 263 */     if (node instanceof ProcessingInstruction) {
/* 264 */       list.add(node);
/*     */     }
/* 266 */     if (node.getChildNodes() != null) {
/* 267 */       for (int i = 0; i < node.getChildNodes().getLength(); i++) {
/* 268 */         addProcessingInstructionsTo(list, node.getChildNodes().item(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addCommentsTo(List<Node> list, Node node) {
/* 274 */     if (node instanceof Comment) {
/* 275 */       list.add(node);
/*     */     }
/* 277 */     if (node.getChildNodes() != null) {
/* 278 */       for (int i = 0; i < node.getChildNodes().getLength(); i++) {
/* 279 */         addProcessingInstructionsTo(list, node.getChildNodes().item(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addTextNodesToRemoveAndTrim(List<Node> toRemove, Node node) {
/* 285 */     if (node instanceof Text) {
/* 286 */       Text text = (Text)node;
/* 287 */       boolean BUG_369394_IS_VALID = false;
/* 288 */       if (!BUG_369394_IS_VALID) {
/* 289 */         text.setData(text.getData().trim());
/*     */       }
/* 291 */       else if (text.getData().trim().length() == 0) {
/* 292 */         text.setData("");
/*     */       } 
/*     */       
/* 295 */       if (text.getData().length() == 0) {
/* 296 */         toRemove.add(node);
/*     */       }
/*     */     } 
/* 299 */     if (node.getChildNodes() != null) {
/* 300 */       for (int i = 0; i < node.getChildNodes().getLength(); i++) {
/* 301 */         addTextNodesToRemoveAndTrim(toRemove, node.getChildNodes().item(i));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final Node toXml(String defaultNamespaceUri, String xml) throws SAXException {
/* 308 */     DocumentBuilder builder = null;
/*     */     try {
/* 310 */       String syntheticXml = "<parent xmlns=\"" + defaultNamespaceUri + "\">" + xml + "</parent>";
/*     */       
/* 312 */       builder = getDocumentBuilderFromPool();
/*     */       
/* 314 */       Document document = builder.parse(new InputSource(new StringReader(syntheticXml)));
/*     */       
/* 316 */       if (this.ignoreProcessingInstructions) {
/* 317 */         List<Node> list = new ArrayList<>();
/* 318 */         addProcessingInstructionsTo(list, document);
/* 319 */         for (Node node1 : list) {
/* 320 */           node1.getParentNode().removeChild(node1);
/*     */         }
/*     */       } 
/* 323 */       if (this.ignoreComments) {
/* 324 */         List<Node> list = new ArrayList<>();
/* 325 */         addCommentsTo(list, document);
/* 326 */         for (Node node1 : list) {
/* 327 */           node1.getParentNode().removeChild(node1);
/*     */         }
/*     */       } 
/* 330 */       if (this.ignoreWhitespace) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 338 */         List<Node> list = new ArrayList<>();
/* 339 */         addTextNodesToRemoveAndTrim(list, document);
/* 340 */         for (Node node1 : list) {
/* 341 */           node1.getParentNode().removeChild(node1);
/*     */         }
/*     */       } 
/* 344 */       NodeList rv = document.getDocumentElement().getChildNodes();
/* 345 */       if (rv.getLength() > 1) {
/* 346 */         throw ScriptRuntime.constructError("SyntaxError", "XML objects may contain at most one node.");
/*     */       }
/* 348 */       if (rv.getLength() == 0) {
/* 349 */         Node node1 = document.createTextNode("");
/* 350 */         return node1;
/*     */       } 
/* 352 */       Node node = rv.item(0);
/* 353 */       document.getDocumentElement().removeChild(node);
/* 354 */       return node;
/*     */     }
/* 356 */     catch (IOException e) {
/* 357 */       throw new RuntimeException("Unreachable.");
/* 358 */     } catch (ParserConfigurationException e) {
/* 359 */       throw new RuntimeException(e);
/*     */     } finally {
/* 361 */       if (builder != null) returnDocumentBuilderToPool(builder); 
/*     */     } 
/*     */   }
/*     */   
/*     */   Document newDocument() {
/* 366 */     DocumentBuilder builder = null;
/*     */     
/*     */     try {
/* 369 */       builder = getDocumentBuilderFromPool();
/* 370 */       return builder.newDocument();
/* 371 */     } catch (ParserConfigurationException ex) {
/*     */       
/* 373 */       throw new RuntimeException(ex);
/*     */     } finally {
/* 375 */       if (builder != null) returnDocumentBuilderToPool(builder);
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private String toString(Node node) {
/* 381 */     DOMSource source = new DOMSource(node);
/* 382 */     StringWriter writer = new StringWriter();
/* 383 */     StreamResult result = new StreamResult(writer);
/*     */     
/*     */     try {
/* 386 */       Transformer transformer = this.xform.newTransformer();
/* 387 */       transformer.setOutputProperty("omit-xml-declaration", "yes");
/*     */       
/* 389 */       transformer.setOutputProperty("indent", "no");
/* 390 */       transformer.setOutputProperty("method", "xml");
/* 391 */       transformer.transform(source, result);
/* 392 */     } catch (TransformerConfigurationException ex) {
/*     */       
/* 394 */       throw new RuntimeException(ex);
/* 395 */     } catch (TransformerException ex) {
/*     */       
/* 397 */       throw new RuntimeException(ex);
/*     */     } 
/* 399 */     return toXmlNewlines(writer.toString());
/*     */   }
/*     */   
/*     */   String escapeAttributeValue(Object value) {
/* 403 */     String text = ScriptRuntime.toString(value);
/*     */     
/* 405 */     if (text.length() == 0) return "";
/*     */     
/* 407 */     Document dom = newDocument();
/* 408 */     Element e = dom.createElement("a");
/* 409 */     e.setAttribute("b", text);
/* 410 */     String elementText = toString(e);
/* 411 */     int begin = elementText.indexOf('"');
/* 412 */     int end = elementText.lastIndexOf('"');
/* 413 */     return elementText.substring(begin + 1, end);
/*     */   }
/*     */   
/*     */   String escapeTextValue(Object value) {
/* 417 */     if (value instanceof XMLObjectImpl) {
/* 418 */       return ((XMLObjectImpl)value).toXMLString();
/*     */     }
/*     */     
/* 421 */     String text = ScriptRuntime.toString(value);
/*     */     
/* 423 */     if (text.length() == 0) return text;
/*     */     
/* 425 */     Document dom = newDocument();
/* 426 */     Element e = dom.createElement("a");
/* 427 */     e.setTextContent(text);
/* 428 */     String elementText = toString(e);
/*     */     
/* 430 */     int begin = elementText.indexOf('>') + 1;
/* 431 */     int end = elementText.lastIndexOf('<');
/* 432 */     return (begin < end) ? elementText.substring(begin, end) : "";
/*     */   }
/*     */ 
/*     */   
/*     */   private String escapeElementValue(String s) {
/* 437 */     return escapeTextValue(s);
/*     */   }
/*     */ 
/*     */   
/*     */   private String elementToXmlString(Element element) {
/* 442 */     Element copy = (Element)element.cloneNode(true);
/* 443 */     if (this.prettyPrint) {
/* 444 */       beautifyElement(copy, 0);
/*     */     }
/* 446 */     return toString(copy);
/*     */   }
/*     */ 
/*     */   
/*     */   final String ecmaToXmlString(Node node) {
/* 451 */     StringBuilder s = new StringBuilder();
/* 452 */     int indentLevel = 0;
/* 453 */     if (this.prettyPrint) {
/* 454 */       for (int i = 0; i < indentLevel; i++) {
/* 455 */         s.append(' ');
/*     */       }
/*     */     }
/* 458 */     if (node instanceof Text) {
/* 459 */       String data = ((Text)node).getData();
/*     */       
/* 461 */       String v = this.prettyPrint ? data.trim() : data;
/* 462 */       s.append(escapeElementValue(v));
/* 463 */       return s.toString();
/*     */     } 
/* 465 */     if (node instanceof Attr) {
/* 466 */       String value = ((Attr)node).getValue();
/* 467 */       s.append(escapeAttributeValue(value));
/* 468 */       return s.toString();
/*     */     } 
/* 470 */     if (node instanceof Comment) {
/* 471 */       s.append("<!--" + ((Comment)node).getNodeValue() + "-->");
/* 472 */       return s.toString();
/*     */     } 
/* 474 */     if (node instanceof ProcessingInstruction) {
/* 475 */       ProcessingInstruction pi = (ProcessingInstruction)node;
/* 476 */       s.append("<?" + pi.getTarget() + " " + pi.getData() + "?>");
/* 477 */       return s.toString();
/*     */     } 
/* 479 */     s.append(elementToXmlString((Element)node));
/* 480 */     return s.toString();
/*     */   }
/*     */   
/*     */   private void beautifyElement(Element e, int indent) {
/* 484 */     StringBuilder s = new StringBuilder();
/* 485 */     s.append('\n');
/* 486 */     for (int i = 0; i < indent; i++) {
/* 487 */       s.append(' ');
/*     */     }
/* 489 */     String afterContent = s.toString();
/* 490 */     for (int j = 0; j < this.prettyIndent; j++) {
/* 491 */       s.append(' ');
/*     */     }
/* 493 */     String beforeContent = s.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 498 */     ArrayList<Node> toIndent = new ArrayList<>();
/* 499 */     boolean indentChildren = false; int k;
/* 500 */     for (k = 0; k < e.getChildNodes().getLength(); k++) {
/* 501 */       if (k == 1) indentChildren = true; 
/* 502 */       if (e.getChildNodes().item(k) instanceof Text) {
/* 503 */         toIndent.add(e.getChildNodes().item(k));
/*     */       } else {
/* 505 */         indentChildren = true;
/* 506 */         toIndent.add(e.getChildNodes().item(k));
/*     */       } 
/*     */     } 
/* 509 */     if (indentChildren) {
/* 510 */       for (k = 0; k < toIndent.size(); k++) {
/* 511 */         e.insertBefore(e.getOwnerDocument().createTextNode(beforeContent), toIndent.get(k));
/*     */       }
/*     */     }
/* 514 */     NodeList nodes = e.getChildNodes();
/* 515 */     ArrayList<Element> list = new ArrayList<>();
/* 516 */     for (int m = 0; m < nodes.getLength(); m++) {
/* 517 */       if (nodes.item(m) instanceof Element) {
/* 518 */         list.add((Element)nodes.item(m));
/*     */       }
/*     */     } 
/* 521 */     for (Element elem : list) {
/* 522 */       beautifyElement(elem, indent + this.prettyIndent);
/*     */     }
/* 524 */     if (indentChildren)
/* 525 */       e.appendChild(e.getOwnerDocument().createTextNode(afterContent)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XmlProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */