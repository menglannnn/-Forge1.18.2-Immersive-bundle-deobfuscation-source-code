/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.IdScriptableObject;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class QName
/*     */   extends IdScriptableObject
/*     */ {
/*     */   static final long serialVersionUID = 416745167693026750L;
/*  24 */   private static final Object QNAME_TAG = "QName"; private XMLLibImpl lib;
/*     */   private QName prototype;
/*     */   private XmlNode.QName delegate;
/*     */   private static final int Id_localName = 1;
/*     */   private static final int Id_uri = 2;
/*     */   private static final int MAX_INSTANCE_ID = 2;
/*     */   private static final int Id_constructor = 1;
/*     */   private static final int Id_toString = 2;
/*     */   private static final int Id_toSource = 3;
/*     */   private static final int MAX_PROTOTYPE_ID = 3;
/*     */   
/*     */   static QName create(XMLLibImpl lib, Scriptable scope, QName prototype, XmlNode.QName delegate) {
/*  36 */     QName rv = new QName();
/*  37 */     rv.lib = lib;
/*  38 */     rv.setParentScope(scope);
/*  39 */     rv.prototype = prototype;
/*  40 */     rv.setPrototype((Scriptable)prototype);
/*  41 */     rv.delegate = delegate;
/*  42 */     return rv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void exportAsJSClass(boolean sealed) {
/*  51 */     exportAsJSClass(3, getParentScope(), sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  57 */     if (this.delegate.getNamespace() == null)
/*  58 */       return "*::" + localName(); 
/*  59 */     if (this.delegate.getNamespace().isGlobal())
/*     */     {
/*  61 */       return localName();
/*     */     }
/*  63 */     return uri() + "::" + localName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String localName() {
/*  68 */     if (this.delegate.getLocalName() == null) return "*"; 
/*  69 */     return this.delegate.getLocalName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String prefix() {
/*  77 */     if (this.delegate.getNamespace() == null) return null; 
/*  78 */     return this.delegate.getNamespace().getPrefix();
/*     */   }
/*     */   
/*     */   String uri() {
/*  82 */     if (this.delegate.getNamespace() == null) return null; 
/*  83 */     return this.delegate.getNamespace().getUri();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   final XmlNode.QName toNodeQname() {
/*  89 */     return this.delegate;
/*     */   }
/*     */   
/*     */   final XmlNode.QName getDelegate() {
/*  93 */     return this.delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  98 */     if (!(obj instanceof QName)) return false; 
/*  99 */     return equals((QName)obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 104 */     return this.delegate.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object equivalentValues(Object value) {
/* 110 */     if (!(value instanceof QName)) return Scriptable.NOT_FOUND; 
/* 111 */     boolean result = equals((QName)value);
/* 112 */     return result ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */   private boolean equals(QName q) {
/* 116 */     return this.delegate.equals(q.delegate);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 121 */     return "QName";
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class<?> hint) {
/* 126 */     return toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxInstanceId() {
/* 138 */     return super.getMaxInstanceId() + 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(String s) {
/* 146 */     int attr, id = 0; String X = null;
/* 147 */     int s_length = s.length();
/* 148 */     if (s_length == 3) { X = "uri"; id = 2; }
/* 149 */     else if (s_length == 9) { X = "localName"; id = 1; }
/* 150 */      if (X != null && X != s && !X.equals(s)) id = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     if (id == 0) return super.findInstanceIdInfo(s);
/*     */ 
/*     */     
/* 158 */     switch (id) {
/*     */       case 1:
/*     */       case 2:
/* 161 */         attr = 5;
/*     */ 
/*     */ 
/*     */         
/* 165 */         return instanceIdInfo(attr, super.getMaxInstanceId() + id);
/*     */     } 
/*     */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/* 172 */     switch (id - super.getMaxInstanceId()) { case 1:
/* 173 */         return "localName";
/* 174 */       case 2: return "uri"; }
/*     */     
/* 176 */     return super.getInstanceIdName(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/* 182 */     switch (id - super.getMaxInstanceId()) { case 1:
/* 183 */         return localName();
/* 184 */       case 2: return uri(); }
/*     */     
/* 186 */     return super.getInstanceIdValue(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 201 */     int id = 0; String X = null;
/* 202 */     int s_length = s.length();
/* 203 */     if (s_length == 8)
/* 204 */     { int c = s.charAt(3);
/* 205 */       if (c == 111) { X = "toSource"; id = 3; }
/* 206 */       else if (c == 116) { X = "toString"; id = 2; }
/*     */        }
/* 208 */     else if (s_length == 11) { X = "constructor"; id = 1; }
/* 209 */      if (X != null && X != s && !X.equals(s)) id = 0;
/*     */ 
/*     */ 
/*     */     
/* 213 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 222 */     switch (id) { case 1:
/* 223 */         arity = 2; s = "constructor"; break;
/* 224 */       case 2: arity = 0; s = "toString"; break;
/* 225 */       case 3: arity = 0; s = "toSource"; break;
/* 226 */       default: throw new IllegalArgumentException(String.valueOf(id)); }
/*     */     
/* 228 */     initPrototypeMethod(QNAME_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 238 */     if (!f.hasTag(QNAME_TAG)) {
/* 239 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 241 */     int id = f.methodId();
/* 242 */     switch (id) {
/*     */       case 1:
/* 244 */         return jsConstructor(cx, (thisObj == null), args);
/*     */       case 2:
/* 246 */         return realThis(thisObj, f).toString();
/*     */       case 3:
/* 248 */         return realThis(thisObj, f).js_toSource();
/*     */     } 
/* 250 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */   
/*     */   private QName realThis(Scriptable thisObj, IdFunctionObject f) {
/* 255 */     return (QName)ensureType(thisObj, QName.class, f);
/*     */   }
/*     */   
/*     */   QName newQName(XMLLibImpl lib, String q_uri, String q_localName, String q_prefix) {
/* 259 */     QName prototype = this.prototype;
/* 260 */     if (prototype == null) {
/* 261 */       prototype = this;
/*     */     }
/* 263 */     XmlNode.Namespace ns = null;
/* 264 */     if (q_prefix != null) {
/* 265 */       ns = XmlNode.Namespace.create(q_prefix, q_uri);
/* 266 */     } else if (q_uri != null) {
/* 267 */       ns = XmlNode.Namespace.create(q_uri);
/*     */     } 
/* 269 */     if (q_localName != null && q_localName.equals("*")) q_localName = null; 
/* 270 */     return create(lib, getParentScope(), prototype, XmlNode.QName.create(ns, q_localName));
/*     */   }
/*     */ 
/*     */   
/*     */   QName constructQName(XMLLibImpl lib, Context cx, Object namespace, Object name) {
/* 275 */     String q_uri, q_prefix, nameString = null;
/* 276 */     if (name instanceof QName) {
/* 277 */       if (namespace == Undefined.instance) {
/* 278 */         return (QName)name;
/*     */       }
/* 280 */       nameString = ((QName)name).localName();
/*     */     } 
/*     */     
/* 283 */     if (name == Undefined.instance) {
/* 284 */       nameString = "";
/*     */     } else {
/* 286 */       nameString = ScriptRuntime.toString(name);
/*     */     } 
/*     */     
/* 289 */     if (namespace == Undefined.instance) {
/* 290 */       if ("*".equals(nameString)) {
/* 291 */         namespace = null;
/*     */       } else {
/* 293 */         namespace = lib.getDefaultNamespace(cx);
/*     */       } 
/*     */     }
/* 296 */     Namespace namespaceNamespace = null;
/* 297 */     if (namespace != null)
/*     */     {
/* 299 */       if (namespace instanceof Namespace) {
/* 300 */         namespaceNamespace = (Namespace)namespace;
/*     */       } else {
/* 302 */         namespaceNamespace = lib.newNamespace(ScriptRuntime.toString(namespace));
/*     */       }  } 
/* 304 */     String q_localName = nameString;
/*     */ 
/*     */     
/* 307 */     if (namespace == null) {
/* 308 */       q_uri = null;
/* 309 */       q_prefix = null;
/*     */     } else {
/* 311 */       q_uri = namespaceNamespace.uri();
/* 312 */       q_prefix = namespaceNamespace.prefix();
/*     */     } 
/* 314 */     return newQName(lib, q_uri, q_localName, q_prefix);
/*     */   }
/*     */   
/*     */   QName constructQName(XMLLibImpl lib, Context cx, Object nameValue) {
/* 318 */     return constructQName(lib, cx, Undefined.instance, nameValue);
/*     */   }
/*     */   
/*     */   QName castToQName(XMLLibImpl lib, Context cx, Object qnameValue) {
/* 322 */     if (qnameValue instanceof QName) {
/* 323 */       return (QName)qnameValue;
/*     */     }
/* 325 */     return constructQName(lib, cx, qnameValue);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object jsConstructor(Context cx, boolean inNewExpr, Object[] args) {
/* 330 */     if (!inNewExpr && args.length == 1) {
/* 331 */       return castToQName(this.lib, cx, args[0]);
/*     */     }
/* 333 */     if (args.length == 0)
/* 334 */       return constructQName(this.lib, cx, Undefined.instance); 
/* 335 */     if (args.length == 1) {
/* 336 */       return constructQName(this.lib, cx, args[0]);
/*     */     }
/* 338 */     return constructQName(this.lib, cx, args[0], args[1]);
/*     */   }
/*     */ 
/*     */   
/*     */   private String js_toSource() {
/* 343 */     StringBuilder sb = new StringBuilder();
/* 344 */     sb.append('(');
/* 345 */     toSourceImpl(uri(), localName(), prefix(), sb);
/* 346 */     sb.append(')');
/* 347 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static void toSourceImpl(String uri, String localName, String prefix, StringBuilder sb) {
/* 351 */     sb.append("new QName(");
/* 352 */     if (uri == null && prefix == null) {
/* 353 */       if (!"*".equals(localName)) {
/* 354 */         sb.append("null, ");
/*     */       }
/* 356 */     } else if (uri != null) {
/* 357 */       Namespace.toSourceImpl(prefix, uri, sb);
/* 358 */       sb.append(", ");
/*     */     } 
/* 360 */     sb.append('\'');
/* 361 */     sb.append(ScriptRuntime.escapeString(localName, '\''));
/* 362 */     sb.append("')");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\QName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */