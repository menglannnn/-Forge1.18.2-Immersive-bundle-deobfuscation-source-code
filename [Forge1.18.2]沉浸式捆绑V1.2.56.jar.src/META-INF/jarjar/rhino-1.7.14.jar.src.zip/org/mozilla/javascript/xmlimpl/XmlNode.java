/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ import org.w3c.dom.UserDataHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XmlNode
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String XML_NAMESPACES_NAMESPACE_URI = "http://www.w3.org/2000/xmlns/";
/*  28 */   private static final String USER_DATA_XMLNODE_KEY = XmlNode.class.getName();
/*     */   
/*     */   private static final boolean DOM_LEVEL_3 = true;
/*     */ 
/*     */   
/*     */   private static XmlNode getUserData(Node node) {
/*  34 */     return (XmlNode)node.getUserData(USER_DATA_XMLNODE_KEY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setUserData(Node node, XmlNode wrap) {
/*  41 */     node.setUserData(USER_DATA_XMLNODE_KEY, wrap, wrap.events);
/*     */   }
/*     */ 
/*     */   
/*     */   private static XmlNode createImpl(Node node) {
/*  46 */     if (node instanceof Document) throw new IllegalArgumentException(); 
/*  47 */     XmlNode rv = null;
/*  48 */     if (getUserData(node) == null) {
/*  49 */       rv = new XmlNode();
/*  50 */       rv.dom = node;
/*  51 */       setUserData(node, rv);
/*     */     } else {
/*  53 */       rv = getUserData(node);
/*     */     } 
/*  55 */     return rv;
/*     */   }
/*     */   
/*     */   static XmlNode newElementWithText(XmlProcessor processor, XmlNode reference, QName qname, String value) {
/*  59 */     if (reference instanceof Document) throw new IllegalArgumentException("Cannot use Document node as reference"); 
/*  60 */     Document document = null;
/*  61 */     if (reference != null) {
/*  62 */       document = reference.dom.getOwnerDocument();
/*     */     } else {
/*  64 */       document = processor.newDocument();
/*     */     } 
/*  66 */     Node referenceDom = (reference != null) ? reference.dom : null;
/*  67 */     Namespace ns = qname.getNamespace();
/*     */ 
/*     */     
/*  70 */     Element e = (ns == null || ns.getUri().length() == 0) ? document.createElementNS(null, qname.getLocalName()) : document.createElementNS(ns.getUri(), qname
/*  71 */         .qualify(referenceDom));
/*  72 */     if (value != null) {
/*  73 */       e.appendChild(document.createTextNode(value));
/*     */     }
/*  75 */     return createImpl(e);
/*     */   }
/*     */   
/*     */   static XmlNode createText(XmlProcessor processor, String value) {
/*  79 */     return createImpl(processor.newDocument().createTextNode(value));
/*     */   }
/*     */   
/*     */   static XmlNode createElementFromNode(Node node) {
/*  83 */     if (node instanceof Document)
/*  84 */       node = ((Document)node).getDocumentElement(); 
/*  85 */     return createImpl(node);
/*     */   }
/*     */   
/*     */   static XmlNode createElement(XmlProcessor processor, String namespaceUri, String xml) throws SAXException {
/*  89 */     return createImpl(processor.toXml(namespaceUri, xml));
/*     */   }
/*     */   
/*     */   static XmlNode createEmpty(XmlProcessor processor) {
/*  93 */     return createText(processor, "");
/*     */   }
/*     */   
/*     */   private static XmlNode copy(XmlNode other) {
/*  97 */     return createImpl(other.dom.cloneNode(true));
/*     */   }
/*     */   
/* 100 */   private UserDataHandler events = new XmlNodeUserDataHandler();
/*     */ 
/*     */   
/*     */   private Node dom;
/*     */ 
/*     */   
/*     */   private XML xml;
/*     */ 
/*     */   
/*     */   String debug() {
/* 110 */     XmlProcessor raw = new XmlProcessor();
/* 111 */     raw.setIgnoreComments(false);
/* 112 */     raw.setIgnoreProcessingInstructions(false);
/* 113 */     raw.setIgnoreWhitespace(false);
/* 114 */     raw.setPrettyPrinting(false);
/* 115 */     return raw.ecmaToXmlString(this.dom);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     return "XmlNode: type=" + this.dom.getNodeType() + " dom=" + this.dom.toString();
/*     */   }
/*     */   
/*     */   XML getXml() {
/* 124 */     return this.xml;
/*     */   }
/*     */   
/*     */   void setXml(XML xml) {
/* 128 */     this.xml = xml;
/*     */   }
/*     */   
/*     */   int getChildCount() {
/* 132 */     return this.dom.getChildNodes().getLength();
/*     */   }
/*     */   
/*     */   XmlNode parent() {
/* 136 */     Node domParent = this.dom.getParentNode();
/* 137 */     if (domParent instanceof Document) return null; 
/* 138 */     if (domParent == null) return null; 
/* 139 */     return createImpl(domParent);
/*     */   }
/*     */   
/*     */   int getChildIndex() {
/* 143 */     if (isAttributeType()) return -1; 
/* 144 */     if (parent() == null) return -1; 
/* 145 */     NodeList siblings = this.dom.getParentNode().getChildNodes();
/* 146 */     for (int i = 0; i < siblings.getLength(); i++) {
/* 147 */       if (siblings.item(i) == this.dom) {
/* 148 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 152 */     throw new RuntimeException("Unreachable.");
/*     */   }
/*     */   
/*     */   void removeChild(int index) {
/* 156 */     this.dom.removeChild(this.dom.getChildNodes().item(index));
/*     */   }
/*     */   
/*     */   String toXmlString(XmlProcessor processor) {
/* 160 */     return processor.ecmaToXmlString(this.dom);
/*     */   }
/*     */ 
/*     */   
/*     */   String ecmaValue() {
/* 165 */     if (isTextType())
/* 166 */       return ((Text)this.dom).getData(); 
/* 167 */     if (isAttributeType())
/* 168 */       return ((Attr)this.dom).getValue(); 
/* 169 */     if (isProcessingInstructionType())
/* 170 */       return ((ProcessingInstruction)this.dom).getData(); 
/* 171 */     if (isCommentType())
/* 172 */       return ((Comment)this.dom).getNodeValue(); 
/* 173 */     if (isElementType()) {
/* 174 */       throw new RuntimeException("Unimplemented ecmaValue() for elements.");
/*     */     }
/* 176 */     throw new RuntimeException("Unimplemented for node " + this.dom);
/*     */   }
/*     */ 
/*     */   
/*     */   void deleteMe() {
/* 181 */     if (this.dom instanceof Attr) {
/* 182 */       Attr attr = (Attr)this.dom;
/* 183 */       attr.getOwnerElement().getAttributes().removeNamedItemNS(attr.getNamespaceURI(), attr.getLocalName());
/*     */     }
/* 185 */     else if (this.dom.getParentNode() != null) {
/* 186 */       this.dom.getParentNode().removeChild(this.dom);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void normalize() {
/* 195 */     this.dom.normalize();
/*     */   }
/*     */   
/*     */   void insertChildAt(int index, XmlNode node) {
/* 199 */     Node parent = this.dom;
/* 200 */     Node child = parent.getOwnerDocument().importNode(node.dom, true);
/* 201 */     if (parent.getChildNodes().getLength() < index)
/*     */     {
/* 203 */       throw new IllegalArgumentException("index=" + index + " length=" + parent.getChildNodes().getLength());
/*     */     }
/* 205 */     if (parent.getChildNodes().getLength() == index) {
/* 206 */       parent.appendChild(child);
/*     */     } else {
/* 208 */       parent.insertBefore(child, parent.getChildNodes().item(index));
/*     */     } 
/*     */   }
/*     */   
/*     */   void insertChildrenAt(int index, XmlNode[] nodes) {
/* 213 */     for (int i = 0; i < nodes.length; i++) {
/* 214 */       insertChildAt(index + i, nodes[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   XmlNode getChild(int index) {
/* 219 */     Node child = this.dom.getChildNodes().item(index);
/* 220 */     return createImpl(child);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean hasChildElement() {
/* 225 */     NodeList nodes = this.dom.getChildNodes();
/* 226 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 227 */       if (nodes.item(i).getNodeType() == 1) return true; 
/*     */     } 
/* 229 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isSameNode(XmlNode other) {
/* 234 */     return (this.dom == other.dom);
/*     */   }
/*     */   
/*     */   private String toUri(String ns) {
/* 238 */     return (ns == null) ? "" : ns;
/*     */   }
/*     */   
/*     */   private void addNamespaces(Namespaces rv, Element element) {
/* 242 */     if (element == null) throw new RuntimeException("element must not be null"); 
/* 243 */     String myDefaultNamespace = toUri(element.lookupNamespaceURI(null));
/* 244 */     String parentDefaultNamespace = "";
/* 245 */     if (element.getParentNode() != null) {
/* 246 */       parentDefaultNamespace = toUri(element.getParentNode().lookupNamespaceURI(null));
/*     */     }
/* 248 */     if (!myDefaultNamespace.equals(parentDefaultNamespace) || !(element.getParentNode() instanceof Element)) {
/* 249 */       rv.declare(Namespace.create("", myDefaultNamespace));
/*     */     }
/* 251 */     NamedNodeMap attributes = element.getAttributes();
/* 252 */     for (int i = 0; i < attributes.getLength(); i++) {
/* 253 */       Attr attr = (Attr)attributes.item(i);
/* 254 */       if (attr.getPrefix() != null && attr.getPrefix().equals("xmlns")) {
/* 255 */         rv.declare(Namespace.create(attr.getLocalName(), attr.getValue()));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Namespaces getAllNamespaces() {
/* 261 */     Namespaces rv = new Namespaces();
/*     */     
/* 263 */     Node target = this.dom;
/* 264 */     if (target instanceof Attr) {
/* 265 */       target = ((Attr)target).getOwnerElement();
/*     */     }
/* 267 */     while (target != null) {
/* 268 */       if (target instanceof Element) {
/* 269 */         addNamespaces(rv, (Element)target);
/*     */       }
/* 271 */       target = target.getParentNode();
/*     */     } 
/*     */     
/* 274 */     rv.declare(Namespace.create("", ""));
/* 275 */     return rv;
/*     */   }
/*     */   
/*     */   Namespace[] getInScopeNamespaces() {
/* 279 */     Namespaces rv = getAllNamespaces();
/* 280 */     return rv.getNamespaces();
/*     */   }
/*     */ 
/*     */   
/*     */   Namespace[] getNamespaceDeclarations() {
/* 285 */     if (this.dom instanceof Element) {
/* 286 */       Namespaces rv = new Namespaces();
/* 287 */       addNamespaces(rv, (Element)this.dom);
/* 288 */       return rv.getNamespaces();
/*     */     } 
/* 290 */     return new Namespace[0];
/*     */   }
/*     */ 
/*     */   
/*     */   Namespace getNamespaceDeclaration(String prefix) {
/* 295 */     if (prefix.equals("") && this.dom instanceof Attr)
/*     */     {
/* 297 */       return Namespace.create("", "");
/*     */     }
/* 299 */     Namespaces rv = getAllNamespaces();
/* 300 */     return rv.getNamespace(prefix);
/*     */   }
/*     */   
/*     */   Namespace getNamespaceDeclaration() {
/* 304 */     if (this.dom.getPrefix() == null) return getNamespaceDeclaration(""); 
/* 305 */     return getNamespaceDeclaration(this.dom.getPrefix());
/*     */   }
/*     */   
/*     */   static class XmlNodeUserDataHandler
/*     */     implements UserDataHandler, Serializable {
/*     */     private static final long serialVersionUID = 4666895518900769588L;
/*     */     
/*     */     public void handle(short operation, String key, Object data, Node src, Node dest) {}
/*     */   }
/*     */   
/*     */   private static class Namespaces {
/* 316 */     private Map<String, String> map = new HashMap<>();
/* 317 */     private Map<String, String> uriToPrefix = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void declare(XmlNode.Namespace n) {
/* 323 */       if (this.map.get(n.prefix) == null) {
/* 324 */         this.map.put(n.prefix, n.uri);
/*     */       }
/*     */ 
/*     */       
/* 328 */       if (this.uriToPrefix.get(n.uri) == null) {
/* 329 */         this.uriToPrefix.put(n.uri, n.prefix);
/*     */       }
/*     */     }
/*     */     
/*     */     XmlNode.Namespace getNamespaceByUri(String uri) {
/* 334 */       if (this.uriToPrefix.get(uri) == null) return null; 
/* 335 */       return XmlNode.Namespace.create(uri, this.uriToPrefix.get(uri));
/*     */     }
/*     */     
/*     */     XmlNode.Namespace getNamespace(String prefix) {
/* 339 */       if (this.map.get(prefix) == null) return null; 
/* 340 */       return XmlNode.Namespace.create(prefix, this.map.get(prefix));
/*     */     }
/*     */     
/*     */     XmlNode.Namespace[] getNamespaces() {
/* 344 */       ArrayList<XmlNode.Namespace> rv = new ArrayList<>();
/* 345 */       for (Map.Entry<String, String> e : this.map.entrySet()) {
/* 346 */         XmlNode.Namespace n = XmlNode.Namespace.create(e.getKey(), e.getValue());
/* 347 */         if (!n.isEmpty()) {
/* 348 */           rv.add(n);
/*     */         }
/*     */       } 
/* 351 */       return rv.<XmlNode.Namespace>toArray(new XmlNode.Namespace[rv.size()]);
/*     */     }
/*     */   }
/*     */   
/*     */   final XmlNode copy() {
/* 356 */     return copy(this);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean isParentType() {
/* 361 */     return isElementType();
/*     */   }
/*     */   
/*     */   final boolean isTextType() {
/* 365 */     return (this.dom.getNodeType() == 3 || this.dom.getNodeType() == 4);
/*     */   }
/*     */   
/*     */   final boolean isAttributeType() {
/* 369 */     return (this.dom.getNodeType() == 2);
/*     */   }
/*     */   
/*     */   final boolean isProcessingInstructionType() {
/* 373 */     return (this.dom.getNodeType() == 7);
/*     */   }
/*     */   
/*     */   final boolean isCommentType() {
/* 377 */     return (this.dom.getNodeType() == 8);
/*     */   }
/*     */   
/*     */   final boolean isElementType() {
/* 381 */     return (this.dom.getNodeType() == 1);
/*     */   }
/*     */   
/*     */   final void renameNode(QName qname) {
/* 385 */     this.dom = this.dom.getOwnerDocument().renameNode(this.dom, qname.getNamespace().getUri(), qname.qualify(this.dom));
/*     */   }
/*     */   
/*     */   void invalidateNamespacePrefix() {
/* 389 */     if (!(this.dom instanceof Element)) throw new IllegalStateException(); 
/* 390 */     String prefix = this.dom.getPrefix();
/* 391 */     QName after = QName.create(this.dom.getNamespaceURI(), this.dom.getLocalName(), null);
/* 392 */     renameNode(after);
/* 393 */     NamedNodeMap attrs = this.dom.getAttributes();
/* 394 */     for (int i = 0; i < attrs.getLength(); i++) {
/* 395 */       if (attrs.item(i).getPrefix().equals(prefix)) {
/* 396 */         createImpl(attrs.item(i)).renameNode(QName.create(attrs.item(i).getNamespaceURI(), attrs.item(i).getLocalName(), null));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void declareNamespace(Element e, String prefix, String uri) {
/* 402 */     if (prefix.length() > 0) {
/* 403 */       e.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + prefix, uri);
/*     */     } else {
/* 405 */       e.setAttribute("xmlns", uri);
/*     */     } 
/*     */   }
/*     */   
/*     */   void declareNamespace(String prefix, String uri) {
/* 410 */     if (!(this.dom instanceof Element)) throw new IllegalStateException(); 
/* 411 */     if (this.dom.lookupNamespaceURI(uri) == null || !this.dom.lookupNamespaceURI(uri).equals(prefix)) {
/*     */ 
/*     */       
/* 414 */       Element e = (Element)this.dom;
/* 415 */       declareNamespace(e, prefix, uri);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Namespace getDefaultNamespace() {
/* 420 */     String prefix = "";
/* 421 */     String uri = (this.dom.lookupNamespaceURI(null) == null) ? "" : this.dom.lookupNamespaceURI(null);
/* 422 */     return Namespace.create(prefix, uri);
/*     */   }
/*     */   
/*     */   private String getExistingPrefixFor(Namespace namespace) {
/* 426 */     if (getDefaultNamespace().getUri().equals(namespace.getUri())) {
/* 427 */       return "";
/*     */     }
/* 429 */     return this.dom.lookupPrefix(namespace.getUri());
/*     */   }
/*     */   
/*     */   private Namespace getNodeNamespace() {
/* 433 */     String uri = this.dom.getNamespaceURI();
/* 434 */     String prefix = this.dom.getPrefix();
/* 435 */     if (uri == null) uri = ""; 
/* 436 */     if (prefix == null) prefix = ""; 
/* 437 */     return Namespace.create(prefix, uri);
/*     */   }
/*     */   
/*     */   Namespace getNamespace() {
/* 441 */     return getNodeNamespace();
/*     */   }
/*     */   
/*     */   void removeNamespace(Namespace namespace) {
/* 445 */     Namespace current = getNodeNamespace();
/*     */ 
/*     */     
/* 448 */     if (namespace.is(current))
/* 449 */       return;  NamedNodeMap attrs = this.dom.getAttributes();
/* 450 */     for (int i = 0; i < attrs.getLength(); i++) {
/* 451 */       XmlNode attr = createImpl(attrs.item(i));
/* 452 */       if (namespace.is(attr.getNodeNamespace())) {
/*     */         return;
/*     */       }
/*     */     } 
/* 456 */     String existingPrefix = getExistingPrefixFor(namespace);
/* 457 */     if (existingPrefix != null) {
/* 458 */       if (namespace.isUnspecifiedPrefix()) {
/*     */ 
/*     */         
/* 461 */         declareNamespace(existingPrefix, getDefaultNamespace().getUri());
/*     */       }
/* 463 */       else if (existingPrefix.equals(namespace.getPrefix())) {
/* 464 */         declareNamespace(existingPrefix, getDefaultNamespace().getUri());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setProcessingInstructionName(String localName) {
/* 473 */     ProcessingInstruction pi = (ProcessingInstruction)this.dom;
/*     */     
/* 475 */     pi.getParentNode().replaceChild(pi, pi
/*     */         
/* 477 */         .getOwnerDocument().createProcessingInstruction(localName, pi.getData()));
/*     */   }
/*     */ 
/*     */   
/*     */   final void setLocalName(String localName) {
/* 482 */     if (this.dom instanceof ProcessingInstruction) {
/* 483 */       setProcessingInstructionName(localName);
/*     */     } else {
/* 485 */       String prefix = this.dom.getPrefix();
/* 486 */       if (prefix == null) prefix = ""; 
/* 487 */       this.dom = this.dom.getOwnerDocument().renameNode(this.dom, this.dom.getNamespaceURI(), QName.qualify(prefix, localName));
/*     */     } 
/*     */   }
/*     */   
/*     */   final QName getQname() {
/* 492 */     String uri = (this.dom.getNamespaceURI() == null) ? "" : this.dom.getNamespaceURI();
/* 493 */     String prefix = (this.dom.getPrefix() == null) ? "" : this.dom.getPrefix();
/* 494 */     return QName.create(uri, this.dom.getLocalName(), prefix);
/*     */   }
/*     */   
/*     */   void addMatchingChildren(XMLList result, Filter filter) {
/* 498 */     Node node = this.dom;
/* 499 */     NodeList children = node.getChildNodes();
/* 500 */     for (int i = 0; i < children.getLength(); i++) {
/* 501 */       Node childnode = children.item(i);
/* 502 */       XmlNode child = createImpl(childnode);
/* 503 */       if (filter.accept(childnode)) {
/* 504 */         result.addToList(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   XmlNode[] getMatchingChildren(Filter filter) {
/* 510 */     ArrayList<XmlNode> rv = new ArrayList<>();
/* 511 */     NodeList nodes = this.dom.getChildNodes();
/* 512 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 513 */       Node node = nodes.item(i);
/* 514 */       if (filter.accept(node)) {
/* 515 */         rv.add(createImpl(node));
/*     */       }
/*     */     } 
/* 518 */     return rv.<XmlNode>toArray(new XmlNode[rv.size()]);
/*     */   }
/*     */   
/*     */   XmlNode[] getAttributes() {
/* 522 */     NamedNodeMap attrs = this.dom.getAttributes();
/*     */     
/* 524 */     if (attrs == null) throw new IllegalStateException("Must be element."); 
/* 525 */     XmlNode[] rv = new XmlNode[attrs.getLength()];
/* 526 */     for (int i = 0; i < attrs.getLength(); i++) {
/* 527 */       rv[i] = createImpl(attrs.item(i));
/*     */     }
/* 529 */     return rv;
/*     */   }
/*     */   
/*     */   String getAttributeValue() {
/* 533 */     return ((Attr)this.dom).getValue();
/*     */   }
/*     */   
/*     */   void setAttribute(QName name, String value) {
/* 537 */     if (!(this.dom instanceof Element)) throw new IllegalStateException("Can only set attribute on elements."); 
/* 538 */     name.setAttribute((Element)this.dom, value);
/*     */   }
/*     */   
/*     */   void replaceWith(XmlNode other) {
/* 542 */     Node replacement = this.dom.getOwnerDocument().importNode(other.dom, true);
/* 543 */     this.dom.getParentNode().replaceChild(replacement, this.dom);
/*     */   }
/*     */   
/*     */   String ecmaToXMLString(XmlProcessor processor) {
/* 547 */     if (isElementType()) {
/* 548 */       Element copy = (Element)this.dom.cloneNode(true);
/* 549 */       Namespace[] inScope = getInScopeNamespaces();
/* 550 */       for (int i = 0; i < inScope.length; i++) {
/* 551 */         declareNamespace(copy, inScope[i].getPrefix(), inScope[i].getUri());
/*     */       }
/* 553 */       return processor.ecmaToXmlString(copy);
/*     */     } 
/* 555 */     return processor.ecmaToXmlString(this.dom);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class Namespace
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 4073904386884677090L;
/*     */ 
/*     */     
/*     */     static Namespace create(String prefix, String uri) {
/* 567 */       if (prefix == null) {
/* 568 */         throw new IllegalArgumentException("Empty string represents default namespace prefix");
/*     */       }
/*     */       
/* 571 */       if (uri == null) {
/* 572 */         throw new IllegalArgumentException("Namespace may not lack a URI");
/*     */       }
/*     */       
/* 575 */       Namespace rv = new Namespace();
/* 576 */       rv.prefix = prefix;
/* 577 */       rv.uri = uri;
/* 578 */       return rv;
/*     */     }
/*     */     
/*     */     static Namespace create(String uri) {
/* 582 */       Namespace rv = new Namespace();
/* 583 */       rv.uri = uri;
/*     */ 
/*     */       
/* 586 */       if (uri == null || uri.length() == 0) {
/* 587 */         rv.prefix = "";
/*     */       }
/*     */       
/* 590 */       return rv;
/*     */     }
/*     */     
/* 593 */     static final Namespace GLOBAL = create("", "");
/*     */ 
/*     */     
/*     */     private String prefix;
/*     */ 
/*     */     
/*     */     private String uri;
/*     */ 
/*     */     
/*     */     public String toString() {
/* 603 */       if (this.prefix == null) return "XmlNode.Namespace [" + this.uri + "]"; 
/* 604 */       return "XmlNode.Namespace [" + this.prefix + "{" + this.uri + "}]";
/*     */     }
/*     */     
/*     */     boolean isUnspecifiedPrefix() {
/* 608 */       return (this.prefix == null);
/*     */     }
/*     */     
/*     */     boolean is(Namespace other) {
/* 612 */       return (this.prefix != null && other.prefix != null && this.prefix.equals(other.prefix) && this.uri.equals(other.uri));
/*     */     }
/*     */     
/*     */     boolean isEmpty() {
/* 616 */       return (this.prefix != null && this.prefix.equals("") && this.uri.equals(""));
/*     */     }
/*     */     
/*     */     boolean isDefault() {
/* 620 */       return (this.prefix != null && this.prefix.equals(""));
/*     */     }
/*     */     
/*     */     boolean isGlobal() {
/* 624 */       return (this.uri != null && this.uri.equals(""));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void setPrefix(String prefix) {
/* 630 */       if (prefix == null) throw new IllegalArgumentException(); 
/* 631 */       this.prefix = prefix;
/*     */     }
/*     */     
/*     */     String getPrefix() {
/* 635 */       return this.prefix;
/*     */     }
/*     */     
/*     */     String getUri() {
/* 639 */       return this.uri;
/*     */     }
/*     */   }
/*     */   
/*     */   static class QName
/*     */     implements Serializable {
/*     */     private static final long serialVersionUID = -6587069811691451077L;
/*     */     private XmlNode.Namespace namespace;
/*     */     private String localName;
/*     */     
/*     */     static QName create(XmlNode.Namespace namespace, String localName) {
/* 650 */       if (localName != null && localName.equals("*")) throw new RuntimeException("* is not valid localName"); 
/* 651 */       QName rv = new QName();
/* 652 */       rv.namespace = namespace;
/* 653 */       rv.localName = localName;
/* 654 */       return rv;
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     static QName create(String uri, String localName, String prefix) {
/* 660 */       return create(XmlNode.Namespace.create(prefix, uri), localName);
/*     */     }
/*     */     
/*     */     static String qualify(String prefix, String localName) {
/* 664 */       if (prefix == null) throw new IllegalArgumentException("prefix must not be null"); 
/* 665 */       if (prefix.length() > 0) return prefix + ":" + localName; 
/* 666 */       return localName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 677 */       return "XmlNode.QName [" + this.localName + "," + this.namespace + "]";
/*     */     }
/*     */     
/*     */     private boolean equals(String one, String two) {
/* 681 */       if (one == null && two == null) return true; 
/* 682 */       if (one == null || two == null) return false; 
/* 683 */       return one.equals(two);
/*     */     }
/*     */     
/*     */     private boolean namespacesEqual(XmlNode.Namespace one, XmlNode.Namespace two) {
/* 687 */       if (one == null && two == null) return true; 
/* 688 */       if (one == null || two == null) return false; 
/* 689 */       return equals(one.getUri(), two.getUri());
/*     */     }
/*     */     
/*     */     final boolean equals(QName other) {
/* 693 */       if (!namespacesEqual(this.namespace, other.namespace)) return false; 
/* 694 */       if (!equals(this.localName, other.localName)) return false; 
/* 695 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 700 */       if (!(obj instanceof QName)) {
/* 701 */         return false;
/*     */       }
/* 703 */       return equals((QName)obj);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 708 */       return (this.localName == null) ? 0 : this.localName.hashCode();
/*     */     }
/*     */     
/*     */     void lookupPrefix(Node node) {
/* 712 */       if (node == null) throw new IllegalArgumentException("node must not be null"); 
/* 713 */       String prefix = node.lookupPrefix(this.namespace.getUri());
/* 714 */       if (prefix == null) {
/*     */         
/* 716 */         String defaultNamespace = node.lookupNamespaceURI(null);
/* 717 */         if (defaultNamespace == null) defaultNamespace = ""; 
/* 718 */         String nodeNamespace = this.namespace.getUri();
/* 719 */         if (nodeNamespace.equals(defaultNamespace)) {
/* 720 */           prefix = "";
/*     */         }
/*     */       } 
/* 723 */       int i = 0;
/* 724 */       while (prefix == null) {
/* 725 */         String generatedPrefix = "e4x_" + i++;
/* 726 */         String generatedUri = node.lookupNamespaceURI(generatedPrefix);
/* 727 */         if (generatedUri == null) {
/* 728 */           prefix = generatedPrefix;
/* 729 */           Node top = node;
/* 730 */           while (top.getParentNode() != null && top.getParentNode() instanceof Element) {
/* 731 */             top = top.getParentNode();
/*     */           }
/* 733 */           ((Element)top).setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + prefix, this.namespace.getUri());
/*     */         } 
/*     */       } 
/* 736 */       this.namespace.setPrefix(prefix);
/*     */     }
/*     */     
/*     */     String qualify(Node node) {
/* 740 */       if (this.namespace.getPrefix() == null) {
/* 741 */         if (node != null) {
/* 742 */           lookupPrefix(node);
/*     */         } else {
/* 744 */           this.namespace.setPrefix("");
/*     */         } 
/*     */       }
/* 747 */       return qualify(this.namespace.getPrefix(), this.localName);
/*     */     }
/*     */     
/*     */     void setAttribute(Element element, String value) {
/* 751 */       if (this.namespace.getPrefix() == null) lookupPrefix(element); 
/* 752 */       element.setAttributeNS(this.namespace.getUri(), qualify(this.namespace.getPrefix(), this.localName), value);
/*     */     }
/*     */     
/*     */     XmlNode.Namespace getNamespace() {
/* 756 */       return this.namespace;
/*     */     }
/*     */     
/*     */     String getLocalName() {
/* 760 */       return this.localName;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class InternalList
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = -3633151157292048978L;
/* 769 */     private List<XmlNode> list = new ArrayList<>();
/*     */ 
/*     */     
/*     */     private void _add(XmlNode n) {
/* 773 */       this.list.add(n);
/*     */     }
/*     */     
/*     */     XmlNode item(int index) {
/* 777 */       return this.list.get(index);
/*     */     }
/*     */     
/*     */     void remove(int index) {
/* 781 */       this.list.remove(index);
/*     */     }
/*     */     
/*     */     void add(InternalList other) {
/* 785 */       for (int i = 0; i < other.length(); i++) {
/* 786 */         _add(other.item(i));
/*     */       }
/*     */     }
/*     */     
/*     */     void add(InternalList from, int startInclusive, int endExclusive) {
/* 791 */       for (int i = startInclusive; i < endExclusive; i++) {
/* 792 */         _add(from.item(i));
/*     */       }
/*     */     }
/*     */     
/*     */     void add(XmlNode node) {
/* 797 */       _add(node);
/*     */     }
/*     */ 
/*     */     
/*     */     void add(XML xml) {
/* 802 */       _add(xml.getAnnotation());
/*     */     }
/*     */ 
/*     */     
/*     */     void addToList(Object toAdd) {
/* 807 */       if (toAdd instanceof org.mozilla.javascript.Undefined) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 812 */       if (toAdd instanceof XMLList) {
/* 813 */         XMLList xmlSrc = (XMLList)toAdd;
/* 814 */         for (int i = 0; i < xmlSrc.length(); i++) {
/* 815 */           _add(xmlSrc.item(i).getAnnotation());
/*     */         }
/* 817 */       } else if (toAdd instanceof XML) {
/* 818 */         _add(((XML)toAdd).getAnnotation());
/* 819 */       } else if (toAdd instanceof XmlNode) {
/* 820 */         _add((XmlNode)toAdd);
/*     */       } 
/*     */     }
/*     */     
/*     */     int length() {
/* 825 */       return this.list.size();
/*     */     }
/*     */   }
/*     */   
/*     */   static abstract class Filter {
/* 830 */     static final Filter COMMENT = new Filter()
/*     */       {
/*     */         boolean accept(Node node) {
/* 833 */           return (node.getNodeType() == 8);
/*     */         }
/*     */       };
/* 836 */     static final Filter TEXT = new Filter()
/*     */       {
/*     */         boolean accept(Node node) {
/* 839 */           return (node.getNodeType() == 3);
/*     */         }
/*     */       };
/*     */     static Filter PROCESSING_INSTRUCTION(final XMLName name) {
/* 843 */       return new Filter()
/*     */         {
/*     */           boolean accept(Node node) {
/* 846 */             if (node.getNodeType() == 7) {
/* 847 */               ProcessingInstruction pi = (ProcessingInstruction)node;
/* 848 */               return name.matchesLocalName(pi.getTarget());
/*     */             } 
/* 850 */             return false;
/*     */           }
/*     */         };
/*     */     }
/* 854 */     static Filter ELEMENT = new Filter()
/*     */       {
/*     */         boolean accept(Node node) {
/* 857 */           return (node.getNodeType() == 1);
/*     */         }
/*     */       };
/* 860 */     static Filter TRUE = new Filter()
/*     */       {
/*     */         boolean accept(Node node) {
/* 863 */           return true;
/*     */         }
/*     */       };
/*     */     
/*     */     abstract boolean accept(Node param1Node);
/*     */   }
/*     */   
/*     */   Node toDomNode() {
/* 871 */     return this.dom;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XmlNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */