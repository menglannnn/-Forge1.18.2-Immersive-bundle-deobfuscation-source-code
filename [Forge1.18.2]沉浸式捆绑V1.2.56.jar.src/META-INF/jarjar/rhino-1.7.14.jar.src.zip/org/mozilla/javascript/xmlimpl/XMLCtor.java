/*     */ package org.mozilla.javascript.xmlimpl;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionCall;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XMLCtor
/*     */   extends IdFunctionObject
/*     */ {
/*     */   static final long serialVersionUID = -8708195078359817341L;
/*  20 */   private static final Object XMLCTOR_TAG = "XMLCtor"; private XmlProcessor options;
/*     */   private static final int Id_ignoreComments = 1;
/*     */   private static final int Id_ignoreProcessingInstructions = 2;
/*     */   private static final int Id_ignoreWhitespace = 3;
/*     */   private static final int Id_prettyIndent = 4;
/*     */   
/*     */   XMLCtor(XML xml, Object tag, int id, int arity) {
/*  27 */     super((IdFunctionCall)xml, tag, id, arity);
/*     */     
/*  29 */     this.options = xml.getProcessor();
/*  30 */     activatePrototypeMap(3);
/*     */   }
/*     */   private static final int Id_prettyPrinting = 5; private static final int MAX_INSTANCE_ID = 5; private static final int Id_defaultSettings = 1; private static final int Id_settings = 2; private static final int Id_setSettings = 3; private static final int MAX_FUNCTION_ID = 3;
/*     */   
/*     */   private void writeSetting(Scriptable target) {
/*  35 */     for (int i = 1; i <= 5; i++) {
/*  36 */       int id = super.getMaxInstanceId() + i;
/*  37 */       String name = getInstanceIdName(id);
/*  38 */       Object value = getInstanceIdValue(id);
/*  39 */       ScriptableObject.putProperty(target, name, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readSettings(Scriptable source) {
/*     */     // Byte code:
/*     */     //   0: iconst_1
/*     */     //   1: istore_2
/*     */     //   2: iload_2
/*     */     //   3: iconst_5
/*     */     //   4: if_icmpgt -> 119
/*     */     //   7: aload_0
/*     */     //   8: invokespecial getMaxInstanceId : ()I
/*     */     //   11: iload_2
/*     */     //   12: iadd
/*     */     //   13: istore_3
/*     */     //   14: aload_0
/*     */     //   15: iload_3
/*     */     //   16: invokevirtual getInstanceIdName : (I)Ljava/lang/String;
/*     */     //   19: astore #4
/*     */     //   21: aload_1
/*     */     //   22: aload #4
/*     */     //   24: invokestatic getProperty : (Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   27: astore #5
/*     */     //   29: aload #5
/*     */     //   31: getstatic org/mozilla/javascript/Scriptable.NOT_FOUND : Ljava/lang/Object;
/*     */     //   34: if_acmpne -> 40
/*     */     //   37: goto -> 113
/*     */     //   40: iload_2
/*     */     //   41: tableswitch default -> 98, 1 -> 76, 2 -> 76, 3 -> 76, 4 -> 87, 5 -> 76
/*     */     //   76: aload #5
/*     */     //   78: instanceof java/lang/Boolean
/*     */     //   81: ifne -> 106
/*     */     //   84: goto -> 113
/*     */     //   87: aload #5
/*     */     //   89: instanceof java/lang/Number
/*     */     //   92: ifne -> 106
/*     */     //   95: goto -> 113
/*     */     //   98: new java/lang/IllegalStateException
/*     */     //   101: dup
/*     */     //   102: invokespecial <init> : ()V
/*     */     //   105: athrow
/*     */     //   106: aload_0
/*     */     //   107: iload_3
/*     */     //   108: aload #5
/*     */     //   110: invokevirtual setInstanceIdValue : (ILjava/lang/Object;)V
/*     */     //   113: iinc #2, 1
/*     */     //   116: goto -> 2
/*     */     //   119: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #45	-> 0
/*     */     //   #46	-> 7
/*     */     //   #47	-> 14
/*     */     //   #48	-> 21
/*     */     //   #49	-> 29
/*     */     //   #50	-> 37
/*     */     //   #52	-> 40
/*     */     //   #57	-> 76
/*     */     //   #58	-> 84
/*     */     //   #62	-> 87
/*     */     //   #63	-> 95
/*     */     //   #67	-> 98
/*     */     //   #69	-> 106
/*     */     //   #45	-> 113
/*     */     //   #71	-> 119
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   14	99	3	id	I
/*     */     //   21	92	4	name	Ljava/lang/String;
/*     */     //   29	84	5	value	Ljava/lang/Object;
/*     */     //   2	117	2	i	I
/*     */     //   0	120	0	this	Lorg/mozilla/javascript/xmlimpl/XMLCtor;
/*     */     //   0	120	1	source	Lorg/mozilla/javascript/Scriptable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxInstanceId() {
/*  87 */     return super.getMaxInstanceId() + 5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(String s) {
/*  94 */     int attr, c, id = 0; String X = null;
/*  95 */     switch (s.length()) { case 12:
/*  96 */         X = "prettyIndent"; id = 4; break;
/*  97 */       case 14: c = s.charAt(0);
/*  98 */         if (c == 105) { X = "ignoreComments"; id = 1; break; }
/*  99 */          if (c == 112) { X = "prettyPrinting"; id = 5; }  break;
/*     */       case 16:
/* 101 */         X = "ignoreWhitespace"; id = 3; break;
/* 102 */       case 28: X = "ignoreProcessingInstructions"; id = 2; break; }
/*     */     
/* 104 */     if (X != null && X != s && !X.equals(s)) id = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     if (id == 0) return super.findInstanceIdInfo(s);
/*     */ 
/*     */     
/* 112 */     switch (id) {
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/* 118 */         attr = 6;
/*     */ 
/*     */ 
/*     */         
/* 122 */         return instanceIdInfo(attr, super.getMaxInstanceId() + id);
/*     */     } 
/*     */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/* 130 */     switch (id - super.getMaxInstanceId()) { case 1:
/* 131 */         return "ignoreComments";
/* 132 */       case 2: return "ignoreProcessingInstructions";
/* 133 */       case 3: return "ignoreWhitespace";
/* 134 */       case 4: return "prettyIndent";
/* 135 */       case 5: return "prettyPrinting"; }
/*     */     
/* 137 */     return super.getInstanceIdName(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/* 143 */     switch (id - super.getMaxInstanceId()) {
/*     */       case 1:
/* 145 */         return ScriptRuntime.wrapBoolean(this.options.isIgnoreComments());
/*     */       case 2:
/* 147 */         return ScriptRuntime.wrapBoolean(this.options.isIgnoreProcessingInstructions());
/*     */       case 3:
/* 149 */         return ScriptRuntime.wrapBoolean(this.options.isIgnoreWhitespace());
/*     */       case 4:
/* 151 */         return ScriptRuntime.wrapInt(this.options.getPrettyIndent());
/*     */       case 5:
/* 153 */         return ScriptRuntime.wrapBoolean(this.options.isPrettyPrinting());
/*     */     } 
/* 155 */     return super.getInstanceIdValue(id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setInstanceIdValue(int id, Object value) {
/* 160 */     switch (id - super.getMaxInstanceId()) {
/*     */       case 1:
/* 162 */         this.options.setIgnoreComments(ScriptRuntime.toBoolean(value));
/*     */         return;
/*     */       case 2:
/* 165 */         this.options.setIgnoreProcessingInstructions(ScriptRuntime.toBoolean(value));
/*     */         return;
/*     */       case 3:
/* 168 */         this.options.setIgnoreWhitespace(ScriptRuntime.toBoolean(value));
/*     */         return;
/*     */       case 4:
/* 171 */         this.options.setPrettyIndent(ScriptRuntime.toInt32(value));
/*     */         return;
/*     */       case 5:
/* 174 */         this.options.setPrettyPrinting(ScriptRuntime.toBoolean(value));
/*     */         return;
/*     */     } 
/* 177 */     super.setInstanceIdValue(id, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 192 */     int id = 0; String X = null;
/* 193 */     int s_length = s.length();
/* 194 */     if (s_length == 8) { X = "settings"; id = 2; }
/* 195 */     else if (s_length == 11) { X = "setSettings"; id = 3; }
/* 196 */     else if (s_length == 15) { X = "defaultSettings"; id = 1; }
/* 197 */      if (X != null && X != s && !X.equals(s)) id = 0;
/*     */ 
/*     */ 
/*     */     
/* 201 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 210 */     switch (id) { case 1:
/* 211 */         arity = 0; s = "defaultSettings"; break;
/* 212 */       case 2: arity = 0; s = "settings"; break;
/* 213 */       case 3: arity = 1; s = "setSettings"; break;
/* 214 */       default: throw new IllegalArgumentException(String.valueOf(id)); }
/*     */     
/* 216 */     initPrototypeMethod(XMLCTOR_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     Scriptable obj;
/* 223 */     if (!f.hasTag(XMLCTOR_TAG)) {
/* 224 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 226 */     int id = f.methodId();
/* 227 */     switch (id) {
/*     */       case 1:
/* 229 */         this.options.setDefault();
/* 230 */         obj = cx.newObject(scope);
/* 231 */         writeSetting(obj);
/* 232 */         return obj;
/*     */       
/*     */       case 2:
/* 235 */         obj = cx.newObject(scope);
/* 236 */         writeSetting(obj);
/* 237 */         return obj;
/*     */       
/*     */       case 3:
/* 240 */         if (args.length == 0 || args[0] == null || args[0] == Undefined.instance) {
/*     */ 
/*     */ 
/*     */           
/* 244 */           this.options.setDefault();
/* 245 */         } else if (args[0] instanceof Scriptable) {
/* 246 */           readSettings((Scriptable)args[0]);
/*     */         } 
/* 248 */         return Undefined.instance;
/*     */     } 
/*     */     
/* 251 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasInstance(Scriptable instance) {
/* 259 */     return (instance instanceof XML || instance instanceof XMLList);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xmlimpl\XMLCtor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */