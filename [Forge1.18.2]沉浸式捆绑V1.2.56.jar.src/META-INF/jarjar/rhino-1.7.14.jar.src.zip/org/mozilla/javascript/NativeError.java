/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeError
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = -5338413581437645187L;
/*  19 */   private static final Object ERROR_TAG = "Error";
/*     */   public static final int DEFAULT_STACK_LIMIT = -1;
/*     */   private static final String STACK_HIDE_KEY = "_stackHide";
/*     */   private RhinoException stackProvider;
/*     */   private Object stack;
/*     */   private static final int Id_constructor = 1;
/*     */   private static final int Id_toString = 2;
/*     */   private static final int Id_toSource = 3;
/*     */   private static final int ConstructorId_captureStackTrace = -1;
/*     */   private static final int MAX_PROTOTYPE_ID = 3;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  31 */     NativeError obj = new NativeError();
/*  32 */     ScriptableObject.putProperty(obj, "name", "Error");
/*  33 */     ScriptableObject.putProperty(obj, "message", "");
/*  34 */     ScriptableObject.putProperty(obj, "fileName", "");
/*  35 */     ScriptableObject.putProperty(obj, "lineNumber", Integer.valueOf(0));
/*  36 */     obj.setAttributes("name", 2);
/*  37 */     obj.setAttributes("message", 2);
/*  38 */     obj.exportAsJSClass(3, scope, sealed);
/*  39 */     NativeCallSite.init(obj, sealed);
/*     */   }
/*     */   
/*     */   static NativeError make(Context cx, Scriptable scope, IdFunctionObject ctorObj, Object[] args) {
/*  43 */     Scriptable proto = (Scriptable)ctorObj.get("prototype", ctorObj);
/*     */     
/*  45 */     NativeError obj = new NativeError();
/*  46 */     obj.setPrototype(proto);
/*  47 */     obj.setParentScope(scope);
/*     */     
/*  49 */     int arglen = args.length;
/*  50 */     if (arglen >= 1) {
/*  51 */       if (!Undefined.isUndefined(args[0])) {
/*  52 */         ScriptableObject.putProperty(obj, "message", ScriptRuntime.toString(args[0]));
/*  53 */         obj.setAttributes("message", 2);
/*     */       } 
/*  55 */       if (arglen >= 2) {
/*  56 */         ScriptableObject.putProperty(obj, "fileName", args[1]);
/*  57 */         if (arglen >= 3) {
/*  58 */           int line = ScriptRuntime.toInt32(args[2]);
/*  59 */           ScriptableObject.putProperty(obj, "lineNumber", Integer.valueOf(line));
/*     */         } 
/*     */       } 
/*     */     } 
/*  63 */     return obj;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/*  68 */     addIdFunctionProperty(ctor, ERROR_TAG, -1, "captureStackTrace", 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     this.stackProvider = new EvaluatorException("");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     ProtoProps protoProps = new ProtoProps();
/*  80 */     associateValue("_ErrorPrototypeProps", protoProps);
/*     */     
/*  82 */     ctor.defineProperty("stackTraceLimit", protoProps::getStackTraceLimit, protoProps::setStackTraceLimit, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     ctor.defineProperty("prepareStackTrace", protoProps::getPrepareStackTrace, protoProps::setPrepareStackTrace, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     super.fillConstructorProperties(ctor);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  98 */     return "Error";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     Object toString = js_toString(this);
/* 105 */     return (toString instanceof String) ? (String)toString : super.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 112 */     switch (id) {
/*     */       case 1:
/* 114 */         arity = 1;
/* 115 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 118 */         arity = 0;
/* 119 */         s = "toString";
/*     */         break;
/*     */       case 3:
/* 122 */         arity = 0;
/* 123 */         s = "toSource";
/*     */         break;
/*     */       default:
/* 126 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 128 */     initPrototypeMethod(ERROR_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     NativeError err;
/* 134 */     if (!f.hasTag(ERROR_TAG)) {
/* 135 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 137 */     int id = f.methodId();
/* 138 */     switch (id) {
/*     */       case 1:
/* 140 */         err = make(cx, scope, f, args);
/*     */ 
/*     */         
/* 143 */         err.setStackProvider(new EvaluatorException(""));
/* 144 */         return err;
/*     */       
/*     */       case 2:
/* 147 */         return js_toString(thisObj);
/*     */       
/*     */       case 3:
/* 150 */         return js_toSource(cx, scope, thisObj);
/*     */       
/*     */       case -1:
/* 153 */         js_captureStackTrace(cx, scope, thisObj, args);
/* 154 */         return Undefined.instance;
/*     */     } 
/* 156 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStackProvider(RhinoException re) {
/* 164 */     if (this.stackProvider == null) {
/* 165 */       defineProperty("stack", this::getStackDelegated, this::setStackDelegated, 2);
/*     */     }
/* 167 */     this.stackProvider = re;
/*     */   }
/*     */   public Object getStackDelegated() {
/*     */     Object value;
/* 171 */     if (this.stack != null) {
/* 172 */       return this.stack;
/*     */     }
/* 174 */     if (this.stackProvider == null) {
/* 175 */       return NOT_FOUND;
/*     */     }
/*     */ 
/*     */     
/* 179 */     int limit = -1;
/* 180 */     Function prepare = null;
/* 181 */     NativeError cons = (NativeError)getPrototype();
/* 182 */     ProtoProps pp = (ProtoProps)cons.getAssociatedValue("_ErrorPrototypeProps");
/*     */     
/* 184 */     if (pp != null) {
/* 185 */       limit = pp.stackTraceLimit;
/* 186 */       prepare = pp.prepareStackTrace;
/*     */     } 
/*     */ 
/*     */     
/* 190 */     String hideFunc = (String)getAssociatedValue("_stackHide");
/* 191 */     ScriptStackElement[] stackTrace = this.stackProvider.getScriptStack(limit, hideFunc);
/*     */ 
/*     */ 
/*     */     
/* 195 */     if (prepare == null) {
/* 196 */       value = RhinoException.formatStackTrace(stackTrace, this.stackProvider.details());
/*     */     } else {
/* 198 */       value = callPrepareStack(prepare, stackTrace);
/*     */     } 
/* 200 */     this.stack = value;
/* 201 */     return value;
/*     */   }
/*     */   
/*     */   public void setStackDelegated(Object value) {
/* 205 */     this.stackProvider = null;
/* 206 */     this.stack = value;
/*     */   }
/*     */   
/*     */   private Object callPrepareStack(Function prepare, ScriptStackElement[] stack) {
/* 210 */     Context cx = Context.getCurrentContext();
/* 211 */     Object[] elts = new Object[stack.length];
/*     */ 
/*     */     
/* 214 */     for (int i = 0; i < stack.length; i++) {
/* 215 */       NativeCallSite site = (NativeCallSite)cx.newObject(this, "CallSite");
/* 216 */       site.setElement(stack[i]);
/* 217 */       elts[i] = site;
/*     */     } 
/*     */     
/* 220 */     Scriptable eltArray = cx.newArray(this, elts);
/* 221 */     return prepare.call(cx, prepare, this, new Object[] { this, eltArray });
/*     */   }
/*     */   private static Object js_toString(Scriptable thisObj) {
/*     */     String name, msg;
/* 225 */     Object nameObj = ScriptableObject.getProperty(thisObj, "name");
/*     */     
/* 227 */     if (nameObj == NOT_FOUND || Undefined.isUndefined(nameObj)) {
/* 228 */       name = "Error";
/*     */     } else {
/* 230 */       name = ScriptRuntime.toString(nameObj);
/*     */     } 
/* 232 */     Object msgObj = ScriptableObject.getProperty(thisObj, "message");
/*     */     
/* 234 */     if (msgObj == NOT_FOUND || Undefined.isUndefined(msgObj)) {
/* 235 */       msg = "";
/*     */     } else {
/* 237 */       msg = ScriptRuntime.toString(msgObj);
/*     */     } 
/* 239 */     if (name.isEmpty())
/* 240 */       return msg; 
/* 241 */     if (msg.isEmpty()) {
/* 242 */       return name;
/*     */     }
/* 244 */     return name + ": " + msg;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String js_toSource(Context cx, Scriptable scope, Scriptable thisObj) {
/* 250 */     Object name = ScriptableObject.getProperty(thisObj, "name");
/* 251 */     Object message = ScriptableObject.getProperty(thisObj, "message");
/* 252 */     Object fileName = ScriptableObject.getProperty(thisObj, "fileName");
/* 253 */     Object lineNumber = ScriptableObject.getProperty(thisObj, "lineNumber");
/*     */     
/* 255 */     StringBuilder sb = new StringBuilder();
/* 256 */     sb.append("(new ");
/* 257 */     if (name == NOT_FOUND) {
/* 258 */       name = Undefined.instance;
/*     */     }
/* 260 */     sb.append(ScriptRuntime.toString(name));
/* 261 */     sb.append("(");
/* 262 */     if (message != NOT_FOUND || fileName != NOT_FOUND || lineNumber != NOT_FOUND) {
/* 263 */       if (message == NOT_FOUND) {
/* 264 */         message = "";
/*     */       }
/* 266 */       sb.append(ScriptRuntime.uneval(cx, scope, message));
/* 267 */       if (fileName != NOT_FOUND || lineNumber != NOT_FOUND) {
/* 268 */         sb.append(", ");
/* 269 */         if (fileName == NOT_FOUND) {
/* 270 */           fileName = "";
/*     */         }
/* 272 */         sb.append(ScriptRuntime.uneval(cx, scope, fileName));
/* 273 */         if (lineNumber != NOT_FOUND) {
/* 274 */           int line = ScriptRuntime.toInt32(lineNumber);
/* 275 */           if (line != 0) {
/* 276 */             sb.append(", ");
/* 277 */             sb.append(ScriptRuntime.toString(line));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 282 */     sb.append("))");
/* 283 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void js_captureStackTrace(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 288 */     ScriptableObject obj = (ScriptableObject)ScriptRuntime.toObject(cx, scope, args[0]);
/* 289 */     Function func = null;
/* 290 */     if (args.length > 1) {
/* 291 */       func = (Function)ScriptRuntime.toObjectOrNull(cx, args[1], scope);
/*     */     }
/*     */ 
/*     */     
/* 295 */     NativeError err = (NativeError)cx.newObject(thisObj, "Error");
/*     */     
/* 297 */     err.setStackProvider(new EvaluatorException("[object Object]"));
/*     */ 
/*     */     
/* 300 */     if (func != null) {
/* 301 */       Object funcName = func.get("name", func);
/* 302 */       if (funcName != null && !Undefined.isUndefined(funcName)) {
/* 303 */         err.associateValue("_stackHide", Context.toString(funcName));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     obj.defineProperty("stack", err.get("stack"), 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 319 */     switch (s)
/*     */     { case "constructor":
/* 321 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 333 */         return id;case "toString": id = 2; return id;case "toSource": id = 3; return id; }  int id = 0; return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ProtoProps
/*     */     implements Serializable
/*     */   {
/*     */     static final String KEY = "_ErrorPrototypeProps";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static final long serialVersionUID = 1907180507775337939L;
/*     */ 
/*     */ 
/*     */     
/* 352 */     int stackTraceLimit = -1;
/*     */     Function prepareStackTrace;
/*     */     
/*     */     public Object getStackTraceLimit() {
/* 356 */       if (this.stackTraceLimit >= 0) {
/* 357 */         return Integer.valueOf(this.stackTraceLimit);
/*     */       }
/* 359 */       return Double.valueOf(Double.POSITIVE_INFINITY);
/*     */     }
/*     */     
/*     */     public void setStackTraceLimit(Object value) {
/* 363 */       double limit = Context.toNumber(value);
/* 364 */       if (Double.isNaN(limit) || Double.isInfinite(limit)) {
/* 365 */         this.stackTraceLimit = -1;
/*     */       } else {
/* 367 */         this.stackTraceLimit = (int)limit;
/*     */       } 
/*     */     }
/*     */     
/*     */     public Object getPrepareStackTrace() {
/* 372 */       return (this.prepareStackTrace == null) ? Undefined.instance : this.prepareStackTrace;
/*     */     }
/*     */     
/*     */     public void setPrepareStackTrace(Object value) {
/* 376 */       if (value == null || Undefined.isUndefined(value)) {
/* 377 */         this.prepareStackTrace = null;
/* 378 */       } else if (value instanceof Function) {
/* 379 */         this.prepareStackTrace = (Function)value;
/*     */       } 
/*     */     }
/*     */     
/*     */     private ProtoProps() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */