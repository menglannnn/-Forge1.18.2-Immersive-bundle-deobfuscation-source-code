/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ public class NativeMap
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 1171922614280016891L;
/*     */   static final String ITERATOR_TAG = "Map Iterator";
/*     */   private boolean instanceOfMap = false;
/*     */   private static final int Id_constructor = 1;
/*  13 */   private static final Object MAP_TAG = "Map";
/*     */   private static final int Id_set = 2;
/*     */   private static final int Id_get = 3;
/*  16 */   private final Hashtable entries = new Hashtable(); private static final int Id_delete = 4;
/*     */   private static final int Id_has = 5;
/*     */   private static final int Id_clear = 6;
/*     */   
/*     */   static void init(Context cx, Scriptable scope, boolean sealed) {
/*  21 */     NativeMap obj = new NativeMap();
/*  22 */     obj.exportAsJSClass(12, scope, false);
/*     */     
/*  24 */     ScriptableObject desc = (ScriptableObject)cx.newObject(scope);
/*  25 */     desc.put("enumerable", desc, Boolean.FALSE);
/*  26 */     desc.put("configurable", desc, Boolean.TRUE);
/*  27 */     desc.put("get", desc, obj.get(NativeSet.GETSIZE, obj));
/*  28 */     obj.defineOwnProperty(cx, "size", desc);
/*     */     
/*  30 */     if (sealed)
/*  31 */       obj.sealObject(); 
/*     */   }
/*     */   private static final int Id_keys = 7; private static final int Id_values = 8;
/*     */   private static final int Id_entries = 9;
/*     */   
/*     */   public String getClassName() {
/*  37 */     return "Map";
/*     */   }
/*     */   private static final int Id_forEach = 10;
/*     */   private static final int SymbolId_getSize = 11;
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  43 */     if (!f.hasTag(MAP_TAG)) {
/*  44 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  46 */     int id = f.methodId();
/*  47 */     switch (id) {
/*     */       case 1:
/*  49 */         if (thisObj == null) {
/*  50 */           NativeMap nm = new NativeMap();
/*  51 */           nm.instanceOfMap = true;
/*  52 */           if (args.length > 0) {
/*  53 */             loadFromIterable(cx, scope, nm, key(args));
/*     */           }
/*  55 */           return nm;
/*     */         } 
/*  57 */         throw ScriptRuntime.typeErrorById("msg.no.new", new Object[] { "Map" });
/*     */       case 2:
/*  59 */         return realThis(thisObj, f)
/*  60 */           .js_set(key(args), (args.length > 1) ? args[1] : Undefined.instance);
/*     */       case 4:
/*  62 */         return realThis(thisObj, f).js_delete(key(args));
/*     */       case 3:
/*  64 */         return realThis(thisObj, f).js_get(key(args));
/*     */       case 5:
/*  66 */         return realThis(thisObj, f).js_has(key(args));
/*     */       case 6:
/*  68 */         return realThis(thisObj, f).js_clear();
/*     */       case 7:
/*  70 */         return realThis(thisObj, f).js_iterator(scope, NativeCollectionIterator.Type.KEYS);
/*     */       case 8:
/*  72 */         return realThis(thisObj, f)
/*  73 */           .js_iterator(scope, NativeCollectionIterator.Type.VALUES);
/*     */       case 9:
/*  75 */         return realThis(thisObj, f).js_iterator(scope, NativeCollectionIterator.Type.BOTH);
/*     */       case 10:
/*  77 */         return realThis(thisObj, f)
/*  78 */           .js_forEach(cx, scope, (args.length > 0) ? args[0] : Undefined.instance, (args.length > 1) ? args[1] : Undefined.instance);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 11:
/*  84 */         return realThis(thisObj, f).js_getSize();
/*     */     } 
/*  86 */     throw new IllegalArgumentException("Map.prototype has no method: " + f.getFunctionName());
/*     */   }
/*     */   private static final int SymbolId_toStringTag = 12; private static final int MAX_PROTOTYPE_ID = 12;
/*     */   
/*     */   private Object js_set(Object k, Object v) {
/*  91 */     Object key = k;
/*  92 */     if (key instanceof Number && ((Number)key).doubleValue() == ScriptRuntime.negativeZero) {
/*  93 */       key = ScriptRuntime.zeroObj;
/*     */     }
/*  95 */     this.entries.put(key, v);
/*  96 */     return this;
/*     */   }
/*     */   
/*     */   private Object js_delete(Object arg) {
/* 100 */     return Boolean.valueOf(this.entries.deleteEntry(arg));
/*     */   }
/*     */   
/*     */   private Object js_get(Object arg) {
/* 104 */     Hashtable.Entry entry = this.entries.getEntry(arg);
/* 105 */     if (entry == null) {
/* 106 */       return Undefined.instance;
/*     */     }
/* 108 */     return entry.value;
/*     */   }
/*     */   
/*     */   private Object js_has(Object arg) {
/* 112 */     return Boolean.valueOf(this.entries.has(arg));
/*     */   }
/*     */   
/*     */   private Object js_getSize() {
/* 116 */     return Integer.valueOf(this.entries.size());
/*     */   }
/*     */   
/*     */   private Object js_iterator(Scriptable scope, NativeCollectionIterator.Type type) {
/* 120 */     return new NativeCollectionIterator(scope, "Map Iterator", type, this.entries.iterator());
/*     */   }
/*     */   
/*     */   private Object js_clear() {
/* 124 */     this.entries.clear();
/* 125 */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   private Object js_forEach(Context cx, Scriptable scope, Object arg1, Object arg2) {
/* 129 */     if (!(arg1 instanceof Callable)) {
/* 130 */       throw ScriptRuntime.typeErrorById("msg.isnt.function", new Object[] { arg1, 
/* 131 */             ScriptRuntime.typeof(arg1) });
/*     */     }
/* 133 */     Callable f = (Callable)arg1;
/*     */     
/* 135 */     boolean isStrict = cx.isStrictMode();
/* 136 */     Iterator<Hashtable.Entry> i = this.entries.iterator();
/* 137 */     while (i.hasNext()) {
/*     */       
/* 139 */       Scriptable thisObj = ScriptRuntime.toObjectOrNull(cx, arg2, scope);
/*     */       
/* 141 */       if (thisObj == null && !isStrict) {
/* 142 */         thisObj = scope;
/*     */       }
/* 144 */       if (thisObj == null) {
/* 145 */         thisObj = Undefined.SCRIPTABLE_UNDEFINED;
/*     */       }
/*     */       
/* 148 */       Hashtable.Entry e = i.next();
/* 149 */       f.call(cx, scope, thisObj, new Object[] { e.value, e.key, this });
/*     */     } 
/* 151 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadFromIterable(Context cx, Scriptable scope, ScriptableObject map, Object arg1) {
/* 159 */     if (arg1 == null || Undefined.instance.equals(arg1)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 164 */     Object ito = ScriptRuntime.callIterator(arg1, cx, scope);
/* 165 */     if (Undefined.instance.equals(ito)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     Scriptable proto = ScriptableObject.getClassPrototype(scope, map.getClassName());
/* 174 */     Callable set = ScriptRuntime.getPropFunctionAndThis(proto, "set", cx, scope);
/* 175 */     ScriptRuntime.lastStoredScriptable(cx);
/*     */     
/* 177 */     ScriptRuntime.loadFromIterable(cx, scope, arg1, (key, value) -> set.call(cx, scope, map, new Object[] { key, value }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static NativeMap realThis(Scriptable thisObj, IdFunctionObject f) {
/* 187 */     NativeMap nm = ensureType(thisObj, NativeMap.class, f);
/* 188 */     if (!nm.instanceOfMap)
/*     */     {
/* 190 */       throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { f.getFunctionName() });
/*     */     }
/*     */     
/* 193 */     return nm;
/*     */   }
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 198 */     switch (id) {
/*     */       case 11:
/* 200 */         initPrototypeMethod(MAP_TAG, id, NativeSet.GETSIZE, "get size", 0);
/*     */         return;
/*     */       case 12:
/* 203 */         initPrototypeValue(12, SymbolKey.TO_STRING_TAG, 
/*     */ 
/*     */             
/* 206 */             getClassName(), 3);
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 212 */     String fnName = null;
/*     */     
/* 214 */     switch (id) {
/*     */       case 1:
/* 216 */         arity = 0;
/* 217 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 220 */         arity = 2;
/* 221 */         s = "set";
/*     */         break;
/*     */       case 3:
/* 224 */         arity = 1;
/* 225 */         s = "get";
/*     */         break;
/*     */       case 4:
/* 228 */         arity = 1;
/* 229 */         s = "delete";
/*     */         break;
/*     */       case 5:
/* 232 */         arity = 1;
/* 233 */         s = "has";
/*     */         break;
/*     */       case 6:
/* 236 */         arity = 0;
/* 237 */         s = "clear";
/*     */         break;
/*     */       case 7:
/* 240 */         arity = 0;
/* 241 */         s = "keys";
/*     */         break;
/*     */       case 8:
/* 244 */         arity = 0;
/* 245 */         s = "values";
/*     */         break;
/*     */       case 9:
/* 248 */         arity = 0;
/* 249 */         s = "entries";
/*     */         break;
/*     */       case 10:
/* 252 */         arity = 1;
/* 253 */         s = "forEach";
/*     */         break;
/*     */       default:
/* 256 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 258 */     initPrototypeMethod(MAP_TAG, id, s, fnName, arity);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(Symbol k) {
/* 263 */     if (NativeSet.GETSIZE.equals(k)) {
/* 264 */       return 11;
/*     */     }
/* 266 */     if (SymbolKey.ITERATOR.equals(k))
/*     */     {
/*     */ 
/*     */       
/* 270 */       return 9;
/*     */     }
/* 272 */     if (SymbolKey.TO_STRING_TAG.equals(k)) {
/* 273 */       return 12;
/*     */     }
/* 275 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 281 */     switch (s)
/*     */     { case "constructor":
/* 283 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 316 */         return id;case "set": id = 2; return id;case "get": id = 3; return id;case "delete": id = 4; return id;case "has": id = 5; return id;case "clear": id = 6; return id;case "keys": id = 7; return id;case "values": id = 8; return id;case "entries": id = 9; return id;case "forEach": id = 10; return id; }  int id = 0; return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object key(Object[] args) {
/* 343 */     if (args.length > 0) {
/* 344 */       Object key = args[0];
/* 345 */       if (key instanceof Delegator) {
/* 346 */         return ((Delegator)key).getDelegee();
/*     */       }
/* 348 */       return key;
/*     */     } 
/* 350 */     return Undefined.instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */