/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AllPermission;
/*     */ import java.security.Permission;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.lang.model.SourceVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JavaMembers
/*     */ {
/*  37 */   private static final boolean STRICT_REFLECTIVE_ACCESS = (SourceVersion.latestSupported().ordinal() > 8);
/*     */   
/*  39 */   private static final Permission allPermission = new AllPermission(); private Class<?> cl; private Map<String, Object> members; private Map<String, FieldAndMethods> fieldAndMethods;
/*     */   
/*     */   JavaMembers(Scriptable scope, Class<?> cl) {
/*  42 */     this(scope, cl, false);
/*     */   }
/*     */   private Map<String, Object> staticMembers; private Map<String, FieldAndMethods> staticFieldAndMethods; NativeJavaMethod ctors;
/*     */   JavaMembers(Scriptable scope, Class<?> cl, boolean includeProtected) {
/*     */     try {
/*  47 */       Context cx = ContextFactory.getGlobal().enterContext();
/*  48 */       ClassShutter shutter = cx.getClassShutter();
/*  49 */       if (shutter != null && !shutter.visibleToScripts(cl.getName())) {
/*  50 */         throw Context.reportRuntimeErrorById("msg.access.prohibited", new Object[] { cl.getName() });
/*     */       }
/*  52 */       this.members = new HashMap<>();
/*  53 */       this.staticMembers = new HashMap<>();
/*  54 */       this.cl = cl;
/*  55 */       boolean includePrivate = cx.hasFeature(13);
/*  56 */       reflect(scope, includeProtected, includePrivate);
/*     */     } finally {
/*  58 */       Context.exit();
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean has(String name, boolean isStatic) {
/*  63 */     Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/*  64 */     Object obj = ht.get(name);
/*  65 */     if (obj != null) {
/*  66 */       return true;
/*     */     }
/*  68 */     return (findExplicitFunction(name, isStatic) != null);
/*     */   } Object get(Scriptable scope, String name, Object javaObject, boolean isStatic) {
/*     */     Object rval;
/*     */     Class<?> type;
/*  72 */     Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/*  73 */     Object member = ht.get(name);
/*  74 */     if (!isStatic && member == null)
/*     */     {
/*  76 */       member = this.staticMembers.get(name);
/*     */     }
/*  78 */     if (member == null) {
/*     */       
/*  80 */       member = getExplicitFunction(scope, name, javaObject, isStatic);
/*     */ 
/*     */       
/*  83 */       if (member == null) return Scriptable.NOT_FOUND; 
/*     */     } 
/*  85 */     if (member instanceof Scriptable) {
/*  86 */       return member;
/*     */     }
/*  88 */     Context cx = Context.getContext();
/*     */ 
/*     */     
/*     */     try {
/*  92 */       if (member instanceof BeanProperty) {
/*  93 */         BeanProperty bp = (BeanProperty)member;
/*  94 */         if (bp.getter == null) return Scriptable.NOT_FOUND; 
/*  95 */         rval = bp.getter.invoke(javaObject, Context.emptyArgs);
/*  96 */         type = bp.getter.method().getReturnType();
/*     */       } else {
/*  98 */         Field field = (Field)member;
/*  99 */         rval = field.get(isStatic ? null : javaObject);
/* 100 */         type = field.getType();
/*     */       } 
/* 102 */     } catch (Exception ex) {
/* 103 */       throw Context.throwAsScriptRuntimeEx(ex);
/*     */     } 
/*     */     
/* 106 */     scope = ScriptableObject.getTopLevelScope(scope);
/* 107 */     return cx.getWrapFactory().wrap(cx, scope, rval, type);
/*     */   }
/*     */   
/*     */   void put(Scriptable scope, String name, Object javaObject, Object value, boolean isStatic) {
/* 111 */     Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/* 112 */     Object member = ht.get(name);
/* 113 */     if (!isStatic && member == null)
/*     */     {
/* 115 */       member = this.staticMembers.get(name);
/*     */     }
/* 117 */     if (member == null) throw reportMemberNotFound(name); 
/* 118 */     if (member instanceof FieldAndMethods) {
/* 119 */       FieldAndMethods fam = (FieldAndMethods)ht.get(name);
/* 120 */       member = fam.field;
/*     */     } 
/*     */ 
/*     */     
/* 124 */     if (member instanceof BeanProperty) {
/* 125 */       BeanProperty bp = (BeanProperty)member;
/* 126 */       if (bp.setter == null) {
/* 127 */         throw reportMemberNotFound(name);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 132 */       if (bp.setters == null || value == null) {
/* 133 */         Class<?> setType = bp.setter.argTypes[0];
/* 134 */         Object[] args = { Context.jsToJava(value, setType) };
/*     */         try {
/* 136 */           bp.setter.invoke(javaObject, args);
/* 137 */         } catch (Exception ex) {
/* 138 */           throw Context.throwAsScriptRuntimeEx(ex);
/*     */         } 
/*     */       } else {
/* 141 */         Object[] args = { value };
/* 142 */         bp.setters.call(
/* 143 */             Context.getContext(), 
/* 144 */             ScriptableObject.getTopLevelScope(scope), scope, args);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 149 */       if (!(member instanceof Field)) {
/* 150 */         String str = (member == null) ? "msg.java.internal.private" : "msg.java.method.assign";
/*     */         
/* 152 */         throw Context.reportRuntimeErrorById(str, new Object[] { name });
/*     */       } 
/* 154 */       Field field = (Field)member;
/* 155 */       Object javaValue = Context.jsToJava(value, field.getType());
/*     */       try {
/* 157 */         field.set(javaObject, javaValue);
/* 158 */       } catch (IllegalAccessException accessEx) {
/* 159 */         if ((field.getModifiers() & 0x10) != 0) {
/*     */           return;
/*     */         }
/*     */         
/* 163 */         throw Context.throwAsScriptRuntimeEx(accessEx);
/* 164 */       } catch (IllegalArgumentException argEx) {
/* 165 */         throw Context.reportRuntimeErrorById("msg.java.internal.field.type", new Object[] { value
/*     */               
/* 167 */               .getClass().getName(), field, javaObject
/*     */               
/* 169 */               .getClass().getName() });
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   Object[] getIds(boolean isStatic) {
/* 175 */     Map<String, Object> map = isStatic ? this.staticMembers : this.members;
/* 176 */     return map.keySet().toArray(new Object[map.size()]);
/*     */   }
/*     */   
/*     */   static String javaSignature(Class<?> type) {
/* 180 */     if (!type.isArray()) {
/* 181 */       return type.getName();
/*     */     }
/* 183 */     int arrayDimension = 0;
/*     */     while (true) {
/* 185 */       arrayDimension++;
/* 186 */       type = type.getComponentType();
/* 187 */       if (!type.isArray()) {
/* 188 */         String name = type.getName();
/* 189 */         String suffix = "[]";
/* 190 */         if (arrayDimension == 1) {
/* 191 */           return name.concat(suffix);
/*     */         }
/* 193 */         int length = name.length() + arrayDimension * suffix.length();
/* 194 */         StringBuilder sb = new StringBuilder(length);
/* 195 */         sb.append(name);
/* 196 */         while (arrayDimension != 0) {
/* 197 */           arrayDimension--;
/* 198 */           sb.append(suffix);
/*     */         } 
/* 200 */         return sb.toString();
/*     */       } 
/*     */     } 
/*     */   } static String liveConnectSignature(Class<?>[] argTypes) {
/* 204 */     int N = argTypes.length;
/* 205 */     if (N == 0) {
/* 206 */       return "()";
/*     */     }
/* 208 */     StringBuilder sb = new StringBuilder();
/* 209 */     sb.append('(');
/* 210 */     for (int i = 0; i != N; i++) {
/* 211 */       if (i != 0) {
/* 212 */         sb.append(',');
/*     */       }
/* 214 */       sb.append(javaSignature(argTypes[i]));
/*     */     } 
/* 216 */     sb.append(')');
/* 217 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private MemberBox findExplicitFunction(String name, boolean isStatic) {
/* 221 */     int sigStart = name.indexOf('(');
/* 222 */     if (sigStart < 0) {
/* 223 */       return null;
/*     */     }
/*     */     
/* 226 */     Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/* 227 */     MemberBox[] methodsOrCtors = null;
/* 228 */     boolean isCtor = (isStatic && sigStart == 0);
/*     */     
/* 230 */     if (isCtor) {
/*     */       
/* 232 */       methodsOrCtors = this.ctors.methods;
/*     */     } else {
/*     */       
/* 235 */       String trueName = name.substring(0, sigStart);
/* 236 */       Object obj = ht.get(trueName);
/* 237 */       if (!isStatic && obj == null)
/*     */       {
/* 239 */         obj = this.staticMembers.get(trueName);
/*     */       }
/* 241 */       if (obj instanceof NativeJavaMethod) {
/* 242 */         NativeJavaMethod njm = (NativeJavaMethod)obj;
/* 243 */         methodsOrCtors = njm.methods;
/*     */       } 
/*     */     } 
/*     */     
/* 247 */     if (methodsOrCtors != null) {
/* 248 */       for (MemberBox methodsOrCtor : methodsOrCtors) {
/* 249 */         Class<?>[] type = methodsOrCtor.argTypes;
/* 250 */         String sig = liveConnectSignature(type);
/* 251 */         if (sigStart + sig.length() == name.length() && name
/* 252 */           .regionMatches(sigStart, sig, 0, sig.length())) {
/* 253 */           return methodsOrCtor;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 258 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object getExplicitFunction(Scriptable scope, String name, Object javaObject, boolean isStatic) {
/* 263 */     Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/* 264 */     Object member = null;
/* 265 */     MemberBox methodOrCtor = findExplicitFunction(name, isStatic);
/*     */     
/* 267 */     if (methodOrCtor != null) {
/* 268 */       Scriptable prototype = ScriptableObject.getFunctionPrototype(scope);
/*     */       
/* 270 */       if (methodOrCtor.isCtor()) {
/* 271 */         NativeJavaConstructor fun = new NativeJavaConstructor(methodOrCtor);
/* 272 */         fun.setPrototype(prototype);
/* 273 */         member = fun;
/* 274 */         ht.put(name, fun);
/*     */       } else {
/* 276 */         String trueName = methodOrCtor.getName();
/* 277 */         member = ht.get(trueName);
/*     */         
/* 279 */         if (member instanceof NativeJavaMethod && ((NativeJavaMethod)member).methods.length > 1) {
/*     */           
/* 281 */           NativeJavaMethod fun = new NativeJavaMethod(methodOrCtor, name);
/* 282 */           fun.setPrototype(prototype);
/* 283 */           ht.put(name, fun);
/* 284 */           member = fun;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 289 */     return member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method[] discoverAccessibleMethods(Class<?> clazz, boolean includeProtected, boolean includePrivate) {
/* 300 */     Map<MethodSignature, Method> map = new HashMap<>();
/* 301 */     discoverAccessibleMethods(clazz, map, includeProtected, includePrivate);
/* 302 */     return (Method[])map.values().toArray((Object[])new Method[map.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void discoverAccessibleMethods(Class<?> clazz, Map<MethodSignature, Method> map, boolean includeProtected, boolean includePrivate) {
/* 310 */     if (Modifier.isPublic(clazz.getModifiers()) || includePrivate) {
/*     */       try {
/* 312 */         if (includeProtected || includePrivate) {
/* 313 */           while (clazz != null) {
/*     */             try {
/* 315 */               Method[] methods = clazz.getDeclaredMethods();
/* 316 */               for (Method method : methods) {
/* 317 */                 int mods = method.getModifiers();
/*     */                 
/* 319 */                 if (Modifier.isPublic(mods) || Modifier.isProtected(mods) || includePrivate) {
/* 320 */                   MethodSignature sig = new MethodSignature(method);
/* 321 */                   if (!map.containsKey(sig)) {
/* 322 */                     if (includePrivate && !method.isAccessible())
/* 323 */                       method.setAccessible(true); 
/* 324 */                     map.put(sig, method);
/*     */                   } 
/*     */                 } 
/*     */               } 
/* 328 */               Class<?>[] arrayOfClass = clazz.getInterfaces();
/* 329 */               for (Class<?> intface : arrayOfClass) {
/* 330 */                 discoverAccessibleMethods(intface, map, includeProtected, includePrivate);
/*     */               }
/*     */               
/* 333 */               clazz = clazz.getSuperclass(); continue;
/* 334 */             } catch (SecurityException e) {
/*     */ 
/*     */ 
/*     */               
/* 338 */               Method[] methods = clazz.getMethods();
/* 339 */               for (Method method : methods) {
/* 340 */                 MethodSignature sig = new MethodSignature(method);
/* 341 */                 if (!map.containsKey(sig)) map.put(sig, method);
/*     */               
/*     */               } 
/*     */             } 
/*     */             return;
/*     */           } 
/*     */         } else {
/* 348 */           discoverPublicMethods(clazz, map);
/*     */         } 
/*     */         return;
/* 351 */       } catch (SecurityException e) {
/* 352 */         Context.reportWarning("Could not discover accessible methods of class " + clazz
/*     */             
/* 354 */             .getName() + " due to lack of privileges, attemping superclasses/interfaces.");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     Class<?>[] interfaces = clazz.getInterfaces();
/* 363 */     for (Class<?> intface : interfaces) {
/* 364 */       discoverAccessibleMethods(intface, map, includeProtected, includePrivate);
/*     */     }
/* 366 */     Class<?> superclass = clazz.getSuperclass();
/* 367 */     if (superclass != null) {
/* 368 */       discoverAccessibleMethods(superclass, map, includeProtected, includePrivate);
/*     */     }
/*     */   }
/*     */   
/*     */   void discoverPublicMethods(Class<?> clazz, Map<MethodSignature, Method> map) {
/* 373 */     Method[] methods = clazz.getMethods();
/* 374 */     for (Method method : methods) {
/* 375 */       registerMethod(map, method);
/*     */     }
/*     */   }
/*     */   
/*     */   static void registerMethod(Map<MethodSignature, Method> map, Method method) {
/* 380 */     MethodSignature sig = new MethodSignature(method);
/*     */     
/* 382 */     map.putIfAbsent(sig, method);
/*     */   }
/*     */   
/*     */   static final class MethodSignature {
/*     */     private final String name;
/*     */     private final Class<?>[] args;
/*     */     
/*     */     private MethodSignature(String name, Class<?>[] args) {
/* 390 */       this.name = name;
/* 391 */       this.args = args;
/*     */     }
/*     */     
/*     */     MethodSignature(Method method) {
/* 395 */       this(method.getName(), method.getParameterTypes());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 400 */       if (o instanceof MethodSignature) {
/* 401 */         MethodSignature ms = (MethodSignature)o;
/* 402 */         return (ms.name.equals(this.name) && Arrays.equals((Object[])this.args, (Object[])ms.args));
/*     */       } 
/* 404 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 409 */       return this.name.hashCode() ^ this.args.length;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reflect(Scriptable scope, boolean includeProtected, boolean includePrivate) {
/* 418 */     Method[] methods = discoverAccessibleMethods(this.cl, includeProtected, includePrivate);
/* 419 */     for (Method method : methods) {
/* 420 */       int mods = method.getModifiers();
/* 421 */       boolean isStatic = Modifier.isStatic(mods);
/* 422 */       Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/* 423 */       String name = method.getName();
/* 424 */       Object value = ht.get(name);
/* 425 */       if (value == null) {
/* 426 */         ht.put(name, method);
/*     */       } else {
/*     */         ObjArray overloadedMethods;
/* 429 */         if (value instanceof ObjArray) {
/* 430 */           overloadedMethods = (ObjArray)value;
/*     */         } else {
/* 432 */           if (!(value instanceof Method)) Kit.codeBug();
/*     */ 
/*     */           
/* 435 */           overloadedMethods = new ObjArray();
/* 436 */           overloadedMethods.add(value);
/* 437 */           ht.put(name, overloadedMethods);
/*     */         } 
/* 439 */         overloadedMethods.add(method);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 445 */     for (int tableCursor = 0; tableCursor != 2; tableCursor++) {
/* 446 */       boolean isStatic = (tableCursor == 0);
/* 447 */       Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/* 448 */       for (Map.Entry<String, Object> entry : ht.entrySet()) {
/*     */         MemberBox[] methodBoxes;
/* 450 */         Object value = entry.getValue();
/* 451 */         if (value instanceof Method) {
/* 452 */           methodBoxes = new MemberBox[1];
/* 453 */           methodBoxes[0] = new MemberBox((Method)value);
/*     */         } else {
/* 455 */           ObjArray overloadedMethods = (ObjArray)value;
/* 456 */           int N = overloadedMethods.size();
/* 457 */           if (N < 2) Kit.codeBug(); 
/* 458 */           methodBoxes = new MemberBox[N];
/* 459 */           for (int k = 0; k != N; k++) {
/* 460 */             Method method = (Method)overloadedMethods.get(k);
/* 461 */             methodBoxes[k] = new MemberBox(method);
/*     */           } 
/*     */         } 
/* 464 */         NativeJavaMethod fun = new NativeJavaMethod(methodBoxes);
/* 465 */         if (scope != null) {
/* 466 */           ScriptRuntime.setFunctionProtoAndParent(fun, scope);
/*     */         }
/* 468 */         ht.put(entry.getKey(), fun);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 473 */     Field[] fields = getAccessibleFields(includeProtected, includePrivate);
/* 474 */     for (Field field : fields) {
/* 475 */       String name = field.getName();
/* 476 */       int mods = field.getModifiers();
/*     */       try {
/* 478 */         boolean isStatic = Modifier.isStatic(mods);
/* 479 */         Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/* 480 */         Object member = ht.get(name);
/* 481 */         if (member == null) {
/* 482 */           ht.put(name, field);
/* 483 */         } else if (member instanceof NativeJavaMethod) {
/* 484 */           NativeJavaMethod method = (NativeJavaMethod)member;
/* 485 */           FieldAndMethods fam = new FieldAndMethods(scope, method.methods, field);
/* 486 */           Map<String, FieldAndMethods> fmht = isStatic ? this.staticFieldAndMethods : this.fieldAndMethods;
/*     */           
/* 488 */           if (fmht == null) {
/* 489 */             fmht = new HashMap<>();
/* 490 */             if (isStatic) {
/* 491 */               this.staticFieldAndMethods = fmht;
/*     */             } else {
/* 493 */               this.fieldAndMethods = fmht;
/*     */             } 
/*     */           } 
/* 496 */           fmht.put(name, fam);
/* 497 */           ht.put(name, fam);
/* 498 */         } else if (member instanceof Field) {
/* 499 */           Field oldField = (Field)member;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 506 */           if (oldField.getDeclaringClass().isAssignableFrom(field.getDeclaringClass())) {
/* 507 */             ht.put(name, field);
/*     */           }
/*     */         } else {
/*     */           
/* 511 */           Kit.codeBug();
/*     */         } 
/* 513 */       } catch (SecurityException e) {
/*     */         
/* 515 */         Context.reportWarning("Could not access field " + name + " of class " + this.cl
/*     */ 
/*     */ 
/*     */             
/* 519 */             .getName() + " due to lack of privileges.");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 526 */     for (int j = 0; j != 2; j++) {
/* 527 */       boolean isStatic = (j == 0);
/* 528 */       Map<String, Object> ht = isStatic ? this.staticMembers : this.members;
/*     */       
/* 530 */       Map<String, BeanProperty> toAdd = new HashMap<>();
/*     */ 
/*     */       
/* 533 */       for (String name : ht.keySet()) {
/*     */         
/* 535 */         boolean memberIsGetMethod = name.startsWith("get");
/* 536 */         boolean memberIsSetMethod = name.startsWith("set");
/* 537 */         boolean memberIsIsMethod = name.startsWith("is");
/* 538 */         if (memberIsGetMethod || memberIsIsMethod || memberIsSetMethod) {
/*     */           
/* 540 */           String nameComponent = name.substring(memberIsIsMethod ? 2 : 3);
/* 541 */           if (nameComponent.length() == 0) {
/*     */             continue;
/*     */           }
/* 544 */           String beanPropertyName = nameComponent;
/* 545 */           char ch0 = nameComponent.charAt(0);
/* 546 */           if (Character.isUpperCase(ch0)) {
/* 547 */             if (nameComponent.length() == 1) {
/* 548 */               beanPropertyName = nameComponent.toLowerCase();
/*     */             } else {
/* 550 */               char ch1 = nameComponent.charAt(1);
/* 551 */               if (!Character.isUpperCase(ch1))
/*     */               {
/* 553 */                 beanPropertyName = Character.toLowerCase(ch0) + nameComponent.substring(1);
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 560 */           if (toAdd.containsKey(beanPropertyName))
/* 561 */             continue;  Object v = ht.get(beanPropertyName);
/* 562 */           if (v != null)
/*     */           {
/* 564 */             if (!includePrivate || !(v instanceof Member) || 
/*     */               
/* 566 */               !Modifier.isPrivate(((Member)v).getModifiers())) {
/*     */               continue;
/*     */             }
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 574 */           MemberBox getter = null;
/* 575 */           getter = findGetter(isStatic, ht, "get", nameComponent);
/*     */           
/* 577 */           if (getter == null) {
/* 578 */             getter = findGetter(isStatic, ht, "is", nameComponent);
/*     */           }
/*     */ 
/*     */           
/* 582 */           MemberBox setter = null;
/* 583 */           NativeJavaMethod setters = null;
/* 584 */           String setterName = "set".concat(nameComponent);
/*     */           
/* 586 */           if (ht.containsKey(setterName)) {
/*     */             
/* 588 */             Object member = ht.get(setterName);
/* 589 */             if (member instanceof NativeJavaMethod) {
/* 590 */               NativeJavaMethod njmSet = (NativeJavaMethod)member;
/* 591 */               if (getter != null) {
/*     */ 
/*     */                 
/* 594 */                 Class<?> type = getter.method().getReturnType();
/* 595 */                 setter = extractSetMethod(type, njmSet.methods, isStatic);
/*     */               } else {
/*     */                 
/* 598 */                 setter = extractSetMethod(njmSet.methods, isStatic);
/*     */               } 
/* 600 */               if (njmSet.methods.length > 1) {
/* 601 */                 setters = njmSet;
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/* 606 */           BeanProperty bp = new BeanProperty(getter, setter, setters);
/* 607 */           toAdd.put(beanPropertyName, bp);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 612 */       ht.putAll(toAdd);
/*     */     } 
/*     */ 
/*     */     
/* 616 */     Constructor[] arrayOfConstructor = (Constructor[])getAccessibleConstructors(includePrivate);
/* 617 */     MemberBox[] ctorMembers = new MemberBox[arrayOfConstructor.length];
/* 618 */     for (int i = 0; i != arrayOfConstructor.length; i++) {
/* 619 */       ctorMembers[i] = new MemberBox(arrayOfConstructor[i]);
/*     */     }
/* 621 */     this.ctors = new NativeJavaMethod(ctorMembers, this.cl.getSimpleName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Constructor<?>[] getAccessibleConstructors(boolean includePrivate) {
/* 627 */     if (includePrivate && this.cl != ScriptRuntime.ClassClass) {
/*     */       try {
/* 629 */         Constructor[] arrayOfConstructor = (Constructor[])this.cl.getDeclaredConstructors();
/* 630 */         AccessibleObject.setAccessible((AccessibleObject[])arrayOfConstructor, true);
/*     */         
/* 632 */         return (Constructor<?>[])arrayOfConstructor;
/* 633 */       } catch (SecurityException e) {
/*     */         
/* 635 */         Context.reportWarning("Could not access constructor  of class " + this.cl
/*     */ 
/*     */             
/* 638 */             .getName() + " due to lack of privileges.");
/*     */       } 
/*     */     }
/*     */     
/* 642 */     return this.cl.getConstructors();
/*     */   }
/*     */   
/*     */   private Field[] getAccessibleFields(boolean includeProtected, boolean includePrivate) {
/* 646 */     if (includePrivate || includeProtected) {
/*     */       try {
/* 648 */         List<Field> fieldsList = new ArrayList<>();
/* 649 */         Class<?> currentClass = this.cl;
/*     */         
/* 651 */         while (currentClass != null) {
/*     */ 
/*     */           
/* 654 */           Field[] declared = currentClass.getDeclaredFields();
/* 655 */           for (Field field : declared) {
/* 656 */             int mod = field.getModifiers();
/* 657 */             if (includePrivate || Modifier.isPublic(mod) || Modifier.isProtected(mod)) {
/* 658 */               if (!field.isAccessible()) field.setAccessible(true); 
/* 659 */               fieldsList.add(field);
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 664 */           currentClass = currentClass.getSuperclass();
/*     */         } 
/*     */         
/* 667 */         return fieldsList.<Field>toArray(new Field[fieldsList.size()]);
/* 668 */       } catch (SecurityException securityException) {}
/*     */     }
/*     */ 
/*     */     
/* 672 */     return this.cl.getFields();
/*     */   }
/*     */ 
/*     */   
/*     */   private static MemberBox findGetter(boolean isStatic, Map<String, Object> ht, String prefix, String propertyName) {
/* 677 */     String getterName = prefix.concat(propertyName);
/* 678 */     if (ht.containsKey(getterName)) {
/*     */       
/* 680 */       Object member = ht.get(getterName);
/* 681 */       if (member instanceof NativeJavaMethod) {
/* 682 */         NativeJavaMethod njmGet = (NativeJavaMethod)member;
/* 683 */         return extractGetMethod(njmGet.methods, isStatic);
/*     */       } 
/*     */     } 
/* 686 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static MemberBox extractGetMethod(MemberBox[] methods, boolean isStatic) {
/* 692 */     for (MemberBox method : methods) {
/*     */ 
/*     */       
/* 695 */       if (method.argTypes.length == 0 && (!isStatic || method.isStatic())) {
/* 696 */         Class<?> type = method.method().getReturnType();
/* 697 */         if (type != void.class) {
/* 698 */           return method;
/*     */         }
/*     */         break;
/*     */       } 
/*     */     } 
/* 703 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MemberBox extractSetMethod(Class<?> type, MemberBox[] methods, boolean isStatic) {
/* 716 */     for (int pass = 1; pass <= 2; pass++) {
/* 717 */       for (MemberBox method : methods) {
/* 718 */         if (!isStatic || method.isStatic()) {
/* 719 */           Class<?>[] params = method.argTypes;
/* 720 */           if (params.length == 1) {
/* 721 */             if (pass == 1) {
/* 722 */               if (params[0] == type) {
/* 723 */                 return method;
/*     */               }
/*     */             } else {
/* 726 */               if (pass != 2) Kit.codeBug(); 
/* 727 */               if (params[0].isAssignableFrom(type)) {
/* 728 */                 return method;
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 735 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static MemberBox extractSetMethod(MemberBox[] methods, boolean isStatic) {
/* 740 */     for (MemberBox method : methods) {
/* 741 */       if ((!isStatic || method.isStatic()) && 
/* 742 */         method.method().getReturnType() == void.class && 
/* 743 */         method.argTypes.length == 1) {
/* 744 */         return method;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 749 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   Map<String, FieldAndMethods> getFieldAndMethodsObjects(Scriptable scope, Object javaObject, boolean isStatic) {
/* 754 */     Map<String, FieldAndMethods> ht = isStatic ? this.staticFieldAndMethods : this.fieldAndMethods;
/* 755 */     if (ht == null) return null; 
/* 756 */     int len = ht.size();
/* 757 */     Map<String, FieldAndMethods> result = new HashMap<>(len);
/* 758 */     for (FieldAndMethods fam : ht.values()) {
/* 759 */       FieldAndMethods famNew = new FieldAndMethods(scope, fam.methods, fam.field);
/* 760 */       famNew.javaObject = javaObject;
/* 761 */       result.put(fam.field.getName(), famNew);
/*     */     } 
/* 763 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   static JavaMembers lookupClass(Scriptable scope, Class<?> dynamicType, Class<?> staticType, boolean includeProtected) {
/*     */     JavaMembers members;
/* 769 */     ClassCache cache = ClassCache.get(scope);
/* 770 */     Map<ClassCache.CacheKey, JavaMembers> ct = cache.getClassCacheMap();
/*     */     
/* 772 */     Class<?> cl = dynamicType;
/* 773 */     Object secCtx = getSecurityContext();
/*     */     while (true) {
/* 775 */       members = ct.get(new ClassCache.CacheKey(cl, secCtx));
/* 776 */       if (members != null) {
/* 777 */         if (cl != dynamicType)
/*     */         {
/*     */           
/* 780 */           ct.put(new ClassCache.CacheKey(dynamicType, secCtx), members);
/*     */         }
/* 782 */         return members;
/*     */       } 
/*     */       try {
/* 785 */         members = createJavaMembers(cache.getAssociatedScope(), cl, includeProtected);
/*     */         break;
/* 787 */       } catch (SecurityException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 792 */         if (staticType != null && staticType.isInterface()) {
/* 793 */           cl = staticType;
/* 794 */           staticType = null; continue;
/*     */         } 
/* 796 */         Class<?> parent = cl.getSuperclass();
/* 797 */         if (parent == null) {
/* 798 */           if (cl.isInterface()) {
/*     */             
/* 800 */             parent = ScriptRuntime.ObjectClass;
/*     */           } else {
/* 802 */             throw e;
/*     */           } 
/*     */         }
/* 805 */         cl = parent;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 810 */     if (cache.isCachingEnabled()) {
/* 811 */       ct.put(new ClassCache.CacheKey(cl, secCtx), members);
/* 812 */       if (cl != dynamicType)
/*     */       {
/*     */         
/* 815 */         ct.put(new ClassCache.CacheKey(dynamicType, secCtx), members);
/*     */       }
/*     */     } 
/* 818 */     return members;
/*     */   }
/*     */ 
/*     */   
/*     */   private static JavaMembers createJavaMembers(Scriptable associatedScope, Class<?> cl, boolean includeProtected) {
/* 823 */     if (STRICT_REFLECTIVE_ACCESS) {
/* 824 */       return new JavaMembers_jdk11(associatedScope, cl, includeProtected);
/*     */     }
/* 826 */     return new JavaMembers(associatedScope, cl, includeProtected);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object getSecurityContext() {
/* 831 */     Object sec = null;
/* 832 */     SecurityManager sm = System.getSecurityManager();
/* 833 */     if (sm != null) {
/* 834 */       sec = sm.getSecurityContext();
/* 835 */       if (sec instanceof AccessControlContext) {
/*     */         try {
/* 837 */           ((AccessControlContext)sec).checkPermission(allPermission);
/*     */ 
/*     */           
/* 840 */           return null;
/* 841 */         } catch (SecurityException securityException) {}
/*     */       }
/*     */     } 
/*     */     
/* 845 */     return sec;
/*     */   }
/*     */   
/*     */   RuntimeException reportMemberNotFound(String memberName) {
/* 849 */     return Context.reportRuntimeErrorById("msg.java.member.not.found", new Object[] { this.cl
/* 850 */           .getName(), memberName });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\JavaMembers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */