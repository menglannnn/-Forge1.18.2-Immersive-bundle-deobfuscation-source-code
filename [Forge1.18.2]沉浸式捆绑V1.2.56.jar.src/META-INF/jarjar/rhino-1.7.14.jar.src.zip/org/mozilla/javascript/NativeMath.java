/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeMath
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = -8838847185801131569L;
/*  17 */   private static final Object MATH_TAG = "Math"; private static final double LOG2E = 1.4426950408889634D; private static final int Id_toSource = 1; private static final int Id_abs = 2; private static final int Id_acos = 3; private static final int Id_asin = 4; private static final int Id_atan = 5; private static final int Id_atan2 = 6; private static final int Id_ceil = 7; private static final int Id_cos = 8; private static final int Id_exp = 9; private static final int Id_floor = 10; private static final int Id_log = 11;
/*     */   private static final int Id_max = 12;
/*  19 */   private static final Double Double32 = Double.valueOf(32.0D); private static final int Id_min = 13; private static final int Id_pow = 14; private static final int Id_random = 15; private static final int Id_round = 16; private static final int Id_sin = 17; private static final int Id_sqrt = 18; private static final int Id_tan = 19; private static final int Id_cbrt = 20; private static final int Id_cosh = 21; private static final int Id_expm1 = 22; private static final int Id_hypot = 23;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  22 */     NativeMath obj = new NativeMath();
/*  23 */     obj.activatePrototypeMap(44);
/*  24 */     obj.setPrototype(getObjectPrototype(scope));
/*  25 */     obj.setParentScope(scope);
/*  26 */     if (sealed) {
/*  27 */       obj.sealObject();
/*     */     }
/*  29 */     ScriptableObject.defineProperty(scope, "Math", obj, 2);
/*     */   }
/*     */   private static final int Id_log1p = 24; private static final int Id_log10 = 25; private static final int Id_sinh = 26; private static final int Id_tanh = 27; private static final int Id_imul = 28; private static final int Id_trunc = 29; private static final int Id_acosh = 30; private static final int Id_asinh = 31; private static final int Id_atanh = 32; private static final int Id_sign = 33; private static final int Id_log2 = 34; private static final int Id_fround = 35; private static final int Id_clz32 = 36; private static final int LAST_METHOD_ID = 36; private static final int Id_E = 37; private static final int Id_PI = 38; private static final int Id_LN10 = 39; private static final int Id_LN2 = 40; private static final int Id_LOG2E = 41; private static final int Id_LOG10E = 42; private static final int Id_SQRT1_2 = 43;
/*     */   private static final int Id_SQRT2 = 44;
/*     */   private static final int MAX_ID = 44;
/*     */   
/*     */   public String getClassName() {
/*  36 */     return "Math";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*  41 */     if (id <= 36) {
/*     */       String name;
/*     */       int arity;
/*  44 */       switch (id) {
/*     */         case 1:
/*  46 */           arity = 0;
/*  47 */           name = "toSource";
/*     */           break;
/*     */         case 2:
/*  50 */           arity = 1;
/*  51 */           name = "abs";
/*     */           break;
/*     */         case 3:
/*  54 */           arity = 1;
/*  55 */           name = "acos";
/*     */           break;
/*     */         case 30:
/*  58 */           arity = 1;
/*  59 */           name = "acosh";
/*     */           break;
/*     */         case 4:
/*  62 */           arity = 1;
/*  63 */           name = "asin";
/*     */           break;
/*     */         case 31:
/*  66 */           arity = 1;
/*  67 */           name = "asinh";
/*     */           break;
/*     */         case 5:
/*  70 */           arity = 1;
/*  71 */           name = "atan";
/*     */           break;
/*     */         case 32:
/*  74 */           arity = 1;
/*  75 */           name = "atanh";
/*     */           break;
/*     */         case 6:
/*  78 */           arity = 2;
/*  79 */           name = "atan2";
/*     */           break;
/*     */         case 20:
/*  82 */           arity = 1;
/*  83 */           name = "cbrt";
/*     */           break;
/*     */         case 7:
/*  86 */           arity = 1;
/*  87 */           name = "ceil";
/*     */           break;
/*     */         case 36:
/*  90 */           arity = 1;
/*  91 */           name = "clz32";
/*     */           break;
/*     */         case 8:
/*  94 */           arity = 1;
/*  95 */           name = "cos";
/*     */           break;
/*     */         case 21:
/*  98 */           arity = 1;
/*  99 */           name = "cosh";
/*     */           break;
/*     */         case 9:
/* 102 */           arity = 1;
/* 103 */           name = "exp";
/*     */           break;
/*     */         case 22:
/* 106 */           arity = 1;
/* 107 */           name = "expm1";
/*     */           break;
/*     */         case 10:
/* 110 */           arity = 1;
/* 111 */           name = "floor";
/*     */           break;
/*     */         case 35:
/* 114 */           arity = 1;
/* 115 */           name = "fround";
/*     */           break;
/*     */         case 23:
/* 118 */           arity = 2;
/* 119 */           name = "hypot";
/*     */           break;
/*     */         case 28:
/* 122 */           arity = 2;
/* 123 */           name = "imul";
/*     */           break;
/*     */         case 11:
/* 126 */           arity = 1;
/* 127 */           name = "log";
/*     */           break;
/*     */         case 24:
/* 130 */           arity = 1;
/* 131 */           name = "log1p";
/*     */           break;
/*     */         case 25:
/* 134 */           arity = 1;
/* 135 */           name = "log10";
/*     */           break;
/*     */         case 34:
/* 138 */           arity = 1;
/* 139 */           name = "log2";
/*     */           break;
/*     */         case 12:
/* 142 */           arity = 2;
/* 143 */           name = "max";
/*     */           break;
/*     */         case 13:
/* 146 */           arity = 2;
/* 147 */           name = "min";
/*     */           break;
/*     */         case 14:
/* 150 */           arity = 2;
/* 151 */           name = "pow";
/*     */           break;
/*     */         case 15:
/* 154 */           arity = 0;
/* 155 */           name = "random";
/*     */           break;
/*     */         case 16:
/* 158 */           arity = 1;
/* 159 */           name = "round";
/*     */           break;
/*     */         case 33:
/* 162 */           arity = 1;
/* 163 */           name = "sign";
/*     */           break;
/*     */         case 17:
/* 166 */           arity = 1;
/* 167 */           name = "sin";
/*     */           break;
/*     */         case 26:
/* 170 */           arity = 1;
/* 171 */           name = "sinh";
/*     */           break;
/*     */         case 18:
/* 174 */           arity = 1;
/* 175 */           name = "sqrt";
/*     */           break;
/*     */         case 19:
/* 178 */           arity = 1;
/* 179 */           name = "tan";
/*     */           break;
/*     */         case 27:
/* 182 */           arity = 1;
/* 183 */           name = "tanh";
/*     */           break;
/*     */         case 29:
/* 186 */           arity = 1;
/* 187 */           name = "trunc";
/*     */           break;
/*     */         default:
/* 190 */           throw new IllegalStateException(String.valueOf(id));
/*     */       } 
/* 192 */       initPrototypeMethod(MATH_TAG, id, name, arity);
/*     */     } else {
/*     */       String name;
/*     */       double x;
/* 196 */       switch (id) {
/*     */         case 37:
/* 198 */           x = Math.E;
/* 199 */           name = "E";
/*     */           break;
/*     */         case 38:
/* 202 */           x = Math.PI;
/* 203 */           name = "PI";
/*     */           break;
/*     */         case 39:
/* 206 */           x = 2.302585092994046D;
/* 207 */           name = "LN10";
/*     */           break;
/*     */         case 40:
/* 210 */           x = 0.6931471805599453D;
/* 211 */           name = "LN2";
/*     */           break;
/*     */         case 41:
/* 214 */           x = 1.4426950408889634D;
/* 215 */           name = "LOG2E";
/*     */           break;
/*     */         case 42:
/* 218 */           x = 0.4342944819032518D;
/* 219 */           name = "LOG10E";
/*     */           break;
/*     */         case 43:
/* 222 */           x = 0.7071067811865476D;
/* 223 */           name = "SQRT1_2";
/*     */           break;
/*     */         case 44:
/* 226 */           x = 1.4142135623730951D;
/* 227 */           name = "SQRT2";
/*     */           break;
/*     */         default:
/* 230 */           throw new IllegalStateException(String.valueOf(id));
/*     */       } 
/* 232 */       initPrototypeValue(id, name, 
/* 233 */           ScriptRuntime.wrapNumber(x), 7);
/*     */     } 
/*     */   }
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     double x;
/*     */     long n;
/*     */     int i;
/* 240 */     if (!f.hasTag(MATH_TAG)) {
/* 241 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*     */     
/* 244 */     int methodId = f.methodId();
/* 245 */     switch (methodId) {
/*     */       case 1:
/* 247 */         return "Math";
/*     */       
/*     */       case 2:
/* 250 */         x = ScriptRuntime.toNumber(args, 0);
/*     */         
/* 252 */         x = (x == 0.0D) ? 0.0D : ((x < 0.0D) ? -x : x);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 483 */         return ScriptRuntime.wrapNumber(x);case 3: case 4: x = ScriptRuntime.toNumber(args, 0); if (!Double.isNaN(x) && -1.0D <= x && x <= 1.0D) { x = (methodId == 3) ? Math.acos(x) : Math.asin(x); } else { x = Double.NaN; }  return ScriptRuntime.wrapNumber(x);case 30: x = ScriptRuntime.toNumber(args, 0); if (!Double.isNaN(x)) return Double.valueOf(Math.log(x + Math.sqrt(x * x - 1.0D)));  return ScriptRuntime.NaNobj;case 31: x = ScriptRuntime.toNumber(args, 0); if (Double.isInfinite(x)) return Double.valueOf(x);  if (!Double.isNaN(x)) { if (x == 0.0D) { if (1.0D / x > 0.0D) return ScriptRuntime.zeroObj;  return ScriptRuntime.negativeZeroObj; }  return Double.valueOf(Math.log(x + Math.sqrt(x * x + 1.0D))); }  return ScriptRuntime.NaNobj;case 5: x = ScriptRuntime.toNumber(args, 0); x = Math.atan(x); return ScriptRuntime.wrapNumber(x);case 32: x = ScriptRuntime.toNumber(args, 0); if (!Double.isNaN(x) && -1.0D <= x && x <= 1.0D) { if (x == 0.0D) { if (1.0D / x > 0.0D) return ScriptRuntime.zeroObj;  return ScriptRuntime.negativeZeroObj; }  return Double.valueOf(0.5D * Math.log((x + 1.0D) / (x - 1.0D))); }  return ScriptRuntime.NaNobj;case 6: x = ScriptRuntime.toNumber(args, 0); x = Math.atan2(x, ScriptRuntime.toNumber(args, 1)); return ScriptRuntime.wrapNumber(x);case 20: x = ScriptRuntime.toNumber(args, 0); x = Math.cbrt(x); return ScriptRuntime.wrapNumber(x);case 7: x = ScriptRuntime.toNumber(args, 0); x = Math.ceil(x); return ScriptRuntime.wrapNumber(x);case 36: x = ScriptRuntime.toNumber(args, 0); if (x == 0.0D || Double.isNaN(x) || Double.isInfinite(x)) return Double32;  n = ScriptRuntime.toUint32(x); if (n == 0L) return Double32;  return Double.valueOf(31.0D - Math.floor(Math.log((n >>> 0L)) * 1.4426950408889634D));case 8: x = ScriptRuntime.toNumber(args, 0); x = Double.isInfinite(x) ? Double.NaN : Math.cos(x); return ScriptRuntime.wrapNumber(x);case 21: x = ScriptRuntime.toNumber(args, 0); x = Math.cosh(x); return ScriptRuntime.wrapNumber(x);case 23: x = js_hypot(args); return ScriptRuntime.wrapNumber(x);case 9: x = ScriptRuntime.toNumber(args, 0); x = (x == Double.POSITIVE_INFINITY) ? x : ((x == Double.NEGATIVE_INFINITY) ? 0.0D : Math.exp(x)); return ScriptRuntime.wrapNumber(x);case 22: x = ScriptRuntime.toNumber(args, 0); x = Math.expm1(x); return ScriptRuntime.wrapNumber(x);case 10: x = ScriptRuntime.toNumber(args, 0); x = Math.floor(x); return ScriptRuntime.wrapNumber(x);case 35: x = ScriptRuntime.toNumber(args, 0); x = (float)x; return ScriptRuntime.wrapNumber(x);case 28: x = js_imul(args); return ScriptRuntime.wrapNumber(x);case 11: x = ScriptRuntime.toNumber(args, 0); x = (x < 0.0D) ? Double.NaN : Math.log(x); return ScriptRuntime.wrapNumber(x);case 24: x = ScriptRuntime.toNumber(args, 0); x = Math.log1p(x); return ScriptRuntime.wrapNumber(x);case 25: x = ScriptRuntime.toNumber(args, 0); x = Math.log10(x); return ScriptRuntime.wrapNumber(x);case 34: x = ScriptRuntime.toNumber(args, 0); x = (x < 0.0D) ? Double.NaN : (Math.log(x) * 1.4426950408889634D); return ScriptRuntime.wrapNumber(x);case 12: case 13: x = (methodId == 12) ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY; for (i = 0; i != args.length; i++) { double d = ScriptRuntime.toNumber(args[i]); if (methodId == 12) { x = Math.max(x, d); } else { x = Math.min(x, d); }  }  return ScriptRuntime.wrapNumber(x);case 14: x = ScriptRuntime.toNumber(args, 0); x = js_pow(x, ScriptRuntime.toNumber(args, 1)); return ScriptRuntime.wrapNumber(x);case 15: x = Math.random(); return ScriptRuntime.wrapNumber(x);case 16: x = ScriptRuntime.toNumber(args, 0); if (!Double.isNaN(x) && !Double.isInfinite(x)) { long l = Math.round(x); if (l != 0L) { x = l; } else if (x < 0.0D) { x = ScriptRuntime.negativeZero; } else if (x != 0.0D) { x = 0.0D; }  }  return ScriptRuntime.wrapNumber(x);case 33: x = ScriptRuntime.toNumber(args, 0); if (!Double.isNaN(x)) { if (x == 0.0D) { if (1.0D / x > 0.0D) return ScriptRuntime.zeroObj;  return ScriptRuntime.negativeZeroObj; }  return Double.valueOf(Math.signum(x)); }  return ScriptRuntime.NaNobj;case 17: x = ScriptRuntime.toNumber(args, 0); x = Double.isInfinite(x) ? Double.NaN : Math.sin(x); return ScriptRuntime.wrapNumber(x);case 26: x = ScriptRuntime.toNumber(args, 0); x = Math.sinh(x); return ScriptRuntime.wrapNumber(x);case 18: x = ScriptRuntime.toNumber(args, 0); x = Math.sqrt(x); return ScriptRuntime.wrapNumber(x);case 19: x = ScriptRuntime.toNumber(args, 0); x = Math.tan(x); return ScriptRuntime.wrapNumber(x);case 27: x = ScriptRuntime.toNumber(args, 0); x = Math.tanh(x); return ScriptRuntime.wrapNumber(x);case 29: x = ScriptRuntime.toNumber(args, 0); x = js_trunc(x); return ScriptRuntime.wrapNumber(x);
/*     */     } 
/*     */     throw new IllegalStateException(String.valueOf(methodId));
/*     */   }
/*     */   private static double js_pow(double x, double y) {
/*     */     double result;
/* 489 */     if (Double.isNaN(y)) {
/*     */       
/* 491 */       result = y;
/* 492 */     } else if (y == 0.0D) {
/*     */       
/* 494 */       result = 1.0D;
/* 495 */     } else if (x == 0.0D) {
/*     */       
/* 497 */       if (1.0D / x > 0.0D) {
/* 498 */         result = (y > 0.0D) ? 0.0D : Double.POSITIVE_INFINITY;
/*     */       } else {
/*     */         
/* 501 */         long y_long = (long)y;
/* 502 */         if (y_long == y && (y_long & 0x1L) != 0L) {
/* 503 */           result = (y > 0.0D) ? -0.0D : Double.NEGATIVE_INFINITY;
/*     */         } else {
/* 505 */           result = (y > 0.0D) ? 0.0D : Double.POSITIVE_INFINITY;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 509 */       result = Math.pow(x, y);
/* 510 */       if (Double.isNaN(result))
/*     */       {
/*     */         
/* 513 */         if (y == Double.POSITIVE_INFINITY) {
/* 514 */           if (x < -1.0D || 1.0D < x) {
/* 515 */             result = Double.POSITIVE_INFINITY;
/* 516 */           } else if (-1.0D < x && x < 1.0D) {
/* 517 */             result = 0.0D;
/*     */           } 
/* 519 */         } else if (y == Double.NEGATIVE_INFINITY) {
/* 520 */           if (x < -1.0D || 1.0D < x) {
/* 521 */             result = 0.0D;
/* 522 */           } else if (-1.0D < x && x < 1.0D) {
/* 523 */             result = Double.POSITIVE_INFINITY;
/*     */           } 
/* 525 */         } else if (x == Double.POSITIVE_INFINITY) {
/* 526 */           result = (y > 0.0D) ? Double.POSITIVE_INFINITY : 0.0D;
/* 527 */         } else if (x == Double.NEGATIVE_INFINITY) {
/* 528 */           long y_long = (long)y;
/* 529 */           if (y_long == y && (y_long & 0x1L) != 0L) {
/*     */             
/* 531 */             result = (y > 0.0D) ? Double.NEGATIVE_INFINITY : -0.0D;
/*     */           } else {
/* 533 */             result = (y > 0.0D) ? Double.POSITIVE_INFINITY : 0.0D;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 538 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static double js_hypot(Object[] args) {
/* 544 */     if (args == null) {
/* 545 */       return 0.0D;
/*     */     }
/* 547 */     double y = 0.0D;
/*     */ 
/*     */     
/* 550 */     boolean hasNaN = false;
/* 551 */     boolean hasInfinity = false;
/*     */     
/* 553 */     for (Object o : args) {
/* 554 */       double d = ScriptRuntime.toNumber(o);
/* 555 */       if (Double.isNaN(d)) {
/* 556 */         hasNaN = true;
/* 557 */       } else if (Double.isInfinite(d)) {
/* 558 */         hasInfinity = true;
/*     */       } else {
/* 560 */         y += d * d;
/*     */       } 
/*     */     } 
/*     */     
/* 564 */     if (hasInfinity) {
/* 565 */       return Double.POSITIVE_INFINITY;
/*     */     }
/* 567 */     if (hasNaN) {
/* 568 */       return Double.NaN;
/*     */     }
/* 570 */     return Math.sqrt(y);
/*     */   }
/*     */   
/*     */   private static double js_trunc(double d) {
/* 574 */     return (d < 0.0D) ? Math.ceil(d) : Math.floor(d);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int js_imul(Object[] args) {
/* 579 */     if (args == null) {
/* 580 */       return 0;
/*     */     }
/*     */     
/* 583 */     int x = ScriptRuntime.toInt32(args, 0);
/* 584 */     int y = ScriptRuntime.toInt32(args, 1);
/* 585 */     return x * y;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 591 */     switch (s)
/*     */     { case "toSource":
/* 593 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 728 */         return id;case "abs": id = 2; return id;case "acos": id = 3; return id;case "asin": id = 4; return id;case "atan": id = 5; return id;case "atan2": id = 6; return id;case "ceil": id = 7; return id;case "cos": id = 8; return id;case "exp": id = 9; return id;case "floor": id = 10; return id;case "log": id = 11; return id;case "max": id = 12; return id;case "min": id = 13; return id;case "pow": id = 14; return id;case "random": id = 15; return id;case "round": id = 16; return id;case "sin": id = 17; return id;case "sqrt": id = 18; return id;case "tan": id = 19; return id;case "cbrt": id = 20; return id;case "cosh": id = 21; return id;case "expm1": id = 22; return id;case "hypot": id = 23; return id;case "log1p": id = 24; return id;case "log10": id = 25; return id;case "sinh": id = 26; return id;case "tanh": id = 27; return id;case "imul": id = 28; return id;case "trunc": id = 29; return id;case "acosh": id = 30; return id;case "asinh": id = 31; return id;case "atanh": id = 32; return id;case "sign": id = 33; return id;case "log2": id = 34; return id;case "fround": id = 35; return id;case "clz32": id = 36; return id;case "E": id = 37; return id;case "PI": id = 38; return id;case "LN10": id = 39; return id;case "LN2": id = 40; return id;case "LOG2E": id = 41; return id;case "LOG10E": id = 42; return id;case "SQRT1_2": id = 43; return id;case "SQRT2": id = 44; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeMath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */