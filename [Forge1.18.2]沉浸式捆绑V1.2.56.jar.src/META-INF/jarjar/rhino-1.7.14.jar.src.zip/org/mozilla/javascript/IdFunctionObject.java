/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdFunctionObject
/*     */   extends BaseFunction
/*     */ {
/*     */   private static final long serialVersionUID = -5332312783643935019L;
/*     */   private final IdFunctionCall idcall;
/*     */   private final Object tag;
/*     */   private final int methodId;
/*     */   private int arity;
/*     */   private boolean useCallAsConstructor;
/*     */   private String functionName;
/*     */   
/*     */   public IdFunctionObject(IdFunctionCall idcall, Object tag, int id, int arity) {
/*  18 */     if (arity < 0) {
/*  19 */       throw new IllegalArgumentException();
/*     */     }
/*  21 */     this.idcall = idcall;
/*  22 */     this.tag = tag;
/*  23 */     this.methodId = id;
/*  24 */     this.arity = arity;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IdFunctionObject(IdFunctionCall idcall, Object tag, int id, String name, int arity, Scriptable scope) {
/*  30 */     super(scope, (Scriptable)null);
/*     */     
/*  32 */     if (arity < 0)
/*  33 */       throw new IllegalArgumentException(); 
/*  34 */     if (name == null) {
/*  35 */       throw new IllegalArgumentException();
/*     */     }
/*  37 */     this.idcall = idcall;
/*  38 */     this.tag = tag;
/*  39 */     this.methodId = id;
/*  40 */     this.arity = arity;
/*  41 */     this.functionName = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initFunction(String name, Scriptable scope) {
/*  46 */     if (name == null) throw new IllegalArgumentException(); 
/*  47 */     if (scope == null) throw new IllegalArgumentException(); 
/*  48 */     this.functionName = name;
/*  49 */     setParentScope(scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasTag(Object tag) {
/*  54 */     return (tag == null) ? ((this.tag == null)) : tag.equals(this.tag);
/*     */   }
/*     */   
/*     */   public Object getTag() {
/*  58 */     return this.tag;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int methodId() {
/*  63 */     return this.methodId;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void markAsConstructor(Scriptable prototypeProperty) {
/*  68 */     this.useCallAsConstructor = true;
/*  69 */     setImmunePrototypeProperty(prototypeProperty);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void addAsProperty(Scriptable target) {
/*  74 */     ScriptableObject.defineProperty(target, this.functionName, this, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void exportAsScopeProperty() {
/*  80 */     addAsProperty(getParentScope());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getPrototype() {
/*  88 */     Scriptable proto = super.getPrototype();
/*  89 */     if (proto == null) {
/*  90 */       proto = getFunctionPrototype(getParentScope());
/*  91 */       setPrototype(proto);
/*     */     } 
/*  93 */     return proto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 100 */     return this.idcall.execIdCall(this, cx, scope, thisObj, args);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable createObject(Context cx, Scriptable scope) {
/* 106 */     if (this.useCallAsConstructor) {
/* 107 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     throw ScriptRuntime.typeErrorById("msg.not.ctor", new Object[] { this.functionName });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String decompile(int indent, int flags) {
/* 119 */     StringBuilder sb = new StringBuilder();
/* 120 */     boolean justbody = (0 != (flags & 0x1));
/* 121 */     if (!justbody) {
/* 122 */       sb.append("function ");
/* 123 */       sb.append(getFunctionName());
/* 124 */       sb.append("() { ");
/*     */     } 
/* 126 */     sb.append("[native code for ");
/* 127 */     if (this.idcall instanceof Scriptable) {
/* 128 */       Scriptable sobj = (Scriptable)this.idcall;
/* 129 */       sb.append(sobj.getClassName());
/* 130 */       sb.append('.');
/*     */     } 
/* 132 */     sb.append(getFunctionName());
/* 133 */     sb.append(", arity=");
/* 134 */     sb.append(getArity());
/* 135 */     sb.append(justbody ? "]\n" : "] }\n");
/* 136 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getArity() {
/* 142 */     return this.arity;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 146 */     return getArity();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFunctionName() {
/* 151 */     return (this.functionName == null) ? "" : this.functionName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final RuntimeException unknown() {
/* 157 */     return new IllegalArgumentException("BAD FUNCTION ID=" + this.methodId + " MASTER=" + this.idcall);
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean equalObjectGraphs(IdFunctionObject f1, IdFunctionObject f2, EqualObjectGraphs eq) {
/* 162 */     return (f1.methodId == f2.methodId && f1.hasTag(f2.tag) && eq.equalGraphs(f1.idcall, f2.idcall));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\IdFunctionObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */