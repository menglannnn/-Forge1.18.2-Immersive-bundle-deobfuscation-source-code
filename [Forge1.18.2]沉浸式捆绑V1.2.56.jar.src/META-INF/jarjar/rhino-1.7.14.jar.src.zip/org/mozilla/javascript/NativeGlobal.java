/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.mozilla.javascript.xml.XMLLib;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeGlobal
/*     */   implements Serializable, IdFunctionCall
/*     */ {
/*     */   static final long serialVersionUID = 6080442165748707530L;
/*     */   private static final String URI_DECODE_RESERVED = ";/?:@&=+$,#";
/*     */   private static final int INVALID_UTF8 = 2147483647;
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  27 */     NativeGlobal obj = new NativeGlobal();
/*     */     
/*  29 */     for (int id = 1; id <= 13; id++) {
/*     */       String name;
/*  31 */       int arity = 1;
/*  32 */       switch (id) {
/*     */         case 1:
/*  34 */           name = "decodeURI";
/*     */           break;
/*     */         case 2:
/*  37 */           name = "decodeURIComponent";
/*     */           break;
/*     */         case 3:
/*  40 */           name = "encodeURI";
/*     */           break;
/*     */         case 4:
/*  43 */           name = "encodeURIComponent";
/*     */           break;
/*     */         case 5:
/*  46 */           name = "escape";
/*     */           break;
/*     */         case 6:
/*  49 */           name = "eval";
/*     */           break;
/*     */         case 7:
/*  52 */           name = "isFinite";
/*     */           break;
/*     */         case 8:
/*  55 */           name = "isNaN";
/*     */           break;
/*     */         case 9:
/*  58 */           name = "isXMLName";
/*     */           break;
/*     */         case 10:
/*  61 */           name = "parseFloat";
/*     */           break;
/*     */         case 11:
/*  64 */           name = "parseInt";
/*  65 */           arity = 2;
/*     */           break;
/*     */         case 12:
/*  68 */           name = "unescape";
/*     */           break;
/*     */         case 13:
/*  71 */           name = "uneval";
/*     */           break;
/*     */         default:
/*  74 */           throw Kit.codeBug();
/*     */       } 
/*  76 */       IdFunctionObject f = new IdFunctionObject(obj, FTAG, id, name, arity, scope);
/*  77 */       if (sealed) {
/*  78 */         f.sealObject();
/*     */       }
/*  80 */       f.exportAsScopeProperty();
/*     */     } 
/*     */     
/*  83 */     ScriptableObject.defineProperty(scope, "NaN", ScriptRuntime.NaNobj, 7);
/*     */     
/*  85 */     ScriptableObject.defineProperty(scope, "Infinity", 
/*     */ 
/*     */         
/*  88 */         ScriptRuntime.wrapNumber(Double.POSITIVE_INFINITY), 7);
/*     */     
/*  90 */     ScriptableObject.defineProperty(scope, "undefined", Undefined.instance, 7);
/*     */     
/*  92 */     ScriptableObject.defineProperty(scope, "globalThis", scope, 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     Scriptable nativeError = ScriptableObject.ensureScriptable(ScriptableObject.getProperty(scope, "Error"));
/*     */     
/* 101 */     Scriptable nativeErrorProto = ScriptableObject.ensureScriptable(
/* 102 */         ScriptableObject.getProperty(nativeError, "prototype"));
/*     */     
/* 104 */     for (TopLevel.NativeErrors error : TopLevel.NativeErrors.values()) {
/* 105 */       if (error != TopLevel.NativeErrors.Error) {
/*     */ 
/*     */ 
/*     */         
/* 109 */         String name = error.name();
/*     */ 
/*     */         
/* 112 */         ScriptableObject errorProto = (ScriptableObject)ScriptRuntime.newBuiltinObject(cx, scope, TopLevel.Builtins.Error, ScriptRuntime.emptyArgs);
/*     */         
/* 114 */         errorProto.defineProperty("name", name, 2);
/* 115 */         errorProto.defineProperty("message", "", 2);
/* 116 */         IdFunctionObject ctor = new IdFunctionObject(obj, FTAG, 14, name, 1, scope);
/*     */         
/* 118 */         ctor.markAsConstructor(errorProto);
/* 119 */         ctor.setPrototype(nativeError);
/* 120 */         errorProto.put("constructor", errorProto, ctor);
/* 121 */         errorProto.setAttributes("constructor", 2);
/* 122 */         errorProto.setPrototype(nativeErrorProto);
/* 123 */         if (sealed) {
/* 124 */           errorProto.sealObject();
/* 125 */           ctor.sealObject();
/*     */         } 
/* 127 */         ctor.setAttributes("name", 3);
/* 128 */         ctor.setAttributes("length", 3);
/* 129 */         ctor.exportAsScopeProperty();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 136 */     if (f.hasTag(FTAG)) {
/* 137 */       String str; boolean result; Object name, value; XMLLib xmlLib; int methodId = f.methodId();
/* 138 */       switch (methodId) {
/*     */         
/*     */         case 1:
/*     */         case 2:
/* 142 */           str = ScriptRuntime.toString(args, 0);
/* 143 */           return decode(str, (methodId == 1));
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/*     */         case 4:
/* 149 */           str = ScriptRuntime.toString(args, 0);
/* 150 */           return encode(str, (methodId == 3));
/*     */ 
/*     */         
/*     */         case 5:
/* 154 */           return js_escape(args);
/*     */         
/*     */         case 6:
/* 157 */           return js_eval(cx, scope, args);
/*     */ 
/*     */         
/*     */         case 7:
/* 161 */           if (args.length < 1) {
/* 162 */             return Boolean.FALSE;
/*     */           }
/* 164 */           return NativeNumber.isFinite(args[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 8:
/* 171 */           if (args.length < 1) {
/* 172 */             result = true;
/*     */           } else {
/* 174 */             double d = ScriptRuntime.toNumber(args[0]);
/* 175 */             result = Double.isNaN(d);
/*     */           } 
/* 177 */           return ScriptRuntime.wrapBoolean(result);
/*     */ 
/*     */ 
/*     */         
/*     */         case 9:
/* 182 */           name = (args.length == 0) ? Undefined.instance : args[0];
/* 183 */           xmlLib = XMLLib.extractFromScope(scope);
/* 184 */           return ScriptRuntime.wrapBoolean(xmlLib.isXMLName(cx, name));
/*     */ 
/*     */         
/*     */         case 10:
/* 188 */           return js_parseFloat(args);
/*     */         
/*     */         case 11:
/* 191 */           return js_parseInt(args);
/*     */         
/*     */         case 12:
/* 194 */           return js_unescape(args);
/*     */ 
/*     */         
/*     */         case 13:
/* 198 */           value = (args.length != 0) ? args[0] : Undefined.instance;
/* 199 */           return ScriptRuntime.uneval(cx, scope, value);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 14:
/* 205 */           return NativeError.make(cx, scope, f, args);
/*     */       } 
/*     */     } 
/* 208 */     throw f.unknown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object js_parseInt(Object[] args) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: iconst_0
/*     */     //   2: invokestatic toString : ([Ljava/lang/Object;I)Ljava/lang/String;
/*     */     //   5: astore_1
/*     */     //   6: aload_0
/*     */     //   7: iconst_1
/*     */     //   8: invokestatic toInt32 : ([Ljava/lang/Object;I)I
/*     */     //   11: istore_2
/*     */     //   12: aload_1
/*     */     //   13: invokevirtual length : ()I
/*     */     //   16: istore_3
/*     */     //   17: iload_3
/*     */     //   18: ifne -> 25
/*     */     //   21: getstatic org/mozilla/javascript/ScriptRuntime.NaNobj : Ljava/lang/Double;
/*     */     //   24: areturn
/*     */     //   25: iconst_0
/*     */     //   26: istore #4
/*     */     //   28: iconst_0
/*     */     //   29: istore #5
/*     */     //   31: aload_1
/*     */     //   32: iload #5
/*     */     //   34: invokevirtual charAt : (I)C
/*     */     //   37: istore #6
/*     */     //   39: iload #6
/*     */     //   41: invokestatic isStrWhiteSpaceChar : (I)Z
/*     */     //   44: ifne -> 50
/*     */     //   47: goto -> 59
/*     */     //   50: iinc #5, 1
/*     */     //   53: iload #5
/*     */     //   55: iload_3
/*     */     //   56: if_icmplt -> 31
/*     */     //   59: iload #6
/*     */     //   61: bipush #43
/*     */     //   63: if_icmpeq -> 84
/*     */     //   66: iload #6
/*     */     //   68: bipush #45
/*     */     //   70: if_icmpne -> 77
/*     */     //   73: iconst_1
/*     */     //   74: goto -> 78
/*     */     //   77: iconst_0
/*     */     //   78: dup
/*     */     //   79: istore #4
/*     */     //   81: ifeq -> 87
/*     */     //   84: iinc #5, 1
/*     */     //   87: iconst_m1
/*     */     //   88: istore #7
/*     */     //   90: iload_2
/*     */     //   91: ifne -> 99
/*     */     //   94: iconst_m1
/*     */     //   95: istore_2
/*     */     //   96: goto -> 166
/*     */     //   99: iload_2
/*     */     //   100: iconst_2
/*     */     //   101: if_icmplt -> 110
/*     */     //   104: iload_2
/*     */     //   105: bipush #36
/*     */     //   107: if_icmple -> 114
/*     */     //   110: getstatic org/mozilla/javascript/ScriptRuntime.NaNobj : Ljava/lang/Double;
/*     */     //   113: areturn
/*     */     //   114: iload_2
/*     */     //   115: bipush #16
/*     */     //   117: if_icmpne -> 166
/*     */     //   120: iload_3
/*     */     //   121: iload #5
/*     */     //   123: isub
/*     */     //   124: iconst_1
/*     */     //   125: if_icmple -> 166
/*     */     //   128: aload_1
/*     */     //   129: iload #5
/*     */     //   131: invokevirtual charAt : (I)C
/*     */     //   134: bipush #48
/*     */     //   136: if_icmpne -> 166
/*     */     //   139: aload_1
/*     */     //   140: iload #5
/*     */     //   142: iconst_1
/*     */     //   143: iadd
/*     */     //   144: invokevirtual charAt : (I)C
/*     */     //   147: istore #6
/*     */     //   149: iload #6
/*     */     //   151: bipush #120
/*     */     //   153: if_icmpeq -> 163
/*     */     //   156: iload #6
/*     */     //   158: bipush #88
/*     */     //   160: if_icmpne -> 166
/*     */     //   163: iinc #5, 2
/*     */     //   166: iload_2
/*     */     //   167: iconst_m1
/*     */     //   168: if_icmpne -> 267
/*     */     //   171: bipush #10
/*     */     //   173: istore_2
/*     */     //   174: iload_3
/*     */     //   175: iload #5
/*     */     //   177: isub
/*     */     //   178: iconst_1
/*     */     //   179: if_icmple -> 267
/*     */     //   182: aload_1
/*     */     //   183: iload #5
/*     */     //   185: invokevirtual charAt : (I)C
/*     */     //   188: bipush #48
/*     */     //   190: if_icmpne -> 267
/*     */     //   193: aload_1
/*     */     //   194: iload #5
/*     */     //   196: iconst_1
/*     */     //   197: iadd
/*     */     //   198: invokevirtual charAt : (I)C
/*     */     //   201: istore #6
/*     */     //   203: iload #6
/*     */     //   205: bipush #120
/*     */     //   207: if_icmpeq -> 217
/*     */     //   210: iload #6
/*     */     //   212: bipush #88
/*     */     //   214: if_icmpne -> 226
/*     */     //   217: bipush #16
/*     */     //   219: istore_2
/*     */     //   220: iinc #5, 2
/*     */     //   223: goto -> 267
/*     */     //   226: bipush #48
/*     */     //   228: iload #6
/*     */     //   230: if_icmpgt -> 267
/*     */     //   233: iload #6
/*     */     //   235: bipush #57
/*     */     //   237: if_icmpgt -> 267
/*     */     //   240: invokestatic getCurrentContext : ()Lorg/mozilla/javascript/Context;
/*     */     //   243: astore #8
/*     */     //   245: aload #8
/*     */     //   247: ifnull -> 261
/*     */     //   250: aload #8
/*     */     //   252: invokevirtual getLanguageVersion : ()I
/*     */     //   255: sipush #150
/*     */     //   258: if_icmpge -> 267
/*     */     //   261: bipush #8
/*     */     //   263: istore_2
/*     */     //   264: iinc #5, 1
/*     */     //   267: aload_1
/*     */     //   268: iload #5
/*     */     //   270: iload_2
/*     */     //   271: invokestatic stringPrefixToNumber : (Ljava/lang/String;II)D
/*     */     //   274: dstore #8
/*     */     //   276: iload #4
/*     */     //   278: ifeq -> 287
/*     */     //   281: dload #8
/*     */     //   283: dneg
/*     */     //   284: goto -> 289
/*     */     //   287: dload #8
/*     */     //   289: invokestatic wrapNumber : (D)Ljava/lang/Number;
/*     */     //   292: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #213	-> 0
/*     */     //   #214	-> 6
/*     */     //   #216	-> 12
/*     */     //   #217	-> 17
/*     */     //   #219	-> 25
/*     */     //   #220	-> 28
/*     */     //   #223	-> 31
/*     */     //   #224	-> 39
/*     */     //   #225	-> 50
/*     */     //   #226	-> 53
/*     */     //   #228	-> 59
/*     */     //   #230	-> 87
/*     */     //   #231	-> 90
/*     */     //   #232	-> 94
/*     */     //   #233	-> 99
/*     */     //   #234	-> 110
/*     */     //   #235	-> 114
/*     */     //   #236	-> 139
/*     */     //   #237	-> 149
/*     */     //   #240	-> 166
/*     */     //   #241	-> 171
/*     */     //   #242	-> 174
/*     */     //   #243	-> 193
/*     */     //   #244	-> 203
/*     */     //   #245	-> 217
/*     */     //   #246	-> 220
/*     */     //   #247	-> 226
/*     */     //   #248	-> 240
/*     */     //   #249	-> 245
/*     */     //   #250	-> 261
/*     */     //   #251	-> 264
/*     */     //   #257	-> 267
/*     */     //   #258	-> 276
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   245	22	8	cx	Lorg/mozilla/javascript/Context;
/*     */     //   0	293	0	args	[Ljava/lang/Object;
/*     */     //   6	287	1	s	Ljava/lang/String;
/*     */     //   12	281	2	radix	I
/*     */     //   17	276	3	len	I
/*     */     //   28	265	4	negative	Z
/*     */     //   31	262	5	start	I
/*     */     //   39	254	6	c	C
/*     */     //   90	203	7	NO_RADIX	I
/*     */     //   276	17	8	d	D
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object js_parseFloat(Object[] args) {
/*     */     char c;
/* 267 */     if (args.length < 1) return ScriptRuntime.NaNobj;
/*     */     
/* 269 */     String s = ScriptRuntime.toString(args[0]);
/* 270 */     int len = s.length();
/* 271 */     int start = 0;
/*     */ 
/*     */     
/*     */     while (true) {
/* 275 */       if (start == len) {
/* 276 */         return ScriptRuntime.NaNobj;
/*     */       }
/* 278 */       c = s.charAt(start);
/* 279 */       if (!ScriptRuntime.isStrWhiteSpaceChar(c)) {
/*     */         break;
/*     */       }
/* 282 */       start++;
/*     */     } 
/*     */     
/* 285 */     int i = start;
/* 286 */     if (c == '+' || c == '-') {
/* 287 */       i++;
/* 288 */       if (i == len) {
/* 289 */         return ScriptRuntime.NaNobj;
/*     */       }
/* 291 */       c = s.charAt(i);
/*     */     } 
/*     */     
/* 294 */     if (c == 'I') {
/*     */       
/* 296 */       if (i + 8 <= len && s.regionMatches(i, "Infinity", 0, 8)) {
/*     */         double d;
/* 298 */         if (s.charAt(start) == '-') {
/* 299 */           d = Double.NEGATIVE_INFINITY;
/*     */         } else {
/* 301 */           d = Double.POSITIVE_INFINITY;
/*     */         } 
/* 303 */         return ScriptRuntime.wrapNumber(d);
/*     */       } 
/* 305 */       return ScriptRuntime.NaNobj;
/*     */     } 
/*     */ 
/*     */     
/* 309 */     int decimal = -1;
/* 310 */     int exponent = -1;
/* 311 */     boolean exponentValid = false;
/* 312 */     for (; i < len; i++) {
/* 313 */       switch (s.charAt(i)) {
/*     */         case '.':
/* 315 */           if (decimal != -1)
/*     */             break; 
/* 317 */           decimal = i;
/*     */           break;
/*     */         
/*     */         case 'E':
/*     */         case 'e':
/* 322 */           if (exponent != -1)
/*     */             break; 
/* 324 */           if (i == len - 1) {
/*     */             break;
/*     */           }
/* 327 */           exponent = i;
/*     */           break;
/*     */ 
/*     */         
/*     */         case '+':
/*     */         case '-':
/* 333 */           if (exponent != i - 1)
/*     */             break; 
/* 335 */           if (i == len - 1) {
/* 336 */             i--;
/*     */             break;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case '0':
/*     */         case '1':
/*     */         case '2':
/*     */         case '3':
/*     */         case '4':
/*     */         case '5':
/*     */         case '6':
/*     */         case '7':
/*     */         case '8':
/*     */         case '9':
/* 351 */           if (exponent != -1) {
/* 352 */             exponentValid = true;
/*     */           }
/*     */           break;
/*     */         
/*     */         default:
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 361 */     if (exponent != -1 && !exponentValid) {
/* 362 */       i = exponent;
/*     */     }
/* 364 */     s = s.substring(start, i);
/*     */     try {
/* 366 */       return Double.valueOf(s);
/* 367 */     } catch (NumberFormatException ex) {
/* 368 */       return ScriptRuntime.NaNobj;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object js_escape(Object[] args) {
/* 379 */     int URL_XALPHAS = 1, URL_XPALPHAS = 2, URL_PATH = 4;
/*     */     
/* 381 */     String s = ScriptRuntime.toString(args, 0);
/*     */     
/* 383 */     int mask = 7;
/* 384 */     if (args.length > 1) {
/* 385 */       double d = ScriptRuntime.toNumber(args[1]);
/* 386 */       if (Double.isNaN(d) || (mask = (int)d) != d || 0 != (mask & 0xFFFFFFF8))
/*     */       {
/*     */         
/* 389 */         throw Context.reportRuntimeErrorById("msg.bad.esc.mask", new Object[0]);
/*     */       }
/*     */     } 
/*     */     
/* 393 */     StringBuilder sb = null;
/* 394 */     int k = 0, L = s.length(); while (true) { if (k != L) {
/* 395 */         int c = s.charAt(k);
/* 396 */         if (mask != 0 && ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 64 || c == 42 || c == 95 || c == 45 || c == 46 || (0 != (mask & 0x4) && (c == 47 || c == 43)))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 406 */           if (sb != null) {
/* 407 */             sb.append((char)c);
/*     */           }
/*     */         } else {
/* 410 */           if (sb == null) {
/* 411 */             sb = new StringBuilder(L + 3);
/* 412 */             sb.append(s);
/* 413 */             sb.setLength(k);
/*     */           } 
/*     */ 
/*     */           
/* 417 */           if (c < 256)
/* 418 */           { if (c == 32 && mask == 2)
/* 419 */             { sb.append('+'); }
/*     */             else
/*     */             
/* 422 */             { sb.append('%');
/* 423 */               int hexSize = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 431 */               int shift = (hexSize - 1) * 4; }  } else { sb.append('%'); sb.append('u'); int hexSize = 4; int i = (hexSize - 1) * 4; }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */       k++; }
/*     */     
/* 439 */     return (sb == null) ? s : sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object js_unescape(Object[] args) {
/* 444 */     String s = ScriptRuntime.toString(args, 0);
/* 445 */     int firstEscapePos = s.indexOf('%');
/* 446 */     if (firstEscapePos >= 0) {
/* 447 */       int L = s.length();
/* 448 */       char[] buf = s.toCharArray();
/* 449 */       int destination = firstEscapePos;
/* 450 */       for (int k = firstEscapePos; k != L; ) {
/* 451 */         char c = buf[k];
/* 452 */         k++;
/* 453 */         if (c == '%' && k != L) {
/*     */           int end; int start;
/* 455 */           if (buf[k] == 'u') {
/* 456 */             start = k + 1;
/* 457 */             end = k + 5;
/*     */           } else {
/* 459 */             start = k;
/* 460 */             end = k + 2;
/*     */           } 
/* 462 */           if (end <= L) {
/* 463 */             int x = 0;
/* 464 */             for (int i = start; i != end; i++) {
/* 465 */               x = Kit.xDigitToInt(buf[i], x);
/*     */             }
/* 467 */             if (x >= 0) {
/* 468 */               c = (char)x;
/* 469 */               k = end;
/*     */             } 
/*     */           } 
/*     */         } 
/* 473 */         buf[destination] = c;
/* 474 */         destination++;
/*     */       } 
/* 476 */       s = new String(buf, 0, destination);
/*     */     } 
/* 478 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object js_eval(Context cx, Scriptable scope, Object[] args) {
/* 486 */     Scriptable global = ScriptableObject.getTopLevelScope(scope);
/* 487 */     return ScriptRuntime.evalSpecial(cx, global, global, args, "eval code", 1);
/*     */   }
/*     */   
/*     */   static boolean isEvalFunction(Object functionObj) {
/* 491 */     if (functionObj instanceof IdFunctionObject) {
/* 492 */       IdFunctionObject function = (IdFunctionObject)functionObj;
/* 493 */       if (function.hasTag(FTAG) && function.methodId() == 6) {
/* 494 */         return true;
/*     */       }
/*     */     } 
/* 497 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EcmaError constructError(Context cx, String error, String message, Scriptable scope) {
/* 504 */     return ScriptRuntime.constructError(error, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EcmaError constructError(Context cx, String error, String message, Scriptable scope, String sourceName, int lineNumber, int columnNumber, String lineSource) {
/* 521 */     return ScriptRuntime.constructError(error, message, sourceName, lineNumber, lineSource, columnNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String encode(String str, boolean fullUri) {
/* 535 */     byte[] utf8buf = null;
/* 536 */     StringBuilder sb = null;
/*     */     
/* 538 */     for (int k = 0, length = str.length(); k != length; k++) {
/* 539 */       char C = str.charAt(k);
/* 540 */       if (encodeUnescaped(C, fullUri)) {
/* 541 */         if (sb != null)
/* 542 */           sb.append(C); 
/*     */       } else {
/*     */         int V;
/* 545 */         if (sb == null) {
/* 546 */           sb = new StringBuilder(length + 3);
/* 547 */           sb.append(str);
/* 548 */           sb.setLength(k);
/* 549 */           utf8buf = new byte[6];
/*     */         } 
/* 551 */         if ('?' <= C && C <= '?') {
/* 552 */           throw uriError();
/*     */         }
/*     */         
/* 555 */         if (C < '?' || '?' < C) {
/* 556 */           V = C;
/*     */         } else {
/* 558 */           k++;
/* 559 */           if (k == length) {
/* 560 */             throw uriError();
/*     */           }
/* 562 */           char C2 = str.charAt(k);
/* 563 */           if ('?' > C2 || C2 > '?') {
/* 564 */             throw uriError();
/*     */           }
/* 566 */           V = (C - 55296 << 10) + C2 - 56320 + 65536;
/*     */         } 
/* 568 */         int L = oneUcs4ToUtf8Char(utf8buf, V);
/* 569 */         for (int j = 0; j < L; j++) {
/* 570 */           int d = 0xFF & utf8buf[j];
/* 571 */           sb.append('%');
/* 572 */           sb.append(toHexChar(d >>> 4));
/* 573 */           sb.append(toHexChar(d & 0xF));
/*     */         } 
/*     */       } 
/*     */     } 
/* 577 */     return (sb == null) ? str : sb.toString();
/*     */   }
/*     */   
/*     */   private static char toHexChar(int i) {
/* 581 */     if (i >> 4 != 0) Kit.codeBug(); 
/* 582 */     return (char)((i < 10) ? (i + 48) : (i - 10 + 65));
/*     */   }
/*     */   
/*     */   private static int unHex(char c) {
/* 586 */     if ('A' <= c && c <= 'F')
/* 587 */       return c - 65 + 10; 
/* 588 */     if ('a' <= c && c <= 'f')
/* 589 */       return c - 97 + 10; 
/* 590 */     if ('0' <= c && c <= '9') {
/* 591 */       return c - 48;
/*     */     }
/* 593 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int unHex(char c1, char c2) {
/* 598 */     int i1 = unHex(c1);
/* 599 */     int i2 = unHex(c2);
/* 600 */     if (i1 >= 0 && i2 >= 0) {
/* 601 */       return i1 << 4 | i2;
/*     */     }
/* 603 */     return -1;
/*     */   }
/*     */   
/*     */   private static String decode(String str, boolean fullUri) {
/* 607 */     char[] buf = null;
/* 608 */     int bufTop = 0;
/*     */     
/* 610 */     for (int k = 0, length = str.length(); k != length; ) {
/* 611 */       char C = str.charAt(k);
/* 612 */       if (C != '%') {
/* 613 */         if (buf != null) {
/* 614 */           buf[bufTop++] = C;
/*     */         }
/* 616 */         k++; continue;
/*     */       } 
/* 618 */       if (buf == null) {
/*     */ 
/*     */         
/* 621 */         buf = new char[length];
/* 622 */         str.getChars(0, k, buf, 0);
/* 623 */         bufTop = k;
/*     */       } 
/* 625 */       int start = k;
/* 626 */       if (k + 3 > length) throw uriError(); 
/* 627 */       int B = unHex(str.charAt(k + 1), str.charAt(k + 2));
/* 628 */       if (B < 0) throw uriError(); 
/* 629 */       k += 3;
/* 630 */       if ((B & 0x80) == 0) {
/* 631 */         C = (char)B;
/*     */       } else {
/*     */         int utf8Tail;
/*     */         int ucs4Char;
/*     */         int minUcs4Char;
/* 636 */         if ((B & 0xC0) == 128)
/*     */         {
/* 638 */           throw uriError(); } 
/* 639 */         if ((B & 0x20) == 0) {
/* 640 */           utf8Tail = 1;
/* 641 */           ucs4Char = B & 0x1F;
/* 642 */           minUcs4Char = 128;
/* 643 */         } else if ((B & 0x10) == 0) {
/* 644 */           utf8Tail = 2;
/* 645 */           ucs4Char = B & 0xF;
/* 646 */           minUcs4Char = 2048;
/* 647 */         } else if ((B & 0x8) == 0) {
/* 648 */           utf8Tail = 3;
/* 649 */           ucs4Char = B & 0x7;
/* 650 */           minUcs4Char = 65536;
/* 651 */         } else if ((B & 0x4) == 0) {
/* 652 */           utf8Tail = 4;
/* 653 */           ucs4Char = B & 0x3;
/* 654 */           minUcs4Char = 2097152;
/* 655 */         } else if ((B & 0x2) == 0) {
/* 656 */           utf8Tail = 5;
/* 657 */           ucs4Char = B & 0x1;
/* 658 */           minUcs4Char = 67108864;
/*     */         } else {
/*     */           
/* 661 */           throw uriError();
/*     */         } 
/* 663 */         if (k + 3 * utf8Tail > length) throw uriError(); 
/* 664 */         for (int j = 0; j != utf8Tail; j++) {
/* 665 */           if (str.charAt(k) != '%') throw uriError(); 
/* 666 */           B = unHex(str.charAt(k + 1), str.charAt(k + 2));
/* 667 */           if (B < 0 || (B & 0xC0) != 128) throw uriError(); 
/* 668 */           ucs4Char = ucs4Char << 6 | B & 0x3F;
/* 669 */           k += 3;
/*     */         } 
/*     */         
/* 672 */         if (ucs4Char < minUcs4Char || (ucs4Char >= 55296 && ucs4Char <= 57343)) {
/* 673 */           ucs4Char = Integer.MAX_VALUE;
/* 674 */         } else if (ucs4Char == 65534 || ucs4Char == 65535) {
/* 675 */           ucs4Char = 65533;
/*     */         } 
/* 677 */         if (ucs4Char >= 65536) {
/* 678 */           ucs4Char -= 65536;
/* 679 */           if (ucs4Char > 1048575) {
/* 680 */             throw uriError();
/*     */           }
/* 682 */           char H = (char)((ucs4Char >>> 10) + 55296);
/* 683 */           C = (char)((ucs4Char & 0x3FF) + 56320);
/* 684 */           buf[bufTop++] = H;
/*     */         } else {
/* 686 */           C = (char)ucs4Char;
/*     */         } 
/*     */       } 
/* 689 */       if (fullUri && ";/?:@&=+$,#".indexOf(C) >= 0) {
/* 690 */         for (int x = start; x != k; x++)
/* 691 */           buf[bufTop++] = str.charAt(x); 
/*     */         continue;
/*     */       } 
/* 694 */       buf[bufTop++] = C;
/*     */     } 
/*     */ 
/*     */     
/* 698 */     return (buf == null) ? str : new String(buf, 0, bufTop);
/*     */   }
/*     */   
/*     */   private static boolean encodeUnescaped(char c, boolean fullUri) {
/* 702 */     if (('A' <= c && c <= 'Z') || ('a' <= c && c <= 'z') || ('0' <= c && c <= '9')) {
/* 703 */       return true;
/*     */     }
/* 705 */     if ("-_.!~*'()".indexOf(c) >= 0) {
/* 706 */       return true;
/*     */     }
/* 708 */     if (fullUri) {
/* 709 */       return (";/?:@&=+$,#".indexOf(c) >= 0);
/*     */     }
/* 711 */     return false;
/*     */   }
/*     */   
/*     */   private static EcmaError uriError() {
/* 715 */     return ScriptRuntime.constructError("URIError", 
/* 716 */         ScriptRuntime.getMessageById("msg.bad.uri", new Object[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int oneUcs4ToUtf8Char(byte[] utf8Buffer, int ucs4Char) {
/* 726 */     int utf8Length = 1;
/*     */ 
/*     */     
/* 729 */     if ((ucs4Char & 0xFFFFFF80) == 0) { utf8Buffer[0] = (byte)ucs4Char; }
/*     */     else
/*     */     
/* 732 */     { int a = ucs4Char >>> 11;
/* 733 */       utf8Length = 2;
/* 734 */       while (a != 0) {
/* 735 */         a >>>= 5;
/* 736 */         utf8Length++;
/*     */       } 
/* 738 */       int i = utf8Length;
/* 739 */       while (--i > 0) {
/* 740 */         utf8Buffer[i] = (byte)(ucs4Char & 0x3F | 0x80);
/* 741 */         ucs4Char >>>= 6;
/*     */       } 
/* 743 */       utf8Buffer[0] = (byte)(256 - (1 << 8 - utf8Length) + ucs4Char); }
/*     */     
/* 745 */     return utf8Length;
/*     */   }
/*     */   
/* 748 */   private static final Object FTAG = "Global";
/*     */   private static final int Id_decodeURI = 1;
/*     */   private static final int Id_decodeURIComponent = 2;
/*     */   private static final int Id_encodeURI = 3;
/*     */   private static final int Id_encodeURIComponent = 4;
/*     */   private static final int Id_escape = 5;
/*     */   private static final int Id_eval = 6;
/*     */   private static final int Id_isFinite = 7;
/*     */   private static final int Id_isNaN = 8;
/*     */   private static final int Id_isXMLName = 9;
/*     */   private static final int Id_parseFloat = 10;
/*     */   private static final int Id_parseInt = 11;
/*     */   private static final int Id_unescape = 12;
/*     */   private static final int Id_uneval = 13;
/*     */   private static final int LAST_SCOPE_FUNCTION_ID = 13;
/*     */   private static final int Id_new_CommonError = 14;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeGlobal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */