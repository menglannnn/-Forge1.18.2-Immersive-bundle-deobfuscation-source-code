/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import java.security.ProtectionDomain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityUtilities
/*    */ {
/*    */   public static String getSystemProperty(final String name) {
/* 26 */     return AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*    */         {
/*    */ 
/*    */           
/*    */           public String run()
/*    */           {
/* 32 */             return System.getProperty(name);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public static ProtectionDomain getProtectionDomain(final Class<?> clazz) {
/* 39 */     return AccessController.<ProtectionDomain>doPrivileged(new PrivilegedAction<ProtectionDomain>()
/*    */         {
/*    */ 
/*    */           
/*    */           public ProtectionDomain run()
/*    */           {
/* 45 */             return clazz.getProtectionDomain();
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ProtectionDomain getScriptProtectionDomain() {
/* 58 */     final SecurityManager securityManager = System.getSecurityManager();
/* 59 */     if (securityManager instanceof RhinoSecurityManager) {
/* 60 */       return AccessController.<ProtectionDomain>doPrivileged(new PrivilegedAction<ProtectionDomain>()
/*    */           {
/*    */             
/*    */             public ProtectionDomain run()
/*    */             {
/* 65 */               Class<?> c = ((RhinoSecurityManager)securityManager).getCurrentScriptClass();
/* 66 */               return (c == null) ? null : c.getProtectionDomain();
/*    */             }
/*    */           });
/*    */     }
/*    */     
/* 71 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\SecurityUtilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */