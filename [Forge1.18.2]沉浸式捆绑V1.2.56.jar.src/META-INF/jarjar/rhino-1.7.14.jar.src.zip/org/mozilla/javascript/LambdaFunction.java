/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LambdaFunction
/*    */   extends BaseFunction
/*    */ {
/*    */   private static final long serialVersionUID = -8388132362854748293L;
/*    */   private final transient Callable target;
/*    */   private final String name;
/*    */   private final int length;
/*    */   
/*    */   public LambdaFunction(Scriptable scope, String name, int length, Callable target) {
/* 34 */     this.target = target;
/* 35 */     this.name = name;
/* 36 */     this.length = length;
/* 37 */     ScriptRuntime.setFunctionProtoAndParent(this, scope);
/* 38 */     setupDefaultPrototype();
/*    */   }
/*    */ 
/*    */   
/*    */   public LambdaFunction(Scriptable scope, int length, Callable target) {
/* 43 */     this.target = target;
/* 44 */     this.length = length;
/* 45 */     this.name = "";
/* 46 */     ScriptRuntime.setFunctionProtoAndParent(this, scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 51 */     return this.target.call(cx, scope, thisObj, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/* 56 */     throw ScriptRuntime.typeErrorById("msg.no.new", new Object[] { getFunctionName() });
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 61 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getArity() {
/* 66 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getFunctionName() {
/* 71 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\LambdaFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */