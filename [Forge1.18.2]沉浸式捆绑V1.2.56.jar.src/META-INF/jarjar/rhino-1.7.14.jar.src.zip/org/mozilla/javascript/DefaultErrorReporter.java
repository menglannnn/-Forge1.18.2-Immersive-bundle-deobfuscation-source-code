/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultErrorReporter
/*    */   implements ErrorReporter
/*    */ {
/* 16 */   static final DefaultErrorReporter instance = new DefaultErrorReporter();
/*    */ 
/*    */   
/*    */   private boolean forEval;
/*    */   
/*    */   private ErrorReporter chainedReporter;
/*    */ 
/*    */   
/*    */   static ErrorReporter forEval(ErrorReporter reporter) {
/* 25 */     DefaultErrorReporter r = new DefaultErrorReporter();
/* 26 */     r.forEval = true;
/* 27 */     r.chainedReporter = reporter;
/* 28 */     return r;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void warning(String message, String sourceURI, int line, String lineText, int lineOffset) {
/* 35 */     if (this.chainedReporter != null) {
/* 36 */       this.chainedReporter.warning(message, sourceURI, line, lineText, lineOffset);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void error(String message, String sourceURI, int line, String lineText, int lineOffset) {
/* 47 */     if (this.forEval) {
/*    */ 
/*    */ 
/*    */       
/* 51 */       String error = "SyntaxError";
/* 52 */       String TYPE_ERROR_NAME = "TypeError";
/* 53 */       String DELIMETER = ": ";
/* 54 */       String prefix = "TypeError: ";
/* 55 */       if (message.startsWith("TypeError: ")) {
/* 56 */         error = "TypeError";
/* 57 */         message = message.substring("TypeError: ".length());
/*    */       } 
/* 59 */       throw ScriptRuntime.constructError(error, message, sourceURI, line, lineText, lineOffset);
/*    */     } 
/*    */     
/* 62 */     if (this.chainedReporter != null) {
/* 63 */       this.chainedReporter.error(message, sourceURI, line, lineText, lineOffset);
/*    */     } else {
/*    */       
/* 66 */       throw runtimeError(message, sourceURI, line, lineText, lineOffset);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EvaluatorException runtimeError(String message, String sourceURI, int line, String lineText, int lineOffset) {
/* 76 */     if (this.chainedReporter != null) {
/* 77 */       return this.chainedReporter.runtimeError(message, sourceURI, line, lineText, lineOffset);
/*    */     }
/* 79 */     return new EvaluatorException(message, sourceURI, line, lineText, lineOffset);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\DefaultErrorReporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */