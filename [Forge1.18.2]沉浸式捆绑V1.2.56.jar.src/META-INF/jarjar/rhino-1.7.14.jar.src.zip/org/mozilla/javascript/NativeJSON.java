/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import org.mozilla.javascript.json.JsonParser;
/*     */ import org.mozilla.javascript.xml.XMLObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeJSON
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = -4567599697595654984L;
/*  29 */   private static final Object JSON_TAG = "JSON"; private static final int MAX_STRINGIFY_GAP_LENGTH = 10;
/*     */   private static final int Id_toSource = 1;
/*     */   private static final int Id_parse = 2;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  34 */     NativeJSON obj = new NativeJSON();
/*  35 */     obj.activatePrototypeMap(3);
/*  36 */     obj.setPrototype(getObjectPrototype(scope));
/*  37 */     obj.setParentScope(scope);
/*  38 */     if (sealed) {
/*  39 */       obj.sealObject();
/*     */     }
/*  41 */     ScriptableObject.defineProperty(scope, "JSON", obj, 2);
/*     */   }
/*     */   private static final int Id_stringify = 3;
/*     */   private static final int LAST_METHOD_ID = 3;
/*     */   private static final int MAX_ID = 3;
/*     */   
/*     */   public String getClassName() {
/*  48 */     return "JSON";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*  53 */     if (id <= 3) {
/*     */       String name;
/*     */       int arity;
/*  56 */       switch (id) {
/*     */         case 1:
/*  58 */           arity = 0;
/*  59 */           name = "toSource";
/*     */           break;
/*     */         case 2:
/*  62 */           arity = 2;
/*  63 */           name = "parse";
/*     */           break;
/*     */         case 3:
/*  66 */           arity = 3;
/*  67 */           name = "stringify";
/*     */           break;
/*     */         default:
/*  70 */           throw new IllegalStateException(String.valueOf(id));
/*     */       } 
/*  72 */       initPrototypeMethod(JSON_TAG, id, name, arity);
/*     */     } else {
/*  74 */       throw new IllegalStateException(String.valueOf(id));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     String jtext;
/*     */     Object value, reviver, replacer, space;
/*  81 */     if (!f.hasTag(JSON_TAG)) {
/*  82 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  84 */     int methodId = f.methodId();
/*  85 */     switch (methodId) {
/*     */       case 1:
/*  87 */         return "JSON";
/*     */ 
/*     */       
/*     */       case 2:
/*  91 */         jtext = ScriptRuntime.toString(args, 0);
/*  92 */         reviver = null;
/*  93 */         if (args.length > 1) {
/*  94 */           reviver = args[1];
/*     */         }
/*  96 */         if (reviver instanceof Callable) {
/*  97 */           return parse(cx, scope, jtext, (Callable)reviver);
/*     */         }
/*  99 */         return parse(cx, scope, jtext);
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 104 */         value = Undefined.instance; replacer = null; space = null;
/*     */         
/* 106 */         if (args.length > 0) {
/* 107 */           value = args[0];
/* 108 */           if (args.length > 1) {
/* 109 */             replacer = args[1];
/* 110 */             if (args.length > 2) {
/* 111 */               space = args[2];
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 116 */         return stringify(cx, scope, value, replacer, space);
/*     */     } 
/*     */ 
/*     */     
/* 120 */     throw new IllegalStateException(String.valueOf(methodId));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object parse(Context cx, Scriptable scope, String jtext) {
/*     */     try {
/* 126 */       return (new JsonParser(cx, scope)).parseValue(jtext);
/* 127 */     } catch (org.mozilla.javascript.json.JsonParser.ParseException ex) {
/* 128 */       throw ScriptRuntime.constructError("SyntaxError", ex.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object parse(Context cx, Scriptable scope, String jtext, Callable reviver) {
/* 133 */     Object unfiltered = parse(cx, scope, jtext);
/* 134 */     Scriptable root = cx.newObject(scope);
/* 135 */     root.put("", root, unfiltered);
/* 136 */     return walk(cx, scope, reviver, root, "");
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object walk(Context cx, Scriptable scope, Callable reviver, Scriptable holder, Object name) {
/*     */     Object property;
/* 142 */     if (name instanceof Number) {
/* 143 */       property = holder.get(((Number)name).intValue(), holder);
/*     */     } else {
/* 145 */       property = holder.get((String)name, holder);
/*     */     } 
/*     */     
/* 148 */     if (property instanceof Scriptable) {
/* 149 */       Scriptable val = (Scriptable)property;
/* 150 */       if (val instanceof NativeArray) {
/* 151 */         long len = ((NativeArray)val).getLength(); long i;
/* 152 */         for (i = 0L; i < len; i++) {
/*     */           
/* 154 */           if (i > 2147483647L) {
/* 155 */             String id = Long.toString(i);
/* 156 */             Object newElement = walk(cx, scope, reviver, val, id);
/* 157 */             if (newElement == Undefined.instance) {
/* 158 */               val.delete(id);
/*     */             } else {
/* 160 */               val.put(id, val, newElement);
/*     */             } 
/*     */           } else {
/* 163 */             int idx = (int)i;
/* 164 */             Object newElement = walk(cx, scope, reviver, val, Integer.valueOf(idx));
/* 165 */             if (newElement == Undefined.instance) {
/* 166 */               val.delete(idx);
/*     */             } else {
/* 168 */               val.put(idx, val, newElement);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } else {
/* 173 */         Object[] keys = val.getIds();
/* 174 */         for (Object p : keys) {
/* 175 */           Object newElement = walk(cx, scope, reviver, val, p);
/* 176 */           if (newElement == Undefined.instance)
/* 177 */           { if (p instanceof Number) { val.delete(((Number)p).intValue()); }
/* 178 */             else { val.delete((String)p); }
/*     */              }
/* 180 */           else if (p instanceof Number) { val.put(((Number)p).intValue(), val, newElement); }
/* 181 */           else { val.put((String)p, val, newElement); }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 187 */     return reviver.call(cx, scope, holder, new Object[] { name, property });
/*     */   }
/*     */   
/*     */   private static String repeat(char c, int count) {
/* 191 */     char[] chars = new char[count];
/* 192 */     Arrays.fill(chars, c);
/* 193 */     return new String(chars);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StringifyState
/*     */   {
/*     */     Stack<Object> stack;
/*     */     
/*     */     String indent;
/*     */     
/*     */     String gap;
/*     */     
/*     */     Callable replacer;
/*     */     
/*     */     Object[] propertyList;
/*     */     
/*     */     Context cx;
/*     */     Scriptable scope;
/*     */     
/*     */     StringifyState(Context cx, Scriptable scope, String indent, String gap, Callable replacer, Object[] propertyList) {
/* 213 */       this.stack = new Stack();
/*     */       this.cx = cx;
/*     */       this.scope = scope;
/*     */       this.indent = indent;
/*     */       this.gap = gap;
/*     */       this.replacer = replacer;
/*     */       this.propertyList = propertyList;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object stringify(Context cx, Scriptable scope, Object value, Object replacer, Object space) {
/* 225 */     String indent = "";
/* 226 */     String gap = "";
/*     */     
/* 228 */     Object[] propertyList = null;
/* 229 */     Callable replacerFunction = null;
/*     */     
/* 231 */     if (replacer instanceof Callable) {
/* 232 */       replacerFunction = (Callable)replacer;
/* 233 */     } else if (replacer instanceof NativeArray) {
/* 234 */       LinkedHashSet<Object> propertySet = new LinkedHashSet();
/* 235 */       NativeArray replacerArray = (NativeArray)replacer;
/* 236 */       for (Iterator<Integer> iterator = replacerArray.getIndexIds().iterator(); iterator.hasNext(); ) { int j = ((Integer)iterator.next()).intValue();
/* 237 */         Object v = replacerArray.get(j, replacerArray);
/* 238 */         if (v instanceof String) {
/* 239 */           propertySet.add(v); continue;
/* 240 */         }  if (v instanceof Number || v instanceof NativeString || v instanceof NativeNumber)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 245 */           propertySet.add(ScriptRuntime.toString(v));
/*     */         } }
/*     */ 
/*     */ 
/*     */       
/* 250 */       propertyList = new Object[propertySet.size()];
/* 251 */       int i = 0;
/* 252 */       for (Object prop : propertySet) {
/* 253 */         ScriptRuntime.StringIdOrIndex idOrIndex = ScriptRuntime.toStringIdOrIndex(cx, prop);
/*     */         
/* 255 */         propertyList[i++] = (idOrIndex.stringId == null) ? 
/* 256 */           Integer.valueOf(idOrIndex.index) : idOrIndex.stringId;
/*     */       } 
/*     */     } 
/*     */     
/* 260 */     if (space instanceof NativeNumber) {
/* 261 */       space = Double.valueOf(ScriptRuntime.toNumber(space));
/* 262 */     } else if (space instanceof NativeString) {
/* 263 */       space = ScriptRuntime.toString(space);
/*     */     } 
/*     */     
/* 266 */     if (space instanceof Number) {
/* 267 */       int gapLength = (int)ScriptRuntime.toInteger(space);
/* 268 */       gapLength = Math.min(10, gapLength);
/* 269 */       gap = (gapLength > 0) ? repeat(' ', gapLength) : "";
/* 270 */     } else if (space instanceof String) {
/* 271 */       gap = (String)space;
/* 272 */       if (gap.length() > 10) {
/* 273 */         gap = gap.substring(0, 10);
/*     */       }
/*     */     } 
/*     */     
/* 277 */     StringifyState state = new StringifyState(cx, scope, indent, gap, replacerFunction, propertyList);
/*     */ 
/*     */     
/* 280 */     ScriptableObject wrapper = new NativeObject();
/* 281 */     wrapper.setParentScope(scope);
/* 282 */     wrapper.setPrototype(ScriptableObject.getObjectPrototype(scope));
/* 283 */     wrapper.defineProperty("", value, 0);
/* 284 */     return str("", wrapper, state);
/*     */   }
/*     */   
/*     */   private static Object str(Object key, Scriptable holder, StringifyState state) {
/* 288 */     Object value = null;
/* 289 */     Object unwrappedJavaValue = null;
/*     */     
/* 291 */     if (key instanceof String) {
/* 292 */       value = getProperty(holder, (String)key);
/*     */     } else {
/* 294 */       value = getProperty(holder, ((Number)key).intValue());
/*     */     } 
/*     */     
/* 297 */     if (value instanceof Scriptable && hasProperty((Scriptable)value, "toJSON")) {
/* 298 */       Object toJSON = getProperty((Scriptable)value, "toJSON");
/* 299 */       if (toJSON instanceof Callable) {
/* 300 */         value = callMethod(state.cx, (Scriptable)value, "toJSON", new Object[] { key });
/*     */       }
/* 302 */     } else if (value instanceof java.math.BigInteger) {
/* 303 */       Scriptable bigInt = ScriptRuntime.toObject(state.cx, state.scope, value);
/* 304 */       if (hasProperty(bigInt, "toJSON")) {
/* 305 */         Object toJSON = getProperty(bigInt, "toJSON");
/* 306 */         if (toJSON instanceof Callable) {
/* 307 */           value = callMethod(state.cx, bigInt, "toJSON", new Object[] { key });
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 312 */     if (state.replacer != null) {
/* 313 */       value = state.replacer.call(state.cx, state.scope, holder, new Object[] { key, value });
/*     */     }
/*     */     
/* 316 */     if (value instanceof NativeNumber) {
/* 317 */       value = Double.valueOf(ScriptRuntime.toNumber(value));
/* 318 */     } else if (value instanceof NativeString) {
/* 319 */       value = ScriptRuntime.toString(value);
/* 320 */     } else if (value instanceof NativeBoolean) {
/* 321 */       value = ((NativeBoolean)value).getDefaultValue(ScriptRuntime.BooleanClass);
/* 322 */     } else if (state.cx.getLanguageVersion() >= 200 && value instanceof NativeBigInt) {
/*     */       
/* 324 */       value = ((NativeBigInt)value).getDefaultValue(ScriptRuntime.BigIntegerClass);
/* 325 */     } else if (value instanceof NativeJavaObject) {
/* 326 */       unwrappedJavaValue = ((NativeJavaObject)value).unwrap();
/* 327 */       if (!(unwrappedJavaValue instanceof Map) && !(unwrappedJavaValue instanceof Collection) && 
/*     */         
/* 329 */         !unwrappedJavaValue.getClass().isArray()) {
/* 330 */         value = unwrappedJavaValue;
/*     */       } else {
/*     */         
/* 333 */         unwrappedJavaValue = null;
/*     */       } 
/* 335 */     } else if (value instanceof XMLObject) {
/* 336 */       value = ((XMLObject)value).toString();
/*     */     } 
/*     */     
/* 339 */     if (value == null) return "null"; 
/* 340 */     if (value.equals(Boolean.TRUE)) return "true"; 
/* 341 */     if (value.equals(Boolean.FALSE)) return "false";
/*     */     
/* 343 */     if (value instanceof CharSequence) {
/* 344 */       return quote(value.toString());
/*     */     }
/*     */     
/* 347 */     if (value instanceof Number) {
/* 348 */       if (value instanceof java.math.BigInteger) {
/* 349 */         throw ScriptRuntime.typeErrorById("msg.json.cant.serialize", new Object[] { "BigInt" });
/*     */       }
/* 351 */       double d = ((Number)value).doubleValue();
/* 352 */       if (!Double.isNaN(d) && d != Double.POSITIVE_INFINITY && d != Double.NEGATIVE_INFINITY)
/*     */       {
/*     */         
/* 355 */         return ScriptRuntime.toString(value);
/*     */       }
/* 357 */       return "null";
/*     */     } 
/*     */     
/* 360 */     if (unwrappedJavaValue != null) {
/* 361 */       return javaToJSON(value, state);
/*     */     }
/*     */     
/* 364 */     if (value instanceof Scriptable && !(value instanceof Callable)) {
/* 365 */       if (isObjectArrayLike(value)) {
/* 366 */         return ja((Scriptable)value, state);
/*     */       }
/* 368 */       return jo((Scriptable)value, state);
/*     */     } 
/* 370 */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   private static String join(Collection<Object> objs, String delimiter) {
/* 374 */     if (objs == null || objs.isEmpty()) {
/* 375 */       return "";
/*     */     }
/* 377 */     Iterator<Object> iter = objs.iterator();
/* 378 */     if (!iter.hasNext()) return ""; 
/* 379 */     StringBuilder builder = new StringBuilder(iter.next().toString());
/* 380 */     while (iter.hasNext()) {
/* 381 */       builder.append(delimiter).append(iter.next());
/*     */     }
/* 383 */     return builder.toString();
/*     */   }
/*     */   private static String jo(Scriptable value, StringifyState state) {
/*     */     String finalValue;
/* 387 */     Object trackValue = value, unwrapped = null;
/* 388 */     if (value instanceof Wrapper) {
/* 389 */       trackValue = unwrapped = ((Wrapper)value).unwrap();
/*     */     }
/*     */     
/* 392 */     if (state.stack.search(trackValue) != -1) {
/* 393 */       throw ScriptRuntime.typeErrorById("msg.cyclic.value", new Object[] { trackValue.getClass().getName() });
/*     */     }
/* 395 */     state.stack.push(trackValue);
/*     */     
/* 397 */     if (unwrapped instanceof Map) {
/* 398 */       Map<?, ?> map = (Map<?, ?>)unwrapped;
/* 399 */       Scriptable nObj = state.cx.newObject(state.scope);
/* 400 */       for (Map.Entry<?, ?> entry : map.entrySet()) {
/* 401 */         int attributes; String key; if (entry.getKey() instanceof Symbol)
/* 402 */           continue;  Object wrappedValue = Context.javaToJS(entry.getValue(), state.scope, state.cx);
/*     */ 
/*     */         
/* 405 */         if (entry.getKey() instanceof String) {
/*     */ 
/*     */           
/* 408 */           key = (String)entry.getKey();
/* 409 */           attributes = 5;
/*     */         }
/*     */         else {
/*     */           
/* 413 */           key = entry.getKey().toString();
/* 414 */           attributes = 0;
/*     */         } 
/*     */         try {
/* 417 */           ScriptableObject.defineProperty(nObj, key, wrappedValue, attributes);
/* 418 */         } catch (EcmaError ecmaError) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 423 */       value = nObj;
/*     */     } 
/*     */     
/* 426 */     String stepback = state.indent;
/* 427 */     state.indent += state.gap;
/* 428 */     Object[] k = null;
/* 429 */     if (state.propertyList != null) {
/* 430 */       k = state.propertyList;
/*     */     } else {
/* 432 */       k = value.getIds();
/*     */     } 
/*     */     
/* 435 */     Collection<Object> partial = new LinkedList();
/*     */     
/* 437 */     for (Object p : k) {
/* 438 */       Object strP = str(p, value, state);
/* 439 */       if (strP != Undefined.instance) {
/* 440 */         String member = quote(p.toString()) + ":";
/* 441 */         if (state.gap.length() > 0) {
/* 442 */           member = member + " ";
/*     */         }
/* 444 */         member = member + strP;
/* 445 */         partial.add(member);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 451 */     if (partial.isEmpty()) {
/* 452 */       finalValue = "{}";
/*     */     }
/* 454 */     else if (state.gap.length() == 0) {
/* 455 */       finalValue = '{' + join(partial, ",") + '}';
/*     */     } else {
/* 457 */       String separator = ",\n" + state.indent;
/* 458 */       String properties = join(partial, separator);
/* 459 */       finalValue = "{\n" + state.indent + properties + '\n' + stepback + '}';
/*     */     } 
/*     */ 
/*     */     
/* 463 */     state.stack.pop();
/* 464 */     state.indent = stepback;
/* 465 */     return finalValue;
/*     */   }
/*     */   private static String ja(Scriptable value, StringifyState state) {
/*     */     String finalValue;
/* 469 */     Object trackValue = value, unwrapped = null;
/* 470 */     if (value instanceof Wrapper) {
/* 471 */       trackValue = unwrapped = ((Wrapper)value).unwrap();
/*     */     }
/* 473 */     if (state.stack.search(trackValue) != -1) {
/* 474 */       throw ScriptRuntime.typeErrorById("msg.cyclic.value", new Object[] { trackValue.getClass().getName() });
/*     */     }
/* 476 */     state.stack.push(trackValue);
/*     */     
/* 478 */     String stepback = state.indent;
/* 479 */     state.indent += state.gap;
/* 480 */     Collection<Object> partial = new LinkedList();
/*     */     
/* 482 */     if (unwrapped != null) {
/* 483 */       Object[] elements = null;
/* 484 */       if (unwrapped.getClass().isArray()) {
/* 485 */         int length = Array.getLength(unwrapped);
/* 486 */         elements = new Object[length];
/* 487 */         for (int i = 0; i < length; i++) {
/* 488 */           elements[i] = Context.javaToJS(Array.get(unwrapped, i), state.scope, state.cx);
/*     */         }
/* 490 */       } else if (unwrapped instanceof Collection) {
/* 491 */         Collection<?> collection = (Collection)unwrapped;
/* 492 */         elements = new Object[collection.size()];
/* 493 */         int i = 0;
/* 494 */         for (Object o : collection) {
/* 495 */           elements[i++] = Context.javaToJS(o, state.scope, state.cx);
/*     */         }
/*     */       } 
/* 498 */       if (elements != null) {
/* 499 */         value = state.cx.newArray(state.scope, elements);
/*     */       }
/*     */     } 
/*     */     
/* 503 */     long len = ((NativeArray)value).getLength();
/*     */     long index;
/* 505 */     for (index = 0L; index < len; index++) {
/*     */       Object strP;
/* 507 */       if (index > 2147483647L) {
/* 508 */         strP = str(Long.toString(index), value, state);
/*     */       } else {
/* 510 */         strP = str(Integer.valueOf((int)index), value, state);
/*     */       } 
/* 512 */       if (strP == Undefined.instance) {
/* 513 */         partial.add("null");
/*     */       } else {
/* 515 */         partial.add(strP);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 521 */     if (partial.isEmpty()) {
/* 522 */       finalValue = "[]";
/*     */     }
/* 524 */     else if (state.gap.length() == 0) {
/* 525 */       finalValue = '[' + join(partial, ",") + ']';
/*     */     } else {
/* 527 */       String separator = ",\n" + state.indent;
/* 528 */       String properties = join(partial, separator);
/* 529 */       finalValue = "[\n" + state.indent + properties + '\n' + stepback + ']';
/*     */     } 
/*     */ 
/*     */     
/* 533 */     state.stack.pop();
/* 534 */     state.indent = stepback;
/* 535 */     return finalValue;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String quote(String string) {
/* 540 */     StringBuilder product = new StringBuilder(string.length() + 2);
/* 541 */     product.append('"');
/* 542 */     int length = string.length();
/* 543 */     for (int i = 0; i < length; i++) {
/* 544 */       char c = string.charAt(i);
/* 545 */       switch (c) {
/*     */         case '"':
/* 547 */           product.append("\\\"");
/*     */           break;
/*     */         case '\\':
/* 550 */           product.append("\\\\");
/*     */           break;
/*     */         case '\b':
/* 553 */           product.append("\\b");
/*     */           break;
/*     */         case '\f':
/* 556 */           product.append("\\f");
/*     */           break;
/*     */         case '\n':
/* 559 */           product.append("\\n");
/*     */           break;
/*     */         case '\r':
/* 562 */           product.append("\\r");
/*     */           break;
/*     */         case '\t':
/* 565 */           product.append("\\t");
/*     */           break;
/*     */         default:
/* 568 */           if (c < ' ') {
/* 569 */             product.append("\\u");
/* 570 */             String hex = String.format("%04x", new Object[] { Integer.valueOf(c) });
/* 571 */             product.append(hex); break;
/*     */           } 
/* 573 */           product.append(c);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 578 */     product.append('"');
/* 579 */     return product.toString();
/*     */   }
/*     */   
/*     */   private static Object javaToJSON(Object value, StringifyState state) {
/* 583 */     value = state.cx.getJavaToJSONConverter().apply(value);
/* 584 */     value = Context.javaToJS(value, state.scope, state.cx);
/*     */     
/* 586 */     ScriptableObject wrapper = new NativeObject();
/* 587 */     wrapper.setParentScope(state.scope);
/* 588 */     wrapper.setPrototype(ScriptableObject.getObjectPrototype(state.scope));
/* 589 */     wrapper.defineProperty("", value, 0);
/* 590 */     return str("", wrapper, state);
/*     */   }
/*     */   
/*     */   private static boolean isObjectArrayLike(Object o) {
/* 594 */     if (o instanceof NativeArray) {
/* 595 */       return true;
/*     */     }
/* 597 */     if (o instanceof NativeJavaObject) {
/* 598 */       Object unwrapped = ((NativeJavaObject)o).unwrap();
/* 599 */       return (unwrapped instanceof Collection || unwrapped.getClass().isArray());
/*     */     } 
/* 601 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 607 */     switch (s)
/*     */     { case "toSource":
/* 609 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 621 */         return id;case "parse": id = 2; return id;case "stringify": id = 3; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeJSON.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */