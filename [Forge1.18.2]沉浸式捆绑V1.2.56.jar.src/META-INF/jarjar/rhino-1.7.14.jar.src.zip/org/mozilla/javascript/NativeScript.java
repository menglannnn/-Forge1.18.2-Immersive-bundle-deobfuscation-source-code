/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NativeScript
/*     */   extends BaseFunction
/*     */ {
/*     */   private static final long serialVersionUID = -6795101161980121700L;
/*  24 */   private static final Object SCRIPT_TAG = "Script"; private static final int Id_constructor = 1; private static final int Id_toString = 2; private static final int Id_compile = 3;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  27 */     NativeScript obj = new NativeScript(null);
/*  28 */     obj.exportAsJSClass(4, scope, sealed);
/*     */   }
/*     */   private static final int Id_exec = 4; private static final int MAX_PROTOTYPE_ID = 4; private Script script;
/*     */   private NativeScript(Script script) {
/*  32 */     this.script = script;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  38 */     return "Script";
/*     */   }
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  43 */     if (this.script != null) {
/*  44 */       return this.script.exec(cx, scope);
/*     */     }
/*  46 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/*  51 */     throw Context.reportRuntimeErrorById("msg.script.is.not.constructor", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  56 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArity() {
/*  61 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   String decompile(int indent, int flags) {
/*  66 */     if (this.script instanceof NativeFunction) {
/*  67 */       return ((NativeFunction)this.script).decompile(indent, flags);
/*     */     }
/*  69 */     return super.decompile(indent, flags);
/*     */   }
/*     */   
/*     */   protected void initPrototypeId(int id)
/*     */   {
/*     */     String s;
/*     */     int arity;
/*  76 */     switch (id) {
/*     */       case 1:
/*  78 */         arity = 1;
/*  79 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/*  82 */         arity = 0;
/*  83 */         s = "toString";
/*     */         break;
/*     */       case 4:
/*  86 */         arity = 0;
/*  87 */         s = "exec";
/*     */         break;
/*     */       case 3:
/*  90 */         arity = 1;
/*  91 */         s = "compile";
/*     */         break;
/*     */       default:
/*  94 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/*  96 */     initPrototypeMethod(SCRIPT_TAG, id, s, arity); } public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     String source;
/*     */     NativeScript real;
/*     */     Script script, realScript;
/*     */     String str1;
/*     */     NativeScript nscript;
/* 102 */     if (!f.hasTag(SCRIPT_TAG)) {
/* 103 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 105 */     int id = f.methodId();
/* 106 */     switch (id) {
/*     */       
/*     */       case 1:
/* 109 */         source = (args.length == 0) ? "" : ScriptRuntime.toString(args[0]);
/* 110 */         script = compile(cx, source);
/* 111 */         nscript = new NativeScript(script);
/* 112 */         ScriptRuntime.setObjectProtoAndParent(nscript, scope);
/* 113 */         return nscript;
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 118 */         real = realThis(thisObj, f);
/* 119 */         realScript = real.script;
/* 120 */         if (realScript == null) {
/* 121 */           return "";
/*     */         }
/* 123 */         return cx.decompileScript(realScript, 0);
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 128 */         throw Context.reportRuntimeErrorById("msg.cant.call.indirect", new Object[] { "exec" });
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 133 */         real = realThis(thisObj, f);
/* 134 */         str1 = ScriptRuntime.toString(args, 0);
/* 135 */         real.script = compile(cx, str1);
/* 136 */         return real;
/*     */     } 
/*     */     
/* 139 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */   
/*     */   private static NativeScript realThis(Scriptable thisObj, IdFunctionObject f) {
/* 143 */     return ensureType(thisObj, NativeScript.class, f);
/*     */   }
/*     */   
/*     */   private static Script compile(Context cx, String source) {
/* 147 */     int[] linep = { 0 };
/* 148 */     String filename = Context.getSourcePositionFromStack(linep);
/* 149 */     if (filename == null) {
/* 150 */       filename = "<Script object>";
/* 151 */       linep[0] = 1;
/*     */     } 
/*     */     
/* 154 */     ErrorReporter reporter = DefaultErrorReporter.forEval(cx.getErrorReporter());
/* 155 */     return cx.compileString(source, null, reporter, filename, linep[0], null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 161 */     switch (s)
/*     */     { case "constructor":
/* 163 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 178 */         return id;case "toString": id = 2; return id;case "compile": id = 3; return id;case "exec": id = 4; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeScript.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */