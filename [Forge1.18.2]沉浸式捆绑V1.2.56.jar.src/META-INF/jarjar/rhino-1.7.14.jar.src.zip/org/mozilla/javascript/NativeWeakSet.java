/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeWeakSet
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 2065753364224029534L;
/*  22 */   private static final Object MAP_TAG = "WeakSet";
/*     */   
/*     */   private boolean instanceOfWeakSet = false;
/*     */   
/*  26 */   private transient WeakHashMap<Scriptable, Boolean> map = new WeakHashMap<>(); private static final int Id_constructor = 1; private static final int Id_add = 2; private static final int Id_delete = 3;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  29 */     NativeWeakSet m = new NativeWeakSet();
/*  30 */     m.exportAsJSClass(5, scope, sealed);
/*     */   }
/*     */   private static final int Id_has = 4; private static final int SymbolId_toStringTag = 5; private static final int MAX_PROTOTYPE_ID = 5;
/*     */   
/*     */   public String getClassName() {
/*  35 */     return "WeakSet";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  42 */     if (!f.hasTag(MAP_TAG)) {
/*  43 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  45 */     int id = f.methodId();
/*  46 */     switch (id) {
/*     */       case 1:
/*  48 */         if (thisObj == null) {
/*  49 */           NativeWeakSet ns = new NativeWeakSet();
/*  50 */           ns.instanceOfWeakSet = true;
/*  51 */           if (args.length > 0) {
/*  52 */             NativeSet.loadFromIterable(cx, scope, ns, NativeMap.key(args));
/*     */           }
/*  54 */           return ns;
/*     */         } 
/*  56 */         throw ScriptRuntime.typeErrorById("msg.no.new", new Object[] { "WeakSet" });
/*     */       case 2:
/*  58 */         return realThis(thisObj, f).js_add(NativeMap.key(args));
/*     */       case 3:
/*  60 */         return realThis(thisObj, f).js_delete(NativeMap.key(args));
/*     */       case 4:
/*  62 */         return realThis(thisObj, f).js_has(NativeMap.key(args));
/*     */     } 
/*  64 */     throw new IllegalArgumentException("WeakMap.prototype has no method: " + f
/*  65 */         .getFunctionName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object js_add(Object key) {
/*  73 */     if (!ScriptRuntime.isObject(key)) {
/*  74 */       throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] { ScriptRuntime.typeof(key) });
/*     */     }
/*     */ 
/*     */     
/*  78 */     this.map.put((Scriptable)key, Boolean.TRUE);
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   private Object js_delete(Object key) {
/*  83 */     if (!ScriptRuntime.isObject(key)) {
/*  84 */       return Boolean.FALSE;
/*     */     }
/*  86 */     return Boolean.valueOf((this.map.remove(key) != null));
/*     */   }
/*     */   
/*     */   private Object js_has(Object key) {
/*  90 */     if (!ScriptRuntime.isObject(key)) {
/*  91 */       return Boolean.FALSE;
/*     */     }
/*  93 */     return Boolean.valueOf(this.map.containsKey(key));
/*     */   }
/*     */   
/*     */   private static NativeWeakSet realThis(Scriptable thisObj, IdFunctionObject f) {
/*  97 */     NativeWeakSet ns = ensureType(thisObj, NativeWeakSet.class, f);
/*  98 */     if (!ns.instanceOfWeakSet)
/*     */     {
/* 100 */       throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { f.getFunctionName() });
/*     */     }
/*     */     
/* 103 */     return ns;
/*     */   }
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 108 */     if (id == 5) {
/* 109 */       initPrototypeValue(5, SymbolKey.TO_STRING_TAG, 
/*     */ 
/*     */           
/* 112 */           getClassName(), 3);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 117 */     String fnName = null;
/*     */     
/* 119 */     switch (id) {
/*     */       case 1:
/* 121 */         arity = 0;
/* 122 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 125 */         arity = 1;
/* 126 */         s = "add";
/*     */         break;
/*     */       case 3:
/* 129 */         arity = 1;
/* 130 */         s = "delete";
/*     */         break;
/*     */       case 4:
/* 133 */         arity = 1;
/* 134 */         s = "has";
/*     */         break;
/*     */       default:
/* 137 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 139 */     initPrototypeMethod(MAP_TAG, id, s, fnName, arity);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(Symbol k) {
/* 144 */     if (SymbolKey.TO_STRING_TAG.equals(k)) {
/* 145 */       return 5;
/*     */     }
/* 147 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 153 */     switch (s)
/*     */     { case "constructor":
/* 155 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 170 */         return id;case "add": id = 2; return id;case "delete": id = 3; return id;case "has": id = 4; return id; }  int id = 0; return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 181 */     stream.defaultReadObject();
/* 182 */     this.map = new WeakHashMap<>();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeWeakSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */