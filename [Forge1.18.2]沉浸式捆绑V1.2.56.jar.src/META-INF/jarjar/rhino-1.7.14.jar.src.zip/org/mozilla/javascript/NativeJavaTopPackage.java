/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaTopPackage
/*     */   extends NativeJavaPackage
/*     */   implements Function, IdFunctionCall
/*     */ {
/*     */   private static final long serialVersionUID = -1455787259477709999L;
/*  29 */   private static final String[][] commonPackages = new String[][] { { "java", "lang", "reflect" }, { "java", "io" }, { "java", "math" }, { "java", "net" }, { "java", "util", "zip" }, { "java", "text", "resources" }, { "java", "applet" }, { "javax", "swing" } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NativeJavaTopPackage(ClassLoader loader) {
/*  42 */     super(true, "", loader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  49 */     return construct(cx, scope, args);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/*  55 */     ClassLoader loader = null;
/*  56 */     if (args.length != 0) {
/*  57 */       Object arg = args[0];
/*  58 */       if (arg instanceof Wrapper) {
/*  59 */         arg = ((Wrapper)arg).unwrap();
/*     */       }
/*  61 */       if (arg instanceof ClassLoader) {
/*  62 */         loader = (ClassLoader)arg;
/*     */       }
/*     */     } 
/*  65 */     if (loader == null) {
/*  66 */       Context.reportRuntimeErrorById("msg.not.classloader", new Object[0]);
/*  67 */       return null;
/*     */     } 
/*  69 */     NativeJavaPackage pkg = new NativeJavaPackage(true, "", loader);
/*  70 */     ScriptRuntime.setObjectProtoAndParent(pkg, scope);
/*  71 */     return pkg;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  76 */     ClassLoader loader = cx.getApplicationClassLoader();
/*  77 */     NativeJavaTopPackage top = new NativeJavaTopPackage(loader);
/*  78 */     top.setPrototype(getObjectPrototype(scope));
/*  79 */     top.setParentScope(scope);
/*     */     
/*  81 */     for (int i = 0; i != commonPackages.length; i++) {
/*  82 */       NativeJavaPackage parent = top;
/*  83 */       for (int m = 0; m != (commonPackages[i]).length; m++) {
/*  84 */         parent = parent.forcePackage(commonPackages[i][m], scope);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  89 */     IdFunctionObject getClass = new IdFunctionObject(top, FTAG, 1, "getClass", 1, scope);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     String[] topNames = ScriptRuntime.getTopPackageNames();
/*  96 */     NativeJavaPackage[] topPackages = new NativeJavaPackage[topNames.length];
/*  97 */     for (int j = 0; j < topNames.length; j++) {
/*  98 */       topPackages[j] = (NativeJavaPackage)top.get(topNames[j], top);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 103 */     ScriptableObject global = (ScriptableObject)scope;
/*     */     
/* 105 */     if (sealed) {
/* 106 */       getClass.sealObject();
/*     */     }
/* 108 */     getClass.exportAsScopeProperty();
/* 109 */     global.defineProperty("Packages", top, 2);
/* 110 */     for (int k = 0; k < topNames.length; k++) {
/* 111 */       global.defineProperty(topNames[k], topPackages[k], 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 120 */     if (f.hasTag(FTAG) && 
/* 121 */       f.methodId() == 1) {
/* 122 */       return js_getClass(cx, scope, args);
/*     */     }
/*     */     
/* 125 */     throw f.unknown();
/*     */   }
/*     */ 
/*     */   
/*     */   private Scriptable js_getClass(Context cx, Scriptable scope, Object[] args) {
/* 130 */     if (args.length > 0 && args[0] instanceof Wrapper) {
/* 131 */       Scriptable result = this;
/* 132 */       Class<?> cl = ((Wrapper)args[0]).unwrap().getClass();
/*     */ 
/*     */       
/* 135 */       String name = cl.getName();
/* 136 */       int offset = 0;
/*     */       while (true) {
/* 138 */         int index = name.indexOf('.', offset);
/*     */ 
/*     */         
/* 141 */         String propName = (index == -1) ? name.substring(offset) : name.substring(offset, index);
/* 142 */         Object prop = result.get(propName, result);
/* 143 */         if (!(prop instanceof Scriptable))
/*     */           break; 
/* 145 */         result = (Scriptable)prop;
/* 146 */         if (index == -1)
/* 147 */           return result; 
/* 148 */         offset = index + 1;
/*     */       } 
/*     */     } 
/* 151 */     throw Context.reportRuntimeErrorById("msg.not.java.obj", new Object[0]);
/*     */   }
/*     */   
/* 154 */   private static final Object FTAG = "JavaTopPackage";
/*     */   private static final int Id_getClass = 1;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeJavaTopPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */