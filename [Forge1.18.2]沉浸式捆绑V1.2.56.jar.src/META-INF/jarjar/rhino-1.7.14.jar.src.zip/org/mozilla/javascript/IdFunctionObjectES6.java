/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ public class IdFunctionObjectES6 extends IdFunctionObject {
/*    */   private static final long serialVersionUID = -8023088662589035261L;
/*    */   private static final int Id_length = 1;
/*    */   
/*    */   public IdFunctionObjectES6(IdFunctionCall idcall, Object tag, int id, String name, int arity, Scriptable scope) {
/*  8 */     super(idcall, tag, id, name, arity, scope);
/*    */ 
/*    */ 
/*    */     
/* 12 */     this.myLength = true;
/* 13 */     this.myName = true;
/*    */   }
/*    */   private static final int Id_name = 3; private boolean myLength; private boolean myName;
/*    */   protected int findInstanceIdInfo(String s) {
/* 17 */     if (s.equals("length")) return instanceIdInfo(3, 1); 
/* 18 */     if (s.equals("name")) return instanceIdInfo(3, 3); 
/* 19 */     return super.findInstanceIdInfo(s);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getInstanceIdValue(int id) {
/* 24 */     if (id == 1 && !this.myLength)
/* 25 */       return NOT_FOUND; 
/* 26 */     if (id == 3 && !this.myName) {
/* 27 */       return NOT_FOUND;
/*    */     }
/* 29 */     return super.getInstanceIdValue(id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setInstanceIdValue(int id, Object value) {
/* 34 */     if (id == 1 && value == NOT_FOUND) {
/* 35 */       this.myLength = false; return;
/*    */     } 
/* 37 */     if (id == 3 && value == NOT_FOUND) {
/* 38 */       this.myName = false;
/*    */       return;
/*    */     } 
/* 41 */     super.setInstanceIdValue(id, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\IdFunctionObjectES6.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */