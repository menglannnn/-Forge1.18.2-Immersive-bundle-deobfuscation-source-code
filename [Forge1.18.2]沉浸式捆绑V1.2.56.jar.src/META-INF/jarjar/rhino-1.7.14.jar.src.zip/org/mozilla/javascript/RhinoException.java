/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RhinoException
/*     */   extends RuntimeException
/*     */ {
/*  20 */   private static final Pattern JAVA_STACK_PATTERN = Pattern.compile("_c_(.*)_\\d+");
/*     */   
/*     */   RhinoException() {
/*  23 */     Evaluator e = Context.createInterpreter();
/*  24 */     if (e != null) e.captureStackInfo(this); 
/*     */   }
/*     */   private static final long serialVersionUID = 1883500631321581169L;
/*     */   RhinoException(String details) {
/*  28 */     super(details);
/*  29 */     Evaluator e = Context.createInterpreter();
/*  30 */     if (e != null) e.captureStackInfo(this);
/*     */   
/*     */   }
/*     */   
/*     */   public final String getMessage() {
/*  35 */     String details = details();
/*  36 */     if (this.sourceName == null || this.lineNumber <= 0) {
/*  37 */       return details;
/*     */     }
/*  39 */     StringBuilder buf = new StringBuilder(details);
/*  40 */     buf.append(" (");
/*  41 */     buf.append(this.sourceName);
/*  42 */     if (this.lineNumber > 0) {
/*  43 */       buf.append('#');
/*  44 */       buf.append(this.lineNumber);
/*     */     } 
/*  46 */     buf.append(')');
/*  47 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String details() {
/*  51 */     return super.getMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String sourceName() {
/*  59 */     return this.sourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void initSourceName(String sourceName) {
/*  70 */     if (sourceName == null) throw new IllegalArgumentException(); 
/*  71 */     if (this.sourceName != null) throw new IllegalStateException(); 
/*  72 */     this.sourceName = sourceName;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int lineNumber() {
/*  77 */     return this.lineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void initLineNumber(int lineNumber) {
/*  87 */     if (lineNumber <= 0) throw new IllegalArgumentException(String.valueOf(lineNumber)); 
/*  88 */     if (this.lineNumber > 0) throw new IllegalStateException(); 
/*  89 */     this.lineNumber = lineNumber;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int columnNumber() {
/*  94 */     return this.columnNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void initColumnNumber(int columnNumber) {
/* 104 */     if (columnNumber <= 0) throw new IllegalArgumentException(String.valueOf(columnNumber)); 
/* 105 */     if (this.columnNumber > 0) throw new IllegalStateException(); 
/* 106 */     this.columnNumber = columnNumber;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String lineSource() {
/* 111 */     return this.lineSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void initLineSource(String lineSource) {
/* 122 */     if (lineSource == null) throw new IllegalArgumentException(); 
/* 123 */     if (this.lineSource != null) throw new IllegalStateException(); 
/* 124 */     this.lineSource = lineSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final void recordErrorOrigin(String sourceName, int lineNumber, String lineSource, int columnNumber) {
/* 130 */     if (lineNumber == -1) {
/* 131 */       lineNumber = 0;
/*     */     }
/*     */     
/* 134 */     if (sourceName != null) {
/* 135 */       initSourceName(sourceName);
/*     */     }
/* 137 */     if (lineNumber != 0) {
/* 138 */       initLineNumber(lineNumber);
/*     */     }
/* 140 */     if (lineSource != null) {
/* 141 */       initLineSource(lineSource);
/*     */     }
/* 143 */     if (columnNumber != 0) {
/* 144 */       initColumnNumber(columnNumber);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private String generateStackTrace() {
/* 150 */     CharArrayWriter writer = new CharArrayWriter();
/* 151 */     super.printStackTrace(new PrintWriter(writer));
/* 152 */     String origStackTrace = writer.toString();
/* 153 */     Evaluator e = Context.createInterpreter();
/* 154 */     if (e != null) return e.getPatchedStack(this, origStackTrace); 
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getScriptStackTrace() {
/* 167 */     return getScriptStackTrace(-1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getScriptStackTrace(int limit, String functionName) {
/* 183 */     ScriptStackElement[] stack = getScriptStack(limit, functionName);
/* 184 */     return formatStackTrace(stack, details());
/*     */   }
/*     */   
/*     */   static String formatStackTrace(ScriptStackElement[] stack, String message) {
/* 188 */     StringBuilder buffer = new StringBuilder();
/* 189 */     String lineSeparator = SecurityUtilities.getSystemProperty("line.separator");
/*     */     
/* 191 */     if (stackStyle == StackStyle.V8 && !"null".equals(message)) {
/*     */       
/* 193 */       buffer.append(message);
/* 194 */       buffer.append(lineSeparator);
/*     */     } 
/*     */     
/* 197 */     for (ScriptStackElement elem : stack) {
/* 198 */       switch (stackStyle) {
/*     */         case MOZILLA:
/* 200 */           elem.renderMozillaStyle(buffer);
/* 201 */           buffer.append(lineSeparator);
/*     */           break;
/*     */         case MOZILLA_LF:
/* 204 */           elem.renderMozillaStyle(buffer);
/* 205 */           buffer.append('\n');
/*     */           break;
/*     */         case V8:
/* 208 */           elem.renderV8Style(buffer);
/* 209 */           buffer.append(lineSeparator);
/*     */           break;
/*     */         case RHINO:
/* 212 */           elem.renderJavaStyle(buffer);
/* 213 */           buffer.append(lineSeparator);
/*     */           break;
/*     */       } 
/*     */     } 
/* 217 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getScriptStackTrace(FilenameFilter filter) {
/* 231 */     return getScriptStackTrace();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScriptStackElement[] getScriptStack() {
/* 243 */     return getScriptStack(-1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScriptStackElement[] getScriptStack(int limit, String hideFunction) {
/* 258 */     List<ScriptStackElement> list = new ArrayList<>();
/* 259 */     ScriptStackElement[][] interpreterStack = (ScriptStackElement[][])null;
/* 260 */     if (this.interpreterStackInfo != null) {
/* 261 */       Evaluator interpreter = Context.createInterpreter();
/* 262 */       if (interpreter instanceof Interpreter) {
/* 263 */         interpreterStack = ((Interpreter)interpreter).getScriptStackElements(this);
/*     */       }
/*     */     } 
/* 266 */     int interpreterStackIndex = 0;
/* 267 */     StackTraceElement[] stack = getStackTrace();
/* 268 */     int count = 0;
/* 269 */     boolean printStarted = (hideFunction == null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     for (StackTraceElement e : stack) {
/* 275 */       String fileName = e.getFileName();
/* 276 */       if (e.getMethodName().startsWith("_c_") && e
/* 277 */         .getLineNumber() > -1 && (fileName == null || 
/* 278 */         !fileName.endsWith(".java"))) {
/* 279 */         String methodName = e.getMethodName();
/* 280 */         Matcher match = JAVA_STACK_PATTERN.matcher(methodName);
/*     */ 
/*     */ 
/*     */         
/* 284 */         methodName = (!"_c_script_0".equals(methodName) && match.find()) ? match.group(1) : null;
/*     */         
/* 286 */         if (!printStarted && hideFunction.equals(methodName)) {
/* 287 */           printStarted = true;
/* 288 */         } else if (printStarted && (limit < 0 || count < limit)) {
/* 289 */           String fn = (fileName == null) ? "(unknown)" : fileName;
/* 290 */           list.add(new ScriptStackElement(fn, methodName, e.getLineNumber()));
/* 291 */           count++;
/*     */         }
/*     */       
/* 294 */       } else if ("org.mozilla.javascript.Interpreter".equals(e.getClassName()) && "interpretLoop"
/* 295 */         .equals(e.getMethodName()) && interpreterStack != null && interpreterStack.length > interpreterStackIndex) {
/*     */ 
/*     */ 
/*     */         
/* 299 */         for (ScriptStackElement elem : interpreterStack[interpreterStackIndex++]) {
/* 300 */           if (!printStarted && hideFunction.equals(elem.functionName)) {
/* 301 */             printStarted = true;
/* 302 */           } else if (printStarted && (limit < 0 || count < limit)) {
/* 303 */             list.add(elem);
/* 304 */             count++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 309 */     return list.<ScriptStackElement>toArray(new ScriptStackElement[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter s) {
/* 314 */     if (this.interpreterStackInfo == null) {
/* 315 */       super.printStackTrace(s);
/*     */     } else {
/* 317 */       s.print(generateStackTrace());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream s) {
/* 323 */     if (this.interpreterStackInfo == null) {
/* 324 */       super.printStackTrace(s);
/*     */     } else {
/* 326 */       s.print(generateStackTrace());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean usesMozillaStackStyle() {
/* 340 */     return (stackStyle == StackStyle.MOZILLA);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useMozillaStackStyle(boolean flag) {
/* 354 */     stackStyle = flag ? StackStyle.MOZILLA : StackStyle.RHINO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setStackStyle(StackStyle style) {
/* 366 */     stackStyle = style;
/*     */   }
/*     */ 
/*     */   
/*     */   public static StackStyle getStackStyle() {
/* 371 */     return stackStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 377 */   private static StackStyle stackStyle = StackStyle.RHINO;
/*     */   
/*     */   private String sourceName;
/*     */   
/*     */   private int lineNumber;
/*     */   
/*     */   private String lineSource;
/*     */   private int columnNumber;
/*     */   Object interpreterStackInfo;
/*     */   int[] interpreterLineData;
/*     */   
/*     */   static {
/* 389 */     String style = System.getProperty("rhino.stack.style");
/* 390 */     if (style != null)
/* 391 */       if ("Rhino".equalsIgnoreCase(style)) {
/* 392 */         stackStyle = StackStyle.RHINO;
/* 393 */       } else if ("Mozilla".equalsIgnoreCase(style)) {
/* 394 */         stackStyle = StackStyle.MOZILLA;
/* 395 */       } else if ("V8".equalsIgnoreCase(style)) {
/* 396 */         stackStyle = StackStyle.V8;
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\RhinoException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */