/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hashtable
/*     */   implements Serializable, Iterable<Hashtable.Entry>
/*     */ {
/*     */   private static final long serialVersionUID = -7151554912419543747L;
/*  30 */   private final HashMap<Object, Entry> map = new HashMap<>();
/*  31 */   private Entry first = null;
/*  32 */   private Entry last = null;
/*     */ 
/*     */   
/*     */   public static final class Entry
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 4086572107122965503L;
/*     */     
/*     */     protected Object key;
/*     */     protected Object value;
/*     */     protected boolean deleted;
/*     */     protected Entry next;
/*     */     protected Entry prev;
/*     */     private final int hashCode;
/*     */     
/*     */     Entry() {
/*  48 */       this.hashCode = 0;
/*     */     }
/*     */     
/*     */     Entry(Object k, Object value) {
/*  52 */       if (k instanceof Number) {
/*  53 */         if (k instanceof Double || k instanceof java.math.BigInteger) {
/*     */ 
/*     */ 
/*     */           
/*  57 */           this.key = k;
/*     */         } else {
/*     */           
/*  60 */           this.key = Double.valueOf(((Number)k).doubleValue());
/*     */         } 
/*  62 */       } else if (k instanceof ConsString) {
/*  63 */         this.key = k.toString();
/*     */       } else {
/*  65 */         this.key = k;
/*     */       } 
/*     */       
/*  68 */       if (this.key == null) {
/*  69 */         this.hashCode = 0;
/*  70 */       } else if (k.equals(ScriptRuntime.negativeZeroObj)) {
/*  71 */         this.hashCode = 0;
/*     */       } else {
/*  73 */         this.hashCode = this.key.hashCode();
/*     */       } 
/*     */       
/*  76 */       this.value = value;
/*     */     }
/*     */     
/*     */     public Object key() {
/*  80 */       return this.key;
/*     */     }
/*     */     
/*     */     public Object value() {
/*  84 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     void clear() {
/*  89 */       this.key = Undefined.instance;
/*  90 */       this.value = Undefined.instance;
/*  91 */       this.deleted = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  96 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 101 */       if (o == null) {
/* 102 */         return false;
/*     */       }
/*     */       try {
/* 105 */         return ScriptRuntime.sameZero(this.key, ((Entry)o).key);
/* 106 */       } catch (ClassCastException cce) {
/* 107 */         return false;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static Entry makeDummy() {
/* 113 */     Entry d = new Entry();
/* 114 */     d.clear();
/* 115 */     return d;
/*     */   }
/*     */   
/*     */   public int size() {
/* 119 */     return this.map.size();
/*     */   }
/*     */   
/*     */   public void put(Object key, Object value) {
/* 123 */     Entry nv = new Entry(key, value);
/* 124 */     Entry ev = this.map.putIfAbsent(nv, nv);
/* 125 */     if (ev == null) {
/*     */       
/* 127 */       if (this.first == null) {
/* 128 */         this.first = this.last = nv;
/*     */       } else {
/* 130 */         this.last.next = nv;
/* 131 */         nv.prev = this.last;
/* 132 */         this.last = nv;
/*     */       } 
/*     */     } else {
/*     */       
/* 136 */       ev.value = value;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 145 */     Entry e = new Entry(key, null);
/* 146 */     Entry v = this.map.get(e);
/* 147 */     if (v == null) {
/* 148 */       return null;
/*     */     }
/* 150 */     return v.value;
/*     */   }
/*     */   
/*     */   public Entry getEntry(Object key) {
/* 154 */     Entry e = new Entry(key, null);
/* 155 */     return this.map.get(e);
/*     */   }
/*     */   
/*     */   public boolean has(Object key) {
/* 159 */     Entry e = new Entry(key, null);
/* 160 */     return this.map.containsKey(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object delete(Object key) {
/* 168 */     Entry e = new Entry(key, null);
/* 169 */     Entry v = this.map.remove(e);
/* 170 */     if (v == null) {
/* 171 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     if (v == this.first) {
/* 183 */       if (v == this.last) {
/*     */ 
/*     */         
/* 186 */         v.clear();
/* 187 */         v.prev = null;
/*     */       } else {
/* 189 */         this.first = v.next;
/* 190 */         this.first.prev = null;
/* 191 */         if (this.first.next != null) {
/* 192 */           this.first.next.prev = this.first;
/*     */         }
/*     */       } 
/*     */     } else {
/* 196 */       Entry prev = v.prev;
/* 197 */       prev.next = v.next;
/* 198 */       v.prev = null;
/* 199 */       if (v.next != null) {
/* 200 */         v.next.prev = prev;
/*     */       } else {
/* 202 */         assert v == this.last;
/* 203 */         this.last = prev;
/*     */       } 
/*     */     } 
/*     */     
/* 207 */     Object ret = v.value;
/* 208 */     v.clear();
/* 209 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean deleteEntry(Object key) {
/* 213 */     Entry e = new Entry(key, null);
/* 214 */     Entry v = this.map.remove(e);
/* 215 */     if (v == null) {
/* 216 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     if (v == this.first) {
/* 228 */       if (v == this.last) {
/*     */ 
/*     */         
/* 231 */         v.clear();
/* 232 */         v.prev = null;
/*     */       } else {
/* 234 */         this.first = v.next;
/* 235 */         this.first.prev = null;
/* 236 */         if (this.first.next != null) {
/* 237 */           this.first.next.prev = this.first;
/*     */         }
/*     */       } 
/*     */     } else {
/* 241 */       Entry prev = v.prev;
/* 242 */       prev.next = v.next;
/* 243 */       v.prev = null;
/* 244 */       if (v.next != null) {
/* 245 */         v.next.prev = prev;
/*     */       } else {
/* 247 */         assert v == this.last;
/* 248 */         this.last = prev;
/*     */       } 
/*     */     } 
/*     */     
/* 252 */     v.clear();
/* 253 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 258 */     Iterator<Entry> it = iterator();
/* 259 */     it.forEachRemaining(Entry::clear);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     if (this.first != null) {
/* 266 */       Entry dummy = makeDummy();
/* 267 */       this.last.next = dummy;
/* 268 */       this.first = this.last = dummy;
/*     */     } 
/*     */ 
/*     */     
/* 272 */     this.map.clear();
/*     */   }
/*     */   
/*     */   public Iterator<Entry> iterator() {
/* 276 */     return new Iter(this.first);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Iter
/*     */     implements Iterator<Entry>
/*     */   {
/*     */     private Hashtable.Entry pos;
/*     */     
/*     */     Iter(Hashtable.Entry start) {
/* 286 */       Hashtable.Entry dummy = Hashtable.makeDummy();
/* 287 */       dummy.next = start;
/* 288 */       this.pos = dummy;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void skipDeleted() {
/* 295 */       while (this.pos.next != null && this.pos.next.deleted) {
/* 296 */         this.pos = this.pos.next;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 302 */       skipDeleted();
/* 303 */       return (this.pos != null && this.pos.next != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Hashtable.Entry next() {
/* 308 */       skipDeleted();
/* 309 */       if (this.pos == null || this.pos.next == null) {
/* 310 */         throw new NoSuchElementException();
/*     */       }
/* 312 */       Hashtable.Entry e = this.pos.next;
/* 313 */       this.pos = this.pos.next;
/* 314 */       return e;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Hashtable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */