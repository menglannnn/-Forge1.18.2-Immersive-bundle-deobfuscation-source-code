/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.beans.BeanDescriptor;
/*    */ import java.beans.BeanInfo;
/*    */ import java.beans.IntrospectionException;
/*    */ import java.beans.Introspector;
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.function.UnaryOperator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaToJSONConverters
/*    */ {
/*    */   public static final UnaryOperator<Object> STRING;
/*    */   
/*    */   static {
/* 37 */     STRING = (o -> o.toString());
/*    */   }
/*    */   
/*    */   public static final UnaryOperator<Object> UNDEFINED = o -> Undefined.instance;
/*    */   public static final UnaryOperator<Object> EMPTY_OBJECT = o -> Collections.EMPTY_MAP;
/*    */   public static final UnaryOperator<Object> THROW_TYPE_ERROR;
/*    */   public static final UnaryOperator<Object> BEAN;
/*    */   
/*    */   static {
/* 46 */     THROW_TYPE_ERROR = (o -> {
/*    */         throw ScriptRuntime.typeErrorById("msg.json.cant.serialize", new Object[] { o.getClass().getName() });
/*    */       });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     BEAN = (value -> {
/*    */         BeanInfo beanInfo;
/*    */         
/*    */         try {
/*    */           beanInfo = Introspector.getBeanInfo(value.getClass(), Object.class);
/* 63 */         } catch (IntrospectionException e) {
/*    */           return null;
/*    */         } 
/*    */         LinkedHashMap<String, Object> properties = new LinkedHashMap<>();
/*    */         for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
/*    */           if (descriptor.getReadMethod() != null) {
/*    */             Object propValue;
/*    */             try {
/*    */               propValue = descriptor.getReadMethod().invoke(value, new Object[0]);
/* 72 */             } catch (Exception e) {}
/*    */             properties.put(descriptor.getName(), propValue);
/*    */           } 
/*    */         } 
/*    */         if (properties.size() == 0)
/*    */           return null; 
/*    */         LinkedHashMap<String, Object> obj = new LinkedHashMap<>();
/*    */         BeanDescriptor beanDescriptor = beanInfo.getBeanDescriptor();
/*    */         obj.put("beanClass", beanDescriptor.getBeanClass().getName());
/*    */         obj.put("properties", properties);
/*    */         return obj;
/*    */       });
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\JavaToJSONConverters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */