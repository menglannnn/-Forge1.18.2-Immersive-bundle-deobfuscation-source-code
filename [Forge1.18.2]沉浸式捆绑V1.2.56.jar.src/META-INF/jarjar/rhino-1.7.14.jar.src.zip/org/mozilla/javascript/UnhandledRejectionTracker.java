/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.IdentityHashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnhandledRejectionTracker
/*    */ {
/*    */   private boolean enabled = false;
/* 27 */   private static final IdentityHashMap<NativePromise, NativePromise> unhandled = new IdentityHashMap<>(0);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(Consumer<Object> handler) {
/* 36 */     Iterator<NativePromise> it = unhandled.values().iterator();
/* 37 */     while (it.hasNext()) {
/*    */       try {
/* 39 */         handler.accept(((NativePromise)it.next()).getResult());
/*    */       } finally {
/*    */         
/* 42 */         it.remove();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Object> enumerate() {
/* 55 */     ArrayList<Object> ret = new ArrayList();
/* 56 */     for (NativePromise result : unhandled.values()) {
/* 57 */       ret.add(result.getResult());
/*    */     }
/* 59 */     return ret;
/*    */   }
/*    */   
/*    */   void enable(boolean enabled) {
/* 63 */     this.enabled = enabled;
/*    */   }
/*    */   
/*    */   void promiseRejected(NativePromise p) {
/* 67 */     if (this.enabled) {
/* 68 */       unhandled.put(p, p);
/*    */     }
/*    */   }
/*    */   
/*    */   void promiseHandled(NativePromise p) {
/* 73 */     if (this.enabled)
/* 74 */       unhandled.remove(p); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\UnhandledRejectionTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */