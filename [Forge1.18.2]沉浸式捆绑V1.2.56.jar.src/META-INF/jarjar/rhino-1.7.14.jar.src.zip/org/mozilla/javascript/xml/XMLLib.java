/*     */ package org.mozilla.javascript.xml;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Ref;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XMLLib
/*     */ {
/*  17 */   private static final Object XML_LIB_KEY = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Factory
/*     */   {
/*     */     public static Factory create(final String className) {
/*  31 */       return new Factory()
/*     */         {
/*     */           public String getImplementationClassName() {
/*  34 */             return className;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public abstract String getImplementationClassName();
/*     */   }
/*     */   
/*     */   public static XMLLib extractFromScopeOrNull(Scriptable scope) {
/*  44 */     ScriptableObject so = ScriptRuntime.getLibraryScopeOrNull(scope);
/*  45 */     if (so == null)
/*     */     {
/*  47 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  52 */     ScriptableObject.getProperty((Scriptable)so, "XML");
/*     */     
/*  54 */     return (XMLLib)so.getAssociatedValue(XML_LIB_KEY);
/*     */   }
/*     */ 
/*     */   
/*     */   public static XMLLib extractFromScope(Scriptable scope) {
/*  59 */     XMLLib lib = extractFromScopeOrNull(scope);
/*  60 */     if (lib != null) {
/*  61 */       return lib;
/*     */     }
/*  63 */     String msg = ScriptRuntime.getMessageById("msg.XML.not.available", new Object[0]);
/*  64 */     throw Context.reportRuntimeError(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final XMLLib bindToScope(Scriptable scope) {
/*  69 */     ScriptableObject so = ScriptRuntime.getLibraryScopeOrNull(scope);
/*  70 */     if (so == null)
/*     */     {
/*  72 */       throw new IllegalStateException();
/*     */     }
/*  74 */     return (XMLLib)so.associateValue(XML_LIB_KEY, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isXMLName(Context paramContext, Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Ref nameRef(Context paramContext, Object paramObject, Scriptable paramScriptable, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Ref nameRef(Context paramContext, Object paramObject1, Object paramObject2, Scriptable paramScriptable, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String escapeAttributeValue(Object paramObject);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String escapeTextValue(Object paramObject);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object toDefaultXmlNamespace(Context paramContext, Object paramObject);
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreComments(boolean b) {
/* 108 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setIgnoreWhitespace(boolean b) {
/* 112 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setIgnoreProcessingInstructions(boolean b) {
/* 116 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setPrettyPrinting(boolean b) {
/* 120 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setPrettyIndent(int i) {
/* 124 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isIgnoreComments() {
/* 128 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isIgnoreProcessingInstructions() {
/* 132 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isIgnoreWhitespace() {
/* 136 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isPrettyPrinting() {
/* 140 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int getPrettyIndent() {
/* 144 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\xml\XMLLib.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */