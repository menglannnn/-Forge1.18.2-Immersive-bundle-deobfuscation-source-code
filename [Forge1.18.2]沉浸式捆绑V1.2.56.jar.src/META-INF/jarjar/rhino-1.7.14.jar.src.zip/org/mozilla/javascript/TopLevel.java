/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.EnumMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopLevel
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = -4648046356662472260L;
/*     */   private EnumMap<Builtins, BaseFunction> ctors;
/*     */   private EnumMap<NativeErrors, BaseFunction> errors;
/*     */   
/*     */   public enum Builtins
/*     */   {
/*  39 */     Object,
/*     */     
/*  41 */     Array,
/*     */     
/*  43 */     Function,
/*     */     
/*  45 */     String,
/*     */     
/*  47 */     Number,
/*     */     
/*  49 */     Boolean,
/*     */     
/*  51 */     RegExp,
/*     */     
/*  53 */     Error,
/*     */     
/*  55 */     Symbol,
/*     */     
/*  57 */     GeneratorFunction,
/*     */     
/*  59 */     BigInt;
/*     */   }
/*     */ 
/*     */   
/*     */   enum NativeErrors
/*     */   {
/*  65 */     Error,
/*     */     
/*  67 */     EvalError,
/*     */     
/*  69 */     RangeError,
/*     */     
/*  71 */     ReferenceError,
/*     */     
/*  73 */     SyntaxError,
/*     */     
/*  75 */     TypeError,
/*     */     
/*  77 */     URIError,
/*     */     
/*  79 */     InternalError,
/*     */     
/*  81 */     JavaException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  89 */     return "global";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cacheBuiltins(Scriptable scope, boolean sealed) {
/* 100 */     this.ctors = new EnumMap<>(Builtins.class);
/* 101 */     for (Builtins builtin : Builtins.values()) {
/* 102 */       Object value = ScriptableObject.getProperty(this, builtin.name());
/* 103 */       if (value instanceof BaseFunction) {
/* 104 */         this.ctors.put(builtin, (BaseFunction)value);
/* 105 */       } else if (builtin == Builtins.GeneratorFunction) {
/*     */ 
/*     */         
/* 108 */         this.ctors.put(builtin, 
/*     */             
/* 110 */             (BaseFunction)BaseFunction.initAsGeneratorFunction(scope, sealed));
/*     */       } 
/*     */     } 
/* 113 */     this.errors = new EnumMap<>(NativeErrors.class);
/* 114 */     for (NativeErrors error : NativeErrors.values()) {
/* 115 */       Object value = ScriptableObject.getProperty(this, error.name());
/* 116 */       if (value instanceof BaseFunction) {
/* 117 */         this.errors.put(error, (BaseFunction)value);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void clearCache() {
/* 124 */     this.ctors = null;
/* 125 */     this.errors = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getBuiltinCtor(Context cx, Scriptable scope, Builtins type) {
/*     */     String typeName;
/* 140 */     assert scope.getParentScope() == null;
/* 141 */     if (scope instanceof TopLevel) {
/* 142 */       Function result = ((TopLevel)scope).getBuiltinCtor(type);
/* 143 */       if (result != null) {
/* 144 */         return result;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 149 */     if (type == Builtins.GeneratorFunction) {
/*     */ 
/*     */ 
/*     */       
/* 153 */       typeName = "__GeneratorFunction";
/*     */     } else {
/* 155 */       typeName = type.name();
/*     */     } 
/* 157 */     return ScriptRuntime.getExistingCtor(cx, scope, typeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Function getNativeErrorCtor(Context cx, Scriptable scope, NativeErrors type) {
/* 172 */     assert scope.getParentScope() == null;
/* 173 */     if (scope instanceof TopLevel) {
/* 174 */       Function result = ((TopLevel)scope).getNativeErrorCtor(type);
/* 175 */       if (result != null) {
/* 176 */         return result;
/*     */       }
/*     */     } 
/*     */     
/* 180 */     return ScriptRuntime.getExistingCtor(cx, scope, type.name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable getBuiltinPrototype(Scriptable scope, Builtins type) {
/*     */     String typeName;
/* 194 */     assert scope.getParentScope() == null;
/* 195 */     if (scope instanceof TopLevel) {
/* 196 */       Scriptable result = ((TopLevel)scope).getBuiltinPrototype(type);
/* 197 */       if (result != null) {
/* 198 */         return result;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 203 */     if (type == Builtins.GeneratorFunction) {
/*     */ 
/*     */ 
/*     */       
/* 207 */       typeName = "__GeneratorFunction";
/*     */     } else {
/* 209 */       typeName = type.name();
/*     */     } 
/* 211 */     return ScriptableObject.getClassPrototype(scope, typeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseFunction getBuiltinCtor(Builtins type) {
/* 223 */     return (this.ctors != null) ? this.ctors.get(type) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BaseFunction getNativeErrorCtor(NativeErrors type) {
/* 234 */     return (this.errors != null) ? this.errors.get(type) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getBuiltinPrototype(Builtins type) {
/* 246 */     BaseFunction func = getBuiltinCtor(type);
/* 247 */     Object proto = (func != null) ? func.getPrototypeProperty() : null;
/* 248 */     return (proto instanceof Scriptable) ? (Scriptable)proto : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\TopLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */