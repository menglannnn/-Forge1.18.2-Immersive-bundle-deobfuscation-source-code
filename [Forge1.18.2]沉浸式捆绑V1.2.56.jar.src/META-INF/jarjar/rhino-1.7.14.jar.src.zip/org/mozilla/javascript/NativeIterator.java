/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeIterator
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = -4136968203581667681L;
/*  19 */   private static final Object ITERATOR_TAG = "Iterator"; private static final String STOP_ITERATION = "StopIteration"; public static final String ITERATOR_PROPERTY_NAME = "__iterator__";
/*     */   private static final int Id_constructor = 1;
/*     */   
/*     */   static void init(Context cx, ScriptableObject scope, boolean sealed) {
/*  23 */     NativeIterator iterator = new NativeIterator();
/*  24 */     iterator.exportAsJSClass(3, scope, sealed);
/*     */ 
/*     */     
/*  27 */     if (cx.getLanguageVersion() >= 200) {
/*  28 */       ES6Generator.init(scope, sealed);
/*     */     } else {
/*  30 */       NativeGenerator.init(scope, sealed);
/*     */     } 
/*     */ 
/*     */     
/*  34 */     NativeObject obj = new StopIteration();
/*  35 */     obj.setPrototype(getObjectPrototype(scope));
/*  36 */     obj.setParentScope(scope);
/*  37 */     if (sealed) {
/*  38 */       obj.sealObject();
/*     */     }
/*  40 */     ScriptableObject.defineProperty(scope, "StopIteration", obj, 2);
/*     */ 
/*     */ 
/*     */     
/*  44 */     scope.associateValue(ITERATOR_TAG, obj);
/*     */   }
/*     */   private static final int Id_next = 2; private static final int Id___iterator__ = 3; private static final int MAX_PROTOTYPE_ID = 3; private Object objectIterator;
/*     */   
/*     */   private NativeIterator() {}
/*     */   
/*     */   private NativeIterator(Object objectIterator) {
/*  51 */     this.objectIterator = objectIterator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getStopIterationObject(Scriptable scope) {
/*  63 */     Scriptable top = ScriptableObject.getTopLevelScope(scope);
/*  64 */     return ScriptableObject.getTopScopeValue(top, ITERATOR_TAG);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class StopIteration
/*     */     extends NativeObject
/*     */   {
/*     */     private static final long serialVersionUID = 2485151085722377663L;
/*     */     
/*  73 */     private Object value = Undefined.instance;
/*     */     
/*     */     public StopIteration() {}
/*     */     
/*     */     public StopIteration(Object val) {
/*  78 */       this.value = val;
/*     */     }
/*     */     
/*     */     public Object getValue() {
/*  82 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getClassName() {
/*  87 */       return "StopIteration";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasInstance(Scriptable instance) {
/*  95 */       return instance instanceof StopIteration;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 101 */     return "Iterator";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 108 */     switch (id) {
/*     */       case 1:
/* 110 */         arity = 2;
/* 111 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 114 */         arity = 0;
/* 115 */         s = "next";
/*     */         break;
/*     */       case 3:
/* 118 */         arity = 1;
/* 119 */         s = "__iterator__";
/*     */         break;
/*     */       default:
/* 122 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 124 */     initPrototypeMethod(ITERATOR_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 130 */     if (!f.hasTag(ITERATOR_TAG)) {
/* 131 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 133 */     int id = f.methodId();
/*     */     
/* 135 */     if (id == 1) {
/* 136 */       return jsConstructor(cx, scope, thisObj, args);
/*     */     }
/*     */     
/* 139 */     NativeIterator iterator = ensureType(thisObj, NativeIterator.class, f);
/*     */     
/* 141 */     switch (id) {
/*     */       case 2:
/* 143 */         return iterator.next(cx, scope);
/*     */ 
/*     */       
/*     */       case 3:
/* 147 */         return thisObj;
/*     */     } 
/*     */     
/* 150 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object jsConstructor(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 157 */     if (args.length == 0 || args[0] == null || args[0] == Undefined.instance) {
/* 158 */       Object argument = (args.length == 0) ? Undefined.instance : args[0];
/* 159 */       throw ScriptRuntime.typeErrorById("msg.no.properties", new Object[] {
/* 160 */             ScriptRuntime.toString(argument) });
/*     */     } 
/* 162 */     Scriptable obj = ScriptRuntime.toObject(cx, scope, args[0]);
/* 163 */     boolean keyOnly = (args.length > 1 && ScriptRuntime.toBoolean(args[1]));
/* 164 */     if (thisObj != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 170 */       Iterator<?> iterator = getJavaIterator(obj);
/* 171 */       if (iterator != null) {
/* 172 */         scope = ScriptableObject.getTopLevelScope(scope);
/* 173 */         return cx.getWrapFactory()
/* 174 */           .wrap(cx, scope, new WrappedJavaIterator(iterator, scope), WrappedJavaIterator.class);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       Scriptable jsIterator = ScriptRuntime.toIterator(cx, scope, obj, keyOnly);
/* 183 */       if (jsIterator != null) {
/* 184 */         return jsIterator;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     Object objectIterator = ScriptRuntime.enumInit(obj, cx, scope, keyOnly ? 3 : 5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     ScriptRuntime.setEnumNumbers(objectIterator, true);
/* 199 */     NativeIterator result = new NativeIterator(objectIterator);
/* 200 */     result.setPrototype(ScriptableObject.getClassPrototype(scope, result.getClassName()));
/* 201 */     result.setParentScope(scope);
/* 202 */     return result;
/*     */   }
/*     */   
/*     */   private Object next(Context cx, Scriptable scope) {
/* 206 */     Boolean b = ScriptRuntime.enumNext(this.objectIterator);
/* 207 */     if (!b.booleanValue())
/*     */     {
/* 209 */       throw new JavaScriptException(getStopIterationObject(scope), null, 0);
/*     */     }
/* 211 */     return ScriptRuntime.enumId(this.objectIterator, cx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Iterator<?> getJavaIterator(Object obj) {
/* 220 */     if (obj instanceof Wrapper) {
/* 221 */       Object unwrapped = ((Wrapper)obj).unwrap();
/* 222 */       Iterator<?> iterator = null;
/* 223 */       if (unwrapped instanceof Iterator) iterator = (Iterator)unwrapped; 
/* 224 */       if (unwrapped instanceof Iterable) iterator = ((Iterable)unwrapped).iterator(); 
/* 225 */       return iterator;
/*     */     } 
/* 227 */     return null;
/*     */   }
/*     */   public static class WrappedJavaIterator { private Iterator<?> iterator; private Scriptable scope;
/*     */     
/*     */     WrappedJavaIterator(Iterator<?> iterator, Scriptable scope) {
/* 232 */       this.iterator = iterator;
/* 233 */       this.scope = scope;
/*     */     }
/*     */     
/*     */     public Object next() {
/* 237 */       if (!this.iterator.hasNext())
/*     */       {
/* 239 */         throw new JavaScriptException(
/* 240 */             NativeIterator.getStopIterationObject(this.scope), null, 0);
/*     */       }
/* 242 */       return this.iterator.next();
/*     */     }
/*     */     
/*     */     public Object __iterator__(boolean b) {
/* 246 */       return this;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 256 */     switch (s)
/*     */     { case "constructor":
/* 258 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 270 */         return id;case "next": id = 2; return id;case "__iterator__": id = 3; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */