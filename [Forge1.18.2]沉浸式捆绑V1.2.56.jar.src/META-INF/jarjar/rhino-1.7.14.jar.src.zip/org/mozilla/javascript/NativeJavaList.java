/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaList
/*     */   extends NativeJavaObject
/*     */ {
/*     */   private static final long serialVersionUID = 660285467829047519L;
/*     */   private List<Object> list;
/*     */   
/*     */   public NativeJavaList(Scriptable scope, Object list) {
/*  54 */     super(scope, list, list.getClass());
/*  55 */     assert list instanceof List;
/*  56 */     this.list = (List<Object>)list;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  61 */     return "JavaList";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(String name, Scriptable start) {
/*  66 */     if (name.equals("length")) {
/*  67 */       return true;
/*     */     }
/*  69 */     return super.has(name, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/*  74 */     if (isWithValidIndex(index)) {
/*  75 */       return true;
/*     */     }
/*  77 */     return super.has(index, start);
/*     */   }
/*     */   
/*     */   public void delete(int index) {
/*  81 */     if (isWithValidIndex(index)) {
/*  82 */       this.list.set(index, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(Symbol key, Scriptable start) {
/*  88 */     if (SymbolKey.IS_CONCAT_SPREADABLE.equals(key)) {
/*  89 */       return true;
/*     */     }
/*  91 */     return super.has(key, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String name, Scriptable start) {
/*  96 */     if ("length".equals(name)) {
/*  97 */       return Integer.valueOf(this.list.size());
/*     */     }
/*  99 */     return super.get(name, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/* 104 */     if (isWithValidIndex(index)) {
/* 105 */       Context cx = Context.getCurrentContext();
/* 106 */       Object obj = this.list.get(index);
/* 107 */       if (cx != null) {
/* 108 */         return cx.getWrapFactory().wrap(cx, this, obj, (obj == null) ? null : obj.getClass());
/*     */       }
/* 110 */       return obj;
/*     */     } 
/* 112 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Symbol key, Scriptable start) {
/* 117 */     if (SymbolKey.IS_CONCAT_SPREADABLE.equals(key)) {
/* 118 */       return Boolean.TRUE;
/*     */     }
/* 120 */     return super.get(key, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/* 125 */     if (index >= 0) {
/* 126 */       Object javaValue = Context.jsToJava(value, Object.class);
/* 127 */       if (index == this.list.size()) {
/* 128 */         this.list.add(javaValue);
/*     */       } else {
/* 130 */         ensureCapacity(index + 1);
/* 131 */         this.list.set(index, javaValue);
/*     */       } 
/*     */       return;
/*     */     } 
/* 135 */     super.put(index, start, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String name, Scriptable start, Object value) {
/* 140 */     if (this.list != null && "length".equals(name)) {
/* 141 */       setLength(value);
/*     */       return;
/*     */     } 
/* 144 */     super.put(name, start, value);
/*     */   }
/*     */   
/*     */   private void ensureCapacity(int minCapacity) {
/* 148 */     if (minCapacity > this.list.size()) {
/* 149 */       if (this.list instanceof ArrayList) {
/* 150 */         ((ArrayList)this.list).ensureCapacity(minCapacity);
/*     */       }
/* 152 */       while (minCapacity > this.list.size()) {
/* 153 */         this.list.add(null);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setLength(Object val) {
/* 159 */     double d = ScriptRuntime.toNumber(val);
/* 160 */     long longVal = ScriptRuntime.toUint32(d);
/* 161 */     if (longVal != d || longVal > 2147483647L) {
/* 162 */       String msg = ScriptRuntime.getMessageById("msg.arraylength.bad", new Object[0]);
/* 163 */       throw ScriptRuntime.rangeError(msg);
/*     */     } 
/* 165 */     if (longVal < this.list.size()) {
/* 166 */       this.list.subList((int)longVal, this.list.size()).clear();
/*     */     } else {
/* 168 */       ensureCapacity((int)longVal);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 174 */     List<?> list = (List)this.javaObject;
/* 175 */     Object[] result = new Object[list.size()];
/* 176 */     int i = list.size();
/* 177 */     while (--i >= 0) {
/* 178 */       result[i] = Integer.valueOf(i);
/*     */     }
/* 180 */     return result;
/*     */   }
/*     */   
/*     */   private boolean isWithValidIndex(int index) {
/* 184 */     return (index >= 0 && index < this.list.size());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeJavaList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */