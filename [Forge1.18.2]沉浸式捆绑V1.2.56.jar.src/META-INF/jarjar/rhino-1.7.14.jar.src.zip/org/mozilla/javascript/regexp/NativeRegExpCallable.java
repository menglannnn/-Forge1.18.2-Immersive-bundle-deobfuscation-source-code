/*    */ package org.mozilla.javascript.regexp;
/*    */ 
/*    */ import org.mozilla.javascript.Context;
/*    */ import org.mozilla.javascript.Function;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ 
/*    */ 
/*    */ class NativeRegExpCallable
/*    */   extends NativeRegExp
/*    */   implements Function
/*    */ {
/*    */   NativeRegExpCallable(Scriptable scope, RECompiled compiled) {
/* 13 */     super(scope, compiled);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   NativeRegExpCallable() {}
/*    */ 
/*    */   
/*    */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 22 */     return execSub(cx, scope, args, 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/* 27 */     return (Scriptable)execSub(cx, scope, args, 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\regexp\NativeRegExpCallable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */