/*     */ package org.mozilla.javascript.regexp;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Function;
/*     */ import org.mozilla.javascript.Kit;
/*     */ import org.mozilla.javascript.RegExpProxy;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ public class RegExpImpl
/*     */   implements RegExpProxy
/*     */ {
/*     */   protected String input;
/*     */   protected boolean multiline;
/*     */   protected SubString[] parens;
/*     */   protected SubString lastMatch;
/*     */   protected SubString lastParen;
/*     */   protected SubString leftContext;
/*     */   protected SubString rightContext;
/*     */   
/*     */   public boolean isRegExp(Scriptable obj) {
/*  25 */     return obj instanceof NativeRegExp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object compileRegExp(Context cx, String source, String flags) {
/*  31 */     return NativeRegExp.compileRE(cx, source, flags, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable wrapRegExp(Context cx, Scriptable scope, Object compiled) {
/*  38 */     return 
/*  39 */       (Scriptable)NativeRegExpInstantiator.withLanguageVersionScopeCompiled(cx.getLanguageVersion(), scope, (RECompiled)compiled); } public Object action(Context cx, Scriptable scope, Scriptable thisObj, Object[] args, int actionType) { int optarg; boolean useRE; int i; NativeRegExp re;
/*     */     Object rval;
/*     */     String search;
/*     */     Object arg1;
/*     */     String repstr;
/*     */     Function lambda;
/*     */     Object val;
/*     */     SubString rc;
/*  47 */     GlobData data = new GlobData();
/*  48 */     data.mode = actionType;
/*  49 */     data.str = ScriptRuntime.toString(thisObj);
/*     */     
/*  51 */     switch (actionType) {
/*     */       
/*     */       case 1:
/*  54 */         optarg = Integer.MAX_VALUE;
/*  55 */         if (cx.getLanguageVersion() < 160) {
/*  56 */           optarg = 1;
/*     */         }
/*     */         
/*  59 */         re = createRegExp(cx, scope, args, optarg, false);
/*  60 */         rval = matchOrReplace(cx, scope, thisObj, args, this, data, re);
/*  61 */         return (data.arrayobj == null) ? rval : data.arrayobj;
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/*  66 */         optarg = Integer.MAX_VALUE;
/*  67 */         if (cx.getLanguageVersion() < 160) {
/*  68 */           optarg = 1;
/*     */         }
/*     */         
/*  71 */         re = createRegExp(cx, scope, args, optarg, false);
/*  72 */         return matchOrReplace(cx, scope, thisObj, args, this, data, re);
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*  77 */         useRE = (args.length > 0 && args[0] instanceof NativeRegExp);
/*     */ 
/*     */         
/*  80 */         if (cx.getLanguageVersion() < 160) {
/*  81 */           i = useRE | ((args.length > 2) ? 1 : 0);
/*     */         }
/*     */         
/*  84 */         re = null;
/*  85 */         search = null;
/*  86 */         if (i != 0) {
/*  87 */           re = createRegExp(cx, scope, args, 2, true);
/*     */         } else {
/*  89 */           Object arg0 = (args.length < 1) ? Undefined.instance : args[0];
/*  90 */           search = ScriptRuntime.toString(arg0);
/*     */         } 
/*     */         
/*  93 */         arg1 = (args.length < 2) ? Undefined.instance : args[1];
/*  94 */         repstr = null;
/*  95 */         lambda = null;
/*  96 */         if (arg1 instanceof Function && (cx
/*  97 */           .getLanguageVersion() < 200 || !(arg1 instanceof NativeRegExp))) {
/*     */           
/*  99 */           lambda = (Function)arg1;
/*     */         } else {
/* 101 */           repstr = ScriptRuntime.toString(arg1);
/*     */         } 
/*     */         
/* 104 */         data.lambda = lambda;
/* 105 */         data.repstr = repstr;
/* 106 */         data.dollar = (repstr == null) ? -1 : repstr.indexOf('$');
/* 107 */         data.charBuf = null;
/* 108 */         data.leftIndex = 0;
/*     */ 
/*     */         
/* 111 */         if (i != 0) {
/* 112 */           val = matchOrReplace(cx, scope, thisObj, args, this, data, re);
/*     */         } else {
/*     */           
/* 115 */           String str = data.str;
/* 116 */           int index = str.indexOf(search);
/* 117 */           if (index >= 0) {
/* 118 */             int slen = search.length();
/* 119 */             this.parens = null;
/* 120 */             this.lastParen = null;
/* 121 */             this.leftContext = new SubString(str, 0, index);
/* 122 */             this.lastMatch = new SubString(str, index, slen);
/* 123 */             this.rightContext = new SubString(str, index + slen, str.length() - index - slen);
/* 124 */             val = Boolean.TRUE;
/*     */           } else {
/* 126 */             val = Boolean.FALSE;
/*     */           } 
/*     */         } 
/*     */         
/* 130 */         if (data.charBuf == null) {
/* 131 */           if (data.global || val == null || 
/* 132 */             !val.equals(Boolean.TRUE))
/*     */           {
/*     */             
/* 135 */             return data.str;
/*     */           }
/* 137 */           SubString lc = this.leftContext;
/* 138 */           replace_glob(data, cx, scope, this, lc.index, lc.length);
/*     */         } 
/* 140 */         rc = this.rightContext;
/* 141 */         data.charBuf.append(rc.str, rc.index, rc.index + rc.length);
/* 142 */         return data.charBuf.toString();
/*     */     } 
/*     */ 
/*     */     
/* 146 */     throw Kit.codeBug(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static NativeRegExp createRegExp(Context cx, Scriptable scope, Object[] args, int optarg, boolean forceFlat) {
/*     */     NativeRegExp re;
/* 155 */     Scriptable topScope = ScriptableObject.getTopLevelScope(scope);
/* 156 */     if (args.length == 0 || args[0] == Undefined.instance) {
/* 157 */       RECompiled compiled = NativeRegExp.compileRE(cx, "", "", false);
/* 158 */       re = NativeRegExpInstantiator.withLanguageVersionScopeCompiled(cx.getLanguageVersion(), topScope, compiled);
/* 159 */     } else if (args[0] instanceof NativeRegExp) {
/* 160 */       re = (NativeRegExp)args[0];
/*     */     } else {
/* 162 */       String opt, src = ScriptRuntime.toString(args[0]);
/*     */       
/* 164 */       if (optarg < args.length) {
/* 165 */         args[0] = src;
/* 166 */         opt = ScriptRuntime.toString(args[optarg]);
/*     */       } else {
/* 168 */         opt = null;
/*     */       } 
/* 170 */       RECompiled compiled = NativeRegExp.compileRE(cx, src, opt, forceFlat);
/* 171 */       re = NativeRegExpInstantiator.withLanguageVersionScopeCompiled(cx.getLanguageVersion(), topScope, compiled);
/*     */     } 
/* 173 */     return re;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object matchOrReplace(Context cx, Scriptable scope, Scriptable thisObj, Object[] args, RegExpImpl reImpl, GlobData data, NativeRegExp re) {
/* 184 */     String str = data.str;
/* 185 */     data.global = ((re.getFlags() & 0x1) != 0);
/* 186 */     int[] indexp = { 0 };
/* 187 */     Object result = null;
/* 188 */     if (data.mode == 3) {
/* 189 */       result = re.executeRegExp(cx, scope, reImpl, str, indexp, 0);
/*     */       
/* 191 */       if (result != null && result.equals(Boolean.TRUE))
/* 192 */       { result = Integer.valueOf(reImpl.leftContext.length); }
/*     */       else
/* 194 */       { result = Integer.valueOf(-1); } 
/* 195 */     } else if (data.global) {
/* 196 */       re.lastIndex = ScriptRuntime.zeroObj;
/* 197 */       for (int count = 0; indexp[0] <= str.length(); count++) {
/* 198 */         result = re.executeRegExp(cx, scope, reImpl, str, indexp, 0);
/*     */         
/* 200 */         if (result == null || !result.equals(Boolean.TRUE))
/*     */           break; 
/* 202 */         if (data.mode == 1) {
/* 203 */           match_glob(data, cx, scope, count, reImpl);
/*     */         } else {
/* 205 */           if (data.mode != 2) Kit.codeBug(); 
/* 206 */           SubString lastMatch = reImpl.lastMatch;
/* 207 */           int leftIndex = data.leftIndex;
/* 208 */           int leftlen = lastMatch.index - leftIndex;
/* 209 */           data.leftIndex = lastMatch.index + lastMatch.length;
/* 210 */           replace_glob(data, cx, scope, reImpl, leftIndex, leftlen);
/*     */         } 
/* 212 */         if (reImpl.lastMatch.length == 0) {
/* 213 */           if (indexp[0] == str.length())
/*     */             break; 
/* 215 */           indexp[0] = indexp[0] + 1;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 219 */       result = re.executeRegExp(cx, scope, reImpl, str, indexp, (data.mode == 2) ? 0 : 1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int find_split(Context cx, Scriptable scope, String target, String separator, Scriptable reObj, int[] ip, int[] matchlen, boolean[] matched, String[][] parensp) {
/* 236 */     int result, i = ip[0];
/* 237 */     int length = target.length();
/*     */ 
/*     */     
/* 240 */     int version = cx.getLanguageVersion();
/* 241 */     NativeRegExp re = (NativeRegExp)reObj;
/*     */ 
/*     */     
/*     */     while (true) {
/* 245 */       int ipsave = ip[0];
/* 246 */       ip[0] = i;
/* 247 */       Object ret = re.executeRegExp(cx, scope, this, target, ip, 0);
/*     */       
/* 249 */       if (!Boolean.TRUE.equals(ret)) {
/*     */         
/* 251 */         ip[0] = ipsave;
/* 252 */         matchlen[0] = 1;
/* 253 */         matched[0] = false;
/* 254 */         return length;
/*     */       } 
/* 256 */       i = ip[0];
/* 257 */       ip[0] = ipsave;
/* 258 */       matched[0] = true;
/*     */       
/* 260 */       SubString sep = this.lastMatch;
/* 261 */       matchlen[0] = sep.length;
/* 262 */       if (matchlen[0] == 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 269 */         if (i == ip[0]) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 276 */           if (i == length) {
/* 277 */             if (version == 120) {
/* 278 */               matchlen[0] = 1;
/* 279 */               int k = i;
/*     */               break;
/*     */             } 
/* 282 */             int j = -1;
/*     */             break;
/*     */           } 
/* 285 */           i++;
/*     */           
/*     */           continue;
/*     */         } 
/*     */       }
/* 290 */       result = i - matchlen[0];
/*     */       break;
/*     */     } 
/* 293 */     int size = (this.parens == null) ? 0 : this.parens.length;
/* 294 */     parensp[0] = new String[size];
/* 295 */     for (int num = 0; num < size; num++) {
/* 296 */       SubString parsub = getParenSubString(num);
/* 297 */       parensp[0][num] = parsub.toString();
/*     */     } 
/* 299 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SubString getParenSubString(int i) {
/* 308 */     if (this.parens != null && i < this.parens.length) {
/* 309 */       SubString parsub = this.parens[i];
/* 310 */       if (parsub != null) {
/* 311 */         return parsub;
/*     */       }
/*     */     } 
/* 314 */     return new SubString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void match_glob(GlobData mdata, Context cx, Scriptable scope, int count, RegExpImpl reImpl) {
/* 324 */     if (mdata.arrayobj == null) {
/* 325 */       mdata.arrayobj = cx.newArray(scope, 0);
/*     */     }
/* 327 */     SubString matchsub = reImpl.lastMatch;
/* 328 */     String matchstr = matchsub.toString();
/* 329 */     mdata.arrayobj.put(count, mdata.arrayobj, matchstr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void replace_glob(GlobData rdata, Context cx, Scriptable scope, RegExpImpl reImpl, int leftIndex, int leftlen) {
/*     */     int replen;
/*     */     String lambdaStr;
/* 341 */     if (rdata.lambda != null) {
/*     */ 
/*     */       
/* 344 */       SubString[] parens = reImpl.parens;
/* 345 */       int parenCount = (parens == null) ? 0 : parens.length;
/* 346 */       Object[] args = new Object[parenCount + 3];
/* 347 */       args[0] = reImpl.lastMatch.toString();
/* 348 */       for (int i = 0; i < parenCount; i++) {
/* 349 */         SubString sub = parens[i];
/* 350 */         if (sub != null) {
/* 351 */           args[i + 1] = sub.toString();
/*     */         } else {
/* 353 */           args[i + 1] = Undefined.instance;
/*     */         } 
/*     */       } 
/* 356 */       args[parenCount + 1] = Integer.valueOf(reImpl.leftContext.length);
/* 357 */       args[parenCount + 2] = rdata.str;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 362 */       if (reImpl != ScriptRuntime.getRegExpProxy(cx)) Kit.codeBug(); 
/* 363 */       RegExpImpl re2 = new RegExpImpl();
/* 364 */       re2.multiline = reImpl.multiline;
/* 365 */       re2.input = reImpl.input;
/* 366 */       ScriptRuntime.setRegExpProxy(cx, re2);
/*     */       try {
/* 368 */         Scriptable parent = ScriptableObject.getTopLevelScope(scope);
/* 369 */         Object result = rdata.lambda.call(cx, parent, parent, args);
/* 370 */         lambdaStr = ScriptRuntime.toString(result);
/*     */       } finally {
/* 372 */         ScriptRuntime.setRegExpProxy(cx, reImpl);
/*     */       } 
/* 374 */       replen = lambdaStr.length();
/*     */     } else {
/* 376 */       lambdaStr = null;
/* 377 */       replen = rdata.repstr.length();
/* 378 */       if (rdata.dollar >= 0) {
/* 379 */         int[] skip = new int[1];
/* 380 */         int dp = rdata.dollar;
/*     */         do {
/* 382 */           SubString sub = interpretDollar(cx, reImpl, rdata.repstr, dp, skip);
/*     */           
/* 384 */           if (sub != null) {
/* 385 */             replen += sub.length - skip[0];
/* 386 */             dp += skip[0];
/*     */           } else {
/* 388 */             dp++;
/*     */           } 
/* 390 */           dp = rdata.repstr.indexOf('$', dp);
/* 391 */         } while (dp >= 0);
/*     */       } 
/*     */     } 
/*     */     
/* 395 */     int growth = leftlen + replen + reImpl.rightContext.length;
/* 396 */     StringBuilder charBuf = rdata.charBuf;
/* 397 */     if (charBuf == null) {
/* 398 */       charBuf = new StringBuilder(growth);
/* 399 */       rdata.charBuf = charBuf;
/*     */     } else {
/* 401 */       charBuf.ensureCapacity(rdata.charBuf.length() + growth);
/*     */     } 
/*     */     
/* 404 */     charBuf.append(reImpl.leftContext.str, leftIndex, leftIndex + leftlen);
/* 405 */     if (rdata.lambda != null) {
/* 406 */       charBuf.append(lambdaStr);
/*     */     } else {
/* 408 */       do_replace(rdata, cx, reImpl);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SubString interpretDollar(Context cx, RegExpImpl res, String da, int dp, int[] skip) {
/* 418 */     if (da.charAt(dp) != '$') Kit.codeBug();
/*     */ 
/*     */     
/* 421 */     int version = cx.getLanguageVersion();
/* 422 */     if (version != 0 && version <= 140)
/*     */     {
/*     */       
/* 425 */       if (dp > 0 && da.charAt(dp - 1) == '\\')
/* 426 */         return null; 
/*     */     }
/* 428 */     int daL = da.length();
/* 429 */     if (dp + 1 >= daL) {
/* 430 */       return null;
/*     */     }
/* 432 */     char dc = da.charAt(dp + 1);
/* 433 */     if (NativeRegExp.isDigit(dc)) {
/*     */       int num, cp;
/* 435 */       if (version != 0 && version <= 140) {
/*     */ 
/*     */         
/* 438 */         if (dc == '0') {
/* 439 */           return null;
/*     */         }
/* 441 */         num = 0;
/* 442 */         cp = dp;
/* 443 */         while (++cp < daL && NativeRegExp.isDigit(dc = da.charAt(cp))) {
/*     */           
/* 445 */           int tmp = 10 * num + dc - 48;
/* 446 */           if (tmp < num)
/*     */             break; 
/* 448 */           num = tmp;
/*     */         } 
/*     */       } else {
/*     */         
/* 452 */         int parenCount = (res.parens == null) ? 0 : res.parens.length;
/* 453 */         num = dc - 48;
/* 454 */         if (num > parenCount)
/* 455 */           return null; 
/* 456 */         cp = dp + 2;
/* 457 */         if (dp + 2 < daL) {
/* 458 */           dc = da.charAt(dp + 2);
/* 459 */           if (NativeRegExp.isDigit(dc)) {
/* 460 */             int tmp = 10 * num + dc - 48;
/* 461 */             if (tmp <= parenCount) {
/* 462 */               cp++;
/* 463 */               num = tmp;
/*     */             } 
/*     */           } 
/*     */         } 
/* 467 */         if (num == 0) return null;
/*     */       
/*     */       } 
/* 470 */       num--;
/* 471 */       skip[0] = cp - dp;
/* 472 */       return res.getParenSubString(num);
/*     */     } 
/*     */     
/* 475 */     skip[0] = 2;
/* 476 */     switch (dc) {
/*     */       case '$':
/* 478 */         return new SubString("$");
/*     */       case '&':
/* 480 */         return res.lastMatch;
/*     */       case '+':
/* 482 */         return res.lastParen;
/*     */       case '`':
/* 484 */         if (version == 120) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 492 */           res.leftContext.index = 0;
/* 493 */           res.leftContext.length = res.lastMatch.index;
/*     */         } 
/* 495 */         return res.leftContext;
/*     */       case '\'':
/* 497 */         return res.rightContext;
/*     */     } 
/* 499 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void do_replace(GlobData rdata, Context cx, RegExpImpl regExpImpl) {
/* 508 */     StringBuilder charBuf = rdata.charBuf;
/* 509 */     int cp = 0;
/* 510 */     String da = rdata.repstr;
/* 511 */     int dp = rdata.dollar;
/* 512 */     if (dp != -1) {
/* 513 */       int[] skip = new int[1];
/*     */       do {
/* 515 */         int len = dp - cp;
/* 516 */         charBuf.append(da.substring(cp, dp));
/* 517 */         cp = dp;
/* 518 */         SubString sub = interpretDollar(cx, regExpImpl, da, dp, skip);
/*     */         
/* 520 */         if (sub != null) {
/* 521 */           len = sub.length;
/* 522 */           if (len > 0) {
/* 523 */             charBuf.append(sub.str, sub.index, sub.index + len);
/*     */           }
/* 525 */           cp += skip[0];
/* 526 */           dp += skip[0];
/*     */         } else {
/* 528 */           dp++;
/*     */         } 
/* 530 */         dp = da.indexOf('$', dp);
/* 531 */       } while (dp >= 0);
/*     */     } 
/* 533 */     int daL = da.length();
/* 534 */     if (daL > cp) {
/* 535 */       charBuf.append(da.substring(cp, daL));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object js_split(Context cx, Scriptable scope, String target, Object[] args) {
/* 549 */     Scriptable result = cx.newArray(scope, 0);
/*     */ 
/*     */     
/* 552 */     boolean limited = (args.length > 1 && args[1] != Undefined.instance);
/* 553 */     long limit = 0L;
/* 554 */     if (limited) {
/*     */       
/* 556 */       limit = ScriptRuntime.toUint32(args[1]);
/* 557 */       if (limit == 0L) {
/* 558 */         return result;
/*     */       }
/* 560 */       if (limit > target.length()) {
/* 561 */         limit = (1 + target.length());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 566 */     if (args.length < 1 || args[0] == Undefined.instance) {
/* 567 */       result.put(0, result, target);
/* 568 */       return result;
/*     */     } 
/*     */     
/* 571 */     String separator = null;
/* 572 */     int[] matchlen = new int[1];
/* 573 */     Scriptable re = null;
/* 574 */     RegExpProxy reProxy = null;
/* 575 */     if (args[0] instanceof Scriptable) {
/* 576 */       reProxy = ScriptRuntime.getRegExpProxy(cx);
/* 577 */       if (reProxy != null) {
/* 578 */         Scriptable test = (Scriptable)args[0];
/* 579 */         if (reProxy.isRegExp(test)) {
/* 580 */           re = test;
/*     */         }
/*     */       } 
/*     */     } 
/* 584 */     if (re == null) {
/* 585 */       separator = ScriptRuntime.toString(args[0]);
/* 586 */       matchlen[0] = separator.length();
/*     */     } 
/*     */ 
/*     */     
/* 590 */     int[] ip = { 0 };
/*     */     
/* 592 */     int len = 0;
/* 593 */     boolean[] matched = { false };
/* 594 */     String[][] parens = { null };
/* 595 */     int version = cx.getLanguageVersion(); int match;
/* 596 */     while ((match = find_split(cx, scope, target, separator, version, reProxy, re, ip, matchlen, matched, parens)) >= 0) {
/*     */       String substr;
/*     */ 
/*     */       
/* 600 */       if ((limited && len >= limit) || match > target.length()) {
/*     */         break;
/*     */       }
/*     */       
/* 604 */       if (target.length() == 0) {
/* 605 */         substr = target;
/*     */       } else {
/* 607 */         substr = target.substring(ip[0], match);
/*     */       } 
/* 609 */       result.put(len, result, substr);
/* 610 */       len++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 616 */       if (re != null && matched[0]) {
/* 617 */         int size = (parens[0]).length;
/* 618 */         for (int num = 0; num < size && (
/* 619 */           !limited || len < limit); num++) {
/*     */           
/* 621 */           result.put(len, result, parens[0][num]);
/* 622 */           len++;
/*     */         } 
/* 624 */         matched[0] = false;
/*     */       } 
/* 626 */       ip[0] = match + matchlen[0];
/*     */       
/* 628 */       if (version < 130 && version != 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 635 */         if (!limited && ip[0] == target.length())
/*     */           break; 
/*     */       }
/*     */     } 
/* 639 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int find_split(Context cx, Scriptable scope, String target, String separator, int version, RegExpProxy reProxy, Scriptable re, int[] ip, int[] matchlen, boolean[] matched, String[][] parensp) {
/* 660 */     int i = ip[0];
/* 661 */     int length = target.length();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 668 */     if (version == 120 && re == null && separator
/* 669 */       .length() == 1 && separator.charAt(0) == ' ') {
/*     */ 
/*     */       
/* 672 */       if (i == 0) {
/* 673 */         while (i < length && Character.isWhitespace(target.charAt(i)))
/* 674 */           i++; 
/* 675 */         ip[0] = i;
/*     */       } 
/*     */ 
/*     */       
/* 679 */       if (i == length) {
/* 680 */         return -1;
/*     */       }
/*     */       
/* 683 */       while (i < length && 
/* 684 */         !Character.isWhitespace(target.charAt(i))) {
/* 685 */         i++;
/*     */       }
/*     */       
/* 688 */       int j = i;
/* 689 */       while (j < length && Character.isWhitespace(target.charAt(j))) {
/* 690 */         j++;
/*     */       }
/*     */       
/* 693 */       matchlen[0] = j - i;
/* 694 */       return i;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 707 */     if (i > length) {
/* 708 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 715 */     if (re != null) {
/* 716 */       return reProxy.find_split(cx, scope, target, separator, re, ip, matchlen, matched, parensp);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 725 */     if (version != 0 && version < 130 && length == 0)
/*     */     {
/* 727 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 739 */     if (separator.length() == 0) {
/* 740 */       if (version == 120) {
/* 741 */         if (i == length) {
/* 742 */           matchlen[0] = 1;
/* 743 */           return i;
/*     */         } 
/* 745 */         return i + 1;
/*     */       } 
/* 747 */       return (i == length) ? -1 : (i + 1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 753 */     if (ip[0] >= length) {
/* 754 */       return length;
/*     */     }
/* 756 */     i = target.indexOf(separator, ip[0]);
/*     */     
/* 758 */     return (i != -1) ? i : length;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\regexp\RegExpImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */