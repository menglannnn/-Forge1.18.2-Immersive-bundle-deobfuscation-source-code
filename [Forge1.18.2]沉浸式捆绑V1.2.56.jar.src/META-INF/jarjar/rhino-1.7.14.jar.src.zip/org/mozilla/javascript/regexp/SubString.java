/*    */ package org.mozilla.javascript.regexp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubString
/*    */ {
/*    */   String str;
/*    */   int index;
/*    */   int length;
/*    */   
/*    */   public SubString() {}
/*    */   
/*    */   public SubString(String str) {
/* 20 */     this.str = str;
/* 21 */     this.index = 0;
/* 22 */     this.length = str.length();
/*    */   }
/*    */ 
/*    */   
/*    */   public SubString(String source, int start, int len) {
/* 27 */     this.str = source;
/* 28 */     this.index = start;
/* 29 */     this.length = len;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 34 */     return (this.str == null) ? "" : this.str
/*    */       
/* 36 */       .substring(this.index, this.index + this.length);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\regexp\SubString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */