/*    */ package org.mozilla.javascript.regexp;
/*    */ 
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeRegExpInstantiator
/*    */ {
/*    */   static NativeRegExp withLanguageVersion(int languageVersion) {
/* 11 */     if (languageVersion < 200) {
/* 12 */       return new NativeRegExpCallable();
/*    */     }
/* 14 */     return new NativeRegExp();
/*    */   }
/*    */ 
/*    */   
/*    */   static NativeRegExp withLanguageVersionScopeCompiled(int languageVersion, Scriptable scope, RECompiled compiled) {
/* 19 */     if (languageVersion < 200) {
/* 20 */       return new NativeRegExpCallable(scope, compiled);
/*    */     }
/* 22 */     return new NativeRegExp(scope, compiled);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\regexp\NativeRegExpInstantiator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */