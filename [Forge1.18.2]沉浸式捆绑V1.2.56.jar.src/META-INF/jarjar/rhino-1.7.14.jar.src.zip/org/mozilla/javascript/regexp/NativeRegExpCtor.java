/*     */ package org.mozilla.javascript.regexp;
/*     */ 
/*     */ import org.mozilla.javascript.BaseFunction;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.TopLevel;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NativeRegExpCtor
/*     */   extends BaseFunction
/*     */ {
/*     */   private static final long serialVersionUID = -5733330028285400526L;
/*     */   private static final int Id_multiline = 1;
/*     */   private static final int Id_STAR = 2;
/*     */   private static final int Id_input = 3;
/*     */   private static final int Id_UNDERSCORE = 4;
/*     */   private static final int Id_lastMatch = 5;
/*     */   private static final int Id_AMPERSAND = 6;
/*     */   private static final int Id_lastParen = 7;
/*     */   private static final int Id_PLUS = 8;
/*     */   private static final int Id_leftContext = 9;
/*     */   private static final int Id_BACK_QUOTE = 10;
/*     */   private static final int Id_rightContext = 11;
/*     */   
/*     */   public String getFunctionName() {
/*  33 */     return "RegExp";
/*     */   }
/*     */   private static final int Id_QUOTE = 12; private static final int DOLLAR_ID_BASE = 12; private static final int Id_DOLLAR_1 = 13; private static final int Id_DOLLAR_2 = 14; private static final int Id_DOLLAR_3 = 15; private static final int Id_DOLLAR_4 = 16; private static final int Id_DOLLAR_5 = 17; private static final int Id_DOLLAR_6 = 18; private static final int Id_DOLLAR_7 = 19; private static final int Id_DOLLAR_8 = 20; private static final int Id_DOLLAR_9 = 21; private static final int MAX_INSTANCE_ID = 21;
/*     */   
/*     */   public int getLength() {
/*  38 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArity() {
/*  43 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  48 */     if (args.length > 0 && args[0] instanceof NativeRegExp && (args.length == 1 || args[1] == Undefined.instance))
/*     */     {
/*     */       
/*  51 */       return args[0];
/*     */     }
/*  53 */     return construct(cx, scope, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/*  58 */     NativeRegExp re = NativeRegExpInstantiator.withLanguageVersion(cx.getLanguageVersion());
/*  59 */     re.compile(cx, scope, args);
/*  60 */     ScriptRuntime.setBuiltinProtoAndParent((ScriptableObject)re, scope, TopLevel.Builtins.RegExp);
/*  61 */     return (Scriptable)re;
/*     */   }
/*     */   
/*     */   private static RegExpImpl getImpl() {
/*  65 */     Context cx = Context.getCurrentContext();
/*  66 */     return (RegExpImpl)ScriptRuntime.getRegExpProxy(cx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxInstanceId() {
/*  95 */     return super.getMaxInstanceId() + 21;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(String s) {
/*     */     int id;
/* 101 */     switch (s) {
/*     */       case "multiline":
/* 103 */         id = 1;
/*     */         break;
/*     */       case "$*":
/* 106 */         id = 2;
/*     */         break;
/*     */       case "input":
/* 109 */         id = 3;
/*     */         break;
/*     */       case "$_":
/* 112 */         id = 4;
/*     */         break;
/*     */       case "lastMatch":
/* 115 */         id = 5;
/*     */         break;
/*     */       case "$&":
/* 118 */         id = 6;
/*     */         break;
/*     */       case "lastParen":
/* 121 */         id = 7;
/*     */         break;
/*     */       case "$+":
/* 124 */         id = 8;
/*     */         break;
/*     */       case "leftContext":
/* 127 */         id = 9;
/*     */         break;
/*     */       case "$`":
/* 130 */         id = 10;
/*     */         break;
/*     */       case "rightContext":
/* 133 */         id = 11;
/*     */         break;
/*     */       case "$'":
/* 136 */         id = 12;
/*     */         break;
/*     */       case "$1":
/* 139 */         id = 13;
/*     */         break;
/*     */       case "$2":
/* 142 */         id = 14;
/*     */         break;
/*     */       case "$3":
/* 145 */         id = 15;
/*     */         break;
/*     */       case "$4":
/* 148 */         id = 16;
/*     */         break;
/*     */       case "$5":
/* 151 */         id = 17;
/*     */         break;
/*     */       case "$6":
/* 154 */         id = 18;
/*     */         break;
/*     */       case "$7":
/* 157 */         id = 19;
/*     */         break;
/*     */       case "$8":
/* 160 */         id = 20;
/*     */         break;
/*     */       case "$9":
/* 163 */         id = 21;
/*     */         break;
/*     */       default:
/* 166 */         id = 0;
/*     */         break;
/*     */     } 
/*     */     
/* 170 */     if (id == 0) return super.findInstanceIdInfo(s);
/*     */ 
/*     */     
/* 173 */     switch (id)
/*     */     { case 1:
/* 175 */         attr = this.multilineAttr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 191 */         return instanceIdInfo(attr, super.getMaxInstanceId() + id);case 2: attr = this.starAttr; return instanceIdInfo(attr, super.getMaxInstanceId() + id);case 3: attr = this.inputAttr; return instanceIdInfo(attr, super.getMaxInstanceId() + id);case 4: attr = this.underscoreAttr; return instanceIdInfo(attr, super.getMaxInstanceId() + id); }  int attr = 5; return instanceIdInfo(attr, super.getMaxInstanceId() + id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/* 196 */     int shifted = id - super.getMaxInstanceId();
/* 197 */     if (1 <= shifted && shifted <= 21) {
/* 198 */       switch (shifted) {
/*     */         case 1:
/* 200 */           return "multiline";
/*     */         case 2:
/* 202 */           return "$*";
/*     */         
/*     */         case 3:
/* 205 */           return "input";
/*     */         case 4:
/* 207 */           return "$_";
/*     */         
/*     */         case 5:
/* 210 */           return "lastMatch";
/*     */         case 6:
/* 212 */           return "$&";
/*     */         
/*     */         case 7:
/* 215 */           return "lastParen";
/*     */         case 8:
/* 217 */           return "$+";
/*     */         
/*     */         case 9:
/* 220 */           return "leftContext";
/*     */         case 10:
/* 222 */           return "$`";
/*     */         
/*     */         case 11:
/* 225 */           return "rightContext";
/*     */         case 12:
/* 227 */           return "$'";
/*     */       } 
/*     */       
/* 230 */       int substring_number = shifted - 12 - 1;
/* 231 */       char[] buf = { '$', (char)(49 + substring_number) };
/* 232 */       return new String(buf);
/*     */     } 
/* 234 */     return super.getInstanceIdName(id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/* 239 */     int shifted = id - super.getMaxInstanceId();
/* 240 */     if (1 <= shifted && shifted <= 21) {
/* 241 */       Object stringResult; int substring_number; RegExpImpl impl = getImpl();
/*     */       
/* 243 */       switch (shifted) {
/*     */         case 1:
/*     */         case 2:
/* 246 */           return ScriptRuntime.wrapBoolean(impl.multiline);
/*     */         
/*     */         case 3:
/*     */         case 4:
/* 250 */           stringResult = impl.input;
/*     */           break;
/*     */         
/*     */         case 5:
/*     */         case 6:
/* 255 */           stringResult = impl.lastMatch;
/*     */           break;
/*     */         
/*     */         case 7:
/*     */         case 8:
/* 260 */           stringResult = impl.lastParen;
/*     */           break;
/*     */         
/*     */         case 9:
/*     */         case 10:
/* 265 */           stringResult = impl.leftContext;
/*     */           break;
/*     */         
/*     */         case 11:
/*     */         case 12:
/* 270 */           stringResult = impl.rightContext;
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 276 */           substring_number = shifted - 12 - 1;
/* 277 */           stringResult = impl.getParenSubString(substring_number);
/*     */           break;
/*     */       } 
/*     */       
/* 281 */       return (stringResult == null) ? "" : stringResult.toString();
/*     */     } 
/* 283 */     return super.getInstanceIdValue(id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setInstanceIdValue(int id, Object value) {
/* 288 */     int shifted = id - super.getMaxInstanceId();
/* 289 */     switch (shifted) {
/*     */       case 1:
/*     */       case 2:
/* 292 */         (getImpl()).multiline = ScriptRuntime.toBoolean(value);
/*     */         return;
/*     */       
/*     */       case 3:
/*     */       case 4:
/* 297 */         (getImpl()).input = ScriptRuntime.toString(value);
/*     */         return;
/*     */       
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/*     */       case 12:
/*     */         return;
/*     */     } 
/* 310 */     int substring_number = shifted - 12 - 1;
/* 311 */     if (0 <= substring_number && substring_number <= 8) {
/*     */       return;
/*     */     }
/*     */     
/* 315 */     super.setInstanceIdValue(id, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setInstanceIdAttributes(int id, int attr) {
/* 320 */     int shifted = id - super.getMaxInstanceId();
/* 321 */     switch (shifted) {
/*     */       case 1:
/* 323 */         this.multilineAttr = attr;
/*     */         return;
/*     */       case 2:
/* 326 */         this.starAttr = attr;
/*     */         return;
/*     */       case 3:
/* 329 */         this.inputAttr = attr;
/*     */         return;
/*     */       case 4:
/* 332 */         this.underscoreAttr = attr;
/*     */         return;
/*     */       
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/*     */       case 12:
/*     */         return;
/*     */     } 
/*     */     
/* 346 */     int substring_number = shifted - 12 - 1;
/* 347 */     if (0 <= substring_number && substring_number <= 8) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 352 */     super.setInstanceIdAttributes(id, attr);
/*     */   }
/*     */   
/* 355 */   private int multilineAttr = 4;
/* 356 */   private int starAttr = 4;
/* 357 */   private int inputAttr = 4;
/* 358 */   private int underscoreAttr = 4;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\regexp\NativeRegExpCtor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */