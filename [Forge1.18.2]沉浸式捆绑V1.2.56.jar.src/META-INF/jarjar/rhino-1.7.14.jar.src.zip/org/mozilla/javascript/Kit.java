/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Kit
/*     */ {
/*     */   public static Class<?> classOrNull(String className) {
/*     */     
/*  19 */     try { return Class.forName(className); }
/*  20 */     catch (ClassNotFoundException classNotFoundException) {  }
/*  21 */     catch (SecurityException securityException) {  }
/*  22 */     catch (LinkageError linkageError) {  }
/*  23 */     catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */     
/*  27 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Class<?> classOrNull(ClassLoader loader, String className) {
/*     */     
/*  33 */     try { return loader.loadClass(className); }
/*  34 */     catch (ClassNotFoundException classNotFoundException) {  }
/*  35 */     catch (SecurityException securityException) {  }
/*  36 */     catch (LinkageError linkageError) {  }
/*  37 */     catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */     
/*  41 */     return null;
/*     */   }
/*     */   
/*     */   static Object newInstanceOrNull(Class<?> cl) {
/*     */     
/*  46 */     try { return cl.newInstance(); }
/*  47 */     catch (SecurityException securityException) {  }
/*  48 */     catch (LinkageError linkageError) {  }
/*  49 */     catch (InstantiationException instantiationException) {  }
/*  50 */     catch (IllegalAccessException illegalAccessException) {}
/*     */     
/*  52 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean testIfCanLoadRhinoClasses(ClassLoader loader) {
/*  57 */     Class<?> testClass = ScriptRuntime.ContextFactoryClass;
/*  58 */     Class<?> x = classOrNull(loader, testClass.getName());
/*  59 */     if (x != testClass)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  64 */       return false;
/*     */     }
/*  66 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int xDigitToInt(int c, int accumulator) {
/*  77 */     if (c <= 57)
/*  78 */     { c -= 48;
/*  79 */       if (0 <= c)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  95 */         return accumulator << 4 | c; }  } else { if (c <= 70) { if (65 <= c) { c -= 55; } else { return -1; }  } else if (c <= 102 && 97 <= c) { c -= 87; } else { return -1; }  return accumulator << 4 | c; }
/*     */     
/*     */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object addListener(Object bag, Object listener) {
/* 146 */     if (listener == null) throw new IllegalArgumentException(); 
/* 147 */     if (listener instanceof Object[]) throw new IllegalArgumentException();
/*     */     
/* 149 */     if (bag == null) {
/* 150 */       bag = listener;
/* 151 */     } else if (!(bag instanceof Object[])) {
/* 152 */       bag = new Object[] { bag, listener };
/*     */     } else {
/* 154 */       Object[] array = (Object[])bag;
/* 155 */       int L = array.length;
/*     */       
/* 157 */       if (L < 2) throw new IllegalArgumentException(); 
/* 158 */       Object[] tmp = new Object[L + 1];
/* 159 */       System.arraycopy(array, 0, tmp, 0, L);
/* 160 */       tmp[L] = listener;
/* 161 */       bag = tmp;
/*     */     } 
/*     */     
/* 164 */     return bag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object removeListener(Object bag, Object listener) {
/* 181 */     if (listener == null) throw new IllegalArgumentException(); 
/* 182 */     if (listener instanceof Object[]) throw new IllegalArgumentException();
/*     */     
/* 184 */     if (bag == listener) {
/* 185 */       bag = null;
/* 186 */     } else if (bag instanceof Object[]) {
/* 187 */       Object[] array = (Object[])bag;
/* 188 */       int L = array.length;
/*     */       
/* 190 */       if (L < 2) throw new IllegalArgumentException(); 
/* 191 */       if (L == 2) {
/* 192 */         if (array[1] == listener) {
/* 193 */           bag = array[0];
/* 194 */         } else if (array[0] == listener) {
/* 195 */           bag = array[1];
/*     */         } 
/*     */       } else {
/* 198 */         int i = L;
/*     */         do {
/* 200 */           i--;
/* 201 */           if (array[i] == listener) {
/* 202 */             Object[] tmp = new Object[L - 1];
/* 203 */             System.arraycopy(array, 0, tmp, 0, i);
/* 204 */             System.arraycopy(array, i + 1, tmp, i, L - i + 1);
/* 205 */             bag = tmp;
/*     */             break;
/*     */           } 
/* 208 */         } while (i != 0);
/*     */       } 
/*     */     } 
/*     */     
/* 212 */     return bag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getListener(Object bag, int index) {
/* 228 */     if (index == 0) {
/* 229 */       if (bag == null) return null; 
/* 230 */       if (!(bag instanceof Object[])) return bag; 
/* 231 */       Object[] arrayOfObject = (Object[])bag;
/*     */       
/* 233 */       if (arrayOfObject.length < 2) throw new IllegalArgumentException(); 
/* 234 */       return arrayOfObject[0];
/* 235 */     }  if (index == 1) {
/* 236 */       if (!(bag instanceof Object[])) {
/* 237 */         if (bag == null) throw new IllegalArgumentException(); 
/* 238 */         return null;
/*     */       } 
/* 240 */       Object[] arrayOfObject = (Object[])bag;
/*     */       
/* 242 */       return arrayOfObject[1];
/*     */     } 
/*     */     
/* 245 */     Object[] array = (Object[])bag;
/* 246 */     int L = array.length;
/* 247 */     if (L < 2) throw new IllegalArgumentException(); 
/* 248 */     if (index == L) return null; 
/* 249 */     return array[index];
/*     */   }
/*     */ 
/*     */   
/*     */   static Object initHash(Map<Object, Object> h, Object key, Object initialValue) {
/* 254 */     synchronized (h) {
/* 255 */       Object current = h.get(key);
/* 256 */       if (current == null) {
/* 257 */         h.put(key, initialValue);
/*     */       } else {
/* 259 */         initialValue = current;
/*     */       } 
/*     */     } 
/* 262 */     return initialValue;
/*     */   }
/*     */   
/*     */   private static final class ComplexKey {
/*     */     private Object key1;
/*     */     private Object key2;
/*     */     private int hash;
/*     */     
/*     */     ComplexKey(Object key1, Object key2) {
/* 271 */       this.key1 = key1;
/* 272 */       this.key2 = key2;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object anotherObj) {
/* 277 */       if (!(anotherObj instanceof ComplexKey)) return false; 
/* 278 */       ComplexKey another = (ComplexKey)anotherObj;
/* 279 */       return (this.key1.equals(another.key1) && this.key2.equals(another.key2));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 284 */       if (this.hash == 0) {
/* 285 */         this.hash = this.key1.hashCode() ^ this.key2.hashCode();
/*     */       }
/* 287 */       return this.hash;
/*     */     }
/*     */   }
/*     */   
/*     */   public static Object makeHashKeyFromPair(Object key1, Object key2) {
/* 292 */     if (key1 == null) throw new IllegalArgumentException(); 
/* 293 */     if (key2 == null) throw new IllegalArgumentException(); 
/* 294 */     return new ComplexKey(key1, key2);
/*     */   }
/*     */   
/*     */   public static String readReader(Reader reader) throws IOException {
/* 298 */     try (BufferedReader in = new BufferedReader(reader)) {
/* 299 */       char[] cbuf = new char[1024];
/* 300 */       StringBuilder sb = new StringBuilder(1024);
/*     */       int bytes_read;
/* 302 */       while ((bytes_read = in.read(cbuf, 0, 1024)) != -1) {
/* 303 */         sb.append(cbuf, 0, bytes_read);
/*     */       }
/* 305 */       return sb.toString();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte[] readStream(InputStream is, int initialBufferCapacity) throws IOException {
/* 310 */     if (initialBufferCapacity <= 0) {
/* 311 */       throw new IllegalArgumentException("Bad initialBufferCapacity: " + initialBufferCapacity);
/*     */     }
/*     */     
/* 314 */     byte[] buffer = new byte[initialBufferCapacity];
/* 315 */     int cursor = 0;
/*     */     while (true) {
/* 317 */       int n = is.read(buffer, cursor, buffer.length - cursor);
/* 318 */       if (n < 0) {
/*     */         break;
/*     */       }
/* 321 */       cursor += n;
/* 322 */       if (cursor == buffer.length) {
/* 323 */         int readahead = -1;
/* 324 */         if (cursor == initialBufferCapacity) {
/* 325 */           readahead = is.read();
/* 326 */           if (readahead < 0) {
/* 327 */             return buffer;
/*     */           }
/*     */         } 
/* 330 */         byte[] tmp = new byte[buffer.length * 2];
/* 331 */         System.arraycopy(buffer, 0, tmp, 0, cursor);
/* 332 */         buffer = tmp;
/* 333 */         if (readahead != -1) {
/* 334 */           buffer[cursor++] = (byte)readahead;
/* 335 */           readahead = -1;
/*     */         } 
/*     */       } 
/*     */     } 
/* 339 */     if (cursor != buffer.length) {
/* 340 */       byte[] tmp = new byte[cursor];
/* 341 */       System.arraycopy(buffer, 0, tmp, 0, cursor);
/* 342 */       buffer = tmp;
/*     */     } 
/* 344 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException codeBug() throws RuntimeException {
/* 353 */     RuntimeException ex = new IllegalStateException("FAILED ASSERTION");
/*     */     
/* 355 */     ex.printStackTrace(System.err);
/* 356 */     throw ex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException codeBug(String msg) throws RuntimeException {
/* 365 */     msg = "FAILED ASSERTION: " + msg;
/* 366 */     RuntimeException ex = new IllegalStateException(msg);
/*     */     
/* 368 */     ex.printStackTrace(System.err);
/* 369 */     throw ex;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Kit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */