/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.math.BigInteger;
/*      */ import java.util.List;
/*      */ import org.mozilla.javascript.ast.AstNode;
/*      */ import org.mozilla.javascript.ast.FunctionNode;
/*      */ import org.mozilla.javascript.ast.Jump;
/*      */ import org.mozilla.javascript.ast.ScriptNode;
/*      */ import org.mozilla.javascript.ast.TemplateCharacters;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class CodeGenerator
/*      */   extends Icode
/*      */ {
/*      */   private static final int MIN_LABEL_TABLE_SIZE = 32;
/*      */   private static final int MIN_FIXUP_TABLE_SIZE = 40;
/*      */   private CompilerEnvirons compilerEnv;
/*      */   private boolean itsInFunctionFlag;
/*      */   private boolean itsInTryFlag;
/*      */   private InterpreterData itsData;
/*      */   private ScriptNode scriptOrFn;
/*      */   private int iCodeTop;
/*      */   private int stackDepth;
/*      */   private int lineNumber;
/*      */   private int doubleTableTop;
/*   40 */   private ObjToIntMap strings = new ObjToIntMap(20);
/*   41 */   private ObjToIntMap bigInts = new ObjToIntMap(20);
/*      */   
/*      */   private int localTop;
/*      */   
/*      */   private int[] labelTable;
/*      */   private int labelTableTop;
/*      */   private long[] fixupTable;
/*      */   private int fixupTableTop;
/*   49 */   private ObjArray literalIds = new ObjArray();
/*      */ 
/*      */ 
/*      */   
/*      */   private int exceptionTableTop;
/*      */ 
/*      */   
/*      */   private static final int ECF_TAIL = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   public InterpreterData compile(CompilerEnvirons compilerEnv, ScriptNode tree, String encodedSource, boolean returnFunction) {
/*   61 */     this.compilerEnv = compilerEnv;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   68 */     (new NodeTransformer()).transform(tree, compilerEnv);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   75 */     if (returnFunction) {
/*   76 */       this.scriptOrFn = (ScriptNode)tree.getFunctionNode(0);
/*      */     } else {
/*   78 */       this.scriptOrFn = tree;
/*      */     } 
/*      */     
/*   81 */     this
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   86 */       .itsData = new InterpreterData(compilerEnv.getLanguageVersion(), this.scriptOrFn.getSourceName(), encodedSource, this.scriptOrFn.isInStrictMode());
/*   87 */     this.itsData.topLevel = true;
/*      */     
/*   89 */     if (returnFunction) {
/*   90 */       generateFunctionICode();
/*      */     } else {
/*   92 */       generateICodeFromTree((Node)this.scriptOrFn);
/*      */     } 
/*   94 */     return this.itsData;
/*      */   }
/*      */   
/*      */   private void generateFunctionICode() {
/*   98 */     this.itsInFunctionFlag = true;
/*      */     
/*  100 */     FunctionNode theFunction = (FunctionNode)this.scriptOrFn;
/*      */     
/*  102 */     this.itsData.itsFunctionType = theFunction.getFunctionType();
/*  103 */     this.itsData.itsNeedsActivation = theFunction.requiresActivation();
/*  104 */     if (theFunction.getFunctionName() != null) {
/*  105 */       this.itsData.itsName = theFunction.getName();
/*      */     }
/*  107 */     if (theFunction.isGenerator()) {
/*  108 */       addIcode(-62);
/*  109 */       addUint16(theFunction.getBaseLineno() & 0xFFFF);
/*      */     } 
/*  111 */     if (theFunction.isInStrictMode()) {
/*  112 */       this.itsData.isStrict = true;
/*      */     }
/*  114 */     if (theFunction.isES6Generator()) {
/*  115 */       this.itsData.isES6Generator = true;
/*      */     }
/*      */     
/*  118 */     this.itsData.declaredAsVar = theFunction.getParent() instanceof org.mozilla.javascript.ast.VariableInitializer;
/*      */     
/*  120 */     generateICodeFromTree(theFunction.getLastChild());
/*      */   }
/*      */   
/*      */   private void generateICodeFromTree(Node tree) {
/*  124 */     generateNestedFunctions();
/*      */     
/*  126 */     generateRegExpLiterals();
/*      */     
/*  128 */     generateTemplateLiterals();
/*      */     
/*  130 */     visitStatement(tree, 0);
/*  131 */     fixLabelGotos();
/*      */     
/*  133 */     if (this.itsData.itsFunctionType == 0) {
/*  134 */       addToken(65);
/*      */     }
/*      */     
/*  137 */     if (this.itsData.itsICode.length != this.iCodeTop) {
/*      */ 
/*      */       
/*  140 */       byte[] tmp = new byte[this.iCodeTop];
/*  141 */       System.arraycopy(this.itsData.itsICode, 0, tmp, 0, this.iCodeTop);
/*  142 */       this.itsData.itsICode = tmp;
/*      */     } 
/*  144 */     if (this.strings.size() == 0) {
/*  145 */       this.itsData.itsStringTable = null;
/*      */     } else {
/*  147 */       this.itsData.itsStringTable = new String[this.strings.size()];
/*  148 */       ObjToIntMap.Iterator iter = this.strings.newIterator();
/*  149 */       iter.start(); for (; !iter.done(); iter.next()) {
/*  150 */         String str = (String)iter.getKey();
/*  151 */         int index = iter.getValue();
/*  152 */         if (this.itsData.itsStringTable[index] != null) Kit.codeBug(); 
/*  153 */         this.itsData.itsStringTable[index] = str;
/*      */       } 
/*      */     } 
/*  156 */     if (this.doubleTableTop == 0) {
/*  157 */       this.itsData.itsDoubleTable = null;
/*  158 */     } else if (this.itsData.itsDoubleTable.length != this.doubleTableTop) {
/*  159 */       double[] tmp = new double[this.doubleTableTop];
/*  160 */       System.arraycopy(this.itsData.itsDoubleTable, 0, tmp, 0, this.doubleTableTop);
/*  161 */       this.itsData.itsDoubleTable = tmp;
/*      */     } 
/*  163 */     if (this.bigInts.size() == 0) {
/*  164 */       this.itsData.itsBigIntTable = null;
/*      */     } else {
/*  166 */       this.itsData.itsBigIntTable = new BigInteger[this.bigInts.size()];
/*  167 */       ObjToIntMap.Iterator iter = this.bigInts.newIterator();
/*  168 */       iter.start(); for (; !iter.done(); iter.next()) {
/*  169 */         BigInteger bigInt = (BigInteger)iter.getKey();
/*  170 */         int index = iter.getValue();
/*  171 */         if (this.itsData.itsBigIntTable[index] != null) Kit.codeBug(); 
/*  172 */         this.itsData.itsBigIntTable[index] = bigInt;
/*      */       } 
/*      */     } 
/*  175 */     if (this.exceptionTableTop != 0 && this.itsData.itsExceptionTable.length != this.exceptionTableTop) {
/*  176 */       int[] tmp = new int[this.exceptionTableTop];
/*  177 */       System.arraycopy(this.itsData.itsExceptionTable, 0, tmp, 0, this.exceptionTableTop);
/*  178 */       this.itsData.itsExceptionTable = tmp;
/*      */     } 
/*      */     
/*  181 */     this.itsData.itsMaxVars = this.scriptOrFn.getParamAndVarCount();
/*      */ 
/*      */     
/*  184 */     this.itsData.itsMaxFrameArray = this.itsData.itsMaxVars + this.itsData.itsMaxLocals + this.itsData.itsMaxStack;
/*      */     
/*  186 */     this.itsData.argNames = this.scriptOrFn.getParamAndVarNames();
/*  187 */     this.itsData.argIsConst = this.scriptOrFn.getParamAndVarConst();
/*  188 */     this.itsData.argCount = this.scriptOrFn.getParamCount();
/*      */     
/*  190 */     this.itsData.encodedSourceStart = this.scriptOrFn.getEncodedSourceStart();
/*  191 */     this.itsData.encodedSourceEnd = this.scriptOrFn.getEncodedSourceEnd();
/*      */     
/*  193 */     if (this.literalIds.size() != 0) {
/*  194 */       this.itsData.literalIds = this.literalIds.toArray();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateNestedFunctions() {
/*  201 */     int functionCount = this.scriptOrFn.getFunctionCount();
/*  202 */     if (functionCount == 0)
/*      */       return; 
/*  204 */     InterpreterData[] array = new InterpreterData[functionCount];
/*  205 */     for (int i = 0; i != functionCount; i++) {
/*  206 */       FunctionNode fn = this.scriptOrFn.getFunctionNode(i);
/*  207 */       CodeGenerator gen = new CodeGenerator();
/*  208 */       gen.compilerEnv = this.compilerEnv;
/*  209 */       gen.scriptOrFn = (ScriptNode)fn;
/*  210 */       gen.itsData = new InterpreterData(this.itsData);
/*  211 */       gen.generateFunctionICode();
/*  212 */       array[i] = gen.itsData;
/*      */       
/*  214 */       AstNode fnParent = fn.getParent();
/*  215 */       if (!(fnParent instanceof org.mozilla.javascript.ast.AstRoot) && !(fnParent instanceof org.mozilla.javascript.ast.Scope) && !(fnParent instanceof org.mozilla.javascript.ast.Block))
/*      */       {
/*      */         
/*  218 */         gen.itsData.declaredAsFunctionExpression = true;
/*      */       }
/*      */     } 
/*  221 */     this.itsData.itsNestedFunctions = array;
/*      */   }
/*      */   
/*      */   private void generateRegExpLiterals() {
/*  225 */     int N = this.scriptOrFn.getRegexpCount();
/*  226 */     if (N == 0)
/*      */       return; 
/*  228 */     Context cx = Context.getContext();
/*  229 */     RegExpProxy rep = ScriptRuntime.checkRegExpProxy(cx);
/*  230 */     Object[] array = new Object[N];
/*  231 */     for (int i = 0; i != N; i++) {
/*  232 */       String string = this.scriptOrFn.getRegexpString(i);
/*  233 */       String flags = this.scriptOrFn.getRegexpFlags(i);
/*  234 */       array[i] = rep.compileRegExp(cx, string, flags);
/*      */     } 
/*  236 */     this.itsData.itsRegExpLiterals = array;
/*      */   }
/*      */   
/*      */   private void generateTemplateLiterals() {
/*  240 */     int N = this.scriptOrFn.getTemplateLiteralCount();
/*  241 */     if (N == 0)
/*      */       return; 
/*  243 */     Object[] array = new Object[N];
/*  244 */     for (int i = 0; i != N; i++) {
/*  245 */       List<TemplateCharacters> strings = this.scriptOrFn.getTemplateLiteralStrings(i);
/*  246 */       int j = 0;
/*  247 */       String[] values = new String[strings.size() * 2];
/*  248 */       for (TemplateCharacters s : strings) {
/*  249 */         values[j++] = s.getValue();
/*  250 */         values[j++] = s.getRawValue();
/*      */       } 
/*  252 */       array[i] = values;
/*      */     } 
/*  254 */     this.itsData.itsTemplateLiterals = array;
/*      */   }
/*      */   
/*      */   private void updateLineNumber(Node node) {
/*  258 */     int lineno = node.getLineno();
/*  259 */     if (lineno != this.lineNumber && lineno >= 0) {
/*  260 */       if (this.itsData.firstLinePC < 0) {
/*  261 */         this.itsData.firstLinePC = lineno;
/*      */       }
/*  263 */       this.lineNumber = lineno;
/*  264 */       addIcode(-26);
/*  265 */       addUint16(lineno & 0xFFFF);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static RuntimeException badTree(Node node) {
/*  270 */     throw new RuntimeException(node.toString()); } private void visitStatement(Node node, int initialStackDepth) { int fnIndex, local; Jump caseNode; Node target; int finallyRegister; Jump tryNode; int localIndex, fnType, exceptionObjectLocal, scopeIndex, scopeLocal; String name;
/*      */     int tryStart;
/*      */     boolean savedFlag;
/*      */     Node catchTarget, finallyTarget;
/*  274 */     int type = node.getType();
/*  275 */     Node child = node.getFirstChild();
/*  276 */     switch (type) {
/*      */       
/*      */       case 113:
/*  279 */         fnIndex = node.getExistingIntProp(1);
/*  280 */         fnType = this.scriptOrFn.getFunctionNode(fnIndex).getFunctionType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  287 */         if (fnType == 3) {
/*  288 */           addIndexOp(-20, fnIndex);
/*      */         }
/*  290 */         else if (fnType != 1) {
/*  291 */           throw Kit.codeBug();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  299 */         if (!this.itsInFunctionFlag) {
/*  300 */           addIndexOp(-19, fnIndex);
/*  301 */           stackChange(1);
/*  302 */           addIcode(-5);
/*  303 */           stackChange(-1);
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 127:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 136:
/*  313 */         updateLineNumber(node);
/*      */       
/*      */       case 140:
/*  316 */         while (child != null) {
/*  317 */           visitStatement(child, initialStackDepth);
/*  318 */           child = child.getNext();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 2:
/*  323 */         visitExpression(child, 0);
/*  324 */         addToken(2);
/*  325 */         stackChange(-1);
/*      */         break;
/*      */       
/*      */       case 3:
/*  329 */         addToken(3);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 145:
/*  334 */         local = allocLocal();
/*  335 */         node.putIntProp(2, local);
/*  336 */         updateLineNumber(node);
/*  337 */         while (child != null) {
/*  338 */           visitStatement(child, initialStackDepth);
/*  339 */           child = child.getNext();
/*      */         } 
/*  341 */         addIndexOp(-56, local);
/*  342 */         releaseLocal(local);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 164:
/*  347 */         addIcode(-64);
/*      */         break;
/*      */       
/*      */       case 118:
/*  351 */         updateLineNumber(node);
/*      */ 
/*      */ 
/*      */         
/*  355 */         visitExpression(child, 0);
/*  356 */         caseNode = (Jump)child.getNext();
/*  357 */         for (; caseNode != null; 
/*  358 */           caseNode = (Jump)caseNode.getNext()) {
/*  359 */           if (caseNode.getType() != 119) throw badTree(caseNode); 
/*  360 */           Node test = caseNode.getFirstChild();
/*  361 */           addIcode(-1);
/*  362 */           stackChange(1);
/*  363 */           visitExpression(test, 0);
/*  364 */           addToken(46);
/*  365 */           stackChange(-1);
/*      */ 
/*      */           
/*  368 */           addGoto(caseNode.target, -6);
/*  369 */           stackChange(-1);
/*      */         } 
/*  371 */         addIcode(-4);
/*  372 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 135:
/*  377 */         markTargetLabel(node);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*  383 */         target = ((Jump)node).target;
/*  384 */         visitExpression(child, 0);
/*  385 */         addGoto(target, type);
/*  386 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/*  392 */         target = ((Jump)node).target;
/*  393 */         addGoto(target, type);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 139:
/*  399 */         target = ((Jump)node).target;
/*  400 */         addGoto(target, -23);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 129:
/*  407 */         stackChange(1);
/*  408 */         finallyRegister = getLocalBlockRef(node);
/*  409 */         addIndexOp(-24, finallyRegister);
/*  410 */         stackChange(-1);
/*  411 */         while (child != null) {
/*  412 */           visitStatement(child, initialStackDepth);
/*  413 */           child = child.getNext();
/*      */         } 
/*  415 */         addIndexOp(-25, finallyRegister);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 137:
/*      */       case 138:
/*  421 */         updateLineNumber(node);
/*  422 */         visitExpression(child, 0);
/*  423 */         addIcode((type == 137) ? -4 : -5);
/*  424 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 84:
/*  429 */         tryNode = (Jump)node;
/*  430 */         exceptionObjectLocal = getLocalBlockRef((Node)tryNode);
/*  431 */         scopeLocal = allocLocal();
/*      */         
/*  433 */         addIndexOp(-13, scopeLocal);
/*      */         
/*  435 */         tryStart = this.iCodeTop;
/*  436 */         savedFlag = this.itsInTryFlag;
/*  437 */         this.itsInTryFlag = true;
/*  438 */         while (child != null) {
/*  439 */           visitStatement(child, initialStackDepth);
/*  440 */           child = child.getNext();
/*      */         } 
/*  442 */         this.itsInTryFlag = savedFlag;
/*      */         
/*  444 */         catchTarget = tryNode.target;
/*  445 */         if (catchTarget != null) {
/*  446 */           int catchStartPC = this.labelTable[getTargetLabel(catchTarget)];
/*  447 */           addExceptionHandler(tryStart, catchStartPC, catchStartPC, false, exceptionObjectLocal, scopeLocal);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  455 */         finallyTarget = tryNode.getFinally();
/*  456 */         if (finallyTarget != null) {
/*  457 */           int finallyStartPC = this.labelTable[getTargetLabel(finallyTarget)];
/*  458 */           addExceptionHandler(tryStart, finallyStartPC, finallyStartPC, true, exceptionObjectLocal, scopeLocal);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  467 */         addIndexOp(-56, scopeLocal);
/*  468 */         releaseLocal(scopeLocal);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 57:
/*  474 */         localIndex = getLocalBlockRef(node);
/*  475 */         scopeIndex = node.getExistingIntProp(14);
/*  476 */         name = child.getString();
/*  477 */         child = child.getNext();
/*  478 */         visitExpression(child, 0);
/*  479 */         addStringPrefix(name);
/*  480 */         addIndexPrefix(localIndex);
/*  481 */         addToken(57);
/*  482 */         addUint8((scopeIndex != 0) ? 1 : 0);
/*  483 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 50:
/*  488 */         updateLineNumber(node);
/*  489 */         visitExpression(child, 0);
/*  490 */         addToken(50);
/*  491 */         addUint16(this.lineNumber & 0xFFFF);
/*  492 */         stackChange(-1);
/*      */         break;
/*      */       
/*      */       case 51:
/*  496 */         updateLineNumber(node);
/*  497 */         addIndexOp(51, getLocalBlockRef(node));
/*      */         break;
/*      */       
/*      */       case 4:
/*  501 */         updateLineNumber(node);
/*  502 */         if (node.getIntProp(20, 0) != 0) {
/*  503 */           if (child == null || this.compilerEnv
/*  504 */             .getLanguageVersion() < 200) {
/*      */ 
/*      */             
/*  507 */             addIcode(-63);
/*  508 */             addUint16(this.lineNumber & 0xFFFF); break;
/*      */           } 
/*  510 */           visitExpression(child, 1);
/*  511 */           addIcode(-65);
/*  512 */           addUint16(this.lineNumber & 0xFFFF);
/*  513 */           stackChange(-1);
/*      */           
/*      */           break;
/*      */         } 
/*  517 */         if (child == null) {
/*  518 */           addIcode(-22); break;
/*      */         } 
/*  520 */         visitExpression(child, 1);
/*  521 */         addToken(4);
/*  522 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 65:
/*  528 */         updateLineNumber(node);
/*  529 */         addToken(65);
/*      */         break;
/*      */       
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*  536 */         visitExpression(child, 0);
/*  537 */         addIndexOp(type, getLocalBlockRef(node));
/*  538 */         stackChange(-1);
/*      */         break;
/*      */       
/*      */       case -62:
/*      */         break;
/*      */       
/*      */       default:
/*  545 */         throw badTree(node);
/*      */     } 
/*      */     
/*  548 */     if (this.stackDepth != initialStackDepth)
/*  549 */       throw Kit.codeBug();  } private void visitExpression(Node node, int contextFlags) { int fnIndex, localIndex; Node lastChild; int argCount, afterSecondJumpStart; Node ifThen; boolean isName; FunctionNode fn; int callType, jump; Node ifElse; String property, name; int i; double num;
/*      */     int index, memberTypeFlags, queryPC;
/*      */     Node enterWith;
/*      */     int elseJumpStart, childCount;
/*      */     Node with;
/*  554 */     int afterElseJumpStart, inum, type = node.getType();
/*  555 */     Node child = node.getFirstChild();
/*  556 */     int savedStackDepth = this.stackDepth;
/*  557 */     switch (type)
/*      */     
/*      */     { case 113:
/*  560 */         fnIndex = node.getExistingIntProp(1);
/*  561 */         fn = this.scriptOrFn.getFunctionNode(fnIndex);
/*      */         
/*  563 */         if (fn.getFunctionType() != 2 && fn
/*  564 */           .getFunctionType() != 4) {
/*  565 */           throw Kit.codeBug();
/*      */         }
/*  567 */         addIndexOp(-19, fnIndex);
/*  568 */         stackChange(1);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 54:
/*  574 */         localIndex = getLocalBlockRef(node);
/*  575 */         addIndexOp(54, localIndex);
/*  576 */         stackChange(1);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 92:
/*  582 */         lastChild = node.getLastChild();
/*  583 */         while (child != lastChild) {
/*  584 */           visitExpression(child, 0);
/*  585 */           addIcode(-4);
/*  586 */           stackChange(-1);
/*  587 */           child = child.getNext();
/*      */         } 
/*      */         
/*  590 */         visitExpression(child, contextFlags & 0x1);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 142:
/*  597 */         stackChange(1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 30:
/*      */       case 38:
/*      */       case 71:
/*  604 */         if (type == 30) {
/*  605 */           visitExpression(child, 0);
/*      */         } else {
/*  607 */           generateCallFunAndThis(child);
/*      */         } 
/*  609 */         argCount = 0;
/*  610 */         while ((child = child.getNext()) != null) {
/*  611 */           visitExpression(child, 0);
/*  612 */           argCount++;
/*      */         } 
/*  614 */         callType = node.getIntProp(10, 0);
/*  615 */         if (type != 71 && callType != 0) {
/*      */           
/*  617 */           addIndexOp(-21, argCount);
/*  618 */           addUint8(callType);
/*  619 */           addUint8((type == 30) ? 1 : 0);
/*  620 */           addUint16(this.lineNumber & 0xFFFF);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  625 */           if (type == 38 && (contextFlags & 0x1) != 0 && 
/*      */             
/*  627 */             !this.compilerEnv.isGenerateDebugInfo() && !this.itsInTryFlag)
/*      */           {
/*  629 */             type = -55;
/*      */           }
/*  631 */           addIndexOp(type, argCount);
/*      */         } 
/*      */         
/*  634 */         if (type == 30) {
/*      */           
/*  636 */           stackChange(-argCount);
/*      */         }
/*      */         else {
/*      */           
/*  640 */           stackChange(-1 - argCount);
/*      */         } 
/*  642 */         if (argCount > this.itsData.itsMaxCalleeArgs) {
/*  643 */           this.itsData.itsMaxCalleeArgs = argCount;
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 108:
/*      */       case 109:
/*  651 */         visitExpression(child, 0);
/*  652 */         addIcode(-1);
/*  653 */         stackChange(1);
/*  654 */         afterSecondJumpStart = this.iCodeTop;
/*  655 */         jump = (type == 109) ? 7 : 6;
/*  656 */         addGotoOp(jump);
/*  657 */         stackChange(-1);
/*  658 */         addIcode(-4);
/*  659 */         stackChange(-1);
/*  660 */         child = child.getNext();
/*      */         
/*  662 */         visitExpression(child, contextFlags & 0x1);
/*  663 */         resolveForwardGoto(afterSecondJumpStart);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 106:
/*  669 */         ifThen = child.getNext();
/*  670 */         ifElse = ifThen.getNext();
/*  671 */         visitExpression(child, 0);
/*  672 */         elseJumpStart = this.iCodeTop;
/*  673 */         addGotoOp(7);
/*  674 */         stackChange(-1);
/*      */         
/*  676 */         visitExpression(ifThen, contextFlags & 0x1);
/*  677 */         afterElseJumpStart = this.iCodeTop;
/*  678 */         addGotoOp(5);
/*  679 */         resolveForwardGoto(elseJumpStart);
/*  680 */         this.stackDepth = savedStackDepth;
/*      */         
/*  682 */         visitExpression(ifElse, contextFlags & 0x1);
/*  683 */         resolveForwardGoto(afterElseJumpStart);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 34:
/*  689 */         visitExpression(child, 0);
/*  690 */         child = child.getNext();
/*  691 */         addStringOp(type, child.getString());
/*      */         break;
/*      */       
/*      */       case 31:
/*  695 */         isName = (child.getType() == 49);
/*  696 */         visitExpression(child, 0);
/*  697 */         child = child.getNext();
/*  698 */         visitExpression(child, 0);
/*  699 */         if (isName) {
/*      */           
/*  701 */           addIcode(0);
/*      */         } else {
/*  703 */           addToken(31);
/*      */         } 
/*  705 */         stackChange(-1);
/*      */         break;
/*      */       
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 36:
/*      */       case 46:
/*      */       case 47:
/*      */       case 52:
/*      */       case 53:
/*      */       case 75:
/*  731 */         visitExpression(child, 0);
/*  732 */         child = child.getNext();
/*  733 */         visitExpression(child, 0);
/*  734 */         addToken(type);
/*  735 */         stackChange(-1);
/*      */         break;
/*      */       
/*      */       case 26:
/*      */       case 27:
/*      */       case 28:
/*      */       case 29:
/*      */       case 32:
/*      */       case 130:
/*  744 */         visitExpression(child, 0);
/*  745 */         if (type == 130) {
/*  746 */           addIcode(-4);
/*  747 */           addIcode(-50); break;
/*      */         } 
/*  749 */         addToken(type);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 68:
/*      */       case 70:
/*  755 */         visitExpression(child, 0);
/*  756 */         addToken(type);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 35:
/*      */       case 143:
/*  762 */         visitExpression(child, 0);
/*  763 */         child = child.getNext();
/*  764 */         property = child.getString();
/*  765 */         child = child.getNext();
/*  766 */         if (type == 143) {
/*  767 */           addIcode(-1);
/*  768 */           stackChange(1);
/*  769 */           addStringOp(33, property);
/*      */           
/*  771 */           stackChange(-1);
/*      */         } 
/*  773 */         visitExpression(child, 0);
/*  774 */         addStringOp(35, property);
/*  775 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 37:
/*      */       case 144:
/*  781 */         visitExpression(child, 0);
/*  782 */         child = child.getNext();
/*  783 */         visitExpression(child, 0);
/*  784 */         child = child.getNext();
/*  785 */         if (type == 144) {
/*  786 */           addIcode(-2);
/*  787 */           stackChange(2);
/*  788 */           addToken(36);
/*  789 */           stackChange(-1);
/*      */           
/*  791 */           stackChange(-1);
/*      */         } 
/*  793 */         visitExpression(child, 0);
/*  794 */         addToken(37);
/*  795 */         stackChange(-2);
/*      */         break;
/*      */       
/*      */       case 69:
/*      */       case 146:
/*  800 */         visitExpression(child, 0);
/*  801 */         child = child.getNext();
/*  802 */         if (type == 146) {
/*  803 */           addIcode(-1);
/*  804 */           stackChange(1);
/*  805 */           addToken(68);
/*      */           
/*  807 */           stackChange(-1);
/*      */         } 
/*  809 */         visitExpression(child, 0);
/*  810 */         addToken(69);
/*  811 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 8:
/*      */       case 74:
/*  817 */         name = child.getString();
/*  818 */         visitExpression(child, 0);
/*  819 */         child = child.getNext();
/*  820 */         visitExpression(child, 0);
/*  821 */         addStringOp(type, name);
/*  822 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 159:
/*  828 */         name = child.getString();
/*  829 */         visitExpression(child, 0);
/*  830 */         child = child.getNext();
/*  831 */         visitExpression(child, 0);
/*  832 */         addStringOp(-59, name);
/*  833 */         stackChange(-1);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 141:
/*  839 */         i = -1;
/*      */ 
/*      */         
/*  842 */         if (this.itsInFunctionFlag && !this.itsData.itsNeedsActivation)
/*  843 */           i = this.scriptOrFn.getIndexForNameNode(node); 
/*  844 */         if (i == -1) {
/*  845 */           addStringOp(-14, node.getString());
/*  846 */           stackChange(1); break;
/*      */         } 
/*  848 */         addVarOp(55, i);
/*  849 */         stackChange(1);
/*  850 */         addToken(32);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/*      */       case 41:
/*      */       case 49:
/*  858 */         addStringOp(type, node.getString());
/*  859 */         stackChange(1);
/*      */         break;
/*      */       
/*      */       case 110:
/*      */       case 111:
/*  864 */         visitIncDec(node, child);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 40:
/*  869 */         num = node.getDouble();
/*  870 */         inum = (int)num;
/*  871 */         if (inum == num) {
/*  872 */           if (inum == 0) {
/*  873 */             addIcode(-51);
/*      */             
/*  875 */             if (1.0D / num < 0.0D) {
/*  876 */               addToken(29);
/*      */             }
/*  878 */           } else if (inum == 1) {
/*  879 */             addIcode(-52);
/*  880 */           } else if ((short)inum == inum) {
/*  881 */             addIcode(-27);
/*      */             
/*  883 */             addUint16(inum & 0xFFFF);
/*      */           } else {
/*  885 */             addIcode(-28);
/*  886 */             addInt(inum);
/*      */           } 
/*      */         } else {
/*  889 */           int j = getDoubleIndex(num);
/*  890 */           addIndexOp(40, j);
/*      */         } 
/*  892 */         stackChange(1);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 55:
/*  898 */         if (this.itsData.itsNeedsActivation) Kit.codeBug(); 
/*  899 */         index = this.scriptOrFn.getIndexForNameNode(node);
/*  900 */         addVarOp(55, index);
/*  901 */         stackChange(1);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 56:
/*  907 */         if (this.itsData.itsNeedsActivation) Kit.codeBug(); 
/*  908 */         index = this.scriptOrFn.getIndexForNameNode(child);
/*  909 */         child = child.getNext();
/*  910 */         visitExpression(child, 0);
/*  911 */         addVarOp(56, index);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 160:
/*  917 */         if (this.itsData.itsNeedsActivation) Kit.codeBug(); 
/*  918 */         index = this.scriptOrFn.getIndexForNameNode(child);
/*  919 */         child = child.getNext();
/*  920 */         visitExpression(child, 0);
/*  921 */         addVarOp(160, index);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 45:
/*      */       case 64:
/*  930 */         addToken(type);
/*  931 */         stackChange(1);
/*      */         break;
/*      */       
/*      */       case 62:
/*      */       case 63:
/*  936 */         addIndexOp(type, getLocalBlockRef(node));
/*  937 */         stackChange(1);
/*      */         break;
/*      */       
/*      */       case 83:
/*  941 */         addBigInt(node.getBigInt());
/*  942 */         stackChange(1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 48:
/*  947 */         index = node.getExistingIntProp(4);
/*  948 */         addIndexOp(48, index);
/*  949 */         stackChange(1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 66:
/*      */       case 67:
/*  955 */         visitLiteral(node, child);
/*      */         break;
/*      */       
/*      */       case 161:
/*  959 */         visitArrayComprehension(node, child, child.getNext());
/*      */         break;
/*      */       
/*      */       case 72:
/*  963 */         visitExpression(child, 0);
/*  964 */         addStringOp(type, (String)node.getProp(17));
/*      */         break;
/*      */ 
/*      */       
/*      */       case 79:
/*      */       case 80:
/*      */       case 81:
/*      */       case 82:
/*  972 */         memberTypeFlags = node.getIntProp(16, 0);
/*      */         
/*  974 */         childCount = 0;
/*      */         while (true)
/*  976 */         { visitExpression(child, 0);
/*  977 */           childCount++;
/*  978 */           child = child.getNext();
/*  979 */           if (child == null)
/*  980 */           { addIndexOp(type, memberTypeFlags);
/*  981 */             stackChange(1 - childCount);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1040 */             if (savedStackDepth + 1 != this.stackDepth)
/* 1041 */               Kit.codeBug();  return; }  } case 150: updateLineNumber(node); visitExpression(child, 0); addIcode(-53); stackChange(-1); queryPC = this.iCodeTop; visitExpression(child.getNext(), 0); addBackwardGoto(-54, queryPC); break;case 76: case 77: case 78: visitExpression(child, 0); addToken(type); break;case 73: case 169: if (child != null) { visitExpression(child, 0); } else { addIcode(-50); stackChange(1); }  if (type == 73) { addToken(73); } else { addIcode(-66); }  addUint16(node.getLineno() & 0xFFFF); break;case 163: enterWith = node.getFirstChild(); with = enterWith.getNext(); visitExpression(enterWith.getFirstChild(), 0); addToken(2); stackChange(-1); visitExpression(with.getFirstChild(), 0); addToken(3); break;case 170: visitTemplateLiteral(node); break;default: throw badTree(node); }  if (savedStackDepth + 1 != this.stackDepth) Kit.codeBug();  }
/*      */ 
/*      */   
/*      */   private void generateCallFunAndThis(Node left) {
/*      */     String name;
/*      */     Node target, id;
/* 1047 */     int type = left.getType();
/* 1048 */     switch (type) {
/*      */       
/*      */       case 39:
/* 1051 */         name = left.getString();
/*      */         
/* 1053 */         addStringOp(-15, name);
/* 1054 */         stackChange(2);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 36:
/* 1060 */         target = left.getFirstChild();
/* 1061 */         visitExpression(target, 0);
/* 1062 */         id = target.getNext();
/* 1063 */         if (type == 33) {
/* 1064 */           String property = id.getString();
/*      */           
/* 1066 */           addStringOp(-16, property);
/* 1067 */           stackChange(1);
/*      */         } else {
/* 1069 */           visitExpression(id, 0);
/*      */           
/* 1071 */           addIcode(-17);
/*      */         } 
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1077 */     visitExpression(left, 0);
/*      */     
/* 1079 */     addIcode(-18);
/* 1080 */     stackChange(1); } private void visitIncDec(Node node, Node child) {
/*      */     int i;
/*      */     String name;
/*      */     Node object, ref;
/*      */     String property;
/*      */     Node index;
/* 1086 */     int incrDecrMask = node.getExistingIntProp(13);
/* 1087 */     int childType = child.getType();
/* 1088 */     switch (childType) {
/*      */       
/*      */       case 55:
/* 1091 */         if (this.itsData.itsNeedsActivation) Kit.codeBug(); 
/* 1092 */         i = this.scriptOrFn.getIndexForNameNode(child);
/* 1093 */         addVarOp(-7, i);
/* 1094 */         addUint8(incrDecrMask);
/* 1095 */         stackChange(1);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 39:
/* 1100 */         name = child.getString();
/* 1101 */         addStringOp(-8, name);
/* 1102 */         addUint8(incrDecrMask);
/* 1103 */         stackChange(1);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 33:
/* 1108 */         object = child.getFirstChild();
/* 1109 */         visitExpression(object, 0);
/* 1110 */         property = object.getNext().getString();
/* 1111 */         addStringOp(-9, property);
/* 1112 */         addUint8(incrDecrMask);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 36:
/* 1117 */         object = child.getFirstChild();
/* 1118 */         visitExpression(object, 0);
/* 1119 */         index = object.getNext();
/* 1120 */         visitExpression(index, 0);
/* 1121 */         addIcode(-10);
/* 1122 */         addUint8(incrDecrMask);
/* 1123 */         stackChange(-1);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 68:
/* 1128 */         ref = child.getFirstChild();
/* 1129 */         visitExpression(ref, 0);
/* 1130 */         addIcode(-11);
/* 1131 */         addUint8(incrDecrMask);
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1136 */     throw badTree(node);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitLiteral(Node node, Node child) {
/* 1142 */     int count, type = node.getType();
/*      */     
/* 1144 */     Object[] propertyIds = null;
/* 1145 */     if (type == 66) {
/* 1146 */       count = 0;
/* 1147 */       for (Node n = child; n != null; n = n.getNext()) {
/* 1148 */         count++;
/*      */       }
/* 1150 */     } else if (type == 67) {
/* 1151 */       propertyIds = (Object[])node.getProp(12);
/* 1152 */       count = (propertyIds == null) ? 0 : propertyIds.length;
/*      */     } else {
/* 1154 */       throw badTree(node);
/*      */     } 
/* 1156 */     addIndexOp(-29, count);
/* 1157 */     stackChange(2);
/* 1158 */     while (child != null) {
/* 1159 */       int childType = child.getType();
/* 1160 */       if (childType == 155) {
/* 1161 */         visitExpression(child.getFirstChild(), 0);
/* 1162 */         addIcode(-57);
/* 1163 */       } else if (childType == 156) {
/* 1164 */         visitExpression(child.getFirstChild(), 0);
/* 1165 */         addIcode(-58);
/* 1166 */       } else if (childType == 167) {
/* 1167 */         visitExpression(child.getFirstChild(), 0);
/* 1168 */         addIcode(-30);
/*      */       } else {
/* 1170 */         visitExpression(child, 0);
/* 1171 */         addIcode(-30);
/*      */       } 
/* 1173 */       stackChange(-1);
/* 1174 */       child = child.getNext();
/*      */     } 
/* 1176 */     if (type == 66) {
/* 1177 */       int[] skipIndexes = (int[])node.getProp(11);
/* 1178 */       if (skipIndexes == null) {
/* 1179 */         addToken(66);
/*      */       } else {
/* 1181 */         int index = this.literalIds.size();
/* 1182 */         this.literalIds.add(skipIndexes);
/* 1183 */         addIndexOp(-31, index);
/*      */       } 
/*      */     } else {
/* 1186 */       int index = this.literalIds.size();
/* 1187 */       this.literalIds.add(propertyIds);
/* 1188 */       addIndexOp(67, index);
/*      */     } 
/* 1190 */     stackChange(-1);
/*      */   }
/*      */   
/*      */   private void visitTemplateLiteral(Node node) {
/* 1194 */     int index = node.getExistingIntProp(28);
/* 1195 */     addIndexOp(-74, index);
/* 1196 */     stackChange(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitArrayComprehension(Node node, Node initStmt, Node expr) {
/* 1205 */     visitStatement(initStmt, this.stackDepth);
/* 1206 */     visitExpression(expr, 0);
/*      */   }
/*      */   
/*      */   private static int getLocalBlockRef(Node node) {
/* 1210 */     Node localBlock = (Node)node.getProp(3);
/* 1211 */     return localBlock.getExistingIntProp(2);
/*      */   }
/*      */   
/*      */   private int getTargetLabel(Node target) {
/* 1215 */     int label = target.labelId();
/* 1216 */     if (label != -1) {
/* 1217 */       return label;
/*      */     }
/* 1219 */     label = this.labelTableTop;
/* 1220 */     if (this.labelTable == null || label == this.labelTable.length) {
/* 1221 */       if (this.labelTable == null) {
/* 1222 */         this.labelTable = new int[32];
/*      */       } else {
/* 1224 */         int[] tmp = new int[this.labelTable.length * 2];
/* 1225 */         System.arraycopy(this.labelTable, 0, tmp, 0, label);
/* 1226 */         this.labelTable = tmp;
/*      */       } 
/*      */     }
/* 1229 */     this.labelTableTop = label + 1;
/* 1230 */     this.labelTable[label] = -1;
/*      */     
/* 1232 */     target.labelId(label);
/* 1233 */     return label;
/*      */   }
/*      */   
/*      */   private void markTargetLabel(Node target) {
/* 1237 */     int label = getTargetLabel(target);
/* 1238 */     if (this.labelTable[label] != -1)
/*      */     {
/* 1240 */       Kit.codeBug();
/*      */     }
/* 1242 */     this.labelTable[label] = this.iCodeTop;
/*      */   }
/*      */   
/*      */   private void addGoto(Node target, int gotoOp) {
/* 1246 */     int label = getTargetLabel(target);
/* 1247 */     if (label >= this.labelTableTop) Kit.codeBug(); 
/* 1248 */     int targetPC = this.labelTable[label];
/*      */     
/* 1250 */     if (targetPC != -1) {
/* 1251 */       addBackwardGoto(gotoOp, targetPC);
/*      */     } else {
/* 1253 */       int gotoPC = this.iCodeTop;
/* 1254 */       addGotoOp(gotoOp);
/* 1255 */       int top = this.fixupTableTop;
/* 1256 */       if (this.fixupTable == null || top == this.fixupTable.length) {
/* 1257 */         if (this.fixupTable == null) {
/* 1258 */           this.fixupTable = new long[40];
/*      */         } else {
/* 1260 */           long[] tmp = new long[this.fixupTable.length * 2];
/* 1261 */           System.arraycopy(this.fixupTable, 0, tmp, 0, top);
/* 1262 */           this.fixupTable = tmp;
/*      */         } 
/*      */       }
/* 1265 */       this.fixupTableTop = top + 1;
/* 1266 */       this.fixupTable[top] = label << 32L | gotoPC;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fixLabelGotos() {
/* 1271 */     for (int i = 0; i < this.fixupTableTop; i++) {
/* 1272 */       long fixup = this.fixupTable[i];
/* 1273 */       int label = (int)(fixup >> 32L);
/* 1274 */       int jumpSource = (int)fixup;
/* 1275 */       int pc = this.labelTable[label];
/* 1276 */       if (pc == -1)
/*      */       {
/* 1278 */         throw Kit.codeBug();
/*      */       }
/* 1280 */       resolveGoto(jumpSource, pc);
/*      */     } 
/* 1282 */     this.fixupTableTop = 0;
/*      */   }
/*      */   
/*      */   private void addBackwardGoto(int gotoOp, int jumpPC) {
/* 1286 */     int fromPC = this.iCodeTop;
/*      */     
/* 1288 */     if (fromPC <= jumpPC) throw Kit.codeBug(); 
/* 1289 */     addGotoOp(gotoOp);
/* 1290 */     resolveGoto(fromPC, jumpPC);
/*      */   }
/*      */ 
/*      */   
/*      */   private void resolveForwardGoto(int fromPC) {
/* 1295 */     if (this.iCodeTop < fromPC + 3) throw Kit.codeBug(); 
/* 1296 */     resolveGoto(fromPC, this.iCodeTop);
/*      */   }
/*      */   
/*      */   private void resolveGoto(int fromPC, int jumpPC) {
/* 1300 */     int offset = jumpPC - fromPC;
/*      */     
/* 1302 */     if (0 <= offset && offset <= 2) throw Kit.codeBug(); 
/* 1303 */     int offsetSite = fromPC + 1;
/* 1304 */     if (offset != (short)offset) {
/* 1305 */       if (this.itsData.longJumps == null) {
/* 1306 */         this.itsData.longJumps = new UintMap();
/*      */       }
/* 1308 */       this.itsData.longJumps.put(offsetSite, jumpPC);
/* 1309 */       offset = 0;
/*      */     } 
/* 1311 */     byte[] array = this.itsData.itsICode;
/* 1312 */     array[offsetSite] = (byte)(offset >> 8);
/* 1313 */     array[offsetSite + 1] = (byte)offset;
/*      */   }
/*      */   
/*      */   private void addToken(int token) {
/* 1317 */     if (!Icode.validTokenCode(token)) throw Kit.codeBug(); 
/* 1318 */     addUint8(token);
/*      */   }
/*      */   
/*      */   private void addIcode(int icode) {
/* 1322 */     if (!Icode.validIcode(icode)) throw Kit.codeBug();
/*      */     
/* 1324 */     addUint8(icode & 0xFF);
/*      */   }
/*      */   
/*      */   private void addUint8(int value) {
/* 1328 */     if ((value & 0xFFFFFF00) != 0) throw Kit.codeBug(); 
/* 1329 */     byte[] array = this.itsData.itsICode;
/* 1330 */     int top = this.iCodeTop;
/* 1331 */     if (top == array.length) {
/* 1332 */       array = increaseICodeCapacity(1);
/*      */     }
/* 1334 */     array[top] = (byte)value;
/* 1335 */     this.iCodeTop = top + 1;
/*      */   }
/*      */   
/*      */   private void addUint16(int value) {
/* 1339 */     if ((value & 0xFFFF0000) != 0) throw Kit.codeBug(); 
/* 1340 */     byte[] array = this.itsData.itsICode;
/* 1341 */     int top = this.iCodeTop;
/* 1342 */     if (top + 2 > array.length) {
/* 1343 */       array = increaseICodeCapacity(2);
/*      */     }
/* 1345 */     array[top] = (byte)(value >>> 8);
/* 1346 */     array[top + 1] = (byte)value;
/* 1347 */     this.iCodeTop = top + 2;
/*      */   }
/*      */   
/*      */   private void addInt(int i) {
/* 1351 */     byte[] array = this.itsData.itsICode;
/* 1352 */     int top = this.iCodeTop;
/* 1353 */     if (top + 4 > array.length) {
/* 1354 */       array = increaseICodeCapacity(4);
/*      */     }
/* 1356 */     array[top] = (byte)(i >>> 24);
/* 1357 */     array[top + 1] = (byte)(i >>> 16);
/* 1358 */     array[top + 2] = (byte)(i >>> 8);
/* 1359 */     array[top + 3] = (byte)i;
/* 1360 */     this.iCodeTop = top + 4;
/*      */   }
/*      */   
/*      */   private int getDoubleIndex(double num) {
/* 1364 */     int index = this.doubleTableTop;
/* 1365 */     if (index == 0) {
/* 1366 */       this.itsData.itsDoubleTable = new double[64];
/* 1367 */     } else if (this.itsData.itsDoubleTable.length == index) {
/* 1368 */       double[] na = new double[index * 2];
/* 1369 */       System.arraycopy(this.itsData.itsDoubleTable, 0, na, 0, index);
/* 1370 */       this.itsData.itsDoubleTable = na;
/*      */     } 
/* 1372 */     this.itsData.itsDoubleTable[index] = num;
/* 1373 */     this.doubleTableTop = index + 1;
/* 1374 */     return index;
/*      */   }
/*      */   
/*      */   private void addGotoOp(int gotoOp) {
/* 1378 */     byte[] array = this.itsData.itsICode;
/* 1379 */     int top = this.iCodeTop;
/* 1380 */     if (top + 3 > array.length) {
/* 1381 */       array = increaseICodeCapacity(3);
/*      */     }
/* 1383 */     array[top] = (byte)gotoOp;
/*      */     
/* 1385 */     this.iCodeTop = top + 1 + 2;
/*      */   }
/*      */   
/*      */   private void addVarOp(int op, int varIndex) {
/* 1389 */     switch (op) {
/*      */       case 160:
/* 1391 */         if (varIndex < 128) {
/* 1392 */           addIcode(-61);
/* 1393 */           addUint8(varIndex);
/*      */           return;
/*      */         } 
/* 1396 */         addIndexOp(-60, varIndex);
/*      */         return;
/*      */       case 55:
/*      */       case 56:
/* 1400 */         if (varIndex < 128) {
/* 1401 */           addIcode((op == 55) ? -48 : -49);
/* 1402 */           addUint8(varIndex);
/*      */           return;
/*      */         } 
/*      */       
/*      */       case -7:
/* 1407 */         addIndexOp(op, varIndex);
/*      */         return;
/*      */     } 
/* 1410 */     throw Kit.codeBug();
/*      */   }
/*      */   
/*      */   private void addStringOp(int op, String str) {
/* 1414 */     addStringPrefix(str);
/* 1415 */     if (Icode.validIcode(op)) {
/* 1416 */       addIcode(op);
/*      */     } else {
/* 1418 */       addToken(op);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addIndexOp(int op, int index) {
/* 1423 */     addIndexPrefix(index);
/* 1424 */     if (Icode.validIcode(op)) {
/* 1425 */       addIcode(op);
/*      */     } else {
/* 1427 */       addToken(op);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addStringPrefix(String str) {
/* 1432 */     int index = this.strings.get(str, -1);
/* 1433 */     if (index == -1) {
/* 1434 */       index = this.strings.size();
/* 1435 */       this.strings.put(str, index);
/*      */     } 
/* 1437 */     if (index < 4) {
/* 1438 */       addIcode(-41 - index);
/* 1439 */     } else if (index <= 255) {
/* 1440 */       addIcode(-45);
/* 1441 */       addUint8(index);
/* 1442 */     } else if (index <= 65535) {
/* 1443 */       addIcode(-46);
/* 1444 */       addUint16(index);
/*      */     } else {
/* 1446 */       addIcode(-47);
/* 1447 */       addInt(index);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addBigInt(BigInteger n) {
/* 1452 */     int index = this.bigInts.get(n, -1);
/* 1453 */     if (index == -1) {
/* 1454 */       index = this.bigInts.size();
/* 1455 */       this.bigInts.put(n, index);
/*      */     } 
/* 1457 */     if (index < 4) {
/* 1458 */       addIcode(-67 - index);
/* 1459 */     } else if (index <= 255) {
/* 1460 */       addIcode(-71);
/* 1461 */       addUint8(index);
/* 1462 */     } else if (index <= 65535) {
/* 1463 */       addIcode(-72);
/* 1464 */       addUint16(index);
/*      */     } else {
/* 1466 */       addIcode(-73);
/* 1467 */       addInt(index);
/*      */     } 
/* 1469 */     addToken(83);
/*      */   }
/*      */   
/*      */   private void addIndexPrefix(int index) {
/* 1473 */     if (index < 0) Kit.codeBug(); 
/* 1474 */     if (index < 6) {
/* 1475 */       addIcode(-32 - index);
/* 1476 */     } else if (index <= 255) {
/* 1477 */       addIcode(-38);
/* 1478 */       addUint8(index);
/* 1479 */     } else if (index <= 65535) {
/* 1480 */       addIcode(-39);
/* 1481 */       addUint16(index);
/*      */     } else {
/* 1483 */       addIcode(-40);
/* 1484 */       addInt(index);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addExceptionHandler(int icodeStart, int icodeEnd, int handlerStart, boolean isFinally, int exceptionObjectLocal, int scopeLocal) {
/* 1495 */     int top = this.exceptionTableTop;
/* 1496 */     int[] table = this.itsData.itsExceptionTable;
/* 1497 */     if (table == null) {
/* 1498 */       if (top != 0) Kit.codeBug(); 
/* 1499 */       table = new int[12];
/* 1500 */       this.itsData.itsExceptionTable = table;
/* 1501 */     } else if (table.length == top) {
/* 1502 */       table = new int[table.length * 2];
/* 1503 */       System.arraycopy(this.itsData.itsExceptionTable, 0, table, 0, top);
/* 1504 */       this.itsData.itsExceptionTable = table;
/*      */     } 
/* 1506 */     table[top + 0] = icodeStart;
/* 1507 */     table[top + 1] = icodeEnd;
/* 1508 */     table[top + 2] = handlerStart;
/* 1509 */     table[top + 3] = isFinally ? 1 : 0;
/* 1510 */     table[top + 4] = exceptionObjectLocal;
/* 1511 */     table[top + 5] = scopeLocal;
/*      */     
/* 1513 */     this.exceptionTableTop = top + 6;
/*      */   }
/*      */   
/*      */   private byte[] increaseICodeCapacity(int extraSize) {
/* 1517 */     int capacity = this.itsData.itsICode.length;
/* 1518 */     int top = this.iCodeTop;
/* 1519 */     if (top + extraSize <= capacity) throw Kit.codeBug(); 
/* 1520 */     capacity *= 2;
/* 1521 */     if (top + extraSize > capacity) {
/* 1522 */       capacity = top + extraSize;
/*      */     }
/* 1524 */     byte[] array = new byte[capacity];
/* 1525 */     System.arraycopy(this.itsData.itsICode, 0, array, 0, top);
/* 1526 */     this.itsData.itsICode = array;
/* 1527 */     return array;
/*      */   }
/*      */   
/*      */   private void stackChange(int change) {
/* 1531 */     if (change <= 0) {
/* 1532 */       this.stackDepth += change;
/*      */     } else {
/* 1534 */       int newDepth = this.stackDepth + change;
/* 1535 */       if (newDepth > this.itsData.itsMaxStack) {
/* 1536 */         this.itsData.itsMaxStack = newDepth;
/*      */       }
/* 1538 */       this.stackDepth = newDepth;
/*      */     } 
/*      */   }
/*      */   
/*      */   private int allocLocal() {
/* 1543 */     int localSlot = this.localTop;
/* 1544 */     this.localTop++;
/* 1545 */     if (this.localTop > this.itsData.itsMaxLocals) {
/* 1546 */       this.itsData.itsMaxLocals = this.localTop;
/*      */     }
/* 1548 */     return localSlot;
/*      */   }
/*      */   
/*      */   private void releaseLocal(int localSlot) {
/* 1552 */     this.localTop--;
/* 1553 */     if (localSlot != this.localTop) Kit.codeBug(); 
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\CodeGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */