/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeCall
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = -7471457301304454454L;
/*  21 */   private static final Object CALL_TAG = "Call"; private static final int Id_constructor = 1; private static final int MAX_PROTOTYPE_ID = 1;
/*     */   NativeFunction function;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  25 */     NativeCall obj = new NativeCall();
/*  26 */     obj.exportAsJSClass(1, scope, sealed);
/*     */   }
/*     */   Object[] originalArgs; boolean isStrict; private Arguments arguments; transient NativeCall parentActivationCall;
/*     */   
/*     */   NativeCall() {}
/*     */   
/*     */   NativeCall(NativeFunction function, Scriptable scope, Object[] args, boolean isArrow, boolean isStrict) {
/*  33 */     this.function = function;
/*     */     
/*  35 */     setParentScope(scope);
/*     */ 
/*     */     
/*  38 */     this.originalArgs = (args == null) ? ScriptRuntime.emptyArgs : args;
/*  39 */     this.isStrict = isStrict;
/*     */ 
/*     */     
/*  42 */     int paramAndVarCount = function.getParamAndVarCount();
/*  43 */     int paramCount = function.getParamCount();
/*  44 */     if (paramAndVarCount != 0) {
/*  45 */       for (int i = 0; i < paramCount; i++) {
/*  46 */         String name = function.getParamOrVarName(i);
/*  47 */         Object val = (i < args.length) ? args[i] : Undefined.instance;
/*     */         
/*  49 */         defineProperty(name, val, 4);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  55 */     if (!has("arguments", this) && !isArrow) {
/*  56 */       this.arguments = new Arguments(this);
/*  57 */       defineProperty("arguments", this.arguments, 4);
/*     */     } 
/*     */     
/*  60 */     if (paramAndVarCount != 0) {
/*  61 */       for (int i = paramCount; i < paramAndVarCount; i++) {
/*  62 */         String name = function.getParamOrVarName(i);
/*  63 */         if (!has(name, this)) {
/*  64 */           if (function.getParamOrVarConst(i)) {
/*  65 */             defineProperty(name, Undefined.instance, 13);
/*  66 */           } else if (!(function instanceof InterpretedFunction) || ((InterpretedFunction)function)
/*  67 */             .hasFunctionNamed(name)) {
/*  68 */             defineProperty(name, Undefined.instance, 4);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  78 */     return "Call";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/*  84 */     return s.equals("constructor") ? 1 : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*  92 */     if (id == 1) {
/*  93 */       arity = 1; s = "constructor";
/*     */     } else {
/*  95 */       throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/*  97 */     initPrototypeMethod(CALL_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 104 */     if (!f.hasTag(CALL_TAG)) {
/* 105 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 107 */     int id = f.methodId();
/* 108 */     if (id == 1) {
/* 109 */       if (thisObj != null) {
/* 110 */         throw Context.reportRuntimeErrorById("msg.only.from.new", new Object[] { "Call" });
/*     */       }
/* 112 */       ScriptRuntime.checkDeprecated(cx, "Call");
/* 113 */       NativeCall result = new NativeCall();
/* 114 */       result.setPrototype(getObjectPrototype(scope));
/* 115 */       return result;
/*     */     } 
/* 117 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */   
/*     */   public void defineAttributesForArguments() {
/* 121 */     if (this.arguments != null)
/* 122 */       this.arguments.defineAttributesForStrictMode(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */