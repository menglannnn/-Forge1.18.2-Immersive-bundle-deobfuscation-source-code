/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptRuntimeES6
/*    */ {
/*    */   public static Object requireObjectCoercible(Context cx, Object val, IdFunctionObject idFuncObj) {
/* 12 */     if (val == null || Undefined.isUndefined(val)) {
/* 13 */       throw ScriptRuntime.typeErrorById("msg.called.null.or.undefined", new Object[] { idFuncObj.getTag(), idFuncObj.getFunctionName() });
/*    */     }
/* 15 */     return val;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ScriptRuntimeES6.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */