/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaScriptException
/*    */   extends RhinoException
/*    */ {
/*    */   private static final long serialVersionUID = -7666130513694669293L;
/*    */   private Object value;
/*    */   private String details;
/*    */   
/*    */   @Deprecated
/*    */   public JavaScriptException(Object value) {
/* 26 */     this(value, "", 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JavaScriptException(Object value, String sourceName, int lineNumber) {
/* 35 */     recordErrorOrigin(sourceName, lineNumber, null, 0);
/* 36 */     this.value = value;
/*    */ 
/*    */     
/* 39 */     if (value instanceof NativeError && 
/* 40 */       Context.getContext().hasFeature(10)) {
/* 41 */       NativeError error = (NativeError)value;
/* 42 */       if (!error.has("fileName", error)) {
/* 43 */         error.put("fileName", error, sourceName);
/*    */       }
/* 45 */       if (!error.has("lineNumber", error)) {
/* 46 */         error.put("lineNumber", error, Integer.valueOf(lineNumber));
/*    */       }
/*    */       
/* 49 */       error.setStackProvider(this);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     this.details = getDetails();
/*    */   }
/*    */ 
/*    */   
/*    */   public String details() {
/* 61 */     return this.details;
/*    */   }
/*    */   
/*    */   public String getDetails() {
/* 65 */     if (this.value == null)
/* 66 */       return "null"; 
/* 67 */     if (this.value instanceof NativeError) {
/* 68 */       return this.value.toString();
/*    */     }
/*    */     
/*    */     try {
/* 72 */       return ScriptRuntime.toString(this.value);
/* 73 */     } catch (RuntimeException rte) {
/*    */       
/* 75 */       if (this.value instanceof Scriptable) {
/* 76 */         return ScriptRuntime.defaultObjectToString((Scriptable)this.value);
/*    */       }
/* 78 */       return this.value.toString();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 84 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public String getSourceName() {
/* 90 */     return sourceName();
/*    */   }
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public int getLineNumber() {
/* 96 */     return lineNumber();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\JavaScriptException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */