/*    */ package org.mozilla.javascript.commonjs.module;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ import org.mozilla.javascript.TopLevel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleScope
/*    */   extends TopLevel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final URI uri;
/*    */   private final URI base;
/*    */   
/*    */   public ModuleScope(Scriptable prototype, URI uri, URI base) {
/* 23 */     this.uri = uri;
/* 24 */     this.base = base;
/* 25 */     setPrototype(prototype);
/* 26 */     cacheBuiltins(prototype, false);
/*    */   }
/*    */   
/*    */   public URI getUri() {
/* 30 */     return this.uri;
/*    */   }
/*    */   
/*    */   public URI getBase() {
/* 34 */     return this.base;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\ModuleScope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */