/*     */ package org.mozilla.javascript.commonjs.module.provider;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.net.URI;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Script;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.commonjs.module.ModuleScript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoftCachingModuleScriptProvider
/*     */   extends CachingModuleScriptProviderBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  34 */   private transient ReferenceQueue<Script> scriptRefQueue = new ReferenceQueue<>();
/*  35 */   private transient ConcurrentMap<String, ScriptReference> scripts = new ConcurrentHashMap<>(16, 0.75F, getConcurrencyLevel());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SoftCachingModuleScriptProvider(ModuleSourceProvider moduleSourceProvider) {
/*  44 */     super(moduleSourceProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleScript getModuleScript(Context cx, String moduleId, URI uri, URI base, Scriptable paths) throws Exception {
/*     */     while (true) {
/*  55 */       ScriptReference ref = (ScriptReference)this.scriptRefQueue.poll();
/*  56 */       if (ref == null) {
/*     */         break;
/*     */       }
/*  59 */       this.scripts.remove(ref.getModuleId(), ref);
/*     */     } 
/*  61 */     return super.getModuleScript(cx, moduleId, uri, base, paths);
/*     */   }
/*     */ 
/*     */   
/*     */   protected CachingModuleScriptProviderBase.CachedModuleScript getLoadedModule(String moduleId) {
/*  66 */     ScriptReference scriptRef = this.scripts.get(moduleId);
/*  67 */     return (scriptRef != null) ? scriptRef.getCachedModuleScript() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void putLoadedModule(String moduleId, ModuleScript moduleScript, Object validator) {
/*  74 */     this.scripts.put(moduleId, new ScriptReference(moduleScript.getScript(), moduleId, moduleScript
/*  75 */           .getUri(), moduleScript.getBase(), validator, this.scriptRefQueue));
/*     */   }
/*     */   
/*     */   private static class ScriptReference
/*     */     extends SoftReference<Script>
/*     */   {
/*     */     private final String moduleId;
/*     */     private final URI uri;
/*     */     private final URI base;
/*     */     private final Object validator;
/*     */     
/*     */     ScriptReference(Script script, String moduleId, URI uri, URI base, Object validator, ReferenceQueue<Script> refQueue) {
/*  87 */       super(script, refQueue);
/*  88 */       this.moduleId = moduleId;
/*  89 */       this.uri = uri;
/*  90 */       this.base = base;
/*  91 */       this.validator = validator;
/*     */     }
/*     */     
/*     */     CachingModuleScriptProviderBase.CachedModuleScript getCachedModuleScript() {
/*  95 */       Script script = get();
/*  96 */       if (script == null) {
/*  97 */         return null;
/*     */       }
/*  99 */       return new CachingModuleScriptProviderBase.CachedModuleScript(new ModuleScript(script, this.uri, this.base), this.validator);
/*     */     }
/*     */ 
/*     */     
/*     */     String getModuleId() {
/* 104 */       return this.moduleId;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 112 */     this.scriptRefQueue = new ReferenceQueue<>();
/* 113 */     this.scripts = new ConcurrentHashMap<>();
/* 114 */     Map<String, CachingModuleScriptProviderBase.CachedModuleScript> serScripts = (Map<String, CachingModuleScriptProviderBase.CachedModuleScript>)in.readObject();
/* 115 */     for (Map.Entry<String, CachingModuleScriptProviderBase.CachedModuleScript> entry : serScripts.entrySet()) {
/* 116 */       CachingModuleScriptProviderBase.CachedModuleScript cachedModuleScript = entry.getValue();
/* 117 */       putLoadedModule(entry.getKey(), cachedModuleScript.getModule(), cachedModuleScript
/* 118 */           .getValidator());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 123 */     Map<String, CachingModuleScriptProviderBase.CachedModuleScript> serScripts = new HashMap<>();
/*     */     
/* 125 */     for (Map.Entry<String, ScriptReference> entry : this.scripts.entrySet()) {
/*     */       
/* 127 */       CachingModuleScriptProviderBase.CachedModuleScript cachedModuleScript = ((ScriptReference)entry.getValue()).getCachedModuleScript();
/* 128 */       if (cachedModuleScript != null) {
/* 129 */         serScripts.put(entry.getKey(), cachedModuleScript);
/*     */       }
/*     */     } 
/* 132 */     out.writeObject(serScripts);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\SoftCachingModuleScriptProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */