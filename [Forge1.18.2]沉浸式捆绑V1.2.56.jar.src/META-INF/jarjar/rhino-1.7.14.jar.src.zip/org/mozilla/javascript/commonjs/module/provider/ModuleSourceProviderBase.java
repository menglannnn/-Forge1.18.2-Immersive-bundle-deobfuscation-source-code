/*     */ package org.mozilla.javascript.commonjs.module.provider;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModuleSourceProviderBase
/*     */   implements ModuleSourceProvider, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public ModuleSource loadSource(String moduleId, Scriptable paths, Object validator) throws IOException, URISyntaxException {
/*  36 */     if (!entityNeedsRevalidation(validator)) {
/*  37 */       return NOT_MODIFIED;
/*     */     }
/*     */     
/*  40 */     ModuleSource moduleSource = loadFromPrivilegedLocations(moduleId, validator);
/*  41 */     if (moduleSource != null) {
/*  42 */       return moduleSource;
/*     */     }
/*  44 */     if (paths != null) {
/*  45 */       moduleSource = loadFromPathArray(moduleId, paths, validator);
/*  46 */       if (moduleSource != null) {
/*  47 */         return moduleSource;
/*     */       }
/*     */     } 
/*  50 */     return loadFromFallbackLocations(moduleId, validator);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleSource loadSource(URI uri, URI base, Object validator) throws IOException, URISyntaxException {
/*  56 */     return loadFromUri(uri, base, validator);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ModuleSource loadFromPathArray(String moduleId, Scriptable paths, Object validator) throws IOException {
/*  62 */     long llength = ScriptRuntime.toUint32(
/*  63 */         ScriptableObject.getProperty(paths, "length"));
/*     */     
/*  65 */     int ilength = (llength > 2147483647L) ? Integer.MAX_VALUE : (int)llength;
/*     */ 
/*     */     
/*  68 */     for (int i = 0; i < ilength; i++) {
/*  69 */       String path = ensureTrailingSlash(
/*  70 */           (String)ScriptableObject.getTypedProperty(paths, i, String.class));
/*     */       try {
/*  72 */         URI uri = new URI(path);
/*  73 */         if (!uri.isAbsolute()) {
/*  74 */           uri = (new File(path)).toURI().resolve("");
/*     */         }
/*  76 */         ModuleSource moduleSource = loadFromUri(uri
/*  77 */             .resolve(moduleId), uri, validator);
/*  78 */         if (moduleSource != null) {
/*  79 */           return moduleSource;
/*     */         }
/*     */       }
/*  82 */       catch (URISyntaxException e) {
/*  83 */         throw new MalformedURLException(e.getMessage());
/*     */       } 
/*     */     } 
/*  86 */     return null;
/*     */   }
/*     */   
/*     */   private static String ensureTrailingSlash(String path) {
/*  90 */     return path.endsWith("/") ? path : path.concat("/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean entityNeedsRevalidation(Object validator) {
/* 106 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ModuleSource loadFromUri(URI paramURI1, URI paramURI2, Object paramObject) throws IOException, URISyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModuleSource loadFromPrivilegedLocations(String moduleId, Object validator) throws IOException, URISyntaxException {
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModuleSource loadFromFallbackLocations(String moduleId, Object validator) throws IOException, URISyntaxException {
/* 168 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\ModuleSourceProviderBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */