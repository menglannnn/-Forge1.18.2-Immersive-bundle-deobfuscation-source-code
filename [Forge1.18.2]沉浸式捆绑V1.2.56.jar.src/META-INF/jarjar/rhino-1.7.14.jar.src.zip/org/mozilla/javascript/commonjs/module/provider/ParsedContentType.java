/*    */ package org.mozilla.javascript.commonjs.module.provider;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ParsedContentType
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final String contentType;
/*    */   private final String encoding;
/*    */   
/*    */   public ParsedContentType(String mimeType) {
/* 27 */     String contentType = null;
/* 28 */     String encoding = null;
/* 29 */     if (mimeType != null) {
/* 30 */       StringTokenizer tok = new StringTokenizer(mimeType, ";");
/* 31 */       if (tok.hasMoreTokens()) {
/* 32 */         contentType = tok.nextToken().trim();
/* 33 */         while (tok.hasMoreTokens()) {
/* 34 */           String param = tok.nextToken().trim();
/* 35 */           if (param.startsWith("charset=")) {
/* 36 */             encoding = param.substring(8).trim();
/* 37 */             int l = encoding.length();
/* 38 */             if (l > 0) {
/* 39 */               if (encoding.charAt(0) == '"') {
/* 40 */                 encoding = encoding.substring(1);
/*    */               }
/* 42 */               if (encoding.charAt(l - 1) == '"') {
/* 43 */                 encoding = encoding.substring(0, l - 1);
/*    */               }
/*    */             } 
/*    */             break;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 51 */     this.contentType = contentType;
/* 52 */     this.encoding = encoding;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getContentType() {
/* 61 */     return this.contentType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getEncoding() {
/* 70 */     return this.encoding;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\ParsedContentType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */