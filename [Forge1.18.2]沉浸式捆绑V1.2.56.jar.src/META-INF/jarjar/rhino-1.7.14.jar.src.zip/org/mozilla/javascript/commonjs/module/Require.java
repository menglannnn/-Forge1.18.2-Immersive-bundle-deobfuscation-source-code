/*     */ package org.mozilla.javascript.commonjs.module;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.mozilla.javascript.BaseFunction;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Script;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Require
/*     */   extends BaseFunction
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final ModuleScriptProvider moduleScriptProvider;
/*     */   private final Scriptable nativeScope;
/*     */   private final Scriptable paths;
/*     */   private final boolean sandboxed;
/*     */   private final Script preExec;
/*     */   private final Script postExec;
/*  49 */   private String mainModuleId = null;
/*     */   
/*     */   private Scriptable mainExports;
/*     */   
/*  53 */   private final Map<String, Scriptable> exportedModuleInterfaces = new ConcurrentHashMap<>();
/*     */   
/*  55 */   private final Object loadLock = new Object();
/*     */ 
/*     */ 
/*     */   
/*  59 */   private static final ThreadLocal<Map<String, Scriptable>> loadingModuleInterfaces = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Require(Context cx, Scriptable nativeScope, ModuleScriptProvider moduleScriptProvider, Script preExec, Script postExec, boolean sandboxed) {
/*  82 */     this.moduleScriptProvider = moduleScriptProvider;
/*  83 */     this.nativeScope = nativeScope;
/*  84 */     this.sandboxed = sandboxed;
/*  85 */     this.preExec = preExec;
/*  86 */     this.postExec = postExec;
/*  87 */     setPrototype(ScriptableObject.getFunctionPrototype(nativeScope));
/*  88 */     if (!sandboxed) {
/*  89 */       this.paths = cx.newArray(nativeScope, 0);
/*  90 */       defineReadOnlyProperty((ScriptableObject)this, "paths", this.paths);
/*     */     } else {
/*     */       
/*  93 */       this.paths = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable requireMain(Context cx, String mainModuleId) {
/*     */     ModuleScript moduleScript;
/* 115 */     if (this.mainModuleId != null) {
/* 116 */       if (!this.mainModuleId.equals(mainModuleId)) {
/* 117 */         throw new IllegalStateException("Main module already set to " + this.mainModuleId);
/*     */       }
/*     */       
/* 120 */       return this.mainExports;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 126 */       moduleScript = this.moduleScriptProvider.getModuleScript(cx, mainModuleId, null, null, this.paths);
/*     */     }
/* 128 */     catch (RuntimeException x) {
/* 129 */       throw x;
/* 130 */     } catch (Exception x) {
/* 131 */       throw new RuntimeException(x);
/*     */     } 
/*     */     
/* 134 */     if (moduleScript != null) {
/* 135 */       this.mainExports = getExportedModuleInterface(cx, mainModuleId, (URI)null, (URI)null, true);
/*     */     }
/* 137 */     else if (!this.sandboxed) {
/*     */       
/* 139 */       URI mainUri = null;
/*     */ 
/*     */       
/*     */       try {
/* 143 */         mainUri = new URI(mainModuleId);
/* 144 */       } catch (URISyntaxException uRISyntaxException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 149 */       if (mainUri == null || !mainUri.isAbsolute()) {
/* 150 */         File file = new File(mainModuleId);
/* 151 */         if (!file.isFile()) {
/* 152 */           throw ScriptRuntime.throwError(cx, this.nativeScope, "Module \"" + mainModuleId + "\" not found.");
/*     */         }
/*     */         
/* 155 */         mainUri = file.toURI();
/*     */       } 
/* 157 */       this.mainExports = getExportedModuleInterface(cx, mainUri.toString(), mainUri, (URI)null, true);
/*     */     } 
/*     */ 
/*     */     
/* 161 */     this.mainModuleId = mainModuleId;
/* 162 */     return this.mainExports;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void install(Scriptable scope) {
/* 171 */     ScriptableObject.putProperty(scope, "require", this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 178 */     if (args == null || args.length < 1) {
/* 179 */       throw ScriptRuntime.throwError(cx, scope, "require() needs one argument");
/*     */     }
/*     */ 
/*     */     
/* 183 */     String id = (String)Context.jsToJava(args[0], String.class);
/* 184 */     URI uri = null;
/* 185 */     URI base = null;
/* 186 */     if (id.startsWith("./") || id.startsWith("../")) {
/* 187 */       if (!(thisObj instanceof ModuleScope)) {
/* 188 */         throw ScriptRuntime.throwError(cx, scope, "Can't resolve relative module ID \"" + id + "\" when require() is used outside of a module");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 193 */       ModuleScope moduleScope = (ModuleScope)thisObj;
/* 194 */       base = moduleScope.getBase();
/* 195 */       URI current = moduleScope.getUri();
/* 196 */       uri = current.resolve(id);
/*     */       
/* 198 */       if (base == null) {
/*     */ 
/*     */         
/* 201 */         id = uri.toString();
/*     */       } else {
/*     */         
/* 204 */         id = base.relativize(current).resolve(id).toString();
/* 205 */         if (id.charAt(0) == '.') {
/*     */ 
/*     */           
/* 208 */           if (this.sandboxed) {
/* 209 */             throw ScriptRuntime.throwError(cx, scope, "Module \"" + id + "\" is not contained in sandbox.");
/*     */           }
/*     */           
/* 212 */           id = uri.toString();
/*     */         } 
/*     */       } 
/*     */     } 
/* 216 */     return getExportedModuleInterface(cx, id, uri, base, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/* 221 */     throw ScriptRuntime.throwError(cx, scope, "require() can not be invoked as a constructor");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Scriptable getExportedModuleInterface(Context cx, String id, URI uri, URI base, boolean isMain) {
/* 229 */     Scriptable exports = this.exportedModuleInterfaces.get(id);
/* 230 */     if (exports != null) {
/* 231 */       if (isMain) {
/* 232 */         throw new IllegalStateException("Attempt to set main module after it was loaded");
/*     */       }
/*     */       
/* 235 */       return exports;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 240 */     Map<String, Scriptable> threadLoadingModules = loadingModuleInterfaces.get();
/* 241 */     if (threadLoadingModules != null) {
/* 242 */       exports = threadLoadingModules.get(id);
/* 243 */       if (exports != null) {
/* 244 */         return exports;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     synchronized (this.loadLock) {
/*     */ 
/*     */       
/* 258 */       exports = this.exportedModuleInterfaces.get(id);
/* 259 */       if (exports != null) {
/* 260 */         return exports;
/*     */       }
/*     */       
/* 263 */       ModuleScript moduleScript = getModule(cx, id, uri, base);
/* 264 */       if (this.sandboxed && !moduleScript.isSandboxed()) {
/* 265 */         throw ScriptRuntime.throwError(cx, this.nativeScope, "Module \"" + id + "\" is not contained in sandbox.");
/*     */       }
/*     */       
/* 268 */       exports = cx.newObject(this.nativeScope);
/*     */       
/* 270 */       boolean outermostLocked = (threadLoadingModules == null);
/* 271 */       if (outermostLocked) {
/* 272 */         threadLoadingModules = new HashMap<>();
/* 273 */         loadingModuleInterfaces.set(threadLoadingModules);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 283 */       threadLoadingModules.put(id, exports);
/*     */ 
/*     */       
/*     */       try {
/* 287 */         Scriptable newExports = executeModuleScript(cx, id, exports, moduleScript, isMain);
/*     */         
/* 289 */         if (exports != newExports) {
/* 290 */           threadLoadingModules.put(id, newExports);
/* 291 */           exports = newExports;
/*     */         }
/*     */       
/* 294 */       } catch (RuntimeException e) {
/*     */         
/* 296 */         threadLoadingModules.remove(id);
/* 297 */         throw e;
/*     */       } finally {
/*     */         
/* 300 */         if (outermostLocked) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 307 */           this.exportedModuleInterfaces.putAll(threadLoadingModules);
/* 308 */           loadingModuleInterfaces.set(null);
/*     */         } 
/*     */       } 
/*     */     } 
/* 312 */     return exports;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Scriptable executeModuleScript(Context cx, String id, Scriptable exports, ModuleScript moduleScript, boolean isMain) {
/* 318 */     ScriptableObject moduleObject = (ScriptableObject)cx.newObject(this.nativeScope);
/*     */     
/* 320 */     URI uri = moduleScript.getUri();
/* 321 */     URI base = moduleScript.getBase();
/* 322 */     defineReadOnlyProperty(moduleObject, "id", id);
/* 323 */     if (!this.sandboxed) {
/* 324 */       defineReadOnlyProperty(moduleObject, "uri", uri.toString());
/*     */     }
/* 326 */     ModuleScope moduleScope = new ModuleScope(this.nativeScope, uri, base);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     moduleScope.put("exports", (Scriptable)moduleScope, exports);
/* 332 */     moduleScope.put("module", (Scriptable)moduleScope, moduleObject);
/* 333 */     moduleObject.put("exports", (Scriptable)moduleObject, exports);
/* 334 */     install((Scriptable)moduleScope);
/* 335 */     if (isMain) {
/* 336 */       defineReadOnlyProperty((ScriptableObject)this, "main", moduleObject);
/*     */     }
/* 338 */     executeOptionalScript(this.preExec, cx, (Scriptable)moduleScope);
/* 339 */     moduleScript.getScript().exec(cx, (Scriptable)moduleScope);
/* 340 */     executeOptionalScript(this.postExec, cx, (Scriptable)moduleScope);
/* 341 */     return ScriptRuntime.toObject(cx, this.nativeScope, 
/* 342 */         ScriptableObject.getProperty((Scriptable)moduleObject, "exports"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void executeOptionalScript(Script script, Context cx, Scriptable executionScope) {
/* 348 */     if (script != null) {
/* 349 */       script.exec(cx, executionScope);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void defineReadOnlyProperty(ScriptableObject obj, String name, Object value) {
/* 355 */     ScriptableObject.putProperty((Scriptable)obj, name, value);
/* 356 */     obj.setAttributes(name, 5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ModuleScript getModule(Context cx, String id, URI uri, URI base) {
/*     */     try {
/* 363 */       ModuleScript moduleScript = this.moduleScriptProvider.getModuleScript(cx, id, uri, base, this.paths);
/* 364 */       if (moduleScript == null) {
/* 365 */         throw ScriptRuntime.throwError(cx, this.nativeScope, "Module \"" + id + "\" not found.");
/*     */       }
/*     */       
/* 368 */       return moduleScript;
/*     */     }
/* 370 */     catch (RuntimeException e) {
/* 371 */       throw e;
/*     */     }
/* 373 */     catch (Exception e) {
/* 374 */       throw Context.throwAsScriptRuntimeEx(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFunctionName() {
/* 380 */     return "require";
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArity() {
/* 385 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 390 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\Require.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */