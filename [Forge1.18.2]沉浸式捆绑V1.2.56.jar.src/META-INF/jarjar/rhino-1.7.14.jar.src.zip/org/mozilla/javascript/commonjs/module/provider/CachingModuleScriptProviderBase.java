/*     */ package org.mozilla.javascript.commonjs.module.provider;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.net.URI;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.commonjs.module.ModuleScript;
/*     */ import org.mozilla.javascript.commonjs.module.ModuleScriptProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CachingModuleScriptProviderBase
/*     */   implements ModuleScriptProvider, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*  28 */   private static final int loadConcurrencyLevel = Runtime.getRuntime().availableProcessors() * 8; private static final int loadLockShift;
/*     */   private static final int loadLockMask;
/*     */   private static final int loadLockCount;
/*     */   
/*     */   static {
/*  33 */     int sshift = 0;
/*  34 */     int ssize = 1;
/*  35 */     while (ssize < loadConcurrencyLevel) {
/*  36 */       sshift++;
/*  37 */       ssize <<= 1;
/*     */     } 
/*  39 */     loadLockShift = 32 - sshift;
/*  40 */     loadLockMask = ssize - 1;
/*  41 */     loadLockCount = ssize;
/*     */   }
/*  43 */   private final Object[] loadLocks = new Object[loadLockCount]; protected CachingModuleScriptProviderBase(ModuleSourceProvider moduleSourceProvider) {
/*  44 */     for (int i = 0; i < this.loadLocks.length; i++) {
/*  45 */       this.loadLocks[i] = new Object();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.moduleSourceProvider = moduleSourceProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private final ModuleSourceProvider moduleSourceProvider;
/*     */   
/*     */   public ModuleScript getModuleScript(Context cx, String moduleId, URI moduleUri, URI baseUri, Scriptable paths) throws Exception {
/*  64 */     CachedModuleScript cachedModule1 = getLoadedModule(moduleId);
/*  65 */     Object validator1 = getValidator(cachedModule1);
/*     */ 
/*     */     
/*  68 */     ModuleSource moduleSource = (moduleUri == null) ? this.moduleSourceProvider.loadSource(moduleId, paths, validator1) : this.moduleSourceProvider.loadSource(moduleUri, baseUri, validator1);
/*  69 */     if (moduleSource == ModuleSourceProvider.NOT_MODIFIED) {
/*  70 */       return cachedModule1.getModule();
/*     */     }
/*  72 */     if (moduleSource == null) {
/*  73 */       return null;
/*     */     }
/*  75 */     try (Reader reader = moduleSource.getReader()) {
/*  76 */       int idHash = moduleId.hashCode();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CachedModuleScript
/*     */   {
/*     */     private final ModuleScript moduleScript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Object validator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CachedModuleScript(ModuleScript moduleScript, Object validator) {
/* 130 */       this.moduleScript = moduleScript;
/* 131 */       this.validator = validator;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ModuleScript getModule() {
/* 139 */       return this.moduleScript;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object getValidator() {
/* 147 */       return this.validator;
/*     */     }
/*     */   }
/*     */   
/*     */   private static Object getValidator(CachedModuleScript cachedModule) {
/* 152 */     return (cachedModule == null) ? null : cachedModule.getValidator();
/*     */   }
/*     */   
/*     */   private static boolean equal(Object o1, Object o2) {
/* 156 */     return (o1 == null) ? ((o2 == null)) : o1.equals(o2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getConcurrencyLevel() {
/* 164 */     return loadLockCount;
/*     */   }
/*     */   
/*     */   protected abstract void putLoadedModule(String paramString, ModuleScript paramModuleScript, Object paramObject);
/*     */   
/*     */   protected abstract CachedModuleScript getLoadedModule(String paramString);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\CachingModuleScriptProviderBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */