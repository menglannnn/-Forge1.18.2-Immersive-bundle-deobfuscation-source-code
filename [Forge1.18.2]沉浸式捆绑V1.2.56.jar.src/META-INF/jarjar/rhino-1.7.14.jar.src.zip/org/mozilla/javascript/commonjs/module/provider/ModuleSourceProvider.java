/*    */ package org.mozilla.javascript.commonjs.module.provider;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ModuleSourceProvider
/*    */ {
/* 26 */   public static final ModuleSource NOT_MODIFIED = new ModuleSource(null, null, null, null, null);
/*    */   
/*    */   ModuleSource loadSource(String paramString, Scriptable paramScriptable, Object paramObject) throws IOException, URISyntaxException;
/*    */   
/*    */   ModuleSource loadSource(URI paramURI1, URI paramURI2, Object paramObject) throws IOException, URISyntaxException;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\ModuleSourceProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */