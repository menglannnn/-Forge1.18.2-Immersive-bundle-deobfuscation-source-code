/*    */ package org.mozilla.javascript.commonjs.module.provider;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.mozilla.javascript.commonjs.module.ModuleScript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrongCachingModuleScriptProvider
/*    */   extends CachingModuleScriptProviderBase
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 23 */   private final Map<String, CachingModuleScriptProviderBase.CachedModuleScript> modules = new ConcurrentHashMap<>(16, 0.75F, getConcurrencyLevel());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StrongCachingModuleScriptProvider(ModuleSourceProvider moduleSourceProvider) {
/* 32 */     super(moduleSourceProvider);
/*    */   }
/*    */ 
/*    */   
/*    */   protected CachingModuleScriptProviderBase.CachedModuleScript getLoadedModule(String moduleId) {
/* 37 */     return this.modules.get(moduleId);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void putLoadedModule(String moduleId, ModuleScript moduleScript, Object validator) {
/* 43 */     this.modules.put(moduleId, new CachingModuleScriptProviderBase.CachedModuleScript(moduleScript, validator));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\StrongCachingModuleScriptProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */