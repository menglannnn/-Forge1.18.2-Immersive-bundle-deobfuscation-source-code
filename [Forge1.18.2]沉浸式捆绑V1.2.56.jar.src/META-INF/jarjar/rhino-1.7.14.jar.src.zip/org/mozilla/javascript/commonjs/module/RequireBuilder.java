/*    */ package org.mozilla.javascript.commonjs.module;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.mozilla.javascript.Context;
/*    */ import org.mozilla.javascript.Script;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequireBuilder
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private boolean sandboxed = true;
/*    */   private ModuleScriptProvider moduleScriptProvider;
/*    */   private Script preExec;
/*    */   private Script postExec;
/*    */   
/*    */   public RequireBuilder setModuleScriptProvider(ModuleScriptProvider moduleScriptProvider) {
/* 40 */     this.moduleScriptProvider = moduleScriptProvider;
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RequireBuilder setPostExec(Script postExec) {
/* 51 */     this.postExec = postExec;
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RequireBuilder setPreExec(Script preExec) {
/* 62 */     this.preExec = preExec;
/* 63 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RequireBuilder setSandboxed(boolean sandboxed) {
/* 75 */     this.sandboxed = sandboxed;
/* 76 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Require createRequire(Context cx, Scriptable globalScope) {
/* 89 */     return new Require(cx, globalScope, this.moduleScriptProvider, this.preExec, this.postExec, this.sandboxed);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\RequireBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */