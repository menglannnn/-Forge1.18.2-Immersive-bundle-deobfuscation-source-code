/*    */ package org.mozilla.javascript.commonjs.module;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.net.URI;
/*    */ import org.mozilla.javascript.Script;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleScript
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Script script;
/*    */   private final URI uri;
/*    */   private final URI base;
/*    */   
/*    */   public ModuleScript(Script script, URI uri, URI base) {
/* 32 */     this.script = script;
/* 33 */     this.uri = uri;
/* 34 */     this.base = base;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Script getScript() {
/* 42 */     return this.script;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public URI getUri() {
/* 50 */     return this.uri;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public URI getBase() {
/* 59 */     return this.base;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSandboxed() {
/* 68 */     return (this.base != null && this.uri != null && 
/*    */       
/* 70 */       !this.base.relativize(this.uri).isAbsolute());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\ModuleScript.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */