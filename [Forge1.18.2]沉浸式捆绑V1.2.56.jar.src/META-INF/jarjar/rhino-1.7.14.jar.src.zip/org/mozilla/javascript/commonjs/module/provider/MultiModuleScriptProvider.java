/*    */ package org.mozilla.javascript.commonjs.module.provider;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import org.mozilla.javascript.Context;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ import org.mozilla.javascript.commonjs.module.ModuleScript;
/*    */ import org.mozilla.javascript.commonjs.module.ModuleScriptProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiModuleScriptProvider
/*    */   implements ModuleScriptProvider
/*    */ {
/*    */   private final ModuleScriptProvider[] providers;
/*    */   
/*    */   public MultiModuleScriptProvider(Iterable<? extends ModuleScriptProvider> providers) {
/* 31 */     List<ModuleScriptProvider> l = new LinkedList<>();
/* 32 */     for (ModuleScriptProvider provider : providers) {
/* 33 */       l.add(provider);
/*    */     }
/* 35 */     this.providers = l.<ModuleScriptProvider>toArray(new ModuleScriptProvider[l.size()]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ModuleScript getModuleScript(Context cx, String moduleId, URI uri, URI base, Scriptable paths) throws Exception {
/* 41 */     for (ModuleScriptProvider provider : this.providers) {
/* 42 */       ModuleScript script = provider.getModuleScript(cx, moduleId, uri, base, paths);
/*    */       
/* 44 */       if (script != null) {
/* 45 */         return script;
/*    */       }
/*    */     } 
/* 48 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\MultiModuleScriptProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */