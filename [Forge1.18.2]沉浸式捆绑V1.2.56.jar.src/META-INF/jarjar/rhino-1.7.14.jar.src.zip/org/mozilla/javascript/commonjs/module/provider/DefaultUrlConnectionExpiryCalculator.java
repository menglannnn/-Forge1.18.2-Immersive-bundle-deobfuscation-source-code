/*    */ package org.mozilla.javascript.commonjs.module.provider;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.net.URLConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultUrlConnectionExpiryCalculator
/*    */   implements UrlConnectionExpiryCalculator, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final long relativeExpiry;
/*    */   
/*    */   public DefaultUrlConnectionExpiryCalculator() {
/* 26 */     this(60000L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DefaultUrlConnectionExpiryCalculator(long relativeExpiry) {
/* 35 */     if (relativeExpiry < 0L) {
/* 36 */       throw new IllegalArgumentException("relativeExpiry < 0");
/*    */     }
/* 38 */     this.relativeExpiry = relativeExpiry;
/*    */   }
/*    */ 
/*    */   
/*    */   public long calculateExpiry(URLConnection urlConnection) {
/* 43 */     return System.currentTimeMillis() + this.relativeExpiry;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\DefaultUrlConnectionExpiryCalculator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */