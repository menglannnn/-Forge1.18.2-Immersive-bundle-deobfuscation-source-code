package org.mozilla.javascript.commonjs.module.provider;

import java.net.URLConnection;

public interface UrlConnectionExpiryCalculator {
  long calculateExpiry(URLConnection paramURLConnection);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\UrlConnectionExpiryCalculator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */