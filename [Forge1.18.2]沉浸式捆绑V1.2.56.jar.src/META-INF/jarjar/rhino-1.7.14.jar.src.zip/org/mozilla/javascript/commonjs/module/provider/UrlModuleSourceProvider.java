/*     */ package org.mozilla.javascript.commonjs.module.provider;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlModuleSourceProvider
/*     */   extends ModuleSourceProviderBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Iterable<URI> privilegedUris;
/*     */   private final Iterable<URI> fallbackUris;
/*     */   private final UrlConnectionSecurityDomainProvider urlConnectionSecurityDomainProvider;
/*     */   private final UrlConnectionExpiryCalculator urlConnectionExpiryCalculator;
/*     */   
/*     */   public UrlModuleSourceProvider(Iterable<URI> privilegedUris, Iterable<URI> fallbackUris) {
/*  53 */     this(privilegedUris, fallbackUris, new DefaultUrlConnectionExpiryCalculator(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlModuleSourceProvider(Iterable<URI> privilegedUris, Iterable<URI> fallbackUris, UrlConnectionExpiryCalculator urlConnectionExpiryCalculator, UrlConnectionSecurityDomainProvider urlConnectionSecurityDomainProvider) {
/*  78 */     this.privilegedUris = privilegedUris;
/*  79 */     this.fallbackUris = fallbackUris;
/*  80 */     this.urlConnectionExpiryCalculator = urlConnectionExpiryCalculator;
/*  81 */     this.urlConnectionSecurityDomainProvider = urlConnectionSecurityDomainProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModuleSource loadFromPrivilegedLocations(String moduleId, Object validator) throws IOException, URISyntaxException {
/*  90 */     return loadFromPathList(moduleId, validator, this.privilegedUris);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModuleSource loadFromFallbackLocations(String moduleId, Object validator) throws IOException, URISyntaxException {
/*  98 */     return loadFromPathList(moduleId, validator, this.fallbackUris);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ModuleSource loadFromPathList(String moduleId, Object validator, Iterable<URI> paths) throws IOException, URISyntaxException {
/* 105 */     if (paths == null) {
/* 106 */       return null;
/*     */     }
/* 108 */     for (URI path : paths) {
/* 109 */       ModuleSource moduleSource = loadFromUri(path
/* 110 */           .resolve(moduleId), path, validator);
/* 111 */       if (moduleSource != null) {
/* 112 */         return moduleSource;
/*     */       }
/*     */     } 
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModuleSource loadFromUri(URI uri, URI base, Object validator) throws IOException, URISyntaxException {
/* 123 */     URI fullUri = new URI(uri + ".js");
/* 124 */     ModuleSource source = loadFromActualUri(fullUri, base, validator);
/*     */ 
/*     */     
/* 127 */     return (source != null) ? source : 
/* 128 */       loadFromActualUri(uri, base, validator);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ModuleSource loadFromActualUri(URI uri, URI base, Object validator) throws IOException {
/*     */     URLValidator applicableValidator;
/* 134 */     URL url = new URL((base == null) ? null : base.toURL(), uri.toString());
/* 135 */     long request_time = System.currentTimeMillis();
/* 136 */     URLConnection urlConnection = openUrlConnection(url);
/*     */     
/* 138 */     if (validator instanceof URLValidator) {
/* 139 */       URLValidator uriValidator = (URLValidator)validator;
/* 140 */       applicableValidator = uriValidator.appliesTo(uri) ? uriValidator : null;
/*     */     }
/*     */     else {
/*     */       
/* 144 */       applicableValidator = null;
/*     */     } 
/* 146 */     if (applicableValidator != null) {
/* 147 */       applicableValidator.applyConditionals(urlConnection);
/*     */     }
/*     */     try {
/* 150 */       urlConnection.connect();
/* 151 */       if (applicableValidator != null && 
/* 152 */         !applicableValidator.updateValidator(urlConnection, request_time, this.urlConnectionExpiryCalculator)) {
/*     */ 
/*     */         
/* 155 */         close(urlConnection);
/* 156 */         return NOT_MODIFIED;
/*     */       } 
/*     */       
/* 159 */       return new ModuleSource(getReader(urlConnection), 
/* 160 */           getSecurityDomain(urlConnection), uri, base, new URLValidator(uri, urlConnection, request_time, this.urlConnectionExpiryCalculator));
/*     */ 
/*     */     
/*     */     }
/* 164 */     catch (FileNotFoundException e) {
/* 165 */       return null;
/*     */     }
/* 167 */     catch (RuntimeException e) {
/* 168 */       close(urlConnection);
/* 169 */       throw e;
/*     */     }
/* 171 */     catch (IOException e) {
/* 172 */       close(urlConnection);
/* 173 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Reader getReader(URLConnection urlConnection) throws IOException {
/* 180 */     return new InputStreamReader(urlConnection.getInputStream(), 
/* 181 */         getCharacterEncoding(urlConnection));
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getCharacterEncoding(URLConnection urlConnection) {
/* 186 */     ParsedContentType pct = new ParsedContentType(urlConnection.getContentType());
/* 187 */     String encoding = pct.getEncoding();
/* 188 */     if (encoding != null) {
/* 189 */       return encoding;
/*     */     }
/* 191 */     String contentType = pct.getContentType();
/* 192 */     if (contentType != null && contentType.startsWith("text/")) {
/* 193 */       return "8859_1";
/*     */     }
/* 195 */     return "utf-8";
/*     */   }
/*     */   
/*     */   private Object getSecurityDomain(URLConnection urlConnection) {
/* 199 */     return (this.urlConnectionSecurityDomainProvider == null) ? null : this.urlConnectionSecurityDomainProvider
/* 200 */       .getSecurityDomain(urlConnection);
/*     */   }
/*     */ 
/*     */   
/*     */   private void close(URLConnection urlConnection) {
/*     */     try {
/* 206 */       urlConnection.getInputStream().close();
/*     */     }
/* 208 */     catch (IOException e) {
/* 209 */       onFailedClosingUrlConnection(urlConnection, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onFailedClosingUrlConnection(URLConnection urlConnection, IOException cause) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URLConnection openUrlConnection(URL url) throws IOException {
/* 231 */     return url.openConnection();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean entityNeedsRevalidation(Object validator) {
/* 236 */     return (!(validator instanceof URLValidator) || ((URLValidator)validator)
/* 237 */       .entityNeedsRevalidation());
/*     */   }
/*     */   
/*     */   private static class URLValidator implements Serializable {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final URI uri;
/*     */     private final long lastModified;
/*     */     private final String entityTags;
/*     */     private long expiry;
/*     */     
/*     */     public URLValidator(URI uri, URLConnection urlConnection, long request_time, UrlConnectionExpiryCalculator urlConnectionExpiryCalculator) {
/* 248 */       this.uri = uri;
/* 249 */       this.lastModified = urlConnection.getLastModified();
/* 250 */       this.entityTags = getEntityTags(urlConnection);
/* 251 */       this.expiry = calculateExpiry(urlConnection, request_time, urlConnectionExpiryCalculator);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean updateValidator(URLConnection urlConnection, long request_time, UrlConnectionExpiryCalculator urlConnectionExpiryCalculator) throws IOException {
/* 258 */       boolean isResourceChanged = isResourceChanged(urlConnection);
/* 259 */       if (!isResourceChanged) {
/* 260 */         this.expiry = calculateExpiry(urlConnection, request_time, urlConnectionExpiryCalculator);
/*     */       }
/*     */       
/* 263 */       return isResourceChanged;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isResourceChanged(URLConnection urlConnection) throws IOException {
/* 268 */       if (urlConnection instanceof HttpURLConnection) {
/* 269 */         return (((HttpURLConnection)urlConnection).getResponseCode() == 304);
/*     */       }
/*     */       
/* 272 */       return (this.lastModified != urlConnection.getLastModified());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static long calculateExpiry(URLConnection urlConnection, long request_time, UrlConnectionExpiryCalculator urlConnectionExpiryCalculator) {
/* 279 */       if ("no-cache".equals(urlConnection.getHeaderField("Pragma"))) {
/* 280 */         return 0L;
/*     */       }
/* 282 */       String cacheControl = urlConnection.getHeaderField("Cache-Control");
/*     */       
/* 284 */       if (cacheControl != null) {
/* 285 */         if (cacheControl.indexOf("no-cache") != -1) {
/* 286 */           return 0L;
/*     */         }
/* 288 */         int max_age = getMaxAge(cacheControl);
/* 289 */         if (-1 != max_age) {
/* 290 */           long response_time = System.currentTimeMillis();
/* 291 */           long apparent_age = Math.max(0L, response_time - urlConnection
/* 292 */               .getDate());
/* 293 */           long corrected_received_age = Math.max(apparent_age, urlConnection
/* 294 */               .getHeaderFieldInt("Age", 0) * 1000L);
/* 295 */           long response_delay = response_time - request_time;
/* 296 */           long corrected_initial_age = corrected_received_age + response_delay;
/*     */           
/* 298 */           long creation_time = response_time - corrected_initial_age;
/*     */           
/* 300 */           return max_age * 1000L + creation_time;
/*     */         } 
/*     */       } 
/* 303 */       long explicitExpiry = urlConnection.getHeaderFieldDate("Expires", -1L);
/*     */       
/* 305 */       if (explicitExpiry != -1L) {
/* 306 */         return explicitExpiry;
/*     */       }
/* 308 */       return (urlConnectionExpiryCalculator == null) ? 0L : urlConnectionExpiryCalculator
/* 309 */         .calculateExpiry(urlConnection);
/*     */     }
/*     */     private static int getMaxAge(String cacheControl) {
/*     */       String strAge;
/* 313 */       int maxAgeIndex = cacheControl.indexOf("max-age");
/* 314 */       if (maxAgeIndex == -1) {
/* 315 */         return -1;
/*     */       }
/* 317 */       int eq = cacheControl.indexOf('=', maxAgeIndex + 7);
/* 318 */       if (eq == -1) {
/* 319 */         return -1;
/*     */       }
/* 321 */       int comma = cacheControl.indexOf(',', eq + 1);
/*     */       
/* 323 */       if (comma == -1) {
/* 324 */         strAge = cacheControl.substring(eq + 1);
/*     */       } else {
/*     */         
/* 327 */         strAge = cacheControl.substring(eq + 1, comma);
/*     */       } 
/*     */       try {
/* 330 */         return Integer.parseInt(strAge);
/*     */       }
/* 332 */       catch (NumberFormatException e) {
/* 333 */         return -1;
/*     */       } 
/*     */     }
/*     */     
/*     */     private static String getEntityTags(URLConnection urlConnection) {
/* 338 */       List<String> etags = urlConnection.getHeaderFields().get("ETag");
/* 339 */       if (etags == null || etags.isEmpty()) {
/* 340 */         return null;
/*     */       }
/* 342 */       StringBuilder b = new StringBuilder();
/* 343 */       Iterator<String> it = etags.iterator();
/* 344 */       b.append(it.next());
/* 345 */       while (it.hasNext()) {
/* 346 */         b.append(", ").append(it.next());
/*     */       }
/* 348 */       return b.toString();
/*     */     }
/*     */     
/*     */     boolean appliesTo(URI uri) {
/* 352 */       return this.uri.equals(uri);
/*     */     }
/*     */     
/*     */     void applyConditionals(URLConnection urlConnection) {
/* 356 */       if (this.lastModified != 0L) {
/* 357 */         urlConnection.setIfModifiedSince(this.lastModified);
/*     */       }
/* 359 */       if (this.entityTags != null && this.entityTags.length() > 0) {
/* 360 */         urlConnection.addRequestProperty("If-None-Match", this.entityTags);
/*     */       }
/*     */     }
/*     */     
/*     */     boolean entityNeedsRevalidation() {
/* 365 */       return (System.currentTimeMillis() > this.expiry);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\commonjs\module\provider\UrlModuleSourceProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */