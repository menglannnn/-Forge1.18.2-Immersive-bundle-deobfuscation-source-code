/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Undefined
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 9195680630202616767L;
/*  28 */   public static final Object instance = new Undefined();
/*     */   
/*  30 */   private static final int instanceHash = System.identityHashCode(instance);
/*     */ 
/*     */ 
/*     */   
/*     */   public Object readResolve() {
/*  35 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  40 */     return (isUndefined(obj) || super.equals(obj));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  46 */     return instanceHash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final Scriptable SCRIPTABLE_UNDEFINED = new Scriptable()
/*     */     {
/*     */       public String getClassName()
/*     */       {
/*  59 */         return "undefined";
/*     */       }
/*     */ 
/*     */       
/*     */       public Object get(String name, Scriptable start) {
/*  64 */         return NOT_FOUND;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object get(int index, Scriptable start) {
/*  69 */         return NOT_FOUND;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean has(String name, Scriptable start) {
/*  74 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean has(int index, Scriptable start) {
/*  79 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public void put(String name, Scriptable start, Object value) {}
/*     */ 
/*     */       
/*     */       public void put(int index, Scriptable start, Object value) {}
/*     */ 
/*     */       
/*     */       public void delete(String name) {}
/*     */ 
/*     */       
/*     */       public void delete(int index) {}
/*     */ 
/*     */       
/*     */       public Scriptable getPrototype() {
/*  96 */         return null;
/*     */       }
/*     */ 
/*     */       
/*     */       public void setPrototype(Scriptable prototype) {}
/*     */ 
/*     */       
/*     */       public Scriptable getParentScope() {
/* 104 */         return null;
/*     */       }
/*     */ 
/*     */       
/*     */       public void setParentScope(Scriptable parent) {}
/*     */ 
/*     */       
/*     */       public Object[] getIds() {
/* 112 */         return ScriptRuntime.emptyArgs;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getDefaultValue(Class<?> hint) {
/* 117 */         if (hint == null || hint == ScriptRuntime.StringClass) {
/* 118 */           return toString();
/*     */         }
/* 120 */         return null;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean hasInstance(Scriptable instance) {
/* 125 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public String toString() {
/* 130 */         return "undefined";
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(Object obj) {
/* 135 */         return (Undefined.isUndefined(obj) || super.equals(obj));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/* 140 */         return Undefined.instanceHash;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUndefined(Object obj) {
/* 149 */     return (instance == obj || SCRIPTABLE_UNDEFINED == obj);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Undefined.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */