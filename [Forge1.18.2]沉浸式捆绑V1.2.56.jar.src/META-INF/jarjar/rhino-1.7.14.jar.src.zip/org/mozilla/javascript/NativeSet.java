/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeSet
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = -8442212766987072986L;
/*  13 */   private static final Object SET_TAG = "Set";
/*     */   
/*     */   static final String ITERATOR_TAG = "Set Iterator";
/*  16 */   static final SymbolKey GETSIZE = new SymbolKey("[Symbol.getSize]"); private boolean instanceOfSet = false; private static final int Id_constructor = 1;
/*     */   private static final int Id_add = 2;
/*  18 */   private final Hashtable entries = new Hashtable(); private static final int Id_delete = 3;
/*     */   private static final int Id_has = 4;
/*     */   private static final int Id_clear = 5;
/*     */   
/*     */   static void init(Context cx, Scriptable scope, boolean sealed) {
/*  23 */     NativeSet obj = new NativeSet();
/*  24 */     obj.exportAsJSClass(10, scope, false);
/*     */     
/*  26 */     ScriptableObject desc = (ScriptableObject)cx.newObject(scope);
/*  27 */     desc.put("enumerable", desc, Boolean.FALSE);
/*  28 */     desc.put("configurable", desc, Boolean.TRUE);
/*  29 */     desc.put("get", desc, obj.get(GETSIZE, obj));
/*  30 */     obj.defineOwnProperty(cx, "size", desc);
/*     */     
/*  32 */     if (sealed)
/*  33 */       obj.sealObject(); 
/*     */   }
/*     */   private static final int Id_keys = 6; private static final int Id_values = 6;
/*     */   private static final int Id_entries = 7;
/*     */   
/*     */   public String getClassName() {
/*  39 */     return "Set";
/*     */   }
/*     */   private static final int Id_forEach = 8;
/*     */   private static final int SymbolId_getSize = 9;
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  45 */     if (!f.hasTag(SET_TAG)) {
/*  46 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  48 */     int id = f.methodId();
/*  49 */     switch (id) {
/*     */       case 1:
/*  51 */         if (thisObj == null) {
/*  52 */           NativeSet ns = new NativeSet();
/*  53 */           ns.instanceOfSet = true;
/*  54 */           if (args.length > 0) {
/*  55 */             loadFromIterable(cx, scope, ns, NativeMap.key(args));
/*     */           }
/*  57 */           return ns;
/*     */         } 
/*  59 */         throw ScriptRuntime.typeErrorById("msg.no.new", new Object[] { "Set" });
/*     */       
/*     */       case 2:
/*  62 */         return realThis(thisObj, f).js_add(NativeMap.key(args));
/*     */       case 3:
/*  64 */         return realThis(thisObj, f).js_delete(NativeMap.key(args));
/*     */       case 4:
/*  66 */         return realThis(thisObj, f).js_has(NativeMap.key(args));
/*     */       case 5:
/*  68 */         return realThis(thisObj, f).js_clear();
/*     */       case 6:
/*  70 */         return realThis(thisObj, f)
/*  71 */           .js_iterator(scope, NativeCollectionIterator.Type.VALUES);
/*     */       case 7:
/*  73 */         return realThis(thisObj, f).js_iterator(scope, NativeCollectionIterator.Type.BOTH);
/*     */       case 8:
/*  75 */         return realThis(thisObj, f)
/*  76 */           .js_forEach(cx, scope, 
/*     */ 
/*     */             
/*  79 */             NativeMap.key(args), (args.length > 1) ? args[1] : Undefined.instance);
/*     */       
/*     */       case 9:
/*  82 */         return realThis(thisObj, f).js_getSize();
/*     */     } 
/*  84 */     throw new IllegalArgumentException("Set.prototype has no method: " + f.getFunctionName());
/*     */   }
/*     */   private static final int SymbolId_toStringTag = 10; private static final int MAX_PROTOTYPE_ID = 10;
/*     */   
/*     */   private Object js_add(Object k) {
/*  89 */     Object key = k;
/*  90 */     if (key instanceof Number && ((Number)key).doubleValue() == ScriptRuntime.negativeZero) {
/*  91 */       key = ScriptRuntime.zeroObj;
/*     */     }
/*  93 */     this.entries.put(key, key);
/*  94 */     return this;
/*     */   }
/*     */   
/*     */   private Object js_delete(Object arg) {
/*  98 */     return Boolean.valueOf(this.entries.deleteEntry(arg));
/*     */   }
/*     */   
/*     */   private Object js_has(Object arg) {
/* 102 */     return Boolean.valueOf(this.entries.has(arg));
/*     */   }
/*     */   
/*     */   private Object js_clear() {
/* 106 */     this.entries.clear();
/* 107 */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   private Object js_getSize() {
/* 111 */     return Integer.valueOf(this.entries.size());
/*     */   }
/*     */   
/*     */   private Object js_iterator(Scriptable scope, NativeCollectionIterator.Type type) {
/* 115 */     return new NativeCollectionIterator(scope, "Set Iterator", type, this.entries.iterator());
/*     */   }
/*     */   
/*     */   private Object js_forEach(Context cx, Scriptable scope, Object arg1, Object arg2) {
/* 119 */     if (!(arg1 instanceof Callable)) {
/* 120 */       throw ScriptRuntime.notFunctionError(arg1);
/*     */     }
/* 122 */     Callable f = (Callable)arg1;
/*     */     
/* 124 */     boolean isStrict = cx.isStrictMode();
/* 125 */     Iterator<Hashtable.Entry> i = this.entries.iterator();
/* 126 */     while (i.hasNext()) {
/*     */       
/* 128 */       Scriptable thisObj = ScriptRuntime.toObjectOrNull(cx, arg2, scope);
/*     */       
/* 130 */       if (thisObj == null && !isStrict) {
/* 131 */         thisObj = scope;
/*     */       }
/* 133 */       if (thisObj == null) {
/* 134 */         thisObj = Undefined.SCRIPTABLE_UNDEFINED;
/*     */       }
/*     */       
/* 137 */       Hashtable.Entry e = i.next();
/* 138 */       f.call(cx, scope, thisObj, new Object[] { e.value, e.value, this });
/*     */     } 
/* 140 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void loadFromIterable(Context cx, Scriptable scope, ScriptableObject set, Object arg1) {
/* 148 */     if (arg1 == null || Undefined.instance.equals(arg1)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 153 */     Object ito = ScriptRuntime.callIterator(arg1, cx, scope);
/* 154 */     if (Undefined.instance.equals(ito)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     ScriptableObject dummy = ensureScriptableObject(cx.newObject(scope, set.getClassName()));
/*     */     
/* 164 */     Callable add = ScriptRuntime.getPropFunctionAndThis(dummy.getPrototype(), "add", cx, scope);
/*     */     
/* 166 */     ScriptRuntime.lastStoredScriptable(cx);
/*     */ 
/*     */     
/* 169 */     try (IteratorLikeIterable it = new IteratorLikeIterable(cx, scope, ito)) {
/* 170 */       for (IteratorLikeIterable.Itr itr = it.iterator(); itr.hasNext(); ) { Object val = itr.next();
/* 171 */         Object finalVal = (val == Scriptable.NOT_FOUND) ? Undefined.instance : val;
/* 172 */         add.call(cx, scope, set, new Object[] { finalVal }); }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private static NativeSet realThis(Scriptable thisObj, IdFunctionObject f) {
/* 178 */     NativeSet ns = ensureType(thisObj, NativeSet.class, f);
/* 179 */     if (!ns.instanceOfSet)
/*     */     {
/* 181 */       throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { f.getFunctionName() });
/*     */     }
/*     */     
/* 184 */     return ns;
/*     */   }
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 189 */     switch (id) {
/*     */       case 9:
/* 191 */         initPrototypeMethod(SET_TAG, id, GETSIZE, "get size", 0);
/*     */         return;
/*     */       case 10:
/* 194 */         initPrototypeValue(10, SymbolKey.TO_STRING_TAG, 
/*     */ 
/*     */             
/* 197 */             getClassName(), 3);
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 203 */     String fnName = null;
/*     */     
/* 205 */     switch (id) {
/*     */       case 1:
/* 207 */         arity = 0;
/* 208 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 211 */         arity = 1;
/* 212 */         s = "add";
/*     */         break;
/*     */       case 3:
/* 215 */         arity = 1;
/* 216 */         s = "delete";
/*     */         break;
/*     */       case 4:
/* 219 */         arity = 1;
/* 220 */         s = "has";
/*     */         break;
/*     */       case 5:
/* 223 */         arity = 0;
/* 224 */         s = "clear";
/*     */         break;
/*     */       case 7:
/* 227 */         arity = 0;
/* 228 */         s = "entries";
/*     */         break;
/*     */       case 6:
/* 231 */         arity = 0;
/* 232 */         s = "values";
/*     */         break;
/*     */       case 8:
/* 235 */         arity = 1;
/* 236 */         s = "forEach";
/*     */         break;
/*     */       default:
/* 239 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 241 */     initPrototypeMethod(SET_TAG, id, s, fnName, arity);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(Symbol k) {
/* 246 */     if (GETSIZE.equals(k)) {
/* 247 */       return 9;
/*     */     }
/* 249 */     if (SymbolKey.ITERATOR.equals(k)) {
/* 250 */       return 6;
/*     */     }
/* 252 */     if (SymbolKey.TO_STRING_TAG.equals(k)) {
/* 253 */       return 10;
/*     */     }
/* 255 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 261 */     switch (s)
/*     */     { case "constructor":
/* 263 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 293 */         return id;case "add": id = 2; return id;case "delete": id = 3; return id;case "has": id = 4; return id;case "clear": id = 5; return id;case "keys": id = 6; return id;case "values": id = 6; return id;case "entries": id = 7; return id;case "forEach": id = 8; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */