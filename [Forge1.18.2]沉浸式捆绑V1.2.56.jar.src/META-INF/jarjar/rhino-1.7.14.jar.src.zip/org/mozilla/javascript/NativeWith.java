/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeWith
/*     */   implements Scriptable, SymbolScriptable, IdFunctionCall, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  21 */     NativeWith obj = new NativeWith();
/*     */     
/*  23 */     obj.setParentScope(scope);
/*  24 */     obj.setPrototype(ScriptableObject.getObjectPrototype(scope));
/*     */     
/*  26 */     IdFunctionObject ctor = new IdFunctionObject(obj, FTAG, 1, "With", 0, scope);
/*     */     
/*  28 */     ctor.markAsConstructor(obj);
/*  29 */     if (sealed) {
/*  30 */       ctor.sealObject();
/*     */     }
/*  32 */     ctor.exportAsScopeProperty();
/*     */   }
/*     */ 
/*     */   
/*     */   private NativeWith() {}
/*     */   
/*     */   protected NativeWith(Scriptable parent, Scriptable prototype) {
/*  39 */     this.parent = parent;
/*  40 */     this.prototype = prototype;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  45 */     return "With";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(String id, Scriptable start) {
/*  51 */     return this.prototype.has(id, this.prototype);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(Symbol key, Scriptable start) {
/*  57 */     if (this.prototype instanceof SymbolScriptable) {
/*  58 */       return ((SymbolScriptable)this.prototype).has(key, this.prototype);
/*     */     }
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/*  66 */     return this.prototype.has(index, this.prototype);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String id, Scriptable start) {
/*  72 */     if (start == this) {
/*  73 */       start = this.prototype;
/*     */     }
/*  75 */     return this.prototype.get(id, start);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Symbol key, Scriptable start) {
/*  81 */     if (start == this) {
/*  82 */       start = this.prototype;
/*     */     }
/*  84 */     if (this.prototype instanceof SymbolScriptable) {
/*  85 */       return ((SymbolScriptable)this.prototype).get(key, start);
/*     */     }
/*  87 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/*  93 */     if (start == this) {
/*  94 */       start = this.prototype;
/*     */     }
/*  96 */     return this.prototype.get(index, start);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String id, Scriptable start, Object value) {
/* 102 */     if (start == this)
/* 103 */       start = this.prototype; 
/* 104 */     this.prototype.put(id, start, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Symbol symbol, Scriptable start, Object value) {
/* 110 */     if (start == this) {
/* 111 */       start = this.prototype;
/*     */     }
/* 113 */     if (this.prototype instanceof SymbolScriptable) {
/* 114 */       ((SymbolScriptable)this.prototype).put(symbol, start, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/* 121 */     if (start == this)
/* 122 */       start = this.prototype; 
/* 123 */     this.prototype.put(index, start, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(String id) {
/* 129 */     this.prototype.delete(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(Symbol key) {
/* 135 */     if (this.prototype instanceof SymbolScriptable) {
/* 136 */       ((SymbolScriptable)this.prototype).delete(key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int index) {
/* 144 */     this.prototype.delete(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scriptable getPrototype() {
/* 149 */     return this.prototype;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrototype(Scriptable prototype) {
/* 154 */     this.prototype = prototype;
/*     */   }
/*     */ 
/*     */   
/*     */   public Scriptable getParentScope() {
/* 159 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParentScope(Scriptable parent) {
/* 164 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 169 */     return this.prototype.getIds();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class<?> typeHint) {
/* 174 */     return this.prototype.getDefaultValue(typeHint);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasInstance(Scriptable value) {
/* 179 */     return this.prototype.hasInstance(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object updateDotQuery(boolean value) {
/* 188 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 195 */     if (f.hasTag(FTAG) && 
/* 196 */       f.methodId() == 1) {
/* 197 */       throw Context.reportRuntimeErrorById("msg.cant.call.indirect", new Object[] { "With" });
/*     */     }
/*     */     
/* 200 */     throw f.unknown();
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isWithFunction(Object functionObj) {
/* 205 */     if (functionObj instanceof IdFunctionObject) {
/* 206 */       IdFunctionObject f = (IdFunctionObject)functionObj;
/* 207 */       return (f.hasTag(FTAG) && f.methodId() == 1);
/*     */     } 
/* 209 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static Object newWithSpecial(Context cx, Scriptable scope, Object[] args) {
/* 214 */     ScriptRuntime.checkDeprecated(cx, "With");
/* 215 */     scope = ScriptableObject.getTopLevelScope(scope);
/* 216 */     NativeWith thisObj = new NativeWith();
/* 217 */     thisObj.setPrototype((args.length == 0) ? 
/* 218 */         ScriptableObject.getObjectPrototype(scope) : 
/* 219 */         ScriptRuntime.toObject(cx, scope, args[0]));
/* 220 */     thisObj.setParentScope(scope);
/* 221 */     return thisObj;
/*     */   }
/*     */   
/* 224 */   private static final Object FTAG = "With";
/*     */   private static final int Id_constructor = 1;
/*     */   protected Scriptable prototype;
/*     */   protected Scriptable parent;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeWith.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */