/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaPackage
/*     */   extends ScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 7445054382212031523L;
/*     */   private String packageName;
/*     */   private transient ClassLoader classLoader;
/*     */   private Set<String> negativeCache;
/*     */   
/*     */   NativeJavaPackage(boolean internalUsage, String packageName, ClassLoader classLoader) {
/* 192 */     this.negativeCache = null;
/*     */     this.packageName = packageName;
/*     */     this.classLoader = classLoader;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public NativeJavaPackage(String packageName, ClassLoader classLoader) {
/*     */     this(false, packageName, classLoader);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public NativeJavaPackage(String packageName) {
/*     */     this(false, packageName, Context.getCurrentContext().getApplicationClassLoader());
/*     */   }
/*     */   
/*     */   public String getClassName() {
/*     */     return "JavaPackage";
/*     */   }
/*     */   
/*     */   public boolean has(String id, Scriptable start) {
/*     */     return true;
/*     */   }
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/*     */     return false;
/*     */   }
/*     */   
/*     */   public void put(String id, Scriptable start, Object value) {}
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/*     */     throw Context.reportRuntimeErrorById("msg.pkg.int", new Object[0]);
/*     */   }
/*     */   
/*     */   public Object get(String id, Scriptable start) {
/*     */     return getPkgProperty(id, start, true);
/*     */   }
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/*     */     return NOT_FOUND;
/*     */   }
/*     */   
/*     */   NativeJavaPackage forcePackage(String name, Scriptable scope) {
/*     */     Object cached = super.get(name, this);
/*     */     if (cached != null && cached instanceof NativeJavaPackage)
/*     */       return (NativeJavaPackage)cached; 
/*     */     String newPackage = (this.packageName.length() == 0) ? name : (this.packageName + "." + name);
/*     */     NativeJavaPackage pkg = new NativeJavaPackage(true, newPackage, this.classLoader);
/*     */     ScriptRuntime.setObjectProtoAndParent(pkg, scope);
/*     */     super.put(name, this, pkg);
/*     */     return pkg;
/*     */   }
/*     */   
/*     */   synchronized Object getPkgProperty(String name, Scriptable start, boolean createPkg) {
/*     */     Object cached = super.get(name, start);
/*     */     if (cached != NOT_FOUND)
/*     */       return cached; 
/*     */     if (this.negativeCache != null && this.negativeCache.contains(name))
/*     */       return null; 
/*     */     String className = (this.packageName.length() == 0) ? name : (this.packageName + '.' + name);
/*     */     Context cx = Context.getContext();
/*     */     ClassShutter shutter = cx.getClassShutter();
/*     */     Scriptable newValue = null;
/*     */     if (shutter == null || shutter.visibleToScripts(className)) {
/*     */       Class<?> cl = null;
/*     */       if (this.classLoader != null) {
/*     */         cl = Kit.classOrNull(this.classLoader, className);
/*     */       } else {
/*     */         cl = Kit.classOrNull(className);
/*     */       } 
/*     */       if (cl != null) {
/*     */         WrapFactory wrapFactory = cx.getWrapFactory();
/*     */         newValue = wrapFactory.wrapJavaClass(cx, getTopLevelScope(this), cl);
/*     */         newValue.setPrototype(getPrototype());
/*     */       } 
/*     */     } 
/*     */     if (newValue == null)
/*     */       if (createPkg) {
/*     */         NativeJavaPackage pkg = new NativeJavaPackage(true, className, this.classLoader);
/*     */         ScriptRuntime.setObjectProtoAndParent(pkg, getParentScope());
/*     */         newValue = pkg;
/*     */       } else {
/*     */         if (this.negativeCache == null)
/*     */           this.negativeCache = new HashSet<>(); 
/*     */         this.negativeCache.add(name);
/*     */       }  
/*     */     if (newValue != null)
/*     */       super.put(name, start, newValue); 
/*     */     return newValue;
/*     */   }
/*     */   
/*     */   public Object getDefaultValue(Class<?> ignored) {
/*     */     return toString();
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/*     */     in.defaultReadObject();
/*     */     this.classLoader = Context.getCurrentContext().getApplicationClassLoader();
/*     */   }
/*     */   
/*     */   public String toString() {
/*     */     return "[JavaPackage " + this.packageName + "]";
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*     */     if (obj instanceof NativeJavaPackage) {
/*     */       NativeJavaPackage njp = (NativeJavaPackage)obj;
/*     */       return (this.packageName.equals(njp.packageName) && this.classLoader == njp.classLoader);
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return this.packageName.hashCode() ^ ((this.classLoader == null) ? 0 : this.classLoader.hashCode());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeJavaPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */