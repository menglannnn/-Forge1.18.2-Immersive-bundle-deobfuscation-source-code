/*      */ package org.mozilla.javascript.tools.debugger;
/*      */ 
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import org.mozilla.javascript.Callable;
/*      */ import org.mozilla.javascript.Context;
/*      */ import org.mozilla.javascript.ContextAction;
/*      */ import org.mozilla.javascript.ContextFactory;
/*      */ import org.mozilla.javascript.ImporterTopLevel;
/*      */ import org.mozilla.javascript.Kit;
/*      */ import org.mozilla.javascript.ObjArray;
/*      */ import org.mozilla.javascript.ScriptRuntime;
/*      */ import org.mozilla.javascript.Scriptable;
/*      */ import org.mozilla.javascript.ScriptableObject;
/*      */ import org.mozilla.javascript.Undefined;
/*      */ import org.mozilla.javascript.debug.DebugFrame;
/*      */ import org.mozilla.javascript.debug.DebuggableObject;
/*      */ import org.mozilla.javascript.debug.DebuggableScript;
/*      */ import org.mozilla.javascript.debug.Debugger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Dim
/*      */ {
/*      */   public static final int STEP_OVER = 0;
/*      */   public static final int STEP_INTO = 1;
/*      */   public static final int STEP_OUT = 2;
/*      */   public static final int GO = 3;
/*      */   public static final int BREAK = 4;
/*      */   public static final int EXIT = 5;
/*      */   private static final int IPROXY_DEBUG = 0;
/*      */   private static final int IPROXY_LISTEN = 1;
/*      */   private static final int IPROXY_COMPILE_SCRIPT = 2;
/*      */   private static final int IPROXY_EVAL_SCRIPT = 3;
/*      */   private static final int IPROXY_STRING_IS_COMPILABLE = 4;
/*      */   private static final int IPROXY_OBJECT_TO_STRING = 5;
/*      */   private static final int IPROXY_OBJECT_PROPERTY = 6;
/*      */   private static final int IPROXY_OBJECT_IDS = 7;
/*      */   private GuiCallback callback;
/*      */   private boolean breakFlag;
/*      */   private ScopeProvider scopeProvider;
/*      */   private SourceProvider sourceProvider;
/*   84 */   private int frameIndex = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile ContextData interruptedContextData;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ContextFactory contextFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  100 */   private Object monitor = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   private Object eventThreadMonitor = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  111 */   private volatile int returnValue = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean insideInterruptLoop;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String evalRequest;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StackFrame evalFrame;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String evalResult;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean breakOnExceptions;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean breakOnEnter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean breakOnReturn;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  154 */   private final Map<String, SourceInfo> urlToSourceInfo = Collections.synchronizedMap(new HashMap<>());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   private final Map<String, FunctionSource> functionNames = Collections.synchronizedMap(new HashMap<>());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   private final Map<DebuggableScript, FunctionSource> functionToSource = Collections.synchronizedMap(new HashMap<>());
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DimIProxy listener;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGuiCallback(GuiCallback callback) {
/*  177 */     this.callback = callback;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBreak() {
/*  184 */     this.breakFlag = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScopeProvider(ScopeProvider scopeProvider) {
/*  191 */     this.scopeProvider = scopeProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSourceProvider(SourceProvider sourceProvider) {
/*  198 */     this.sourceProvider = sourceProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void contextSwitch(int frameIndex) {
/*  205 */     this.frameIndex = frameIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBreakOnExceptions(boolean breakOnExceptions) {
/*  212 */     this.breakOnExceptions = breakOnExceptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBreakOnEnter(boolean breakOnEnter) {
/*  219 */     this.breakOnEnter = breakOnEnter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBreakOnReturn(boolean breakOnReturn) {
/*  226 */     this.breakOnReturn = breakOnReturn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void attachTo(ContextFactory factory) {
/*  233 */     detach();
/*  234 */     this.contextFactory = factory;
/*  235 */     this.listener = new DimIProxy(this, 1);
/*  236 */     factory.addListener(this.listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void detach() {
/*  243 */     if (this.listener != null) {
/*  244 */       this.contextFactory.removeListener(this.listener);
/*  245 */       this.contextFactory = null;
/*  246 */       this.listener = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  254 */     detach();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FunctionSource getFunctionSource(DebuggableScript fnOrScript) {
/*  261 */     FunctionSource fsource = functionSource(fnOrScript);
/*  262 */     if (fsource == null) {
/*  263 */       String url = getNormalizedUrl(fnOrScript);
/*  264 */       SourceInfo si = sourceInfo(url);
/*  265 */       if (si == null && 
/*  266 */         !fnOrScript.isGeneratedScript()) {
/*      */         
/*  268 */         String source = loadSource(url);
/*  269 */         if (source != null) {
/*  270 */           DebuggableScript top = fnOrScript;
/*      */           while (true) {
/*  272 */             DebuggableScript parent = top.getParent();
/*  273 */             if (parent == null) {
/*      */               break;
/*      */             }
/*  276 */             top = parent;
/*      */           } 
/*  278 */           registerTopScript(top, source);
/*  279 */           fsource = functionSource(fnOrScript);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  284 */     return fsource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String loadSource(String sourceUrl) {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore_2
/*      */     //   2: aload_1
/*      */     //   3: bipush #35
/*      */     //   5: invokevirtual indexOf : (I)I
/*      */     //   8: istore_3
/*      */     //   9: iload_3
/*      */     //   10: iflt -> 20
/*      */     //   13: aload_1
/*      */     //   14: iconst_0
/*      */     //   15: iload_3
/*      */     //   16: invokevirtual substring : (II)Ljava/lang/String;
/*      */     //   19: astore_1
/*      */     //   20: aload_1
/*      */     //   21: bipush #58
/*      */     //   23: invokevirtual indexOf : (I)I
/*      */     //   26: ifge -> 220
/*      */     //   29: aload_1
/*      */     //   30: ldc '~/'
/*      */     //   32: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   35: ifeq -> 99
/*      */     //   38: ldc 'user.home'
/*      */     //   40: invokestatic getSystemProperty : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   43: astore #5
/*      */     //   45: aload #5
/*      */     //   47: ifnull -> 99
/*      */     //   50: aload_1
/*      */     //   51: iconst_2
/*      */     //   52: invokevirtual substring : (I)Ljava/lang/String;
/*      */     //   55: astore #6
/*      */     //   57: new java/io/File
/*      */     //   60: dup
/*      */     //   61: new java/io/File
/*      */     //   64: dup
/*      */     //   65: aload #5
/*      */     //   67: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   70: aload #6
/*      */     //   72: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
/*      */     //   75: astore #7
/*      */     //   77: aload #7
/*      */     //   79: invokevirtual exists : ()Z
/*      */     //   82: ifeq -> 99
/*      */     //   85: new java/io/FileInputStream
/*      */     //   88: dup
/*      */     //   89: aload #7
/*      */     //   91: invokespecial <init> : (Ljava/io/File;)V
/*      */     //   94: astore #4
/*      */     //   96: goto -> 233
/*      */     //   99: new java/io/File
/*      */     //   102: dup
/*      */     //   103: aload_1
/*      */     //   104: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   107: astore #5
/*      */     //   109: aload #5
/*      */     //   111: invokevirtual exists : ()Z
/*      */     //   114: ifeq -> 131
/*      */     //   117: new java/io/FileInputStream
/*      */     //   120: dup
/*      */     //   121: aload #5
/*      */     //   123: invokespecial <init> : (Ljava/io/File;)V
/*      */     //   126: astore #4
/*      */     //   128: goto -> 233
/*      */     //   131: goto -> 136
/*      */     //   134: astore #5
/*      */     //   136: aload_1
/*      */     //   137: ldc '//'
/*      */     //   139: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   142: ifeq -> 168
/*      */     //   145: new java/lang/StringBuilder
/*      */     //   148: dup
/*      */     //   149: invokespecial <init> : ()V
/*      */     //   152: ldc 'http:'
/*      */     //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   157: aload_1
/*      */     //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   161: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   164: astore_1
/*      */     //   165: goto -> 220
/*      */     //   168: aload_1
/*      */     //   169: ldc '/'
/*      */     //   171: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   174: ifeq -> 200
/*      */     //   177: new java/lang/StringBuilder
/*      */     //   180: dup
/*      */     //   181: invokespecial <init> : ()V
/*      */     //   184: ldc 'http://127.0.0.1'
/*      */     //   186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   189: aload_1
/*      */     //   190: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   193: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   196: astore_1
/*      */     //   197: goto -> 220
/*      */     //   200: new java/lang/StringBuilder
/*      */     //   203: dup
/*      */     //   204: invokespecial <init> : ()V
/*      */     //   207: ldc 'http://'
/*      */     //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   212: aload_1
/*      */     //   213: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   216: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   219: astore_1
/*      */     //   220: new java/net/URL
/*      */     //   223: dup
/*      */     //   224: aload_1
/*      */     //   225: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   228: invokevirtual openStream : ()Ljava/io/InputStream;
/*      */     //   231: astore #4
/*      */     //   233: new java/io/InputStreamReader
/*      */     //   236: dup
/*      */     //   237: aload #4
/*      */     //   239: invokespecial <init> : (Ljava/io/InputStream;)V
/*      */     //   242: invokestatic readReader : (Ljava/io/Reader;)Ljava/lang/String;
/*      */     //   245: astore_2
/*      */     //   246: aload #4
/*      */     //   248: invokevirtual close : ()V
/*      */     //   251: goto -> 264
/*      */     //   254: astore #8
/*      */     //   256: aload #4
/*      */     //   258: invokevirtual close : ()V
/*      */     //   261: aload #8
/*      */     //   263: athrow
/*      */     //   264: goto -> 304
/*      */     //   267: astore #4
/*      */     //   269: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*      */     //   272: new java/lang/StringBuilder
/*      */     //   275: dup
/*      */     //   276: invokespecial <init> : ()V
/*      */     //   279: ldc 'Failed to load source from '
/*      */     //   281: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   284: aload_1
/*      */     //   285: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   288: ldc ': '
/*      */     //   290: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   293: aload #4
/*      */     //   295: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   298: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   301: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   304: aload_2
/*      */     //   305: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #291	-> 0
/*      */     //   #292	-> 2
/*      */     //   #293	-> 9
/*      */     //   #294	-> 13
/*      */     //   #300	-> 20
/*      */     //   #303	-> 29
/*      */     //   #304	-> 38
/*      */     //   #305	-> 45
/*      */     //   #306	-> 50
/*      */     //   #307	-> 57
/*      */     //   #308	-> 77
/*      */     //   #309	-> 85
/*      */     //   #310	-> 96
/*      */     //   #314	-> 99
/*      */     //   #315	-> 109
/*      */     //   #316	-> 117
/*      */     //   #317	-> 128
/*      */     //   #319	-> 131
/*      */     //   #321	-> 136
/*      */     //   #322	-> 145
/*      */     //   #323	-> 168
/*      */     //   #324	-> 177
/*      */     //   #326	-> 200
/*      */     //   #330	-> 220
/*      */     //   #334	-> 233
/*      */     //   #336	-> 246
/*      */     //   #337	-> 251
/*      */     //   #336	-> 254
/*      */     //   #337	-> 261
/*      */     //   #341	-> 264
/*      */     //   #338	-> 267
/*      */     //   #339	-> 269
/*      */     //   #340	-> 301
/*      */     //   #342	-> 304
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   96	3	4	is	Ljava/io/InputStream;
/*      */     //   57	42	6	pathFromHome	Ljava/lang/String;
/*      */     //   77	22	7	f	Ljava/io/File;
/*      */     //   45	54	5	home	Ljava/lang/String;
/*      */     //   128	3	4	is	Ljava/io/InputStream;
/*      */     //   109	22	5	f	Ljava/io/File;
/*      */     //   233	31	4	is	Ljava/io/InputStream;
/*      */     //   269	35	4	ex	Ljava/io/IOException;
/*      */     //   0	306	0	this	Lorg/mozilla/javascript/tools/debugger/Dim;
/*      */     //   0	306	1	sourceUrl	Ljava/lang/String;
/*      */     //   2	304	2	source	Ljava/lang/String;
/*      */     //   9	297	3	hash	I
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   20	264	267	java/io/IOException
/*      */     //   29	96	134	java/lang/SecurityException
/*      */     //   99	128	134	java/lang/SecurityException
/*      */     //   233	246	254	finally
/*      */     //   254	256	254	finally
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void registerTopScript(DebuggableScript topScript, String source) {
/*  349 */     if (!topScript.isTopLevel()) {
/*  350 */       throw new IllegalArgumentException();
/*      */     }
/*  352 */     String url = getNormalizedUrl(topScript);
/*  353 */     DebuggableScript[] functions = getAllFunctions(topScript);
/*  354 */     if (this.sourceProvider != null) {
/*  355 */       String providedSource = this.sourceProvider.getSource(topScript);
/*  356 */       if (providedSource != null) {
/*  357 */         source = providedSource;
/*      */       }
/*      */     } 
/*      */     
/*  361 */     SourceInfo sourceInfo = new SourceInfo(source, functions, url);
/*      */     
/*  363 */     synchronized (this.urlToSourceInfo) {
/*  364 */       SourceInfo old = this.urlToSourceInfo.get(url);
/*  365 */       if (old != null) {
/*  366 */         sourceInfo.copyBreakpointsFrom(old);
/*      */       }
/*  368 */       this.urlToSourceInfo.put(url, sourceInfo);
/*  369 */       for (int i = 0; i != sourceInfo.functionSourcesTop(); i++) {
/*  370 */         FunctionSource fsource = sourceInfo.functionSource(i);
/*  371 */         String name = fsource.name();
/*  372 */         if (name.length() != 0) {
/*  373 */           this.functionNames.put(name, fsource);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  378 */     synchronized (this.functionToSource) {
/*  379 */       for (int i = 0; i != functions.length; i++) {
/*  380 */         FunctionSource fsource = sourceInfo.functionSource(i);
/*  381 */         this.functionToSource.put(functions[i], fsource);
/*      */       } 
/*      */     } 
/*      */     
/*  385 */     this.callback.updateSourceText(sourceInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FunctionSource functionSource(DebuggableScript fnOrScript) {
/*  392 */     return this.functionToSource.get(fnOrScript);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] functionNames() {
/*  399 */     synchronized (this.urlToSourceInfo) {
/*  400 */       return (String[])this.functionNames.keySet().toArray((Object[])new String[this.functionNames.size()]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FunctionSource functionSourceByName(String functionName) {
/*  408 */     return this.functionNames.get(functionName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SourceInfo sourceInfo(String url) {
/*  415 */     return this.urlToSourceInfo.get(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getNormalizedUrl(DebuggableScript fnOrScript) {
/*  422 */     String url = fnOrScript.getSourceName();
/*  423 */     if (url == null) { url = "<stdin>";
/*      */        }
/*      */     
/*      */     else
/*      */     
/*      */     { 
/*  429 */       char evalSeparator = '#';
/*  430 */       StringBuilder sb = null;
/*  431 */       int urlLength = url.length();
/*  432 */       int cursor = 0;
/*      */       while (true) {
/*  434 */         int searchStart = url.indexOf(evalSeparator, cursor);
/*  435 */         if (searchStart < 0) {
/*      */           break;
/*      */         }
/*  438 */         String replace = null;
/*  439 */         int i = searchStart + 1;
/*  440 */         while (i != urlLength) {
/*  441 */           int c = url.charAt(i);
/*  442 */           if (48 > c || c > 57) {
/*      */             break;
/*      */           }
/*  445 */           i++;
/*      */         } 
/*  447 */         if (i != searchStart + 1)
/*      */         {
/*  449 */           if ("(eval)".regionMatches(0, url, i, 6)) {
/*  450 */             cursor = i + 6;
/*  451 */             replace = "(eval)";
/*      */           } 
/*      */         }
/*  454 */         if (replace == null) {
/*      */           break;
/*      */         }
/*  457 */         if (sb == null) {
/*  458 */           sb = new StringBuilder();
/*  459 */           sb.append(url.substring(0, searchStart));
/*      */         } 
/*  461 */         sb.append(replace);
/*      */       } 
/*  463 */       if (sb != null) {
/*  464 */         if (cursor != urlLength) {
/*  465 */           sb.append(url.substring(cursor));
/*      */         }
/*  467 */         url = sb.toString();
/*      */       }  }
/*      */     
/*  470 */     return url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static DebuggableScript[] getAllFunctions(DebuggableScript function) {
/*  478 */     ObjArray functions = new ObjArray();
/*  479 */     collectFunctions_r(function, functions);
/*  480 */     DebuggableScript[] result = new DebuggableScript[functions.size()];
/*  481 */     functions.toArray((Object[])result);
/*  482 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void collectFunctions_r(DebuggableScript function, ObjArray array) {
/*  490 */     array.add(function);
/*  491 */     for (int i = 0; i != function.getFunctionCount(); i++) {
/*  492 */       collectFunctions_r(function.getFunction(i), array);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearAllBreakpoints() {
/*  500 */     for (SourceInfo si : this.urlToSourceInfo.values()) {
/*  501 */       si.removeAllBreakpoints();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleBreakpointHit(StackFrame frame, Context cx) {
/*  509 */     this.breakFlag = false;
/*  510 */     interrupted(cx, frame, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleExceptionThrown(Context cx, Throwable ex, StackFrame frame) {
/*  518 */     if (this.breakOnExceptions) {
/*  519 */       ContextData cd = frame.contextData();
/*  520 */       if (cd.lastProcessedException != ex) {
/*  521 */         interrupted(cx, frame, ex);
/*  522 */         cd.lastProcessedException = ex;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextData currentContextData() {
/*  531 */     return this.interruptedContextData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReturnValue(int returnValue) {
/*  538 */     synchronized (this.monitor) {
/*  539 */       this.returnValue = returnValue;
/*  540 */       this.monitor.notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void go() {
/*  548 */     synchronized (this.monitor) {
/*  549 */       this.returnValue = 3;
/*  550 */       this.monitor.notifyAll();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String eval(String expr) {
/*  558 */     String result = "undefined";
/*  559 */     if (expr == null) {
/*  560 */       return result;
/*      */     }
/*  562 */     ContextData contextData = currentContextData();
/*  563 */     if (contextData == null || this.frameIndex >= contextData.frameCount()) {
/*  564 */       return result;
/*      */     }
/*  566 */     StackFrame frame = contextData.getFrame(this.frameIndex);
/*  567 */     if (contextData.eventThreadFlag) {
/*  568 */       Context cx = Context.getCurrentContext();
/*  569 */       result = do_eval(cx, frame, expr);
/*      */     } else {
/*  571 */       synchronized (this.monitor) {
/*  572 */         if (this.insideInterruptLoop) {
/*  573 */           this.evalRequest = expr;
/*  574 */           this.evalFrame = frame;
/*  575 */           this.monitor.notify();
/*      */           do {
/*      */             try {
/*  578 */               this.monitor.wait();
/*  579 */             } catch (InterruptedException exc) {
/*  580 */               Thread.currentThread().interrupt();
/*      */               break;
/*      */             } 
/*  583 */           } while (this.evalRequest != null);
/*  584 */           result = this.evalResult;
/*      */         } 
/*      */       } 
/*      */     } 
/*  588 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void compileScript(String url, String text) {
/*  595 */     DimIProxy action = new DimIProxy(this, 2);
/*  596 */     action.url = url;
/*  597 */     action.text = text;
/*  598 */     action.withContext();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void evalScript(String url, String text) {
/*  605 */     DimIProxy action = new DimIProxy(this, 3);
/*  606 */     action.url = url;
/*  607 */     action.text = text;
/*  608 */     action.withContext();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String objectToString(Object object) {
/*  615 */     DimIProxy action = new DimIProxy(this, 5);
/*  616 */     action.object = object;
/*  617 */     action.withContext();
/*  618 */     return action.stringResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean stringIsCompilableUnit(String str) {
/*  625 */     DimIProxy action = new DimIProxy(this, 4);
/*  626 */     action.text = str;
/*  627 */     action.withContext();
/*  628 */     return action.booleanResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObjectProperty(Object object, Object id) {
/*  635 */     DimIProxy action = new DimIProxy(this, 6);
/*  636 */     action.object = object;
/*  637 */     action.id = id;
/*  638 */     action.withContext();
/*  639 */     return action.objectResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getObjectIds(Object object) {
/*  646 */     DimIProxy action = new DimIProxy(this, 7);
/*  647 */     action.object = object;
/*  648 */     action.withContext();
/*  649 */     return action.objectArrayResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getObjectPropertyImpl(Context cx, Object object, Object id) {
/*      */     Object result;
/*  657 */     Scriptable scriptable = (Scriptable)object;
/*      */     
/*  659 */     if (id instanceof String) {
/*  660 */       String name = (String)id;
/*  661 */       if (name.equals("this")) {
/*  662 */         result = scriptable;
/*  663 */       } else if (name.equals("__proto__")) {
/*  664 */         result = scriptable.getPrototype();
/*  665 */       } else if (name.equals("__parent__")) {
/*  666 */         result = scriptable.getParentScope();
/*      */       } else {
/*  668 */         result = ScriptableObject.getProperty(scriptable, name);
/*  669 */         if (result == ScriptableObject.NOT_FOUND) {
/*  670 */           result = Undefined.instance;
/*      */         }
/*      */       } 
/*      */     } else {
/*  674 */       int index = ((Integer)id).intValue();
/*  675 */       result = ScriptableObject.getProperty(scriptable, index);
/*  676 */       if (result == ScriptableObject.NOT_FOUND) {
/*  677 */         result = Undefined.instance;
/*      */       }
/*      */     } 
/*  680 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object[] getObjectIdsImpl(Context cx, Object object) {
/*      */     Object[] ids;
/*  687 */     if (!(object instanceof Scriptable) || object == Undefined.instance) {
/*  688 */       return Context.emptyArgs;
/*      */     }
/*      */ 
/*      */     
/*  692 */     Scriptable scriptable = (Scriptable)object;
/*  693 */     if (scriptable instanceof DebuggableObject) {
/*  694 */       ids = ((DebuggableObject)scriptable).getAllIds();
/*      */     } else {
/*  696 */       ids = scriptable.getIds();
/*      */     } 
/*      */     
/*  699 */     Scriptable proto = scriptable.getPrototype();
/*  700 */     Scriptable parent = scriptable.getParentScope();
/*  701 */     int extra = 0;
/*  702 */     if (proto != null) {
/*  703 */       extra++;
/*      */     }
/*  705 */     if (parent != null) {
/*  706 */       extra++;
/*      */     }
/*  708 */     if (extra != 0) {
/*  709 */       Object[] tmp = new Object[extra + ids.length];
/*  710 */       System.arraycopy(ids, 0, tmp, extra, ids.length);
/*  711 */       ids = tmp;
/*  712 */       extra = 0;
/*  713 */       if (proto != null) {
/*  714 */         ids[extra++] = "__proto__";
/*      */       }
/*  716 */       if (parent != null) {
/*  717 */         ids[extra++] = "__parent__";
/*      */       }
/*      */     } 
/*      */     
/*  721 */     return ids;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void interrupted(Context cx, StackFrame frame, Throwable scriptException) {
/*      */     // Byte code:
/*      */     //   0: aload_2
/*      */     //   1: invokevirtual contextData : ()Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;
/*      */     //   4: astore #4
/*      */     //   6: aload_0
/*      */     //   7: getfield callback : Lorg/mozilla/javascript/tools/debugger/GuiCallback;
/*      */     //   10: invokeinterface isGuiEventThread : ()Z
/*      */     //   15: istore #5
/*      */     //   17: aload #4
/*      */     //   19: iload #5
/*      */     //   21: invokestatic access$402 : (Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;Z)Z
/*      */     //   24: pop
/*      */     //   25: iconst_0
/*      */     //   26: istore #6
/*      */     //   28: aload_0
/*      */     //   29: getfield eventThreadMonitor : Ljava/lang/Object;
/*      */     //   32: dup
/*      */     //   33: astore #7
/*      */     //   35: monitorenter
/*      */     //   36: iload #5
/*      */     //   38: ifeq -> 57
/*      */     //   41: aload_0
/*      */     //   42: getfield interruptedContextData : Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;
/*      */     //   45: ifnull -> 80
/*      */     //   48: iconst_1
/*      */     //   49: istore #6
/*      */     //   51: aload #7
/*      */     //   53: monitorexit
/*      */     //   54: goto -> 100
/*      */     //   57: aload_0
/*      */     //   58: getfield interruptedContextData : Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;
/*      */     //   61: ifnull -> 80
/*      */     //   64: aload_0
/*      */     //   65: getfield eventThreadMonitor : Ljava/lang/Object;
/*      */     //   68: invokevirtual wait : ()V
/*      */     //   71: goto -> 57
/*      */     //   74: astore #8
/*      */     //   76: aload #7
/*      */     //   78: monitorexit
/*      */     //   79: return
/*      */     //   80: aload_0
/*      */     //   81: aload #4
/*      */     //   83: putfield interruptedContextData : Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;
/*      */     //   86: aload #7
/*      */     //   88: monitorexit
/*      */     //   89: goto -> 100
/*      */     //   92: astore #9
/*      */     //   94: aload #7
/*      */     //   96: monitorexit
/*      */     //   97: aload #9
/*      */     //   99: athrow
/*      */     //   100: iload #6
/*      */     //   102: ifeq -> 106
/*      */     //   105: return
/*      */     //   106: aload_0
/*      */     //   107: getfield interruptedContextData : Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;
/*      */     //   110: ifnonnull -> 117
/*      */     //   113: invokestatic codeBug : ()Ljava/lang/RuntimeException;
/*      */     //   116: pop
/*      */     //   117: aload #4
/*      */     //   119: invokevirtual frameCount : ()I
/*      */     //   122: istore #7
/*      */     //   124: aload_0
/*      */     //   125: iload #7
/*      */     //   127: iconst_1
/*      */     //   128: isub
/*      */     //   129: putfield frameIndex : I
/*      */     //   132: invokestatic currentThread : ()Ljava/lang/Thread;
/*      */     //   135: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   138: astore #8
/*      */     //   140: aload_3
/*      */     //   141: ifnonnull -> 150
/*      */     //   144: aconst_null
/*      */     //   145: astore #9
/*      */     //   147: goto -> 156
/*      */     //   150: aload_3
/*      */     //   151: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   154: astore #9
/*      */     //   156: iconst_m1
/*      */     //   157: istore #10
/*      */     //   159: iload #5
/*      */     //   161: ifne -> 358
/*      */     //   164: aload_0
/*      */     //   165: getfield monitor : Ljava/lang/Object;
/*      */     //   168: dup
/*      */     //   169: astore #11
/*      */     //   171: monitorenter
/*      */     //   172: aload_0
/*      */     //   173: getfield insideInterruptLoop : Z
/*      */     //   176: ifeq -> 183
/*      */     //   179: invokestatic codeBug : ()Ljava/lang/RuntimeException;
/*      */     //   182: pop
/*      */     //   183: aload_0
/*      */     //   184: iconst_1
/*      */     //   185: putfield insideInterruptLoop : Z
/*      */     //   188: aload_0
/*      */     //   189: aconst_null
/*      */     //   190: putfield evalRequest : Ljava/lang/String;
/*      */     //   193: aload_0
/*      */     //   194: iconst_m1
/*      */     //   195: putfield returnValue : I
/*      */     //   198: aload_0
/*      */     //   199: getfield callback : Lorg/mozilla/javascript/tools/debugger/GuiCallback;
/*      */     //   202: aload_2
/*      */     //   203: aload #8
/*      */     //   205: aload #9
/*      */     //   207: invokeinterface enterInterrupt : (Lorg/mozilla/javascript/tools/debugger/Dim$StackFrame;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   212: aload_0
/*      */     //   213: getfield monitor : Ljava/lang/Object;
/*      */     //   216: invokevirtual wait : ()V
/*      */     //   219: goto -> 233
/*      */     //   222: astore #12
/*      */     //   224: invokestatic currentThread : ()Ljava/lang/Thread;
/*      */     //   227: invokevirtual interrupt : ()V
/*      */     //   230: goto -> 323
/*      */     //   233: aload_0
/*      */     //   234: getfield evalRequest : Ljava/lang/String;
/*      */     //   237: ifnull -> 306
/*      */     //   240: aload_0
/*      */     //   241: aconst_null
/*      */     //   242: putfield evalResult : Ljava/lang/String;
/*      */     //   245: aload_0
/*      */     //   246: aload_1
/*      */     //   247: aload_0
/*      */     //   248: getfield evalFrame : Lorg/mozilla/javascript/tools/debugger/Dim$StackFrame;
/*      */     //   251: aload_0
/*      */     //   252: getfield evalRequest : Ljava/lang/String;
/*      */     //   255: invokestatic do_eval : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/tools/debugger/Dim$StackFrame;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   258: putfield evalResult : Ljava/lang/String;
/*      */     //   261: aload_0
/*      */     //   262: aconst_null
/*      */     //   263: putfield evalRequest : Ljava/lang/String;
/*      */     //   266: aload_0
/*      */     //   267: aconst_null
/*      */     //   268: putfield evalFrame : Lorg/mozilla/javascript/tools/debugger/Dim$StackFrame;
/*      */     //   271: aload_0
/*      */     //   272: getfield monitor : Ljava/lang/Object;
/*      */     //   275: invokevirtual notify : ()V
/*      */     //   278: goto -> 303
/*      */     //   281: astore #13
/*      */     //   283: aload_0
/*      */     //   284: aconst_null
/*      */     //   285: putfield evalRequest : Ljava/lang/String;
/*      */     //   288: aload_0
/*      */     //   289: aconst_null
/*      */     //   290: putfield evalFrame : Lorg/mozilla/javascript/tools/debugger/Dim$StackFrame;
/*      */     //   293: aload_0
/*      */     //   294: getfield monitor : Ljava/lang/Object;
/*      */     //   297: invokevirtual notify : ()V
/*      */     //   300: aload #13
/*      */     //   302: athrow
/*      */     //   303: goto -> 212
/*      */     //   306: aload_0
/*      */     //   307: getfield returnValue : I
/*      */     //   310: iconst_m1
/*      */     //   311: if_icmpeq -> 212
/*      */     //   314: aload_0
/*      */     //   315: getfield returnValue : I
/*      */     //   318: istore #10
/*      */     //   320: goto -> 323
/*      */     //   323: aload_0
/*      */     //   324: iconst_0
/*      */     //   325: putfield insideInterruptLoop : Z
/*      */     //   328: goto -> 341
/*      */     //   331: astore #14
/*      */     //   333: aload_0
/*      */     //   334: iconst_0
/*      */     //   335: putfield insideInterruptLoop : Z
/*      */     //   338: aload #14
/*      */     //   340: athrow
/*      */     //   341: aload #11
/*      */     //   343: monitorexit
/*      */     //   344: goto -> 355
/*      */     //   347: astore #15
/*      */     //   349: aload #11
/*      */     //   351: monitorexit
/*      */     //   352: aload #15
/*      */     //   354: athrow
/*      */     //   355: goto -> 408
/*      */     //   358: aload_0
/*      */     //   359: iconst_m1
/*      */     //   360: putfield returnValue : I
/*      */     //   363: aload_0
/*      */     //   364: getfield callback : Lorg/mozilla/javascript/tools/debugger/GuiCallback;
/*      */     //   367: aload_2
/*      */     //   368: aload #8
/*      */     //   370: aload #9
/*      */     //   372: invokeinterface enterInterrupt : (Lorg/mozilla/javascript/tools/debugger/Dim$StackFrame;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   377: aload_0
/*      */     //   378: getfield returnValue : I
/*      */     //   381: iconst_m1
/*      */     //   382: if_icmpne -> 402
/*      */     //   385: aload_0
/*      */     //   386: getfield callback : Lorg/mozilla/javascript/tools/debugger/GuiCallback;
/*      */     //   389: invokeinterface dispatchNextGuiEvent : ()V
/*      */     //   394: goto -> 377
/*      */     //   397: astore #11
/*      */     //   399: goto -> 377
/*      */     //   402: aload_0
/*      */     //   403: getfield returnValue : I
/*      */     //   406: istore #10
/*      */     //   408: iload #10
/*      */     //   410: tableswitch default -> 503, 0 -> 436, 1 -> 457, 2 -> 474
/*      */     //   436: aload #4
/*      */     //   438: iconst_1
/*      */     //   439: invokestatic access$1402 : (Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;Z)Z
/*      */     //   442: pop
/*      */     //   443: aload #4
/*      */     //   445: aload #4
/*      */     //   447: invokevirtual frameCount : ()I
/*      */     //   450: invokestatic access$1502 : (Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;I)I
/*      */     //   453: pop
/*      */     //   454: goto -> 503
/*      */     //   457: aload #4
/*      */     //   459: iconst_1
/*      */     //   460: invokestatic access$1402 : (Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;Z)Z
/*      */     //   463: pop
/*      */     //   464: aload #4
/*      */     //   466: iconst_m1
/*      */     //   467: invokestatic access$1502 : (Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;I)I
/*      */     //   470: pop
/*      */     //   471: goto -> 503
/*      */     //   474: aload #4
/*      */     //   476: invokevirtual frameCount : ()I
/*      */     //   479: iconst_1
/*      */     //   480: if_icmple -> 503
/*      */     //   483: aload #4
/*      */     //   485: iconst_1
/*      */     //   486: invokestatic access$1402 : (Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;Z)Z
/*      */     //   489: pop
/*      */     //   490: aload #4
/*      */     //   492: aload #4
/*      */     //   494: invokevirtual frameCount : ()I
/*      */     //   497: iconst_1
/*      */     //   498: isub
/*      */     //   499: invokestatic access$1502 : (Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;I)I
/*      */     //   502: pop
/*      */     //   503: aload_0
/*      */     //   504: getfield eventThreadMonitor : Ljava/lang/Object;
/*      */     //   507: dup
/*      */     //   508: astore #7
/*      */     //   510: monitorenter
/*      */     //   511: aload_0
/*      */     //   512: aconst_null
/*      */     //   513: putfield interruptedContextData : Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;
/*      */     //   516: aload_0
/*      */     //   517: getfield eventThreadMonitor : Ljava/lang/Object;
/*      */     //   520: invokevirtual notifyAll : ()V
/*      */     //   523: aload #7
/*      */     //   525: monitorexit
/*      */     //   526: goto -> 537
/*      */     //   529: astore #16
/*      */     //   531: aload #7
/*      */     //   533: monitorexit
/*      */     //   534: aload #16
/*      */     //   536: athrow
/*      */     //   537: goto -> 579
/*      */     //   540: astore #17
/*      */     //   542: aload_0
/*      */     //   543: getfield eventThreadMonitor : Ljava/lang/Object;
/*      */     //   546: dup
/*      */     //   547: astore #18
/*      */     //   549: monitorenter
/*      */     //   550: aload_0
/*      */     //   551: aconst_null
/*      */     //   552: putfield interruptedContextData : Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;
/*      */     //   555: aload_0
/*      */     //   556: getfield eventThreadMonitor : Ljava/lang/Object;
/*      */     //   559: invokevirtual notifyAll : ()V
/*      */     //   562: aload #18
/*      */     //   564: monitorexit
/*      */     //   565: goto -> 576
/*      */     //   568: astore #19
/*      */     //   570: aload #18
/*      */     //   572: monitorexit
/*      */     //   573: aload #19
/*      */     //   575: athrow
/*      */     //   576: aload #17
/*      */     //   578: athrow
/*      */     //   579: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #729	-> 0
/*      */     //   #730	-> 6
/*      */     //   #731	-> 17
/*      */     //   #733	-> 25
/*      */     //   #736	-> 28
/*      */     //   #737	-> 36
/*      */     //   #738	-> 41
/*      */     //   #739	-> 48
/*      */     //   #740	-> 51
/*      */     //   #743	-> 57
/*      */     //   #745	-> 64
/*      */     //   #748	-> 71
/*      */     //   #746	-> 74
/*      */     //   #747	-> 76
/*      */     //   #751	-> 80
/*      */     //   #752	-> 86
/*      */     //   #754	-> 100
/*      */     //   #769	-> 105
/*      */     //   #772	-> 106
/*      */     //   #776	-> 117
/*      */     //   #777	-> 124
/*      */     //   #779	-> 132
/*      */     //   #781	-> 140
/*      */     //   #782	-> 144
/*      */     //   #784	-> 150
/*      */     //   #787	-> 156
/*      */     //   #788	-> 159
/*      */     //   #789	-> 164
/*      */     //   #790	-> 172
/*      */     //   #791	-> 183
/*      */     //   #792	-> 188
/*      */     //   #793	-> 193
/*      */     //   #794	-> 198
/*      */     //   #799	-> 212
/*      */     //   #803	-> 219
/*      */     //   #800	-> 222
/*      */     //   #801	-> 224
/*      */     //   #802	-> 230
/*      */     //   #804	-> 233
/*      */     //   #805	-> 240
/*      */     //   #807	-> 245
/*      */     //   #810	-> 261
/*      */     //   #811	-> 266
/*      */     //   #812	-> 271
/*      */     //   #813	-> 278
/*      */     //   #810	-> 281
/*      */     //   #811	-> 288
/*      */     //   #812	-> 293
/*      */     //   #813	-> 300
/*      */     //   #814	-> 303
/*      */     //   #816	-> 306
/*      */     //   #817	-> 314
/*      */     //   #818	-> 320
/*      */     //   #822	-> 323
/*      */     //   #823	-> 328
/*      */     //   #822	-> 331
/*      */     //   #823	-> 338
/*      */     //   #824	-> 341
/*      */     //   #826	-> 358
/*      */     //   #827	-> 363
/*      */     //   #828	-> 377
/*      */     //   #830	-> 385
/*      */     //   #832	-> 394
/*      */     //   #831	-> 397
/*      */     //   #832	-> 399
/*      */     //   #834	-> 402
/*      */     //   #836	-> 408
/*      */     //   #838	-> 436
/*      */     //   #839	-> 443
/*      */     //   #840	-> 454
/*      */     //   #842	-> 457
/*      */     //   #843	-> 464
/*      */     //   #844	-> 471
/*      */     //   #846	-> 474
/*      */     //   #847	-> 483
/*      */     //   #848	-> 490
/*      */     //   #849	-> 494
/*      */     //   #848	-> 499
/*      */     //   #855	-> 503
/*      */     //   #856	-> 511
/*      */     //   #857	-> 516
/*      */     //   #858	-> 523
/*      */     //   #859	-> 537
/*      */     //   #855	-> 540
/*      */     //   #856	-> 550
/*      */     //   #857	-> 555
/*      */     //   #858	-> 562
/*      */     //   #859	-> 576
/*      */     //   #861	-> 579
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   76	4	8	exc	Ljava/lang/InterruptedException;
/*      */     //   147	3	9	alertMessage	Ljava/lang/String;
/*      */     //   224	9	12	exc	Ljava/lang/InterruptedException;
/*      */     //   124	379	7	frameCount	I
/*      */     //   140	363	8	threadTitle	Ljava/lang/String;
/*      */     //   156	347	9	alertMessage	Ljava/lang/String;
/*      */     //   159	344	10	returnValue	I
/*      */     //   0	580	0	this	Lorg/mozilla/javascript/tools/debugger/Dim;
/*      */     //   0	580	1	cx	Lorg/mozilla/javascript/Context;
/*      */     //   0	580	2	frame	Lorg/mozilla/javascript/tools/debugger/Dim$StackFrame;
/*      */     //   0	580	3	scriptException	Ljava/lang/Throwable;
/*      */     //   6	574	4	contextData	Lorg/mozilla/javascript/tools/debugger/Dim$ContextData;
/*      */     //   17	563	5	eventThreadFlag	Z
/*      */     //   28	552	6	recursiveEventThreadCall	Z
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   36	54	92	finally
/*      */     //   57	79	92	finally
/*      */     //   64	71	74	java/lang/InterruptedException
/*      */     //   80	89	92	finally
/*      */     //   92	97	92	finally
/*      */     //   117	503	540	finally
/*      */     //   172	344	347	finally
/*      */     //   212	219	222	java/lang/InterruptedException
/*      */     //   212	323	331	finally
/*      */     //   245	261	281	finally
/*      */     //   281	283	281	finally
/*      */     //   331	333	331	finally
/*      */     //   347	352	347	finally
/*      */     //   385	394	397	java/lang/InterruptedException
/*      */     //   511	526	529	finally
/*      */     //   529	534	529	finally
/*      */     //   540	542	540	finally
/*      */     //   550	565	568	finally
/*      */     //   568	573	568	finally
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String do_eval(Context cx, StackFrame frame, String expr) {
/*      */     String resultString;
/*  868 */     Debugger saved_debugger = cx.getDebugger();
/*  869 */     Object saved_data = cx.getDebuggerContextData();
/*  870 */     int saved_level = cx.getOptimizationLevel();
/*      */     
/*  872 */     cx.setDebugger(null, null);
/*  873 */     cx.setOptimizationLevel(-1);
/*  874 */     cx.setGeneratingDebug(false);
/*      */     try {
/*  876 */       Callable script = (Callable)cx.compileString(expr, "", 0, null);
/*  877 */       Object result = script.call(cx, frame.scope, frame.thisObj, ScriptRuntime.emptyArgs);
/*      */       
/*  879 */       if (result == Undefined.instance) {
/*  880 */         resultString = "";
/*      */       } else {
/*  882 */         resultString = ScriptRuntime.toString(result);
/*      */       } 
/*  884 */     } catch (Exception exc) {
/*  885 */       resultString = exc.getMessage();
/*      */     } finally {
/*  887 */       cx.setGeneratingDebug(true);
/*  888 */       cx.setOptimizationLevel(saved_level);
/*  889 */       cx.setDebugger(saved_debugger, saved_data);
/*      */     } 
/*  891 */     if (resultString == null) {
/*  892 */       resultString = "null";
/*      */     }
/*  894 */     return resultString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class DimIProxy
/*      */     implements ContextAction, ContextFactory.Listener, Debugger
/*      */   {
/*      */     private Dim dim;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String url;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String text;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object object;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object id;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean booleanResult;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String stringResult;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object objectResult;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object[] objectArrayResult;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DimIProxy(Dim dim, int type) {
/*  959 */       this.dim = dim;
/*  960 */       this.type = type;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object run(Context cx) {
/*      */       Scriptable scope;
/*      */       ImporterTopLevel importerTopLevel;
/*  969 */       switch (this.type) {
/*      */         case 2:
/*  971 */           cx.compileString(this.text, this.url, 1, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1014 */           return null;case 3: scope = null; if (this.dim.scopeProvider != null) scope = this.dim.scopeProvider.getScope();  if (scope == null) importerTopLevel = new ImporterTopLevel(cx);  cx.evaluateString((Scriptable)importerTopLevel, this.text, this.url, 1, null); return null;case 4: this.booleanResult = cx.stringIsCompilableUnit(this.text); return null;case 5: if (this.object == Undefined.instance) { this.stringResult = "undefined"; } else if (this.object == null) { this.stringResult = "null"; } else if (this.object instanceof org.mozilla.javascript.NativeCall) { this.stringResult = "[object Call]"; } else { this.stringResult = Context.toString(this.object); }  return null;case 6: this.objectResult = this.dim.getObjectPropertyImpl(cx, this.object, this.id); return null;case 7: this.objectArrayResult = this.dim.getObjectIdsImpl(cx, this.object); return null;
/*      */       } 
/*      */       throw Kit.codeBug();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void withContext() {
/* 1023 */       this.dim.contextFactory.call(this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void contextCreated(Context cx) {
/* 1032 */       if (this.type != 1) Kit.codeBug(); 
/* 1033 */       Dim.ContextData contextData = new Dim.ContextData();
/* 1034 */       Debugger debugger = new DimIProxy(this.dim, 0);
/* 1035 */       cx.setDebugger(debugger, contextData);
/* 1036 */       cx.setGeneratingDebug(true);
/* 1037 */       cx.setOptimizationLevel(-1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void contextReleased(Context cx) {
/* 1044 */       if (this.type != 1) Kit.codeBug();
/*      */     
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DebugFrame getFrame(Context cx, DebuggableScript fnOrScript) {
/* 1053 */       if (this.type != 0) Kit.codeBug();
/*      */       
/* 1055 */       Dim.FunctionSource item = this.dim.getFunctionSource(fnOrScript);
/* 1056 */       if (item == null)
/*      */       {
/* 1058 */         return null;
/*      */       }
/* 1060 */       return new Dim.StackFrame(cx, this.dim, item);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleCompilationDone(Context cx, DebuggableScript fnOrScript, String source) {
/* 1069 */       if (this.type != 0) Kit.codeBug();
/*      */       
/* 1071 */       if (!fnOrScript.isTopLevel()) {
/*      */         return;
/*      */       }
/* 1074 */       this.dim.registerTopScript(fnOrScript, source);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ContextData
/*      */   {
/* 1086 */     private ObjArray frameStack = new ObjArray();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean breakNextLine;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1097 */     private int stopAtFrameDepth = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean eventThreadFlag;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Throwable lastProcessedException;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ContextData get(Context cx) {
/* 1113 */       return (ContextData)cx.getDebuggerContextData();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int frameCount() {
/* 1120 */       return this.frameStack.size();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Dim.StackFrame getFrame(int frameNumber) {
/* 1127 */       int num = this.frameStack.size() - frameNumber - 1;
/* 1128 */       return (Dim.StackFrame)this.frameStack.get(num);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void pushFrame(Dim.StackFrame frame) {
/* 1135 */       this.frameStack.push(frame);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void popFrame() {
/* 1142 */       this.frameStack.pop();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class StackFrame
/*      */     implements DebugFrame
/*      */   {
/*      */     private Dim dim;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Dim.ContextData contextData;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Scriptable scope;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Scriptable thisObj;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Dim.FunctionSource fsource;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean[] breakpoints;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int lineNumber;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private StackFrame(Context cx, Dim dim, Dim.FunctionSource fsource) {
/* 1190 */       this.dim = dim;
/* 1191 */       this.contextData = Dim.ContextData.get(cx);
/* 1192 */       this.fsource = fsource;
/* 1193 */       this.breakpoints = (fsource.sourceInfo()).breakpoints;
/* 1194 */       this.lineNumber = fsource.firstLine();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onEnter(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 1202 */       this.contextData.pushFrame(this);
/* 1203 */       this.scope = scope;
/* 1204 */       this.thisObj = thisObj;
/* 1205 */       if (this.dim.breakOnEnter) {
/* 1206 */         this.dim.handleBreakpointHit(this, cx);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onLineChange(Context cx, int lineno) {
/* 1214 */       this.lineNumber = lineno;
/*      */       
/* 1216 */       if (!this.breakpoints[lineno] && !this.dim.breakFlag) {
/* 1217 */         boolean lineBreak = this.contextData.breakNextLine;
/* 1218 */         if (lineBreak && this.contextData.stopAtFrameDepth >= 0)
/*      */         {
/* 1220 */           lineBreak = (this.contextData.frameCount() <= this.contextData.stopAtFrameDepth);
/*      */         }
/* 1222 */         if (!lineBreak) {
/*      */           return;
/*      */         }
/* 1225 */         this.contextData.stopAtFrameDepth = -1;
/* 1226 */         this.contextData.breakNextLine = false;
/*      */       } 
/*      */       
/* 1229 */       this.dim.handleBreakpointHit(this, cx);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onExceptionThrown(Context cx, Throwable exception) {
/* 1236 */       this.dim.handleExceptionThrown(cx, exception, this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onExit(Context cx, boolean byThrow, Object resultOrException) {
/* 1244 */       if (this.dim.breakOnReturn && !byThrow) {
/* 1245 */         this.dim.handleBreakpointHit(this, cx);
/*      */       }
/* 1247 */       this.contextData.popFrame();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onDebuggerStatement(Context cx) {
/* 1254 */       this.dim.handleBreakpointHit(this, cx);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Dim.SourceInfo sourceInfo() {
/* 1261 */       return this.fsource.sourceInfo();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Dim.ContextData contextData() {
/* 1268 */       return this.contextData;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object scope() {
/* 1275 */       return this.scope;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object thisObj() {
/* 1282 */       return this.thisObj;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getUrl() {
/* 1289 */       return this.fsource.sourceInfo().url();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getLineNumber() {
/* 1296 */       return this.lineNumber;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getFunctionName() {
/* 1303 */       return this.fsource.name();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class FunctionSource
/*      */   {
/*      */     private Dim.SourceInfo sourceInfo;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int firstLine;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private FunctionSource(Dim.SourceInfo sourceInfo, int firstLine, String name) {
/* 1332 */       if (name == null) throw new IllegalArgumentException(); 
/* 1333 */       this.sourceInfo = sourceInfo;
/* 1334 */       this.firstLine = firstLine;
/* 1335 */       this.name = name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Dim.SourceInfo sourceInfo() {
/* 1343 */       return this.sourceInfo;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int firstLine() {
/* 1350 */       return this.firstLine;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String name() {
/* 1357 */       return this.name;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SourceInfo
/*      */   {
/* 1369 */     private static final boolean[] EMPTY_BOOLEAN_ARRAY = new boolean[0];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String source;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String url;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean[] breakableLines;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean[] breakpoints;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Dim.FunctionSource[] functionSources;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private SourceInfo(String source, DebuggableScript[] functions, String normilizedUrl) {
/* 1401 */       this.source = source;
/* 1402 */       this.url = normilizedUrl;
/*      */       
/* 1404 */       int N = functions.length;
/* 1405 */       int[][] lineArrays = new int[N][];
/* 1406 */       for (int i = 0; i != N; i++) {
/* 1407 */         lineArrays[i] = functions[i].getLineNumbers();
/*      */       }
/*      */       
/* 1410 */       int minAll = 0, maxAll = -1;
/* 1411 */       int[] firstLines = new int[N]; int j;
/* 1412 */       for (j = 0; j != N; j++) {
/* 1413 */         int[] lines = lineArrays[j];
/* 1414 */         if (lines == null || lines.length == 0) {
/* 1415 */           firstLines[j] = -1;
/*      */         } else {
/*      */           
/* 1418 */           int max = lines[0], min = max;
/* 1419 */           for (int k = 1; k != lines.length; k++) {
/* 1420 */             int line = lines[k];
/* 1421 */             if (line < min) {
/* 1422 */               min = line;
/* 1423 */             } else if (line > max) {
/* 1424 */               max = line;
/*      */             } 
/*      */           } 
/* 1427 */           firstLines[j] = min;
/* 1428 */           if (minAll > maxAll) {
/* 1429 */             minAll = min;
/* 1430 */             maxAll = max;
/*      */           } else {
/* 1432 */             if (min < minAll) {
/* 1433 */               minAll = min;
/*      */             }
/* 1435 */             if (max > maxAll) {
/* 1436 */               maxAll = max;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1442 */       if (minAll > maxAll) {
/*      */         
/* 1444 */         this.breakableLines = EMPTY_BOOLEAN_ARRAY;
/* 1445 */         this.breakpoints = EMPTY_BOOLEAN_ARRAY;
/*      */       } else {
/* 1447 */         if (minAll < 0)
/*      */         {
/* 1449 */           throw new IllegalStateException(String.valueOf(minAll));
/*      */         }
/* 1451 */         int linesTop = maxAll + 1;
/* 1452 */         this.breakableLines = new boolean[linesTop];
/* 1453 */         this.breakpoints = new boolean[linesTop];
/* 1454 */         for (int k = 0; k != N; k++) {
/* 1455 */           int[] lines = lineArrays[k];
/* 1456 */           if (lines != null && lines.length != 0) {
/* 1457 */             for (int m = 0; m != lines.length; m++) {
/* 1458 */               int line = lines[m];
/* 1459 */               this.breakableLines[line] = true;
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/* 1464 */       this.functionSources = new Dim.FunctionSource[N];
/* 1465 */       for (j = 0; j != N; j++) {
/* 1466 */         String name = functions[j].getFunctionName();
/* 1467 */         if (name == null) {
/* 1468 */           name = "";
/*      */         }
/* 1470 */         this.functionSources[j] = new Dim.FunctionSource(this, firstLines[j], name);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String source() {
/* 1479 */       return this.source;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String url() {
/* 1486 */       return this.url;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int functionSourcesTop() {
/* 1493 */       return this.functionSources.length;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Dim.FunctionSource functionSource(int i) {
/* 1500 */       return this.functionSources[i];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void copyBreakpointsFrom(SourceInfo old) {
/* 1508 */       int end = old.breakpoints.length;
/* 1509 */       if (end > this.breakpoints.length) {
/* 1510 */         end = this.breakpoints.length;
/*      */       }
/* 1512 */       for (int line = 0; line != end; line++) {
/* 1513 */         if (old.breakpoints[line]) {
/* 1514 */           this.breakpoints[line] = true;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean breakableLine(int line) {
/* 1524 */       return (line < this.breakableLines.length && this.breakableLines[line]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean breakpoint(int line) {
/* 1532 */       if (!breakableLine(line)) {
/* 1533 */         throw new IllegalArgumentException(String.valueOf(line));
/*      */       }
/* 1535 */       return (line < this.breakpoints.length && this.breakpoints[line]);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean breakpoint(int line, boolean value) {
/*      */       boolean changed;
/* 1542 */       if (!breakableLine(line)) {
/* 1543 */         throw new IllegalArgumentException(String.valueOf(line));
/*      */       }
/*      */       
/* 1546 */       synchronized (this.breakpoints) {
/* 1547 */         if (this.breakpoints[line] != value) {
/* 1548 */           this.breakpoints[line] = value;
/* 1549 */           changed = true;
/*      */         } else {
/* 1551 */           changed = false;
/*      */         } 
/*      */       } 
/* 1554 */       return changed;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeAllBreakpoints() {
/* 1561 */       synchronized (this.breakpoints) {
/* 1562 */         for (int line = 0; line != this.breakpoints.length; line++)
/* 1563 */           this.breakpoints[line] = false; 
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\debugger\Dim.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */