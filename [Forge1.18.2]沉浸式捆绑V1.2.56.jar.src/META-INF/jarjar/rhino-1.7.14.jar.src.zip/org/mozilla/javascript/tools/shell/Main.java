/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ContextAction;
/*     */ import org.mozilla.javascript.ErrorReporter;
/*     */ import org.mozilla.javascript.GeneratedClassLoader;
/*     */ import org.mozilla.javascript.JavaScriptException;
/*     */ import org.mozilla.javascript.Kit;
/*     */ import org.mozilla.javascript.NativeArray;
/*     */ import org.mozilla.javascript.RhinoException;
/*     */ import org.mozilla.javascript.Script;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.SecurityController;
/*     */ import org.mozilla.javascript.commonjs.module.ModuleScope;
/*     */ import org.mozilla.javascript.commonjs.module.Require;
/*     */ import org.mozilla.javascript.tools.SourceReader;
/*     */ import org.mozilla.javascript.tools.ToolErrorReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */ {
/*  53 */   public static ShellContextFactory shellContextFactory = new ShellContextFactory();
/*     */   
/*  55 */   public static Global global = new Global();
/*     */   protected static ToolErrorReporter errorReporter;
/*  57 */   protected static int exitCode = 0;
/*     */   private static final int EXITCODE_RUNTIME_ERROR = 3;
/*     */   private static final int EXITCODE_FILE_NOT_FOUND = 4;
/*     */   static boolean processStdin = true;
/*  61 */   static List<String> fileList = new ArrayList<>();
/*     */   static List<String> modulePath;
/*     */   static String mainModule;
/*     */   static boolean sandboxed = false;
/*     */   static boolean useRequire = false;
/*     */   static Require require;
/*     */   private static SecurityProxy securityImpl;
/*  68 */   private static final ScriptCache scriptCache = new ScriptCache(32);
/*     */   
/*     */   static {
/*  71 */     global.initQuitAction(new IProxy(3));
/*     */   }
/*     */   
/*     */   private static class IProxy
/*     */     implements ContextAction<Object>, QuitAction
/*     */   {
/*     */     private static final int PROCESS_FILES = 1;
/*     */     private static final int EVAL_INLINE_SCRIPT = 2;
/*     */     private static final int SYSTEM_EXIT = 3;
/*     */     private int type;
/*     */     String[] args;
/*     */     String scriptText;
/*  83 */     private final Timers timers = new Timers();
/*     */     
/*     */     IProxy(int type) {
/*  86 */       this.type = type;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object run(Context cx) {
/*  91 */       cx.setTrackUnhandledPromiseRejections(true);
/*  92 */       this.timers.install((Scriptable)Main.global);
/*  93 */       if (Main.useRequire) {
/*  94 */         Main.require = Main.global.installRequire(cx, Main.modulePath, Main.sandboxed);
/*     */       }
/*  96 */       if (this.type == 1) {
/*  97 */         Main.processFiles(cx, this.args);
/*  98 */         Main.printPromiseWarnings(cx);
/*  99 */       } else if (this.type == 2) {
/* 100 */         Main.evalInlineScript(cx, this.scriptText);
/*     */       } else {
/* 102 */         throw Kit.codeBug();
/*     */       } 
/*     */       try {
/* 105 */         this.timers.runAllTimers(cx, (Scriptable)Main.global);
/* 106 */       } catch (JavaScriptException e) {
/* 107 */         ToolErrorReporter.reportException(cx.getErrorReporter(), (RhinoException)e);
/* 108 */         Main.exitCode = 3;
/* 109 */       } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */       
/* 112 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void quit(Context cx, int exitCode) {
/* 117 */       if (this.type == 3) {
/* 118 */         System.exit(exitCode);
/*     */         return;
/*     */       } 
/* 121 */       throw Kit.codeBug();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 134 */       if (Boolean.getBoolean("rhino.use_java_policy_security")) {
/* 135 */         initJavaPolicySecuritySupport();
/*     */       }
/* 137 */     } catch (SecurityException ex) {
/* 138 */       ex.printStackTrace(System.err);
/*     */     } 
/*     */     
/* 141 */     int result = exec(args);
/* 142 */     if (result != 0) {
/* 143 */       System.exit(result);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static int exec(String[] origArgs) {
/* 149 */     errorReporter = new ToolErrorReporter(false, global.getErr());
/* 150 */     shellContextFactory.setErrorReporter((ErrorReporter)errorReporter);
/* 151 */     String[] args = processOptions(origArgs);
/* 152 */     if (exitCode > 0) {
/* 153 */       return exitCode;
/*     */     }
/* 155 */     if (processStdin) {
/* 156 */       fileList.add(null);
/*     */     }
/* 158 */     if (!global.initialized) {
/* 159 */       global.init(shellContextFactory);
/*     */     }
/* 161 */     IProxy iproxy = new IProxy(1);
/* 162 */     iproxy.args = args;
/* 163 */     shellContextFactory.call(iproxy);
/*     */     
/* 165 */     return exitCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void processFiles(Context cx, String[] args) {
/* 172 */     Object[] array = new Object[args.length];
/* 173 */     System.arraycopy(args, 0, array, 0, args.length);
/* 174 */     Scriptable argsObj = cx.newArray((Scriptable)global, array);
/* 175 */     global.defineProperty("arguments", argsObj, 2);
/*     */     
/* 177 */     for (String file : fileList) {
/*     */       try {
/* 179 */         processSource(cx, file);
/* 180 */       } catch (IOException ioex) {
/* 181 */         Context.reportError(
/* 182 */             ToolErrorReporter.getMessage("msg.couldnt.read.source", file, ioex
/* 183 */               .getMessage()));
/* 184 */         exitCode = 4;
/* 185 */       } catch (RhinoException rex) {
/* 186 */         ToolErrorReporter.reportException(cx.getErrorReporter(), rex);
/* 187 */         exitCode = 3;
/* 188 */       } catch (VirtualMachineError ex) {
/*     */         
/* 190 */         ex.printStackTrace();
/* 191 */         String msg = ToolErrorReporter.getMessage("msg.uncaughtJSException", ex.toString());
/* 192 */         Context.reportError(msg);
/* 193 */         exitCode = 3;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static void evalInlineScript(Context cx, String scriptText) {
/*     */     try {
/* 200 */       Script script = cx.compileString(scriptText, "<command>", 1, null);
/* 201 */       if (script != null) {
/* 202 */         script.exec(cx, getShellScope());
/*     */       }
/* 204 */     } catch (RhinoException rex) {
/* 205 */       ToolErrorReporter.reportException(cx.getErrorReporter(), rex);
/* 206 */       exitCode = 3;
/* 207 */     } catch (VirtualMachineError ex) {
/*     */       
/* 209 */       ex.printStackTrace();
/* 210 */       String msg = ToolErrorReporter.getMessage("msg.uncaughtJSException", ex.toString());
/* 211 */       Context.reportError(msg);
/* 212 */       exitCode = 3;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Global getGlobal() {
/* 217 */     return global;
/*     */   }
/*     */   
/*     */   static Scriptable getShellScope() {
/* 221 */     return getScope(null);
/*     */   }
/*     */   
/*     */   static Scriptable getScope(String path) {
/* 225 */     if (useRequire) {
/*     */       URI uri;
/*     */ 
/*     */       
/* 229 */       if (path == null) {
/*     */         
/* 231 */         uri = (new File(System.getProperty("user.dir"))).toURI();
/*     */       
/*     */       }
/* 234 */       else if (SourceReader.toUrl(path) != null) {
/*     */         try {
/* 236 */           uri = new URI(path);
/* 237 */         } catch (URISyntaxException x) {
/*     */           
/* 239 */           uri = (new File(path)).toURI();
/*     */         } 
/*     */       } else {
/* 242 */         uri = (new File(path)).toURI();
/*     */       } 
/*     */       
/* 245 */       return (Scriptable)new ModuleScope((Scriptable)global, uri, null);
/*     */     } 
/* 247 */     return (Scriptable)global;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] processOptions(String[] args) {
/*     */     String usageError;
/* 254 */     for (int i = 0;; i++) {
/* 255 */       if (i == args.length) {
/* 256 */         return new String[0];
/*     */       }
/* 258 */       String arg = args[i];
/* 259 */       if (!arg.startsWith("-")) {
/* 260 */         processStdin = false;
/* 261 */         fileList.add(arg);
/* 262 */         mainModule = arg;
/* 263 */         String[] result = new String[args.length - i - 1];
/* 264 */         System.arraycopy(args, i + 1, result, 0, args.length - i - 1);
/* 265 */         return result;
/*     */       } 
/* 267 */       if (arg.equals("-version")) {
/* 268 */         int version; if (++i == args.length) {
/* 269 */           usageError = arg;
/*     */           
/*     */           break;
/*     */         } 
/*     */         try {
/* 274 */           version = Integer.parseInt(args[i]);
/* 275 */         } catch (NumberFormatException ex) {
/* 276 */           usageError = args[i];
/*     */           break;
/*     */         } 
/* 279 */         if (!Context.isValidLanguageVersion(version)) {
/* 280 */           usageError = args[i];
/*     */           break;
/*     */         } 
/* 283 */         shellContextFactory.setLanguageVersion(version);
/*     */       
/*     */       }
/* 286 */       else if (arg.equals("-opt") || arg.equals("-O")) {
/* 287 */         int opt; if (++i == args.length) {
/* 288 */           usageError = arg;
/*     */           
/*     */           break;
/*     */         } 
/*     */         try {
/* 293 */           opt = Integer.parseInt(args[i]);
/* 294 */         } catch (NumberFormatException ex) {
/* 295 */           usageError = args[i];
/*     */           break;
/*     */         } 
/* 298 */         if (opt == -2) {
/*     */           
/* 300 */           opt = -1;
/* 301 */         } else if (!Context.isValidOptimizationLevel(opt)) {
/* 302 */           usageError = args[i];
/*     */           break;
/*     */         } 
/* 305 */         shellContextFactory.setOptimizationLevel(opt);
/*     */       
/*     */       }
/* 308 */       else if (arg.equals("-encoding")) {
/* 309 */         if (++i == args.length) {
/* 310 */           usageError = arg;
/*     */           break;
/*     */         } 
/* 313 */         String enc = args[i];
/* 314 */         shellContextFactory.setCharacterEncoding(enc);
/*     */       
/*     */       }
/* 317 */       else if (arg.equals("-strict")) {
/* 318 */         shellContextFactory.setStrictMode(true);
/* 319 */         shellContextFactory.setAllowReservedKeywords(false);
/* 320 */         errorReporter.setIsReportingWarnings(true);
/*     */       
/*     */       }
/* 323 */       else if (arg.equals("-fatal-warnings")) {
/* 324 */         shellContextFactory.setWarningAsError(true);
/*     */       
/*     */       }
/* 327 */       else if (arg.equals("-e")) {
/* 328 */         processStdin = false;
/* 329 */         if (++i == args.length) {
/* 330 */           usageError = arg;
/*     */           break;
/*     */         } 
/* 333 */         if (!global.initialized) {
/* 334 */           global.init(shellContextFactory);
/*     */         }
/* 336 */         IProxy iproxy = new IProxy(2);
/* 337 */         iproxy.scriptText = args[i];
/* 338 */         shellContextFactory.call(iproxy);
/*     */       
/*     */       }
/* 341 */       else if (arg.equals("-require")) {
/* 342 */         useRequire = true;
/*     */       
/*     */       }
/* 345 */       else if (arg.equals("-sandbox")) {
/* 346 */         sandboxed = true;
/* 347 */         useRequire = true;
/*     */       
/*     */       }
/* 350 */       else if (arg.equals("-modules")) {
/* 351 */         if (++i == args.length) {
/* 352 */           usageError = arg;
/*     */           break;
/*     */         } 
/* 355 */         if (modulePath == null) {
/* 356 */           modulePath = new ArrayList<>();
/*     */         }
/* 358 */         modulePath.add(args[i]);
/* 359 */         useRequire = true;
/*     */       
/*     */       }
/* 362 */       else if (arg.equals("-w")) {
/* 363 */         errorReporter.setIsReportingWarnings(true);
/*     */       
/*     */       }
/* 366 */       else if (arg.equals("-f")) {
/* 367 */         processStdin = false;
/* 368 */         if (++i == args.length) {
/* 369 */           usageError = arg;
/*     */           break;
/*     */         } 
/* 372 */         if (args[i].equals("-")) {
/* 373 */           fileList.add(null);
/*     */         } else {
/* 375 */           fileList.add(args[i]);
/* 376 */           mainModule = args[i];
/*     */         }
/*     */       
/*     */       }
/* 380 */       else if (arg.equals("-sealedlib")) {
/* 381 */         global.setSealedStdLib(true);
/*     */       
/*     */       }
/* 384 */       else if (arg.equals("-debug")) {
/* 385 */         shellContextFactory.setGeneratingDebug(true);
/*     */       } else {
/*     */         
/* 388 */         if (arg.equals("-?") || arg.equals("-help")) {
/*     */           
/* 390 */           global.getOut()
/* 391 */             .println(
/* 392 */               ToolErrorReporter.getMessage("msg.shell.usage", Main.class
/* 393 */                 .getName()));
/* 394 */           exitCode = 1;
/* 395 */           return null;
/*     */         } 
/* 397 */         usageError = arg;
/*     */         break;
/*     */       } 
/*     */     } 
/* 401 */     global.getOut().println(ToolErrorReporter.getMessage("msg.shell.invalid", usageError));
/* 402 */     global.getOut()
/* 403 */       .println(ToolErrorReporter.getMessage("msg.shell.usage", Main.class.getName()));
/* 404 */     exitCode = 1;
/* 405 */     return null;
/*     */   }
/*     */   
/*     */   private static void initJavaPolicySecuritySupport() {
/*     */     Throwable exObj;
/*     */     try {
/* 411 */       Class<?> cl = Class.forName("org.mozilla.javascript.tools.shell.JavaPolicySecurity");
/* 412 */       securityImpl = (SecurityProxy)cl.newInstance();
/* 413 */       SecurityController.initGlobal(securityImpl);
/*     */       return;
/* 415 */     } catch (ClassNotFoundException ex) {
/* 416 */       exObj = ex;
/* 417 */     } catch (IllegalAccessException ex) {
/* 418 */       exObj = ex;
/* 419 */     } catch (InstantiationException ex) {
/* 420 */       exObj = ex;
/* 421 */     } catch (LinkageError ex) {
/* 422 */       exObj = ex;
/*     */     } 
/* 424 */     throw new IllegalStateException("Can not load security support: " + exObj, exObj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void processSource(Context cx, String filename) throws IOException {
/* 436 */     if (filename == null || filename.equals("-")) {
/* 437 */       Charset cs; Scriptable scope = getShellScope();
/*     */       
/* 439 */       String charEnc = shellContextFactory.getCharacterEncoding();
/* 440 */       if (charEnc != null) {
/* 441 */         cs = Charset.forName(charEnc);
/*     */       } else {
/* 443 */         cs = Charset.defaultCharset();
/*     */       } 
/* 445 */       ShellConsole console = global.getConsole(cs);
/* 446 */       if (filename == null)
/*     */       {
/* 448 */         console.println(cx.getImplementationVersion());
/*     */       }
/*     */       
/* 451 */       int lineno = 1;
/* 452 */       boolean hitEOF = false;
/* 453 */       while (!hitEOF) {
/* 454 */         String[] prompts = global.getPrompts(cx);
/* 455 */         String prompt = null;
/* 456 */         if (filename == null) prompt = prompts[0]; 
/* 457 */         console.flush();
/* 458 */         StringBuilder source = new StringBuilder();
/*     */         
/*     */         while (true) {
/*     */           String newline;
/*     */           
/*     */           try {
/* 464 */             newline = console.readLine(prompt);
/* 465 */           } catch (IOException ioe) {
/* 466 */             console.println(ioe.toString());
/*     */             break;
/*     */           } 
/* 469 */           if (newline == null) {
/* 470 */             hitEOF = true;
/*     */             break;
/*     */           } 
/* 473 */           source.append(newline).append('\n');
/* 474 */           lineno++;
/* 475 */           if (cx.stringIsCompilableUnit(source.toString()))
/* 476 */             break;  prompt = prompts[1];
/*     */         } 
/*     */         try {
/* 479 */           String finalSource = source.toString();
/* 480 */           Script script = cx.compileString(finalSource, "<stdin>", lineno, null);
/* 481 */           if (script != null) {
/* 482 */             Object result = script.exec(cx, scope);
/*     */             
/* 484 */             if (result != Context.getUndefinedValue() && (!(result instanceof org.mozilla.javascript.Function) || 
/*     */               
/* 486 */               !finalSource.trim().startsWith("function"))) {
/*     */               try {
/* 488 */                 console.println(Context.toString(result));
/* 489 */               } catch (RhinoException rex) {
/* 490 */                 ToolErrorReporter.reportException(cx.getErrorReporter(), rex);
/*     */               } 
/*     */             }
/* 493 */             NativeArray h = global.history;
/* 494 */             h.put((int)h.getLength(), (Scriptable)h, source);
/*     */           } 
/* 496 */           printPromiseWarnings(cx);
/* 497 */         } catch (RhinoException rex) {
/* 498 */           String newline; ToolErrorReporter.reportException(cx.getErrorReporter(), (RhinoException)newline);
/* 499 */           exitCode = 3;
/* 500 */         } catch (VirtualMachineError ex) {
/*     */           
/* 502 */           ex.printStackTrace();
/*     */           
/* 504 */           String msg = ToolErrorReporter.getMessage("msg.uncaughtJSException", ex.toString());
/* 505 */           Context.reportError(msg);
/* 506 */           exitCode = 3;
/*     */         } 
/*     */       } 
/* 509 */       console.println();
/* 510 */       console.flush();
/* 511 */     } else if (useRequire && filename.equals(mainModule)) {
/* 512 */       require.requireMain(cx, filename);
/*     */     } else {
/* 514 */       processFile(cx, getScope(filename), filename);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void processFileNoThrow(Context cx, Scriptable scope, String filename) {
/*     */     try {
/* 520 */       processFile(cx, scope, filename);
/* 521 */     } catch (IOException ioex) {
/* 522 */       Context.reportError(
/* 523 */           ToolErrorReporter.getMessage("msg.couldnt.read.source", filename, ioex
/* 524 */             .getMessage()));
/* 525 */       exitCode = 4;
/* 526 */     } catch (RhinoException rex) {
/* 527 */       ToolErrorReporter.reportException(cx.getErrorReporter(), rex);
/* 528 */       exitCode = 3;
/* 529 */     } catch (VirtualMachineError ex) {
/*     */       
/* 531 */       ex.printStackTrace();
/* 532 */       String msg = ToolErrorReporter.getMessage("msg.uncaughtJSException", ex.toString());
/* 533 */       Context.reportError(msg);
/* 534 */       exitCode = 3;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void processFile(Context cx, Scriptable scope, String filename) throws IOException {
/* 540 */     if (securityImpl == null) {
/* 541 */       processFileSecure(cx, scope, filename, null);
/*     */     } else {
/* 543 */       securityImpl.callProcessFileSecure(cx, scope, filename);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void processFileSecure(Context cx, Scriptable scope, String path, Object securityDomain) throws IOException {
/* 550 */     boolean isClass = path.endsWith(".class");
/* 551 */     Object source = readFileOrUrl(path, !isClass);
/*     */     
/* 553 */     byte[] digest = getDigest(source);
/* 554 */     String key = path + "_" + cx.getOptimizationLevel();
/* 555 */     ScriptReference ref = scriptCache.get(key, digest);
/* 556 */     Script script = (ref != null) ? ref.get() : null;
/*     */     
/* 558 */     if (script == null) {
/* 559 */       if (isClass) {
/* 560 */         script = loadCompiledScript(cx, path, (byte[])source, securityDomain);
/*     */       } else {
/* 562 */         String strSrc = (String)source;
/*     */ 
/*     */ 
/*     */         
/* 566 */         if (strSrc.length() > 0 && strSrc.charAt(0) == '#') {
/* 567 */           for (int i = 1; i != strSrc.length(); i++) {
/* 568 */             int c = strSrc.charAt(i);
/* 569 */             if (c == 10 || c == 13) {
/* 570 */               strSrc = strSrc.substring(i);
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/* 575 */         script = cx.compileString(strSrc, path, 1, securityDomain);
/*     */       } 
/* 577 */       scriptCache.put(key, digest, script);
/*     */     } 
/*     */     
/* 580 */     if (script != null) {
/* 581 */       script.exec(cx, scope);
/*     */     }
/*     */   }
/*     */   
/*     */   private static byte[] getDigest(Object source) {
/* 586 */     byte[] digest = null;
/*     */     
/* 588 */     if (source != null) {
/* 589 */       byte[] bytes; if (source instanceof String) {
/* 590 */         bytes = ((String)source).getBytes(StandardCharsets.UTF_8);
/*     */       } else {
/* 592 */         bytes = (byte[])source;
/*     */       } 
/*     */       try {
/* 595 */         MessageDigest md = MessageDigest.getInstance("MD5");
/* 596 */         digest = md.digest(bytes);
/* 597 */       } catch (NoSuchAlgorithmException nsa) {
/*     */         
/* 599 */         throw new RuntimeException(nsa);
/*     */       } 
/*     */     } 
/*     */     
/* 603 */     return digest;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Script loadCompiledScript(Context cx, String path, byte[] data, Object securityDomain) throws FileNotFoundException {
/* 609 */     if (data == null) {
/* 610 */       throw new FileNotFoundException(path);
/*     */     }
/*     */ 
/*     */     
/* 614 */     int nameStart = path.lastIndexOf('/');
/* 615 */     if (nameStart < 0) {
/* 616 */       nameStart = 0;
/*     */     } else {
/* 618 */       nameStart++;
/*     */     } 
/* 620 */     int nameEnd = path.lastIndexOf('.');
/* 621 */     if (nameEnd < nameStart)
/*     */     {
/*     */       
/* 624 */       nameEnd = path.length();
/*     */     }
/* 626 */     String name = path.substring(nameStart, nameEnd);
/*     */     
/*     */     try {
/* 629 */       GeneratedClassLoader loader = SecurityController.createLoader(cx.getApplicationClassLoader(), securityDomain);
/* 630 */       Class<?> clazz = loader.defineClass(name, data);
/* 631 */       loader.linkClass(clazz);
/* 632 */       if (!Script.class.isAssignableFrom(clazz)) {
/* 633 */         throw Context.reportRuntimeError("msg.must.implement.Script");
/*     */       }
/* 635 */       return (Script)clazz.newInstance();
/* 636 */     } catch (IllegalAccessException iaex) {
/* 637 */       Context.reportError(iaex.toString());
/* 638 */       throw new RuntimeException(iaex);
/* 639 */     } catch (InstantiationException inex) {
/* 640 */       Context.reportError(inex.toString());
/* 641 */       throw new RuntimeException(inex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void printPromiseWarnings(Context cx) {
/* 646 */     List<Object> unhandled = cx.getUnhandledPromiseTracker().enumerate();
/* 647 */     if (!unhandled.isEmpty()) {
/* 648 */       Object result = unhandled.get(0);
/* 649 */       String msg = "Unhandled rejected promise: " + Context.toString(result);
/* 650 */       if (result instanceof Scriptable) {
/* 651 */         Object stack = ScriptableObject.getProperty((Scriptable)result, "stack");
/* 652 */         if (stack != null && stack != Scriptable.NOT_FOUND) {
/* 653 */           msg = msg + '\n' + Context.toString(stack);
/*     */         }
/*     */       } 
/* 656 */       System.out.println(msg);
/* 657 */       if (unhandled.size() > 1) {
/* 658 */         System.out.println("  and " + (unhandled
/* 659 */             .size() - 1) + " other unhandled rejected promises");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static InputStream getIn() {
/* 665 */     return getGlobal().getIn();
/*     */   }
/*     */   
/*     */   public static void setIn(InputStream in) {
/* 669 */     getGlobal().setIn(in);
/*     */   }
/*     */   
/*     */   public static PrintStream getOut() {
/* 673 */     return getGlobal().getOut();
/*     */   }
/*     */   
/*     */   public static void setOut(PrintStream out) {
/* 677 */     getGlobal().setOut(out);
/*     */   }
/*     */   
/*     */   public static PrintStream getErr() {
/* 681 */     return getGlobal().getErr();
/*     */   }
/*     */   
/*     */   public static void setErr(PrintStream err) {
/* 685 */     getGlobal().setErr(err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object readFileOrUrl(String path, boolean convertToString) throws IOException {
/* 695 */     return SourceReader.readFileOrUrl(path, convertToString, shellContextFactory
/* 696 */         .getCharacterEncoding());
/*     */   }
/*     */   
/*     */   static class ScriptReference extends SoftReference<Script> {
/*     */     String path;
/*     */     byte[] digest;
/*     */     
/*     */     ScriptReference(String path, byte[] digest, Script script, ReferenceQueue<Script> queue) {
/* 704 */       super(script, queue);
/* 705 */       this.path = path;
/* 706 */       this.digest = digest;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ScriptCache extends LinkedHashMap<String, ScriptReference> {
/*     */     private static final long serialVersionUID = -6866856136258508615L;
/*     */     ReferenceQueue<Script> queue;
/*     */     int capacity;
/*     */     
/*     */     ScriptCache(int capacity) {
/* 716 */       super(capacity + 1, 2.0F, true);
/* 717 */       this.capacity = capacity;
/* 718 */       this.queue = new ReferenceQueue<>();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean removeEldestEntry(Map.Entry<String, Main.ScriptReference> eldest) {
/* 723 */       return (size() > this.capacity);
/*     */     }
/*     */     
/*     */     Main.ScriptReference get(String path, byte[] digest) {
/*     */       Main.ScriptReference ref;
/* 728 */       while ((ref = (Main.ScriptReference)this.queue.poll()) != null) {
/* 729 */         remove(ref.path);
/*     */       }
/* 731 */       ref = get(path);
/* 732 */       if (ref != null && !Arrays.equals(digest, ref.digest)) {
/* 733 */         remove(ref.path);
/* 734 */         ref = null;
/*     */       } 
/* 736 */       return ref;
/*     */     }
/*     */     
/*     */     void put(String path, byte[] digest, Script script) {
/* 740 */       put(path, new Main.ScriptReference(path, digest, script, this.queue));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */