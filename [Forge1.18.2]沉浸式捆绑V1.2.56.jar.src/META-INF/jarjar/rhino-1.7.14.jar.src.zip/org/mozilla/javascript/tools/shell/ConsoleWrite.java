/*    */ package org.mozilla.javascript.tools.shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConsoleWrite
/*    */   implements Runnable
/*    */ {
/*    */   private ConsoleTextArea textArea;
/*    */   private String str;
/*    */   
/*    */   public ConsoleWrite(ConsoleTextArea textArea, String str) {
/* 30 */     this.textArea = textArea;
/* 31 */     this.str = str;
/*    */   }
/*    */   
/*    */   public void run() {
/* 35 */     this.textArea.write(this.str);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\ConsoleWrite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */