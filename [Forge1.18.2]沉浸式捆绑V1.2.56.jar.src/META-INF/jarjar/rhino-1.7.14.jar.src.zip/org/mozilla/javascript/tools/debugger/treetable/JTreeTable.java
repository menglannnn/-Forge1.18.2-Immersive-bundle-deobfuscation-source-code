/*     */ package org.mozilla.javascript.tools.debugger.treetable;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.EventObject;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.tree.DefaultTreeCellRenderer;
/*     */ import javax.swing.tree.DefaultTreeSelectionModel;
/*     */ import javax.swing.tree.TreeCellRenderer;
/*     */ import javax.swing.tree.TreeModel;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JTreeTable
/*     */   extends JTable
/*     */ {
/*     */   private static final long serialVersionUID = -2103973006456695515L;
/*     */   protected TreeTableCellRenderer tree;
/*     */   
/*     */   public JTreeTable(TreeTableModel treeTableModel) {
/*  79 */     this.tree = new TreeTableCellRenderer(treeTableModel);
/*     */ 
/*     */     
/*  82 */     setModel(new TreeTableModelAdapter(treeTableModel, this.tree));
/*     */ 
/*     */     
/*  85 */     ListToTreeSelectionModelWrapper selectionWrapper = new ListToTreeSelectionModelWrapper();
/*     */     
/*  87 */     this.tree.setSelectionModel(selectionWrapper);
/*  88 */     setSelectionModel(selectionWrapper.getListSelectionModel());
/*     */ 
/*     */     
/*  91 */     setDefaultRenderer(TreeTableModel.class, this.tree);
/*  92 */     setDefaultEditor(TreeTableModel.class, new TreeTableCellEditor());
/*     */ 
/*     */     
/*  95 */     setShowGrid(false);
/*     */ 
/*     */     
/*  98 */     setIntercellSpacing(new Dimension(0, 0));
/*     */ 
/*     */ 
/*     */     
/* 102 */     if (this.tree.getRowHeight() < 1)
/*     */     {
/* 104 */       setRowHeight(18);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateUI() {
/* 115 */     super.updateUI();
/* 116 */     if (this.tree != null) {
/* 117 */       this.tree.updateUI();
/*     */     }
/*     */ 
/*     */     
/* 121 */     LookAndFeel.installColorsAndFont(this, "Tree.background", "Tree.foreground", "Tree.font");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEditingRow() {
/* 133 */     return (getColumnClass(this.editingColumn) == TreeTableModel.class) ? -1 : this.editingRow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowHeight(int rowHeight) {
/* 142 */     super.setRowHeight(rowHeight);
/* 143 */     if (this.tree != null && this.tree.getRowHeight() != rowHeight) {
/* 144 */       this.tree.setRowHeight(getRowHeight());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JTree getTree() {
/* 152 */     return this.tree;
/*     */   }
/*     */ 
/*     */   
/*     */   public class TreeTableCellRenderer
/*     */     extends JTree
/*     */     implements TableCellRenderer
/*     */   {
/*     */     private static final long serialVersionUID = -193867880014600717L;
/*     */     protected int visibleRow;
/*     */     
/*     */     public TreeTableCellRenderer(TreeModel model) {
/* 164 */       super(model);
/*     */ 
/*     */       
/* 167 */       setBorder((Border)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void updateUI() {
/* 176 */       super.updateUI();
/*     */ 
/*     */       
/* 179 */       TreeCellRenderer tcr = getCellRenderer();
/* 180 */       if (tcr instanceof DefaultTreeCellRenderer) {
/* 181 */         DefaultTreeCellRenderer dtcr = (DefaultTreeCellRenderer)tcr;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 186 */         dtcr.setTextSelectionColor(
/* 187 */             UIManager.getColor("Table.selectionForeground"));
/* 188 */         dtcr.setBackgroundSelectionColor(
/* 189 */             UIManager.getColor("Table.selectionBackground"));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setRowHeight(int rowHeight) {
/* 199 */       if (rowHeight > 0) {
/* 200 */         super.setRowHeight(rowHeight);
/* 201 */         if (JTreeTable.this.getRowHeight() != rowHeight) {
/* 202 */           JTreeTable.this.setRowHeight(getRowHeight());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBounds(int x, int y, int w, int h) {
/* 212 */       super.setBounds(x, 0, w, JTreeTable.this.getHeight());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void paint(Graphics g) {
/* 221 */       g.translate(0, -this.visibleRow * getRowHeight());
/* 222 */       super.paint(g);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 233 */       if (isSelected) {
/* 234 */         setBackground(table.getSelectionBackground());
/*     */       } else {
/* 236 */         setBackground(table.getBackground());
/*     */       } 
/* 238 */       this.visibleRow = row;
/* 239 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class TreeTableCellEditor
/*     */     extends AbstractCellEditor
/*     */     implements TableCellEditor
/*     */   {
/*     */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int r, int c) {
/* 254 */       return JTreeTable.this.tree;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isCellEditable(EventObject e) {
/* 277 */       if (e instanceof MouseEvent) {
/* 278 */         for (int counter = JTreeTable.this.getColumnCount() - 1; counter >= 0; 
/* 279 */           counter--) {
/* 280 */           if (JTreeTable.this.getColumnClass(counter) == TreeTableModel.class) {
/* 281 */             MouseEvent me = (MouseEvent)e;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 286 */             MouseEvent newME = new MouseEvent(JTreeTable.this.tree, me.getID(), me.getWhen(), me.getModifiers(), me.getX() - (JTreeTable.this.getCellRect(0, counter, true)).x, me.getY(), me.getClickCount(), me.isPopupTrigger());
/* 287 */             JTreeTable.this.tree.dispatchEvent(newME);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 292 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class ListToTreeSelectionModelWrapper
/*     */     extends DefaultTreeSelectionModel
/*     */   {
/*     */     private static final long serialVersionUID = 8168140829623071131L;
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean updatingListSelectionModel;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ListToTreeSelectionModelWrapper() {
/* 313 */       getListSelectionModel()
/* 314 */         .addListSelectionListener(createListSelectionListener());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ListSelectionModel getListSelectionModel() {
/* 323 */       return this.listSelectionModel;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void resetRowSelection() {
/* 333 */       if (!this.updatingListSelectionModel) {
/* 334 */         this.updatingListSelectionModel = true;
/*     */         try {
/* 336 */           super.resetRowSelection();
/*     */         } finally {
/*     */           
/* 339 */           this.updatingListSelectionModel = false;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ListSelectionListener createListSelectionListener() {
/* 353 */       return new ListSelectionHandler();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void updateSelectedPathsFromSelectedRows() {
/* 362 */       if (!this.updatingListSelectionModel) {
/* 363 */         this.updatingListSelectionModel = true;
/*     */ 
/*     */         
/*     */         try {
/* 367 */           int min = this.listSelectionModel.getMinSelectionIndex();
/* 368 */           int max = this.listSelectionModel.getMaxSelectionIndex();
/*     */           
/* 370 */           clearSelection();
/* 371 */           if (min != -1 && max != -1) {
/* 372 */             for (int counter = min; counter <= max; counter++) {
/* 373 */               if (this.listSelectionModel.isSelectedIndex(counter)) {
/*     */                 
/* 375 */                 TreePath selPath = JTreeTable.this.tree.getPathForRow(counter);
/*     */                 
/* 377 */                 if (selPath != null) {
/* 378 */                   addSelectionPath(selPath);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } finally {
/*     */           
/* 385 */           this.updatingListSelectionModel = false;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     class ListSelectionHandler
/*     */       implements ListSelectionListener
/*     */     {
/*     */       public void valueChanged(ListSelectionEvent e) {
/* 396 */         JTreeTable.ListToTreeSelectionModelWrapper.this.updateSelectedPathsFromSelectedRows();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\debugger\treetable\JTreeTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */