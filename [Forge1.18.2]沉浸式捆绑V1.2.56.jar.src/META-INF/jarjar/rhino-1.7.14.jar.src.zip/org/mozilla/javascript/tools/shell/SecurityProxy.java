package org.mozilla.javascript.tools.shell;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.SecurityController;

public abstract class SecurityProxy extends SecurityController {
  protected abstract void callProcessFileSecure(Context paramContext, Scriptable paramScriptable, String paramString);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\SecurityProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */