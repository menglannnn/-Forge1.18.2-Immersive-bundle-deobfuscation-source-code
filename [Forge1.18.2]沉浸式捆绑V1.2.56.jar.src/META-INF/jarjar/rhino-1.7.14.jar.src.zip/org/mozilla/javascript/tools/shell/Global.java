/*      */ package org.mozilla.javascript.tools.shell;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.mozilla.javascript.Context;
/*      */ import org.mozilla.javascript.ContextFactory;
/*      */ import org.mozilla.javascript.ErrorReporter;
/*      */ import org.mozilla.javascript.Function;
/*      */ import org.mozilla.javascript.ImporterTopLevel;
/*      */ import org.mozilla.javascript.NativeArray;
/*      */ import org.mozilla.javascript.RhinoException;
/*      */ import org.mozilla.javascript.Script;
/*      */ import org.mozilla.javascript.ScriptRuntime;
/*      */ import org.mozilla.javascript.Scriptable;
/*      */ import org.mozilla.javascript.ScriptableObject;
/*      */ import org.mozilla.javascript.Synchronizer;
/*      */ import org.mozilla.javascript.Undefined;
/*      */ import org.mozilla.javascript.Wrapper;
/*      */ import org.mozilla.javascript.commonjs.module.ModuleScriptProvider;
/*      */ import org.mozilla.javascript.commonjs.module.Require;
/*      */ import org.mozilla.javascript.commonjs.module.RequireBuilder;
/*      */ import org.mozilla.javascript.commonjs.module.provider.ModuleSourceProvider;
/*      */ import org.mozilla.javascript.commonjs.module.provider.SoftCachingModuleScriptProvider;
/*      */ import org.mozilla.javascript.commonjs.module.provider.UrlModuleSourceProvider;
/*      */ import org.mozilla.javascript.serialize.ScriptableInputStream;
/*      */ import org.mozilla.javascript.serialize.ScriptableOutputStream;
/*      */ import org.mozilla.javascript.tools.ToolErrorReporter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Global
/*      */   extends ImporterTopLevel
/*      */ {
/*      */   static final long serialVersionUID = 4029130780977538005L;
/*      */   NativeArray history;
/*      */   boolean attemptedJLineLoad;
/*      */   private ShellConsole console;
/*      */   private InputStream inStream;
/*      */   private PrintStream outStream;
/*      */   private PrintStream errStream;
/*      */   private boolean sealedStdLib = false;
/*      */   boolean initialized;
/*      */   private QuitAction quitAction;
/*   75 */   private String[] prompts = new String[] { "js> ", "  > " };
/*      */   
/*      */   private HashMap<String, String> doctestCanonicalizations;
/*      */ 
/*      */   
/*      */   public Global(Context cx) {
/*   81 */     init(cx);
/*      */   }
/*      */   
/*      */   public boolean isInitialized() {
/*   85 */     return this.initialized;
/*      */   }
/*      */ 
/*      */   
/*      */   public void initQuitAction(QuitAction quitAction) {
/*   90 */     if (quitAction == null) throw new IllegalArgumentException("quitAction is null"); 
/*   91 */     if (this.quitAction != null) throw new IllegalArgumentException("The method is once-call.");
/*      */     
/*   93 */     this.quitAction = quitAction;
/*      */   }
/*      */   
/*      */   public void init(ContextFactory factory) {
/*   97 */     factory.call(cx -> {
/*      */           init(cx);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init(Context cx) {
/*  107 */     initStandardObjects(cx, this.sealedStdLib);
/*  108 */     String[] names = { "defineClass", "deserialize", "doctest", "gc", "help", "load", "loadClass", "print", "quit", "readline", "readFile", "readUrl", "runCommand", "seal", "serialize", "spawn", "sync", "toint32", "version", "write" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  130 */     defineFunctionProperties(names, Global.class, 2);
/*      */ 
/*      */ 
/*      */     
/*  134 */     Environment.defineClass((ScriptableObject)this);
/*  135 */     Environment environment = new Environment((ScriptableObject)this);
/*  136 */     defineProperty("environment", environment, 2);
/*      */     
/*  138 */     this.history = (NativeArray)cx.newArray((Scriptable)this, 0);
/*  139 */     defineProperty("history", this.history, 2);
/*      */     
/*  141 */     this.initialized = true;
/*      */   }
/*      */   
/*      */   public Require installRequire(Context cx, List<String> modulePath, boolean sandboxed) {
/*  145 */     RequireBuilder rb = new RequireBuilder();
/*  146 */     rb.setSandboxed(sandboxed);
/*  147 */     List<URI> uris = new ArrayList<>();
/*  148 */     if (modulePath != null) {
/*  149 */       for (String path : modulePath) {
/*      */         try {
/*  151 */           URI uri = new URI(path);
/*  152 */           if (!uri.isAbsolute())
/*      */           {
/*  154 */             uri = (new File(path)).toURI().resolve("");
/*      */           }
/*  156 */           if (!uri.toString().endsWith("/"))
/*      */           {
/*      */             
/*  159 */             uri = new URI(uri + "/");
/*      */           }
/*  161 */           uris.add(uri);
/*  162 */         } catch (URISyntaxException usx) {
/*  163 */           throw new RuntimeException(usx);
/*      */         } 
/*      */       } 
/*      */     }
/*  167 */     rb.setModuleScriptProvider((ModuleScriptProvider)new SoftCachingModuleScriptProvider((ModuleSourceProvider)new UrlModuleSourceProvider(uris, null)));
/*      */     
/*  169 */     Require require = rb.createRequire(cx, (Scriptable)this);
/*  170 */     require.install((Scriptable)this);
/*  171 */     return require;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void help(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  180 */     PrintStream out = getInstance(funObj).getOut();
/*  181 */     out.println(ToolErrorReporter.getMessage("msg.help"));
/*      */   }
/*      */   
/*      */   public static void gc(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  185 */     System.gc();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object print(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  196 */     return doPrint(args, funObj, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object write(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  201 */     return doPrint(args, funObj, false);
/*      */   }
/*      */   
/*      */   private static Object doPrint(Object[] args, Function funObj, boolean newline) {
/*  205 */     PrintStream out = getInstance(funObj).getOut();
/*  206 */     for (int i = 0; i < args.length; i++) {
/*  207 */       if (i > 0) out.print(" ");
/*      */ 
/*      */       
/*  210 */       String s = Context.toString(args[i]);
/*      */       
/*  212 */       out.print(s);
/*      */     } 
/*  214 */     if (newline) {
/*  215 */       out.println();
/*      */     }
/*  217 */     return Context.getUndefinedValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void quit(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  226 */     Global global = getInstance(funObj);
/*  227 */     if (global.quitAction != null) {
/*  228 */       int exitCode = (args.length == 0) ? 0 : ScriptRuntime.toInt32(args[0]);
/*  229 */       global.quitAction.quit(cx, exitCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double version(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  239 */     if (args.length > 0) {
/*  240 */       double d = Context.toNumber(args[0]);
/*  241 */       cx.setLanguageVersion((int)d);
/*      */     } 
/*  243 */     return cx.getLanguageVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void load(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  252 */     for (Object arg : args) {
/*  253 */       String file = Context.toString(arg);
/*      */       try {
/*  255 */         Main.processFile(cx, thisObj, file);
/*  256 */       } catch (IOException ioex) {
/*      */         
/*  258 */         String msg = ToolErrorReporter.getMessage("msg.couldnt.read.source", file, ioex
/*  259 */             .getMessage());
/*  260 */         throw Context.reportRuntimeError(msg);
/*  261 */       } catch (VirtualMachineError ex) {
/*      */         
/*  263 */         ex.printStackTrace();
/*  264 */         String msg = ToolErrorReporter.getMessage("msg.uncaughtJSException", ex.toString());
/*  265 */         throw Context.reportRuntimeError(msg);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void defineClass(Context cx, Scriptable thisObj, Object[] args, Function funObj) throws IllegalAccessException, InstantiationException, InvocationTargetException {
/*  285 */     Class<?> clazz = getClass(args);
/*  286 */     if (!Scriptable.class.isAssignableFrom(clazz)) {
/*  287 */       throw reportRuntimeError("msg.must.implement.Scriptable");
/*      */     }
/*  289 */     ScriptableObject.defineClass(thisObj, clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void loadClass(Context cx, Scriptable thisObj, Object[] args, Function funObj) throws IllegalAccessException, InstantiationException {
/*  304 */     Class<?> clazz = getClass(args);
/*  305 */     if (!Script.class.isAssignableFrom(clazz)) {
/*  306 */       throw reportRuntimeError("msg.must.implement.Script");
/*      */     }
/*  308 */     Script script = (Script)clazz.newInstance();
/*  309 */     script.exec(cx, thisObj);
/*      */   }
/*      */   
/*      */   private static Class<?> getClass(Object[] args) {
/*  313 */     if (args.length == 0) {
/*  314 */       throw reportRuntimeError("msg.expected.string.arg");
/*      */     }
/*  316 */     Object arg0 = args[0];
/*  317 */     if (arg0 instanceof Wrapper) {
/*  318 */       Object wrapped = ((Wrapper)arg0).unwrap();
/*  319 */       if (wrapped instanceof Class) return (Class)wrapped; 
/*      */     } 
/*  321 */     String className = Context.toString(args[0]);
/*      */     try {
/*  323 */       return Class.forName(className);
/*  324 */     } catch (ClassNotFoundException cnfe) {
/*  325 */       throw reportRuntimeError("msg.class.not.found", className);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void serialize(Context cx, Scriptable thisObj, Object[] args, Function funObj) throws IOException {
/*  331 */     if (args.length < 2) {
/*  332 */       throw Context.reportRuntimeError("Expected an object to serialize and a filename to write the serialization to");
/*      */     }
/*      */ 
/*      */     
/*  336 */     Object obj = args[0];
/*  337 */     String filename = Context.toString(args[1]);
/*  338 */     FileOutputStream fos = new FileOutputStream(filename);
/*  339 */     Scriptable scope = ScriptableObject.getTopLevelScope(thisObj);
/*  340 */     ScriptableOutputStream out = new ScriptableOutputStream(fos, scope);
/*  341 */     out.writeObject(obj);
/*  342 */     out.close();
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object deserialize(Context cx, Scriptable thisObj, Object[] args, Function funObj) throws IOException, ClassNotFoundException {
/*  347 */     if (args.length < 1) {
/*  348 */       throw Context.reportRuntimeError("Expected a filename to read the serialization from");
/*      */     }
/*  350 */     String filename = Context.toString(args[0]);
/*  351 */     FileInputStream fis = new FileInputStream(filename);
/*  352 */     Scriptable scope = ScriptableObject.getTopLevelScope(thisObj);
/*  353 */     ScriptableInputStream scriptableInputStream = new ScriptableInputStream(fis, scope);
/*  354 */     Object deserialized = scriptableInputStream.readObject();
/*  355 */     scriptableInputStream.close();
/*  356 */     return Context.toObject(deserialized, scope);
/*      */   }
/*      */   
/*      */   public String[] getPrompts(Context cx) {
/*  360 */     if (ScriptableObject.hasProperty((Scriptable)this, "prompts")) {
/*  361 */       Object promptsJS = ScriptableObject.getProperty((Scriptable)this, "prompts");
/*  362 */       if (promptsJS instanceof Scriptable) {
/*  363 */         Scriptable s = (Scriptable)promptsJS;
/*  364 */         if (ScriptableObject.hasProperty(s, 0) && ScriptableObject.hasProperty(s, 1)) {
/*  365 */           Object elem0 = ScriptableObject.getProperty(s, 0);
/*  366 */           if (elem0 instanceof Function) {
/*  367 */             elem0 = ((Function)elem0).call(cx, (Scriptable)this, s, new Object[0]);
/*      */           }
/*  369 */           this.prompts[0] = Context.toString(elem0);
/*  370 */           Object elem1 = ScriptableObject.getProperty(s, 1);
/*  371 */           if (elem1 instanceof Function) {
/*  372 */             elem1 = ((Function)elem1).call(cx, (Scriptable)this, s, new Object[0]);
/*      */           }
/*  374 */           this.prompts[1] = Context.toString(elem1);
/*      */         } 
/*      */       } 
/*      */     } 
/*  378 */     return this.prompts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object doctest(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  386 */     if (args.length == 0) {
/*  387 */       return Boolean.FALSE;
/*      */     }
/*  389 */     String session = Context.toString(args[0]);
/*  390 */     Global global = getInstance(funObj);
/*  391 */     return Integer.valueOf(global.runDoctest(cx, (Scriptable)global, session, (String)null, 0));
/*      */   }
/*      */ 
/*      */   
/*      */   public int runDoctest(Context cx, Scriptable scope, String session, String sourceName, int lineNumber) {
/*  396 */     this.doctestCanonicalizations = new HashMap<>();
/*  397 */     String[] lines = session.split("\r\n?|\n");
/*  398 */     String prompt0 = this.prompts[0].trim();
/*  399 */     String prompt1 = this.prompts[1].trim();
/*  400 */     int testCount = 0;
/*  401 */     int i = 0;
/*  402 */     while (i < lines.length && !lines[i].trim().startsWith(prompt0)) {
/*  403 */       i++;
/*      */     }
/*  405 */     while (i < lines.length) {
/*      */       
/*  407 */       StringBuilder inputString = new StringBuilder(lines[i].trim().substring(prompt0.length()));
/*  408 */       inputString.append('\n');
/*  409 */       i++;
/*  410 */       while (i < lines.length && lines[i].trim().startsWith(prompt1)) {
/*  411 */         inputString.append(lines[i].trim().substring(prompt1.length()));
/*  412 */         inputString.append('\n');
/*  413 */         i++;
/*      */       } 
/*  415 */       StringBuilder expectedString = new StringBuilder();
/*  416 */       while (i < lines.length && !lines[i].trim().startsWith(prompt0)) {
/*  417 */         expectedString.append(lines[i]).append('\n');
/*  418 */         i++;
/*      */       } 
/*  420 */       PrintStream savedOut = getOut();
/*  421 */       PrintStream savedErr = getErr();
/*  422 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  423 */       ByteArrayOutputStream err = new ByteArrayOutputStream();
/*  424 */       setOut(new PrintStream(out));
/*  425 */       setErr(new PrintStream(err));
/*  426 */       String resultString = "";
/*  427 */       ErrorReporter savedErrorReporter = cx.getErrorReporter();
/*  428 */       cx.setErrorReporter((ErrorReporter)new ToolErrorReporter(false, getErr()));
/*      */       try {
/*  430 */         testCount++;
/*  431 */         String finalInputString = inputString.toString();
/*      */         
/*  433 */         Object result = cx.evaluateString(scope, finalInputString, "doctest input", 1, null);
/*  434 */         if (result != Context.getUndefinedValue() && (!(result instanceof Function) || 
/*      */           
/*  436 */           !finalInputString.trim().startsWith("function"))) {
/*  437 */           resultString = Context.toString(result);
/*      */         }
/*  439 */       } catch (RhinoException e) {
/*  440 */         ToolErrorReporter.reportException(cx.getErrorReporter(), e);
/*      */       } finally {
/*  442 */         setOut(savedOut);
/*  443 */         setErr(savedErr);
/*  444 */         cx.setErrorReporter(savedErrorReporter);
/*  445 */         resultString = resultString + err.toString() + out.toString();
/*      */       } 
/*  447 */       if (!doctestOutputMatches(expectedString.toString(), resultString)) {
/*  448 */         String message = "doctest failure running:\n" + inputString + "expected: " + expectedString + "actual: " + resultString + "\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  456 */         if (sourceName != null) {
/*  457 */           throw Context.reportRuntimeError(message, sourceName, lineNumber + i - 1, null, 0);
/*      */         }
/*      */         
/*  460 */         throw Context.reportRuntimeError(message);
/*      */       } 
/*      */     } 
/*      */     
/*  464 */     return testCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doctestOutputMatches(String expected, String actual) {
/*  477 */     expected = expected.trim();
/*  478 */     actual = actual.trim().replace("\r\n", "\n");
/*  479 */     if (expected.equals(actual)) return true; 
/*  480 */     for (Map.Entry<String, String> entry : this.doctestCanonicalizations.entrySet()) {
/*  481 */       expected = expected.replace(entry.getKey(), entry.getValue());
/*      */     }
/*  483 */     if (expected.equals(actual)) return true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  490 */     Pattern p = Pattern.compile("@[0-9a-fA-F]+");
/*  491 */     Matcher expectedMatcher = p.matcher(expected);
/*  492 */     Matcher actualMatcher = p.matcher(actual);
/*      */     while (true) {
/*  494 */       if (!expectedMatcher.find()) return false; 
/*  495 */       if (!actualMatcher.find()) return false; 
/*  496 */       if (actualMatcher.start() != expectedMatcher.start()) return false; 
/*  497 */       int start = expectedMatcher.start();
/*  498 */       if (!expected.substring(0, start).equals(actual.substring(0, start))) return false; 
/*  499 */       String expectedGroup = expectedMatcher.group();
/*  500 */       String actualGroup = actualMatcher.group();
/*  501 */       String mapping = this.doctestCanonicalizations.get(expectedGroup);
/*  502 */       if (mapping == null) {
/*  503 */         this.doctestCanonicalizations.put(expectedGroup, actualGroup);
/*  504 */         expected = expected.replace(expectedGroup, actualGroup);
/*  505 */       } else if (!actualGroup.equals(mapping)) {
/*  506 */         return false;
/*      */       } 
/*  508 */       if (expected.equals(actual)) return true;
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object spawn(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*      */     Runner runner;
/*  519 */     Scriptable scope = funObj.getParentScope();
/*      */     
/*  521 */     if (args.length != 0 && args[0] instanceof Function) {
/*  522 */       Object[] newArgs = null;
/*  523 */       if (args.length > 1 && args[1] instanceof Scriptable) {
/*  524 */         newArgs = cx.getElements((Scriptable)args[1]);
/*      */       }
/*  526 */       if (newArgs == null) {
/*  527 */         newArgs = ScriptRuntime.emptyArgs;
/*      */       }
/*  529 */       runner = new Runner(scope, (Function)args[0], newArgs);
/*  530 */     } else if (args.length != 0 && args[0] instanceof Script) {
/*  531 */       runner = new Runner(scope, (Script)args[0]);
/*      */     } else {
/*  533 */       throw reportRuntimeError("msg.spawn.args");
/*      */     } 
/*  535 */     runner.factory = cx.getFactory();
/*  536 */     Thread thread = new Thread(runner);
/*  537 */     thread.start();
/*  538 */     return thread;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object sync(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  550 */     if (args.length >= 1 && args.length <= 2 && args[0] instanceof Function) {
/*  551 */       Object syncObject = null;
/*  552 */       if (args.length == 2 && args[1] != Undefined.instance) {
/*  553 */         syncObject = args[1];
/*      */       }
/*  555 */       return new Synchronizer((Scriptable)args[0], syncObject);
/*      */     } 
/*  557 */     throw reportRuntimeError("msg.sync.args");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object runCommand(Context cx, Scriptable thisObj, Object[] args, Function funObj) throws IOException {
/*  598 */     int L = args.length;
/*  599 */     if (L == 0 || (L == 1 && args[0] instanceof Scriptable)) {
/*  600 */       throw reportRuntimeError("msg.runCommand.bad.args");
/*      */     }
/*  602 */     File wd = null;
/*  603 */     InputStream in = null;
/*  604 */     OutputStream out = null, err = null;
/*  605 */     ByteArrayOutputStream outBytes = null, errBytes = null;
/*  606 */     Object outObj = null, errObj = null;
/*  607 */     String[] environment = null;
/*  608 */     Scriptable params = null;
/*  609 */     Object[] addArgs = null;
/*  610 */     if (args[L - 1] instanceof Scriptable) {
/*  611 */       params = (Scriptable)args[L - 1];
/*  612 */       L--;
/*  613 */       Object envObj = ScriptableObject.getProperty(params, "env");
/*  614 */       if (envObj != Scriptable.NOT_FOUND) {
/*  615 */         if (envObj == null) {
/*  616 */           environment = new String[0];
/*      */         } else {
/*  618 */           if (!(envObj instanceof Scriptable)) {
/*  619 */             throw reportRuntimeError("msg.runCommand.bad.env");
/*      */           }
/*  621 */           Scriptable envHash = (Scriptable)envObj;
/*  622 */           Object[] ids = ScriptableObject.getPropertyIds(envHash);
/*  623 */           environment = new String[ids.length];
/*  624 */           for (int j = 0; j != ids.length; j++) {
/*  625 */             Object val; String key; Object keyObj = ids[j];
/*      */             
/*  627 */             if (keyObj instanceof String) {
/*  628 */               key = (String)keyObj;
/*  629 */               val = ScriptableObject.getProperty(envHash, key);
/*      */             } else {
/*  631 */               int ikey = ((Number)keyObj).intValue();
/*  632 */               key = Integer.toString(ikey);
/*  633 */               val = ScriptableObject.getProperty(envHash, ikey);
/*      */             } 
/*  635 */             if (val == ScriptableObject.NOT_FOUND) {
/*  636 */               val = Undefined.instance;
/*      */             }
/*  638 */             environment[j] = key + '=' + ScriptRuntime.toString(val);
/*      */           } 
/*      */         } 
/*      */       }
/*  642 */       Object wdObj = ScriptableObject.getProperty(params, "dir");
/*  643 */       if (wdObj != Scriptable.NOT_FOUND) {
/*  644 */         wd = new File(ScriptRuntime.toString(wdObj));
/*      */       }
/*      */       
/*  647 */       Object inObj = ScriptableObject.getProperty(params, "input");
/*  648 */       if (inObj != Scriptable.NOT_FOUND) {
/*  649 */         in = toInputStream(inObj);
/*      */       }
/*  651 */       outObj = ScriptableObject.getProperty(params, "output");
/*  652 */       if (outObj != Scriptable.NOT_FOUND) {
/*  653 */         out = toOutputStream(outObj);
/*  654 */         if (out == null) {
/*  655 */           outBytes = new ByteArrayOutputStream();
/*  656 */           out = outBytes;
/*      */         } 
/*      */       } 
/*  659 */       errObj = ScriptableObject.getProperty(params, "err");
/*  660 */       if (errObj != Scriptable.NOT_FOUND) {
/*  661 */         err = toOutputStream(errObj);
/*  662 */         if (err == null) {
/*  663 */           errBytes = new ByteArrayOutputStream();
/*  664 */           err = errBytes;
/*      */         } 
/*      */       } 
/*  667 */       Object addArgsObj = ScriptableObject.getProperty(params, "args");
/*  668 */       if (addArgsObj != Scriptable.NOT_FOUND) {
/*  669 */         Scriptable s = Context.toObject(addArgsObj, getTopLevelScope(thisObj));
/*  670 */         addArgs = cx.getElements(s);
/*      */       } 
/*      */     } 
/*  673 */     Global global = getInstance(funObj);
/*  674 */     if (out == null) {
/*  675 */       out = global.getOut();
/*      */     }
/*  677 */     if (err == null) {
/*  678 */       err = global.getErr();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  685 */     String[] cmd = new String[(addArgs == null) ? L : (L + addArgs.length)]; int i;
/*  686 */     for (i = 0; i != L; i++) {
/*  687 */       cmd[i] = ScriptRuntime.toString(args[i]);
/*      */     }
/*  689 */     if (addArgs != null) {
/*  690 */       for (i = 0; i != addArgs.length; i++) {
/*  691 */         cmd[L + i] = ScriptRuntime.toString(addArgs[i]);
/*      */       }
/*      */     }
/*      */     
/*  695 */     int exitCode = runProcess(cmd, environment, wd, in, out, err);
/*  696 */     if (outBytes != null) {
/*  697 */       String s = ScriptRuntime.toString(outObj) + outBytes.toString();
/*  698 */       ScriptableObject.putProperty(params, "output", s);
/*      */     } 
/*  700 */     if (errBytes != null) {
/*  701 */       String s = ScriptRuntime.toString(errObj) + errBytes.toString();
/*  702 */       ScriptableObject.putProperty(params, "err", s);
/*      */     } 
/*      */     
/*  705 */     return Integer.valueOf(exitCode);
/*      */   }
/*      */   
/*      */   public static void seal(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*      */     int i;
/*  710 */     for (i = 0; i != args.length; i++) {
/*  711 */       Object arg = args[i];
/*  712 */       if (!(arg instanceof ScriptableObject) || arg == Undefined.instance) {
/*  713 */         if (!(arg instanceof Scriptable) || arg == Undefined.instance) {
/*  714 */           throw reportRuntimeError("msg.shell.seal.not.object");
/*      */         }
/*  716 */         throw reportRuntimeError("msg.shell.seal.not.scriptable");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  721 */     for (i = 0; i != args.length; i++) {
/*  722 */       Object arg = args[i];
/*  723 */       ((ScriptableObject)arg).sealObject();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object readFile(Context cx, Scriptable thisObj, Object[] args, Function funObj) throws IOException {
/*  742 */     if (args.length == 0) {
/*  743 */       throw reportRuntimeError("msg.shell.readFile.bad.args");
/*      */     }
/*  745 */     String path = ScriptRuntime.toString(args[0]);
/*  746 */     String charCoding = null;
/*  747 */     if (args.length >= 2) {
/*  748 */       charCoding = ScriptRuntime.toString(args[1]);
/*      */     }
/*      */     
/*  751 */     return readUrl(path, charCoding, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object readUrl(Context cx, Scriptable thisObj, Object[] args, Function funObj) throws IOException {
/*  770 */     if (args.length == 0) {
/*  771 */       throw reportRuntimeError("msg.shell.readUrl.bad.args");
/*      */     }
/*  773 */     String url = ScriptRuntime.toString(args[0]);
/*  774 */     String charCoding = null;
/*  775 */     if (args.length >= 2) {
/*  776 */       charCoding = ScriptRuntime.toString(args[1]);
/*      */     }
/*      */     
/*  779 */     return readUrl(url, charCoding, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toint32(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/*  784 */     Object arg = (args.length != 0) ? args[0] : Undefined.instance;
/*  785 */     if (arg instanceof Integer) return arg; 
/*  786 */     return ScriptRuntime.wrapInt(ScriptRuntime.toInt32(arg));
/*      */   }
/*      */   
/*      */   private boolean loadJLine(Charset cs) {
/*  790 */     if (!this.attemptedJLineLoad) {
/*      */       
/*  792 */       this.attemptedJLineLoad = true;
/*  793 */       this.console = ShellConsole.getConsole((Scriptable)this, cs);
/*      */     } 
/*  795 */     return (this.console != null);
/*      */   }
/*      */   
/*      */   public ShellConsole getConsole(Charset cs) {
/*  799 */     if (!loadJLine(cs)) {
/*  800 */       this.console = ShellConsole.getConsole(getIn(), getErr(), cs);
/*      */     }
/*  802 */     return this.console;
/*      */   }
/*      */   
/*      */   public InputStream getIn() {
/*  806 */     if (this.inStream == null && !this.attemptedJLineLoad && 
/*  807 */       loadJLine(Charset.defaultCharset())) {
/*  808 */       this.inStream = this.console.getIn();
/*      */     }
/*      */     
/*  811 */     return (this.inStream == null) ? System.in : this.inStream;
/*      */   }
/*      */   
/*      */   public void setIn(InputStream in) {
/*  815 */     this.inStream = in;
/*      */   }
/*      */   
/*      */   public PrintStream getOut() {
/*  819 */     return (this.outStream == null) ? System.out : this.outStream;
/*      */   }
/*      */   
/*      */   public void setOut(PrintStream out) {
/*  823 */     this.outStream = out;
/*      */   }
/*      */   
/*      */   public PrintStream getErr() {
/*  827 */     return (this.errStream == null) ? System.err : this.errStream;
/*      */   }
/*      */   
/*      */   public void setErr(PrintStream err) {
/*  831 */     this.errStream = err;
/*      */   }
/*      */   
/*      */   public void setSealedStdLib(boolean value) {
/*  835 */     this.sealedStdLib = value;
/*      */   }
/*      */   
/*      */   private static Global getInstance(Function function) {
/*  839 */     Scriptable scope = function.getParentScope();
/*  840 */     if (!(scope instanceof Global))
/*  841 */       throw reportRuntimeError("msg.bad.shell.function.scope", String.valueOf(scope)); 
/*  842 */     return (Global)scope;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int runProcess(String[] cmd, String[] environment, File wd, InputStream in, OutputStream out, OutputStream err) throws IOException {
/*      */     Process p;
/*  862 */     if (environment == null) {
/*  863 */       p = Runtime.getRuntime().exec(cmd, (String[])null, wd);
/*      */     } else {
/*  865 */       p = Runtime.getRuntime().exec(cmd, environment, wd);
/*      */     } 
/*      */     
/*      */     try {
/*  869 */       PipeThread inThread = null;
/*  870 */       if (in != null) {
/*  871 */         inThread = new PipeThread(false, in, p.getOutputStream());
/*  872 */         inThread.start();
/*      */       } else {
/*  874 */         p.getOutputStream().close();
/*      */       } 
/*      */       
/*  877 */       PipeThread outThread = null;
/*  878 */       if (out != null) {
/*  879 */         outThread = new PipeThread(true, p.getInputStream(), out);
/*  880 */         outThread.start();
/*      */       } else {
/*  882 */         p.getInputStream().close();
/*      */       } 
/*      */       
/*  885 */       PipeThread errThread = null;
/*  886 */       if (err != null) {
/*  887 */         errThread = new PipeThread(true, p.getErrorStream(), err);
/*  888 */         errThread.start();
/*      */       } else {
/*  890 */         p.getErrorStream().close();
/*      */       } 
/*      */ 
/*      */       
/*      */       while (true) {
/*      */         try {
/*  896 */           p.waitFor();
/*  897 */           if (outThread != null) {
/*  898 */             outThread.join();
/*      */           }
/*  900 */           if (inThread != null) {
/*  901 */             inThread.join();
/*      */           }
/*  903 */           if (errThread != null) {
/*  904 */             errThread.join();
/*      */           }
/*      */           break;
/*  907 */         } catch (InterruptedException interruptedException) {}
/*      */       } 
/*      */ 
/*      */       
/*  911 */       return p.exitValue();
/*      */     } finally {
/*  913 */       p.destroy();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void pipe(boolean fromProcess, InputStream from, OutputStream to) throws IOException {
/*      */     try {
/*  919 */       int SIZE = 4096;
/*  920 */       byte[] buffer = new byte[4096];
/*      */       while (true) {
/*      */         int n;
/*  923 */         if (!fromProcess) {
/*  924 */           n = from.read(buffer, 0, 4096);
/*      */         } else {
/*      */           try {
/*  927 */             n = from.read(buffer, 0, 4096);
/*  928 */           } catch (IOException ex) {
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         
/*  933 */         if (n < 0) {
/*      */           break;
/*      */         }
/*  936 */         if (fromProcess) {
/*  937 */           to.write(buffer, 0, n);
/*  938 */           to.flush(); continue;
/*      */         } 
/*      */         try {
/*  941 */           to.write(buffer, 0, n);
/*  942 */           to.flush();
/*  943 */         } catch (IOException ex) {
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } finally {
/*      */       
/*      */       try {
/*  951 */         if (fromProcess) {
/*  952 */           from.close();
/*      */         } else {
/*  954 */           to.close();
/*      */         } 
/*  956 */       } catch (IOException iOException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static InputStream toInputStream(Object value) throws IOException {
/*  964 */     InputStream is = null;
/*  965 */     String s = null;
/*  966 */     if (value instanceof Wrapper) {
/*  967 */       Object unwrapped = ((Wrapper)value).unwrap();
/*  968 */       if (unwrapped instanceof InputStream) {
/*  969 */         is = (InputStream)unwrapped;
/*  970 */       } else if (unwrapped instanceof byte[]) {
/*  971 */         is = new ByteArrayInputStream((byte[])unwrapped);
/*  972 */       } else if (unwrapped instanceof Reader) {
/*  973 */         s = readReader((Reader)unwrapped);
/*  974 */       } else if (unwrapped instanceof char[]) {
/*  975 */         s = new String((char[])unwrapped);
/*      */       } 
/*      */     } 
/*  978 */     if (is == null) {
/*  979 */       if (s == null) {
/*  980 */         s = ScriptRuntime.toString(value);
/*      */       }
/*  982 */       is = new ByteArrayInputStream(s.getBytes());
/*      */     } 
/*  984 */     return is;
/*      */   }
/*      */   
/*      */   private static OutputStream toOutputStream(Object value) {
/*  988 */     OutputStream os = null;
/*  989 */     if (value instanceof Wrapper) {
/*  990 */       Object unwrapped = ((Wrapper)value).unwrap();
/*  991 */       if (unwrapped instanceof OutputStream) {
/*  992 */         os = (OutputStream)unwrapped;
/*      */       }
/*      */     } 
/*  995 */     return os;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String readUrl(String filePath, String charCoding, boolean urlIsFile) throws IOException {
/* 1001 */     InputStream is = null; try {
/*      */       int chunkLength; Reader r;
/* 1003 */       if (!urlIsFile) {
/* 1004 */         URL urlObj = new URL(filePath);
/* 1005 */         URLConnection uc = urlObj.openConnection();
/* 1006 */         is = uc.getInputStream();
/* 1007 */         chunkLength = uc.getContentLength();
/* 1008 */         if (chunkLength <= 0) chunkLength = 1024; 
/* 1009 */         if (charCoding == null) {
/* 1010 */           String type = uc.getContentType();
/* 1011 */           if (type != null) {
/* 1012 */             charCoding = getCharCodingFromType(type);
/*      */           }
/*      */         } 
/*      */       } else {
/* 1016 */         File f = new File(filePath);
/* 1017 */         if (!f.exists())
/* 1018 */           throw new FileNotFoundException("File not found: " + filePath); 
/* 1019 */         if (!f.canRead()) {
/* 1020 */           throw new IOException("Cannot read file: " + filePath);
/*      */         }
/* 1022 */         long length = f.length();
/* 1023 */         chunkLength = (int)length;
/* 1024 */         if (chunkLength != length) throw new IOException("Too big file size: " + length);
/*      */         
/* 1026 */         if (chunkLength == 0) {
/* 1027 */           return "";
/*      */         }
/*      */         
/* 1030 */         is = new FileInputStream(f);
/*      */       } 
/*      */ 
/*      */       
/* 1034 */       if (charCoding == null) {
/* 1035 */         r = new InputStreamReader(is);
/*      */       } else {
/* 1037 */         r = new InputStreamReader(is, charCoding);
/*      */       } 
/* 1039 */       return readReader(r, chunkLength);
/*      */     } finally {
/*      */       
/* 1042 */       if (is != null) is.close();
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object readline(Context cx, Scriptable thisObj, Object[] args, Function funObj) throws IOException {
/* 1057 */     Global self = getInstance(funObj);
/*      */     
/* 1059 */     if (args.length > 0) {
/* 1060 */       return self.console.readLine(Context.toString(args[0]));
/*      */     }
/* 1062 */     return self.console.readLine();
/*      */   }
/*      */   
/*      */   private static String getCharCodingFromType(String type) {
/* 1066 */     int i = type.indexOf(';');
/* 1067 */     if (i >= 0) {
/* 1068 */       int end = type.length();
/* 1069 */       i++;
/* 1070 */       while (i != end && type.charAt(i) <= ' ') {
/* 1071 */         i++;
/*      */       }
/* 1073 */       String charset = "charset";
/* 1074 */       if (charset.regionMatches(true, 0, type, i, charset.length())) {
/* 1075 */         i += charset.length();
/* 1076 */         while (i != end && type.charAt(i) <= ' ') {
/* 1077 */           i++;
/*      */         }
/* 1079 */         if (i != end && type.charAt(i) == '=') {
/* 1080 */           i++;
/* 1081 */           while (i != end && type.charAt(i) <= ' ') {
/* 1082 */             i++;
/*      */           }
/* 1084 */           if (i != end) {
/*      */ 
/*      */             
/* 1087 */             while (type.charAt(end - 1) <= ' ') {
/* 1088 */               end--;
/*      */             }
/* 1090 */             return type.substring(i, end);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1095 */     return null;
/*      */   }
/*      */   
/*      */   private static String readReader(Reader reader) throws IOException {
/* 1099 */     return readReader(reader, 4096);
/*      */   }
/*      */   
/*      */   private static String readReader(Reader reader, int initialBufferSize) throws IOException {
/* 1103 */     char[] buffer = new char[initialBufferSize];
/* 1104 */     int offset = 0;
/*      */     while (true) {
/* 1106 */       int n = reader.read(buffer, offset, buffer.length - offset);
/* 1107 */       if (n < 0) {
/*      */         break;
/*      */       }
/* 1110 */       offset += n;
/* 1111 */       if (offset == buffer.length) {
/* 1112 */         char[] tmp = new char[buffer.length * 2];
/* 1113 */         System.arraycopy(buffer, 0, tmp, 0, offset);
/* 1114 */         buffer = tmp;
/*      */       } 
/*      */     } 
/* 1117 */     return new String(buffer, 0, offset);
/*      */   }
/*      */   
/*      */   static RuntimeException reportRuntimeError(String msgId) {
/* 1121 */     String message = ToolErrorReporter.getMessage(msgId);
/* 1122 */     return (RuntimeException)Context.reportRuntimeError(message);
/*      */   }
/*      */   
/*      */   static RuntimeException reportRuntimeError(String msgId, String msgArg) {
/* 1126 */     String message = ToolErrorReporter.getMessage(msgId, msgArg);
/* 1127 */     return (RuntimeException)Context.reportRuntimeError(message);
/*      */   }
/*      */   
/*      */   public Global() {}
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\Global.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */