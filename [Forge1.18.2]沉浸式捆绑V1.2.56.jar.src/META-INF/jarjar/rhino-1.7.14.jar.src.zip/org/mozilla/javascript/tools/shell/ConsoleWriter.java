/*    */ package org.mozilla.javascript.tools.shell;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ import javax.swing.SwingUtilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConsoleWriter
/*    */   extends OutputStream
/*    */ {
/*    */   private ConsoleTextArea textArea;
/*    */   private StringBuffer buffer;
/*    */   
/*    */   public ConsoleWriter(ConsoleTextArea textArea) {
/* 45 */     this.textArea = textArea;
/* 46 */     this.buffer = new StringBuffer();
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void write(int ch) {
/* 51 */     this.buffer.append((char)ch);
/* 52 */     if (ch == 10) {
/* 53 */       flushBuffer();
/*    */     }
/*    */   }
/*    */   
/*    */   public synchronized void write(char[] data, int off, int len) {
/* 58 */     for (int i = off; i < len; i++) {
/* 59 */       this.buffer.append(data[i]);
/* 60 */       if (data[i] == '\n') {
/* 61 */         flushBuffer();
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void flush() {
/* 68 */     if (this.buffer.length() > 0) {
/* 69 */       flushBuffer();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 75 */     flush();
/*    */   }
/*    */   
/*    */   private void flushBuffer() {
/* 79 */     String str = this.buffer.toString();
/* 80 */     this.buffer.setLength(0);
/* 81 */     SwingUtilities.invokeLater(new ConsoleWrite(this.textArea, str));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\ConsoleWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */