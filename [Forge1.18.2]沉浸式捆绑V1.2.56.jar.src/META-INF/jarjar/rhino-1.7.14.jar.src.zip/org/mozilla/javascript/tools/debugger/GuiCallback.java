package org.mozilla.javascript.tools.debugger;

public interface GuiCallback {
  void updateSourceText(Dim.SourceInfo paramSourceInfo);
  
  void enterInterrupt(Dim.StackFrame paramStackFrame, String paramString1, String paramString2);
  
  boolean isGuiEventThread();
  
  void dispatchNextGuiEvent() throws InterruptedException;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\debugger\GuiCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */