/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PipedInputStream;
/*     */ import java.io.PipedOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Segment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConsoleTextArea
/*     */   extends JTextArea
/*     */   implements KeyListener, DocumentListener
/*     */ {
/*     */   static final long serialVersionUID = 8557083244830872961L;
/*     */   private ConsoleWriter console1;
/*     */   private ConsoleWriter console2;
/*     */   private PrintStream out;
/*     */   private PrintStream err;
/*     */   private PrintWriter inPipe;
/*     */   private PipedInputStream in;
/*     */   private List<String> history;
/*  97 */   private int historyIndex = -1;
/*  98 */   private int outputMark = 0;
/*     */ 
/*     */   
/*     */   public void select(int start, int end) {
/* 102 */     requestFocus();
/* 103 */     super.select(start, end);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConsoleTextArea(String[] argv) {
/* 108 */     this.history = new ArrayList<>();
/* 109 */     this.console1 = new ConsoleWriter(this);
/* 110 */     this.console2 = new ConsoleWriter(this);
/* 111 */     this.out = new PrintStream(this.console1, true);
/* 112 */     this.err = new PrintStream(this.console2, true);
/* 113 */     PipedOutputStream outPipe = new PipedOutputStream();
/* 114 */     this.inPipe = new PrintWriter(outPipe);
/* 115 */     this.in = new PipedInputStream();
/*     */     try {
/* 117 */       outPipe.connect(this.in);
/* 118 */     } catch (IOException exc) {
/* 119 */       exc.printStackTrace();
/*     */     } 
/* 121 */     getDocument().addDocumentListener(this);
/* 122 */     addKeyListener(this);
/* 123 */     setLineWrap(true);
/* 124 */     setFont(new Font("Monospaced", 0, 12));
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void returnPressed() {
/* 129 */     Document doc = getDocument();
/* 130 */     int len = doc.getLength();
/* 131 */     Segment segment = new Segment();
/*     */     try {
/* 133 */       doc.getText(this.outputMark, len - this.outputMark, segment);
/* 134 */     } catch (BadLocationException ignored) {
/* 135 */       ignored.printStackTrace();
/*     */     } 
/* 137 */     if (segment.count > 0) {
/* 138 */       this.history.add(segment.toString());
/*     */     }
/* 140 */     this.historyIndex = this.history.size();
/* 141 */     this.inPipe.write(segment.array, segment.offset, segment.count);
/* 142 */     append("\n");
/* 143 */     this.outputMark = doc.getLength();
/* 144 */     this.inPipe.write("\n");
/* 145 */     this.inPipe.flush();
/* 146 */     this.console1.flush();
/*     */   }
/*     */   
/*     */   public void eval(String str) {
/* 150 */     this.inPipe.write(str);
/* 151 */     this.inPipe.write("\n");
/* 152 */     this.inPipe.flush();
/* 153 */     this.console1.flush();
/*     */   }
/*     */   
/*     */   public void keyPressed(KeyEvent e) {
/* 157 */     int code = e.getKeyCode();
/* 158 */     if (code == 8 || code == 37) {
/* 159 */       if (this.outputMark == getCaretPosition()) {
/* 160 */         e.consume();
/*     */       }
/* 162 */     } else if (code == 36) {
/* 163 */       int caretPos = getCaretPosition();
/* 164 */       if (caretPos == this.outputMark) {
/* 165 */         e.consume();
/* 166 */       } else if (caretPos > this.outputMark && 
/* 167 */         !e.isControlDown()) {
/* 168 */         if (e.isShiftDown()) {
/* 169 */           moveCaretPosition(this.outputMark);
/*     */         } else {
/* 171 */           setCaretPosition(this.outputMark);
/*     */         } 
/* 173 */         e.consume();
/*     */       }
/*     */     
/* 176 */     } else if (code == 10) {
/* 177 */       returnPressed();
/* 178 */       e.consume();
/* 179 */     } else if (code == 38) {
/* 180 */       this.historyIndex--;
/* 181 */       if (this.historyIndex >= 0) {
/* 182 */         if (this.historyIndex >= this.history.size()) {
/* 183 */           this.historyIndex = this.history.size() - 1;
/*     */         }
/* 185 */         if (this.historyIndex >= 0) {
/* 186 */           String str = this.history.get(this.historyIndex);
/* 187 */           int len = getDocument().getLength();
/* 188 */           replaceRange(str, this.outputMark, len);
/* 189 */           int caretPos = this.outputMark + str.length();
/* 190 */           select(caretPos, caretPos);
/*     */         } else {
/* 192 */           this.historyIndex++;
/*     */         } 
/*     */       } else {
/* 195 */         this.historyIndex++;
/*     */       } 
/* 197 */       e.consume();
/* 198 */     } else if (code == 40) {
/* 199 */       int caretPos = this.outputMark;
/* 200 */       if (this.history.size() > 0) {
/* 201 */         this.historyIndex++;
/* 202 */         if (this.historyIndex < 0) this.historyIndex = 0; 
/* 203 */         int len = getDocument().getLength();
/* 204 */         if (this.historyIndex < this.history.size()) {
/* 205 */           String str = this.history.get(this.historyIndex);
/* 206 */           replaceRange(str, this.outputMark, len);
/* 207 */           caretPos = this.outputMark + str.length();
/*     */         } else {
/* 209 */           this.historyIndex = this.history.size();
/* 210 */           replaceRange("", this.outputMark, len);
/*     */         } 
/*     */       } 
/* 213 */       select(caretPos, caretPos);
/* 214 */       e.consume();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void keyTyped(KeyEvent e) {
/* 219 */     int keyChar = e.getKeyChar();
/* 220 */     if (keyChar == 8) {
/* 221 */       if (this.outputMark == getCaretPosition()) {
/* 222 */         e.consume();
/*     */       }
/* 224 */     } else if (getCaretPosition() < this.outputMark) {
/* 225 */       setCaretPosition(this.outputMark);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void keyReleased(KeyEvent e) {}
/*     */   
/*     */   public synchronized void write(String str) {
/* 233 */     insert(str, this.outputMark);
/* 234 */     int len = str.length();
/* 235 */     this.outputMark += len;
/* 236 */     select(this.outputMark, this.outputMark);
/*     */   }
/*     */   
/*     */   public synchronized void insertUpdate(DocumentEvent e) {
/* 240 */     int len = e.getLength();
/* 241 */     int off = e.getOffset();
/* 242 */     if (this.outputMark > off) {
/* 243 */       this.outputMark += len;
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void removeUpdate(DocumentEvent e) {
/* 248 */     int len = e.getLength();
/* 249 */     int off = e.getOffset();
/* 250 */     if (this.outputMark > off) {
/* 251 */       if (this.outputMark >= off + len) {
/* 252 */         this.outputMark -= len;
/*     */       } else {
/* 254 */         this.outputMark = off;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void postUpdateUI() {
/* 261 */     requestFocus();
/* 262 */     setCaret(getCaret());
/* 263 */     select(this.outputMark, this.outputMark);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void changedUpdate(DocumentEvent e) {}
/*     */ 
/*     */   
/*     */   public InputStream getIn() {
/* 271 */     return this.in;
/*     */   }
/*     */   
/*     */   public PrintStream getOut() {
/* 275 */     return this.out;
/*     */   }
/*     */   
/*     */   public PrintStream getErr() {
/* 279 */     return this.err;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\ConsoleTextArea.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */