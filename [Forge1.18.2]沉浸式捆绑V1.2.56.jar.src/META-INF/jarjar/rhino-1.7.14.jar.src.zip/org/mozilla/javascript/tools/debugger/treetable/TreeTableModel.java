package org.mozilla.javascript.tools.debugger.treetable;

import javax.swing.tree.TreeModel;

public interface TreeTableModel extends TreeModel {
  int getColumnCount();
  
  String getColumnName(int paramInt);
  
  Class<?> getColumnClass(int paramInt);
  
  Object getValueAt(Object paramObject, int paramInt);
  
  boolean isCellEditable(Object paramObject, int paramInt);
  
  void setValueAt(Object paramObject1, Object paramObject2, int paramInt);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\debugger\treetable\TreeTableModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */