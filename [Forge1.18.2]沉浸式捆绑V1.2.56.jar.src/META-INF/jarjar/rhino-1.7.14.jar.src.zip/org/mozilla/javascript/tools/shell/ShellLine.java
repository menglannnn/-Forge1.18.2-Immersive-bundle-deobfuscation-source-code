/*    */ package org.mozilla.javascript.tools.shell;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.nio.charset.Charset;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ShellLine
/*    */ {
/*    */   @Deprecated
/*    */   public static InputStream getStream(Scriptable scope) {
/* 23 */     ShellConsole console = ShellConsole.getConsole(scope, 
/* 24 */         Charset.defaultCharset());
/* 25 */     return (console != null) ? console.getIn() : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\ShellLine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */