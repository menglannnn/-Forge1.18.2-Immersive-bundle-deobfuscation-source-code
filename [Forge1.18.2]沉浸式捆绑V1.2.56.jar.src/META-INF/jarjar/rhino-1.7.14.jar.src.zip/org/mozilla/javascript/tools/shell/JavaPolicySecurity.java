/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessControlException;
/*     */ import java.security.AccessController;
/*     */ import java.security.CodeSource;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.Policy;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.Enumeration;
/*     */ import org.mozilla.javascript.Callable;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.GeneratedClassLoader;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaPolicySecurity
/*     */   extends SecurityProxy
/*     */ {
/*     */   public Class<?> getStaticSecurityDomainClassInternal() {
/*  33 */     return ProtectionDomain.class;
/*     */   }
/*     */   
/*     */   private static class Loader
/*     */     extends ClassLoader
/*     */     implements GeneratedClassLoader {
/*     */     private ProtectionDomain domain;
/*     */     
/*     */     Loader(ClassLoader parent, ProtectionDomain domain) {
/*  42 */       super((parent != null) ? parent : getSystemClassLoader());
/*  43 */       this.domain = domain;
/*     */     }
/*     */     
/*     */     public Class<?> defineClass(String name, byte[] data) {
/*  47 */       return defineClass(name, data, 0, data.length, this.domain);
/*     */     }
/*     */     
/*     */     public void linkClass(Class<?> cl) {
/*  51 */       resolveClass(cl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ContextPermissions
/*     */     extends PermissionCollection
/*     */   {
/*     */     static final long serialVersionUID = -1721494496320750721L;
/*     */ 
/*     */     
/*  63 */     AccessControlContext _context = AccessController.getContext(); ContextPermissions(ProtectionDomain staticDomain) {
/*  64 */       if (staticDomain != null) {
/*  65 */         this._statisPermissions = staticDomain.getPermissions();
/*     */       }
/*  67 */       setReadOnly();
/*     */     }
/*     */     PermissionCollection _statisPermissions;
/*     */     
/*     */     public void add(Permission permission) {
/*  72 */       throw new RuntimeException("NOT IMPLEMENTED");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean implies(Permission permission) {
/*  77 */       if (this._statisPermissions != null && 
/*  78 */         !this._statisPermissions.implies(permission)) {
/*  79 */         return false;
/*     */       }
/*     */       
/*     */       try {
/*  83 */         this._context.checkPermission(permission);
/*  84 */         return true;
/*  85 */       } catch (AccessControlException ex) {
/*  86 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Enumeration<Permission> elements() {
/*  93 */       return new Enumeration<Permission>() {
/*  94 */           public boolean hasMoreElements() { return false; } public Permission nextElement() {
/*  95 */             return null;
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     public String toString() {
/* 101 */       StringBuilder sb = new StringBuilder();
/* 102 */       sb.append(getClass().getName());
/* 103 */       sb.append('@');
/* 104 */       sb.append(Integer.toHexString(System.identityHashCode(this)));
/* 105 */       sb.append(" (context=");
/* 106 */       sb.append(this._context);
/* 107 */       sb.append(", static_permitions=");
/* 108 */       sb.append(this._statisPermissions);
/* 109 */       sb.append(')');
/* 110 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaPolicySecurity() {
/* 120 */     new CodeSource(null, (Certificate[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void callProcessFileSecure(final Context cx, final Scriptable scope, final String filename) {
/* 128 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */           public Object run() {
/* 130 */             URL url = JavaPolicySecurity.this.getUrlObj(filename);
/* 131 */             ProtectionDomain staticDomain = JavaPolicySecurity.this.getUrlDomain(url);
/*     */             try {
/* 133 */               Main.processFileSecure(cx, scope, url.toExternalForm(), staticDomain);
/*     */             }
/* 135 */             catch (IOException ioex) {
/* 136 */               throw new RuntimeException(ioex);
/*     */             } 
/* 138 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private URL getUrlObj(String url) {
/*     */     URL urlObj;
/*     */     try {
/* 147 */       urlObj = new URL(url);
/* 148 */     } catch (MalformedURLException ex) {
/*     */ 
/*     */       
/* 151 */       String curDir = System.getProperty("user.dir");
/* 152 */       curDir = curDir.replace('\\', '/');
/* 153 */       if (!curDir.endsWith("/")) {
/* 154 */         curDir = curDir + '/';
/*     */       }
/*     */       try {
/* 157 */         URL curDirURL = new URL("file:" + curDir);
/* 158 */         urlObj = new URL(curDirURL, url);
/* 159 */       } catch (MalformedURLException ex2) {
/* 160 */         throw new RuntimeException("Can not construct file URL for '" + url + "':" + ex2
/*     */             
/* 162 */             .getMessage());
/*     */       } 
/*     */     } 
/* 165 */     return urlObj;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ProtectionDomain getUrlDomain(URL url) {
/* 171 */     CodeSource cs = new CodeSource(url, (Certificate[])null);
/* 172 */     PermissionCollection pc = Policy.getPolicy().getPermissions(cs);
/* 173 */     return new ProtectionDomain(cs, pc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClassLoader createClassLoader(final ClassLoader parentLoader, Object securityDomain) {
/* 180 */     final ProtectionDomain domain = (ProtectionDomain)securityDomain;
/* 181 */     return AccessController.<GeneratedClassLoader>doPrivileged((PrivilegedAction)new PrivilegedAction<Loader>() {
/*     */           public JavaPolicySecurity.Loader run() {
/* 183 */             return new JavaPolicySecurity.Loader(parentLoader, domain);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDynamicSecurityDomain(Object securityDomain) {
/* 191 */     ProtectionDomain staticDomain = (ProtectionDomain)securityDomain;
/* 192 */     return getDynamicDomain(staticDomain);
/*     */   }
/*     */   
/*     */   private ProtectionDomain getDynamicDomain(ProtectionDomain staticDomain) {
/* 196 */     ContextPermissions p = new ContextPermissions(staticDomain);
/* 197 */     ProtectionDomain contextDomain = new ProtectionDomain(null, p);
/* 198 */     return contextDomain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object callWithDomain(Object securityDomain, final Context cx, final Callable callable, final Scriptable scope, final Scriptable thisObj, final Object[] args) {
/* 209 */     ProtectionDomain staticDomain = (ProtectionDomain)securityDomain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     ProtectionDomain dynamicDomain = getDynamicDomain(staticDomain);
/* 226 */     ProtectionDomain[] tmp = { dynamicDomain };
/* 227 */     AccessControlContext restricted = new AccessControlContext(tmp);
/*     */     
/* 229 */     PrivilegedAction<Object> action = new PrivilegedAction() {
/*     */         public Object run() {
/* 231 */           return callable.call(cx, scope, thisObj, args);
/*     */         }
/*     */       };
/*     */     
/* 235 */     return AccessController.doPrivileged(action, restricted);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\JavaPolicySecurity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */