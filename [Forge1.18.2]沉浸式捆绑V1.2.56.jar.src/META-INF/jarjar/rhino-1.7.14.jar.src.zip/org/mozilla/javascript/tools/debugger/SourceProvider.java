package org.mozilla.javascript.tools.debugger;

import org.mozilla.javascript.debug.DebuggableScript;

public interface SourceProvider {
  String getSource(DebuggableScript paramDebuggableScript);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\debugger\SourceProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */