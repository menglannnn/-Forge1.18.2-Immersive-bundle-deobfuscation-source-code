/*    */ package org.mozilla.javascript.tools.debugger.treetable;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import javax.swing.CellEditor;
/*    */ import javax.swing.event.CellEditorListener;
/*    */ import javax.swing.event.ChangeEvent;
/*    */ import javax.swing.event.EventListenerList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractCellEditor
/*    */   implements CellEditor
/*    */ {
/* 43 */   protected EventListenerList listenerList = new EventListenerList();
/*    */   
/* 45 */   public Object getCellEditorValue() { return null; }
/* 46 */   public boolean isCellEditable(EventObject e) { return true; }
/* 47 */   public boolean shouldSelectCell(EventObject anEvent) { return false; } public boolean stopCellEditing() {
/* 48 */     return true;
/*    */   }
/*    */   public void cancelCellEditing() {}
/*    */   public void addCellEditorListener(CellEditorListener l) {
/* 52 */     this.listenerList.add(CellEditorListener.class, l);
/*    */   }
/*    */   
/*    */   public void removeCellEditorListener(CellEditorListener l) {
/* 56 */     this.listenerList.remove(CellEditorListener.class, l);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void fireEditingStopped() {
/* 66 */     Object[] listeners = this.listenerList.getListenerList();
/*    */ 
/*    */     
/* 69 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 70 */       if (listeners[i] == CellEditorListener.class) {
/* 71 */         ((CellEditorListener)listeners[i + 1]).editingStopped(new ChangeEvent(this));
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void fireEditingCanceled() {
/* 83 */     Object[] listeners = this.listenerList.getListenerList();
/*    */ 
/*    */     
/* 86 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 87 */       if (listeners[i] == CellEditorListener.class)
/* 88 */         ((CellEditorListener)listeners[i + 1]).editingCanceled(new ChangeEvent(this)); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\debugger\treetable\AbstractCellEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */