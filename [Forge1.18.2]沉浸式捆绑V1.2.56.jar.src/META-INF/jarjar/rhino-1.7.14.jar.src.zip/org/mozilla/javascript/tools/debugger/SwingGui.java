/*     */ package org.mozilla.javascript.tools.debugger;
/*     */ 
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.ActiveEvent;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.MenuComponent;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.TreeMap;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDesktopPane;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.mozilla.javascript.Kit;
/*     */ import org.mozilla.javascript.SecurityUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwingGui
/*     */   extends JFrame
/*     */   implements GuiCallback
/*     */ {
/*     */   private static final long serialVersionUID = -8217029773456711621L;
/*     */   Dim dim;
/*     */   private Runnable exitAction;
/*     */   private JDesktopPane desk;
/*     */   private ContextWindow context;
/*     */   private Menubar menubar;
/*     */   private JToolBar toolBar;
/*     */   private JSInternalConsole console;
/*     */   private JSplitPane split1;
/*     */   private JLabel statusBar;
/* 156 */   private final Map<String, JFrame> toplevels = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */ 
/*     */   
/* 160 */   private final Map<String, FileWindow> fileWindows = Collections.synchronizedMap(new TreeMap<>());
/*     */ 
/*     */ 
/*     */   
/*     */   private FileWindow currentWindow;
/*     */ 
/*     */ 
/*     */   
/*     */   JFileChooser dlg;
/*     */ 
/*     */   
/*     */   private EventQueue awtEventQueue;
/*     */ 
/*     */ 
/*     */   
/*     */   public SwingGui(Dim dim, String title) {
/* 176 */     super(title);
/* 177 */     this.dim = dim;
/* 178 */     init();
/* 179 */     dim.setGuiCallback(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Menubar getMenubar() {
/* 184 */     return this.menubar;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExitAction(Runnable r) {
/* 189 */     this.exitAction = r;
/*     */   }
/*     */ 
/*     */   
/*     */   public JSInternalConsole getConsole() {
/* 194 */     return this.console;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean b) {
/* 200 */     super.setVisible(b);
/* 201 */     if (b) {
/*     */       
/* 203 */       this.console.consoleTextArea.requestFocus();
/* 204 */       this.context.split.setDividerLocation(0.5D);
/*     */       try {
/* 206 */         this.console.setMaximum(true);
/* 207 */         this.console.setSelected(true);
/* 208 */         this.console.show();
/* 209 */         this.console.consoleTextArea.requestFocus();
/* 210 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void addTopLevel(String key, JFrame frame) {
/* 217 */     if (frame != this) {
/* 218 */       this.toplevels.put(key, frame);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/* 224 */     this.menubar = new Menubar(this);
/* 225 */     setJMenuBar(this.menubar);
/* 226 */     this.toolBar = new JToolBar();
/*     */ 
/*     */     
/* 229 */     String[] toolTips = { "Break (Pause)", "Go (F5)", "Step Into (F11)", "Step Over (F7)", "Step Out (F8)" };
/*     */ 
/*     */     
/* 232 */     int count = 0;
/* 233 */     JButton breakButton = new JButton("Break"), button = breakButton;
/* 234 */     button.setToolTipText("Break");
/* 235 */     button.setActionCommand("Break");
/* 236 */     button.addActionListener(this.menubar);
/* 237 */     button.setEnabled(true);
/* 238 */     button.setToolTipText(toolTips[count++]);
/*     */     
/* 240 */     JButton goButton = new JButton("Go");
/* 241 */     button.setToolTipText("Go");
/* 242 */     button.setActionCommand("Go");
/* 243 */     button.addActionListener(this.menubar);
/* 244 */     button.setEnabled(false);
/* 245 */     button.setToolTipText(toolTips[count++]);
/*     */     
/* 247 */     JButton stepIntoButton = new JButton("Step Into");
/* 248 */     button.setToolTipText("Step Into");
/* 249 */     button.setActionCommand("Step Into");
/* 250 */     button.addActionListener(this.menubar);
/* 251 */     button.setEnabled(false);
/* 252 */     button.setToolTipText(toolTips[count++]);
/*     */     
/* 254 */     JButton stepOverButton = new JButton("Step Over");
/* 255 */     button.setToolTipText("Step Over");
/* 256 */     button.setActionCommand("Step Over");
/* 257 */     button.setEnabled(false);
/* 258 */     button.addActionListener(this.menubar);
/* 259 */     button.setToolTipText(toolTips[count++]);
/*     */     
/* 261 */     JButton stepOutButton = new JButton("Step Out");
/* 262 */     button.setToolTipText("Step Out");
/* 263 */     button.setActionCommand("Step Out");
/* 264 */     button.setEnabled(false);
/* 265 */     button.addActionListener(this.menubar);
/* 266 */     button.setToolTipText(toolTips[count++]);
/*     */     
/* 268 */     Dimension dim = stepOverButton.getPreferredSize();
/* 269 */     breakButton.setPreferredSize(dim);
/* 270 */     breakButton.setMinimumSize(dim);
/* 271 */     breakButton.setMaximumSize(dim);
/* 272 */     breakButton.setSize(dim);
/* 273 */     goButton.setPreferredSize(dim);
/* 274 */     goButton.setMinimumSize(dim);
/* 275 */     goButton.setMaximumSize(dim);
/* 276 */     stepIntoButton.setPreferredSize(dim);
/* 277 */     stepIntoButton.setMinimumSize(dim);
/* 278 */     stepIntoButton.setMaximumSize(dim);
/* 279 */     stepOverButton.setPreferredSize(dim);
/* 280 */     stepOverButton.setMinimumSize(dim);
/* 281 */     stepOverButton.setMaximumSize(dim);
/* 282 */     stepOutButton.setPreferredSize(dim);
/* 283 */     stepOutButton.setMinimumSize(dim);
/* 284 */     stepOutButton.setMaximumSize(dim);
/* 285 */     this.toolBar.add(breakButton);
/* 286 */     this.toolBar.add(goButton);
/* 287 */     this.toolBar.add(stepIntoButton);
/* 288 */     this.toolBar.add(stepOverButton);
/* 289 */     this.toolBar.add(stepOutButton);
/*     */     
/* 291 */     JPanel contentPane = new JPanel();
/* 292 */     contentPane.setLayout(new BorderLayout());
/* 293 */     getContentPane().add(this.toolBar, "North");
/* 294 */     getContentPane().add(contentPane, "Center");
/* 295 */     this.desk = new JDesktopPane();
/* 296 */     this.desk.setPreferredSize(new Dimension(600, 300));
/* 297 */     this.desk.setMinimumSize(new Dimension(150, 50));
/* 298 */     this.desk.add(this.console = new JSInternalConsole("JavaScript Console"));
/* 299 */     this.context = new ContextWindow(this);
/* 300 */     this.context.setPreferredSize(new Dimension(600, 120));
/* 301 */     this.context.setMinimumSize(new Dimension(50, 50));
/*     */     
/* 303 */     this.split1 = new JSplitPane(0, this.desk, this.context);
/* 304 */     this.split1.setOneTouchExpandable(true);
/* 305 */     setResizeWeight(this.split1, 0.66D);
/* 306 */     contentPane.add(this.split1, "Center");
/* 307 */     this.statusBar = new JLabel();
/* 308 */     this.statusBar.setText("Thread: ");
/* 309 */     contentPane.add(this.statusBar, "South");
/* 310 */     this.dlg = new JFileChooser();
/*     */     
/* 312 */     FileFilter filter = new FileFilter()
/*     */       {
/*     */         public boolean accept(File f)
/*     */         {
/* 316 */           if (f.isDirectory()) {
/* 317 */             return true;
/*     */           }
/* 319 */           String n = f.getName();
/* 320 */           int i = n.lastIndexOf('.');
/* 321 */           if (i > 0 && i < n.length() - 1) {
/* 322 */             String ext = n.substring(i + 1).toLowerCase();
/* 323 */             if (ext.equals("js")) {
/* 324 */               return true;
/*     */             }
/*     */           } 
/* 327 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getDescription() {
/* 332 */           return "JavaScript Files (*.js)";
/*     */         }
/*     */       };
/* 335 */     this.dlg.addChoosableFileFilter(filter);
/* 336 */     addWindowListener(new WindowAdapter()
/*     */         {
/*     */           public void windowClosing(WindowEvent e)
/*     */           {
/* 340 */             SwingGui.this.exit();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void exit() {
/* 347 */     if (this.exitAction != null) {
/* 348 */       SwingUtilities.invokeLater(this.exitAction);
/*     */     }
/* 350 */     this.dim.setReturnValue(5);
/*     */   }
/*     */ 
/*     */   
/*     */   FileWindow getFileWindow(String url) {
/* 355 */     if (url == null || url.equals("<stdin>")) {
/* 356 */       return null;
/*     */     }
/* 358 */     return this.fileWindows.get(url);
/*     */   }
/*     */ 
/*     */   
/*     */   static String getShortName(String url) {
/* 363 */     int lastSlash = url.lastIndexOf('/');
/* 364 */     if (lastSlash < 0) {
/* 365 */       lastSlash = url.lastIndexOf('\\');
/*     */     }
/* 367 */     String shortName = url;
/* 368 */     if (lastSlash >= 0 && lastSlash + 1 < url.length()) {
/* 369 */       shortName = url.substring(lastSlash + 1);
/*     */     }
/* 371 */     return shortName;
/*     */   }
/*     */ 
/*     */   
/*     */   void removeWindow(FileWindow w) {
/* 376 */     this.fileWindows.remove(w.getUrl());
/* 377 */     JMenu windowMenu = getWindowMenu();
/* 378 */     int count = windowMenu.getItemCount();
/* 379 */     JMenuItem lastItem = windowMenu.getItem(count - 1);
/* 380 */     String name = getShortName(w.getUrl());
/* 381 */     for (int i = 5; i < count; i++) {
/* 382 */       JMenuItem item = windowMenu.getItem(i);
/* 383 */       if (item != null) {
/* 384 */         String text = item.getText();
/*     */ 
/*     */         
/* 387 */         int pos = text.indexOf(' ');
/* 388 */         if (text.substring(pos + 1).equals(name)) {
/* 389 */           windowMenu.remove(item);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 395 */           if (count == 6) {
/*     */             
/* 397 */             windowMenu.remove(4); break;
/*     */           } 
/* 399 */           int j = i - 4;
/* 400 */           for (; i < count - 1; i++) {
/* 401 */             JMenuItem thisItem = windowMenu.getItem(i);
/* 402 */             if (thisItem != null) {
/*     */ 
/*     */               
/* 405 */               text = thisItem.getText();
/* 406 */               if (text.equals("More Windows...")) {
/*     */                 break;
/*     */               }
/* 409 */               pos = text.indexOf(' ');
/* 410 */               thisItem.setText((char)(48 + j) + " " + text.substring(pos + 1));
/* 411 */               thisItem.setMnemonic(48 + j);
/* 412 */               j++;
/*     */             } 
/*     */           } 
/* 415 */           if (count - 6 == 0 && lastItem != item && 
/* 416 */             lastItem.getText().equals("More Windows...")) {
/* 417 */             windowMenu.remove(lastItem);
/*     */           }
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 424 */     windowMenu.revalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   void showStopLine(Dim.StackFrame frame) {
/* 429 */     String sourceName = frame.getUrl();
/* 430 */     if (sourceName == null || sourceName.equals("<stdin>")) {
/* 431 */       if (this.console.isVisible()) {
/* 432 */         this.console.show();
/*     */       }
/*     */     } else {
/* 435 */       showFileWindow(sourceName, -1);
/* 436 */       int lineNumber = frame.getLineNumber();
/* 437 */       FileWindow w = getFileWindow(sourceName);
/* 438 */       if (w != null) {
/* 439 */         setFilePosition(w, lineNumber);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void showFileWindow(String sourceUrl, int lineNumber) {
/*     */     FileWindow w;
/* 454 */     if (sourceUrl != null) {
/* 455 */       w = getFileWindow(sourceUrl);
/*     */     } else {
/* 457 */       JInternalFrame f = getSelectedFrame();
/* 458 */       if (f != null && f instanceof FileWindow) {
/* 459 */         w = (FileWindow)f;
/*     */       } else {
/* 461 */         w = this.currentWindow;
/*     */       } 
/*     */     } 
/* 464 */     if (w == null && sourceUrl != null) {
/* 465 */       Dim.SourceInfo si = this.dim.sourceInfo(sourceUrl);
/* 466 */       createFileWindow(si, -1);
/* 467 */       w = getFileWindow(sourceUrl);
/*     */     } 
/* 469 */     if (w == null) {
/*     */       return;
/*     */     }
/* 472 */     if (lineNumber > -1) {
/* 473 */       int start = w.getPosition(lineNumber - 1);
/* 474 */       int end = w.getPosition(lineNumber) - 1;
/* 475 */       if (start <= 0) {
/*     */         return;
/*     */       }
/* 478 */       w.textArea.select(start);
/* 479 */       w.textArea.setCaretPosition(start);
/* 480 */       w.textArea.moveCaretPosition(end);
/*     */     } 
/*     */     try {
/* 483 */       if (w.isIcon()) {
/* 484 */         w.setIcon(false);
/*     */       }
/* 486 */       w.setVisible(true);
/* 487 */       w.moveToFront();
/* 488 */       w.setSelected(true);
/* 489 */       requestFocus();
/* 490 */       w.requestFocus();
/* 491 */       w.textArea.requestFocus();
/* 492 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createFileWindow(Dim.SourceInfo sourceInfo, int line) {
/* 498 */     boolean activate = true;
/*     */     
/* 500 */     String url = sourceInfo.url();
/* 501 */     FileWindow w = new FileWindow(this, sourceInfo);
/* 502 */     this.fileWindows.put(url, w);
/* 503 */     if (line != -1) {
/* 504 */       if (this.currentWindow != null) {
/* 505 */         this.currentWindow.setPosition(-1);
/*     */       }
/*     */       try {
/* 508 */         w.setPosition(w.textArea.getLineStartOffset(line - 1));
/* 509 */       } catch (BadLocationException exc) {
/*     */         try {
/* 511 */           w.setPosition(w.textArea.getLineStartOffset(0));
/* 512 */         } catch (BadLocationException ee) {
/* 513 */           w.setPosition(-1);
/*     */         } 
/*     */       } 
/*     */     } 
/* 517 */     this.desk.add(w);
/* 518 */     if (line != -1) {
/* 519 */       this.currentWindow = w;
/*     */     }
/* 521 */     this.menubar.addFile(url);
/* 522 */     w.setVisible(true);
/*     */     
/* 524 */     if (activate) {
/*     */       try {
/* 526 */         w.setMaximum(true);
/* 527 */         w.setSelected(true);
/* 528 */         w.moveToFront();
/* 529 */       } catch (Exception exception) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean updateFileWindow(Dim.SourceInfo sourceInfo) {
/* 544 */     String fileName = sourceInfo.url();
/* 545 */     FileWindow w = getFileWindow(fileName);
/* 546 */     if (w != null) {
/* 547 */       w.updateText(sourceInfo);
/* 548 */       w.show();
/* 549 */       return true;
/*     */     } 
/* 551 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setFilePosition(FileWindow w, int line) {
/* 556 */     boolean activate = true;
/* 557 */     JTextArea ta = w.textArea;
/*     */     try {
/* 559 */       if (line == -1) {
/* 560 */         w.setPosition(-1);
/* 561 */         if (this.currentWindow == w) {
/* 562 */           this.currentWindow = null;
/*     */         }
/*     */       } else {
/* 565 */         int loc = ta.getLineStartOffset(line - 1);
/* 566 */         if (this.currentWindow != null && this.currentWindow != w) {
/* 567 */           this.currentWindow.setPosition(-1);
/*     */         }
/* 569 */         w.setPosition(loc);
/* 570 */         this.currentWindow = w;
/*     */       } 
/* 572 */     } catch (BadLocationException badLocationException) {}
/*     */ 
/*     */     
/* 575 */     if (activate) {
/* 576 */       if (w.isIcon()) {
/* 577 */         this.desk.getDesktopManager().deiconifyFrame(w);
/*     */       }
/* 579 */       this.desk.getDesktopManager().activateFrame(w);
/*     */       try {
/* 581 */         w.show();
/* 582 */         w.toFront();
/* 583 */         w.setSelected(true);
/* 584 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void enterInterruptImpl(Dim.StackFrame lastFrame, String threadTitle, String alertMessage) {
/* 591 */     this.statusBar.setText("Thread: " + threadTitle);
/*     */     
/* 593 */     showStopLine(lastFrame);
/*     */     
/* 595 */     if (alertMessage != null) {
/* 596 */       MessageDialogWrapper.showMessageDialog(this, alertMessage, "Exception in Script", 0);
/*     */     }
/*     */ 
/*     */     
/* 600 */     updateEnabled(true);
/*     */     
/* 602 */     Dim.ContextData contextData = lastFrame.contextData();
/*     */     
/* 604 */     JComboBox<String> ctx = this.context.context;
/* 605 */     List<String> toolTips = this.context.toolTips;
/* 606 */     this.context.disableUpdate();
/* 607 */     int frameCount = contextData.frameCount();
/* 608 */     ctx.removeAllItems();
/*     */ 
/*     */     
/* 611 */     ctx.setSelectedItem((Object)null);
/* 612 */     toolTips.clear();
/* 613 */     for (int i = 0; i < frameCount; i++) {
/* 614 */       Dim.StackFrame frame = contextData.getFrame(i);
/* 615 */       String url = frame.getUrl();
/* 616 */       int lineNumber = frame.getLineNumber();
/* 617 */       String shortName = url;
/* 618 */       if (url.length() > 20) {
/* 619 */         shortName = "..." + url.substring(url.length() - 17);
/*     */       }
/* 621 */       String location = "\"" + shortName + "\", line " + lineNumber;
/* 622 */       ctx.insertItemAt(location, i);
/* 623 */       location = "\"" + url + "\", line " + lineNumber;
/* 624 */       toolTips.add(location);
/*     */     } 
/* 626 */     this.context.enableUpdate();
/* 627 */     ctx.setSelectedIndex(0);
/* 628 */     ctx.setMinimumSize(new Dimension(50, (ctx.getMinimumSize()).height));
/*     */   }
/*     */ 
/*     */   
/*     */   private JMenu getWindowMenu() {
/* 633 */     return this.menubar.getMenu(3);
/*     */   }
/*     */ 
/*     */   
/*     */   private String chooseFile(String title) {
/* 638 */     this.dlg.setDialogTitle(title);
/* 639 */     File CWD = null;
/* 640 */     String dir = SecurityUtilities.getSystemProperty("user.dir");
/* 641 */     if (dir != null) {
/* 642 */       CWD = new File(dir);
/*     */     }
/* 644 */     if (CWD != null) {
/* 645 */       this.dlg.setCurrentDirectory(CWD);
/*     */     }
/* 647 */     int returnVal = this.dlg.showOpenDialog(this);
/* 648 */     if (returnVal == 0) {
/*     */       
/* 650 */       try { String result = this.dlg.getSelectedFile().getCanonicalPath();
/* 651 */         CWD = this.dlg.getSelectedFile().getParentFile();
/* 652 */         Properties props = System.getProperties();
/* 653 */         props.put("user.dir", CWD.getPath());
/* 654 */         System.setProperties(props);
/* 655 */         return result; }
/* 656 */       catch (IOException iOException) {  }
/* 657 */       catch (SecurityException securityException) {}
/*     */     }
/*     */     
/* 660 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private JInternalFrame getSelectedFrame() {
/* 665 */     JInternalFrame[] frames = this.desk.getAllFrames();
/* 666 */     for (int i = 0; i < frames.length; i++) {
/* 667 */       if (frames[i].isShowing()) {
/* 668 */         return frames[i];
/*     */       }
/*     */     } 
/* 671 */     return frames[frames.length - 1];
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateEnabled(boolean interrupted) {
/* 676 */     ((Menubar)getJMenuBar()).updateEnabled(interrupted);
/* 677 */     for (int ci = 0, cc = this.toolBar.getComponentCount(); ci < cc; ci++) {
/*     */       boolean enableButton;
/* 679 */       if (ci == 0) {
/*     */         
/* 681 */         enableButton = !interrupted;
/*     */       } else {
/* 683 */         enableButton = interrupted;
/*     */       } 
/* 685 */       this.toolBar.getComponent(ci).setEnabled(enableButton);
/*     */     } 
/* 687 */     if (interrupted) {
/* 688 */       this.toolBar.setEnabled(true);
/*     */       
/* 690 */       int state = getExtendedState();
/* 691 */       if (state == 1) {
/* 692 */         setExtendedState(0);
/*     */       }
/* 694 */       toFront();
/* 695 */       this.context.setEnabled(true);
/*     */     } else {
/* 697 */       if (this.currentWindow != null) this.currentWindow.setPosition(-1); 
/* 698 */       this.context.setEnabled(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setResizeWeight(JSplitPane pane, double weight) {
/*     */     
/* 708 */     try { Method m = JSplitPane.class.getMethod("setResizeWeight", new Class[] { double.class });
/* 709 */       m.invoke(pane, new Object[] { Double.valueOf(weight) }); }
/* 710 */     catch (NoSuchMethodException noSuchMethodException) {  }
/* 711 */     catch (IllegalAccessException illegalAccessException) {  }
/* 712 */     catch (InvocationTargetException invocationTargetException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String readFile(String fileName) {
/*     */     String text;
/* 720 */     try (Reader r = new FileReader(fileName)) {
/* 721 */       text = Kit.readReader(r);
/*     */     }
/* 723 */     catch (IOException ex) {
/* 724 */       MessageDialogWrapper.showMessageDialog(this, ex
/* 725 */           .getMessage(), "Error reading " + fileName, 0);
/* 726 */       text = null;
/*     */     } 
/* 728 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateSourceText(Dim.SourceInfo sourceInfo) {
/* 736 */     RunProxy proxy = new RunProxy(this, 3);
/* 737 */     proxy.sourceInfo = sourceInfo;
/* 738 */     SwingUtilities.invokeLater(proxy);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterInterrupt(Dim.StackFrame lastFrame, String threadTitle, String alertMessage) {
/* 744 */     if (SwingUtilities.isEventDispatchThread()) {
/* 745 */       enterInterruptImpl(lastFrame, threadTitle, alertMessage);
/*     */     } else {
/* 747 */       RunProxy proxy = new RunProxy(this, 4);
/* 748 */       proxy.lastFrame = lastFrame;
/* 749 */       proxy.threadTitle = threadTitle;
/* 750 */       proxy.alertMessage = alertMessage;
/* 751 */       SwingUtilities.invokeLater(proxy);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGuiEventThread() {
/* 758 */     return SwingUtilities.isEventDispatchThread();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatchNextGuiEvent() throws InterruptedException {
/* 764 */     EventQueue queue = this.awtEventQueue;
/* 765 */     if (queue == null) {
/* 766 */       queue = Toolkit.getDefaultToolkit().getSystemEventQueue();
/* 767 */       this.awtEventQueue = queue;
/*     */     } 
/* 769 */     AWTEvent event = queue.getNextEvent();
/* 770 */     if (event instanceof ActiveEvent) {
/* 771 */       ((ActiveEvent)event).dispatch();
/*     */     } else {
/* 773 */       Object source = event.getSource();
/* 774 */       if (source instanceof Component) {
/* 775 */         Component comp = (Component)source;
/* 776 */         comp.dispatchEvent(event);
/* 777 */       } else if (source instanceof MenuComponent) {
/* 778 */         ((MenuComponent)source).dispatchEvent(event);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 787 */     String cmd = e.getActionCommand();
/* 788 */     int returnValue = -1;
/* 789 */     if (cmd.equals("Cut") || cmd.equals("Copy") || cmd.equals("Paste")) {
/* 790 */       JInternalFrame f = getSelectedFrame();
/* 791 */       if (f != null && f instanceof ActionListener) {
/* 792 */         ((ActionListener)f).actionPerformed(e);
/*     */       }
/* 794 */     } else if (cmd.equals("Step Over")) {
/* 795 */       returnValue = 0;
/* 796 */     } else if (cmd.equals("Step Into")) {
/* 797 */       returnValue = 1;
/* 798 */     } else if (cmd.equals("Step Out")) {
/* 799 */       returnValue = 2;
/* 800 */     } else if (cmd.equals("Go")) {
/* 801 */       returnValue = 3;
/* 802 */     } else if (cmd.equals("Break")) {
/* 803 */       this.dim.setBreak();
/* 804 */     } else if (cmd.equals("Exit")) {
/* 805 */       exit();
/* 806 */     } else if (cmd.equals("Open")) {
/* 807 */       String fileName = chooseFile("Select a file to compile");
/* 808 */       if (fileName != null) {
/* 809 */         String text = readFile(fileName);
/* 810 */         if (text != null) {
/* 811 */           RunProxy proxy = new RunProxy(this, 1);
/* 812 */           proxy.fileName = fileName;
/* 813 */           proxy.text = text;
/* 814 */           (new Thread(proxy)).start();
/*     */         } 
/*     */       } 
/* 817 */     } else if (cmd.equals("Load")) {
/* 818 */       String fileName = chooseFile("Select a file to execute");
/* 819 */       if (fileName != null) {
/* 820 */         String text = readFile(fileName);
/* 821 */         if (text != null) {
/* 822 */           RunProxy proxy = new RunProxy(this, 2);
/* 823 */           proxy.fileName = fileName;
/* 824 */           proxy.text = text;
/* 825 */           (new Thread(proxy)).start();
/*     */         } 
/*     */       } 
/* 828 */     } else if (cmd.equals("More Windows...")) {
/* 829 */       MoreWindows dlg = new MoreWindows(this, this.fileWindows, "Window", "Files");
/* 830 */       dlg.showDialog(this);
/* 831 */     } else if (cmd.equals("Console")) {
/* 832 */       if (this.console.isIcon()) {
/* 833 */         this.desk.getDesktopManager().deiconifyFrame(this.console);
/*     */       }
/* 835 */       this.console.show();
/* 836 */       this.desk.getDesktopManager().activateFrame(this.console);
/* 837 */       this.console.consoleTextArea.requestFocus();
/* 838 */     } else if (!cmd.equals("Cut") && 
/* 839 */       !cmd.equals("Copy") && 
/* 840 */       !cmd.equals("Paste")) {
/* 841 */       if (cmd.equals("Go to function...")) {
/* 842 */         FindFunction dlg = new FindFunction(this, "Go to function", "Function");
/* 843 */         dlg.showDialog(this);
/* 844 */       } else if (cmd.equals("Go to line...")) {
/*     */ 
/*     */         
/* 847 */         String s = (String)JOptionPane.showInputDialog(this, "Line number", "Go to line...", 3, null, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 855 */         if (s == null || s.trim().length() == 0) {
/*     */           return;
/*     */         }
/*     */         try {
/* 859 */           int line = Integer.parseInt(s);
/* 860 */           showFileWindow((String)null, line);
/* 861 */         } catch (NumberFormatException numberFormatException) {}
/*     */       
/*     */       }
/* 864 */       else if (cmd.equals("Tile")) {
/* 865 */         JInternalFrame[] frames = this.desk.getAllFrames();
/* 866 */         int count = frames.length;
/*     */         
/* 868 */         int cols = (int)Math.sqrt(count), rows = cols;
/* 869 */         if (rows * cols < count) {
/* 870 */           cols++;
/* 871 */           if (rows * cols < count) {
/* 872 */             rows++;
/*     */           }
/*     */         } 
/* 875 */         Dimension size = this.desk.getSize();
/* 876 */         int w = size.width / cols;
/* 877 */         int h = size.height / rows;
/* 878 */         int x = 0;
/* 879 */         int y = 0;
/* 880 */         for (int i = 0; i < rows; i++) {
/* 881 */           for (int j = 0; j < cols; j++) {
/* 882 */             int index = i * cols + j;
/* 883 */             if (index >= frames.length) {
/*     */               break;
/*     */             }
/* 886 */             JInternalFrame f = frames[index];
/*     */             try {
/* 888 */               f.setIcon(false);
/* 889 */               f.setMaximum(false);
/* 890 */             } catch (Exception exception) {}
/*     */             
/* 892 */             this.desk.getDesktopManager().setBoundsForFrame(f, x, y, w, h);
/* 893 */             x += w;
/*     */           } 
/* 895 */           y += h;
/* 896 */           x = 0;
/*     */         } 
/* 898 */       } else if (cmd.equals("Cascade")) {
/* 899 */         JInternalFrame[] frames = this.desk.getAllFrames();
/* 900 */         int count = frames.length;
/*     */         
/* 902 */         int y = 0, x = y;
/* 903 */         int h = this.desk.getHeight();
/* 904 */         int d = h / count;
/* 905 */         if (d > 30) d = 30; 
/* 906 */         for (int i = count - 1; i >= 0; i--, x += d, y += d) {
/* 907 */           JInternalFrame f = frames[i];
/*     */           try {
/* 909 */             f.setIcon(false);
/* 910 */             f.setMaximum(false);
/* 911 */           } catch (Exception exception) {}
/*     */           
/* 913 */           Dimension dimen = f.getPreferredSize();
/* 914 */           int w = dimen.width;
/* 915 */           h = dimen.height;
/* 916 */           this.desk.getDesktopManager().setBoundsForFrame(f, x, y, w, h);
/*     */         } 
/*     */       } else {
/* 919 */         Object obj = getFileWindow(cmd);
/* 920 */         if (obj != null) {
/* 921 */           FileWindow w = (FileWindow)obj;
/*     */           try {
/* 923 */             if (w.isIcon()) {
/* 924 */               w.setIcon(false);
/*     */             }
/* 926 */             w.setVisible(true);
/* 927 */             w.moveToFront();
/* 928 */             w.setSelected(true);
/* 929 */           } catch (Exception exception) {}
/*     */         } 
/*     */       } 
/*     */     } 
/* 933 */     if (returnValue != -1) {
/* 934 */       updateEnabled(false);
/* 935 */       this.dim.setReturnValue(returnValue);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\debugger\SwingGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */