/*     */ package org.mozilla.javascript.tools.debugger;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JFrame;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ContextFactory;
/*     */ import org.mozilla.javascript.Kit;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.tools.shell.Global;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */ {
/*     */   private Dim dim;
/*     */   private SwingGui debugGui;
/*     */   
/*     */   public Main(String title) {
/*  40 */     this.dim = new Dim();
/*  41 */     this.debugGui = new SwingGui(this.dim, title);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JFrame getDebugFrame() {
/*  48 */     return this.debugGui;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doBreak() {
/*  55 */     this.dim.setBreak();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBreakOnExceptions(boolean value) {
/*  62 */     this.dim.setBreakOnExceptions(value);
/*  63 */     this.debugGui.getMenubar().getBreakOnExceptions().setSelected(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBreakOnEnter(boolean value) {
/*  70 */     this.dim.setBreakOnEnter(value);
/*  71 */     this.debugGui.getMenubar().getBreakOnEnter().setSelected(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBreakOnReturn(boolean value) {
/*  78 */     this.dim.setBreakOnReturn(value);
/*  79 */     this.debugGui.getMenubar().getBreakOnReturn().setSelected(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearAllBreakpoints() {
/*  86 */     this.dim.clearAllBreakpoints();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void go() {
/*  93 */     this.dim.go();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(Scriptable scope) {
/* 100 */     setScopeProvider(IProxy.newScopeProvider(scope));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScopeProvider(ScopeProvider p) {
/* 108 */     this.dim.setScopeProvider(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceProvider(SourceProvider sourceProvider) {
/* 116 */     this.dim.setSourceProvider(sourceProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExitAction(Runnable r) {
/* 124 */     this.debugGui.setExitAction(r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getIn() {
/* 132 */     return this.debugGui.getConsole().getIn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintStream getOut() {
/* 140 */     return this.debugGui.getConsole().getOut();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintStream getErr() {
/* 148 */     return this.debugGui.getConsole().getErr();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pack() {
/* 155 */     this.debugGui.pack();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(int w, int h) {
/* 162 */     this.debugGui.setSize(w, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean flag) {
/* 169 */     this.debugGui.setVisible(flag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 176 */     return this.debugGui.isVisible();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 183 */     clearAllBreakpoints();
/* 184 */     this.dim.go();
/* 185 */     this.debugGui.dispose();
/* 186 */     this.dim = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void attachTo(ContextFactory factory) {
/* 193 */     this.dim.attachTo(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void detach() {
/* 200 */     this.dim.detach();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 208 */     Main main = new Main("Rhino JavaScript Debugger");
/* 209 */     main.doBreak();
/* 210 */     main.setExitAction(new IProxy(1));
/*     */     
/* 212 */     System.setIn(main.getIn());
/* 213 */     System.setOut(main.getOut());
/* 214 */     System.setErr(main.getErr());
/*     */     
/* 216 */     Global global = org.mozilla.javascript.tools.shell.Main.getGlobal();
/* 217 */     global.setIn(main.getIn());
/* 218 */     global.setOut(main.getOut());
/* 219 */     global.setErr(main.getErr());
/*     */     
/* 221 */     main.attachTo((ContextFactory)org.mozilla.javascript.tools.shell.Main.shellContextFactory);
/*     */ 
/*     */     
/* 224 */     main.setScope((Scriptable)global);
/*     */     
/* 226 */     main.pack();
/* 227 */     main.setSize(600, 460);
/* 228 */     main.setVisible(true);
/*     */     
/* 230 */     org.mozilla.javascript.tools.shell.Main.exec(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Main mainEmbedded(String title) {
/* 240 */     ContextFactory factory = ContextFactory.getGlobal();
/* 241 */     Global global = new Global();
/* 242 */     global.init(factory);
/* 243 */     return mainEmbedded(factory, (Scriptable)global, title);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Main mainEmbedded(ContextFactory factory, Scriptable scope, String title) {
/* 254 */     return mainEmbeddedImpl(factory, scope, title);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Main mainEmbedded(ContextFactory factory, ScopeProvider scopeProvider, String title) {
/* 265 */     return mainEmbeddedImpl(factory, scopeProvider, title);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Main mainEmbeddedImpl(ContextFactory factory, Object scopeProvider, String title) {
/* 274 */     if (title == null) {
/* 275 */       title = "Rhino JavaScript Debugger (embedded usage)";
/*     */     }
/* 277 */     Main main = new Main(title);
/* 278 */     main.doBreak();
/* 279 */     main.setExitAction(new IProxy(1));
/*     */     
/* 281 */     main.attachTo(factory);
/* 282 */     if (scopeProvider instanceof ScopeProvider) {
/* 283 */       main.setScopeProvider((ScopeProvider)scopeProvider);
/*     */     } else {
/* 285 */       Scriptable scope = (Scriptable)scopeProvider;
/* 286 */       if (scope instanceof Global) {
/* 287 */         Global global = (Global)scope;
/* 288 */         global.setIn(main.getIn());
/* 289 */         global.setOut(main.getOut());
/* 290 */         global.setErr(main.getErr());
/*     */       } 
/* 292 */       main.setScope(scope);
/*     */     } 
/*     */     
/* 295 */     main.pack();
/* 296 */     main.setSize(600, 460);
/* 297 */     main.setVisible(true);
/* 298 */     return main;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setSize(Dimension dimension) {
/* 308 */     this.debugGui.setSize(dimension.width, dimension.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setOptimizationLevel(int level) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void contextEntered(Context cx) {
/* 325 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void contextExited(Context cx) {
/* 334 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void contextCreated(Context cx) {
/* 343 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void contextReleased(Context cx) {
/* 353 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class IProxy
/*     */     implements Runnable, ScopeProvider
/*     */   {
/*     */     public static final int EXIT_ACTION = 1;
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int SCOPE_PROVIDER = 2;
/*     */ 
/*     */ 
/*     */     
/*     */     private final int type;
/*     */ 
/*     */ 
/*     */     
/*     */     private Scriptable scope;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IProxy(int type) {
/* 381 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ScopeProvider newScopeProvider(Scriptable scope) {
/* 388 */       IProxy scopeProvider = new IProxy(2);
/* 389 */       scopeProvider.scope = scope;
/* 390 */       return scopeProvider;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 399 */       if (this.type != 1) Kit.codeBug(); 
/* 400 */       System.exit(0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Scriptable getScope() {
/* 409 */       if (this.type != 2) Kit.codeBug(); 
/* 410 */       if (this.scope == null) Kit.codeBug(); 
/* 411 */       return this.scope;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\debugger\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */