/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ContextFactory;
/*     */ import org.mozilla.javascript.ErrorReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShellContextFactory
/*     */   extends ContextFactory
/*     */ {
/*     */   private boolean strictMode;
/*     */   private boolean warningAsError;
/*  17 */   private int languageVersion = 180;
/*     */   
/*     */   private int optimizationLevel;
/*     */   
/*     */   private boolean generatingDebug;
/*     */   private boolean allowReservedKeywords = true;
/*     */   private ErrorReporter errorReporter;
/*     */   private String characterEncoding;
/*     */   
/*     */   protected boolean hasFeature(Context cx, int featureIndex) {
/*  27 */     switch (featureIndex) {
/*     */       case 8:
/*     */       case 9:
/*     */       case 11:
/*  31 */         return this.strictMode;
/*     */       
/*     */       case 3:
/*  34 */         return this.allowReservedKeywords;
/*     */       
/*     */       case 12:
/*  37 */         return this.warningAsError;
/*     */       
/*     */       case 10:
/*  40 */         return this.generatingDebug;
/*     */     } 
/*  42 */     return super.hasFeature(cx, featureIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onContextCreated(Context cx) {
/*  48 */     cx.setLanguageVersion(this.languageVersion);
/*  49 */     cx.setOptimizationLevel(this.optimizationLevel);
/*  50 */     if (this.errorReporter != null) {
/*  51 */       cx.setErrorReporter(this.errorReporter);
/*     */     }
/*  53 */     cx.setGeneratingDebug(this.generatingDebug);
/*  54 */     super.onContextCreated(cx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStrictMode(boolean flag) {
/*  59 */     checkNotSealed();
/*  60 */     this.strictMode = flag;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWarningAsError(boolean flag) {
/*  65 */     checkNotSealed();
/*  66 */     this.warningAsError = flag;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLanguageVersion(int version) {
/*  71 */     Context.checkLanguageVersion(version);
/*  72 */     checkNotSealed();
/*  73 */     this.languageVersion = version;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOptimizationLevel(int optimizationLevel) {
/*  78 */     Context.checkOptimizationLevel(optimizationLevel);
/*  79 */     checkNotSealed();
/*  80 */     this.optimizationLevel = optimizationLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setErrorReporter(ErrorReporter errorReporter) {
/*  85 */     if (errorReporter == null) throw new IllegalArgumentException(); 
/*  86 */     this.errorReporter = errorReporter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGeneratingDebug(boolean generatingDebug) {
/*  91 */     this.generatingDebug = generatingDebug;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCharacterEncoding() {
/*  96 */     return this.characterEncoding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharacterEncoding(String characterEncoding) {
/* 101 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */   public void setAllowReservedKeywords(boolean allowReservedKeywords) {
/* 105 */     this.allowReservedKeywords = allowReservedKeywords;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\ShellContextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */