/*     */ package org.mozilla.javascript.tools.jsc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.mozilla.javascript.CompilerEnvirons;
/*     */ import org.mozilla.javascript.ErrorReporter;
/*     */ import org.mozilla.javascript.optimizer.ClassCompiler;
/*     */ import org.mozilla.javascript.tools.SourceReader;
/*     */ import org.mozilla.javascript.tools.ToolErrorReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */ {
/*     */   private boolean printHelp;
/*     */   private ToolErrorReporter reporter;
/*     */   private CompilerEnvirons compilerEnv;
/*     */   private ClassCompiler compiler;
/*     */   private String targetName;
/*     */   private String targetPackage;
/*     */   private String destinationDir;
/*     */   private String characterEncoding;
/*     */   
/*     */   public static void main(String[] args) {
/*  34 */     Main main = new Main();
/*  35 */     args = main.processOptions(args);
/*  36 */     if (args == null) {
/*  37 */       if (main.printHelp) {
/*  38 */         System.out.println(ToolErrorReporter.getMessage("msg.jsc.usage", Main.class
/*  39 */               .getName()));
/*  40 */         System.exit(0);
/*     */       } 
/*  42 */       System.exit(1);
/*     */     } 
/*  44 */     if (!main.reporter.hasReportedError()) {
/*  45 */       main.processSource(args);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Main() {
/*  51 */     this.reporter = new ToolErrorReporter(true);
/*  52 */     this.compilerEnv = new CompilerEnvirons();
/*  53 */     this.compilerEnv.setErrorReporter((ErrorReporter)this.reporter);
/*  54 */     this.compiler = new ClassCompiler(this.compilerEnv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] processOptions(String[] args) {
/*  63 */     this.targetPackage = "";
/*  64 */     this.compilerEnv.setGenerateDebugInfo(false);
/*  65 */     for (int i = 0; i < args.length; i++) {
/*  66 */       String arg = args[i];
/*  67 */       if (!arg.startsWith("-")) {
/*  68 */         int tail = args.length - i;
/*  69 */         if (this.targetName != null && tail > 1) {
/*  70 */           addError("msg.multiple.js.to.file", this.targetName);
/*  71 */           return null;
/*     */         } 
/*  73 */         String[] result = new String[tail];
/*  74 */         for (int j = 0; j != tail; j++) {
/*  75 */           result[j] = args[i + j];
/*     */         }
/*  77 */         return result;
/*     */       } 
/*  79 */       if (arg.equals("-help") || arg.equals("-h") || arg
/*  80 */         .equals("--help")) {
/*     */         
/*  82 */         this.printHelp = true;
/*  83 */         return null;
/*     */       } 
/*     */ 
/*     */       
/*  87 */       try { if (arg.equals("-version") && ++i < args.length)
/*  88 */         { int version = Integer.parseInt(args[i]);
/*  89 */           this.compilerEnv.setLanguageVersion(version);
/*     */            }
/*     */         
/*  92 */         else if ((arg.equals("-opt") || arg.equals("-O")) && ++i < args.length)
/*     */         
/*     */         { 
/*  95 */           int optLevel = Integer.parseInt(args[i]);
/*  96 */           this.compilerEnv.setOptimizationLevel(optLevel);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */            }
/*     */         
/* 104 */         else if (arg.equals("-nosource"))
/* 105 */         { this.compilerEnv.setGeneratingSource(false);
/*     */            }
/*     */         
/* 108 */         else if (arg.equals("-debug") || arg.equals("-g"))
/* 109 */         { this.compilerEnv.setGenerateDebugInfo(true);
/*     */            }
/*     */         
/* 112 */         else if (arg.equals("-main-method-class") && ++i < args.length)
/* 113 */         { this.compiler.setMainMethodClass(args[i]);
/*     */            }
/*     */         
/* 116 */         else if (arg.equals("-encoding") && ++i < args.length)
/* 117 */         { this.characterEncoding = args[i];
/*     */            }
/*     */         
/* 120 */         else if (arg.equals("-o") && ++i < args.length)
/* 121 */         { String name = args[i];
/* 122 */           int end = name.length();
/* 123 */           if (end == 0 || 
/* 124 */             !Character.isJavaIdentifierStart(name.charAt(0))) {
/*     */             
/* 126 */             addError("msg.invalid.classfile.name", name);
/*     */           } else {
/*     */             String str;
/* 129 */             for (int j = 1; j < end; j++) {
/* 130 */               char c = name.charAt(j);
/* 131 */               if (!Character.isJavaIdentifierPart(c)) {
/* 132 */                 if (c == '.')
/*     */                 {
/* 134 */                   if (j == end - 6 && name.endsWith(".class")) {
/* 135 */                     str = name.substring(0, j);
/*     */                     break;
/*     */                   } 
/*     */                 }
/* 139 */                 addError("msg.invalid.classfile.name", str);
/*     */                 break;
/*     */               } 
/*     */             } 
/* 143 */             this.targetName = str;
/*     */           }  }
/*     */         else
/* 146 */         { if (arg.equals("-observe-instruction-count")) {
/* 147 */             this.compilerEnv.setGenerateObserverCount(true);
/*     */           }
/* 149 */           if (arg.equals("-package") && ++i < args.length)
/* 150 */           { String pkg = args[i];
/* 151 */             int end = pkg.length();
/* 152 */             for (int j = 0; j != end; ) {
/* 153 */               char c = pkg.charAt(j);
/* 154 */               if (Character.isJavaIdentifierStart(c)) {
/* 155 */                 for (; ++j != end; j++) {
/* 156 */                   c = pkg.charAt(j);
/* 157 */                   if (!Character.isJavaIdentifierPart(c)) {
/*     */                     break;
/*     */                   }
/*     */                 } 
/* 161 */                 if (j == end) {
/*     */                   break;
/*     */                 }
/* 164 */                 if (c == '.' && j != end - 1) {
/*     */                   j++; continue;
/*     */                 } 
/*     */               } 
/* 168 */               addError("msg.package.name", this.targetPackage);
/* 169 */               return null;
/*     */             } 
/* 171 */             this.targetPackage = pkg;
/*     */              }
/*     */           
/* 174 */           else if (arg.equals("-extends") && ++i < args.length)
/* 175 */           { Class<?> superClass; String targetExtends = args[i];
/*     */             
/*     */             try {
/* 178 */               superClass = Class.forName(targetExtends);
/* 179 */             } catch (ClassNotFoundException e) {
/* 180 */               throw new Error(e.toString());
/*     */             } 
/* 182 */             this.compiler.setTargetExtends(superClass);
/*     */              }
/*     */           
/* 185 */           else if (arg.equals("-implements") && ++i < args.length)
/*     */           
/* 187 */           { String targetImplements = args[i];
/* 188 */             StringTokenizer st = new StringTokenizer(targetImplements, ",");
/*     */             
/* 190 */             List<Class<?>> list = new ArrayList<>();
/* 191 */             while (st.hasMoreTokens()) {
/* 192 */               String className = st.nextToken();
/*     */               try {
/* 194 */                 list.add(Class.forName(className));
/* 195 */               } catch (ClassNotFoundException e) {
/* 196 */                 throw new Error(e.toString());
/*     */               } 
/*     */             } 
/* 199 */             Class<?>[] implementsClasses = (Class[])list.<Class<?>[]>toArray((Class<?>[][])new Class[list.size()]);
/* 200 */             this.compiler.setTargetImplements(implementsClasses);
/*     */              }
/*     */           
/* 203 */           else if (arg.equals("-d") && ++i < args.length)
/* 204 */           { this.destinationDir = args[i]; }
/*     */           else
/*     */           
/* 207 */           { badUsage(arg);
/* 208 */             return null; }  }  }
/*     */       catch (NumberFormatException numberFormatException) { badUsage(args[i]); return null; }
/*     */     
/* 211 */     }  p(ToolErrorReporter.getMessage("msg.no.file"));
/* 212 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void badUsage(String s) {
/* 218 */     System.err.println(ToolErrorReporter.getMessage("msg.jsc.bad.usage", Main.class
/* 219 */           .getName(), s));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processSource(String[] filenames) {
/* 228 */     for (int i = 0; i != filenames.length; i++) {
/* 229 */       String filename = filenames[i];
/* 230 */       if (!filename.endsWith(".js")) {
/* 231 */         addError("msg.extension.not.js", filename);
/*     */         return;
/*     */       } 
/* 234 */       File f = new File(filename);
/* 235 */       String source = readSource(f);
/* 236 */       if (source == null)
/*     */         return; 
/* 238 */       String mainClassName = this.targetName;
/* 239 */       if (mainClassName == null) {
/* 240 */         String name = f.getName();
/* 241 */         String nojs = name.substring(0, name.length() - 3);
/* 242 */         mainClassName = getClassName(nojs);
/*     */       } 
/* 244 */       if (this.targetPackage.length() != 0) {
/* 245 */         mainClassName = this.targetPackage + "." + mainClassName;
/*     */       }
/*     */ 
/*     */       
/* 249 */       Object[] compiled = this.compiler.compileToClassFiles(source, filename, 1, mainClassName);
/*     */       
/* 251 */       if (compiled == null || compiled.length == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 255 */       File targetTopDir = null;
/* 256 */       if (this.destinationDir != null) {
/* 257 */         targetTopDir = new File(this.destinationDir);
/*     */       } else {
/* 259 */         String parent = f.getParent();
/* 260 */         if (parent != null) {
/* 261 */           targetTopDir = new File(parent);
/*     */         }
/*     */       } 
/* 264 */       for (int j = 0; j != compiled.length; j += 2) {
/* 265 */         String className = (String)compiled[j];
/* 266 */         byte[] bytes = (byte[])compiled[j + 1];
/*     */         try {
/* 268 */           File outfile = getOutputFile(targetTopDir, className);
/* 269 */           FileOutputStream os = new FileOutputStream(outfile);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 275 */         catch (IOException ioe) {
/* 276 */           addFormatedError(ioe.toString());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String readSource(File f) {
/* 284 */     String absPath = f.getAbsolutePath();
/* 285 */     if (!f.isFile()) {
/* 286 */       addError("msg.jsfile.not.found", absPath);
/* 287 */       return null;
/*     */     } 
/*     */     try {
/* 290 */       return (String)SourceReader.readFileOrUrl(absPath, true, this.characterEncoding);
/*     */     }
/* 292 */     catch (FileNotFoundException ex) {
/* 293 */       addError("msg.couldnt.open", absPath);
/* 294 */     } catch (IOException ioe) {
/* 295 */       addFormatedError(ioe.toString());
/*     */     } 
/* 297 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private File getOutputFile(File parentDir, String className) throws IOException {
/* 302 */     String path = className.replace('.', File.separatorChar);
/* 303 */     path = path.concat(".class");
/* 304 */     File f = new File(parentDir, path);
/* 305 */     String dirPath = f.getParent();
/* 306 */     if (dirPath != null) {
/* 307 */       File dir = new File(dirPath);
/* 308 */       if (!dir.exists() && 
/* 309 */         !dir.mkdirs()) {
/* 310 */         throw new IOException("Error making output directory " + dirPath);
/*     */       }
/*     */     } 
/*     */     
/* 314 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getClassName(String name) {
/* 324 */     char[] s = new char[name.length() + 1];
/*     */     
/* 326 */     int j = 0;
/*     */     
/* 328 */     if (!Character.isJavaIdentifierStart(name.charAt(0))) {
/* 329 */       s[j++] = '_';
/*     */     }
/* 331 */     for (int i = 0; i < name.length(); i++, j++) {
/* 332 */       char c = name.charAt(i);
/* 333 */       if (Character.isJavaIdentifierPart(c)) {
/* 334 */         s[j] = c;
/*     */       } else {
/* 336 */         s[j] = '_';
/*     */       } 
/*     */     } 
/* 339 */     return (new String(s)).trim();
/*     */   }
/*     */   
/*     */   private static void p(String s) {
/* 343 */     System.out.println(s);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addError(String messageId, String arg) {
/*     */     String msg;
/* 349 */     if (arg == null) {
/* 350 */       msg = ToolErrorReporter.getMessage(messageId);
/*     */     } else {
/* 352 */       msg = ToolErrorReporter.getMessage(messageId, arg);
/*     */     } 
/* 354 */     addFormatedError(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addFormatedError(String message) {
/* 359 */     this.reporter.error(message, null, -1, null, -1);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\jsc\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */