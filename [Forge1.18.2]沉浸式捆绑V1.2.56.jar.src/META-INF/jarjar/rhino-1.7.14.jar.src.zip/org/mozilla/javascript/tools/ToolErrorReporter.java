/*     */ package org.mozilla.javascript.tools;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ErrorReporter;
/*     */ import org.mozilla.javascript.EvaluatorException;
/*     */ import org.mozilla.javascript.RhinoException;
/*     */ import org.mozilla.javascript.SecurityUtilities;
/*     */ import org.mozilla.javascript.WrappedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolErrorReporter
/*     */   implements ErrorReporter
/*     */ {
/*     */   private static final String messagePrefix = "js: ";
/*     */   private boolean hasReportedErrorFlag;
/*     */   private boolean reportWarnings;
/*     */   private PrintStream err;
/*     */   
/*     */   public ToolErrorReporter(boolean reportWarnings) {
/*  31 */     this(reportWarnings, System.err);
/*     */   }
/*     */   
/*     */   public ToolErrorReporter(boolean reportWarnings, PrintStream err) {
/*  35 */     this.reportWarnings = reportWarnings;
/*  36 */     this.err = err;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMessage(String messageId) {
/*  45 */     return getMessage(messageId, (Object[])null);
/*     */   }
/*     */   
/*     */   public static String getMessage(String messageId, String argument) {
/*  49 */     Object[] args = { argument };
/*  50 */     return getMessage(messageId, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getMessage(String messageId, Object arg1, Object arg2) {
/*  55 */     Object[] args = { arg1, arg2 };
/*  56 */     return getMessage(messageId, args);
/*     */   }
/*     */   public static String getMessage(String messageId, Object[] args) {
/*     */     String formatString;
/*  60 */     Context cx = Context.getCurrentContext();
/*  61 */     Locale locale = (cx == null) ? Locale.getDefault() : cx.getLocale();
/*     */ 
/*     */ 
/*     */     
/*  65 */     ResourceBundle rb = ResourceBundle.getBundle("org.mozilla.javascript.tools.resources.Messages", locale);
/*     */ 
/*     */     
/*     */     try {
/*  69 */       formatString = rb.getString(messageId);
/*  70 */     } catch (MissingResourceException mre) {
/*  71 */       throw new RuntimeException("no message resource found for message property " + messageId);
/*     */     } 
/*     */ 
/*     */     
/*  75 */     if (args == null) {
/*  76 */       return formatString;
/*     */     }
/*  78 */     MessageFormat formatter = new MessageFormat(formatString);
/*  79 */     return formatter.format(args);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getExceptionMessage(RhinoException ex) {
/*     */     String msg;
/*  86 */     if (ex instanceof org.mozilla.javascript.JavaScriptException) {
/*  87 */       msg = getMessage("msg.uncaughtJSException", ex.details());
/*  88 */     } else if (ex instanceof org.mozilla.javascript.EcmaError) {
/*  89 */       msg = getMessage("msg.uncaughtEcmaError", ex.details());
/*  90 */     } else if (ex instanceof EvaluatorException) {
/*  91 */       msg = ex.details();
/*     */     } else {
/*  93 */       msg = ex.toString();
/*     */     } 
/*  95 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void warning(String message, String sourceName, int line, String lineSource, int lineOffset) {
/* 101 */     if (!this.reportWarnings)
/*     */       return; 
/* 103 */     reportErrorMessage(message, sourceName, line, lineSource, lineOffset, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String message, String sourceName, int line, String lineSource, int lineOffset) {
/* 110 */     this.hasReportedErrorFlag = true;
/* 111 */     reportErrorMessage(message, sourceName, line, lineSource, lineOffset, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluatorException runtimeError(String message, String sourceName, int line, String lineSource, int lineOffset) {
/* 119 */     return new EvaluatorException(message, sourceName, line, lineSource, lineOffset);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasReportedError() {
/* 124 */     return this.hasReportedErrorFlag;
/*     */   }
/*     */   
/*     */   public boolean isReportingWarnings() {
/* 128 */     return this.reportWarnings;
/*     */   }
/*     */   
/*     */   public void setIsReportingWarnings(boolean reportWarnings) {
/* 132 */     this.reportWarnings = reportWarnings;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void reportException(ErrorReporter er, RhinoException ex) {
/* 137 */     if (er instanceof ToolErrorReporter) {
/* 138 */       ((ToolErrorReporter)er).reportException(ex);
/*     */     } else {
/* 140 */       String msg = getExceptionMessage(ex);
/* 141 */       er.error(msg, ex.sourceName(), ex.lineNumber(), ex
/* 142 */           .lineSource(), ex.columnNumber());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reportException(RhinoException ex) {
/* 148 */     if (ex instanceof WrappedException) {
/* 149 */       WrappedException we = (WrappedException)ex;
/* 150 */       we.printStackTrace(this.err);
/*     */     } else {
/*     */       
/* 153 */       String lineSeparator = SecurityUtilities.getSystemProperty("line.separator");
/*     */       
/* 155 */       String msg = getExceptionMessage(ex) + lineSeparator + ex.getScriptStackTrace();
/* 156 */       reportErrorMessage(msg, ex.sourceName(), ex.lineNumber(), ex
/* 157 */           .lineSource(), ex.columnNumber(), false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reportErrorMessage(String message, String sourceName, int line, String lineSource, int lineOffset, boolean justWarning) {
/* 165 */     if (line > 0) {
/* 166 */       String lineStr = String.valueOf(line);
/* 167 */       if (sourceName != null) {
/* 168 */         Object[] args = { sourceName, lineStr, message };
/* 169 */         message = getMessage("msg.format3", args);
/*     */       } else {
/* 171 */         Object[] args = { lineStr, message };
/* 172 */         message = getMessage("msg.format2", args);
/*     */       } 
/*     */     } else {
/* 175 */       Object[] args = { message };
/* 176 */       message = getMessage("msg.format1", args);
/*     */     } 
/* 178 */     if (justWarning) {
/* 179 */       message = getMessage("msg.warning", message);
/*     */     }
/* 181 */     this.err.println("js: " + message);
/* 182 */     if (null != lineSource) {
/* 183 */       this.err.println("js: " + lineSource);
/* 184 */       this.err.println("js: " + buildIndicator(lineOffset));
/*     */     } 
/*     */   }
/*     */   
/*     */   private String buildIndicator(int offset) {
/* 189 */     StringBuilder sb = new StringBuilder();
/* 190 */     for (int i = 0; i < offset - 1; i++)
/* 191 */       sb.append("."); 
/* 192 */     sb.append("^");
/* 193 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\ToolErrorReporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */