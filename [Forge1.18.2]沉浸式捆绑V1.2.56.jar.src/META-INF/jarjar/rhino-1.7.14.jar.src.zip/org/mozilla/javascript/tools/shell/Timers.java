/*     */ package org.mozilla.javascript.tools.shell;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.PriorityQueue;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.Function;
/*     */ import org.mozilla.javascript.LambdaFunction;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Timers
/*     */ {
/*  19 */   private int lastId = 0;
/*  20 */   private final HashMap<Integer, Timeout> timers = new HashMap<>();
/*  21 */   private final PriorityQueue<Timeout> timerQueue = new PriorityQueue<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void install(Scriptable scope) {
/*  29 */     LambdaFunction setTimeout = new LambdaFunction(scope, "setTimeout", 1, (lcx, lscope, thisObj, args) -> setTimeout(args));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  36 */     ScriptableObject.defineProperty(scope, "setTimeout", setTimeout, 2);
/*  37 */     LambdaFunction clearTimeout = new LambdaFunction(scope, "clearTimeout", 1, (lcx, lscope, thisObj, args) -> clearTimeout(args));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     ScriptableObject.defineProperty(scope, "clearTimeout", clearTimeout, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void runAllTimers(Context cx, Scriptable scope) throws InterruptedException {
/*     */     while (true) {
/*  59 */       cx.processMicrotasks();
/*  60 */       boolean executed = executeNext(cx, scope);
/*  61 */       if (!executed) {
/*  62 */         cx.processMicrotasks();
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean executeNext(Context cx, Scriptable scope) throws InterruptedException {
/*  75 */     Timeout t = this.timerQueue.peek();
/*  76 */     if (t == null) {
/*  77 */       return false;
/*     */     }
/*  79 */     long remaining = t.expiration - System.currentTimeMillis();
/*  80 */     if (remaining > 0L) {
/*  81 */       Thread.sleep(remaining);
/*     */     }
/*  83 */     this.timerQueue.remove();
/*  84 */     this.timers.remove(Integer.valueOf(t.id));
/*  85 */     cx.enqueueMicrotask(() -> t.func.call(cx, scope, scope, t.funcArgs));
/*  86 */     return true;
/*     */   }
/*     */   
/*     */   private Object setTimeout(Object[] args) {
/*  90 */     if (args.length == 0) {
/*  91 */       throw ScriptRuntime.typeError("Expected function parameter");
/*     */     }
/*  93 */     if (!(args[0] instanceof Function)) {
/*  94 */       throw ScriptRuntime.typeError("Expected first argument to be a function");
/*     */     }
/*     */     
/*  97 */     int id = ++this.lastId;
/*  98 */     Timeout t = new Timeout();
/*  99 */     t.id = id;
/* 100 */     t.func = (Function)args[0];
/* 101 */     int delay = 0;
/* 102 */     if (args.length > 1) {
/* 103 */       delay = ScriptRuntime.toInt32(args[1]);
/*     */     }
/* 105 */     t.expiration = System.currentTimeMillis() + delay;
/* 106 */     if (args.length > 2) {
/* 107 */       t.funcArgs = new Object[args.length - 2];
/* 108 */       System.arraycopy(args, 2, t.funcArgs, 0, t.funcArgs.length);
/*     */     } 
/*     */     
/* 111 */     this.timers.put(Integer.valueOf(id), t);
/* 112 */     this.timerQueue.add(t);
/* 113 */     return Integer.valueOf(id);
/*     */   }
/*     */   
/*     */   private Object clearTimeout(Object[] args) {
/* 117 */     if (args.length == 0) {
/* 118 */       throw ScriptRuntime.typeError("Expected function parameter");
/*     */     }
/* 120 */     int id = ScriptRuntime.toInt32(args[0]);
/* 121 */     Timeout t = this.timers.remove(Integer.valueOf(id));
/* 122 */     if (t != null) {
/* 123 */       this.timerQueue.remove(t);
/*     */     }
/* 125 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Timeout
/*     */     implements Comparable<Timeout>
/*     */   {
/*     */     int id;
/*     */     
/*     */     Function func;
/*     */     
/* 136 */     Object[] funcArgs = ScriptRuntime.emptyArgs;
/*     */     
/*     */     long expiration;
/*     */     
/*     */     public int compareTo(Timeout o) {
/* 141 */       return Long.compare(this.expiration, o.expiration);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*     */       try {
/* 147 */         return (this.expiration == ((Timeout)obj).expiration);
/* 148 */       } catch (ClassCastException cce) {
/* 149 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       assert false;
/* 157 */       return (int)this.expiration;
/*     */     }
/*     */     
/*     */     private Timeout() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\tools\shell\Timers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */