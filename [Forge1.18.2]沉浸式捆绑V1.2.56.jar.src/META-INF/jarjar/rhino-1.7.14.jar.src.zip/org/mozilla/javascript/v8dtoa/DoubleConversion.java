/*    */ package org.mozilla.javascript.v8dtoa;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DoubleConversion
/*    */ {
/*    */   private static final long kSignMask = -9223372036854775808L;
/*    */   private static final long kExponentMask = 9218868437227405312L;
/*    */   private static final long kSignificandMask = 4503599627370495L;
/*    */   private static final long kHiddenBit = 4503599627370496L;
/*    */   private static final int kPhysicalSignificandSize = 52;
/*    */   private static final int kSignificandSize = 53;
/*    */   private static final int kExponentBias = 1075;
/*    */   private static final int kDenormalExponent = -1074;
/*    */   
/*    */   private static int exponent(long d64) {
/* 47 */     if (isDenormal(d64)) {
/* 48 */       return -1074;
/*    */     }
/* 50 */     int biased_e = (int)((d64 & 0x7FF0000000000000L) >> 52L);
/* 51 */     return biased_e - 1075;
/*    */   }
/*    */   
/*    */   private static long significand(long d64) {
/* 55 */     long significand = d64 & 0xFFFFFFFFFFFFFL;
/* 56 */     if (!isDenormal(d64)) {
/* 57 */       return significand + 4503599627370496L;
/*    */     }
/* 59 */     return significand;
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean isDenormal(long d64) {
/* 64 */     return ((d64 & 0x7FF0000000000000L) == 0L);
/*    */   }
/*    */   
/*    */   private static int sign(long d64) {
/* 68 */     return ((d64 & Long.MIN_VALUE) == 0L) ? 1 : -1;
/*    */   }
/*    */   
/*    */   public static int doubleToInt32(double x) {
/* 72 */     int i = (int)x;
/* 73 */     if (i == x) {
/* 74 */       return i;
/*    */     }
/* 76 */     long d64 = Double.doubleToLongBits(x);
/* 77 */     int exponent = exponent(d64);
/* 78 */     if (exponent <= -53 || exponent > 31) {
/* 79 */       return 0;
/*    */     }
/* 81 */     long s = significand(d64);
/* 82 */     return sign(d64) * (int)((exponent < 0) ? (s >> -exponent) : (s << exponent));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\v8dtoa\DoubleConversion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */