/*      */ package org.mozilla.javascript.optimizer;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.mozilla.classfile.ClassFileWriter;
/*      */ import org.mozilla.javascript.CompilerEnvirons;
/*      */ import org.mozilla.javascript.Context;
/*      */ import org.mozilla.javascript.Evaluator;
/*      */ import org.mozilla.javascript.Function;
/*      */ import org.mozilla.javascript.GeneratedClassLoader;
/*      */ import org.mozilla.javascript.Kit;
/*      */ import org.mozilla.javascript.NativeFunction;
/*      */ import org.mozilla.javascript.ObjArray;
/*      */ import org.mozilla.javascript.ObjToIntMap;
/*      */ import org.mozilla.javascript.RhinoException;
/*      */ import org.mozilla.javascript.Script;
/*      */ import org.mozilla.javascript.Scriptable;
/*      */ import org.mozilla.javascript.SecurityController;
/*      */ import org.mozilla.javascript.ast.FunctionNode;
/*      */ import org.mozilla.javascript.ast.Name;
/*      */ import org.mozilla.javascript.ast.ScriptNode;
/*      */ import org.mozilla.javascript.ast.TemplateCharacters;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Codegen
/*      */   implements Evaluator
/*      */ {
/*      */   static final String DEFAULT_MAIN_METHOD_CLASS = "org.mozilla.javascript.optimizer.OptRuntime";
/*      */   private static final String SUPER_CLASS_NAME = "org.mozilla.javascript.NativeFunction";
/*      */   static final String ID_FIELD_NAME = "_id";
/*      */   static final String REGEXP_INIT_METHOD_NAME = "_reInit";
/*      */   static final String REGEXP_INIT_METHOD_SIGNATURE = "(Lorg/mozilla/javascript/Context;)V";
/*      */   static final String TEMPLATE_LITERAL_INIT_METHOD_NAME = "_qInit";
/*      */   static final String TEMPLATE_LITERAL_INIT_METHOD_SIGNATURE = "()V";
/*      */   static final String FUNCTION_INIT_SIGNATURE = "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)V";
/*      */   static final String FUNCTION_CONSTRUCTOR_SIGNATURE = "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;I)V";
/*      */   
/*      */   public void captureStackInfo(RhinoException ex) {
/*   50 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSourcePositionFromStack(Context cx, int[] linep) {
/*   55 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getPatchedStack(RhinoException ex, String nativeStackTrace) {
/*   60 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> getScriptStack(RhinoException ex) {
/*   65 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEvalScriptFlag(Script script) {
/*   70 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object compile(CompilerEnvirons compilerEnv, ScriptNode tree, String encodedSource, boolean returnFunction) {
/*      */     int serial;
/*   80 */     synchronized (globalLock) {
/*   81 */       serial = ++globalSerialClassCounter;
/*      */     } 
/*      */     
/*   84 */     String baseName = "c";
/*   85 */     if (tree.getSourceName().length() > 0) {
/*   86 */       baseName = tree.getSourceName().replaceAll("\\W", "_");
/*   87 */       if (!Character.isJavaIdentifierStart(baseName.charAt(0))) {
/*   88 */         baseName = "_" + baseName;
/*      */       }
/*      */     } 
/*      */     
/*   92 */     String mainClassName = "org.mozilla.javascript.gen." + baseName + "_" + serial;
/*      */ 
/*      */     
/*   95 */     byte[] mainClassBytes = compileToClassFile(compilerEnv, mainClassName, tree, encodedSource, returnFunction);
/*      */     
/*   97 */     return new Object[] { mainClassName, mainClassBytes };
/*      */   }
/*      */   
/*      */   public Script createScriptObject(Object bytecode, Object staticSecurityDomain) {
/*      */     Script script;
/*  102 */     Class<?> cl = defineClass(bytecode, staticSecurityDomain);
/*      */ 
/*      */     
/*      */     try {
/*  106 */       script = (Script)cl.newInstance();
/*  107 */     } catch (Exception ex) {
/*  108 */       throw new RuntimeException("Unable to instantiate compiled class:" + ex.toString());
/*      */     } 
/*  110 */     return script;
/*      */   }
/*      */ 
/*      */   
/*      */   public Function createFunctionObject(Context cx, Scriptable scope, Object bytecode, Object staticSecurityDomain) {
/*      */     NativeFunction f;
/*  116 */     Class<?> cl = defineClass(bytecode, staticSecurityDomain);
/*      */ 
/*      */     
/*      */     try {
/*  120 */       Constructor<?> ctor = cl.getConstructors()[0];
/*  121 */       Object[] initArgs = { scope, cx, Integer.valueOf(0) };
/*  122 */       f = (NativeFunction)ctor.newInstance(initArgs);
/*  123 */     } catch (Exception ex) {
/*  124 */       throw new RuntimeException("Unable to instantiate compiled class:" + ex.toString());
/*      */     } 
/*  126 */     return (Function)f;
/*      */   }
/*      */   private Class<?> defineClass(Object bytecode, Object staticSecurityDomain) {
/*      */     Exception e;
/*  130 */     Object[] nameBytesPair = (Object[])bytecode;
/*  131 */     String className = (String)nameBytesPair[0];
/*  132 */     byte[] classBytes = (byte[])nameBytesPair[1];
/*      */ 
/*      */ 
/*      */     
/*  136 */     ClassLoader rhinoLoader = getClass().getClassLoader();
/*      */     
/*  138 */     GeneratedClassLoader loader = SecurityController.createLoader(rhinoLoader, staticSecurityDomain);
/*      */     
/*      */     try {
/*  141 */       Class<?> cl = loader.defineClass(className, classBytes);
/*  142 */       loader.linkClass(cl);
/*  143 */       return cl;
/*  144 */     } catch (SecurityException x) {
/*  145 */       e = x;
/*  146 */     } catch (IllegalArgumentException x) {
/*  147 */       e = x;
/*      */     } 
/*  149 */     throw new RuntimeException("Malformed optimizer package " + e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] compileToClassFile(CompilerEnvirons compilerEnv, String mainClassName, ScriptNode scriptOrFn, String encodedSource, boolean returnFunction) {
/*      */     FunctionNode functionNode;
/*  158 */     this.compilerEnv = compilerEnv;
/*      */     
/*  160 */     transform(scriptOrFn);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  166 */     if (returnFunction) {
/*  167 */       functionNode = scriptOrFn.getFunctionNode(0);
/*      */     }
/*      */     
/*  170 */     initScriptNodesData((ScriptNode)functionNode);
/*      */     
/*  172 */     this.mainClassName = mainClassName;
/*  173 */     this.mainClassSignature = ClassFileWriter.classNameToSignature(mainClassName);
/*      */     
/*  175 */     return generateCode(encodedSource);
/*      */   }
/*      */   
/*      */   private void transform(ScriptNode tree) {
/*  179 */     initOptFunctions_r(tree);
/*      */     
/*  181 */     int optLevel = this.compilerEnv.getOptimizationLevel();
/*      */     
/*  183 */     Map<String, OptFunctionNode> possibleDirectCalls = null;
/*  184 */     if (optLevel > 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  190 */       if (tree.getType() == 140) {
/*  191 */         int functionCount = tree.getFunctionCount();
/*  192 */         for (int i = 0; i != functionCount; i++) {
/*  193 */           OptFunctionNode ofn = OptFunctionNode.get(tree, i);
/*  194 */           if (ofn.fnode.getFunctionType() == 1) {
/*  195 */             String name = ofn.fnode.getName();
/*  196 */             if (name.length() != 0) {
/*  197 */               if (possibleDirectCalls == null) {
/*  198 */                 possibleDirectCalls = new HashMap<>();
/*      */               }
/*  200 */               possibleDirectCalls.put(name, ofn);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  207 */     if (possibleDirectCalls != null) {
/*  208 */       this.directCallTargets = new ObjArray();
/*      */     }
/*      */     
/*  211 */     OptTransformer ot = new OptTransformer(possibleDirectCalls, this.directCallTargets);
/*  212 */     ot.transform(tree, this.compilerEnv);
/*      */     
/*  214 */     if (optLevel > 0) {
/*  215 */       (new Optimizer()).optimize(tree);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void initOptFunctions_r(ScriptNode scriptOrFn) {
/*  220 */     for (int i = 0, N = scriptOrFn.getFunctionCount(); i != N; i++) {
/*  221 */       FunctionNode fn = scriptOrFn.getFunctionNode(i);
/*  222 */       new OptFunctionNode(fn);
/*  223 */       initOptFunctions_r((ScriptNode)fn);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void initScriptNodesData(ScriptNode scriptOrFn) {
/*  228 */     ObjArray x = new ObjArray();
/*  229 */     collectScriptNodes_r(scriptOrFn, x);
/*      */     
/*  231 */     int count = x.size();
/*  232 */     this.scriptOrFnNodes = new ScriptNode[count];
/*  233 */     x.toArray((Object[])this.scriptOrFnNodes);
/*      */     
/*  235 */     this.scriptOrFnIndexes = new ObjToIntMap(count);
/*  236 */     for (int i = 0; i != count; i++) {
/*  237 */       this.scriptOrFnIndexes.put(this.scriptOrFnNodes[i], i);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void collectScriptNodes_r(ScriptNode n, ObjArray x) {
/*  242 */     x.add(n);
/*  243 */     int nestedCount = n.getFunctionCount();
/*  244 */     for (int i = 0; i != nestedCount; i++) {
/*  245 */       collectScriptNodes_r((ScriptNode)n.getFunctionNode(i), x);
/*      */     }
/*      */   }
/*      */   
/*      */   private byte[] generateCode(String encodedSource) {
/*  250 */     boolean hasScript = (this.scriptOrFnNodes[0].getType() == 140);
/*  251 */     boolean hasFunctions = (this.scriptOrFnNodes.length > 1 || !hasScript);
/*  252 */     boolean isStrictMode = this.scriptOrFnNodes[0].isInStrictMode();
/*      */     
/*  254 */     String sourceFile = null;
/*  255 */     if (this.compilerEnv.isGenerateDebugInfo()) {
/*  256 */       sourceFile = this.scriptOrFnNodes[0].getSourceName();
/*      */     }
/*      */     
/*  259 */     ClassFileWriter cfw = new ClassFileWriter(this.mainClassName, "org.mozilla.javascript.NativeFunction", sourceFile);
/*  260 */     cfw.addField("_id", "I", (short)2);
/*      */     
/*  262 */     if (hasFunctions) {
/*  263 */       generateFunctionConstructor(cfw);
/*      */     }
/*      */     
/*  266 */     if (hasScript) {
/*  267 */       cfw.addInterface("org/mozilla/javascript/Script");
/*  268 */       generateScriptCtor(cfw);
/*  269 */       generateMain(cfw);
/*  270 */       generateExecute(cfw);
/*      */     } 
/*      */     
/*  273 */     generateCallMethod(cfw, isStrictMode);
/*  274 */     generateResumeGenerator(cfw);
/*      */     
/*  276 */     generateNativeFunctionOverrides(cfw, encodedSource);
/*      */     
/*  278 */     int count = this.scriptOrFnNodes.length;
/*  279 */     for (int i = 0; i != count; i++) {
/*  280 */       ScriptNode n = this.scriptOrFnNodes[i];
/*      */       
/*  282 */       BodyCodegen bodygen = new BodyCodegen();
/*  283 */       bodygen.cfw = cfw;
/*  284 */       bodygen.codegen = this;
/*  285 */       bodygen.compilerEnv = this.compilerEnv;
/*  286 */       bodygen.scriptOrFn = n;
/*  287 */       bodygen.scriptOrFnIndex = i;
/*      */       
/*  289 */       bodygen.generateBodyCode();
/*      */       
/*  291 */       if (n.getType() == 113) {
/*  292 */         OptFunctionNode ofn = OptFunctionNode.get(n);
/*  293 */         generateFunctionInit(cfw, ofn);
/*  294 */         if (ofn.isTargetOfDirectCall()) {
/*  295 */           emitDirectConstructor(cfw, ofn);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  300 */     emitRegExpInit(cfw);
/*  301 */     emitTemplateLiteralInit(cfw);
/*  302 */     emitConstantDudeInitializers(cfw);
/*      */     
/*  304 */     return cfw.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void emitDirectConstructor(ClassFileWriter cfw, OptFunctionNode ofn) {
/*  319 */     cfw.startMethod(
/*  320 */         getDirectCtorName((ScriptNode)ofn.fnode), 
/*  321 */         getBodyMethodSignature((ScriptNode)ofn.fnode), (short)10);
/*      */ 
/*      */     
/*  324 */     int argCount = ofn.fnode.getParamCount();
/*  325 */     int firstLocal = 4 + argCount * 3 + 1;
/*      */     
/*  327 */     cfw.addALoad(0);
/*  328 */     cfw.addALoad(1);
/*  329 */     cfw.addALoad(2);
/*  330 */     cfw.addInvoke(182, "org/mozilla/javascript/BaseFunction", "createObject", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  337 */     cfw.addAStore(firstLocal);
/*      */     
/*  339 */     cfw.addALoad(0);
/*  340 */     cfw.addALoad(1);
/*  341 */     cfw.addALoad(2);
/*  342 */     cfw.addALoad(firstLocal);
/*  343 */     for (int i = 0; i < argCount; i++) {
/*  344 */       cfw.addALoad(4 + i * 3);
/*  345 */       cfw.addDLoad(5 + i * 3);
/*      */     } 
/*  347 */     cfw.addALoad(4 + argCount * 3);
/*  348 */     cfw.addInvoke(184, this.mainClassName, 
/*      */ 
/*      */         
/*  351 */         getBodyMethodName((ScriptNode)ofn.fnode), 
/*  352 */         getBodyMethodSignature((ScriptNode)ofn.fnode));
/*  353 */     int exitLabel = cfw.acquireLabel();
/*  354 */     cfw.add(89);
/*  355 */     cfw.add(193, "org/mozilla/javascript/Scriptable");
/*  356 */     cfw.add(153, exitLabel);
/*      */     
/*  358 */     cfw.add(192, "org/mozilla/javascript/Scriptable");
/*  359 */     cfw.add(176);
/*  360 */     cfw.markLabel(exitLabel);
/*      */     
/*  362 */     cfw.addALoad(firstLocal);
/*  363 */     cfw.add(176);
/*      */     
/*  365 */     cfw.stopMethod((short)(firstLocal + 1));
/*      */   }
/*      */   
/*      */   static boolean isGenerator(ScriptNode node) {
/*  369 */     return (node.getType() == 113 && ((FunctionNode)node).isGenerator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateResumeGenerator(ClassFileWriter cfw) {
/*  385 */     boolean hasGenerators = false;
/*  386 */     for (int i = 0; i < this.scriptOrFnNodes.length; i++) {
/*  387 */       if (isGenerator(this.scriptOrFnNodes[i])) hasGenerators = true;
/*      */     
/*      */     } 
/*      */ 
/*      */     
/*  392 */     if (!hasGenerators)
/*      */       return; 
/*  394 */     cfw.startMethod("resumeGenerator", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", (short)17);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  403 */     cfw.addALoad(0);
/*  404 */     cfw.addALoad(1);
/*  405 */     cfw.addALoad(2);
/*  406 */     cfw.addALoad(4);
/*  407 */     cfw.addALoad(5);
/*  408 */     cfw.addILoad(3);
/*      */     
/*  410 */     cfw.addLoadThis();
/*  411 */     cfw.add(180, cfw.getClassName(), "_id", "I");
/*      */     
/*  413 */     int startSwitch = cfw.addTableSwitch(0, this.scriptOrFnNodes.length - 1);
/*  414 */     cfw.markTableSwitchDefault(startSwitch);
/*  415 */     int endlabel = cfw.acquireLabel();
/*      */     
/*  417 */     for (int j = 0; j < this.scriptOrFnNodes.length; j++) {
/*  418 */       ScriptNode n = this.scriptOrFnNodes[j];
/*  419 */       cfw.markTableSwitchCase(startSwitch, j, 6);
/*  420 */       if (isGenerator(n)) {
/*  421 */         String type = "(" + this.mainClassSignature + "Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/Object;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  428 */         cfw.addInvoke(184, this.mainClassName, 
/*  429 */             getBodyMethodName(n) + "_gen", type);
/*  430 */         cfw.add(176);
/*      */       } else {
/*  432 */         cfw.add(167, endlabel);
/*      */       } 
/*      */     } 
/*      */     
/*  436 */     cfw.markLabel(endlabel);
/*  437 */     pushUndefined(cfw);
/*  438 */     cfw.add(176);
/*      */ 
/*      */     
/*  441 */     cfw.stopMethod((short)6);
/*      */   }
/*      */   
/*      */   private void generateCallMethod(ClassFileWriter cfw, boolean isStrictMode) {
/*  445 */     cfw.startMethod("call", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;", (short)17);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  458 */     int nonTopCallLabel = cfw.acquireLabel();
/*  459 */     cfw.addALoad(1);
/*  460 */     cfw.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "hasTopCall", "(Lorg/mozilla/javascript/Context;)Z");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  465 */     cfw.add(154, nonTopCallLabel);
/*  466 */     cfw.addALoad(0);
/*  467 */     cfw.addALoad(1);
/*  468 */     cfw.addALoad(2);
/*  469 */     cfw.addALoad(3);
/*  470 */     cfw.addALoad(4);
/*  471 */     cfw.addPush(isStrictMode);
/*  472 */     cfw.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "doTopCall", "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Z)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  483 */     cfw.add(176);
/*  484 */     cfw.markLabel(nonTopCallLabel);
/*      */ 
/*      */     
/*  487 */     cfw.addALoad(0);
/*  488 */     cfw.addALoad(1);
/*  489 */     cfw.addALoad(2);
/*  490 */     cfw.addALoad(3);
/*  491 */     cfw.addALoad(4);
/*      */     
/*  493 */     int end = this.scriptOrFnNodes.length;
/*  494 */     boolean generateSwitch = (2 <= end);
/*      */     
/*  496 */     int switchStart = 0;
/*  497 */     int switchStackTop = 0;
/*  498 */     if (generateSwitch) {
/*  499 */       cfw.addLoadThis();
/*  500 */       cfw.add(180, cfw.getClassName(), "_id", "I");
/*      */ 
/*      */       
/*  503 */       switchStart = cfw.addTableSwitch(1, end - 1);
/*      */     } 
/*      */     
/*  506 */     for (int i = 0; i != end; i++) {
/*  507 */       ScriptNode n = this.scriptOrFnNodes[i];
/*  508 */       if (generateSwitch) {
/*  509 */         if (i == 0) {
/*  510 */           cfw.markTableSwitchDefault(switchStart);
/*  511 */           switchStackTop = cfw.getStackTop();
/*      */         } else {
/*  513 */           cfw.markTableSwitchCase(switchStart, i - 1, switchStackTop);
/*      */         } 
/*      */       }
/*  516 */       if (n.getType() == 113) {
/*  517 */         OptFunctionNode ofn = OptFunctionNode.get(n);
/*  518 */         if (ofn.isTargetOfDirectCall()) {
/*  519 */           int pcount = ofn.fnode.getParamCount();
/*  520 */           if (pcount != 0)
/*      */           {
/*      */             
/*  523 */             for (int p = 0; p != pcount; p++) {
/*  524 */               cfw.add(190);
/*  525 */               cfw.addPush(p);
/*  526 */               int undefArg = cfw.acquireLabel();
/*  527 */               int beyond = cfw.acquireLabel();
/*  528 */               cfw.add(164, undefArg);
/*      */               
/*  530 */               cfw.addALoad(4);
/*  531 */               cfw.addPush(p);
/*  532 */               cfw.add(50);
/*  533 */               cfw.add(167, beyond);
/*  534 */               cfw.markLabel(undefArg);
/*  535 */               pushUndefined(cfw);
/*  536 */               cfw.markLabel(beyond);
/*      */               
/*  538 */               cfw.adjustStackTop(-1);
/*  539 */               cfw.addPush(0.0D);
/*      */               
/*  541 */               cfw.addALoad(4);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*  546 */       cfw.addInvoke(184, this.mainClassName, 
/*      */ 
/*      */           
/*  549 */           getBodyMethodName(n), 
/*  550 */           getBodyMethodSignature(n));
/*  551 */       cfw.add(176);
/*      */     } 
/*  553 */     cfw.stopMethod((short)5);
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateMain(ClassFileWriter cfw) {
/*  558 */     cfw.startMethod("main", "([Ljava/lang/String;)V", (short)9);
/*      */ 
/*      */     
/*  561 */     cfw.add(187, cfw.getClassName());
/*  562 */     cfw.add(89);
/*  563 */     cfw.addInvoke(183, cfw.getClassName(), "<init>", "()V");
/*      */     
/*  565 */     cfw.add(42);
/*      */     
/*  567 */     cfw.addInvoke(184, this.mainMethodClass, "main", "(Lorg/mozilla/javascript/Script;[Ljava/lang/String;)V");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  572 */     cfw.add(177);
/*      */     
/*  574 */     cfw.stopMethod((short)1);
/*      */   }
/*      */   
/*      */   private static void generateExecute(ClassFileWriter cfw) {
/*  578 */     cfw.startMethod("exec", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;", (short)17);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  585 */     int CONTEXT_ARG = 1;
/*  586 */     int SCOPE_ARG = 2;
/*      */     
/*  588 */     cfw.addLoadThis();
/*  589 */     cfw.addALoad(1);
/*  590 */     cfw.addALoad(2);
/*  591 */     cfw.add(89);
/*  592 */     cfw.add(1);
/*  593 */     cfw.addInvoke(182, cfw
/*      */         
/*  595 */         .getClassName(), "call", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  603 */     cfw.addALoad(1);
/*  604 */     cfw.addInvoke(182, "org.mozilla.javascript.Context", "processMicrotasks", "()V");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  610 */     cfw.add(176);
/*      */     
/*  612 */     cfw.stopMethod((short)3);
/*      */   }
/*      */   
/*      */   private static void generateScriptCtor(ClassFileWriter cfw) {
/*  616 */     cfw.startMethod("<init>", "()V", (short)1);
/*      */     
/*  618 */     cfw.addLoadThis();
/*  619 */     cfw.addInvoke(183, "org.mozilla.javascript.NativeFunction", "<init>", "()V");
/*      */     
/*  621 */     cfw.addLoadThis();
/*  622 */     cfw.addPush(0);
/*  623 */     cfw.add(181, cfw.getClassName(), "_id", "I");
/*      */     
/*  625 */     cfw.add(177);
/*      */     
/*  627 */     cfw.stopMethod((short)1);
/*      */   }
/*      */   
/*      */   private void generateFunctionConstructor(ClassFileWriter cfw) {
/*  631 */     int SCOPE_ARG = 1;
/*  632 */     int CONTEXT_ARG = 2;
/*  633 */     int ID_ARG = 3;
/*      */     
/*  635 */     cfw.startMethod("<init>", "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;I)V", (short)1);
/*  636 */     cfw.addALoad(0);
/*  637 */     cfw.addInvoke(183, "org.mozilla.javascript.NativeFunction", "<init>", "()V");
/*      */     
/*  639 */     cfw.addLoadThis();
/*  640 */     cfw.addILoad(3);
/*  641 */     cfw.add(181, cfw.getClassName(), "_id", "I");
/*      */     
/*  643 */     cfw.addLoadThis();
/*  644 */     cfw.addALoad(2);
/*  645 */     cfw.addALoad(1);
/*      */     
/*  647 */     int start = (this.scriptOrFnNodes[0].getType() == 140) ? 1 : 0;
/*  648 */     int end = this.scriptOrFnNodes.length;
/*  649 */     if (start == end) throw badTree(); 
/*  650 */     boolean generateSwitch = (2 <= end - start);
/*      */     
/*  652 */     int switchStart = 0;
/*  653 */     int switchStackTop = 0;
/*  654 */     if (generateSwitch) {
/*  655 */       cfw.addILoad(3);
/*      */ 
/*      */       
/*  658 */       switchStart = cfw.addTableSwitch(start + 1, end - 1);
/*      */     } 
/*      */     
/*  661 */     for (int i = start; i != end; i++) {
/*  662 */       if (generateSwitch) {
/*  663 */         if (i == start) {
/*  664 */           cfw.markTableSwitchDefault(switchStart);
/*  665 */           switchStackTop = cfw.getStackTop();
/*      */         } else {
/*  667 */           cfw.markTableSwitchCase(switchStart, i - 1 - start, switchStackTop);
/*      */         } 
/*      */       }
/*  670 */       OptFunctionNode ofn = OptFunctionNode.get(this.scriptOrFnNodes[i]);
/*  671 */       cfw.addInvoke(183, this.mainClassName, 
/*      */ 
/*      */           
/*  674 */           getFunctionInitMethodName(ofn), "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)V");
/*      */       
/*  676 */       cfw.add(177);
/*      */     } 
/*      */ 
/*      */     
/*  680 */     cfw.stopMethod((short)4);
/*      */   }
/*      */   
/*      */   private void generateFunctionInit(ClassFileWriter cfw, OptFunctionNode ofn) {
/*  684 */     int CONTEXT_ARG = 1;
/*  685 */     int SCOPE_ARG = 2;
/*  686 */     cfw.startMethod(
/*  687 */         getFunctionInitMethodName(ofn), "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)V", (short)18);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  692 */     cfw.addLoadThis();
/*  693 */     cfw.addALoad(1);
/*  694 */     cfw.addALoad(2);
/*  695 */     cfw.addInvoke(182, "org/mozilla/javascript/NativeFunction", "initScriptFunction", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)V");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  702 */     if (ofn.fnode.getRegexpCount() != 0) {
/*  703 */       cfw.addALoad(1);
/*  704 */       cfw.addInvoke(184, this.mainClassName, "_reInit", "(Lorg/mozilla/javascript/Context;)V");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  711 */     if (ofn.fnode.getTemplateLiteralCount() != 0) {
/*  712 */       cfw.addInvoke(184, this.mainClassName, "_qInit", "()V");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  719 */     cfw.add(177);
/*      */     
/*  721 */     cfw.stopMethod((short)3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateNativeFunctionOverrides(ClassFileWriter cfw, String encodedSource) {
/*  728 */     cfw.startMethod("getLanguageVersion", "()I", (short)1);
/*      */     
/*  730 */     cfw.addPush(this.compilerEnv.getLanguageVersion());
/*  731 */     cfw.add(172);
/*      */ 
/*      */     
/*  734 */     cfw.stopMethod((short)1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  739 */     int Do_getFunctionName = 0;
/*  740 */     int Do_getParamCount = 1;
/*  741 */     int Do_getParamAndVarCount = 2;
/*  742 */     int Do_getParamOrVarName = 3;
/*  743 */     int Do_getEncodedSource = 4;
/*  744 */     int Do_getParamOrVarConst = 5;
/*  745 */     int Do_isGeneratorFunction = 6;
/*  746 */     int SWITCH_COUNT = 7;
/*      */     
/*  748 */     for (int methodIndex = 0; methodIndex != 7; methodIndex++) {
/*  749 */       if (methodIndex != 4 || encodedSource != null) {
/*      */         short methodLocals;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  759 */         switch (methodIndex) {
/*      */           case 0:
/*  761 */             methodLocals = 1;
/*  762 */             cfw.startMethod("getFunctionName", "()Ljava/lang/String;", (short)1);
/*      */             break;
/*      */           case 1:
/*  765 */             methodLocals = 1;
/*  766 */             cfw.startMethod("getParamCount", "()I", (short)1);
/*      */             break;
/*      */           case 2:
/*  769 */             methodLocals = 1;
/*  770 */             cfw.startMethod("getParamAndVarCount", "()I", (short)1);
/*      */             break;
/*      */           case 3:
/*  773 */             methodLocals = 2;
/*  774 */             cfw.startMethod("getParamOrVarName", "(I)Ljava/lang/String;", (short)1);
/*      */             break;
/*      */           case 5:
/*  777 */             methodLocals = 3;
/*  778 */             cfw.startMethod("getParamOrVarConst", "(I)Z", (short)1);
/*      */             break;
/*      */           case 4:
/*  781 */             methodLocals = 1;
/*  782 */             cfw.startMethod("getEncodedSource", "()Ljava/lang/String;", (short)1);
/*  783 */             cfw.addPush(encodedSource);
/*      */             break;
/*      */           case 6:
/*  786 */             methodLocals = 1;
/*  787 */             cfw.startMethod("isGeneratorFunction", "()Z", (short)4);
/*      */             break;
/*      */           default:
/*  790 */             throw Kit.codeBug();
/*      */         } 
/*      */         
/*  793 */         int count = this.scriptOrFnNodes.length;
/*      */         
/*  795 */         int switchStart = 0;
/*  796 */         int switchStackTop = 0;
/*  797 */         if (count > 1) {
/*      */ 
/*      */           
/*  800 */           cfw.addLoadThis();
/*  801 */           cfw.add(180, cfw.getClassName(), "_id", "I");
/*      */ 
/*      */           
/*  804 */           switchStart = cfw.addTableSwitch(1, count - 1);
/*      */         } 
/*      */         
/*  807 */         for (int i = 0; i != count; i++) {
/*  808 */           int paramAndVarCount, paramSwitchStart; boolean[] constness; int j, k, m; ScriptNode n = this.scriptOrFnNodes[i];
/*  809 */           if (i == 0) {
/*  810 */             if (count > 1) {
/*  811 */               cfw.markTableSwitchDefault(switchStart);
/*  812 */               switchStackTop = cfw.getStackTop();
/*      */             } 
/*      */           } else {
/*  815 */             cfw.markTableSwitchCase(switchStart, i - 1, switchStackTop);
/*      */           } 
/*      */ 
/*      */           
/*  819 */           switch (methodIndex) {
/*      */             
/*      */             case 0:
/*  822 */               if (n.getType() == 140) {
/*  823 */                 cfw.addPush("");
/*      */               } else {
/*  825 */                 String name = ((FunctionNode)n).getName();
/*  826 */                 cfw.addPush(name);
/*      */               } 
/*  828 */               cfw.add(176);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 1:
/*  833 */               cfw.addPush(n.getParamCount());
/*  834 */               cfw.add(172);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 2:
/*  839 */               cfw.addPush(n.getParamAndVarCount());
/*  840 */               cfw.add(172);
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 3:
/*  846 */               paramAndVarCount = n.getParamAndVarCount();
/*  847 */               if (paramAndVarCount == 0) {
/*      */ 
/*      */ 
/*      */                 
/*  851 */                 cfw.add(1);
/*  852 */                 cfw.add(176); break;
/*  853 */               }  if (paramAndVarCount == 1) {
/*      */ 
/*      */                 
/*  856 */                 cfw.addPush(n.getParamOrVarName(0));
/*  857 */                 cfw.add(176);
/*      */                 break;
/*      */               } 
/*  860 */               cfw.addILoad(1);
/*      */ 
/*      */               
/*  863 */               paramSwitchStart = cfw.addTableSwitch(1, paramAndVarCount - 1);
/*  864 */               for (j = 0; j != paramAndVarCount; j++) {
/*  865 */                 if (cfw.getStackTop() != 0) Kit.codeBug(); 
/*  866 */                 String s = n.getParamOrVarName(j);
/*  867 */                 if (j == 0) {
/*  868 */                   cfw.markTableSwitchDefault(paramSwitchStart);
/*      */                 } else {
/*  870 */                   cfw.markTableSwitchCase(paramSwitchStart, j - 1, 0);
/*      */                 } 
/*  872 */                 cfw.addPush(s);
/*  873 */                 cfw.add(176);
/*      */               } 
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 5:
/*  881 */               paramAndVarCount = n.getParamAndVarCount();
/*  882 */               constness = n.getParamAndVarConst();
/*  883 */               if (paramAndVarCount == 0) {
/*      */ 
/*      */ 
/*      */                 
/*  887 */                 cfw.add(3);
/*  888 */                 cfw.add(172); break;
/*  889 */               }  if (paramAndVarCount == 1) {
/*      */ 
/*      */                 
/*  892 */                 cfw.addPush(constness[0]);
/*  893 */                 cfw.add(172);
/*      */                 break;
/*      */               } 
/*  896 */               cfw.addILoad(1);
/*      */ 
/*      */               
/*  899 */               k = cfw.addTableSwitch(1, paramAndVarCount - 1);
/*  900 */               for (m = 0; m != paramAndVarCount; m++) {
/*  901 */                 if (cfw.getStackTop() != 0) Kit.codeBug(); 
/*  902 */                 if (m == 0) {
/*  903 */                   cfw.markTableSwitchDefault(k);
/*      */                 } else {
/*  905 */                   cfw.markTableSwitchCase(k, m - 1, 0);
/*      */                 } 
/*  907 */                 cfw.addPush(constness[m]);
/*  908 */                 cfw.add(172);
/*      */               } 
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 6:
/*  915 */               if (n instanceof FunctionNode) {
/*  916 */                 cfw.addPush(((FunctionNode)n).isES6Generator());
/*      */               } else {
/*  918 */                 cfw.addPush(false);
/*      */               } 
/*  920 */               cfw.add(172);
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 4:
/*  926 */               cfw.addPush(n.getEncodedSourceStart());
/*  927 */               cfw.addPush(n.getEncodedSourceEnd());
/*  928 */               cfw.addInvoke(182, "java/lang/String", "substring", "(II)Ljava/lang/String;");
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  933 */               cfw.add(176);
/*      */               break;
/*      */             
/*      */             default:
/*  937 */               throw Kit.codeBug();
/*      */           } 
/*      */         
/*      */         } 
/*  941 */         cfw.stopMethod(methodLocals);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void emitRegExpInit(ClassFileWriter cfw) {
/*  948 */     int totalRegCount = 0;
/*  949 */     for (int i = 0; i != this.scriptOrFnNodes.length; i++) {
/*  950 */       totalRegCount += this.scriptOrFnNodes[i].getRegexpCount();
/*      */     }
/*  952 */     if (totalRegCount == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  956 */     cfw.startMethod("_reInit", "(Lorg/mozilla/javascript/Context;)V", (short)10);
/*      */ 
/*      */ 
/*      */     
/*  960 */     cfw.addField("_reInitDone", "Z", (short)74);
/*  961 */     cfw.add(178, this.mainClassName, "_reInitDone", "Z");
/*  962 */     int doInit = cfw.acquireLabel();
/*  963 */     cfw.add(153, doInit);
/*  964 */     cfw.add(177);
/*  965 */     cfw.markLabel(doInit);
/*      */ 
/*      */     
/*  968 */     cfw.addALoad(0);
/*  969 */     cfw.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "checkRegExpProxy", "(Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/RegExpProxy;");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  974 */     cfw.addAStore(1);
/*      */ 
/*      */ 
/*      */     
/*  978 */     for (int j = 0; j != this.scriptOrFnNodes.length; j++) {
/*  979 */       ScriptNode n = this.scriptOrFnNodes[j];
/*  980 */       int regCount = n.getRegexpCount();
/*  981 */       for (int k = 0; k != regCount; k++) {
/*  982 */         String reFieldName = getCompiledRegexpName(n, k);
/*  983 */         String reFieldType = "Ljava/lang/Object;";
/*  984 */         String reString = n.getRegexpString(k);
/*  985 */         String reFlags = n.getRegexpFlags(k);
/*  986 */         cfw.addField(reFieldName, reFieldType, (short)10);
/*  987 */         cfw.addALoad(1);
/*  988 */         cfw.addALoad(0);
/*  989 */         cfw.addPush(reString);
/*  990 */         if (reFlags == null) {
/*  991 */           cfw.add(1);
/*      */         } else {
/*  993 */           cfw.addPush(reFlags);
/*      */         } 
/*  995 */         cfw.addInvoke(185, "org/mozilla/javascript/RegExpProxy", "compileRegExp", "(Lorg/mozilla/javascript/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1002 */         cfw.add(179, this.mainClassName, reFieldName, reFieldType);
/*      */       } 
/*      */     } 
/*      */     
/* 1006 */     cfw.addPush(1);
/* 1007 */     cfw.add(179, this.mainClassName, "_reInitDone", "Z");
/* 1008 */     cfw.add(177);
/* 1009 */     cfw.stopMethod((short)2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void emitTemplateLiteralInit(ClassFileWriter cfw) {
/* 1029 */     int totalTemplateLiteralCount = 0;
/* 1030 */     for (ScriptNode n : this.scriptOrFnNodes) {
/* 1031 */       totalTemplateLiteralCount += n.getTemplateLiteralCount();
/*      */     }
/* 1033 */     if (totalTemplateLiteralCount == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1037 */     cfw.startMethod("_qInit", "()V", (short)10);
/*      */ 
/*      */ 
/*      */     
/* 1041 */     cfw.addField("_qInitDone", "Z", (short)74);
/*      */     
/* 1043 */     cfw.add(178, this.mainClassName, "_qInitDone", "Z");
/* 1044 */     int doInit = cfw.acquireLabel();
/* 1045 */     cfw.add(153, doInit);
/* 1046 */     cfw.add(177);
/* 1047 */     cfw.markLabel(doInit);
/*      */ 
/*      */ 
/*      */     
/* 1051 */     for (ScriptNode n : this.scriptOrFnNodes) {
/* 1052 */       int qCount = n.getTemplateLiteralCount();
/* 1053 */       if (qCount != 0) {
/* 1054 */         String qFieldName = getTemplateLiteralName(n);
/* 1055 */         String qFieldType = "[Ljava/lang/Object;";
/* 1056 */         cfw.addField(qFieldName, qFieldType, (short)10);
/* 1057 */         cfw.addPush(qCount);
/* 1058 */         cfw.add(189, "java/lang/Object");
/* 1059 */         for (int j = 0; j < qCount; j++) {
/* 1060 */           List<TemplateCharacters> strings = n.getTemplateLiteralStrings(j);
/* 1061 */           cfw.add(89);
/* 1062 */           cfw.addPush(j);
/* 1063 */           cfw.addPush(strings.size() * 2);
/* 1064 */           cfw.add(189, "java/lang/String");
/* 1065 */           int k = 0;
/* 1066 */           for (TemplateCharacters s : strings) {
/*      */             
/* 1068 */             cfw.add(89);
/* 1069 */             cfw.addPush(k++);
/* 1070 */             if (s.getValue() != null) {
/* 1071 */               cfw.addPush(s.getValue());
/*      */             } else {
/* 1073 */               cfw.add(1);
/*      */             } 
/* 1075 */             cfw.add(83);
/*      */             
/* 1077 */             cfw.add(89);
/* 1078 */             cfw.addPush(k++);
/* 1079 */             cfw.addPush(s.getRawValue());
/* 1080 */             cfw.add(83);
/*      */           } 
/* 1082 */           cfw.add(83);
/*      */         } 
/* 1084 */         cfw.add(179, this.mainClassName, qFieldName, qFieldType);
/*      */       } 
/*      */     } 
/* 1087 */     cfw.addPush(true);
/* 1088 */     cfw.add(179, this.mainClassName, "_qInitDone", "Z");
/* 1089 */     cfw.add(177);
/* 1090 */     cfw.stopMethod((short)0);
/*      */   }
/*      */   
/*      */   private void emitConstantDudeInitializers(ClassFileWriter cfw) {
/* 1094 */     int N = this.itsConstantListSize;
/* 1095 */     if (N == 0)
/*      */       return; 
/* 1097 */     cfw.startMethod("<clinit>", "()V", (short)24);
/*      */     
/* 1099 */     double[] array = this.itsConstantList;
/* 1100 */     for (int i = 0; i != N; i++) {
/* 1101 */       double num = array[i];
/* 1102 */       String constantName = "_k" + i;
/* 1103 */       String constantType = getStaticConstantWrapperType(num);
/* 1104 */       cfw.addField(constantName, constantType, (short)10);
/* 1105 */       int inum = (int)num;
/* 1106 */       if (inum == num) {
/* 1107 */         cfw.addPush(inum);
/* 1108 */         cfw.addInvoke(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1114 */         cfw.addPush(num);
/* 1115 */         addDoubleWrap(cfw);
/*      */       } 
/* 1117 */       cfw.add(179, this.mainClassName, constantName, constantType);
/*      */     } 
/*      */     
/* 1120 */     cfw.add(177);
/* 1121 */     cfw.stopMethod((short)0);
/*      */   }
/*      */   
/*      */   void pushNumberAsObject(ClassFileWriter cfw, double num) {
/* 1125 */     if (num == 0.0D) {
/* 1126 */       if (1.0D / num > 0.0D) {
/*      */         
/* 1128 */         cfw.add(178, "org/mozilla/javascript/ScriptRuntime", "zeroObj", "Ljava/lang/Double;");
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1134 */         cfw.addPush(num);
/* 1135 */         addDoubleWrap(cfw);
/*      */       } 
/*      */     } else {
/* 1138 */       if (num == 1.0D) {
/* 1139 */         cfw.add(178, "org/mozilla/javascript/optimizer/OptRuntime", "oneObj", "Ljava/lang/Double;");
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/* 1146 */       if (num == -1.0D) {
/* 1147 */         cfw.add(178, "org/mozilla/javascript/optimizer/OptRuntime", "minusOneObj", "Ljava/lang/Double;");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1153 */       else if (Double.isNaN(num)) {
/* 1154 */         cfw.add(178, "org/mozilla/javascript/ScriptRuntime", "NaNobj", "Ljava/lang/Double;");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1160 */       else if (this.itsConstantListSize >= 2000) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1165 */         cfw.addPush(num);
/* 1166 */         addDoubleWrap(cfw);
/*      */       } else {
/*      */         
/* 1169 */         int N = this.itsConstantListSize;
/* 1170 */         int index = 0;
/* 1171 */         if (N == 0) {
/* 1172 */           this.itsConstantList = new double[64];
/*      */         } else {
/* 1174 */           double[] array = this.itsConstantList;
/* 1175 */           while (index != N && array[index] != num) {
/* 1176 */             index++;
/*      */           }
/* 1178 */           if (N == array.length) {
/* 1179 */             array = new double[N * 2];
/* 1180 */             System.arraycopy(this.itsConstantList, 0, array, 0, N);
/* 1181 */             this.itsConstantList = array;
/*      */           } 
/*      */         } 
/* 1184 */         if (index == N) {
/* 1185 */           this.itsConstantList[N] = num;
/* 1186 */           this.itsConstantListSize = N + 1;
/*      */         } 
/* 1188 */         String constantName = "_k" + index;
/* 1189 */         String constantType = getStaticConstantWrapperType(num);
/* 1190 */         cfw.add(178, this.mainClassName, constantName, constantType);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private static void addDoubleWrap(ClassFileWriter cfw) {
/* 1195 */     cfw.addInvoke(184, "org/mozilla/javascript/optimizer/OptRuntime", "wrapDouble", "(D)Ljava/lang/Double;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getStaticConstantWrapperType(double num) {
/* 1203 */     int inum = (int)num;
/* 1204 */     if (inum == num) {
/* 1205 */       return "Ljava/lang/Integer;";
/*      */     }
/* 1207 */     return "Ljava/lang/Double;";
/*      */   }
/*      */   
/*      */   static void pushUndefined(ClassFileWriter cfw) {
/* 1211 */     cfw.add(178, "org/mozilla/javascript/Undefined", "instance", "Ljava/lang/Object;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getIndex(ScriptNode n) {
/* 1219 */     return this.scriptOrFnIndexes.getExisting(n);
/*      */   }
/*      */   
/*      */   String getDirectCtorName(ScriptNode n) {
/* 1223 */     return "_n" + getIndex(n);
/*      */   }
/*      */   
/*      */   String getBodyMethodName(ScriptNode n) {
/* 1227 */     return "_c_" + cleanName(n) + "_" + getIndex(n);
/*      */   }
/*      */ 
/*      */   
/*      */   String cleanName(ScriptNode n) {
/* 1232 */     String result = "";
/* 1233 */     if (n instanceof FunctionNode) {
/* 1234 */       Name name = ((FunctionNode)n).getFunctionName();
/* 1235 */       if (name == null) {
/* 1236 */         result = "anonymous";
/*      */       } else {
/* 1238 */         result = name.getIdentifier();
/*      */       } 
/*      */     } else {
/* 1241 */       result = "script";
/*      */     } 
/* 1243 */     return result;
/*      */   }
/*      */   
/*      */   String getBodyMethodSignature(ScriptNode n) {
/* 1247 */     StringBuilder sb = new StringBuilder();
/* 1248 */     sb.append('(');
/* 1249 */     sb.append(this.mainClassSignature);
/* 1250 */     sb.append("Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */     
/* 1254 */     if (n.getType() == 113) {
/* 1255 */       OptFunctionNode ofn = OptFunctionNode.get(n);
/* 1256 */       if (ofn.isTargetOfDirectCall()) {
/* 1257 */         int pCount = ofn.fnode.getParamCount();
/* 1258 */         for (int i = 0; i != pCount; i++) {
/* 1259 */           sb.append("Ljava/lang/Object;D");
/*      */         }
/*      */       } 
/*      */     } 
/* 1263 */     sb.append("[Ljava/lang/Object;)Ljava/lang/Object;");
/* 1264 */     return sb.toString();
/*      */   }
/*      */   
/*      */   String getFunctionInitMethodName(OptFunctionNode ofn) {
/* 1268 */     return "_i" + getIndex((ScriptNode)ofn.fnode);
/*      */   }
/*      */   
/*      */   String getCompiledRegexpName(ScriptNode n, int regexpIndex) {
/* 1272 */     return "_re" + getIndex(n) + "_" + regexpIndex;
/*      */   }
/*      */   
/*      */   String getTemplateLiteralName(ScriptNode n) {
/* 1276 */     return "_q" + getIndex(n);
/*      */   }
/*      */   
/*      */   static RuntimeException badTree() {
/* 1280 */     throw new RuntimeException("Bad tree in codegen");
/*      */   }
/*      */   
/*      */   public void setMainMethodClass(String className) {
/* 1284 */     this.mainMethodClass = className;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1305 */   private static final Object globalLock = new Object();
/*      */   
/*      */   private static int globalSerialClassCounter;
/*      */   
/*      */   private CompilerEnvirons compilerEnv;
/*      */   
/*      */   private ObjArray directCallTargets;
/*      */   ScriptNode[] scriptOrFnNodes;
/*      */   private ObjToIntMap scriptOrFnIndexes;
/* 1314 */   private String mainMethodClass = "org.mozilla.javascript.optimizer.OptRuntime";
/*      */   String mainClassName;
/*      */   String mainClassSignature;
/*      */   private double[] itsConstantList;
/*      */   private int itsConstantListSize;
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\optimizer\Codegen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */