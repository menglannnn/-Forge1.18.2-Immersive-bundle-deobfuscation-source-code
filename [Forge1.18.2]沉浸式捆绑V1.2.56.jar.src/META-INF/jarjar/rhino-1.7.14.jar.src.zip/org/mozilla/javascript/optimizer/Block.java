/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.Map;
/*     */ import org.mozilla.javascript.Node;
/*     */ import org.mozilla.javascript.ObjArray;
/*     */ import org.mozilla.javascript.ObjToIntMap;
/*     */ 
/*     */ class Block {
/*     */   private Block[] itsSuccessors;
/*     */   private Block[] itsPredecessors;
/*     */   private int itsStartNodeIndex;
/*     */   private int itsEndNodeIndex;
/*     */   private int itsBlockID;
/*     */   private BitSet itsLiveOnEntrySet;
/*     */   private BitSet itsLiveOnExitSet;
/*     */   private BitSet itsUseBeforeDefSet;
/*     */   private BitSet itsNotDefSet;
/*     */   static final boolean DEBUG = false;
/*     */   private static int debug_blockCount;
/*     */   
/*     */   private static class FatBlock { private static Block[] reduceToArray(ObjToIntMap map) {
/*  23 */       Block[] result = null;
/*  24 */       if (!map.isEmpty()) {
/*  25 */         result = new Block[map.size()];
/*  26 */         int i = 0;
/*  27 */         ObjToIntMap.Iterator iter = map.newIterator();
/*  28 */         iter.start(); for (; !iter.done(); iter.next()) {
/*  29 */           FatBlock fb = (FatBlock)iter.getKey();
/*  30 */           result[i++] = fb.realBlock;
/*     */         } 
/*     */       } 
/*  33 */       return result;
/*     */     }
/*     */     
/*     */     void addSuccessor(FatBlock b) {
/*  37 */       this.successors.put(b, 0);
/*     */     }
/*     */     
/*     */     void addPredecessor(FatBlock b) {
/*  41 */       this.predecessors.put(b, 0);
/*     */     }
/*     */     
/*     */     Block[] getSuccessors() {
/*  45 */       return reduceToArray(this.successors);
/*     */     }
/*     */     
/*     */     Block[] getPredecessors() {
/*  49 */       return reduceToArray(this.predecessors);
/*     */     }
/*     */ 
/*     */     
/*  53 */     private ObjToIntMap successors = new ObjToIntMap();
/*     */     
/*  55 */     private ObjToIntMap predecessors = new ObjToIntMap();
/*     */     Block realBlock;
/*     */     
/*     */     private FatBlock() {} }
/*     */   
/*     */   Block(int startNodeIndex, int endNodeIndex) {
/*  61 */     this.itsStartNodeIndex = startNodeIndex;
/*  62 */     this.itsEndNodeIndex = endNodeIndex;
/*     */   }
/*     */   
/*     */   static void runFlowAnalyzes(OptFunctionNode fn, Node[] statementNodes) {
/*  66 */     int paramCount = fn.fnode.getParamCount();
/*  67 */     int varCount = fn.fnode.getParamAndVarCount();
/*  68 */     int[] varTypes = new int[varCount];
/*     */     int i;
/*  70 */     for (i = 0; i != paramCount; i++) {
/*  71 */       varTypes[i] = 3;
/*     */     }
/*     */ 
/*     */     
/*  75 */     for (i = paramCount; i != varCount; i++) {
/*  76 */       varTypes[i] = 0;
/*     */     }
/*     */     
/*  79 */     Block[] theBlocks = buildBlocks(statementNodes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     reachingDefDataFlow(fn, statementNodes, theBlocks, varTypes);
/*  94 */     typeFlow(fn, statementNodes, theBlocks, varTypes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     for (int j = paramCount; j != varCount; j++) {
/* 108 */       if (varTypes[j] == 1) {
/* 109 */         fn.setIsNumberVar(j);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static Block[] buildBlocks(Node[] statementNodes) {
/* 116 */     Map<Node, FatBlock> theTargetBlocks = new HashMap<>();
/* 117 */     ObjArray theBlocks = new ObjArray();
/*     */ 
/*     */     
/* 120 */     int beginNodeIndex = 0;
/*     */     int i;
/* 122 */     for (i = 0; i < statementNodes.length; i++) {
/* 123 */       FatBlock fb; switch (statementNodes[i].getType()) {
/*     */         
/*     */         case 135:
/* 126 */           if (i != beginNodeIndex) {
/* 127 */             FatBlock fatBlock = newFatBlock(beginNodeIndex, i - 1);
/* 128 */             if (statementNodes[beginNodeIndex].getType() == 135) {
/* 129 */               theTargetBlocks.put(statementNodes[beginNodeIndex], fatBlock);
/*     */             }
/* 131 */             theBlocks.add(fatBlock);
/*     */             
/* 133 */             beginNodeIndex = i;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/* 141 */           fb = newFatBlock(beginNodeIndex, i);
/* 142 */           if (statementNodes[beginNodeIndex].getType() == 135) {
/* 143 */             theTargetBlocks.put(statementNodes[beginNodeIndex], fb);
/*     */           }
/* 145 */           theBlocks.add(fb);
/*     */           
/* 147 */           beginNodeIndex = i + 1;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 153 */     if (beginNodeIndex != statementNodes.length) {
/* 154 */       FatBlock fb = newFatBlock(beginNodeIndex, statementNodes.length - 1);
/* 155 */       if (statementNodes[beginNodeIndex].getType() == 135) {
/* 156 */         theTargetBlocks.put(statementNodes[beginNodeIndex], fb);
/*     */       }
/* 158 */       theBlocks.add(fb);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 163 */     for (i = 0; i < theBlocks.size(); i++) {
/* 164 */       FatBlock fb = (FatBlock)theBlocks.get(i);
/*     */       
/* 166 */       Node blockEndNode = statementNodes[fb.realBlock.itsEndNodeIndex];
/* 167 */       int blockEndNodeType = blockEndNode.getType();
/*     */       
/* 169 */       if (blockEndNodeType != 5 && i < theBlocks.size() - 1) {
/* 170 */         FatBlock fallThruTarget = (FatBlock)theBlocks.get(i + 1);
/* 171 */         fb.addSuccessor(fallThruTarget);
/* 172 */         fallThruTarget.addPredecessor(fb);
/*     */       } 
/*     */       
/* 175 */       if (blockEndNodeType == 7 || blockEndNodeType == 6 || blockEndNodeType == 5) {
/*     */ 
/*     */         
/* 178 */         Node target = ((Jump)blockEndNode).target;
/* 179 */         FatBlock branchTargetBlock = theTargetBlocks.get(target);
/* 180 */         target.putProp(6, branchTargetBlock.realBlock);
/* 181 */         fb.addSuccessor(branchTargetBlock);
/* 182 */         branchTargetBlock.addPredecessor(fb);
/*     */       } 
/*     */     } 
/*     */     
/* 186 */     Block[] result = new Block[theBlocks.size()];
/*     */     
/* 188 */     for (int j = 0; j < theBlocks.size(); j++) {
/* 189 */       FatBlock fb = (FatBlock)theBlocks.get(j);
/* 190 */       Block b = fb.realBlock;
/* 191 */       b.itsSuccessors = fb.getSuccessors();
/* 192 */       b.itsPredecessors = fb.getPredecessors();
/* 193 */       b.itsBlockID = j;
/* 194 */       result[j] = b;
/*     */     } 
/*     */     
/* 197 */     return result;
/*     */   }
/*     */   
/*     */   private static FatBlock newFatBlock(int startNodeIndex, int endNodeIndex) {
/* 201 */     FatBlock fb = new FatBlock();
/* 202 */     fb.realBlock = new Block(startNodeIndex, endNodeIndex);
/* 203 */     return fb;
/*     */   }
/*     */   
/*     */   private static String toString(Block[] blockList, Node[] statementNodes) {
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void reachingDefDataFlow(OptFunctionNode fn, Node[] statementNodes, Block[] theBlocks, int[] varTypes) {
/* 255 */     for (int i = 0; i < theBlocks.length; i++) {
/* 256 */       theBlocks[i].initLiveOnEntrySets(fn, statementNodes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     boolean[] visit = new boolean[theBlocks.length];
/* 264 */     boolean[] doneOnce = new boolean[theBlocks.length];
/* 265 */     int vIndex = theBlocks.length - 1;
/* 266 */     boolean needRescan = false;
/* 267 */     visit[vIndex] = true; while (true) {
/*     */       int j;
/* 269 */       if (visit[vIndex] || !doneOnce[vIndex]) {
/* 270 */         doneOnce[vIndex] = true;
/* 271 */         visit[vIndex] = false;
/* 272 */         if (theBlocks[vIndex].doReachedUseDataFlow()) {
/* 273 */           Block[] pred = (theBlocks[vIndex]).itsPredecessors;
/* 274 */           if (pred != null) {
/* 275 */             for (int k = 0; k < pred.length; k++) {
/* 276 */               int index = (pred[k]).itsBlockID;
/* 277 */               visit[index] = true;
/* 278 */               j = needRescan | ((index > vIndex) ? 1 : 0);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/* 283 */       if (vIndex == 0) {
/* 284 */         if (j != 0) {
/* 285 */           vIndex = theBlocks.length - 1;
/* 286 */           j = 0;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       } 
/* 291 */       vIndex--;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 300 */     theBlocks[0].markAnyTypeVariables(varTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void typeFlow(OptFunctionNode fn, Node[] statementNodes, Block[] theBlocks, int[] varTypes) {
/* 305 */     boolean[] visit = new boolean[theBlocks.length];
/* 306 */     boolean[] doneOnce = new boolean[theBlocks.length];
/* 307 */     int vIndex = 0;
/* 308 */     boolean needRescan = false;
/* 309 */     visit[vIndex] = true; while (true) {
/*     */       int i;
/* 311 */       if (visit[vIndex] || !doneOnce[vIndex]) {
/* 312 */         doneOnce[vIndex] = true;
/* 313 */         visit[vIndex] = false;
/* 314 */         if (theBlocks[vIndex].doTypeFlow(fn, statementNodes, varTypes)) {
/* 315 */           Block[] succ = (theBlocks[vIndex]).itsSuccessors;
/* 316 */           if (succ != null) {
/* 317 */             for (int j = 0; j < succ.length; j++) {
/* 318 */               int index = (succ[j]).itsBlockID;
/* 319 */               visit[index] = true;
/* 320 */               i = needRescan | ((index < vIndex) ? 1 : 0);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/* 325 */       if (vIndex == theBlocks.length - 1) {
/* 326 */         if (i != 0) {
/* 327 */           vIndex = 0;
/* 328 */           i = 0;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       } 
/* 333 */       vIndex++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean assignType(int[] varTypes, int index, int type) {
/* 339 */     int prev = varTypes[index];
/* 340 */     varTypes[index] = varTypes[index] | type; return (prev != (varTypes[index] | type));
/*     */   }
/*     */   
/*     */   private void markAnyTypeVariables(int[] varTypes) {
/* 344 */     for (int i = 0; i != varTypes.length; i++) {
/* 345 */       if (this.itsLiveOnEntrySet.get(i)) {
/* 346 */         assignType(varTypes, i, 3);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void lookForVariableAccess(OptFunctionNode fn, Node n) {
/*     */     int i;
/*     */     Node node1, lhs;
/*     */     int varIndex;
/*     */     Node rhs;
/* 360 */     switch (n.getType()) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 141:
/* 365 */         i = fn.fnode.getIndexForNameNode(n);
/* 366 */         if (i > -1 && !this.itsNotDefSet.get(i)) {
/* 367 */           this.itsUseBeforeDefSet.set(i);
/*     */         }
/*     */         return;
/*     */       
/*     */       case 110:
/*     */       case 111:
/* 373 */         node1 = n.getFirstChild();
/* 374 */         if (node1.getType() == 55) {
/* 375 */           int j = fn.getVarIndex(node1);
/* 376 */           if (!this.itsNotDefSet.get(j)) this.itsUseBeforeDefSet.set(j); 
/* 377 */           this.itsNotDefSet.set(j);
/*     */         } else {
/* 379 */           lookForVariableAccess(fn, node1);
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case 56:
/*     */       case 160:
/* 386 */         lhs = n.getFirstChild();
/* 387 */         rhs = lhs.getNext();
/* 388 */         lookForVariableAccess(fn, rhs);
/* 389 */         this.itsNotDefSet.set(fn.getVarIndex(n));
/*     */         return;
/*     */ 
/*     */       
/*     */       case 55:
/* 394 */         varIndex = fn.getVarIndex(n);
/* 395 */         if (!this.itsNotDefSet.get(varIndex)) this.itsUseBeforeDefSet.set(varIndex);
/*     */         
/*     */         return;
/*     */     } 
/* 399 */     Node child = n.getFirstChild();
/* 400 */     while (child != null) {
/* 401 */       lookForVariableAccess(fn, child);
/* 402 */       child = child.getNext();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initLiveOnEntrySets(OptFunctionNode fn, Node[] statementNodes) {
/* 414 */     int listLength = fn.getVarCount();
/* 415 */     this.itsUseBeforeDefSet = new BitSet(listLength);
/* 416 */     this.itsNotDefSet = new BitSet(listLength);
/* 417 */     this.itsLiveOnEntrySet = new BitSet(listLength);
/* 418 */     this.itsLiveOnExitSet = new BitSet(listLength);
/* 419 */     for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
/* 420 */       Node n = statementNodes[i];
/* 421 */       lookForVariableAccess(fn, n);
/*     */     } 
/* 423 */     this.itsNotDefSet.flip(0, listLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean doReachedUseDataFlow() {
/* 433 */     this.itsLiveOnExitSet.clear();
/* 434 */     if (this.itsSuccessors != null) {
/* 435 */       for (int i = 0; i < this.itsSuccessors.length; i++) {
/* 436 */         this.itsLiveOnExitSet.or((this.itsSuccessors[i]).itsLiveOnEntrySet);
/*     */       }
/*     */     }
/* 439 */     return updateEntrySet(this.itsLiveOnEntrySet, this.itsLiveOnExitSet, this.itsUseBeforeDefSet, this.itsNotDefSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean updateEntrySet(BitSet entrySet, BitSet exitSet, BitSet useBeforeDef, BitSet notDef) {
/* 446 */     int card = entrySet.cardinality();
/* 447 */     entrySet.or(exitSet);
/* 448 */     entrySet.and(notDef);
/* 449 */     entrySet.or(useBeforeDef);
/* 450 */     return (entrySet.cardinality() != card); } private static int findExpressionType(OptFunctionNode fn, Node n, int[] varTypes) { Node node1;
/*     */     Node ifTrue;
/*     */     Node child;
/*     */     int i;
/*     */     Node ifFalse;
/*     */     int lType;
/*     */     int j;
/*     */     int ifTrueType;
/*     */     int rType;
/*     */     int ifFalseType;
/* 460 */     switch (n.getType()) {
/*     */       case 40:
/* 462 */         return 1;
/*     */       
/*     */       case 30:
/*     */       case 38:
/*     */       case 71:
/* 467 */         return 3;
/*     */       
/*     */       case 33:
/*     */       case 36:
/*     */       case 39:
/*     */       case 43:
/* 473 */         return 3;
/*     */       
/*     */       case 55:
/* 476 */         return varTypes[fn.getVarIndex(n)];
/*     */       
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/*     */       case 18:
/*     */       case 19:
/*     */       case 20:
/*     */       case 22:
/*     */       case 23:
/*     */       case 24:
/*     */       case 25:
/*     */       case 27:
/*     */       case 28:
/*     */       case 29:
/*     */       case 75:
/*     */       case 110:
/*     */       case 111:
/* 494 */         return 1;
/*     */ 
/*     */       
/*     */       case 130:
/* 498 */         return 3;
/*     */ 
/*     */       
/*     */       case 12:
/*     */       case 13:
/*     */       case 14:
/*     */       case 15:
/*     */       case 16:
/*     */       case 17:
/*     */       case 26:
/*     */       case 31:
/*     */       case 44:
/*     */       case 45:
/*     */       case 46:
/*     */       case 47:
/*     */       case 52:
/*     */       case 53:
/*     */       case 70:
/* 516 */         return 3;
/*     */ 
/*     */       
/*     */       case 32:
/*     */       case 41:
/*     */       case 141:
/* 522 */         return 3;
/*     */       
/*     */       case 42:
/*     */       case 48:
/*     */       case 66:
/*     */       case 67:
/*     */       case 83:
/*     */       case 161:
/*     */       case 170:
/* 531 */         return 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 21:
/* 538 */         node1 = n.getFirstChild();
/* 539 */         i = findExpressionType(fn, node1, varTypes);
/* 540 */         j = findExpressionType(fn, node1.getNext(), varTypes);
/* 541 */         return i | j;
/*     */ 
/*     */ 
/*     */       
/*     */       case 106:
/* 546 */         ifTrue = n.getFirstChild().getNext();
/* 547 */         ifFalse = ifTrue.getNext();
/* 548 */         ifTrueType = findExpressionType(fn, ifTrue, varTypes);
/* 549 */         ifFalseType = findExpressionType(fn, ifFalse, varTypes);
/* 550 */         return ifTrueType | ifFalseType;
/*     */ 
/*     */       
/*     */       case 8:
/*     */       case 35:
/*     */       case 37:
/*     */       case 56:
/*     */       case 92:
/*     */       case 160:
/* 559 */         return findExpressionType(fn, n.getLastChild(), varTypes);
/*     */ 
/*     */       
/*     */       case 108:
/*     */       case 109:
/* 564 */         child = n.getFirstChild();
/* 565 */         lType = findExpressionType(fn, child, varTypes);
/* 566 */         rType = findExpressionType(fn, child.getNext(), varTypes);
/* 567 */         return lType | rType;
/*     */     } 
/*     */ 
/*     */     
/* 571 */     return 3; }
/*     */    private static boolean findDefPoints(OptFunctionNode fn, Node n, int[] varTypes) {
/*     */     Node rValue;
/*     */     int theType, i;
/* 575 */     boolean result = false;
/* 576 */     Node first = n.getFirstChild();
/* 577 */     for (Node next = first; next != null; next = next.getNext()) {
/* 578 */       result |= findDefPoints(fn, next, varTypes);
/*     */     }
/* 580 */     switch (n.getType()) {
/*     */       case 110:
/*     */       case 111:
/* 583 */         if (first.getType() == 55) {
/*     */           
/* 585 */           int j = fn.getVarIndex(first);
/* 586 */           if (!fn.fnode.getParamAndVarConst()[j]) {
/* 587 */             result |= assignType(varTypes, j, 1);
/*     */           }
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 56:
/*     */       case 160:
/* 594 */         rValue = first.getNext();
/* 595 */         theType = findExpressionType(fn, rValue, varTypes);
/* 596 */         i = fn.getVarIndex(n);
/* 597 */         if (n.getType() != 56 || !fn.fnode.getParamAndVarConst()[i]) {
/* 598 */           result |= assignType(varTypes, i, theType);
/*     */         }
/*     */         break;
/*     */     } 
/*     */     
/* 603 */     return result;
/*     */   }
/*     */   
/*     */   private boolean doTypeFlow(OptFunctionNode fn, Node[] statementNodes, int[] varTypes) {
/* 607 */     boolean changed = false;
/*     */     
/* 609 */     for (int i = this.itsStartNodeIndex; i <= this.itsEndNodeIndex; i++) {
/* 610 */       Node n = statementNodes[i];
/* 611 */       if (n != null) {
/* 612 */         changed |= findDefPoints(fn, n, varTypes);
/*     */       }
/*     */     } 
/*     */     
/* 616 */     return changed;
/*     */   }
/*     */   
/*     */   private void printLiveOnEntrySet(OptFunctionNode fn) {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\optimizer\Block.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */