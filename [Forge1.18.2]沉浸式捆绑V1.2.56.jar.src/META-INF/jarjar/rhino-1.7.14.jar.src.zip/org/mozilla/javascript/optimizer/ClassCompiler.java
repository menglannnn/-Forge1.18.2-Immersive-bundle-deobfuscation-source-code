/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import org.mozilla.javascript.CompilerEnvirons;
/*     */ import org.mozilla.javascript.IRFactory;
/*     */ import org.mozilla.javascript.JavaAdapter;
/*     */ import org.mozilla.javascript.ObjToIntMap;
/*     */ import org.mozilla.javascript.Parser;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.ast.AstRoot;
/*     */ import org.mozilla.javascript.ast.FunctionNode;
/*     */ import org.mozilla.javascript.ast.ScriptNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassCompiler
/*     */ {
/*     */   private String mainMethodClassName;
/*     */   private CompilerEnvirons compilerEnv;
/*     */   private Class<?> targetExtends;
/*     */   private Class<?>[] targetImplements;
/*     */   
/*     */   public ClassCompiler(CompilerEnvirons compilerEnv) {
/*  34 */     if (compilerEnv == null) throw new IllegalArgumentException(); 
/*  35 */     this.compilerEnv = compilerEnv;
/*  36 */     this.mainMethodClassName = "org.mozilla.javascript.optimizer.OptRuntime";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMainMethodClass(String className) {
/*  50 */     this.mainMethodClassName = className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMainMethodClass() {
/*  59 */     return this.mainMethodClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompilerEnvirons getCompilerEnv() {
/*  67 */     return this.compilerEnv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getTargetExtends() {
/*  75 */     return this.targetExtends;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetExtends(Class<?> extendsClass) {
/*  85 */     this.targetExtends = extendsClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] getTargetImplements() {
/*  93 */     return (this.targetImplements == null) ? null : (Class[])this.targetImplements.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetImplements(Class<?>[] implementsClasses) {
/* 104 */     this.targetImplements = (implementsClasses == null) ? null : (Class[])implementsClasses.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String makeAuxiliaryClassName(String mainClassName, String auxMarker) {
/* 117 */     return mainClassName + auxMarker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] compileToClassFiles(String source, String sourceLocation, int lineno, String mainClassName) {
/*     */     String scriptClassName;
/* 138 */     Parser p = new Parser(this.compilerEnv);
/* 139 */     AstRoot ast = p.parse(source, sourceLocation, lineno);
/* 140 */     IRFactory irf = new IRFactory(this.compilerEnv);
/* 141 */     ScriptNode tree = irf.transformTree(ast);
/*     */ 
/*     */     
/* 144 */     irf = null;
/* 145 */     ast = null;
/* 146 */     p = null;
/*     */     
/* 148 */     Class<?> superClass = getTargetExtends();
/* 149 */     Class<?>[] interfaces = getTargetImplements();
/*     */     
/* 151 */     boolean isPrimary = (interfaces == null && superClass == null);
/* 152 */     if (isPrimary) {
/* 153 */       scriptClassName = mainClassName;
/*     */     } else {
/* 155 */       scriptClassName = makeAuxiliaryClassName(mainClassName, "1");
/*     */     } 
/*     */     
/* 158 */     Codegen codegen = new Codegen();
/* 159 */     codegen.setMainMethodClass(this.mainMethodClassName);
/*     */     
/* 161 */     byte[] scriptClassBytes = codegen.compileToClassFile(this.compilerEnv, scriptClassName, tree, tree
/* 162 */         .getEncodedSource(), false);
/*     */ 
/*     */     
/* 165 */     if (isPrimary) {
/* 166 */       return new Object[] { scriptClassName, scriptClassBytes };
/*     */     }
/* 168 */     int functionCount = tree.getFunctionCount();
/* 169 */     ObjToIntMap functionNames = new ObjToIntMap(functionCount);
/* 170 */     for (int i = 0; i != functionCount; i++) {
/* 171 */       FunctionNode ofn = tree.getFunctionNode(i);
/* 172 */       String name = ofn.getName();
/* 173 */       if (name != null && name.length() != 0) {
/* 174 */         functionNames.put(name, ofn.getParamCount());
/*     */       }
/*     */     } 
/* 177 */     if (superClass == null) {
/* 178 */       superClass = ScriptRuntime.ObjectClass;
/*     */     }
/*     */     
/* 181 */     byte[] mainClassBytes = JavaAdapter.createAdapterCode(functionNames, mainClassName, superClass, interfaces, scriptClassName);
/*     */ 
/*     */ 
/*     */     
/* 185 */     return new Object[] { mainClassName, mainClassBytes, scriptClassName, scriptClassBytes };
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\optimizer\ClassCompiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */