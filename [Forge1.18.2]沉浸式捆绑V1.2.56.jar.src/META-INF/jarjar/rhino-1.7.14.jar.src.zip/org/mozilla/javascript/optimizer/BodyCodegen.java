/*      */ package org.mozilla.javascript.optimizer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import org.mozilla.javascript.CompilerEnvirons;
/*      */ import org.mozilla.javascript.Context;
/*      */ import org.mozilla.javascript.Kit;
/*      */ import org.mozilla.javascript.Node;
/*      */ import org.mozilla.javascript.Token;
/*      */ import org.mozilla.javascript.ast.FunctionNode;
/*      */ import org.mozilla.javascript.ast.Jump;
/*      */ import org.mozilla.javascript.ast.ScriptNode;
/*      */ 
/*      */ class BodyCodegen {
/*      */   private static final int JAVASCRIPT_EXCEPTION = 0;
/*      */   private static final int EVALUATOR_EXCEPTION = 1;
/*      */   private static final int ECMAERROR_EXCEPTION = 2;
/*      */   private static final int THROWABLE_EXCEPTION = 3;
/*      */   private static final int FINALLY_EXCEPTION = 4;
/*      */   private static final int EXCEPTION_MAX = 5;
/*      */   
/*      */   void generateBodyCode() {
/*      */     ScriptNode scriptNode;
/*   28 */     this.isGenerator = Codegen.isGenerator(this.scriptOrFn);
/*      */ 
/*      */     
/*   31 */     initBodyGeneration();
/*      */     
/*   33 */     if (this.isGenerator) {
/*      */ 
/*      */       
/*   36 */       String type = "(" + this.codegen.mainClassSignature + "Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/Object;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   43 */       this.cfw.startMethod(this.codegen
/*   44 */           .getBodyMethodName(this.scriptOrFn) + "_gen", type, (short)10);
/*      */     }
/*      */     else {
/*      */       
/*   48 */       this.cfw.startMethod(this.codegen
/*   49 */           .getBodyMethodName(this.scriptOrFn), this.codegen
/*   50 */           .getBodyMethodSignature(this.scriptOrFn), (short)10);
/*      */     } 
/*      */ 
/*      */     
/*   54 */     generatePrologue();
/*      */     
/*   56 */     if (this.fnCurrent != null) {
/*   57 */       Node treeTop = this.scriptOrFn.getLastChild();
/*      */     } else {
/*   59 */       scriptNode = this.scriptOrFn;
/*      */     } 
/*   61 */     generateStatement((Node)scriptNode);
/*   62 */     generateEpilogue();
/*      */     
/*   64 */     this.cfw.stopMethod((short)(this.localsMax + 1));
/*      */     
/*   66 */     if (this.isGenerator)
/*      */     {
/*      */       
/*   69 */       generateGenerator();
/*      */     }
/*      */     
/*   72 */     if (this.literals != null)
/*      */     {
/*   74 */       for (int i = 0; i < this.literals.size(); i++) {
/*   75 */         Node node = this.literals.get(i);
/*   76 */         int type = node.getType();
/*   77 */         switch (type) {
/*      */           case 67:
/*   79 */             generateObjectLiteralFactory(node, i + 1);
/*      */             break;
/*      */           case 66:
/*   82 */             generateArrayLiteralFactory(node, i + 1);
/*      */             break;
/*      */           default:
/*   85 */             Kit.codeBug(Token.typeToName(type));
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateGenerator() {
/*   94 */     this.cfw.startMethod(this.codegen
/*   95 */         .getBodyMethodName(this.scriptOrFn), this.codegen
/*   96 */         .getBodyMethodSignature(this.scriptOrFn), (short)10);
/*      */ 
/*      */     
/*   99 */     initBodyGeneration();
/*  100 */     this.argsLocal = this.firstFreeLocal = (short)(this.firstFreeLocal + 1);
/*  101 */     this.localsMax = this.firstFreeLocal;
/*      */ 
/*      */     
/*  104 */     if (this.fnCurrent != null) {
/*      */ 
/*      */       
/*  107 */       this.cfw.addALoad(this.funObjLocal);
/*  108 */       this.cfw.addInvoke(185, "org/mozilla/javascript/Scriptable", "getParentScope", "()Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  113 */       this.cfw.addAStore(this.variableObjectLocal);
/*      */     } 
/*      */ 
/*      */     
/*  117 */     this.cfw.addALoad(this.funObjLocal);
/*  118 */     this.cfw.addALoad(this.variableObjectLocal);
/*  119 */     this.cfw.addALoad(this.argsLocal);
/*  120 */     this.cfw.addPush(this.scriptOrFn.isInStrictMode());
/*  121 */     addScriptRuntimeInvoke("createFunctionActivation", "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Z)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  128 */     this.cfw.addAStore(this.variableObjectLocal);
/*      */ 
/*      */     
/*  131 */     this.cfw.add(187, this.codegen.mainClassName);
/*      */     
/*  133 */     this.cfw.add(89);
/*  134 */     this.cfw.addALoad(this.variableObjectLocal);
/*  135 */     this.cfw.addALoad(this.contextLocal);
/*  136 */     this.cfw.addPush(this.scriptOrFnIndex);
/*  137 */     this.cfw.addInvoke(183, this.codegen.mainClassName, "<init>", "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;I)V");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  143 */     generateNestedFunctionInits();
/*      */ 
/*      */     
/*  146 */     this.cfw.addALoad(this.variableObjectLocal);
/*  147 */     this.cfw.addALoad(this.thisObjLocal);
/*  148 */     this.cfw.addLoadConstant(this.maxLocals);
/*  149 */     this.cfw.addLoadConstant(this.maxStack);
/*  150 */     addOptRuntimeInvoke("createNativeGenerator", "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;II)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  157 */     this.cfw.add(176);
/*  158 */     this.cfw.stopMethod((short)(this.localsMax + 1));
/*      */   }
/*      */   
/*      */   private void generateNestedFunctionInits() {
/*  162 */     int functionCount = this.scriptOrFn.getFunctionCount();
/*  163 */     for (int i = 0; i != functionCount; i++) {
/*  164 */       OptFunctionNode ofn = OptFunctionNode.get(this.scriptOrFn, i);
/*  165 */       if (ofn.fnode.getFunctionType() == 1) {
/*  166 */         visitFunction(ofn, 1);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void initBodyGeneration() {
/*  172 */     this.varRegisters = null;
/*  173 */     if (this.scriptOrFn.getType() == 113) {
/*  174 */       this.fnCurrent = OptFunctionNode.get(this.scriptOrFn);
/*  175 */       this.hasVarsInRegs = !this.fnCurrent.fnode.requiresActivation();
/*  176 */       if (this.hasVarsInRegs) {
/*  177 */         int n = this.fnCurrent.fnode.getParamAndVarCount();
/*  178 */         if (n != 0) {
/*  179 */           this.varRegisters = new short[n];
/*      */         }
/*      */       } 
/*  182 */       this.inDirectCallFunction = this.fnCurrent.isTargetOfDirectCall();
/*  183 */       if (this.inDirectCallFunction && !this.hasVarsInRegs) Codegen.badTree(); 
/*      */     } else {
/*  185 */       this.fnCurrent = null;
/*  186 */       this.hasVarsInRegs = false;
/*  187 */       this.inDirectCallFunction = false;
/*      */     } 
/*      */     
/*  190 */     this.locals = new int[1024];
/*      */     
/*  192 */     this.funObjLocal = 0;
/*  193 */     this.contextLocal = 1;
/*  194 */     this.variableObjectLocal = 2;
/*  195 */     this.thisObjLocal = 3;
/*  196 */     this.localsMax = 4;
/*  197 */     this.firstFreeLocal = 4;
/*      */     
/*  199 */     this.popvLocal = -1;
/*  200 */     this.argsLocal = -1;
/*  201 */     this.itsZeroArgArray = -1;
/*  202 */     this.itsOneArgArray = -1;
/*  203 */     this.epilogueLabel = -1;
/*  204 */     this.enterAreaStartLabel = -1;
/*  205 */     this.generatorStateLocal = -1;
/*      */   }
/*      */   
/*      */   private void generatePrologue() {
/*      */     String debugVariableName;
/*  210 */     if (this.inDirectCallFunction) {
/*  211 */       int directParameterCount = this.scriptOrFn.getParamCount();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  216 */       if (this.firstFreeLocal != 4) Kit.codeBug();  int i;
/*  217 */       for (i = 0; i != directParameterCount; i++) {
/*  218 */         this.varRegisters[i] = this.firstFreeLocal;
/*      */         
/*  220 */         this.firstFreeLocal = (short)(this.firstFreeLocal + 3);
/*      */       } 
/*  222 */       if (!this.fnCurrent.getParameterNumberContext()) {
/*      */         
/*  224 */         this.itsForcedObjectParameters = true;
/*  225 */         for (i = 0; i != directParameterCount; i++) {
/*  226 */           short reg = this.varRegisters[i];
/*  227 */           this.cfw.addALoad(reg);
/*  228 */           this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/*  229 */           int isObjectLabel = this.cfw.acquireLabel();
/*  230 */           this.cfw.add(166, isObjectLabel);
/*  231 */           this.cfw.addDLoad(reg + 1);
/*  232 */           addDoubleWrap();
/*  233 */           this.cfw.addAStore(reg);
/*  234 */           this.cfw.markLabel(isObjectLabel);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  239 */     if (this.fnCurrent != null) {
/*      */       
/*  241 */       this.cfw.addALoad(this.funObjLocal);
/*  242 */       this.cfw.addInvoke(185, "org/mozilla/javascript/Scriptable", "getParentScope", "()Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  247 */       this.cfw.addAStore(this.variableObjectLocal);
/*      */     } 
/*      */ 
/*      */     
/*  251 */     this.argsLocal = this.firstFreeLocal = (short)(this.firstFreeLocal + 1);
/*  252 */     this.localsMax = this.firstFreeLocal;
/*      */ 
/*      */     
/*  255 */     if (this.isGenerator) {
/*      */ 
/*      */       
/*  258 */       this.operationLocal = this.firstFreeLocal = (short)(this.firstFreeLocal + 1);
/*  259 */       this.localsMax = this.firstFreeLocal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  265 */       this.cfw.addALoad(this.thisObjLocal);
/*  266 */       this.generatorStateLocal = this.firstFreeLocal = (short)(this.firstFreeLocal + 1);
/*  267 */       this.localsMax = this.firstFreeLocal;
/*  268 */       this.cfw.add(192, "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState");
/*  269 */       this.cfw.add(89);
/*  270 */       this.cfw.addAStore(this.generatorStateLocal);
/*  271 */       this.cfw.add(180, "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState", "thisObj", "Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  276 */       this.cfw.addAStore(this.thisObjLocal);
/*      */       
/*  278 */       if (this.epilogueLabel == -1) {
/*  279 */         this.epilogueLabel = this.cfw.acquireLabel();
/*      */       }
/*      */       
/*  282 */       List<Node> targets = ((FunctionNode)this.scriptOrFn).getResumptionPoints();
/*  283 */       if (targets != null) {
/*      */         
/*  285 */         generateGetGeneratorResumptionPoint();
/*      */ 
/*      */         
/*  288 */         this.generatorSwitch = this.cfw.addTableSwitch(0, targets.size() + 0);
/*  289 */         generateCheckForThrowOrClose(-1, false, 0);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  295 */     if (this.fnCurrent == null) {
/*  296 */       if (this.scriptOrFn.getRegexpCount() != 0) {
/*  297 */         this.cfw.addALoad(this.contextLocal);
/*  298 */         this.cfw.addInvoke(184, this.codegen.mainClassName, "_reInit", "(Lorg/mozilla/javascript/Context;)V");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  304 */       if (this.scriptOrFn.getTemplateLiteralCount() != 0) {
/*  305 */         this.cfw.addInvoke(184, this.codegen.mainClassName, "_qInit", "()V");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  313 */     if (this.compilerEnv.isGenerateObserverCount()) saveCurrentCodeOffset();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  318 */     if (this.isGenerator)
/*      */       return; 
/*  320 */     if (this.hasVarsInRegs) {
/*      */       
/*  322 */       int parmCount = this.scriptOrFn.getParamCount();
/*  323 */       if (parmCount > 0 && !this.inDirectCallFunction) {
/*      */ 
/*      */         
/*  326 */         this.cfw.addALoad(this.argsLocal);
/*  327 */         this.cfw.add(190);
/*  328 */         this.cfw.addPush(parmCount);
/*  329 */         int label = this.cfw.acquireLabel();
/*  330 */         this.cfw.add(162, label);
/*  331 */         this.cfw.addALoad(this.argsLocal);
/*  332 */         this.cfw.addPush(parmCount);
/*  333 */         addScriptRuntimeInvoke("padArguments", "([Ljava/lang/Object;I)[Ljava/lang/Object;");
/*      */         
/*  335 */         this.cfw.addAStore(this.argsLocal);
/*  336 */         this.cfw.markLabel(label);
/*      */       } 
/*      */       
/*  339 */       int paramCount = this.fnCurrent.fnode.getParamCount();
/*  340 */       int varCount = this.fnCurrent.fnode.getParamAndVarCount();
/*  341 */       boolean[] constDeclarations = this.fnCurrent.fnode.getParamAndVarConst();
/*      */ 
/*      */ 
/*      */       
/*  345 */       short firstUndefVar = -1;
/*  346 */       for (int i = 0; i != varCount; i++) {
/*  347 */         short reg = -1;
/*  348 */         if (i < paramCount) {
/*  349 */           if (!this.inDirectCallFunction) {
/*  350 */             reg = getNewWordLocal();
/*  351 */             this.cfw.addALoad(this.argsLocal);
/*  352 */             this.cfw.addPush(i);
/*  353 */             this.cfw.add(50);
/*  354 */             this.cfw.addAStore(reg);
/*      */           } 
/*  356 */         } else if (this.fnCurrent.isNumberVar(i)) {
/*  357 */           reg = getNewWordPairLocal(constDeclarations[i]);
/*  358 */           this.cfw.addPush(0.0D);
/*  359 */           this.cfw.addDStore(reg);
/*      */         } else {
/*  361 */           reg = getNewWordLocal(constDeclarations[i]);
/*  362 */           if (firstUndefVar == -1) {
/*  363 */             Codegen.pushUndefined(this.cfw);
/*  364 */             firstUndefVar = reg;
/*      */           } else {
/*  366 */             this.cfw.addALoad(firstUndefVar);
/*      */           } 
/*  368 */           this.cfw.addAStore(reg);
/*      */         } 
/*  370 */         if (reg >= 0) {
/*  371 */           if (constDeclarations[i]) {
/*  372 */             this.cfw.addPush(0);
/*  373 */             this.cfw.addIStore(reg + (this.fnCurrent.isNumberVar(i) ? 2 : 1));
/*      */           } 
/*  375 */           this.varRegisters[i] = reg;
/*      */         } 
/*      */ 
/*      */         
/*  379 */         if (this.compilerEnv.isGenerateDebugInfo()) {
/*  380 */           String name = this.fnCurrent.fnode.getParamOrVarName(i);
/*  381 */           String type = this.fnCurrent.isNumberVar(i) ? "D" : "Ljava/lang/Object;";
/*  382 */           int startPC = this.cfw.getCurrentCodeOffset();
/*  383 */           if (reg < 0) {
/*  384 */             reg = this.varRegisters[i];
/*      */           }
/*  386 */           this.cfw.addVariableDescriptor(name, type, startPC, reg);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  395 */     boolean isArrow = false;
/*  396 */     if (this.scriptOrFn instanceof FunctionNode) {
/*  397 */       isArrow = (((FunctionNode)this.scriptOrFn).getFunctionType() == 4);
/*      */     }
/*  399 */     if (this.fnCurrent != null) {
/*  400 */       debugVariableName = "activation";
/*  401 */       this.cfw.addALoad(this.funObjLocal);
/*  402 */       this.cfw.addALoad(this.variableObjectLocal);
/*  403 */       this.cfw.addALoad(this.argsLocal);
/*  404 */       String methodName = isArrow ? "createArrowFunctionActivation" : "createFunctionActivation";
/*      */       
/*  406 */       this.cfw.addPush(this.scriptOrFn.isInStrictMode());
/*  407 */       addScriptRuntimeInvoke(methodName, "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Z)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  414 */       this.cfw.addAStore(this.variableObjectLocal);
/*  415 */       this.cfw.addALoad(this.contextLocal);
/*  416 */       this.cfw.addALoad(this.variableObjectLocal);
/*  417 */       addScriptRuntimeInvoke("enterActivationFunction", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)V");
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  423 */       debugVariableName = "global";
/*  424 */       this.cfw.addALoad(this.funObjLocal);
/*  425 */       this.cfw.addALoad(this.thisObjLocal);
/*  426 */       this.cfw.addALoad(this.contextLocal);
/*  427 */       this.cfw.addALoad(this.variableObjectLocal);
/*  428 */       this.cfw.addPush(0);
/*  429 */       addScriptRuntimeInvoke("initScript", "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Z)V");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  439 */     this.enterAreaStartLabel = this.cfw.acquireLabel();
/*  440 */     this.epilogueLabel = this.cfw.acquireLabel();
/*  441 */     this.cfw.markLabel(this.enterAreaStartLabel);
/*      */     
/*  443 */     generateNestedFunctionInits();
/*      */ 
/*      */     
/*  446 */     if (this.compilerEnv.isGenerateDebugInfo()) {
/*  447 */       this.cfw.addVariableDescriptor(debugVariableName, "Lorg/mozilla/javascript/Scriptable;", this.cfw
/*      */ 
/*      */           
/*  450 */           .getCurrentCodeOffset(), this.variableObjectLocal);
/*      */     }
/*      */ 
/*      */     
/*  454 */     if (this.fnCurrent == null) {
/*      */       
/*  456 */       this.popvLocal = getNewWordLocal();
/*  457 */       Codegen.pushUndefined(this.cfw);
/*  458 */       this.cfw.addAStore(this.popvLocal);
/*      */       
/*  460 */       int linenum = this.scriptOrFn.getEndLineno();
/*  461 */       if (linenum != -1) this.cfw.addLineNumberEntry((short)linenum);
/*      */     
/*      */     } else {
/*  464 */       if (this.fnCurrent.itsContainsCalls0) {
/*  465 */         this.itsZeroArgArray = getNewWordLocal();
/*  466 */         this.cfw.add(178, "org/mozilla/javascript/ScriptRuntime", "emptyArgs", "[Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  471 */         this.cfw.addAStore(this.itsZeroArgArray);
/*      */       } 
/*  473 */       if (this.fnCurrent.itsContainsCalls1) {
/*  474 */         this.itsOneArgArray = getNewWordLocal();
/*  475 */         this.cfw.addPush(1);
/*  476 */         this.cfw.add(189, "java/lang/Object");
/*  477 */         this.cfw.addAStore(this.itsOneArgArray);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void generateGetGeneratorResumptionPoint() {
/*  483 */     this.cfw.addALoad(this.generatorStateLocal);
/*  484 */     this.cfw.add(180, "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState", "resumptionPoint", "I");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateSetGeneratorResumptionPoint(int nextState) {
/*  492 */     this.cfw.addALoad(this.generatorStateLocal);
/*  493 */     this.cfw.addLoadConstant(nextState);
/*  494 */     this.cfw.add(181, "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState", "resumptionPoint", "I");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateGetGeneratorStackState() {
/*  502 */     this.cfw.addALoad(this.generatorStateLocal);
/*  503 */     addOptRuntimeInvoke("getGeneratorStackState", "(Ljava/lang/Object;)[Ljava/lang/Object;");
/*      */   }
/*      */   
/*      */   private void generateEpilogue() {
/*  507 */     if (this.compilerEnv.isGenerateObserverCount()) addInstructionCount(); 
/*  508 */     if (this.isGenerator) {
/*      */       
/*  510 */       Map<Node, int[]> liveLocals = ((FunctionNode)this.scriptOrFn).getLiveLocals();
/*  511 */       if (liveLocals != null) {
/*  512 */         List<Node> nodes = ((FunctionNode)this.scriptOrFn).getResumptionPoints();
/*  513 */         for (int i = 0; i < nodes.size(); i++) {
/*  514 */           Node node = nodes.get(i);
/*  515 */           int[] live = liveLocals.get(node);
/*  516 */           if (live != null) {
/*  517 */             this.cfw.markTableSwitchCase(this.generatorSwitch, getNextGeneratorState(node));
/*  518 */             generateGetGeneratorLocalsState();
/*  519 */             for (int j = 0; j < live.length; j++) {
/*  520 */               this.cfw.add(89);
/*  521 */               this.cfw.addLoadConstant(j);
/*  522 */               this.cfw.add(50);
/*  523 */               this.cfw.addAStore(live[j]);
/*      */             } 
/*  525 */             this.cfw.add(87);
/*  526 */             this.cfw.add(167, getTargetLabel(node));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  532 */       if (this.finallys != null) {
/*  533 */         for (Map.Entry<Node, FinallyReturnPoint> e : this.finallys.entrySet()) {
/*  534 */           if (((Node)e.getKey()).getType() == 129) {
/*  535 */             FinallyReturnPoint ret = e.getValue();
/*      */             
/*  537 */             this.cfw.markLabel(ret.tableLabel, (short)1);
/*      */ 
/*      */             
/*  540 */             int startSwitch = this.cfw.addTableSwitch(0, ret.jsrPoints.size() - 1);
/*  541 */             int c = 0;
/*  542 */             this.cfw.markTableSwitchDefault(startSwitch);
/*  543 */             for (int i = 0; i < ret.jsrPoints.size(); i++) {
/*      */               
/*  545 */               this.cfw.markTableSwitchCase(startSwitch, c);
/*  546 */               this.cfw.add(167, ((Integer)ret.jsrPoints.get(i)).intValue());
/*  547 */               c++;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  554 */     if (this.epilogueLabel != -1) {
/*  555 */       this.cfw.markLabel(this.epilogueLabel);
/*      */     }
/*      */     
/*  558 */     if (this.isGenerator) {
/*  559 */       if (((FunctionNode)this.scriptOrFn).getResumptionPoints() != null) {
/*  560 */         this.cfw.markTableSwitchDefault(this.generatorSwitch);
/*      */       }
/*      */ 
/*      */       
/*  564 */       generateSetGeneratorResumptionPoint(-1);
/*      */ 
/*      */       
/*  567 */       this.cfw.addALoad(this.variableObjectLocal);
/*  568 */       this.cfw.addALoad(this.generatorStateLocal);
/*  569 */       addOptRuntimeInvoke("throwStopIteration", "(Ljava/lang/Object;Ljava/lang/Object;)V");
/*      */       
/*  571 */       Codegen.pushUndefined(this.cfw);
/*  572 */       this.cfw.add(176);
/*      */     }
/*  574 */     else if (this.hasVarsInRegs) {
/*  575 */       this.cfw.add(176);
/*      */     }
/*  577 */     else if (this.fnCurrent == null) {
/*  578 */       this.cfw.addALoad(this.popvLocal);
/*  579 */       this.cfw.add(176);
/*      */     } else {
/*      */       
/*  582 */       generateActivationExit();
/*  583 */       this.cfw.add(176);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  588 */       int finallyHandler = this.cfw.acquireLabel();
/*  589 */       this.cfw.markHandler(finallyHandler);
/*  590 */       short exceptionObject = getNewWordLocal();
/*  591 */       this.cfw.addAStore(exceptionObject);
/*      */ 
/*      */ 
/*      */       
/*  595 */       generateActivationExit();
/*      */       
/*  597 */       this.cfw.addALoad(exceptionObject);
/*  598 */       releaseWordLocal(exceptionObject);
/*      */       
/*  600 */       this.cfw.add(191);
/*      */ 
/*      */       
/*  603 */       this.cfw.addExceptionHandler(this.enterAreaStartLabel, this.epilogueLabel, finallyHandler, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateGetGeneratorLocalsState() {
/*  609 */     this.cfw.addALoad(this.generatorStateLocal);
/*  610 */     addOptRuntimeInvoke("getGeneratorLocalsState", "(Ljava/lang/Object;)[Ljava/lang/Object;");
/*      */   }
/*      */   
/*      */   private void generateSetGeneratorReturnValue() {
/*  614 */     this.cfw.addALoad(this.generatorStateLocal);
/*  615 */     this.cfw.add(95);
/*  616 */     addOptRuntimeInvoke("setGeneratorReturnValue", "(Ljava/lang/Object;Ljava/lang/Object;)V");
/*      */   }
/*      */   
/*      */   private void generateActivationExit() {
/*  620 */     if (this.fnCurrent == null || this.hasVarsInRegs) throw Kit.codeBug(); 
/*  621 */     this.cfw.addALoad(this.contextLocal);
/*  622 */     addScriptRuntimeInvoke("exitActivationFunction", "(Lorg/mozilla/javascript/Context;)V"); } private void generateStatement(Node node) { boolean prevLocal; int fnIndex, local, enumType, i;
/*      */     OptFunctionNode ofn;
/*      */     int scopeIndex, label, t;
/*      */     String name;
/*  626 */     updateLineNumber(node);
/*  627 */     int type = node.getType();
/*  628 */     Node child = node.getFirstChild();
/*  629 */     switch (type) {
/*      */       
/*      */       case 127:
/*      */       case 132:
/*      */       case 133:
/*      */       case 134:
/*      */       case 136:
/*      */       case 140:
/*  637 */         if (this.compilerEnv.isGenerateObserverCount())
/*      */         {
/*      */           
/*  640 */           addInstructionCount(1);
/*      */         }
/*  642 */         while (child != null) {
/*  643 */           generateStatement(child);
/*  644 */           child = child.getNext();
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       case 145:
/*  650 */         prevLocal = this.inLocalBlock;
/*  651 */         this.inLocalBlock = true;
/*  652 */         i = getNewWordLocal();
/*  653 */         if (this.isGenerator) {
/*  654 */           this.cfw.add(1);
/*  655 */           this.cfw.addAStore(i);
/*      */         } 
/*  657 */         node.putIntProp(2, i);
/*  658 */         while (child != null) {
/*  659 */           generateStatement(child);
/*  660 */           child = child.getNext();
/*      */         } 
/*  662 */         releaseWordLocal((short)i);
/*  663 */         node.removeProp(2);
/*  664 */         this.inLocalBlock = prevLocal;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  670 */         fnIndex = node.getExistingIntProp(1);
/*  671 */         ofn = OptFunctionNode.get(this.scriptOrFn, fnIndex);
/*  672 */         t = ofn.fnode.getFunctionType();
/*  673 */         if (t == 3) {
/*  674 */           visitFunction(ofn, t);
/*      */         }
/*  676 */         else if (t != 1) {
/*  677 */           throw Codegen.badTree();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 84:
/*  684 */         visitTryCatchFinally((Jump)node, child);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 57:
/*  690 */         this.cfw.setStackTop((short)0);
/*      */         
/*  692 */         local = getLocalBlockRegister(node);
/*  693 */         scopeIndex = node.getExistingIntProp(14);
/*      */         
/*  695 */         name = child.getString();
/*  696 */         child = child.getNext();
/*  697 */         generateExpression(child, node);
/*  698 */         if (scopeIndex == 0) {
/*  699 */           this.cfw.add(1);
/*      */         } else {
/*      */           
/*  702 */           this.cfw.addALoad(local);
/*      */         } 
/*  704 */         this.cfw.addPush(name);
/*  705 */         this.cfw.addALoad(this.contextLocal);
/*  706 */         this.cfw.addALoad(this.variableObjectLocal);
/*      */         
/*  708 */         addScriptRuntimeInvoke("newCatchScope", "(Ljava/lang/Throwable;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  716 */         this.cfw.addAStore(local);
/*      */ 
/*      */ 
/*      */       
/*      */       case 50:
/*  721 */         generateExpression(child, node);
/*  722 */         if (this.compilerEnv.isGenerateObserverCount()) addInstructionCount(); 
/*  723 */         generateThrowJavaScriptException();
/*      */ 
/*      */       
/*      */       case 51:
/*  727 */         if (this.compilerEnv.isGenerateObserverCount()) addInstructionCount(); 
/*  728 */         this.cfw.addALoad(getLocalBlockRegister(node));
/*  729 */         this.cfw.add(191);
/*      */ 
/*      */       
/*      */       case 4:
/*      */       case 65:
/*  734 */         if (child != null) {
/*  735 */           generateExpression(child, node);
/*  736 */         } else if (type == 4) {
/*  737 */           Codegen.pushUndefined(this.cfw);
/*      */         } else {
/*  739 */           if (this.popvLocal < 0) throw Codegen.badTree(); 
/*  740 */           this.cfw.addALoad(this.popvLocal);
/*      */         } 
/*  742 */         if (this.isGenerator)
/*      */         {
/*  744 */           generateSetGeneratorReturnValue();
/*      */         }
/*      */         
/*  747 */         if (this.compilerEnv.isGenerateObserverCount()) addInstructionCount(); 
/*  748 */         if (this.epilogueLabel == -1) {
/*  749 */           if (!this.hasVarsInRegs) throw Codegen.badTree(); 
/*  750 */           this.epilogueLabel = this.cfw.acquireLabel();
/*      */         } 
/*  752 */         this.cfw.add(167, this.epilogueLabel);
/*      */ 
/*      */       
/*      */       case 118:
/*  756 */         if (this.compilerEnv.isGenerateObserverCount()) addInstructionCount(); 
/*  757 */         visitSwitch((Jump)node, child);
/*      */ 
/*      */       
/*      */       case 2:
/*  761 */         generateExpression(child, node);
/*  762 */         this.cfw.addALoad(this.contextLocal);
/*  763 */         this.cfw.addALoad(this.variableObjectLocal);
/*  764 */         addScriptRuntimeInvoke("enterWith", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  770 */         this.cfw.addAStore(this.variableObjectLocal);
/*  771 */         incReferenceWordLocal(this.variableObjectLocal);
/*      */ 
/*      */       
/*      */       case 3:
/*  775 */         this.cfw.addALoad(this.variableObjectLocal);
/*  776 */         addScriptRuntimeInvoke("leaveWith", "(Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */         
/*  780 */         this.cfw.addAStore(this.variableObjectLocal);
/*  781 */         decReferenceWordLocal(this.variableObjectLocal);
/*      */ 
/*      */       
/*      */       case 58:
/*      */       case 59:
/*      */       case 60:
/*      */       case 61:
/*  788 */         generateExpression(child, node);
/*  789 */         this.cfw.addALoad(this.contextLocal);
/*  790 */         this.cfw.addALoad(this.variableObjectLocal);
/*  791 */         enumType = (type == 58) ? 0 : ((type == 59) ? 1 : ((type == 61) ? 6 : 2));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  799 */         this.cfw.addPush(enumType);
/*  800 */         addScriptRuntimeInvoke("enumInit", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  807 */         this.cfw.addAStore(getLocalBlockRegister(node));
/*      */ 
/*      */       
/*      */       case 137:
/*  811 */         if (child.getType() == 56) {
/*      */ 
/*      */           
/*  814 */           visitSetVar(child, child.getFirstChild(), false);
/*  815 */         } else if (child.getType() == 160) {
/*      */ 
/*      */           
/*  818 */           visitSetConstVar(child, child.getFirstChild(), false);
/*  819 */         } else if (child.getType() == 73 || child
/*  820 */           .getType() == 169) {
/*  821 */           generateYieldPoint(child, false);
/*      */         } else {
/*  823 */           generateExpression(child, node);
/*  824 */           if (node.getIntProp(8, -1) != -1) { this.cfw.add(88); }
/*  825 */           else { this.cfw.add(87); }
/*      */         
/*      */         } 
/*      */       
/*      */       case 138:
/*  830 */         generateExpression(child, node);
/*  831 */         if (this.popvLocal < 0) {
/*  832 */           this.popvLocal = getNewWordLocal();
/*      */         }
/*  834 */         this.cfw.addAStore(this.popvLocal);
/*      */ 
/*      */ 
/*      */       
/*      */       case 135:
/*  839 */         if (this.compilerEnv.isGenerateObserverCount()) addInstructionCount(); 
/*  840 */         label = getTargetLabel(node);
/*  841 */         this.cfw.markLabel(label);
/*  842 */         if (this.compilerEnv.isGenerateObserverCount()) saveCurrentCodeOffset();
/*      */       
/*      */ 
/*      */       
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 139:
/*  850 */         if (this.compilerEnv.isGenerateObserverCount()) addInstructionCount(); 
/*  851 */         visitGoto((Jump)node, type, child);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 129:
/*  861 */         if (this.isGenerator) {
/*      */ 
/*      */ 
/*      */           
/*  865 */           if (this.compilerEnv.isGenerateObserverCount()) saveCurrentCodeOffset();
/*      */ 
/*      */           
/*  868 */           this.cfw.setStackTop((short)1);
/*      */ 
/*      */           
/*  871 */           int finallyRegister = getNewWordLocal();
/*      */           
/*  873 */           int finallyStart = this.cfw.acquireLabel();
/*  874 */           int finallyEnd = this.cfw.acquireLabel();
/*  875 */           this.cfw.markLabel(finallyStart);
/*      */           
/*  877 */           generateIntegerWrap();
/*  878 */           this.cfw.addAStore(finallyRegister);
/*      */           
/*  880 */           while (child != null) {
/*  881 */             generateStatement(child);
/*  882 */             child = child.getNext();
/*      */           } 
/*      */           
/*  885 */           this.cfw.addALoad(finallyRegister);
/*  886 */           this.cfw.add(192, "java/lang/Integer");
/*  887 */           generateIntegerUnwrap();
/*  888 */           FinallyReturnPoint ret = this.finallys.get(node);
/*  889 */           ret.tableLabel = this.cfw.acquireLabel();
/*  890 */           this.cfw.add(167, ret.tableLabel);
/*      */ 
/*      */           
/*  893 */           this.cfw.setStackTop((short)0);
/*      */           
/*  895 */           releaseWordLocal((short)finallyRegister);
/*  896 */           this.cfw.markLabel(finallyEnd);
/*      */         } 
/*      */ 
/*      */       
/*      */       case 164:
/*      */         return;
/*      */     } 
/*      */     
/*  904 */     throw Codegen.badTree(); }
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateIntegerWrap() {
/*  909 */     this.cfw.addInvoke(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
/*      */   }
/*      */ 
/*      */   
/*      */   private void generateIntegerUnwrap() {
/*  914 */     this.cfw.addInvoke(182, "java/lang/Integer", "intValue", "()I");
/*      */   }
/*      */   
/*      */   private void generateThrowJavaScriptException() {
/*  918 */     this.cfw.add(187, "org/mozilla/javascript/JavaScriptException");
/*  919 */     this.cfw.add(90);
/*  920 */     this.cfw.add(95);
/*  921 */     this.cfw.addPush(this.scriptOrFn.getSourceName());
/*  922 */     this.cfw.addPush(this.itsLineNumber);
/*  923 */     this.cfw.addInvoke(183, "org/mozilla/javascript/JavaScriptException", "<init>", "(Ljava/lang/Object;Ljava/lang/String;I)V");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  928 */     this.cfw.add(191);
/*      */   }
/*      */   
/*      */   private int getNextGeneratorState(Node node) {
/*  932 */     int nodeIndex = ((FunctionNode)this.scriptOrFn).getResumptionPoints().indexOf(node);
/*  933 */     return nodeIndex + 1; } private void generateExpression(Node node, Node parent) { int specialType; double num; byte[] bytes; int i; Node next; int local, trueTarget, falseTarget; Node ifThen; int childNumberFlag, prop, trueGOTO; boolean isName; int k, j; Node ifElse; int falseGOTO; String special; int memberTypeFlags; Node enterWith, initStmt; int beyond, elseTarget; String methodName; Node with, expr;
/*      */     short stack;
/*      */     String signature;
/*      */     Node leaveWith;
/*  937 */     int afterHook, type = node.getType();
/*  938 */     Node child = node.getFirstChild();
/*  939 */     switch (type) {
/*      */       case 142:
/*      */         return;
/*      */       
/*      */       case 113:
/*  944 */         if (this.fnCurrent != null || parent.getType() != 140) {
/*  945 */           int fnIndex = node.getExistingIntProp(1);
/*  946 */           OptFunctionNode ofn = OptFunctionNode.get(this.scriptOrFn, fnIndex);
/*  947 */           int t = ofn.fnode.getFunctionType();
/*  948 */           if (t != 2 && t != 4) {
/*  949 */             throw Codegen.badTree();
/*      */           }
/*  951 */           visitFunction(ofn, t);
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/*  957 */         this.cfw.addALoad(this.contextLocal);
/*  958 */         this.cfw.addALoad(this.variableObjectLocal);
/*  959 */         this.cfw.addPush(node.getString());
/*  960 */         addScriptRuntimeInvoke("name", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 30:
/*      */       case 38:
/*  972 */         specialType = node.getIntProp(10, 0);
/*  973 */         if (specialType == 0) {
/*      */           
/*  975 */           OptFunctionNode target = (OptFunctionNode)node.getProp(9);
/*      */           
/*  977 */           if (target != null) {
/*  978 */             visitOptimizedCall(node, target, type, child);
/*  979 */           } else if (type == 38) {
/*  980 */             visitStandardCall(node, child);
/*      */           } else {
/*  982 */             visitStandardNew(node, child);
/*      */           } 
/*      */         } else {
/*  985 */           visitSpecialCall(node, type, specialType, child);
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       case 71:
/*  991 */         generateFunctionAndThisObj(child, node);
/*      */         
/*  993 */         child = child.getNext();
/*  994 */         generateCallArgArray(node, child, false);
/*  995 */         this.cfw.addALoad(this.contextLocal);
/*  996 */         addScriptRuntimeInvoke("callRef", "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/Ref;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 40:
/* 1007 */         num = node.getDouble();
/* 1008 */         if (node.getIntProp(8, -1) != -1) {
/* 1009 */           this.cfw.addPush(num);
/*      */         } else {
/* 1011 */           this.codegen.pushNumberAsObject(this.cfw, num);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 83:
/* 1018 */         bytes = node.getBigInt().toByteArray();
/* 1019 */         this.cfw.add(187, "java/math/BigInteger");
/* 1020 */         this.cfw.add(89);
/* 1021 */         this.cfw.addPush(bytes.length);
/* 1022 */         this.cfw.add(188, 8);
/* 1023 */         for (k = 0; k < bytes.length; k++) {
/* 1024 */           this.cfw.add(89);
/* 1025 */           this.cfw.addPush(k);
/* 1026 */           this.cfw.add(16, bytes[k]);
/* 1027 */           this.cfw.add(84);
/*      */         } 
/* 1029 */         this.cfw.addInvoke(183, "java/math/BigInteger", "<init>", "([B)V");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 41:
/* 1035 */         this.cfw.addPush(node.getString());
/*      */ 
/*      */       
/*      */       case 43:
/* 1039 */         this.cfw.addALoad(this.thisObjLocal);
/*      */ 
/*      */       
/*      */       case 64:
/* 1043 */         this.cfw.add(42);
/*      */ 
/*      */       
/*      */       case 42:
/* 1047 */         this.cfw.add(1);
/*      */ 
/*      */       
/*      */       case 45:
/* 1051 */         this.cfw.add(178, "java/lang/Boolean", "TRUE", "Ljava/lang/Boolean;");
/*      */ 
/*      */       
/*      */       case 44:
/* 1055 */         this.cfw.add(178, "java/lang/Boolean", "FALSE", "Ljava/lang/Boolean;");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/* 1061 */         this.cfw.addALoad(this.contextLocal);
/* 1062 */         this.cfw.addALoad(this.variableObjectLocal);
/* 1063 */         i = node.getExistingIntProp(4);
/* 1064 */         this.cfw.add(178, this.codegen.mainClassName, this.codegen
/*      */ 
/*      */             
/* 1067 */             .getCompiledRegexpName(this.scriptOrFn, i), "Ljava/lang/Object;");
/*      */         
/* 1069 */         this.cfw.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "wrapRegExp", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 92:
/* 1082 */         next = child.getNext();
/* 1083 */         while (next != null) {
/* 1084 */           generateExpression(child, node);
/* 1085 */           this.cfw.add(87);
/* 1086 */           child = next;
/* 1087 */           next = next.getNext();
/*      */         } 
/* 1089 */         generateExpression(child, node);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 62:
/*      */       case 63:
/* 1096 */         local = getLocalBlockRegister(node);
/* 1097 */         this.cfw.addALoad(local);
/* 1098 */         if (type == 62) {
/* 1099 */           addScriptRuntimeInvoke("enumNext", "(Ljava/lang/Object;)Ljava/lang/Boolean;");
/*      */         } else {
/*      */           
/* 1102 */           this.cfw.addALoad(this.contextLocal);
/* 1103 */           addScriptRuntimeInvoke("enumId", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 66:
/* 1113 */         visitArrayLiteral(node, child, false);
/*      */ 
/*      */       
/*      */       case 67:
/* 1117 */         visitObjectLiteral(node, child, false);
/*      */ 
/*      */ 
/*      */       
/*      */       case 26:
/* 1122 */         trueTarget = this.cfw.acquireLabel();
/* 1123 */         j = this.cfw.acquireLabel();
/* 1124 */         beyond = this.cfw.acquireLabel();
/* 1125 */         generateIfJump(child, node, trueTarget, j);
/*      */         
/* 1127 */         this.cfw.markLabel(trueTarget);
/* 1128 */         this.cfw.add(178, "java/lang/Boolean", "FALSE", "Ljava/lang/Boolean;");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1133 */         this.cfw.add(167, beyond);
/* 1134 */         this.cfw.markLabel(j);
/* 1135 */         this.cfw.add(178, "java/lang/Boolean", "TRUE", "Ljava/lang/Boolean;");
/* 1136 */         this.cfw.markLabel(beyond);
/* 1137 */         this.cfw.adjustStackTop(-1);
/*      */ 
/*      */ 
/*      */       
/*      */       case 27:
/* 1142 */         visitBitNot(node, child);
/*      */ 
/*      */       
/*      */       case 130:
/* 1146 */         generateExpression(child, node);
/* 1147 */         this.cfw.add(87);
/* 1148 */         Codegen.pushUndefined(this.cfw);
/*      */ 
/*      */       
/*      */       case 32:
/* 1152 */         generateExpression(child, node);
/* 1153 */         addScriptRuntimeInvoke("typeof", "(Ljava/lang/Object;)Ljava/lang/String;");
/*      */ 
/*      */       
/*      */       case 141:
/* 1157 */         visitTypeofname(node);
/*      */ 
/*      */       
/*      */       case 110:
/*      */       case 111:
/* 1162 */         visitIncDec(node);
/*      */ 
/*      */ 
/*      */       
/*      */       case 108:
/*      */       case 109:
/* 1168 */         generateExpression(child, node);
/* 1169 */         this.cfw.add(89);
/* 1170 */         addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)Z");
/* 1171 */         falseTarget = this.cfw.acquireLabel();
/* 1172 */         if (type == 109) { this.cfw.add(153, falseTarget); }
/* 1173 */         else { this.cfw.add(154, falseTarget); }
/* 1174 */          this.cfw.add(87);
/* 1175 */         generateExpression(child.getNext(), node);
/* 1176 */         this.cfw.markLabel(falseTarget);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 106:
/* 1182 */         ifThen = child.getNext();
/* 1183 */         ifElse = ifThen.getNext();
/* 1184 */         generateExpression(child, node);
/* 1185 */         addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)Z");
/* 1186 */         elseTarget = this.cfw.acquireLabel();
/* 1187 */         this.cfw.add(153, elseTarget);
/* 1188 */         stack = this.cfw.getStackTop();
/* 1189 */         generateExpression(ifThen, node);
/* 1190 */         afterHook = this.cfw.acquireLabel();
/* 1191 */         this.cfw.add(167, afterHook);
/* 1192 */         this.cfw.markLabel(elseTarget, stack);
/* 1193 */         generateExpression(ifElse, node);
/* 1194 */         this.cfw.markLabel(afterHook);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 21:
/* 1200 */         generateExpression(child, node);
/* 1201 */         generateExpression(child.getNext(), node);
/* 1202 */         switch (node.getIntProp(8, -1)) {
/*      */           case 0:
/* 1204 */             this.cfw.add(99);
/*      */           
/*      */           case 1:
/* 1207 */             this.cfw.addALoad(this.contextLocal);
/* 1208 */             addOptRuntimeInvoke("add", "(DLjava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */           
/*      */           case 2:
/* 1213 */             this.cfw.addALoad(this.contextLocal);
/* 1214 */             addOptRuntimeInvoke("add", "(Ljava/lang/Object;DLorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1219 */         this.cfw.addALoad(this.contextLocal);
/* 1220 */         addScriptRuntimeInvoke("add", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 22:
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/* 1234 */         visitArithmetic(node, type, child, parent);
/*      */ 
/*      */       
/*      */       case 75:
/* 1238 */         visitExponentiation(node, child, parent);
/*      */ 
/*      */       
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/* 1247 */         visitBitOp(node, type, child);
/*      */ 
/*      */ 
/*      */       
/*      */       case 28:
/* 1252 */         childNumberFlag = node.getIntProp(8, -1);
/* 1253 */         generateExpression(child, node);
/* 1254 */         if (childNumberFlag == -1) {
/* 1255 */           addObjectToDouble();
/* 1256 */           addDoubleWrap();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 29:
/* 1263 */         childNumberFlag = node.getIntProp(8, -1);
/* 1264 */         generateExpression(child, node);
/* 1265 */         if (childNumberFlag == -1) {
/* 1266 */           addObjectToNumeric();
/* 1267 */           addScriptRuntimeInvoke("negate", "(Ljava/lang/Number;)Ljava/lang/Number;");
/*      */         } else {
/*      */           
/* 1270 */           this.cfw.add(119);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 154:
/* 1277 */         generateExpression(child, node);
/* 1278 */         addObjectToDouble();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 153:
/* 1284 */         prop = -1;
/* 1285 */         if (child.getType() == 40) {
/* 1286 */           prop = child.getIntProp(8, -1);
/*      */         }
/* 1288 */         if (prop != -1) {
/* 1289 */           child.removeProp(8);
/* 1290 */           generateExpression(child, node);
/* 1291 */           child.putIntProp(8, prop);
/*      */         } else {
/* 1293 */           generateExpression(child, node);
/* 1294 */           addDoubleWrap();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 52:
/*      */       case 53:
/* 1306 */         trueGOTO = this.cfw.acquireLabel();
/* 1307 */         falseGOTO = this.cfw.acquireLabel();
/* 1308 */         visitIfJumpRelOp(node, child, trueGOTO, falseGOTO);
/* 1309 */         addJumpedBooleanWrap(trueGOTO, falseGOTO);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*      */       case 13:
/*      */       case 46:
/*      */       case 47:
/* 1318 */         trueGOTO = this.cfw.acquireLabel();
/* 1319 */         falseGOTO = this.cfw.acquireLabel();
/* 1320 */         visitIfJumpEqOp(node, child, trueGOTO, falseGOTO);
/* 1321 */         addJumpedBooleanWrap(trueGOTO, falseGOTO);
/*      */ 
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 34:
/* 1327 */         visitGetProp(node, child);
/*      */ 
/*      */       
/*      */       case 36:
/* 1331 */         generateExpression(child, node);
/* 1332 */         generateExpression(child.getNext(), node);
/* 1333 */         this.cfw.addALoad(this.contextLocal);
/* 1334 */         if (node.getIntProp(8, -1) != -1) {
/* 1335 */           addScriptRuntimeInvoke("getObjectIndex", "(Ljava/lang/Object;DLorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1341 */           this.cfw.addALoad(this.variableObjectLocal);
/* 1342 */           addScriptRuntimeInvoke("getObjectElem", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 68:
/* 1353 */         generateExpression(child, node);
/* 1354 */         this.cfw.addALoad(this.contextLocal);
/* 1355 */         addScriptRuntimeInvoke("refGet", "(Lorg/mozilla/javascript/Ref;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 55:
/* 1363 */         visitGetVar(node);
/*      */ 
/*      */       
/*      */       case 56:
/* 1367 */         visitSetVar(node, child, true);
/*      */ 
/*      */       
/*      */       case 8:
/* 1371 */         visitSetName(node, child);
/*      */ 
/*      */       
/*      */       case 74:
/* 1375 */         visitStrictSetName(node, child);
/*      */ 
/*      */       
/*      */       case 159:
/* 1379 */         visitSetConst(node, child);
/*      */ 
/*      */       
/*      */       case 160:
/* 1383 */         visitSetConstVar(node, child, true);
/*      */ 
/*      */       
/*      */       case 35:
/*      */       case 143:
/* 1388 */         visitSetProp(type, node, child);
/*      */ 
/*      */       
/*      */       case 37:
/*      */       case 144:
/* 1393 */         visitSetElem(type, node, child);
/*      */ 
/*      */ 
/*      */       
/*      */       case 69:
/*      */       case 146:
/* 1399 */         generateExpression(child, node);
/* 1400 */         child = child.getNext();
/* 1401 */         if (type == 146) {
/* 1402 */           this.cfw.add(89);
/* 1403 */           this.cfw.addALoad(this.contextLocal);
/* 1404 */           addScriptRuntimeInvoke("refGet", "(Lorg/mozilla/javascript/Ref;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1410 */         generateExpression(child, node);
/* 1411 */         this.cfw.addALoad(this.contextLocal);
/* 1412 */         this.cfw.addALoad(this.variableObjectLocal);
/* 1413 */         addScriptRuntimeInvoke("refSet", "(Lorg/mozilla/javascript/Ref;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 70:
/* 1424 */         generateExpression(child, node);
/* 1425 */         this.cfw.addALoad(this.contextLocal);
/* 1426 */         addScriptRuntimeInvoke("refDel", "(Lorg/mozilla/javascript/Ref;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 31:
/* 1434 */         isName = (child.getType() == 49);
/* 1435 */         generateExpression(child, node);
/* 1436 */         child = child.getNext();
/* 1437 */         generateExpression(child, node);
/* 1438 */         this.cfw.addALoad(this.contextLocal);
/* 1439 */         this.cfw.addPush(isName);
/* 1440 */         addScriptRuntimeInvoke("delete", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Z)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 49:
/* 1450 */         while (child != null) {
/* 1451 */           generateExpression(child, node);
/* 1452 */           child = child.getNext();
/*      */         } 
/*      */         
/* 1455 */         this.cfw.addALoad(this.contextLocal);
/* 1456 */         this.cfw.addALoad(this.variableObjectLocal);
/* 1457 */         this.cfw.addPush(node.getString());
/* 1458 */         addScriptRuntimeInvoke("bind", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 54:
/* 1468 */         this.cfw.addALoad(getLocalBlockRegister(node));
/*      */ 
/*      */ 
/*      */       
/*      */       case 72:
/* 1473 */         special = (String)node.getProp(17);
/* 1474 */         generateExpression(child, node);
/* 1475 */         this.cfw.addPush(special);
/* 1476 */         this.cfw.addALoad(this.contextLocal);
/* 1477 */         this.cfw.addALoad(this.variableObjectLocal);
/* 1478 */         addScriptRuntimeInvoke("specialRef", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Ref;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 79:
/*      */       case 80:
/*      */       case 81:
/*      */       case 82:
/* 1493 */         memberTypeFlags = node.getIntProp(16, 0);
/*      */         
/*      */         do {
/* 1496 */           generateExpression(child, node);
/* 1497 */           child = child.getNext();
/* 1498 */         } while (child != null);
/* 1499 */         this.cfw.addALoad(this.contextLocal);
/*      */         
/* 1501 */         switch (type) {
/*      */           case 79:
/* 1503 */             methodName = "memberRef";
/* 1504 */             signature = "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;I)Lorg/mozilla/javascript/Ref;";
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 80:
/* 1512 */             methodName = "memberRef";
/* 1513 */             signature = "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;I)Lorg/mozilla/javascript/Ref;";
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 81:
/* 1522 */             methodName = "nameRef";
/* 1523 */             signature = "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Lorg/mozilla/javascript/Ref;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1529 */             this.cfw.addALoad(this.variableObjectLocal);
/*      */             break;
/*      */           case 82:
/* 1532 */             methodName = "nameRef";
/* 1533 */             signature = "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Lorg/mozilla/javascript/Ref;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1540 */             this.cfw.addALoad(this.variableObjectLocal);
/*      */             break;
/*      */           default:
/* 1543 */             throw Kit.codeBug();
/*      */         } 
/* 1545 */         this.cfw.addPush(memberTypeFlags);
/* 1546 */         addScriptRuntimeInvoke(methodName, signature);
/*      */ 
/*      */ 
/*      */       
/*      */       case 150:
/* 1551 */         visitDotQuery(node, child);
/*      */ 
/*      */       
/*      */       case 77:
/* 1555 */         generateExpression(child, node);
/* 1556 */         this.cfw.addALoad(this.contextLocal);
/* 1557 */         addScriptRuntimeInvoke("escapeAttributeValue", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/String;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 78:
/* 1565 */         generateExpression(child, node);
/* 1566 */         this.cfw.addALoad(this.contextLocal);
/* 1567 */         addScriptRuntimeInvoke("escapeTextValue", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/String;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 76:
/* 1575 */         generateExpression(child, node);
/* 1576 */         this.cfw.addALoad(this.contextLocal);
/* 1577 */         addScriptRuntimeInvoke("setDefaultNamespace", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 73:
/*      */       case 169:
/* 1586 */         generateYieldPoint(node, true);
/*      */ 
/*      */ 
/*      */       
/*      */       case 163:
/* 1591 */         enterWith = child;
/* 1592 */         with = enterWith.getNext();
/* 1593 */         leaveWith = with.getNext();
/* 1594 */         generateStatement(enterWith);
/* 1595 */         generateExpression(with.getFirstChild(), with);
/* 1596 */         generateStatement(leaveWith);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 161:
/* 1602 */         initStmt = child;
/* 1603 */         expr = child.getNext();
/* 1604 */         generateStatement(initStmt);
/* 1605 */         generateExpression(expr, node);
/*      */ 
/*      */ 
/*      */       
/*      */       case 170:
/* 1610 */         visitTemplateLiteral(node);
/*      */     } 
/*      */ 
/*      */     
/* 1614 */     throw new RuntimeException("Unexpected node type " + type); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node findNestedYield(Node node) {
/* 1621 */     Node child = node.getFirstChild();
/* 1622 */     while (child != null) {
/* 1623 */       if (child.getType() == 73 || child.getType() == 169) {
/* 1624 */         return child;
/*      */       }
/* 1626 */       Node grandchild = findNestedYield(child);
/* 1627 */       if (grandchild != null) {
/* 1628 */         return grandchild;
/*      */       }
/* 1630 */       child = child.getNext();
/*      */     } 
/* 1632 */     return null;
/*      */   }
/*      */   
/*      */   private void generateYieldPoint(Node node, boolean exprContext) {
/* 1636 */     if (this.unnestedYields.containsKey(node)) {
/*      */       
/* 1638 */       if (exprContext) {
/* 1639 */         this.cfw.addALoad(this.variableObjectLocal);
/* 1640 */         this.cfw.addLoadConstant(this.unnestedYields.get(node));
/* 1641 */         this.cfw.addALoad(this.contextLocal);
/* 1642 */         this.cfw.addALoad(this.variableObjectLocal);
/* 1643 */         addScriptRuntimeInvoke("getObjectPropNoWarn", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */       } 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 1651 */     Node nestedYield = findNestedYield(node);
/* 1652 */     if (nestedYield != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1658 */       generateYieldPoint(nestedYield, true);
/*      */       
/* 1660 */       String nn = "__nested__yield__" + this.unnestedYieldCount;
/* 1661 */       this.unnestedYieldCount++;
/* 1662 */       this.cfw.addALoad(this.variableObjectLocal);
/* 1663 */       this.cfw.add(95);
/* 1664 */       this.cfw.addLoadConstant(nn);
/* 1665 */       this.cfw.add(95);
/* 1666 */       this.cfw.addALoad(this.contextLocal);
/*      */       
/* 1668 */       addScriptRuntimeInvoke("setObjectProp", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */       
/* 1672 */       this.cfw.add(87);
/*      */       
/* 1674 */       this.unnestedYields.put(nestedYield, nn);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1679 */     generateLocalYieldPoint(node, exprContext);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateLocalYieldPoint(Node node, boolean exprContext) {
/* 1685 */     int top = this.cfw.getStackTop();
/* 1686 */     this.maxStack = (this.maxStack > top) ? this.maxStack : top;
/* 1687 */     if (top != 0) {
/* 1688 */       generateGetGeneratorStackState();
/* 1689 */       for (int i = 0; i < top; i++) {
/* 1690 */         this.cfw.add(90);
/* 1691 */         this.cfw.add(95);
/* 1692 */         this.cfw.addLoadConstant(i);
/* 1693 */         this.cfw.add(95);
/* 1694 */         this.cfw.add(83);
/*      */       } 
/*      */       
/* 1697 */       this.cfw.add(87);
/*      */     } 
/*      */ 
/*      */     
/* 1701 */     Node child = node.getFirstChild();
/* 1702 */     if (child != null) { generateExpression(child, node); }
/* 1703 */     else { Codegen.pushUndefined(this.cfw); }
/*      */     
/* 1705 */     if (node.getType() == 169) {
/*      */       
/* 1707 */       this.cfw.add(187, "org/mozilla/javascript/ES6Generator$YieldStarResult");
/* 1708 */       this.cfw.add(90);
/* 1709 */       this.cfw.add(95);
/* 1710 */       this.cfw.addInvoke(183, "org/mozilla/javascript/ES6Generator$YieldStarResult", "<init>", "(Ljava/lang/Object;)V");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1718 */     int nextState = getNextGeneratorState(node);
/* 1719 */     generateSetGeneratorResumptionPoint(nextState);
/*      */     
/* 1721 */     boolean hasLocals = generateSaveLocals(node);
/*      */     
/* 1723 */     this.cfw.add(176);
/*      */ 
/*      */ 
/*      */     
/* 1727 */     generateCheckForThrowOrClose(getTargetLabel(node), hasLocals, nextState);
/*      */ 
/*      */     
/* 1730 */     if (top != 0) {
/* 1731 */       generateGetGeneratorStackState();
/* 1732 */       for (int i = top - 1; i >= 0; i--) {
/* 1733 */         this.cfw.add(89);
/* 1734 */         this.cfw.addLoadConstant(i);
/* 1735 */         this.cfw.add(50);
/* 1736 */         this.cfw.add(95);
/*      */       } 
/* 1738 */       this.cfw.add(87);
/*      */     } 
/*      */ 
/*      */     
/* 1742 */     if (exprContext) {
/* 1743 */       this.cfw.addALoad(this.argsLocal);
/*      */     }
/*      */   }
/*      */   
/*      */   private void generateCheckForThrowOrClose(int label, boolean hasLocals, int nextState) {
/* 1748 */     int throwLabel = this.cfw.acquireLabel();
/* 1749 */     int closeLabel = this.cfw.acquireLabel();
/*      */ 
/*      */     
/* 1752 */     this.cfw.markLabel(throwLabel);
/* 1753 */     this.cfw.addALoad(this.argsLocal);
/* 1754 */     generateThrowJavaScriptException();
/*      */ 
/*      */     
/* 1757 */     this.cfw.markLabel(closeLabel);
/* 1758 */     this.cfw.addALoad(this.argsLocal);
/* 1759 */     this.cfw.add(192, "java/lang/Throwable");
/* 1760 */     this.cfw.add(191);
/*      */ 
/*      */ 
/*      */     
/* 1764 */     if (label != -1) this.cfw.markLabel(label); 
/* 1765 */     if (!hasLocals)
/*      */     {
/* 1767 */       this.cfw.markTableSwitchCase(this.generatorSwitch, nextState);
/*      */     }
/*      */ 
/*      */     
/* 1771 */     this.cfw.addILoad(this.operationLocal);
/* 1772 */     this.cfw.addLoadConstant(2);
/* 1773 */     this.cfw.add(159, closeLabel);
/* 1774 */     this.cfw.addILoad(this.operationLocal);
/* 1775 */     this.cfw.addLoadConstant(1);
/* 1776 */     this.cfw.add(159, throwLabel);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitTemplateLiteral(Node node) {
/* 1782 */     int index = node.getExistingIntProp(28);
/* 1783 */     this.cfw.addALoad(this.contextLocal);
/* 1784 */     this.cfw.addALoad(this.variableObjectLocal);
/* 1785 */     this.cfw.add(178, this.codegen.mainClassName, this.codegen
/*      */ 
/*      */         
/* 1788 */         .getTemplateLiteralName(this.scriptOrFn), "[Ljava/lang/Object;");
/*      */     
/* 1790 */     this.cfw.addPush(index);
/* 1791 */     this.cfw.addInvoke(184, "org/mozilla/javascript/ScriptRuntime", "getTemplateLiteralCallSite", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;I)Lorg/mozilla/javascript/Scriptable;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateIfJump(Node node, Node parent, int trueLabel, int falseLabel) {
/* 1802 */     int interLabel, type = node.getType();
/* 1803 */     Node child = node.getFirstChild();
/*      */     
/* 1805 */     switch (type) {
/*      */       case 26:
/* 1807 */         generateIfJump(child, node, falseLabel, trueLabel);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 108:
/*      */       case 109:
/* 1813 */         interLabel = this.cfw.acquireLabel();
/* 1814 */         if (type == 109) {
/* 1815 */           generateIfJump(child, node, interLabel, falseLabel);
/*      */         } else {
/* 1817 */           generateIfJump(child, node, trueLabel, interLabel);
/*      */         } 
/* 1819 */         this.cfw.markLabel(interLabel);
/* 1820 */         child = child.getNext();
/* 1821 */         generateIfJump(child, node, trueLabel, falseLabel);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 52:
/*      */       case 53:
/* 1831 */         visitIfJumpRelOp(node, child, trueLabel, falseLabel);
/*      */         return;
/*      */       
/*      */       case 12:
/*      */       case 13:
/*      */       case 46:
/*      */       case 47:
/* 1838 */         visitIfJumpEqOp(node, child, trueLabel, falseLabel);
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1843 */     generateExpression(node, parent);
/* 1844 */     addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)Z");
/* 1845 */     this.cfw.add(154, trueLabel);
/* 1846 */     this.cfw.add(167, falseLabel);
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitFunction(OptFunctionNode ofn, int functionType) {
/* 1851 */     int fnIndex = this.codegen.getIndex((ScriptNode)ofn.fnode);
/* 1852 */     this.cfw.add(187, this.codegen.mainClassName);
/*      */     
/* 1854 */     this.cfw.add(89);
/* 1855 */     this.cfw.addALoad(this.variableObjectLocal);
/* 1856 */     this.cfw.addALoad(this.contextLocal);
/* 1857 */     this.cfw.addPush(fnIndex);
/* 1858 */     this.cfw.addInvoke(183, this.codegen.mainClassName, "<init>", "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;I)V");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1864 */     if (functionType == 4) {
/* 1865 */       this.cfw.addALoad(this.contextLocal);
/* 1866 */       this.cfw.addALoad(this.variableObjectLocal);
/* 1867 */       this.cfw.addALoad(this.thisObjLocal);
/* 1868 */       addOptRuntimeInvoke("bindThis", "(Lorg/mozilla/javascript/NativeFunction;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Function;");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1877 */     if (functionType == 2 || functionType == 4) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1883 */     this.cfw.addPush(functionType);
/* 1884 */     this.cfw.addALoad(this.variableObjectLocal);
/* 1885 */     this.cfw.addALoad(this.contextLocal);
/* 1886 */     addOptRuntimeInvoke("initFunction", "(Lorg/mozilla/javascript/NativeFunction;ILorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;)V");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getTargetLabel(Node target) {
/* 1896 */     int labelId = target.labelId();
/* 1897 */     if (labelId == -1) {
/* 1898 */       labelId = this.cfw.acquireLabel();
/* 1899 */       target.labelId(labelId);
/*      */     } 
/* 1901 */     return labelId;
/*      */   }
/*      */   
/*      */   private void visitGoto(Jump node, int type, Node child) {
/* 1905 */     Node target = node.target;
/* 1906 */     if (type == 6 || type == 7) {
/* 1907 */       if (child == null) throw Codegen.badTree(); 
/* 1908 */       int targetLabel = getTargetLabel(target);
/* 1909 */       int fallThruLabel = this.cfw.acquireLabel();
/* 1910 */       if (type == 6) { generateIfJump(child, (Node)node, targetLabel, fallThruLabel); }
/* 1911 */       else { generateIfJump(child, (Node)node, fallThruLabel, targetLabel); }
/* 1912 */        this.cfw.markLabel(fallThruLabel);
/*      */     }
/* 1914 */     else if (type == 139) {
/* 1915 */       if (this.isGenerator) {
/* 1916 */         addGotoWithReturn(target);
/*      */       } else {
/*      */         
/* 1919 */         inlineFinally(target);
/*      */       } 
/*      */     } else {
/* 1922 */       addGoto(target, 167);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void addGotoWithReturn(Node target) {
/* 1928 */     FinallyReturnPoint ret = this.finallys.get(target);
/* 1929 */     this.cfw.addLoadConstant(ret.jsrPoints.size());
/* 1930 */     addGoto(target, 167);
/*      */     
/* 1932 */     this.cfw.add(87);
/* 1933 */     int retLabel = this.cfw.acquireLabel();
/* 1934 */     this.cfw.markLabel(retLabel);
/* 1935 */     ret.jsrPoints.add(Integer.valueOf(retLabel));
/*      */   }
/*      */   
/*      */   private void generateArrayLiteralFactory(Node node, int count) {
/* 1939 */     String methodName = this.codegen.getBodyMethodName(this.scriptOrFn) + "_literal" + count;
/* 1940 */     initBodyGeneration();
/* 1941 */     this.argsLocal = this.firstFreeLocal = (short)(this.firstFreeLocal + 1);
/* 1942 */     this.localsMax = this.firstFreeLocal;
/* 1943 */     this.cfw.startMethod(methodName, "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;", (short)2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1951 */     visitArrayLiteral(node, node.getFirstChild(), true);
/* 1952 */     this.cfw.add(176);
/* 1953 */     this.cfw.stopMethod((short)(this.localsMax + 1));
/*      */   }
/*      */   
/*      */   private void generateObjectLiteralFactory(Node node, int count) {
/* 1957 */     String methodName = this.codegen.getBodyMethodName(this.scriptOrFn) + "_literal" + count;
/* 1958 */     initBodyGeneration();
/* 1959 */     this.argsLocal = this.firstFreeLocal = (short)(this.firstFreeLocal + 1);
/* 1960 */     this.localsMax = this.firstFreeLocal;
/* 1961 */     this.cfw.startMethod(methodName, "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;", (short)2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1969 */     visitObjectLiteral(node, node.getFirstChild(), true);
/* 1970 */     this.cfw.add(176);
/* 1971 */     this.cfw.stopMethod((short)(this.localsMax + 1));
/*      */   }
/*      */   
/*      */   private void visitArrayLiteral(Node node, Node child, boolean topLevel) {
/* 1975 */     int count = 0;
/* 1976 */     for (Node cursor = child; cursor != null; cursor = cursor.getNext()) {
/* 1977 */       count++;
/*      */     }
/*      */ 
/*      */     
/* 1981 */     if (!topLevel && (count > 10 || this.cfw
/* 1982 */       .getCurrentCodeOffset() > 30000) && !this.hasVarsInRegs && !this.isGenerator && !this.inLocalBlock) {
/*      */ 
/*      */ 
/*      */       
/* 1986 */       if (this.literals == null) {
/* 1987 */         this.literals = new LinkedList<>();
/*      */       }
/* 1989 */       this.literals.add(node);
/*      */       
/* 1991 */       String methodName = this.codegen.getBodyMethodName(this.scriptOrFn) + "_literal" + this.literals.size();
/* 1992 */       this.cfw.addALoad(this.funObjLocal);
/* 1993 */       this.cfw.addALoad(this.contextLocal);
/* 1994 */       this.cfw.addALoad(this.variableObjectLocal);
/* 1995 */       this.cfw.addALoad(this.thisObjLocal);
/* 1996 */       this.cfw.addALoad(this.argsLocal);
/* 1997 */       this.cfw.addInvoke(182, this.codegen.mainClassName, methodName, "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2010 */     if (this.isGenerator) {
/*      */       int i;
/*      */       
/* 2013 */       for (i = 0; i != count; i++) {
/* 2014 */         generateExpression(child, node);
/* 2015 */         child = child.getNext();
/*      */       } 
/* 2017 */       addNewObjectArray(count);
/* 2018 */       for (i = 0; i != count; i++) {
/* 2019 */         this.cfw.add(90);
/* 2020 */         this.cfw.add(95);
/* 2021 */         this.cfw.addPush(count - i - 1);
/* 2022 */         this.cfw.add(95);
/* 2023 */         this.cfw.add(83);
/*      */       } 
/*      */     } else {
/* 2026 */       addNewObjectArray(count);
/* 2027 */       for (int i = 0; i != count; i++) {
/* 2028 */         this.cfw.add(89);
/* 2029 */         this.cfw.addPush(i);
/* 2030 */         generateExpression(child, node);
/* 2031 */         this.cfw.add(83);
/* 2032 */         child = child.getNext();
/*      */       } 
/*      */     } 
/* 2035 */     int[] skipIndexes = (int[])node.getProp(11);
/* 2036 */     if (skipIndexes == null) {
/* 2037 */       this.cfw.add(1);
/* 2038 */       this.cfw.add(3);
/*      */     } else {
/* 2040 */       this.cfw.addPush(OptRuntime.encodeIntArray(skipIndexes));
/* 2041 */       this.cfw.addPush(skipIndexes.length);
/*      */     } 
/* 2043 */     this.cfw.addALoad(this.contextLocal);
/* 2044 */     this.cfw.addALoad(this.variableObjectLocal);
/* 2045 */     addOptRuntimeInvoke("newArrayLiteral", "([Ljava/lang/Object;Ljava/lang/String;ILorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addLoadPropertyIds(Object[] properties, int count) {
/* 2057 */     addNewObjectArray(count);
/* 2058 */     for (int i = 0; i != count; i++) {
/* 2059 */       this.cfw.add(89);
/* 2060 */       this.cfw.addPush(i);
/* 2061 */       Object id = properties[i];
/* 2062 */       if (id instanceof String) {
/* 2063 */         this.cfw.addPush((String)id);
/*      */       } else {
/* 2065 */         this.cfw.addPush(((Integer)id).intValue());
/* 2066 */         addScriptRuntimeInvoke("wrapInt", "(I)Ljava/lang/Integer;");
/*      */       } 
/* 2068 */       this.cfw.add(83);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void addLoadPropertyValues(Node node, Node child, int count) {
/* 2074 */     if (this.isGenerator) {
/*      */       int i;
/* 2076 */       for (i = 0; i != count; i++) {
/* 2077 */         int childType = child.getType();
/* 2078 */         if (childType == 155 || childType == 156 || childType == 167) {
/* 2079 */           generateExpression(child.getFirstChild(), node);
/*      */         } else {
/* 2081 */           generateExpression(child, node);
/*      */         } 
/* 2083 */         child = child.getNext();
/*      */       } 
/* 2085 */       addNewObjectArray(count);
/* 2086 */       for (i = 0; i != count; i++) {
/* 2087 */         this.cfw.add(90);
/* 2088 */         this.cfw.add(95);
/* 2089 */         this.cfw.addPush(count - i - 1);
/* 2090 */         this.cfw.add(95);
/* 2091 */         this.cfw.add(83);
/*      */       } 
/*      */     } else {
/* 2094 */       addNewObjectArray(count);
/* 2095 */       Node child2 = child;
/* 2096 */       for (int i = 0; i != count; i++) {
/* 2097 */         this.cfw.add(89);
/* 2098 */         this.cfw.addPush(i);
/* 2099 */         int childType = child2.getType();
/* 2100 */         if (childType == 155 || childType == 156 || childType == 167) {
/* 2101 */           generateExpression(child2.getFirstChild(), node);
/*      */         } else {
/* 2103 */           generateExpression(child2, node);
/*      */         } 
/* 2105 */         this.cfw.add(83);
/* 2106 */         child2 = child2.getNext();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitObjectLiteral(Node node, Node child, boolean topLevel) {
/* 2112 */     Object[] properties = (Object[])node.getProp(12);
/* 2113 */     int count = (properties == null) ? 0 : properties.length;
/*      */ 
/*      */     
/* 2116 */     if (!topLevel && (count > 10 || this.cfw
/* 2117 */       .getCurrentCodeOffset() > 30000) && !this.hasVarsInRegs && !this.isGenerator && !this.inLocalBlock) {
/*      */ 
/*      */ 
/*      */       
/* 2121 */       if (this.literals == null) {
/* 2122 */         this.literals = new LinkedList<>();
/*      */       }
/* 2124 */       this.literals.add(node);
/*      */       
/* 2126 */       String methodName = this.codegen.getBodyMethodName(this.scriptOrFn) + "_literal" + this.literals.size();
/* 2127 */       this.cfw.addALoad(this.funObjLocal);
/* 2128 */       this.cfw.addALoad(this.contextLocal);
/* 2129 */       this.cfw.addALoad(this.variableObjectLocal);
/* 2130 */       this.cfw.addALoad(this.thisObjLocal);
/* 2131 */       this.cfw.addALoad(this.argsLocal);
/* 2132 */       this.cfw.addInvoke(182, this.codegen.mainClassName, methodName, "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2144 */     if (this.isGenerator) {
/*      */ 
/*      */       
/* 2147 */       addLoadPropertyValues(node, child, count);
/* 2148 */       addLoadPropertyIds(properties, count);
/*      */       
/* 2150 */       this.cfw.add(95);
/*      */     } else {
/* 2152 */       addLoadPropertyIds(properties, count);
/* 2153 */       addLoadPropertyValues(node, child, count);
/*      */     } 
/*      */ 
/*      */     
/* 2157 */     boolean hasGetterSetters = false;
/* 2158 */     Node child2 = child; int i;
/* 2159 */     for (i = 0; i != count; i++) {
/* 2160 */       int childType = child2.getType();
/* 2161 */       if (childType == 155 || childType == 156) {
/* 2162 */         hasGetterSetters = true;
/*      */         break;
/*      */       } 
/* 2165 */       child2 = child2.getNext();
/*      */     } 
/*      */     
/* 2168 */     if (hasGetterSetters) {
/* 2169 */       this.cfw.addPush(count);
/* 2170 */       this.cfw.add(188, 10);
/* 2171 */       child2 = child;
/* 2172 */       for (i = 0; i != count; i++) {
/* 2173 */         this.cfw.add(89);
/* 2174 */         this.cfw.addPush(i);
/* 2175 */         int childType = child2.getType();
/* 2176 */         if (childType == 155) {
/* 2177 */           this.cfw.add(2);
/* 2178 */         } else if (childType == 156) {
/* 2179 */           this.cfw.add(4);
/*      */         } else {
/* 2181 */           this.cfw.add(3);
/*      */         } 
/* 2183 */         this.cfw.add(79);
/* 2184 */         child2 = child2.getNext();
/*      */       } 
/*      */     } else {
/* 2187 */       this.cfw.add(1);
/*      */     } 
/*      */     
/* 2190 */     this.cfw.addALoad(this.contextLocal);
/* 2191 */     this.cfw.addALoad(this.variableObjectLocal);
/* 2192 */     addScriptRuntimeInvoke("newObjectLiteral", "([Ljava/lang/Object;[Ljava/lang/Object;[ILorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitSpecialCall(Node node, int type, int specialType, Node child) {
/*      */     String methodName, callSignature;
/* 2203 */     this.cfw.addALoad(this.contextLocal);
/*      */     
/* 2205 */     if (type == 30) {
/* 2206 */       generateExpression(child, node);
/*      */     } else {
/*      */       
/* 2209 */       generateFunctionAndThisObj(child, node);
/*      */     } 
/*      */     
/* 2212 */     child = child.getNext();
/*      */     
/* 2214 */     generateCallArgArray(node, child, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2219 */     if (type == 30) {
/* 2220 */       methodName = "newObjectSpecial";
/* 2221 */       callSignature = "(Lorg/mozilla/javascript/Context;Ljava/lang/Object;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2229 */       this.cfw.addALoad(this.variableObjectLocal);
/* 2230 */       this.cfw.addALoad(this.thisObjLocal);
/* 2231 */       this.cfw.addPush(specialType);
/*      */     } else {
/* 2233 */       methodName = "callSpecial";
/* 2234 */       callSignature = "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;ILjava/lang/String;I)Ljava/lang/Object;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2244 */       this.cfw.addALoad(this.variableObjectLocal);
/* 2245 */       this.cfw.addALoad(this.thisObjLocal);
/* 2246 */       this.cfw.addPush(specialType);
/* 2247 */       String sourceName = this.scriptOrFn.getSourceName();
/* 2248 */       this.cfw.addPush((sourceName == null) ? "" : sourceName);
/* 2249 */       this.cfw.addPush(this.itsLineNumber);
/*      */     } 
/*      */     
/* 2252 */     addOptRuntimeInvoke(methodName, callSignature);
/*      */   }
/*      */   private void visitStandardCall(Node node, Node child) {
/*      */     String methodName, signature;
/* 2256 */     if (node.getType() != 38) throw Codegen.badTree();
/*      */     
/* 2258 */     Node firstArgChild = child.getNext();
/* 2259 */     int childType = child.getType();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2264 */     if (firstArgChild == null) {
/* 2265 */       if (childType == 39)
/*      */       {
/* 2267 */         String name = child.getString();
/* 2268 */         this.cfw.addPush(name);
/* 2269 */         methodName = "callName0";
/* 2270 */         signature = "(Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 2275 */       else if (childType == 33)
/*      */       {
/* 2277 */         Node propTarget = child.getFirstChild();
/* 2278 */         generateExpression(propTarget, node);
/* 2279 */         Node id = propTarget.getNext();
/* 2280 */         String property = id.getString();
/* 2281 */         this.cfw.addPush(property);
/* 2282 */         methodName = "callProp0";
/* 2283 */         signature = "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */         
/* 2289 */         if (childType == 34) {
/* 2290 */           throw Kit.codeBug();
/*      */         }
/* 2292 */         generateFunctionAndThisObj(child, node);
/* 2293 */         methodName = "call0";
/* 2294 */         signature = "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2302 */     else if (childType == 39) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2307 */       String name = child.getString();
/* 2308 */       generateCallArgArray(node, firstArgChild, false);
/* 2309 */       this.cfw.addPush(name);
/* 2310 */       methodName = "callName";
/* 2311 */       signature = "([Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 2318 */       int argCount = 0;
/* 2319 */       for (Node arg = firstArgChild; arg != null; arg = arg.getNext()) {
/* 2320 */         argCount++;
/*      */       }
/* 2322 */       generateFunctionAndThisObj(child, node);
/*      */       
/* 2324 */       if (argCount == 1) {
/* 2325 */         generateExpression(firstArgChild, node);
/* 2326 */         methodName = "call1";
/* 2327 */         signature = "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 2334 */       else if (argCount == 2) {
/* 2335 */         generateExpression(firstArgChild, node);
/* 2336 */         generateExpression(firstArgChild.getNext(), node);
/* 2337 */         methodName = "call2";
/* 2338 */         signature = "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 2347 */         generateCallArgArray(node, firstArgChild, false);
/* 2348 */         methodName = "callN";
/* 2349 */         signature = "(Lorg/mozilla/javascript/Callable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;";
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2359 */     this.cfw.addALoad(this.contextLocal);
/* 2360 */     this.cfw.addALoad(this.variableObjectLocal);
/* 2361 */     addOptRuntimeInvoke(methodName, signature);
/*      */   }
/*      */   
/*      */   private void visitStandardNew(Node node, Node child) {
/* 2365 */     if (node.getType() != 30) throw Codegen.badTree();
/*      */     
/* 2367 */     Node firstArgChild = child.getNext();
/*      */     
/* 2369 */     generateExpression(child, node);
/*      */     
/* 2371 */     this.cfw.addALoad(this.contextLocal);
/* 2372 */     this.cfw.addALoad(this.variableObjectLocal);
/*      */     
/* 2374 */     generateCallArgArray(node, firstArgChild, false);
/* 2375 */     addScriptRuntimeInvoke("newObject", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitOptimizedCall(Node node, OptFunctionNode target, int type, Node child) {
/* 2385 */     Node firstArgChild = child.getNext();
/* 2386 */     String className = this.codegen.mainClassName;
/*      */     
/* 2388 */     short thisObjLocal = 0;
/* 2389 */     if (type == 30) {
/* 2390 */       generateExpression(child, node);
/*      */     } else {
/* 2392 */       generateFunctionAndThisObj(child, node);
/* 2393 */       thisObjLocal = getNewWordLocal();
/* 2394 */       this.cfw.addAStore(thisObjLocal);
/*      */     } 
/*      */ 
/*      */     
/* 2398 */     int beyond = this.cfw.acquireLabel();
/* 2399 */     int regularCall = this.cfw.acquireLabel();
/*      */     
/* 2401 */     this.cfw.add(89);
/* 2402 */     this.cfw.add(193, className);
/* 2403 */     this.cfw.add(153, regularCall);
/* 2404 */     this.cfw.add(192, className);
/* 2405 */     this.cfw.add(89);
/* 2406 */     this.cfw.add(180, className, "_id", "I");
/* 2407 */     this.cfw.addPush(this.codegen.getIndex((ScriptNode)target.fnode));
/* 2408 */     this.cfw.add(160, regularCall);
/*      */ 
/*      */     
/* 2411 */     this.cfw.addALoad(this.contextLocal);
/* 2412 */     this.cfw.addALoad(this.variableObjectLocal);
/*      */ 
/*      */     
/* 2415 */     if (type == 30) {
/* 2416 */       this.cfw.add(1);
/*      */     } else {
/* 2418 */       this.cfw.addALoad(thisObjLocal);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2428 */     Node argChild = firstArgChild;
/* 2429 */     while (argChild != null) {
/* 2430 */       int dcp_register = nodeIsDirectCallParameter(argChild);
/* 2431 */       if (dcp_register >= 0) {
/* 2432 */         this.cfw.addALoad(dcp_register);
/* 2433 */         this.cfw.addDLoad(dcp_register + 1);
/* 2434 */       } else if (argChild.getIntProp(8, -1) == 0) {
/* 2435 */         this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/* 2436 */         generateExpression(argChild, node);
/*      */       } else {
/* 2438 */         generateExpression(argChild, node);
/* 2439 */         this.cfw.addPush(0.0D);
/*      */       } 
/* 2441 */       argChild = argChild.getNext();
/*      */     } 
/*      */     
/* 2444 */     this.cfw.add(178, "org/mozilla/javascript/ScriptRuntime", "emptyArgs", "[Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2449 */     this.cfw.addInvoke(184, this.codegen.mainClassName, (type == 30) ? this.codegen
/*      */ 
/*      */ 
/*      */         
/* 2453 */         .getDirectCtorName((ScriptNode)target.fnode) : this.codegen
/* 2454 */         .getBodyMethodName((ScriptNode)target.fnode), this.codegen
/* 2455 */         .getBodyMethodSignature((ScriptNode)target.fnode));
/*      */     
/* 2457 */     this.cfw.add(167, beyond);
/*      */     
/* 2459 */     this.cfw.markLabel(regularCall);
/*      */     
/* 2461 */     this.cfw.addALoad(this.contextLocal);
/* 2462 */     this.cfw.addALoad(this.variableObjectLocal);
/*      */     
/* 2464 */     if (type != 30) {
/* 2465 */       this.cfw.addALoad(thisObjLocal);
/* 2466 */       releaseWordLocal(thisObjLocal);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2471 */     generateCallArgArray(node, firstArgChild, true);
/*      */     
/* 2473 */     if (type == 30) {
/* 2474 */       addScriptRuntimeInvoke("newObject", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 2482 */       this.cfw.addInvoke(185, "org/mozilla/javascript/Callable", "call", "(Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2493 */     this.cfw.markLabel(beyond);
/*      */   }
/*      */   
/*      */   private void generateCallArgArray(Node node, Node argChild, boolean directCall) {
/* 2497 */     int argCount = 0;
/* 2498 */     for (Node child = argChild; child != null; child = child.getNext()) {
/* 2499 */       argCount++;
/*      */     }
/*      */     
/* 2502 */     if (argCount == 1 && this.itsOneArgArray >= 0) {
/* 2503 */       this.cfw.addALoad(this.itsOneArgArray);
/*      */     } else {
/* 2505 */       addNewObjectArray(argCount);
/*      */     } 
/*      */     
/* 2508 */     for (int i = 0; i != argCount; i++) {
/*      */ 
/*      */ 
/*      */       
/* 2512 */       if (!this.isGenerator) {
/* 2513 */         this.cfw.add(89);
/* 2514 */         this.cfw.addPush(i);
/*      */       } 
/*      */       
/* 2517 */       if (!directCall) {
/* 2518 */         generateExpression(argChild, node);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2525 */         int dcp_register = nodeIsDirectCallParameter(argChild);
/* 2526 */         if (dcp_register >= 0) {
/* 2527 */           dcpLoadAsObject(dcp_register);
/*      */         } else {
/* 2529 */           generateExpression(argChild, node);
/* 2530 */           int childNumberFlag = argChild.getIntProp(8, -1);
/* 2531 */           if (childNumberFlag == 0) {
/* 2532 */             addDoubleWrap();
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2540 */       if (this.isGenerator) {
/* 2541 */         short tempLocal = getNewWordLocal();
/* 2542 */         this.cfw.addAStore(tempLocal);
/* 2543 */         this.cfw.add(192, "[Ljava/lang/Object;");
/* 2544 */         this.cfw.add(89);
/* 2545 */         this.cfw.addPush(i);
/* 2546 */         this.cfw.addALoad(tempLocal);
/* 2547 */         releaseWordLocal(tempLocal);
/*      */       } 
/*      */       
/* 2550 */       this.cfw.add(83);
/*      */       
/* 2552 */       argChild = argChild.getNext();
/*      */     } 
/*      */   } private void generateFunctionAndThisObj(Node node, Node parent) {
/*      */     Node target;
/*      */     String name;
/*      */     Node id;
/* 2558 */     int type = node.getType();
/* 2559 */     switch (node.getType()) {
/*      */       case 34:
/* 2561 */         throw Kit.codeBug();
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 36:
/* 2566 */         target = node.getFirstChild();
/* 2567 */         generateExpression(target, node);
/* 2568 */         id = target.getNext();
/* 2569 */         if (type == 33) {
/* 2570 */           String property = id.getString();
/* 2571 */           this.cfw.addPush(property);
/* 2572 */           this.cfw.addALoad(this.contextLocal);
/* 2573 */           this.cfw.addALoad(this.variableObjectLocal);
/* 2574 */           addScriptRuntimeInvoke("getPropFunctionAndThis", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Callable;");
/*      */ 
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */ 
/*      */         
/* 2582 */         generateExpression(id, node);
/* 2583 */         if (node.getIntProp(8, -1) != -1) addDoubleWrap(); 
/* 2584 */         this.cfw.addALoad(this.contextLocal);
/* 2585 */         this.cfw.addALoad(this.variableObjectLocal);
/* 2586 */         addScriptRuntimeInvoke("getElemFunctionAndThis", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Callable;");
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/* 2599 */         name = node.getString();
/* 2600 */         this.cfw.addPush(name);
/* 2601 */         this.cfw.addALoad(this.contextLocal);
/* 2602 */         this.cfw.addALoad(this.variableObjectLocal);
/* 2603 */         addScriptRuntimeInvoke("getNameFunctionAndThis", "(Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Callable;");
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 2613 */         generateExpression(node, parent);
/* 2614 */         this.cfw.addALoad(this.contextLocal);
/* 2615 */         addScriptRuntimeInvoke("getValueFunctionAndThis", "(Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/Callable;");
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2623 */     this.cfw.addALoad(this.contextLocal);
/* 2624 */     addScriptRuntimeInvoke("lastStoredScriptable", "(Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/Scriptable;");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateLineNumber(Node node) {
/* 2630 */     this.itsLineNumber = node.getLineno();
/* 2631 */     if (this.itsLineNumber == -1)
/* 2632 */       return;  this.cfw.addLineNumberEntry((short)this.itsLineNumber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitTryCatchFinally(Jump node, Node child) {
/* 2648 */     short savedVariableObject = getNewWordLocal();
/* 2649 */     this.cfw.addALoad(this.variableObjectLocal);
/* 2650 */     this.cfw.addAStore(savedVariableObject);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2657 */     int startLabel = this.cfw.acquireLabel();
/* 2658 */     this.cfw.markLabel(startLabel, (short)0);
/*      */     
/* 2660 */     Node catchTarget = node.target;
/* 2661 */     Node finallyTarget = node.getFinally();
/* 2662 */     int[] handlerLabels = new int[5];
/*      */     
/* 2664 */     this.exceptionManager.pushExceptionInfo(node);
/* 2665 */     if (catchTarget != null) {
/* 2666 */       handlerLabels[0] = this.cfw.acquireLabel();
/* 2667 */       handlerLabels[1] = this.cfw.acquireLabel();
/* 2668 */       handlerLabels[2] = this.cfw.acquireLabel();
/* 2669 */       Context cx = Context.getCurrentContext();
/* 2670 */       if (cx != null && cx.hasFeature(13)) {
/* 2671 */         handlerLabels[3] = this.cfw.acquireLabel();
/*      */       }
/*      */     } 
/* 2674 */     if (finallyTarget != null) {
/* 2675 */       handlerLabels[4] = this.cfw.acquireLabel();
/*      */     }
/* 2677 */     this.exceptionManager.setHandlers(handlerLabels, startLabel);
/*      */ 
/*      */     
/* 2680 */     if (this.isGenerator && finallyTarget != null) {
/* 2681 */       FinallyReturnPoint ret = new FinallyReturnPoint();
/* 2682 */       if (this.finallys == null) {
/* 2683 */         this.finallys = new HashMap<>();
/*      */       }
/*      */       
/* 2686 */       this.finallys.put(finallyTarget, ret);
/*      */       
/* 2688 */       this.finallys.put(finallyTarget.getNext(), ret);
/*      */     } 
/*      */     
/* 2691 */     while (child != null) {
/* 2692 */       if (child == catchTarget) {
/* 2693 */         int catchLabel = getTargetLabel(catchTarget);
/* 2694 */         this.exceptionManager.removeHandler(0, catchLabel);
/* 2695 */         this.exceptionManager.removeHandler(1, catchLabel);
/* 2696 */         this.exceptionManager.removeHandler(2, catchLabel);
/* 2697 */         this.exceptionManager.removeHandler(3, catchLabel);
/*      */       } 
/* 2699 */       generateStatement(child);
/* 2700 */       child = child.getNext();
/*      */     } 
/*      */ 
/*      */     
/* 2704 */     int realEnd = this.cfw.acquireLabel();
/* 2705 */     this.cfw.add(167, realEnd);
/*      */     
/* 2707 */     int exceptionLocal = getLocalBlockRegister((Node)node);
/*      */ 
/*      */     
/* 2710 */     if (catchTarget != null) {
/*      */       
/* 2712 */       int catchLabel = catchTarget.labelId();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2719 */       generateCatchBlock(0, savedVariableObject, catchLabel, exceptionLocal, handlerLabels[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2729 */       generateCatchBlock(1, savedVariableObject, catchLabel, exceptionLocal, handlerLabels[1]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2740 */       generateCatchBlock(2, savedVariableObject, catchLabel, exceptionLocal, handlerLabels[2]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2747 */       Context cx = Context.getCurrentContext();
/* 2748 */       if (cx != null && cx.hasFeature(13)) {
/* 2749 */         generateCatchBlock(3, savedVariableObject, catchLabel, exceptionLocal, handlerLabels[3]);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2760 */     if (finallyTarget != null) {
/* 2761 */       int finallyHandler = this.cfw.acquireLabel();
/* 2762 */       int finallyEnd = this.cfw.acquireLabel();
/* 2763 */       this.cfw.markHandler(finallyHandler);
/* 2764 */       if (!this.isGenerator) {
/* 2765 */         this.cfw.markLabel(handlerLabels[4]);
/*      */       }
/* 2767 */       this.cfw.addAStore(exceptionLocal);
/*      */ 
/*      */       
/* 2770 */       this.cfw.addALoad(savedVariableObject);
/* 2771 */       this.cfw.addAStore(this.variableObjectLocal);
/*      */ 
/*      */       
/* 2774 */       int finallyLabel = finallyTarget.labelId();
/* 2775 */       if (this.isGenerator) { addGotoWithReturn(finallyTarget); }
/*      */       else
/* 2777 */       { inlineFinally(finallyTarget, handlerLabels[4], finallyEnd); }
/*      */ 
/*      */ 
/*      */       
/* 2781 */       this.cfw.addALoad(exceptionLocal);
/* 2782 */       if (this.isGenerator) this.cfw.add(192, "java/lang/Throwable"); 
/* 2783 */       this.cfw.add(191);
/*      */       
/* 2785 */       this.cfw.markLabel(finallyEnd);
/*      */       
/* 2787 */       if (this.isGenerator) {
/* 2788 */         this.cfw.addExceptionHandler(startLabel, finallyLabel, finallyHandler, null);
/*      */       }
/*      */     } 
/*      */     
/* 2792 */     releaseWordLocal(savedVariableObject);
/* 2793 */     this.cfw.markLabel(realEnd);
/*      */     
/* 2795 */     if (!this.isGenerator) {
/* 2796 */       this.exceptionManager.popExceptionInfo();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void generateCatchBlock(int exceptionType, short savedVariableObject, int catchLabel, int exceptionLocal, int handler) {
/* 2816 */     if (handler == 0) {
/* 2817 */       handler = this.cfw.acquireLabel();
/*      */     }
/* 2819 */     this.cfw.markHandler(handler);
/*      */ 
/*      */     
/* 2822 */     this.cfw.addAStore(exceptionLocal);
/*      */ 
/*      */     
/* 2825 */     this.cfw.addALoad(savedVariableObject);
/* 2826 */     this.cfw.addAStore(this.variableObjectLocal);
/*      */     
/* 2828 */     this.cfw.add(167, catchLabel);
/*      */   }
/*      */   
/*      */   private static String exceptionTypeToName(int exceptionType) {
/* 2832 */     if (exceptionType == 0)
/* 2833 */       return "org/mozilla/javascript/JavaScriptException"; 
/* 2834 */     if (exceptionType == 1)
/* 2835 */       return "org/mozilla/javascript/EvaluatorException"; 
/* 2836 */     if (exceptionType == 2)
/* 2837 */       return "org/mozilla/javascript/EcmaError"; 
/* 2838 */     if (exceptionType == 3)
/* 2839 */       return "java/lang/Throwable"; 
/* 2840 */     if (exceptionType == 4) {
/* 2841 */       return null;
/*      */     }
/* 2843 */     throw Kit.codeBug();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class ExceptionManager
/*      */   {
/* 2869 */     private LinkedList<ExceptionInfo> exceptionInfo = new LinkedList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void pushExceptionInfo(Jump node) {
/* 2878 */       Node fBlock = BodyCodegen.getFinallyAtTarget(node.getFinally());
/* 2879 */       ExceptionInfo ei = new ExceptionInfo(node, fBlock);
/* 2880 */       this.exceptionInfo.add(ei);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void addHandler(int exceptionType, int handlerLabel, int startLabel) {
/* 2892 */       ExceptionInfo top = getTop();
/* 2893 */       top.handlerLabels[exceptionType] = handlerLabel;
/* 2894 */       top.exceptionStarts[exceptionType] = startLabel;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setHandlers(int[] handlerLabels, int startLabel) {
/* 2906 */       for (int i = 0; i < handlerLabels.length; i++) {
/* 2907 */         if (handlerLabels[i] != 0) {
/* 2908 */           addHandler(i, handlerLabels[i], startLabel);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int removeHandler(int exceptionType, int endLabel) {
/* 2922 */       ExceptionInfo top = getTop();
/* 2923 */       if (top.handlerLabels[exceptionType] != 0) {
/* 2924 */         int handlerLabel = top.handlerLabels[exceptionType];
/* 2925 */         endCatch(top, exceptionType, endLabel);
/* 2926 */         top.handlerLabels[exceptionType] = 0;
/* 2927 */         return handlerLabel;
/*      */       } 
/* 2929 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     void popExceptionInfo() {
/* 2934 */       this.exceptionInfo.removeLast();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void markInlineFinallyStart(Node finallyBlock, int finallyStart) {
/* 2958 */       ListIterator<ExceptionInfo> iter = this.exceptionInfo.listIterator(this.exceptionInfo.size());
/* 2959 */       while (iter.hasPrevious()) {
/* 2960 */         ExceptionInfo ei = iter.previous();
/* 2961 */         for (int i = 0; i < 5; i++) {
/* 2962 */           if (ei.handlerLabels[i] != 0 && ei.currentFinally == null) {
/* 2963 */             endCatch(ei, i, finallyStart);
/* 2964 */             ei.exceptionStarts[i] = 0;
/* 2965 */             ei.currentFinally = finallyBlock;
/*      */           } 
/*      */         } 
/* 2968 */         if (ei.finallyBlock == finallyBlock) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void markInlineFinallyEnd(Node finallyBlock, int finallyEnd) {
/* 2984 */       ListIterator<ExceptionInfo> iter = this.exceptionInfo.listIterator(this.exceptionInfo.size());
/* 2985 */       while (iter.hasPrevious()) {
/* 2986 */         ExceptionInfo ei = iter.previous();
/* 2987 */         for (int i = 0; i < 5; i++) {
/* 2988 */           if (ei.handlerLabels[i] != 0 && ei.currentFinally == finallyBlock) {
/* 2989 */             ei.exceptionStarts[i] = finallyEnd;
/* 2990 */             ei.currentFinally = null;
/*      */           } 
/*      */         } 
/* 2993 */         if (ei.finallyBlock == finallyBlock) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void endCatch(ExceptionInfo ei, int exceptionType, int catchEnd) {
/* 3006 */       if (ei.exceptionStarts[exceptionType] == 0) {
/* 3007 */         throw new IllegalStateException("bad exception start");
/*      */       }
/*      */       
/* 3010 */       int currentStart = ei.exceptionStarts[exceptionType];
/* 3011 */       int currentStartPC = BodyCodegen.this.cfw.getLabelPC(currentStart);
/* 3012 */       int catchEndPC = BodyCodegen.this.cfw.getLabelPC(catchEnd);
/* 3013 */       if (currentStartPC != catchEndPC) {
/* 3014 */         BodyCodegen.this.cfw.addExceptionHandler(ei.exceptionStarts[exceptionType], catchEnd, ei.handlerLabels[exceptionType], BodyCodegen
/*      */ 
/*      */ 
/*      */             
/* 3018 */             .exceptionTypeToName(exceptionType));
/*      */       }
/*      */     }
/*      */     
/*      */     private ExceptionInfo getTop() {
/* 3023 */       return this.exceptionInfo.getLast();
/*      */     }
/*      */     private class ExceptionInfo { Node finallyBlock; int[] handlerLabels; int[] exceptionStarts; Node currentFinally;
/*      */       
/*      */       ExceptionInfo(Jump node, Node finallyBlock) {
/* 3028 */         this.finallyBlock = finallyBlock;
/* 3029 */         this.handlerLabels = new int[5];
/* 3030 */         this.exceptionStarts = new int[5];
/* 3031 */         this.currentFinally = null;
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3046 */   private ExceptionManager exceptionManager = new ExceptionManager(); static final int GENERATOR_TERMINATE = -1; static final int GENERATOR_START = 0; static final int GENERATOR_YIELD_START = 1; ClassFileWriter cfw; Codegen codegen; CompilerEnvirons compilerEnv; ScriptNode scriptOrFn; public int scriptOrFnIndex; private int savedCodeOffset; private OptFunctionNode fnCurrent; private static final int MAX_LOCALS = 1024; private int[] locals; private short firstFreeLocal;
/*      */   private short localsMax;
/*      */   private int itsLineNumber;
/*      */   private boolean hasVarsInRegs;
/*      */   private short[] varRegisters;
/*      */   private boolean inDirectCallFunction;
/*      */   private boolean itsForcedObjectParameters;
/*      */   private int enterAreaStartLabel;
/*      */   private int epilogueLabel;
/*      */   private boolean inLocalBlock;
/*      */   private short variableObjectLocal;
/*      */   private short popvLocal;
/*      */   private short contextLocal;
/*      */   private short argsLocal;
/*      */   private short operationLocal;
/*      */   private short thisObjLocal;
/*      */   private short funObjLocal;
/*      */   private short itsZeroArgArray;
/*      */   private short itsOneArgArray;
/*      */   private short generatorStateLocal;
/*      */   private boolean isGenerator;
/*      */   private int generatorSwitch;
/*      */   
/*      */   private void inlineFinally(Node finallyTarget, int finallyStart, int finallyEnd) {
/* 3070 */     Node fBlock = getFinallyAtTarget(finallyTarget);
/* 3071 */     fBlock.resetTargets();
/* 3072 */     Node child = fBlock.getFirstChild();
/* 3073 */     this.exceptionManager.markInlineFinallyStart(fBlock, finallyStart);
/* 3074 */     while (child != null) {
/* 3075 */       generateStatement(child);
/* 3076 */       child = child.getNext();
/*      */     } 
/* 3078 */     this.exceptionManager.markInlineFinallyEnd(fBlock, finallyEnd);
/*      */   }
/*      */   
/*      */   private void inlineFinally(Node finallyTarget) {
/* 3082 */     int finallyStart = this.cfw.acquireLabel();
/* 3083 */     int finallyEnd = this.cfw.acquireLabel();
/* 3084 */     this.cfw.markLabel(finallyStart);
/* 3085 */     inlineFinally(finallyTarget, finallyStart, finallyEnd);
/* 3086 */     this.cfw.markLabel(finallyEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Node getFinallyAtTarget(Node node) {
/* 3096 */     if (node == null) {
/* 3097 */       return null;
/*      */     }
/* 3099 */     if (node.getType() == 129) {
/* 3100 */       return node;
/*      */     }
/* 3102 */     if (node.getType() == 135) {
/* 3103 */       Node fBlock = node.getNext();
/* 3104 */       if (fBlock != null && fBlock.getType() == 129) {
/* 3105 */         return fBlock;
/*      */       }
/*      */     } 
/* 3108 */     throw Kit.codeBug("bad finally target");
/*      */   }
/*      */   
/*      */   private boolean generateSaveLocals(Node node) {
/* 3112 */     int count = 0;
/* 3113 */     for (int i = 0; i < this.firstFreeLocal; i++) {
/* 3114 */       if (this.locals[i] != 0) count++;
/*      */     
/*      */     } 
/* 3117 */     if (count == 0) {
/* 3118 */       ((FunctionNode)this.scriptOrFn).addLiveLocals(node, null);
/* 3119 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 3123 */     this.maxLocals = (this.maxLocals > count) ? this.maxLocals : count;
/*      */ 
/*      */     
/* 3126 */     int[] ls = new int[count];
/* 3127 */     int s = 0; int j;
/* 3128 */     for (j = 0; j < this.firstFreeLocal; j++) {
/* 3129 */       if (this.locals[j] != 0) {
/* 3130 */         ls[s] = j;
/* 3131 */         s++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3136 */     ((FunctionNode)this.scriptOrFn).addLiveLocals(node, ls);
/*      */ 
/*      */     
/* 3139 */     generateGetGeneratorLocalsState();
/* 3140 */     for (j = 0; j < count; j++) {
/* 3141 */       this.cfw.add(89);
/* 3142 */       this.cfw.addLoadConstant(j);
/* 3143 */       this.cfw.addALoad(ls[j]);
/* 3144 */       this.cfw.add(83);
/*      */     } 
/*      */     
/* 3147 */     this.cfw.add(87);
/*      */     
/* 3149 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitSwitch(Jump switchNode, Node child) {
/* 3156 */     generateExpression(child, (Node)switchNode);
/*      */     
/* 3158 */     short selector = getNewWordLocal();
/* 3159 */     this.cfw.addAStore(selector);
/*      */     
/* 3161 */     Jump caseNode = (Jump)child.getNext();
/* 3162 */     for (; caseNode != null; 
/* 3163 */       caseNode = (Jump)caseNode.getNext()) {
/* 3164 */       if (caseNode.getType() != 119) throw Codegen.badTree(); 
/* 3165 */       Node test = caseNode.getFirstChild();
/* 3166 */       generateExpression(test, (Node)caseNode);
/* 3167 */       this.cfw.addALoad(selector);
/* 3168 */       addScriptRuntimeInvoke("shallowEq", "(Ljava/lang/Object;Ljava/lang/Object;)Z");
/*      */       
/* 3170 */       addGoto(caseNode.target, 154);
/*      */     } 
/* 3172 */     releaseWordLocal(selector);
/*      */   }
/*      */   
/*      */   private void visitTypeofname(Node node) {
/* 3176 */     if (this.hasVarsInRegs) {
/* 3177 */       int varIndex = this.fnCurrent.fnode.getIndexForNameNode(node);
/* 3178 */       if (varIndex >= 0) {
/* 3179 */         if (this.fnCurrent.isNumberVar(varIndex)) {
/* 3180 */           this.cfw.addPush("number");
/* 3181 */         } else if (varIsDirectCallParameter(varIndex)) {
/* 3182 */           int dcp_register = this.varRegisters[varIndex];
/* 3183 */           this.cfw.addALoad(dcp_register);
/* 3184 */           this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/* 3185 */           int isNumberLabel = this.cfw.acquireLabel();
/* 3186 */           this.cfw.add(165, isNumberLabel);
/* 3187 */           short stack = this.cfw.getStackTop();
/* 3188 */           this.cfw.addALoad(dcp_register);
/* 3189 */           addScriptRuntimeInvoke("typeof", "(Ljava/lang/Object;)Ljava/lang/String;");
/* 3190 */           int beyond = this.cfw.acquireLabel();
/* 3191 */           this.cfw.add(167, beyond);
/* 3192 */           this.cfw.markLabel(isNumberLabel, stack);
/* 3193 */           this.cfw.addPush("number");
/* 3194 */           this.cfw.markLabel(beyond);
/*      */         } else {
/* 3196 */           this.cfw.addALoad(this.varRegisters[varIndex]);
/* 3197 */           addScriptRuntimeInvoke("typeof", "(Ljava/lang/Object;)Ljava/lang/String;");
/*      */         } 
/*      */         return;
/*      */       } 
/*      */     } 
/* 3202 */     this.cfw.addALoad(this.variableObjectLocal);
/* 3203 */     this.cfw.addPush(node.getString());
/* 3204 */     addScriptRuntimeInvoke("typeofName", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/String;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void saveCurrentCodeOffset() {
/* 3216 */     this.savedCodeOffset = this.cfw.getCurrentCodeOffset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addInstructionCount() {
/* 3225 */     int count = this.cfw.getCurrentCodeOffset() - this.savedCodeOffset;
/*      */ 
/*      */ 
/*      */     
/* 3229 */     addInstructionCount(Math.max(count, 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addInstructionCount(int count) {
/* 3239 */     this.cfw.addALoad(this.contextLocal);
/* 3240 */     this.cfw.addPush(count);
/* 3241 */     addScriptRuntimeInvoke("addInstructionCount", "(Lorg/mozilla/javascript/Context;I)V"); } private void visitIncDec(Node node) { boolean post; int varIndex;
/*      */     short reg;
/*      */     boolean[] constDeclarations;
/*      */     Node getPropChild, elemChild, refChild;
/* 3245 */     int incrDecrMask = node.getExistingIntProp(13);
/* 3246 */     Node child = node.getFirstChild();
/* 3247 */     switch (child.getType()) {
/*      */       case 55:
/* 3249 */         if (!this.hasVarsInRegs) Kit.codeBug(); 
/* 3250 */         post = ((incrDecrMask & 0x2) != 0);
/* 3251 */         varIndex = this.fnCurrent.getVarIndex(child);
/* 3252 */         reg = this.varRegisters[varIndex];
/* 3253 */         constDeclarations = this.fnCurrent.fnode.getParamAndVarConst();
/* 3254 */         if (constDeclarations[varIndex]) {
/* 3255 */           if (node.getIntProp(8, -1) != -1) {
/* 3256 */             int offset = varIsDirectCallParameter(varIndex) ? 1 : 0;
/* 3257 */             this.cfw.addDLoad(reg + offset);
/* 3258 */             if (!post) {
/* 3259 */               this.cfw.addPush(1.0D);
/* 3260 */               if ((incrDecrMask & 0x1) == 0) {
/* 3261 */                 this.cfw.add(99);
/*      */               } else {
/* 3263 */                 this.cfw.add(103);
/*      */               } 
/*      */             } 
/*      */           } else {
/* 3267 */             if (varIsDirectCallParameter(varIndex)) {
/* 3268 */               dcpLoadAsObject(reg);
/*      */             } else {
/* 3270 */               this.cfw.addALoad(reg);
/*      */             } 
/* 3272 */             if (post) {
/* 3273 */               this.cfw.add(89);
/* 3274 */               addObjectToDouble();
/* 3275 */               this.cfw.add(88);
/*      */             } else {
/* 3277 */               addObjectToDouble();
/* 3278 */               this.cfw.addPush(1.0D);
/* 3279 */               if ((incrDecrMask & 0x1) == 0) {
/* 3280 */                 this.cfw.add(99);
/*      */               } else {
/* 3282 */                 this.cfw.add(103);
/*      */               } 
/* 3284 */               addDoubleWrap();
/*      */             }
/*      */           
/*      */           }
/*      */         
/* 3289 */         } else if (node.getIntProp(8, -1) != -1) {
/* 3290 */           int offset = varIsDirectCallParameter(varIndex) ? 1 : 0;
/* 3291 */           this.cfw.addDLoad(reg + offset);
/* 3292 */           if (post) {
/* 3293 */             this.cfw.add(92);
/*      */           }
/* 3295 */           this.cfw.addPush(1.0D);
/* 3296 */           if ((incrDecrMask & 0x1) == 0) {
/* 3297 */             this.cfw.add(99);
/*      */           } else {
/* 3299 */             this.cfw.add(103);
/*      */           } 
/* 3301 */           if (!post) {
/* 3302 */             this.cfw.add(92);
/*      */           }
/* 3304 */           this.cfw.addDStore(reg + offset);
/*      */         } else {
/* 3306 */           if (varIsDirectCallParameter(varIndex)) {
/* 3307 */             dcpLoadAsObject(reg);
/*      */           } else {
/* 3309 */             this.cfw.addALoad(reg);
/*      */           } 
/* 3311 */           addObjectToDouble();
/* 3312 */           if (post) {
/* 3313 */             this.cfw.add(92);
/*      */           }
/* 3315 */           this.cfw.addPush(1.0D);
/* 3316 */           if ((incrDecrMask & 0x1) == 0) {
/* 3317 */             this.cfw.add(99);
/*      */           } else {
/* 3319 */             this.cfw.add(103);
/*      */           } 
/* 3321 */           addDoubleWrap();
/* 3322 */           if (!post) {
/* 3323 */             this.cfw.add(89);
/*      */           }
/* 3325 */           this.cfw.addAStore(reg);
/* 3326 */           if (post) {
/* 3327 */             addDoubleWrap();
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 39:
/* 3332 */         this.cfw.addALoad(this.variableObjectLocal);
/* 3333 */         this.cfw.addPush(child.getString());
/* 3334 */         this.cfw.addALoad(this.contextLocal);
/* 3335 */         this.cfw.addPush(incrDecrMask);
/* 3336 */         addScriptRuntimeInvoke("nameIncrDecr", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;I)Ljava/lang/Object;");
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 34:
/* 3344 */         throw Kit.codeBug();
/*      */       
/*      */       case 33:
/* 3347 */         getPropChild = child.getFirstChild();
/* 3348 */         generateExpression(getPropChild, node);
/* 3349 */         generateExpression(getPropChild.getNext(), node);
/* 3350 */         this.cfw.addALoad(this.contextLocal);
/* 3351 */         this.cfw.addALoad(this.variableObjectLocal);
/* 3352 */         this.cfw.addPush(incrDecrMask);
/* 3353 */         addScriptRuntimeInvoke("propIncrDecr", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 36:
/* 3364 */         elemChild = child.getFirstChild();
/* 3365 */         generateExpression(elemChild, node);
/* 3366 */         generateExpression(elemChild.getNext(), node);
/* 3367 */         this.cfw.addALoad(this.contextLocal);
/* 3368 */         this.cfw.addALoad(this.variableObjectLocal);
/* 3369 */         this.cfw.addPush(incrDecrMask);
/* 3370 */         if (elemChild.getNext().getIntProp(8, -1) != -1) {
/* 3371 */           addOptRuntimeInvoke("elemIncrDecr", "(Ljava/lang/Object;DLorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */           
/* 3380 */           addScriptRuntimeInvoke("elemIncrDecr", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 68:
/* 3393 */         refChild = child.getFirstChild();
/* 3394 */         generateExpression(refChild, node);
/* 3395 */         this.cfw.addALoad(this.contextLocal);
/* 3396 */         this.cfw.addALoad(this.variableObjectLocal);
/* 3397 */         this.cfw.addPush(incrDecrMask);
/* 3398 */         addScriptRuntimeInvoke("refIncrDecr", "(Lorg/mozilla/javascript/Ref;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;I)Ljava/lang/Object;");
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3407 */     Codegen.badTree(); }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isArithmeticNode(Node node) {
/* 3412 */     int type = node.getType();
/* 3413 */     return (type == 22 || type == 25 || type == 24 || type == 23);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitArithmetic(Node node, int type, Node child, Node parent) {
/* 3420 */     int childNumberFlag = node.getIntProp(8, -1);
/* 3421 */     if (childNumberFlag != -1) {
/* 3422 */       generateExpression(child, node);
/* 3423 */       generateExpression(child.getNext(), node);
/*      */       
/* 3425 */       switch (type) {
/*      */         case 22:
/* 3427 */           this.cfw.add(103);
/*      */           return;
/*      */         case 23:
/* 3430 */           this.cfw.add(107);
/*      */           return;
/*      */         case 24:
/* 3433 */           this.cfw.add(111);
/*      */           return;
/*      */         case 25:
/* 3436 */           this.cfw.add(115);
/*      */           return;
/*      */       } 
/* 3439 */       throw Kit.codeBug(Token.typeToName(type));
/*      */     } 
/*      */     
/* 3442 */     generateExpression(child, node);
/* 3443 */     if (!isArithmeticNode(child)) addObjectToNumeric(); 
/* 3444 */     generateExpression(child.getNext(), node);
/* 3445 */     if (!isArithmeticNode(child.getNext())) addObjectToNumeric();
/*      */     
/* 3447 */     switch (type) {
/*      */       case 22:
/* 3449 */         addScriptRuntimeInvoke("subtract", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */         return;
/*      */       
/*      */       case 23:
/* 3453 */         addScriptRuntimeInvoke("multiply", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */         return;
/*      */       
/*      */       case 24:
/* 3457 */         addScriptRuntimeInvoke("divide", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */         return;
/*      */       
/*      */       case 25:
/* 3461 */         addScriptRuntimeInvoke("remainder", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 3466 */     throw Kit.codeBug(Token.typeToName(type));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitExponentiation(Node node, Node child, Node parent) {
/* 3472 */     int childNumberFlag = node.getIntProp(8, -1);
/* 3473 */     if (childNumberFlag != -1) {
/* 3474 */       generateExpression(child, node);
/* 3475 */       generateExpression(child.getNext(), node);
/* 3476 */       this.cfw.addInvoke(184, "java/lang/Math", "pow", "(DD)D");
/*      */     } else {
/* 3478 */       generateExpression(child, node);
/* 3479 */       generateExpression(child.getNext(), node);
/*      */       
/* 3481 */       short reg = getNewWordLocal();
/* 3482 */       this.cfw.addAStore(reg);
/* 3483 */       addObjectToNumeric();
/* 3484 */       this.cfw.addALoad(reg);
/* 3485 */       addObjectToNumeric();
/*      */       
/* 3487 */       addScriptRuntimeInvoke("exponentiate", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void visitBitNot(Node node, Node child) {
/* 3493 */     int childNumberFlag = node.getIntProp(8, -1);
/* 3494 */     generateExpression(child, node);
/* 3495 */     if (childNumberFlag == -1) {
/* 3496 */       addObjectToNumeric();
/* 3497 */       addScriptRuntimeInvoke("bitwiseNOT", "(Ljava/lang/Number;)Ljava/lang/Number;");
/*      */     } else {
/* 3499 */       addScriptRuntimeInvoke("toInt32", "(D)I");
/* 3500 */       this.cfw.addPush(-1);
/* 3501 */       this.cfw.add(130);
/* 3502 */       this.cfw.add(135);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitBitOp(Node node, int type, Node child) {
/* 3507 */     int childNumberFlag = node.getIntProp(8, -1);
/* 3508 */     generateExpression(child, node);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3513 */     if (type == 20) {
/* 3514 */       addScriptRuntimeInvoke("toUint32", "(Ljava/lang/Object;)J");
/* 3515 */       generateExpression(child.getNext(), node);
/* 3516 */       addScriptRuntimeInvoke("toInt32", "(Ljava/lang/Object;)I");
/*      */ 
/*      */       
/* 3519 */       this.cfw.addPush(31);
/* 3520 */       this.cfw.add(126);
/* 3521 */       this.cfw.add(125);
/* 3522 */       this.cfw.add(138);
/* 3523 */       addDoubleWrap();
/*      */       return;
/*      */     } 
/* 3526 */     if (childNumberFlag == -1) {
/* 3527 */       addObjectToNumeric();
/* 3528 */       generateExpression(child.getNext(), node);
/* 3529 */       addObjectToNumeric();
/*      */       
/* 3531 */       switch (type) {
/*      */         case 9:
/* 3533 */           addScriptRuntimeInvoke("bitwiseOR", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */           return;
/*      */ 
/*      */         
/*      */         case 10:
/* 3538 */           addScriptRuntimeInvoke("bitwiseXOR", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */           return;
/*      */ 
/*      */         
/*      */         case 11:
/* 3543 */           addScriptRuntimeInvoke("bitwiseAND", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */           return;
/*      */ 
/*      */         
/*      */         case 19:
/* 3548 */           addScriptRuntimeInvoke("signedRightShift", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */           return;
/*      */ 
/*      */         
/*      */         case 18:
/* 3553 */           addScriptRuntimeInvoke("leftShift", "(Ljava/lang/Number;Ljava/lang/Number;)Ljava/lang/Number;");
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/* 3558 */       throw Kit.codeBug(Token.typeToName(type));
/*      */     } 
/*      */     
/* 3561 */     addScriptRuntimeInvoke("toInt32", "(D)I");
/* 3562 */     generateExpression(child.getNext(), node);
/* 3563 */     addScriptRuntimeInvoke("toInt32", "(D)I");
/*      */     
/* 3565 */     switch (type) {
/*      */       case 9:
/* 3567 */         this.cfw.add(128);
/*      */         break;
/*      */       case 10:
/* 3570 */         this.cfw.add(130);
/*      */         break;
/*      */       case 11:
/* 3573 */         this.cfw.add(126);
/*      */         break;
/*      */       case 19:
/* 3576 */         this.cfw.add(122);
/*      */         break;
/*      */       case 18:
/* 3579 */         this.cfw.add(120);
/*      */         break;
/*      */       default:
/* 3582 */         throw Kit.codeBug(Token.typeToName(type));
/*      */     } 
/* 3584 */     this.cfw.add(135);
/*      */   }
/*      */ 
/*      */   
/*      */   private int nodeIsDirectCallParameter(Node node) {
/* 3589 */     if (node.getType() == 55 && this.inDirectCallFunction && !this.itsForcedObjectParameters) {
/* 3590 */       int varIndex = this.fnCurrent.getVarIndex(node);
/* 3591 */       if (this.fnCurrent.isParameter(varIndex)) {
/* 3592 */         return this.varRegisters[varIndex];
/*      */       }
/*      */     } 
/* 3595 */     return -1;
/*      */   }
/*      */   
/*      */   private boolean varIsDirectCallParameter(int varIndex) {
/* 3599 */     return (this.fnCurrent.isParameter(varIndex) && this.inDirectCallFunction && !this.itsForcedObjectParameters);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void genSimpleCompare(int type, int trueGOTO, int falseGOTO) {
/* 3605 */     if (trueGOTO == -1) throw Codegen.badTree(); 
/* 3606 */     switch (type) {
/*      */       case 15:
/* 3608 */         this.cfw.add(152);
/* 3609 */         this.cfw.add(158, trueGOTO);
/*      */         break;
/*      */       case 17:
/* 3612 */         this.cfw.add(151);
/* 3613 */         this.cfw.add(156, trueGOTO);
/*      */         break;
/*      */       case 14:
/* 3616 */         this.cfw.add(152);
/* 3617 */         this.cfw.add(155, trueGOTO);
/*      */         break;
/*      */       case 16:
/* 3620 */         this.cfw.add(151);
/* 3621 */         this.cfw.add(157, trueGOTO);
/*      */         break;
/*      */       default:
/* 3624 */         throw Codegen.badTree();
/*      */     } 
/* 3626 */     if (falseGOTO != -1) this.cfw.add(167, falseGOTO); 
/*      */   }
/*      */   
/*      */   private void visitIfJumpRelOp(Node node, Node child, int trueGOTO, int falseGOTO) {
/* 3630 */     if (trueGOTO == -1 || falseGOTO == -1) throw Codegen.badTree(); 
/* 3631 */     int type = node.getType();
/* 3632 */     Node rChild = child.getNext();
/* 3633 */     if (type == 53 || type == 52) {
/* 3634 */       generateExpression(child, node);
/* 3635 */       generateExpression(rChild, node);
/* 3636 */       this.cfw.addALoad(this.contextLocal);
/* 3637 */       addScriptRuntimeInvoke((type == 53) ? "instanceOf" : "in", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;)Z");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3643 */       this.cfw.add(154, trueGOTO);
/* 3644 */       this.cfw.add(167, falseGOTO);
/*      */       return;
/*      */     } 
/* 3647 */     int childNumberFlag = node.getIntProp(8, -1);
/* 3648 */     int left_dcp_register = nodeIsDirectCallParameter(child);
/* 3649 */     int right_dcp_register = nodeIsDirectCallParameter(rChild);
/* 3650 */     if (childNumberFlag != -1) {
/*      */ 
/*      */ 
/*      */       
/* 3654 */       if (childNumberFlag != 2) {
/*      */         
/* 3656 */         generateExpression(child, node);
/* 3657 */       } else if (left_dcp_register != -1) {
/* 3658 */         dcpLoadAsNumber(left_dcp_register);
/*      */       } else {
/* 3660 */         generateExpression(child, node);
/* 3661 */         addObjectToDouble();
/*      */       } 
/*      */       
/* 3664 */       if (childNumberFlag != 1) {
/*      */         
/* 3666 */         generateExpression(rChild, node);
/* 3667 */       } else if (right_dcp_register != -1) {
/* 3668 */         dcpLoadAsNumber(right_dcp_register);
/*      */       } else {
/* 3670 */         generateExpression(rChild, node);
/* 3671 */         addObjectToDouble();
/*      */       } 
/*      */       
/* 3674 */       genSimpleCompare(type, trueGOTO, falseGOTO);
/*      */     } else {
/*      */       
/* 3677 */       if (left_dcp_register != -1 && right_dcp_register != -1) {
/*      */ 
/*      */         
/* 3680 */         short stack = this.cfw.getStackTop();
/* 3681 */         int leftIsNotNumber = this.cfw.acquireLabel();
/* 3682 */         this.cfw.addALoad(left_dcp_register);
/* 3683 */         this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/* 3684 */         this.cfw.add(166, leftIsNotNumber);
/* 3685 */         this.cfw.addDLoad(left_dcp_register + 1);
/* 3686 */         dcpLoadAsNumber(right_dcp_register);
/* 3687 */         genSimpleCompare(type, trueGOTO, falseGOTO);
/* 3688 */         if (stack != this.cfw.getStackTop()) throw Codegen.badTree();
/*      */         
/* 3690 */         this.cfw.markLabel(leftIsNotNumber);
/* 3691 */         int rightIsNotNumber = this.cfw.acquireLabel();
/* 3692 */         this.cfw.addALoad(right_dcp_register);
/* 3693 */         this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/* 3694 */         this.cfw.add(166, rightIsNotNumber);
/* 3695 */         this.cfw.addALoad(left_dcp_register);
/* 3696 */         addObjectToDouble();
/* 3697 */         this.cfw.addDLoad(right_dcp_register + 1);
/* 3698 */         genSimpleCompare(type, trueGOTO, falseGOTO);
/* 3699 */         if (stack != this.cfw.getStackTop()) throw Codegen.badTree();
/*      */         
/* 3701 */         this.cfw.markLabel(rightIsNotNumber);
/*      */         
/* 3703 */         this.cfw.addALoad(left_dcp_register);
/* 3704 */         this.cfw.addALoad(right_dcp_register);
/*      */       } else {
/*      */         
/* 3707 */         generateExpression(child, node);
/* 3708 */         generateExpression(rChild, node);
/*      */       } 
/*      */       
/* 3711 */       this.cfw.addPush(type);
/* 3712 */       addScriptRuntimeInvoke("compare", "(Ljava/lang/Object;Ljava/lang/Object;I)Z");
/* 3713 */       this.cfw.add(154, trueGOTO);
/* 3714 */       this.cfw.add(167, falseGOTO);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitIfJumpEqOp(Node node, Node child, int trueGOTO, int falseGOTO) {
/* 3719 */     if (trueGOTO == -1 || falseGOTO == -1) throw Codegen.badTree();
/*      */     
/* 3721 */     short stackInitial = this.cfw.getStackTop();
/* 3722 */     int type = node.getType();
/* 3723 */     Node rChild = child.getNext();
/*      */ 
/*      */     
/* 3726 */     if (child.getType() == 42 || rChild.getType() == 42) {
/*      */       
/* 3728 */       if (child.getType() == 42) {
/* 3729 */         child = rChild;
/*      */       }
/* 3731 */       generateExpression(child, node);
/* 3732 */       if (type == 46 || type == 47) {
/* 3733 */         int testCode = (type == 46) ? 198 : 199;
/* 3734 */         this.cfw.add(testCode, trueGOTO);
/*      */       } else {
/* 3736 */         if (type != 12) {
/*      */           
/* 3738 */           if (type != 13) throw Codegen.badTree(); 
/* 3739 */           int tmp = trueGOTO;
/* 3740 */           trueGOTO = falseGOTO;
/* 3741 */           falseGOTO = tmp;
/*      */         } 
/* 3743 */         this.cfw.add(89);
/* 3744 */         int undefCheckLabel = this.cfw.acquireLabel();
/* 3745 */         this.cfw.add(199, undefCheckLabel);
/* 3746 */         short stack = this.cfw.getStackTop();
/* 3747 */         this.cfw.add(87);
/* 3748 */         this.cfw.add(167, trueGOTO);
/* 3749 */         this.cfw.markLabel(undefCheckLabel, stack);
/* 3750 */         Codegen.pushUndefined(this.cfw);
/* 3751 */         this.cfw.add(165, trueGOTO);
/*      */       } 
/* 3753 */       this.cfw.add(167, falseGOTO);
/*      */     } else {
/* 3755 */       String name; int testCode, child_dcp_register = nodeIsDirectCallParameter(child);
/* 3756 */       if (child_dcp_register != -1 && rChild.getType() == 153) {
/* 3757 */         Node convertChild = rChild.getFirstChild();
/* 3758 */         if (convertChild.getType() == 40) {
/* 3759 */           this.cfw.addALoad(child_dcp_register);
/* 3760 */           this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/* 3761 */           int notNumbersLabel = this.cfw.acquireLabel();
/* 3762 */           this.cfw.add(166, notNumbersLabel);
/* 3763 */           this.cfw.addDLoad(child_dcp_register + 1);
/* 3764 */           this.cfw.addPush(convertChild.getDouble());
/* 3765 */           this.cfw.add(151);
/* 3766 */           if (type == 12) { this.cfw.add(153, trueGOTO); }
/* 3767 */           else { this.cfw.add(154, trueGOTO); }
/* 3768 */            this.cfw.add(167, falseGOTO);
/* 3769 */           this.cfw.markLabel(notNumbersLabel);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 3774 */       generateExpression(child, node);
/* 3775 */       generateExpression(rChild, node);
/*      */ 
/*      */ 
/*      */       
/* 3779 */       switch (type) {
/*      */         case 12:
/* 3781 */           name = "eq";
/* 3782 */           testCode = 154;
/*      */           break;
/*      */         case 13:
/* 3785 */           name = "eq";
/* 3786 */           testCode = 153;
/*      */           break;
/*      */         case 46:
/* 3789 */           name = "shallowEq";
/* 3790 */           testCode = 154;
/*      */           break;
/*      */         case 47:
/* 3793 */           name = "shallowEq";
/* 3794 */           testCode = 153;
/*      */           break;
/*      */         default:
/* 3797 */           throw Codegen.badTree();
/*      */       } 
/* 3799 */       addScriptRuntimeInvoke(name, "(Ljava/lang/Object;Ljava/lang/Object;)Z");
/* 3800 */       this.cfw.add(testCode, trueGOTO);
/* 3801 */       this.cfw.add(167, falseGOTO);
/*      */     } 
/* 3803 */     if (stackInitial != this.cfw.getStackTop()) throw Codegen.badTree(); 
/*      */   }
/*      */   
/*      */   private void visitSetName(Node node, Node child) {
/* 3807 */     String name = node.getFirstChild().getString();
/* 3808 */     while (child != null) {
/* 3809 */       generateExpression(child, node);
/* 3810 */       child = child.getNext();
/*      */     } 
/* 3812 */     this.cfw.addALoad(this.contextLocal);
/* 3813 */     this.cfw.addALoad(this.variableObjectLocal);
/* 3814 */     this.cfw.addPush(name);
/* 3815 */     addScriptRuntimeInvoke("setName", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/Object;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitStrictSetName(Node node, Node child) {
/* 3826 */     String name = node.getFirstChild().getString();
/* 3827 */     while (child != null) {
/* 3828 */       generateExpression(child, node);
/* 3829 */       child = child.getNext();
/*      */     } 
/* 3831 */     this.cfw.addALoad(this.contextLocal);
/* 3832 */     this.cfw.addALoad(this.variableObjectLocal);
/* 3833 */     this.cfw.addPush(name);
/* 3834 */     addScriptRuntimeInvoke("strictSetName", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/Object;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitSetConst(Node node, Node child) {
/* 3845 */     String name = node.getFirstChild().getString();
/* 3846 */     while (child != null) {
/* 3847 */       generateExpression(child, node);
/* 3848 */       child = child.getNext();
/*      */     } 
/* 3850 */     this.cfw.addALoad(this.contextLocal);
/* 3851 */     this.cfw.addPush(name);
/* 3852 */     addScriptRuntimeInvoke("setConst", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Ljava/lang/String;)Ljava/lang/Object;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitGetVar(Node node) {
/* 3862 */     if (!this.hasVarsInRegs) Kit.codeBug(); 
/* 3863 */     int varIndex = this.fnCurrent.getVarIndex(node);
/* 3864 */     short reg = this.varRegisters[varIndex];
/* 3865 */     if (varIsDirectCallParameter(varIndex)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3870 */       if (node.getIntProp(8, -1) != -1) {
/* 3871 */         dcpLoadAsNumber(reg);
/*      */       } else {
/* 3873 */         dcpLoadAsObject(reg);
/*      */       } 
/* 3875 */     } else if (this.fnCurrent.isNumberVar(varIndex)) {
/* 3876 */       this.cfw.addDLoad(reg);
/*      */     } else {
/* 3878 */       this.cfw.addALoad(reg);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitSetVar(Node node, Node child, boolean needValue) {
/* 3883 */     if (!this.hasVarsInRegs) Kit.codeBug(); 
/* 3884 */     int varIndex = this.fnCurrent.getVarIndex(node);
/* 3885 */     generateExpression(child.getNext(), node);
/* 3886 */     boolean isNumber = (node.getIntProp(8, -1) != -1);
/* 3887 */     short reg = this.varRegisters[varIndex];
/* 3888 */     boolean[] constDeclarations = this.fnCurrent.fnode.getParamAndVarConst();
/* 3889 */     if (constDeclarations[varIndex]) {
/* 3890 */       if (!needValue)
/* 3891 */         if (isNumber) { this.cfw.add(88); }
/* 3892 */         else { this.cfw.add(87); }
/*      */          
/* 3894 */     } else if (varIsDirectCallParameter(varIndex)) {
/* 3895 */       if (isNumber) {
/* 3896 */         if (needValue) this.cfw.add(92); 
/* 3897 */         this.cfw.addALoad(reg);
/* 3898 */         this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/* 3899 */         int isNumberLabel = this.cfw.acquireLabel();
/* 3900 */         int beyond = this.cfw.acquireLabel();
/* 3901 */         this.cfw.add(165, isNumberLabel);
/* 3902 */         short stack = this.cfw.getStackTop();
/* 3903 */         addDoubleWrap();
/* 3904 */         this.cfw.addAStore(reg);
/* 3905 */         this.cfw.add(167, beyond);
/* 3906 */         this.cfw.markLabel(isNumberLabel, stack);
/* 3907 */         this.cfw.addDStore(reg + 1);
/* 3908 */         this.cfw.markLabel(beyond);
/*      */       } else {
/* 3910 */         if (needValue) this.cfw.add(89); 
/* 3911 */         this.cfw.addAStore(reg);
/*      */       } 
/*      */     } else {
/* 3914 */       boolean isNumberVar = this.fnCurrent.isNumberVar(varIndex);
/* 3915 */       if (isNumber) {
/* 3916 */         if (isNumberVar) {
/* 3917 */           this.cfw.addDStore(reg);
/* 3918 */           if (needValue) this.cfw.addDLoad(reg); 
/*      */         } else {
/* 3920 */           if (needValue) this.cfw.add(92);
/*      */ 
/*      */           
/* 3923 */           addDoubleWrap();
/* 3924 */           this.cfw.addAStore(reg);
/*      */         } 
/*      */       } else {
/* 3927 */         if (isNumberVar) Kit.codeBug(); 
/* 3928 */         this.cfw.addAStore(reg);
/* 3929 */         if (needValue) this.cfw.addALoad(reg); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void visitSetConstVar(Node node, Node child, boolean needValue) {
/* 3935 */     if (!this.hasVarsInRegs) Kit.codeBug(); 
/* 3936 */     int varIndex = this.fnCurrent.getVarIndex(node);
/* 3937 */     generateExpression(child.getNext(), node);
/* 3938 */     boolean isNumber = (node.getIntProp(8, -1) != -1);
/* 3939 */     short reg = this.varRegisters[varIndex];
/* 3940 */     int beyond = this.cfw.acquireLabel();
/* 3941 */     int noAssign = this.cfw.acquireLabel();
/* 3942 */     if (isNumber) {
/* 3943 */       this.cfw.addILoad(reg + 2);
/* 3944 */       this.cfw.add(154, noAssign);
/* 3945 */       short stack = this.cfw.getStackTop();
/* 3946 */       this.cfw.addPush(1);
/* 3947 */       this.cfw.addIStore(reg + 2);
/* 3948 */       this.cfw.addDStore(reg);
/* 3949 */       if (needValue) {
/* 3950 */         this.cfw.addDLoad(reg);
/* 3951 */         this.cfw.markLabel(noAssign, stack);
/*      */       } else {
/* 3953 */         this.cfw.add(167, beyond);
/* 3954 */         this.cfw.markLabel(noAssign, stack);
/* 3955 */         this.cfw.add(88);
/*      */       } 
/*      */     } else {
/* 3958 */       this.cfw.addILoad(reg + 1);
/* 3959 */       this.cfw.add(154, noAssign);
/* 3960 */       short stack = this.cfw.getStackTop();
/* 3961 */       this.cfw.addPush(1);
/* 3962 */       this.cfw.addIStore(reg + 1);
/* 3963 */       this.cfw.addAStore(reg);
/* 3964 */       if (needValue) {
/* 3965 */         this.cfw.addALoad(reg);
/* 3966 */         this.cfw.markLabel(noAssign, stack);
/*      */       } else {
/* 3968 */         this.cfw.add(167, beyond);
/* 3969 */         this.cfw.markLabel(noAssign, stack);
/* 3970 */         this.cfw.add(87);
/*      */       } 
/*      */     } 
/* 3973 */     this.cfw.markLabel(beyond);
/*      */   }
/*      */   
/*      */   private void visitGetProp(Node node, Node child) {
/* 3977 */     generateExpression(child, node);
/* 3978 */     Node nameChild = child.getNext();
/* 3979 */     generateExpression(nameChild, node);
/* 3980 */     if (node.getType() == 34) {
/* 3981 */       this.cfw.addALoad(this.contextLocal);
/* 3982 */       this.cfw.addALoad(this.variableObjectLocal);
/* 3983 */       addScriptRuntimeInvoke("getObjectPropNoWarn", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3996 */     int childType = child.getType();
/* 3997 */     if (childType == 43 && nameChild.getType() == 41) {
/* 3998 */       this.cfw.addALoad(this.contextLocal);
/* 3999 */       addScriptRuntimeInvoke("getObjectProp", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 4006 */       this.cfw.addALoad(this.contextLocal);
/* 4007 */       this.cfw.addALoad(this.variableObjectLocal);
/* 4008 */       addScriptRuntimeInvoke("getObjectProp", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitSetProp(int type, Node node, Node child) {
/* 4019 */     Node objectChild = child;
/* 4020 */     generateExpression(child, node);
/* 4021 */     child = child.getNext();
/* 4022 */     if (type == 143) {
/* 4023 */       this.cfw.add(89);
/*      */     }
/* 4025 */     Node nameChild = child;
/* 4026 */     generateExpression(child, node);
/* 4027 */     child = child.getNext();
/* 4028 */     if (type == 143) {
/*      */       
/* 4030 */       this.cfw.add(90);
/*      */ 
/*      */       
/* 4033 */       if (objectChild.getType() == 43 && nameChild.getType() == 41) {
/* 4034 */         this.cfw.addALoad(this.contextLocal);
/* 4035 */         addScriptRuntimeInvoke("getObjectProp", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Context;)Ljava/lang/Object;");
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 4042 */         this.cfw.addALoad(this.contextLocal);
/* 4043 */         this.cfw.addALoad(this.variableObjectLocal);
/* 4044 */         addScriptRuntimeInvoke("getObjectProp", "(Ljava/lang/Object;Ljava/lang/String;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4053 */     generateExpression(child, node);
/* 4054 */     this.cfw.addALoad(this.contextLocal);
/* 4055 */     this.cfw.addALoad(this.variableObjectLocal);
/* 4056 */     addScriptRuntimeInvoke("setObjectProp", "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitSetElem(int type, Node node, Node child) {
/* 4067 */     generateExpression(child, node);
/* 4068 */     child = child.getNext();
/* 4069 */     if (type == 144) {
/* 4070 */       this.cfw.add(89);
/*      */     }
/* 4072 */     generateExpression(child, node);
/* 4073 */     child = child.getNext();
/* 4074 */     boolean indexIsNumber = (node.getIntProp(8, -1) != -1);
/* 4075 */     if (type == 144) {
/* 4076 */       if (indexIsNumber) {
/*      */ 
/*      */         
/* 4079 */         this.cfw.add(93);
/* 4080 */         this.cfw.addALoad(this.contextLocal);
/* 4081 */         this.cfw.addALoad(this.variableObjectLocal);
/* 4082 */         addScriptRuntimeInvoke("getObjectIndex", "(Ljava/lang/Object;DLorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 4091 */         this.cfw.add(90);
/* 4092 */         this.cfw.addALoad(this.contextLocal);
/* 4093 */         this.cfw.addALoad(this.variableObjectLocal);
/* 4094 */         addScriptRuntimeInvoke("getObjectElem", "(Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4103 */     generateExpression(child, node);
/* 4104 */     this.cfw.addALoad(this.contextLocal);
/* 4105 */     this.cfw.addALoad(this.variableObjectLocal);
/* 4106 */     if (indexIsNumber) {
/* 4107 */       addScriptRuntimeInvoke("setObjectIndex", "(Ljava/lang/Object;DLjava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 4116 */       addScriptRuntimeInvoke("setObjectElem", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void visitDotQuery(Node node, Node child) {
/* 4128 */     updateLineNumber(node);
/* 4129 */     generateExpression(child, node);
/* 4130 */     this.cfw.addALoad(this.variableObjectLocal);
/* 4131 */     addScriptRuntimeInvoke("enterDotQuery", "(Ljava/lang/Object;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4136 */     this.cfw.addAStore(this.variableObjectLocal);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4141 */     this.cfw.add(1);
/* 4142 */     int queryLoopStart = this.cfw.acquireLabel();
/* 4143 */     this.cfw.markLabel(queryLoopStart);
/* 4144 */     this.cfw.add(87);
/*      */     
/* 4146 */     generateExpression(child.getNext(), node);
/* 4147 */     addScriptRuntimeInvoke("toBoolean", "(Ljava/lang/Object;)Z");
/* 4148 */     this.cfw.addALoad(this.variableObjectLocal);
/* 4149 */     addScriptRuntimeInvoke("updateDotQuery", "(ZLorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;");
/*      */ 
/*      */     
/* 4152 */     this.cfw.add(89);
/* 4153 */     this.cfw.add(198, queryLoopStart);
/*      */     
/* 4155 */     this.cfw.addALoad(this.variableObjectLocal);
/* 4156 */     addScriptRuntimeInvoke("leaveDotQuery", "(Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */     
/* 4159 */     this.cfw.addAStore(this.variableObjectLocal);
/*      */   }
/*      */   
/*      */   private static int getLocalBlockRegister(Node node) {
/* 4163 */     Node localBlock = (Node)node.getProp(3);
/* 4164 */     int localSlot = localBlock.getExistingIntProp(2);
/* 4165 */     return localSlot;
/*      */   }
/*      */   
/*      */   private void dcpLoadAsNumber(int dcp_register) {
/* 4169 */     this.cfw.addALoad(dcp_register);
/* 4170 */     this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/* 4171 */     int isNumberLabel = this.cfw.acquireLabel();
/* 4172 */     this.cfw.add(165, isNumberLabel);
/* 4173 */     short stack = this.cfw.getStackTop();
/* 4174 */     this.cfw.addALoad(dcp_register);
/* 4175 */     addObjectToDouble();
/* 4176 */     int beyond = this.cfw.acquireLabel();
/* 4177 */     this.cfw.add(167, beyond);
/* 4178 */     this.cfw.markLabel(isNumberLabel, stack);
/* 4179 */     this.cfw.addDLoad(dcp_register + 1);
/* 4180 */     this.cfw.markLabel(beyond);
/*      */   }
/*      */   
/*      */   private void dcpLoadAsObject(int dcp_register) {
/* 4184 */     this.cfw.addALoad(dcp_register);
/* 4185 */     this.cfw.add(178, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
/* 4186 */     int isNumberLabel = this.cfw.acquireLabel();
/* 4187 */     this.cfw.add(165, isNumberLabel);
/* 4188 */     short stack = this.cfw.getStackTop();
/* 4189 */     this.cfw.addALoad(dcp_register);
/* 4190 */     int beyond = this.cfw.acquireLabel();
/* 4191 */     this.cfw.add(167, beyond);
/* 4192 */     this.cfw.markLabel(isNumberLabel, stack);
/* 4193 */     this.cfw.addDLoad(dcp_register + 1);
/* 4194 */     addDoubleWrap();
/* 4195 */     this.cfw.markLabel(beyond);
/*      */   }
/*      */   
/*      */   private void addGoto(Node target, int jumpcode) {
/* 4199 */     int targetLabel = getTargetLabel(target);
/* 4200 */     this.cfw.add(jumpcode, targetLabel);
/*      */   }
/*      */   
/*      */   private void addObjectToDouble() {
/* 4204 */     addScriptRuntimeInvoke("toNumber", "(Ljava/lang/Object;)D");
/*      */   }
/*      */   
/*      */   private void addObjectToNumeric() {
/* 4208 */     addScriptRuntimeInvoke("toNumeric", "(Ljava/lang/Object;)Ljava/lang/Number;");
/*      */   }
/*      */   
/*      */   private void addNewObjectArray(int size) {
/* 4212 */     if (size == 0) {
/* 4213 */       if (this.itsZeroArgArray >= 0) {
/* 4214 */         this.cfw.addALoad(this.itsZeroArgArray);
/*      */       } else {
/* 4216 */         this.cfw.add(178, "org/mozilla/javascript/ScriptRuntime", "emptyArgs", "[Ljava/lang/Object;");
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 4223 */       this.cfw.addPush(size);
/* 4224 */       this.cfw.add(189, "java/lang/Object");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addScriptRuntimeInvoke(String methodName, String methodSignature) {
/* 4229 */     this.cfw.addInvoke(184, "org.mozilla.javascript.ScriptRuntime", methodName, methodSignature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addOptRuntimeInvoke(String methodName, String methodSignature) {
/* 4237 */     this.cfw.addInvoke(184, "org/mozilla/javascript/optimizer/OptRuntime", methodName, methodSignature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addJumpedBooleanWrap(int trueLabel, int falseLabel) {
/* 4245 */     this.cfw.markLabel(falseLabel);
/* 4246 */     int skip = this.cfw.acquireLabel();
/* 4247 */     this.cfw.add(178, "java/lang/Boolean", "FALSE", "Ljava/lang/Boolean;");
/* 4248 */     this.cfw.add(167, skip);
/* 4249 */     this.cfw.markLabel(trueLabel);
/* 4250 */     this.cfw.add(178, "java/lang/Boolean", "TRUE", "Ljava/lang/Boolean;");
/* 4251 */     this.cfw.markLabel(skip);
/* 4252 */     this.cfw.adjustStackTop(-1);
/*      */   }
/*      */   
/*      */   private void addDoubleWrap() {
/* 4256 */     addOptRuntimeInvoke("wrapDouble", "(D)Ljava/lang/Double;");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private short getNewWordPairLocal(boolean isConst) {
/* 4266 */     return getNewWordIntern(isConst ? 3 : 2);
/*      */   }
/*      */   
/*      */   private short getNewWordLocal(boolean isConst) {
/* 4270 */     return getNewWordIntern(isConst ? 2 : 1);
/*      */   }
/*      */   
/*      */   private short getNewWordLocal() {
/* 4274 */     return getNewWordIntern(1);
/*      */   }
/*      */   
/*      */   private short getNewWordIntern(int count) {
/* 4278 */     assert count >= 1 && count <= 3;
/*      */     
/* 4280 */     int[] locals = this.locals;
/* 4281 */     int result = -1;
/* 4282 */     if (count > 1) {
/*      */       int i;
/*      */       
/* 4285 */       label41: for (i = this.firstFreeLocal; i + count <= 1024; ) {
/* 4286 */         for (int j = 0; j < count; j++) {
/* 4287 */           if (locals[i + j] != 0) {
/* 4288 */             i += j + 1;
/*      */             continue label41;
/*      */           } 
/*      */         } 
/* 4292 */         result = i;
/*      */       } 
/*      */     } else {
/*      */       
/* 4296 */       result = this.firstFreeLocal;
/*      */     } 
/*      */     
/* 4299 */     if (result != -1) {
/* 4300 */       locals[result] = 1;
/* 4301 */       if (count > 1) locals[result + 1] = 1; 
/* 4302 */       if (count > 2) locals[result + 2] = 1;
/*      */       
/* 4304 */       if (result == this.firstFreeLocal) {
/* 4305 */         for (int i = result + count; i < 1024; i++) {
/* 4306 */           if (locals[i] == 0) {
/* 4307 */             this.firstFreeLocal = (short)i;
/* 4308 */             if (this.localsMax < this.firstFreeLocal) this.localsMax = this.firstFreeLocal; 
/* 4309 */             return (short)result;
/*      */           } 
/*      */         } 
/*      */       } else {
/* 4313 */         return (short)result;
/*      */       } 
/*      */     } 
/*      */     
/* 4317 */     throw Context.reportRuntimeError("Program too complex (out of locals)");
/*      */   }
/*      */ 
/*      */   
/*      */   private void incReferenceWordLocal(short local) {
/* 4322 */     this.locals[local] = this.locals[local] + 1;
/*      */   }
/*      */ 
/*      */   
/*      */   private void decReferenceWordLocal(short local) {
/* 4327 */     this.locals[local] = this.locals[local] - 1;
/*      */   }
/*      */   
/*      */   private void releaseWordLocal(short local) {
/* 4331 */     if (local < this.firstFreeLocal) this.firstFreeLocal = local; 
/* 4332 */     this.locals[local] = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4378 */   private int maxLocals = 0;
/* 4379 */   private int maxStack = 0;
/*      */   private Map<Node, FinallyReturnPoint> finallys;
/*      */   private List<Node> literals;
/*      */   
/*      */   static class FinallyReturnPoint
/*      */   {
/* 4385 */     public List<Integer> jsrPoints = new ArrayList<>();
/* 4386 */     public int tableLabel = 0;
/*      */   }
/*      */   
/* 4389 */   private int unnestedYieldCount = 0;
/* 4390 */   private IdentityHashMap<Node, String> unnestedYields = new IdentityHashMap<>();
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\optimizer\BodyCodegen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */