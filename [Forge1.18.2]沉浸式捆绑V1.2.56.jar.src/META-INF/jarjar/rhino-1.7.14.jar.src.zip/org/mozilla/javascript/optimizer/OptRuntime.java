/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import org.mozilla.javascript.ArrowFunction;
/*     */ import org.mozilla.javascript.Callable;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ContextFactory;
/*     */ import org.mozilla.javascript.ES6Generator;
/*     */ import org.mozilla.javascript.Function;
/*     */ import org.mozilla.javascript.JavaScriptException;
/*     */ import org.mozilla.javascript.NativeFunction;
/*     */ import org.mozilla.javascript.NativeGenerator;
/*     */ import org.mozilla.javascript.NativeIterator;
/*     */ import org.mozilla.javascript.Script;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OptRuntime
/*     */   extends ScriptRuntime
/*     */ {
/*  24 */   public static final Double oneObj = Double.valueOf(1.0D);
/*  25 */   public static final Double minusOneObj = Double.valueOf(-1.0D);
/*     */ 
/*     */   
/*     */   public static Object call0(Callable fun, Scriptable thisObj, Context cx, Scriptable scope) {
/*  29 */     return fun.call(cx, scope, thisObj, ScriptRuntime.emptyArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object call1(Callable fun, Scriptable thisObj, Object arg0, Context cx, Scriptable scope) {
/*  35 */     return fun.call(cx, scope, thisObj, new Object[] { arg0 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object call2(Callable fun, Scriptable thisObj, Object arg0, Object arg1, Context cx, Scriptable scope) {
/*  46 */     return fun.call(cx, scope, thisObj, new Object[] { arg0, arg1 });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object callN(Callable fun, Scriptable thisObj, Object[] args, Context cx, Scriptable scope) {
/*  52 */     return fun.call(cx, scope, thisObj, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object callName(Object[] args, String name, Context cx, Scriptable scope) {
/*  57 */     Callable f = getNameFunctionAndThis(name, cx, scope);
/*  58 */     Scriptable thisObj = lastStoredScriptable(cx);
/*  59 */     return f.call(cx, scope, thisObj, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object callName0(String name, Context cx, Scriptable scope) {
/*  64 */     Callable f = getNameFunctionAndThis(name, cx, scope);
/*  65 */     Scriptable thisObj = lastStoredScriptable(cx);
/*  66 */     return f.call(cx, scope, thisObj, ScriptRuntime.emptyArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object callProp0(Object value, String property, Context cx, Scriptable scope) {
/*  71 */     Callable f = getPropFunctionAndThis(value, property, cx, scope);
/*  72 */     Scriptable thisObj = lastStoredScriptable(cx);
/*  73 */     return f.call(cx, scope, thisObj, ScriptRuntime.emptyArgs);
/*     */   }
/*     */   
/*     */   public static Object add(Object val1, double val2, Context cx) {
/*  77 */     if (val1 instanceof Double) {
/*  78 */       return Double.valueOf(((Double)val1).doubleValue() + val2);
/*     */     }
/*  80 */     if (val1 instanceof Integer) {
/*  81 */       return Double.valueOf(((Integer)val1).intValue() + val2);
/*     */     }
/*  83 */     return ScriptRuntime.add(val1, Double.valueOf(val2), cx);
/*     */   }
/*     */   
/*     */   public static Object add(double val1, Object val2, Context cx) {
/*  87 */     if (val2 instanceof Double) {
/*  88 */       return Double.valueOf(val1 + ((Double)val2).doubleValue());
/*     */     }
/*  90 */     if (val2 instanceof Integer) {
/*  91 */       return Double.valueOf(val1 + ((Integer)val2).intValue());
/*     */     }
/*  93 */     return ScriptRuntime.add(Double.valueOf(val1), val2, cx);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Object elemIncrDecr(Object obj, double index, Context cx, int incrDecrMask) {
/*  99 */     return elemIncrDecr(obj, index, cx, getTopCallScope(cx), incrDecrMask);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object elemIncrDecr(Object obj, double index, Context cx, Scriptable scope, int incrDecrMask) {
/* 104 */     return ScriptRuntime.elemIncrDecr(obj, Double.valueOf(index), cx, scope, incrDecrMask);
/*     */   }
/*     */   
/*     */   public static Object[] padStart(Object[] currentArgs, int count) {
/* 108 */     Object[] result = new Object[currentArgs.length + count];
/* 109 */     System.arraycopy(currentArgs, 0, result, count, currentArgs.length);
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void initFunction(NativeFunction fn, int functionType, Scriptable scope, Context cx) {
/* 115 */     ScriptRuntime.initFunction(cx, scope, fn, functionType, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Function bindThis(NativeFunction fn, Context cx, Scriptable scope, Scriptable thisObj) {
/* 120 */     return (Function)new ArrowFunction(cx, scope, (Callable)fn, thisObj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object callSpecial(Context cx, Callable fun, Scriptable thisObj, Object[] args, Scriptable scope, Scriptable callerThis, int callType, String fileName, int lineNumber) {
/* 133 */     return ScriptRuntime.callSpecial(cx, fun, thisObj, args, scope, callerThis, callType, fileName, lineNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object newObjectSpecial(Context cx, Object fun, Object[] args, Scriptable scope, Scriptable callerThis, int callType) {
/* 144 */     return ScriptRuntime.newSpecial(cx, fun, args, scope, callType);
/*     */   }
/*     */   
/*     */   public static Double wrapDouble(double num) {
/* 148 */     if (num == 0.0D) {
/* 149 */       if (1.0D / num > 0.0D)
/*     */       {
/* 151 */         return zeroObj; } 
/*     */     } else {
/* 153 */       if (num == 1.0D)
/* 154 */         return oneObj; 
/* 155 */       if (num == -1.0D)
/* 156 */         return minusOneObj; 
/* 157 */       if (Double.isNaN(num))
/* 158 */         return NaNobj; 
/*     */     } 
/* 160 */     return Double.valueOf(num);
/*     */   }
/*     */ 
/*     */   
/*     */   static String encodeIntArray(int[] array) {
/* 165 */     if (array == null) {
/* 166 */       return null;
/*     */     }
/* 168 */     int n = array.length;
/* 169 */     char[] buffer = new char[1 + n * 2];
/* 170 */     buffer[0] = '\001';
/* 171 */     for (int i = 0; i != n; i++) {
/* 172 */       int value = array[i];
/* 173 */       int shift = 1 + i * 2;
/* 174 */       buffer[shift] = (char)(value >>> 16);
/* 175 */       buffer[shift + 1] = (char)value;
/*     */     } 
/* 177 */     return new String(buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int[] decodeIntArray(String str, int arraySize) {
/* 182 */     if (arraySize == 0) {
/* 183 */       if (str != null) throw new IllegalArgumentException(); 
/* 184 */       return null;
/*     */     } 
/* 186 */     if (str.length() != 1 + arraySize * 2 && str.charAt(0) != '\001') {
/* 187 */       throw new IllegalArgumentException();
/*     */     }
/* 189 */     int[] array = new int[arraySize];
/* 190 */     for (int i = 0; i != arraySize; i++) {
/* 191 */       int shift = 1 + i * 2;
/* 192 */       array[i] = str.charAt(shift) << 16 | str.charAt(shift + 1);
/*     */     } 
/* 194 */     return array;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Scriptable newArrayLiteral(Object[] objects, String encodedInts, int skipCount, Context cx, Scriptable scope) {
/* 199 */     int[] skipIndexces = decodeIntArray(encodedInts, skipCount);
/* 200 */     return newArrayLiteral(objects, skipIndexces, cx, scope);
/*     */   }
/*     */   
/*     */   public static void main(Script script, String[] args) {
/* 204 */     ContextFactory.getGlobal()
/* 205 */       .call(cx -> {
/*     */           ScriptableObject global = getGlobal(cx);
/*     */           Object[] argsCopy = new Object[args.length];
/*     */           System.arraycopy(args, 0, argsCopy, 0, args.length);
/*     */           Scriptable argsObj = cx.newArray((Scriptable)global, argsCopy);
/*     */           global.defineProperty("arguments", argsObj, 2);
/*     */           script.exec(cx, (Scriptable)global);
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void throwStopIteration(Object scope, Object genState) {
/* 221 */     Object value = getGeneratorReturnValue(genState);
/*     */ 
/*     */     
/* 224 */     Object si = (value == Undefined.instance) ? NativeIterator.getStopIterationObject((Scriptable)scope) : new NativeIterator.StopIteration(value);
/*     */     
/* 226 */     throw new JavaScriptException(si, "", 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Scriptable createNativeGenerator(NativeFunction funObj, Scriptable scope, Scriptable thisObj, int maxLocals, int maxStack) {
/* 235 */     GeneratorState gs = new GeneratorState(thisObj, maxLocals, maxStack);
/* 236 */     if (Context.getCurrentContext().getLanguageVersion() >= 200) {
/* 237 */       return (Scriptable)new ES6Generator(scope, funObj, gs);
/*     */     }
/* 239 */     return (Scriptable)new NativeGenerator(scope, funObj, gs);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object[] getGeneratorStackState(Object obj) {
/* 244 */     GeneratorState rgs = (GeneratorState)obj;
/* 245 */     if (rgs.stackState == null) rgs.stackState = new Object[rgs.maxStack]; 
/* 246 */     return rgs.stackState;
/*     */   }
/*     */   
/*     */   public static Object[] getGeneratorLocalsState(Object obj) {
/* 250 */     GeneratorState rgs = (GeneratorState)obj;
/* 251 */     if (rgs.localsState == null) rgs.localsState = new Object[rgs.maxLocals]; 
/* 252 */     return rgs.localsState;
/*     */   }
/*     */   
/*     */   public static void setGeneratorReturnValue(Object obj, Object val) {
/* 256 */     GeneratorState rgs = (GeneratorState)obj;
/* 257 */     rgs.returnValue = val;
/*     */   }
/*     */   
/*     */   public static Object getGeneratorReturnValue(Object obj) {
/* 261 */     GeneratorState rgs = (GeneratorState)obj;
/* 262 */     return (rgs.returnValue == null) ? Undefined.instance : rgs.returnValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class GeneratorState
/*     */   {
/*     */     static final String CLASS_NAME = "org/mozilla/javascript/optimizer/OptRuntime$GeneratorState";
/*     */     
/*     */     public int resumptionPoint;
/*     */     
/*     */     static final String resumptionPoint_NAME = "resumptionPoint";
/*     */     
/*     */     static final String resumptionPoint_TYPE = "I";
/*     */     
/*     */     public Scriptable thisObj;
/*     */     
/*     */     static final String thisObj_NAME = "thisObj";
/*     */     
/*     */     static final String thisObj_TYPE = "Lorg/mozilla/javascript/Scriptable;";
/*     */     Object[] stackState;
/*     */     Object[] localsState;
/*     */     int maxLocals;
/*     */     int maxStack;
/*     */     Object returnValue;
/*     */     
/*     */     GeneratorState(Scriptable thisObj, int maxLocals, int maxStack) {
/* 288 */       this.thisObj = thisObj;
/* 289 */       this.maxLocals = maxLocals;
/* 290 */       this.maxStack = maxStack;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\optimizer\OptRuntime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */