/*    */ package org.mozilla.javascript.optimizer;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.mozilla.javascript.Kit;
/*    */ import org.mozilla.javascript.Node;
/*    */ import org.mozilla.javascript.NodeTransformer;
/*    */ import org.mozilla.javascript.ObjArray;
/*    */ import org.mozilla.javascript.ast.ScriptNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OptTransformer
/*    */   extends NodeTransformer
/*    */ {
/*    */   private Map<String, OptFunctionNode> possibleDirectCalls;
/*    */   private ObjArray directCallTargets;
/*    */   
/*    */   OptTransformer(Map<String, OptFunctionNode> possibleDirectCalls, ObjArray directCallTargets) {
/* 24 */     this.possibleDirectCalls = possibleDirectCalls;
/* 25 */     this.directCallTargets = directCallTargets;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void visitNew(Node node, ScriptNode tree) {
/* 30 */     detectDirectCall(node, tree);
/* 31 */     super.visitNew(node, tree);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void visitCall(Node node, ScriptNode tree) {
/* 36 */     detectDirectCall(node, tree);
/* 37 */     super.visitCall(node, tree);
/*    */   }
/*    */   
/*    */   private void detectDirectCall(Node node, ScriptNode tree) {
/* 41 */     if (tree.getType() == 113) {
/* 42 */       Node left = node.getFirstChild();
/*    */ 
/*    */       
/* 45 */       int argCount = 0;
/* 46 */       if (left != null) {
/* 47 */         Node arg = left.getNext();
/* 48 */         while (arg != null) {
/* 49 */           arg = arg.getNext();
/* 50 */           argCount++;
/*    */         } 
/*    */       } 
/*    */       
/* 54 */       if (argCount == 0) {
/* 55 */         (OptFunctionNode.get(tree)).itsContainsCalls0 = true;
/*    */       }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 70 */       if (this.possibleDirectCalls != null) {
/* 71 */         String targetName = null;
/* 72 */         if (left.getType() == 39) {
/* 73 */           targetName = left.getString();
/* 74 */         } else if (left.getType() == 33) {
/* 75 */           targetName = left.getFirstChild().getNext().getString();
/* 76 */         } else if (left.getType() == 34) {
/* 77 */           throw Kit.codeBug();
/*    */         } 
/* 79 */         if (targetName != null) {
/*    */           
/* 81 */           OptFunctionNode ofn = this.possibleDirectCalls.get(targetName);
/* 82 */           if (ofn != null && argCount == ofn.fnode
/* 83 */             .getParamCount() && 
/* 84 */             !ofn.fnode.requiresActivation())
/*    */           {
/*    */ 
/*    */             
/* 88 */             if (argCount <= 32) {
/* 89 */               node.putProp(9, ofn);
/* 90 */               if (!ofn.isTargetOfDirectCall()) {
/* 91 */                 int index = this.directCallTargets.size();
/* 92 */                 this.directCallTargets.add(ofn);
/* 93 */                 ofn.setDirectTargetIndex(index);
/*    */               } 
/*    */             } 
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\optimizer\OptTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */