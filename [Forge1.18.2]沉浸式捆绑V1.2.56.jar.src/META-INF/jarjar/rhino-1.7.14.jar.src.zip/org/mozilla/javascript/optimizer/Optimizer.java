/*     */ package org.mozilla.javascript.optimizer;
/*     */ 
/*     */ import org.mozilla.javascript.Node;
/*     */ import org.mozilla.javascript.ObjArray;
/*     */ import org.mozilla.javascript.ast.ScriptNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Optimizer
/*     */ {
/*     */   static final int NoType = 0;
/*     */   static final int NumberType = 1;
/*     */   static final int AnyType = 3;
/*     */   private boolean inDirectCallFunction;
/*     */   OptFunctionNode theFunction;
/*     */   private boolean parameterUsedInNumberContext;
/*     */   
/*     */   void optimize(ScriptNode scriptOrFn) {
/*  22 */     int functionCount = scriptOrFn.getFunctionCount();
/*  23 */     for (int i = 0; i != functionCount; i++) {
/*  24 */       OptFunctionNode f = OptFunctionNode.get(scriptOrFn, i);
/*  25 */       optimizeFunction(f);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void optimizeFunction(OptFunctionNode theFunction) {
/*  30 */     if (theFunction.fnode.requiresActivation())
/*     */       return; 
/*  32 */     this.inDirectCallFunction = theFunction.isTargetOfDirectCall();
/*  33 */     this.theFunction = theFunction;
/*     */     
/*  35 */     ObjArray statementsArray = new ObjArray();
/*  36 */     buildStatementList_r((Node)theFunction.fnode, statementsArray);
/*  37 */     Node[] theStatementNodes = new Node[statementsArray.size()];
/*  38 */     statementsArray.toArray((Object[])theStatementNodes);
/*     */     
/*  40 */     Block.runFlowAnalyzes(theFunction, theStatementNodes);
/*     */     
/*  42 */     if (!theFunction.fnode.requiresActivation()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  50 */       this.parameterUsedInNumberContext = false;
/*  51 */       for (Node theStatementNode : theStatementNodes) {
/*  52 */         rewriteForNumberVariables(theStatementNode, 1);
/*     */       }
/*  54 */       theFunction.setParameterNumberContext(this.parameterUsedInNumberContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void markDCPNumberContext(Node n) {
/*  89 */     if (this.inDirectCallFunction && n.getType() == 55) {
/*  90 */       int varIndex = this.theFunction.getVarIndex(n);
/*  91 */       if (this.theFunction.isParameter(varIndex)) {
/*  92 */         this.parameterUsedInNumberContext = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean convertParameter(Node n) {
/*  98 */     if (this.inDirectCallFunction && n.getType() == 55) {
/*  99 */       int varIndex = this.theFunction.getVarIndex(n);
/* 100 */       if (this.theFunction.isParameter(varIndex)) {
/* 101 */         n.removeProp(8);
/* 102 */         return true;
/*     */       } 
/*     */     } 
/* 105 */     return false; } private int rewriteForNumberVariables(Node n, int desired) { Node node3; int varIndex; Node node2, lChild, node1, arrayBase, child; int i; Node rChild; int type; Node arrayIndex; OptFunctionNode target;
/*     */     int rType, lType;
/*     */     Node rValue;
/*     */     int baseType, m, k, j, indexType, i1, rValueType;
/* 109 */     switch (n.getType()) {
/*     */       
/*     */       case 137:
/* 112 */         node3 = n.getFirstChild();
/* 113 */         i = rewriteForNumberVariables(node3, 1);
/* 114 */         if (i == 1) n.putIntProp(8, 0); 
/* 115 */         return 0;
/*     */       
/*     */       case 40:
/* 118 */         n.putIntProp(8, 0);
/* 119 */         return 1;
/*     */ 
/*     */       
/*     */       case 55:
/* 123 */         varIndex = this.theFunction.getVarIndex(n);
/* 124 */         if (this.inDirectCallFunction && this.theFunction
/* 125 */           .isParameter(varIndex) && desired == 1) {
/*     */           
/* 127 */           n.putIntProp(8, 0);
/* 128 */           return 1;
/* 129 */         }  if (this.theFunction.isNumberVar(varIndex)) {
/* 130 */           n.putIntProp(8, 0);
/* 131 */           return 1;
/*     */         } 
/* 133 */         return 0;
/*     */ 
/*     */ 
/*     */       
/*     */       case 110:
/*     */       case 111:
/* 139 */         node2 = n.getFirstChild();
/* 140 */         i = rewriteForNumberVariables(node2, 1);
/* 141 */         if (node2.getType() == 55) {
/* 142 */           if (i == 1 && !convertParameter(node2)) {
/* 143 */             n.putIntProp(8, 0);
/* 144 */             markDCPNumberContext(node2);
/* 145 */             return 1;
/*     */           } 
/* 147 */           return 0;
/* 148 */         }  if (node2.getType() == 36 || node2
/* 149 */           .getType() == 33) {
/* 150 */           return i;
/*     */         }
/* 152 */         return 0;
/*     */ 
/*     */       
/*     */       case 56:
/*     */       case 160:
/* 157 */         lChild = n.getFirstChild();
/* 158 */         rChild = lChild.getNext();
/* 159 */         rType = rewriteForNumberVariables(rChild, 1);
/* 160 */         m = this.theFunction.getVarIndex(n);
/* 161 */         if (this.inDirectCallFunction && this.theFunction.isParameter(m)) {
/* 162 */           if (rType == 1) {
/* 163 */             if (!convertParameter(rChild)) {
/* 164 */               n.putIntProp(8, 0);
/* 165 */               return 1;
/*     */             } 
/* 167 */             markDCPNumberContext(rChild);
/* 168 */             return 0;
/*     */           } 
/* 170 */           return rType;
/* 171 */         }  if (this.theFunction.isNumberVar(m)) {
/* 172 */           if (rType != 1) {
/* 173 */             n.removeChild(rChild);
/* 174 */             n.addChildToBack(new Node(154, rChild));
/*     */           } 
/* 176 */           n.putIntProp(8, 0);
/* 177 */           markDCPNumberContext(rChild);
/* 178 */           return 1;
/*     */         } 
/* 180 */         if (rType == 1 && 
/* 181 */           !convertParameter(rChild)) {
/* 182 */           n.removeChild(rChild);
/* 183 */           n.addChildToBack(new Node(153, rChild));
/*     */         } 
/*     */         
/* 186 */         return 0;
/*     */ 
/*     */ 
/*     */       
/*     */       case 14:
/*     */       case 15:
/*     */       case 16:
/*     */       case 17:
/* 194 */         lChild = n.getFirstChild();
/* 195 */         rChild = lChild.getNext();
/* 196 */         lType = rewriteForNumberVariables(lChild, 1);
/* 197 */         k = rewriteForNumberVariables(rChild, 1);
/* 198 */         markDCPNumberContext(lChild);
/* 199 */         markDCPNumberContext(rChild);
/*     */         
/* 201 */         if (convertParameter(lChild)) {
/* 202 */           if (convertParameter(rChild))
/* 203 */             return 0; 
/* 204 */           if (k == 1) {
/* 205 */             n.putIntProp(8, 2);
/*     */           }
/* 207 */         } else if (convertParameter(rChild)) {
/* 208 */           if (lType == 1) {
/* 209 */             n.putIntProp(8, 1);
/*     */           }
/*     */         }
/* 212 */         else if (lType == 1) {
/* 213 */           if (k == 1) {
/* 214 */             n.putIntProp(8, 0);
/*     */           } else {
/* 216 */             n.putIntProp(8, 1);
/*     */           }
/*     */         
/* 219 */         } else if (k == 1) {
/* 220 */           n.putIntProp(8, 2);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 225 */         return 0;
/*     */ 
/*     */ 
/*     */       
/*     */       case 21:
/* 230 */         lChild = n.getFirstChild();
/* 231 */         rChild = lChild.getNext();
/* 232 */         lType = rewriteForNumberVariables(lChild, 1);
/* 233 */         k = rewriteForNumberVariables(rChild, 1);
/*     */         
/* 235 */         if (convertParameter(lChild)) {
/* 236 */           if (convertParameter(rChild)) {
/* 237 */             return 0;
/*     */           }
/* 239 */           if (k == 1) {
/* 240 */             n.putIntProp(8, 2);
/*     */           }
/*     */         }
/* 243 */         else if (convertParameter(rChild)) {
/* 244 */           if (lType == 1) {
/* 245 */             n.putIntProp(8, 1);
/*     */           }
/*     */         }
/* 248 */         else if (lType == 1) {
/* 249 */           if (k == 1) {
/* 250 */             n.putIntProp(8, 0);
/* 251 */             return 1;
/*     */           } 
/* 253 */           n.putIntProp(8, 1);
/*     */         }
/* 255 */         else if (k == 1) {
/* 256 */           n.putIntProp(8, 2);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 261 */         return 0;
/*     */ 
/*     */ 
/*     */       
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/*     */       case 18:
/*     */       case 19:
/*     */       case 22:
/*     */       case 23:
/*     */       case 24:
/*     */       case 25:
/*     */       case 75:
/* 275 */         lChild = n.getFirstChild();
/* 276 */         rChild = lChild.getNext();
/* 277 */         lType = rewriteForNumberVariables(lChild, 1);
/* 278 */         k = rewriteForNumberVariables(rChild, 1);
/* 279 */         markDCPNumberContext(lChild);
/* 280 */         markDCPNumberContext(rChild);
/* 281 */         if (lType == 1) {
/* 282 */           if (k == 1) {
/* 283 */             n.putIntProp(8, 0);
/* 284 */             return 1;
/*     */           } 
/* 286 */           if (!convertParameter(rChild)) {
/* 287 */             n.removeChild(rChild);
/* 288 */             n.addChildToBack(new Node(154, rChild));
/* 289 */             n.putIntProp(8, 0);
/*     */           } 
/* 291 */           return 1;
/*     */         } 
/* 293 */         if (k == 1) {
/* 294 */           if (!convertParameter(lChild)) {
/* 295 */             n.removeChild(lChild);
/* 296 */             n.addChildToFront(new Node(154, lChild));
/* 297 */             n.putIntProp(8, 0);
/*     */           } 
/* 299 */           return 1;
/*     */         } 
/*     */         
/* 302 */         return 3;
/*     */ 
/*     */ 
/*     */       
/*     */       case 27:
/*     */       case 28:
/*     */       case 29:
/* 309 */         node1 = n.getFirstChild();
/* 310 */         type = rewriteForNumberVariables(node1, 1);
/* 311 */         if (type == 1 && !convertParameter(node1)) {
/* 312 */           n.putIntProp(8, 0);
/* 313 */           markDCPNumberContext(node1);
/* 314 */           return 1;
/*     */         } 
/* 316 */         return 0;
/*     */ 
/*     */ 
/*     */       
/*     */       case 37:
/*     */       case 144:
/* 322 */         arrayBase = n.getFirstChild();
/* 323 */         arrayIndex = arrayBase.getNext();
/* 324 */         rValue = arrayIndex.getNext();
/* 325 */         j = rewriteForNumberVariables(arrayBase, 1);
/* 326 */         if (j == 1 && 
/* 327 */           !convertParameter(arrayBase)) {
/* 328 */           n.removeChild(arrayBase);
/* 329 */           n.addChildToFront(new Node(153, arrayBase));
/*     */         } 
/*     */         
/* 332 */         i1 = rewriteForNumberVariables(arrayIndex, 1);
/* 333 */         if (i1 == 1 && 
/* 334 */           !convertParameter(arrayIndex))
/*     */         {
/*     */ 
/*     */           
/* 338 */           n.putIntProp(8, 1);
/*     */         }
/*     */         
/* 341 */         rValueType = rewriteForNumberVariables(rValue, 1);
/* 342 */         if (rValueType == 1 && 
/* 343 */           !convertParameter(rValue)) {
/* 344 */           n.removeChild(rValue);
/* 345 */           n.addChildToBack(new Node(153, rValue));
/*     */         } 
/*     */         
/* 348 */         return 0;
/*     */ 
/*     */       
/*     */       case 36:
/* 352 */         arrayBase = n.getFirstChild();
/* 353 */         arrayIndex = arrayBase.getNext();
/* 354 */         baseType = rewriteForNumberVariables(arrayBase, 1);
/* 355 */         if (baseType == 1 && 
/* 356 */           !convertParameter(arrayBase)) {
/* 357 */           n.removeChild(arrayBase);
/* 358 */           n.addChildToFront(new Node(153, arrayBase));
/*     */         } 
/*     */         
/* 361 */         indexType = rewriteForNumberVariables(arrayIndex, 1);
/* 362 */         if (indexType == 1 && 
/* 363 */           !convertParameter(arrayIndex))
/*     */         {
/*     */ 
/*     */           
/* 367 */           n.putIntProp(8, 2);
/*     */         }
/*     */         
/* 370 */         return 0;
/*     */ 
/*     */       
/*     */       case 38:
/* 374 */         child = n.getFirstChild();
/*     */         
/* 376 */         rewriteAsObjectChildren(child, child.getFirstChild());
/* 377 */         child = child.getNext();
/*     */         
/* 379 */         target = (OptFunctionNode)n.getProp(9);
/* 380 */         if (target != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 385 */           while (child != null) {
/* 386 */             int i2 = rewriteForNumberVariables(child, 1);
/* 387 */             if (i2 == 1) {
/* 388 */               markDCPNumberContext(child);
/*     */             }
/* 390 */             child = child.getNext();
/*     */           } 
/*     */         } else {
/* 393 */           rewriteAsObjectChildren(n, child);
/*     */         } 
/* 395 */         return 0;
/*     */     } 
/*     */ 
/*     */     
/* 399 */     rewriteAsObjectChildren(n, n.getFirstChild());
/* 400 */     return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rewriteAsObjectChildren(Node n, Node child) {
/* 407 */     while (child != null) {
/* 408 */       Node nextChild = child.getNext();
/* 409 */       int type = rewriteForNumberVariables(child, 0);
/* 410 */       if (type == 1 && 
/* 411 */         !convertParameter(child)) {
/* 412 */         n.removeChild(child);
/* 413 */         Node nuChild = new Node(153, child);
/* 414 */         if (nextChild == null) { n.addChildToBack(nuChild); }
/* 415 */         else { n.addChildBefore(nuChild, nextChild); }
/*     */       
/*     */       } 
/* 418 */       child = nextChild;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void buildStatementList_r(Node node, ObjArray statements) {
/* 423 */     int type = node.getType();
/* 424 */     if (type == 133 || type == 145 || type == 136 || type == 113) {
/*     */ 
/*     */ 
/*     */       
/* 428 */       Node child = node.getFirstChild();
/* 429 */       while (child != null) {
/* 430 */         buildStatementList_r(child, statements);
/* 431 */         child = child.getNext();
/*     */       } 
/*     */     } else {
/* 434 */       statements.add(node);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\optimizer\Optimizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */