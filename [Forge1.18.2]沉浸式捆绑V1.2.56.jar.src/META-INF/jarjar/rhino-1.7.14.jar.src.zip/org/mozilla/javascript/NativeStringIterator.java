/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NativeStringIterator
/*    */   extends ES6Iterator
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String ITERATOR_TAG = "StringIterator";
/*    */   private String string;
/*    */   private int index;
/*    */   
/*    */   static void init(ScriptableObject scope, boolean sealed) {
/* 14 */     ES6Iterator.init(scope, sealed, new NativeStringIterator(), "StringIterator");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private NativeStringIterator() {}
/*    */ 
/*    */ 
/*    */   
/*    */   NativeStringIterator(Scriptable scope, Object stringLike) {
/* 25 */     super(scope, "StringIterator");
/* 26 */     this.index = 0;
/* 27 */     this.string = ScriptRuntime.toString(stringLike);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 32 */     return "String Iterator";
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isDone(Context cx, Scriptable scope) {
/* 37 */     return (this.index >= this.string.length());
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object nextValue(Context cx, Scriptable scope) {
/* 42 */     int newIndex = this.string.offsetByCodePoints(this.index, 1);
/* 43 */     Object value = this.string.substring(this.index, newIndex);
/* 44 */     this.index = newIndex;
/* 45 */     return value;
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getTag() {
/* 50 */     return "StringIterator";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeStringIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */