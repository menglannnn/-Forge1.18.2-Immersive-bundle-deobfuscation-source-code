/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaArray
/*     */   extends NativeJavaObject
/*     */   implements SymbolScriptable
/*     */ {
/*     */   private static final long serialVersionUID = -924022554283675333L;
/*     */   Object array;
/*     */   int length;
/*     */   Class<?> cls;
/*     */   
/*     */   public String getClassName() {
/*  28 */     return "JavaArray";
/*     */   }
/*     */   
/*     */   public static NativeJavaArray wrap(Scriptable scope, Object array) {
/*  32 */     return new NativeJavaArray(scope, array);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unwrap() {
/*  37 */     return this.array;
/*     */   }
/*     */   
/*     */   public NativeJavaArray(Scriptable scope, Object array) {
/*  41 */     super(scope, (Object)null, ScriptRuntime.ObjectClass);
/*  42 */     Class<?> cl = array.getClass();
/*  43 */     if (!cl.isArray()) {
/*  44 */       throw new RuntimeException("Array expected");
/*     */     }
/*  46 */     this.array = array;
/*  47 */     this.length = Array.getLength(array);
/*  48 */     this.cls = cl.getComponentType();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(String id, Scriptable start) {
/*  53 */     return (id.equals("length") || super.has(id, start));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/*  58 */     return (0 <= index && index < this.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(Symbol key, Scriptable start) {
/*  63 */     return SymbolKey.IS_CONCAT_SPREADABLE.equals(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String id, Scriptable start) {
/*  68 */     if (id.equals("length"))
/*  69 */       return Integer.valueOf(this.length); 
/*  70 */     Object result = super.get(id, start);
/*  71 */     if (result == NOT_FOUND && 
/*  72 */       !ScriptableObject.hasProperty(getPrototype(), id))
/*     */     {
/*  74 */       throw Context.reportRuntimeErrorById("msg.java.member.not.found", new Object[] { this.array
/*  75 */             .getClass().getName(), id });
/*     */     }
/*  77 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/*  82 */     if (0 <= index && index < this.length) {
/*  83 */       Context cx = Context.getContext();
/*  84 */       Object obj = Array.get(this.array, index);
/*  85 */       return cx.getWrapFactory().wrap(cx, this, obj, this.cls);
/*     */     } 
/*  87 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Symbol key, Scriptable start) {
/*  92 */     if (SymbolKey.IS_CONCAT_SPREADABLE.equals(key)) {
/*  93 */       return Boolean.TRUE;
/*     */     }
/*  95 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String id, Scriptable start, Object value) {
/* 101 */     if (!id.equals("length")) {
/* 102 */       throw Context.reportRuntimeErrorById("msg.java.array.member.not.found", new Object[] { id });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/* 108 */     if (0 <= index && index < this.length) {
/* 109 */       Array.set(this.array, index, Context.jsToJava(value, this.cls));
/*     */     } else {
/*     */       
/* 112 */       throw Context.reportRuntimeErrorById("msg.java.array.index.out.of.bounds", new Object[] {
/* 113 */             String.valueOf(index), 
/* 114 */             String.valueOf(this.length - 1)
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(Symbol key) {}
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class<?> hint) {
/* 125 */     if (hint == null || hint == ScriptRuntime.StringClass)
/* 126 */       return this.array.toString(); 
/* 127 */     if (hint == ScriptRuntime.BooleanClass)
/* 128 */       return Boolean.TRUE; 
/* 129 */     if (hint == ScriptRuntime.NumberClass)
/* 130 */       return ScriptRuntime.NaNobj; 
/* 131 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 136 */     Object[] result = new Object[this.length];
/* 137 */     int i = this.length;
/* 138 */     while (--i >= 0)
/* 139 */       result[i] = Integer.valueOf(i); 
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasInstance(Scriptable value) {
/* 145 */     if (!(value instanceof Wrapper))
/* 146 */       return false; 
/* 147 */     Object instance = ((Wrapper)value).unwrap();
/* 148 */     return this.cls.isInstance(instance);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scriptable getPrototype() {
/* 153 */     if (this.prototype == null) {
/* 154 */       this
/* 155 */         .prototype = ScriptableObject.getArrayPrototype(getParentScope());
/*     */     }
/* 157 */     return this.prototype;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeJavaArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */