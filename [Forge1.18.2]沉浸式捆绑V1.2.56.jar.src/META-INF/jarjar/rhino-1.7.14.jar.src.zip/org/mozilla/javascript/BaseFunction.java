/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseFunction
/*     */   extends IdScriptableObject
/*     */   implements Function
/*     */ {
/*     */   private static final long serialVersionUID = 5311394446546053859L;
/*  21 */   private static final Object FUNCTION_TAG = "Function"; private static final String FUNCTION_CLASS = "Function"; static final String GENERATOR_FUNCTION_CLASS = "__GeneratorFunction"; private static final int Id_length = 1; private static final int Id_arity = 2; private static final int Id_name = 3; private static final int Id_prototype = 4; private static final int Id_arguments = 5; private static final int MAX_INSTANCE_ID = 5; private static final int Id_constructor = 1;
/*     */   private static final int Id_toString = 2;
/*     */   private static final int Id_toSource = 3;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  26 */     BaseFunction obj = new BaseFunction();
/*     */     
/*  28 */     obj.prototypePropertyAttributes = 7;
/*  29 */     obj.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */   private static final int Id_apply = 4; private static final int Id_call = 5; private static final int Id_bind = 6; private static final int MAX_PROTOTYPE_ID = 6; private Object prototypeProperty; private Object argumentsObj; private boolean isGeneratorFunction; private int prototypePropertyAttributes; private int argumentsAttributes; private int arityPropertyAttributes; private int namePropertyAttributes; private int lengthPropertyAttributes;
/*     */   static Object initAsGeneratorFunction(Scriptable scope, boolean sealed) {
/*  33 */     BaseFunction obj = new BaseFunction(true);
/*     */     
/*  35 */     obj.prototypePropertyAttributes = 5;
/*  36 */     obj.exportAsJSClass(6, scope, sealed);
/*     */ 
/*     */     
/*  39 */     return ScriptableObject.getProperty(scope, "__GeneratorFunction");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseFunction()
/*     */   {
/* 640 */     this.argumentsObj = NOT_FOUND;
/* 641 */     this.isGeneratorFunction = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 646 */     this.prototypePropertyAttributes = 6;
/* 647 */     this.argumentsAttributes = 6;
/* 648 */     this.arityPropertyAttributes = 7;
/* 649 */     this.namePropertyAttributes = 7;
/* 650 */     this.lengthPropertyAttributes = 7; } public BaseFunction(boolean isGenerator) { this.argumentsObj = NOT_FOUND; this.isGeneratorFunction = false; this.prototypePropertyAttributes = 6; this.argumentsAttributes = 6; this.arityPropertyAttributes = 7; this.namePropertyAttributes = 7; this.lengthPropertyAttributes = 7; this.isGeneratorFunction = isGenerator; } public BaseFunction(Scriptable scope, Scriptable prototype) { super(scope, prototype); this.argumentsObj = NOT_FOUND; this.isGeneratorFunction = false; this.prototypePropertyAttributes = 6; this.argumentsAttributes = 6; this.arityPropertyAttributes = 7; this.namePropertyAttributes = 7; this.lengthPropertyAttributes = 7; }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*     */     return isGeneratorFunction() ? "__GeneratorFunction" : "Function";
/*     */   }
/*     */   
/*     */   protected boolean isGeneratorFunction() {
/*     */     return this.isGeneratorFunction;
/*     */   }
/*     */   
/*     */   public String getTypeOf() {
/*     */     return avoidObjectDetection() ? "undefined" : "function";
/*     */   }
/*     */   
/*     */   public boolean hasInstance(Scriptable instance) {
/*     */     Object protoProp = ScriptableObject.getProperty(this, "prototype");
/*     */     if (protoProp instanceof Scriptable)
/*     */       return ScriptRuntime.jsDelegatesTo(instance, (Scriptable)protoProp); 
/*     */     throw ScriptRuntime.typeErrorById("msg.instanceof.bad.prototype", new Object[] { getFunctionName() });
/*     */   }
/*     */   
/*     */   protected int getMaxInstanceId() {
/*     */     return 5;
/*     */   }
/*     */   
/*     */   protected int findInstanceIdInfo(String s) {
/*     */     switch (s) {
/*     */       case "length":
/*     */         if (this.lengthPropertyAttributes >= 0)
/*     */           return instanceIdInfo(this.lengthPropertyAttributes, 1); 
/*     */         break;
/*     */       case "arity":
/*     */         if (this.arityPropertyAttributes >= 0)
/*     */           return instanceIdInfo(this.arityPropertyAttributes, 2); 
/*     */         break;
/*     */       case "name":
/*     */         if (this.namePropertyAttributes >= 0)
/*     */           return instanceIdInfo(this.namePropertyAttributes, 3); 
/*     */         break;
/*     */       case "prototype":
/*     */         if (hasPrototypeProperty())
/*     */           return instanceIdInfo(this.prototypePropertyAttributes, 4); 
/*     */         break;
/*     */       case "arguments":
/*     */         return instanceIdInfo(this.argumentsAttributes, 5);
/*     */     } 
/*     */     return super.findInstanceIdInfo(s);
/*     */   }
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/*     */     switch (id) {
/*     */       case 1:
/*     */         return "length";
/*     */       case 2:
/*     */         return "arity";
/*     */       case 3:
/*     */         return "name";
/*     */       case 4:
/*     */         return "prototype";
/*     */       case 5:
/*     */         return "arguments";
/*     */     } 
/*     */     return super.getInstanceIdName(id);
/*     */   }
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/*     */     switch (id) {
/*     */       case 1:
/*     */         return (this.lengthPropertyAttributes >= 0) ? Integer.valueOf(getLength()) : NOT_FOUND;
/*     */       case 2:
/*     */         return (this.arityPropertyAttributes >= 0) ? Integer.valueOf(getArity()) : NOT_FOUND;
/*     */       case 3:
/*     */         return (this.namePropertyAttributes >= 0) ? getFunctionName() : NOT_FOUND;
/*     */       case 4:
/*     */         return getPrototypeProperty();
/*     */       case 5:
/*     */         return getArguments();
/*     */     } 
/*     */     return super.getInstanceIdValue(id);
/*     */   }
/*     */   
/*     */   protected void setInstanceIdValue(int id, Object value) {
/*     */     switch (id) {
/*     */       case 4:
/*     */         if ((this.prototypePropertyAttributes & 0x1) == 0)
/*     */           this.prototypeProperty = (value != null) ? value : UniqueTag.NULL_VALUE; 
/*     */         return;
/*     */       case 5:
/*     */         if (value == NOT_FOUND)
/*     */           Kit.codeBug(); 
/*     */         if (defaultHas("arguments")) {
/*     */           defaultPut("arguments", value);
/*     */         } else if ((this.argumentsAttributes & 0x1) == 0) {
/*     */           this.argumentsObj = value;
/*     */         } 
/*     */         return;
/*     */       case 3:
/*     */         if (value == NOT_FOUND)
/*     */           this.namePropertyAttributes = -1; 
/*     */         return;
/*     */       case 2:
/*     */         if (value == NOT_FOUND)
/*     */           this.arityPropertyAttributes = -1; 
/*     */         return;
/*     */       case 1:
/*     */         if (value == NOT_FOUND)
/*     */           this.lengthPropertyAttributes = -1; 
/*     */         return;
/*     */     } 
/*     */     super.setInstanceIdValue(id, value);
/*     */   }
/*     */   
/*     */   protected void setInstanceIdAttributes(int id, int attr) {
/*     */     switch (id) {
/*     */       case 4:
/*     */         this.prototypePropertyAttributes = attr;
/*     */         return;
/*     */       case 5:
/*     */         this.argumentsAttributes = attr;
/*     */         return;
/*     */       case 2:
/*     */         this.arityPropertyAttributes = attr;
/*     */         return;
/*     */       case 3:
/*     */         this.namePropertyAttributes = attr;
/*     */         return;
/*     */       case 1:
/*     */         this.lengthPropertyAttributes = attr;
/*     */         return;
/*     */     } 
/*     */     super.setInstanceIdAttributes(id, attr);
/*     */   }
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/*     */     ctor.setPrototype(this);
/*     */     super.fillConstructorProperties(ctor);
/*     */   }
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*     */     switch (id) {
/*     */       case 1:
/*     */         arity = 1;
/*     */         s = "constructor";
/*     */         break;
/*     */       case 2:
/*     */         arity = 0;
/*     */         s = "toString";
/*     */         break;
/*     */       case 3:
/*     */         arity = 1;
/*     */         s = "toSource";
/*     */         break;
/*     */       case 4:
/*     */         arity = 2;
/*     */         s = "apply";
/*     */         break;
/*     */       case 5:
/*     */         arity = 1;
/*     */         s = "call";
/*     */         break;
/*     */       case 6:
/*     */         arity = 1;
/*     */         s = "bind";
/*     */         break;
/*     */       default:
/*     */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/*     */     initPrototypeMethod(FUNCTION_TAG, id, s, arity);
/*     */   }
/*     */   
/*     */   static boolean isApply(IdFunctionObject f) {
/*     */     return (f.hasTag(FUNCTION_TAG) && f.methodId() == 4);
/*     */   }
/*     */   
/*     */   static boolean isApplyOrCall(IdFunctionObject f) {
/*     */     if (f.hasTag(FUNCTION_TAG))
/*     */       switch (f.methodId()) {
/*     */         case 4:
/*     */         case 5:
/*     */           return true;
/*     */       }  
/*     */     return false;
/*     */   }
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     BaseFunction realf;
/*     */     Callable targetFunction;
/*     */     int indent, argc, flags;
/*     */     Scriptable boundThis;
/*     */     Object[] boundArgs;
/*     */     if (!f.hasTag(FUNCTION_TAG))
/*     */       return super.execIdCall(f, cx, scope, thisObj, args); 
/*     */     int id = f.methodId();
/*     */     switch (id) {
/*     */       case 1:
/*     */         return jsConstructor(cx, scope, args);
/*     */       case 2:
/*     */         realf = realFunction(thisObj, f);
/*     */         indent = ScriptRuntime.toInt32(args, 0);
/*     */         return realf.decompile(indent, 0);
/*     */       case 3:
/*     */         realf = realFunction(thisObj, f);
/*     */         indent = 0;
/*     */         flags = 2;
/*     */         if (args.length != 0) {
/*     */           indent = ScriptRuntime.toInt32(args[0]);
/*     */           if (indent >= 0) {
/*     */             flags = 0;
/*     */           } else {
/*     */             indent = 0;
/*     */           } 
/*     */         } 
/*     */         return realf.decompile(indent, flags);
/*     */       case 4:
/*     */       case 5:
/*     */         return ScriptRuntime.applyOrCall((id == 4), cx, scope, thisObj, args);
/*     */       case 6:
/*     */         if (!(thisObj instanceof Callable))
/*     */           throw ScriptRuntime.notFunctionError(thisObj); 
/*     */         targetFunction = (Callable)thisObj;
/*     */         argc = args.length;
/*     */         if (argc > 0) {
/*     */           boundThis = ScriptRuntime.toObjectOrNull(cx, args[0], scope);
/*     */           boundArgs = new Object[argc - 1];
/*     */           System.arraycopy(args, 1, boundArgs, 0, argc - 1);
/*     */         } else {
/*     */           boundThis = null;
/*     */           boundArgs = ScriptRuntime.emptyArgs;
/*     */         } 
/*     */         return new BoundFunction(cx, scope, targetFunction, boundThis, boundArgs);
/*     */     } 
/*     */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */   
/*     */   private static BaseFunction realFunction(Scriptable thisObj, IdFunctionObject f) {
/*     */     if (thisObj == null)
/*     */       throw ScriptRuntime.notFunctionError(null); 
/*     */     Object x = thisObj.getDefaultValue(ScriptRuntime.FunctionClass);
/*     */     if (x instanceof Delegator)
/*     */       x = ((Delegator)x).getDelegee(); 
/*     */     return ensureType(x, BaseFunction.class, f);
/*     */   }
/*     */   
/*     */   public void setImmunePrototypeProperty(Object value) {
/*     */     if ((this.prototypePropertyAttributes & 0x1) != 0)
/*     */       throw new IllegalStateException(); 
/*     */     this.prototypeProperty = (value != null) ? value : UniqueTag.NULL_VALUE;
/*     */     this.prototypePropertyAttributes = 7;
/*     */   }
/*     */   
/*     */   protected Scriptable getClassPrototype() {
/*     */     Object protoVal = getPrototypeProperty();
/*     */     if (protoVal instanceof Scriptable)
/*     */       return (Scriptable)protoVal; 
/*     */     return ScriptableObject.getObjectPrototype(this);
/*     */   }
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/*     */     Scriptable result = createObject(cx, scope);
/*     */     if (result != null) {
/*     */       Object val = call(cx, scope, result, args);
/*     */       if (val instanceof Scriptable)
/*     */         result = (Scriptable)val; 
/*     */     } else {
/*     */       Object val = call(cx, scope, (Scriptable)null, args);
/*     */       if (!(val instanceof Scriptable))
/*     */         throw new IllegalStateException("Bad implementation of call as constructor, name=" + getFunctionName() + " in " + getClass().getName()); 
/*     */       result = (Scriptable)val;
/*     */       if (result.getPrototype() == null) {
/*     */         Scriptable proto = getClassPrototype();
/*     */         if (result != proto)
/*     */           result.setPrototype(proto); 
/*     */       } 
/*     */       if (result.getParentScope() == null) {
/*     */         Scriptable parent = getParentScope();
/*     */         if (result != parent)
/*     */           result.setParentScope(parent); 
/*     */       } 
/*     */     } 
/*     */     return result;
/*     */   }
/*     */   
/*     */   public Scriptable createObject(Context cx, Scriptable scope) {
/*     */     Scriptable newInstance = new NativeObject();
/*     */     newInstance.setPrototype(getClassPrototype());
/*     */     newInstance.setParentScope(getParentScope());
/*     */     return newInstance;
/*     */   }
/*     */   
/*     */   String decompile(int indent, int flags) {
/*     */     StringBuilder sb = new StringBuilder();
/*     */     boolean justbody = (0 != (flags & 0x1));
/*     */     if (!justbody) {
/*     */       sb.append("function ");
/*     */       sb.append(getFunctionName());
/*     */       sb.append("() {\n\t");
/*     */     } 
/*     */     sb.append("[native code, arity=");
/*     */     sb.append(getArity());
/*     */     sb.append("]\n");
/*     */     if (!justbody)
/*     */       sb.append("}\n"); 
/*     */     return sb.toString();
/*     */   }
/*     */   
/*     */   public int getArity() {
/*     */     return 0;
/*     */   }
/*     */   
/*     */   public int getLength() {
/*     */     return 0;
/*     */   }
/*     */   
/*     */   public String getFunctionName() {
/*     */     return "";
/*     */   }
/*     */   
/*     */   public void setStandardPropertyAttributes(int attributes) {
/*     */     this.namePropertyAttributes = attributes;
/*     */     this.lengthPropertyAttributes = attributes;
/*     */     this.arityPropertyAttributes = attributes;
/*     */   }
/*     */   
/*     */   public void setPrototypePropertyAttributes(int attributes) {
/*     */     this.prototypePropertyAttributes = attributes;
/*     */   }
/*     */   
/*     */   protected boolean hasPrototypeProperty() {
/*     */     return (this.prototypeProperty != null || this instanceof NativeFunction);
/*     */   }
/*     */   
/*     */   protected Object getPrototypeProperty() {
/*     */     Object result = this.prototypeProperty;
/*     */     if (result == null) {
/*     */       if (this instanceof NativeFunction) {
/*     */         result = setupDefaultPrototype();
/*     */       } else {
/*     */         result = Undefined.instance;
/*     */       } 
/*     */     } else if (result == UniqueTag.NULL_VALUE) {
/*     */       result = null;
/*     */     } 
/*     */     return result;
/*     */   }
/*     */   
/*     */   protected void setPrototypeProperty(Object prototype) {
/*     */     this.prototypeProperty = prototype;
/*     */   }
/*     */   
/*     */   protected synchronized Object setupDefaultPrototype() {
/*     */     if (this.prototypeProperty != null)
/*     */       return this.prototypeProperty; 
/*     */     NativeObject obj = new NativeObject();
/*     */     obj.defineProperty("constructor", this, 2);
/*     */     this.prototypeProperty = obj;
/*     */     Scriptable proto = getObjectPrototype(this);
/*     */     if (proto != obj)
/*     */       obj.setPrototype(proto); 
/*     */     return obj;
/*     */   }
/*     */   
/*     */   private Object getArguments() {
/*     */     Object value = defaultHas("arguments") ? defaultGet("arguments") : this.argumentsObj;
/*     */     if (value != NOT_FOUND)
/*     */       return value; 
/*     */     Context cx = Context.getContext();
/*     */     NativeCall activation = ScriptRuntime.findFunctionActivation(cx, this);
/*     */     return (activation == null) ? null : activation.get("arguments", activation);
/*     */   }
/*     */   
/*     */   private Object jsConstructor(Context cx, Scriptable scope, Object[] args) {
/*     */     int arglen = args.length;
/*     */     StringBuilder sourceBuf = new StringBuilder();
/*     */     sourceBuf.append("function ");
/*     */     if (isGeneratorFunction())
/*     */       sourceBuf.append("* "); 
/*     */     if (cx.getLanguageVersion() != 120)
/*     */       sourceBuf.append("anonymous"); 
/*     */     sourceBuf.append('(');
/*     */     for (int i = 0; i < arglen - 1; i++) {
/*     */       if (i > 0)
/*     */         sourceBuf.append(','); 
/*     */       sourceBuf.append(ScriptRuntime.toString(args[i]));
/*     */     } 
/*     */     sourceBuf.append(") {");
/*     */     if (arglen != 0) {
/*     */       String funBody = ScriptRuntime.toString(args[arglen - 1]);
/*     */       sourceBuf.append(funBody);
/*     */     } 
/*     */     sourceBuf.append("\n}");
/*     */     String source = sourceBuf.toString();
/*     */     int[] linep = new int[1];
/*     */     String filename = Context.getSourcePositionFromStack(linep);
/*     */     if (filename == null) {
/*     */       filename = "<eval'ed string>";
/*     */       linep[0] = 1;
/*     */     } 
/*     */     String sourceURI = ScriptRuntime.makeUrlForGeneratedScript(false, filename, linep[0]);
/*     */     Scriptable global = ScriptableObject.getTopLevelScope(scope);
/*     */     ErrorReporter reporter = DefaultErrorReporter.forEval(cx.getErrorReporter());
/*     */     Evaluator evaluator = Context.createInterpreter();
/*     */     if (evaluator == null)
/*     */       throw new JavaScriptException("Interpreter not present", filename, linep[0]); 
/*     */     return cx.compileFunction(global, source, evaluator, reporter, sourceURI, 1, null);
/*     */   }
/*     */   
/*     */   protected int findPrototypeId(String s) {
/*     */     switch (s) {
/*     */       case "constructor":
/*     */         id = 1;
/*     */         return id;
/*     */       case "toString":
/*     */         id = 2;
/*     */         return id;
/*     */       case "toSource":
/*     */         id = 3;
/*     */         return id;
/*     */       case "apply":
/*     */         id = 4;
/*     */         return id;
/*     */       case "call":
/*     */         id = 5;
/*     */         return id;
/*     */       case "bind":
/*     */         id = 6;
/*     */         return id;
/*     */     } 
/*     */     int id = 0;
/*     */     return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\BaseFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */