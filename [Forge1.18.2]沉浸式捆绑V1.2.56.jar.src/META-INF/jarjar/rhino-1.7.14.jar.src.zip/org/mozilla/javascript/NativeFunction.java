/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import org.mozilla.javascript.debug.DebuggableScript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NativeFunction
/*     */   extends BaseFunction
/*     */ {
/*     */   private static final long serialVersionUID = 8713897114082216401L;
/*     */   
/*     */   public final void initScriptFunction(Context cx, Scriptable scope) {
/*  23 */     initScriptFunction(cx, scope, isGeneratorFunction());
/*     */   }
/*     */ 
/*     */   
/*     */   public final void initScriptFunction(Context cx, Scriptable scope, boolean es6GeneratorFunction) {
/*  28 */     ScriptRuntime.setFunctionProtoAndParent(this, scope, es6GeneratorFunction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String decompile(int indent, int flags) {
/*  39 */     String encodedSource = getEncodedSource();
/*  40 */     if (encodedSource == null) {
/*  41 */       return super.decompile(indent, flags);
/*     */     }
/*  43 */     UintMap properties = new UintMap(1);
/*  44 */     properties.put(1, indent);
/*  45 */     return Decompiler.decompile(encodedSource, flags, properties);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  51 */     int paramCount = getParamCount();
/*  52 */     if (getLanguageVersion() != 120) {
/*  53 */       return paramCount;
/*     */     }
/*  55 */     Context cx = Context.getContext();
/*  56 */     NativeCall activation = ScriptRuntime.findFunctionActivation(cx, this);
/*  57 */     if (activation == null) {
/*  58 */       return paramCount;
/*     */     }
/*  60 */     return activation.originalArgs.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getArity() {
/*  66 */     return getParamCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String jsGet_name() {
/*  77 */     return getFunctionName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncodedSource() {
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public DebuggableScript getDebuggableView() {
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resumeGenerator(Context cx, Scriptable scope, int operation, Object state, Object value) {
/* 105 */     throw new EvaluatorException("resumeGenerator() not implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int getLanguageVersion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int getParamCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int getParamAndVarCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getParamOrVarName(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean getParamOrVarConst(int index) {
/* 140 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */