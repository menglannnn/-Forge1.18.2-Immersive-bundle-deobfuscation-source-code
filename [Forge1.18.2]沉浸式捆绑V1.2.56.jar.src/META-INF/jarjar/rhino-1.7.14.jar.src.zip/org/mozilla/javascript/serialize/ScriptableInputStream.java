/*    */ package org.mozilla.javascript.serialize;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamClass;
/*    */ import org.mozilla.javascript.Context;
/*    */ import org.mozilla.javascript.Scriptable;
/*    */ import org.mozilla.javascript.Undefined;
/*    */ import org.mozilla.javascript.UniqueTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptableInputStream
/*    */   extends ObjectInputStream
/*    */ {
/*    */   private Scriptable scope;
/*    */   private ClassLoader classLoader;
/*    */   
/*    */   public ScriptableInputStream(InputStream in, Scriptable scope) throws IOException {
/* 41 */     super(in);
/* 42 */     this.scope = scope;
/* 43 */     enableResolveObject(true);
/* 44 */     Context cx = Context.getCurrentContext();
/* 45 */     if (cx != null) {
/* 46 */       this.classLoader = cx.getApplicationClassLoader();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class<?> resolveClass(ObjectStreamClass desc) throws IOException, ClassNotFoundException {
/* 54 */     String name = desc.getName();
/* 55 */     if (this.classLoader != null) {
/*    */       try {
/* 57 */         return this.classLoader.loadClass(name);
/* 58 */       } catch (ClassNotFoundException classNotFoundException) {}
/*    */     }
/*    */ 
/*    */     
/* 62 */     return super.resolveClass(desc);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object resolveObject(Object obj) throws IOException {
/* 69 */     if (obj instanceof ScriptableOutputStream.PendingLookup) {
/* 70 */       String name = ((ScriptableOutputStream.PendingLookup)obj).getName();
/* 71 */       obj = ScriptableOutputStream.lookupQualifiedName(this.scope, name);
/* 72 */       if (obj == Scriptable.NOT_FOUND) {
/* 73 */         throw new IOException("Object " + name + " not found upon deserialization.");
/*    */       }
/*    */     }
/* 76 */     else if (obj instanceof UniqueTag) {
/* 77 */       obj = ((UniqueTag)obj).readResolve();
/* 78 */     } else if (obj instanceof Undefined) {
/* 79 */       obj = ((Undefined)obj).readResolve();
/*    */     } 
/* 81 */     return obj;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\serialize\ScriptableInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */