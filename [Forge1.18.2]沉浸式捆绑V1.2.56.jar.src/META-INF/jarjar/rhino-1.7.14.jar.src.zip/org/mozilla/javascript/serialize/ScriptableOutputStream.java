/*     */ package org.mozilla.javascript.serialize;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.UniqueTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptableOutputStream
/*     */   extends ObjectOutputStream
/*     */ {
/*     */   private Scriptable scope;
/*     */   private Map<Object, String> table;
/*     */   
/*     */   public ScriptableOutputStream(OutputStream out, Scriptable scope) throws IOException {
/*  52 */     super(out);
/*  53 */     this.scope = scope;
/*  54 */     this.table = new HashMap<>();
/*  55 */     this.table.put(scope, "");
/*  56 */     enableReplaceObject(true);
/*  57 */     excludeStandardObjectNames();
/*     */   }
/*     */   
/*     */   public void excludeAllIds(Object[] ids) {
/*  61 */     for (Object id : ids) {
/*  62 */       if (id instanceof String && this.scope
/*  63 */         .get((String)id, this.scope) instanceof Scriptable)
/*     */       {
/*  65 */         addExcludedName((String)id);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOptionalExcludedName(String name) {
/*  81 */     Object obj = lookupQualifiedName(this.scope, name);
/*  82 */     if (obj != null && obj != UniqueTag.NOT_FOUND) {
/*  83 */       if (!(obj instanceof Scriptable)) {
/*  84 */         throw new IllegalArgumentException("Object for excluded name " + name + " is not a Scriptable, it is " + obj
/*     */ 
/*     */             
/*  87 */             .getClass().getName());
/*     */       }
/*  89 */       this.table.put(obj, name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addExcludedName(String name) {
/* 103 */     Object obj = lookupQualifiedName(this.scope, name);
/* 104 */     if (!(obj instanceof Scriptable)) {
/* 105 */       throw new IllegalArgumentException("Object for excluded name " + name + " not found.");
/*     */     }
/*     */     
/* 108 */     this.table.put(obj, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasExcludedName(String name) {
/* 115 */     return (this.table.get(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeExcludedName(String name) {
/* 122 */     this.table.remove(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void excludeStandardObjectNames() {
/* 130 */     String[] names = { "Object", "Object.prototype", "Function", "Function.prototype", "String", "String.prototype", "Math", "Array", "Array.prototype", "Error", "Error.prototype", "Number", "Number.prototype", "Date", "Date.prototype", "RegExp", "RegExp.prototype", "Script", "Script.prototype", "Continuation", "Continuation.prototype" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     for (int i = 0; i < names.length; i++) {
/* 143 */       addExcludedName(names[i]);
/*     */     }
/*     */     
/* 146 */     String[] optionalNames = { "XML", "XML.prototype", "XMLList", "XMLList.prototype" };
/*     */ 
/*     */ 
/*     */     
/* 150 */     for (int j = 0; j < optionalNames.length; j++) {
/* 151 */       addOptionalExcludedName(optionalNames[j]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Object lookupQualifiedName(Scriptable scope, String qualifiedName) {
/* 158 */     StringTokenizer st = new StringTokenizer(qualifiedName, ".");
/* 159 */     Object result = scope;
/* 160 */     while (st.hasMoreTokens()) {
/* 161 */       String s = st.nextToken();
/* 162 */       result = ScriptableObject.getProperty((Scriptable)result, s);
/* 163 */       if (result == null || !(result instanceof Scriptable))
/*     */         break; 
/*     */     } 
/* 166 */     return result;
/*     */   }
/*     */   
/*     */   static class PendingLookup implements Serializable { private static final long serialVersionUID = -2692990309789917727L;
/*     */     private String name;
/*     */     
/*     */     PendingLookup(String name) {
/* 173 */       this.name = name;
/*     */     } String getName() {
/* 175 */       return this.name;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object replaceObject(Object obj) throws IOException {
/* 184 */     String name = this.table.get(obj);
/* 185 */     if (name == null)
/* 186 */       return obj; 
/* 187 */     return new PendingLookup(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\serialize\ScriptableOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */