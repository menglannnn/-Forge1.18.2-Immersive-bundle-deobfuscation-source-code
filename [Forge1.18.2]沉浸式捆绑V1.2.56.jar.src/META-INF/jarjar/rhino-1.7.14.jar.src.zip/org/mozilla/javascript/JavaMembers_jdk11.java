/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JavaMembers_jdk11
/*     */   extends JavaMembers
/*     */ {
/*     */   JavaMembers_jdk11(Scriptable scope, Class<?> cl, boolean includeProtected) {
/*  18 */     super(scope, cl, includeProtected);
/*     */   }
/*     */ 
/*     */   
/*     */   void discoverPublicMethods(Class<?> clazz, Map<JavaMembers.MethodSignature, Method> map) {
/*  23 */     if (isExportedClass(clazz)) {
/*  24 */       super.discoverPublicMethods(clazz, map);
/*     */     } else {
/*  26 */       Method[] methods = clazz.getMethods();
/*  27 */       for (Method method : methods) {
/*  28 */         method = findAccessibleMethod(method);
/*  29 */         registerMethod(map, method);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isExportedClass(Class<?> clazz) {
/*     */     String pname;
/*     */     Method getmodule;
/*     */     Object module;
/*     */     boolean exported;
/*  44 */     Package pkg = clazz.getPackage();
/*  45 */     if (pkg == null) {
/*     */       
/*  47 */       if (!Proxy.isProxyClass(clazz))
/*     */       {
/*  49 */         return true;
/*     */       }
/*  51 */       String clName = clazz.getName();
/*  52 */       pname = clName.substring(0, clName.lastIndexOf('.'));
/*     */     } else {
/*  54 */       pname = pkg.getName();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  59 */     Class<?> cl = clazz.getClass();
/*     */     try {
/*  61 */       getmodule = cl.getMethod("getModule", new Class[0]);
/*  62 */     } catch (NoSuchMethodException e) {
/*     */       
/*  64 */       return true;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  69 */       module = getmodule.invoke(clazz, new Object[0]);
/*  70 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/*  71 */       return false;
/*     */     } 
/*     */     
/*  74 */     Class<?> moduleClass = module.getClass();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  79 */       Method isexported = moduleClass.getMethod("isExported", new Class[] { String.class });
/*  80 */       exported = ((Boolean)isexported.invoke(module, new Object[] { pname })).booleanValue();
/*  81 */     } catch (NoSuchMethodException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  86 */       exported = false;
/*     */     } 
/*  88 */     return exported;
/*     */   }
/*     */   
/*     */   private static Method findAccessibleMethod(Method method) {
/*  92 */     Class<?> cl = method.getDeclaringClass();
/*  93 */     String methodName = method.getName();
/*  94 */     Class<?>[] methodTypes = method.getParameterTypes();
/*     */     
/*     */     label23: while (true) {
/*  97 */       for (Class<?> intface : cl.getInterfaces()) {
/*     */         try {
/*  99 */           method = intface.getMethod(methodName, methodTypes);
/*     */           break label23;
/* 101 */         } catch (NoSuchMethodException noSuchMethodException) {}
/*     */       } 
/*     */       
/* 104 */       cl = cl.getSuperclass();
/* 105 */       if (cl == null) {
/*     */         break;
/*     */       }
/* 108 */       if (isExportedClass(cl)) {
/*     */         try {
/* 110 */           method = cl.getMethod(methodName, methodTypes);
/*     */           break;
/* 112 */         } catch (NoSuchMethodException noSuchMethodException) {}
/*     */       }
/*     */     } 
/*     */     
/* 116 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\JavaMembers_jdk11.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */