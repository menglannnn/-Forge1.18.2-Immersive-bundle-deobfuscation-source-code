/*     */ package org.mozilla.javascript;public class Token { public static final boolean printTrees = false; static final boolean printICode = false; static final boolean printNames = false; public static final int ERROR = -1; public static final int EOF = 0; public static final int EOL = 1; public static final int FIRST_BYTECODE_TOKEN = 2; public static final int ENTERWITH = 2; public static final int LEAVEWITH = 3; public static final int RETURN = 4; public static final int GOTO = 5; public static final int IFEQ = 6; public static final int IFNE = 7; public static final int SETNAME = 8; public static final int BITOR = 9; public static final int BITXOR = 10; public static final int BITAND = 11; public static final int EQ = 12; public static final int NE = 13; public static final int LT = 14; public static final int LE = 15; public static final int GT = 16; public static final int GE = 17; public static final int LSH = 18; public static final int RSH = 19; public static final int URSH = 20; public static final int ADD = 21; public static final int SUB = 22; public static final int MUL = 23; public static final int DIV = 24; public static final int MOD = 25; public static final int NOT = 26; public static final int BITNOT = 27; public static final int POS = 28; public static final int NEG = 29; public static final int NEW = 30; public static final int DELPROP = 31; public static final int TYPEOF = 32; public static final int GETPROP = 33; public static final int GETPROPNOWARN = 34; public static final int SETPROP = 35; public static final int GETELEM = 36; public static final int SETELEM = 37; public static final int CALL = 38; public static final int NAME = 39; public static final int NUMBER = 40; public static final int STRING = 41; public static final int NULL = 42; public static final int THIS = 43; public static final int FALSE = 44; public static final int TRUE = 45; public static final int SHEQ = 46; public static final int SHNE = 47; public static final int REGEXP = 48; public static final int BINDNAME = 49; public static final int THROW = 50; public static final int RETHROW = 51; public static final int IN = 52; public static final int INSTANCEOF = 53; public static final int LOCAL_LOAD = 54; public static final int GETVAR = 55; public static final int SETVAR = 56; public static final int CATCH_SCOPE = 57; public static final int ENUM_INIT_KEYS = 58; public static final int ENUM_INIT_VALUES = 59; public static final int ENUM_INIT_ARRAY = 60; public static final int ENUM_INIT_VALUES_IN_ORDER = 61; public static final int ENUM_NEXT = 62; public static final int ENUM_ID = 63; public static final int THISFN = 64; public static final int RETURN_RESULT = 65; public static final int ARRAYLIT = 66; public static final int OBJECTLIT = 67; public static final int GET_REF = 68; public static final int SET_REF = 69; public static final int DEL_REF = 70; public static final int REF_CALL = 71; public static final int REF_SPECIAL = 72; public static final int YIELD = 73; public static final int STRICT_SETNAME = 74; public static final int EXP = 75; public static final int DEFAULTNAMESPACE = 76; public static final int ESCXMLATTR = 77; public static final int ESCXMLTEXT = 78; public static final int REF_MEMBER = 79; public static final int REF_NS_MEMBER = 80; public static final int REF_NAME = 81; public static final int REF_NS_NAME = 82; public static final int BIGINT = 83; public static final int LAST_BYTECODE_TOKEN = 83; public static final int TRY = 84; public static final int SEMI = 85; public static final int LB = 86; public static final int RB = 87; public static final int LC = 88; public static final int RC = 89; public static final int LP = 90; public static final int RP = 91; public static final int COMMA = 92; public static final int ASSIGN = 93; public static final int ASSIGN_BITOR = 94; public static final int ASSIGN_BITXOR = 95; public static final int ASSIGN_BITAND = 96; public static final int ASSIGN_LSH = 97; public static final int ASSIGN_RSH = 98; public static final int ASSIGN_URSH = 99; public static final int ASSIGN_ADD = 100; public static final int ASSIGN_SUB = 101; public static final int ASSIGN_MUL = 102; public static final int ASSIGN_DIV = 103; public static final int ASSIGN_MOD = 104; public static final int ASSIGN_EXP = 105; public static final int FIRST_ASSIGN = 93; public static final int LAST_ASSIGN = 105; public static final int HOOK = 106; public static final int COLON = 107; public static final int OR = 108; public static final int AND = 109; public static final int INC = 110; public static final int DEC = 111; public static final int DOT = 112; public static final int FUNCTION = 113; public static final int EXPORT = 114; public static final int IMPORT = 115; public static final int IF = 116; public static final int ELSE = 117; public static final int SWITCH = 118; public static final int CASE = 119; public static final int DEFAULT = 120; public static final int WHILE = 121; public static final int DO = 122; public static final int FOR = 123; public static final int BREAK = 124; public static final int CONTINUE = 125; public static final int VAR = 126; public static final int WITH = 127; public static final int CATCH = 128; public static final int FINALLY = 129; public static final int VOID = 130; public static final int RESERVED = 131; public static final int EMPTY = 132; public static final int BLOCK = 133; public static final int LABEL = 134; public static final int TARGET = 135; public static final int LOOP = 136; public static final int EXPR_VOID = 137; public static final int EXPR_RESULT = 138; public static final int JSR = 139; public static final int SCRIPT = 140; public static final int TYPEOFNAME = 141; public static final int USE_STACK = 142; public static final int SETPROP_OP = 143; public static final int SETELEM_OP = 144; public static final int LOCAL_BLOCK = 145; public static final int SET_REF_OP = 146; public static final int DOTDOT = 147; public static final int COLONCOLON = 148; public static final int XML = 149; public static final int DOTQUERY = 150; public static final int XMLATTR = 151; public static final int XMLEND = 152; public static final int TO_OBJECT = 153; public static final int TO_DOUBLE = 154; public static final int GET = 155; public static final int SET = 156; public static final int LET = 157;
/*     */   public static final int CONST = 158;
/*     */   public static final int SETCONST = 159;
/*     */   public static final int SETCONSTVAR = 160;
/*     */   public static final int ARRAYCOMP = 161;
/*     */   public static final int LETEXPR = 162;
/*     */   public static final int WITHEXPR = 163;
/*     */   public static final int DEBUGGER = 164;
/*     */   public static final int COMMENT = 165;
/*     */   public static final int GENEXPR = 166;
/*     */   public static final int METHOD = 167;
/*     */   public static final int ARROW = 168;
/*     */   public static final int YIELD_STAR = 169;
/*     */   public static final int TEMPLATE_LITERAL = 170;
/*     */   public static final int TEMPLATE_CHARS = 171;
/*     */   public static final int TEMPLATE_LITERAL_SUBST = 172;
/*     */   public static final int TAGGED_TEMPLATE_LITERAL = 173;
/*     */   public static final int LAST_TOKEN = 173;
/*     */   
/*  20 */   public enum CommentType { LINE,
/*  21 */     BLOCK_COMMENT,
/*  22 */     JSDOC,
/*  23 */     HTML; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String name(int token) {
/* 237 */     return String.valueOf(token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String typeToName(int token) {
/* 250 */     switch (token) {
/*     */       case -1:
/* 252 */         return "ERROR";
/*     */       case 0:
/* 254 */         return "EOF";
/*     */       case 1:
/* 256 */         return "EOL";
/*     */       case 2:
/* 258 */         return "ENTERWITH";
/*     */       case 3:
/* 260 */         return "LEAVEWITH";
/*     */       case 4:
/* 262 */         return "RETURN";
/*     */       case 5:
/* 264 */         return "GOTO";
/*     */       case 6:
/* 266 */         return "IFEQ";
/*     */       case 7:
/* 268 */         return "IFNE";
/*     */       case 8:
/* 270 */         return "SETNAME";
/*     */       case 9:
/* 272 */         return "BITOR";
/*     */       case 10:
/* 274 */         return "BITXOR";
/*     */       case 11:
/* 276 */         return "BITAND";
/*     */       case 12:
/* 278 */         return "EQ";
/*     */       case 13:
/* 280 */         return "NE";
/*     */       case 14:
/* 282 */         return "LT";
/*     */       case 15:
/* 284 */         return "LE";
/*     */       case 16:
/* 286 */         return "GT";
/*     */       case 17:
/* 288 */         return "GE";
/*     */       case 18:
/* 290 */         return "LSH";
/*     */       case 19:
/* 292 */         return "RSH";
/*     */       case 20:
/* 294 */         return "URSH";
/*     */       case 21:
/* 296 */         return "ADD";
/*     */       case 22:
/* 298 */         return "SUB";
/*     */       case 23:
/* 300 */         return "MUL";
/*     */       case 24:
/* 302 */         return "DIV";
/*     */       case 25:
/* 304 */         return "MOD";
/*     */       case 26:
/* 306 */         return "NOT";
/*     */       case 27:
/* 308 */         return "BITNOT";
/*     */       case 28:
/* 310 */         return "POS";
/*     */       case 29:
/* 312 */         return "NEG";
/*     */       case 30:
/* 314 */         return "NEW";
/*     */       case 31:
/* 316 */         return "DELPROP";
/*     */       case 32:
/* 318 */         return "TYPEOF";
/*     */       case 33:
/* 320 */         return "GETPROP";
/*     */       case 34:
/* 322 */         return "GETPROPNOWARN";
/*     */       case 35:
/* 324 */         return "SETPROP";
/*     */       case 36:
/* 326 */         return "GETELEM";
/*     */       case 37:
/* 328 */         return "SETELEM";
/*     */       case 38:
/* 330 */         return "CALL";
/*     */       case 39:
/* 332 */         return "NAME";
/*     */       case 40:
/* 334 */         return "NUMBER";
/*     */       case 41:
/* 336 */         return "STRING";
/*     */       case 42:
/* 338 */         return "NULL";
/*     */       case 43:
/* 340 */         return "THIS";
/*     */       case 44:
/* 342 */         return "FALSE";
/*     */       case 45:
/* 344 */         return "TRUE";
/*     */       case 46:
/* 346 */         return "SHEQ";
/*     */       case 47:
/* 348 */         return "SHNE";
/*     */       case 48:
/* 350 */         return "REGEXP";
/*     */       case 49:
/* 352 */         return "BINDNAME";
/*     */       case 50:
/* 354 */         return "THROW";
/*     */       case 51:
/* 356 */         return "RETHROW";
/*     */       case 52:
/* 358 */         return "IN";
/*     */       case 53:
/* 360 */         return "INSTANCEOF";
/*     */       case 54:
/* 362 */         return "LOCAL_LOAD";
/*     */       case 55:
/* 364 */         return "GETVAR";
/*     */       case 56:
/* 366 */         return "SETVAR";
/*     */       case 57:
/* 368 */         return "CATCH_SCOPE";
/*     */       case 58:
/* 370 */         return "ENUM_INIT_KEYS";
/*     */       case 59:
/* 372 */         return "ENUM_INIT_VALUES";
/*     */       case 60:
/* 374 */         return "ENUM_INIT_ARRAY";
/*     */       case 61:
/* 376 */         return "ENUM_INIT_VALUES_IN_ORDER";
/*     */       case 62:
/* 378 */         return "ENUM_NEXT";
/*     */       case 63:
/* 380 */         return "ENUM_ID";
/*     */       case 64:
/* 382 */         return "THISFN";
/*     */       case 65:
/* 384 */         return "RETURN_RESULT";
/*     */       case 66:
/* 386 */         return "ARRAYLIT";
/*     */       case 67:
/* 388 */         return "OBJECTLIT";
/*     */       case 68:
/* 390 */         return "GET_REF";
/*     */       case 69:
/* 392 */         return "SET_REF";
/*     */       case 70:
/* 394 */         return "DEL_REF";
/*     */       case 71:
/* 396 */         return "REF_CALL";
/*     */       case 72:
/* 398 */         return "REF_SPECIAL";
/*     */       case 76:
/* 400 */         return "DEFAULTNAMESPACE";
/*     */       case 78:
/* 402 */         return "ESCXMLTEXT";
/*     */       case 77:
/* 404 */         return "ESCXMLATTR";
/*     */       case 79:
/* 406 */         return "REF_MEMBER";
/*     */       case 80:
/* 408 */         return "REF_NS_MEMBER";
/*     */       case 81:
/* 410 */         return "REF_NAME";
/*     */       case 82:
/* 412 */         return "REF_NS_NAME";
/*     */       case 84:
/* 414 */         return "TRY";
/*     */       case 85:
/* 416 */         return "SEMI";
/*     */       case 86:
/* 418 */         return "LB";
/*     */       case 87:
/* 420 */         return "RB";
/*     */       case 88:
/* 422 */         return "LC";
/*     */       case 89:
/* 424 */         return "RC";
/*     */       case 90:
/* 426 */         return "LP";
/*     */       case 91:
/* 428 */         return "RP";
/*     */       case 92:
/* 430 */         return "COMMA";
/*     */       case 93:
/* 432 */         return "ASSIGN";
/*     */       case 94:
/* 434 */         return "ASSIGN_BITOR";
/*     */       case 95:
/* 436 */         return "ASSIGN_BITXOR";
/*     */       case 96:
/* 438 */         return "ASSIGN_BITAND";
/*     */       case 97:
/* 440 */         return "ASSIGN_LSH";
/*     */       case 98:
/* 442 */         return "ASSIGN_RSH";
/*     */       case 99:
/* 444 */         return "ASSIGN_URSH";
/*     */       case 100:
/* 446 */         return "ASSIGN_ADD";
/*     */       case 101:
/* 448 */         return "ASSIGN_SUB";
/*     */       case 102:
/* 450 */         return "ASSIGN_MUL";
/*     */       case 103:
/* 452 */         return "ASSIGN_DIV";
/*     */       case 104:
/* 454 */         return "ASSIGN_MOD";
/*     */       case 105:
/* 456 */         return "ASSIGN_EXP";
/*     */       case 106:
/* 458 */         return "HOOK";
/*     */       case 107:
/* 460 */         return "COLON";
/*     */       case 108:
/* 462 */         return "OR";
/*     */       case 109:
/* 464 */         return "AND";
/*     */       case 110:
/* 466 */         return "INC";
/*     */       case 111:
/* 468 */         return "DEC";
/*     */       case 112:
/* 470 */         return "DOT";
/*     */       case 113:
/* 472 */         return "FUNCTION";
/*     */       case 114:
/* 474 */         return "EXPORT";
/*     */       case 115:
/* 476 */         return "IMPORT";
/*     */       case 116:
/* 478 */         return "IF";
/*     */       case 117:
/* 480 */         return "ELSE";
/*     */       case 118:
/* 482 */         return "SWITCH";
/*     */       case 119:
/* 484 */         return "CASE";
/*     */       case 120:
/* 486 */         return "DEFAULT";
/*     */       case 121:
/* 488 */         return "WHILE";
/*     */       case 122:
/* 490 */         return "DO";
/*     */       case 123:
/* 492 */         return "FOR";
/*     */       case 124:
/* 494 */         return "BREAK";
/*     */       case 125:
/* 496 */         return "CONTINUE";
/*     */       case 126:
/* 498 */         return "VAR";
/*     */       case 127:
/* 500 */         return "WITH";
/*     */       case 128:
/* 502 */         return "CATCH";
/*     */       case 129:
/* 504 */         return "FINALLY";
/*     */       case 130:
/* 506 */         return "VOID";
/*     */       case 131:
/* 508 */         return "RESERVED";
/*     */       case 132:
/* 510 */         return "EMPTY";
/*     */       case 133:
/* 512 */         return "BLOCK";
/*     */       case 134:
/* 514 */         return "LABEL";
/*     */       case 135:
/* 516 */         return "TARGET";
/*     */       case 136:
/* 518 */         return "LOOP";
/*     */       case 137:
/* 520 */         return "EXPR_VOID";
/*     */       case 138:
/* 522 */         return "EXPR_RESULT";
/*     */       case 139:
/* 524 */         return "JSR";
/*     */       case 140:
/* 526 */         return "SCRIPT";
/*     */       case 141:
/* 528 */         return "TYPEOFNAME";
/*     */       case 142:
/* 530 */         return "USE_STACK";
/*     */       case 143:
/* 532 */         return "SETPROP_OP";
/*     */       case 144:
/* 534 */         return "SETELEM_OP";
/*     */       case 145:
/* 536 */         return "LOCAL_BLOCK";
/*     */       case 146:
/* 538 */         return "SET_REF_OP";
/*     */       case 147:
/* 540 */         return "DOTDOT";
/*     */       case 148:
/* 542 */         return "COLONCOLON";
/*     */       case 149:
/* 544 */         return "XML";
/*     */       case 150:
/* 546 */         return "DOTQUERY";
/*     */       case 151:
/* 548 */         return "XMLATTR";
/*     */       case 152:
/* 550 */         return "XMLEND";
/*     */       case 153:
/* 552 */         return "TO_OBJECT";
/*     */       case 154:
/* 554 */         return "TO_DOUBLE";
/*     */       case 155:
/* 556 */         return "GET";
/*     */       case 156:
/* 558 */         return "SET";
/*     */       case 157:
/* 560 */         return "LET";
/*     */       case 73:
/* 562 */         return "YIELD";
/*     */       case 75:
/* 564 */         return "EXP";
/*     */       case 158:
/* 566 */         return "CONST";
/*     */       case 159:
/* 568 */         return "SETCONST";
/*     */       case 161:
/* 570 */         return "ARRAYCOMP";
/*     */       case 163:
/* 572 */         return "WITHEXPR";
/*     */       case 162:
/* 574 */         return "LETEXPR";
/*     */       case 164:
/* 576 */         return "DEBUGGER";
/*     */       case 165:
/* 578 */         return "COMMENT";
/*     */       case 166:
/* 580 */         return "GENEXPR";
/*     */       case 167:
/* 582 */         return "METHOD";
/*     */       case 168:
/* 584 */         return "ARROW";
/*     */       case 169:
/* 586 */         return "YIELD_STAR";
/*     */       case 83:
/* 588 */         return "BIGINT";
/*     */       case 170:
/* 590 */         return "TEMPLATE_LITERAL";
/*     */       case 171:
/* 592 */         return "TEMPLATE_CHARS";
/*     */       case 172:
/* 594 */         return "TEMPLATE_LITERAL_SUBST";
/*     */       case 173:
/* 596 */         return "TAGGED_TEMPLATE_LITERAL";
/*     */     } 
/*     */ 
/*     */     
/* 600 */     throw new IllegalStateException(String.valueOf(token));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String keywordToName(int token) {
/* 611 */     switch (token) {
/*     */       case 124:
/* 613 */         return "break";
/*     */       case 119:
/* 615 */         return "case";
/*     */       case 125:
/* 617 */         return "continue";
/*     */       case 120:
/* 619 */         return "default";
/*     */       case 31:
/* 621 */         return "delete";
/*     */       case 122:
/* 623 */         return "do";
/*     */       case 117:
/* 625 */         return "else";
/*     */       case 44:
/* 627 */         return "false";
/*     */       case 123:
/* 629 */         return "for";
/*     */       case 113:
/* 631 */         return "function";
/*     */       case 116:
/* 633 */         return "if";
/*     */       case 52:
/* 635 */         return "in";
/*     */       case 157:
/* 637 */         return "let";
/*     */       case 30:
/* 639 */         return "new";
/*     */       case 42:
/* 641 */         return "null";
/*     */       case 4:
/* 643 */         return "return";
/*     */       case 118:
/* 645 */         return "switch";
/*     */       case 43:
/* 647 */         return "this";
/*     */       case 45:
/* 649 */         return "true";
/*     */       case 32:
/* 651 */         return "typeof";
/*     */       case 126:
/* 653 */         return "var";
/*     */       case 130:
/* 655 */         return "void";
/*     */       case 121:
/* 657 */         return "while";
/*     */       case 127:
/* 659 */         return "with";
/*     */       case 73:
/* 661 */         return "yield";
/*     */       case 128:
/* 663 */         return "catch";
/*     */       case 158:
/* 665 */         return "const";
/*     */       case 164:
/* 667 */         return "debugger";
/*     */       case 129:
/* 669 */         return "finally";
/*     */       case 53:
/* 671 */         return "instanceof";
/*     */       case 50:
/* 673 */         return "throw";
/*     */       case 84:
/* 675 */         return "try";
/*     */     } 
/* 677 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidToken(int code) {
/* 688 */     return (code >= -1 && code <= 173);
/*     */   } }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Token.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */