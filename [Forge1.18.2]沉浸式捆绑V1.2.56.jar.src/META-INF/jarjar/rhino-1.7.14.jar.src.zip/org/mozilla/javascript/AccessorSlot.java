/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ public class AccessorSlot
/*     */   extends Slot
/*     */ {
/*     */   private static final long serialVersionUID = 1677840254177335827L;
/*     */   transient Getter getter;
/*     */   transient Setter setter;
/*     */   
/*     */   AccessorSlot(Slot oldSlot) {
/*  12 */     super(oldSlot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isValueSlot() {
/*  22 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isSetterSlot() {
/*  27 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ScriptableObject getPropertyDescriptor(Context cx, Scriptable scope) {
/*  35 */     ScriptableObject desc = (ScriptableObject)cx.newObject(scope);
/*  36 */     desc.setCommonDescriptorProperties(getAttributes(), (this.getter == null && this.setter == null));
/*  37 */     String fName = (this.name == null) ? "f" : this.name.toString();
/*  38 */     if (this.getter != null) {
/*  39 */       Function f = this.getter.asGetterFunction(fName, scope);
/*  40 */       desc.defineProperty("get", (f == null) ? Undefined.instance : f, 0);
/*     */     } 
/*  42 */     if (this.setter != null) {
/*  43 */       Function f = this.setter.asSetterFunction(fName, scope);
/*  44 */       desc.defineProperty("set", (f == null) ? Undefined.instance : f, 0);
/*     */     } 
/*  46 */     return desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setValue(Object value, Scriptable owner, Scriptable start) {
/*  51 */     if (this.setter == null) {
/*  52 */       if (this.getter != null) {
/*  53 */         throwNoSetterException(start, value);
/*  54 */         return true;
/*     */       } 
/*     */     } else {
/*  57 */       return this.setter.setValue(value, owner, start);
/*     */     } 
/*  59 */     return super.setValue(value, owner, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(Scriptable start) {
/*  64 */     if (this.getter != null) {
/*  65 */       return this.getter.getValue(start);
/*     */     }
/*  67 */     return super.getValue(start);
/*     */   }
/*     */ 
/*     */   
/*     */   Function getSetterFunction(String name, Scriptable scope) {
/*  72 */     if (this.setter == null) {
/*  73 */       return null;
/*     */     }
/*  75 */     return this.setter.asSetterFunction(name, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   Function getGetterFunction(String name, Scriptable scope) {
/*  80 */     if (this.getter == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     return this.getter.asGetterFunction(name, scope);
/*     */   }
/*     */   
/*     */   static interface Getter {
/*     */     Object getValue(Scriptable param1Scriptable);
/*     */     
/*     */     Function asGetterFunction(String param1String, Scriptable param1Scriptable);
/*     */   }
/*     */   
/*     */   static final class MemberBoxGetter
/*     */     implements Getter {
/*     */     final MemberBox member;
/*     */     
/*     */     MemberBoxGetter(MemberBox member) {
/*  97 */       this.member = member;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getValue(Scriptable start) {
/* 102 */       if (this.member.delegateTo == null) {
/* 103 */         return this.member.invoke(start, ScriptRuntime.emptyArgs);
/*     */       }
/* 105 */       return this.member.invoke(this.member.delegateTo, new Object[] { start });
/*     */     }
/*     */ 
/*     */     
/*     */     public Function asGetterFunction(String name, Scriptable scope) {
/* 110 */       return this.member.asGetterFunction(name, scope);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class FunctionGetter
/*     */     implements Getter
/*     */   {
/*     */     final Object target;
/*     */     
/*     */     FunctionGetter(Object target) {
/* 120 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getValue(Scriptable start) {
/* 125 */       if (this.target instanceof Function) {
/* 126 */         Function t = (Function)this.target;
/* 127 */         Context cx = Context.getContext();
/* 128 */         return t.call(cx, t.getParentScope(), start, ScriptRuntime.emptyArgs);
/*     */       } 
/* 130 */       return Undefined.instance;
/*     */     }
/*     */ 
/*     */     
/*     */     public Function asGetterFunction(String name, Scriptable scope) {
/* 135 */       return (this.target instanceof Function) ? (Function)this.target : null;
/*     */     }
/*     */   }
/*     */   
/*     */   static interface Setter {
/*     */     boolean setValue(Object param1Object, Scriptable param1Scriptable1, Scriptable param1Scriptable2);
/*     */     
/*     */     Function asSetterFunction(String param1String, Scriptable param1Scriptable);
/*     */   }
/*     */   
/*     */   static final class MemberBoxSetter
/*     */     implements Setter {
/*     */     final MemberBox member;
/*     */     
/*     */     MemberBoxSetter(MemberBox member) {
/* 150 */       this.member = member;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setValue(Object value, Scriptable owner, Scriptable start) {
/* 155 */       Context cx = Context.getContext();
/* 156 */       Class<?>[] pTypes = this.member.argTypes;
/*     */ 
/*     */       
/* 159 */       Class<?> valueType = pTypes[pTypes.length - 1];
/* 160 */       int tag = FunctionObject.getTypeTag(valueType);
/* 161 */       Object actualArg = FunctionObject.convertArg(cx, start, value, tag);
/*     */       
/* 163 */       if (this.member.delegateTo == null) {
/* 164 */         this.member.invoke(start, new Object[] { actualArg });
/*     */       } else {
/* 166 */         this.member.invoke(this.member.delegateTo, new Object[] { start, actualArg });
/*     */       } 
/* 168 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public Function asSetterFunction(String name, Scriptable scope) {
/* 173 */       return this.member.asSetterFunction(name, scope);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class FunctionSetter
/*     */     implements Setter
/*     */   {
/*     */     final Object target;
/*     */     
/*     */     FunctionSetter(Object target) {
/* 184 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setValue(Object value, Scriptable owner, Scriptable start) {
/* 189 */       if (this.target instanceof Function) {
/* 190 */         Function t = (Function)this.target;
/* 191 */         Context cx = Context.getContext();
/* 192 */         t.call(cx, t.getParentScope(), start, new Object[] { value });
/*     */       } 
/* 194 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public Function asSetterFunction(String name, Scriptable scope) {
/* 199 */       return (this.target instanceof Function) ? (Function)this.target : null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\AccessorSlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */