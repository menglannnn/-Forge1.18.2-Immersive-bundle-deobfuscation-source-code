/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaObject
/*     */   implements Scriptable, SymbolScriptable, Wrapper, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6948590651130498591L;
/*     */   private static final int JSTYPE_UNDEFINED = 0;
/*     */   private static final int JSTYPE_NULL = 1;
/*     */   private static final int JSTYPE_BOOLEAN = 2;
/*     */   private static final int JSTYPE_NUMBER = 3;
/*     */   private static final int JSTYPE_STRING = 4;
/*     */   private static final int JSTYPE_JAVA_CLASS = 5;
/*     */   private static final int JSTYPE_JAVA_OBJECT = 6;
/*     */   private static final int JSTYPE_JAVA_ARRAY = 7;
/*     */   private static final int JSTYPE_OBJECT = 8;
/*     */   private static final int JSTYPE_BIGINT = 9;
/*     */   
/*     */   static void init(ScriptableObject scope, boolean sealed) {
/*  38 */     JavaIterableIterator.init(scope, sealed);
/*     */   }
/*     */   static final byte CONVERSION_TRIVIAL = 1; static final byte CONVERSION_NONTRIVIAL = 0; static final byte CONVERSION_NONE = 99; private static Callable symbol_iterator; protected Scriptable prototype; protected Scriptable parent; protected transient Object javaObject; protected transient Class<?> staticType; protected transient JavaMembers members; private transient Map<String, FieldAndMethods> fieldAndMethods; protected transient boolean isAdapter;
/*     */   public NativeJavaObject() {}
/*     */   
/*     */   public NativeJavaObject(Scriptable scope, Object javaObject, Class<?> staticType) {
/*  44 */     this(scope, javaObject, staticType, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeJavaObject(Scriptable scope, Object javaObject, Class<?> staticType, boolean isAdapter) {
/*  49 */     this.parent = scope;
/*  50 */     this.javaObject = javaObject;
/*  51 */     this.staticType = staticType;
/*  52 */     this.isAdapter = isAdapter;
/*  53 */     initMembers();
/*     */   }
/*     */   
/*     */   protected void initMembers() {
/*     */     Class<?> dynamicType;
/*  58 */     if (this.javaObject != null) {
/*  59 */       dynamicType = this.javaObject.getClass();
/*     */     } else {
/*  61 */       dynamicType = this.staticType;
/*     */     } 
/*  63 */     this.members = JavaMembers.lookupClass(this.parent, dynamicType, this.staticType, this.isAdapter);
/*  64 */     this.fieldAndMethods = this.members.getFieldAndMethodsObjects(this, this.javaObject, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(String name, Scriptable start) {
/*  69 */     return this.members.has(name, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(Symbol key, Scriptable start) {
/*  79 */     if (SymbolKey.ITERATOR.equals(key) && this.javaObject instanceof Iterable) {
/*  80 */       return true;
/*     */     }
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String name, Scriptable start) {
/*  87 */     if (this.fieldAndMethods != null) {
/*  88 */       Object result = this.fieldAndMethods.get(name);
/*  89 */       if (result != null) {
/*  90 */         return result;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  95 */     return this.members.get(this, name, this.javaObject, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Symbol key, Scriptable start) {
/* 100 */     if (SymbolKey.ITERATOR.equals(key) && this.javaObject instanceof Iterable) {
/* 101 */       return symbol_iterator;
/*     */     }
/*     */     
/* 104 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/* 109 */     throw this.members.reportMemberNotFound(Integer.toString(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String name, Scriptable start, Object value) {
/* 117 */     if (this.prototype == null || this.members.has(name, false))
/* 118 */     { this.members.put(this, name, this.javaObject, value, false); }
/* 119 */     else { this.prototype.put(name, this.prototype, value); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Symbol symbol, Scriptable start, Object value) {
/* 127 */     String name = symbol.toString();
/* 128 */     if (this.prototype == null || this.members.has(name, false)) {
/* 129 */       this.members.put(this, name, this.javaObject, value, false);
/* 130 */     } else if (this.prototype instanceof SymbolScriptable) {
/* 131 */       ((SymbolScriptable)this.prototype).put(symbol, this.prototype, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/* 137 */     throw this.members.reportMemberNotFound(Integer.toString(index));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasInstance(Scriptable value) {
/* 143 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(String name) {}
/*     */ 
/*     */   
/*     */   public void delete(Symbol key) {}
/*     */ 
/*     */   
/*     */   public void delete(int index) {}
/*     */ 
/*     */   
/*     */   public Scriptable getPrototype() {
/* 157 */     if (this.prototype == null && this.javaObject instanceof String) {
/* 158 */       return TopLevel.getBuiltinPrototype(
/* 159 */           ScriptableObject.getTopLevelScope(this.parent), TopLevel.Builtins.String);
/*     */     }
/* 161 */     return this.prototype;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrototype(Scriptable m) {
/* 167 */     this.prototype = m;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getParentScope() {
/* 173 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentScope(Scriptable m) {
/* 179 */     this.parent = m;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 184 */     return this.members.getIds(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Object wrap(Scriptable scope, Object obj, Class<?> staticType) {
/* 194 */     Context cx = Context.getContext();
/* 195 */     return cx.getWrapFactory().wrap(cx, scope, obj, staticType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unwrap() {
/* 200 */     return this.javaObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 205 */     return "JavaObject";
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class<?> hint) {
/*     */     Object value;
/* 211 */     if (hint == null) {
/* 212 */       if (this.javaObject instanceof Boolean) {
/* 213 */         hint = ScriptRuntime.BooleanClass;
/*     */       }
/* 215 */       if (this.javaObject instanceof Number) {
/* 216 */         hint = ScriptRuntime.NumberClass;
/*     */       }
/*     */     } 
/* 219 */     if (hint == null || hint == ScriptRuntime.StringClass) {
/* 220 */       value = this.javaObject.toString();
/*     */     } else {
/*     */       String converterName;
/* 223 */       if (hint == ScriptRuntime.BooleanClass) {
/* 224 */         converterName = "booleanValue";
/* 225 */       } else if (hint == ScriptRuntime.NumberClass) {
/* 226 */         converterName = "doubleValue";
/*     */       } else {
/* 228 */         throw Context.reportRuntimeErrorById("msg.default.value", new Object[0]);
/*     */       } 
/* 230 */       Object converterObject = get(converterName, this);
/* 231 */       if (converterObject instanceof Function) {
/* 232 */         Function f = (Function)converterObject;
/*     */         
/* 234 */         value = f.call(
/* 235 */             Context.getContext(), f
/* 236 */             .getParentScope(), this, ScriptRuntime.emptyArgs);
/*     */ 
/*     */       
/*     */       }
/* 240 */       else if (hint == ScriptRuntime.NumberClass && this.javaObject instanceof Boolean) {
/* 241 */         boolean b = ((Boolean)this.javaObject).booleanValue();
/* 242 */         value = b ? ScriptRuntime.wrapNumber(1.0D) : ScriptRuntime.zeroObj;
/*     */       } else {
/* 244 */         value = this.javaObject.toString();
/*     */       } 
/*     */     } 
/*     */     
/* 248 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canConvert(Object fromObj, Class<?> to) {
/* 257 */     int weight = getConversionWeight(fromObj, to);
/*     */     
/* 259 */     return (weight < 99);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getConversionWeight(Object fromObj, Class<?> to) {
/*     */     Object javaObj;
/* 285 */     int fromCode = getJSTypeCode(fromObj);
/*     */     
/* 287 */     switch (fromCode) {
/*     */       case 0:
/* 289 */         if (to == ScriptRuntime.StringClass || to == ScriptRuntime.ObjectClass) {
/* 290 */           return 1;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 1:
/* 295 */         if (!to.isPrimitive()) {
/* 296 */           return 1;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 302 */         if (to == boolean.class)
/* 303 */           return 1; 
/* 304 */         if (to == ScriptRuntime.BooleanClass)
/* 305 */           return 2; 
/* 306 */         if (to == ScriptRuntime.ObjectClass)
/* 307 */           return 3; 
/* 308 */         if (to == ScriptRuntime.StringClass) {
/* 309 */           return 4;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 3:
/*     */       case 9:
/* 315 */         if (to.isPrimitive()) {
/* 316 */           if (to == double.class)
/* 317 */             return 1; 
/* 318 */           if (to != boolean.class)
/* 319 */             return 1 + getSizeRank(to); 
/*     */           break;
/*     */         } 
/* 322 */         if (to == ScriptRuntime.StringClass)
/*     */         {
/* 324 */           return 9; } 
/* 325 */         if (to == ScriptRuntime.BigIntegerClass)
/* 326 */           return 10; 
/* 327 */         if (to == ScriptRuntime.ObjectClass)
/* 328 */           return 11; 
/* 329 */         if (ScriptRuntime.NumberClass.isAssignableFrom(to))
/*     */         {
/* 331 */           return 2;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 337 */         if (to == ScriptRuntime.StringClass)
/* 338 */           return 1; 
/* 339 */         if (to.isInstance(fromObj))
/* 340 */           return 2; 
/* 341 */         if (to.isPrimitive()) {
/* 342 */           if (to == char.class)
/* 343 */             return 3; 
/* 344 */           if (to != boolean.class) {
/* 345 */             return 4;
/*     */           }
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 5:
/* 351 */         if (to == ScriptRuntime.ClassClass)
/* 352 */           return 1; 
/* 353 */         if (to == ScriptRuntime.ObjectClass)
/* 354 */           return 3; 
/* 355 */         if (to == ScriptRuntime.StringClass) {
/* 356 */           return 4;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 6:
/*     */       case 7:
/* 362 */         javaObj = fromObj;
/* 363 */         if (javaObj instanceof Wrapper) {
/* 364 */           javaObj = ((Wrapper)javaObj).unwrap();
/*     */         }
/* 366 */         if (to.isInstance(javaObj)) {
/* 367 */           return 0;
/*     */         }
/* 369 */         if (to == ScriptRuntime.StringClass)
/* 370 */           return 2; 
/* 371 */         if (to.isPrimitive() && to != boolean.class) {
/* 372 */           return (fromCode == 7) ? 99 : (2 + getSizeRank(to));
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 8:
/* 378 */         if (to != ScriptRuntime.ObjectClass && to.isInstance(fromObj))
/*     */         {
/* 380 */           return 1;
/*     */         }
/* 382 */         if (to.isArray()) {
/* 383 */           if (fromObj instanceof NativeArray)
/*     */           {
/*     */ 
/*     */             
/* 387 */             return 2; }  break;
/*     */         } 
/* 389 */         if (to == ScriptRuntime.ObjectClass)
/* 390 */           return 3; 
/* 391 */         if (to == ScriptRuntime.StringClass)
/* 392 */           return 4; 
/* 393 */         if (to == ScriptRuntime.DateClass) {
/* 394 */           if (fromObj instanceof NativeDate)
/*     */           {
/* 396 */             return 1; }  break;
/*     */         } 
/* 398 */         if (to.isInterface()) {
/*     */           
/* 400 */           if (fromObj instanceof NativeFunction)
/*     */           {
/* 402 */             return 1;
/*     */           }
/* 404 */           if (fromObj instanceof NativeObject) {
/* 405 */             return 2;
/*     */           }
/* 407 */           return 12;
/* 408 */         }  if (to.isPrimitive() && to != boolean.class) {
/* 409 */           return 4 + getSizeRank(to);
/*     */         }
/*     */         break;
/*     */     } 
/*     */     
/* 414 */     return 99;
/*     */   }
/*     */   
/*     */   static int getSizeRank(Class<?> aType) {
/* 418 */     if (aType == double.class)
/* 419 */       return 1; 
/* 420 */     if (aType == float.class)
/* 421 */       return 2; 
/* 422 */     if (aType == long.class)
/* 423 */       return 3; 
/* 424 */     if (aType == int.class)
/* 425 */       return 4; 
/* 426 */     if (aType == short.class)
/* 427 */       return 5; 
/* 428 */     if (aType == char.class)
/* 429 */       return 6; 
/* 430 */     if (aType == byte.class)
/* 431 */       return 7; 
/* 432 */     if (aType == boolean.class) {
/* 433 */       return 99;
/*     */     }
/* 435 */     return 8;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int getJSTypeCode(Object value) {
/* 440 */     if (value == null)
/* 441 */       return 1; 
/* 442 */     if (value == Undefined.instance)
/* 443 */       return 0; 
/* 444 */     if (value instanceof CharSequence)
/* 445 */       return 4; 
/* 446 */     if (value instanceof BigInteger)
/* 447 */       return 9; 
/* 448 */     if (value instanceof Number)
/* 449 */       return 3; 
/* 450 */     if (value instanceof Boolean)
/* 451 */       return 2; 
/* 452 */     if (value instanceof Scriptable) {
/* 453 */       if (value instanceof NativeJavaClass)
/* 454 */         return 5; 
/* 455 */       if (value instanceof NativeJavaArray)
/* 456 */         return 7; 
/* 457 */       if (value instanceof Wrapper) {
/* 458 */         return 6;
/*     */       }
/* 460 */       return 8;
/*     */     } 
/* 462 */     if (value instanceof Class) {
/* 463 */       return 5;
/*     */     }
/* 465 */     Class<?> valueClass = value.getClass();
/* 466 */     if (valueClass.isArray()) {
/* 467 */       return 7;
/*     */     }
/* 469 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Object coerceType(Class<?> type, Object value) {
/* 481 */     return coerceTypeImpl(type, value);
/*     */   }
/*     */ 
/*     */   
/*     */   static Object coerceTypeImpl(Class<?> type, Object value) {
/* 486 */     if (value != null && value.getClass() == type) {
/* 487 */       return value;
/*     */     }
/*     */     
/* 490 */     int jsTypeCode = getJSTypeCode(value);
/* 491 */     switch (jsTypeCode) {
/*     */       
/*     */       case 1:
/* 494 */         if (type.isPrimitive()) {
/* 495 */           reportConversionError(value, type);
/*     */         }
/* 497 */         return null;
/*     */       
/*     */       case 0:
/* 500 */         if (type == ScriptRuntime.StringClass || type == ScriptRuntime.ObjectClass) {
/* 501 */           return "undefined";
/*     */         }
/* 503 */         reportConversionError("undefined", type);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 508 */         if (type == boolean.class || type == ScriptRuntime.BooleanClass || type == ScriptRuntime.ObjectClass)
/*     */         {
/*     */           
/* 511 */           return value; } 
/* 512 */         if (type == ScriptRuntime.StringClass) {
/* 513 */           return value.toString();
/*     */         }
/* 515 */         reportConversionError(value, type);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/*     */       case 9:
/* 521 */         if (type == ScriptRuntime.StringClass)
/* 522 */           return ScriptRuntime.toString(value); 
/* 523 */         if (type == ScriptRuntime.ObjectClass) {
/* 524 */           Context context = Context.getCurrentContext();
/* 525 */           if (context != null && context
/* 526 */             .hasFeature(18)) {
/*     */             
/* 528 */             long roundedValue = Math.round(toDouble(value));
/* 529 */             if (roundedValue == toDouble(value)) {
/* 530 */               return coerceToNumber(long.class, value);
/*     */             }
/*     */           } 
/* 533 */           return coerceToNumber((jsTypeCode == 9) ? BigInteger.class : double.class, value);
/*     */         } 
/* 535 */         if ((type.isPrimitive() && type != boolean.class) || ScriptRuntime.NumberClass
/* 536 */           .isAssignableFrom(type)) {
/* 537 */           return coerceToNumber(type, value);
/*     */         }
/* 539 */         reportConversionError(value, type);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 544 */         if (type == ScriptRuntime.StringClass || type.isInstance(value))
/* 545 */           return value.toString(); 
/* 546 */         if (type == char.class || type == ScriptRuntime.CharacterClass) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 551 */           if (((CharSequence)value).length() == 1) {
/* 552 */             return Character.valueOf(((CharSequence)value).charAt(0));
/*     */           }
/* 554 */           return coerceToNumber(type, value);
/* 555 */         }  if ((type.isPrimitive() && type != boolean.class) || ScriptRuntime.NumberClass
/* 556 */           .isAssignableFrom(type)) {
/* 557 */           return coerceToNumber(type, value);
/*     */         }
/* 559 */         reportConversionError(value, type);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/* 564 */         if (value instanceof Wrapper) {
/* 565 */           value = ((Wrapper)value).unwrap();
/*     */         }
/*     */         
/* 568 */         if (type == ScriptRuntime.ClassClass || type == ScriptRuntime.ObjectClass)
/* 569 */           return value; 
/* 570 */         if (type == ScriptRuntime.StringClass) {
/* 571 */           return value.toString();
/*     */         }
/* 573 */         reportConversionError(value, type);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 6:
/*     */       case 7:
/* 579 */         if (value instanceof Wrapper) {
/* 580 */           value = ((Wrapper)value).unwrap();
/*     */         }
/* 582 */         if (type.isPrimitive()) {
/* 583 */           if (type == boolean.class) {
/* 584 */             reportConversionError(value, type);
/*     */           }
/* 586 */           return coerceToNumber(type, value);
/*     */         } 
/* 588 */         if (type == ScriptRuntime.StringClass) {
/* 589 */           return value.toString();
/*     */         }
/* 591 */         if (type.isInstance(value)) {
/* 592 */           return value;
/*     */         }
/* 594 */         reportConversionError(value, type);
/*     */         break;
/*     */       
/*     */       case 8:
/* 598 */         if (type == ScriptRuntime.StringClass)
/* 599 */           return ScriptRuntime.toString(value); 
/* 600 */         if (type.isPrimitive()) {
/* 601 */           if (type == boolean.class) {
/* 602 */             reportConversionError(value, type);
/*     */           }
/* 604 */           return coerceToNumber(type, value);
/* 605 */         }  if (type.isInstance(value))
/* 606 */           return value; 
/* 607 */         if (type == ScriptRuntime.DateClass && value instanceof NativeDate) {
/* 608 */           double time = ((NativeDate)value).getJSTimeValue();
/*     */           
/* 610 */           return new Date((long)time);
/* 611 */         }  if (type.isArray() && value instanceof NativeArray) {
/*     */ 
/*     */           
/* 614 */           NativeArray array = (NativeArray)value;
/* 615 */           long length = array.getLength();
/* 616 */           Class<?> arrayType = type.getComponentType();
/* 617 */           Object Result = Array.newInstance(arrayType, (int)length);
/* 618 */           for (int i = 0; i < length; i++) {
/*     */             try {
/* 620 */               Array.set(Result, i, coerceTypeImpl(arrayType, array.get(i, array)));
/* 621 */             } catch (EvaluatorException ee) {
/* 622 */               reportConversionError(value, type);
/*     */             } 
/*     */           } 
/*     */           
/* 626 */           return Result;
/* 627 */         }  if (value instanceof Wrapper) {
/* 628 */           value = ((Wrapper)value).unwrap();
/* 629 */           if (type.isInstance(value)) return value; 
/* 630 */           reportConversionError(value, type); break;
/* 631 */         }  if (type.isInterface() && (value instanceof NativeObject || (value instanceof Callable && value instanceof ScriptableObject)))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 636 */           return createInterfaceAdapter(type, (ScriptableObject)value);
/*     */         }
/* 638 */         reportConversionError(value, type);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 643 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Object createInterfaceAdapter(Class<?> type, ScriptableObject so) {
/* 653 */     Object key = Kit.makeHashKeyFromPair(COERCED_INTERFACE_KEY, type);
/* 654 */     Object old = so.getAssociatedValue(key);
/* 655 */     if (old != null)
/*     */     {
/* 657 */       return old;
/*     */     }
/* 659 */     Context cx = Context.getContext();
/* 660 */     Object glue = InterfaceAdapter.create(cx, type, so);
/*     */     
/* 662 */     glue = so.associateValue(key, glue);
/* 663 */     return glue;
/*     */   }
/*     */   
/*     */   private static Object coerceToNumber(Class<?> type, Object value) {
/* 667 */     Class<?> valueClass = value.getClass();
/*     */ 
/*     */     
/* 670 */     if (type == char.class || type == ScriptRuntime.CharacterClass) {
/* 671 */       if (valueClass == ScriptRuntime.CharacterClass) {
/* 672 */         return value;
/*     */       }
/* 674 */       return Character.valueOf(
/*     */           
/* 676 */           (char)(int)toInteger(value, ScriptRuntime.CharacterClass, 0.0D, 65535.0D));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 684 */     if (type == ScriptRuntime.ObjectClass || type == ScriptRuntime.DoubleClass || type == double.class) {
/*     */ 
/*     */       
/* 687 */       if (valueClass == ScriptRuntime.DoubleClass) {
/* 688 */         return value;
/*     */       }
/* 690 */       return Double.valueOf(toDouble(value));
/*     */     } 
/*     */     
/* 693 */     if (type == ScriptRuntime.BigIntegerClass) {
/* 694 */       if (valueClass == ScriptRuntime.BigIntegerClass) {
/* 695 */         return value;
/*     */       }
/* 697 */       return ScriptRuntime.toBigInt(value);
/*     */     } 
/*     */     
/* 700 */     if (type == ScriptRuntime.FloatClass || type == float.class) {
/* 701 */       if (valueClass == ScriptRuntime.FloatClass) {
/* 702 */         return value;
/*     */       }
/* 704 */       double number = toDouble(value);
/* 705 */       if (Double.isInfinite(number) || Double.isNaN(number) || number == 0.0D) {
/* 706 */         return Float.valueOf((float)number);
/*     */       }
/*     */       
/* 709 */       double absNumber = Math.abs(number);
/* 710 */       if (absNumber < 1.401298464324817E-45D)
/* 711 */         return Float.valueOf((number > 0.0D) ? 0.0F : -0.0F); 
/* 712 */       if (absNumber > 3.4028234663852886E38D) {
/* 713 */         return Float.valueOf((number > 0.0D) ? Float.POSITIVE_INFINITY : Float.NEGATIVE_INFINITY);
/*     */       }
/*     */       
/* 716 */       return Float.valueOf((float)number);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 721 */     if (type == ScriptRuntime.IntegerClass || type == int.class) {
/* 722 */       if (valueClass == ScriptRuntime.IntegerClass) {
/* 723 */         return value;
/*     */       }
/* 725 */       return Integer.valueOf(
/*     */           
/* 727 */           (int)toInteger(value, ScriptRuntime.IntegerClass, -2.147483648E9D, 2.147483647E9D));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 734 */     if (type == ScriptRuntime.LongClass || type == long.class) {
/* 735 */       if (valueClass == ScriptRuntime.LongClass) {
/* 736 */         return value;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 745 */       double max = Double.longBitsToDouble(4890909195324358655L);
/* 746 */       double min = Double.longBitsToDouble(-4332462841530417152L);
/* 747 */       return Long.valueOf(toInteger(value, ScriptRuntime.LongClass, min, max));
/*     */     } 
/*     */     
/* 750 */     if (type == ScriptRuntime.ShortClass || type == short.class) {
/* 751 */       if (valueClass == ScriptRuntime.ShortClass) {
/* 752 */         return value;
/*     */       }
/* 754 */       return Short.valueOf(
/*     */           
/* 756 */           (short)(int)toInteger(value, ScriptRuntime.ShortClass, -32768.0D, 32767.0D));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 763 */     if (type == ScriptRuntime.ByteClass || type == byte.class) {
/* 764 */       if (valueClass == ScriptRuntime.ByteClass) {
/* 765 */         return value;
/*     */       }
/* 767 */       return Byte.valueOf(
/*     */           
/* 769 */           (byte)(int)toInteger(value, ScriptRuntime.ByteClass, -128.0D, 127.0D));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 776 */     return Double.valueOf(toDouble(value));
/*     */   }
/*     */   private static double toDouble(Object value) {
/*     */     Method meth;
/* 780 */     if (value instanceof Number)
/* 781 */       return ((Number)value).doubleValue(); 
/* 782 */     if (value instanceof String)
/* 783 */       return ScriptRuntime.toNumber((String)value); 
/* 784 */     if (value instanceof Scriptable) {
/* 785 */       if (value instanceof Wrapper)
/*     */       {
/* 787 */         return toDouble(((Wrapper)value).unwrap());
/*     */       }
/* 789 */       return ScriptRuntime.toNumber(value);
/*     */     } 
/*     */     
/*     */     try {
/* 793 */       meth = value.getClass().getMethod("doubleValue", (Class[])null);
/* 794 */     } catch (NoSuchMethodException e) {
/* 795 */       meth = null;
/* 796 */     } catch (SecurityException e) {
/* 797 */       meth = null;
/*     */     } 
/* 799 */     if (meth != null) {
/*     */       try {
/* 801 */         return ((Number)meth.invoke(value, (Object[])null)).doubleValue();
/* 802 */       } catch (IllegalAccessException e) {
/*     */         
/* 804 */         reportConversionError(value, double.class);
/* 805 */       } catch (InvocationTargetException e) {
/*     */         
/* 807 */         reportConversionError(value, double.class);
/*     */       } 
/*     */     }
/* 810 */     return ScriptRuntime.toNumber(value.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   private static long toInteger(Object value, Class<?> type, double min, double max) {
/* 815 */     double d = toDouble(value);
/*     */     
/* 817 */     if (Double.isInfinite(d) || Double.isNaN(d))
/*     */     {
/* 819 */       reportConversionError(ScriptRuntime.toString(value), type);
/*     */     }
/*     */     
/* 822 */     if (d > 0.0D) {
/* 823 */       d = Math.floor(d);
/*     */     } else {
/* 825 */       d = Math.ceil(d);
/*     */     } 
/*     */     
/* 828 */     if (d < min || d > max)
/*     */     {
/* 830 */       reportConversionError(ScriptRuntime.toString(value), type);
/*     */     }
/* 832 */     return (long)d;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void reportConversionError(Object value, Class<?> type) {
/* 838 */     throw Context.reportRuntimeErrorById("msg.conversion.not.allowed", new Object[] {
/*     */           
/* 840 */           String.valueOf(value), 
/* 841 */           JavaMembers.javaSignature(type) });
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 845 */     out.defaultWriteObject();
/*     */     
/* 847 */     out.writeBoolean(this.isAdapter);
/* 848 */     if (this.isAdapter) {
/* 849 */       if (adapter_writeAdapterObject == null) {
/* 850 */         throw new IOException();
/*     */       }
/* 852 */       Object[] args = { this.javaObject, out };
/*     */       try {
/* 854 */         adapter_writeAdapterObject.invoke(null, args);
/* 855 */       } catch (Exception ex) {
/* 856 */         throw new IOException();
/*     */       } 
/*     */     } else {
/* 859 */       out.writeObject(this.javaObject);
/*     */     } 
/*     */     
/* 862 */     if (this.staticType != null) {
/* 863 */       out.writeObject(this.staticType.getName());
/*     */     } else {
/* 865 */       out.writeObject(null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 870 */     in.defaultReadObject();
/*     */     
/* 872 */     this.isAdapter = in.readBoolean();
/* 873 */     if (this.isAdapter) {
/* 874 */       if (adapter_readAdapterObject == null) throw new ClassNotFoundException(); 
/* 875 */       Object[] args = { this, in };
/*     */       try {
/* 877 */         this.javaObject = adapter_readAdapterObject.invoke(null, args);
/* 878 */       } catch (Exception ex) {
/* 879 */         throw new IOException();
/*     */       } 
/*     */     } else {
/* 882 */       this.javaObject = in.readObject();
/*     */     } 
/*     */     
/* 885 */     String className = (String)in.readObject();
/* 886 */     if (className != null) {
/* 887 */       this.staticType = Class.forName(className);
/*     */     } else {
/* 889 */       this.staticType = null;
/*     */     } 
/*     */     
/* 892 */     initMembers();
/*     */   }
/*     */   static {
/* 895 */     symbol_iterator = ((cx, scope, thisObj, args) -> {
/*     */         if (!(thisObj instanceof NativeJavaObject))
/*     */           throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { SymbolKey.ITERATOR }); 
/*     */         Object javaObject = ((NativeJavaObject)thisObj).javaObject;
/*     */         if (!(javaObject instanceof Iterable))
/*     */           throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { SymbolKey.ITERATOR }); 
/*     */         return new JavaIterableIterator(scope, (Iterable)javaObject);
/*     */       });
/*     */   }
/*     */   
/*     */   private static final class JavaIterableIterator
/*     */     extends ES6Iterator {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private static final String ITERATOR_TAG = "JavaIterableIterator";
/*     */     private Iterator iterator;
/*     */     
/*     */     static void init(ScriptableObject scope, boolean sealed) {
/* 912 */       ES6Iterator.init(scope, sealed, new JavaIterableIterator(), "JavaIterableIterator");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private JavaIterableIterator() {}
/*     */ 
/*     */     
/*     */     JavaIterableIterator(Scriptable scope, Iterable iterable) {
/* 921 */       super(scope, "JavaIterableIterator");
/* 922 */       this.iterator = iterable.iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getClassName() {
/* 927 */       return "Java Iterable Iterator";
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isDone(Context cx, Scriptable scope) {
/* 932 */       return !this.iterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextValue(Context cx, Scriptable scope) {
/* 937 */       if (!this.iterator.hasNext()) {
/* 938 */         return Undefined.instance;
/*     */       }
/* 940 */       return this.iterator.next();
/*     */     }
/*     */ 
/*     */     
/*     */     protected String getTag() {
/* 945 */       return "JavaIterableIterator";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 964 */   private static final Object COERCED_INTERFACE_KEY = "Coerced Interface";
/*     */   
/*     */   private static Method adapter_writeAdapterObject;
/*     */   private static Method adapter_readAdapterObject;
/*     */   
/*     */   static {
/* 970 */     Class<?>[] sig2 = new Class[2];
/* 971 */     Class<?> cl = Kit.classOrNull("org.mozilla.javascript.JavaAdapter");
/* 972 */     if (cl != null)
/*     */       try {
/* 974 */         sig2[0] = ScriptRuntime.ObjectClass;
/* 975 */         sig2[1] = Kit.classOrNull("java.io.ObjectOutputStream");
/* 976 */         adapter_writeAdapterObject = cl.getMethod("writeAdapterObject", sig2);
/*     */         
/* 978 */         sig2[0] = ScriptRuntime.ScriptableClass;
/* 979 */         sig2[1] = Kit.classOrNull("java.io.ObjectInputStream");
/* 980 */         adapter_readAdapterObject = cl.getMethod("readAdapterObject", sig2);
/*     */       }
/* 982 */       catch (NoSuchMethodException e) {
/* 983 */         adapter_writeAdapterObject = null;
/* 984 */         adapter_readAdapterObject = null;
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeJavaObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */