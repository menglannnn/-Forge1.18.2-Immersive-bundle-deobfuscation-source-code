/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UintMap
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4242698212885848444L;
/*     */   private static final int A = -1640531527;
/*     */   private static final int EMPTY = -1;
/*     */   private static final int DELETED = -2;
/*     */   private transient int[] keys;
/*     */   private transient Object[] values;
/*     */   private int power;
/*     */   private int keyCount;
/*     */   private transient int occupiedCount;
/*     */   private transient int ivaluesShift;
/*     */   private static final boolean check = false;
/*     */   
/*     */   public UintMap() {
/*  29 */     this(4);
/*     */   }
/*     */   
/*     */   public UintMap(int initialCapacity) {
/*  33 */     if (initialCapacity < 0) Kit.codeBug();
/*     */     
/*  35 */     int minimalCapacity = initialCapacity * 4 / 3;
/*     */     int i;
/*  37 */     for (i = 2; 1 << i < minimalCapacity; i++);
/*  38 */     this.power = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  43 */     return (this.keyCount == 0);
/*     */   }
/*     */   
/*     */   public int size() {
/*  47 */     return this.keyCount;
/*     */   }
/*     */   
/*     */   public boolean has(int key) {
/*  51 */     if (key < 0) Kit.codeBug(); 
/*  52 */     return (0 <= findIndex(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject(int key) {
/*  61 */     if (key < 0) Kit.codeBug(); 
/*  62 */     if (this.values != null) {
/*  63 */       int index = findIndex(key);
/*  64 */       if (0 <= index) {
/*  65 */         return this.values[index];
/*     */       }
/*     */     } 
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt(int key, int defaultValue) {
/*  77 */     if (key < 0) Kit.codeBug(); 
/*  78 */     int index = findIndex(key);
/*  79 */     if (0 <= index) {
/*  80 */       if (this.ivaluesShift != 0) {
/*  81 */         return this.keys[this.ivaluesShift + index];
/*     */       }
/*  83 */       return 0;
/*     */     } 
/*  85 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExistingInt(int key) {
/*  95 */     if (key < 0) Kit.codeBug(); 
/*  96 */     int index = findIndex(key);
/*  97 */     if (0 <= index) {
/*  98 */       if (this.ivaluesShift != 0) {
/*  99 */         return this.keys[this.ivaluesShift + index];
/*     */       }
/* 101 */       return 0;
/*     */     } 
/*     */     
/* 104 */     Kit.codeBug();
/* 105 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int key, Object value) {
/* 110 */     if (key < 0) Kit.codeBug(); 
/* 111 */     int index = ensureIndex(key, false);
/* 112 */     if (this.values == null) {
/* 113 */       this.values = new Object[1 << this.power];
/*     */     }
/* 115 */     this.values[index] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int key, int value) {
/* 120 */     if (key < 0) Kit.codeBug(); 
/* 121 */     int index = ensureIndex(key, true);
/* 122 */     if (this.ivaluesShift == 0) {
/* 123 */       int N = 1 << this.power;
/*     */       
/* 125 */       if (this.keys.length != N * 2) {
/* 126 */         int[] tmp = new int[N * 2];
/* 127 */         System.arraycopy(this.keys, 0, tmp, 0, N);
/* 128 */         this.keys = tmp;
/*     */       } 
/* 130 */       this.ivaluesShift = N;
/*     */     } 
/* 132 */     this.keys[this.ivaluesShift + index] = value;
/*     */   }
/*     */   
/*     */   public void remove(int key) {
/* 136 */     if (key < 0) Kit.codeBug(); 
/* 137 */     int index = findIndex(key);
/* 138 */     if (0 <= index) {
/* 139 */       this.keys[index] = -2;
/* 140 */       this.keyCount--;
/*     */ 
/*     */       
/* 143 */       if (this.values != null) {
/* 144 */         this.values[index] = null;
/*     */       }
/* 146 */       if (this.ivaluesShift != 0) {
/* 147 */         this.keys[this.ivaluesShift + index] = 0;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/* 153 */     int N = 1 << this.power;
/* 154 */     if (this.keys != null) {
/* 155 */       int i; for (i = 0; i != N; i++) {
/* 156 */         this.keys[i] = -1;
/*     */       }
/* 158 */       if (this.values != null) {
/* 159 */         for (i = 0; i != N; i++) {
/* 160 */           this.values[i] = null;
/*     */         }
/*     */       }
/*     */     } 
/* 164 */     this.ivaluesShift = 0;
/* 165 */     this.keyCount = 0;
/* 166 */     this.occupiedCount = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getKeys() {
/* 171 */     int[] keys = this.keys;
/* 172 */     int n = this.keyCount;
/* 173 */     int[] result = new int[n];
/* 174 */     for (int i = 0; n != 0; i++) {
/* 175 */       int entry = keys[i];
/* 176 */       if (entry != -1 && entry != -2) {
/* 177 */         result[--n] = entry;
/*     */       }
/*     */     } 
/* 180 */     return result;
/*     */   }
/*     */   
/*     */   private static int tableLookupStep(int fraction, int mask, int power) {
/* 184 */     int shift = 32 - 2 * power;
/* 185 */     if (shift >= 0) {
/* 186 */       return fraction >>> shift & mask | 0x1;
/*     */     }
/* 188 */     return fraction & mask >>> -shift | 0x1;
/*     */   }
/*     */   
/*     */   private int findIndex(int key) {
/* 192 */     int[] keys = this.keys;
/* 193 */     if (keys != null) {
/* 194 */       int fraction = key * -1640531527;
/* 195 */       int index = fraction >>> 32 - this.power;
/* 196 */       int entry = keys[index];
/* 197 */       if (entry == key) {
/* 198 */         return index;
/*     */       }
/* 200 */       if (entry != -1) {
/*     */         
/* 202 */         int mask = (1 << this.power) - 1;
/* 203 */         int step = tableLookupStep(fraction, mask, this.power);
/* 204 */         int n = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         do {
/* 210 */           index = index + step & mask;
/* 211 */           entry = keys[index];
/* 212 */           if (entry == key) {
/* 213 */             return index;
/*     */           }
/* 215 */         } while (entry != -1);
/*     */       } 
/*     */     } 
/* 218 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int insertNewKey(int key) {
/* 226 */     int[] keys = this.keys;
/* 227 */     int fraction = key * -1640531527;
/* 228 */     int index = fraction >>> 32 - this.power;
/* 229 */     if (keys[index] != -1) {
/* 230 */       int mask = (1 << this.power) - 1;
/* 231 */       int step = tableLookupStep(fraction, mask, this.power);
/* 232 */       int firstIndex = index;
/*     */       
/*     */       do {
/* 235 */         index = index + step & mask;
/*     */       }
/* 237 */       while (keys[index] != -1);
/*     */     } 
/* 239 */     keys[index] = key;
/* 240 */     this.occupiedCount++;
/* 241 */     this.keyCount++;
/* 242 */     return index;
/*     */   }
/*     */   
/*     */   private void rehashTable(boolean ensureIntSpace) {
/* 246 */     if (this.keys != null)
/*     */     {
/* 248 */       if (this.keyCount * 2 >= this.occupiedCount)
/*     */       {
/* 250 */         this.power++;
/*     */       }
/*     */     }
/* 253 */     int N = 1 << this.power;
/* 254 */     int[] old = this.keys;
/* 255 */     int oldShift = this.ivaluesShift;
/* 256 */     if (oldShift == 0 && !ensureIntSpace) {
/* 257 */       this.keys = new int[N];
/*     */     } else {
/* 259 */       this.ivaluesShift = N;
/* 260 */       this.keys = new int[N * 2];
/*     */     } 
/* 262 */     for (int i = 0; i != N; i++) {
/* 263 */       this.keys[i] = -1;
/*     */     }
/*     */     
/* 266 */     Object[] oldValues = this.values;
/* 267 */     if (oldValues != null) {
/* 268 */       this.values = new Object[N];
/*     */     }
/*     */     
/* 271 */     int oldCount = this.keyCount;
/* 272 */     this.occupiedCount = 0;
/* 273 */     if (oldCount != 0) {
/* 274 */       this.keyCount = 0;
/* 275 */       for (int j = 0, remaining = oldCount; remaining != 0; j++) {
/* 276 */         int key = old[j];
/* 277 */         if (key != -1 && key != -2) {
/* 278 */           int index = insertNewKey(key);
/* 279 */           if (oldValues != null) {
/* 280 */             this.values[index] = oldValues[j];
/*     */           }
/* 282 */           if (oldShift != 0) {
/* 283 */             this.keys[this.ivaluesShift + index] = old[oldShift + j];
/*     */           }
/* 285 */           remaining--;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int ensureIndex(int key, boolean intType) {
/* 293 */     int index = -1;
/* 294 */     int firstDeleted = -1;
/* 295 */     int[] keys = this.keys;
/* 296 */     if (keys != null) {
/* 297 */       int fraction = key * -1640531527;
/* 298 */       index = fraction >>> 32 - this.power;
/* 299 */       int entry = keys[index];
/* 300 */       if (entry == key) {
/* 301 */         return index;
/*     */       }
/* 303 */       if (entry != -1) {
/* 304 */         if (entry == -2) {
/* 305 */           firstDeleted = index;
/*     */         }
/*     */         
/* 308 */         int mask = (1 << this.power) - 1;
/* 309 */         int step = tableLookupStep(fraction, mask, this.power);
/* 310 */         int n = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         do {
/* 316 */           index = index + step & mask;
/* 317 */           entry = keys[index];
/* 318 */           if (entry == key) {
/* 319 */             return index;
/*     */           }
/* 321 */           if (entry != -2 || firstDeleted >= 0)
/* 322 */             continue;  firstDeleted = index;
/*     */         }
/* 324 */         while (entry != -1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 329 */     if (firstDeleted >= 0) {
/* 330 */       index = firstDeleted;
/*     */     } else {
/*     */       
/* 333 */       if (keys == null || this.occupiedCount * 4 >= (1 << this.power) * 3) {
/*     */         
/* 335 */         rehashTable(intType);
/* 336 */         return insertNewKey(key);
/*     */       } 
/* 338 */       this.occupiedCount++;
/*     */     } 
/* 340 */     keys[index] = key;
/* 341 */     this.keyCount++;
/* 342 */     return index;
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 346 */     out.defaultWriteObject();
/*     */     
/* 348 */     int count = this.keyCount;
/* 349 */     if (count != 0) {
/* 350 */       boolean hasIntValues = (this.ivaluesShift != 0);
/* 351 */       boolean hasObjectValues = (this.values != null);
/* 352 */       out.writeBoolean(hasIntValues);
/* 353 */       out.writeBoolean(hasObjectValues);
/*     */       
/* 355 */       for (int i = 0; count != 0; i++) {
/* 356 */         int key = this.keys[i];
/* 357 */         if (key != -1 && key != -2) {
/* 358 */           count--;
/* 359 */           out.writeInt(key);
/* 360 */           if (hasIntValues) {
/* 361 */             out.writeInt(this.keys[this.ivaluesShift + i]);
/*     */           }
/* 363 */           if (hasObjectValues) {
/* 364 */             out.writeObject(this.values[i]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 372 */     in.defaultReadObject();
/*     */     
/* 374 */     int writtenKeyCount = this.keyCount;
/* 375 */     if (writtenKeyCount != 0) {
/* 376 */       this.keyCount = 0;
/* 377 */       boolean hasIntValues = in.readBoolean();
/* 378 */       boolean hasObjectValues = in.readBoolean();
/*     */       
/* 380 */       int N = 1 << this.power;
/* 381 */       if (hasIntValues) {
/* 382 */         this.keys = new int[2 * N];
/* 383 */         this.ivaluesShift = N;
/*     */       } else {
/* 385 */         this.keys = new int[N];
/*     */       }  int i;
/* 387 */       for (i = 0; i != N; i++) {
/* 388 */         this.keys[i] = -1;
/*     */       }
/* 390 */       if (hasObjectValues) {
/* 391 */         this.values = new Object[N];
/*     */       }
/* 393 */       for (i = 0; i != writtenKeyCount; i++) {
/* 394 */         int key = in.readInt();
/* 395 */         int index = insertNewKey(key);
/* 396 */         if (hasIntValues) {
/* 397 */           int ivalue = in.readInt();
/* 398 */           this.keys[this.ivaluesShift + index] = ivalue;
/*     */         } 
/* 400 */         if (hasObjectValues)
/* 401 */           this.values[index] = in.readObject(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\UintMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */