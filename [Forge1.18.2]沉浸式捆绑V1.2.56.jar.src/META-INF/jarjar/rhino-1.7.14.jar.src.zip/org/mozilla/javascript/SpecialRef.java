/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpecialRef
/*     */   extends Ref
/*     */ {
/*     */   private static final long serialVersionUID = -7521596632456797847L;
/*     */   private static final int SPECIAL_NONE = 0;
/*     */   private static final int SPECIAL_PROTO = 1;
/*     */   private static final int SPECIAL_PARENT = 2;
/*     */   private Scriptable target;
/*     */   private int type;
/*     */   private String name;
/*     */   
/*     */   private SpecialRef(Scriptable target, int type, String name) {
/*  21 */     this.target = target;
/*  22 */     this.type = type;
/*  23 */     this.name = name;
/*     */   }
/*     */   static Ref createSpecial(Context cx, Scriptable scope, Object object, String name) {
/*     */     int type;
/*  27 */     Scriptable target = ScriptRuntime.toObjectOrNull(cx, object, scope);
/*  28 */     if (target == null) {
/*  29 */       throw ScriptRuntime.undefReadError(object, name);
/*     */     }
/*     */ 
/*     */     
/*  33 */     if (name.equals("__proto__")) {
/*  34 */       type = 1;
/*  35 */     } else if (name.equals("__parent__")) {
/*  36 */       type = 2;
/*     */     } else {
/*  38 */       throw new IllegalArgumentException(name);
/*     */     } 
/*     */     
/*  41 */     if (!cx.hasFeature(5))
/*     */     {
/*  43 */       type = 0;
/*     */     }
/*     */     
/*  46 */     return new SpecialRef(target, type, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Context cx) {
/*  51 */     switch (this.type) {
/*     */       case 0:
/*  53 */         return ScriptRuntime.getObjectProp(this.target, this.name, cx);
/*     */       case 1:
/*  55 */         return this.target.getPrototype();
/*     */       case 2:
/*  57 */         return this.target.getParentScope();
/*     */     } 
/*  59 */     throw Kit.codeBug();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object set(Context cx, Object value) {
/*  66 */     throw new IllegalStateException();
/*     */   }
/*     */   
/*     */   public Object set(Context cx, Scriptable scope, Object value) {
/*     */     Scriptable obj;
/*  71 */     switch (this.type) {
/*     */       case 0:
/*  73 */         return ScriptRuntime.setObjectProp(this.target, this.name, value, cx);
/*     */       
/*     */       case 1:
/*     */       case 2:
/*  77 */         obj = ScriptRuntime.toObjectOrNull(cx, value, scope);
/*  78 */         if (obj != null) {
/*     */ 
/*     */           
/*  81 */           Scriptable search = obj;
/*     */           do {
/*  83 */             if (search == this.target) {
/*  84 */               throw Context.reportRuntimeErrorById("msg.cyclic.value", new Object[] { this.name });
/*     */             }
/*  86 */             if (this.type == 1) {
/*  87 */               search = search.getPrototype();
/*     */             } else {
/*  89 */               search = search.getParentScope();
/*     */             } 
/*  91 */           } while (search != null);
/*     */         } 
/*  93 */         if (this.type == 1) {
/*  94 */           if (this.target instanceof ScriptableObject && 
/*  95 */             !((ScriptableObject)this.target).isExtensible() && cx
/*  96 */             .getLanguageVersion() >= 180) {
/*  97 */             throw ScriptRuntime.typeErrorById("msg.not.extensible", new Object[0]);
/*     */           }
/*     */           
/* 100 */           if (cx.getLanguageVersion() >= 200) {
/* 101 */             String typeOfTarget = ScriptRuntime.typeof(this.target);
/* 102 */             if ("function".equals(typeOfTarget)) {
/* 103 */               if (value == null) {
/* 104 */                 this.target.setPrototype(Undefined.SCRIPTABLE_UNDEFINED);
/* 105 */                 return value;
/*     */               } 
/*     */               
/* 108 */               String str = ScriptRuntime.typeof(value);
/* 109 */               if ("object".equals(str) || "function"
/* 110 */                 .equals(str)) {
/* 111 */                 this.target.setPrototype(obj);
/*     */               }
/* 113 */               return value;
/*     */             } 
/*     */             
/* 116 */             String typeOfValue = ScriptRuntime.typeof(value);
/* 117 */             if ((value != null && !"object".equals(typeOfValue)) || 
/* 118 */               !"object".equals(typeOfTarget)) {
/* 119 */               return Undefined.instance;
/*     */             }
/* 121 */             this.target.setPrototype(obj);
/*     */           } else {
/* 123 */             this.target.setPrototype(obj);
/*     */           } 
/*     */         } else {
/* 126 */           this.target.setParentScope(obj);
/*     */         } 
/* 128 */         return obj;
/*     */     } 
/*     */     
/* 131 */     throw Kit.codeBug();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(Context cx) {
/* 137 */     if (this.type == 0) {
/* 138 */       return ScriptRuntime.hasObjectElem(this.target, this.name, cx);
/*     */     }
/* 140 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean delete(Context cx) {
/* 145 */     if (this.type == 0) {
/* 146 */       return ScriptRuntime.deleteObjectElem(this.target, this.name, cx);
/*     */     }
/* 148 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\SpecialRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */