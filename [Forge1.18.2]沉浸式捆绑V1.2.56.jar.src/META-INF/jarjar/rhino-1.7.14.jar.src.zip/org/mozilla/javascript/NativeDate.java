/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class NativeDate
/*      */   extends IdScriptableObject
/*      */ {
/*      */   private static final long serialVersionUID = -8307438915861678966L;
/*   24 */   private static final Object DATE_TAG = "Date"; private static final String js_NaN_date_str = "Invalid Date"; private static final double HalfTimeDomain = 8.64E15D; private static final double HoursPerDay = 24.0D; private static final double MinutesPerHour = 60.0D; private static final double SecondsPerMinute = 60.0D; private static final double msPerSecond = 1000.0D; private static final double MinutesPerDay = 1440.0D; private static final double SecondsPerDay = 86400.0D; private static final double SecondsPerHour = 3600.0D; private static final double msPerDay = 8.64E7D; private static final double msPerHour = 3600000.0D; private static final double msPerMinute = 60000.0D; private static final int MAXARGS = 7; private static final int ConstructorId_now = -3; private static final int ConstructorId_parse = -2; private static final int ConstructorId_UTC = -1; private static final int Id_constructor = 1; private static final int Id_toString = 2; private static final int Id_toTimeString = 3; private static final int Id_toDateString = 4; private static final int Id_toLocaleString = 5; private static final int Id_toLocaleTimeString = 6; private static final int Id_toLocaleDateString = 7; private static final int Id_toUTCString = 8; private static final int Id_toSource = 9; private static final int Id_valueOf = 10; private static final int Id_getTime = 11; private static final int Id_getYear = 12; private static final int Id_getFullYear = 13; private static final int Id_getUTCFullYear = 14;
/*      */   private static final int Id_getMonth = 15;
/*      */   private static final int Id_getUTCMonth = 16;
/*      */   
/*      */   static void init(Scriptable scope, boolean sealed) {
/*   29 */     NativeDate obj = new NativeDate();
/*      */     
/*   31 */     obj.date = Double.NaN;
/*   32 */     obj.exportAsJSClass(47, scope, sealed);
/*      */   }
/*      */   private static final int Id_getDate = 17; private static final int Id_getUTCDate = 18; private static final int Id_getDay = 19; private static final int Id_getUTCDay = 20; private static final int Id_getHours = 21; private static final int Id_getUTCHours = 22; private static final int Id_getMinutes = 23; private static final int Id_getUTCMinutes = 24; private static final int Id_getSeconds = 25; private static final int Id_getUTCSeconds = 26; private static final int Id_getMilliseconds = 27; private static final int Id_getUTCMilliseconds = 28; private static final int Id_getTimezoneOffset = 29; private static final int Id_setTime = 30;
/*      */   private static final int Id_setMilliseconds = 31;
/*      */   private static final int Id_setUTCMilliseconds = 32;
/*      */   
/*      */   public String getClassName() {
/*   39 */     return "Date";
/*      */   }
/*      */   private static final int Id_setSeconds = 33; private static final int Id_setUTCSeconds = 34; private static final int Id_setMinutes = 35; private static final int Id_setUTCMinutes = 36; private static final int Id_setHours = 37; private static final int Id_setUTCHours = 38; private static final int Id_setDate = 39; private static final int Id_setUTCDate = 40; private static final int Id_setMonth = 41; private static final int Id_setUTCMonth = 42; private static final int Id_setFullYear = 43; private static final int Id_setUTCFullYear = 44; private static final int Id_setYear = 45; private static final int Id_toISOString = 46; private static final int Id_toJSON = 47; private static final int MAX_PROTOTYPE_ID = 47; private static final int Id_toGMTString = 8;
/*      */   
/*      */   public Object getDefaultValue(Class<?> typeHint) {
/*   44 */     if (typeHint == null) typeHint = ScriptRuntime.StringClass; 
/*   45 */     return super.getDefaultValue(typeHint);
/*      */   }
/*      */   
/*      */   double getJSTimeValue() {
/*   49 */     return this.date;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/*   54 */     addIdFunctionProperty(ctor, DATE_TAG, -3, "now", 0);
/*   55 */     addIdFunctionProperty(ctor, DATE_TAG, -2, "parse", 1);
/*   56 */     addIdFunctionProperty(ctor, DATE_TAG, -1, "UTC", 7);
/*   57 */     super.fillConstructorProperties(ctor);
/*      */   }
/*      */   
/*      */   protected void initPrototypeId(int id)
/*      */   {
/*      */     String s;
/*      */     int arity;
/*   64 */     switch (id) {
/*      */       case 1:
/*   66 */         arity = 7;
/*   67 */         s = "constructor";
/*      */         break;
/*      */       case 2:
/*   70 */         arity = 0;
/*   71 */         s = "toString";
/*      */         break;
/*      */       case 3:
/*   74 */         arity = 0;
/*   75 */         s = "toTimeString";
/*      */         break;
/*      */       case 4:
/*   78 */         arity = 0;
/*   79 */         s = "toDateString";
/*      */         break;
/*      */       case 5:
/*   82 */         arity = 0;
/*   83 */         s = "toLocaleString";
/*      */         break;
/*      */       case 6:
/*   86 */         arity = 0;
/*   87 */         s = "toLocaleTimeString";
/*      */         break;
/*      */       case 7:
/*   90 */         arity = 0;
/*   91 */         s = "toLocaleDateString";
/*      */         break;
/*      */       case 8:
/*   94 */         arity = 0;
/*   95 */         s = "toUTCString";
/*      */         break;
/*      */       case 9:
/*   98 */         arity = 0;
/*   99 */         s = "toSource";
/*      */         break;
/*      */       case 10:
/*  102 */         arity = 0;
/*  103 */         s = "valueOf";
/*      */         break;
/*      */       case 11:
/*  106 */         arity = 0;
/*  107 */         s = "getTime";
/*      */         break;
/*      */       case 12:
/*  110 */         arity = 0;
/*  111 */         s = "getYear";
/*      */         break;
/*      */       case 13:
/*  114 */         arity = 0;
/*  115 */         s = "getFullYear";
/*      */         break;
/*      */       case 14:
/*  118 */         arity = 0;
/*  119 */         s = "getUTCFullYear";
/*      */         break;
/*      */       case 15:
/*  122 */         arity = 0;
/*  123 */         s = "getMonth";
/*      */         break;
/*      */       case 16:
/*  126 */         arity = 0;
/*  127 */         s = "getUTCMonth";
/*      */         break;
/*      */       case 17:
/*  130 */         arity = 0;
/*  131 */         s = "getDate";
/*      */         break;
/*      */       case 18:
/*  134 */         arity = 0;
/*  135 */         s = "getUTCDate";
/*      */         break;
/*      */       case 19:
/*  138 */         arity = 0;
/*  139 */         s = "getDay";
/*      */         break;
/*      */       case 20:
/*  142 */         arity = 0;
/*  143 */         s = "getUTCDay";
/*      */         break;
/*      */       case 21:
/*  146 */         arity = 0;
/*  147 */         s = "getHours";
/*      */         break;
/*      */       case 22:
/*  150 */         arity = 0;
/*  151 */         s = "getUTCHours";
/*      */         break;
/*      */       case 23:
/*  154 */         arity = 0;
/*  155 */         s = "getMinutes";
/*      */         break;
/*      */       case 24:
/*  158 */         arity = 0;
/*  159 */         s = "getUTCMinutes";
/*      */         break;
/*      */       case 25:
/*  162 */         arity = 0;
/*  163 */         s = "getSeconds";
/*      */         break;
/*      */       case 26:
/*  166 */         arity = 0;
/*  167 */         s = "getUTCSeconds";
/*      */         break;
/*      */       case 27:
/*  170 */         arity = 0;
/*  171 */         s = "getMilliseconds";
/*      */         break;
/*      */       case 28:
/*  174 */         arity = 0;
/*  175 */         s = "getUTCMilliseconds";
/*      */         break;
/*      */       case 29:
/*  178 */         arity = 0;
/*  179 */         s = "getTimezoneOffset";
/*      */         break;
/*      */       case 30:
/*  182 */         arity = 1;
/*  183 */         s = "setTime";
/*      */         break;
/*      */       case 31:
/*  186 */         arity = 1;
/*  187 */         s = "setMilliseconds";
/*      */         break;
/*      */       case 32:
/*  190 */         arity = 1;
/*  191 */         s = "setUTCMilliseconds";
/*      */         break;
/*      */       case 33:
/*  194 */         arity = 2;
/*  195 */         s = "setSeconds";
/*      */         break;
/*      */       case 34:
/*  198 */         arity = 2;
/*  199 */         s = "setUTCSeconds";
/*      */         break;
/*      */       case 35:
/*  202 */         arity = 3;
/*  203 */         s = "setMinutes";
/*      */         break;
/*      */       case 36:
/*  206 */         arity = 3;
/*  207 */         s = "setUTCMinutes";
/*      */         break;
/*      */       case 37:
/*  210 */         arity = 4;
/*  211 */         s = "setHours";
/*      */         break;
/*      */       case 38:
/*  214 */         arity = 4;
/*  215 */         s = "setUTCHours";
/*      */         break;
/*      */       case 39:
/*  218 */         arity = 1;
/*  219 */         s = "setDate";
/*      */         break;
/*      */       case 40:
/*  222 */         arity = 1;
/*  223 */         s = "setUTCDate";
/*      */         break;
/*      */       case 41:
/*  226 */         arity = 2;
/*  227 */         s = "setMonth";
/*      */         break;
/*      */       case 42:
/*  230 */         arity = 2;
/*  231 */         s = "setUTCMonth";
/*      */         break;
/*      */       case 43:
/*  234 */         arity = 3;
/*  235 */         s = "setFullYear";
/*      */         break;
/*      */       case 44:
/*  238 */         arity = 3;
/*  239 */         s = "setUTCFullYear";
/*      */         break;
/*      */       case 45:
/*  242 */         arity = 1;
/*  243 */         s = "setYear";
/*      */         break;
/*      */       case 46:
/*  246 */         arity = 0;
/*  247 */         s = "toISOString";
/*      */         break;
/*      */       case 47:
/*  250 */         arity = 1;
/*  251 */         s = "toJSON";
/*      */         break;
/*      */       default:
/*  254 */         throw new IllegalArgumentException(String.valueOf(id));
/*      */     } 
/*  256 */     initPrototypeMethod(DATE_TAG, id, s, arity); } public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) { String dataStr, toISOString;
/*      */     Scriptable o;
/*      */     Object tv, toISO;
/*      */     double year;
/*      */     String msg;
/*      */     Object result;
/*  262 */     if (!f.hasTag(DATE_TAG)) {
/*  263 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*      */     }
/*  265 */     int id = f.methodId();
/*  266 */     switch (id) {
/*      */       case -3:
/*  268 */         return ScriptRuntime.wrapNumber(now());
/*      */ 
/*      */       
/*      */       case -2:
/*  272 */         dataStr = ScriptRuntime.toString(args, 0);
/*  273 */         return ScriptRuntime.wrapNumber(date_parseString(dataStr));
/*      */ 
/*      */       
/*      */       case -1:
/*  277 */         return ScriptRuntime.wrapNumber(jsStaticFunction_UTC(args));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  283 */         if (thisObj != null) return date_format(now(), 2); 
/*  284 */         return jsConstructor(args);
/*      */ 
/*      */ 
/*      */       
/*      */       case 47:
/*  289 */         toISOString = "toISOString";
/*      */         
/*  291 */         o = ScriptRuntime.toObject(cx, scope, thisObj);
/*  292 */         tv = ScriptRuntime.toPrimitive(o, ScriptRuntime.NumberClass);
/*  293 */         if (tv instanceof Number) {
/*  294 */           double d = ((Number)tv).doubleValue();
/*  295 */           if (Double.isNaN(d) || Double.isInfinite(d)) {
/*  296 */             return null;
/*      */           }
/*      */         } 
/*  299 */         toISO = ScriptableObject.getProperty(o, "toISOString");
/*  300 */         if (toISO == NOT_FOUND) {
/*  301 */           throw ScriptRuntime.typeErrorById("msg.function.not.found.in", new Object[] { "toISOString", 
/*      */ 
/*      */                 
/*  304 */                 ScriptRuntime.toString(o) });
/*      */         }
/*  306 */         if (!(toISO instanceof Callable)) {
/*  307 */           throw ScriptRuntime.typeErrorById("msg.isnt.function.in", new Object[] { "toISOString", 
/*      */ 
/*      */                 
/*  310 */                 ScriptRuntime.toString(o), 
/*  311 */                 ScriptRuntime.toString(toISO) });
/*      */         }
/*  313 */         result = ((Callable)toISO).call(cx, scope, o, ScriptRuntime.emptyArgs);
/*  314 */         if (!ScriptRuntime.isPrimitive(result))
/*  315 */           throw ScriptRuntime.typeErrorById("msg.toisostring.must.return.primitive", new Object[] {
/*      */                 
/*  317 */                 ScriptRuntime.toString(result)
/*      */               }); 
/*  319 */         return result;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  324 */     NativeDate realThis = ensureType(thisObj, NativeDate.class, f);
/*  325 */     double t = realThis.date;
/*      */     
/*  327 */     switch (id) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*  331 */         if (!Double.isNaN(t)) {
/*  332 */           return date_format(t, id);
/*      */         }
/*  334 */         return "Invalid Date";
/*      */       
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*  339 */         if (!Double.isNaN(t)) {
/*  340 */           return toLocale_helper(t, id);
/*      */         }
/*  342 */         return "Invalid Date";
/*      */       
/*      */       case 8:
/*  345 */         if (!Double.isNaN(t)) {
/*  346 */           return js_toUTCString(t);
/*      */         }
/*  348 */         return "Invalid Date";
/*      */       
/*      */       case 9:
/*  351 */         return "(new Date(" + ScriptRuntime.toString(t) + "))";
/*      */       
/*      */       case 10:
/*      */       case 11:
/*  355 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*  360 */         if (!Double.isNaN(t)) {
/*  361 */           if (id != 14) t = LocalTime(t); 
/*  362 */           t = YearFromTime(t);
/*  363 */           if (id == 12) {
/*  364 */             if (cx.hasFeature(1)) {
/*  365 */               if (1900.0D <= t && t < 2000.0D) {
/*  366 */                 t -= 1900.0D;
/*      */               }
/*      */             } else {
/*  369 */               t -= 1900.0D;
/*      */             } 
/*      */           }
/*      */         } 
/*  373 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 15:
/*      */       case 16:
/*  377 */         if (!Double.isNaN(t)) {
/*  378 */           if (id == 15) t = LocalTime(t); 
/*  379 */           t = MonthFromTime(t);
/*      */         } 
/*  381 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 17:
/*      */       case 18:
/*  385 */         if (!Double.isNaN(t)) {
/*  386 */           if (id == 17) t = LocalTime(t); 
/*  387 */           t = DateFromTime(t);
/*      */         } 
/*  389 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 19:
/*      */       case 20:
/*  393 */         if (!Double.isNaN(t)) {
/*  394 */           if (id == 19) t = LocalTime(t); 
/*  395 */           t = WeekDay(t);
/*      */         } 
/*  397 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 21:
/*      */       case 22:
/*  401 */         if (!Double.isNaN(t)) {
/*  402 */           if (id == 21) t = LocalTime(t); 
/*  403 */           t = HourFromTime(t);
/*      */         } 
/*  405 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 23:
/*      */       case 24:
/*  409 */         if (!Double.isNaN(t)) {
/*  410 */           if (id == 23) t = LocalTime(t); 
/*  411 */           t = MinFromTime(t);
/*      */         } 
/*  413 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 25:
/*      */       case 26:
/*  417 */         if (!Double.isNaN(t)) {
/*  418 */           if (id == 25) t = LocalTime(t); 
/*  419 */           t = SecFromTime(t);
/*      */         } 
/*  421 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 27:
/*      */       case 28:
/*  425 */         if (!Double.isNaN(t)) {
/*  426 */           if (id == 27) t = LocalTime(t); 
/*  427 */           t = msFromTime(t);
/*      */         } 
/*  429 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 29:
/*  432 */         if (!Double.isNaN(t)) {
/*  433 */           t = (t - LocalTime(t)) / 60000.0D;
/*      */         }
/*  435 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 30:
/*  438 */         t = TimeClip(ScriptRuntime.toNumber(args, 0));
/*  439 */         realThis.date = t;
/*  440 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 31:
/*      */       case 32:
/*      */       case 33:
/*      */       case 34:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*  450 */         t = makeTime(t, args, id);
/*  451 */         realThis.date = t;
/*  452 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*  460 */         t = makeDate(t, args, id);
/*  461 */         realThis.date = t;
/*  462 */         return ScriptRuntime.wrapNumber(t);
/*      */ 
/*      */       
/*      */       case 45:
/*  466 */         year = ScriptRuntime.toNumber(args, 0);
/*      */         
/*  468 */         if (Double.isNaN(year) || Double.isInfinite(year)) {
/*  469 */           t = Double.NaN;
/*      */         } else {
/*  471 */           if (Double.isNaN(t)) {
/*  472 */             t = 0.0D;
/*      */           } else {
/*  474 */             t = LocalTime(t);
/*      */           } 
/*      */           
/*  477 */           if (year >= 0.0D && year <= 99.0D) year += 1900.0D;
/*      */           
/*  479 */           double day = MakeDay(year, MonthFromTime(t), DateFromTime(t));
/*  480 */           t = MakeDate(day, TimeWithinDay(t));
/*  481 */           t = internalUTC(t);
/*  482 */           t = TimeClip(t);
/*      */         } 
/*      */         
/*  485 */         realThis.date = t;
/*  486 */         return ScriptRuntime.wrapNumber(t);
/*      */       
/*      */       case 46:
/*  489 */         if (!Double.isNaN(t)) {
/*  490 */           return js_toISOString(t);
/*      */         }
/*  492 */         msg = ScriptRuntime.getMessageById("msg.invalid.date", new Object[0]);
/*  493 */         throw ScriptRuntime.rangeError(msg);
/*      */     } 
/*      */     
/*  496 */     throw new IllegalArgumentException(String.valueOf(id)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double Day(double t) {
/*  515 */     return Math.floor(t / 8.64E7D);
/*      */   }
/*      */ 
/*      */   
/*      */   private static double TimeWithinDay(double t) {
/*  520 */     double result = t % 8.64E7D;
/*  521 */     if (result < 0.0D) result += 8.64E7D; 
/*  522 */     return result;
/*      */   }
/*      */   
/*      */   private static boolean IsLeapYear(int year) {
/*  526 */     return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double DayFromYear(double y) {
/*  533 */     return 365.0D * (y - 1970.0D) + 
/*  534 */       Math.floor((y - 1969.0D) / 4.0D) - 
/*  535 */       Math.floor((y - 1901.0D) / 100.0D) + 
/*  536 */       Math.floor((y - 1601.0D) / 400.0D);
/*      */   }
/*      */   
/*      */   private static double TimeFromYear(double y) {
/*  540 */     return DayFromYear(y) * 8.64E7D;
/*      */   }
/*      */   
/*      */   private static int YearFromTime(double t) {
/*  544 */     if (Double.isInfinite(t) || Double.isNaN(t)) {
/*  545 */       return 0;
/*      */     }
/*      */     
/*  548 */     double y = Math.floor(t / 3.1556952E10D) + 1970.0D;
/*  549 */     double t2 = TimeFromYear(y);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  556 */     if (t2 > t)
/*  557 */     { y--; }
/*      */     
/*  559 */     else if (t2 + 8.64E7D * DaysInYear(y) <= t) { y++; }
/*      */     
/*  561 */     return (int)y;
/*      */   }
/*      */   
/*      */   private static double DayFromMonth(int m, int year) {
/*  565 */     int day = m * 30;
/*      */     
/*  567 */     if (m >= 7) {
/*  568 */       day += m / 2 - 1;
/*  569 */     } else if (m >= 2) {
/*  570 */       day += (m - 1) / 2 - 1;
/*      */     } else {
/*  572 */       day += m;
/*      */     } 
/*      */     
/*  575 */     if (m >= 2 && IsLeapYear(year)) {
/*  576 */       day++;
/*      */     }
/*      */     
/*  579 */     return day;
/*      */   }
/*      */   
/*      */   private static double DaysInYear(double year) {
/*  583 */     if (Double.isInfinite(year) || Double.isNaN(year)) {
/*  584 */       return Double.NaN;
/*      */     }
/*  586 */     return IsLeapYear((int)year) ? 366.0D : 365.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int DaysInMonth(int year, int month) {
/*  591 */     if (month == 2) return IsLeapYear(year) ? 29 : 28; 
/*  592 */     return (month >= 8) ? (31 - (month & 0x1)) : (30 + (month & 0x1));
/*      */   }
/*      */   
/*      */   private static int MonthFromTime(double t) {
/*  596 */     int mstart, year = YearFromTime(t);
/*  597 */     int d = (int)(Day(t) - DayFromYear(year));
/*      */     
/*  599 */     d -= 59;
/*  600 */     if (d < 0) {
/*  601 */       return (d < -28) ? 0 : 1;
/*      */     }
/*      */     
/*  604 */     if (IsLeapYear(year)) {
/*  605 */       if (d == 0) return 1; 
/*  606 */       d--;
/*      */     } 
/*      */ 
/*      */     
/*  610 */     int estimate = d / 30;
/*      */     
/*  612 */     switch (estimate) {
/*      */       case 0:
/*  614 */         return 2;
/*      */       case 1:
/*  616 */         mstart = 31;
/*      */         break;
/*      */       case 2:
/*  619 */         mstart = 61;
/*      */         break;
/*      */       case 3:
/*  622 */         mstart = 92;
/*      */         break;
/*      */       case 4:
/*  625 */         mstart = 122;
/*      */         break;
/*      */       case 5:
/*  628 */         mstart = 153;
/*      */         break;
/*      */       case 6:
/*  631 */         mstart = 184;
/*      */         break;
/*      */       case 7:
/*  634 */         mstart = 214;
/*      */         break;
/*      */       case 8:
/*  637 */         mstart = 245;
/*      */         break;
/*      */       case 9:
/*  640 */         mstart = 275;
/*      */         break;
/*      */       case 10:
/*  643 */         return 11;
/*      */       default:
/*  645 */         throw Kit.codeBug();
/*      */     } 
/*      */     
/*  648 */     return (d >= mstart) ? (estimate + 2) : (estimate + 1);
/*      */   }
/*      */   
/*      */   private static int DateFromTime(double t) {
/*  652 */     int mdays, mstart, year = YearFromTime(t);
/*  653 */     int d = (int)(Day(t) - DayFromYear(year));
/*      */     
/*  655 */     d -= 59;
/*  656 */     if (d < 0) {
/*  657 */       return (d < -28) ? (d + 31 + 28 + 1) : (d + 28 + 1);
/*      */     }
/*      */     
/*  660 */     if (IsLeapYear(year)) {
/*  661 */       if (d == 0) return 29; 
/*  662 */       d--;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  667 */     switch (d / 30) {
/*      */       case 0:
/*  669 */         return d + 1;
/*      */       case 1:
/*  671 */         mdays = 31;
/*  672 */         mstart = 31;
/*      */         break;
/*      */       case 2:
/*  675 */         mdays = 30;
/*  676 */         mstart = 61;
/*      */         break;
/*      */       case 3:
/*  679 */         mdays = 31;
/*  680 */         mstart = 92;
/*      */         break;
/*      */       case 4:
/*  683 */         mdays = 30;
/*  684 */         mstart = 122;
/*      */         break;
/*      */       case 5:
/*  687 */         mdays = 31;
/*  688 */         mstart = 153;
/*      */         break;
/*      */       case 6:
/*  691 */         mdays = 31;
/*  692 */         mstart = 184;
/*      */         break;
/*      */       case 7:
/*  695 */         mdays = 30;
/*  696 */         mstart = 214;
/*      */         break;
/*      */       case 8:
/*  699 */         mdays = 31;
/*  700 */         mstart = 245;
/*      */         break;
/*      */       case 9:
/*  703 */         mdays = 30;
/*  704 */         mstart = 275;
/*      */         break;
/*      */       case 10:
/*  707 */         return d - 275 + 1;
/*      */       default:
/*  709 */         throw Kit.codeBug();
/*      */     } 
/*  711 */     d -= mstart;
/*  712 */     if (d < 0)
/*      */     {
/*  714 */       d += mdays;
/*      */     }
/*  716 */     return d + 1;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int WeekDay(double t) {
/*  721 */     double result = Day(t) + 4.0D;
/*  722 */     result %= 7.0D;
/*  723 */     if (result < 0.0D) result += 7.0D; 
/*  724 */     return (int)result;
/*      */   }
/*      */   
/*      */   private static double now() {
/*  728 */     return System.currentTimeMillis();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double DaylightSavingTA(double t) {
/*  736 */     if (t < 0.0D) {
/*  737 */       int year = EquivalentYear(YearFromTime(t));
/*  738 */       double day = MakeDay(year, MonthFromTime(t), DateFromTime(t));
/*  739 */       t = MakeDate(day, TimeWithinDay(t));
/*      */     } 
/*  741 */     Date date = new Date((long)t);
/*  742 */     if (thisTimeZone.inDaylightTime(date)) return 3600000.0D; 
/*  743 */     return 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int EquivalentYear(int year) {
/*  754 */     int day = (int)DayFromYear(year) + 4;
/*  755 */     day %= 7;
/*  756 */     if (day < 0) day += 7;
/*      */     
/*  758 */     if (IsLeapYear(year)) {
/*  759 */       switch (day) {
/*      */         case 0:
/*  761 */           return 1984;
/*      */         case 1:
/*  763 */           return 1996;
/*      */         case 2:
/*  765 */           return 1980;
/*      */         case 3:
/*  767 */           return 1992;
/*      */         case 4:
/*  769 */           return 1976;
/*      */         case 5:
/*  771 */           return 1988;
/*      */         case 6:
/*  773 */           return 1972;
/*      */       } 
/*      */     } else {
/*  776 */       switch (day) {
/*      */         case 0:
/*  778 */           return 1978;
/*      */         case 1:
/*  780 */           return 1973;
/*      */         case 2:
/*  782 */           return 1985;
/*      */         case 3:
/*  784 */           return 1986;
/*      */         case 4:
/*  786 */           return 1981;
/*      */         case 5:
/*  788 */           return 1971;
/*      */         case 6:
/*  790 */           return 1977;
/*      */       } 
/*      */     
/*      */     } 
/*  794 */     throw Kit.codeBug();
/*      */   }
/*      */   
/*      */   private static double LocalTime(double t) {
/*  798 */     return t + LocalTZA + DaylightSavingTA(t);
/*      */   }
/*      */   
/*      */   private static double internalUTC(double t) {
/*  802 */     return t - LocalTZA - DaylightSavingTA(t - LocalTZA);
/*      */   }
/*      */ 
/*      */   
/*      */   private static int HourFromTime(double t) {
/*  807 */     double result = Math.floor(t / 3600000.0D) % 24.0D;
/*  808 */     if (result < 0.0D) result += 24.0D; 
/*  809 */     return (int)result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int MinFromTime(double t) {
/*  814 */     double result = Math.floor(t / 60000.0D) % 60.0D;
/*  815 */     if (result < 0.0D) result += 60.0D; 
/*  816 */     return (int)result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int SecFromTime(double t) {
/*  821 */     double result = Math.floor(t / 1000.0D) % 60.0D;
/*  822 */     if (result < 0.0D) result += 60.0D; 
/*  823 */     return (int)result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int msFromTime(double t) {
/*  828 */     double result = t % 1000.0D;
/*  829 */     if (result < 0.0D) result += 1000.0D; 
/*  830 */     return (int)result;
/*      */   }
/*      */   
/*      */   private static double MakeTime(double hour, double min, double sec, double ms) {
/*  834 */     return ((hour * 60.0D + min) * 60.0D + sec) * 1000.0D + ms;
/*      */   }
/*      */   
/*      */   private static double MakeDay(double year, double month, double date) {
/*  838 */     year += Math.floor(month / 12.0D);
/*      */     
/*  840 */     month %= 12.0D;
/*  841 */     if (month < 0.0D) month += 12.0D;
/*      */     
/*  843 */     double yearday = Math.floor(TimeFromYear(year) / 8.64E7D);
/*  844 */     double monthday = DayFromMonth((int)month, (int)year);
/*      */     
/*  846 */     return yearday + monthday + date - 1.0D;
/*      */   }
/*      */   
/*      */   private static double MakeDate(double day, double time) {
/*  850 */     return day * 8.64E7D + time;
/*      */   }
/*      */   
/*      */   private static double TimeClip(double d) {
/*  854 */     if (Double.isNaN(d) || d == Double.POSITIVE_INFINITY || d == Double.NEGATIVE_INFINITY || 
/*      */ 
/*      */       
/*  857 */       Math.abs(d) > 8.64E15D) {
/*  858 */       return Double.NaN;
/*      */     }
/*  860 */     if (d > 0.0D) return Math.floor(d + 0.0D); 
/*  861 */     return Math.ceil(d + 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double date_msecFromDate(double year, double mon, double mday, double hour, double min, double sec, double msec) {
/*  879 */     double day = MakeDay(year, mon, mday);
/*  880 */     double time = MakeTime(hour, min, sec, msec);
/*  881 */     double result = MakeDate(day, time);
/*  882 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double date_msecFromArgs(Object[] args) {
/*  889 */     double[] array = new double[7];
/*      */ 
/*      */ 
/*      */     
/*  893 */     for (int loop = 0; loop < 7; loop++) {
/*  894 */       if (loop < args.length) {
/*  895 */         double d = ScriptRuntime.toNumber(args[loop]);
/*  896 */         if (Double.isNaN(d) || Double.isInfinite(d)) {
/*  897 */           return Double.NaN;
/*      */         }
/*  899 */         array[loop] = ScriptRuntime.toInteger(args[loop]);
/*      */       }
/*  901 */       else if (loop == 2) {
/*  902 */         array[loop] = 1.0D;
/*      */       } else {
/*  904 */         array[loop] = 0.0D;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  910 */     if (array[0] >= 0.0D && array[0] <= 99.0D) array[0] = array[0] + 1900.0D;
/*      */     
/*  912 */     return date_msecFromDate(array[0], array[1], array[2], array[3], array[4], array[5], array[6]);
/*      */   }
/*      */ 
/*      */   
/*      */   private static double jsStaticFunction_UTC(Object[] args) {
/*  917 */     if (args.length == 0) {
/*  918 */       return Double.NaN;
/*      */     }
/*  920 */     return TimeClip(date_msecFromArgs(args));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double parseISOString(String s) {
/*  934 */     int ERROR = -1;
/*  935 */     int YEAR = 0, MONTH = 1, DAY = 2;
/*  936 */     int HOUR = 3, MIN = 4, SEC = 5, MSEC = 6;
/*  937 */     int TZHOUR = 7, TZMIN = 8;
/*  938 */     int state = 0;
/*      */     
/*  940 */     int[] values = { 1970, 1, 1, 0, 0, 0, 0, -1, -1 };
/*  941 */     int yearlen = 4, yearmod = 1, tzmod = 1;
/*  942 */     int i = 0, len = s.length();
/*  943 */     if (len != 0) {
/*  944 */       char c = s.charAt(0);
/*  945 */       if (c == '+' || c == '-') {
/*      */         
/*  947 */         i++;
/*  948 */         yearlen = 6;
/*  949 */         yearmod = (c == '-') ? -1 : 1;
/*  950 */       } else if (c == 'T') {
/*      */         
/*  952 */         i++;
/*  953 */         state = 3;
/*      */       } 
/*      */     } 
/*      */     
/*  957 */     label126: while (state != -1) {
/*  958 */       int m = i + ((state == 0) ? yearlen : ((state == 6) ? 3 : 2));
/*  959 */       if (m > len) {
/*  960 */         state = -1;
/*      */         
/*      */         break;
/*      */       } 
/*  964 */       int value = 0;
/*  965 */       for (; i < m; i++) {
/*  966 */         char c1 = s.charAt(i);
/*  967 */         if (c1 < '0' || c1 > '9') {
/*  968 */           state = -1;
/*      */           break label126;
/*      */         } 
/*  971 */         value = 10 * value + c1 - 48;
/*      */       } 
/*  973 */       values[state] = value;
/*      */       
/*  975 */       if (i == len) {
/*      */         
/*  977 */         switch (state) {
/*      */           case 3:
/*      */           case 7:
/*  980 */             state = -1;
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       } 
/*  985 */       char c = s.charAt(i++);
/*  986 */       if (c == 'Z') {
/*      */         
/*  988 */         values[7] = 0;
/*  989 */         values[8] = 0;
/*  990 */         switch (state) {
/*      */           case 4:
/*      */           case 5:
/*      */           case 6:
/*      */             break;
/*      */         } 
/*  996 */         state = -1;
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1002 */       switch (state) {
/*      */         case 0:
/*      */         case 1:
/* 1005 */           state = (c == '-') ? (state + 1) : ((c == 'T') ? 3 : -1);
/*      */           break;
/*      */         case 2:
/* 1008 */           state = (c == 'T') ? 3 : -1;
/*      */           break;
/*      */         case 3:
/* 1011 */           state = (c == ':') ? 4 : -1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/* 1016 */           if (c != ':')
/*      */           {
/* 1018 */             i--;
/*      */           }
/* 1020 */           state = 8;
/*      */           break;
/*      */         case 4:
/* 1023 */           state = (c == ':') ? 5 : ((c == '+' || c == '-') ? 7 : -1);
/*      */           break;
/*      */         case 5:
/* 1026 */           state = (c == '.') ? 6 : ((c == '+' || c == '-') ? 7 : -1);
/*      */           break;
/*      */         case 6:
/* 1029 */           state = (c == '+' || c == '-') ? 7 : -1;
/*      */           break;
/*      */         case 8:
/* 1032 */           state = -1;
/*      */           break;
/*      */       } 
/* 1035 */       if (state == 7)
/*      */       {
/* 1037 */         tzmod = (c == '-') ? -1 : 1;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1044 */     if (state != -1 && i == len) {
/*      */ 
/*      */       
/* 1047 */       int year = values[0], month = values[1], day = values[2];
/* 1048 */       int hour = values[3], min = values[4], sec = values[5], msec = values[6];
/* 1049 */       int tzhour = values[7], tzmin = values[8];
/* 1050 */       if (year <= 275943 && month >= 1 && month <= 12 && day >= 1 && day <= 
/*      */         
/* 1052 */         DaysInMonth(year, month) && hour <= 24 && (hour != 24 || (min <= 0 && sec <= 0 && msec <= 0)) && min <= 59 && sec <= 59 && tzhour <= 23 && tzmin <= 59) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1062 */         double date = date_msecFromDate((year * yearmod), (month - 1), day, hour, min, sec, msec);
/* 1063 */         if (tzhour != -1)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1069 */           date -= (tzhour * 60 + tzmin) * 60000.0D * tzmod;
/*      */         }
/*      */         
/* 1072 */         if (date >= -8.64E15D && date <= 8.64E15D) {
/* 1073 */           return date;
/*      */         }
/*      */       } 
/*      */     } 
/* 1077 */     return Double.NaN;
/*      */   }
/*      */   
/*      */   private static double date_parseString(String s) {
/* 1081 */     double d = parseISOString(s);
/* 1082 */     if (!Double.isNaN(d)) {
/* 1083 */       return d;
/*      */     }
/*      */     
/* 1086 */     int year = -1;
/* 1087 */     int mon = -1;
/* 1088 */     int mday = -1;
/* 1089 */     int hour = -1;
/* 1090 */     int min = -1;
/* 1091 */     int sec = -1;
/* 1092 */     char c = Character.MIN_VALUE;
/* 1093 */     char si = Character.MIN_VALUE;
/* 1094 */     int i = 0;
/* 1095 */     int n = -1;
/* 1096 */     double tzoffset = -1.0D;
/* 1097 */     char prevc = Character.MIN_VALUE;
/* 1098 */     int limit = 0;
/* 1099 */     boolean seenplusminus = false;
/*      */     
/* 1101 */     limit = s.length();
/* 1102 */     while (i < limit) {
/* 1103 */       c = s.charAt(i);
/* 1104 */       i++;
/* 1105 */       if (c <= ' ' || c == ',' || c == '-') {
/* 1106 */         if (i < limit) {
/* 1107 */           si = s.charAt(i);
/* 1108 */           if (c == '-' && '0' <= si && si <= '9') {
/* 1109 */             prevc = c;
/*      */           }
/*      */         } 
/*      */         continue;
/*      */       } 
/* 1114 */       if (c == '(') {
/*      */         
/* 1116 */         int depth = 1;
/* 1117 */         while (i < limit) {
/* 1118 */           c = s.charAt(i);
/* 1119 */           i++;
/* 1120 */           if (c == '(') { depth++; continue; }
/* 1121 */            if (c == ')' && --depth <= 0)
/*      */             break; 
/*      */         }  continue;
/*      */       } 
/* 1125 */       if ('0' <= c && c <= '9') {
/* 1126 */         n = c - 48;
/* 1127 */         while (i < limit && '0' <= (c = s.charAt(i)) && c <= '9') {
/* 1128 */           n = n * 10 + c - 48;
/* 1129 */           i++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1139 */         if (prevc == '+' || prevc == '-')
/*      */         
/* 1141 */         { seenplusminus = true;
/*      */ 
/*      */           
/* 1144 */           if (n < 24) { n *= 60; }
/* 1145 */           else { n = n % 100 + n / 100 * 60; }
/* 1146 */            if (prevc == '+') n = -n; 
/* 1147 */           if (tzoffset != 0.0D && tzoffset != -1.0D) return Double.NaN; 
/* 1148 */           tzoffset = n; }
/* 1149 */         else if (n >= 70 || (prevc == '/' && mon >= 0 && mday >= 0 && year < 0))
/* 1150 */         { if (year >= 0) return Double.NaN; 
/* 1151 */           if (c <= ' ' || c == ',' || c == '/' || i >= limit)
/* 1152 */           { year = (n < 100) ? (n + 1900) : n; }
/* 1153 */           else { return Double.NaN; }  }
/* 1154 */         else if (c == ':')
/* 1155 */         { if (hour < 0) { hour = n; }
/* 1156 */           else if (min < 0) { min = n; }
/* 1157 */           else { return Double.NaN; }  }
/* 1158 */         else if (c == '/')
/* 1159 */         { if (mon < 0) { mon = n - 1; }
/* 1160 */           else if (mday < 0) { mday = n; }
/* 1161 */           else { return Double.NaN; }  }
/* 1162 */         else { if (i < limit && c != ',' && c > ' ' && c != '-')
/* 1163 */             return Double.NaN; 
/* 1164 */           if (seenplusminus && n < 60) {
/*      */             
/* 1166 */             if (tzoffset < 0.0D) { tzoffset -= n; }
/* 1167 */             else { tzoffset += n; } 
/* 1168 */           } else if (hour >= 0 && min < 0) {
/* 1169 */             min = n;
/* 1170 */           } else if (min >= 0 && sec < 0) {
/* 1171 */             sec = n;
/* 1172 */           } else if (mday < 0) {
/* 1173 */             mday = n;
/*      */           } else {
/* 1175 */             return Double.NaN;
/*      */           }  }
/* 1177 */          prevc = Character.MIN_VALUE; continue;
/* 1178 */       }  if (c == '/' || c == ':' || c == '+' || c == '-') {
/* 1179 */         prevc = c; continue;
/*      */       } 
/* 1181 */       int st = i - 1;
/* 1182 */       while (i < limit) {
/* 1183 */         c = s.charAt(i);
/* 1184 */         if (('A' > c || c > 'Z') && ('a' > c || c > 'z'))
/* 1185 */           break;  i++;
/*      */       } 
/* 1187 */       int letterCount = i - st;
/* 1188 */       if (letterCount < 2) return Double.NaN;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1194 */       String wtb = "am;pm;monday;tuesday;wednesday;thursday;friday;saturday;sunday;january;february;march;april;may;june;july;august;september;october;november;december;gmt;ut;utc;est;edt;cst;cdt;mst;mdt;pst;pdt;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1201 */       int index = 0;
/* 1202 */       int wtbOffset = 0; while (true) {
/* 1203 */         int wtbNext = wtb.indexOf(';', wtbOffset);
/* 1204 */         if (wtbNext < 0) return Double.NaN; 
/* 1205 */         if (wtb.regionMatches(true, wtbOffset, s, st, letterCount))
/* 1206 */           break;  wtbOffset = wtbNext + 1;
/* 1207 */         index++;
/*      */       } 
/* 1209 */       if (index < 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1214 */         if (hour > 12 || hour < 0)
/* 1215 */           return Double.NaN; 
/* 1216 */         if (index == 0) {
/*      */           
/* 1218 */           if (hour == 12) hour = 0; 
/*      */           continue;
/*      */         } 
/* 1221 */         if (hour != 12) hour += 12;  continue;
/*      */       } 
/* 1223 */       index -= 2; if (index < 7)
/*      */         continue; 
/* 1225 */       index -= 7; if (index < 12) {
/*      */         
/* 1227 */         if (mon < 0) {
/* 1228 */           mon = index; continue;
/*      */         } 
/* 1230 */         return Double.NaN;
/*      */       } 
/*      */       
/* 1233 */       index -= 12;
/*      */       
/* 1235 */       switch (index) {
/*      */         case 0:
/* 1237 */           tzoffset = 0.0D;
/*      */           continue;
/*      */         case 1:
/* 1240 */           tzoffset = 0.0D;
/*      */           continue;
/*      */         case 2:
/* 1243 */           tzoffset = 0.0D;
/*      */           continue;
/*      */         case 3:
/* 1246 */           tzoffset = 300.0D;
/*      */           continue;
/*      */         case 4:
/* 1249 */           tzoffset = 240.0D;
/*      */           continue;
/*      */         case 5:
/* 1252 */           tzoffset = 360.0D;
/*      */           continue;
/*      */         case 6:
/* 1255 */           tzoffset = 300.0D;
/*      */           continue;
/*      */         case 7:
/* 1258 */           tzoffset = 420.0D;
/*      */           continue;
/*      */         case 8:
/* 1261 */           tzoffset = 360.0D;
/*      */           continue;
/*      */         case 9:
/* 1264 */           tzoffset = 480.0D;
/*      */           continue;
/*      */         case 10:
/* 1267 */           tzoffset = 420.0D;
/*      */           continue;
/*      */       } 
/* 1270 */       Kit.codeBug();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1275 */     if (year < 0 || mon < 0 || mday < 0) return Double.NaN; 
/* 1276 */     if (sec < 0) sec = 0; 
/* 1277 */     if (min < 0) min = 0; 
/* 1278 */     if (hour < 0) hour = 0;
/*      */     
/* 1280 */     double msec = date_msecFromDate(year, mon, mday, hour, min, sec, 0.0D);
/* 1281 */     if (tzoffset == -1.0D)
/*      */     {
/* 1283 */       return internalUTC(msec);
/*      */     }
/* 1285 */     return msec + tzoffset * 60000.0D;
/*      */   }
/*      */   
/*      */   private static String date_format(double t, int methodId) {
/* 1289 */     StringBuilder result = new StringBuilder(60);
/* 1290 */     double local = LocalTime(t);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1296 */     if (methodId != 3) {
/* 1297 */       appendWeekDayName(result, WeekDay(local));
/* 1298 */       result.append(' ');
/* 1299 */       appendMonthName(result, MonthFromTime(local));
/* 1300 */       result.append(' ');
/* 1301 */       append0PaddedUint(result, DateFromTime(local), 2);
/* 1302 */       result.append(' ');
/* 1303 */       int year = YearFromTime(local);
/* 1304 */       if (year < 0) {
/* 1305 */         result.append('-');
/* 1306 */         year = -year;
/*      */       } 
/* 1308 */       append0PaddedUint(result, year, 4);
/* 1309 */       if (methodId != 4) result.append(' ');
/*      */     
/*      */     } 
/* 1312 */     if (methodId != 4) {
/* 1313 */       append0PaddedUint(result, HourFromTime(local), 2);
/* 1314 */       result.append(':');
/* 1315 */       append0PaddedUint(result, MinFromTime(local), 2);
/* 1316 */       result.append(':');
/* 1317 */       append0PaddedUint(result, SecFromTime(local), 2);
/*      */ 
/*      */ 
/*      */       
/* 1321 */       int minutes = (int)Math.floor((LocalTZA + DaylightSavingTA(t)) / 60000.0D);
/*      */       
/* 1323 */       int offset = minutes / 60 * 100 + minutes % 60;
/* 1324 */       if (offset > 0) {
/* 1325 */         result.append(" GMT+");
/*      */       } else {
/* 1327 */         result.append(" GMT-");
/* 1328 */         offset = -offset;
/*      */       } 
/* 1330 */       append0PaddedUint(result, offset, 4);
/*      */ 
/*      */ 
/*      */       
/* 1334 */       if (t < 0.0D) {
/* 1335 */         int equiv = EquivalentYear(YearFromTime(local));
/* 1336 */         double day = MakeDay(equiv, MonthFromTime(t), DateFromTime(t));
/* 1337 */         t = MakeDate(day, TimeWithinDay(t));
/*      */       } 
/* 1339 */       result.append(" (");
/* 1340 */       Date date = new Date((long)t);
/* 1341 */       synchronized (timeZoneFormatter) {
/* 1342 */         result.append(timeZoneFormatter.format(date));
/*      */       } 
/* 1344 */       result.append(')');
/*      */     } 
/* 1346 */     return result.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private static Object jsConstructor(Object[] args) {
/* 1351 */     NativeDate obj = new NativeDate();
/*      */ 
/*      */ 
/*      */     
/* 1355 */     if (args.length == 0) {
/* 1356 */       obj.date = now();
/* 1357 */       return obj;
/*      */     } 
/*      */ 
/*      */     
/* 1361 */     if (args.length == 1) {
/* 1362 */       double date; Object arg0 = args[0];
/* 1363 */       if (arg0 instanceof NativeDate) {
/* 1364 */         obj.date = ((NativeDate)arg0).date;
/* 1365 */         return obj;
/*      */       } 
/* 1367 */       if (arg0 instanceof Scriptable) {
/* 1368 */         arg0 = ((Scriptable)arg0).getDefaultValue(null);
/*      */       }
/*      */       
/* 1371 */       if (arg0 instanceof CharSequence) {
/*      */         
/* 1373 */         date = date_parseString(arg0.toString());
/*      */       } else {
/*      */         
/* 1376 */         date = ScriptRuntime.toNumber(arg0);
/*      */       } 
/* 1378 */       obj.date = TimeClip(date);
/* 1379 */       return obj;
/*      */     } 
/*      */     
/* 1382 */     double time = date_msecFromArgs(args);
/*      */     
/* 1384 */     if (!Double.isNaN(time) && !Double.isInfinite(time)) time = TimeClip(internalUTC(time));
/*      */     
/* 1386 */     obj.date = time;
/*      */     
/* 1388 */     return obj;
/*      */   }
/*      */   
/*      */   private static String toLocale_helper(double t, int methodId) {
/*      */     DateFormat formatter;
/* 1393 */     switch (methodId) {
/*      */       case 5:
/* 1395 */         formatter = localeDateTimeFormatter;
/*      */         break;
/*      */       case 6:
/* 1398 */         formatter = localeTimeFormatter;
/*      */         break;
/*      */       case 7:
/* 1401 */         formatter = localeDateFormatter;
/*      */         break;
/*      */       default:
/* 1404 */         throw new AssertionError();
/*      */     } 
/*      */     
/* 1407 */     synchronized (formatter) {
/* 1408 */       return formatter.format(new Date((long)t));
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String js_toUTCString(double date) {
/* 1413 */     StringBuilder result = new StringBuilder(60);
/*      */     
/* 1415 */     appendWeekDayName(result, WeekDay(date));
/* 1416 */     result.append(", ");
/* 1417 */     append0PaddedUint(result, DateFromTime(date), 2);
/* 1418 */     result.append(' ');
/* 1419 */     appendMonthName(result, MonthFromTime(date));
/* 1420 */     result.append(' ');
/* 1421 */     int year = YearFromTime(date);
/* 1422 */     if (year < 0) {
/* 1423 */       result.append('-');
/* 1424 */       year = -year;
/*      */     } 
/* 1426 */     append0PaddedUint(result, year, 4);
/* 1427 */     result.append(' ');
/* 1428 */     append0PaddedUint(result, HourFromTime(date), 2);
/* 1429 */     result.append(':');
/* 1430 */     append0PaddedUint(result, MinFromTime(date), 2);
/* 1431 */     result.append(':');
/* 1432 */     append0PaddedUint(result, SecFromTime(date), 2);
/* 1433 */     result.append(" GMT");
/* 1434 */     return result.toString();
/*      */   }
/*      */   
/*      */   private static String js_toISOString(double t) {
/* 1438 */     StringBuilder result = new StringBuilder(27);
/*      */     
/* 1440 */     int year = YearFromTime(t);
/* 1441 */     if (year < 0) {
/* 1442 */       result.append('-');
/* 1443 */       append0PaddedUint(result, -year, 6);
/* 1444 */     } else if (year > 9999) {
/* 1445 */       result.append('+');
/* 1446 */       append0PaddedUint(result, year, 6);
/*      */     } else {
/* 1448 */       append0PaddedUint(result, year, 4);
/*      */     } 
/* 1450 */     result.append('-');
/* 1451 */     append0PaddedUint(result, MonthFromTime(t) + 1, 2);
/* 1452 */     result.append('-');
/* 1453 */     append0PaddedUint(result, DateFromTime(t), 2);
/* 1454 */     result.append('T');
/* 1455 */     append0PaddedUint(result, HourFromTime(t), 2);
/* 1456 */     result.append(':');
/* 1457 */     append0PaddedUint(result, MinFromTime(t), 2);
/* 1458 */     result.append(':');
/* 1459 */     append0PaddedUint(result, SecFromTime(t), 2);
/* 1460 */     result.append('.');
/* 1461 */     append0PaddedUint(result, msFromTime(t), 3);
/* 1462 */     result.append('Z');
/* 1463 */     return result.toString();
/*      */   }
/*      */   
/*      */   private static void append0PaddedUint(StringBuilder sb, int i, int minWidth) {
/* 1467 */     if (i < 0) Kit.codeBug(); 
/* 1468 */     int scale = 1;
/* 1469 */     minWidth--;
/* 1470 */     if (i >= 10) {
/* 1471 */       if (i < 1000000000) {
/*      */         while (true) {
/* 1473 */           int newScale = scale * 10;
/* 1474 */           if (i < newScale) {
/*      */             break;
/*      */           }
/* 1477 */           minWidth--;
/* 1478 */           scale = newScale;
/*      */         } 
/*      */       } else {
/*      */         
/* 1482 */         minWidth -= 9;
/* 1483 */         scale = 1000000000;
/*      */       } 
/*      */     }
/* 1486 */     while (minWidth > 0) {
/* 1487 */       sb.append('0');
/* 1488 */       minWidth--;
/*      */     } 
/* 1490 */     while (scale != 1) {
/* 1491 */       sb.append((char)(48 + i / scale));
/* 1492 */       i %= scale;
/* 1493 */       scale /= 10;
/*      */     } 
/* 1495 */     sb.append((char)(48 + i));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void appendMonthName(StringBuilder sb, int index) {
/* 1502 */     String months = "JanFebMarAprMayJunJulAugSepOctNovDec";
/*      */ 
/*      */     
/* 1505 */     index *= 3;
/* 1506 */     for (int i = 0; i != 3; i++) {
/* 1507 */       sb.append(months.charAt(index + i));
/*      */     }
/*      */   }
/*      */   
/*      */   private static void appendWeekDayName(StringBuilder sb, int index) {
/* 1512 */     String days = "SunMonTueWedThuFriSat";
/* 1513 */     index *= 3;
/* 1514 */     for (int i = 0; i != 3; i++)
/* 1515 */       sb.append(days.charAt(index + i)); 
/*      */   }
/*      */   private static double makeTime(double date, Object[] args, int methodId) {
/*      */     int maxargs;
/*      */     double hour, min, sec, msec, lorutime;
/* 1520 */     if (args.length == 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1530 */       return Double.NaN;
/*      */     }
/*      */ 
/*      */     
/* 1534 */     boolean local = true;
/* 1535 */     switch (methodId) {
/*      */       case 32:
/* 1537 */         local = false;
/*      */       
/*      */       case 31:
/* 1540 */         maxargs = 1;
/*      */         break;
/*      */       
/*      */       case 34:
/* 1544 */         local = false;
/*      */       
/*      */       case 33:
/* 1547 */         maxargs = 2;
/*      */         break;
/*      */       
/*      */       case 36:
/* 1551 */         local = false;
/*      */       
/*      */       case 35:
/* 1554 */         maxargs = 3;
/*      */         break;
/*      */       
/*      */       case 38:
/* 1558 */         local = false;
/*      */       
/*      */       case 37:
/* 1561 */         maxargs = 4;
/*      */         break;
/*      */       
/*      */       default:
/* 1565 */         throw Kit.codeBug();
/*      */     } 
/*      */     
/* 1568 */     boolean hasNaN = false;
/* 1569 */     int numNums = (args.length < maxargs) ? args.length : maxargs;
/* 1570 */     assert numNums <= 4;
/* 1571 */     double[] nums = new double[4]; int i;
/* 1572 */     for (i = 0; i < numNums; i++) {
/* 1573 */       double d = ScriptRuntime.toNumber(args[i]);
/* 1574 */       if (Double.isNaN(d) || Double.isInfinite(d)) {
/* 1575 */         hasNaN = true;
/*      */       } else {
/* 1577 */         nums[i] = ScriptRuntime.toInteger(d);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1583 */     if (hasNaN || Double.isNaN(date)) {
/* 1584 */       return Double.NaN;
/*      */     }
/*      */     
/* 1587 */     i = 0; int stop = numNums;
/*      */ 
/*      */ 
/*      */     
/* 1591 */     if (local) { lorutime = LocalTime(date); }
/* 1592 */     else { lorutime = date; }
/*      */     
/* 1594 */     if (maxargs >= 4 && i < stop) { hour = nums[i++]; }
/* 1595 */     else { hour = HourFromTime(lorutime); }
/*      */     
/* 1597 */     if (maxargs >= 3 && i < stop) { min = nums[i++]; }
/* 1598 */     else { min = MinFromTime(lorutime); }
/*      */     
/* 1600 */     if (maxargs >= 2 && i < stop) { sec = nums[i++]; }
/* 1601 */     else { sec = SecFromTime(lorutime); }
/*      */     
/* 1603 */     if (maxargs >= 1 && i < stop) { msec = nums[i++]; }
/* 1604 */     else { msec = msFromTime(lorutime); }
/*      */     
/* 1606 */     double time = MakeTime(hour, min, sec, msec);
/* 1607 */     double result = MakeDate(Day(lorutime), time);
/*      */     
/* 1609 */     if (local) result = internalUTC(result);
/*      */     
/* 1611 */     return TimeClip(result);
/*      */   }
/*      */   private static double makeDate(double date, Object[] args, int methodId) {
/*      */     int maxargs;
/*      */     double year, month, lorutime;
/* 1616 */     if (args.length == 0) {
/* 1617 */       return Double.NaN;
/*      */     }
/*      */ 
/*      */     
/* 1621 */     boolean local = true;
/* 1622 */     switch (methodId) {
/*      */       case 40:
/* 1624 */         local = false;
/*      */       
/*      */       case 39:
/* 1627 */         maxargs = 1;
/*      */         break;
/*      */       
/*      */       case 42:
/* 1631 */         local = false;
/*      */       
/*      */       case 41:
/* 1634 */         maxargs = 2;
/*      */         break;
/*      */       
/*      */       case 44:
/* 1638 */         local = false;
/*      */       
/*      */       case 43:
/* 1641 */         maxargs = 3;
/*      */         break;
/*      */       
/*      */       default:
/* 1645 */         throw Kit.codeBug();
/*      */     } 
/*      */     
/* 1648 */     boolean hasNaN = false;
/* 1649 */     int numNums = (args.length < maxargs) ? args.length : maxargs;
/* 1650 */     assert 1 <= numNums && numNums <= 3;
/* 1651 */     double[] nums = new double[3]; int i;
/* 1652 */     for (i = 0; i < numNums; i++) {
/* 1653 */       double d = ScriptRuntime.toNumber(args[i]);
/* 1654 */       if (Double.isNaN(d) || Double.isInfinite(d)) {
/* 1655 */         hasNaN = true;
/*      */       } else {
/* 1657 */         nums[i] = ScriptRuntime.toInteger(d);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1662 */     if (hasNaN) {
/* 1663 */       return Double.NaN;
/*      */     }
/*      */     
/* 1666 */     i = 0; int stop = numNums;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1672 */     if (Double.isNaN(date))
/* 1673 */     { if (maxargs < 3) {
/* 1674 */         return Double.NaN;
/*      */       }
/* 1676 */       lorutime = 0.0D; }
/*      */     
/* 1678 */     else if (local) { lorutime = LocalTime(date); }
/* 1679 */     else { lorutime = date; }
/*      */ 
/*      */     
/* 1682 */     if (maxargs >= 3 && i < stop) { year = nums[i++]; }
/* 1683 */     else { year = YearFromTime(lorutime); }
/*      */     
/* 1685 */     if (maxargs >= 2 && i < stop) { month = nums[i++]; }
/* 1686 */     else { month = MonthFromTime(lorutime); }
/*      */     
/* 1688 */     if (maxargs >= 1 && i < stop) { day = nums[i++]; }
/* 1689 */     else { day = DateFromTime(lorutime); }
/*      */     
/* 1691 */     double day = MakeDay(year, month, day);
/* 1692 */     double result = MakeDate(day, TimeWithinDay(lorutime));
/*      */     
/* 1694 */     if (local) result = internalUTC(result);
/*      */     
/* 1696 */     return TimeClip(result);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int findPrototypeId(String s) {
/* 1702 */     switch (s)
/*      */     { case "constructor":
/* 1704 */         id = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1851 */         return id;case "toString": id = 2; return id;case "toTimeString": id = 3; return id;case "toDateString": id = 4; return id;case "toLocaleString": id = 5; return id;case "toLocaleTimeString": id = 6; return id;case "toLocaleDateString": id = 7; return id;case "toUTCString": id = 8; return id;case "toSource": id = 9; return id;case "valueOf": id = 10; return id;case "getTime": id = 11; return id;case "getYear": id = 12; return id;case "getFullYear": id = 13; return id;case "getUTCFullYear": id = 14; return id;case "getMonth": id = 15; return id;case "getUTCMonth": id = 16; return id;case "getDate": id = 17; return id;case "getUTCDate": id = 18; return id;case "getDay": id = 19; return id;case "getUTCDay": id = 20; return id;case "getHours": id = 21; return id;case "getUTCHours": id = 22; return id;case "getMinutes": id = 23; return id;case "getUTCMinutes": id = 24; return id;case "getSeconds": id = 25; return id;case "getUTCSeconds": id = 26; return id;case "getMilliseconds": id = 27; return id;case "getUTCMilliseconds": id = 28; return id;case "getTimezoneOffset": id = 29; return id;case "setTime": id = 30; return id;case "setMilliseconds": id = 31; return id;case "setUTCMilliseconds": id = 32; return id;case "setSeconds": id = 33; return id;case "setUTCSeconds": id = 34; return id;case "setMinutes": id = 35; return id;case "setUTCMinutes": id = 36; return id;case "setHours": id = 37; return id;case "setUTCHours": id = 38; return id;case "setDate": id = 39; return id;case "setUTCDate": id = 40; return id;case "setMonth": id = 41; return id;case "setUTCMonth": id = 42; return id;case "setFullYear": id = 43; return id;case "setUTCFullYear": id = 44; return id;case "setYear": id = 45; return id;case "toISOString": id = 46; return id;case "toJSON": id = 47; return id;case "toGMTString": id = 8; return id; }  int id = 0; return id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1909 */   private static final TimeZone thisTimeZone = TimeZone.getDefault();
/* 1910 */   private static final double LocalTZA = thisTimeZone.getRawOffset();
/*      */ 
/*      */   
/* 1913 */   private static final DateFormat timeZoneFormatter = new SimpleDateFormat("zzz");
/* 1914 */   private static final DateFormat localeDateTimeFormatter = new SimpleDateFormat("MMMM d, yyyy h:mm:ss a z");
/*      */   
/* 1916 */   private static final DateFormat localeDateFormatter = new SimpleDateFormat("MMMM d, yyyy");
/* 1917 */   private static final DateFormat localeTimeFormatter = new SimpleDateFormat("h:mm:ss a z");
/*      */   private double date;
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeDate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */