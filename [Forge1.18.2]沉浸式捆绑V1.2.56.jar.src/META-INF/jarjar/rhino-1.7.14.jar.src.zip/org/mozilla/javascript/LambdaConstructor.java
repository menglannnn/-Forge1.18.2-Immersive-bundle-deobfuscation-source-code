/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LambdaConstructor
/*     */   extends LambdaFunction
/*     */ {
/*     */   private static final long serialVersionUID = 2691205302914111400L;
/*     */   public static final int CONSTRUCTOR_FUNCTION = 1;
/*     */   public static final int CONSTRUCTOR_NEW = 2;
/*     */   public static final int CONSTRUCTOR_DEFAULT = 3;
/*     */   private final transient Constructable targetConstructor;
/*     */   private final int flags;
/*     */   
/*     */   public LambdaConstructor(Scriptable scope, String name, int length, Constructable target) {
/*  48 */     super(scope, name, length, (Callable)null);
/*  49 */     this.targetConstructor = target;
/*  50 */     this.flags = 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LambdaConstructor(Scriptable scope, String name, int length, int flags, Constructable target) {
/*  59 */     super(scope, name, length, (Callable)null);
/*  60 */     this.targetConstructor = target;
/*  61 */     this.flags = flags;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  66 */     if ((this.flags & 0x1) == 0) {
/*  67 */       throw ScriptRuntime.typeErrorById("msg.constructor.no.function", new Object[] { getFunctionName() });
/*     */     }
/*  69 */     return this.targetConstructor.construct(cx, scope, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/*  74 */     if ((this.flags & 0x2) == 0) {
/*  75 */       throw ScriptRuntime.typeErrorById("msg.no.new", new Object[] { getFunctionName() });
/*     */     }
/*  77 */     Scriptable obj = this.targetConstructor.construct(cx, scope, args);
/*  78 */     obj.setPrototype(getClassPrototype());
/*  79 */     obj.setParentScope(scope);
/*  80 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void definePrototypeMethod(Scriptable scope, String name, int length, Callable target) {
/*  88 */     LambdaFunction f = new LambdaFunction(scope, name, length, target);
/*  89 */     ScriptableObject proto = getPrototypeScriptable();
/*  90 */     proto.defineProperty(name, f, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void definePrototypeMethod(Scriptable scope, String name, int length, Callable target, int attributes, int propertyAttributes) {
/* 104 */     LambdaFunction f = new LambdaFunction(scope, name, length, target);
/* 105 */     f.setStandardPropertyAttributes(propertyAttributes);
/* 106 */     ScriptableObject proto = getPrototypeScriptable();
/* 107 */     proto.defineProperty(name, f, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public void definePrototypeProperty(String name, Object value, int attributes) {
/* 112 */     ScriptableObject proto = getPrototypeScriptable();
/* 113 */     proto.defineProperty(name, value, attributes);
/*     */   }
/*     */   
/*     */   public void definePrototypeProperty(Symbol key, Object value, int attributes) {
/* 117 */     ScriptableObject proto = getPrototypeScriptable();
/* 118 */     proto.defineProperty(key, value, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defineConstructorMethod(Scriptable scope, String name, int length, Callable target, int attributes) {
/* 133 */     LambdaFunction f = new LambdaFunction(scope, name, length, target);
/* 134 */     defineProperty(name, f, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defineConstructorMethod(Scriptable scope, Symbol key, String name, int length, Callable target, int attributes) {
/* 154 */     LambdaFunction f = new LambdaFunction(scope, name, length, target);
/* 155 */     defineProperty(key, f, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defineConstructorMethod(Scriptable scope, String name, int length, Callable target, int attributes, int propertyAttributes) {
/* 170 */     LambdaFunction f = new LambdaFunction(scope, name, length, target);
/* 171 */     f.setStandardPropertyAttributes(propertyAttributes);
/* 172 */     defineProperty(name, f, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T convertThisObject(Scriptable thisObj, Class<T> targetClass) {
/* 182 */     if (!targetClass.isInstance(thisObj)) {
/* 183 */       throw ScriptRuntime.typeErrorById("msg.this.not.instance", new Object[0]);
/*     */     }
/* 185 */     return (T)thisObj;
/*     */   }
/*     */   
/*     */   private ScriptableObject getPrototypeScriptable() {
/* 189 */     Object prop = getPrototypeProperty();
/* 190 */     if (!(prop instanceof ScriptableObject)) {
/* 191 */       throw ScriptRuntime.typeError("Not properly a lambda constructor");
/*     */     }
/* 193 */     return (ScriptableObject)prop;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\LambdaConstructor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */