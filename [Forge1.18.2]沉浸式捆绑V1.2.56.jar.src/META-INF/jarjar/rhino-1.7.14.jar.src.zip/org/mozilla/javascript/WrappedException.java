/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WrappedException
/*    */   extends EvaluatorException
/*    */ {
/*    */   private static final long serialVersionUID = -1551979216966520648L;
/*    */   private Throwable exception;
/*    */   
/*    */   public WrappedException(Throwable exception) {
/* 26 */     super("Wrapped " + exception);
/* 27 */     this.exception = exception;
/* 28 */     initCause(exception);
/*    */     
/* 30 */     int[] linep = { 0 };
/* 31 */     String sourceName = Context.getSourcePositionFromStack(linep);
/* 32 */     int lineNumber = linep[0];
/* 33 */     if (sourceName != null) {
/* 34 */       initSourceName(sourceName);
/*    */     }
/* 36 */     if (lineNumber != 0) {
/* 37 */       initLineNumber(lineNumber);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Throwable getWrappedException() {
/* 49 */     return this.exception;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public Object unwrap() {
/* 58 */     return getWrappedException();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\WrappedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */