/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IdScriptableObject
/*     */   extends ScriptableObject
/*     */   implements IdFunctionCall
/*     */ {
/*     */   private static final long serialVersionUID = -3744239272168621609L;
/*     */   private transient PrototypeValues prototypeValues;
/*     */   
/*     */   private static final class PrototypeValues
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 3038645279153854371L;
/*     */     private static final int NAME_SLOT = 1;
/*     */     private static final int SLOT_SPAN = 2;
/*     */     private IdScriptableObject obj;
/*     */     private int maxId;
/*     */     private Object[] valueArray;
/*     */     private short[] attributeArray;
/*     */     int constructorId;
/*     */     private IdFunctionObject constructor;
/*     */     private short constructorAttrs;
/*     */     
/*     */     PrototypeValues(IdScriptableObject obj, int maxId) {
/*  49 */       if (obj == null) throw new IllegalArgumentException(); 
/*  50 */       if (maxId < 1) throw new IllegalArgumentException(); 
/*  51 */       this.obj = obj;
/*  52 */       this.maxId = maxId;
/*     */     }
/*     */     
/*     */     final int getMaxId() {
/*  56 */       return this.maxId;
/*     */     }
/*     */     
/*     */     final void initValue(int id, String name, Object value, int attributes) {
/*  60 */       if (1 > id || id > this.maxId) throw new IllegalArgumentException(); 
/*  61 */       if (name == null) throw new IllegalArgumentException(); 
/*  62 */       if (value == Scriptable.NOT_FOUND) throw new IllegalArgumentException(); 
/*  63 */       ScriptableObject.checkValidAttributes(attributes);
/*  64 */       if (this.obj.findPrototypeId(name) != id) throw new IllegalArgumentException(name);
/*     */       
/*  66 */       if (id == this.constructorId) {
/*  67 */         if (!(value instanceof IdFunctionObject)) {
/*  68 */           throw new IllegalArgumentException("consructor should be initialized with IdFunctionObject");
/*     */         }
/*     */         
/*  71 */         this.constructor = (IdFunctionObject)value;
/*  72 */         this.constructorAttrs = (short)attributes;
/*     */         
/*     */         return;
/*     */       } 
/*  76 */       initSlot(id, name, value, attributes);
/*     */     }
/*     */     
/*     */     final void initValue(int id, Symbol key, Object value, int attributes) {
/*  80 */       if (1 > id || id > this.maxId) throw new IllegalArgumentException(); 
/*  81 */       if (key == null) throw new IllegalArgumentException(); 
/*  82 */       if (value == Scriptable.NOT_FOUND) throw new IllegalArgumentException(); 
/*  83 */       ScriptableObject.checkValidAttributes(attributes);
/*  84 */       if (this.obj.findPrototypeId(key) != id) throw new IllegalArgumentException(key.toString());
/*     */       
/*  86 */       if (id == this.constructorId) {
/*  87 */         if (!(value instanceof IdFunctionObject)) {
/*  88 */           throw new IllegalArgumentException("consructor should be initialized with IdFunctionObject");
/*     */         }
/*     */         
/*  91 */         this.constructor = (IdFunctionObject)value;
/*  92 */         this.constructorAttrs = (short)attributes;
/*     */         
/*     */         return;
/*     */       } 
/*  96 */       initSlot(id, key, value, attributes);
/*     */     }
/*     */     
/*     */     private void initSlot(int id, Object name, Object value, int attributes) {
/* 100 */       Object[] array = this.valueArray;
/* 101 */       if (array == null) throw new IllegalStateException();
/*     */       
/* 103 */       if (value == null) {
/* 104 */         value = UniqueTag.NULL_VALUE;
/*     */       }
/* 106 */       int index = (id - 1) * 2;
/* 107 */       synchronized (this) {
/* 108 */         Object value2 = array[index];
/* 109 */         if (value2 == null)
/* 110 */         { array[index] = value;
/* 111 */           array[index + 1] = name;
/* 112 */           this.attributeArray[id - 1] = (short)attributes; }
/*     */         
/* 114 */         else if (!name.equals(array[index + 1])) { throw new IllegalStateException(); }
/*     */       
/*     */       } 
/*     */     }
/*     */     
/*     */     final IdFunctionObject createPrecachedConstructor() {
/* 120 */       if (this.constructorId != 0) throw new IllegalStateException(); 
/* 121 */       this.constructorId = this.obj.findPrototypeId("constructor");
/* 122 */       if (this.constructorId == 0) {
/* 123 */         throw new IllegalStateException("No id for constructor property");
/*     */       }
/* 125 */       this.obj.initPrototypeId(this.constructorId);
/* 126 */       if (this.constructor == null) {
/* 127 */         throw new IllegalStateException(this.obj
/* 128 */             .getClass().getName() + ".initPrototypeId() did not initialize id=" + this.constructorId);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 133 */       this.constructor.initFunction(this.obj.getClassName(), ScriptableObject.getTopLevelScope(this.obj));
/* 134 */       this.constructor.markAsConstructor(this.obj);
/* 135 */       return this.constructor;
/*     */     }
/*     */     
/*     */     final int findId(String name) {
/* 139 */       return this.obj.findPrototypeId(name);
/*     */     }
/*     */     
/*     */     final int findId(Symbol key) {
/* 143 */       return this.obj.findPrototypeId(key);
/*     */     }
/*     */     
/*     */     final boolean has(int id) {
/* 147 */       Object[] array = this.valueArray;
/* 148 */       if (array == null)
/*     */       {
/* 150 */         return true;
/*     */       }
/* 152 */       int valueSlot = (id - 1) * 2;
/* 153 */       Object value = array[valueSlot];
/* 154 */       if (value == null)
/*     */       {
/* 156 */         return true;
/*     */       }
/* 158 */       return (value != Scriptable.NOT_FOUND);
/*     */     }
/*     */     
/*     */     final Object get(int id) {
/* 162 */       Object value = ensureId(id);
/* 163 */       if (value == UniqueTag.NULL_VALUE) {
/* 164 */         value = null;
/*     */       }
/* 166 */       return value;
/*     */     }
/*     */     
/*     */     final void set(int id, Scriptable start, Object value) {
/* 170 */       if (value == Scriptable.NOT_FOUND) throw new IllegalArgumentException(); 
/* 171 */       ensureId(id);
/* 172 */       int attr = this.attributeArray[id - 1];
/* 173 */       if ((attr & 0x1) == 0) {
/* 174 */         if (start == this.obj) {
/* 175 */           if (value == null) {
/* 176 */             value = UniqueTag.NULL_VALUE;
/*     */           }
/* 178 */           int valueSlot = (id - 1) * 2;
/* 179 */           synchronized (this) {
/* 180 */             this.valueArray[valueSlot] = value;
/*     */           } 
/*     */         } else {
/* 183 */           int nameSlot = (id - 1) * 2 + 1;
/* 184 */           Object name = this.valueArray[nameSlot];
/* 185 */           if (name instanceof Symbol) {
/* 186 */             if (start instanceof SymbolScriptable) {
/* 187 */               ((SymbolScriptable)start).put((Symbol)name, start, value);
/*     */             }
/*     */           } else {
/* 190 */             start.put((String)name, start, value);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     final void delete(int id) {
/* 197 */       ensureId(id);
/* 198 */       int attr = this.attributeArray[id - 1];
/*     */       
/* 200 */       if ((attr & 0x4) != 0) {
/* 201 */         Context cx = Context.getContext();
/* 202 */         if (cx.isStrictMode()) {
/* 203 */           int nameSlot = (id - 1) * 2 + 1;
/* 204 */           String name = (String)this.valueArray[nameSlot];
/* 205 */           throw ScriptRuntime.typeErrorById("msg.delete.property.with.configurable.false", new Object[] { name });
/*     */         } 
/*     */       } else {
/*     */         
/* 209 */         int valueSlot = (id - 1) * 2;
/* 210 */         synchronized (this) {
/* 211 */           this.valueArray[valueSlot] = Scriptable.NOT_FOUND;
/* 212 */           this.attributeArray[id - 1] = 0;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     final int getAttributes(int id) {
/* 218 */       ensureId(id);
/* 219 */       return this.attributeArray[id - 1];
/*     */     }
/*     */     
/*     */     final void setAttributes(int id, int attributes) {
/* 223 */       ScriptableObject.checkValidAttributes(attributes);
/* 224 */       ensureId(id);
/* 225 */       synchronized (this) {
/* 226 */         this.attributeArray[id - 1] = (short)attributes;
/*     */       } 
/*     */     }
/*     */     
/*     */     final Object[] getNames(boolean getAll, boolean getSymbols, Object[] extraEntries) {
/* 231 */       Object[] names = null;
/* 232 */       int count = 0;
/* 233 */       for (int id = 1; id <= this.maxId; id++) {
/* 234 */         Object value = ensureId(id);
/* 235 */         if ((getAll || (this.attributeArray[id - 1] & 0x2) == 0) && 
/* 236 */           value != Scriptable.NOT_FOUND) {
/* 237 */           int nameSlot = (id - 1) * 2 + 1;
/* 238 */           Object name = this.valueArray[nameSlot];
/* 239 */           if (name instanceof String) {
/* 240 */             if (names == null) {
/* 241 */               names = new Object[this.maxId];
/*     */             }
/* 243 */             names[count++] = name;
/* 244 */           } else if (getSymbols && name instanceof Symbol) {
/* 245 */             if (names == null) {
/* 246 */               names = new Object[this.maxId];
/*     */             }
/* 248 */             names[count++] = name.toString();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 253 */       if (count == 0)
/* 254 */         return extraEntries; 
/* 255 */       if (extraEntries == null || extraEntries.length == 0) {
/* 256 */         if (count != names.length) {
/* 257 */           Object[] arrayOfObject = new Object[count];
/* 258 */           System.arraycopy(names, 0, arrayOfObject, 0, count);
/* 259 */           names = arrayOfObject;
/*     */         } 
/* 261 */         return names;
/*     */       } 
/* 263 */       int extra = extraEntries.length;
/* 264 */       Object[] tmp = new Object[extra + count];
/* 265 */       System.arraycopy(extraEntries, 0, tmp, 0, extra);
/* 266 */       System.arraycopy(names, 0, tmp, extra, count);
/* 267 */       return tmp;
/*     */     }
/*     */ 
/*     */     
/*     */     private Object ensureId(int id) {
/* 272 */       Object[] array = this.valueArray;
/* 273 */       if (array == null) {
/* 274 */         synchronized (this) {
/* 275 */           array = this.valueArray;
/* 276 */           if (array == null) {
/* 277 */             array = new Object[this.maxId * 2];
/* 278 */             this.valueArray = array;
/* 279 */             this.attributeArray = new short[this.maxId];
/*     */           } 
/*     */         } 
/*     */       }
/* 283 */       int valueSlot = (id - 1) * 2;
/* 284 */       Object value = array[valueSlot];
/* 285 */       if (value == null) {
/* 286 */         if (id == this.constructorId) {
/* 287 */           initSlot(this.constructorId, "constructor", this.constructor, this.constructorAttrs);
/* 288 */           this.constructor = null;
/*     */         } else {
/* 290 */           this.obj.initPrototypeId(id);
/*     */         } 
/* 292 */         value = array[valueSlot];
/* 293 */         if (value == null) {
/* 294 */           throw new IllegalStateException(this.obj
/* 295 */               .getClass().getName() + ".initPrototypeId(int id) did not initialize id=" + id);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 301 */       return value;
/*     */     }
/*     */   }
/*     */   
/*     */   public IdScriptableObject() {}
/*     */   
/*     */   public IdScriptableObject(Scriptable scope, Scriptable prototype) {
/* 308 */     super(scope, prototype);
/*     */   }
/*     */   
/*     */   protected final boolean defaultHas(String name) {
/* 312 */     return super.has(name, this);
/*     */   }
/*     */   
/*     */   protected final Object defaultGet(String name) {
/* 316 */     return super.get(name, this);
/*     */   }
/*     */   
/*     */   protected final void defaultPut(String name, Object value) {
/* 320 */     super.put(name, this, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(String name, Scriptable start) {
/* 325 */     int info = findInstanceIdInfo(name);
/* 326 */     if (info != 0) {
/* 327 */       int attr = info >>> 16;
/* 328 */       if ((attr & 0x4) != 0) {
/* 329 */         return true;
/*     */       }
/* 331 */       int id = info & 0xFFFF;
/* 332 */       return (NOT_FOUND != getInstanceIdValue(id));
/*     */     } 
/* 334 */     if (this.prototypeValues != null) {
/* 335 */       int id = this.prototypeValues.findId(name);
/* 336 */       if (id != 0) {
/* 337 */         return this.prototypeValues.has(id);
/*     */       }
/*     */     } 
/* 340 */     return super.has(name, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(Symbol key, Scriptable start) {
/* 345 */     int info = findInstanceIdInfo(key);
/* 346 */     if (info != 0) {
/* 347 */       int attr = info >>> 16;
/* 348 */       if ((attr & 0x4) != 0) {
/* 349 */         return true;
/*     */       }
/* 351 */       int id = info & 0xFFFF;
/* 352 */       return (NOT_FOUND != getInstanceIdValue(id));
/*     */     } 
/* 354 */     if (this.prototypeValues != null) {
/* 355 */       int id = this.prototypeValues.findId(key);
/* 356 */       if (id != 0) {
/* 357 */         return this.prototypeValues.has(id);
/*     */       }
/*     */     } 
/* 360 */     return super.has(key, start);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String name, Scriptable start) {
/* 367 */     Object value = super.get(name, start);
/* 368 */     if (value != NOT_FOUND) {
/* 369 */       return value;
/*     */     }
/* 371 */     int info = findInstanceIdInfo(name);
/* 372 */     if (info != 0) {
/* 373 */       int id = info & 0xFFFF;
/* 374 */       value = getInstanceIdValue(id);
/* 375 */       if (value != NOT_FOUND) return value; 
/*     */     } 
/* 377 */     if (this.prototypeValues != null) {
/* 378 */       int id = this.prototypeValues.findId(name);
/* 379 */       if (id != 0) {
/* 380 */         value = this.prototypeValues.get(id);
/* 381 */         if (value != NOT_FOUND) return value; 
/*     */       } 
/*     */     } 
/* 384 */     return NOT_FOUND;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Symbol key, Scriptable start) {
/* 389 */     Object value = super.get(key, start);
/* 390 */     if (value != NOT_FOUND) {
/* 391 */       return value;
/*     */     }
/* 393 */     int info = findInstanceIdInfo(key);
/* 394 */     if (info != 0) {
/* 395 */       int id = info & 0xFFFF;
/* 396 */       value = getInstanceIdValue(id);
/* 397 */       if (value != NOT_FOUND) return value; 
/*     */     } 
/* 399 */     if (this.prototypeValues != null) {
/* 400 */       int id = this.prototypeValues.findId(key);
/* 401 */       if (id != 0) {
/* 402 */         value = this.prototypeValues.get(id);
/* 403 */         if (value != NOT_FOUND) return value; 
/*     */       } 
/*     */     } 
/* 406 */     return NOT_FOUND;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String name, Scriptable start, Object value) {
/* 411 */     int info = findInstanceIdInfo(name);
/* 412 */     if (info != 0) {
/* 413 */       if (start == this && isSealed()) {
/* 414 */         throw Context.reportRuntimeErrorById("msg.modify.sealed", new Object[] { name });
/*     */       }
/* 416 */       int attr = info >>> 16;
/* 417 */       if ((attr & 0x1) == 0) {
/* 418 */         if (start == this) {
/* 419 */           int id = info & 0xFFFF;
/* 420 */           setInstanceIdValue(id, value);
/*     */         } else {
/* 422 */           start.put(name, start, value);
/*     */         } 
/*     */       }
/*     */       return;
/*     */     } 
/* 427 */     if (this.prototypeValues != null) {
/* 428 */       int id = this.prototypeValues.findId(name);
/* 429 */       if (id != 0) {
/* 430 */         if (start == this && isSealed()) {
/* 431 */           throw Context.reportRuntimeErrorById("msg.modify.sealed", new Object[] { name });
/*     */         }
/* 433 */         this.prototypeValues.set(id, start, value);
/*     */         return;
/*     */       } 
/*     */     } 
/* 437 */     super.put(name, start, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(Symbol key, Scriptable start, Object value) {
/* 442 */     int info = findInstanceIdInfo(key);
/* 443 */     if (info != 0) {
/* 444 */       if (start == this && isSealed()) {
/* 445 */         throw Context.reportRuntimeErrorById("msg.modify.sealed", new Object[0]);
/*     */       }
/* 447 */       int attr = info >>> 16;
/* 448 */       if ((attr & 0x1) == 0) {
/* 449 */         if (start == this) {
/* 450 */           int id = info & 0xFFFF;
/* 451 */           setInstanceIdValue(id, value);
/*     */         } else {
/* 453 */           ensureSymbolScriptable(start).put(key, start, value);
/*     */         } 
/*     */       }
/*     */       return;
/*     */     } 
/* 458 */     if (this.prototypeValues != null) {
/* 459 */       int id = this.prototypeValues.findId(key);
/* 460 */       if (id != 0) {
/* 461 */         if (start == this && isSealed()) {
/* 462 */           throw Context.reportRuntimeErrorById("msg.modify.sealed", new Object[0]);
/*     */         }
/* 464 */         this.prototypeValues.set(id, start, value);
/*     */         return;
/*     */       } 
/*     */     } 
/* 468 */     super.put(key, start, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(String name) {
/* 473 */     int info = findInstanceIdInfo(name);
/* 474 */     if (info != 0)
/*     */     {
/* 476 */       if (!isSealed()) {
/* 477 */         int attr = info >>> 16;
/*     */         
/* 479 */         if ((attr & 0x4) != 0) {
/* 480 */           Context cx = Context.getContext();
/* 481 */           if (cx.isStrictMode()) {
/* 482 */             throw ScriptRuntime.typeErrorById("msg.delete.property.with.configurable.false", new Object[] { name });
/*     */           }
/*     */         } else {
/*     */           
/* 486 */           int id = info & 0xFFFF;
/* 487 */           setInstanceIdValue(id, NOT_FOUND);
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     }
/* 492 */     if (this.prototypeValues != null) {
/* 493 */       int id = this.prototypeValues.findId(name);
/* 494 */       if (id != 0) {
/* 495 */         if (!isSealed()) {
/* 496 */           this.prototypeValues.delete(id);
/*     */         }
/*     */         return;
/*     */       } 
/*     */     } 
/* 501 */     super.delete(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(Symbol key) {
/* 506 */     int info = findInstanceIdInfo(key);
/* 507 */     if (info != 0)
/*     */     {
/* 509 */       if (!isSealed()) {
/* 510 */         int attr = info >>> 16;
/*     */         
/* 512 */         if ((attr & 0x4) != 0) {
/* 513 */           Context cx = Context.getContext();
/* 514 */           if (cx.isStrictMode()) {
/* 515 */             throw ScriptRuntime.typeErrorById("msg.delete.property.with.configurable.false", new Object[0]);
/*     */           }
/*     */         } else {
/*     */           
/* 519 */           int id = info & 0xFFFF;
/* 520 */           setInstanceIdValue(id, NOT_FOUND);
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     }
/* 525 */     if (this.prototypeValues != null) {
/* 526 */       int id = this.prototypeValues.findId(key);
/* 527 */       if (id != 0) {
/* 528 */         if (!isSealed()) {
/* 529 */           this.prototypeValues.delete(id);
/*     */         }
/*     */         return;
/*     */       } 
/*     */     } 
/* 534 */     super.delete(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAttributes(String name) {
/* 539 */     int info = findInstanceIdInfo(name);
/* 540 */     if (info != 0) {
/* 541 */       int attr = info >>> 16;
/* 542 */       return attr;
/*     */     } 
/* 544 */     if (this.prototypeValues != null) {
/* 545 */       int id = this.prototypeValues.findId(name);
/* 546 */       if (id != 0) {
/* 547 */         return this.prototypeValues.getAttributes(id);
/*     */       }
/*     */     } 
/* 550 */     return super.getAttributes(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAttributes(Symbol key) {
/* 555 */     int info = findInstanceIdInfo(key);
/* 556 */     if (info != 0) {
/* 557 */       int attr = info >>> 16;
/* 558 */       return attr;
/*     */     } 
/* 560 */     if (this.prototypeValues != null) {
/* 561 */       int id = this.prototypeValues.findId(key);
/* 562 */       if (id != 0) {
/* 563 */         return this.prototypeValues.getAttributes(id);
/*     */       }
/*     */     } 
/* 566 */     return super.getAttributes(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttributes(String name, int attributes) {
/* 571 */     ScriptableObject.checkValidAttributes(attributes);
/* 572 */     int info = findInstanceIdInfo(name);
/* 573 */     if (info != 0) {
/* 574 */       int id = info & 0xFFFF;
/* 575 */       int currentAttributes = info >>> 16;
/* 576 */       if (attributes != currentAttributes) {
/* 577 */         setInstanceIdAttributes(id, attributes);
/*     */       }
/*     */       return;
/*     */     } 
/* 581 */     if (this.prototypeValues != null) {
/* 582 */       int id = this.prototypeValues.findId(name);
/* 583 */       if (id != 0) {
/* 584 */         this.prototypeValues.setAttributes(id, attributes);
/*     */         return;
/*     */       } 
/*     */     } 
/* 588 */     super.setAttributes(name, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   Object[] getIds(boolean getNonEnumerable, boolean getSymbols) {
/* 593 */     Object[] result = super.getIds(getNonEnumerable, getSymbols);
/*     */     
/* 595 */     if (this.prototypeValues != null) {
/* 596 */       result = this.prototypeValues.getNames(getNonEnumerable, getSymbols, result);
/*     */     }
/*     */     
/* 599 */     int maxInstanceId = getMaxInstanceId();
/* 600 */     if (maxInstanceId != 0) {
/* 601 */       Object[] ids = null;
/* 602 */       int count = 0;
/*     */       
/* 604 */       for (int id = maxInstanceId; id != 0; id--) {
/* 605 */         String name = getInstanceIdName(id);
/* 606 */         int info = findInstanceIdInfo(name);
/* 607 */         if (info != 0) {
/* 608 */           int attr = info >>> 16;
/* 609 */           if ((attr & 0x4) != 0 || 
/* 610 */             NOT_FOUND != getInstanceIdValue(id))
/*     */           {
/*     */ 
/*     */             
/* 614 */             if (getNonEnumerable || (attr & 0x2) == 0) {
/* 615 */               if (count == 0)
/*     */               {
/* 617 */                 ids = new Object[id];
/*     */               }
/* 619 */               ids[count++] = name;
/*     */             }  } 
/*     */         } 
/*     */       } 
/* 623 */       if (count != 0) {
/* 624 */         if (result.length == 0 && ids.length == count) {
/* 625 */           result = ids;
/*     */         } else {
/* 627 */           Object[] tmp = new Object[result.length + count];
/* 628 */           System.arraycopy(result, 0, tmp, 0, result.length);
/* 629 */           System.arraycopy(ids, 0, tmp, result.length, count);
/* 630 */           result = tmp;
/*     */         } 
/*     */       }
/*     */     } 
/* 634 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getMaxInstanceId() {
/* 639 */     return 0;
/*     */   }
/*     */   
/*     */   protected static int instanceIdInfo(int attributes, int id) {
/* 643 */     return attributes << 16 | id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(String name) {
/* 651 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(Symbol key) {
/* 659 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/* 664 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/* 673 */     throw new IllegalStateException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setInstanceIdValue(int id, Object value) {
/* 681 */     throw new IllegalStateException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setInstanceIdAttributes(int id, int attr) {
/* 693 */     throw ScriptRuntime.constructError("InternalError", "Changing attributes not supported for " + 
/*     */ 
/*     */         
/* 696 */         getClassName() + " " + 
/*     */         
/* 698 */         getInstanceIdName(id) + " property");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 709 */     throw f.unknown();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final IdFunctionObject exportAsJSClass(int maxPrototypeId, Scriptable scope, boolean sealed) {
/* 715 */     if (scope != this && scope != null) {
/* 716 */       setParentScope(scope);
/* 717 */       setPrototype(getObjectPrototype(scope));
/*     */     } 
/*     */     
/* 720 */     activatePrototypeMap(maxPrototypeId);
/* 721 */     IdFunctionObject ctor = this.prototypeValues.createPrecachedConstructor();
/* 722 */     if (sealed) {
/* 723 */       sealObject();
/*     */     }
/* 725 */     fillConstructorProperties(ctor);
/* 726 */     if (sealed) {
/* 727 */       ctor.sealObject();
/*     */     }
/* 729 */     ctor.exportAsScopeProperty();
/* 730 */     return ctor;
/*     */   }
/*     */   
/*     */   public final boolean hasPrototypeMap() {
/* 734 */     return (this.prototypeValues != null);
/*     */   }
/*     */   
/*     */   public final void activatePrototypeMap(int maxPrototypeId) {
/* 738 */     PrototypeValues values = new PrototypeValues(this, maxPrototypeId);
/* 739 */     synchronized (this) {
/* 740 */       if (this.prototypeValues != null) throw new IllegalStateException(); 
/* 741 */       this.prototypeValues = values;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final IdFunctionObject initPrototypeMethod(Object tag, int id, String name, int arity) {
/* 746 */     return initPrototypeMethod(tag, id, name, name, arity);
/*     */   }
/*     */ 
/*     */   
/*     */   public final IdFunctionObject initPrototypeMethod(Object tag, int id, String propertyName, String functionName, int arity) {
/* 751 */     Scriptable scope = ScriptableObject.getTopLevelScope(this);
/*     */     
/* 753 */     IdFunctionObject function = newIdFunction(tag, id, (functionName != null) ? functionName : propertyName, arity, scope);
/*     */     
/* 755 */     this.prototypeValues.initValue(id, propertyName, function, 2);
/* 756 */     return function;
/*     */   }
/*     */ 
/*     */   
/*     */   public final IdFunctionObject initPrototypeMethod(Object tag, int id, Symbol key, String functionName, int arity) {
/* 761 */     Scriptable scope = ScriptableObject.getTopLevelScope(this);
/* 762 */     IdFunctionObject function = newIdFunction(tag, id, functionName, arity, scope);
/* 763 */     this.prototypeValues.initValue(id, key, function, 2);
/* 764 */     return function;
/*     */   }
/*     */   
/*     */   public final void initPrototypeConstructor(IdFunctionObject f) {
/* 768 */     int id = this.prototypeValues.constructorId;
/* 769 */     if (id == 0) throw new IllegalStateException(); 
/* 770 */     if (f.methodId() != id) throw new IllegalArgumentException(); 
/* 771 */     if (isSealed()) {
/* 772 */       f.sealObject();
/*     */     }
/* 774 */     this.prototypeValues.initValue(id, "constructor", f, 2);
/*     */   }
/*     */   
/*     */   public final void initPrototypeValue(int id, String name, Object value, int attributes) {
/* 778 */     this.prototypeValues.initValue(id, name, value, attributes);
/*     */   }
/*     */   
/*     */   public final void initPrototypeValue(int id, Symbol key, Object value, int attributes) {
/* 782 */     this.prototypeValues.initValue(id, key, value, attributes);
/*     */   }
/*     */   
/*     */   protected void initPrototypeId(int id) {
/* 786 */     throw new IllegalStateException(String.valueOf(id));
/*     */   }
/*     */   
/*     */   protected int findPrototypeId(String name) {
/* 790 */     throw new IllegalStateException(name);
/*     */   }
/*     */   
/*     */   protected int findPrototypeId(Symbol key) {
/* 794 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {}
/*     */   
/*     */   protected void addIdFunctionProperty(Scriptable obj, Object tag, int id, String name, int arity) {
/* 801 */     Scriptable scope = ScriptableObject.getTopLevelScope(obj);
/* 802 */     IdFunctionObject f = newIdFunction(tag, id, name, arity, scope);
/* 803 */     f.addAsProperty(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <T> T ensureType(Object obj, Class<T> clazz, IdFunctionObject f) {
/* 825 */     if (clazz.isInstance(obj)) {
/* 826 */       return (T)obj;
/*     */     }
/* 828 */     if (obj == null) {
/* 829 */       throw ScriptRuntime.typeErrorById("msg.incompat.call.details", new Object[] { f
/* 830 */             .getFunctionName(), "null", clazz.getName() });
/*     */     }
/* 832 */     throw ScriptRuntime.typeErrorById("msg.incompat.call.details", new Object[] { f
/*     */           
/* 834 */           .getFunctionName(), obj
/* 835 */           .getClass().getName(), clazz
/* 836 */           .getName() });
/*     */   }
/*     */ 
/*     */   
/*     */   private IdFunctionObject newIdFunction(Object tag, int id, String name, int arity, Scriptable scope) {
/* 841 */     IdFunctionObject function = null;
/* 842 */     if (Context.getContext().getLanguageVersion() < 200) {
/* 843 */       function = new IdFunctionObject(this, tag, id, name, arity, scope);
/*     */     } else {
/* 845 */       function = new IdFunctionObjectES6(this, tag, id, name, arity, scope);
/*     */     } 
/*     */     
/* 848 */     if (isSealed()) {
/* 849 */       function.sealObject();
/*     */     }
/* 851 */     return function;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void defineOwnProperty(Context cx, Object key, ScriptableObject desc, boolean checkValid) {
/* 857 */     if (key instanceof String) {
/* 858 */       String name = (String)key;
/* 859 */       int info = findInstanceIdInfo(name);
/* 860 */       if (info != 0) {
/* 861 */         int id = info & 0xFFFF;
/* 862 */         if (isAccessorDescriptor(desc)) {
/* 863 */           delete(id);
/*     */         } else {
/* 865 */           checkPropertyDefinition(desc);
/* 866 */           ScriptableObject current = getOwnPropertyDescriptor(cx, key);
/* 867 */           checkPropertyChange(name, current, desc);
/* 868 */           int attr = info >>> 16;
/* 869 */           Object value = getProperty(desc, "value");
/* 870 */           if (value != NOT_FOUND && (attr & 0x1) == 0) {
/* 871 */             Object currentValue = getInstanceIdValue(id);
/* 872 */             if (!sameValue(value, currentValue)) {
/* 873 */               setInstanceIdValue(id, value);
/*     */             }
/*     */           } 
/* 876 */           setAttributes(name, applyDescriptorToAttributeBitset(attr, desc));
/*     */           return;
/*     */         } 
/*     */       } 
/* 880 */       if (this.prototypeValues != null) {
/* 881 */         int id = this.prototypeValues.findId(name);
/* 882 */         if (id != 0) {
/* 883 */           if (isAccessorDescriptor(desc)) {
/* 884 */             this.prototypeValues.delete(id);
/*     */           } else {
/* 886 */             checkPropertyDefinition(desc);
/* 887 */             ScriptableObject current = getOwnPropertyDescriptor(cx, key);
/* 888 */             checkPropertyChange(name, current, desc);
/* 889 */             int attr = this.prototypeValues.getAttributes(id);
/* 890 */             Object value = getProperty(desc, "value");
/* 891 */             if (value != NOT_FOUND && (attr & 0x1) == 0) {
/* 892 */               Object currentValue = this.prototypeValues.get(id);
/* 893 */               if (!sameValue(value, currentValue)) {
/* 894 */                 this.prototypeValues.set(id, this, value);
/*     */               }
/*     */             } 
/* 897 */             this.prototypeValues.setAttributes(id, 
/* 898 */                 applyDescriptorToAttributeBitset(attr, desc));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 903 */             if (super.has(name, this)) {
/* 904 */               super.delete(name);
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 912 */     super.defineOwnProperty(cx, key, desc, checkValid);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ScriptableObject getOwnPropertyDescriptor(Context cx, Object id) {
/* 917 */     ScriptableObject desc = super.getOwnPropertyDescriptor(cx, id);
/* 918 */     if (desc == null) {
/* 919 */       if (id instanceof String) {
/* 920 */         desc = getBuiltInDescriptor((String)id);
/* 921 */       } else if (ScriptRuntime.isSymbol(id)) {
/* 922 */         desc = getBuiltInDescriptor(((NativeSymbol)id).getKey());
/*     */       } 
/*     */     }
/* 925 */     return desc;
/*     */   }
/*     */   
/*     */   private ScriptableObject getBuiltInDescriptor(String name) {
/* 929 */     Object value = null;
/* 930 */     int attr = 0;
/*     */     
/* 932 */     Scriptable scope = getParentScope();
/* 933 */     if (scope == null) {
/* 934 */       scope = this;
/*     */     }
/*     */     
/* 937 */     int info = findInstanceIdInfo(name);
/* 938 */     if (info != 0) {
/* 939 */       int id = info & 0xFFFF;
/* 940 */       value = getInstanceIdValue(id);
/* 941 */       attr = info >>> 16;
/* 942 */       return buildDataDescriptor(scope, value, attr);
/*     */     } 
/* 944 */     if (this.prototypeValues != null) {
/* 945 */       int id = this.prototypeValues.findId(name);
/* 946 */       if (id != 0) {
/* 947 */         value = this.prototypeValues.get(id);
/* 948 */         attr = this.prototypeValues.getAttributes(id);
/* 949 */         return buildDataDescriptor(scope, value, attr);
/*     */       } 
/*     */     } 
/* 952 */     return null;
/*     */   }
/*     */   
/*     */   private ScriptableObject getBuiltInDescriptor(Symbol key) {
/* 956 */     Object value = null;
/* 957 */     int attr = 0;
/*     */     
/* 959 */     Scriptable scope = getParentScope();
/* 960 */     if (scope == null) {
/* 961 */       scope = this;
/*     */     }
/*     */     
/* 964 */     if (this.prototypeValues != null) {
/* 965 */       int id = this.prototypeValues.findId(key);
/* 966 */       if (id != 0) {
/* 967 */         value = this.prototypeValues.get(id);
/* 968 */         attr = this.prototypeValues.getAttributes(id);
/* 969 */         return buildDataDescriptor(scope, value, attr);
/*     */       } 
/*     */     } 
/* 972 */     return null;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 976 */     stream.defaultReadObject();
/* 977 */     int maxPrototypeId = stream.readInt();
/* 978 */     if (maxPrototypeId != 0) {
/* 979 */       activatePrototypeMap(maxPrototypeId);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 984 */     stream.defaultWriteObject();
/* 985 */     int maxPrototypeId = 0;
/* 986 */     if (this.prototypeValues != null) {
/* 987 */       maxPrototypeId = this.prototypeValues.getMaxId();
/*     */     }
/* 989 */     stream.writeInt(maxPrototypeId);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\IdScriptableObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */