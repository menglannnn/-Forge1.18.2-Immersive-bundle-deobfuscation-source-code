/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaClass
/*     */   extends NativeJavaObject
/*     */   implements Function
/*     */ {
/*     */   private static final long serialVersionUID = -6460763940409461664L;
/*     */   static final String javaClassPropertyName = "__javaObject__";
/*     */   private Map<String, FieldAndMethods> staticFieldAndMethods;
/*     */   
/*     */   public NativeJavaClass() {}
/*     */   
/*     */   public NativeJavaClass(Scriptable scope, Class<?> cl) {
/*  40 */     this(scope, cl, false);
/*     */   }
/*     */   
/*     */   public NativeJavaClass(Scriptable scope, Class<?> cl, boolean isAdapter) {
/*  44 */     super(scope, cl, (Class<?>)null, isAdapter);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initMembers() {
/*  49 */     Class<?> cl = (Class)this.javaObject;
/*  50 */     this.members = JavaMembers.lookupClass(this.parent, cl, cl, this.isAdapter);
/*  51 */     this.staticFieldAndMethods = this.members.getFieldAndMethodsObjects(this, cl, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  56 */     return "JavaClass";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(String name, Scriptable start) {
/*  61 */     return (this.members.has(name, true) || "__javaObject__".equals(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String name, Scriptable start) {
/*  70 */     if (name.equals("prototype")) {
/*  71 */       return null;
/*     */     }
/*  73 */     if (this.staticFieldAndMethods != null) {
/*  74 */       Object result = this.staticFieldAndMethods.get(name);
/*  75 */       if (result != null) {
/*  76 */         return result;
/*     */       }
/*     */     } 
/*  79 */     if (this.members.has(name, true)) {
/*  80 */       return this.members.get(this, name, this.javaObject, true);
/*     */     }
/*     */     
/*  83 */     Context cx = Context.getContext();
/*  84 */     Scriptable scope = ScriptableObject.getTopLevelScope(start);
/*  85 */     WrapFactory wrapFactory = cx.getWrapFactory();
/*     */     
/*  87 */     if ("__javaObject__".equals(name)) {
/*  88 */       return wrapFactory.wrap(cx, scope, this.javaObject, ScriptRuntime.ClassClass);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     Class<?> nestedClass = findNestedClass(getClassObject(), name);
/*  95 */     if (nestedClass != null) {
/*  96 */       Scriptable nestedValue = wrapFactory.wrapJavaClass(cx, scope, nestedClass);
/*     */       
/*  98 */       nestedValue.setParentScope(this);
/*  99 */       return nestedValue;
/*     */     } 
/*     */     
/* 102 */     throw this.members.reportMemberNotFound(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String name, Scriptable start, Object value) {
/* 107 */     this.members.put(this, name, this.javaObject, value, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 112 */     return this.members.getIds(true);
/*     */   }
/*     */   
/*     */   public Class<?> getClassObject() {
/* 116 */     return (Class)unwrap();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class<?> hint) {
/* 121 */     if (hint == null || hint == ScriptRuntime.StringClass)
/* 122 */       return toString(); 
/* 123 */     if (hint == ScriptRuntime.BooleanClass)
/* 124 */       return Boolean.TRUE; 
/* 125 */     if (hint == ScriptRuntime.NumberClass)
/* 126 */       return ScriptRuntime.NaNobj; 
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 137 */     if (args.length == 1 && args[0] instanceof Scriptable) {
/* 138 */       Class<?> c = getClassObject();
/* 139 */       Scriptable p = (Scriptable)args[0];
/*     */       do {
/* 141 */         if (p instanceof Wrapper) {
/* 142 */           Object o = ((Wrapper)p).unwrap();
/* 143 */           if (c.isInstance(o))
/* 144 */             return p; 
/*     */         } 
/* 146 */         p = p.getPrototype();
/* 147 */       } while (p != null);
/*     */     } 
/* 149 */     return construct(cx, scope, args);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/* 155 */     Class<?> classObject = getClassObject();
/* 156 */     int modifiers = classObject.getModifiers();
/* 157 */     if (!Modifier.isInterface(modifiers) && 
/* 158 */       !Modifier.isAbstract(modifiers)) {
/*     */       
/* 160 */       NativeJavaMethod ctors = this.members.ctors;
/* 161 */       int index = ctors.findCachedFunction(cx, args);
/* 162 */       if (index < 0) {
/* 163 */         String sig = NativeJavaMethod.scriptSignature(args);
/* 164 */         throw Context.reportRuntimeErrorById("msg.no.java.ctor", new Object[] { classObject
/* 165 */               .getName(), sig });
/*     */       } 
/*     */ 
/*     */       
/* 169 */       return constructSpecific(cx, scope, args, ctors.methods[index]);
/*     */     } 
/* 171 */     if (args.length == 0) {
/* 172 */       throw Context.reportRuntimeErrorById("msg.adapter.zero.args", new Object[0]);
/*     */     }
/* 174 */     Scriptable topLevel = ScriptableObject.getTopLevelScope(this);
/* 175 */     String msg = "";
/*     */ 
/*     */     
/*     */     try {
/* 179 */       if ("Dalvik".equals(System.getProperty("java.vm.name")) && classObject
/* 180 */         .isInterface()) {
/* 181 */         Object obj = createInterfaceAdapter(classObject, 
/* 182 */             ScriptableObject.ensureScriptableObject(args[0]));
/* 183 */         return cx.getWrapFactory().wrapAsJavaObject(cx, scope, obj, null);
/*     */       } 
/*     */ 
/*     */       
/* 187 */       Object v = topLevel.get("JavaAdapter", topLevel);
/* 188 */       if (v != NOT_FOUND) {
/* 189 */         Function f = (Function)v;
/*     */         
/* 191 */         Object[] adapterArgs = { this, args[0] };
/* 192 */         return f.construct(cx, topLevel, adapterArgs);
/*     */       } 
/* 194 */     } catch (Exception ex) {
/*     */       
/* 196 */       String m = ex.getMessage();
/* 197 */       if (m != null)
/* 198 */         msg = m; 
/*     */     } 
/* 200 */     throw Context.reportRuntimeErrorById("msg.cant.instantiate", new Object[] { msg, classObject
/* 201 */           .getName() });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Scriptable constructSpecific(Context cx, Scriptable scope, Object[] args, MemberBox ctor) {
/* 207 */     Object instance = constructInternal(args, ctor);
/*     */ 
/*     */     
/* 210 */     Scriptable topLevel = ScriptableObject.getTopLevelScope(scope);
/* 211 */     return cx.getWrapFactory().wrapNewObject(cx, topLevel, instance);
/*     */   }
/*     */ 
/*     */   
/*     */   static Object constructInternal(Object[] args, MemberBox ctor) {
/* 216 */     Class<?>[] argTypes = ctor.argTypes;
/*     */     
/* 218 */     if (ctor.vararg) {
/*     */       
/* 220 */       Object varArgs, newArgs[] = new Object[argTypes.length];
/* 221 */       for (int i = 0; i < argTypes.length - 1; i++) {
/* 222 */         newArgs[i] = Context.jsToJava(args[i], argTypes[i]);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 229 */       if (args.length == argTypes.length && (args[args.length - 1] == null || args[args.length - 1] instanceof NativeArray || args[args.length - 1] instanceof NativeJavaArray)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 235 */         varArgs = Context.jsToJava(args[args.length - 1], argTypes[argTypes.length - 1]);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 240 */         Class<?> componentType = argTypes[argTypes.length - 1].getComponentType();
/* 241 */         varArgs = Array.newInstance(componentType, args.length - argTypes.length + 1);
/*     */         
/* 243 */         for (int j = 0; j < Array.getLength(varArgs); j++) {
/* 244 */           Object value = Context.jsToJava(args[argTypes.length - 1 + j], componentType);
/*     */           
/* 246 */           Array.set(varArgs, j, value);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 251 */       newArgs[argTypes.length - 1] = varArgs;
/*     */       
/* 253 */       args = newArgs;
/*     */     } else {
/* 255 */       Object[] origArgs = args;
/* 256 */       for (int i = 0; i < args.length; i++) {
/* 257 */         Object arg = args[i];
/* 258 */         Object x = Context.jsToJava(arg, argTypes[i]);
/* 259 */         if (x != arg) {
/* 260 */           if (args == origArgs) {
/* 261 */             args = (Object[])origArgs.clone();
/*     */           }
/* 263 */           args[i] = x;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 268 */     return ctor.newInstance(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 273 */     return "[JavaClass " + getClassObject().getName() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasInstance(Scriptable value) {
/* 287 */     if (value instanceof Wrapper && !(value instanceof NativeJavaClass)) {
/*     */       
/* 289 */       Object instance = ((Wrapper)value).unwrap();
/*     */       
/* 291 */       return getClassObject().isInstance(instance);
/*     */     } 
/*     */ 
/*     */     
/* 295 */     return false;
/*     */   }
/*     */   
/*     */   private static Class<?> findNestedClass(Class<?> parentClass, String name) {
/* 299 */     String nestedClassName = parentClass.getName() + '$' + name;
/* 300 */     ClassLoader loader = parentClass.getClassLoader();
/* 301 */     if (loader == null)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 306 */       return Kit.classOrNull(nestedClassName);
/*     */     }
/* 308 */     return Kit.classOrNull(loader, nestedClassName);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeJavaClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */