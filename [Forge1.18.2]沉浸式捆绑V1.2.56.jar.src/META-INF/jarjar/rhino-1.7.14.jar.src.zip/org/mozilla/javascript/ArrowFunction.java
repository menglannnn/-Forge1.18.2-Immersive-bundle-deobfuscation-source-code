/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrowFunction
/*    */   extends BaseFunction
/*    */ {
/*    */   private static final long serialVersionUID = -7377989503697220633L;
/*    */   private final Callable targetFunction;
/*    */   private final Scriptable boundThis;
/*    */   
/*    */   public ArrowFunction(Context cx, Scriptable scope, Callable targetFunction, Scriptable boundThis) {
/* 22 */     this.targetFunction = targetFunction;
/* 23 */     this.boundThis = boundThis;
/*    */     
/* 25 */     ScriptRuntime.setFunctionProtoAndParent(this, scope);
/*    */     
/* 27 */     Function thrower = ScriptRuntime.typeErrorThrower(cx);
/* 28 */     NativeObject throwing = new NativeObject();
/* 29 */     throwing.put("get", throwing, thrower);
/* 30 */     throwing.put("set", throwing, thrower);
/* 31 */     throwing.put("enumerable", throwing, Boolean.FALSE);
/* 32 */     throwing.put("configurable", throwing, Boolean.FALSE);
/* 33 */     throwing.preventExtensions();
/*    */     
/* 35 */     defineOwnProperty(cx, "caller", throwing, false);
/* 36 */     defineOwnProperty(cx, "arguments", throwing, false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 42 */     Scriptable callThis = (this.boundThis != null) ? this.boundThis : ScriptRuntime.getTopCallScope(cx);
/* 43 */     return this.targetFunction.call(cx, scope, callThis, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/* 48 */     throw ScriptRuntime.typeErrorById("msg.not.ctor", new Object[] { decompile(0, 0) });
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasInstance(Scriptable instance) {
/* 53 */     if (this.targetFunction instanceof Function) {
/* 54 */       return ((Function)this.targetFunction).hasInstance(instance);
/*    */     }
/* 56 */     throw ScriptRuntime.typeErrorById("msg.not.ctor", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 61 */     if (this.targetFunction instanceof BaseFunction) {
/* 62 */       return ((BaseFunction)this.targetFunction).getLength();
/*    */     }
/* 64 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getArity() {
/* 69 */     return getLength();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   String decompile(int indent, int flags) {
/* 75 */     if (this.targetFunction instanceof BaseFunction) {
/* 76 */       return ((BaseFunction)this.targetFunction).decompile(indent, flags);
/*    */     }
/* 78 */     return super.decompile(indent, flags);
/*    */   }
/*    */   
/*    */   static boolean equalObjectGraphs(ArrowFunction f1, ArrowFunction f2, EqualObjectGraphs eq) {
/* 82 */     return (eq.equalGraphs(f1.boundThis, f2.boundThis) && eq.equalGraphs(f1.targetFunction, f2.targetFunction));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ArrowFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */