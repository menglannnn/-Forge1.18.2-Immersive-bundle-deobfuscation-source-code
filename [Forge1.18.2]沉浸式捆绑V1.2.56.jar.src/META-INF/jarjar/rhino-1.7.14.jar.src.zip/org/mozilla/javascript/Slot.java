/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Slot
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6090581677123995491L;
/*     */   Object name;
/*     */   int indexOrHash;
/*     */   private short attributes;
/*     */   Object value;
/*     */   transient Slot next;
/*     */   transient Slot orderedNext;
/*     */   
/*     */   Slot(Object name, int indexOrHash, int attributes) {
/*  23 */     this.name = name;
/*  24 */     this.indexOrHash = indexOrHash;
/*  25 */     this.attributes = (short)attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isValueSlot() {
/*  33 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetterSlot() {
/*  40 */     return false;
/*     */   }
/*     */   
/*     */   protected Slot(Slot oldSlot) {
/*  44 */     this.name = oldSlot.name;
/*  45 */     this.indexOrHash = oldSlot.indexOrHash;
/*  46 */     this.attributes = oldSlot.attributes;
/*  47 */     this.value = oldSlot.value;
/*  48 */     this.next = oldSlot.next;
/*  49 */     this.orderedNext = oldSlot.orderedNext;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/*  53 */     in.defaultReadObject();
/*  54 */     if (this.name != null) {
/*  55 */       this.indexOrHash = this.name.hashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean setValue(Object value, Scriptable owner, Scriptable start) {
/*  60 */     if ((this.attributes & 0x1) != 0) {
/*  61 */       if (Context.isCurrentContextStrict()) {
/*  62 */         throw ScriptRuntime.typeErrorById("msg.modify.readonly", new Object[] { this.name });
/*     */       }
/*  64 */       return true;
/*     */     } 
/*  66 */     if (owner == start) {
/*  67 */       this.value = value;
/*  68 */       return true;
/*     */     } 
/*  70 */     return false;
/*     */   }
/*     */   
/*     */   public Object getValue(Scriptable start) {
/*  74 */     return this.value;
/*     */   }
/*     */   
/*     */   int getAttributes() {
/*  78 */     return this.attributes;
/*     */   }
/*     */   
/*     */   synchronized void setAttributes(int value) {
/*  82 */     ScriptableObject.checkValidAttributes(value);
/*  83 */     this.attributes = (short)value;
/*     */   }
/*     */   
/*     */   ScriptableObject getPropertyDescriptor(Context cx, Scriptable scope) {
/*  87 */     return ScriptableObject.buildDataDescriptor(scope, this.value, this.attributes);
/*     */   }
/*     */   
/*     */   protected void throwNoSetterException(Scriptable start, Object newValue) {
/*  91 */     Context cx = Context.getContext();
/*  92 */     if (cx.isStrictMode() || cx
/*     */ 
/*     */ 
/*     */       
/*  96 */       .hasFeature(11)) {
/*     */       
/*  98 */       String prop = "";
/*  99 */       if (this.name != null) {
/* 100 */         prop = "[" + start.getClassName() + "]." + this.name;
/*     */       }
/* 102 */       throw ScriptRuntime.typeErrorById("msg.set.prop.no.setter", new Object[] { prop, 
/* 103 */             Context.toString(newValue) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Function getSetterFunction(String name, Scriptable scope) {
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   Function getGetterFunction(String name, Scriptable scope) {
/* 117 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Slot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */