/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImporterTopLevel
/*     */   extends TopLevel
/*     */ {
/*     */   private static final long serialVersionUID = -9095380847465315412L;
/*  48 */   private static final Object IMPORTER_TAG = "Importer"; private static final int Id_constructor = 1;
/*     */   private static final int Id_importClass = 2;
/*     */   private static final int Id_importPackage = 3;
/*     */   
/*     */   public ImporterTopLevel(Context cx) {
/*  53 */     this(cx, false);
/*     */   } private static final int MAX_PROTOTYPE_ID = 3; private static final String AKEY = "importedPackages"; private boolean topScopeFlag;
/*     */   public ImporterTopLevel() {}
/*     */   public ImporterTopLevel(Context cx, boolean sealed) {
/*  57 */     initStandardObjects(cx, sealed);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  62 */     return this.topScopeFlag ? "global" : "JavaImporter";
/*     */   }
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  66 */     ImporterTopLevel obj = new ImporterTopLevel();
/*  67 */     obj.exportAsJSClass(3, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initStandardObjects(Context cx, boolean sealed) {
/*  73 */     cx.initStandardObjects(this, sealed);
/*  74 */     this.topScopeFlag = true;
/*     */ 
/*     */ 
/*     */     
/*  78 */     IdFunctionObject ctor = exportAsJSClass(3, this, false);
/*  79 */     if (sealed) {
/*  80 */       ctor.sealObject();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  85 */     delete("constructor");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(String name, Scriptable start) {
/*  90 */     return (super.has(name, start) || getPackageProperty(name, start) != NOT_FOUND);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String name, Scriptable start) {
/*  95 */     Object result = super.get(name, start);
/*  96 */     if (result != NOT_FOUND) return result; 
/*  97 */     result = getPackageProperty(name, start);
/*  98 */     return result;
/*     */   }
/*     */   
/*     */   private Object getPackageProperty(String name, Scriptable start) {
/* 102 */     Object result = NOT_FOUND;
/* 103 */     Scriptable scope = start;
/* 104 */     if (this.topScopeFlag) {
/* 105 */       scope = ScriptableObject.getTopLevelScope(scope);
/*     */     }
/* 107 */     Object[] elements = getNativeJavaPackages(scope);
/* 108 */     if (elements == null) {
/* 109 */       return result;
/*     */     }
/* 111 */     for (int i = 0; i < elements.length; i++) {
/* 112 */       NativeJavaPackage p = (NativeJavaPackage)elements[i];
/* 113 */       Object v = p.getPkgProperty(name, start, false);
/* 114 */       if (v != null && !(v instanceof NativeJavaPackage)) {
/* 115 */         if (result == NOT_FOUND) {
/* 116 */           result = v;
/*     */         } else {
/* 118 */           throw Context.reportRuntimeErrorById("msg.ambig.import", new Object[] { result
/* 119 */                 .toString(), v.toString() });
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 124 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object[] getNativeJavaPackages(Scriptable scope) {
/* 129 */     synchronized (scope) {
/* 130 */       if (scope instanceof ScriptableObject) {
/* 131 */         ScriptableObject so = (ScriptableObject)scope;
/* 132 */         ObjArray importedPackages = (ObjArray)so.getAssociatedValue("importedPackages");
/* 133 */         if (importedPackages != null) {
/* 134 */           return importedPackages.toArray();
/*     */         }
/*     */       } 
/*     */     } 
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void importPackage(Context cx, Scriptable thisObj, Object[] args, Function funObj) {
/* 144 */     js_importPackage(this, args);
/*     */   }
/*     */   
/*     */   private Object js_construct(Scriptable scope, Object[] args) {
/* 148 */     ImporterTopLevel result = new ImporterTopLevel();
/* 149 */     for (int i = 0; i != args.length; i++) {
/* 150 */       Object arg = args[i];
/* 151 */       if (arg instanceof NativeJavaClass) {
/* 152 */         importClass(result, (NativeJavaClass)arg);
/* 153 */       } else if (arg instanceof NativeJavaPackage) {
/* 154 */         importPackage(result, (NativeJavaPackage)arg);
/*     */       } else {
/* 156 */         throw Context.reportRuntimeErrorById("msg.not.class.not.pkg", new Object[] {
/* 157 */               Context.toString(arg)
/*     */             });
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     result.setParentScope(scope);
/* 166 */     result.setPrototype(this);
/* 167 */     return result;
/*     */   }
/*     */   
/*     */   private static Object js_importClass(Scriptable scope, Object[] args) {
/* 171 */     for (int i = 0; i != args.length; i++) {
/* 172 */       Object arg = args[i];
/* 173 */       if (!(arg instanceof NativeJavaClass)) {
/* 174 */         throw Context.reportRuntimeErrorById("msg.not.class", new Object[] { Context.toString(arg) });
/*     */       }
/* 176 */       importClass(scope, (NativeJavaClass)arg);
/*     */     } 
/* 178 */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   private static Object js_importPackage(ScriptableObject scope, Object[] args) {
/* 182 */     for (int i = 0; i != args.length; i++) {
/* 183 */       Object arg = args[i];
/* 184 */       if (!(arg instanceof NativeJavaPackage)) {
/* 185 */         throw Context.reportRuntimeErrorById("msg.not.pkg", new Object[] { Context.toString(arg) });
/*     */       }
/* 187 */       importPackage(scope, (NativeJavaPackage)arg);
/*     */     } 
/* 189 */     return Undefined.instance;
/*     */   }
/*     */   
/*     */   private static void importPackage(ScriptableObject scope, NativeJavaPackage pkg) {
/* 193 */     if (pkg == null) {
/*     */       return;
/*     */     }
/* 196 */     synchronized (scope) {
/* 197 */       ObjArray importedPackages = (ObjArray)scope.getAssociatedValue("importedPackages");
/* 198 */       if (importedPackages == null) {
/* 199 */         importedPackages = new ObjArray();
/* 200 */         scope.associateValue("importedPackages", importedPackages);
/*     */       } 
/* 202 */       for (int j = 0; j != importedPackages.size(); j++) {
/* 203 */         if (pkg.equals(importedPackages.get(j))) {
/*     */           return;
/*     */         }
/*     */       } 
/* 207 */       importedPackages.add(pkg);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void importClass(Scriptable scope, NativeJavaClass cl) {
/* 212 */     String s = cl.getClassObject().getName();
/* 213 */     String n = s.substring(s.lastIndexOf('.') + 1);
/* 214 */     Object val = scope.get(n, scope);
/* 215 */     if (val != NOT_FOUND && val != cl) {
/* 216 */       throw Context.reportRuntimeErrorById("msg.prop.defined", new Object[] { n });
/*     */     }
/*     */     
/* 219 */     scope.put(n, scope, cl);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 226 */     switch (id) {
/*     */       case 1:
/* 228 */         arity = 0;
/* 229 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 232 */         arity = 1;
/* 233 */         s = "importClass";
/*     */         break;
/*     */       case 3:
/* 236 */         arity = 1;
/* 237 */         s = "importPackage";
/*     */         break;
/*     */       default:
/* 240 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 242 */     initPrototypeMethod(IMPORTER_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 248 */     if (!f.hasTag(IMPORTER_TAG)) {
/* 249 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 251 */     int id = f.methodId();
/* 252 */     switch (id) {
/*     */       case 1:
/* 254 */         return js_construct(scope, args);
/*     */       
/*     */       case 2:
/* 257 */         return js_importClass(realScope(scope, thisObj, f), args);
/*     */       
/*     */       case 3:
/* 260 */         return js_importPackage(realScope(scope, thisObj, f), args);
/*     */     } 
/* 262 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */   
/*     */   private ScriptableObject realScope(Scriptable scope, Scriptable thisObj, IdFunctionObject f) {
/* 266 */     if (this.topScopeFlag)
/*     */     {
/*     */ 
/*     */       
/* 270 */       thisObj = ScriptableObject.getTopLevelScope(scope);
/*     */     }
/* 272 */     return ensureType(thisObj, ScriptableObject.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 278 */     switch (s)
/*     */     { case "constructor":
/* 280 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 292 */         return id;case "importClass": id = 2; return id;case "importPackage": id = 3; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ImporterTopLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */