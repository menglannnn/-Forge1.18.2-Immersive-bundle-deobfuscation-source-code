/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefiningClassLoader
/*    */   extends ClassLoader
/*    */   implements GeneratedClassLoader
/*    */ {
/*    */   private final ClassLoader parentLoader;
/*    */   
/*    */   public DefiningClassLoader() {
/* 16 */     this.parentLoader = getClass().getClassLoader();
/*    */   }
/*    */   
/*    */   public DefiningClassLoader(ClassLoader parentLoader) {
/* 20 */     this.parentLoader = parentLoader;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> defineClass(String name, byte[] data) {
/* 28 */     return defineClass(name, data, 0, data.length, 
/* 29 */         SecurityUtilities.getProtectionDomain(getClass()));
/*    */   }
/*    */ 
/*    */   
/*    */   public void linkClass(Class<?> cl) {
/* 34 */     resolveClass(cl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 41 */     Class<?> cl = findLoadedClass(name);
/* 42 */     if (cl == null) {
/* 43 */       if (this.parentLoader != null) {
/* 44 */         cl = this.parentLoader.loadClass(name);
/*    */       } else {
/* 46 */         cl = findSystemClass(name);
/*    */       } 
/*    */     }
/* 49 */     if (resolve) {
/* 50 */       resolveClass(cl);
/*    */     }
/* 52 */     return cl;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\DefiningClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */