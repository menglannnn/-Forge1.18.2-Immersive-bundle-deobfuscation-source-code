/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HashSlotMap
/*    */   implements SlotMap
/*    */ {
/* 20 */   private final LinkedHashMap<Object, Slot> map = new LinkedHashMap<>();
/*    */ 
/*    */   
/*    */   public int size() {
/* 24 */     return this.map.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 29 */     return this.map.isEmpty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Slot query(Object key, int index) {
/* 34 */     Object name = makeKey(key, index);
/* 35 */     return this.map.get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Slot modify(Object key, int index, int attributes) {
/* 40 */     Object name = makeKey(key, index);
/* 41 */     Slot slot = this.map.get(name);
/* 42 */     if (slot != null) {
/* 43 */       return slot;
/*    */     }
/*    */     
/* 46 */     return createSlot(key, index, attributes);
/*    */   }
/*    */ 
/*    */   
/*    */   public void replace(Slot oldSlot, Slot newSlot) {
/* 51 */     Object name = makeKey(oldSlot);
/* 52 */     this.map.put(name, newSlot);
/*    */   }
/*    */   
/*    */   private Slot createSlot(Object key, int index, int attributes) {
/* 56 */     Slot newSlot = new Slot(key, index, attributes);
/* 57 */     add(newSlot);
/* 58 */     return newSlot;
/*    */   }
/*    */ 
/*    */   
/*    */   public void add(Slot newSlot) {
/* 63 */     Object name = makeKey(newSlot);
/* 64 */     this.map.put(name, newSlot);
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove(Object key, int index) {
/* 69 */     Object name = makeKey(key, index);
/* 70 */     Slot slot = this.map.get(name);
/* 71 */     if (slot != null) {
/*    */       
/* 73 */       if ((slot.getAttributes() & 0x4) != 0) {
/* 74 */         Context cx = Context.getContext();
/* 75 */         if (cx.isStrictMode()) {
/* 76 */           throw ScriptRuntime.typeErrorById("msg.delete.property.with.configurable.false", new Object[] { key });
/*    */         }
/*    */         
/*    */         return;
/*    */       } 
/* 81 */       this.map.remove(name);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<Slot> iterator() {
/* 87 */     return this.map.values().iterator();
/*    */   }
/*    */   
/*    */   private Object makeKey(Object name, int index) {
/* 91 */     return (name == null) ? String.valueOf(index) : name;
/*    */   }
/*    */   
/*    */   private Object makeKey(Slot slot) {
/* 95 */     return (slot.name == null) ? String.valueOf(slot.indexOrHash) : slot.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\HashSlotMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */