/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AbstractEcmaObjectOperations
/*     */ {
/*     */   enum INTEGRITY_LEVEL
/*     */   {
/*  23 */     FROZEN,
/*  24 */     SEALED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean testIntegrityLevel(Context cx, Object o, INTEGRITY_LEVEL level) {
/*  38 */     ScriptableObject obj = ScriptableObject.ensureScriptableObject(o);
/*     */     
/*  40 */     if (obj.isExtensible()) return false;
/*     */     
/*  42 */     for (Object name : obj.getIds(true, true)) {
/*  43 */       ScriptableObject desc = obj.getOwnPropertyDescriptor(cx, name);
/*  44 */       if (Boolean.TRUE.equals(desc.get("configurable"))) return false;
/*     */       
/*  46 */       if (level == INTEGRITY_LEVEL.FROZEN && desc
/*  47 */         .isDataDescriptor(desc) && Boolean.TRUE
/*  48 */         .equals(desc.get("writable"))) return false;
/*     */     
/*     */     } 
/*  51 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean setIntegrityLevel(Context cx, Object o, INTEGRITY_LEVEL level) {
/*  99 */     ScriptableObject obj = ScriptableObject.ensureScriptableObject(o);
/*     */ 
/*     */     
/* 102 */     obj.preventExtensions();
/*     */     
/* 104 */     for (Object key : obj.getIds(true, true)) {
/* 105 */       ScriptableObject desc = obj.getOwnPropertyDescriptor(cx, key);
/*     */       
/* 107 */       if (level == INTEGRITY_LEVEL.SEALED) {
/* 108 */         if (Boolean.TRUE.equals(desc.get("configurable"))) {
/* 109 */           desc.put("configurable", desc, Boolean.valueOf(false));
/*     */           
/* 111 */           obj.defineOwnProperty(cx, key, desc, false);
/*     */         } 
/*     */       } else {
/* 114 */         if (obj.isDataDescriptor(desc) && Boolean.TRUE.equals(desc.get("writable"))) {
/* 115 */           desc.put("writable", desc, Boolean.valueOf(false));
/*     */         }
/* 117 */         if (Boolean.TRUE.equals(desc.get("configurable"))) {
/* 118 */           desc.put("configurable", desc, Boolean.valueOf(false));
/*     */         }
/* 120 */         obj.defineOwnProperty(cx, key, desc, false);
/*     */       } 
/*     */     } 
/*     */     
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Constructable speciesConstructor(Context cx, Scriptable s, Constructable defaultConstructor) {
/* 155 */     Object constructor = ScriptableObject.getProperty(s, "constructor");
/* 156 */     if (constructor == Scriptable.NOT_FOUND || Undefined.isUndefined(constructor)) {
/* 157 */       return defaultConstructor;
/*     */     }
/* 159 */     if (!ScriptRuntime.isObject(constructor))
/* 160 */       throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] {
/* 161 */             ScriptRuntime.typeof(constructor)
/*     */           }); 
/* 163 */     Object species = ScriptableObject.getProperty((Scriptable)constructor, SymbolKey.SPECIES);
/* 164 */     if (species == Scriptable.NOT_FOUND || species == null || Undefined.isUndefined(species)) {
/* 165 */       return defaultConstructor;
/*     */     }
/* 167 */     if (!(species instanceof Constructable)) {
/* 168 */       throw ScriptRuntime.typeErrorById("msg.not.ctor", new Object[] { ScriptRuntime.typeof(species) });
/*     */     }
/* 170 */     return (Constructable)species;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\AbstractEcmaObjectOperations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */