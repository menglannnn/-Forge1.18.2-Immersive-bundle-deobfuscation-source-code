/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mozilla.javascript.ast.FunctionNode;
/*     */ import org.mozilla.javascript.ast.Jump;
/*     */ import org.mozilla.javascript.ast.Scope;
/*     */ import org.mozilla.javascript.ast.ScriptNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeTransformer
/*     */ {
/*     */   private ObjArray loops;
/*     */   private ObjArray loopEnds;
/*     */   private boolean hasFinally;
/*     */   
/*     */   public final void transform(ScriptNode tree, CompilerEnvirons env) {
/*  33 */     transform(tree, false, env);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void transform(ScriptNode tree, boolean inStrictMode, CompilerEnvirons env) {
/*  38 */     boolean useStrictMode = inStrictMode;
/*     */ 
/*     */ 
/*     */     
/*  42 */     if (env.getLanguageVersion() >= 200 && tree.isInStrictMode()) {
/*  43 */       useStrictMode = true;
/*     */     }
/*  45 */     transformCompilationUnit(tree, useStrictMode);
/*  46 */     for (int i = 0; i != tree.getFunctionCount(); i++) {
/*  47 */       FunctionNode fn = tree.getFunctionNode(i);
/*  48 */       transform((ScriptNode)fn, useStrictMode, env);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void transformCompilationUnit(ScriptNode tree, boolean inStrictMode) {
/*  54 */     this.loops = new ObjArray();
/*  55 */     this.loopEnds = new ObjArray();
/*     */ 
/*     */     
/*  58 */     this.hasFinally = false;
/*     */ 
/*     */ 
/*     */     
/*  62 */     boolean createScopeObjects = (tree.getType() != 113 || ((FunctionNode)tree).requiresActivation());
/*  63 */     tree.flattenSymbolTable(!createScopeObjects);
/*     */ 
/*     */ 
/*     */     
/*  67 */     transformCompilationUnit_r(tree, (Node)tree, (Scope)tree, createScopeObjects, inStrictMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void transformCompilationUnit_r(ScriptNode tree, Node parent, Scope scope, boolean createScopeObjects, boolean inStrictMode) {
/*  77 */     Node node = null; while (true) {
/*     */       Node leave; Jump jump1; boolean isGenerator; Jump jump; Node node1, result; Scope defining; Node child, nameSource, finallytarget, unwindBlock; Jump jumpStatement; Node cursor; String name; int i;
/*     */       Scope scope1;
/*  80 */       Node previous = null;
/*  81 */       if (node == null) {
/*  82 */         node = parent.getFirstChild();
/*     */       } else {
/*  84 */         previous = node;
/*  85 */         node = node.getNext();
/*     */       } 
/*  87 */       if (node == null) {
/*     */         break;
/*     */       }
/*     */       
/*  91 */       int type = node.getType();
/*  92 */       if (createScopeObjects && (type == 133 || type == 136 || type == 161) && node instanceof Scope) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  97 */         Scope newScope = (Scope)node;
/*  98 */         if (newScope.getSymbolTable() != null) {
/*     */ 
/*     */           
/* 101 */           Node let = new Node((type == 161) ? 162 : 157);
/*     */           
/* 103 */           Node innerLet = new Node(157);
/* 104 */           let.addChildToBack(innerLet);
/* 105 */           for (String str : newScope.getSymbolTable().keySet()) {
/* 106 */             innerLet.addChildToBack(Node.newString(39, str));
/*     */           }
/* 108 */           newScope.setSymbolTable(null);
/* 109 */           Node oldNode = node;
/* 110 */           node = replaceCurrent(parent, previous, node, let);
/* 111 */           type = node.getType();
/* 112 */           let.addChildToBack(oldNode);
/*     */         } 
/*     */       } 
/*     */       
/* 116 */       switch (type) {
/*     */         
/*     */         case 118:
/*     */         case 134:
/*     */         case 136:
/* 121 */           this.loops.push(node);
/* 122 */           this.loopEnds.push(((Jump)node).target);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 127:
/* 127 */           this.loops.push(node);
/* 128 */           leave = node.getNext();
/* 129 */           if (leave.getType() != 3) {
/* 130 */             Kit.codeBug();
/*     */           }
/* 132 */           this.loopEnds.push(leave);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 84:
/* 138 */           jump1 = (Jump)node;
/* 139 */           finallytarget = jump1.getFinally();
/* 140 */           if (finallytarget != null) {
/* 141 */             this.hasFinally = true;
/* 142 */             this.loops.push(node);
/* 143 */             this.loopEnds.push(finallytarget);
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 3:
/*     */         case 135:
/* 150 */           if (!this.loopEnds.isEmpty() && this.loopEnds.peek() == node) {
/* 151 */             this.loopEnds.pop();
/* 152 */             this.loops.pop();
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 73:
/*     */         case 169:
/* 158 */           ((FunctionNode)tree).addResumptionPoint(node);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/* 164 */           isGenerator = (tree.getType() == 113 && ((FunctionNode)tree).isGenerator());
/* 165 */           if (isGenerator) {
/* 166 */             node.putIntProp(20, 1);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 175 */           if (!this.hasFinally)
/*     */             break; 
/* 177 */           unwindBlock = null;
/* 178 */           for (i = this.loops.size() - 1; i >= 0; i--) {
/* 179 */             Node n = (Node)this.loops.get(i);
/* 180 */             int elemtype = n.getType();
/* 181 */             if (elemtype == 84 || elemtype == 127) {
/*     */               Node unwind;
/* 183 */               if (elemtype == 84) {
/* 184 */                 Jump jsrnode = new Jump(139);
/* 185 */                 Node jsrtarget = ((Jump)n).getFinally();
/* 186 */                 jsrnode.target = jsrtarget;
/* 187 */                 Jump jump2 = jsrnode;
/*     */               } else {
/* 189 */                 unwind = new Node(3);
/*     */               } 
/* 191 */               if (unwindBlock == null)
/*     */               {
/* 193 */                 unwindBlock = new Node(133, node.getLineno());
/*     */               }
/* 195 */               unwindBlock.addChildToBack(unwind);
/*     */             } 
/*     */           } 
/* 198 */           if (unwindBlock != null) {
/* 199 */             Node returnNode = node;
/* 200 */             Node returnExpr = returnNode.getFirstChild();
/* 201 */             node = replaceCurrent(parent, previous, node, unwindBlock);
/* 202 */             if (returnExpr == null || isGenerator) {
/* 203 */               unwindBlock.addChildToBack(returnNode); continue;
/*     */             } 
/* 205 */             Node store = new Node(138, returnExpr);
/* 206 */             unwindBlock.addChildToFront(store);
/* 207 */             returnNode = new Node(65);
/* 208 */             unwindBlock.addChildToBack(returnNode);
/*     */             
/* 210 */             transformCompilationUnit_r(tree, store, scope, createScopeObjects, inStrictMode);
/*     */             continue;
/*     */           } 
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 124:
/*     */         case 125:
/* 223 */           jump = (Jump)node;
/* 224 */           jumpStatement = jump.getJumpStatement();
/* 225 */           if (jumpStatement == null) Kit.codeBug();
/*     */           
/* 227 */           i = this.loops.size(); while (true) {
/* 228 */             if (i == 0)
/*     */             {
/*     */ 
/*     */               
/* 232 */               throw Kit.codeBug();
/*     */             }
/* 234 */             i--;
/* 235 */             Node n = (Node)this.loops.get(i);
/* 236 */             if (n == jumpStatement) {
/*     */               break;
/*     */             }
/*     */             
/* 240 */             int elemtype = n.getType();
/* 241 */             if (elemtype == 127) {
/* 242 */               Node node2 = new Node(3);
/* 243 */               previous = addBeforeCurrent(parent, previous, node, node2); continue;
/*     */             } 
/* 245 */             if (elemtype == 84) {
/* 246 */               Jump tryNode = (Jump)n;
/* 247 */               Jump jsrFinally = new Jump(139);
/* 248 */               jsrFinally.target = tryNode.getFinally();
/* 249 */               previous = addBeforeCurrent(parent, previous, node, (Node)jsrFinally);
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 254 */           if (type == 124) {
/* 255 */             jump.target = jumpStatement.target;
/*     */           } else {
/* 257 */             jump.target = jumpStatement.getContinue();
/*     */           } 
/* 259 */           jump.setType(5);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 38:
/* 265 */           visitCall(node, tree);
/*     */           break;
/*     */         
/*     */         case 30:
/* 269 */           visitNew(node, tree);
/*     */           break;
/*     */         
/*     */         case 157:
/*     */         case 162:
/* 274 */           node1 = node.getFirstChild();
/* 275 */           if (node1.getType() == 157) {
/*     */ 
/*     */ 
/*     */             
/* 279 */             boolean createWith = (tree.getType() != 113 || ((FunctionNode)tree).requiresActivation());
/* 280 */             node = visitLet(createWith, parent, previous, node);
/*     */             break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 126:
/*     */         case 158:
/* 289 */           result = new Node(133);
/* 290 */           for (cursor = node.getFirstChild(); cursor != null; ) {
/*     */ 
/*     */             
/* 293 */             Node n = cursor;
/* 294 */             cursor = cursor.getNext();
/* 295 */             if (n.getType() == 39) {
/* 296 */               if (!n.hasChildren())
/*     */                 continue; 
/* 298 */               Node init = n.getFirstChild();
/* 299 */               n.removeChild(init);
/* 300 */               n.setType(49);
/* 301 */               n = new Node((type == 158) ? 159 : 8, n, init);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 308 */             else if (n.getType() != 162) {
/* 309 */               throw Kit.codeBug();
/*     */             } 
/* 311 */             Node pop = new Node(137, n, node.getLineno());
/* 312 */             result.addChildToBack(pop);
/*     */           } 
/* 314 */           node = replaceCurrent(parent, previous, node, result);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 141:
/* 319 */           defining = scope.getDefiningScope(node.getString());
/* 320 */           if (defining != null) {
/* 321 */             node.setScope(defining);
/*     */           }
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 32:
/* 332 */           child = node.getFirstChild();
/* 333 */           if (type == 7) {
/* 334 */             while (child.getType() == 26) {
/* 335 */               child = child.getFirstChild();
/*     */             }
/* 337 */             if (child.getType() == 12 || child
/* 338 */               .getType() == 13) {
/* 339 */               Node first = child.getFirstChild();
/* 340 */               Node last = child.getLastChild();
/* 341 */               if (first.getType() == 39 && first
/* 342 */                 .getString().equals("undefined")) {
/* 343 */                 child = last;
/* 344 */               } else if (last.getType() == 39 && last
/* 345 */                 .getString().equals("undefined")) {
/* 346 */                 child = first;
/*     */               } 
/*     */             } 
/*     */           } 
/* 350 */           if (child.getType() == 33) {
/* 351 */             child.setType(34);
/*     */           }
/*     */           break;
/*     */ 
/*     */         
/*     */         case 8:
/* 357 */           if (inStrictMode) {
/* 358 */             node.setType(74);
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         case 31:
/*     */         case 39:
/*     */         case 159:
/* 366 */           if (createScopeObjects) {
/*     */             break;
/*     */           }
/*     */           
/* 370 */           if (type == 39) {
/* 371 */             nameSource = node;
/*     */           } else {
/* 373 */             nameSource = node.getFirstChild();
/* 374 */             if (nameSource.getType() != 49) {
/* 375 */               if (type == 31) {
/*     */                 break;
/*     */               }
/* 378 */               throw Kit.codeBug();
/*     */             } 
/*     */           } 
/* 381 */           if (nameSource.getScope() != null) {
/*     */             break;
/*     */           }
/* 384 */           name = nameSource.getString();
/* 385 */           scope1 = scope.getDefiningScope(name);
/* 386 */           if (scope1 != null) {
/* 387 */             nameSource.setScope(scope1);
/* 388 */             if (type == 39) {
/* 389 */               node.setType(55); break;
/* 390 */             }  if (type == 8 || type == 74) {
/*     */               
/* 392 */               node.setType(56);
/* 393 */               nameSource.setType(41); break;
/* 394 */             }  if (type == 159) {
/* 395 */               node.setType(160);
/* 396 */               nameSource.setType(41); break;
/* 397 */             }  if (type == 31) {
/*     */               
/* 399 */               Node n = new Node(44);
/* 400 */               node = replaceCurrent(parent, previous, node, n); break;
/*     */             } 
/* 402 */             throw Kit.codeBug();
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 409 */       transformCompilationUnit_r(tree, node, (node instanceof Scope) ? (Scope)node : scope, createScopeObjects, inStrictMode);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitNew(Node node, ScriptNode tree) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitCall(Node node, ScriptNode tree) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected Node visitLet(boolean createWith, Node parent, Node previous, Node scopeNode) {
/* 424 */     Node result, vars = scopeNode.getFirstChild();
/* 425 */     Node body = vars.getNext();
/* 426 */     scopeNode.removeChild(vars);
/* 427 */     scopeNode.removeChild(body);
/* 428 */     boolean isExpression = (scopeNode.getType() == 162);
/*     */ 
/*     */     
/* 431 */     if (createWith) {
/* 432 */       result = new Node(isExpression ? 163 : 133);
/* 433 */       result = replaceCurrent(parent, previous, scopeNode, result);
/* 434 */       ArrayList<Object> list = new ArrayList();
/* 435 */       Node objectLiteral = new Node(67);
/* 436 */       for (Node v = vars.getFirstChild(); v != null; v = v.getNext()) {
/* 437 */         Node current = v;
/* 438 */         if (current.getType() == 162) {
/*     */ 
/*     */           
/* 441 */           List<?> destructuringNames = (List)current.getProp(22);
/* 442 */           Node c = current.getFirstChild();
/* 443 */           if (c.getType() != 157) throw Kit.codeBug();
/*     */           
/* 445 */           if (isExpression) {
/* 446 */             body = new Node(92, c.getNext(), body);
/*     */           } else {
/*     */             
/* 449 */             body = new Node(133, new Node(137, c.getNext()), body);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 454 */           if (destructuringNames != null) {
/* 455 */             list.addAll(destructuringNames);
/* 456 */             for (int i = 0; i < destructuringNames.size(); i++) {
/* 457 */               objectLiteral.addChildToBack(new Node(130, 
/* 458 */                     Node.newNumber(0.0D)));
/*     */             }
/*     */           } 
/* 461 */           current = c.getFirstChild();
/*     */         } 
/* 463 */         if (current.getType() != 39) throw Kit.codeBug(); 
/* 464 */         list.add(ScriptRuntime.getIndexObject(current.getString()));
/* 465 */         Node init = current.getFirstChild();
/* 466 */         if (init == null) {
/* 467 */           init = new Node(130, Node.newNumber(0.0D));
/*     */         }
/* 469 */         objectLiteral.addChildToBack(init);
/*     */       } 
/* 471 */       objectLiteral.putProp(12, list.toArray());
/* 472 */       Node newVars = new Node(2, objectLiteral);
/* 473 */       result.addChildToBack(newVars);
/* 474 */       result.addChildToBack(new Node(127, body));
/* 475 */       result.addChildToBack(new Node(3));
/*     */     } else {
/* 477 */       result = new Node(isExpression ? 92 : 133);
/* 478 */       result = replaceCurrent(parent, previous, scopeNode, result);
/* 479 */       Node newVars = new Node(92);
/* 480 */       for (Node v = vars.getFirstChild(); v != null; v = v.getNext()) {
/* 481 */         Node current = v;
/* 482 */         if (current.getType() == 162) {
/*     */           
/* 484 */           Node c = current.getFirstChild();
/* 485 */           if (c.getType() != 157) throw Kit.codeBug();
/*     */           
/* 487 */           if (isExpression) {
/* 488 */             body = new Node(92, c.getNext(), body);
/*     */           } else {
/*     */             
/* 491 */             body = new Node(133, new Node(137, c.getNext()), body);
/*     */           } 
/*     */ 
/*     */           
/* 495 */           Scope.joinScopes((Scope)current, (Scope)scopeNode);
/*     */           
/* 497 */           current = c.getFirstChild();
/*     */         } 
/* 499 */         if (current.getType() != 39) throw Kit.codeBug(); 
/* 500 */         Node stringNode = Node.newString(current.getString());
/* 501 */         stringNode.setScope((Scope)scopeNode);
/* 502 */         Node init = current.getFirstChild();
/* 503 */         if (init == null) {
/* 504 */           init = new Node(130, Node.newNumber(0.0D));
/*     */         }
/* 506 */         newVars.addChildToBack(new Node(56, stringNode, init));
/*     */       } 
/* 508 */       if (isExpression) {
/* 509 */         result.addChildToBack(newVars);
/* 510 */         scopeNode.setType(92);
/* 511 */         result.addChildToBack(scopeNode);
/* 512 */         scopeNode.addChildToBack(body);
/* 513 */         if (body instanceof Scope) {
/* 514 */           Scope scopeParent = ((Scope)body).getParentScope();
/* 515 */           ((Scope)body).setParentScope((Scope)scopeNode);
/* 516 */           ((Scope)scopeNode).setParentScope(scopeParent);
/*     */         } 
/*     */       } else {
/* 519 */         result.addChildToBack(new Node(137, newVars));
/* 520 */         scopeNode.setType(133);
/* 521 */         result.addChildToBack(scopeNode);
/* 522 */         scopeNode.addChildrenToBack(body);
/* 523 */         if (body instanceof Scope) {
/* 524 */           Scope scopeParent = ((Scope)body).getParentScope();
/* 525 */           ((Scope)body).setParentScope((Scope)scopeNode);
/* 526 */           ((Scope)scopeNode).setParentScope(scopeParent);
/*     */         } 
/*     */       } 
/*     */     } 
/* 530 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Node addBeforeCurrent(Node parent, Node previous, Node current, Node toAdd) {
/* 536 */     if (previous == null) {
/* 537 */       if (current != parent.getFirstChild()) Kit.codeBug(); 
/* 538 */       parent.addChildToFront(toAdd);
/*     */     } else {
/* 540 */       if (current != previous.getNext()) Kit.codeBug(); 
/* 541 */       parent.addChildAfter(toAdd, previous);
/*     */     } 
/* 543 */     return toAdd;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Node replaceCurrent(Node parent, Node previous, Node current, Node replacement) {
/* 549 */     if (previous == null) {
/* 550 */       if (current != parent.getFirstChild()) Kit.codeBug(); 
/* 551 */       parent.replaceChild(current, replacement);
/* 552 */     } else if (previous.next == current) {
/*     */ 
/*     */       
/* 555 */       parent.replaceChildAfter(previous, replacement);
/*     */     } else {
/* 557 */       parent.replaceChild(current, replacement);
/*     */     } 
/* 559 */     return replacement;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NodeTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */