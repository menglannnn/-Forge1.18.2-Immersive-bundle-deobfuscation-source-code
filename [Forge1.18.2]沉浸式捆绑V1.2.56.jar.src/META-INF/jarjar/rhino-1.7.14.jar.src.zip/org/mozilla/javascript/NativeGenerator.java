/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeGenerator
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 1645892441041347273L;
/*     */   public static final int GENERATOR_SEND = 0;
/*     */   public static final int GENERATOR_THROW = 1;
/*     */   public static final int GENERATOR_CLOSE = 2;
/*     */   private static final int Id_close = 1;
/*     */   private static final int Id_next = 2;
/*     */   private static final int Id_send = 3;
/*     */   private static final int Id_throw = 4;
/*     */   private static final int Id___iterator__ = 5;
/*  18 */   private static final Object GENERATOR_TAG = "Generator"; private static final int MAX_PROTOTYPE_ID = 5; private NativeFunction function; private Object savedState;
/*     */   private String lineSource;
/*     */   private int lineNumber;
/*     */   private boolean firstTime;
/*     */   private boolean locked;
/*     */   
/*     */   static NativeGenerator init(ScriptableObject scope, boolean sealed) {
/*  25 */     NativeGenerator prototype = new NativeGenerator();
/*  26 */     if (scope != null) {
/*  27 */       prototype.setParentScope(scope);
/*  28 */       prototype.setPrototype(getObjectPrototype(scope));
/*     */     } 
/*  30 */     prototype.activatePrototypeMap(5);
/*  31 */     if (sealed) {
/*  32 */       prototype.sealObject();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  39 */     if (scope != null) {
/*  40 */       scope.associateValue(GENERATOR_TAG, prototype);
/*     */     }
/*     */     
/*  43 */     return prototype;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NativeGenerator()
/*     */   {
/* 216 */     this.firstTime = true; } public NativeGenerator(Scriptable scope, NativeFunction function, Object savedState) { this.firstTime = true;
/*     */     this.function = function;
/*     */     this.savedState = savedState;
/*     */     Scriptable top = ScriptableObject.getTopLevelScope(scope);
/*     */     setParentScope(top);
/*     */     NativeGenerator prototype = (NativeGenerator)ScriptableObject.getTopScopeValue(top, GENERATOR_TAG);
/*     */     setPrototype(prototype); }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*     */     return "Generator";
/*     */   }
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*     */     switch (id) {
/*     */       case 1:
/*     */         arity = 1;
/*     */         s = "close";
/*     */         break;
/*     */       case 2:
/*     */         arity = 1;
/*     */         s = "next";
/*     */         break;
/*     */       case 3:
/*     */         arity = 0;
/*     */         s = "send";
/*     */         break;
/*     */       case 4:
/*     */         arity = 0;
/*     */         s = "throw";
/*     */         break;
/*     */       case 5:
/*     */         arity = 1;
/*     */         s = "__iterator__";
/*     */         break;
/*     */       default:
/*     */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/*     */     initPrototypeMethod(GENERATOR_TAG, id, s, arity);
/*     */   }
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     Object arg;
/*     */     if (!f.hasTag(GENERATOR_TAG))
/*     */       return super.execIdCall(f, cx, scope, thisObj, args); 
/*     */     int id = f.methodId();
/*     */     NativeGenerator generator = ensureType(thisObj, NativeGenerator.class, f);
/*     */     switch (id) {
/*     */       case 1:
/*     */         return generator.resume(cx, scope, 2, new GeneratorClosedException());
/*     */       case 2:
/*     */         generator.firstTime = false;
/*     */         return generator.resume(cx, scope, 0, Undefined.instance);
/*     */       case 3:
/*     */         arg = (args.length > 0) ? args[0] : Undefined.instance;
/*     */         if (generator.firstTime && !arg.equals(Undefined.instance))
/*     */           throw ScriptRuntime.typeErrorById("msg.send.newborn", new Object[0]); 
/*     */         return generator.resume(cx, scope, 0, arg);
/*     */       case 4:
/*     */         return generator.resume(cx, scope, 1, (args.length > 0) ? args[0] : Undefined.instance);
/*     */       case 5:
/*     */         return thisObj;
/*     */     } 
/*     */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */   
/*     */   private Object resume(Context cx, Scriptable scope, int operation, Object value) {
/*     */     if (this.savedState == null) {
/*     */       Object thrown;
/*     */       if (operation == 2)
/*     */         return Undefined.instance; 
/*     */       if (operation == 1) {
/*     */         thrown = value;
/*     */       } else {
/*     */         thrown = NativeIterator.getStopIterationObject(scope);
/*     */       } 
/*     */       throw new JavaScriptException(thrown, this.lineSource, this.lineNumber);
/*     */     } 
/*     */     try {
/*     */       synchronized (this) {
/*     */         if (this.locked)
/*     */           throw ScriptRuntime.typeErrorById("msg.already.exec.gen", new Object[0]); 
/*     */         this.locked = true;
/*     */       } 
/*     */       return this.function.resumeGenerator(cx, scope, operation, this.savedState, value);
/*     */     } catch (GeneratorClosedException e) {
/*     */       return Undefined.instance;
/*     */     } catch (RhinoException e) {
/*     */       this.lineNumber = e.lineNumber();
/*     */       this.lineSource = e.lineSource();
/*     */       this.savedState = null;
/*     */       throw e;
/*     */     } finally {
/*     */       synchronized (this) {
/*     */         this.locked = false;
/*     */       } 
/*     */       if (operation == 2)
/*     */         this.savedState = null; 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected int findPrototypeId(String s) {
/*     */     switch (s) {
/*     */       case "close":
/*     */         id = 1;
/*     */         return id;
/*     */       case "next":
/*     */         id = 2;
/*     */         return id;
/*     */       case "send":
/*     */         id = 3;
/*     */         return id;
/*     */       case "throw":
/*     */         id = 4;
/*     */         return id;
/*     */       case "__iterator__":
/*     */         id = 5;
/*     */         return id;
/*     */     } 
/*     */     int id = 0;
/*     */     return id;
/*     */   }
/*     */   
/*     */   public static class GeneratorClosedException extends RuntimeException {
/*     */     private static final long serialVersionUID = 2561315658662379681L;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */