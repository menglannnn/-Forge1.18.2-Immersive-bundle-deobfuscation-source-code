/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LambdaSlot
/*    */   extends Slot
/*    */ {
/*    */   private static final long serialVersionUID = -3046681698806493052L;
/*    */   transient Supplier<Object> getter;
/*    */   transient Consumer<Object> setter;
/*    */   
/*    */   LambdaSlot(Slot oldSlot) {
/* 18 */     super(oldSlot);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isValueSlot() {
/* 26 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   boolean isSetterSlot() {
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   ScriptableObject getPropertyDescriptor(Context cx, Scriptable scope) {
/* 36 */     ScriptableObject desc = (ScriptableObject)cx.newObject(scope);
/* 37 */     if (this.getter != null) {
/* 38 */       desc.defineProperty("value", this.getter.get(), 0);
/*    */     } else {
/* 40 */       desc.defineProperty("value", this.value, 0);
/*    */     } 
/* 42 */     desc.setCommonDescriptorProperties(getAttributes(), true);
/* 43 */     return desc;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean setValue(Object value, Scriptable owner, Scriptable start) {
/* 48 */     if (this.setter != null) {
/* 49 */       if (owner == start) {
/* 50 */         this.setter.accept(value);
/* 51 */         return true;
/*    */       } 
/* 53 */       return false;
/*    */     } 
/* 55 */     return super.setValue(value, owner, start);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue(Scriptable start) {
/* 60 */     if (this.getter != null) {
/* 61 */       return this.getter.get();
/*    */     }
/* 63 */     return super.getValue(start);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\LambdaSlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */