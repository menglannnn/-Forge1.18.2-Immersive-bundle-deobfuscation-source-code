/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeSymbol
/*     */   extends IdScriptableObject
/*     */   implements Symbol
/*     */ {
/*     */   private static final long serialVersionUID = -589539749749830003L;
/*     */   public static final String CLASS_NAME = "Symbol";
/*     */   public static final String TYPE_NAME = "symbol";
/*  23 */   private static final Object GLOBAL_TABLE_KEY = new Object();
/*  24 */   private static final Object CONSTRUCTOR_SLOT = new Object(); private final SymbolKey key; private final NativeSymbol symbolData;
/*     */   private static final int ConstructorId_keyFor = -2;
/*     */   private static final int ConstructorId_for = -1;
/*     */   private static final int Id_constructor = 1;
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  30 */     NativeSymbol obj = new NativeSymbol("");
/*  31 */     ScriptableObject ctor = obj.exportAsJSClass(5, scope, false);
/*     */     
/*  33 */     cx.putThreadLocal(CONSTRUCTOR_SLOT, Boolean.TRUE);
/*     */     try {
/*  35 */       createStandardSymbol(cx, scope, ctor, "iterator", SymbolKey.ITERATOR);
/*  36 */       createStandardSymbol(cx, scope, ctor, "species", SymbolKey.SPECIES);
/*  37 */       createStandardSymbol(cx, scope, ctor, "toStringTag", SymbolKey.TO_STRING_TAG);
/*  38 */       createStandardSymbol(cx, scope, ctor, "hasInstance", SymbolKey.HAS_INSTANCE);
/*  39 */       createStandardSymbol(cx, scope, ctor, "isConcatSpreadable", SymbolKey.IS_CONCAT_SPREADABLE);
/*     */       
/*  41 */       createStandardSymbol(cx, scope, ctor, "isRegExp", SymbolKey.IS_REGEXP);
/*  42 */       createStandardSymbol(cx, scope, ctor, "toPrimitive", SymbolKey.TO_PRIMITIVE);
/*  43 */       createStandardSymbol(cx, scope, ctor, "match", SymbolKey.MATCH);
/*  44 */       createStandardSymbol(cx, scope, ctor, "replace", SymbolKey.REPLACE);
/*  45 */       createStandardSymbol(cx, scope, ctor, "search", SymbolKey.SEARCH);
/*  46 */       createStandardSymbol(cx, scope, ctor, "split", SymbolKey.SPLIT);
/*  47 */       createStandardSymbol(cx, scope, ctor, "unscopables", SymbolKey.UNSCOPABLES);
/*     */     } finally {
/*     */       
/*  50 */       cx.removeThreadLocal(CONSTRUCTOR_SLOT);
/*     */     } 
/*     */     
/*  53 */     if (sealed)
/*     */     {
/*  55 */       ctor.sealObject();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final int Id_toString = 2;
/*     */   private static final int Id_valueOf = 4;
/*     */   private static final int SymbolId_toStringTag = 3;
/*     */   private static final int SymbolId_toPrimitive = 5;
/*     */   private static final int MAX_PROTOTYPE_ID = 5;
/*     */   
/*     */   private NativeSymbol(String desc) {
/*  66 */     this.key = new SymbolKey(desc);
/*  67 */     this.symbolData = null;
/*     */   }
/*     */   
/*     */   private NativeSymbol(SymbolKey key) {
/*  71 */     this.key = key;
/*  72 */     this.symbolData = this;
/*     */   }
/*     */   
/*     */   public NativeSymbol(NativeSymbol s) {
/*  76 */     this.key = s.key;
/*  77 */     this.symbolData = s.symbolData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeSymbol construct(Context cx, Scriptable scope, Object[] args) {
/*  85 */     cx.putThreadLocal(CONSTRUCTOR_SLOT, Boolean.TRUE);
/*     */     try {
/*  87 */       return (NativeSymbol)cx.newObject(scope, "Symbol", args);
/*     */     } finally {
/*  89 */       cx.removeThreadLocal(CONSTRUCTOR_SLOT);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  95 */     return "Symbol";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/* 100 */     super.fillConstructorProperties(ctor);
/* 101 */     addIdFunctionProperty(ctor, "Symbol", -1, "for", 1);
/* 102 */     addIdFunctionProperty(ctor, "Symbol", -2, "keyFor", 1);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void createStandardSymbol(Context cx, Scriptable scope, ScriptableObject ctor, String name, SymbolKey key) {
/* 107 */     Scriptable sym = cx.newObject(scope, "Symbol", new Object[] { name, key });
/* 108 */     ctor.defineProperty(name, sym, 7);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 113 */     int id = 0;
/* 114 */     switch (s)
/*     */     { case "constructor":
/* 116 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 128 */         return id;case "toString": id = 2; return id;case "valueOf": id = 4; return id; }  id = 0; return id;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(Symbol key) {
/* 133 */     if (SymbolKey.TO_STRING_TAG.equals(key))
/* 134 */       return 3; 
/* 135 */     if (SymbolKey.TO_PRIMITIVE.equals(key)) {
/* 136 */       return 5;
/*     */     }
/* 138 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/* 152 */     switch (id) {
/*     */       case 1:
/* 154 */         initPrototypeMethod("Symbol", id, "constructor", 0);
/*     */         return;
/*     */       case 2:
/* 157 */         initPrototypeMethod("Symbol", id, "toString", 0);
/*     */         return;
/*     */       case 4:
/* 160 */         initPrototypeMethod("Symbol", id, "valueOf", 0);
/*     */         return;
/*     */       case 3:
/* 163 */         initPrototypeValue(id, SymbolKey.TO_STRING_TAG, "Symbol", 3);
/*     */         return;
/*     */       case 5:
/* 166 */         initPrototypeMethod("Symbol", id, SymbolKey.TO_PRIMITIVE, "Symbol.toPrimitive", 1);
/*     */         return;
/*     */     } 
/*     */     
/* 170 */     super.initPrototypeId(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 178 */     if (!f.hasTag("Symbol")) {
/* 179 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 181 */     int id = f.methodId();
/* 182 */     switch (id) {
/*     */       case -1:
/* 184 */         return js_for(cx, scope, args);
/*     */       case -2:
/* 186 */         return js_keyFor(cx, scope, args);
/*     */       
/*     */       case 1:
/* 189 */         if (thisObj == null) {
/* 190 */           if (cx.getThreadLocal(CONSTRUCTOR_SLOT) == null)
/*     */           {
/* 192 */             throw ScriptRuntime.typeErrorById("msg.no.symbol.new", new Object[0]);
/*     */           }
/*     */           
/* 195 */           return js_constructor(args);
/*     */         } 
/* 197 */         return construct(cx, scope, args);
/*     */       
/*     */       case 2:
/* 200 */         return getSelf(cx, scope, thisObj).toString();
/*     */       case 4:
/*     */       case 5:
/* 203 */         return getSelf(cx, scope, thisObj).js_valueOf();
/*     */     } 
/* 205 */     return super.execIdCall(f, cx, scope, thisObj, args);
/*     */   }
/*     */ 
/*     */   
/*     */   private static NativeSymbol getSelf(Context cx, Scriptable scope, Object thisObj) {
/*     */     try {
/* 211 */       return (NativeSymbol)ScriptRuntime.toObject(cx, scope, thisObj);
/* 212 */     } catch (ClassCastException cce) {
/* 213 */       throw ScriptRuntime.typeErrorById("msg.invalid.type", new Object[] { thisObj.getClass().getName() });
/*     */     } 
/*     */   }
/*     */   
/*     */   private static NativeSymbol js_constructor(Object[] args) {
/*     */     String desc;
/* 219 */     if (args.length > 0) {
/* 220 */       if (Undefined.instance.equals(args[0])) {
/* 221 */         desc = "";
/*     */       } else {
/* 223 */         desc = ScriptRuntime.toString(args[0]);
/*     */       } 
/*     */     } else {
/* 226 */       desc = "";
/*     */     } 
/*     */     
/* 229 */     if (args.length > 1) {
/* 230 */       return new NativeSymbol((SymbolKey)args[1]);
/*     */     }
/*     */     
/* 233 */     return new NativeSymbol(new SymbolKey(desc));
/*     */   }
/*     */ 
/*     */   
/*     */   private Object js_valueOf() {
/* 238 */     return this.symbolData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object js_for(Context cx, Scriptable scope, Object[] args) {
/* 245 */     String name = (args.length > 0) ? ScriptRuntime.toString(args[0]) : ScriptRuntime.toString(Undefined.instance);
/*     */     
/* 247 */     Map<String, NativeSymbol> table = getGlobalMap();
/* 248 */     NativeSymbol ret = table.get(name);
/*     */     
/* 250 */     if (ret == null) {
/* 251 */       ret = construct(cx, scope, new Object[] { name });
/* 252 */       table.put(name, ret);
/*     */     } 
/* 254 */     return ret;
/*     */   }
/*     */   
/*     */   private Object js_keyFor(Context cx, Scriptable scope, Object[] args) {
/* 258 */     Object s = (args.length > 0) ? args[0] : Undefined.instance;
/* 259 */     if (!(s instanceof NativeSymbol)) {
/* 260 */       throw ScriptRuntime.throwCustomError(cx, scope, "TypeError", "Not a Symbol");
/*     */     }
/* 262 */     NativeSymbol sym = (NativeSymbol)s;
/*     */     
/* 264 */     Map<String, NativeSymbol> table = getGlobalMap();
/* 265 */     for (Map.Entry<String, NativeSymbol> e : table.entrySet()) {
/* 266 */       if (((NativeSymbol)e.getValue()).key == sym.key) {
/* 267 */         return e.getKey();
/*     */       }
/*     */     } 
/* 270 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 275 */     return this.key.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isStrictMode() {
/* 281 */     Context cx = Context.getCurrentContext();
/* 282 */     return (cx != null && cx.isStrictMode());
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String name, Scriptable start, Object value) {
/* 287 */     if (!isSymbol()) {
/* 288 */       super.put(name, start, value);
/* 289 */     } else if (isStrictMode()) {
/* 290 */       throw ScriptRuntime.typeErrorById("msg.no.assign.symbol.strict", new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/* 296 */     if (!isSymbol()) {
/* 297 */       super.put(index, start, value);
/* 298 */     } else if (isStrictMode()) {
/* 299 */       throw ScriptRuntime.typeErrorById("msg.no.assign.symbol.strict", new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(Symbol key, Scriptable start, Object value) {
/* 305 */     if (!isSymbol()) {
/* 306 */       super.put(key, start, value);
/* 307 */     } else if (isStrictMode()) {
/* 308 */       throw ScriptRuntime.typeErrorById("msg.no.assign.symbol.strict", new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSymbol() {
/* 319 */     return (this.symbolData == this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTypeOf() {
/* 324 */     return isSymbol() ? "symbol" : super.getTypeOf();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 329 */     return this.key.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object x) {
/* 334 */     return this.key.equals(x);
/*     */   }
/*     */   
/*     */   SymbolKey getKey() {
/* 338 */     return this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, NativeSymbol> getGlobalMap() {
/* 343 */     ScriptableObject top = (ScriptableObject)getTopLevelScope(this);
/*     */     
/* 345 */     Map<String, NativeSymbol> map = (Map<String, NativeSymbol>)top.getAssociatedValue(GLOBAL_TABLE_KEY);
/* 346 */     if (map == null) {
/* 347 */       map = new HashMap<>();
/* 348 */       top.associateValue(GLOBAL_TABLE_KEY, map);
/*     */     } 
/* 350 */     return map;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeSymbol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */