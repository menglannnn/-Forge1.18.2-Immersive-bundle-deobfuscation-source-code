package org.mozilla.javascript;

public interface ConstProperties {
  void putConst(String paramString, Scriptable paramScriptable, Object paramObject);
  
  void defineConst(String paramString, Scriptable paramScriptable);
  
  boolean isConst(String paramString);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ConstProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */