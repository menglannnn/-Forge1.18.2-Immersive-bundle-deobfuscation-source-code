/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeInt8Array
/*     */   extends NativeTypedArrayView<Byte>
/*     */ {
/*     */   private static final long serialVersionUID = -3349419704390398895L;
/*     */   private static final String CLASS_NAME = "Int8Array";
/*     */   
/*     */   public NativeInt8Array() {}
/*     */   
/*     */   public NativeInt8Array(NativeArrayBuffer ab, int off, int len) {
/*  32 */     super(ab, off, len, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeInt8Array(int len) {
/*  37 */     this(new NativeArrayBuffer(len), 0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  43 */     return "Int8Array";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  48 */     NativeInt8Array a = new NativeInt8Array();
/*  49 */     a.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeInt8Array construct(NativeArrayBuffer ab, int off, int len) {
/*  55 */     return new NativeInt8Array(ab, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBytesPerElement() {
/*  61 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeInt8Array realThis(Scriptable thisObj, IdFunctionObject f) {
/*  67 */     return (NativeInt8Array)ensureType(thisObj, NativeInt8Array.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_get(int index) {
/*  73 */     if (checkIndex(index)) {
/*  74 */       return Undefined.instance;
/*     */     }
/*  76 */     return ByteIo.readInt8(this.arrayBuffer.buffer, index + this.offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_set(int index, Object c) {
/*  82 */     if (checkIndex(index)) {
/*  83 */       return Undefined.instance;
/*     */     }
/*  85 */     int val = Conversions.toInt8(c);
/*  86 */     ByteIo.writeInt8(this.arrayBuffer.buffer, index + this.offset, val);
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Byte get(int i) {
/*  95 */     if (checkIndex(i)) {
/*  96 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  98 */     return (Byte)js_get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Byte set(int i, Byte aByte) {
/* 104 */     if (checkIndex(i)) {
/* 105 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 107 */     return (Byte)js_set(i, aByte);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeInt8Array.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */