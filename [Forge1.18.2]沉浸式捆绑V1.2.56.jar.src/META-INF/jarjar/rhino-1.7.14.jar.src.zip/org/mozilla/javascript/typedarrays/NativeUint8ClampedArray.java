/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeUint8ClampedArray
/*     */   extends NativeTypedArrayView<Integer>
/*     */ {
/*     */   private static final long serialVersionUID = -3349419704390398895L;
/*     */   private static final String CLASS_NAME = "Uint8ClampedArray";
/*     */   
/*     */   public NativeUint8ClampedArray() {}
/*     */   
/*     */   public NativeUint8ClampedArray(NativeArrayBuffer ab, int off, int len) {
/*  33 */     super(ab, off, len, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeUint8ClampedArray(int len) {
/*  38 */     this(new NativeArrayBuffer(len), 0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  44 */     return "Uint8ClampedArray";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  49 */     NativeUint8ClampedArray a = new NativeUint8ClampedArray();
/*  50 */     a.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeUint8ClampedArray construct(NativeArrayBuffer ab, int off, int len) {
/*  56 */     return new NativeUint8ClampedArray(ab, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBytesPerElement() {
/*  62 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeUint8ClampedArray realThis(Scriptable thisObj, IdFunctionObject f) {
/*  68 */     return (NativeUint8ClampedArray)ensureType(thisObj, NativeUint8ClampedArray.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_get(int index) {
/*  74 */     if (checkIndex(index)) {
/*  75 */       return Undefined.instance;
/*     */     }
/*  77 */     return ByteIo.readUint8(this.arrayBuffer.buffer, index + this.offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_set(int index, Object c) {
/*  83 */     if (checkIndex(index)) {
/*  84 */       return Undefined.instance;
/*     */     }
/*  86 */     int val = Conversions.toUint8Clamp(c);
/*  87 */     ByteIo.writeUint8(this.arrayBuffer.buffer, index + this.offset, val);
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer get(int i) {
/*  94 */     if (checkIndex(i)) {
/*  95 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  97 */     return (Integer)js_get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer set(int i, Integer aByte) {
/* 103 */     if (checkIndex(i)) {
/* 104 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 106 */     return (Integer)js_set(i, aByte);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeUint8ClampedArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */