/*    */ package org.mozilla.javascript.typedarrays;
/*    */ 
/*    */ import org.mozilla.javascript.ScriptRuntime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Conversions
/*    */ {
/*    */   public static int toInt8(Object arg) {
/* 19 */     return (byte)ScriptRuntime.toInt32(arg);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int toUint8(Object arg) {
/* 24 */     return ScriptRuntime.toInt32(arg) & 0xFF;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int toUint8Clamp(Object arg) {
/* 29 */     double d = ScriptRuntime.toNumber(arg);
/* 30 */     if (d <= 0.0D) {
/* 31 */       return 0;
/*    */     }
/* 33 */     if (d >= 255.0D) {
/* 34 */       return 255;
/*    */     }
/*    */ 
/*    */     
/* 38 */     double f = Math.floor(d);
/* 39 */     if (f + 0.5D < d) {
/* 40 */       return (int)(f + 1.0D);
/*    */     }
/* 42 */     if (d < f + 0.5D) {
/* 43 */       return (int)f;
/*    */     }
/* 45 */     if ((int)f % 2 != 0) {
/* 46 */       return (int)f + 1;
/*    */     }
/* 48 */     return (int)f;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int toInt16(Object arg) {
/* 53 */     return (short)ScriptRuntime.toInt32(arg);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int toUint16(Object arg) {
/* 58 */     return ScriptRuntime.toInt32(arg) & 0xFFFF;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int toInt32(Object arg) {
/* 63 */     return ScriptRuntime.toInt32(arg);
/*    */   }
/*    */ 
/*    */   
/*    */   public static long toUint32(Object arg) {
/* 68 */     return ScriptRuntime.toUint32(arg);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\Conversions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */