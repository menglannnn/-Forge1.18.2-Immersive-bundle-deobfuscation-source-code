/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdScriptableObject;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NativeArrayBufferView
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 6884475582973958419L;
/*  22 */   private static Boolean useLittleEndian = null;
/*     */   protected final NativeArrayBuffer arrayBuffer;
/*     */   protected final int offset;
/*     */   protected final int byteLength;
/*     */   private static final int Id_buffer = 1;
/*     */   private static final int Id_byteOffset = 2;
/*     */   private static final int Id_byteLength = 3;
/*     */   protected static final int MAX_INSTANCE_ID = 3;
/*     */   
/*     */   public NativeArrayBufferView() {
/*  32 */     this.arrayBuffer = new NativeArrayBuffer();
/*  33 */     this.offset = 0;
/*  34 */     this.byteLength = 0;
/*     */   }
/*     */   
/*     */   protected NativeArrayBufferView(NativeArrayBuffer ab, int offset, int byteLength) {
/*  38 */     this.offset = offset;
/*  39 */     this.byteLength = byteLength;
/*  40 */     this.arrayBuffer = ab;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeArrayBuffer getBuffer() {
/*  45 */     return this.arrayBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getByteOffset() {
/*  50 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getByteLength() {
/*  55 */     return this.byteLength;
/*     */   }
/*     */   
/*     */   protected static boolean useLittleEndian() {
/*  59 */     if (useLittleEndian == null) {
/*  60 */       Context ctx = Context.getCurrentContext();
/*     */       
/*  62 */       if (ctx == null) {
/*  63 */         return false;
/*     */       }
/*  65 */       useLittleEndian = Boolean.valueOf(ctx.hasFeature(19));
/*     */     } 
/*  67 */     return useLittleEndian.booleanValue();
/*     */   }
/*     */   
/*     */   protected static boolean isArg(Object[] args, int i) {
/*  71 */     return (args.length > i && !Undefined.instance.equals(args[i]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxInstanceId() {
/*  78 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/*  83 */     switch (id) {
/*     */       case 1:
/*  85 */         return "buffer";
/*     */       case 2:
/*  87 */         return "byteOffset";
/*     */       case 3:
/*  89 */         return "byteLength";
/*     */     } 
/*  91 */     return super.getInstanceIdName(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/*  97 */     switch (id) {
/*     */       case 1:
/*  99 */         return this.arrayBuffer;
/*     */       case 2:
/* 101 */         return ScriptRuntime.wrapInt(this.offset);
/*     */       case 3:
/* 103 */         return ScriptRuntime.wrapInt(this.byteLength);
/*     */     } 
/* 105 */     return super.getInstanceIdValue(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(String s) {
/*     */     int id;
/* 112 */     switch (s) {
/*     */       case "buffer":
/* 114 */         id = 1;
/*     */         break;
/*     */       case "byteOffset":
/* 117 */         id = 2;
/*     */         break;
/*     */       case "byteLength":
/* 120 */         id = 3;
/*     */         break;
/*     */       default:
/* 123 */         id = 0;
/*     */         break;
/*     */     } 
/* 126 */     if (id == 0) {
/* 127 */       return super.findInstanceIdInfo(s);
/*     */     }
/* 129 */     return instanceIdInfo(5, id);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeArrayBufferView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */