/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeUint32Array
/*     */   extends NativeTypedArrayView<Long>
/*     */ {
/*     */   private static final long serialVersionUID = -7987831421954144244L;
/*     */   private static final String CLASS_NAME = "Uint32Array";
/*     */   private static final int BYTES_PER_ELEMENT = 4;
/*     */   
/*     */   public NativeUint32Array() {}
/*     */   
/*     */   public NativeUint32Array(NativeArrayBuffer ab, int off, int len) {
/*  33 */     super(ab, off, len, len * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeUint32Array(int len) {
/*  38 */     this(new NativeArrayBuffer(len * 4.0D), 0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  44 */     return "Uint32Array";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  49 */     NativeUint32Array a = new NativeUint32Array();
/*  50 */     a.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeUint32Array construct(NativeArrayBuffer ab, int off, int len) {
/*  56 */     return new NativeUint32Array(ab, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBytesPerElement() {
/*  62 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeUint32Array realThis(Scriptable thisObj, IdFunctionObject f) {
/*  68 */     return (NativeUint32Array)ensureType(thisObj, NativeUint32Array.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_get(int index) {
/*  74 */     if (checkIndex(index)) {
/*  75 */       return Undefined.instance;
/*     */     }
/*  77 */     return ByteIo.readUint32(this.arrayBuffer.buffer, index * 4 + this.offset, useLittleEndian());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_set(int index, Object c) {
/*  83 */     if (checkIndex(index)) {
/*  84 */       return Undefined.instance;
/*     */     }
/*  86 */     long val = Conversions.toUint32(c);
/*  87 */     ByteIo.writeUint32(this.arrayBuffer.buffer, index * 4 + this.offset, val, useLittleEndian());
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Long get(int i) {
/*  94 */     if (checkIndex(i)) {
/*  95 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  97 */     return (Long)js_get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Long set(int i, Long aByte) {
/* 103 */     if (checkIndex(i)) {
/* 104 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 106 */     return (Long)js_set(i, aByte);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeUint32Array.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */