/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeFloat32Array
/*     */   extends NativeTypedArrayView<Float>
/*     */ {
/*     */   private static final long serialVersionUID = -8963461831950499340L;
/*     */   private static final String CLASS_NAME = "Float32Array";
/*     */   private static final int BYTES_PER_ELEMENT = 4;
/*     */   
/*     */   public NativeFloat32Array() {}
/*     */   
/*     */   public NativeFloat32Array(NativeArrayBuffer ab, int off, int len) {
/*  34 */     super(ab, off, len, len * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeFloat32Array(int len) {
/*  39 */     this(new NativeArrayBuffer(len * 4.0D), 0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  45 */     return "Float32Array";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  50 */     NativeFloat32Array a = new NativeFloat32Array();
/*  51 */     a.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeFloat32Array construct(NativeArrayBuffer ab, int off, int len) {
/*  57 */     return new NativeFloat32Array(ab, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBytesPerElement() {
/*  63 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeFloat32Array realThis(Scriptable thisObj, IdFunctionObject f) {
/*  69 */     return (NativeFloat32Array)ensureType(thisObj, NativeFloat32Array.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_get(int index) {
/*  75 */     if (checkIndex(index)) {
/*  76 */       return Undefined.instance;
/*     */     }
/*  78 */     return ByteIo.readFloat32(this.arrayBuffer.buffer, index * 4 + this.offset, useLittleEndian());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_set(int index, Object c) {
/*  84 */     if (checkIndex(index)) {
/*  85 */       return Undefined.instance;
/*     */     }
/*  87 */     double val = ScriptRuntime.toNumber(c);
/*  88 */     ByteIo.writeFloat32(this.arrayBuffer.buffer, index * 4 + this.offset, val, useLittleEndian());
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Float get(int i) {
/*  95 */     if (checkIndex(i)) {
/*  96 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  98 */     return (Float)js_get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Float set(int i, Float aByte) {
/* 104 */     if (checkIndex(i)) {
/* 105 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 107 */     return (Float)js_set(i, aByte);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeFloat32Array.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */