/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeDataView
/*     */   extends NativeArrayBufferView
/*     */ {
/*     */   private static final long serialVersionUID = 1427967607557438968L;
/*     */   public static final String CLASS_NAME = "DataView";
/*     */   private static final int Id_constructor = 1;
/*     */   private static final int Id_getInt8 = 2;
/*     */   private static final int Id_getUint8 = 3;
/*     */   private static final int Id_getInt16 = 4;
/*     */   private static final int Id_getUint16 = 5;
/*     */   private static final int Id_getInt32 = 6;
/*     */   private static final int Id_getUint32 = 7;
/*     */   private static final int Id_getFloat32 = 8;
/*     */   
/*     */   public NativeDataView(NativeArrayBuffer ab, int offset, int length) {
/*  31 */     super(ab, offset, length);
/*     */   }
/*     */   private static final int Id_getFloat64 = 9; private static final int Id_setInt8 = 10; private static final int Id_setUint8 = 11; private static final int Id_setInt16 = 12; private static final int Id_setUint16 = 13; private static final int Id_setInt32 = 14; private static final int Id_setUint32 = 15; private static final int Id_setFloat32 = 16; private static final int Id_setFloat64 = 17; private static final int MAX_PROTOTYPE_ID = 17;
/*     */   public NativeDataView() {}
/*     */   public String getClassName() {
/*  36 */     return "DataView";
/*     */   }
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  40 */     NativeDataView dv = new NativeDataView();
/*  41 */     dv.exportAsJSClass(17, scope, sealed);
/*     */   }
/*     */   
/*     */   private static int determinePos(Object[] args) {
/*  45 */     if (isArg(args, 0)) {
/*  46 */       double doublePos = ScriptRuntime.toNumber(args[0]);
/*  47 */       if (Double.isInfinite(doublePos)) {
/*  48 */         throw ScriptRuntime.rangeError("offset out of range");
/*     */       }
/*  50 */       return ScriptRuntime.toInt32(doublePos);
/*     */     } 
/*  52 */     return 0;
/*     */   }
/*     */   
/*     */   private void rangeCheck(int pos, int len) {
/*  56 */     if (pos < 0 || pos + len > this.byteLength) {
/*  57 */       throw ScriptRuntime.rangeError("offset out of range");
/*     */     }
/*     */   }
/*     */   
/*     */   private static NativeDataView realThis(Scriptable thisObj, IdFunctionObject f) {
/*  62 */     return (NativeDataView)ensureType(thisObj, NativeDataView.class, f);
/*     */   }
/*     */   private static NativeDataView js_constructor(Object[] args) {
/*     */     int pos, len;
/*  66 */     if (!isArg(args, 0) || !(args[0] instanceof NativeArrayBuffer)) {
/*  67 */       throw ScriptRuntime.constructError("TypeError", "Missing parameters");
/*     */     }
/*     */     
/*  70 */     NativeArrayBuffer ab = (NativeArrayBuffer)args[0];
/*     */ 
/*     */     
/*  73 */     if (isArg(args, 1)) {
/*  74 */       double doublePos = ScriptRuntime.toNumber(args[1]);
/*  75 */       if (Double.isInfinite(doublePos)) {
/*  76 */         throw ScriptRuntime.rangeError("offset out of range");
/*     */       }
/*  78 */       pos = ScriptRuntime.toInt32(doublePos);
/*     */     } else {
/*  80 */       pos = 0;
/*     */     } 
/*     */ 
/*     */     
/*  84 */     if (isArg(args, 2)) {
/*  85 */       double doublePos = ScriptRuntime.toNumber(args[2]);
/*  86 */       if (Double.isInfinite(doublePos)) {
/*  87 */         throw ScriptRuntime.rangeError("offset out of range");
/*     */       }
/*  89 */       len = ScriptRuntime.toInt32(doublePos);
/*     */     } else {
/*  91 */       len = ab.getLength() - pos;
/*     */     } 
/*     */     
/*  94 */     if (len < 0) {
/*  95 */       throw ScriptRuntime.rangeError("length out of range");
/*     */     }
/*  97 */     if (pos < 0 || pos + len > ab.getLength()) {
/*  98 */       throw ScriptRuntime.rangeError("offset out of range");
/*     */     }
/* 100 */     return new NativeDataView(ab, pos, len);
/*     */   }
/*     */   
/*     */   private Object js_getInt(int bytes, boolean signed, Object[] args) {
/* 104 */     int pos = determinePos(args);
/* 105 */     rangeCheck(pos, bytes);
/*     */     
/* 107 */     boolean littleEndian = (isArg(args, 1) && bytes > 1 && ScriptRuntime.toBoolean(args[1]));
/*     */     
/* 109 */     switch (bytes) {
/*     */       case 1:
/* 111 */         if (signed) {
/* 112 */           return ByteIo.readInt8(this.arrayBuffer.buffer, this.offset + pos);
/*     */         }
/* 114 */         return ByteIo.readUint8(this.arrayBuffer.buffer, this.offset + pos);
/*     */       
/*     */       case 2:
/* 117 */         if (signed) {
/* 118 */           return ByteIo.readInt16(this.arrayBuffer.buffer, this.offset + pos, littleEndian);
/*     */         }
/* 120 */         return ByteIo.readUint16(this.arrayBuffer.buffer, this.offset + pos, littleEndian);
/*     */       
/*     */       case 4:
/* 123 */         return signed ? 
/* 124 */           ByteIo.readInt32(this.arrayBuffer.buffer, this.offset + pos, littleEndian) : 
/* 125 */           ByteIo.readUint32(this.arrayBuffer.buffer, this.offset + pos, littleEndian);
/*     */     } 
/* 127 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */   
/*     */   private Object js_getFloat(int bytes, Object[] args) {
/* 132 */     int pos = determinePos(args);
/* 133 */     rangeCheck(pos, bytes);
/*     */     
/* 135 */     boolean littleEndian = (isArg(args, 1) && bytes > 1 && ScriptRuntime.toBoolean(args[1]));
/*     */     
/* 137 */     switch (bytes) {
/*     */       case 4:
/* 139 */         return ByteIo.readFloat32(this.arrayBuffer.buffer, this.offset + pos, littleEndian);
/*     */       case 8:
/* 141 */         return ByteIo.readFloat64(this.arrayBuffer.buffer, this.offset + pos, littleEndian);
/*     */     } 
/* 143 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */   
/*     */   private void js_setInt(int bytes, boolean signed, Object[] args) {
/* 148 */     int pos = determinePos(args);
/* 149 */     if (pos < 0) {
/* 150 */       throw ScriptRuntime.rangeError("offset out of range");
/*     */     }
/*     */     
/* 153 */     boolean littleEndian = (isArg(args, 2) && bytes > 1 && ScriptRuntime.toBoolean(args[2]));
/*     */     
/* 155 */     Object val = ScriptRuntime.zeroObj;
/* 156 */     if (args.length > 1) {
/* 157 */       val = args[1];
/*     */     }
/*     */     
/* 160 */     switch (bytes) {
/*     */       case 1:
/* 162 */         if (signed) {
/* 163 */           int value = Conversions.toInt8(val);
/* 164 */           if (pos + bytes > this.byteLength) {
/* 165 */             throw ScriptRuntime.rangeError("offset out of range");
/*     */           }
/* 167 */           ByteIo.writeInt8(this.arrayBuffer.buffer, this.offset + pos, value);
/*     */         } else {
/* 169 */           int value = Conversions.toUint8(val);
/* 170 */           if (pos + bytes > this.byteLength) {
/* 171 */             throw ScriptRuntime.rangeError("offset out of range");
/*     */           }
/* 173 */           ByteIo.writeUint8(this.arrayBuffer.buffer, this.offset + pos, value);
/*     */         } 
/*     */         return;
/*     */       case 2:
/* 177 */         if (signed) {
/* 178 */           int value = Conversions.toInt16(val);
/* 179 */           if (pos + bytes > this.byteLength) {
/* 180 */             throw ScriptRuntime.rangeError("offset out of range");
/*     */           }
/* 182 */           ByteIo.writeInt16(this.arrayBuffer.buffer, this.offset + pos, value, littleEndian);
/*     */         } else {
/* 184 */           int value = Conversions.toUint16(val);
/* 185 */           if (pos + bytes > this.byteLength) {
/* 186 */             throw ScriptRuntime.rangeError("offset out of range");
/*     */           }
/* 188 */           ByteIo.writeUint16(this.arrayBuffer.buffer, this.offset + pos, value, littleEndian);
/*     */         } 
/*     */         return;
/*     */       case 4:
/* 192 */         if (signed) {
/* 193 */           int value = Conversions.toInt32(val);
/* 194 */           if (pos + bytes > this.byteLength) {
/* 195 */             throw ScriptRuntime.rangeError("offset out of range");
/*     */           }
/* 197 */           ByteIo.writeInt32(this.arrayBuffer.buffer, this.offset + pos, value, littleEndian);
/*     */         } else {
/* 199 */           long value = Conversions.toUint32(val);
/* 200 */           if (pos + bytes > this.byteLength) {
/* 201 */             throw ScriptRuntime.rangeError("offset out of range");
/*     */           }
/* 203 */           ByteIo.writeUint32(this.arrayBuffer.buffer, this.offset + pos, value, littleEndian);
/*     */         } 
/*     */         return;
/*     */     } 
/* 207 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */   
/*     */   private void js_setFloat(int bytes, Object[] args) {
/* 212 */     int pos = determinePos(args);
/* 213 */     if (pos < 0) {
/* 214 */       throw ScriptRuntime.rangeError("offset out of range");
/*     */     }
/*     */     
/* 217 */     boolean littleEndian = (isArg(args, 2) && bytes > 1 && ScriptRuntime.toBoolean(args[2]));
/*     */     
/* 219 */     double val = Double.NaN;
/* 220 */     if (args.length > 1) {
/* 221 */       val = ScriptRuntime.toNumber(args[1]);
/*     */     }
/*     */     
/* 224 */     if (pos + bytes > this.byteLength) {
/* 225 */       throw ScriptRuntime.rangeError("offset out of range");
/*     */     }
/*     */     
/* 228 */     switch (bytes) {
/*     */       case 4:
/* 230 */         ByteIo.writeFloat32(this.arrayBuffer.buffer, this.offset + pos, val, littleEndian);
/*     */         return;
/*     */       case 8:
/* 233 */         ByteIo.writeFloat64(this.arrayBuffer.buffer, this.offset + pos, val, littleEndian);
/*     */         return;
/*     */     } 
/* 236 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 245 */     if (!f.hasTag(getClassName())) {
/* 246 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 248 */     int id = f.methodId();
/* 249 */     switch (id) {
/*     */       case 1:
/* 251 */         return js_constructor(args);
/*     */       case 2:
/* 253 */         return realThis(thisObj, f).js_getInt(1, true, args);
/*     */       case 3:
/* 255 */         return realThis(thisObj, f).js_getInt(1, false, args);
/*     */       case 4:
/* 257 */         return realThis(thisObj, f).js_getInt(2, true, args);
/*     */       case 5:
/* 259 */         return realThis(thisObj, f).js_getInt(2, false, args);
/*     */       case 6:
/* 261 */         return realThis(thisObj, f).js_getInt(4, true, args);
/*     */       case 7:
/* 263 */         return realThis(thisObj, f).js_getInt(4, false, args);
/*     */       case 8:
/* 265 */         return realThis(thisObj, f).js_getFloat(4, args);
/*     */       case 9:
/* 267 */         return realThis(thisObj, f).js_getFloat(8, args);
/*     */       case 10:
/* 269 */         realThis(thisObj, f).js_setInt(1, true, args);
/* 270 */         return Undefined.instance;
/*     */       case 11:
/* 272 */         realThis(thisObj, f).js_setInt(1, false, args);
/* 273 */         return Undefined.instance;
/*     */       case 12:
/* 275 */         realThis(thisObj, f).js_setInt(2, true, args);
/* 276 */         return Undefined.instance;
/*     */       case 13:
/* 278 */         realThis(thisObj, f).js_setInt(2, false, args);
/* 279 */         return Undefined.instance;
/*     */       case 14:
/* 281 */         realThis(thisObj, f).js_setInt(4, true, args);
/* 282 */         return Undefined.instance;
/*     */       case 15:
/* 284 */         realThis(thisObj, f).js_setInt(4, false, args);
/* 285 */         return Undefined.instance;
/*     */       case 16:
/* 287 */         realThis(thisObj, f).js_setFloat(4, args);
/* 288 */         return Undefined.instance;
/*     */       case 17:
/* 290 */         realThis(thisObj, f).js_setFloat(8, args);
/* 291 */         return Undefined.instance;
/*     */     } 
/* 293 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 300 */     switch (id) {
/*     */       case 1:
/* 302 */         arity = 1;
/* 303 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 306 */         arity = 1;
/* 307 */         s = "getInt8";
/*     */         break;
/*     */       case 3:
/* 310 */         arity = 1;
/* 311 */         s = "getUint8";
/*     */         break;
/*     */       case 4:
/* 314 */         arity = 1;
/* 315 */         s = "getInt16";
/*     */         break;
/*     */       case 5:
/* 318 */         arity = 1;
/* 319 */         s = "getUint16";
/*     */         break;
/*     */       case 6:
/* 322 */         arity = 1;
/* 323 */         s = "getInt32";
/*     */         break;
/*     */       case 7:
/* 326 */         arity = 1;
/* 327 */         s = "getUint32";
/*     */         break;
/*     */       case 8:
/* 330 */         arity = 1;
/* 331 */         s = "getFloat32";
/*     */         break;
/*     */       case 9:
/* 334 */         arity = 1;
/* 335 */         s = "getFloat64";
/*     */         break;
/*     */       case 10:
/* 338 */         arity = 2;
/* 339 */         s = "setInt8";
/*     */         break;
/*     */       case 11:
/* 342 */         arity = 2;
/* 343 */         s = "setUint8";
/*     */         break;
/*     */       case 12:
/* 346 */         arity = 2;
/* 347 */         s = "setInt16";
/*     */         break;
/*     */       case 13:
/* 350 */         arity = 2;
/* 351 */         s = "setUint16";
/*     */         break;
/*     */       case 14:
/* 354 */         arity = 2;
/* 355 */         s = "setInt32";
/*     */         break;
/*     */       case 15:
/* 358 */         arity = 2;
/* 359 */         s = "setUint32";
/*     */         break;
/*     */       case 16:
/* 362 */         arity = 2;
/* 363 */         s = "setFloat32";
/*     */         break;
/*     */       case 17:
/* 366 */         arity = 2;
/* 367 */         s = "setFloat64";
/*     */         break;
/*     */       default:
/* 370 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 372 */     initPrototypeMethod(getClassName(), id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 378 */     switch (s)
/*     */     { case "constructor":
/* 380 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 434 */         return id;case "getInt8": id = 2; return id;case "getUint8": id = 3; return id;case "getInt16": id = 4; return id;case "getUint16": id = 5; return id;case "getInt32": id = 6; return id;case "getUint32": id = 7; return id;case "getFloat32": id = 8; return id;case "getFloat64": id = 9; return id;case "setInt8": id = 10; return id;case "setUint8": id = 11; return id;case "setInt16": id = 12; return id;case "setUint16": id = 13; return id;case "setInt32": id = 14; return id;case "setUint32": id = 15; return id;case "setFloat32": id = 16; return id;case "setFloat64": id = 17; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeDataView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */