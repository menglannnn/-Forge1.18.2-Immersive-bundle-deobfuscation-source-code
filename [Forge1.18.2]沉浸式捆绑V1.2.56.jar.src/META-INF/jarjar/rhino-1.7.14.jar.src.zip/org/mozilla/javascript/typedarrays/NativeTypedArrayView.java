/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.RandomAccess;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ExternalArrayData;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.NativeArray;
/*     */ import org.mozilla.javascript.NativeArrayIterator;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Symbol;
/*     */ import org.mozilla.javascript.SymbolKey;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ import org.mozilla.javascript.Wrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NativeTypedArrayView<T>
/*     */   extends NativeArrayBufferView
/*     */   implements List<T>, RandomAccess, ExternalArrayData
/*     */ {
/*     */   private static final long serialVersionUID = -4963053773152251274L;
/*     */   protected final int length;
/*     */   private static final int Id_constructor = 1;
/*     */   private static final int Id_toString = 2;
/*     */   private static final int Id_get = 3;
/*     */   private static final int Id_set = 4;
/*     */   private static final int Id_subarray = 5;
/*     */   private static final int SymbolId_iterator = 6;
/*     */   protected static final int MAX_PROTOTYPE_ID = 6;
/*     */   private static final int Id_length = 4;
/*     */   private static final int Id_BYTES_PER_ELEMENT = 5;
/*     */   private static final int MAX_INSTANCE_ID = 5;
/*     */   
/*     */   protected NativeTypedArrayView() {
/*  41 */     this.length = 0;
/*     */   }
/*     */   
/*     */   protected NativeTypedArrayView(NativeArrayBuffer ab, int off, int len, int byteLen) {
/*  45 */     super(ab, off, byteLen);
/*  46 */     this.length = len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/*  53 */     return js_get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/*  58 */     return !checkIndex(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object val) {
/*  63 */     js_set(index, val);
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(int index) {}
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/*  71 */     Object[] ret = new Object[this.length];
/*  72 */     for (int i = 0; i < this.length; i++) {
/*  73 */       ret[i] = Integer.valueOf(i);
/*     */     }
/*  75 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkIndex(int index) {
/*  81 */     return (index < 0 || index >= this.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract int getBytesPerElement();
/*     */ 
/*     */   
/*     */   protected abstract NativeTypedArrayView<T> construct(NativeArrayBuffer paramNativeArrayBuffer, int paramInt1, int paramInt2);
/*     */ 
/*     */   
/*     */   protected abstract Object js_get(int paramInt);
/*     */ 
/*     */   
/*     */   protected abstract Object js_set(int paramInt, Object paramObject);
/*     */   
/*     */   protected abstract NativeTypedArrayView<T> realThis(Scriptable paramScriptable, IdFunctionObject paramIdFunctionObject);
/*     */   
/*     */   private NativeArrayBuffer makeArrayBuffer(Context cx, Scriptable scope, int length) {
/*  99 */     return (NativeArrayBuffer)cx
/* 100 */       .newObject(scope, "ArrayBuffer", new Object[] {
/*     */ 
/*     */           
/* 103 */           Double.valueOf(length * getBytesPerElement()) });
/*     */   }
/*     */   
/*     */   private NativeTypedArrayView<T> js_constructor(Context cx, Scriptable scope, Object[] args) {
/* 107 */     if (!isArg(args, 0)) {
/* 108 */       return construct(new NativeArrayBuffer(), 0, 0);
/*     */     }
/*     */     
/* 111 */     Object arg0 = args[0];
/* 112 */     if (arg0 == null) {
/* 113 */       return construct(new NativeArrayBuffer(), 0, 0);
/*     */     }
/*     */     
/* 116 */     if (arg0 instanceof Number || arg0 instanceof String) {
/*     */       
/* 118 */       int length = ScriptRuntime.toInt32(arg0);
/* 119 */       NativeArrayBuffer buffer = makeArrayBuffer(cx, scope, length);
/* 120 */       return construct(buffer, 0, length);
/*     */     } 
/*     */     
/* 123 */     if (arg0 instanceof NativeTypedArrayView) {
/*     */ 
/*     */       
/* 126 */       NativeTypedArrayView<T> src = (NativeTypedArrayView<T>)arg0;
/* 127 */       NativeArrayBuffer na = makeArrayBuffer(cx, scope, src.length);
/* 128 */       NativeTypedArrayView<T> v = construct(na, 0, src.length);
/*     */       
/* 130 */       for (int i = 0; i < src.length; i++) {
/* 131 */         v.js_set(i, src.js_get(i));
/*     */       }
/* 133 */       return v;
/*     */     } 
/*     */     
/* 136 */     if (arg0 instanceof NativeArrayBuffer) {
/*     */       int byteLen;
/* 138 */       NativeArrayBuffer na = (NativeArrayBuffer)arg0;
/* 139 */       int byteOff = isArg(args, 1) ? ScriptRuntime.toInt32(args[1]) : 0;
/*     */ 
/*     */       
/* 142 */       if (isArg(args, 2)) {
/* 143 */         byteLen = ScriptRuntime.toInt32(args[2]) * getBytesPerElement();
/*     */       } else {
/* 145 */         byteLen = na.getLength() - byteOff;
/*     */       } 
/*     */       
/* 148 */       if (byteOff < 0 || byteOff > na.buffer.length) {
/* 149 */         throw ScriptRuntime.rangeError("offset out of range");
/*     */       }
/* 151 */       if (byteLen < 0 || byteOff + byteLen > na.buffer.length) {
/* 152 */         throw ScriptRuntime.rangeError("length out of range");
/*     */       }
/* 154 */       if (byteOff % getBytesPerElement() != 0) {
/* 155 */         throw ScriptRuntime.rangeError("offset must be a multiple of the byte size");
/*     */       }
/* 157 */       if (byteLen % getBytesPerElement() != 0) {
/* 158 */         throw ScriptRuntime.rangeError("offset and buffer must be a multiple of the byte size");
/*     */       }
/*     */ 
/*     */       
/* 162 */       return construct(na, byteOff, byteLen / getBytesPerElement());
/*     */     } 
/*     */     
/* 165 */     if (arg0 instanceof NativeArray) {
/*     */       
/* 167 */       NativeArray array = (NativeArray)arg0;
/*     */       
/* 169 */       NativeArrayBuffer na = makeArrayBuffer(cx, scope, array.size());
/* 170 */       NativeTypedArrayView<T> v = construct(na, 0, array.size());
/* 171 */       for (int i = 0; i < array.size(); i++) {
/*     */ 
/*     */         
/* 174 */         Object value = array.get(i, (Scriptable)array);
/* 175 */         if (value == Scriptable.NOT_FOUND || value == Undefined.instance) {
/* 176 */           v.js_set(i, ScriptRuntime.NaNobj);
/* 177 */         } else if (value instanceof Wrapper) {
/* 178 */           v.js_set(i, ((Wrapper)value).unwrap());
/*     */         } else {
/* 180 */           v.js_set(i, value);
/*     */         } 
/*     */       } 
/* 183 */       return v;
/*     */     } 
/*     */     
/* 186 */     if (ScriptRuntime.isArrayObject(arg0)) {
/*     */       
/* 188 */       Object[] arrayElements = ScriptRuntime.getArrayElements((Scriptable)arg0);
/*     */       
/* 190 */       NativeArrayBuffer na = makeArrayBuffer(cx, scope, arrayElements.length);
/* 191 */       NativeTypedArrayView<T> v = construct(na, 0, arrayElements.length);
/* 192 */       for (int i = 0; i < arrayElements.length; i++) {
/* 193 */         v.js_set(i, arrayElements[i]);
/*     */       }
/* 195 */       return v;
/*     */     } 
/* 197 */     throw ScriptRuntime.constructError("Error", "invalid argument");
/*     */   }
/*     */   
/*     */   private void setRange(NativeTypedArrayView<T> v, int off) {
/* 201 */     if (off >= this.length) {
/* 202 */       throw ScriptRuntime.rangeError("offset out of range");
/*     */     }
/*     */     
/* 205 */     if (v.length > this.length - off) {
/* 206 */       throw ScriptRuntime.rangeError("source array too long");
/*     */     }
/*     */     
/* 209 */     if (v.arrayBuffer == this.arrayBuffer) {
/*     */       
/* 211 */       Object[] tmp = new Object[v.length]; int i;
/* 212 */       for (i = 0; i < v.length; i++) {
/* 213 */         tmp[i] = v.js_get(i);
/*     */       }
/* 215 */       for (i = 0; i < v.length; i++) {
/* 216 */         js_set(i + off, tmp[i]);
/*     */       }
/*     */     } else {
/* 219 */       for (int i = 0; i < v.length; i++) {
/* 220 */         js_set(i + off, v.js_get(i));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setRange(NativeArray a, int off) {
/* 226 */     if (off > this.length) {
/* 227 */       throw ScriptRuntime.rangeError("offset out of range");
/*     */     }
/* 229 */     if (off + a.size() > this.length) {
/* 230 */       throw ScriptRuntime.rangeError("offset + length out of range");
/*     */     }
/*     */     
/* 233 */     int pos = off;
/* 234 */     for (Object val : a) {
/* 235 */       js_set(pos, val);
/* 236 */       pos++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object js_subarray(Context cx, Scriptable scope, int s, int e) {
/* 241 */     int start = (s < 0) ? (this.length + s) : s;
/* 242 */     int end = (e < 0) ? (this.length + e) : e;
/*     */ 
/*     */     
/* 245 */     start = Math.max(0, start);
/* 246 */     end = Math.min(this.length, end);
/* 247 */     int len = Math.max(0, end - start);
/* 248 */     int byteOff = Math.min(start * getBytesPerElement(), this.arrayBuffer.getLength());
/*     */     
/* 250 */     return cx.newObject(scope, 
/*     */         
/* 252 */         getClassName(), new Object[] { this.arrayBuffer, 
/* 253 */           Integer.valueOf(byteOff), Integer.valueOf(len) });
/*     */   } public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     NativeTypedArrayView<T> realThis;
/*     */     int arrayLength;
/*     */     StringBuilder builder;
/*     */     int i;
/*     */     NativeTypedArrayView<T> self;
/*     */     int start, end;
/* 261 */     if (!f.hasTag(getClassName())) {
/* 262 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 264 */     int id = f.methodId();
/* 265 */     switch (id) {
/*     */       case 1:
/* 267 */         if (thisObj != null && cx.getLanguageVersion() >= 200) {
/* 268 */           throw ScriptRuntime.typeErrorById("msg.only.from.new", new Object[] { getClassName() });
/*     */         }
/* 270 */         return js_constructor(cx, scope, args);
/*     */       
/*     */       case 2:
/* 273 */         realThis = realThis(thisObj, f);
/* 274 */         arrayLength = realThis.getArrayLength();
/* 275 */         builder = new StringBuilder();
/* 276 */         if (arrayLength > 0) {
/* 277 */           builder.append(ScriptRuntime.toString(realThis.js_get(0)));
/*     */         }
/* 279 */         for (i = 1; i < arrayLength; i++) {
/* 280 */           builder.append(',');
/* 281 */           builder.append(ScriptRuntime.toString(realThis.js_get(i)));
/*     */         } 
/* 283 */         return builder.toString();
/*     */       
/*     */       case 3:
/* 286 */         if (args.length > 0) {
/* 287 */           return realThis(thisObj, f).js_get(ScriptRuntime.toInt32(args[0]));
/*     */         }
/* 289 */         throw ScriptRuntime.constructError("Error", "invalid arguments");
/*     */       
/*     */       case 4:
/* 292 */         if (args.length > 0) {
/* 293 */           NativeTypedArrayView<T> nativeTypedArrayView = realThis(thisObj, f);
/* 294 */           if (args[0] instanceof NativeTypedArrayView) {
/* 295 */             int offset = isArg(args, 1) ? ScriptRuntime.toInt32(args[1]) : 0;
/*     */             
/* 297 */             NativeTypedArrayView<T> nativeView = (NativeTypedArrayView<T>)args[0];
/* 298 */             nativeTypedArrayView.setRange(nativeView, offset);
/* 299 */             return Undefined.instance;
/*     */           } 
/* 301 */           if (args[0] instanceof NativeArray) {
/* 302 */             int offset = isArg(args, 1) ? ScriptRuntime.toInt32(args[1]) : 0;
/* 303 */             nativeTypedArrayView.setRange((NativeArray)args[0], offset);
/* 304 */             return Undefined.instance;
/*     */           } 
/* 306 */           if (args[0] instanceof Scriptable)
/*     */           {
/* 308 */             return Undefined.instance;
/*     */           }
/* 310 */           if (isArg(args, 2)) {
/* 311 */             return nativeTypedArrayView.js_set(ScriptRuntime.toInt32(args[0]), args[1]);
/*     */           }
/*     */         } 
/* 314 */         throw ScriptRuntime.constructError("Error", "invalid arguments");
/*     */       
/*     */       case 5:
/* 317 */         self = realThis(thisObj, f);
/* 318 */         start = isArg(args, 0) ? ScriptRuntime.toInt32(args[0]) : 0;
/* 319 */         end = isArg(args, 1) ? ScriptRuntime.toInt32(args[1]) : self.length;
/* 320 */         if (cx.getLanguageVersion() >= 200 || args.length > 0) {
/* 321 */           return self.js_subarray(cx, scope, start, end);
/*     */         }
/* 323 */         throw ScriptRuntime.constructError("Error", "invalid arguments");
/*     */       
/*     */       case 6:
/* 326 */         return new NativeArrayIterator(scope, thisObj, NativeArrayIterator.ARRAY_ITERATOR_TYPE.VALUES);
/*     */     } 
/* 328 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 333 */     if (id == 6) {
/* 334 */       initPrototypeMethod(getClassName(), id, (Symbol)SymbolKey.ITERATOR, "[Symbol.iterator]", 0);
/*     */       
/*     */       return;
/*     */     } 
/* 338 */     String fnName = null;
/*     */     
/* 340 */     switch (id) {
/*     */       case 1:
/* 342 */         arity = 3;
/* 343 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 346 */         arity = 0;
/* 347 */         s = "toString";
/*     */         break;
/*     */       case 3:
/* 350 */         arity = 1;
/* 351 */         s = "get";
/*     */         break;
/*     */       case 4:
/* 354 */         arity = 2;
/* 355 */         s = "set";
/*     */         break;
/*     */       case 5:
/* 358 */         arity = 2;
/* 359 */         s = "subarray";
/*     */         break;
/*     */       default:
/* 362 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 364 */     initPrototypeMethod(getClassName(), id, s, fnName, arity);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(Symbol k) {
/* 369 */     if (SymbolKey.ITERATOR.equals(k)) {
/* 370 */       return 6;
/*     */     }
/* 372 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 378 */     switch (s)
/*     */     { case "constructor":
/* 380 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 398 */         return id;case "toString": id = 2; return id;case "get": id = 3; return id;case "set": id = 4; return id;case "subarray": id = 5; return id; }  int id = 0; return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/* 415 */     ctor.defineProperty("BYTES_PER_ELEMENT", 
/*     */         
/* 417 */         ScriptRuntime.wrapInt(getBytesPerElement()), 7);
/*     */ 
/*     */     
/* 420 */     super.fillConstructorProperties(ctor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxInstanceId() {
/* 427 */     return 5;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/* 432 */     switch (id) {
/*     */       case 4:
/* 434 */         return "length";
/*     */       case 5:
/* 436 */         return "BYTES_PER_ELEMENT";
/*     */     } 
/* 438 */     return super.getInstanceIdName(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/* 444 */     switch (id) {
/*     */       case 4:
/* 446 */         return ScriptRuntime.wrapInt(this.length);
/*     */       case 5:
/* 448 */         return ScriptRuntime.wrapInt(getBytesPerElement());
/*     */     } 
/* 450 */     return super.getInstanceIdValue(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(String s) {
/*     */     int id;
/* 457 */     switch (s) {
/*     */       case "length":
/* 459 */         id = 4;
/*     */         break;
/*     */       case "BYTES_PER_ELEMENT":
/* 462 */         id = 5;
/*     */         break;
/*     */       default:
/* 465 */         id = 0;
/*     */         break;
/*     */     } 
/* 468 */     if (id == 0) {
/* 469 */       return super.findInstanceIdInfo(s);
/*     */     }
/* 471 */     if (id == 5) {
/* 472 */       return instanceIdInfo(7, id);
/*     */     }
/* 474 */     return instanceIdInfo(5, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getArrayElement(int index) {
/* 488 */     return js_get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setArrayElement(int index, Object value) {
/* 493 */     js_set(index, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getArrayLength() {
/* 498 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> objects) {
/* 506 */     for (Object o : objects) {
/* 507 */       if (!contains(o)) {
/* 508 */         return false;
/*     */       }
/*     */     } 
/* 511 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(Object o) {
/* 517 */     for (int i = 0; i < this.length; i++) {
/* 518 */       if (o.equals(js_get(i))) {
/* 519 */         return i;
/*     */       }
/*     */     } 
/* 522 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 528 */     for (int i = this.length - 1; i >= 0; i--) {
/* 529 */       if (o.equals(js_get(i))) {
/* 530 */         return i;
/*     */       }
/*     */     } 
/* 533 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 539 */     Object[] a = new Object[this.length];
/* 540 */     for (int i = 0; i < this.length; i++) {
/* 541 */       a[i] = js_get(i);
/*     */     }
/* 543 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <U> U[] toArray(U[] ts) {
/*     */     U[] a;
/* 551 */     if (ts.length >= this.length) {
/* 552 */       a = ts;
/*     */     } else {
/* 554 */       a = (U[])Array.newInstance(ts.getClass().getComponentType(), this.length);
/*     */     } 
/*     */     
/* 557 */     for (int i = 0; i < this.length; i++) {
/*     */       try {
/* 559 */         a[i] = (U)js_get(i);
/* 560 */       } catch (ClassCastException cce) {
/* 561 */         throw new ArrayStoreException();
/*     */       } 
/*     */     } 
/* 564 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 570 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 576 */     return (this.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 582 */     return (indexOf(o) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 588 */     if (o == null) {
/* 589 */       return false;
/*     */     }
/*     */     try {
/* 592 */       NativeTypedArrayView<T> v = (NativeTypedArrayView<T>)o;
/* 593 */       if (this.length != v.length) {
/* 594 */         return false;
/*     */       }
/* 596 */       for (int i = 0; i < this.length; i++) {
/* 597 */         if (!js_get(i).equals(v.js_get(i))) {
/* 598 */           return false;
/*     */         }
/*     */       } 
/* 601 */       return true;
/* 602 */     } catch (ClassCastException cce) {
/* 603 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 609 */     int hc = 0;
/* 610 */     for (int i = 0; i < this.length; i++) {
/* 611 */       hc += js_get(i).hashCode();
/*     */     }
/* 613 */     return hc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 619 */     return new NativeTypedArrayIterator<>(this, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListIterator<T> listIterator() {
/* 625 */     return new NativeTypedArrayIterator<>(this, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListIterator<T> listIterator(int start) {
/* 631 */     if (checkIndex(start)) {
/* 632 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 634 */     return new NativeTypedArrayIterator<>(this, start);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> subList(int i, int i2) {
/* 640 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(T aByte) {
/* 646 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int i, T aByte) {
/* 652 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends T> bytes) {
/* 658 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(int i, Collection<? extends T> bytes) {
/* 664 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 670 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T remove(int i) {
/* 676 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 682 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> objects) {
/* 688 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> objects) {
/* 694 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeTypedArrayView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */