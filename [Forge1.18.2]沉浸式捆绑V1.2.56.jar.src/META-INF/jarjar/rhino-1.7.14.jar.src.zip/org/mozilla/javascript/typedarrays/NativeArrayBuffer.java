/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.IdScriptableObject;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeArrayBuffer
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 3110411773054879549L;
/*     */   public static final String CLASS_NAME = "ArrayBuffer";
/*  25 */   private static final byte[] EMPTY_BUF = new byte[0];
/*     */   final byte[] buffer;
/*     */   private static final int Id_constructor = 1;
/*     */   private static final int Id_slice = 2;
/*     */   
/*     */   public String getClassName() {
/*  31 */     return "ArrayBuffer";
/*     */   }
/*     */   private static final int MAX_PROTOTYPE_ID = 2; private static final int ConstructorId_isView = -1; private static final int Id_byteLength = 1; private static final int MAX_INSTANCE_ID = 1;
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  35 */     NativeArrayBuffer na = new NativeArrayBuffer();
/*  36 */     na.exportAsJSClass(2, scope, sealed);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeArrayBuffer() {
/*  41 */     this.buffer = EMPTY_BUF;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeArrayBuffer(double len) {
/*  46 */     if (len >= 2.147483647E9D) {
/*  47 */       throw ScriptRuntime.rangeError("length parameter (" + len + ") is too large ");
/*     */     }
/*  49 */     if (len == Double.NEGATIVE_INFINITY) {
/*  50 */       throw ScriptRuntime.rangeError("Negative array length " + len);
/*     */     }
/*     */ 
/*     */     
/*  54 */     if (len <= -1.0D) {
/*  55 */       throw ScriptRuntime.rangeError("Negative array length " + len);
/*     */     }
/*     */     
/*  58 */     int intLen = ScriptRuntime.toInt32(len);
/*  59 */     if (intLen < 0) {
/*  60 */       throw ScriptRuntime.rangeError("Negative array length " + len);
/*     */     }
/*  62 */     if (intLen == 0) {
/*  63 */       this.buffer = EMPTY_BUF;
/*     */     } else {
/*  65 */       this.buffer = new byte[intLen];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  71 */     return this.buffer.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBuffer() {
/*  79 */     return this.buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeArrayBuffer slice(double s, double e) {
/*  98 */     int end = ScriptRuntime.toInt32(
/*  99 */         Math.max(0.0D, Math.min(this.buffer.length, (e < 0.0D) ? (this.buffer.length + e) : e)));
/*     */     
/* 101 */     int start = ScriptRuntime.toInt32(Math.min(end, Math.max(0.0D, (s < 0.0D) ? (this.buffer.length + s) : s)));
/* 102 */     int len = end - start;
/*     */     
/* 104 */     NativeArrayBuffer newBuf = new NativeArrayBuffer(len);
/* 105 */     System.arraycopy(this.buffer, start, newBuf.buffer, 0, len);
/* 106 */     return newBuf;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     double length;
/*     */     NativeArrayBuffer self;
/*     */     double start, end;
/* 114 */     if (!f.hasTag("ArrayBuffer")) {
/* 115 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 117 */     int id = f.methodId();
/* 118 */     switch (id) {
/*     */       case -1:
/* 120 */         return Boolean.valueOf((
/* 121 */             isArg(args, 0) && args[0] instanceof NativeArrayBufferView));
/*     */       
/*     */       case 1:
/* 124 */         length = isArg(args, 0) ? ScriptRuntime.toNumber(args[0]) : 0.0D;
/* 125 */         return new NativeArrayBuffer(length);
/*     */       
/*     */       case 2:
/* 128 */         self = realThis(thisObj, f);
/* 129 */         start = isArg(args, 0) ? ScriptRuntime.toNumber(args[0]) : 0.0D;
/* 130 */         end = isArg(args, 1) ? ScriptRuntime.toNumber(args[1]) : self.buffer.length;
/* 131 */         return self.slice(start, end);
/*     */     } 
/* 133 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */   
/*     */   private static NativeArrayBuffer realThis(Scriptable thisObj, IdFunctionObject f) {
/* 137 */     return (NativeArrayBuffer)ensureType(thisObj, NativeArrayBuffer.class, f);
/*     */   }
/*     */   
/*     */   private static boolean isArg(Object[] args, int i) {
/* 141 */     return (args.length > i && !Undefined.instance.equals(args[i]));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 148 */     switch (id) {
/*     */       case 1:
/* 150 */         arity = 1;
/* 151 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 154 */         arity = 2;
/* 155 */         s = "slice";
/*     */         break;
/*     */       default:
/* 158 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 160 */     initPrototypeMethod("ArrayBuffer", id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 166 */     switch (s)
/*     */     { case "constructor":
/* 168 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 177 */         return id;case "slice": id = 2; return id; }  int id = 0; return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/* 189 */     addIdFunctionProperty((Scriptable)ctor, "ArrayBuffer", -1, "isView", 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxInstanceId() {
/* 196 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getInstanceIdName(int id) {
/* 201 */     if (id == 1) {
/* 202 */       return "byteLength";
/*     */     }
/* 204 */     return super.getInstanceIdName(id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getInstanceIdValue(int id) {
/* 209 */     if (id == 1) {
/* 210 */       return ScriptRuntime.wrapInt(this.buffer.length);
/*     */     }
/* 212 */     return super.getInstanceIdValue(id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findInstanceIdInfo(String s) {
/* 217 */     if ("byteLength".equals(s)) {
/* 218 */       return instanceIdInfo(5, 1);
/*     */     }
/* 220 */     return super.findInstanceIdInfo(s);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeArrayBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */