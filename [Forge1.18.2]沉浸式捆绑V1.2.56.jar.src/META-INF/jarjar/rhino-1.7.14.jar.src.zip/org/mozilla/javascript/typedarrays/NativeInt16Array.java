/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeInt16Array
/*     */   extends NativeTypedArrayView<Short>
/*     */ {
/*     */   private static final long serialVersionUID = -8592870435287581398L;
/*     */   private static final String CLASS_NAME = "Int16Array";
/*     */   private static final int BYTES_PER_ELEMENT = 2;
/*     */   
/*     */   public NativeInt16Array() {}
/*     */   
/*     */   public NativeInt16Array(NativeArrayBuffer ab, int off, int len) {
/*  33 */     super(ab, off, len, len * 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeInt16Array(int len) {
/*  38 */     this(new NativeArrayBuffer(len * 2.0D), 0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  44 */     return "Int16Array";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  49 */     NativeInt16Array a = new NativeInt16Array();
/*  50 */     a.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeInt16Array construct(NativeArrayBuffer ab, int off, int len) {
/*  56 */     return new NativeInt16Array(ab, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBytesPerElement() {
/*  62 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeInt16Array realThis(Scriptable thisObj, IdFunctionObject f) {
/*  68 */     return (NativeInt16Array)ensureType(thisObj, NativeInt16Array.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_get(int index) {
/*  74 */     if (checkIndex(index)) {
/*  75 */       return Undefined.instance;
/*     */     }
/*  77 */     return ByteIo.readInt16(this.arrayBuffer.buffer, index * 2 + this.offset, useLittleEndian());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_set(int index, Object c) {
/*  83 */     if (checkIndex(index)) {
/*  84 */       return Undefined.instance;
/*     */     }
/*  86 */     int val = Conversions.toInt16(c);
/*  87 */     ByteIo.writeInt16(this.arrayBuffer.buffer, index * 2 + this.offset, val, useLittleEndian());
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Short get(int i) {
/*  94 */     if (checkIndex(i)) {
/*  95 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  97 */     return (Short)js_get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Short set(int i, Short aByte) {
/* 103 */     if (checkIndex(i)) {
/* 104 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 106 */     return (Short)js_set(i, aByte);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeInt16Array.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */