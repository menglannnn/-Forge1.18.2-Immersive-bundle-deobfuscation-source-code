/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.ScriptRuntime;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeFloat64Array
/*     */   extends NativeTypedArrayView<Double>
/*     */ {
/*     */   private static final long serialVersionUID = -1255405650050639335L;
/*     */   private static final String CLASS_NAME = "Float64Array";
/*     */   private static final int BYTES_PER_ELEMENT = 8;
/*     */   
/*     */   public NativeFloat64Array() {}
/*     */   
/*     */   public NativeFloat64Array(NativeArrayBuffer ab, int off, int len) {
/*  34 */     super(ab, off, len, len * 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeFloat64Array(int len) {
/*  39 */     this(new NativeArrayBuffer(len * 8.0D), 0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  45 */     return "Float64Array";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  50 */     NativeFloat64Array a = new NativeFloat64Array();
/*  51 */     a.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeFloat64Array construct(NativeArrayBuffer ab, int off, int len) {
/*  57 */     return new NativeFloat64Array(ab, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBytesPerElement() {
/*  63 */     return 8;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeFloat64Array realThis(Scriptable thisObj, IdFunctionObject f) {
/*  69 */     return (NativeFloat64Array)ensureType(thisObj, NativeFloat64Array.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_get(int index) {
/*  75 */     if (checkIndex(index)) {
/*  76 */       return Undefined.instance;
/*     */     }
/*  78 */     long base = ByteIo.readUint64Primitive(this.arrayBuffer.buffer, index * 8 + this.offset, useLittleEndian());
/*  79 */     return Double.valueOf(Double.longBitsToDouble(base));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_set(int index, Object c) {
/*  85 */     if (checkIndex(index)) {
/*  86 */       return Undefined.instance;
/*     */     }
/*  88 */     double val = ScriptRuntime.toNumber(c);
/*  89 */     long base = Double.doubleToLongBits(val);
/*  90 */     ByteIo.writeUint64(this.arrayBuffer.buffer, index * 8 + this.offset, base, useLittleEndian());
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Double get(int i) {
/*  97 */     if (checkIndex(i)) {
/*  98 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 100 */     return (Double)js_get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Double set(int i, Double aByte) {
/* 106 */     if (checkIndex(i)) {
/* 107 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 109 */     return (Double)js_set(i, aByte);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeFloat64Array.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */