/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeUint16Array
/*     */   extends NativeTypedArrayView<Integer>
/*     */ {
/*     */   private static final long serialVersionUID = 7700018949434240321L;
/*     */   private static final String CLASS_NAME = "Uint16Array";
/*     */   private static final int BYTES_PER_ELEMENT = 2;
/*     */   
/*     */   public NativeUint16Array() {}
/*     */   
/*     */   public NativeUint16Array(NativeArrayBuffer ab, int off, int len) {
/*  33 */     super(ab, off, len, len * 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeUint16Array(int len) {
/*  38 */     this(new NativeArrayBuffer(len * 2.0D), 0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  44 */     return "Uint16Array";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  49 */     NativeUint16Array a = new NativeUint16Array();
/*  50 */     a.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeUint16Array construct(NativeArrayBuffer ab, int off, int len) {
/*  56 */     return new NativeUint16Array(ab, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBytesPerElement() {
/*  62 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeUint16Array realThis(Scriptable thisObj, IdFunctionObject f) {
/*  68 */     return (NativeUint16Array)ensureType(thisObj, NativeUint16Array.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_get(int index) {
/*  74 */     if (checkIndex(index)) {
/*  75 */       return Undefined.instance;
/*     */     }
/*  77 */     return ByteIo.readUint16(this.arrayBuffer.buffer, index * 2 + this.offset, useLittleEndian());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_set(int index, Object c) {
/*  83 */     if (checkIndex(index)) {
/*  84 */       return Undefined.instance;
/*     */     }
/*  86 */     int val = Conversions.toUint16(c);
/*  87 */     ByteIo.writeUint16(this.arrayBuffer.buffer, index * 2 + this.offset, val, useLittleEndian());
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer get(int i) {
/*  94 */     if (checkIndex(i)) {
/*  95 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  97 */     return (Integer)js_get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer set(int i, Integer aByte) {
/* 103 */     if (checkIndex(i)) {
/* 104 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 106 */     return (Integer)js_set(i, aByte);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeUint16Array.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */