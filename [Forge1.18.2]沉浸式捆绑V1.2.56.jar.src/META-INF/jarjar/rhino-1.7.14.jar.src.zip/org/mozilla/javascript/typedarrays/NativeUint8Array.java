/*     */ package org.mozilla.javascript.typedarrays;
/*     */ 
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.IdFunctionObject;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.Undefined;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeUint8Array
/*     */   extends NativeTypedArrayView<Integer>
/*     */ {
/*     */   private static final long serialVersionUID = -3349419704390398895L;
/*     */   private static final String CLASS_NAME = "Uint8Array";
/*     */   
/*     */   public NativeUint8Array() {}
/*     */   
/*     */   public NativeUint8Array(NativeArrayBuffer ab, int off, int len) {
/*  32 */     super(ab, off, len, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeUint8Array(int len) {
/*  37 */     this(new NativeArrayBuffer(len), 0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  43 */     return "Uint8Array";
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  48 */     NativeUint8Array a = new NativeUint8Array();
/*  49 */     a.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeUint8Array construct(NativeArrayBuffer ab, int off, int len) {
/*  55 */     return new NativeUint8Array(ab, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBytesPerElement() {
/*  61 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeUint8Array realThis(Scriptable thisObj, IdFunctionObject f) {
/*  67 */     return (NativeUint8Array)ensureType(thisObj, NativeUint8Array.class, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_get(int index) {
/*  73 */     if (checkIndex(index)) {
/*  74 */       return Undefined.instance;
/*     */     }
/*  76 */     return ByteIo.readUint8(this.arrayBuffer.buffer, index + this.offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object js_set(int index, Object c) {
/*  82 */     if (checkIndex(index)) {
/*  83 */       return Undefined.instance;
/*     */     }
/*  85 */     int val = Conversions.toUint8(c);
/*  86 */     ByteIo.writeUint8(this.arrayBuffer.buffer, index + this.offset, val);
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer get(int i) {
/*  93 */     if (checkIndex(i)) {
/*  94 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  96 */     return (Integer)js_get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer set(int i, Integer aByte) {
/* 102 */     if (checkIndex(i)) {
/* 103 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 105 */     return (Integer)js_set(i, aByte);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\typedarrays\NativeUint8Array.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */