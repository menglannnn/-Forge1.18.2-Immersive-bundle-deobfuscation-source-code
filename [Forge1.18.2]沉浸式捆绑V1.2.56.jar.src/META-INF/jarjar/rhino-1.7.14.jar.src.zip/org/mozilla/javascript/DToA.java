/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ class DToA {
/*      */   static final int DTOSTR_STANDARD = 0;
/*      */   static final int DTOSTR_STANDARD_EXPONENTIAL = 1;
/*      */   static final int DTOSTR_FIXED = 2;
/*      */   static final int DTOSTR_EXPONENTIAL = 3;
/*      */   static final int DTOSTR_PRECISION = 4;
/*      */   private static final int Frac_mask = 1048575;
/*      */   private static final int Exp_shift = 20;
/*      */   private static final int Exp_msk1 = 1048576;
/*      */   private static final long Frac_maskL = 4503599627370495L;
/*      */   private static final int Exp_shiftL = 52;
/*      */   private static final long Exp_msk1L = 4503599627370496L;
/*      */   private static final int Bias = 1023;
/*      */   private static final int P = 53;
/*      */   private static final int Exp_shift1 = 20;
/*      */   private static final int Exp_mask = 2146435072;
/*      */   private static final int Exp_mask_shifted = 2047;
/*      */   private static final int Bndry_mask = 1048575;
/*      */   private static final int Log2P = 1;
/*      */   private static final int Sign_bit = -2147483648;
/*      */   private static final int Exp_11 = 1072693248;
/*      */   private static final int Ten_pmax = 22;
/*      */   private static final int Quick_max = 14;
/*      */   private static final int Bletch = 16;
/*      */   private static final int Frac_mask1 = 1048575;
/*      */   private static final int Int_max = 14;
/*      */   private static final int n_bigtens = 5;
/*      */   
/*      */   private static char BASEDIGIT(int digit) {
/*   34 */     return (char)((digit >= 10) ? (87 + digit) : (48 + digit));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   72 */   private static final double[] tens = new double[] { 1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D, 100000.0D, 1000000.0D, 1.0E7D, 1.0E8D, 1.0E9D, 1.0E10D, 1.0E11D, 1.0E12D, 1.0E13D, 1.0E14D, 1.0E15D, 1.0E16D, 1.0E17D, 1.0E18D, 1.0E19D, 1.0E20D, 1.0E21D, 1.0E22D };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   78 */   private static final double[] bigtens = new double[] { 1.0E16D, 1.0E32D, 1.0E64D, 1.0E128D, 1.0E256D };
/*      */ 
/*      */ 
/*      */   
/*      */   private static int lo0bits(int y) {
/*   83 */     int x = y;
/*      */     
/*   85 */     if ((x & 0x7) != 0) {
/*   86 */       if ((x & 0x1) != 0)
/*   87 */         return 0; 
/*   88 */       if ((x & 0x2) != 0) {
/*   89 */         return 1;
/*      */       }
/*   91 */       return 2;
/*      */     } 
/*   93 */     int k = 0;
/*   94 */     if ((x & 0xFFFF) == 0) {
/*   95 */       k = 16;
/*   96 */       x >>>= 16;
/*      */     } 
/*   98 */     if ((x & 0xFF) == 0) {
/*   99 */       k += 8;
/*  100 */       x >>>= 8;
/*      */     } 
/*  102 */     if ((x & 0xF) == 0) {
/*  103 */       k += 4;
/*  104 */       x >>>= 4;
/*      */     } 
/*  106 */     if ((x & 0x3) == 0) {
/*  107 */       k += 2;
/*  108 */       x >>>= 2;
/*      */     } 
/*  110 */     if ((x & 0x1) == 0) {
/*  111 */       k++;
/*  112 */       x >>>= 1;
/*  113 */       if ((x & 0x1) == 0)
/*  114 */         return 32; 
/*      */     } 
/*  116 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int hi0bits(int x) {
/*  122 */     int k = 0;
/*      */     
/*  124 */     if ((x & 0xFFFF0000) == 0) {
/*  125 */       k = 16;
/*  126 */       x <<= 16;
/*      */     } 
/*  128 */     if ((x & 0xFF000000) == 0) {
/*  129 */       k += 8;
/*  130 */       x <<= 8;
/*      */     } 
/*  132 */     if ((x & 0xF0000000) == 0) {
/*  133 */       k += 4;
/*  134 */       x <<= 4;
/*      */     } 
/*  136 */     if ((x & 0xC0000000) == 0) {
/*  137 */       k += 2;
/*  138 */       x <<= 2;
/*      */     } 
/*  140 */     if ((x & Integer.MIN_VALUE) == 0) {
/*  141 */       k++;
/*  142 */       if ((x & 0x40000000) == 0)
/*  143 */         return 32; 
/*      */     } 
/*  145 */     return k;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void stuffBits(byte[] bits, int offset, int val) {
/*  150 */     bits[offset] = (byte)(val >> 24);
/*  151 */     bits[offset + 1] = (byte)(val >> 16);
/*  152 */     bits[offset + 2] = (byte)(val >> 8);
/*  153 */     bits[offset + 3] = (byte)val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BigInteger d2b(double d, int[] e, int[] bits) {
/*      */     byte[] dbl_bits;
/*      */     int i, k;
/*  163 */     long dBits = Double.doubleToLongBits(d);
/*  164 */     int d0 = (int)(dBits >>> 32L);
/*  165 */     int d1 = (int)dBits;
/*      */     
/*  167 */     int z = d0 & 0xFFFFF;
/*  168 */     d0 &= Integer.MAX_VALUE;
/*      */     int de;
/*  170 */     if ((de = d0 >>> 20) != 0)
/*  171 */       z |= 0x100000; 
/*      */     int y;
/*  173 */     if ((y = d1) != 0) {
/*  174 */       dbl_bits = new byte[8];
/*  175 */       k = lo0bits(y);
/*  176 */       y >>>= k;
/*  177 */       if (k != 0) {
/*  178 */         stuffBits(dbl_bits, 4, y | z << 32 - k);
/*  179 */         z >>= k;
/*      */       } else {
/*      */         
/*  182 */         stuffBits(dbl_bits, 4, y);
/*  183 */       }  stuffBits(dbl_bits, 0, z);
/*  184 */       i = (z != 0) ? 2 : 1;
/*      */     }
/*      */     else {
/*      */       
/*  188 */       dbl_bits = new byte[4];
/*  189 */       k = lo0bits(z);
/*  190 */       z >>>= k;
/*  191 */       stuffBits(dbl_bits, 0, z);
/*  192 */       k += 32;
/*  193 */       i = 1;
/*      */     } 
/*  195 */     if (de != 0) {
/*  196 */       e[0] = de - 1023 - 52 + k;
/*  197 */       bits[0] = 53 - k;
/*      */     } else {
/*      */       
/*  200 */       e[0] = de - 1023 - 52 + 1 + k;
/*  201 */       bits[0] = 32 * i - hi0bits(z);
/*      */     } 
/*  203 */     return new BigInteger(dbl_bits);
/*      */   }
/*      */   static String JS_dtobasestr(int base, double d) {
/*      */     boolean negative;
/*      */     String intDigits;
/*  208 */     if (2 > base || base > 36) {
/*  209 */       throw new IllegalArgumentException("Bad base: " + base);
/*      */     }
/*      */     
/*  212 */     if (Double.isNaN(d))
/*  213 */       return "NaN"; 
/*  214 */     if (Double.isInfinite(d))
/*  215 */       return (d > 0.0D) ? "Infinity" : "-Infinity"; 
/*  216 */     if (d == 0.0D)
/*      */     {
/*  218 */       return "0";
/*      */     }
/*      */ 
/*      */     
/*  222 */     if (d >= 0.0D) {
/*  223 */       negative = false;
/*      */     } else {
/*  225 */       negative = true;
/*  226 */       d = -d;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  232 */     double dfloor = Math.floor(d);
/*  233 */     long lfloor = (long)dfloor;
/*  234 */     if (lfloor == dfloor) {
/*      */       
/*  236 */       intDigits = Long.toString(negative ? -lfloor : lfloor, base);
/*      */     } else {
/*      */       
/*  239 */       long mantissa, floorBits = Double.doubleToLongBits(dfloor);
/*  240 */       int exp = (int)(floorBits >> 52L) & 0x7FF;
/*      */       
/*  242 */       if (exp == 0) {
/*  243 */         mantissa = (floorBits & 0xFFFFFFFFFFFFFL) << 1L;
/*      */       } else {
/*  245 */         mantissa = floorBits & 0xFFFFFFFFFFFFFL | 0x10000000000000L;
/*      */       } 
/*  247 */       if (negative) {
/*  248 */         mantissa = -mantissa;
/*      */       }
/*  250 */       exp -= 1075;
/*  251 */       BigInteger x = BigInteger.valueOf(mantissa);
/*  252 */       if (exp > 0) {
/*  253 */         x = x.shiftLeft(exp);
/*  254 */       } else if (exp < 0) {
/*  255 */         x = x.shiftRight(-exp);
/*      */       } 
/*  257 */       intDigits = x.toString(base);
/*      */     } 
/*      */     
/*  260 */     if (d == dfloor)
/*      */     {
/*  262 */       return intDigits;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  271 */     StringBuilder buffer = new StringBuilder();
/*  272 */     buffer.append(intDigits).append('.');
/*  273 */     double df = d - dfloor;
/*      */     
/*  275 */     long dBits = Double.doubleToLongBits(d);
/*  276 */     int word0 = (int)(dBits >> 32L);
/*  277 */     int word1 = (int)dBits;
/*      */     
/*  279 */     int[] e = new int[1];
/*  280 */     int[] bbits = new int[1];
/*      */     
/*  282 */     BigInteger b = d2b(df, e, bbits);
/*      */ 
/*      */ 
/*      */     
/*  286 */     int s2 = -(word0 >>> 20 & 0x7FF);
/*  287 */     if (s2 == 0)
/*  288 */       s2 = -1; 
/*  289 */     s2 += 1076;
/*      */ 
/*      */     
/*  292 */     BigInteger mlo = BigInteger.valueOf(1L);
/*  293 */     BigInteger mhi = mlo;
/*  294 */     if (word1 == 0 && (word0 & 0xFFFFF) == 0 && (word0 & 0x7FE00000) != 0) {
/*      */ 
/*      */ 
/*      */       
/*  298 */       s2++;
/*  299 */       mhi = BigInteger.valueOf(2L);
/*      */     } 
/*      */     
/*  302 */     b = b.shiftLeft(e[0] + s2);
/*  303 */     BigInteger s = BigInteger.valueOf(1L);
/*  304 */     s = s.shiftLeft(s2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  310 */     BigInteger bigBase = BigInteger.valueOf(base);
/*      */     
/*  312 */     boolean done = false;
/*      */     do {
/*  314 */       b = b.multiply(bigBase);
/*  315 */       BigInteger[] divResult = b.divideAndRemainder(s);
/*  316 */       b = divResult[1];
/*  317 */       int digit = (char)divResult[0].intValue();
/*  318 */       if (mlo == mhi) {
/*  319 */         mlo = mhi = mlo.multiply(bigBase);
/*      */       } else {
/*  321 */         mlo = mlo.multiply(bigBase);
/*  322 */         mhi = mhi.multiply(bigBase);
/*      */       } 
/*      */ 
/*      */       
/*  326 */       int j = b.compareTo(mlo);
/*      */       
/*  328 */       BigInteger delta = s.subtract(mhi);
/*  329 */       int j1 = (delta.signum() <= 0) ? 1 : b.compareTo(delta);
/*      */       
/*  331 */       if (j1 == 0 && (word1 & 0x1) == 0) {
/*  332 */         if (j > 0)
/*  333 */           digit++; 
/*  334 */         done = true;
/*      */       }
/*  336 */       else if (j < 0 || (j == 0 && (word1 & 0x1) == 0)) {
/*  337 */         if (j1 > 0) {
/*      */ 
/*      */           
/*  340 */           b = b.shiftLeft(1);
/*  341 */           j1 = b.compareTo(s);
/*  342 */           if (j1 > 0)
/*      */           {
/*  344 */             digit++; } 
/*      */         } 
/*  346 */         done = true;
/*  347 */       } else if (j1 > 0) {
/*  348 */         digit++;
/*  349 */         done = true;
/*      */       } 
/*      */       
/*  352 */       buffer.append(BASEDIGIT(digit));
/*  353 */     } while (!done);
/*      */     
/*  355 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int word0(double d) {
/*  394 */     long dBits = Double.doubleToLongBits(d);
/*  395 */     return (int)(dBits >> 32L);
/*      */   }
/*      */ 
/*      */   
/*      */   static double setWord0(double d, int i) {
/*  400 */     long dBits = Double.doubleToLongBits(d);
/*  401 */     dBits = i << 32L | dBits & 0xFFFFFFFFL;
/*  402 */     return Double.longBitsToDouble(dBits);
/*      */   }
/*      */ 
/*      */   
/*      */   static int word1(double d) {
/*  407 */     long dBits = Double.doubleToLongBits(d);
/*  408 */     return (int)dBits;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static BigInteger pow5mult(BigInteger b, int k) {
/*  415 */     return b.multiply(BigInteger.valueOf(5L).pow(k));
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean roundOff(StringBuilder buf) {
/*  420 */     int i = buf.length();
/*  421 */     while (i != 0) {
/*  422 */       i--;
/*  423 */       char c = buf.charAt(i);
/*  424 */       if (c != '9') {
/*  425 */         buf.setCharAt(i, (char)(c + 1));
/*  426 */         buf.setLength(i + 1);
/*  427 */         return false;
/*      */       } 
/*      */     } 
/*  430 */     buf.setLength(0);
/*  431 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int JS_dtoa(double d, int mode, boolean biasUp, int ndigits, boolean[] sign, StringBuilder buf) {
/*      */     int b2, b5, s2, s5;
/*      */     char dig;
/*      */     double d2;
/*      */     boolean denorm;
/*  485 */     int[] be = new int[1];
/*  486 */     int[] bbits = new int[1];
/*      */ 
/*      */ 
/*      */     
/*  490 */     if ((word0(d) & Integer.MIN_VALUE) != 0) {
/*      */       
/*  492 */       sign[0] = true;
/*      */       
/*  494 */       d = setWord0(d, word0(d) & Integer.MAX_VALUE);
/*      */     } else {
/*      */       
/*  497 */       sign[0] = false;
/*      */     } 
/*  499 */     if ((word0(d) & 0x7FF00000) == 2146435072) {
/*      */       
/*  501 */       buf.append((word1(d) == 0 && (word0(d) & 0xFFFFF) == 0) ? "Infinity" : "NaN");
/*  502 */       return 9999;
/*      */     } 
/*  504 */     if (d == 0.0D) {
/*      */       
/*  506 */       buf.setLength(0);
/*  507 */       buf.append('0');
/*  508 */       return 1;
/*      */     } 
/*      */     
/*  511 */     BigInteger b = d2b(d, be, bbits); int i;
/*  512 */     if ((i = word0(d) >>> 20 & 0x7FF) != 0) {
/*  513 */       d2 = setWord0(d, word0(d) & 0xFFFFF | 0x3FF00000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  535 */       i -= 1023;
/*  536 */       denorm = false;
/*      */     }
/*      */     else {
/*      */       
/*  540 */       i = bbits[0] + be[0] + 1074;
/*      */ 
/*      */       
/*  543 */       long x = (i > 32) ? (word0(d) << 64 - i | (word1(d) >>> i - 32)) : (word1(d) << 32 - i);
/*      */ 
/*      */       
/*  546 */       d2 = setWord0(x, word0(x) - 32505856);
/*  547 */       i -= 1075;
/*  548 */       denorm = true;
/*      */     } 
/*      */     
/*  551 */     double ds = (d2 - 1.5D) * 0.289529654602168D + 0.1760912590558D + i * 0.301029995663981D;
/*  552 */     int k = (int)ds;
/*  553 */     if (ds < 0.0D && ds != k)
/*  554 */       k--; 
/*  555 */     boolean k_check = true;
/*  556 */     if (k >= 0 && k <= 22) {
/*  557 */       if (d < tens[k])
/*  558 */         k--; 
/*  559 */       k_check = false;
/*      */     } 
/*      */ 
/*      */     
/*  563 */     int j = bbits[0] - i - 1;
/*      */     
/*  565 */     if (j >= 0) {
/*  566 */       b2 = 0;
/*  567 */       s2 = j;
/*      */     } else {
/*      */       
/*  570 */       b2 = -j;
/*  571 */       s2 = 0;
/*      */     } 
/*  573 */     if (k >= 0) {
/*  574 */       b5 = 0;
/*  575 */       s5 = k;
/*  576 */       s2 += k;
/*      */     } else {
/*      */       
/*  579 */       b2 -= k;
/*  580 */       b5 = -k;
/*  581 */       s5 = 0;
/*      */     } 
/*      */ 
/*      */     
/*  585 */     if (mode < 0 || mode > 9)
/*  586 */       mode = 0; 
/*  587 */     boolean try_quick = true;
/*  588 */     if (mode > 5) {
/*  589 */       mode -= 4;
/*  590 */       try_quick = false;
/*      */     } 
/*  592 */     boolean leftright = true;
/*  593 */     int ilim1 = 0, ilim = ilim1;
/*  594 */     switch (mode) {
/*      */       case 0:
/*      */       case 1:
/*  597 */         ilim = ilim1 = -1;
/*  598 */         i = 18;
/*  599 */         ndigits = 0;
/*      */         break;
/*      */       case 2:
/*  602 */         leftright = false;
/*      */       
/*      */       case 4:
/*  605 */         if (ndigits <= 0)
/*  606 */           ndigits = 1; 
/*  607 */         ilim = ilim1 = i = ndigits;
/*      */         break;
/*      */       case 3:
/*  610 */         leftright = false;
/*      */       
/*      */       case 5:
/*  613 */         i = ndigits + k + 1;
/*  614 */         ilim = i;
/*  615 */         ilim1 = i - 1;
/*  616 */         if (i <= 0) {
/*  617 */           i = 1;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  623 */     boolean fast_failed = false;
/*  624 */     if (ilim >= 0 && ilim <= 14 && try_quick) {
/*      */ 
/*      */ 
/*      */       
/*  628 */       i = 0;
/*  629 */       d2 = d;
/*  630 */       int k0 = k;
/*  631 */       int ilim0 = ilim;
/*  632 */       int ieps = 2;
/*      */       
/*  634 */       if (k > 0) {
/*  635 */         ds = tens[k & 0xF];
/*  636 */         j = k >> 4;
/*  637 */         if ((j & 0x10) != 0) {
/*      */           
/*  639 */           j &= 0xF;
/*  640 */           d /= bigtens[4];
/*  641 */           ieps++;
/*      */         } 
/*  643 */         for (; j != 0; j >>= 1, i++) {
/*  644 */           if ((j & 0x1) != 0) {
/*  645 */             ieps++;
/*  646 */             ds *= bigtens[i];
/*      */           } 
/*  648 */         }  d /= ds;
/*      */       } else {
/*  650 */         int j1; if ((j1 = -k) != 0) {
/*  651 */           d *= tens[j1 & 0xF];
/*  652 */           for (j = j1 >> 4; j != 0; j >>= 1, i++) {
/*  653 */             if ((j & 0x1) != 0) {
/*  654 */               ieps++;
/*  655 */               d *= bigtens[i];
/*      */             } 
/*      */           } 
/*      */         } 
/*  659 */       }  if (k_check && d < 1.0D && ilim > 0) {
/*  660 */         if (ilim1 <= 0) {
/*  661 */           fast_failed = true;
/*      */         } else {
/*  663 */           ilim = ilim1;
/*  664 */           k--;
/*  665 */           d *= 10.0D;
/*  666 */           ieps++;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  672 */       double eps = ieps * d + 7.0D;
/*  673 */       eps = setWord0(eps, word0(eps) - 54525952);
/*  674 */       if (ilim == 0) {
/*  675 */         BigInteger bigInteger1 = null, bigInteger2 = bigInteger1;
/*  676 */         d -= 5.0D;
/*  677 */         if (d > eps) {
/*  678 */           buf.append('1');
/*  679 */           k++;
/*  680 */           return k + 1;
/*      */         } 
/*  682 */         if (d < -eps) {
/*  683 */           buf.setLength(0);
/*  684 */           buf.append('0');
/*  685 */           return 1;
/*      */         } 
/*  687 */         fast_failed = true;
/*      */       } 
/*  689 */       if (!fast_failed) {
/*  690 */         fast_failed = true;
/*  691 */         if (leftright) {
/*      */ 
/*      */ 
/*      */           
/*  695 */           eps = 0.5D / tens[ilim - 1] - eps;
/*  696 */           i = 0; while (true) {
/*  697 */             long L = (long)d;
/*  698 */             d -= L;
/*  699 */             buf.append((char)(int)(48L + L));
/*  700 */             if (d < eps) {
/*  701 */               return k + 1;
/*      */             }
/*  703 */             if (1.0D - d < eps) {
/*      */               char lastCh;
/*      */               
/*      */               while (true) {
/*  707 */                 lastCh = buf.charAt(buf.length() - 1);
/*  708 */                 buf.setLength(buf.length() - 1);
/*  709 */                 if (lastCh != '9')
/*  710 */                   break;  if (buf.length() == 0) {
/*  711 */                   k++;
/*  712 */                   lastCh = '0';
/*      */                   break;
/*      */                 } 
/*      */               } 
/*  716 */               buf.append((char)(lastCh + 1));
/*  717 */               return k + 1;
/*      */             } 
/*  719 */             if (++i >= ilim)
/*      */               break; 
/*  721 */             eps *= 10.0D;
/*  722 */             d *= 10.0D;
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  727 */           eps *= tens[ilim - 1];
/*  728 */           for (i = 1;; i++, d *= 10.0D) {
/*  729 */             long L = (long)d;
/*  730 */             d -= L;
/*  731 */             buf.append((char)(int)(48L + L));
/*  732 */             if (i == ilim) {
/*  733 */               if (d > 0.5D + eps) {
/*      */                 char lastCh;
/*      */                 
/*      */                 while (true) {
/*  737 */                   lastCh = buf.charAt(buf.length() - 1);
/*  738 */                   buf.setLength(buf.length() - 1);
/*  739 */                   if (lastCh != '9')
/*  740 */                     break;  if (buf.length() == 0) {
/*  741 */                     k++;
/*  742 */                     lastCh = '0';
/*      */                     break;
/*      */                   } 
/*      */                 } 
/*  746 */                 buf.append((char)(lastCh + 1));
/*  747 */                 return k + 1;
/*      */               } 
/*      */               
/*  750 */               if (d < 0.5D - eps) {
/*  751 */                 stripTrailingZeroes(buf);
/*      */ 
/*      */                 
/*  754 */                 return k + 1;
/*      */               } 
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  761 */       if (fast_failed) {
/*  762 */         buf.setLength(0);
/*  763 */         d = d2;
/*  764 */         k = k0;
/*  765 */         ilim = ilim0;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  771 */     if (be[0] >= 0 && k <= 14) {
/*      */       
/*  773 */       ds = tens[k];
/*  774 */       if (ndigits < 0 && ilim <= 0) {
/*  775 */         BigInteger bigInteger1 = null, bigInteger2 = bigInteger1;
/*  776 */         if (ilim < 0 || d < 5.0D * ds || (!biasUp && d == 5.0D * ds)) {
/*  777 */           buf.setLength(0);
/*  778 */           buf.append('0');
/*  779 */           return 1;
/*      */         } 
/*  781 */         buf.append('1');
/*  782 */         k++;
/*  783 */         return k + 1;
/*      */       } 
/*  785 */       for (i = 1;; i++) {
/*  786 */         long L = (long)(d / ds);
/*  787 */         d -= L * ds;
/*  788 */         buf.append((char)(int)(48L + L));
/*  789 */         if (i == ilim) {
/*  790 */           d += d;
/*  791 */           if (d > ds || (d == ds && ((L & 0x1L) != 0L || biasUp))) {
/*      */             char lastCh;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             while (true) {
/*  802 */               lastCh = buf.charAt(buf.length() - 1);
/*  803 */               buf.setLength(buf.length() - 1);
/*  804 */               if (lastCh != '9')
/*  805 */                 break;  if (buf.length() == 0) {
/*  806 */                 k++;
/*  807 */                 lastCh = '0';
/*      */                 break;
/*      */               } 
/*      */             } 
/*  811 */             buf.append((char)(lastCh + 1));
/*      */           } 
/*      */           break;
/*      */         } 
/*  815 */         d *= 10.0D;
/*  816 */         if (d == 0.0D)
/*      */           break; 
/*      */       } 
/*  819 */       return k + 1;
/*      */     } 
/*      */     
/*  822 */     int m2 = b2;
/*  823 */     int m5 = b5;
/*  824 */     BigInteger mlo = null, mhi = mlo;
/*  825 */     if (leftright) {
/*  826 */       if (mode < 2) {
/*  827 */         i = denorm ? (be[0] + 1075) : (54 - bbits[0]);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  832 */         j = ilim - 1;
/*  833 */         if (m5 >= j) {
/*  834 */           m5 -= j;
/*      */         } else {
/*  836 */           s5 += j -= m5;
/*  837 */           b5 += j;
/*  838 */           m5 = 0;
/*      */         } 
/*  840 */         if ((i = ilim) < 0) {
/*  841 */           m2 -= i;
/*  842 */           i = 0;
/*      */         } 
/*      */       } 
/*      */       
/*  846 */       b2 += i;
/*  847 */       s2 += i;
/*  848 */       mhi = BigInteger.valueOf(1L);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  854 */     if (m2 > 0 && s2 > 0) {
/*  855 */       i = (m2 < s2) ? m2 : s2;
/*  856 */       b2 -= i;
/*  857 */       m2 -= i;
/*  858 */       s2 -= i;
/*      */     } 
/*      */ 
/*      */     
/*  862 */     if (b5 > 0) {
/*  863 */       if (leftright) {
/*  864 */         if (m5 > 0) {
/*  865 */           mhi = pow5mult(mhi, m5);
/*  866 */           BigInteger b1 = mhi.multiply(b);
/*  867 */           b = b1;
/*      */         } 
/*  869 */         if ((j = b5 - m5) != 0) {
/*  870 */           b = pow5mult(b, j);
/*      */         }
/*      */       } else {
/*  873 */         b = pow5mult(b, b5);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  878 */     BigInteger S = BigInteger.valueOf(1L);
/*  879 */     if (s5 > 0) {
/*  880 */       S = pow5mult(S, s5);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  885 */     boolean spec_case = false;
/*  886 */     if (mode < 2 && 
/*  887 */       word1(d) == 0 && (word0(d) & 0xFFFFF) == 0 && (
/*  888 */       word0(d) & 0x7FE00000) != 0) {
/*      */ 
/*      */ 
/*      */       
/*  892 */       b2++;
/*  893 */       s2++;
/*  894 */       spec_case = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  905 */     byte[] S_bytes = S.toByteArray();
/*  906 */     int S_hiWord = 0;
/*  907 */     for (int idx = 0; idx < 4; idx++) {
/*  908 */       S_hiWord <<= 8;
/*  909 */       if (idx < S_bytes.length)
/*  910 */         S_hiWord |= S_bytes[idx] & 0xFF; 
/*      */     } 
/*  912 */     if ((i = ((s5 != 0) ? (32 - hi0bits(S_hiWord)) : 1) + s2 & 0x1F) != 0) {
/*  913 */       i = 32 - i;
/*      */     }
/*  915 */     if (i > 4) {
/*  916 */       i -= 4;
/*  917 */       b2 += i;
/*  918 */       m2 += i;
/*  919 */       s2 += i;
/*      */     }
/*  921 */     else if (i < 4) {
/*  922 */       i += 28;
/*  923 */       b2 += i;
/*  924 */       m2 += i;
/*  925 */       s2 += i;
/*      */     } 
/*      */     
/*  928 */     if (b2 > 0)
/*  929 */       b = b.shiftLeft(b2); 
/*  930 */     if (s2 > 0) {
/*  931 */       S = S.shiftLeft(s2);
/*      */     }
/*      */     
/*  934 */     if (k_check && 
/*  935 */       b.compareTo(S) < 0) {
/*  936 */       k--;
/*  937 */       b = b.multiply(BigInteger.valueOf(10L));
/*  938 */       if (leftright)
/*  939 */         mhi = mhi.multiply(BigInteger.valueOf(10L)); 
/*  940 */       ilim = ilim1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  945 */     if (ilim <= 0 && mode > 2) {
/*      */ 
/*      */       
/*  948 */       if (ilim < 0 || (
/*  949 */         i = b.compareTo(S = S.multiply(BigInteger.valueOf(5L)))) < 0 || (i == 0 && !biasUp)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  956 */         buf.setLength(0);
/*  957 */         buf.append('0');
/*  958 */         return 1;
/*      */       } 
/*      */ 
/*      */       
/*  962 */       buf.append('1');
/*  963 */       k++;
/*  964 */       return k + 1;
/*      */     } 
/*  966 */     if (leftright) {
/*  967 */       if (m2 > 0) {
/*  968 */         mhi = mhi.shiftLeft(m2);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  974 */       mlo = mhi;
/*  975 */       if (spec_case) {
/*  976 */         mhi = mlo;
/*  977 */         mhi = mhi.shiftLeft(1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  982 */       for (i = 1;; i++) {
/*  983 */         BigInteger[] divResult = b.divideAndRemainder(S);
/*  984 */         b = divResult[1];
/*  985 */         dig = (char)(divResult[0].intValue() + 48);
/*      */ 
/*      */ 
/*      */         
/*  989 */         j = b.compareTo(mlo);
/*      */         
/*  991 */         BigInteger delta = S.subtract(mhi);
/*  992 */         int j1 = (delta.signum() <= 0) ? 1 : b.compareTo(delta);
/*      */         
/*  994 */         if (j1 == 0 && mode == 0 && (word1(d) & 0x1) == 0) {
/*  995 */           if (dig == '9') {
/*  996 */             buf.append('9');
/*  997 */             if (roundOff(buf)) {
/*  998 */               k++;
/*  999 */               buf.append('1');
/*      */             } 
/* 1001 */             return k + 1;
/*      */           } 
/*      */           
/* 1004 */           if (j > 0)
/* 1005 */             dig = (char)(dig + 1); 
/* 1006 */           buf.append(dig);
/* 1007 */           return k + 1;
/*      */         } 
/* 1009 */         if (j < 0 || (j == 0 && mode == 0 && (
/*      */ 
/*      */           
/* 1012 */           word1(d) & 0x1) == 0)) {
/*      */           
/* 1014 */           if (j1 > 0) {
/*      */ 
/*      */             
/* 1017 */             b = b.shiftLeft(1);
/* 1018 */             j1 = b.compareTo(S);
/* 1019 */             dig = (char)(dig + 1); if ((j1 > 0 || (j1 == 0 && ((dig & 0x1) == 1 || biasUp))) && dig == '9') {
/*      */               
/* 1021 */               buf.append('9');
/* 1022 */               if (roundOff(buf)) {
/* 1023 */                 k++;
/* 1024 */                 buf.append('1');
/*      */               } 
/* 1026 */               return k + 1;
/*      */             } 
/*      */           } 
/*      */           
/* 1030 */           buf.append(dig);
/* 1031 */           return k + 1;
/*      */         } 
/* 1033 */         if (j1 > 0) {
/* 1034 */           if (dig == '9') {
/*      */ 
/*      */ 
/*      */             
/* 1038 */             buf.append('9');
/* 1039 */             if (roundOff(buf)) {
/* 1040 */               k++;
/* 1041 */               buf.append('1');
/*      */             } 
/* 1043 */             return k + 1;
/*      */           } 
/* 1045 */           buf.append((char)(dig + 1));
/* 1046 */           return k + 1;
/*      */         } 
/* 1048 */         buf.append(dig);
/* 1049 */         if (i == ilim)
/*      */           break; 
/* 1051 */         b = b.multiply(BigInteger.valueOf(10L));
/* 1052 */         if (mlo == mhi) {
/* 1053 */           mlo = mhi = mhi.multiply(BigInteger.valueOf(10L));
/*      */         } else {
/* 1055 */           mlo = mlo.multiply(BigInteger.valueOf(10L));
/* 1056 */           mhi = mhi.multiply(BigInteger.valueOf(10L));
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 1061 */       for (i = 1;; i++) {
/*      */         
/* 1063 */         BigInteger[] divResult = b.divideAndRemainder(S);
/* 1064 */         b = divResult[1];
/* 1065 */         dig = (char)(divResult[0].intValue() + 48);
/* 1066 */         buf.append(dig);
/* 1067 */         if (i >= ilim)
/*      */           break; 
/* 1069 */         b = b.multiply(BigInteger.valueOf(10L));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1074 */     b = b.shiftLeft(1);
/* 1075 */     j = b.compareTo(S);
/* 1076 */     if (j > 0 || (j == 0 && ((dig & 0x1) == 1 || biasUp))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1085 */       if (roundOff(buf)) {
/* 1086 */         k++;
/* 1087 */         buf.append('1');
/* 1088 */         return k + 1;
/*      */       } 
/*      */     } else {
/*      */       
/* 1092 */       stripTrailingZeroes(buf);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1106 */     return k + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void stripTrailingZeroes(StringBuilder buf) {
/* 1114 */     int bl = buf.length();
/* 1115 */     while (bl-- > 0 && buf.charAt(bl) == '0');
/*      */ 
/*      */     
/* 1118 */     buf.setLength(bl + 1);
/*      */   }
/*      */ 
/*      */   
/* 1122 */   private static final int[] dtoaModes = new int[] { 0, 0, 3, 2, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void JS_dtostr(StringBuilder buffer, int mode, int precision, double d) {
/* 1133 */     boolean[] sign = new boolean[1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1139 */     if (mode == 2 && (d >= 1.0E21D || d <= -1.0E21D)) {
/* 1140 */       mode = 0;
/*      */     }
/* 1142 */     int decPt = JS_dtoa(d, dtoaModes[mode], (mode >= 2), precision, sign, buffer);
/* 1143 */     int nDigits = buffer.length();
/*      */ 
/*      */     
/* 1146 */     if (decPt != 9999) {
/* 1147 */       boolean exponentialNotation = false;
/* 1148 */       int minNDigits = 0;
/*      */ 
/*      */       
/* 1151 */       switch (mode) {
/*      */         case 0:
/* 1153 */           if (decPt < -5 || decPt > 21) {
/* 1154 */             exponentialNotation = true; break;
/*      */           } 
/* 1156 */           minNDigits = decPt;
/*      */           break;
/*      */         
/*      */         case 2:
/* 1160 */           if (precision >= 0) {
/* 1161 */             minNDigits = decPt + precision; break;
/*      */           } 
/* 1163 */           minNDigits = decPt;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/* 1168 */           minNDigits = precision;
/*      */         
/*      */         case 1:
/* 1171 */           exponentialNotation = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/* 1176 */           minNDigits = precision;
/* 1177 */           if (decPt < -5 || decPt > precision) {
/* 1178 */             exponentialNotation = true;
/*      */           }
/*      */           break;
/*      */       } 
/*      */       
/* 1183 */       if (nDigits < minNDigits) {
/* 1184 */         int p = minNDigits;
/* 1185 */         nDigits = minNDigits;
/*      */         do {
/* 1187 */           buffer.append('0');
/* 1188 */         } while (buffer.length() != p);
/*      */       } 
/*      */       
/* 1191 */       if (exponentialNotation) {
/*      */         
/* 1193 */         if (nDigits != 1) {
/* 1194 */           buffer.insert(1, '.');
/*      */         }
/* 1196 */         buffer.append('e');
/* 1197 */         if (decPt - 1 >= 0)
/* 1198 */           buffer.append('+'); 
/* 1199 */         buffer.append(decPt - 1);
/*      */       }
/* 1201 */       else if (decPt != nDigits) {
/*      */ 
/*      */         
/* 1204 */         if (decPt > 0) {
/*      */           
/* 1206 */           buffer.insert(decPt, '.');
/*      */         } else {
/*      */           
/* 1209 */           for (int i = 0; i < 1 - decPt; i++)
/* 1210 */             buffer.insert(0, '0'); 
/* 1211 */           buffer.insert(1, '.');
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1217 */     if (sign[0] && (
/* 1218 */       word0(d) != Integer.MIN_VALUE || word1(d) != 0) && ((
/* 1219 */       word0(d) & 0x7FF00000) != 2146435072 || (
/* 1220 */       word1(d) == 0 && (word0(d) & 0xFFFFF) == 0)))
/* 1221 */       buffer.insert(0, '-'); 
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\DToA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */