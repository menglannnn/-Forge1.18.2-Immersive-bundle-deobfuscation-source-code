/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LazilyLoadedCtor
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int STATE_BEFORE_INIT = 0;
/*     */   private static final int STATE_INITIALIZING = 1;
/*     */   private static final int STATE_WITH_VALUE = 2;
/*     */   private final ScriptableObject scope;
/*     */   private final String propertyName;
/*     */   private final String className;
/*     */   private final boolean sealed;
/*     */   private final boolean privileged;
/*     */   private Object initializedValue;
/*     */   private int state;
/*     */   
/*     */   public LazilyLoadedCtor(ScriptableObject scope, String propertyName, String className, boolean sealed) {
/*  36 */     this(scope, propertyName, className, sealed, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LazilyLoadedCtor(ScriptableObject scope, String propertyName, String className, boolean sealed, boolean privileged) {
/*  43 */     this.scope = scope;
/*  44 */     this.propertyName = propertyName;
/*  45 */     this.className = className;
/*  46 */     this.sealed = sealed;
/*  47 */     this.privileged = privileged;
/*  48 */     this.state = 0;
/*     */     
/*  50 */     scope.addLazilyInitializedValue(propertyName, 0, this, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void init() {
/*  56 */     synchronized (this) {
/*  57 */       if (this.state == 1) {
/*  58 */         throw new IllegalStateException("Recursive initialization for " + this.propertyName);
/*     */       }
/*  60 */       if (this.state == 0) {
/*  61 */         this.state = 1;
/*     */ 
/*     */         
/*  64 */         Object value = Scriptable.NOT_FOUND;
/*     */         try {
/*  66 */           value = buildValue();
/*     */         } finally {
/*  68 */           this.initializedValue = value;
/*  69 */           this.state = 2;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   Object getValue() {
/*  77 */     if (this.state != 2)
/*  78 */       throw new IllegalStateException(this.propertyName); 
/*  79 */     return this.initializedValue;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object buildValue() {
/*  84 */     if (this.privileged)
/*     */     {
/*  86 */       return AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             
/*     */             public Object run()
/*     */             {
/*  91 */               return LazilyLoadedCtor.this.buildValue0();
/*     */             }
/*     */           });
/*     */     }
/*  95 */     return buildValue0();
/*     */   }
/*     */ 
/*     */   
/*     */   private Object buildValue0() {
/* 100 */     Class<? extends Scriptable> cl = cast(Kit.classOrNull(this.className));
/* 101 */     if (cl != null) {
/*     */       
/* 103 */       try { Object value = ScriptableObject.buildClassCtor(this.scope, cl, this.sealed, false);
/*     */         
/* 105 */         if (value != null) {
/* 106 */           return value;
/*     */         }
/*     */ 
/*     */         
/* 110 */         value = this.scope.get(this.propertyName, this.scope);
/* 111 */         if (value != Scriptable.NOT_FOUND)
/* 112 */           return value;  }
/* 113 */       catch (InvocationTargetException ex)
/* 114 */       { Throwable target = ex.getTargetException();
/* 115 */         if (target instanceof RuntimeException) {
/* 116 */           throw (RuntimeException)target;
/*     */         } }
/* 118 */       catch (RhinoException rhinoException) {  }
/* 119 */       catch (InstantiationException instantiationException) {  }
/* 120 */       catch (IllegalAccessException illegalAccessException) {  }
/* 121 */       catch (SecurityException securityException) {}
/*     */     }
/*     */     
/* 124 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Class<? extends Scriptable> cast(Class<?> cl) {
/* 129 */     return (Class)cl;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\LazilyLoadedCtor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */