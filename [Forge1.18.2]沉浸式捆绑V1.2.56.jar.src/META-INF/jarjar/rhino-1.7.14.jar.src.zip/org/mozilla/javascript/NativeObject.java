/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeObject
/*     */   extends IdScriptableObject
/*     */   implements Map
/*     */ {
/*     */   private static final long serialVersionUID = -6345305608474346996L;
/*  28 */   private static final Object OBJECT_TAG = "Object"; private static final int ConstructorId_getPrototypeOf = -1; private static final int ConstructorId_keys = -2; private static final int ConstructorId_getOwnPropertyNames = -3; private static final int ConstructorId_getOwnPropertyDescriptor = -4; private static final int ConstructorId_defineProperty = -5; private static final int ConstructorId_isExtensible = -6; private static final int ConstructorId_preventExtensions = -7; private static final int ConstructorId_defineProperties = -8; private static final int ConstructorId_create = -9; private static final int ConstructorId_isSealed = -10; private static final int ConstructorId_isFrozen = -11; private static final int ConstructorId_seal = -12; private static final int ConstructorId_freeze = -13; private static final int ConstructorId_getOwnPropertySymbols = -14; private static final int ConstructorId_assign = -15; private static final int ConstructorId_is = -16; private static final int ConstructorId_setPrototypeOf = -17; private static final int ConstructorId_entries = -18; private static final int ConstructorId_fromEntries = -19; private static final int ConstructorId_values = -20; private static final int Id_constructor = 1; private static final int Id_toString = 2; private static final int Id_toLocaleString = 3; private static final int Id_valueOf = 4; private static final int Id_hasOwnProperty = 5; private static final int Id_propertyIsEnumerable = 6; private static final int Id_isPrototypeOf = 7; private static final int Id_toSource = 8; private static final int Id___defineGetter__ = 9; private static final int Id___defineSetter__ = 10; private static final int Id___lookupGetter__ = 11; private static final int Id___lookupSetter__ = 12; private static final int MAX_PROTOTYPE_ID = 12;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  31 */     NativeObject obj = new NativeObject();
/*  32 */     obj.exportAsJSClass(12, scope, sealed);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  37 */     return "Object";
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  42 */     return ScriptRuntime.defaultObjectToString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/*  47 */     addIdFunctionProperty(ctor, OBJECT_TAG, -1, "getPrototypeOf", 1);
/*  48 */     if ((Context.getCurrentContext()).version >= 200) {
/*  49 */       addIdFunctionProperty(ctor, OBJECT_TAG, -17, "setPrototypeOf", 2);
/*     */       
/*  51 */       addIdFunctionProperty(ctor, OBJECT_TAG, -18, "entries", 1);
/*  52 */       addIdFunctionProperty(ctor, OBJECT_TAG, -19, "fromEntries", 1);
/*  53 */       addIdFunctionProperty(ctor, OBJECT_TAG, -20, "values", 1);
/*     */     } 
/*  55 */     addIdFunctionProperty(ctor, OBJECT_TAG, -2, "keys", 1);
/*  56 */     addIdFunctionProperty(ctor, OBJECT_TAG, -3, "getOwnPropertyNames", 1);
/*     */     
/*  58 */     addIdFunctionProperty(ctor, OBJECT_TAG, -14, "getOwnPropertySymbols", 1);
/*     */     
/*  60 */     addIdFunctionProperty(ctor, OBJECT_TAG, -4, "getOwnPropertyDescriptor", 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     addIdFunctionProperty(ctor, OBJECT_TAG, -5, "defineProperty", 3);
/*  67 */     addIdFunctionProperty(ctor, OBJECT_TAG, -6, "isExtensible", 1);
/*  68 */     addIdFunctionProperty(ctor, OBJECT_TAG, -7, "preventExtensions", 1);
/*     */     
/*  70 */     addIdFunctionProperty(ctor, OBJECT_TAG, -8, "defineProperties", 2);
/*     */     
/*  72 */     addIdFunctionProperty(ctor, OBJECT_TAG, -9, "create", 2);
/*  73 */     addIdFunctionProperty(ctor, OBJECT_TAG, -10, "isSealed", 1);
/*  74 */     addIdFunctionProperty(ctor, OBJECT_TAG, -11, "isFrozen", 1);
/*  75 */     addIdFunctionProperty(ctor, OBJECT_TAG, -12, "seal", 1);
/*  76 */     addIdFunctionProperty(ctor, OBJECT_TAG, -13, "freeze", 1);
/*  77 */     addIdFunctionProperty(ctor, OBJECT_TAG, -15, "assign", 2);
/*  78 */     addIdFunctionProperty(ctor, OBJECT_TAG, -16, "is", 2);
/*  79 */     super.fillConstructorProperties(ctor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*  86 */     switch (id) {
/*     */       case 1:
/*  88 */         arity = 1;
/*  89 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/*  92 */         arity = 0;
/*  93 */         s = "toString";
/*     */         break;
/*     */       case 3:
/*  96 */         arity = 0;
/*  97 */         s = "toLocaleString";
/*     */         break;
/*     */       case 4:
/* 100 */         arity = 0;
/* 101 */         s = "valueOf";
/*     */         break;
/*     */       case 5:
/* 104 */         arity = 1;
/* 105 */         s = "hasOwnProperty";
/*     */         break;
/*     */       case 6:
/* 108 */         arity = 1;
/* 109 */         s = "propertyIsEnumerable";
/*     */         break;
/*     */       case 7:
/* 112 */         arity = 1;
/* 113 */         s = "isPrototypeOf";
/*     */         break;
/*     */       case 8:
/* 116 */         arity = 0;
/* 117 */         s = "toSource";
/*     */         break;
/*     */       case 9:
/* 120 */         arity = 2;
/* 121 */         s = "__defineGetter__";
/*     */         break;
/*     */       case 10:
/* 124 */         arity = 2;
/* 125 */         s = "__defineSetter__";
/*     */         break;
/*     */       case 11:
/* 128 */         arity = 1;
/* 129 */         s = "__lookupGetter__";
/*     */         break;
/*     */       case 12:
/* 132 */         arity = 1;
/* 133 */         s = "__lookupSetter__";
/*     */         break;
/*     */       default:
/* 136 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 138 */     initPrototypeMethod(OBJECT_TAG, id, s, arity); } public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) { Object toString; boolean result; ScriptableObject so; Object object1; Scriptable proto; Object arg; Scriptable targetObj; Object a1; Callable fun; Object object2; ScriptRuntime.StringIdOrIndex stringIdOrIndex; Scriptable scriptable2; Object arg0; Scriptable scriptable1, s; ScriptableObject scriptableObject1; Scriptable obj; int i; Object a2; int index; ScriptableObject scriptableObject3; Object[] ids; ScriptableObject scriptableObject2; Object name, propsObj; ScriptableObject newObject; Callable getterOrSetter; boolean isSetter; Scriptable prototypeProto; int k, j; Object arrayOfObject1[], nameArg, descArg; Scriptable props; boolean bool1; Object gs;
/*     */     int m;
/*     */     ArrayList<Object> syms;
/*     */     Scriptable scriptable3;
/*     */     ScriptableObject desc;
/*     */     int n;
/* 144 */     if (!f.hasTag(OBJECT_TAG)) {
/* 145 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 147 */     int id = f.methodId();
/* 148 */     switch (id) {
/*     */       
/*     */       case 1:
/* 151 */         if (thisObj != null)
/*     */         {
/* 153 */           return f.construct(cx, scope, args);
/*     */         }
/* 155 */         if (args.length == 0 || args[0] == null || Undefined.isUndefined(args[0])) {
/* 156 */           return new NativeObject();
/*     */         }
/* 158 */         return ScriptRuntime.toObject(cx, scope, args[0]);
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 163 */         if (thisObj == null) {
/* 164 */           throw ScriptRuntime.notFunctionError(null);
/*     */         }
/* 166 */         toString = ScriptableObject.getProperty(thisObj, "toString");
/* 167 */         if (!(toString instanceof Callable)) {
/* 168 */           throw ScriptRuntime.notFunctionError(toString);
/*     */         }
/* 170 */         fun = (Callable)toString;
/* 171 */         return fun.call(cx, scope, thisObj, ScriptRuntime.emptyArgs);
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 176 */         if (cx.hasFeature(4)) {
/*     */           
/* 178 */           String str = ScriptRuntime.defaultObjectToSource(cx, scope, thisObj, args);
/*     */ 
/*     */           
/* 181 */           int L = str.length();
/* 182 */           if (L != 0 && str.charAt(0) == '(' && str.charAt(L - 1) == ')')
/*     */           {
/* 184 */             str = str.substring(1, L - 1);
/*     */           }
/* 186 */           return str;
/*     */         } 
/* 188 */         return ScriptRuntime.defaultObjectToString(thisObj);
/*     */ 
/*     */       
/*     */       case 4:
/* 192 */         if (cx.getLanguageVersion() >= 180 && (thisObj == null || 
/* 193 */           Undefined.isUndefined(thisObj))) {
/* 194 */           throw ScriptRuntime.typeErrorById("msg." + ((thisObj == null) ? "null" : "undef") + ".to.object", new Object[0]);
/*     */         }
/*     */         
/* 197 */         return thisObj;
/*     */ 
/*     */       
/*     */       case 5:
/* 201 */         if (cx.getLanguageVersion() >= 180 && (thisObj == null || 
/* 202 */           Undefined.isUndefined(thisObj))) {
/* 203 */           throw ScriptRuntime.typeErrorById("msg." + ((thisObj == null) ? "null" : "undef") + ".to.object", new Object[0]);
/*     */         }
/*     */ 
/*     */         
/* 207 */         object2 = (args.length < 1) ? Undefined.instance : args[0];
/* 208 */         if (object2 instanceof Symbol) {
/* 209 */           result = ensureSymbolScriptable(thisObj).has((Symbol)object2, thisObj);
/*     */         } else {
/* 211 */           ScriptRuntime.StringIdOrIndex stringIdOrIndex1 = ScriptRuntime.toStringIdOrIndex(cx, object2);
/* 212 */           if (stringIdOrIndex1.stringId == null) {
/* 213 */             result = thisObj.has(stringIdOrIndex1.index, thisObj);
/*     */           } else {
/* 215 */             result = thisObj.has(stringIdOrIndex1.stringId, thisObj);
/*     */           } 
/*     */         } 
/* 218 */         return ScriptRuntime.wrapBoolean(result);
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 223 */         if (cx.getLanguageVersion() >= 180 && (thisObj == null || 
/* 224 */           Undefined.isUndefined(thisObj))) {
/* 225 */           throw ScriptRuntime.typeErrorById("msg." + ((thisObj == null) ? "null" : "undef") + ".to.object", new Object[0]);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 230 */         object2 = (args.length < 1) ? Undefined.instance : args[0];
/*     */         
/* 232 */         if (object2 instanceof Symbol) {
/* 233 */           result = ((SymbolScriptable)thisObj).has((Symbol)object2, thisObj);
/* 234 */           result = (result && isEnumerable((Symbol)object2, thisObj));
/*     */         } else {
/* 236 */           ScriptRuntime.StringIdOrIndex stringIdOrIndex1 = ScriptRuntime.toStringIdOrIndex(cx, object2);
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 241 */             if (stringIdOrIndex1.stringId == null) {
/* 242 */               result = thisObj.has(stringIdOrIndex1.index, thisObj);
/* 243 */               result = (result && isEnumerable(stringIdOrIndex1.index, thisObj));
/*     */             } else {
/* 245 */               result = thisObj.has(stringIdOrIndex1.stringId, thisObj);
/* 246 */               result = (result && isEnumerable(stringIdOrIndex1.stringId, thisObj));
/*     */             } 
/* 248 */           } catch (EvaluatorException ee) {
/* 249 */             if (ee.getMessage()
/* 250 */               .startsWith(
/* 251 */                 ScriptRuntime.getMessageById("msg.prop.not.found", new Object[] {
/*     */ 
/*     */                     
/* 254 */                     (stringIdOrIndex1.stringId == null) ? Integer.toString(stringIdOrIndex1.index) : stringIdOrIndex1.stringId
/*     */                   }))) {
/* 256 */               result = false;
/*     */             } else {
/* 258 */               throw ee;
/*     */             } 
/*     */           } 
/*     */         } 
/* 262 */         return ScriptRuntime.wrapBoolean(result);
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 267 */         if (cx.getLanguageVersion() >= 180 && (thisObj == null || 
/* 268 */           Undefined.isUndefined(thisObj))) {
/* 269 */           throw ScriptRuntime.typeErrorById("msg." + ((thisObj == null) ? "null" : "undef") + ".to.object", new Object[0]);
/*     */         }
/*     */ 
/*     */         
/* 273 */         result = false;
/* 274 */         if (args.length != 0 && args[0] instanceof Scriptable) {
/* 275 */           Scriptable v = (Scriptable)args[0];
/*     */           do {
/* 277 */             v = v.getPrototype();
/* 278 */             if (v == thisObj) {
/* 279 */               result = true;
/*     */               break;
/*     */             } 
/* 282 */           } while (v != null);
/*     */         } 
/* 284 */         return ScriptRuntime.wrapBoolean(result);
/*     */ 
/*     */       
/*     */       case 8:
/* 288 */         return ScriptRuntime.defaultObjectToSource(cx, scope, thisObj, args);
/*     */       
/*     */       case 9:
/*     */       case 10:
/* 292 */         if (args.length < 2 || !(args[1] instanceof Callable)) {
/* 293 */           Object badArg = (args.length >= 2) ? args[1] : Undefined.instance;
/* 294 */           throw ScriptRuntime.notFunctionError(badArg);
/*     */         } 
/* 296 */         if (!(thisObj instanceof ScriptableObject)) {
/* 297 */           throw Context.reportRuntimeErrorById("msg.extend.scriptable", new Object[] { (thisObj == null) ? "null" : thisObj
/*     */                 
/* 299 */                 .getClass().getName(), 
/* 300 */                 String.valueOf(args[0]) });
/*     */         }
/* 302 */         so = (ScriptableObject)thisObj;
/* 303 */         stringIdOrIndex = ScriptRuntime.toStringIdOrIndex(cx, args[0]);
/* 304 */         index = (stringIdOrIndex.stringId != null) ? 0 : stringIdOrIndex.index;
/* 305 */         getterOrSetter = (Callable)args[1];
/* 306 */         bool1 = (id == 10);
/* 307 */         so.setGetterOrSetter(stringIdOrIndex.stringId, index, getterOrSetter, bool1);
/* 308 */         if (so instanceof NativeArray) ((NativeArray)so).setDenseOnly(false);
/*     */         
/* 310 */         return Undefined.instance;
/*     */ 
/*     */       
/*     */       case 11:
/*     */       case 12:
/* 315 */         if (args.length < 1 || !(thisObj instanceof ScriptableObject)) {
/* 316 */           return Undefined.instance;
/*     */         }
/* 318 */         so = (ScriptableObject)thisObj;
/* 319 */         stringIdOrIndex = ScriptRuntime.toStringIdOrIndex(cx, args[0]);
/* 320 */         index = (stringIdOrIndex.stringId != null) ? 0 : stringIdOrIndex.index;
/* 321 */         isSetter = (id == 12);
/*     */         
/*     */         while (true) {
/* 324 */           gs = so.getGetterOrSetter(stringIdOrIndex.stringId, index, this, isSetter);
/* 325 */           if (gs != null) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 330 */           Scriptable v = so.getPrototype();
/* 331 */           if (v == null) {
/*     */             break;
/*     */           }
/* 334 */           if (v instanceof ScriptableObject) {
/* 335 */             so = (ScriptableObject)v;
/*     */             continue;
/*     */           } 
/*     */           break;
/*     */         } 
/* 340 */         if (gs != null) {
/* 341 */           return gs;
/*     */         }
/*     */         
/* 344 */         return Undefined.instance;
/*     */ 
/*     */       
/*     */       case -1:
/* 348 */         object1 = (args.length < 1) ? Undefined.instance : args[0];
/* 349 */         scriptable2 = getCompatibleObject(cx, scope, object1);
/* 350 */         return scriptable2.getPrototype();
/*     */ 
/*     */       
/*     */       case -17:
/* 354 */         if (args.length < 2) {
/* 355 */           throw ScriptRuntime.typeErrorById("msg.method.missing.parameter", new Object[] { "Object.setPrototypeOf", "2", 
/*     */ 
/*     */ 
/*     */                 
/* 359 */                 Integer.toString(args.length) });
/*     */         }
/* 361 */         proto = (args[1] == null) ? null : ensureScriptable(args[1]);
/* 362 */         if (proto instanceof Symbol) {
/* 363 */           throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] {
/* 364 */                 ScriptRuntime.typeof(proto)
/*     */               });
/*     */         }
/* 367 */         arg0 = args[0];
/* 368 */         if (cx.getLanguageVersion() >= 200) {
/* 369 */           ScriptRuntimeES6.requireObjectCoercible(cx, arg0, f);
/*     */         }
/* 371 */         if (!(arg0 instanceof ScriptableObject)) {
/* 372 */           return arg0;
/*     */         }
/* 374 */         scriptableObject3 = (ScriptableObject)arg0;
/* 375 */         if (!scriptableObject3.isExtensible()) {
/* 376 */           throw ScriptRuntime.typeErrorById("msg.not.extensible", new Object[0]);
/*     */         }
/*     */ 
/*     */         
/* 380 */         prototypeProto = proto;
/* 381 */         while (prototypeProto != null) {
/* 382 */           if (prototypeProto == scriptableObject3) {
/* 383 */             throw ScriptRuntime.typeErrorById("msg.object.cyclic.prototype", new Object[] { scriptableObject3
/* 384 */                   .getClass().getSimpleName() });
/*     */           }
/* 386 */           prototypeProto = prototypeProto.getPrototype();
/*     */         } 
/* 388 */         scriptableObject3.setPrototype(proto);
/* 389 */         return scriptableObject3;
/*     */ 
/*     */       
/*     */       case -2:
/* 393 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 394 */         scriptable1 = getCompatibleObject(cx, scope, arg);
/* 395 */         ids = scriptable1.getIds();
/* 396 */         for (k = 0; k < ids.length; k++) {
/* 397 */           ids[k] = ScriptRuntime.toString(ids[k]);
/*     */         }
/* 399 */         return cx.newArray(scope, ids);
/*     */ 
/*     */ 
/*     */       
/*     */       case -18:
/* 404 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 405 */         scriptable1 = getCompatibleObject(cx, scope, arg);
/* 406 */         ids = scriptable1.getIds();
/* 407 */         j = 0;
/* 408 */         for (m = 0; m < ids.length; m++) {
/* 409 */           if (ids[m] instanceof Integer) {
/* 410 */             int intId = ((Integer)ids[m]).intValue();
/* 411 */             if (scriptable1.has(intId, scriptable1) && isEnumerable(intId, scriptable1)) {
/* 412 */               String stringId = ScriptRuntime.toString(ids[m]);
/* 413 */               Object[] entry = { stringId, scriptable1.get(intId, scriptable1) };
/* 414 */               ids[j++] = cx.newArray(scope, entry);
/*     */             } 
/*     */           } else {
/* 417 */             String stringId = ScriptRuntime.toString(ids[m]);
/* 418 */             if (scriptable1.has(stringId, scriptable1) && isEnumerable(stringId, scriptable1)) {
/* 419 */               Object[] entry = { stringId, scriptable1.get(stringId, scriptable1) };
/* 420 */               ids[j++] = cx.newArray(scope, entry);
/*     */             } 
/*     */           } 
/*     */         } 
/* 424 */         if (j != ids.length) {
/* 425 */           ids = Arrays.copyOf(ids, j);
/*     */         }
/* 427 */         return cx.newArray(scope, ids);
/*     */ 
/*     */       
/*     */       case -19:
/* 431 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 432 */         arg = getCompatibleObject(cx, scope, arg);
/* 433 */         scriptable1 = cx.newObject(scope);
/* 434 */         ScriptRuntime.loadFromIterable(cx, scope, arg, (key, value) -> {
/*     */               if (key instanceof Integer) {
/*     */                 obj.put(((Integer)key).intValue(), obj, value);
/*     */               } else if (key instanceof Symbol && obj instanceof SymbolScriptable) {
/*     */                 ((SymbolScriptable)obj).put((Symbol)key, obj, value);
/*     */               } else {
/*     */                 obj.put(ScriptRuntime.toString(key), obj, value);
/*     */               } 
/*     */             });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 448 */         return scriptable1;
/*     */ 
/*     */       
/*     */       case -20:
/* 452 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 453 */         scriptable1 = getCompatibleObject(cx, scope, arg);
/* 454 */         ids = scriptable1.getIds();
/* 455 */         j = 0;
/* 456 */         for (m = 0; m < ids.length; m++) {
/* 457 */           if (ids[m] instanceof Integer) {
/* 458 */             int intId = ((Integer)ids[m]).intValue();
/* 459 */             if (scriptable1.has(intId, scriptable1) && isEnumerable(intId, scriptable1)) {
/* 460 */               ids[j++] = scriptable1.get(intId, scriptable1);
/*     */             }
/*     */           } else {
/* 463 */             String stringId = ScriptRuntime.toString(ids[m]);
/*     */             
/* 465 */             if (scriptable1.has(stringId, scriptable1) && isEnumerable(stringId, scriptable1)) {
/* 466 */               ids[j++] = scriptable1.get(stringId, scriptable1);
/*     */             }
/*     */           } 
/*     */         } 
/* 470 */         if (j != ids.length) {
/* 471 */           ids = Arrays.copyOf(ids, j);
/*     */         }
/* 473 */         return cx.newArray(scope, ids);
/*     */ 
/*     */       
/*     */       case -3:
/* 477 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 478 */         s = getCompatibleObject(cx, scope, arg);
/* 479 */         scriptableObject2 = ensureScriptableObject(s);
/* 480 */         arrayOfObject1 = scriptableObject2.getIds(true, false);
/* 481 */         for (m = 0; m < arrayOfObject1.length; m++) {
/* 482 */           arrayOfObject1[m] = ScriptRuntime.toString(arrayOfObject1[m]);
/*     */         }
/* 484 */         return cx.newArray(scope, arrayOfObject1);
/*     */ 
/*     */       
/*     */       case -14:
/* 488 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 489 */         s = getCompatibleObject(cx, scope, arg);
/* 490 */         scriptableObject2 = ensureScriptableObject(s);
/* 491 */         arrayOfObject1 = scriptableObject2.getIds(true, true);
/* 492 */         syms = new ArrayList();
/* 493 */         for (n = 0; n < arrayOfObject1.length; n++) {
/* 494 */           if (arrayOfObject1[n] instanceof Symbol) {
/* 495 */             syms.add(arrayOfObject1[n]);
/*     */           }
/*     */         } 
/* 498 */         return cx.newArray(scope, syms.toArray());
/*     */ 
/*     */       
/*     */       case -4:
/* 502 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/*     */ 
/*     */ 
/*     */         
/* 506 */         s = getCompatibleObject(cx, scope, arg);
/* 507 */         scriptableObject2 = ensureScriptableObject(s);
/* 508 */         nameArg = (args.length < 2) ? Undefined.instance : args[1];
/* 509 */         scriptable3 = scriptableObject2.getOwnPropertyDescriptor(cx, nameArg);
/* 510 */         return (scriptable3 == null) ? Undefined.instance : scriptable3;
/*     */ 
/*     */       
/*     */       case -5:
/* 514 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 515 */         scriptableObject1 = ensureScriptableObject(arg);
/* 516 */         name = (args.length < 2) ? Undefined.instance : args[1];
/* 517 */         descArg = (args.length < 3) ? Undefined.instance : args[2];
/* 518 */         desc = ensureScriptableObject(descArg);
/* 519 */         scriptableObject1.defineOwnProperty(cx, name, desc);
/* 520 */         return scriptableObject1;
/*     */ 
/*     */       
/*     */       case -6:
/* 524 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 525 */         if (cx.getLanguageVersion() >= 200 && !(arg instanceof ScriptableObject))
/*     */         {
/* 527 */           return Boolean.FALSE;
/*     */         }
/*     */         
/* 530 */         scriptableObject1 = ensureScriptableObject(arg);
/* 531 */         return Boolean.valueOf(scriptableObject1.isExtensible());
/*     */ 
/*     */       
/*     */       case -7:
/* 535 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 536 */         if (cx.getLanguageVersion() >= 200 && !(arg instanceof ScriptableObject))
/*     */         {
/* 538 */           return arg;
/*     */         }
/*     */         
/* 541 */         scriptableObject1 = ensureScriptableObject(arg);
/* 542 */         scriptableObject1.preventExtensions();
/* 543 */         return scriptableObject1;
/*     */ 
/*     */       
/*     */       case -8:
/* 547 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 548 */         scriptableObject1 = ensureScriptableObject(arg);
/* 549 */         propsObj = (args.length < 2) ? Undefined.instance : args[1];
/* 550 */         props = Context.toObject(propsObj, scope);
/* 551 */         scriptableObject1.defineOwnProperties(cx, ensureScriptableObject(props));
/* 552 */         return scriptableObject1;
/*     */ 
/*     */       
/*     */       case -9:
/* 556 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 557 */         obj = (arg == null) ? null : ensureScriptable(arg);
/*     */         
/* 559 */         newObject = new NativeObject();
/* 560 */         newObject.setParentScope(scope);
/* 561 */         newObject.setPrototype(obj);
/*     */         
/* 563 */         if (args.length > 1 && !Undefined.isUndefined(args[1])) {
/* 564 */           props = Context.toObject(args[1], scope);
/* 565 */           newObject.defineOwnProperties(cx, ensureScriptableObject(props));
/*     */         } 
/*     */         
/* 568 */         return newObject;
/*     */ 
/*     */       
/*     */       case -10:
/* 572 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 573 */         if (cx.getLanguageVersion() >= 200 && !(arg instanceof ScriptableObject))
/*     */         {
/* 575 */           return Boolean.TRUE;
/*     */         }
/*     */         
/* 578 */         return Boolean.valueOf(AbstractEcmaObjectOperations.testIntegrityLevel(cx, arg, AbstractEcmaObjectOperations.INTEGRITY_LEVEL.SEALED));
/*     */ 
/*     */ 
/*     */       
/*     */       case -11:
/* 583 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 584 */         if (cx.getLanguageVersion() >= 200 && !(arg instanceof ScriptableObject))
/*     */         {
/* 586 */           return Boolean.TRUE;
/*     */         }
/*     */         
/* 589 */         return Boolean.valueOf(AbstractEcmaObjectOperations.testIntegrityLevel(cx, arg, AbstractEcmaObjectOperations.INTEGRITY_LEVEL.FROZEN));
/*     */ 
/*     */ 
/*     */       
/*     */       case -12:
/* 594 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 595 */         if (cx.getLanguageVersion() >= 200 && !(arg instanceof ScriptableObject))
/*     */         {
/* 597 */           return arg;
/*     */         }
/*     */         
/* 600 */         AbstractEcmaObjectOperations.setIntegrityLevel(cx, arg, AbstractEcmaObjectOperations.INTEGRITY_LEVEL.SEALED);
/*     */ 
/*     */         
/* 603 */         return arg;
/*     */ 
/*     */       
/*     */       case -13:
/* 607 */         arg = (args.length < 1) ? Undefined.instance : args[0];
/* 608 */         if (cx.getLanguageVersion() >= 200 && !(arg instanceof ScriptableObject))
/*     */         {
/* 610 */           return arg;
/*     */         }
/*     */         
/* 613 */         AbstractEcmaObjectOperations.setIntegrityLevel(cx, arg, AbstractEcmaObjectOperations.INTEGRITY_LEVEL.FROZEN);
/*     */ 
/*     */         
/* 616 */         return arg;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -15:
/* 622 */         if (args.length > 0) {
/* 623 */           targetObj = ScriptRuntime.toObject(cx, scope, args[0]);
/*     */         } else {
/* 625 */           targetObj = ScriptRuntime.toObject(cx, scope, Undefined.instance);
/*     */         } 
/* 627 */         for (i = 1; i < args.length; i++) {
/* 628 */           if (args[i] != null && !Undefined.isUndefined(args[i])) {
/*     */ 
/*     */             
/* 631 */             Scriptable sourceObj = ScriptRuntime.toObject(cx, scope, args[i]);
/* 632 */             Object[] arrayOfObject = sourceObj.getIds();
/* 633 */             for (Object key : arrayOfObject) {
/* 634 */               if (targetObj instanceof ScriptableObject) {
/*     */ 
/*     */                 
/* 637 */                 ScriptableObject scriptableObject = ((ScriptableObject)targetObj).getOwnPropertyDescriptor(cx, key);
/* 638 */                 if (scriptableObject != null && 
/* 639 */                   isDataDescriptor(scriptableObject) && 
/* 640 */                   isFalse(scriptableObject.get("writable"))) {
/* 641 */                   throw ScriptRuntime.typeErrorById("msg.change.value.with.writable.false", new Object[] { key });
/*     */                 }
/*     */               } 
/*     */               
/* 645 */               if (key instanceof String) {
/* 646 */                 Object val = sourceObj.get((String)key, sourceObj);
/* 647 */                 if (val != Scriptable.NOT_FOUND && !Undefined.isUndefined(val)) {
/* 648 */                   targetObj.put((String)key, targetObj, val);
/*     */                 }
/* 650 */               } else if (key instanceof Number) {
/* 651 */                 int ii = ScriptRuntime.toInt32(key);
/* 652 */                 Object val = sourceObj.get(ii, sourceObj);
/* 653 */                 if (val != Scriptable.NOT_FOUND && !Undefined.isUndefined(val))
/* 654 */                   targetObj.put(ii, targetObj, val); 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 659 */         return targetObj;
/*     */ 
/*     */ 
/*     */       
/*     */       case -16:
/* 664 */         a1 = (args.length < 1) ? Undefined.instance : args[0];
/* 665 */         a2 = (args.length < 2) ? Undefined.instance : args[1];
/* 666 */         return ScriptRuntime.wrapBoolean(ScriptRuntime.same(a1, a2));
/*     */     } 
/*     */ 
/*     */     
/* 670 */     throw new IllegalArgumentException(String.valueOf(id)); }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isEnumerable(int index, Object obj) {
/* 675 */     if (obj instanceof ScriptableObject) {
/* 676 */       ScriptableObject so = (ScriptableObject)obj;
/* 677 */       int attrs = so.getAttributes(index);
/* 678 */       return ((attrs & 0x2) == 0);
/*     */     } 
/* 680 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isEnumerable(String key, Object obj) {
/* 685 */     if (obj instanceof ScriptableObject) {
/* 686 */       ScriptableObject so = (ScriptableObject)obj;
/* 687 */       int attrs = so.getAttributes(key);
/* 688 */       return ((attrs & 0x2) == 0);
/*     */     } 
/* 690 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isEnumerable(Symbol sym, Object obj) {
/* 695 */     if (obj instanceof ScriptableObject) {
/* 696 */       ScriptableObject so = (ScriptableObject)obj;
/* 697 */       int attrs = so.getAttributes(sym);
/* 698 */       return ((attrs & 0x2) == 0);
/*     */     } 
/* 700 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Scriptable getCompatibleObject(Context cx, Scriptable scope, Object arg) {
/* 705 */     if (cx.getLanguageVersion() >= 200) {
/* 706 */       Scriptable s = ScriptRuntime.toObject(cx, scope, arg);
/* 707 */       return ensureScriptable(s);
/*     */     } 
/* 709 */     return ensureScriptable(arg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 716 */     if (key instanceof String)
/* 717 */       return has((String)key, this); 
/* 718 */     if (key instanceof Number) {
/* 719 */       return has(((Number)key).intValue(), this);
/*     */     }
/* 721 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 726 */     for (Object obj : values()) {
/* 727 */       if (value == obj || (value != null && value.equals(obj))) {
/* 728 */         return true;
/*     */       }
/*     */     } 
/* 731 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 736 */     Object value = get(key);
/* 737 */     if (key instanceof String) {
/* 738 */       delete((String)key);
/* 739 */     } else if (key instanceof Number) {
/* 740 */       delete(((Number)key).intValue());
/*     */     } 
/* 742 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Object> keySet() {
/* 747 */     return new KeySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Object> values() {
/* 752 */     return new ValueCollection();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<Object, Object>> entrySet() {
/* 757 */     return new EntrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 762 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map m) {
/* 767 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 772 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   class EntrySet
/*     */     extends AbstractSet<Map.Entry<Object, Object>> {
/*     */     public Iterator<Map.Entry<Object, Object>> iterator() {
/* 778 */       return new Iterator<Map.Entry<Object, Object>>() {
/* 779 */           Object[] ids = NativeObject.this.getIds();
/* 780 */           Object key = null;
/* 781 */           int index = 0;
/*     */ 
/*     */           
/*     */           public boolean hasNext() {
/* 785 */             return (this.index < this.ids.length);
/*     */           }
/*     */ 
/*     */           
/*     */           public Map.Entry<Object, Object> next() {
/* 790 */             final Object ekey = this.key = this.ids[this.index++];
/* 791 */             final Object value = NativeObject.this.get(this.key);
/* 792 */             return new Map.Entry<Object, Object>()
/*     */               {
/*     */                 public Object getKey() {
/* 795 */                   return ekey;
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public Object getValue() {
/* 800 */                   return value;
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public Object setValue(Object value) {
/* 805 */                   throw new UnsupportedOperationException();
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public boolean equals(Object other) {
/* 810 */                   if (!(other instanceof Map.Entry)) {
/* 811 */                     return false;
/*     */                   }
/* 813 */                   Map.Entry<?, ?> e = (Map.Entry<?, ?>)other;
/* 814 */                   return (((ekey == null) ? (e.getKey() == null) : ekey.equals(e.getKey())) && ((value == null) ? (e
/*     */                     
/* 816 */                     .getValue() == null) : value
/* 817 */                     .equals(e.getValue())));
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public int hashCode() {
/* 822 */                   return ((ekey == null) ? 0 : ekey.hashCode()) ^ ((value == null) ? 0 : value
/* 823 */                     .hashCode());
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public String toString() {
/* 828 */                   return ekey + "=" + value;
/*     */                 }
/*     */               };
/*     */           }
/*     */ 
/*     */           
/*     */           public void remove() {
/* 835 */             if (this.key == null) {
/* 836 */               throw new IllegalStateException();
/*     */             }
/* 838 */             NativeObject.this.remove(this.key);
/* 839 */             this.key = null;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 846 */       return NativeObject.this.size();
/*     */     }
/*     */   }
/*     */   
/*     */   class KeySet
/*     */     extends AbstractSet<Object>
/*     */   {
/*     */     public boolean contains(Object key) {
/* 854 */       return NativeObject.this.containsKey(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Object> iterator() {
/* 859 */       return new Iterator() {
/* 860 */           Object[] ids = NativeObject.this.getIds();
/*     */           Object key;
/* 862 */           int index = 0;
/*     */ 
/*     */           
/*     */           public boolean hasNext() {
/* 866 */             return (this.index < this.ids.length);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object next() {
/*     */             try {
/* 872 */               return this.key = this.ids[this.index++];
/* 873 */             } catch (ArrayIndexOutOfBoundsException e) {
/* 874 */               this.key = null;
/* 875 */               throw new NoSuchElementException();
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void remove() {
/* 881 */             if (this.key == null) {
/* 882 */               throw new IllegalStateException();
/*     */             }
/* 884 */             NativeObject.this.remove(this.key);
/* 885 */             this.key = null;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 892 */       return NativeObject.this.size();
/*     */     }
/*     */   }
/*     */   
/*     */   class ValueCollection
/*     */     extends AbstractCollection<Object>
/*     */   {
/*     */     public Iterator<Object> iterator() {
/* 900 */       return new Iterator() {
/* 901 */           Object[] ids = NativeObject.this.getIds();
/*     */           Object key;
/* 903 */           int index = 0;
/*     */ 
/*     */           
/*     */           public boolean hasNext() {
/* 907 */             return (this.index < this.ids.length);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object next() {
/* 912 */             return NativeObject.this.get(this.key = this.ids[this.index++]);
/*     */           }
/*     */ 
/*     */           
/*     */           public void remove() {
/* 917 */             if (this.key == null) {
/* 918 */               throw new IllegalStateException();
/*     */             }
/* 920 */             NativeObject.this.remove(this.key);
/* 921 */             this.key = null;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 928 */       return NativeObject.this.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 935 */     switch (s)
/*     */     { case "constructor":
/* 937 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 976 */         return id;case "toString": id = 2; return id;case "toLocaleString": id = 3; return id;case "valueOf": id = 4; return id;case "hasOwnProperty": id = 5; return id;case "propertyIsEnumerable": id = 6; return id;case "isPrototypeOf": id = 7; return id;case "toSource": id = 8; return id;case "__defineGetter__": id = 9; return id;case "__defineSetter__": id = 10; return id;case "__lookupGetter__": id = 11; return id;case "__lookupSetter__": id = 12; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */