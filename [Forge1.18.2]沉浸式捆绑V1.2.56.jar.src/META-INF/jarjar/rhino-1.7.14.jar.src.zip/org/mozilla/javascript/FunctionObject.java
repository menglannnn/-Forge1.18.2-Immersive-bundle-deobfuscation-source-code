/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionObject
/*     */   extends BaseFunction
/*     */ {
/*     */   private static final long serialVersionUID = -5332312783643935019L;
/*     */   private static final short VARARGS_METHOD = -1;
/*     */   private static final short VARARGS_CTOR = -2;
/*     */   private static boolean sawSecurityException;
/*     */   public static final int JAVA_UNSUPPORTED_TYPE = 0;
/*     */   public static final int JAVA_STRING_TYPE = 1;
/*     */   public static final int JAVA_INT_TYPE = 2;
/*     */   public static final int JAVA_BOOLEAN_TYPE = 3;
/*     */   public static final int JAVA_DOUBLE_TYPE = 4;
/*     */   public static final int JAVA_SCRIPTABLE_TYPE = 5;
/*     */   public static final int JAVA_OBJECT_TYPE = 6;
/*     */   MemberBox member;
/*     */   private String functionName;
/*     */   private transient byte[] typeTags;
/*     */   private int parmsLength;
/*     */   private transient boolean hasVoidReturn;
/*     */   private transient int returnTypeTag;
/*     */   private boolean isStatic;
/*     */   
/*     */   public FunctionObject(String name, Member methodOrConstructor, Scriptable scope) {
/*  83 */     if (methodOrConstructor instanceof Constructor) {
/*  84 */       this.member = new MemberBox((Constructor)methodOrConstructor);
/*  85 */       this.isStatic = true;
/*     */     } else {
/*  87 */       this.member = new MemberBox((Method)methodOrConstructor);
/*  88 */       this.isStatic = this.member.isStatic();
/*     */     } 
/*  90 */     String methodName = this.member.getName();
/*  91 */     this.functionName = name;
/*  92 */     Class<?>[] types = this.member.argTypes;
/*  93 */     int arity = types.length;
/*  94 */     if (arity == 4 && (types[1].isArray() || types[2].isArray())) {
/*     */       
/*  96 */       if (types[1].isArray()) {
/*  97 */         if (!this.isStatic || types[0] != ScriptRuntime.ContextClass || types[1]
/*     */           
/*  99 */           .getComponentType() != ScriptRuntime.ObjectClass || types[2] != ScriptRuntime.FunctionClass || types[3] != boolean.class)
/*     */         {
/*     */           
/* 102 */           throw Context.reportRuntimeErrorById("msg.varargs.ctor", new Object[] { methodName });
/*     */         }
/* 104 */         this.parmsLength = -2;
/*     */       } else {
/* 106 */         if (!this.isStatic || types[0] != ScriptRuntime.ContextClass || types[1] != ScriptRuntime.ScriptableClass || types[2]
/*     */ 
/*     */           
/* 109 */           .getComponentType() != ScriptRuntime.ObjectClass || types[3] != ScriptRuntime.FunctionClass)
/*     */         {
/* 111 */           throw Context.reportRuntimeErrorById("msg.varargs.fun", new Object[] { methodName });
/*     */         }
/* 113 */         this.parmsLength = -1;
/*     */       } 
/*     */     } else {
/* 116 */       this.parmsLength = arity;
/* 117 */       if (arity > 0) {
/* 118 */         this.typeTags = new byte[arity];
/* 119 */         for (int i = 0; i != arity; i++) {
/* 120 */           int tag = getTypeTag(types[i]);
/* 121 */           if (tag == 0) {
/* 122 */             throw Context.reportRuntimeErrorById("msg.bad.parms", new Object[] { types[i]
/* 123 */                   .getName(), methodName });
/*     */           }
/* 125 */           this.typeTags[i] = (byte)tag;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 130 */     if (this.member.isMethod()) {
/* 131 */       Method method = this.member.method();
/* 132 */       Class<?> returnType = method.getReturnType();
/* 133 */       if (returnType == void.class) {
/* 134 */         this.hasVoidReturn = true;
/*     */       } else {
/* 136 */         this.returnTypeTag = getTypeTag(returnType);
/*     */       } 
/*     */     } else {
/* 139 */       Class<?> ctorType = this.member.getDeclaringClass();
/* 140 */       if (!ScriptRuntime.ScriptableClass.isAssignableFrom(ctorType)) {
/* 141 */         throw Context.reportRuntimeErrorById("msg.bad.ctor.return", new Object[] { ctorType.getName() });
/*     */       }
/*     */     } 
/*     */     
/* 145 */     ScriptRuntime.setFunctionProtoAndParent(this, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTypeTag(Class<?> type) {
/* 153 */     if (type == ScriptRuntime.StringClass) return 1; 
/* 154 */     if (type == ScriptRuntime.IntegerClass || type == int.class) return 2; 
/* 155 */     if (type == ScriptRuntime.BooleanClass || type == boolean.class) return 3; 
/* 156 */     if (type == ScriptRuntime.DoubleClass || type == double.class) return 4; 
/* 157 */     if (ScriptRuntime.ScriptableClass.isAssignableFrom(type)) return 5; 
/* 158 */     if (type == ScriptRuntime.ObjectClass) return 6;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     return 0;
/*     */   }
/*     */   
/*     */   public static Object convertArg(Context cx, Scriptable scope, Object arg, int typeTag) {
/* 167 */     switch (typeTag) {
/*     */       case 1:
/* 169 */         if (arg instanceof String) return arg; 
/* 170 */         return ScriptRuntime.toString(arg);
/*     */       case 2:
/* 172 */         if (arg instanceof Integer) return arg; 
/* 173 */         return Integer.valueOf(ScriptRuntime.toInt32(arg));
/*     */       case 3:
/* 175 */         if (arg instanceof Boolean) return arg; 
/* 176 */         return ScriptRuntime.toBoolean(arg) ? Boolean.TRUE : Boolean.FALSE;
/*     */       case 4:
/* 178 */         if (arg instanceof Double) return arg; 
/* 179 */         return Double.valueOf(ScriptRuntime.toNumber(arg));
/*     */       case 5:
/* 181 */         return ScriptRuntime.toObjectOrNull(cx, arg, scope);
/*     */       case 6:
/* 183 */         if (arg instanceof ConsString) return arg.toString(); 
/* 184 */         return arg;
/*     */     } 
/* 186 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getArity() {
/* 196 */     return (this.parmsLength < 0) ? 1 : this.parmsLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 202 */     return getArity();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFunctionName() {
/* 207 */     return (this.functionName == null) ? "" : this.functionName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Member getMethodOrConstructor() {
/* 212 */     if (this.member.isMethod()) {
/* 213 */       return this.member.method();
/*     */     }
/* 215 */     return this.member.ctor();
/*     */   }
/*     */ 
/*     */   
/*     */   static Method findSingleMethod(Method[] methods, String name) {
/* 220 */     Method found = null;
/* 221 */     for (int i = 0, N = methods.length; i != N; i++) {
/* 222 */       Method method = methods[i];
/* 223 */       if (method != null && name.equals(method.getName())) {
/* 224 */         if (found != null) {
/* 225 */           throw Context.reportRuntimeErrorById("msg.no.overload", new Object[] { name, method
/* 226 */                 .getDeclaringClass().getName() });
/*     */         }
/* 228 */         found = method;
/*     */       } 
/*     */     } 
/* 231 */     return found;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Method[] getMethodList(Class<?> clazz) {
/* 242 */     Method[] methods = null;
/*     */ 
/*     */     
/*     */     try {
/* 246 */       if (!sawSecurityException) methods = clazz.getDeclaredMethods(); 
/* 247 */     } catch (SecurityException e) {
/*     */       
/* 249 */       sawSecurityException = true;
/*     */     } 
/* 251 */     if (methods == null) {
/* 252 */       methods = clazz.getMethods();
/*     */     }
/* 254 */     int count = 0;
/* 255 */     for (int i = 0; i < methods.length; i++) {
/* 256 */       if (sawSecurityException ? (methods[i]
/* 257 */         .getDeclaringClass() != clazz) : 
/* 258 */         !Modifier.isPublic(methods[i].getModifiers())) {
/* 259 */         methods[i] = null;
/*     */       } else {
/* 261 */         count++;
/*     */       } 
/*     */     } 
/* 264 */     Method[] result = new Method[count];
/* 265 */     int j = 0;
/* 266 */     for (int k = 0; k < methods.length; k++) {
/* 267 */       if (methods[k] != null) result[j++] = methods[k]; 
/*     */     } 
/* 269 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAsConstructor(Scriptable scope, Scriptable prototype) {
/* 286 */     initAsConstructor(scope, prototype);
/* 287 */     defineProperty(scope, prototype.getClassName(), this, 2);
/*     */   }
/*     */   
/*     */   void initAsConstructor(Scriptable scope, Scriptable prototype) {
/* 291 */     ScriptRuntime.setFunctionProtoAndParent(this, scope);
/* 292 */     setImmunePrototypeProperty(prototype);
/*     */     
/* 294 */     prototype.setParentScope(this);
/*     */     
/* 296 */     defineProperty(prototype, "constructor", this, 7);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 301 */     setParentScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Object convertArg(Context cx, Scriptable scope, Object arg, Class<?> desired) {
/* 310 */     int tag = getTypeTag(desired);
/* 311 */     if (tag == 0) {
/* 312 */       throw Context.reportRuntimeErrorById("msg.cant.convert", new Object[] { desired.getName() });
/*     */     }
/* 314 */     return convertArg(cx, scope, arg, tag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     Object object;
/* 328 */     boolean checkMethodResult = false;
/* 329 */     int argsLength = args.length;
/*     */     
/* 331 */     if (this.parmsLength < 0) {
/* 332 */       for (int i = 0; i < argsLength; i++) {
/*     */         
/* 334 */         if (args[i] instanceof ConsString) {
/* 335 */           args[i] = args[i].toString();
/*     */         }
/*     */       } 
/*     */       
/* 339 */       if (this.parmsLength == -1) {
/* 340 */         Object[] invokeArgs = { cx, thisObj, args, this };
/* 341 */         object = this.member.invoke(null, invokeArgs);
/* 342 */         checkMethodResult = true;
/*     */       } else {
/* 344 */         boolean inNewExpr = (thisObj == null);
/* 345 */         Boolean b = inNewExpr ? Boolean.TRUE : Boolean.FALSE;
/* 346 */         Object[] invokeArgs = { cx, args, this, b };
/*     */ 
/*     */ 
/*     */         
/* 350 */         object = this.member.isCtor() ? this.member.newInstance(invokeArgs) : this.member.invoke(null, invokeArgs);
/*     */       } 
/*     */     } else {
/*     */       Object[] invokeArgs;
/* 354 */       if (!this.isStatic) {
/* 355 */         Class<?> clazz = this.member.getDeclaringClass();
/* 356 */         if (thisObj instanceof Delegator) {
/* 357 */           thisObj = ((Delegator)thisObj).getDelegee();
/*     */         }
/* 359 */         if (!clazz.isInstance(thisObj)) {
/* 360 */           boolean compatible = false;
/* 361 */           if (thisObj == scope || thisObj instanceof org.mozilla.javascript.commonjs.module.ModuleScope) {
/* 362 */             Scriptable parentScope = getParentScope();
/* 363 */             if (scope != parentScope) {
/*     */ 
/*     */               
/* 366 */               compatible = clazz.isInstance(parentScope);
/* 367 */               if (compatible) {
/* 368 */                 thisObj = parentScope;
/*     */               }
/*     */             } 
/*     */           } 
/* 372 */           if (!compatible)
/*     */           {
/* 374 */             throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { this.functionName });
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 380 */       if (this.parmsLength == argsLength) {
/*     */ 
/*     */         
/* 383 */         invokeArgs = args;
/* 384 */         for (int i = 0; i != this.parmsLength; i++) {
/* 385 */           Object arg = args[i];
/* 386 */           Object converted = convertArg(cx, scope, arg, this.typeTags[i]);
/* 387 */           if (arg != converted) {
/* 388 */             if (invokeArgs == args) {
/* 389 */               invokeArgs = (Object[])args.clone();
/*     */             }
/* 391 */             invokeArgs[i] = converted;
/*     */           } 
/*     */         } 
/* 394 */       } else if (this.parmsLength == 0) {
/* 395 */         invokeArgs = ScriptRuntime.emptyArgs;
/*     */       } else {
/* 397 */         invokeArgs = new Object[this.parmsLength];
/* 398 */         for (int i = 0; i != this.parmsLength; i++) {
/* 399 */           Object arg = (i < argsLength) ? args[i] : Undefined.instance;
/* 400 */           invokeArgs[i] = convertArg(cx, scope, arg, this.typeTags[i]);
/*     */         } 
/*     */       } 
/*     */       
/* 404 */       if (this.member.isMethod()) {
/* 405 */         object = this.member.invoke(thisObj, invokeArgs);
/* 406 */         checkMethodResult = true;
/*     */       } else {
/* 408 */         object = this.member.newInstance(invokeArgs);
/*     */       } 
/*     */     } 
/*     */     
/* 412 */     if (checkMethodResult) {
/* 413 */       if (this.hasVoidReturn) {
/* 414 */         object = Undefined.instance;
/* 415 */       } else if (this.returnTypeTag == 0) {
/* 416 */         object = cx.getWrapFactory().wrap(cx, scope, object, null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 424 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable createObject(Context cx, Scriptable scope) {
/*     */     Scriptable result;
/* 434 */     if (this.member.isCtor() || this.parmsLength == -2) {
/* 435 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 439 */       result = (Scriptable)this.member.getDeclaringClass().newInstance();
/* 440 */     } catch (Exception ex) {
/* 441 */       throw Context.throwAsScriptRuntimeEx(ex);
/*     */     } 
/*     */     
/* 444 */     result.setPrototype(getClassPrototype());
/* 445 */     result.setParentScope(getParentScope());
/* 446 */     return result;
/*     */   }
/*     */   
/*     */   boolean isVarArgsMethod() {
/* 450 */     return (this.parmsLength == -1);
/*     */   }
/*     */   
/*     */   boolean isVarArgsConstructor() {
/* 454 */     return (this.parmsLength == -2);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 458 */     in.defaultReadObject();
/* 459 */     if (this.parmsLength > 0) {
/* 460 */       Class<?>[] types = this.member.argTypes;
/* 461 */       this.typeTags = new byte[this.parmsLength];
/* 462 */       for (int i = 0; i != this.parmsLength; i++) {
/* 463 */         this.typeTags[i] = (byte)getTypeTag(types[i]);
/*     */       }
/*     */     } 
/* 466 */     if (this.member.isMethod()) {
/* 467 */       Method method = this.member.method();
/* 468 */       Class<?> returnType = method.getReturnType();
/* 469 */       if (returnType == void.class) {
/* 470 */         this.hasVoidReturn = true;
/*     */       } else {
/* 472 */         this.returnTypeTag = getTypeTag(returnType);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\FunctionObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */