/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import org.mozilla.javascript.xml.XMLLib;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextFactory
/*     */ {
/*     */   private static volatile boolean hasCustomGlobal;
/* 109 */   private static ContextFactory global = new ContextFactory();
/*     */   
/*     */   private volatile boolean sealed;
/*     */   
/* 113 */   private final Object listenersLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile Object listeners;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disabledListening;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassLoader applicationClassLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContextFactory getGlobal() {
/* 137 */     return global;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasExplicitGlobal() {
/* 149 */     return hasCustomGlobal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void initGlobal(ContextFactory factory) {
/* 159 */     if (factory == null) {
/* 160 */       throw new IllegalArgumentException();
/*     */     }
/* 162 */     if (hasCustomGlobal) {
/* 163 */       throw new IllegalStateException();
/*     */     }
/* 165 */     hasCustomGlobal = true;
/* 166 */     global = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized GlobalSetter getGlobalSetter() {
/* 176 */     if (hasCustomGlobal) {
/* 177 */       throw new IllegalStateException();
/*     */     }
/* 179 */     hasCustomGlobal = true;
/*     */     class GlobalSetterImpl
/*     */       implements GlobalSetter {
/*     */       public void setContextFactoryGlobal(ContextFactory factory) {
/* 183 */         ContextFactory.global = (factory == null) ? new ContextFactory() : factory;
/*     */       }
/*     */ 
/*     */       
/*     */       public ContextFactory getContextFactoryGlobal() {
/* 188 */         return ContextFactory.global;
/*     */       }
/*     */     };
/* 191 */     return new GlobalSetterImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Context makeContext() {
/* 202 */     return new Context(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasFeature(Context cx, int featureIndex) {
/*     */     int version;
/* 211 */     switch (featureIndex) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 224 */         version = cx.getLanguageVersion();
/* 225 */         return (version == 100 || version == 110 || version == 120);
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 230 */         return false;
/*     */       
/*     */       case 3:
/* 233 */         return true;
/*     */       
/*     */       case 4:
/* 236 */         version = cx.getLanguageVersion();
/* 237 */         return (version == 120);
/*     */       
/*     */       case 5:
/* 240 */         return true;
/*     */       
/*     */       case 6:
/* 243 */         version = cx.getLanguageVersion();
/* 244 */         return (version == 0 || version >= 160);
/*     */       
/*     */       case 7:
/* 247 */         return false;
/*     */       
/*     */       case 8:
/* 250 */         return false;
/*     */       
/*     */       case 9:
/* 253 */         return false;
/*     */       
/*     */       case 10:
/* 256 */         return false;
/*     */       
/*     */       case 11:
/* 259 */         return false;
/*     */       
/*     */       case 12:
/* 262 */         return false;
/*     */       
/*     */       case 13:
/* 265 */         return false;
/*     */       
/*     */       case 14:
/* 268 */         return true;
/*     */       
/*     */       case 15:
/* 271 */         return (cx.getLanguageVersion() <= 170);
/*     */       
/*     */       case 16:
/* 274 */         return (cx.getLanguageVersion() >= 200);
/*     */       
/*     */       case 17:
/* 277 */         return false;
/*     */       
/*     */       case 18:
/* 280 */         return false;
/*     */       
/*     */       case 19:
/* 283 */         return false;
/*     */       
/*     */       case 20:
/* 286 */         return true;
/*     */       
/*     */       case 21:
/* 289 */         return false;
/*     */     } 
/*     */     
/* 292 */     throw new IllegalArgumentException(String.valueOf(featureIndex));
/*     */   }
/*     */   
/*     */   private static boolean isDom3Present() {
/* 296 */     Class<?> nodeClass = Kit.classOrNull("org.w3c.dom.Node");
/* 297 */     if (nodeClass == null) return false;
/*     */ 
/*     */     
/*     */     try {
/* 301 */       nodeClass.getMethod("getUserData", new Class[] { String.class });
/* 302 */       return true;
/* 303 */     } catch (NoSuchMethodException e) {
/* 304 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLLib.Factory getE4xImplementationFactory() {
/* 324 */     if (isDom3Present()) {
/* 325 */       return XMLLib.Factory.create("org.mozilla.javascript.xmlimpl.XMLLibImpl");
/*     */     }
/*     */     
/* 328 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GeneratedClassLoader createClassLoader(final ClassLoader parent) {
/* 338 */     return AccessController.<GeneratedClassLoader>doPrivileged((PrivilegedAction)new PrivilegedAction<DefiningClassLoader>()
/*     */         {
/*     */           public DefiningClassLoader run()
/*     */           {
/* 342 */             return new DefiningClassLoader(parent);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static interface GlobalSetter {
/*     */     void setContextFactoryGlobal(ContextFactory param1ContextFactory);
/*     */     
/*     */     ContextFactory getContextFactoryGlobal(); }
/*     */   
/*     */   public final ClassLoader getApplicationClassLoader() {
/* 353 */     return this.applicationClassLoader;
/*     */   }
/*     */   
/*     */   public static interface Listener {
/*     */     void contextCreated(Context param1Context);
/*     */     
/*     */     void contextReleased(Context param1Context); }
/*     */   
/*     */   public final void initApplicationClassLoader(ClassLoader loader) {
/* 362 */     if (loader == null) throw new IllegalArgumentException("loader is null"); 
/* 363 */     if (!Kit.testIfCanLoadRhinoClasses(loader)) {
/* 364 */       throw new IllegalArgumentException("Loader can not resolve Rhino classes");
/*     */     }
/* 366 */     if (this.applicationClassLoader != null)
/* 367 */       throw new IllegalStateException("applicationClassLoader can only be set once"); 
/* 368 */     checkNotSealed();
/*     */     
/* 370 */     this.applicationClassLoader = loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object doTopCall(Callable callable, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 380 */     Object result = callable.call(cx, scope, thisObj, args);
/* 381 */     return (result instanceof ConsString) ? result.toString() : result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void observeInstructionCount(Context cx, int instructionCount) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onContextCreated(Context cx) {
/* 391 */     Object listeners = this.listeners;
/* 392 */     for (int i = 0;; i++) {
/* 393 */       Listener l = (Listener)Kit.getListener(listeners, i);
/* 394 */       if (l == null)
/* 395 */         break;  l.contextCreated(cx);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void onContextReleased(Context cx) {
/* 400 */     Object listeners = this.listeners;
/* 401 */     for (int i = 0;; i++) {
/* 402 */       Listener l = (Listener)Kit.getListener(listeners, i);
/* 403 */       if (l == null)
/* 404 */         break;  l.contextReleased(cx);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void addListener(Listener listener) {
/* 409 */     checkNotSealed();
/* 410 */     synchronized (this.listenersLock) {
/* 411 */       if (this.disabledListening) {
/* 412 */         throw new IllegalStateException();
/*     */       }
/* 414 */       this.listeners = Kit.addListener(this.listeners, listener);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void removeListener(Listener listener) {
/* 419 */     checkNotSealed();
/* 420 */     synchronized (this.listenersLock) {
/* 421 */       if (this.disabledListening) {
/* 422 */         throw new IllegalStateException();
/*     */       }
/* 424 */       this.listeners = Kit.removeListener(this.listeners, listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   final void disableContextListening() {
/* 430 */     checkNotSealed();
/* 431 */     synchronized (this.listenersLock) {
/* 432 */       this.disabledListening = true;
/* 433 */       this.listeners = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSealed() {
/* 443 */     return this.sealed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void seal() {
/* 453 */     checkNotSealed();
/* 454 */     this.sealed = true;
/*     */   }
/*     */   
/*     */   protected final void checkNotSealed() {
/* 458 */     if (this.sealed) throw new IllegalStateException();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T call(ContextAction<T> action) {
/* 472 */     return Context.call(this, action);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Context enterContext() {
/* 515 */     return enterContext(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final Context enter() {
/* 524 */     return enterContext(null);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final void exit() {
/* 530 */     Context.exit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Context enterContext(Context cx) {
/* 548 */     return Context.enter(cx, this);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ContextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */