/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeneratorExpressionLoop
/*    */   extends ForInLoop
/*    */ {
/*    */   public GeneratorExpressionLoop() {}
/*    */   
/*    */   public GeneratorExpressionLoop(int pos) {
/* 17 */     super(pos);
/*    */   }
/*    */   
/*    */   public GeneratorExpressionLoop(int pos, int len) {
/* 21 */     super(pos, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isForEach() {
/* 29 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setIsForEach(boolean isForEach) {
/* 37 */     throw new UnsupportedOperationException("this node type does not support for each");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 42 */     return makeIndent(depth) + " for " + (
/*    */       
/* 44 */       isForEach() ? "each " : "") + "(" + this.iterator
/*    */       
/* 46 */       .toSource(0) + (
/* 47 */       isForOf() ? " of " : " in ") + this.iteratedObject
/* 48 */       .toSource(0) + ")";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 58 */     if (v.visit(this)) {
/* 59 */       this.iterator.visit(v);
/* 60 */       this.iteratedObject.visit(v);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\GeneratorExpressionLoop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */