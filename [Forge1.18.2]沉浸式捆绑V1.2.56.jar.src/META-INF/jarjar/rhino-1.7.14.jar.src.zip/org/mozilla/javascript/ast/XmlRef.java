/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XmlRef
/*     */   extends AstNode
/*     */ {
/*     */   protected Name namespace;
/*  36 */   protected int atPos = -1;
/*  37 */   protected int colonPos = -1;
/*     */ 
/*     */   
/*     */   public XmlRef() {}
/*     */   
/*     */   public XmlRef(int pos) {
/*  43 */     super(pos);
/*     */   }
/*     */   
/*     */   public XmlRef(int pos, int len) {
/*  47 */     super(pos, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getNamespace() {
/*  54 */     return this.namespace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespace(Name namespace) {
/*  62 */     this.namespace = namespace;
/*  63 */     if (namespace != null) {
/*  64 */       namespace.setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttributeAccess() {
/*  71 */     return (this.atPos >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAtPos() {
/*  79 */     return this.atPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAtPos(int atPos) {
/*  86 */     this.atPos = atPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColonPos() {
/*  94 */     return this.colonPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColonPos(int colonPos) {
/* 101 */     this.colonPos = colonPos;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\XmlRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */