/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WhileLoop
/*    */   extends Loop
/*    */ {
/*    */   private AstNode condition;
/*    */   
/*    */   public WhileLoop() {}
/*    */   
/*    */   public WhileLoop(int pos) {
/* 29 */     super(pos);
/*    */   }
/*    */   
/*    */   public WhileLoop(int pos, int len) {
/* 33 */     super(pos, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AstNode getCondition() {
/* 40 */     return this.condition;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCondition(AstNode condition) {
/* 48 */     assertNotNull(condition);
/* 49 */     this.condition = condition;
/* 50 */     condition.setParent(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 55 */     StringBuilder sb = new StringBuilder();
/* 56 */     sb.append(makeIndent(depth));
/* 57 */     sb.append("while (");
/* 58 */     sb.append(this.condition.toSource(0));
/* 59 */     sb.append(") ");
/* 60 */     if (getInlineComment() != null) {
/* 61 */       sb.append(getInlineComment().toSource(depth + 1)).append("\n");
/*    */     }
/* 63 */     if (this.body.getType() == 133) {
/* 64 */       sb.append(this.body.toSource(depth).trim());
/* 65 */       sb.append("\n");
/*    */     } else {
/* 67 */       if (getInlineComment() == null) {
/* 68 */         sb.append("\n");
/*    */       }
/* 70 */       sb.append(this.body.toSource(depth + 1));
/*    */     } 
/* 72 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 80 */     if (v.visit(this)) {
/* 81 */       this.condition.visit(v);
/* 82 */       this.body.visit(v);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\WhileLoop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */