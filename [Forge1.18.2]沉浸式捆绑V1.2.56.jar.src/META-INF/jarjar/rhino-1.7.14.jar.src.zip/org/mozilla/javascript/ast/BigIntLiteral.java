/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BigIntLiteral
/*    */   extends AstNode
/*    */ {
/*    */   private String value;
/*    */   private BigInteger bigInt;
/*    */   
/*    */   public BigIntLiteral() {}
/*    */   
/*    */   public BigIntLiteral(int pos) {
/* 25 */     super(pos);
/*    */   }
/*    */   
/*    */   public BigIntLiteral(int pos, int len) {
/* 29 */     super(pos, len);
/*    */   }
/*    */ 
/*    */   
/*    */   public BigIntLiteral(int pos, String value) {
/* 34 */     super(pos);
/* 35 */     setValue(value);
/* 36 */     setLength(value.length());
/*    */   }
/*    */ 
/*    */   
/*    */   public BigIntLiteral(int pos, String value, BigInteger bigInt) {
/* 41 */     this(pos, value);
/* 42 */     setBigInt(bigInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 47 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(String value) {
/* 56 */     assertNotNull(value);
/* 57 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BigInteger getBigInt() {
/* 63 */     return this.bigInt;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBigInt(BigInteger value) {
/* 69 */     this.bigInt = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 74 */     return makeIndent(depth) + ((this.bigInt == null) ? "<null>" : this.bigInt.toString());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 80 */     v.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\BigIntLiteral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */