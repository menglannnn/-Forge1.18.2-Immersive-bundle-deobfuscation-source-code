/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IfStatement
/*     */   extends AstNode
/*     */ {
/*     */   private AstNode condition;
/*     */   private AstNode thenPart;
/*  22 */   private int elsePosition = -1;
/*     */   private AstNode elsePart;
/*     */   private AstNode elseKeyWordInlineComment;
/*  25 */   private int lp = -1;
/*  26 */   private int rp = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IfStatement() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public IfStatement(int pos) {
/*  36 */     super(pos);
/*     */   }
/*     */   
/*     */   public IfStatement(int pos, int len) {
/*  40 */     super(pos, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getCondition() {
/*  47 */     return this.condition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCondition(AstNode condition) {
/*  55 */     assertNotNull(condition);
/*  56 */     this.condition = condition;
/*  57 */     condition.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getThenPart() {
/*  64 */     return this.thenPart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThenPart(AstNode thenPart) {
/*  72 */     assertNotNull(thenPart);
/*  73 */     this.thenPart = thenPart;
/*  74 */     thenPart.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getElsePart() {
/*  81 */     return this.elsePart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElsePart(AstNode elsePart) {
/*  90 */     this.elsePart = elsePart;
/*  91 */     if (elsePart != null) {
/*  92 */       elsePart.setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getElsePosition() {
/*  99 */     return this.elsePosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElsePosition(int elsePosition) {
/* 106 */     this.elsePosition = elsePosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLp() {
/* 113 */     return this.lp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLp(int lp) {
/* 120 */     this.lp = lp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRp() {
/* 127 */     return this.rp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRp(int rp) {
/* 134 */     this.rp = rp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParens(int lp, int rp) {
/* 141 */     this.lp = lp;
/* 142 */     this.rp = rp;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 147 */     String pad = makeIndent(depth);
/* 148 */     StringBuilder sb = new StringBuilder(32);
/* 149 */     sb.append(pad);
/* 150 */     sb.append("if (");
/* 151 */     sb.append(this.condition.toSource(0));
/* 152 */     sb.append(") ");
/* 153 */     if (getInlineComment() != null) {
/* 154 */       sb.append("    ").append(getInlineComment().toSource()).append("\n");
/*     */     }
/* 156 */     if (this.thenPart.getType() != 133) {
/* 157 */       if (getInlineComment() == null) {
/* 158 */         sb.append("\n");
/*     */       }
/* 160 */       sb.append(makeIndent(depth + 1));
/*     */     } 
/* 162 */     sb.append(this.thenPart.toSource(depth).trim());
/* 163 */     if (this.elsePart != null) {
/* 164 */       if (this.thenPart.getType() != 133) {
/* 165 */         sb.append("\n").append(pad).append("else ");
/*     */       } else {
/* 167 */         sb.append(" else ");
/*     */       } 
/* 169 */       if (getElseKeyWordInlineComment() != null) {
/* 170 */         sb.append("    ").append(getElseKeyWordInlineComment().toSource()).append("\n");
/*     */       }
/* 172 */       if (this.elsePart.getType() != 133 && this.elsePart
/* 173 */         .getType() != 116) {
/* 174 */         if (getElseKeyWordInlineComment() == null) {
/* 175 */           sb.append("\n");
/*     */         }
/* 177 */         sb.append(makeIndent(depth + 1));
/*     */       } 
/* 179 */       sb.append(this.elsePart.toSource(depth).trim());
/*     */     } 
/* 181 */     sb.append("\n");
/* 182 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 191 */     if (v.visit(this)) {
/* 192 */       this.condition.visit(v);
/* 193 */       this.thenPart.visit(v);
/* 194 */       if (this.elsePart != null) {
/* 195 */         this.elsePart.visit(v);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public AstNode getElseKeyWordInlineComment() {
/* 201 */     return this.elseKeyWordInlineComment;
/*     */   }
/*     */   
/*     */   public void setElseKeyWordInlineComment(AstNode elseKeyWordInlineComment) {
/* 205 */     this.elseKeyWordInlineComment = elseKeyWordInlineComment;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\IfStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */