/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateCharacters
/*    */   extends AstNode
/*    */ {
/*    */   private String value;
/*    */   private String rawValue;
/*    */   
/*    */   public TemplateCharacters() {}
/*    */   
/*    */   public TemplateCharacters(int pos) {
/* 26 */     super(pos);
/*    */   }
/*    */   
/*    */   public TemplateCharacters(int pos, int len) {
/* 30 */     super(pos, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 39 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(String value) {
/* 49 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getRawValue() {
/* 58 */     return this.rawValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRawValue(String rawValue) {
/* 68 */     assertNotNull(rawValue);
/* 69 */     this.rawValue = rawValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 74 */     return makeIndent(depth) + this.rawValue;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 80 */     v.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\TemplateCharacters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */