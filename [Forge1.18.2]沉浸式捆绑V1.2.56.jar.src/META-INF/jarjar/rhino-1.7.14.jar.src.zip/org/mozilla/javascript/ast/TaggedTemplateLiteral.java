/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaggedTemplateLiteral
/*    */   extends AstNode
/*    */ {
/*    */   private AstNode target;
/*    */   private AstNode templateLiteral;
/*    */   
/*    */   public TaggedTemplateLiteral() {}
/*    */   
/*    */   public TaggedTemplateLiteral(int pos) {
/* 26 */     super(pos);
/*    */   }
/*    */   
/*    */   public TaggedTemplateLiteral(int pos, int len) {
/* 30 */     super(pos, len);
/*    */   }
/*    */   
/*    */   public AstNode getTarget() {
/* 34 */     return this.target;
/*    */   }
/*    */   
/*    */   public void setTarget(AstNode target) {
/* 38 */     this.target = target;
/*    */   }
/*    */   
/*    */   public AstNode getTemplateLiteral() {
/* 42 */     return this.templateLiteral;
/*    */   }
/*    */   
/*    */   public void setTemplateLiteral(AstNode templateLiteral) {
/* 46 */     this.templateLiteral = templateLiteral;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 51 */     StringBuilder sb = new StringBuilder();
/* 52 */     sb.append(makeIndent(depth));
/* 53 */     sb.append(this.target.toSource(0));
/* 54 */     sb.append(this.templateLiteral.toSource(0));
/* 55 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 61 */     if (v.visit(this)) {
/* 62 */       this.target.visit(v);
/* 63 */       this.templateLiteral.visit(v);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\TaggedTemplateLiteral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */