/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import org.mozilla.javascript.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnaryExpression
/*     */   extends AstNode
/*     */ {
/*     */   private AstNode operand;
/*     */   
/*     */   public UnaryExpression() {}
/*     */   
/*     */   public UnaryExpression(int pos) {
/*  29 */     super(pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnaryExpression(int pos, int len) {
/*  36 */     super(pos, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnaryExpression(int operator, int operatorPosition, AstNode operand) {
/*  49 */     assertNotNull(operand);
/*  50 */     int beg = operand.getPosition();
/*     */     
/*  52 */     int end = operand.getPosition() + operand.getLength();
/*  53 */     setBounds(beg, end);
/*  54 */     setOperator(operator);
/*  55 */     setOperand(operand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOperator() {
/*  62 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperator(int operator) {
/*  72 */     if (!Token.isValidToken(operator))
/*  73 */       throw new IllegalArgumentException("Invalid token: " + operator); 
/*  74 */     setType(operator);
/*     */   }
/*     */   
/*     */   public AstNode getOperand() {
/*  78 */     return this.operand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperand(AstNode operand) {
/*  86 */     assertNotNull(operand);
/*  87 */     this.operand = operand;
/*  88 */     operand.setParent(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/*  93 */     StringBuilder sb = new StringBuilder();
/*  94 */     sb.append(makeIndent(depth));
/*  95 */     int type = getType();
/*  96 */     sb.append(operatorToString(type));
/*  97 */     if (type == 32 || type == 31 || type == 130) {
/*  98 */       sb.append(" ");
/*     */     }
/* 100 */     sb.append(this.operand.toSource());
/*     */     
/* 102 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 110 */     if (v.visit(this))
/* 111 */       this.operand.visit(v); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\UnaryExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */