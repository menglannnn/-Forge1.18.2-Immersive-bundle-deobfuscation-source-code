/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import org.mozilla.javascript.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Comment
/*     */   extends AstNode
/*     */ {
/*     */   private String value;
/*     */   private Token.CommentType commentType;
/*     */   
/*     */   public Comment(int pos, int len, Token.CommentType type, String value) {
/*  58 */     super(pos, len);
/*  59 */     this.commentType = type;
/*  60 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token.CommentType getCommentType() {
/*  67 */     return this.commentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommentType(Token.CommentType type) {
/*  76 */     this.commentType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/*  83 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String commentString) {
/*  91 */     this.value = commentString;
/*  92 */     setLength(this.value.length());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/*  97 */     StringBuilder sb = new StringBuilder(getLength() + 10);
/*  98 */     sb.append(makeIndent(depth));
/*  99 */     sb.append(this.value);
/* 100 */     if (Token.CommentType.BLOCK_COMMENT == getCommentType()) {
/* 101 */       sb.append("\n");
/*     */     }
/* 103 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 112 */     v.visit(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\Comment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */