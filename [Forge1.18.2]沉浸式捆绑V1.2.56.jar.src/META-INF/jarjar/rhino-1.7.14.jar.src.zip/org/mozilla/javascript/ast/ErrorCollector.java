/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.mozilla.javascript.EvaluatorException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorCollector
/*    */   implements IdeErrorReporter
/*    */ {
/* 24 */   private List<ParseProblem> errors = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void warning(String message, String sourceName, int line, String lineSource, int lineOffset) {
/* 34 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void warning(String message, String sourceName, int offset, int length) {
/* 43 */     this.errors.add(new ParseProblem(ParseProblem.Type.Warning, message, sourceName, offset, length));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void error(String message, String sourceName, int line, String lineSource, int lineOffset) {
/* 57 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void error(String message, String sourceName, int fileOffset, int length) {
/* 67 */     this.errors.add(new ParseProblem(ParseProblem.Type.Error, message, sourceName, fileOffset, length));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EvaluatorException runtimeError(String message, String sourceName, int line, String lineSource, int lineOffset) {
/* 80 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<ParseProblem> getErrors() {
/* 87 */     return this.errors;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 92 */     StringBuilder sb = new StringBuilder(this.errors.size() * 100);
/* 93 */     for (ParseProblem pp : this.errors) {
/* 94 */       sb.append(pp.toString()).append("\n");
/*    */     }
/* 96 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\ErrorCollector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */