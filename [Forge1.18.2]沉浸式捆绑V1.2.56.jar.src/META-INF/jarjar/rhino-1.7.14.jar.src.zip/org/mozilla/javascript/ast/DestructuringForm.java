package org.mozilla.javascript.ast;

public interface DestructuringForm {
  void setIsDestructuring(boolean paramBoolean);
  
  boolean isDestructuring();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\DestructuringForm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */