/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectLiteral
/*     */   extends AstNode
/*     */   implements DestructuringForm
/*     */ {
/*  36 */   private static final List<ObjectProperty> NO_ELEMS = Collections.unmodifiableList(new ArrayList<>());
/*     */ 
/*     */   
/*     */   private List<ObjectProperty> elements;
/*     */ 
/*     */   
/*     */   boolean isDestructuring;
/*     */ 
/*     */   
/*     */   public ObjectLiteral() {}
/*     */ 
/*     */   
/*     */   public ObjectLiteral(int pos) {
/*  49 */     super(pos);
/*     */   }
/*     */   
/*     */   public ObjectLiteral(int pos, int len) {
/*  53 */     super(pos, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ObjectProperty> getElements() {
/*  61 */     return (this.elements != null) ? this.elements : NO_ELEMS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElements(List<ObjectProperty> elements) {
/*  70 */     if (elements == null) {
/*  71 */       this.elements = null;
/*     */     } else {
/*  73 */       if (this.elements != null)
/*  74 */         this.elements.clear(); 
/*  75 */       for (ObjectProperty o : elements) {
/*  76 */         addElement(o);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addElement(ObjectProperty element) {
/*  86 */     assertNotNull(element);
/*  87 */     if (this.elements == null) {
/*  88 */       this.elements = new ArrayList<>();
/*     */     }
/*  90 */     this.elements.add(element);
/*  91 */     element.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsDestructuring(boolean destructuring) {
/* 101 */     this.isDestructuring = destructuring;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDestructuring() {
/* 111 */     return this.isDestructuring;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 116 */     StringBuilder sb = new StringBuilder();
/* 117 */     sb.append(makeIndent(depth));
/* 118 */     sb.append("{");
/* 119 */     if (this.elements != null) {
/* 120 */       printList(this.elements, sb);
/*     */     }
/* 122 */     sb.append("}");
/* 123 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 132 */     if (v.visit(this))
/* 133 */       for (ObjectProperty prop : getElements())
/* 134 */         prop.visit(v);  
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\ObjectLiteral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */