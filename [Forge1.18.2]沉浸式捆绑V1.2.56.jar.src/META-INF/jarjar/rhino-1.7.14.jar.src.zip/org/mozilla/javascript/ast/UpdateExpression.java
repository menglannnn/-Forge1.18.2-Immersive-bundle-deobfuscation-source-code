/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import org.mozilla.javascript.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateExpression
/*     */   extends AstNode
/*     */ {
/*     */   private AstNode operand;
/*     */   private boolean isPostfix;
/*     */   
/*     */   public UpdateExpression() {}
/*     */   
/*     */   public UpdateExpression(int pos) {
/*  25 */     super(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public UpdateExpression(int pos, int len) {
/*  30 */     super(pos, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public UpdateExpression(int operator, int operatorPosition, AstNode operand) {
/*  35 */     this(operator, operatorPosition, operand, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UpdateExpression(int operator, int operatorPosition, AstNode operand, boolean postFix) {
/*  49 */     assertNotNull(operand);
/*  50 */     int beg = postFix ? operand.getPosition() : operatorPosition;
/*     */     
/*  52 */     int end = postFix ? (operatorPosition + 2) : (operand.getPosition() + operand.getLength());
/*  53 */     setBounds(beg, end);
/*  54 */     setOperator(operator);
/*  55 */     setOperand(operand);
/*  56 */     this.isPostfix = postFix;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOperator() {
/*  61 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperator(int operator) {
/*  71 */     if (!Token.isValidToken(operator))
/*  72 */       throw new IllegalArgumentException("Invalid token: " + operator); 
/*  73 */     setType(operator);
/*     */   }
/*     */   
/*     */   public AstNode getOperand() {
/*  77 */     return this.operand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperand(AstNode operand) {
/*  86 */     assertNotNull(operand);
/*  87 */     this.operand = operand;
/*  88 */     operand.setParent(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPostfix() {
/*  93 */     return this.isPostfix;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrefix() {
/*  98 */     return !this.isPostfix;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIsPostfix(boolean isPostfix) {
/* 103 */     this.isPostfix = isPostfix;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 108 */     StringBuilder sb = new StringBuilder();
/* 109 */     sb.append(makeIndent(depth));
/* 110 */     int type = getType();
/* 111 */     if (!this.isPostfix) {
/* 112 */       sb.append(operatorToString(type));
/*     */     }
/* 114 */     sb.append(this.operand.toSource());
/* 115 */     if (this.isPostfix) {
/* 116 */       sb.append(operatorToString(type));
/*     */     }
/* 118 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 124 */     if (v.visit(this))
/* 125 */       this.operand.visit(v); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\UpdateExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */