/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForLoop
/*     */   extends Loop
/*     */ {
/*     */   private AstNode initializer;
/*     */   private AstNode condition;
/*     */   private AstNode increment;
/*     */   
/*     */   public ForLoop() {}
/*     */   
/*     */   public ForLoop(int pos) {
/*  32 */     super(pos);
/*     */   }
/*     */   
/*     */   public ForLoop(int pos, int len) {
/*  36 */     super(pos, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getInitializer() {
/*  46 */     return this.initializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitializer(AstNode initializer) {
/*  58 */     assertNotNull(initializer);
/*  59 */     this.initializer = initializer;
/*  60 */     initializer.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getCondition() {
/*  67 */     return this.condition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCondition(AstNode condition) {
/*  77 */     assertNotNull(condition);
/*  78 */     this.condition = condition;
/*  79 */     condition.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getIncrement() {
/*  86 */     return this.increment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncrement(AstNode increment) {
/*  97 */     assertNotNull(increment);
/*  98 */     this.increment = increment;
/*  99 */     increment.setParent(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 104 */     StringBuilder sb = new StringBuilder();
/* 105 */     sb.append(makeIndent(depth));
/* 106 */     sb.append("for (");
/* 107 */     sb.append(this.initializer.toSource(0));
/* 108 */     sb.append("; ");
/* 109 */     sb.append(this.condition.toSource(0));
/* 110 */     sb.append("; ");
/* 111 */     sb.append(this.increment.toSource(0));
/* 112 */     sb.append(") ");
/* 113 */     if (getInlineComment() != null) {
/* 114 */       sb.append(getInlineComment().toSource()).append("\n");
/*     */     }
/* 116 */     if (this.body.getType() == 133) {
/* 117 */       String bodySource = this.body.toSource(depth);
/* 118 */       if (getInlineComment() == null) {
/* 119 */         bodySource = bodySource.trim();
/*     */       }
/* 121 */       sb.append(bodySource).append("\n");
/*     */     } else {
/* 123 */       if (getInlineComment() == null) {
/* 124 */         sb.append("\n");
/*     */       }
/* 126 */       sb.append(this.body.toSource(depth + 1));
/*     */     } 
/* 128 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 137 */     if (v.visit(this)) {
/* 138 */       this.initializer.visit(v);
/* 139 */       this.condition.visit(v);
/* 140 */       this.increment.visit(v);
/* 141 */       this.body.visit(v);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\ForLoop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */