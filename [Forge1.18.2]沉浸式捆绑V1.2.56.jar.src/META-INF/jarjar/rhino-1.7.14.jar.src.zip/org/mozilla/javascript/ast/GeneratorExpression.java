/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneratorExpression
/*     */   extends Scope
/*     */ {
/*     */   private AstNode result;
/*  19 */   private List<GeneratorExpressionLoop> loops = new ArrayList<>();
/*     */   
/*     */   private AstNode filter;
/*  22 */   private int ifPosition = -1;
/*  23 */   private int lp = -1;
/*  24 */   private int rp = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratorExpression() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratorExpression(int pos) {
/*  34 */     super(pos);
/*     */   }
/*     */   
/*     */   public GeneratorExpression(int pos, int len) {
/*  38 */     super(pos, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getResult() {
/*  45 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResult(AstNode result) {
/*  53 */     assertNotNull(result);
/*  54 */     this.result = result;
/*  55 */     result.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GeneratorExpressionLoop> getLoops() {
/*  62 */     return this.loops;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoops(List<GeneratorExpressionLoop> loops) {
/*  70 */     assertNotNull(loops);
/*  71 */     this.loops.clear();
/*  72 */     for (GeneratorExpressionLoop acl : loops) {
/*  73 */       addLoop(acl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLoop(GeneratorExpressionLoop acl) {
/*  82 */     assertNotNull(acl);
/*  83 */     this.loops.add(acl);
/*  84 */     acl.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getFilter() {
/*  91 */     return this.filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilter(AstNode filter) {
/*  99 */     this.filter = filter;
/* 100 */     if (filter != null) {
/* 101 */       filter.setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIfPosition() {
/* 108 */     return this.ifPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIfPosition(int ifPosition) {
/* 115 */     this.ifPosition = ifPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFilterLp() {
/* 122 */     return this.lp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilterLp(int lp) {
/* 129 */     this.lp = lp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFilterRp() {
/* 136 */     return this.rp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilterRp(int rp) {
/* 143 */     this.rp = rp;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 148 */     StringBuilder sb = new StringBuilder(250);
/* 149 */     sb.append("(");
/* 150 */     sb.append(this.result.toSource(0));
/* 151 */     for (GeneratorExpressionLoop loop : this.loops) {
/* 152 */       sb.append(loop.toSource(0));
/*     */     }
/* 154 */     if (this.filter != null) {
/* 155 */       sb.append(" if (");
/* 156 */       sb.append(this.filter.toSource(0));
/* 157 */       sb.append(")");
/*     */     } 
/* 159 */     sb.append(")");
/* 160 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 169 */     if (!v.visit(this)) {
/*     */       return;
/*     */     }
/* 172 */     this.result.visit(v);
/* 173 */     for (GeneratorExpressionLoop loop : this.loops) {
/* 174 */       loop.visit(v);
/*     */     }
/* 176 */     if (this.filter != null)
/* 177 */       this.filter.visit(v); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\GeneratorExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */