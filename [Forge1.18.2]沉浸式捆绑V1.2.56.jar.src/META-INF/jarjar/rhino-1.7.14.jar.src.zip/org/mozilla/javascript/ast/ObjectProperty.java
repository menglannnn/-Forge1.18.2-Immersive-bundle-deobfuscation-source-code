/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectProperty
/*     */   extends InfixExpression
/*     */ {
/*     */   public void setNodeType(int nodeType) {
/*  42 */     if (nodeType != 107 && nodeType != 155 && nodeType != 156 && nodeType != 167)
/*     */     {
/*     */ 
/*     */       
/*  46 */       throw new IllegalArgumentException("invalid node type: " + nodeType); } 
/*  47 */     setType(nodeType);
/*     */   }
/*     */   
/*     */   public ObjectProperty() {}
/*     */   
/*     */   public ObjectProperty(int pos) {
/*  53 */     super(pos);
/*     */   }
/*     */   
/*     */   public ObjectProperty(int pos, int len) {
/*  57 */     super(pos, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIsGetterMethod() {
/*  62 */     this.type = 155;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGetterMethod() {
/*  67 */     return (this.type == 155);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIsSetterMethod() {
/*  72 */     this.type = 156;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSetterMethod() {
/*  77 */     return (this.type == 156);
/*     */   }
/*     */   
/*     */   public void setIsNormalMethod() {
/*  81 */     this.type = 167;
/*     */   }
/*     */   
/*     */   public boolean isNormalMethod() {
/*  85 */     return (this.type == 167);
/*     */   }
/*     */   
/*     */   public boolean isMethod() {
/*  89 */     return (isGetterMethod() || isSetterMethod() || isNormalMethod());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/*  94 */     StringBuilder sb = new StringBuilder();
/*  95 */     sb.append("\n");
/*  96 */     sb.append(makeIndent(depth + 1));
/*  97 */     if (isGetterMethod()) {
/*  98 */       sb.append("get ");
/*  99 */     } else if (isSetterMethod()) {
/* 100 */       sb.append("set ");
/*     */     } 
/* 102 */     sb.append(this.left.toSource((getType() == 107) ? 0 : depth));
/* 103 */     if (this.type == 107) {
/* 104 */       sb.append(": ");
/*     */     }
/* 106 */     sb.append(this.right.toSource((getType() == 107) ? 0 : (depth + 1)));
/* 107 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\ObjectProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */