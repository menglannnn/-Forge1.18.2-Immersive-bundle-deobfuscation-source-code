/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyExpression
/*    */   extends AstNode
/*    */ {
/*    */   public EmptyExpression() {}
/*    */   
/*    */   public EmptyExpression(int pos) {
/* 26 */     super(pos);
/*    */   }
/*    */   
/*    */   public EmptyExpression(int pos, int len) {
/* 30 */     super(pos, len);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 35 */     return makeIndent(depth);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 43 */     v.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\EmptyExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */