/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorNode
/*    */   extends AstNode
/*    */ {
/*    */   private String message;
/*    */   
/*    */   public ErrorNode() {}
/*    */   
/*    */   public ErrorNode(int pos) {
/* 27 */     super(pos);
/*    */   }
/*    */   
/*    */   public ErrorNode(int pos, int len) {
/* 31 */     super(pos, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 38 */     return this.message;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setMessage(String message) {
/* 45 */     this.message = message;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 50 */     return "";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 59 */     v.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\ErrorNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */