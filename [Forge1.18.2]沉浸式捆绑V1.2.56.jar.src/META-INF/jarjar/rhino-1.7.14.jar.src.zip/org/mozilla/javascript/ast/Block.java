/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ import org.mozilla.javascript.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Block
/*    */   extends AstNode
/*    */ {
/*    */   public Block() {}
/*    */   
/*    */   public Block(int pos) {
/* 30 */     super(pos);
/*    */   }
/*    */   
/*    */   public Block(int pos, int len) {
/* 34 */     super(pos, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addStatement(AstNode statement) {
/* 41 */     addChild(statement);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 46 */     StringBuilder sb = new StringBuilder();
/* 47 */     sb.append(makeIndent(depth));
/* 48 */     sb.append("{\n");
/* 49 */     for (Node kid : this) {
/* 50 */       AstNode astNodeKid = (AstNode)kid;
/* 51 */       sb.append(astNodeKid.toSource(depth + 1));
/* 52 */       if (astNodeKid.getType() == 165) {
/* 53 */         sb.append("\n");
/*    */       }
/*    */     } 
/* 56 */     sb.append(makeIndent(depth));
/* 57 */     sb.append("}");
/* 58 */     if (getInlineComment() != null) {
/* 59 */       sb.append(getInlineComment().toSource(depth));
/*    */     }
/* 61 */     sb.append("\n");
/* 62 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 67 */     if (v.visit(this))
/* 68 */       for (Node kid : this)
/* 69 */         ((AstNode)kid).visit(v);  
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\Block.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */