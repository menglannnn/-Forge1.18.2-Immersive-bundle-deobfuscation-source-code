/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForInLoop
/*     */   extends Loop
/*     */ {
/*     */   protected AstNode iterator;
/*     */   protected AstNode iteratedObject;
/*  23 */   protected int inPosition = -1;
/*  24 */   protected int eachPosition = -1;
/*     */ 
/*     */   
/*     */   protected boolean isForEach;
/*     */   
/*     */   protected boolean isForOf;
/*     */ 
/*     */   
/*     */   public ForInLoop() {}
/*     */ 
/*     */   
/*     */   public ForInLoop(int pos) {
/*  36 */     super(pos);
/*     */   }
/*     */   
/*     */   public ForInLoop(int pos, int len) {
/*  40 */     super(pos, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getIterator() {
/*  47 */     return this.iterator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIterator(AstNode iterator) {
/*  56 */     assertNotNull(iterator);
/*  57 */     this.iterator = iterator;
/*  58 */     iterator.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getIteratedObject() {
/*  65 */     return this.iteratedObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIteratedObject(AstNode object) {
/*  73 */     assertNotNull(object);
/*  74 */     this.iteratedObject = object;
/*  75 */     object.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isForEach() {
/*  82 */     return this.isForEach;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsForEach(boolean isForEach) {
/*  89 */     this.isForEach = isForEach;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isForOf() {
/*  96 */     return this.isForOf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsForOf(boolean isForOf) {
/* 103 */     this.isForOf = isForOf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInPosition() {
/* 110 */     return this.inPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInPosition(int inPosition) {
/* 119 */     this.inPosition = inPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEachPosition() {
/* 126 */     return this.eachPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEachPosition(int eachPosition) {
/* 135 */     this.eachPosition = eachPosition;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 140 */     StringBuilder sb = new StringBuilder();
/* 141 */     sb.append(makeIndent(depth));
/* 142 */     sb.append("for ");
/* 143 */     if (isForEach()) {
/* 144 */       sb.append("each ");
/*     */     }
/* 146 */     sb.append("(");
/* 147 */     sb.append(this.iterator.toSource(0));
/* 148 */     if (this.isForOf) {
/* 149 */       sb.append(" of ");
/*     */     } else {
/* 151 */       sb.append(" in ");
/*     */     } 
/* 153 */     sb.append(this.iteratedObject.toSource(0));
/* 154 */     sb.append(") ");
/* 155 */     if (this.body.getType() == 133) {
/* 156 */       sb.append(this.body.toSource(depth).trim()).append("\n");
/*     */     } else {
/* 158 */       sb.append("\n").append(this.body.toSource(depth + 1));
/*     */     } 
/* 160 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 168 */     if (v.visit(this)) {
/* 169 */       this.iterator.visit(v);
/* 170 */       this.iteratedObject.visit(v);
/* 171 */       this.body.visit(v);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\ForInLoop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */