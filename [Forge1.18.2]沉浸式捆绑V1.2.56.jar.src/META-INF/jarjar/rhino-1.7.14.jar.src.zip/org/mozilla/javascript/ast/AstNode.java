/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.mozilla.javascript.Kit;
/*     */ import org.mozilla.javascript.Node;
/*     */ import org.mozilla.javascript.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AstNode
/*     */   extends Node
/*     */   implements Comparable<AstNode>
/*     */ {
/*  66 */   protected int position = -1;
/*  67 */   protected int length = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AstNode parent;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AstNode inlineComment;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private static Map<Integer, String> operatorNames = new HashMap<>();
/*     */   
/*     */   static {
/*  86 */     operatorNames.put(Integer.valueOf(52), "in");
/*  87 */     operatorNames.put(Integer.valueOf(32), "typeof");
/*  88 */     operatorNames.put(Integer.valueOf(53), "instanceof");
/*  89 */     operatorNames.put(Integer.valueOf(31), "delete");
/*  90 */     operatorNames.put(Integer.valueOf(92), ",");
/*  91 */     operatorNames.put(Integer.valueOf(107), ":");
/*  92 */     operatorNames.put(Integer.valueOf(108), "||");
/*  93 */     operatorNames.put(Integer.valueOf(109), "&&");
/*  94 */     operatorNames.put(Integer.valueOf(110), "++");
/*  95 */     operatorNames.put(Integer.valueOf(111), "--");
/*  96 */     operatorNames.put(Integer.valueOf(9), "|");
/*  97 */     operatorNames.put(Integer.valueOf(10), "^");
/*  98 */     operatorNames.put(Integer.valueOf(11), "&");
/*  99 */     operatorNames.put(Integer.valueOf(12), "==");
/* 100 */     operatorNames.put(Integer.valueOf(13), "!=");
/* 101 */     operatorNames.put(Integer.valueOf(14), "<");
/* 102 */     operatorNames.put(Integer.valueOf(16), ">");
/* 103 */     operatorNames.put(Integer.valueOf(15), "<=");
/* 104 */     operatorNames.put(Integer.valueOf(17), ">=");
/* 105 */     operatorNames.put(Integer.valueOf(18), "<<");
/* 106 */     operatorNames.put(Integer.valueOf(19), ">>");
/* 107 */     operatorNames.put(Integer.valueOf(20), ">>>");
/* 108 */     operatorNames.put(Integer.valueOf(21), "+");
/* 109 */     operatorNames.put(Integer.valueOf(22), "-");
/* 110 */     operatorNames.put(Integer.valueOf(23), "*");
/* 111 */     operatorNames.put(Integer.valueOf(24), "/");
/* 112 */     operatorNames.put(Integer.valueOf(25), "%");
/* 113 */     operatorNames.put(Integer.valueOf(75), "**");
/* 114 */     operatorNames.put(Integer.valueOf(26), "!");
/* 115 */     operatorNames.put(Integer.valueOf(27), "~");
/* 116 */     operatorNames.put(Integer.valueOf(28), "+");
/* 117 */     operatorNames.put(Integer.valueOf(29), "-");
/* 118 */     operatorNames.put(Integer.valueOf(46), "===");
/* 119 */     operatorNames.put(Integer.valueOf(47), "!==");
/* 120 */     operatorNames.put(Integer.valueOf(93), "=");
/* 121 */     operatorNames.put(Integer.valueOf(94), "|=");
/* 122 */     operatorNames.put(Integer.valueOf(96), "&=");
/* 123 */     operatorNames.put(Integer.valueOf(97), "<<=");
/* 124 */     operatorNames.put(Integer.valueOf(98), ">>=");
/* 125 */     operatorNames.put(Integer.valueOf(99), ">>>=");
/* 126 */     operatorNames.put(Integer.valueOf(100), "+=");
/* 127 */     operatorNames.put(Integer.valueOf(101), "-=");
/* 128 */     operatorNames.put(Integer.valueOf(102), "*=");
/* 129 */     operatorNames.put(Integer.valueOf(103), "/=");
/* 130 */     operatorNames.put(Integer.valueOf(104), "%=");
/* 131 */     operatorNames.put(Integer.valueOf(95), "^=");
/* 132 */     operatorNames.put(Integer.valueOf(105), "**=");
/* 133 */     operatorNames.put(Integer.valueOf(130), "void");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PositionComparator
/*     */     implements Comparator<AstNode>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     public int compare(AstNode n1, AstNode n2) {
/* 145 */       return n1.position - n2.position;
/*     */     }
/*     */   }
/*     */   
/*     */   public AstNode() {
/* 150 */     super(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode(int pos) {
/* 158 */     this();
/* 159 */     this.position = pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode(int pos, int len) {
/* 169 */     this();
/* 170 */     this.position = pos;
/* 171 */     this.length = len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPosition() {
/* 178 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(int position) {
/* 185 */     this.position = position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAbsolutePosition() {
/* 194 */     int pos = this.position;
/* 195 */     AstNode parent = this.parent;
/* 196 */     while (parent != null) {
/* 197 */       pos += parent.getPosition();
/* 198 */       parent = parent.getParent();
/*     */     } 
/* 200 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 207 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLength(int length) {
/* 214 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(int position, int end) {
/* 222 */     setPosition(position);
/* 223 */     setLength(end - position);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRelative(int parentPosition) {
/* 234 */     this.position -= parentPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getParent() {
/* 241 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(AstNode parent) {
/* 250 */     if (parent == this.parent) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 255 */     if (this.parent != null) {
/* 256 */       setRelative(-this.parent.getAbsolutePosition());
/*     */     }
/*     */     
/* 259 */     this.parent = parent;
/* 260 */     if (parent != null) {
/* 261 */       setRelative(parent.getAbsolutePosition());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChild(AstNode kid) {
/* 274 */     assertNotNull(kid);
/* 275 */     int end = kid.getPosition() + kid.getLength();
/* 276 */     setLength(end - getPosition());
/* 277 */     addChildToBack(kid);
/* 278 */     kid.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstRoot getAstRoot() {
/* 287 */     AstNode parent = this;
/* 288 */     while (parent != null && !(parent instanceof AstRoot)) {
/* 289 */       parent = parent.getParent();
/*     */     }
/* 291 */     return (AstRoot)parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toSource() {
/* 314 */     return toSource(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String makeIndent(int indent) {
/* 322 */     StringBuilder sb = new StringBuilder();
/* 323 */     for (int i = 0; i < indent; i++) {
/* 324 */       sb.append("  ");
/*     */     }
/* 326 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String shortName() {
/* 334 */     String classname = getClass().getName();
/* 335 */     int last = classname.lastIndexOf(".");
/* 336 */     return classname.substring(last + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String operatorToString(int op) {
/* 345 */     String result = operatorNames.get(Integer.valueOf(op));
/* 346 */     if (result == null)
/* 347 */       throw new IllegalArgumentException("Invalid operator: " + op); 
/* 348 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSideEffects() {
/* 374 */     switch (getType()) {
/*     */       case -1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/*     */       case 30:
/*     */       case 31:
/*     */       case 35:
/*     */       case 37:
/*     */       case 38:
/*     */       case 50:
/*     */       case 51:
/*     */       case 56:
/*     */       case 57:
/*     */       case 65:
/*     */       case 69:
/*     */       case 70:
/*     */       case 71:
/*     */       case 73:
/*     */       case 84:
/*     */       case 85:
/*     */       case 93:
/*     */       case 94:
/*     */       case 95:
/*     */       case 96:
/*     */       case 97:
/*     */       case 98:
/*     */       case 99:
/*     */       case 100:
/*     */       case 101:
/*     */       case 102:
/*     */       case 103:
/*     */       case 104:
/*     */       case 110:
/*     */       case 111:
/*     */       case 113:
/*     */       case 114:
/*     */       case 115:
/*     */       case 116:
/*     */       case 117:
/*     */       case 118:
/*     */       case 121:
/*     */       case 122:
/*     */       case 123:
/*     */       case 124:
/*     */       case 125:
/*     */       case 126:
/*     */       case 127:
/*     */       case 128:
/*     */       case 129:
/*     */       case 133:
/*     */       case 134:
/*     */       case 135:
/*     */       case 136:
/*     */       case 138:
/*     */       case 139:
/*     */       case 143:
/*     */       case 144:
/*     */       case 145:
/*     */       case 146:
/*     */       case 157:
/*     */       case 158:
/*     */       case 162:
/*     */       case 163:
/*     */       case 169:
/* 443 */         return true;
/*     */     } 
/*     */     
/* 446 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void assertNotNull(Object arg) {
/* 456 */     if (arg == null) {
/* 457 */       throw new IllegalArgumentException("arg cannot be null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends AstNode> void printList(List<T> items, StringBuilder sb) {
/* 467 */     int max = items.size();
/* 468 */     int count = 0;
/* 469 */     for (AstNode item : items) {
/* 470 */       sb.append(item.toSource(0));
/* 471 */       if (count++ < max - 1) {
/* 472 */         sb.append(", "); continue;
/* 473 */       }  if (item instanceof EmptyExpression) {
/* 474 */         sb.append(",");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuntimeException codeBug() throws RuntimeException {
/* 485 */     throw Kit.codeBug();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionNode getEnclosingFunction() {
/* 506 */     AstNode parent = getParent();
/* 507 */     while (parent != null && !(parent instanceof FunctionNode)) {
/* 508 */       parent = parent.getParent();
/*     */     }
/* 510 */     return (FunctionNode)parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scope getEnclosingScope() {
/* 521 */     AstNode parent = getParent();
/* 522 */     while (parent != null && !(parent instanceof Scope)) {
/* 523 */       parent = parent.getParent();
/*     */     }
/* 525 */     return (Scope)parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(AstNode other) {
/* 541 */     if (equals(other)) return 0; 
/* 542 */     int abs1 = getAbsolutePosition();
/* 543 */     int abs2 = other.getAbsolutePosition();
/* 544 */     if (abs1 < abs2) return -1; 
/* 545 */     if (abs2 < abs1) return 1; 
/* 546 */     int len1 = getLength();
/* 547 */     int len2 = other.getLength();
/* 548 */     if (len1 < len2) return -1; 
/* 549 */     if (len2 < len1) return 1; 
/* 550 */     return hashCode() - other.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int depth() {
/* 559 */     return (this.parent == null) ? 0 : (1 + this.parent.depth());
/*     */   }
/*     */   
/*     */   protected static class DebugPrintVisitor implements NodeVisitor { private StringBuilder buffer;
/*     */     private static final int DEBUG_INDENT = 2;
/*     */     
/*     */     public DebugPrintVisitor(StringBuilder buf) {
/* 566 */       this.buffer = buf;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 570 */       return this.buffer.toString();
/*     */     }
/*     */     
/*     */     private static String makeIndent(int depth) {
/* 574 */       StringBuilder sb = new StringBuilder(2 * depth);
/* 575 */       for (int i = 0; i < 2 * depth; i++) {
/* 576 */         sb.append(" ");
/*     */       }
/* 578 */       return sb.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean visit(AstNode node) {
/* 583 */       int tt = node.getType();
/* 584 */       String name = Token.typeToName(tt);
/* 585 */       this.buffer.append(node.getAbsolutePosition()).append("\t");
/* 586 */       this.buffer.append(makeIndent(node.depth()));
/* 587 */       this.buffer.append(name).append(" ");
/* 588 */       this.buffer.append(node.getPosition()).append(" ");
/* 589 */       this.buffer.append(node.getLength());
/* 590 */       if (tt == 39) {
/* 591 */         this.buffer.append(" ").append(((Name)node).getIdentifier());
/* 592 */       } else if (tt == 41) {
/* 593 */         this.buffer.append(" ").append(((StringLiteral)node).getValue(true));
/*     */       } 
/* 595 */       this.buffer.append("\n");
/* 596 */       return true;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineno() {
/* 607 */     if (this.lineno != -1)
/* 608 */       return this.lineno; 
/* 609 */     if (this.parent != null)
/* 610 */       return this.parent.getLineno(); 
/* 611 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String debugPrint() {
/* 621 */     DebugPrintVisitor dpv = new DebugPrintVisitor(new StringBuilder(1000));
/* 622 */     visit(dpv);
/* 623 */     return dpv.toString();
/*     */   }
/*     */   
/*     */   public AstNode getInlineComment() {
/* 627 */     return this.inlineComment;
/*     */   }
/*     */   
/*     */   public void setInlineComment(AstNode inlineComment) {
/* 631 */     this.inlineComment = inlineComment;
/*     */   }
/*     */   
/*     */   public abstract String toSource(int paramInt);
/*     */   
/*     */   public abstract void visit(NodeVisitor paramNodeVisitor);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\AstNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */