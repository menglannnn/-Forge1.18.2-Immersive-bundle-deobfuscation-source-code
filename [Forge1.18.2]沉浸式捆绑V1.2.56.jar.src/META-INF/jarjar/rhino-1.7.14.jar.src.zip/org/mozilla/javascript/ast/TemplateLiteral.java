/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateLiteral
/*     */   extends AstNode
/*     */ {
/*     */   private List<AstNode> elements;
/*     */   
/*     */   public TemplateLiteral() {}
/*     */   
/*     */   public TemplateLiteral(int pos) {
/*  30 */     super(pos);
/*     */   }
/*     */   
/*     */   public TemplateLiteral(int pos, int len) {
/*  34 */     super(pos, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<TemplateCharacters> getTemplateStrings() {
/*  39 */     if (this.elements == null) return Collections.emptyList(); 
/*  40 */     List<TemplateCharacters> strings = new ArrayList<>();
/*  41 */     for (AstNode e : this.elements) {
/*  42 */       if (e.getType() == 171) {
/*  43 */         strings.add((TemplateCharacters)e);
/*     */       }
/*     */     } 
/*  46 */     return Collections.unmodifiableList(strings);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AstNode> getSubstitutions() {
/*  51 */     if (this.elements == null) return Collections.emptyList(); 
/*  52 */     List<AstNode> subs = new ArrayList<>();
/*  53 */     for (AstNode e : this.elements) {
/*  54 */       if (e.getType() != 171) {
/*  55 */         subs.add(e);
/*     */       }
/*     */     } 
/*  58 */     return Collections.unmodifiableList(subs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AstNode> getElements() {
/*  67 */     if (this.elements == null) return Collections.emptyList(); 
/*  68 */     return this.elements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElements(List<AstNode> elements) {
/*  77 */     if (elements == null) {
/*  78 */       this.elements = null;
/*     */     } else {
/*  80 */       if (this.elements != null) this.elements.clear(); 
/*  81 */       for (AstNode e : elements) addElement(e);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addElement(AstNode element) {
/*  92 */     assertNotNull(element);
/*  93 */     if (this.elements == null) this.elements = new ArrayList<>(); 
/*  94 */     this.elements.add(element);
/*  95 */     element.setParent(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 100 */     return (this.elements == null) ? 0 : this.elements.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getElement(int index) {
/* 111 */     if (this.elements == null) throw new IndexOutOfBoundsException("no elements"); 
/* 112 */     return this.elements.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 117 */     StringBuilder sb = new StringBuilder();
/* 118 */     sb.append(makeIndent(depth));
/* 119 */     sb.append("`");
/* 120 */     for (AstNode e : getElements()) {
/* 121 */       if (e.getType() == 171) {
/* 122 */         sb.append(e.toSource(0)); continue;
/*     */       } 
/* 124 */       sb.append("${").append(e.toSource(0)).append("}");
/*     */     } 
/*     */     
/* 127 */     sb.append("`");
/* 128 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 134 */     if (v.visit(this))
/* 135 */       for (AstNode e : getElements())
/* 136 */         e.visit(v);  
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\TemplateLiteral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */