/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayComprehensionLoop
/*    */   extends ForInLoop
/*    */ {
/*    */   public ArrayComprehensionLoop() {}
/*    */   
/*    */   public ArrayComprehensionLoop(int pos) {
/* 23 */     super(pos);
/*    */   }
/*    */   
/*    */   public ArrayComprehensionLoop(int pos, int len) {
/* 27 */     super(pos, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AstNode getBody() {
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBody(AstNode body) {
/* 46 */     throw new UnsupportedOperationException("this node type has no body");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 51 */     return makeIndent(depth) + " for " + (
/*    */       
/* 53 */       isForEach() ? "each " : "") + "(" + this.iterator
/*    */       
/* 55 */       .toSource(0) + (
/* 56 */       isForOf() ? " of " : " in ") + this.iteratedObject
/* 57 */       .toSource(0) + ")";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 67 */     if (v.visit(this)) {
/* 68 */       this.iterator.visit(v);
/* 69 */       this.iteratedObject.visit(v);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\ArrayComprehensionLoop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */