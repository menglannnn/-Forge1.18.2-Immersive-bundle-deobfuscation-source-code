/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ import org.mozilla.javascript.ScriptRuntime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringLiteral
/*    */   extends AstNode
/*    */ {
/*    */   private String value;
/*    */   private char quoteChar;
/*    */   
/*    */   public StringLiteral() {}
/*    */   
/*    */   public StringLiteral(int pos) {
/* 29 */     super(pos);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StringLiteral(int pos, int len) {
/* 37 */     super(pos, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 46 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getValue(boolean includeQuotes) {
/* 53 */     if (!includeQuotes)
/* 54 */       return this.value; 
/* 55 */     return this.quoteChar + this.value + this.quoteChar;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(String value) {
/* 64 */     assertNotNull(value);
/* 65 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public char getQuoteCharacter() {
/* 72 */     return this.quoteChar;
/*    */   }
/*    */   
/*    */   public void setQuoteCharacter(char c) {
/* 76 */     this.quoteChar = c;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSource(int depth) {
/* 81 */     return makeIndent(depth) + this.quoteChar + 
/*    */       
/* 83 */       ScriptRuntime.escapeString(this.value, this.quoteChar) + this.quoteChar;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 93 */     v.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\StringLiteral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */