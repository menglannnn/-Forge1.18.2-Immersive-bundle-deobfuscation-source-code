/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlElemRef
/*     */   extends XmlRef
/*     */ {
/*     */   private AstNode indexExpr;
/*  36 */   private int lb = -1;
/*  37 */   private int rb = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlElemRef() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlElemRef(int pos) {
/*  47 */     super(pos);
/*     */   }
/*     */   
/*     */   public XmlElemRef(int pos, int len) {
/*  51 */     super(pos, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getExpression() {
/*  59 */     return this.indexExpr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(AstNode expr) {
/*  67 */     assertNotNull(expr);
/*  68 */     this.indexExpr = expr;
/*  69 */     expr.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLb() {
/*  76 */     return this.lb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLb(int lb) {
/*  83 */     this.lb = lb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRb() {
/*  90 */     return this.rb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRb(int rb) {
/*  97 */     this.rb = rb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBrackets(int lb, int rb) {
/* 104 */     this.lb = lb;
/* 105 */     this.rb = rb;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 110 */     StringBuilder sb = new StringBuilder();
/* 111 */     sb.append(makeIndent(depth));
/* 112 */     if (isAttributeAccess()) {
/* 113 */       sb.append("@");
/*     */     }
/* 115 */     if (this.namespace != null) {
/* 116 */       sb.append(this.namespace.toSource(0));
/* 117 */       sb.append("::");
/*     */     } 
/* 119 */     sb.append("[");
/* 120 */     sb.append(this.indexExpr.toSource(0));
/* 121 */     sb.append("]");
/* 122 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 131 */     if (v.visit(this)) {
/* 132 */       if (this.namespace != null) {
/* 133 */         this.namespace.visit(v);
/*     */       }
/* 135 */       this.indexExpr.visit(v);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\XmlElemRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */