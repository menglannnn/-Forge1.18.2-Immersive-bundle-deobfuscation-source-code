/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.mozilla.javascript.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionNode
/*     */   extends ScriptNode
/*     */ {
/*     */   public static final int FUNCTION_STATEMENT = 1;
/*     */   public static final int FUNCTION_EXPRESSION = 2;
/*     */   public static final int FUNCTION_EXPRESSION_STATEMENT = 3;
/*     */   public static final int ARROW_FUNCTION = 4;
/*     */   
/*     */   public enum Form
/*     */   {
/*  68 */     FUNCTION, GETTER, SETTER, METHOD;
/*     */   }
/*     */   
/*  71 */   private static final List<AstNode> NO_PARAMS = Collections.unmodifiableList(new ArrayList<>());
/*     */   
/*     */   private Name functionName;
/*     */   private List<AstNode> params;
/*     */   private AstNode body;
/*     */   private boolean isExpressionClosure;
/*  77 */   private Form functionForm = Form.FUNCTION;
/*  78 */   private int lp = -1;
/*  79 */   private int rp = -1;
/*     */   
/*     */   private int functionType;
/*     */   
/*     */   private boolean needsActivation;
/*     */   
/*     */   private boolean isGenerator;
/*     */   
/*     */   private boolean isES6Generator;
/*     */   
/*     */   private List<Node> generatorResumePoints;
/*     */   
/*     */   private Map<Node, int[]> liveLocals;
/*     */   
/*     */   private AstNode memberExprNode;
/*     */   
/*     */   public FunctionNode() {}
/*     */   
/*     */   public FunctionNode(int pos) {
/*  98 */     super(pos);
/*     */   }
/*     */   
/*     */   public FunctionNode(int pos, Name name) {
/* 102 */     super(pos);
/* 103 */     setFunctionName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getFunctionName() {
/* 111 */     return this.functionName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFunctionName(Name name) {
/* 119 */     this.functionName = name;
/* 120 */     if (name != null) {
/* 121 */       name.setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 129 */     return (this.functionName != null) ? this.functionName.getIdentifier() : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AstNode> getParams() {
/* 138 */     return (this.params != null) ? this.params : NO_PARAMS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParams(List<AstNode> params) {
/* 147 */     if (params == null) {
/* 148 */       this.params = null;
/*     */     } else {
/* 150 */       if (this.params != null)
/* 151 */         this.params.clear(); 
/* 152 */       for (AstNode param : params) {
/* 153 */         addParam(param);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(AstNode param) {
/* 164 */     assertNotNull(param);
/* 165 */     if (this.params == null) {
/* 166 */       this.params = new ArrayList<>();
/*     */     }
/* 168 */     this.params.add(param);
/* 169 */     param.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParam(AstNode node) {
/* 178 */     return (this.params == null) ? false : this.params.contains(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getBody() {
/* 188 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(AstNode body) {
/* 203 */     assertNotNull(body);
/* 204 */     this.body = body;
/* 205 */     if (Boolean.TRUE.equals(body.getProp(25))) {
/* 206 */       setIsExpressionClosure(true);
/*     */     }
/* 208 */     int absEnd = body.getPosition() + body.getLength();
/* 209 */     body.setParent(this);
/* 210 */     setLength(absEnd - this.position);
/* 211 */     setEncodedSourceBounds(this.position, absEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLp() {
/* 218 */     return this.lp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLp(int lp) {
/* 225 */     this.lp = lp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRp() {
/* 232 */     return this.rp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRp(int rp) {
/* 239 */     this.rp = rp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParens(int lp, int rp) {
/* 246 */     this.lp = lp;
/* 247 */     this.rp = rp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExpressionClosure() {
/* 254 */     return this.isExpressionClosure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsExpressionClosure(boolean isExpressionClosure) {
/* 261 */     this.isExpressionClosure = isExpressionClosure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresActivation() {
/* 275 */     return this.needsActivation;
/*     */   }
/*     */   
/*     */   public void setRequiresActivation() {
/* 279 */     this.needsActivation = true;
/*     */   }
/*     */   
/*     */   public boolean isGenerator() {
/* 283 */     return this.isGenerator;
/*     */   }
/*     */   
/*     */   public void setIsGenerator() {
/* 287 */     this.isGenerator = true;
/*     */   }
/*     */   
/*     */   public boolean isES6Generator() {
/* 291 */     return this.isES6Generator;
/*     */   }
/*     */   
/*     */   public void setIsES6Generator() {
/* 295 */     this.isES6Generator = true;
/* 296 */     this.isGenerator = true;
/*     */   }
/*     */   
/*     */   public void addResumptionPoint(Node target) {
/* 300 */     if (this.generatorResumePoints == null)
/* 301 */       this.generatorResumePoints = new ArrayList<>(); 
/* 302 */     this.generatorResumePoints.add(target);
/*     */   }
/*     */   
/*     */   public List<Node> getResumptionPoints() {
/* 306 */     return this.generatorResumePoints;
/*     */   }
/*     */   
/*     */   public Map<Node, int[]> getLiveLocals() {
/* 310 */     return this.liveLocals;
/*     */   }
/*     */   
/*     */   public void addLiveLocals(Node node, int[] locals) {
/* 314 */     if (this.liveLocals == null)
/* 315 */       this.liveLocals = (Map)new HashMap<>(); 
/* 316 */     this.liveLocals.put(node, locals);
/*     */   }
/*     */ 
/*     */   
/*     */   public int addFunction(FunctionNode fnNode) {
/* 321 */     int result = super.addFunction(fnNode);
/* 322 */     if (getFunctionCount() > 0) {
/* 323 */       this.needsActivation = true;
/*     */     }
/* 325 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFunctionType() {
/* 332 */     return this.functionType;
/*     */   }
/*     */   
/*     */   public void setFunctionType(int type) {
/* 336 */     this.functionType = type;
/*     */   }
/*     */   
/*     */   public boolean isMethod() {
/* 340 */     return (this.functionForm == Form.GETTER || this.functionForm == Form.SETTER || this.functionForm == Form.METHOD);
/*     */   }
/*     */   
/*     */   public boolean isGetterMethod() {
/* 344 */     return (this.functionForm == Form.GETTER);
/*     */   }
/*     */   
/*     */   public boolean isSetterMethod() {
/* 348 */     return (this.functionForm == Form.SETTER);
/*     */   }
/*     */   
/*     */   public boolean isNormalMethod() {
/* 352 */     return (this.functionForm == Form.METHOD);
/*     */   }
/*     */   
/*     */   public void setFunctionIsGetterMethod() {
/* 356 */     this.functionForm = Form.GETTER;
/*     */   }
/*     */   
/*     */   public void setFunctionIsSetterMethod() {
/* 360 */     this.functionForm = Form.SETTER;
/*     */   }
/*     */   
/*     */   public void setFunctionIsNormalMethod() {
/* 364 */     this.functionForm = Form.METHOD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMemberExprNode(AstNode node) {
/* 378 */     this.memberExprNode = node;
/* 379 */     if (node != null)
/* 380 */       node.setParent(this); 
/*     */   }
/*     */   
/*     */   public AstNode getMemberExprNode() {
/* 384 */     return this.memberExprNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 389 */     StringBuilder sb = new StringBuilder();
/* 390 */     boolean isArrow = (this.functionType == 4);
/* 391 */     if (!isMethod()) {
/* 392 */       sb.append(makeIndent(depth));
/* 393 */       if (!isArrow) {
/* 394 */         sb.append("function");
/*     */       }
/*     */     } 
/* 397 */     if (this.functionName != null) {
/* 398 */       sb.append(" ");
/* 399 */       sb.append(this.functionName.toSource(0));
/*     */     } 
/* 401 */     if (this.params == null) {
/* 402 */       sb.append("() ");
/* 403 */     } else if (isArrow && this.lp == -1) {
/*     */       
/* 405 */       printList(this.params, sb);
/* 406 */       sb.append(" ");
/*     */     } else {
/* 408 */       sb.append("(");
/* 409 */       printList(this.params, sb);
/* 410 */       sb.append(") ");
/*     */     } 
/* 412 */     if (isArrow) {
/* 413 */       sb.append("=> ");
/*     */     }
/* 415 */     if (this.isExpressionClosure) {
/* 416 */       AstNode body = getBody();
/* 417 */       if (body.getLastChild() instanceof ReturnStatement) {
/*     */         
/* 419 */         body = ((ReturnStatement)body.getLastChild()).getReturnValue();
/* 420 */         sb.append(body.toSource(0));
/* 421 */         if (this.functionType == 1) {
/* 422 */           sb.append(";");
/*     */         }
/*     */       } else {
/*     */         
/* 426 */         sb.append(" ");
/* 427 */         sb.append(body.toSource(0));
/*     */       } 
/*     */     } else {
/* 430 */       sb.append(getBody().toSource(depth).trim());
/*     */     } 
/* 432 */     if (this.functionType == 1 || isMethod()) {
/* 433 */       sb.append("\n");
/*     */     }
/* 435 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 445 */     if (v.visit(this)) {
/* 446 */       if (this.functionName != null) {
/* 447 */         this.functionName.visit(v);
/*     */       }
/* 449 */       for (AstNode param : getParams()) {
/* 450 */         param.visit(v);
/*     */       }
/* 452 */       getBody().visit(v);
/* 453 */       if (!this.isExpressionClosure && 
/* 454 */         this.memberExprNode != null)
/* 455 */         this.memberExprNode.visit(v); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\FunctionNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */