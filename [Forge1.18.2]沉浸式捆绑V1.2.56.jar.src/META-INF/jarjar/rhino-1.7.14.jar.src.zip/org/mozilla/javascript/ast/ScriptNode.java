/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.mozilla.javascript.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptNode
/*     */   extends Scope
/*     */ {
/*  21 */   private int encodedSourceStart = -1;
/*  22 */   private int encodedSourceEnd = -1;
/*     */   private String sourceName;
/*     */   private String encodedSource;
/*  25 */   private int endLineno = -1;
/*     */   
/*     */   private List<FunctionNode> functions;
/*     */   private List<RegExpLiteral> regexps;
/*     */   private List<TemplateLiteral> templateLiterals;
/*  30 */   private List<FunctionNode> EMPTY_LIST = Collections.emptyList();
/*     */   
/*  32 */   private List<Symbol> symbols = new ArrayList<>(4);
/*  33 */   private int paramCount = 0;
/*     */   
/*     */   private String[] variableNames;
/*     */   private boolean[] isConsts;
/*     */   private Object compilerData;
/*  38 */   private int tempNumber = 0;
/*     */ 
/*     */   
/*     */   private boolean inStrictMode;
/*     */ 
/*     */ 
/*     */   
/*     */   public ScriptNode() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public ScriptNode(int pos) {
/*  50 */     super(pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/*  57 */     return this.sourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceName(String sourceName) {
/*  64 */     this.sourceName = sourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEncodedSourceStart() {
/*  72 */     return this.encodedSourceStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodedSourceStart(int start) {
/*  81 */     this.encodedSourceStart = start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEncodedSourceEnd() {
/*  89 */     return this.encodedSourceEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodedSourceEnd(int end) {
/*  98 */     this.encodedSourceEnd = end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodedSourceBounds(int start, int end) {
/* 107 */     this.encodedSourceStart = start;
/* 108 */     this.encodedSourceEnd = end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodedSource(String encodedSource) {
/* 117 */     this.encodedSource = encodedSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncodedSource() {
/* 133 */     return this.encodedSource;
/*     */   }
/*     */   
/*     */   public int getBaseLineno() {
/* 137 */     return this.lineno;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseLineno(int lineno) {
/* 145 */     if (lineno < 0 || this.lineno >= 0) codeBug(); 
/* 146 */     this.lineno = lineno;
/*     */   }
/*     */   
/*     */   public int getEndLineno() {
/* 150 */     return this.endLineno;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEndLineno(int lineno) {
/* 155 */     if (lineno < 0 || this.endLineno >= 0) codeBug(); 
/* 156 */     this.endLineno = lineno;
/*     */   }
/*     */   
/*     */   public int getFunctionCount() {
/* 160 */     return (this.functions == null) ? 0 : this.functions.size();
/*     */   }
/*     */   
/*     */   public FunctionNode getFunctionNode(int i) {
/* 164 */     return this.functions.get(i);
/*     */   }
/*     */   
/*     */   public List<FunctionNode> getFunctions() {
/* 168 */     return (this.functions == null) ? this.EMPTY_LIST : this.functions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addFunction(FunctionNode fnNode) {
/* 178 */     if (fnNode == null) codeBug(); 
/* 179 */     if (this.functions == null) this.functions = new ArrayList<>(); 
/* 180 */     this.functions.add(fnNode);
/* 181 */     return this.functions.size() - 1;
/*     */   }
/*     */   
/*     */   public int getRegexpCount() {
/* 185 */     return (this.regexps == null) ? 0 : this.regexps.size();
/*     */   }
/*     */   
/*     */   public String getRegexpString(int index) {
/* 189 */     return ((RegExpLiteral)this.regexps.get(index)).getValue();
/*     */   }
/*     */   
/*     */   public String getRegexpFlags(int index) {
/* 193 */     return ((RegExpLiteral)this.regexps.get(index)).getFlags();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addRegExp(RegExpLiteral re) {
/* 198 */     if (re == null) codeBug(); 
/* 199 */     if (this.regexps == null) this.regexps = new ArrayList<>(); 
/* 200 */     this.regexps.add(re);
/* 201 */     re.putIntProp(4, this.regexps.size() - 1);
/*     */   }
/*     */   
/*     */   public int getTemplateLiteralCount() {
/* 205 */     return (this.templateLiterals == null) ? 0 : this.templateLiterals.size();
/*     */   }
/*     */   
/*     */   public List<TemplateCharacters> getTemplateLiteralStrings(int index) {
/* 209 */     return ((TemplateLiteral)this.templateLiterals.get(index)).getTemplateStrings();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addTemplateLiteral(TemplateLiteral templateLiteral) {
/* 214 */     if (templateLiteral == null) codeBug(); 
/* 215 */     if (this.templateLiterals == null) this.templateLiterals = new ArrayList<>(); 
/* 216 */     this.templateLiterals.add(templateLiteral);
/* 217 */     templateLiteral.putIntProp(28, this.templateLiterals.size() - 1);
/*     */   }
/*     */   
/*     */   public int getIndexForNameNode(Node nameNode) {
/* 221 */     if (this.variableNames == null) codeBug(); 
/* 222 */     Scope node = nameNode.getScope();
/* 223 */     Symbol symbol = null;
/* 224 */     if (node != null && nameNode instanceof Name) {
/* 225 */       symbol = node.getSymbol(((Name)nameNode).getIdentifier());
/*     */     }
/* 227 */     return (symbol == null) ? -1 : symbol.getIndex();
/*     */   }
/*     */   
/*     */   public String getParamOrVarName(int index) {
/* 231 */     if (this.variableNames == null) codeBug(); 
/* 232 */     return this.variableNames[index];
/*     */   }
/*     */   
/*     */   public int getParamCount() {
/* 236 */     return this.paramCount;
/*     */   }
/*     */   
/*     */   public int getParamAndVarCount() {
/* 240 */     if (this.variableNames == null) codeBug(); 
/* 241 */     return this.symbols.size();
/*     */   }
/*     */   
/*     */   public String[] getParamAndVarNames() {
/* 245 */     if (this.variableNames == null) codeBug(); 
/* 246 */     return this.variableNames;
/*     */   }
/*     */   
/*     */   public boolean[] getParamAndVarConst() {
/* 250 */     if (this.variableNames == null) codeBug(); 
/* 251 */     return this.isConsts;
/*     */   }
/*     */   
/*     */   void addSymbol(Symbol symbol) {
/* 255 */     if (this.variableNames != null) codeBug(); 
/* 256 */     if (symbol.getDeclType() == 90) {
/* 257 */       this.paramCount++;
/*     */     }
/* 259 */     this.symbols.add(symbol);
/*     */   }
/*     */   
/*     */   public List<Symbol> getSymbols() {
/* 263 */     return this.symbols;
/*     */   }
/*     */   
/*     */   public void setSymbols(List<Symbol> symbols) {
/* 267 */     this.symbols = symbols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flattenSymbolTable(boolean flattenAllTables) {
/* 278 */     if (!flattenAllTables) {
/* 279 */       List<Symbol> newSymbols = new ArrayList<>();
/* 280 */       if (this.symbolTable != null)
/*     */       {
/*     */ 
/*     */         
/* 284 */         for (int j = 0; j < this.symbols.size(); j++) {
/* 285 */           Symbol symbol = this.symbols.get(j);
/* 286 */           if (symbol.getContainingTable() == this) {
/* 287 */             newSymbols.add(symbol);
/*     */           }
/*     */         } 
/*     */       }
/* 291 */       this.symbols = newSymbols;
/*     */     } 
/* 293 */     this.variableNames = new String[this.symbols.size()];
/* 294 */     this.isConsts = new boolean[this.symbols.size()];
/* 295 */     for (int i = 0; i < this.symbols.size(); i++) {
/* 296 */       Symbol symbol = this.symbols.get(i);
/* 297 */       this.variableNames[i] = symbol.getName();
/* 298 */       this.isConsts[i] = (symbol.getDeclType() == 158);
/* 299 */       symbol.setIndex(i);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getCompilerData() {
/* 304 */     return this.compilerData;
/*     */   }
/*     */   
/*     */   public void setCompilerData(Object data) {
/* 308 */     assertNotNull(data);
/*     */     
/* 310 */     if (this.compilerData != null) throw new IllegalStateException(); 
/* 311 */     this.compilerData = data;
/*     */   }
/*     */   
/*     */   public String getNextTempName() {
/* 315 */     return "$" + this.tempNumber++;
/*     */   }
/*     */   
/*     */   public void setInStrictMode(boolean inStrictMode) {
/* 319 */     this.inStrictMode = inStrictMode;
/*     */   }
/*     */   
/*     */   public boolean isInStrictMode() {
/* 323 */     return this.inStrictMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 328 */     if (v.visit(this))
/* 329 */       for (Node kid : this)
/* 330 */         ((AstNode)kid).visit(v);  
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\ScriptNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */