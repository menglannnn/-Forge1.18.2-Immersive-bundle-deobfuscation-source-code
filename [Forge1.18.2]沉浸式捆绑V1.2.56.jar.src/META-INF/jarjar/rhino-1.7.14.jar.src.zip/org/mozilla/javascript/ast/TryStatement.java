/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TryStatement
/*     */   extends AstNode
/*     */ {
/*  30 */   private static final List<CatchClause> NO_CATCHES = Collections.unmodifiableList(new ArrayList<>());
/*     */   
/*     */   private AstNode tryBlock;
/*     */   private List<CatchClause> catchClauses;
/*     */   private AstNode finallyBlock;
/*  35 */   private int finallyPosition = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TryStatement() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public TryStatement(int pos) {
/*  45 */     super(pos);
/*     */   }
/*     */   
/*     */   public TryStatement(int pos, int len) {
/*  49 */     super(pos, len);
/*     */   }
/*     */   
/*     */   public AstNode getTryBlock() {
/*  53 */     return this.tryBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTryBlock(AstNode tryBlock) {
/*  61 */     assertNotNull(tryBlock);
/*  62 */     this.tryBlock = tryBlock;
/*  63 */     tryBlock.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CatchClause> getCatchClauses() {
/*  71 */     return (this.catchClauses != null) ? this.catchClauses : NO_CATCHES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatchClauses(List<CatchClause> catchClauses) {
/*  80 */     if (catchClauses == null) {
/*  81 */       this.catchClauses = null;
/*     */     } else {
/*  83 */       if (this.catchClauses != null)
/*  84 */         this.catchClauses.clear(); 
/*  85 */       for (CatchClause cc : catchClauses) {
/*  86 */         addCatchClause(cc);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCatchClause(CatchClause clause) {
/*  97 */     assertNotNull(clause);
/*  98 */     if (this.catchClauses == null) {
/*  99 */       this.catchClauses = new ArrayList<>();
/*     */     }
/* 101 */     this.catchClauses.add(clause);
/* 102 */     clause.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AstNode getFinallyBlock() {
/* 109 */     return this.finallyBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFinallyBlock(AstNode finallyBlock) {
/* 117 */     this.finallyBlock = finallyBlock;
/* 118 */     if (finallyBlock != null) {
/* 119 */       finallyBlock.setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFinallyPosition() {
/* 126 */     return this.finallyPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFinallyPosition(int finallyPosition) {
/* 133 */     this.finallyPosition = finallyPosition;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 138 */     StringBuilder sb = new StringBuilder(250);
/* 139 */     sb.append(makeIndent(depth));
/* 140 */     sb.append("try ");
/* 141 */     if (getInlineComment() != null) {
/* 142 */       sb.append(getInlineComment().toSource(depth + 1)).append("\n");
/*     */     }
/* 144 */     sb.append(this.tryBlock.toSource(depth).trim());
/* 145 */     for (CatchClause cc : getCatchClauses()) {
/* 146 */       sb.append(cc.toSource(depth));
/*     */     }
/* 148 */     if (this.finallyBlock != null) {
/* 149 */       sb.append(" finally ");
/* 150 */       sb.append(this.finallyBlock.toSource(depth));
/*     */     } 
/* 152 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NodeVisitor v) {
/* 161 */     if (v.visit(this)) {
/* 162 */       this.tryBlock.visit(v);
/* 163 */       for (CatchClause cc : getCatchClauses()) {
/* 164 */         cc.visit(v);
/*     */       }
/* 166 */       if (this.finallyBlock != null)
/* 167 */         this.finallyBlock.visit(v); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\TryStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */