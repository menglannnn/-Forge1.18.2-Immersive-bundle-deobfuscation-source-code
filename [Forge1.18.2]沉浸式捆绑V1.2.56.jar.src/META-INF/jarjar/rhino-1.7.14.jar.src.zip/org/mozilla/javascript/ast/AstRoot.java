/*     */ package org.mozilla.javascript.ast;
/*     */ 
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.mozilla.javascript.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AstRoot
/*     */   extends ScriptNode
/*     */ {
/*     */   private SortedSet<Comment> comments;
/*     */   
/*     */   public AstRoot() {}
/*     */   
/*     */   public AstRoot(int pos) {
/*  37 */     super(pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedSet<Comment> getComments() {
/*  45 */     return this.comments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComments(SortedSet<Comment> comments) {
/*  54 */     if (comments == null) {
/*  55 */       this.comments = null;
/*     */     } else {
/*  57 */       if (this.comments != null)
/*  58 */         this.comments.clear(); 
/*  59 */       for (Comment c : comments) {
/*  60 */         addComment(c);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addComment(Comment comment) {
/*  70 */     assertNotNull(comment);
/*  71 */     if (this.comments == null) {
/*  72 */       this.comments = new TreeSet<>(new AstNode.PositionComparator());
/*     */     }
/*  74 */     this.comments.add(comment);
/*  75 */     comment.setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitComments(NodeVisitor visitor) {
/*  86 */     if (this.comments != null) {
/*  87 */       for (Comment c : this.comments) {
/*  88 */         visitor.visit(c);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitAll(NodeVisitor visitor) {
/* 101 */     visit(visitor);
/* 102 */     visitComments(visitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSource(int depth) {
/* 107 */     StringBuilder sb = new StringBuilder();
/* 108 */     for (Node node : this) {
/* 109 */       sb.append(((AstNode)node).toSource(depth));
/* 110 */       if (node.getType() == 165) {
/* 111 */         sb.append("\n");
/*     */       }
/*     */     } 
/* 114 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String debugPrint() {
/* 122 */     AstNode.DebugPrintVisitor dpv = new AstNode.DebugPrintVisitor(new StringBuilder(1000));
/* 123 */     visitAll(dpv);
/* 124 */     return dpv.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkParentLinks() {
/* 133 */     visit(new NodeVisitor()
/*     */         {
/*     */           public boolean visit(AstNode node) {
/* 136 */             int type = node.getType();
/* 137 */             if (type == 140)
/* 138 */               return true; 
/* 139 */             if (node.getParent() == null)
/* 140 */               throw new IllegalStateException("No parent for node: " + node + "\n" + node
/*     */                   
/* 142 */                   .toSource(0)); 
/* 143 */             return true;
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\AstRoot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */