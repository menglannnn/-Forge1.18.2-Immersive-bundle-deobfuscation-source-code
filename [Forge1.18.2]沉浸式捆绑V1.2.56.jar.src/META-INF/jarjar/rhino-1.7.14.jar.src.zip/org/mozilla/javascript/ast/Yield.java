/*    */ package org.mozilla.javascript.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Yield
/*    */   extends AstNode
/*    */ {
/*    */   private AstNode value;
/*    */   
/*    */   public Yield() {
/* 23 */     this.type = 73;
/*    */   }
/*    */   
/*    */   public Yield(int pos) {
/* 27 */     super(pos);
/* 28 */     this.type = 73;
/*    */   }
/*    */   
/*    */   public Yield(int pos, int len) {
/* 32 */     super(pos, len);
/* 33 */     this.type = 73;
/*    */   }
/*    */   
/*    */   public Yield(int pos, int len, AstNode value, boolean isStar) {
/* 37 */     super(pos, len);
/* 38 */     this.type = isStar ? 169 : 73;
/* 39 */     setValue(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AstNode getValue() {
/* 46 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(AstNode expr) {
/* 54 */     this.value = expr;
/* 55 */     if (expr != null) {
/* 56 */       expr.setParent(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public String toSource(int depth) {
/* 61 */     return (this.value == null) ? "yield" : ("yield " + this.value
/*    */       
/* 63 */       .toSource(0));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(NodeVisitor v) {
/* 71 */     if (v.visit(this) && this.value != null)
/* 72 */       this.value.visit(v); 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ast\Yield.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */