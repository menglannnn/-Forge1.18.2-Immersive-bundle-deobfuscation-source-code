/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbeddedSlotMap
/*     */   implements SlotMap
/*     */ {
/*     */   private Slot[] slots;
/*     */   private Slot firstAdded;
/*     */   private Slot lastAdded;
/*     */   private int count;
/*     */   private static final int INITIAL_SLOT_SIZE = 4;
/*     */   
/*     */   private static final class Iter
/*     */     implements Iterator<Slot>
/*     */   {
/*     */     private Slot next;
/*     */     
/*     */     Iter(Slot slot) {
/*  37 */       this.next = slot;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  42 */       return (this.next != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Slot next() {
/*  47 */       Slot ret = this.next;
/*  48 */       if (ret == null) {
/*  49 */         throw new NoSuchElementException();
/*     */       }
/*  51 */       this.next = this.next.orderedNext;
/*  52 */       return ret;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  60 */     return this.count;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  65 */     return (this.count == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Slot> iterator() {
/*  70 */     return new Iter(this.firstAdded);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Slot query(Object key, int index) {
/*  76 */     if (this.slots == null) {
/*  77 */       return null;
/*     */     }
/*     */     
/*  80 */     int indexOrHash = (key != null) ? key.hashCode() : index;
/*  81 */     int slotIndex = getSlotIndex(this.slots.length, indexOrHash);
/*  82 */     for (Slot slot = this.slots[slotIndex]; slot != null; slot = slot.next) {
/*  83 */       if (indexOrHash == slot.indexOrHash && Objects.equals(slot.name, key)) {
/*  84 */         return slot;
/*     */       }
/*     */     } 
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Slot modify(Object key, int index, int attributes) {
/*  98 */     int indexOrHash = (key != null) ? key.hashCode() : index;
/*     */ 
/*     */     
/* 101 */     if (this.slots != null) {
/* 102 */       int slotIndex = getSlotIndex(this.slots.length, indexOrHash); Slot slot;
/* 103 */       for (slot = this.slots[slotIndex]; slot != null && (
/* 104 */         indexOrHash != slot.indexOrHash || !Objects.equals(slot.name, key)); slot = slot.next);
/*     */ 
/*     */ 
/*     */       
/* 108 */       if (slot != null) {
/* 109 */         return slot;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 114 */     return createSlot(key, indexOrHash, attributes);
/*     */   }
/*     */   
/*     */   private Slot createSlot(Object key, int indexOrHash, int attributes) {
/* 118 */     if (this.count == 0)
/*     */     {
/* 120 */       this.slots = new Slot[4];
/*     */     }
/*     */ 
/*     */     
/* 124 */     if (4 * (this.count + 1) > 3 * this.slots.length) {
/*     */       
/* 126 */       Slot[] newSlots = new Slot[this.slots.length * 2];
/* 127 */       copyTable(this.slots, newSlots);
/* 128 */       this.slots = newSlots;
/*     */     } 
/*     */     
/* 131 */     Slot newSlot = new Slot(key, indexOrHash, attributes);
/* 132 */     insertNewSlot(newSlot);
/* 133 */     return newSlot;
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(Slot oldSlot, Slot newSlot) {
/* 138 */     int insertPos = getSlotIndex(this.slots.length, oldSlot.indexOrHash);
/* 139 */     Slot prev = this.slots[insertPos];
/* 140 */     Slot tmpSlot = prev;
/*     */     
/* 142 */     while (tmpSlot != null && 
/* 143 */       tmpSlot != oldSlot) {
/*     */ 
/*     */       
/* 146 */       prev = tmpSlot;
/* 147 */       tmpSlot = tmpSlot.next;
/*     */     } 
/*     */ 
/*     */     
/* 151 */     assert tmpSlot == oldSlot;
/*     */ 
/*     */     
/* 154 */     if (prev == oldSlot) {
/* 155 */       this.slots[insertPos] = newSlot;
/*     */     } else {
/* 157 */       prev.next = newSlot;
/*     */     } 
/* 159 */     newSlot.next = oldSlot.next;
/*     */ 
/*     */     
/* 162 */     if (oldSlot == this.firstAdded) {
/* 163 */       this.firstAdded = newSlot;
/*     */     } else {
/* 165 */       Slot ps = this.firstAdded;
/* 166 */       while (ps != null && ps.orderedNext != oldSlot) {
/* 167 */         ps = ps.orderedNext;
/*     */       }
/* 169 */       if (ps != null) {
/* 170 */         ps.orderedNext = newSlot;
/*     */       }
/*     */     } 
/* 173 */     newSlot.orderedNext = oldSlot.orderedNext;
/* 174 */     if (oldSlot == this.lastAdded) {
/* 175 */       this.lastAdded = newSlot;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Slot newSlot) {
/* 181 */     if (this.slots == null) {
/* 182 */       this.slots = new Slot[4];
/*     */     }
/* 184 */     insertNewSlot(newSlot);
/*     */   }
/*     */   
/*     */   private void insertNewSlot(Slot newSlot) {
/* 188 */     this.count++;
/*     */     
/* 190 */     if (this.lastAdded != null) {
/* 191 */       this.lastAdded.orderedNext = newSlot;
/*     */     }
/* 193 */     if (this.firstAdded == null) {
/* 194 */       this.firstAdded = newSlot;
/*     */     }
/* 196 */     this.lastAdded = newSlot;
/*     */     
/* 198 */     addKnownAbsentSlot(this.slots, newSlot);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(Object key, int index) {
/* 203 */     int indexOrHash = (key != null) ? key.hashCode() : index;
/*     */     
/* 205 */     if (this.count != 0) {
/* 206 */       int slotIndex = getSlotIndex(this.slots.length, indexOrHash);
/* 207 */       Slot prev = this.slots[slotIndex];
/* 208 */       Slot slot = prev;
/* 209 */       while (slot != null && (
/* 210 */         slot.indexOrHash != indexOrHash || !Objects.equals(slot.name, key))) {
/*     */ 
/*     */         
/* 213 */         prev = slot;
/* 214 */         slot = slot.next;
/*     */       } 
/* 216 */       if (slot != null) {
/*     */         
/* 218 */         if ((slot.getAttributes() & 0x4) != 0) {
/* 219 */           Context cx = Context.getContext();
/* 220 */           if (cx.isStrictMode()) {
/* 221 */             throw ScriptRuntime.typeErrorById("msg.delete.property.with.configurable.false", new Object[] { key });
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/* 226 */         this.count--;
/*     */         
/* 228 */         if (prev == slot) {
/* 229 */           this.slots[slotIndex] = slot.next;
/*     */         } else {
/* 231 */           prev.next = slot.next;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 239 */         if (slot == this.firstAdded) {
/* 240 */           prev = null;
/* 241 */           this.firstAdded = slot.orderedNext;
/*     */         } else {
/* 243 */           prev = this.firstAdded;
/* 244 */           while (prev.orderedNext != slot) {
/* 245 */             prev = prev.orderedNext;
/*     */           }
/* 247 */           prev.orderedNext = slot.orderedNext;
/*     */         } 
/* 249 */         if (slot == this.lastAdded) {
/* 250 */           this.lastAdded = prev;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void copyTable(Slot[] oldSlots, Slot[] newSlots) {
/* 257 */     for (Slot slot : oldSlots) {
/* 258 */       while (slot != null) {
/* 259 */         Slot nextSlot = slot.next;
/* 260 */         slot.next = null;
/* 261 */         addKnownAbsentSlot(newSlots, slot);
/* 262 */         slot = nextSlot;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addKnownAbsentSlot(Slot[] addSlots, Slot slot) {
/* 272 */     int insertPos = getSlotIndex(addSlots.length, slot.indexOrHash);
/* 273 */     Slot old = addSlots[insertPos];
/* 274 */     addSlots[insertPos] = slot;
/* 275 */     slot.next = old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getSlotIndex(int tableSize, int indexOrHash) {
/* 282 */     return indexOrHash & tableSize - 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\EmbeddedSlotMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */