/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeCallSite
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 2688372752566593594L;
/*     */   private static final String CALLSITE_TAG = "CallSite";
/*     */   private ScriptStackElement element;
/*     */   private static final int Id_constructor = 1;
/*     */   private static final int Id_getThis = 2;
/*     */   private static final int Id_getTypeName = 3;
/*     */   private static final int Id_getFunction = 4;
/*     */   private static final int Id_getFunctionName = 5;
/*     */   private static final int Id_getMethodName = 6;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  19 */     NativeCallSite cs = new NativeCallSite();
/*  20 */     cs.exportAsJSClass(15, scope, sealed);
/*     */   }
/*     */   private static final int Id_getFileName = 7; private static final int Id_getLineNumber = 8; private static final int Id_getColumnNumber = 9; private static final int Id_getEvalOrigin = 10; private static final int Id_isToplevel = 11; private static final int Id_isEval = 12; private static final int Id_isNative = 13; private static final int Id_isConstructor = 14; private static final int Id_toString = 15; private static final int MAX_PROTOTYPE_ID = 15;
/*     */   static NativeCallSite make(Scriptable scope, Scriptable ctorObj) {
/*  24 */     NativeCallSite cs = new NativeCallSite();
/*  25 */     Scriptable proto = (Scriptable)ctorObj.get("prototype", ctorObj);
/*  26 */     cs.setParentScope(scope);
/*  27 */     cs.setPrototype(proto);
/*  28 */     return cs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setElement(ScriptStackElement elt) {
/*  34 */     this.element = elt;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  39 */     return "CallSite";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*  46 */     switch (id) {
/*     */       case 1:
/*  48 */         arity = 0;
/*  49 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/*  52 */         arity = 0;
/*  53 */         s = "getThis";
/*     */         break;
/*     */       case 3:
/*  56 */         arity = 0;
/*  57 */         s = "getTypeName";
/*     */         break;
/*     */       case 4:
/*  60 */         arity = 0;
/*  61 */         s = "getFunction";
/*     */         break;
/*     */       case 5:
/*  64 */         arity = 0;
/*  65 */         s = "getFunctionName";
/*     */         break;
/*     */       case 6:
/*  68 */         arity = 0;
/*  69 */         s = "getMethodName";
/*     */         break;
/*     */       case 7:
/*  72 */         arity = 0;
/*  73 */         s = "getFileName";
/*     */         break;
/*     */       case 8:
/*  76 */         arity = 0;
/*  77 */         s = "getLineNumber";
/*     */         break;
/*     */       case 9:
/*  80 */         arity = 0;
/*  81 */         s = "getColumnNumber";
/*     */         break;
/*     */       case 10:
/*  84 */         arity = 0;
/*  85 */         s = "getEvalOrigin";
/*     */         break;
/*     */       case 11:
/*  88 */         arity = 0;
/*  89 */         s = "isToplevel";
/*     */         break;
/*     */       case 12:
/*  92 */         arity = 0;
/*  93 */         s = "isEval";
/*     */         break;
/*     */       case 13:
/*  96 */         arity = 0;
/*  97 */         s = "isNative";
/*     */         break;
/*     */       case 14:
/* 100 */         arity = 0;
/* 101 */         s = "isConstructor";
/*     */         break;
/*     */       case 15:
/* 104 */         arity = 0;
/* 105 */         s = "toString";
/*     */         break;
/*     */       default:
/* 108 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 110 */     initPrototypeMethod("CallSite", id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 116 */     if (!f.hasTag("CallSite")) {
/* 117 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 119 */     int id = f.methodId();
/* 120 */     switch (id) {
/*     */       case 1:
/* 122 */         return make(scope, f);
/*     */       case 5:
/* 124 */         return getFunctionName(thisObj);
/*     */       case 7:
/* 126 */         return getFileName(thisObj);
/*     */       case 8:
/* 128 */         return getLineNumber(thisObj);
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 9:
/* 133 */         return Undefined.instance;
/*     */       case 6:
/* 135 */         return null;
/*     */       case 10:
/*     */       case 11:
/*     */       case 12:
/*     */       case 13:
/*     */       case 14:
/* 141 */         return Boolean.FALSE;
/*     */       case 15:
/* 143 */         return js_toString(thisObj);
/*     */     } 
/* 145 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 151 */     if (this.element == null) {
/* 152 */       return "";
/*     */     }
/* 154 */     return this.element.toString();
/*     */   }
/*     */   
/*     */   private static Object js_toString(Scriptable obj) {
/* 158 */     while (obj != null && !(obj instanceof NativeCallSite)) {
/* 159 */       obj = obj.getPrototype();
/*     */     }
/* 161 */     if (obj == null) {
/* 162 */       return NOT_FOUND;
/*     */     }
/* 164 */     NativeCallSite cs = (NativeCallSite)obj;
/* 165 */     StringBuilder sb = new StringBuilder();
/* 166 */     cs.element.renderJavaStyle(sb);
/* 167 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static Object getFunctionName(Scriptable obj) {
/* 171 */     while (obj != null && !(obj instanceof NativeCallSite)) {
/* 172 */       obj = obj.getPrototype();
/*     */     }
/* 174 */     if (obj == null) {
/* 175 */       return NOT_FOUND;
/*     */     }
/* 177 */     NativeCallSite cs = (NativeCallSite)obj;
/* 178 */     return (cs.element == null) ? null : cs.element.functionName;
/*     */   }
/*     */   
/*     */   private static Object getFileName(Scriptable obj) {
/* 182 */     while (obj != null && !(obj instanceof NativeCallSite)) {
/* 183 */       obj = obj.getPrototype();
/*     */     }
/* 185 */     if (obj == null) {
/* 186 */       return NOT_FOUND;
/*     */     }
/* 188 */     NativeCallSite cs = (NativeCallSite)obj;
/* 189 */     return (cs.element == null) ? null : cs.element.fileName;
/*     */   }
/*     */   
/*     */   private static Object getLineNumber(Scriptable obj) {
/* 193 */     while (obj != null && !(obj instanceof NativeCallSite)) {
/* 194 */       obj = obj.getPrototype();
/*     */     }
/* 196 */     if (obj == null) {
/* 197 */       return NOT_FOUND;
/*     */     }
/* 199 */     NativeCallSite cs = (NativeCallSite)obj;
/* 200 */     if (cs.element == null || cs.element.lineNumber < 0) {
/* 201 */       return Undefined.instance;
/*     */     }
/* 203 */     return Integer.valueOf(cs.element.lineNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 209 */     switch (s)
/*     */     { case "constructor":
/* 211 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 259 */         return id;case "getThis": id = 2; return id;case "getTypeName": id = 3; return id;case "getFunction": id = 4; return id;case "getFunctionName": id = 5; return id;case "getMethodName": id = 6; return id;case "getFileName": id = 7; return id;case "getLineNumber": id = 8; return id;case "getColumnNumber": id = 9; return id;case "getEvalOrigin": id = 10; return id;case "isToplevel": id = 11; return id;case "isEval": id = 12; return id;case "isNative": id = 13; return id;case "isConstructor": id = 14; return id;case "toString": id = 15; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeCallSite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */