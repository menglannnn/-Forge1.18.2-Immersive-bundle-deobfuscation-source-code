/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IteratorLikeIterable
/*     */   implements Iterable<Object>, Closeable
/*     */ {
/*     */   private final Context cx;
/*     */   private final Scriptable scope;
/*     */   private final Callable next;
/*     */   private final Callable returnFunc;
/*     */   private final Scriptable iterator;
/*     */   private boolean closed;
/*     */   
/*     */   public IteratorLikeIterable(Context cx, Scriptable scope, Object target) {
/*  31 */     this.cx = cx;
/*  32 */     this.scope = scope;
/*     */     
/*  34 */     this.next = ScriptRuntime.getPropFunctionAndThis(target, "next", cx, scope);
/*  35 */     this.iterator = ScriptRuntime.lastStoredScriptable(cx);
/*     */     
/*  37 */     Object retObj = ScriptRuntime.getObjectPropNoWarn(target, "return", cx, scope);
/*     */     
/*  39 */     if (retObj != null && !Undefined.isUndefined(retObj)) {
/*  40 */       if (!(retObj instanceof Callable)) {
/*  41 */         throw ScriptRuntime.notFunctionError(target, retObj, "return");
/*     */       }
/*  43 */       this.returnFunc = (Callable)retObj;
/*     */     } else {
/*  45 */       this.returnFunc = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  51 */     if (!this.closed) {
/*  52 */       this.closed = true;
/*  53 */       if (this.returnFunc != null) {
/*  54 */         this.returnFunc.call(this.cx, this.scope, this.iterator, ScriptRuntime.emptyArgs);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Itr iterator() {
/*  61 */     return new Itr();
/*     */   }
/*     */   
/*     */   public final class Itr
/*     */     implements Iterator<Object> {
/*     */     private Object nextVal;
/*     */     private boolean isDone;
/*     */     
/*     */     public boolean hasNext() {
/*  70 */       if (this.isDone) {
/*  71 */         return false;
/*     */       }
/*  73 */       Object val = IteratorLikeIterable.this.next.call(IteratorLikeIterable.this.cx, IteratorLikeIterable.this.scope, IteratorLikeIterable.this.iterator, ScriptRuntime.emptyArgs);
/*     */ 
/*     */ 
/*     */       
/*  77 */       Object doneval = ScriptableObject.getProperty(
/*  78 */           ScriptableObject.ensureScriptable(val), "done");
/*  79 */       if (doneval == Scriptable.NOT_FOUND) {
/*  80 */         doneval = Undefined.instance;
/*     */       }
/*     */       
/*  83 */       if (ScriptRuntime.toBoolean(doneval)) {
/*  84 */         this.isDone = true;
/*  85 */         return false;
/*     */       } 
/*  87 */       this.nextVal = ScriptRuntime.getObjectPropNoWarn(val, "value", IteratorLikeIterable.this.cx, IteratorLikeIterable.this.scope);
/*  88 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object next() {
/*  93 */       if (this.isDone) {
/*  94 */         throw new NoSuchElementException();
/*     */       }
/*  96 */       return this.nextVal;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDone() {
/* 101 */       return this.isDone;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setDone(boolean done) {
/* 106 */       this.isDone = done;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\IteratorLikeIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */