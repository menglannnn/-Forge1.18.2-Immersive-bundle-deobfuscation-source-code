/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeBoolean
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = -3716996899943880933L;
/*  17 */   private static final Object BOOLEAN_TAG = "Boolean"; private static final int Id_constructor = 1; private static final int Id_toString = 2; private static final int Id_toSource = 3;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  20 */     NativeBoolean obj = new NativeBoolean(false);
/*  21 */     obj.exportAsJSClass(4, scope, sealed);
/*     */   }
/*     */   private static final int Id_valueOf = 4; private static final int MAX_PROTOTYPE_ID = 4; private boolean booleanValue;
/*     */   NativeBoolean(boolean b) {
/*  25 */     this.booleanValue = b;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  30 */     return "Boolean";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class<?> typeHint) {
/*  37 */     if (typeHint == ScriptRuntime.BooleanClass) return ScriptRuntime.wrapBoolean(this.booleanValue); 
/*  38 */     return super.getDefaultValue(typeHint);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*  45 */     switch (id) {
/*     */       case 1:
/*  47 */         arity = 1;
/*  48 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/*  51 */         arity = 0;
/*  52 */         s = "toString";
/*     */         break;
/*     */       case 3:
/*  55 */         arity = 0;
/*  56 */         s = "toSource";
/*     */         break;
/*     */       case 4:
/*  59 */         arity = 0;
/*  60 */         s = "valueOf";
/*     */         break;
/*     */       default:
/*  63 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/*  65 */     initPrototypeMethod(BOOLEAN_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  71 */     if (!f.hasTag(BOOLEAN_TAG)) {
/*  72 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  74 */     int id = f.methodId();
/*     */     
/*  76 */     if (id == 1) {
/*     */       boolean b;
/*  78 */       if (args.length == 0) {
/*  79 */         b = false;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  90 */         b = (args[0] instanceof ScriptableObject && ((ScriptableObject)args[0]).avoidObjectDetection()) ? false : ScriptRuntime.toBoolean(args[0]);
/*     */       } 
/*  92 */       if (thisObj == null)
/*     */       {
/*  94 */         return new NativeBoolean(b);
/*     */       }
/*     */       
/*  97 */       return ScriptRuntime.wrapBoolean(b);
/*     */     } 
/*     */ 
/*     */     
/* 101 */     boolean value = ((NativeBoolean)ensureType(thisObj, (Class)NativeBoolean.class, f)).booleanValue;
/*     */     
/* 103 */     switch (id) {
/*     */       case 2:
/* 105 */         return value ? "true" : "false";
/*     */       
/*     */       case 3:
/* 108 */         return value ? "(new Boolean(true))" : "(new Boolean(false))";
/*     */       
/*     */       case 4:
/* 111 */         return ScriptRuntime.wrapBoolean(value);
/*     */     } 
/* 113 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 119 */     switch (s)
/*     */     { case "constructor":
/* 121 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 136 */         return id;case "toString": id = 2; return id;case "toSource": id = 3; return id;case "valueOf": id = 4; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeBoolean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */