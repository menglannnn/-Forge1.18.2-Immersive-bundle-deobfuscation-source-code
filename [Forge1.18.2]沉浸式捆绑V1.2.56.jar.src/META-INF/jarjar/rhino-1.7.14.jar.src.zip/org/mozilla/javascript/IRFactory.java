/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.mozilla.javascript.ast.ArrayComprehension;
/*      */ import org.mozilla.javascript.ast.ArrayComprehensionLoop;
/*      */ import org.mozilla.javascript.ast.ArrayLiteral;
/*      */ import org.mozilla.javascript.ast.Assignment;
/*      */ import org.mozilla.javascript.ast.AstNode;
/*      */ import org.mozilla.javascript.ast.AstRoot;
/*      */ import org.mozilla.javascript.ast.BigIntLiteral;
/*      */ import org.mozilla.javascript.ast.Block;
/*      */ import org.mozilla.javascript.ast.BreakStatement;
/*      */ import org.mozilla.javascript.ast.CatchClause;
/*      */ import org.mozilla.javascript.ast.ConditionalExpression;
/*      */ import org.mozilla.javascript.ast.ContinueStatement;
/*      */ import org.mozilla.javascript.ast.DestructuringForm;
/*      */ import org.mozilla.javascript.ast.DoLoop;
/*      */ import org.mozilla.javascript.ast.ElementGet;
/*      */ import org.mozilla.javascript.ast.EmptyExpression;
/*      */ import org.mozilla.javascript.ast.ExpressionStatement;
/*      */ import org.mozilla.javascript.ast.ForInLoop;
/*      */ import org.mozilla.javascript.ast.ForLoop;
/*      */ import org.mozilla.javascript.ast.FunctionCall;
/*      */ import org.mozilla.javascript.ast.FunctionNode;
/*      */ import org.mozilla.javascript.ast.GeneratorExpression;
/*      */ import org.mozilla.javascript.ast.GeneratorExpressionLoop;
/*      */ import org.mozilla.javascript.ast.IfStatement;
/*      */ import org.mozilla.javascript.ast.InfixExpression;
/*      */ import org.mozilla.javascript.ast.Jump;
/*      */ import org.mozilla.javascript.ast.KeywordLiteral;
/*      */ import org.mozilla.javascript.ast.Label;
/*      */ import org.mozilla.javascript.ast.LabeledStatement;
/*      */ import org.mozilla.javascript.ast.LetNode;
/*      */ import org.mozilla.javascript.ast.Name;
/*      */ import org.mozilla.javascript.ast.NewExpression;
/*      */ import org.mozilla.javascript.ast.NumberLiteral;
/*      */ import org.mozilla.javascript.ast.ObjectLiteral;
/*      */ import org.mozilla.javascript.ast.ObjectProperty;
/*      */ import org.mozilla.javascript.ast.ParenthesizedExpression;
/*      */ import org.mozilla.javascript.ast.PropertyGet;
/*      */ import org.mozilla.javascript.ast.RegExpLiteral;
/*      */ import org.mozilla.javascript.ast.ReturnStatement;
/*      */ import org.mozilla.javascript.ast.Scope;
/*      */ import org.mozilla.javascript.ast.ScriptNode;
/*      */ import org.mozilla.javascript.ast.StringLiteral;
/*      */ import org.mozilla.javascript.ast.SwitchCase;
/*      */ import org.mozilla.javascript.ast.SwitchStatement;
/*      */ import org.mozilla.javascript.ast.Symbol;
/*      */ import org.mozilla.javascript.ast.TaggedTemplateLiteral;
/*      */ import org.mozilla.javascript.ast.TemplateCharacters;
/*      */ import org.mozilla.javascript.ast.TemplateLiteral;
/*      */ import org.mozilla.javascript.ast.ThrowStatement;
/*      */ import org.mozilla.javascript.ast.TryStatement;
/*      */ import org.mozilla.javascript.ast.UnaryExpression;
/*      */ import org.mozilla.javascript.ast.UpdateExpression;
/*      */ import org.mozilla.javascript.ast.VariableDeclaration;
/*      */ import org.mozilla.javascript.ast.VariableInitializer;
/*      */ import org.mozilla.javascript.ast.WhileLoop;
/*      */ import org.mozilla.javascript.ast.WithStatement;
/*      */ import org.mozilla.javascript.ast.XmlElemRef;
/*      */ import org.mozilla.javascript.ast.XmlExpression;
/*      */ import org.mozilla.javascript.ast.XmlFragment;
/*      */ import org.mozilla.javascript.ast.XmlLiteral;
/*      */ import org.mozilla.javascript.ast.XmlMemberGet;
/*      */ import org.mozilla.javascript.ast.XmlPropRef;
/*      */ import org.mozilla.javascript.ast.XmlRef;
/*      */ import org.mozilla.javascript.ast.XmlString;
/*      */ import org.mozilla.javascript.ast.Yield;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class IRFactory
/*      */   extends Parser
/*      */ {
/*      */   private static final int LOOP_DO_WHILE = 0;
/*      */   private static final int LOOP_WHILE = 1;
/*      */   private static final int LOOP_FOR = 2;
/*      */   private static final int ALWAYS_TRUE_BOOLEAN = 1;
/*      */   private static final int ALWAYS_FALSE_BOOLEAN = -1;
/*   94 */   private Decompiler decompiler = new Decompiler();
/*      */ 
/*      */   
/*      */   public IRFactory() {}
/*      */ 
/*      */   
/*      */   public IRFactory(CompilerEnvirons env) {
/*  101 */     this(env, env.getErrorReporter());
/*      */   }
/*      */   
/*      */   public IRFactory(CompilerEnvirons env, ErrorReporter errorReporter) {
/*  105 */     super(env, errorReporter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ScriptNode transformTree(AstRoot root) {
/*  113 */     this.currentScriptOrFn = (ScriptNode)root;
/*  114 */     this.inUseStrictDirective = root.isInStrictMode();
/*  115 */     int sourceStartOffset = this.decompiler.getCurrentOffset();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  121 */     ScriptNode script = (ScriptNode)transform((AstNode)root);
/*      */     
/*  123 */     int sourceEndOffset = this.decompiler.getCurrentOffset();
/*  124 */     script.setEncodedSourceBounds(sourceStartOffset, sourceEndOffset);
/*      */     
/*  126 */     if (this.compilerEnv.isGeneratingSource()) {
/*  127 */       script.setEncodedSource(this.decompiler.getEncodedSource());
/*      */     }
/*      */     
/*  130 */     this.decompiler = null;
/*  131 */     return script;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Node transform(AstNode node) {
/*  139 */     switch (node.getType()) {
/*      */       case 161:
/*  141 */         return transformArrayComp((ArrayComprehension)node);
/*      */       case 66:
/*  143 */         return transformArrayLiteral((ArrayLiteral)node);
/*      */       case 83:
/*  145 */         return transformBigInt((BigIntLiteral)node);
/*      */       case 133:
/*  147 */         return transformBlock(node);
/*      */       case 124:
/*  149 */         return transformBreak((BreakStatement)node);
/*      */       case 38:
/*  151 */         return transformFunctionCall((FunctionCall)node);
/*      */       case 125:
/*  153 */         return transformContinue((ContinueStatement)node);
/*      */       case 122:
/*  155 */         return transformDoLoop((DoLoop)node);
/*      */       case 132:
/*      */       case 165:
/*  158 */         return (Node)node;
/*      */       case 123:
/*  160 */         if (node instanceof ForInLoop) {
/*  161 */           return transformForInLoop((ForInLoop)node);
/*      */         }
/*  163 */         return transformForLoop((ForLoop)node);
/*      */       case 113:
/*  165 */         return transformFunction((FunctionNode)node);
/*      */       case 166:
/*  167 */         return transformGenExpr((GeneratorExpression)node);
/*      */       case 36:
/*  169 */         return transformElementGet((ElementGet)node);
/*      */       case 33:
/*  171 */         return transformPropertyGet((PropertyGet)node);
/*      */       case 106:
/*  173 */         return transformCondExpr((ConditionalExpression)node);
/*      */       case 116:
/*  175 */         return transformIf((IfStatement)node);
/*      */       
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 45:
/*      */       case 164:
/*  182 */         return transformLiteral(node);
/*      */       
/*      */       case 39:
/*  185 */         return transformName((Name)node);
/*      */       case 40:
/*  187 */         return transformNumber((NumberLiteral)node);
/*      */       case 30:
/*  189 */         return transformNewExpr((NewExpression)node);
/*      */       case 67:
/*  191 */         return transformObjectLiteral((ObjectLiteral)node);
/*      */       case 170:
/*  193 */         return transformTemplateLiteral((TemplateLiteral)node);
/*      */       case 173:
/*  195 */         return transformTemplateLiteralCall((TaggedTemplateLiteral)node);
/*      */       case 48:
/*  197 */         return transformRegExp((RegExpLiteral)node);
/*      */       case 4:
/*  199 */         return transformReturn((ReturnStatement)node);
/*      */       case 140:
/*  201 */         return transformScript((ScriptNode)node);
/*      */       case 41:
/*  203 */         return transformString((StringLiteral)node);
/*      */       case 118:
/*  205 */         return transformSwitch((SwitchStatement)node);
/*      */       case 50:
/*  207 */         return transformThrow((ThrowStatement)node);
/*      */       case 84:
/*  209 */         return transformTry((TryStatement)node);
/*      */       case 121:
/*  211 */         return transformWhileLoop((WhileLoop)node);
/*      */       case 127:
/*  213 */         return transformWith((WithStatement)node);
/*      */       case 73:
/*      */       case 169:
/*  216 */         return transformYield((Yield)node);
/*      */     } 
/*  218 */     if (node instanceof ExpressionStatement) {
/*  219 */       return transformExprStmt((ExpressionStatement)node);
/*      */     }
/*  221 */     if (node instanceof Assignment) {
/*  222 */       return transformAssignment((Assignment)node);
/*      */     }
/*  224 */     if (node instanceof UnaryExpression) {
/*  225 */       return transformUnary((UnaryExpression)node);
/*      */     }
/*  227 */     if (node instanceof UpdateExpression) {
/*  228 */       return transformUpdate((UpdateExpression)node);
/*      */     }
/*  230 */     if (node instanceof XmlMemberGet) {
/*  231 */       return transformXmlMemberGet((XmlMemberGet)node);
/*      */     }
/*  233 */     if (node instanceof InfixExpression) {
/*  234 */       return transformInfix((InfixExpression)node);
/*      */     }
/*  236 */     if (node instanceof VariableDeclaration) {
/*  237 */       return transformVariables((VariableDeclaration)node);
/*      */     }
/*  239 */     if (node instanceof ParenthesizedExpression) {
/*  240 */       return transformParenExpr((ParenthesizedExpression)node);
/*      */     }
/*  242 */     if (node instanceof LabeledStatement) {
/*  243 */       return transformLabeledStatement((LabeledStatement)node);
/*      */     }
/*  245 */     if (node instanceof LetNode) {
/*  246 */       return transformLetNode((LetNode)node);
/*      */     }
/*  248 */     if (node instanceof XmlRef) {
/*  249 */       return transformXmlRef((XmlRef)node);
/*      */     }
/*  251 */     if (node instanceof XmlLiteral) {
/*  252 */       return transformXmlLiteral((XmlLiteral)node);
/*      */     }
/*  254 */     throw new IllegalArgumentException("Can't transform: " + node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node transformArrayComp(ArrayComprehension node) {
/*  279 */     int lineno = node.getLineno();
/*  280 */     Scope scopeNode = createScopeNode(161, lineno);
/*  281 */     String arrayName = this.currentScriptOrFn.getNextTempName();
/*  282 */     pushScope(scopeNode);
/*      */     try {
/*  284 */       defineSymbol(157, arrayName, false);
/*  285 */       Node block = new Node(133, lineno);
/*  286 */       Node newArray = createCallOrNew(30, createName("Array"));
/*      */ 
/*      */ 
/*      */       
/*  290 */       Node init = new Node(137, createAssignment(93, createName(arrayName), newArray), lineno);
/*      */       
/*  292 */       block.addChildToBack(init);
/*  293 */       block.addChildToBack(arrayCompTransformHelper(node, arrayName));
/*  294 */       scopeNode.addChildToBack(block);
/*  295 */       scopeNode.addChildToBack(createName(arrayName));
/*  296 */       return (Node)scopeNode;
/*      */     } finally {
/*  298 */       popScope();
/*      */     } 
/*      */   }
/*      */   
/*      */   private Node arrayCompTransformHelper(ArrayComprehension node, String arrayName) {
/*  303 */     this.decompiler.addToken(86);
/*  304 */     int lineno = node.getLineno();
/*  305 */     Node expr = transform(node.getResult());
/*      */     
/*  307 */     List<ArrayComprehensionLoop> loops = node.getLoops();
/*  308 */     int numLoops = loops.size();
/*      */ 
/*      */     
/*  311 */     Node[] iterators = new Node[numLoops];
/*  312 */     Node[] iteratedObjs = new Node[numLoops];
/*      */     
/*  314 */     for (int i = 0; i < numLoops; i++) {
/*  315 */       ArrayComprehensionLoop acl = loops.get(i);
/*  316 */       this.decompiler.addName(" ");
/*  317 */       this.decompiler.addToken(123);
/*  318 */       if (acl.isForEach()) {
/*  319 */         this.decompiler.addName("each ");
/*      */       }
/*  321 */       this.decompiler.addToken(90);
/*      */       
/*  323 */       AstNode iter = acl.getIterator();
/*  324 */       String name = null;
/*  325 */       if (iter.getType() == 39) {
/*  326 */         name = iter.getString();
/*  327 */         this.decompiler.addName(name);
/*      */       } else {
/*      */         
/*  330 */         decompile(iter);
/*  331 */         name = this.currentScriptOrFn.getNextTempName();
/*  332 */         defineSymbol(90, name, false);
/*      */         
/*  334 */         expr = createBinary(92, 
/*      */             
/*  336 */             createAssignment(93, (Node)iter, createName(name)), expr);
/*      */       } 
/*      */       
/*  339 */       Node init = createName(name);
/*      */ 
/*      */       
/*  342 */       defineSymbol(157, name, false);
/*  343 */       iterators[i] = init;
/*      */       
/*  345 */       if (acl.isForOf()) {
/*  346 */         this.decompiler.addName("of ");
/*      */       } else {
/*  348 */         this.decompiler.addToken(52);
/*      */       } 
/*  350 */       iteratedObjs[i] = transform(acl.getIteratedObject());
/*  351 */       this.decompiler.addToken(91);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  356 */     Node call = createCallOrNew(38, 
/*  357 */         createPropertyGet(createName(arrayName), (String)null, "push", 0));
/*      */     
/*  359 */     Node body = new Node(137, call, lineno);
/*      */     
/*  361 */     if (node.getFilter() != null) {
/*  362 */       this.decompiler.addName(" ");
/*  363 */       this.decompiler.addToken(116);
/*  364 */       this.decompiler.addToken(90);
/*  365 */       body = createIf(transform(node.getFilter()), body, (Node)null, lineno);
/*  366 */       this.decompiler.addToken(91);
/*      */     } 
/*      */ 
/*      */     
/*  370 */     int pushed = 0; try {
/*      */       int j;
/*  372 */       for (j = numLoops - 1; j >= 0; j--) {
/*  373 */         ArrayComprehensionLoop acl = loops.get(j);
/*      */         
/*  375 */         Scope loop = createLoopNode((Node)null, acl
/*      */             
/*  377 */             .getLineno());
/*  378 */         pushScope(loop);
/*  379 */         pushed++;
/*      */         
/*  381 */         body = createForIn(157, (Node)loop, iterators[j], iteratedObjs[j], body, acl
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  387 */             .isForEach(), acl
/*  388 */             .isForOf());
/*      */       } 
/*      */     } finally {
/*  391 */       for (int j = 0; j < pushed; j++) {
/*  392 */         popScope();
/*      */       }
/*      */     } 
/*      */     
/*  396 */     this.decompiler.addToken(87);
/*      */ 
/*      */ 
/*      */     
/*  400 */     call.addChildToBack(expr);
/*  401 */     return body;
/*      */   }
/*      */   
/*      */   private Node transformArrayLiteral(ArrayLiteral node) {
/*  405 */     if (node.isDestructuring()) {
/*  406 */       return (Node)node;
/*      */     }
/*  408 */     this.decompiler.addToken(86);
/*  409 */     List<AstNode> elems = node.getElements();
/*  410 */     Node array = new Node(66);
/*  411 */     List<Integer> skipIndexes = null;
/*  412 */     for (int i = 0; i < elems.size(); i++) {
/*  413 */       AstNode elem = elems.get(i);
/*  414 */       if (elem.getType() != 132) {
/*  415 */         array.addChildToBack(transform(elem));
/*      */       } else {
/*  417 */         if (skipIndexes == null) {
/*  418 */           skipIndexes = new ArrayList<>();
/*      */         }
/*  420 */         skipIndexes.add(Integer.valueOf(i));
/*      */       } 
/*  422 */       if (i < elems.size() - 1) this.decompiler.addToken(92); 
/*      */     } 
/*  424 */     this.decompiler.addToken(87);
/*  425 */     array.putIntProp(21, node.getDestructuringLength());
/*  426 */     if (skipIndexes != null) {
/*  427 */       int[] skips = new int[skipIndexes.size()];
/*  428 */       for (int j = 0; j < skipIndexes.size(); ) { skips[j] = ((Integer)skipIndexes.get(j)).intValue(); j++; }
/*  429 */        array.putProp(11, skips);
/*      */     } 
/*  431 */     return array;
/*      */   }
/*      */   
/*      */   private Node transformAssignment(Assignment node) {
/*  435 */     AstNode right = node.getRight();
/*  436 */     AstNode left = removeParens(node.getLeft());
/*  437 */     left = transformAssignmentLeft(node, left, right);
/*      */     
/*  439 */     Node target = null;
/*  440 */     if (isDestructuring((Node)left)) {
/*  441 */       decompile(left);
/*  442 */       AstNode astNode = left;
/*      */     } else {
/*  444 */       target = transform(left);
/*      */     } 
/*      */     
/*  447 */     this.decompiler.addToken(node.getType());
/*  448 */     return createAssignment(node.getType(), target, transform(right));
/*      */   }
/*      */   
/*      */   private AstNode transformAssignmentLeft(Assignment node, AstNode left, AstNode right) {
/*  452 */     if (right.getType() == 42 && node
/*  453 */       .getType() == 93 && left instanceof Name && right instanceof KeywordLiteral) {
/*      */ 
/*      */ 
/*      */       
/*  457 */       String identifier = ((Name)left).getIdentifier();
/*  458 */       for (AstNode p = node.getParent(); p != null; p = p.getParent()) {
/*  459 */         if (p instanceof FunctionNode) {
/*  460 */           Name functionName = ((FunctionNode)p).getFunctionName();
/*  461 */           if (functionName != null && functionName.getIdentifier().equals(identifier)) {
/*  462 */             PropertyGet propertyGet = new PropertyGet();
/*  463 */             KeywordLiteral thisKeyword = new KeywordLiteral();
/*  464 */             thisKeyword.setType(43);
/*  465 */             propertyGet.setLeft((AstNode)thisKeyword);
/*  466 */             propertyGet.setRight(left);
/*  467 */             node.setLeft((AstNode)propertyGet);
/*  468 */             return (AstNode)propertyGet;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  473 */     return left;
/*      */   }
/*      */   
/*      */   private Node transformBigInt(BigIntLiteral node) {
/*  477 */     this.decompiler.addBigInt(node.getBigInt());
/*  478 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformBlock(AstNode node) {
/*  482 */     if (node instanceof Scope) {
/*  483 */       pushScope((Scope)node);
/*      */     }
/*      */     try {
/*  486 */       List<Node> kids = new ArrayList<>();
/*  487 */       for (Node kid : node) {
/*  488 */         kids.add(transform((AstNode)kid));
/*      */       }
/*  490 */       node.removeChildren();
/*  491 */       for (Node kid : kids) {
/*  492 */         node.addChildToBack(kid);
/*      */       }
/*  494 */       return (Node)node;
/*      */     } finally {
/*  496 */       if (node instanceof Scope) {
/*  497 */         popScope();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private Node transformBreak(BreakStatement node) {
/*  503 */     this.decompiler.addToken(124);
/*  504 */     if (node.getBreakLabel() != null) {
/*  505 */       this.decompiler.addName(node.getBreakLabel().getIdentifier());
/*      */     }
/*  507 */     this.decompiler.addEOL(85);
/*  508 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformCondExpr(ConditionalExpression node) {
/*  512 */     Node test = transform(node.getTestExpression());
/*  513 */     this.decompiler.addToken(106);
/*  514 */     Node ifTrue = transform(node.getTrueExpression());
/*  515 */     this.decompiler.addToken(107);
/*  516 */     Node ifFalse = transform(node.getFalseExpression());
/*  517 */     return createCondExpr(test, ifTrue, ifFalse);
/*      */   }
/*      */   
/*      */   private Node transformContinue(ContinueStatement node) {
/*  521 */     this.decompiler.addToken(125);
/*  522 */     if (node.getLabel() != null) {
/*  523 */       this.decompiler.addName(node.getLabel().getIdentifier());
/*      */     }
/*  525 */     this.decompiler.addEOL(85);
/*  526 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformDoLoop(DoLoop loop) {
/*  530 */     loop.setType(136);
/*  531 */     pushScope((Scope)loop);
/*      */     try {
/*  533 */       this.decompiler.addToken(122);
/*  534 */       this.decompiler.addEOL(88);
/*  535 */       Node body = transform(loop.getBody());
/*  536 */       this.decompiler.addToken(89);
/*  537 */       this.decompiler.addToken(121);
/*  538 */       this.decompiler.addToken(90);
/*  539 */       Node cond = transform(loop.getCondition());
/*  540 */       this.decompiler.addToken(91);
/*  541 */       this.decompiler.addEOL(85);
/*  542 */       return createLoop((Jump)loop, 0, body, cond, (Node)null, (Node)null);
/*      */     } finally {
/*  544 */       popScope();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Node transformElementGet(ElementGet node) {
/*  551 */     Node target = transform(node.getTarget());
/*  552 */     this.decompiler.addToken(86);
/*  553 */     Node element = transform(node.getElement());
/*  554 */     this.decompiler.addToken(87);
/*  555 */     return new Node(36, target, element);
/*      */   }
/*      */   
/*      */   private Node transformExprStmt(ExpressionStatement node) {
/*  559 */     Node expr = transform(node.getExpression());
/*  560 */     this.decompiler.addEOL(85);
/*  561 */     return new Node(node.getType(), expr, node.getLineno());
/*      */   }
/*      */   
/*      */   private Node transformForInLoop(ForInLoop loop) {
/*  565 */     this.decompiler.addToken(123);
/*  566 */     if (loop.isForEach()) this.decompiler.addName("each "); 
/*  567 */     this.decompiler.addToken(90);
/*      */     
/*  569 */     loop.setType(136);
/*  570 */     pushScope((Scope)loop);
/*      */     try {
/*  572 */       int declType = -1;
/*  573 */       AstNode iter = loop.getIterator();
/*  574 */       if (iter instanceof VariableDeclaration) {
/*  575 */         declType = ((VariableDeclaration)iter).getType();
/*      */       }
/*  577 */       Node lhs = transform(iter);
/*  578 */       if (loop.isForOf()) {
/*  579 */         this.decompiler.addName("of ");
/*      */       } else {
/*  581 */         this.decompiler.addToken(52);
/*      */       } 
/*  583 */       Node obj = transform(loop.getIteratedObject());
/*  584 */       this.decompiler.addToken(91);
/*  585 */       this.decompiler.addEOL(88);
/*  586 */       Node body = transform(loop.getBody());
/*  587 */       this.decompiler.addEOL(89);
/*  588 */       return createForIn(declType, (Node)loop, lhs, obj, body, loop.isForEach(), loop.isForOf());
/*      */     } finally {
/*  590 */       popScope();
/*      */     } 
/*      */   }
/*      */   
/*      */   private Node transformForLoop(ForLoop loop) {
/*  595 */     this.decompiler.addToken(123);
/*  596 */     this.decompiler.addToken(90);
/*  597 */     loop.setType(136);
/*      */ 
/*      */     
/*  600 */     Scope savedScope = this.currentScope;
/*  601 */     this.currentScope = (Scope)loop;
/*      */     try {
/*  603 */       Node init = transform(loop.getInitializer());
/*  604 */       this.decompiler.addToken(85);
/*  605 */       Node test = transform(loop.getCondition());
/*  606 */       this.decompiler.addToken(85);
/*  607 */       Node incr = transform(loop.getIncrement());
/*  608 */       this.decompiler.addToken(91);
/*  609 */       this.decompiler.addEOL(88);
/*  610 */       Node body = transform(loop.getBody());
/*  611 */       this.decompiler.addEOL(89);
/*  612 */       return createFor((Scope)loop, init, test, incr, body);
/*      */     } finally {
/*  614 */       this.currentScope = savedScope;
/*      */     } 
/*      */   }
/*      */   
/*      */   private Node transformFunction(FunctionNode fn) {
/*  619 */     int functionType = fn.getFunctionType();
/*  620 */     int start = this.decompiler.markFunctionStart(functionType);
/*  621 */     Node mexpr = decompileFunctionHeader(fn);
/*  622 */     int index = this.currentScriptOrFn.addFunction(fn);
/*      */     
/*  624 */     Parser.PerFunctionVariables savedVars = new Parser.PerFunctionVariables(this, fn);
/*      */ 
/*      */     
/*      */     try {
/*  628 */       Node destructuring = (Node)fn.getProp(23);
/*  629 */       fn.removeProp(23);
/*      */       
/*  631 */       int lineno = fn.getBody().getLineno();
/*  632 */       this.nestingOfFunction++;
/*  633 */       Node body = transform(fn.getBody());
/*      */       
/*  635 */       if (!fn.isExpressionClosure()) {
/*  636 */         this.decompiler.addToken(89);
/*      */       }
/*  638 */       fn.setEncodedSourceBounds(start, this.decompiler.markFunctionEnd(start));
/*      */       
/*  640 */       if (functionType != 2 && !fn.isExpressionClosure())
/*      */       {
/*      */         
/*  643 */         this.decompiler.addToken(1);
/*      */       }
/*      */       
/*  646 */       if (destructuring != null) {
/*  647 */         body.addChildToFront(new Node(137, destructuring, lineno));
/*      */       }
/*      */       
/*  650 */       int syntheticType = fn.getFunctionType();
/*  651 */       Node pn = initFunction(fn, index, body, syntheticType);
/*  652 */       if (mexpr != null) {
/*  653 */         pn = createAssignment(93, mexpr, pn);
/*  654 */         if (syntheticType != 2) {
/*  655 */           pn = createExprStatementNoReturn(pn, fn.getLineno());
/*      */         }
/*      */       } 
/*  658 */       return pn;
/*      */     } finally {
/*      */       
/*  661 */       this.nestingOfFunction--;
/*  662 */       savedVars.restore();
/*      */     } 
/*      */   }
/*      */   
/*      */   private Node transformFunctionCall(FunctionCall node) {
/*  667 */     Node call = createCallOrNew(38, transform(node.getTarget()));
/*  668 */     call.setLineno(node.getLineno());
/*  669 */     this.decompiler.addToken(90);
/*  670 */     List<AstNode> args = node.getArguments();
/*  671 */     for (int i = 0; i < args.size(); i++) {
/*  672 */       AstNode arg = args.get(i);
/*  673 */       call.addChildToBack(transform(arg));
/*  674 */       if (i < args.size() - 1) {
/*  675 */         this.decompiler.addToken(92);
/*      */       }
/*      */     } 
/*  678 */     this.decompiler.addToken(91);
/*  679 */     return call;
/*      */   }
/*      */ 
/*      */   
/*      */   private Node transformGenExpr(GeneratorExpression node) {
/*      */     Node pn;
/*  685 */     FunctionNode fn = new FunctionNode();
/*  686 */     fn.setSourceName(this.currentScriptOrFn.getNextTempName());
/*  687 */     fn.setIsGenerator();
/*  688 */     fn.setFunctionType(2);
/*  689 */     fn.setRequiresActivation();
/*      */     
/*  691 */     int functionType = fn.getFunctionType();
/*  692 */     int start = this.decompiler.markFunctionStart(functionType);
/*  693 */     Node mexpr = decompileFunctionHeader(fn);
/*  694 */     int index = this.currentScriptOrFn.addFunction(fn);
/*      */     
/*  696 */     Parser.PerFunctionVariables savedVars = new Parser.PerFunctionVariables(this, fn);
/*      */ 
/*      */     
/*      */     try {
/*  700 */       Node destructuring = (Node)fn.getProp(23);
/*  701 */       fn.removeProp(23);
/*      */       
/*  703 */       int lineno = node.lineno;
/*  704 */       this.nestingOfFunction++;
/*  705 */       Node body = genExprTransformHelper(node);
/*      */       
/*  707 */       if (!fn.isExpressionClosure()) {
/*  708 */         this.decompiler.addToken(89);
/*      */       }
/*  710 */       fn.setEncodedSourceBounds(start, this.decompiler.markFunctionEnd(start));
/*      */       
/*  712 */       if (functionType != 2 && !fn.isExpressionClosure())
/*      */       {
/*      */         
/*  715 */         this.decompiler.addToken(1);
/*      */       }
/*      */       
/*  718 */       if (destructuring != null) {
/*  719 */         body.addChildToFront(new Node(137, destructuring, lineno));
/*      */       }
/*      */       
/*  722 */       int syntheticType = fn.getFunctionType();
/*  723 */       pn = initFunction(fn, index, body, syntheticType);
/*  724 */       if (mexpr != null) {
/*  725 */         pn = createAssignment(93, mexpr, pn);
/*  726 */         if (syntheticType != 2) {
/*  727 */           pn = createExprStatementNoReturn(pn, fn.getLineno());
/*      */         }
/*      */       } 
/*      */     } finally {
/*  731 */       this.nestingOfFunction--;
/*  732 */       savedVars.restore();
/*      */     } 
/*      */     
/*  735 */     Node call = createCallOrNew(38, pn);
/*  736 */     call.setLineno(node.getLineno());
/*  737 */     this.decompiler.addToken(90);
/*  738 */     this.decompiler.addToken(91);
/*  739 */     return call;
/*      */   }
/*      */   
/*      */   private Node genExprTransformHelper(GeneratorExpression node) {
/*  743 */     this.decompiler.addToken(90);
/*  744 */     int lineno = node.getLineno();
/*  745 */     Node expr = transform(node.getResult());
/*      */     
/*  747 */     List<GeneratorExpressionLoop> loops = node.getLoops();
/*  748 */     int numLoops = loops.size();
/*      */ 
/*      */     
/*  751 */     Node[] iterators = new Node[numLoops];
/*  752 */     Node[] iteratedObjs = new Node[numLoops];
/*      */     
/*  754 */     for (int i = 0; i < numLoops; i++) {
/*  755 */       GeneratorExpressionLoop acl = loops.get(i);
/*  756 */       this.decompiler.addName(" ");
/*  757 */       this.decompiler.addToken(123);
/*  758 */       this.decompiler.addToken(90);
/*      */       
/*  760 */       AstNode iter = acl.getIterator();
/*  761 */       String name = null;
/*  762 */       if (iter.getType() == 39) {
/*  763 */         name = iter.getString();
/*  764 */         this.decompiler.addName(name);
/*      */       } else {
/*      */         
/*  767 */         decompile(iter);
/*  768 */         name = this.currentScriptOrFn.getNextTempName();
/*  769 */         defineSymbol(90, name, false);
/*      */         
/*  771 */         expr = createBinary(92, 
/*      */             
/*  773 */             createAssignment(93, (Node)iter, createName(name)), expr);
/*      */       } 
/*      */       
/*  776 */       Node init = createName(name);
/*      */ 
/*      */       
/*  779 */       defineSymbol(157, name, false);
/*  780 */       iterators[i] = init;
/*      */       
/*  782 */       if (acl.isForOf()) {
/*  783 */         this.decompiler.addName("of ");
/*      */       } else {
/*  785 */         this.decompiler.addToken(52);
/*      */       } 
/*  787 */       iteratedObjs[i] = transform(acl.getIteratedObject());
/*  788 */       this.decompiler.addToken(91);
/*      */     } 
/*      */ 
/*      */     
/*  792 */     Node yield = new Node(73, expr, node.getLineno());
/*      */     
/*  794 */     Node body = new Node(137, yield, lineno);
/*      */     
/*  796 */     if (node.getFilter() != null) {
/*  797 */       this.decompiler.addName(" ");
/*  798 */       this.decompiler.addToken(116);
/*  799 */       this.decompiler.addToken(90);
/*  800 */       body = createIf(transform(node.getFilter()), body, (Node)null, lineno);
/*  801 */       this.decompiler.addToken(91);
/*      */     } 
/*      */ 
/*      */     
/*  805 */     int pushed = 0; try {
/*      */       int j;
/*  807 */       for (j = numLoops - 1; j >= 0; j--) {
/*  808 */         GeneratorExpressionLoop acl = loops.get(j);
/*      */         
/*  810 */         Scope loop = createLoopNode((Node)null, acl
/*      */             
/*  812 */             .getLineno());
/*  813 */         pushScope(loop);
/*  814 */         pushed++;
/*      */         
/*  816 */         body = createForIn(157, (Node)loop, iterators[j], iteratedObjs[j], body, acl
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  822 */             .isForEach(), acl
/*  823 */             .isForOf());
/*      */       } 
/*      */     } finally {
/*  826 */       for (int j = 0; j < pushed; j++) {
/*  827 */         popScope();
/*      */       }
/*      */     } 
/*      */     
/*  831 */     this.decompiler.addToken(91);
/*      */     
/*  833 */     return body;
/*      */   }
/*      */   
/*      */   private Node transformIf(IfStatement n) {
/*  837 */     this.decompiler.addToken(116);
/*  838 */     this.decompiler.addToken(90);
/*  839 */     Node cond = transform(n.getCondition());
/*  840 */     this.decompiler.addToken(91);
/*  841 */     this.decompiler.addEOL(88);
/*  842 */     Node ifTrue = transform(n.getThenPart());
/*  843 */     Node ifFalse = null;
/*  844 */     if (n.getElsePart() != null) {
/*  845 */       this.decompiler.addToken(89);
/*  846 */       this.decompiler.addToken(117);
/*  847 */       this.decompiler.addEOL(88);
/*  848 */       ifFalse = transform(n.getElsePart());
/*      */     } 
/*  850 */     this.decompiler.addEOL(89);
/*  851 */     return createIf(cond, ifTrue, ifFalse, n.getLineno());
/*      */   }
/*      */   
/*      */   private Node transformInfix(InfixExpression node) {
/*  855 */     Node left = transform(node.getLeft());
/*  856 */     this.decompiler.addToken(node.getType());
/*  857 */     Node right = transform(node.getRight());
/*  858 */     if (node instanceof org.mozilla.javascript.ast.XmlDotQuery) {
/*  859 */       this.decompiler.addToken(91);
/*      */     }
/*  861 */     return createBinary(node.getType(), left, right);
/*      */   }
/*      */   
/*      */   private Node transformLabeledStatement(LabeledStatement ls) {
/*  865 */     Label label = ls.getFirstLabel();
/*  866 */     List<Label> labels = ls.getLabels();
/*  867 */     this.decompiler.addName(label.getName());
/*  868 */     if (labels.size() > 1)
/*      */     {
/*  870 */       for (Label lb : labels.subList(1, labels.size())) {
/*  871 */         this.decompiler.addEOL(107);
/*  872 */         this.decompiler.addName(lb.getName());
/*      */       } 
/*      */     }
/*  875 */     if (ls.getStatement().getType() == 133) {
/*      */       
/*  877 */       this.decompiler.addToken(67);
/*  878 */       this.decompiler.addEOL(88);
/*      */     } else {
/*  880 */       this.decompiler.addEOL(107);
/*      */     } 
/*  882 */     Node statement = transform(ls.getStatement());
/*  883 */     if (ls.getStatement().getType() == 133) {
/*  884 */       this.decompiler.addEOL(89);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  889 */     Node breakTarget = Node.newTarget();
/*  890 */     Node block = new Node(133, (Node)label, statement, breakTarget);
/*  891 */     label.target = breakTarget;
/*      */     
/*  893 */     return block;
/*      */   }
/*      */   
/*      */   private Node transformLetNode(LetNode node) {
/*  897 */     pushScope((Scope)node);
/*      */     try {
/*  899 */       this.decompiler.addToken(157);
/*  900 */       this.decompiler.addToken(90);
/*  901 */       Node vars = transformVariableInitializers(node.getVariables());
/*  902 */       this.decompiler.addToken(91);
/*  903 */       node.addChildToBack(vars);
/*  904 */       boolean letExpr = (node.getType() == 162);
/*  905 */       if (node.getBody() != null) {
/*  906 */         if (letExpr) {
/*  907 */           this.decompiler.addName(" ");
/*      */         } else {
/*  909 */           this.decompiler.addEOL(88);
/*      */         } 
/*  911 */         node.addChildToBack(transform(node.getBody()));
/*  912 */         if (!letExpr) {
/*  913 */           this.decompiler.addEOL(89);
/*      */         }
/*      */       } 
/*  916 */       return (Node)node;
/*      */     } finally {
/*  918 */       popScope();
/*      */     } 
/*      */   }
/*      */   
/*      */   private Node transformLiteral(AstNode node) {
/*  923 */     this.decompiler.addToken(node.getType());
/*  924 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformName(Name node) {
/*  928 */     this.decompiler.addName(node.getIdentifier());
/*  929 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformNewExpr(NewExpression node) {
/*  933 */     this.decompiler.addToken(30);
/*  934 */     Node nx = createCallOrNew(30, transform(node.getTarget()));
/*  935 */     nx.setLineno(node.getLineno());
/*  936 */     List<AstNode> args = node.getArguments();
/*  937 */     this.decompiler.addToken(90);
/*  938 */     for (int i = 0; i < args.size(); i++) {
/*  939 */       AstNode arg = args.get(i);
/*  940 */       nx.addChildToBack(transform(arg));
/*  941 */       if (i < args.size() - 1) {
/*  942 */         this.decompiler.addToken(92);
/*      */       }
/*      */     } 
/*  945 */     this.decompiler.addToken(91);
/*  946 */     if (node.getInitializer() != null) {
/*  947 */       nx.addChildToBack(transformObjectLiteral(node.getInitializer()));
/*      */     }
/*  949 */     return nx;
/*      */   }
/*      */   
/*      */   private Node transformNumber(NumberLiteral node) {
/*  953 */     this.decompiler.addNumber(node.getNumber());
/*  954 */     return (Node)node;
/*      */   }
/*      */   private Node transformObjectLiteral(ObjectLiteral node) {
/*      */     Object[] properties;
/*  958 */     if (node.isDestructuring()) {
/*  959 */       return (Node)node;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  964 */     this.decompiler.addToken(88);
/*  965 */     List<ObjectProperty> elems = node.getElements();
/*  966 */     Node object = new Node(67);
/*      */     
/*  968 */     if (elems.isEmpty()) {
/*  969 */       properties = ScriptRuntime.emptyArgs;
/*      */     } else {
/*  971 */       int size = elems.size(), i = 0;
/*  972 */       properties = new Object[size];
/*  973 */       for (ObjectProperty prop : elems) {
/*  974 */         if (prop.isGetterMethod()) {
/*  975 */           this.decompiler.addToken(155);
/*  976 */         } else if (prop.isSetterMethod()) {
/*  977 */           this.decompiler.addToken(156);
/*  978 */         } else if (prop.isNormalMethod()) {
/*  979 */           this.decompiler.addToken(167);
/*      */         } 
/*      */         
/*  982 */         properties[i++] = getPropKey((Node)prop.getLeft());
/*      */ 
/*      */ 
/*      */         
/*  986 */         if (!prop.isMethod()) {
/*  987 */           this.decompiler.addToken(67);
/*      */         }
/*      */         
/*  990 */         Node right = transform(prop.getRight());
/*  991 */         if (prop.isGetterMethod()) {
/*  992 */           right = createUnary(155, right);
/*  993 */         } else if (prop.isSetterMethod()) {
/*  994 */           right = createUnary(156, right);
/*  995 */         } else if (prop.isNormalMethod()) {
/*  996 */           right = createUnary(167, right);
/*      */         } 
/*  998 */         object.addChildToBack(right);
/*      */         
/* 1000 */         if (i < size) {
/* 1001 */           this.decompiler.addToken(92);
/*      */         }
/*      */       } 
/*      */     } 
/* 1005 */     this.decompiler.addToken(89);
/* 1006 */     object.putProp(12, properties);
/* 1007 */     return object;
/*      */   }
/*      */   
/*      */   private Object getPropKey(Node id) {
/*      */     Object key;
/* 1012 */     if (id instanceof Name) {
/* 1013 */       String s = ((Name)id).getIdentifier();
/* 1014 */       this.decompiler.addName(s);
/* 1015 */       key = ScriptRuntime.getIndexObject(s);
/* 1016 */     } else if (id instanceof StringLiteral) {
/* 1017 */       String s = ((StringLiteral)id).getValue();
/* 1018 */       this.decompiler.addString(s);
/* 1019 */       key = ScriptRuntime.getIndexObject(s);
/* 1020 */     } else if (id instanceof NumberLiteral) {
/* 1021 */       double n = ((NumberLiteral)id).getNumber();
/* 1022 */       this.decompiler.addNumber(n);
/* 1023 */       key = ScriptRuntime.getIndexObject(n);
/*      */     } else {
/* 1025 */       throw Kit.codeBug();
/*      */     } 
/* 1027 */     return key;
/*      */   }
/*      */   
/*      */   private Node transformParenExpr(ParenthesizedExpression node) {
/* 1031 */     AstNode expr = node.getExpression();
/* 1032 */     this.decompiler.addToken(90);
/* 1033 */     int count = 1;
/* 1034 */     while (expr instanceof ParenthesizedExpression) {
/* 1035 */       this.decompiler.addToken(90);
/* 1036 */       count++;
/* 1037 */       expr = ((ParenthesizedExpression)expr).getExpression();
/*      */     } 
/* 1039 */     Node result = transform(expr);
/* 1040 */     for (int i = 0; i < count; i++) {
/* 1041 */       this.decompiler.addToken(91);
/*      */     }
/* 1043 */     result.putProp(19, Boolean.TRUE);
/* 1044 */     return result;
/*      */   }
/*      */   
/*      */   private Node transformPropertyGet(PropertyGet node) {
/* 1048 */     Node target = transform(node.getTarget());
/* 1049 */     String name = node.getProperty().getIdentifier();
/* 1050 */     this.decompiler.addToken(112);
/* 1051 */     this.decompiler.addName(name);
/* 1052 */     return createPropertyGet(target, (String)null, name, 0);
/*      */   }
/*      */   
/*      */   private Node transformTemplateLiteral(TemplateLiteral node) {
/* 1056 */     this.decompiler.addToken(170);
/* 1057 */     List<AstNode> elems = node.getElements();
/*      */     
/* 1059 */     Node pn = Node.newString("");
/* 1060 */     for (int i = 0; i < elems.size(); i++) {
/* 1061 */       AstNode elem = elems.get(i);
/* 1062 */       if (elem.getType() != 171) {
/* 1063 */         this.decompiler.addToken(172);
/* 1064 */         pn = createBinary(21, pn, transform(elem));
/* 1065 */         this.decompiler.addToken(89);
/*      */       } else {
/* 1067 */         TemplateCharacters chars = (TemplateCharacters)elem;
/* 1068 */         this.decompiler.addTemplateLiteral(chars.getRawValue());
/*      */         
/* 1070 */         String value = chars.getValue();
/* 1071 */         if (value.length() > 0) {
/* 1072 */           pn = createBinary(21, pn, Node.newString(value));
/*      */         }
/*      */       } 
/*      */     } 
/* 1076 */     this.decompiler.addToken(170);
/* 1077 */     return pn;
/*      */   }
/*      */   
/*      */   private Node transformTemplateLiteralCall(TaggedTemplateLiteral node) {
/* 1081 */     Node call = createCallOrNew(38, transform(node.getTarget()));
/* 1082 */     call.setLineno(node.getLineno());
/* 1083 */     this.decompiler.addToken(170);
/* 1084 */     TemplateLiteral templateLiteral = (TemplateLiteral)node.getTemplateLiteral();
/* 1085 */     List<AstNode> elems = templateLiteral.getElements();
/* 1086 */     call.addChildToBack((Node)templateLiteral);
/* 1087 */     for (int i = 0; i < elems.size(); i++) {
/* 1088 */       AstNode elem = elems.get(i);
/* 1089 */       if (elem.getType() != 171) {
/* 1090 */         this.decompiler.addToken(172);
/* 1091 */         call.addChildToBack(transform(elem));
/* 1092 */         this.decompiler.addToken(89);
/*      */       } else {
/* 1094 */         TemplateCharacters chars = (TemplateCharacters)elem;
/* 1095 */         this.decompiler.addTemplateLiteral(chars.getRawValue());
/*      */       } 
/*      */     } 
/* 1098 */     this.currentScriptOrFn.addTemplateLiteral(templateLiteral);
/* 1099 */     this.decompiler.addToken(170);
/* 1100 */     return call;
/*      */   }
/*      */   
/*      */   private Node transformRegExp(RegExpLiteral node) {
/* 1104 */     this.decompiler.addRegexp(node.getValue(), node.getFlags());
/* 1105 */     this.currentScriptOrFn.addRegExp(node);
/* 1106 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformReturn(ReturnStatement node) {
/* 1110 */     boolean expClosure = Boolean.TRUE.equals(node.getProp(25));
/* 1111 */     boolean isArrow = Boolean.TRUE.equals(node.getProp(27));
/* 1112 */     if (expClosure) {
/* 1113 */       if (!isArrow) {
/* 1114 */         this.decompiler.addName(" ");
/*      */       }
/*      */     } else {
/* 1117 */       this.decompiler.addToken(4);
/*      */     } 
/* 1119 */     AstNode rv = node.getReturnValue();
/* 1120 */     Node value = (rv == null) ? null : transform(rv);
/* 1121 */     if (!expClosure) this.decompiler.addEOL(85); 
/* 1122 */     return (rv == null) ? new Node(4, node
/* 1123 */         .getLineno()) : new Node(4, value, node
/* 1124 */         .getLineno());
/*      */   }
/*      */   
/*      */   private Node transformScript(ScriptNode node) {
/* 1128 */     this.decompiler.addToken(140);
/* 1129 */     if (this.currentScope != null) Kit.codeBug(); 
/* 1130 */     this.currentScope = (Scope)node;
/* 1131 */     Node body = new Node(133);
/* 1132 */     for (Node kid : node) {
/* 1133 */       body.addChildToBack(transform((AstNode)kid));
/*      */     }
/* 1135 */     node.removeChildren();
/* 1136 */     Node children = body.getFirstChild();
/* 1137 */     if (children != null) {
/* 1138 */       node.addChildrenToBack(children);
/*      */     }
/* 1140 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformString(StringLiteral node) {
/* 1144 */     this.decompiler.addString(node.getValue());
/* 1145 */     return Node.newString(node.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node transformSwitch(SwitchStatement node) {
/* 1188 */     this.decompiler.addToken(118);
/* 1189 */     this.decompiler.addToken(90);
/* 1190 */     Node switchExpr = transform(node.getExpression());
/* 1191 */     this.decompiler.addToken(91);
/* 1192 */     node.addChildToBack(switchExpr);
/*      */     
/* 1194 */     Node block = new Node(133, (Node)node, node.getLineno());
/* 1195 */     this.decompiler.addEOL(88);
/*      */     
/* 1197 */     for (SwitchCase sc : node.getCases()) {
/* 1198 */       AstNode expr = sc.getExpression();
/* 1199 */       Node caseExpr = null;
/*      */       
/* 1201 */       if (expr != null) {
/* 1202 */         this.decompiler.addToken(119);
/* 1203 */         caseExpr = transform(expr);
/*      */       } else {
/* 1205 */         this.decompiler.addToken(120);
/*      */       } 
/* 1207 */       this.decompiler.addEOL(107);
/*      */       
/* 1209 */       List<AstNode> stmts = sc.getStatements();
/* 1210 */       Block block1 = new Block();
/* 1211 */       if (stmts != null) {
/* 1212 */         for (AstNode kid : stmts) {
/* 1213 */           block1.addChildToBack(transform(kid));
/*      */         }
/*      */       }
/* 1216 */       addSwitchCase(block, caseExpr, (Node)block1);
/*      */     } 
/* 1218 */     this.decompiler.addEOL(89);
/* 1219 */     closeSwitch(block);
/* 1220 */     return block;
/*      */   }
/*      */   
/*      */   private Node transformThrow(ThrowStatement node) {
/* 1224 */     this.decompiler.addToken(50);
/* 1225 */     Node value = transform(node.getExpression());
/* 1226 */     this.decompiler.addEOL(85);
/* 1227 */     return new Node(50, value, node.getLineno());
/*      */   }
/*      */   
/*      */   private Node transformTry(TryStatement node) {
/* 1231 */     this.decompiler.addToken(84);
/* 1232 */     this.decompiler.addEOL(88);
/* 1233 */     Node tryBlock = transform(node.getTryBlock());
/* 1234 */     this.decompiler.addEOL(89);
/*      */     
/* 1236 */     Block block = new Block();
/* 1237 */     for (CatchClause cc : node.getCatchClauses()) {
/* 1238 */       EmptyExpression emptyExpression; this.decompiler.addToken(128);
/* 1239 */       this.decompiler.addToken(90);
/*      */       
/* 1241 */       String varName = cc.getVarName().getIdentifier();
/* 1242 */       this.decompiler.addName(varName);
/*      */       
/* 1244 */       Node catchCond = null;
/* 1245 */       AstNode ccc = cc.getCatchCondition();
/* 1246 */       if (ccc != null) {
/* 1247 */         this.decompiler.addName(" ");
/* 1248 */         this.decompiler.addToken(116);
/* 1249 */         catchCond = transform(ccc);
/*      */       } else {
/* 1251 */         emptyExpression = new EmptyExpression();
/*      */       } 
/* 1253 */       this.decompiler.addToken(91);
/* 1254 */       this.decompiler.addEOL(88);
/*      */       
/* 1256 */       Node body = transform((AstNode)cc.getBody());
/* 1257 */       this.decompiler.addEOL(89);
/*      */       
/* 1259 */       block.addChildToBack(createCatch(varName, (Node)emptyExpression, body, cc.getLineno()));
/*      */     } 
/* 1261 */     Node finallyBlock = null;
/* 1262 */     if (node.getFinallyBlock() != null) {
/* 1263 */       this.decompiler.addToken(129);
/* 1264 */       this.decompiler.addEOL(88);
/* 1265 */       finallyBlock = transform(node.getFinallyBlock());
/* 1266 */       this.decompiler.addEOL(89);
/*      */     } 
/* 1268 */     return createTryCatchFinally(tryBlock, (Node)block, finallyBlock, node.getLineno());
/*      */   }
/*      */   
/*      */   private Node transformUnary(UnaryExpression node) {
/* 1272 */     int type = node.getType();
/* 1273 */     if (type == 76) {
/* 1274 */       return transformDefaultXmlNamepace(node);
/*      */     }
/* 1276 */     this.decompiler.addToken(type);
/*      */     
/* 1278 */     Node child = transform(node.getOperand());
/* 1279 */     return createUnary(type, child);
/*      */   }
/*      */   
/*      */   private Node transformUpdate(UpdateExpression node) {
/* 1283 */     int type = node.getType();
/* 1284 */     if (node.isPrefix()) {
/* 1285 */       this.decompiler.addToken(type);
/*      */     }
/* 1287 */     Node child = transform(node.getOperand());
/* 1288 */     if (node.isPostfix()) {
/* 1289 */       this.decompiler.addToken(type);
/*      */     }
/* 1291 */     return createIncDec(type, node.isPostfix(), child);
/*      */   }
/*      */   
/*      */   private Node transformVariables(VariableDeclaration node) {
/* 1295 */     this.decompiler.addToken(node.getType());
/* 1296 */     transformVariableInitializers(node);
/*      */ 
/*      */ 
/*      */     
/* 1300 */     AstNode parent = node.getParent();
/* 1301 */     if (!(parent instanceof org.mozilla.javascript.ast.Loop) && !(parent instanceof LetNode)) {
/* 1302 */       this.decompiler.addEOL(85);
/*      */     }
/* 1304 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformVariableInitializers(VariableDeclaration node) {
/* 1308 */     List<VariableInitializer> vars = node.getVariables();
/* 1309 */     int size = vars.size(), i = 0;
/* 1310 */     for (VariableInitializer var : vars) {
/* 1311 */       AstNode target = var.getTarget();
/* 1312 */       AstNode init = var.getInitializer();
/*      */       
/* 1314 */       Node left = null;
/* 1315 */       if (var.isDestructuring()) {
/* 1316 */         decompile(target);
/* 1317 */         AstNode astNode = target;
/*      */       } else {
/* 1319 */         left = transform(target);
/*      */       } 
/*      */       
/* 1322 */       Node right = null;
/* 1323 */       if (init != null) {
/* 1324 */         this.decompiler.addToken(93);
/* 1325 */         right = transform(init);
/*      */       } 
/*      */       
/* 1328 */       if (var.isDestructuring()) {
/* 1329 */         if (right == null) {
/* 1330 */           node.addChildToBack(left);
/*      */         } else {
/* 1332 */           Node d = createDestructuringAssignment(node.getType(), left, right);
/* 1333 */           node.addChildToBack(d);
/*      */         } 
/*      */       } else {
/* 1336 */         if (right != null) {
/* 1337 */           left.addChildToBack(right);
/*      */         }
/* 1339 */         node.addChildToBack(left);
/*      */       } 
/* 1341 */       if (i++ < size - 1) {
/* 1342 */         this.decompiler.addToken(92);
/*      */       }
/*      */     } 
/* 1345 */     return (Node)node;
/*      */   }
/*      */   
/*      */   private Node transformWhileLoop(WhileLoop loop) {
/* 1349 */     this.decompiler.addToken(121);
/* 1350 */     loop.setType(136);
/* 1351 */     pushScope((Scope)loop);
/*      */     try {
/* 1353 */       this.decompiler.addToken(90);
/* 1354 */       Node cond = transform(loop.getCondition());
/* 1355 */       this.decompiler.addToken(91);
/* 1356 */       this.decompiler.addEOL(88);
/* 1357 */       Node body = transform(loop.getBody());
/* 1358 */       this.decompiler.addEOL(89);
/* 1359 */       return createLoop((Jump)loop, 1, body, cond, (Node)null, (Node)null);
/*      */     } finally {
/* 1361 */       popScope();
/*      */     } 
/*      */   }
/*      */   
/*      */   private Node transformWith(WithStatement node) {
/* 1366 */     this.decompiler.addToken(127);
/* 1367 */     this.decompiler.addToken(90);
/* 1368 */     Node expr = transform(node.getExpression());
/* 1369 */     this.decompiler.addToken(91);
/* 1370 */     this.decompiler.addEOL(88);
/* 1371 */     Node stmt = transform(node.getStatement());
/* 1372 */     this.decompiler.addEOL(89);
/* 1373 */     return createWith(expr, stmt, node.getLineno());
/*      */   }
/*      */   
/*      */   private Node transformYield(Yield node) {
/* 1377 */     this.decompiler.addToken(node.getType());
/* 1378 */     Node kid = (node.getValue() == null) ? null : transform(node.getValue());
/* 1379 */     if (kid != null) return new Node(node.getType(), kid, node.getLineno()); 
/* 1380 */     return new Node(node.getType(), node.getLineno());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node transformXmlLiteral(XmlLiteral node) {
/* 1387 */     Node pnXML = new Node(30, node.getLineno());
/* 1388 */     List<XmlFragment> frags = node.getFragments();
/*      */     
/* 1390 */     XmlString first = (XmlString)frags.get(0);
/* 1391 */     boolean anon = first.getXml().trim().startsWith("<>");
/* 1392 */     pnXML.addChildToBack(createName(anon ? "XMLList" : "XML"));
/*      */     
/* 1394 */     Node pn = null;
/* 1395 */     for (XmlFragment frag : frags) {
/* 1396 */       Node expr; if (frag instanceof XmlString) {
/* 1397 */         String xml = ((XmlString)frag).getXml();
/* 1398 */         this.decompiler.addName(xml);
/* 1399 */         if (pn == null) {
/* 1400 */           pn = createString(xml); continue;
/*      */         } 
/* 1402 */         pn = createBinary(21, pn, createString(xml));
/*      */         continue;
/*      */       } 
/* 1405 */       XmlExpression xexpr = (XmlExpression)frag;
/* 1406 */       boolean isXmlAttr = xexpr.isXmlAttribute();
/*      */       
/* 1408 */       this.decompiler.addToken(88);
/* 1409 */       if (xexpr.getExpression() instanceof EmptyExpression) {
/* 1410 */         expr = createString("");
/*      */       } else {
/* 1412 */         expr = transform(xexpr.getExpression());
/*      */       } 
/* 1414 */       this.decompiler.addToken(89);
/* 1415 */       if (isXmlAttr) {
/*      */         
/* 1417 */         expr = createUnary(77, expr);
/* 1418 */         Node prepend = createBinary(21, createString("\""), expr);
/* 1419 */         expr = createBinary(21, prepend, createString("\""));
/*      */       } else {
/* 1421 */         expr = createUnary(78, expr);
/*      */       } 
/* 1423 */       pn = createBinary(21, pn, expr);
/*      */     } 
/*      */ 
/*      */     
/* 1427 */     pnXML.addChildToBack(pn);
/* 1428 */     return pnXML;
/*      */   }
/*      */   
/*      */   private Node transformXmlMemberGet(XmlMemberGet node) {
/* 1432 */     XmlRef ref = node.getMemberRef();
/* 1433 */     Node pn = transform(node.getLeft());
/* 1434 */     int flags = ref.isAttributeAccess() ? 2 : 0;
/* 1435 */     if (node.getType() == 147) {
/* 1436 */       flags |= 0x4;
/* 1437 */       this.decompiler.addToken(147);
/*      */     } else {
/* 1439 */       this.decompiler.addToken(112);
/*      */     } 
/* 1441 */     return transformXmlRef(pn, ref, flags);
/*      */   }
/*      */ 
/*      */   
/*      */   private Node transformXmlRef(XmlRef node) {
/* 1446 */     int memberTypeFlags = node.isAttributeAccess() ? 2 : 0;
/* 1447 */     return transformXmlRef((Node)null, node, memberTypeFlags);
/*      */   }
/*      */   
/*      */   private Node transformXmlRef(Node pn, XmlRef node, int memberTypeFlags) {
/* 1451 */     if ((memberTypeFlags & 0x2) != 0) this.decompiler.addToken(151); 
/* 1452 */     Name namespace = node.getNamespace();
/* 1453 */     String ns = (namespace != null) ? namespace.getIdentifier() : null;
/* 1454 */     if (ns != null) {
/* 1455 */       this.decompiler.addName(ns);
/* 1456 */       this.decompiler.addToken(148);
/*      */     } 
/* 1458 */     if (node instanceof XmlPropRef) {
/* 1459 */       String name = ((XmlPropRef)node).getPropName().getIdentifier();
/* 1460 */       this.decompiler.addName(name);
/* 1461 */       return createPropertyGet(pn, ns, name, memberTypeFlags);
/*      */     } 
/* 1463 */     this.decompiler.addToken(86);
/* 1464 */     Node expr = transform(((XmlElemRef)node).getExpression());
/* 1465 */     this.decompiler.addToken(87);
/* 1466 */     return createElementGet(pn, ns, expr, memberTypeFlags);
/*      */   }
/*      */   
/*      */   private Node transformDefaultXmlNamepace(UnaryExpression node) {
/* 1470 */     this.decompiler.addToken(120);
/* 1471 */     this.decompiler.addName(" xml");
/* 1472 */     this.decompiler.addName(" namespace");
/* 1473 */     this.decompiler.addToken(93);
/* 1474 */     Node child = transform(node.getOperand());
/* 1475 */     return createUnary(76, child);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void addSwitchCase(Node switchBlock, Node caseExpression, Node statements) {
/* 1480 */     if (switchBlock.getType() != 133) throw Kit.codeBug(); 
/* 1481 */     Jump switchNode = (Jump)switchBlock.getFirstChild();
/* 1482 */     if (switchNode.getType() != 118) throw Kit.codeBug();
/*      */     
/* 1484 */     Node gotoTarget = Node.newTarget();
/* 1485 */     if (caseExpression != null) {
/* 1486 */       Jump caseNode = new Jump(119, caseExpression);
/* 1487 */       caseNode.target = gotoTarget;
/* 1488 */       switchNode.addChildToBack((Node)caseNode);
/*      */     } else {
/* 1490 */       switchNode.setDefault(gotoTarget);
/*      */     } 
/* 1492 */     switchBlock.addChildToBack(gotoTarget);
/* 1493 */     switchBlock.addChildToBack(statements);
/*      */   }
/*      */   
/*      */   private static void closeSwitch(Node switchBlock) {
/* 1497 */     if (switchBlock.getType() != 133) throw Kit.codeBug(); 
/* 1498 */     Jump switchNode = (Jump)switchBlock.getFirstChild();
/* 1499 */     if (switchNode.getType() != 118) throw Kit.codeBug();
/*      */     
/* 1501 */     Node switchBreakTarget = Node.newTarget();
/*      */ 
/*      */     
/* 1504 */     switchNode.target = switchBreakTarget;
/*      */     
/* 1506 */     Node defaultTarget = switchNode.getDefault();
/* 1507 */     if (defaultTarget == null) {
/* 1508 */       defaultTarget = switchBreakTarget;
/*      */     }
/*      */     
/* 1511 */     switchBlock.addChildAfter((Node)makeJump(5, defaultTarget), (Node)switchNode);
/* 1512 */     switchBlock.addChildToBack(switchBreakTarget);
/*      */   }
/*      */   
/*      */   private static Node createExprStatementNoReturn(Node expr, int lineno) {
/* 1516 */     return new Node(137, expr, lineno);
/*      */   }
/*      */   
/*      */   private static Node createString(String string) {
/* 1520 */     return Node.newString(string);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node createCatch(String varName, Node catchCond, Node stmts, int lineno) {
/* 1533 */     if (catchCond == null) {
/* 1534 */       catchCond = new Node(132);
/*      */     }
/* 1536 */     return new Node(128, createName(varName), catchCond, stmts, lineno);
/*      */   }
/*      */ 
/*      */   
/*      */   private static Node initFunction(FunctionNode fnNode, int functionIndex, Node statements, int functionType) {
/* 1541 */     fnNode.setFunctionType(functionType);
/* 1542 */     fnNode.addChildToBack(statements);
/*      */     
/* 1544 */     int functionCount = fnNode.getFunctionCount();
/* 1545 */     if (functionCount != 0)
/*      */     {
/* 1547 */       fnNode.setRequiresActivation();
/*      */     }
/*      */     
/* 1550 */     if (functionType == 2) {
/* 1551 */       Name name = fnNode.getFunctionName();
/* 1552 */       if (name != null && name
/* 1553 */         .length() != 0 && fnNode
/* 1554 */         .getSymbol(name.getIdentifier()) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1562 */         fnNode.putSymbol(new Symbol(113, name.getIdentifier()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1568 */         Node setFn = new Node(137, new Node(8, Node.newString(49, name.getIdentifier()), new Node(64)));
/*      */         
/* 1570 */         statements.addChildrenToFront(setFn);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1575 */     Node lastStmt = statements.getLastChild();
/* 1576 */     if (lastStmt == null || lastStmt.getType() != 4) {
/* 1577 */       statements.addChildToBack(new Node(4));
/*      */     }
/*      */     
/* 1580 */     Node result = Node.newString(113, fnNode.getName());
/* 1581 */     result.putIntProp(1, functionIndex);
/* 1582 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Scope createLoopNode(Node loopLabel, int lineno) {
/* 1590 */     Scope result = createScopeNode(136, lineno);
/* 1591 */     if (loopLabel != null) {
/* 1592 */       ((Jump)loopLabel).setLoop((Jump)result);
/*      */     }
/* 1594 */     return result;
/*      */   }
/*      */   
/*      */   private static Node createFor(Scope loop, Node init, Node test, Node incr, Node body) {
/* 1598 */     if (init.getType() == 157) {
/*      */ 
/*      */ 
/*      */       
/* 1602 */       Scope let = Scope.splitScope(loop);
/* 1603 */       let.setType(157);
/* 1604 */       let.addChildrenToBack(init);
/* 1605 */       let.addChildToBack(createLoop((Jump)loop, 2, body, test, new Node(132), incr));
/* 1606 */       return (Node)let;
/*      */     } 
/* 1608 */     return createLoop((Jump)loop, 2, body, test, init, incr);
/*      */   }
/*      */ 
/*      */   
/*      */   private static Node createLoop(Jump loop, int loopType, Node body, Node cond, Node init, Node incr) {
/* 1613 */     Node bodyTarget = Node.newTarget();
/* 1614 */     Node condTarget = Node.newTarget();
/* 1615 */     if (loopType == 2 && cond.getType() == 132) {
/* 1616 */       cond = new Node(45);
/*      */     }
/* 1618 */     Jump IFEQ = new Jump(6, cond);
/* 1619 */     IFEQ.target = bodyTarget;
/* 1620 */     Node breakTarget = Node.newTarget();
/*      */     
/* 1622 */     loop.addChildToBack(bodyTarget);
/* 1623 */     loop.addChildrenToBack(body);
/* 1624 */     if (loopType == 1 || loopType == 2)
/*      */     {
/* 1626 */       loop.addChildrenToBack(new Node(132, loop.getLineno()));
/*      */     }
/* 1628 */     loop.addChildToBack(condTarget);
/* 1629 */     loop.addChildToBack((Node)IFEQ);
/* 1630 */     loop.addChildToBack(breakTarget);
/*      */     
/* 1632 */     loop.target = breakTarget;
/* 1633 */     Node continueTarget = condTarget;
/*      */     
/* 1635 */     if (loopType == 1 || loopType == 2) {
/*      */       
/* 1637 */       loop.addChildToFront((Node)makeJump(5, condTarget));
/*      */       
/* 1639 */       if (loopType == 2) {
/* 1640 */         int initType = init.getType();
/* 1641 */         if (initType != 132) {
/* 1642 */           if (initType != 126 && initType != 157) {
/* 1643 */             init = new Node(137, init);
/*      */           }
/* 1645 */           loop.addChildToFront(init);
/*      */         } 
/* 1647 */         Node incrTarget = Node.newTarget();
/* 1648 */         loop.addChildAfter(incrTarget, body);
/* 1649 */         if (incr.getType() != 132) {
/* 1650 */           incr = new Node(137, incr);
/* 1651 */           loop.addChildAfter(incr, incrTarget);
/*      */         } 
/* 1653 */         continueTarget = incrTarget;
/*      */       } 
/*      */     } 
/*      */     
/* 1657 */     loop.setContinue(continueTarget);
/* 1658 */     return (Node)loop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node createForIn(int declType, Node loop, Node lhs, Node obj, Node body, boolean isForEach, boolean isForOf) {
/*      */     Node lvalue, assign;
/* 1670 */     int destructuring = -1;
/* 1671 */     int destructuringLen = 0;
/*      */     
/* 1673 */     int type = lhs.getType();
/* 1674 */     if (type == 126 || type == 157) {
/* 1675 */       Node kid = lhs.getLastChild();
/* 1676 */       int kidType = kid.getType();
/* 1677 */       if (kidType == 66 || kidType == 67) {
/* 1678 */         type = destructuring = kidType;
/* 1679 */         lvalue = kid;
/* 1680 */         destructuringLen = 0;
/* 1681 */         if (kid instanceof ArrayLiteral)
/* 1682 */           destructuringLen = ((ArrayLiteral)kid).getDestructuringLength(); 
/* 1683 */       } else if (kidType == 39) {
/* 1684 */         lvalue = Node.newString(39, kid.getString());
/*      */       } else {
/* 1686 */         reportError("msg.bad.for.in.lhs");
/* 1687 */         return null;
/*      */       } 
/* 1689 */     } else if (type == 66 || type == 67) {
/* 1690 */       destructuring = type;
/* 1691 */       lvalue = lhs;
/* 1692 */       destructuringLen = 0;
/* 1693 */       if (lhs instanceof ArrayLiteral)
/* 1694 */         destructuringLen = ((ArrayLiteral)lhs).getDestructuringLength(); 
/*      */     } else {
/* 1696 */       lvalue = makeReference(lhs);
/* 1697 */       if (lvalue == null) {
/* 1698 */         reportError("msg.bad.for.in.lhs");
/* 1699 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/* 1703 */     Node localBlock = new Node(145);
/* 1704 */     int initType = isForEach ? 59 : (isForOf ? 61 : ((destructuring != -1) ? 60 : 58));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1712 */     Node init = new Node(initType, obj);
/* 1713 */     init.putProp(3, localBlock);
/* 1714 */     Node cond = new Node(62);
/* 1715 */     cond.putProp(3, localBlock);
/* 1716 */     Node id = new Node(63);
/* 1717 */     id.putProp(3, localBlock);
/*      */     
/* 1719 */     Node newBody = new Node(133);
/*      */     
/* 1721 */     if (destructuring != -1) {
/* 1722 */       assign = createDestructuringAssignment(declType, lvalue, id);
/* 1723 */       if (!isForEach && !isForOf && (destructuring == 67 || destructuringLen != 2))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1728 */         reportError("msg.bad.for.in.destruct");
/*      */       }
/*      */     } else {
/* 1731 */       assign = simpleAssignment(lvalue, id);
/*      */     } 
/* 1733 */     newBody.addChildToBack(new Node(137, assign));
/* 1734 */     newBody.addChildToBack(body);
/*      */     
/* 1736 */     loop = createLoop((Jump)loop, 1, newBody, cond, (Node)null, (Node)null);
/* 1737 */     loop.addChildToFront(init);
/* 1738 */     if (type == 126 || type == 157) loop.addChildToFront(lhs); 
/* 1739 */     localBlock.addChildToBack(loop);
/*      */     
/* 1741 */     return localBlock;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node createTryCatchFinally(Node tryBlock, Node catchBlocks, Node finallyBlock, int lineno) {
/* 1762 */     boolean hasFinally = (finallyBlock != null && (finallyBlock.getType() != 133 || finallyBlock.hasChildren()));
/*      */ 
/*      */     
/* 1765 */     if (tryBlock.getType() == 133 && !tryBlock.hasChildren() && !hasFinally) {
/* 1766 */       return tryBlock;
/*      */     }
/*      */     
/* 1769 */     boolean hasCatch = catchBlocks.hasChildren();
/*      */ 
/*      */     
/* 1772 */     if (!hasFinally && !hasCatch)
/*      */     {
/* 1774 */       return tryBlock;
/*      */     }
/*      */     
/* 1777 */     Node handlerBlock = new Node(145);
/* 1778 */     Jump pn = new Jump(84, tryBlock, lineno);
/* 1779 */     pn.putProp(3, handlerBlock);
/*      */     
/* 1781 */     if (hasCatch) {
/*      */       
/* 1783 */       Node endCatch = Node.newTarget();
/* 1784 */       pn.addChildToBack((Node)makeJump(5, endCatch));
/*      */ 
/*      */       
/* 1787 */       Node catchTarget = Node.newTarget();
/* 1788 */       pn.target = catchTarget;
/*      */       
/* 1790 */       pn.addChildToBack(catchTarget);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1840 */       Node catchScopeBlock = new Node(145);
/*      */ 
/*      */       
/* 1843 */       Node cb = catchBlocks.getFirstChild();
/* 1844 */       boolean hasDefault = false;
/* 1845 */       int scopeIndex = 0;
/* 1846 */       while (cb != null) {
/* 1847 */         Node condStmt; int catchLineNo = cb.getLineno();
/*      */         
/* 1849 */         Node name = cb.getFirstChild();
/* 1850 */         Node cond = name.getNext();
/* 1851 */         Node catchStatement = cond.getNext();
/* 1852 */         cb.removeChild(name);
/* 1853 */         cb.removeChild(cond);
/* 1854 */         cb.removeChild(catchStatement);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1860 */         catchStatement.addChildToBack(new Node(3));
/* 1861 */         catchStatement.addChildToBack((Node)makeJump(5, endCatch));
/*      */ 
/*      */ 
/*      */         
/* 1865 */         if (cond.getType() == 132) {
/* 1866 */           condStmt = catchStatement;
/* 1867 */           hasDefault = true;
/*      */         } else {
/* 1869 */           condStmt = createIf(cond, catchStatement, (Node)null, catchLineNo);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1874 */         Node catchScope = new Node(57, name, createUseLocal(handlerBlock));
/* 1875 */         catchScope.putProp(3, catchScopeBlock);
/* 1876 */         catchScope.putIntProp(14, scopeIndex);
/* 1877 */         catchScopeBlock.addChildToBack(catchScope);
/*      */ 
/*      */         
/* 1880 */         catchScopeBlock.addChildToBack(
/* 1881 */             createWith(createUseLocal(catchScopeBlock), condStmt, catchLineNo));
/*      */ 
/*      */         
/* 1884 */         cb = cb.getNext();
/* 1885 */         scopeIndex++;
/*      */       } 
/* 1887 */       pn.addChildToBack(catchScopeBlock);
/* 1888 */       if (!hasDefault) {
/*      */         
/* 1890 */         Node rethrow = new Node(51);
/* 1891 */         rethrow.putProp(3, handlerBlock);
/* 1892 */         pn.addChildToBack(rethrow);
/*      */       } 
/*      */       
/* 1895 */       pn.addChildToBack(endCatch);
/*      */     } 
/*      */     
/* 1898 */     if (hasFinally) {
/* 1899 */       Node finallyTarget = Node.newTarget();
/* 1900 */       pn.setFinally(finallyTarget);
/*      */ 
/*      */       
/* 1903 */       pn.addChildToBack((Node)makeJump(139, finallyTarget));
/*      */ 
/*      */       
/* 1906 */       Node finallyEnd = Node.newTarget();
/* 1907 */       pn.addChildToBack((Node)makeJump(5, finallyEnd));
/*      */       
/* 1909 */       pn.addChildToBack(finallyTarget);
/* 1910 */       Node fBlock = new Node(129, finallyBlock);
/* 1911 */       fBlock.putProp(3, handlerBlock);
/* 1912 */       pn.addChildToBack(fBlock);
/*      */       
/* 1914 */       pn.addChildToBack(finallyEnd);
/*      */     } 
/* 1916 */     handlerBlock.addChildToBack((Node)pn);
/* 1917 */     return handlerBlock;
/*      */   }
/*      */   
/*      */   private Node createWith(Node obj, Node body, int lineno) {
/* 1921 */     setRequiresActivation();
/* 1922 */     Node result = new Node(133, lineno);
/* 1923 */     result.addChildToBack(new Node(2, obj));
/* 1924 */     Node bodyNode = new Node(127, body, lineno);
/* 1925 */     result.addChildrenToBack(bodyNode);
/* 1926 */     result.addChildToBack(new Node(3));
/* 1927 */     return result;
/*      */   }
/*      */   
/*      */   private static Node createIf(Node cond, Node ifTrue, Node ifFalse, int lineno) {
/* 1931 */     int condStatus = isAlwaysDefinedBoolean(cond);
/* 1932 */     if (condStatus == 1)
/* 1933 */       return ifTrue; 
/* 1934 */     if (condStatus == -1) {
/* 1935 */       if (ifFalse != null) {
/* 1936 */         return ifFalse;
/*      */       }
/*      */       
/* 1939 */       return new Node(133, lineno);
/*      */     } 
/*      */     
/* 1942 */     Node result = new Node(133, lineno);
/* 1943 */     Node ifNotTarget = Node.newTarget();
/* 1944 */     Jump IFNE = new Jump(7, cond);
/* 1945 */     IFNE.target = ifNotTarget;
/*      */     
/* 1947 */     result.addChildToBack((Node)IFNE);
/* 1948 */     result.addChildrenToBack(ifTrue);
/*      */     
/* 1950 */     if (ifFalse != null) {
/* 1951 */       Node endTarget = Node.newTarget();
/* 1952 */       result.addChildToBack((Node)makeJump(5, endTarget));
/* 1953 */       result.addChildToBack(ifNotTarget);
/* 1954 */       result.addChildrenToBack(ifFalse);
/* 1955 */       result.addChildToBack(endTarget);
/*      */     } else {
/* 1957 */       result.addChildToBack(ifNotTarget);
/*      */     } 
/*      */     
/* 1960 */     return result;
/*      */   }
/*      */   
/*      */   private static Node createCondExpr(Node cond, Node ifTrue, Node ifFalse) {
/* 1964 */     int condStatus = isAlwaysDefinedBoolean(cond);
/* 1965 */     if (condStatus == 1)
/* 1966 */       return ifTrue; 
/* 1967 */     if (condStatus == -1) {
/* 1968 */       return ifFalse;
/*      */     }
/* 1970 */     return new Node(106, cond, ifTrue, ifFalse);
/*      */   }
/*      */   private static Node createUnary(int nodeType, Node child) {
/*      */     Node n;
/* 1974 */     int status, childType = child.getType();
/* 1975 */     switch (nodeType) {
/*      */ 
/*      */       
/*      */       case 31:
/* 1979 */         if (childType == 39) {
/*      */ 
/*      */           
/* 1982 */           child.setType(49);
/* 1983 */           Node left = child;
/* 1984 */           Node right = Node.newString(child.getString());
/* 1985 */           n = new Node(nodeType, left, right);
/* 1986 */         } else if (childType == 33 || childType == 36) {
/* 1987 */           Node left = child.getFirstChild();
/* 1988 */           Node right = child.getLastChild();
/* 1989 */           child.removeChild(left);
/* 1990 */           child.removeChild(right);
/* 1991 */           n = new Node(nodeType, left, right);
/* 1992 */         } else if (childType == 68) {
/* 1993 */           Node ref = child.getFirstChild();
/* 1994 */           child.removeChild(ref);
/* 1995 */           n = new Node(70, ref);
/*      */         } else {
/*      */           
/* 1998 */           n = new Node(nodeType, new Node(45), child);
/*      */         } 
/* 2000 */         return n;
/*      */       
/*      */       case 32:
/* 2003 */         if (childType == 39) {
/* 2004 */           child.setType(141);
/* 2005 */           return child;
/*      */         } 
/*      */         break;
/*      */       case 27:
/* 2009 */         if (childType == 40) {
/* 2010 */           int value = ScriptRuntime.toInt32(child.getDouble());
/* 2011 */           child.setDouble((value ^ 0xFFFFFFFF));
/* 2012 */           return child;
/*      */         } 
/*      */         break;
/*      */       case 29:
/* 2016 */         if (childType == 40) {
/* 2017 */           child.setDouble(-child.getDouble());
/* 2018 */           return child;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 26:
/* 2023 */         status = isAlwaysDefinedBoolean(child);
/* 2024 */         if (status != 0) {
/*      */           int type;
/* 2026 */           if (status == 1) {
/* 2027 */             type = 44;
/*      */           } else {
/* 2029 */             type = 45;
/*      */           } 
/* 2031 */           if (childType == 45 || childType == 44) {
/* 2032 */             child.setType(type);
/* 2033 */             return child;
/*      */           } 
/* 2035 */           return new Node(type);
/*      */         } 
/*      */         break;
/*      */     } 
/*      */     
/* 2040 */     return new Node(nodeType, child);
/*      */   }
/*      */   
/*      */   private Node createCallOrNew(int nodeType, Node child) {
/* 2044 */     int type = 0;
/* 2045 */     if (child.getType() == 39) {
/* 2046 */       String name = child.getString();
/* 2047 */       if (name.equals("eval")) {
/* 2048 */         type = 1;
/* 2049 */       } else if (name.equals("With")) {
/* 2050 */         type = 2;
/*      */       } 
/* 2052 */     } else if (child.getType() == 33) {
/* 2053 */       String name = child.getLastChild().getString();
/* 2054 */       if (name.equals("eval")) {
/* 2055 */         type = 1;
/*      */       }
/*      */     } 
/* 2058 */     Node node = new Node(nodeType, child);
/* 2059 */     if (type != 0) {
/*      */       
/* 2061 */       setRequiresActivation();
/* 2062 */       node.putIntProp(10, type);
/*      */     } 
/* 2064 */     return node;
/*      */   } private static Node createIncDec(int nodeType, boolean post, Node child) {
/*      */     Node n;
/*      */     int incrDecrMask;
/* 2068 */     child = makeReference(child);
/* 2069 */     int childType = child.getType();
/*      */     
/* 2071 */     switch (childType) {
/*      */       
/*      */       case 33:
/*      */       case 36:
/*      */       case 39:
/*      */       case 68:
/* 2077 */         n = new Node(nodeType, child);
/* 2078 */         incrDecrMask = 0;
/* 2079 */         if (nodeType == 111) {
/* 2080 */           incrDecrMask |= 0x1;
/*      */         }
/* 2082 */         if (post) {
/* 2083 */           incrDecrMask |= 0x2;
/*      */         }
/* 2085 */         n.putIntProp(13, incrDecrMask);
/* 2086 */         return n;
/*      */     } 
/*      */     
/* 2089 */     throw Kit.codeBug();
/*      */   }
/*      */ 
/*      */   
/*      */   private Node createPropertyGet(Node target, String namespace, String name, int memberTypeFlags) {
/* 2094 */     if (namespace == null && memberTypeFlags == 0) {
/* 2095 */       if (target == null) {
/* 2096 */         return createName(name);
/*      */       }
/* 2098 */       checkActivationName(name, 33);
/* 2099 */       if (ScriptRuntime.isSpecialProperty(name)) {
/* 2100 */         Node ref = new Node(72, target);
/* 2101 */         ref.putProp(17, name);
/* 2102 */         return new Node(68, ref);
/*      */       } 
/* 2104 */       return new Node(33, target, Node.newString(name));
/*      */     } 
/* 2106 */     Node elem = Node.newString(name);
/* 2107 */     memberTypeFlags |= 0x1;
/* 2108 */     return createMemberRefGet(target, namespace, elem, memberTypeFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node createElementGet(Node target, String namespace, Node elem, int memberTypeFlags) {
/* 2120 */     if (namespace == null && memberTypeFlags == 0) {
/*      */ 
/*      */       
/* 2123 */       if (target == null) throw Kit.codeBug(); 
/* 2124 */       return new Node(36, target, elem);
/*      */     } 
/* 2126 */     return createMemberRefGet(target, namespace, elem, memberTypeFlags);
/*      */   }
/*      */   
/*      */   private Node createMemberRefGet(Node target, String namespace, Node elem, int memberTypeFlags) {
/* 2130 */     Node ref, nsNode = null;
/* 2131 */     if (namespace != null)
/*      */     {
/* 2133 */       if (namespace.equals("*")) {
/* 2134 */         nsNode = new Node(42);
/*      */       } else {
/* 2136 */         nsNode = createName(namespace);
/*      */       } 
/*      */     }
/*      */     
/* 2140 */     if (target == null) {
/* 2141 */       if (namespace == null) {
/* 2142 */         ref = new Node(81, elem);
/*      */       } else {
/* 2144 */         ref = new Node(82, nsNode, elem);
/*      */       }
/*      */     
/* 2147 */     } else if (namespace == null) {
/* 2148 */       ref = new Node(79, target, elem);
/*      */     } else {
/* 2150 */       ref = new Node(80, target, nsNode, elem);
/*      */     } 
/*      */     
/* 2153 */     if (memberTypeFlags != 0) {
/* 2154 */       ref.putIntProp(16, memberTypeFlags);
/*      */     }
/* 2156 */     return new Node(68, ref);
/*      */   }
/*      */   
/*      */   private static Node createBinary(int nodeType, Node left, Node right) { int leftStatus;
/* 2160 */     switch (nodeType) {
/*      */       
/*      */       case 21:
/* 2163 */         if (left.type == 41) {
/*      */           String s2;
/* 2165 */           if (right.type == 41)
/* 2166 */           { s2 = right.getString(); }
/* 2167 */           else { if (right.type == 40)
/* 2168 */             { s2 = ScriptRuntime.numberToString(right.getDouble(), 10);
/*      */ 
/*      */ 
/*      */               
/* 2172 */               String s1 = left.getString();
/* 2173 */               left.setString(s1.concat(s2));
/* 2174 */               return left; }  break; }  String str1 = left.getString(); left.setString(str1.concat(s2)); return left;
/* 2175 */         }  if (left.type == 40) {
/* 2176 */           if (right.type == 40) {
/* 2177 */             left.setDouble(left.getDouble() + right.getDouble());
/* 2178 */             return left;
/* 2179 */           }  if (right.type == 41) {
/*      */             
/* 2181 */             String s1 = ScriptRuntime.numberToString(left.getDouble(), 10);
/* 2182 */             String s2 = right.getString();
/* 2183 */             right.setString(s1.concat(s2));
/* 2184 */             return right;
/*      */           } 
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 22:
/* 2194 */         if (left.type == 40) {
/* 2195 */           double ld = left.getDouble();
/* 2196 */           if (right.type == 40) {
/*      */             
/* 2198 */             left.setDouble(ld - right.getDouble());
/* 2199 */             return left;
/* 2200 */           }  if (ld == 0.0D)
/*      */           {
/* 2202 */             return new Node(29, right); }  break;
/*      */         } 
/* 2204 */         if (right.type == 40 && 
/* 2205 */           right.getDouble() == 0.0D)
/*      */         {
/*      */           
/* 2208 */           return new Node(28, left);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/* 2215 */         if (left.type == 40) {
/* 2216 */           double ld = left.getDouble();
/* 2217 */           if (right.type == 40) {
/*      */             
/* 2219 */             left.setDouble(ld * right.getDouble());
/* 2220 */             return left;
/* 2221 */           }  if (ld == 1.0D)
/*      */           {
/* 2223 */             return new Node(28, right); }  break;
/*      */         } 
/* 2225 */         if (right.type == 40 && 
/* 2226 */           right.getDouble() == 1.0D)
/*      */         {
/*      */           
/* 2229 */           return new Node(28, left);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/* 2237 */         if (right.type == 40) {
/* 2238 */           double rd = right.getDouble();
/* 2239 */           if (left.type == 40) {
/*      */             
/* 2241 */             left.setDouble(left.getDouble() / rd);
/* 2242 */             return left;
/* 2243 */           }  if (rd == 1.0D)
/*      */           {
/*      */             
/* 2246 */             return new Node(28, left);
/*      */           }
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/* 2257 */         leftStatus = isAlwaysDefinedBoolean(left);
/* 2258 */         if (leftStatus == -1)
/*      */         {
/* 2260 */           return left; } 
/* 2261 */         if (leftStatus == 1)
/*      */         {
/* 2263 */           return right;
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 108:
/* 2274 */         leftStatus = isAlwaysDefinedBoolean(left);
/* 2275 */         if (leftStatus == 1)
/*      */         {
/* 2277 */           return left; } 
/* 2278 */         if (leftStatus == -1)
/*      */         {
/* 2280 */           return right;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 2286 */     return new Node(nodeType, left, right); } private Node createAssignment(int assignType, Node left, Node right) {
/*      */     int assignOp;
/*      */     Node op, obj, opLeft, lvalueLeft, id, node1;
/*      */     int type;
/* 2290 */     Node node2, node3, ref = makeReference(left);
/* 2291 */     if (ref == null) {
/* 2292 */       if (left.getType() == 66 || left.getType() == 67) {
/* 2293 */         if (assignType != 93) {
/* 2294 */           reportError("msg.bad.destruct.op");
/* 2295 */           return right;
/*      */         } 
/* 2297 */         return createDestructuringAssignment(-1, left, right);
/*      */       } 
/* 2299 */       reportError("msg.bad.assign.left");
/* 2300 */       return right;
/*      */     } 
/* 2302 */     left = ref;
/*      */ 
/*      */     
/* 2305 */     switch (assignType) {
/*      */       case 93:
/* 2307 */         return simpleAssignment(left, right);
/*      */       case 94:
/* 2309 */         assignOp = 9;
/*      */         break;
/*      */       case 95:
/* 2312 */         assignOp = 10;
/*      */         break;
/*      */       case 96:
/* 2315 */         assignOp = 11;
/*      */         break;
/*      */       case 97:
/* 2318 */         assignOp = 18;
/*      */         break;
/*      */       case 98:
/* 2321 */         assignOp = 19;
/*      */         break;
/*      */       case 99:
/* 2324 */         assignOp = 20;
/*      */         break;
/*      */       case 100:
/* 2327 */         assignOp = 21;
/*      */         break;
/*      */       case 101:
/* 2330 */         assignOp = 22;
/*      */         break;
/*      */       case 102:
/* 2333 */         assignOp = 23;
/*      */         break;
/*      */       case 103:
/* 2336 */         assignOp = 24;
/*      */         break;
/*      */       case 104:
/* 2339 */         assignOp = 25;
/*      */         break;
/*      */       case 105:
/* 2342 */         assignOp = 75;
/*      */         break;
/*      */       default:
/* 2345 */         throw Kit.codeBug();
/*      */     } 
/*      */     
/* 2348 */     int nodeType = left.getType();
/* 2349 */     switch (nodeType) {
/*      */       
/*      */       case 39:
/* 2352 */         op = new Node(assignOp, left, right);
/* 2353 */         lvalueLeft = Node.newString(49, left.getString());
/* 2354 */         return new Node(8, lvalueLeft, op);
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 36:
/* 2359 */         obj = left.getFirstChild();
/* 2360 */         id = left.getLastChild();
/*      */         
/* 2362 */         type = (nodeType == 33) ? 143 : 144;
/*      */         
/* 2364 */         node2 = new Node(142);
/* 2365 */         node3 = new Node(assignOp, node2, right);
/* 2366 */         return new Node(type, obj, id, node3);
/*      */ 
/*      */       
/*      */       case 68:
/* 2370 */         ref = left.getFirstChild();
/* 2371 */         checkMutableReference(ref);
/* 2372 */         opLeft = new Node(142);
/* 2373 */         node1 = new Node(assignOp, opLeft, right);
/* 2374 */         return new Node(146, ref, node1);
/*      */     } 
/*      */ 
/*      */     
/* 2378 */     throw Kit.codeBug();
/*      */   }
/*      */   
/*      */   private static Node createUseLocal(Node localBlock) {
/* 2382 */     if (145 != localBlock.getType()) throw Kit.codeBug(); 
/* 2383 */     Node result = new Node(54);
/* 2384 */     result.putProp(3, localBlock);
/* 2385 */     return result;
/*      */   }
/*      */   
/*      */   private static Jump makeJump(int type, Node target) {
/* 2389 */     Jump n = new Jump(type);
/* 2390 */     n.target = target;
/* 2391 */     return n;
/*      */   }
/*      */   
/*      */   private static Node makeReference(Node node) {
/* 2395 */     int type = node.getType();
/* 2396 */     switch (type) {
/*      */       case 33:
/*      */       case 36:
/*      */       case 39:
/*      */       case 68:
/* 2401 */         return node;
/*      */       case 38:
/* 2403 */         node.setType(71);
/* 2404 */         return new Node(68, node);
/*      */     } 
/*      */     
/* 2407 */     return null;
/*      */   }
/*      */   
/*      */   private static int isAlwaysDefinedBoolean(Node node) {
/*      */     double num;
/* 2412 */     switch (node.getType()) {
/*      */       case 42:
/*      */       case 44:
/* 2415 */         return -1;
/*      */       case 45:
/* 2417 */         return 1;
/*      */       
/*      */       case 40:
/* 2420 */         num = node.getDouble();
/* 2421 */         if (!Double.isNaN(num) && num != 0.0D) {
/* 2422 */           return 1;
/*      */         }
/* 2424 */         return -1;
/*      */     } 
/*      */     
/* 2427 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isDestructuring(Node n) {
/* 2432 */     return (n instanceof DestructuringForm && ((DestructuringForm)n).isDestructuring());
/*      */   }
/*      */   
/*      */   Node decompileFunctionHeader(FunctionNode fn) {
/* 2436 */     Node mexpr = null;
/* 2437 */     if (fn.getFunctionName() != null) {
/* 2438 */       this.decompiler.addName(fn.getName());
/* 2439 */     } else if (fn.getMemberExprNode() != null) {
/* 2440 */       mexpr = transform(fn.getMemberExprNode());
/*      */     } 
/* 2442 */     boolean isArrow = (fn.getFunctionType() == 4);
/* 2443 */     boolean noParen = (isArrow && fn.getLp() == -1);
/* 2444 */     if (!noParen) {
/* 2445 */       this.decompiler.addToken(90);
/*      */     }
/* 2447 */     List<AstNode> params = fn.getParams();
/* 2448 */     for (int i = 0; i < params.size(); i++) {
/* 2449 */       decompile(params.get(i));
/* 2450 */       if (i < params.size() - 1) {
/* 2451 */         this.decompiler.addToken(92);
/*      */       }
/*      */     } 
/* 2454 */     if (!noParen) {
/* 2455 */       this.decompiler.addToken(91);
/*      */     }
/* 2457 */     if (isArrow) {
/* 2458 */       this.decompiler.addToken(168);
/*      */     }
/* 2460 */     if (!fn.isExpressionClosure()) {
/* 2461 */       this.decompiler.addEOL(88);
/*      */     }
/* 2463 */     return mexpr;
/*      */   }
/*      */   
/*      */   void decompile(AstNode node) {
/* 2467 */     switch (node.getType()) {
/*      */       case 66:
/* 2469 */         decompileArrayLiteral((ArrayLiteral)node);
/*      */       
/*      */       case 67:
/* 2472 */         decompileObjectLiteral((ObjectLiteral)node);
/*      */       
/*      */       case 41:
/* 2475 */         this.decompiler.addString(((StringLiteral)node).getValue());
/*      */       
/*      */       case 39:
/* 2478 */         this.decompiler.addName(((Name)node).getIdentifier());
/*      */       
/*      */       case 40:
/* 2481 */         this.decompiler.addNumber(((NumberLiteral)node).getNumber());
/*      */       
/*      */       case 83:
/* 2484 */         this.decompiler.addBigInt(((BigIntLiteral)node).getBigInt());
/*      */       
/*      */       case 33:
/* 2487 */         decompilePropertyGet((PropertyGet)node);
/*      */       
/*      */       case 132:
/*      */         return;
/*      */       case 36:
/* 2492 */         decompileElementGet((ElementGet)node);
/*      */       
/*      */       case 43:
/* 2495 */         this.decompiler.addToken(node.getType());
/*      */     } 
/*      */     
/* 2498 */     Kit.codeBug("unexpected token: " + Token.typeToName(node.getType()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void decompileArrayLiteral(ArrayLiteral node) {
/* 2504 */     this.decompiler.addToken(86);
/* 2505 */     List<AstNode> elems = node.getElements();
/* 2506 */     int size = elems.size();
/* 2507 */     for (int i = 0; i < size; i++) {
/* 2508 */       AstNode elem = elems.get(i);
/* 2509 */       decompile(elem);
/* 2510 */       if (i < size - 1) {
/* 2511 */         this.decompiler.addToken(92);
/*      */       }
/*      */     } 
/* 2514 */     this.decompiler.addToken(87);
/*      */   }
/*      */ 
/*      */   
/*      */   void decompileObjectLiteral(ObjectLiteral node) {
/* 2519 */     this.decompiler.addToken(88);
/* 2520 */     List<ObjectProperty> props = node.getElements();
/* 2521 */     int size = props.size();
/* 2522 */     for (int i = 0; i < size; i++) {
/* 2523 */       ObjectProperty prop = props.get(i);
/*      */       
/* 2525 */       boolean shorthandPropertyName = Boolean.TRUE.equals(prop.getProp(26));
/* 2526 */       decompile(prop.getLeft());
/* 2527 */       if (!shorthandPropertyName) {
/* 2528 */         this.decompiler.addToken(107);
/* 2529 */         decompile(prop.getRight());
/*      */       } 
/* 2531 */       if (i < size - 1) {
/* 2532 */         this.decompiler.addToken(92);
/*      */       }
/*      */     } 
/* 2535 */     this.decompiler.addToken(89);
/*      */   }
/*      */ 
/*      */   
/*      */   void decompilePropertyGet(PropertyGet node) {
/* 2540 */     decompile(node.getTarget());
/* 2541 */     this.decompiler.addToken(112);
/* 2542 */     decompile((AstNode)node.getProperty());
/*      */   }
/*      */ 
/*      */   
/*      */   void decompileElementGet(ElementGet node) {
/* 2547 */     decompile(node.getTarget());
/* 2548 */     this.decompiler.addToken(86);
/* 2549 */     decompile(node.getElement());
/* 2550 */     this.decompiler.addToken(87);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\IRFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */