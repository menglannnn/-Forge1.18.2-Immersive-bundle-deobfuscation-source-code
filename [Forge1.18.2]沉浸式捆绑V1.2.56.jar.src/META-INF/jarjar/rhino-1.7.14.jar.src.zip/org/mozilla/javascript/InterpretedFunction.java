/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import org.mozilla.javascript.debug.DebuggableScript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InterpretedFunction
/*     */   extends NativeFunction
/*     */   implements Script
/*     */ {
/*     */   private static final long serialVersionUID = 541475680333911468L;
/*     */   InterpreterData idata;
/*     */   SecurityController securityController;
/*     */   Object securityDomain;
/*     */   
/*     */   private InterpretedFunction(InterpreterData idata, Object staticSecurityDomain) {
/*     */     Object dynamicDomain;
/*  19 */     this.idata = idata;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  24 */     Context cx = Context.getContext();
/*  25 */     SecurityController sc = cx.getSecurityController();
/*     */     
/*  27 */     if (sc != null) {
/*  28 */       dynamicDomain = sc.getDynamicSecurityDomain(staticSecurityDomain);
/*     */     } else {
/*  30 */       if (staticSecurityDomain != null) {
/*  31 */         throw new IllegalArgumentException();
/*     */       }
/*  33 */       dynamicDomain = null;
/*     */     } 
/*     */     
/*  36 */     this.securityController = sc;
/*  37 */     this.securityDomain = dynamicDomain;
/*     */   }
/*     */   
/*     */   private InterpretedFunction(InterpretedFunction parent, int index) {
/*  41 */     this.idata = parent.idata.itsNestedFunctions[index];
/*  42 */     this.securityController = parent.securityController;
/*  43 */     this.securityDomain = parent.securityDomain;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static InterpretedFunction createScript(InterpreterData idata, Object staticSecurityDomain) {
/*  49 */     InterpretedFunction f = new InterpretedFunction(idata, staticSecurityDomain);
/*  50 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static InterpretedFunction createFunction(Context cx, Scriptable scope, InterpreterData idata, Object staticSecurityDomain) {
/*  57 */     InterpretedFunction f = new InterpretedFunction(idata, staticSecurityDomain);
/*  58 */     f.initScriptFunction(cx, scope, f.idata.isES6Generator);
/*  59 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static InterpretedFunction createFunction(Context cx, Scriptable scope, InterpretedFunction parent, int index) {
/*  65 */     InterpretedFunction f = new InterpretedFunction(parent, index);
/*  66 */     f.initScriptFunction(cx, scope, f.idata.isES6Generator);
/*  67 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFunctionName() {
/*  72 */     return (this.idata.itsName == null) ? "" : this.idata.itsName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  87 */     if (!ScriptRuntime.hasTopCall(cx)) {
/*  88 */       return ScriptRuntime.doTopCall(this, cx, scope, thisObj, args, this.idata.isStrict);
/*     */     }
/*  90 */     return Interpreter.interpret(this, cx, scope, thisObj, args);
/*     */   }
/*     */   
/*     */   public Object exec(Context cx, Scriptable scope) {
/*     */     Object ret;
/*  95 */     if (!isScript())
/*     */     {
/*  97 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 100 */     if (!ScriptRuntime.hasTopCall(cx)) {
/*     */ 
/*     */       
/* 103 */       ret = ScriptRuntime.doTopCall(this, cx, scope, scope, ScriptRuntime.emptyArgs, this.idata.isStrict);
/*     */     } else {
/*     */       
/* 106 */       ret = Interpreter.interpret(this, cx, scope, scope, ScriptRuntime.emptyArgs);
/*     */     } 
/* 108 */     cx.processMicrotasks();
/* 109 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean isScript() {
/* 113 */     return (this.idata.itsFunctionType == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getEncodedSource() {
/* 118 */     return Interpreter.getEncodedSource(this.idata);
/*     */   }
/*     */ 
/*     */   
/*     */   public DebuggableScript getDebuggableView() {
/* 123 */     return this.idata;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resumeGenerator(Context cx, Scriptable scope, int operation, Object state, Object value) {
/* 129 */     return Interpreter.resumeGenerator(cx, scope, operation, state, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getLanguageVersion() {
/* 134 */     return this.idata.languageVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getParamCount() {
/* 139 */     return this.idata.argCount;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getParamAndVarCount() {
/* 144 */     return this.idata.argNames.length;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getParamOrVarName(int index) {
/* 149 */     return this.idata.argNames[index];
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean getParamOrVarConst(int index) {
/* 154 */     return this.idata.argIsConst[index];
/*     */   }
/*     */   
/*     */   boolean hasFunctionNamed(String name) {
/* 158 */     for (int f = 0; f < this.idata.getFunctionCount(); f++) {
/* 159 */       InterpreterData functionData = (InterpreterData)this.idata.getFunction(f);
/* 160 */       if (!functionData.declaredAsFunctionExpression && name
/* 161 */         .equals(functionData.getFunctionName())) {
/* 162 */         return false;
/*     */       }
/*     */     } 
/* 165 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\InterpretedFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */