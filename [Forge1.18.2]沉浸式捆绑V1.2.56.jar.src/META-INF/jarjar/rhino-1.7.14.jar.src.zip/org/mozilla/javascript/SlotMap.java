package org.mozilla.javascript;

public interface SlotMap extends Iterable<Slot> {
  int size();
  
  boolean isEmpty();
  
  Slot modify(Object paramObject, int paramInt1, int paramInt2);
  
  Slot query(Object paramObject, int paramInt);
  
  void replace(Slot paramSlot1, Slot paramSlot2);
  
  void add(Slot paramSlot);
  
  void remove(Object paramObject, int paramInt);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\SlotMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */