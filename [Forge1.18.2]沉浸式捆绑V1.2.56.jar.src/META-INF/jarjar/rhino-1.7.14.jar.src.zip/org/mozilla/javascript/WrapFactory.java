/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrapFactory
/*     */ {
/*     */   public Object wrap(Context cx, Scriptable scope, Object obj, Class<?> staticType) {
/*  48 */     if (obj == null || obj == Undefined.instance || obj instanceof Scriptable) {
/*  49 */       return obj;
/*     */     }
/*  51 */     if (staticType != null && staticType.isPrimitive()) {
/*  52 */       if (staticType == void.class) return Undefined.instance; 
/*  53 */       if (staticType == char.class) return Integer.valueOf(((Character)obj).charValue()); 
/*  54 */       return obj;
/*     */     } 
/*  56 */     if (!isJavaPrimitiveWrap()) {
/*  57 */       if (obj instanceof String || obj instanceof Boolean || obj instanceof Integer || obj instanceof Short || obj instanceof Long || obj instanceof Float || obj instanceof Double || obj instanceof java.math.BigInteger)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  65 */         return obj; } 
/*  66 */       if (obj instanceof Character) {
/*  67 */         return String.valueOf(((Character)obj).charValue());
/*     */       }
/*     */     } 
/*  70 */     Class<?> cls = obj.getClass();
/*  71 */     if (cls.isArray()) {
/*  72 */       return NativeJavaArray.wrap(scope, obj);
/*     */     }
/*  74 */     return wrapAsJavaObject(cx, scope, obj, staticType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable wrapNewObject(Context cx, Scriptable scope, Object obj) {
/*  86 */     if (obj instanceof Scriptable) {
/*  87 */       return (Scriptable)obj;
/*     */     }
/*  89 */     Class<?> cls = obj.getClass();
/*  90 */     if (cls.isArray()) {
/*  91 */       return NativeJavaArray.wrap(scope, obj);
/*     */     }
/*  93 */     return wrapAsJavaObject(cx, scope, obj, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable wrapAsJavaObject(Context cx, Scriptable scope, Object javaObject, Class<?> staticType) {
/* 115 */     if (List.class.isAssignableFrom(javaObject.getClass()))
/* 116 */       return new NativeJavaList(scope, javaObject); 
/* 117 */     if (Map.class.isAssignableFrom(javaObject.getClass())) {
/* 118 */       return new NativeJavaMap(scope, javaObject);
/*     */     }
/* 120 */     return new NativeJavaObject(scope, javaObject, staticType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable wrapJavaClass(Context cx, Scriptable scope, Class<?> javaClass) {
/* 136 */     return new NativeJavaClass(scope, javaClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isJavaPrimitiveWrap() {
/* 148 */     return this.javaPrimitiveWrap;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setJavaPrimitiveWrap(boolean value) {
/* 153 */     Context cx = Context.getCurrentContext();
/* 154 */     if (cx != null && cx.isSealed()) {
/* 155 */       Context.onSealedMutation();
/*     */     }
/* 157 */     this.javaPrimitiveWrap = value;
/*     */   }
/*     */   
/*     */   private boolean javaPrimitiveWrap = true;
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\WrapFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */