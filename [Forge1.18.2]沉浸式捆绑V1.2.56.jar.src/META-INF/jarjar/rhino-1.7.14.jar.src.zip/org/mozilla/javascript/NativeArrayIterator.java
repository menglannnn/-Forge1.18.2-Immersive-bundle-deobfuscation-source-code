/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ public final class NativeArrayIterator extends ES6Iterator {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String ITERATOR_TAG = "ArrayIterator";
/*    */   private ARRAY_ITERATOR_TYPE type;
/*    */   private Scriptable arrayLike;
/*    */   private int index;
/*    */   
/*    */   public enum ARRAY_ITERATOR_TYPE {
/* 11 */     ENTRIES,
/* 12 */     KEYS,
/* 13 */     VALUES;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void init(ScriptableObject scope, boolean sealed) {
/* 22 */     ES6Iterator.init(scope, sealed, new NativeArrayIterator(), "ArrayIterator");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private NativeArrayIterator() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public NativeArrayIterator(Scriptable scope, Scriptable arrayLike, ARRAY_ITERATOR_TYPE type) {
/* 33 */     super(scope, "ArrayIterator");
/* 34 */     this.index = 0;
/* 35 */     this.arrayLike = arrayLike;
/* 36 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 41 */     return "Array Iterator";
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isDone(Context cx, Scriptable scope) {
/* 46 */     return (this.index >= NativeArray.getLengthProperty(cx, this.arrayLike));
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object nextValue(Context cx, Scriptable scope) {
/* 51 */     if (this.type == ARRAY_ITERATOR_TYPE.KEYS) {
/* 52 */       return Integer.valueOf(this.index++);
/*    */     }
/*    */     
/* 55 */     Object value = this.arrayLike.get(this.index, this.arrayLike);
/* 56 */     if (value == Scriptable.NOT_FOUND) {
/* 57 */       value = Undefined.instance;
/*    */     }
/*    */     
/* 60 */     if (this.type == ARRAY_ITERATOR_TYPE.ENTRIES) {
/* 61 */       value = cx.newArray(scope, new Object[] { Integer.valueOf(this.index), value });
/*    */     }
/*    */     
/* 64 */     this.index++;
/* 65 */     return value;
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getTag() {
/* 70 */     return "ArrayIterator";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeArrayIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */