/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.MathContext;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Locale;
/*      */ import java.util.MissingResourceException;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.function.BiConsumer;
/*      */ import org.mozilla.javascript.v8dtoa.DoubleConversion;
/*      */ import org.mozilla.javascript.v8dtoa.FastDtoa;
/*      */ import org.mozilla.javascript.xml.XMLLib;
/*      */ import org.mozilla.javascript.xml.XMLObject;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ScriptRuntime
/*      */ {
/*      */   @Deprecated
/*      */   public static BaseFunction typeErrorThrower() {
/*   42 */     return typeErrorThrower(Context.getCurrentContext());
/*      */   }
/*      */ 
/*      */   
/*      */   public static BaseFunction typeErrorThrower(Context cx) {
/*   47 */     if (cx.typeErrorThrower == null) {
/*   48 */       BaseFunction thrower = new BaseFunction()
/*      */         {
/*      */           private static final long serialVersionUID = -5891740962154902286L;
/*      */ 
/*      */ 
/*      */           
/*      */           public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*   55 */             throw ScriptRuntime.typeErrorById("msg.op.not.allowed", new Object[0]);
/*      */           }
/*      */ 
/*      */           
/*      */           public int getLength() {
/*   60 */             return 0;
/*      */           }
/*      */         };
/*   63 */       setFunctionProtoAndParent(thrower, cx.topCallScope);
/*   64 */       thrower.preventExtensions();
/*   65 */       cx.typeErrorThrower = thrower;
/*      */     } 
/*   67 */     return cx.typeErrorThrower;
/*      */   }
/*      */   
/*      */   static class NoSuchMethodShim implements Callable {
/*      */     String methodName;
/*      */     Callable noSuchMethodMethod;
/*      */     
/*      */     NoSuchMethodShim(Callable noSuchMethodMethod, String methodName) {
/*   75 */       this.noSuchMethodMethod = noSuchMethodMethod;
/*   76 */       this.methodName = methodName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*   89 */       Object[] nestedArgs = new Object[2];
/*      */       
/*   91 */       nestedArgs[0] = this.methodName;
/*   92 */       nestedArgs[1] = ScriptRuntime.newArrayLiteral(args, null, cx, scope);
/*   93 */       return this.noSuchMethodMethod.call(cx, scope, thisObj, nestedArgs);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   public static final Class<?> BooleanClass = Kit.classOrNull("java.lang.Boolean");
/*  107 */   public static final Class<?> ByteClass = Kit.classOrNull("java.lang.Byte");
/*  108 */   public static final Class<?> CharacterClass = Kit.classOrNull("java.lang.Character");
/*  109 */   public static final Class<?> ClassClass = Kit.classOrNull("java.lang.Class");
/*  110 */   public static final Class<?> DoubleClass = Kit.classOrNull("java.lang.Double");
/*  111 */   public static final Class<?> FloatClass = Kit.classOrNull("java.lang.Float");
/*  112 */   public static final Class<?> IntegerClass = Kit.classOrNull("java.lang.Integer");
/*  113 */   public static final Class<?> LongClass = Kit.classOrNull("java.lang.Long");
/*  114 */   public static final Class<?> NumberClass = Kit.classOrNull("java.lang.Number");
/*  115 */   public static final Class<?> ObjectClass = Kit.classOrNull("java.lang.Object");
/*  116 */   public static final Class<?> ShortClass = Kit.classOrNull("java.lang.Short");
/*  117 */   public static final Class<?> StringClass = Kit.classOrNull("java.lang.String");
/*  118 */   public static final Class<?> DateClass = Kit.classOrNull("java.util.Date");
/*  119 */   public static final Class<?> BigIntegerClass = Kit.classOrNull("java.math.BigInteger");
/*  120 */   public static final Class<?> ContextClass = Kit.classOrNull("org.mozilla.javascript.Context");
/*  121 */   public static final Class<?> ContextFactoryClass = Kit.classOrNull("org.mozilla.javascript.ContextFactory");
/*  122 */   public static final Class<?> FunctionClass = Kit.classOrNull("org.mozilla.javascript.Function");
/*  123 */   public static final Class<?> ScriptableObjectClass = Kit.classOrNull("org.mozilla.javascript.ScriptableObject");
/*  124 */   public static final Class<Scriptable> ScriptableClass = Scriptable.class;
/*      */   
/*  126 */   private static final Object LIBRARY_SCOPE_KEY = "LIBRARY_SCOPE"; public static final double NaN = NaND;
/*      */   
/*      */   public static boolean isRhinoRuntimeType(Class<?> cl) {
/*  129 */     if (cl.isPrimitive()) {
/*  130 */       return (cl != char.class);
/*      */     }
/*  132 */     return (cl == StringClass || cl == BooleanClass || NumberClass
/*      */       
/*  134 */       .isAssignableFrom(cl) || ScriptableClass
/*  135 */       .isAssignableFrom(cl));
/*      */   }
/*      */ 
/*      */   
/*      */   public static ScriptableObject initSafeStandardObjects(Context cx, ScriptableObject scope, boolean sealed) {
/*  140 */     if (scope == null) {
/*  141 */       scope = new NativeObject();
/*  142 */     } else if (scope instanceof TopLevel) {
/*  143 */       ((TopLevel)scope).clearCache();
/*      */     } 
/*      */     
/*  146 */     scope.associateValue(LIBRARY_SCOPE_KEY, scope);
/*  147 */     (new ClassCache()).associate(scope);
/*      */     
/*  149 */     BaseFunction.init(scope, sealed);
/*  150 */     NativeObject.init(scope, sealed);
/*      */     
/*  152 */     Scriptable objectProto = ScriptableObject.getObjectPrototype(scope);
/*      */ 
/*      */     
/*  155 */     Scriptable functionProto = ScriptableObject.getClassPrototype(scope, "Function");
/*  156 */     functionProto.setPrototype(objectProto);
/*      */ 
/*      */     
/*  159 */     if (scope.getPrototype() == null) scope.setPrototype(objectProto);
/*      */ 
/*      */     
/*  162 */     NativeError.init(scope, sealed);
/*  163 */     NativeGlobal.init(cx, scope, sealed);
/*      */     
/*  165 */     NativeArray.init(scope, sealed);
/*  166 */     if (cx.getOptimizationLevel() > 0)
/*      */     {
/*      */ 
/*      */       
/*  170 */       NativeArray.setMaximumInitialCapacity(200000);
/*      */     }
/*  172 */     NativeString.init(scope, sealed);
/*  173 */     NativeBoolean.init(scope, sealed);
/*  174 */     NativeNumber.init(scope, sealed);
/*  175 */     NativeDate.init(scope, sealed);
/*  176 */     NativeMath.init(scope, sealed);
/*  177 */     NativeJSON.init(scope, sealed);
/*      */     
/*  179 */     NativeWith.init(scope, sealed);
/*  180 */     NativeCall.init(scope, sealed);
/*  181 */     NativeScript.init(scope, sealed);
/*      */     
/*  183 */     NativeIterator.init(cx, scope, sealed);
/*      */     
/*  185 */     NativeArrayIterator.init(scope, sealed);
/*  186 */     NativeStringIterator.init(scope, sealed);
/*      */     
/*  188 */     NativeJavaObject.init(scope, sealed);
/*  189 */     NativeJavaMap.init(scope, sealed);
/*      */ 
/*      */     
/*  192 */     boolean withXml = (cx.hasFeature(6) && cx.getE4xImplementationFactory() != null);
/*      */ 
/*      */     
/*  195 */     new LazilyLoadedCtor(scope, "RegExp", "org.mozilla.javascript.regexp.NativeRegExp", sealed, true);
/*      */     
/*  197 */     new LazilyLoadedCtor(scope, "Continuation", "org.mozilla.javascript.NativeContinuation", sealed, true);
/*      */ 
/*      */     
/*  200 */     if (withXml) {
/*  201 */       String xmlImpl = cx.getE4xImplementationFactory().getImplementationClassName();
/*  202 */       new LazilyLoadedCtor(scope, "XML", xmlImpl, sealed, true);
/*  203 */       new LazilyLoadedCtor(scope, "XMLList", xmlImpl, sealed, true);
/*  204 */       new LazilyLoadedCtor(scope, "Namespace", xmlImpl, sealed, true);
/*  205 */       new LazilyLoadedCtor(scope, "QName", xmlImpl, sealed, true);
/*      */     } 
/*      */     
/*  208 */     if ((cx.getLanguageVersion() >= 180 && cx
/*  209 */       .hasFeature(14)) || cx
/*  210 */       .getLanguageVersion() >= 200) {
/*  211 */       new LazilyLoadedCtor(scope, "ArrayBuffer", "org.mozilla.javascript.typedarrays.NativeArrayBuffer", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  217 */       new LazilyLoadedCtor(scope, "Int8Array", "org.mozilla.javascript.typedarrays.NativeInt8Array", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  223 */       new LazilyLoadedCtor(scope, "Uint8Array", "org.mozilla.javascript.typedarrays.NativeUint8Array", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  229 */       new LazilyLoadedCtor(scope, "Uint8ClampedArray", "org.mozilla.javascript.typedarrays.NativeUint8ClampedArray", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  235 */       new LazilyLoadedCtor(scope, "Int16Array", "org.mozilla.javascript.typedarrays.NativeInt16Array", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  241 */       new LazilyLoadedCtor(scope, "Uint16Array", "org.mozilla.javascript.typedarrays.NativeUint16Array", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  247 */       new LazilyLoadedCtor(scope, "Int32Array", "org.mozilla.javascript.typedarrays.NativeInt32Array", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  253 */       new LazilyLoadedCtor(scope, "Uint32Array", "org.mozilla.javascript.typedarrays.NativeUint32Array", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  259 */       new LazilyLoadedCtor(scope, "Float32Array", "org.mozilla.javascript.typedarrays.NativeFloat32Array", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  265 */       new LazilyLoadedCtor(scope, "Float64Array", "org.mozilla.javascript.typedarrays.NativeFloat64Array", sealed, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  271 */       new LazilyLoadedCtor(scope, "DataView", "org.mozilla.javascript.typedarrays.NativeDataView", sealed, true);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  279 */     if (cx.getLanguageVersion() >= 200) {
/*  280 */       NativeSymbol.init(cx, scope, sealed);
/*  281 */       NativeCollectionIterator.init(scope, "Set Iterator", sealed);
/*  282 */       NativeCollectionIterator.init(scope, "Map Iterator", sealed);
/*  283 */       NativeMap.init(cx, scope, sealed);
/*  284 */       NativePromise.init(cx, scope, sealed);
/*  285 */       NativeSet.init(cx, scope, sealed);
/*  286 */       NativeWeakMap.init(scope, sealed);
/*  287 */       NativeWeakSet.init(scope, sealed);
/*  288 */       NativeBigInt.init(scope, sealed);
/*      */     } 
/*      */     
/*  291 */     if (scope instanceof TopLevel) {
/*  292 */       ((TopLevel)scope).cacheBuiltins(scope, sealed);
/*      */     }
/*      */     
/*  295 */     return scope;
/*      */   }
/*      */ 
/*      */   
/*      */   public static ScriptableObject initStandardObjects(Context cx, ScriptableObject scope, boolean sealed) {
/*  300 */     ScriptableObject s = initSafeStandardObjects(cx, scope, sealed);
/*      */     
/*  302 */     new LazilyLoadedCtor(s, "Packages", "org.mozilla.javascript.NativeJavaTopPackage", sealed, true);
/*      */     
/*  304 */     new LazilyLoadedCtor(s, "getClass", "org.mozilla.javascript.NativeJavaTopPackage", sealed, true);
/*      */     
/*  306 */     new LazilyLoadedCtor(s, "JavaAdapter", "org.mozilla.javascript.JavaAdapter", sealed, true);
/*  307 */     new LazilyLoadedCtor(s, "JavaImporter", "org.mozilla.javascript.ImporterTopLevel", sealed, true);
/*      */ 
/*      */     
/*  310 */     for (String packageName : getTopPackageNames()) {
/*  311 */       new LazilyLoadedCtor(s, packageName, "org.mozilla.javascript.NativeJavaTopPackage", sealed, true);
/*      */     }
/*      */ 
/*      */     
/*  315 */     return s;
/*      */   }
/*      */ 
/*      */   
/*      */   static String[] getTopPackageNames() {
/*  320 */     (new String[7])[0] = "java"; (new String[7])[1] = "javax"; (new String[7])[2] = "org"; (new String[7])[3] = "com"; (new String[7])[4] = "edu"; (new String[7])[5] = "net"; (new String[7])[6] = "android"; (new String[6])[0] = "java"; (new String[6])[1] = "javax"; (new String[6])[2] = "org"; (new String[6])[3] = "com"; (new String[6])[4] = "edu"; (new String[6])[5] = "net"; return "Dalvik".equals(System.getProperty("java.vm.name")) ? new String[7] : new String[6];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ScriptableObject getLibraryScopeOrNull(Scriptable scope) {
/*  327 */     ScriptableObject libScope = (ScriptableObject)ScriptableObject.getTopScopeValue(scope, LIBRARY_SCOPE_KEY);
/*  328 */     return libScope;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJSLineTerminator(int c) {
/*  335 */     if ((c & 0xDFD0) != 0) {
/*  336 */       return false;
/*      */     }
/*  338 */     return (c == 10 || c == 13 || c == 8232 || c == 8233);
/*      */   }
/*      */   
/*      */   public static boolean isJSWhitespaceOrLineTerminator(int c) {
/*  342 */     return (isStrWhiteSpaceChar(c) || isJSLineTerminator(c));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isStrWhiteSpaceChar(int c) {
/*  350 */     switch (c) {
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 32:
/*      */       case 160:
/*      */       case 8232:
/*      */       case 8233:
/*      */       case 65279:
/*  361 */         return true;
/*      */     } 
/*  363 */     return (Character.getType(c) == 12);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Boolean wrapBoolean(boolean b) {
/*  368 */     return Boolean.valueOf(b);
/*      */   }
/*      */   
/*      */   public static Integer wrapInt(int i) {
/*  372 */     return Integer.valueOf(i);
/*      */   }
/*      */   
/*      */   public static Number wrapNumber(double x) {
/*  376 */     if (Double.isNaN(x)) {
/*  377 */       return NaNobj;
/*      */     }
/*  379 */     return Double.valueOf(x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean toBoolean(Object val) {
/*      */     while (true) {
/*  389 */       if (val instanceof Boolean) return ((Boolean)val).booleanValue(); 
/*  390 */       if (val == null || Undefined.isUndefined(val)) return false; 
/*  391 */       if (val instanceof CharSequence) return (((CharSequence)val).length() != 0); 
/*  392 */       if (val instanceof BigInteger) {
/*  393 */         return !((BigInteger)val).equals(BigInteger.ZERO);
/*      */       }
/*  395 */       if (val instanceof Number) {
/*  396 */         double d = ((Number)val).doubleValue();
/*  397 */         return (!Double.isNaN(d) && d != 0.0D);
/*      */       } 
/*  399 */       if (val instanceof Scriptable) {
/*  400 */         if (val instanceof ScriptableObject && ((ScriptableObject)val)
/*  401 */           .avoidObjectDetection()) {
/*  402 */           return false;
/*      */         }
/*  404 */         if (Context.getContext().isVersionECMA1())
/*      */         {
/*  406 */           return true;
/*      */         }
/*      */         
/*  409 */         val = ((Scriptable)val).getDefaultValue(BooleanClass);
/*  410 */         if (val instanceof Scriptable && !isSymbol(val))
/*  411 */           throw errorWithClassName("msg.primitive.expected", val);  continue;
/*      */       }  break;
/*      */     } 
/*  414 */     warnAboutNonJSObject(val);
/*  415 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toNumber(Object val) {
/*      */     while (true) {
/*  426 */       if (val instanceof BigInteger) {
/*  427 */         throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */       }
/*  429 */       if (val instanceof Number) return ((Number)val).doubleValue(); 
/*  430 */       if (val == null) return 0.0D; 
/*  431 */       if (Undefined.isUndefined(val)) return Double.NaN; 
/*  432 */       if (val instanceof String) return toNumber((String)val); 
/*  433 */       if (val instanceof CharSequence) return toNumber(val.toString()); 
/*  434 */       if (val instanceof Boolean) return ((Boolean)val).booleanValue() ? 1.0D : 0.0D; 
/*  435 */       if (val instanceof Symbol) throw typeErrorById("msg.not.a.number", new Object[0]); 
/*  436 */       if (val instanceof Scriptable) {
/*  437 */         val = ((Scriptable)val).getDefaultValue(NumberClass);
/*  438 */         if (val instanceof Scriptable && !isSymbol(val))
/*  439 */           throw errorWithClassName("msg.primitive.expected", val);  continue;
/*      */       }  break;
/*      */     } 
/*  442 */     warnAboutNonJSObject(val);
/*  443 */     return Double.NaN;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double toNumber(Object[] args, int index) {
/*  448 */     return (index < args.length) ? toNumber(args[index]) : Double.NaN;
/*      */   }
/*      */ 
/*      */   
/*  452 */   public static final Double NaNobj = Double.valueOf(Double.NaN);
/*      */ 
/*      */   
/*  455 */   public static final double negativeZero = Double.longBitsToDouble(Long.MIN_VALUE);
/*      */   
/*  457 */   public static final Double zeroObj = Double.valueOf(0.0D);
/*  458 */   public static final Double negativeZeroObj = Double.valueOf(-0.0D); private static final String DEFAULT_NS_TAG = "__default_namespace__"; public static final int ENUMERATE_KEYS = 0; public static final int ENUMERATE_VALUES = 1; public static final int ENUMERATE_ARRAY = 2;
/*      */   
/*      */   static double stringPrefixToNumber(String s, int start, int radix) {
/*  461 */     return stringToNumber(s, start, s.length() - 1, radix, true);
/*      */   }
/*      */   public static final int ENUMERATE_KEYS_NO_ITERATOR = 3; public static final int ENUMERATE_VALUES_NO_ITERATOR = 4; public static final int ENUMERATE_ARRAY_NO_ITERATOR = 5; public static final int ENUMERATE_VALUES_IN_ORDER = 6;
/*      */   static double stringToNumber(String s, int start, int end, int radix) {
/*  465 */     return stringToNumber(s, start, end, radix, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double stringToNumber(String source, int sourceStart, int sourceEnd, int radix, boolean isPrefix) {
/*  473 */     char digitMax = '9';
/*  474 */     char lowerCaseBound = 'a';
/*  475 */     char upperCaseBound = 'A';
/*  476 */     if (radix < 10) {
/*  477 */       digitMax = (char)(48 + radix - 1);
/*      */     }
/*  479 */     if (radix > 10) {
/*  480 */       lowerCaseBound = (char)(97 + radix - 10);
/*  481 */       upperCaseBound = (char)(65 + radix - 10);
/*      */     } 
/*      */     
/*  484 */     double sum = 0.0D; int end;
/*  485 */     for (end = sourceStart; end <= sourceEnd; end++) {
/*  486 */       int newDigit; char c = source.charAt(end);
/*      */       
/*  488 */       if ('0' <= c && c <= digitMax) { newDigit = c - 48; }
/*  489 */       else if ('a' <= c && c < lowerCaseBound) { newDigit = c - 97 + 10; }
/*  490 */       else if ('A' <= c && c < upperCaseBound) { newDigit = c - 65 + 10; }
/*  491 */       else { if (!isPrefix) return Double.NaN;  break; }
/*      */       
/*  493 */       sum = sum * radix + newDigit;
/*      */     } 
/*  495 */     if (sourceStart == end) {
/*  496 */       return Double.NaN;
/*      */     }
/*  498 */     if (sum > 9.007199254740991E15D) {
/*  499 */       if (radix == 10)
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  506 */           return Double.parseDouble(source.substring(sourceStart, end));
/*  507 */         } catch (NumberFormatException nfe) {
/*  508 */           return Double.NaN;
/*      */         }  
/*  510 */       if (radix == 2 || radix == 4 || radix == 8 || radix == 16 || radix == 32) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  521 */         int bitShiftInChar = 1;
/*  522 */         int digit = 0;
/*      */         
/*  524 */         int SKIP_LEADING_ZEROS = 0;
/*  525 */         int FIRST_EXACT_53_BITS = 1;
/*  526 */         int AFTER_BIT_53 = 2;
/*  527 */         int ZEROS_AFTER_54 = 3;
/*  528 */         int MIXED_AFTER_54 = 4;
/*      */         
/*  530 */         int state = 0;
/*  531 */         int exactBitsLimit = 53;
/*  532 */         double factor = 0.0D;
/*  533 */         boolean bit53 = false;
/*      */         
/*  535 */         boolean bit54 = false;
/*  536 */         int pos = sourceStart;
/*      */         while (true) {
/*      */           int newDigit;
/*  539 */           if (bitShiftInChar == 1) {
/*  540 */             if (pos == end)
/*  541 */               break;  newDigit = source.charAt(pos++);
/*  542 */             if (48 <= newDigit && newDigit <= 57) { newDigit -= 48; }
/*  543 */             else if (97 <= newDigit && newDigit <= 122) { newDigit -= 87; }
/*  544 */             else { newDigit -= 55; }
/*  545 */              bitShiftInChar = radix;
/*      */           } 
/*  547 */           bitShiftInChar >>= 1;
/*  548 */           boolean bit = ((newDigit & bitShiftInChar) != 0);
/*      */           
/*  550 */           switch (state) {
/*      */             case 0:
/*  552 */               if (bit) {
/*  553 */                 exactBitsLimit--;
/*  554 */                 sum = 1.0D;
/*  555 */                 state = 1;
/*      */               } 
/*      */             
/*      */             case 1:
/*  559 */               sum *= 2.0D;
/*  560 */               if (bit) sum++; 
/*  561 */               exactBitsLimit--;
/*  562 */               if (exactBitsLimit == 0) {
/*  563 */                 bit53 = bit;
/*  564 */                 state = 2;
/*      */               } 
/*      */             
/*      */             case 2:
/*  568 */               bit54 = bit;
/*  569 */               factor = 2.0D;
/*  570 */               state = 3;
/*      */             
/*      */             case 3:
/*  573 */               if (bit) {
/*  574 */                 state = 4;
/*      */               }
/*      */             
/*      */             case 4:
/*  578 */               factor *= 2.0D;
/*      */           } 
/*      */         
/*      */         } 
/*  582 */         switch (state) {
/*      */           case 0:
/*  584 */             sum = 0.0D;
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 3:
/*  593 */             if (bit54 & bit53) sum++; 
/*  594 */             sum *= factor;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 4:
/*  599 */             if (bit54) sum++; 
/*  600 */             sum *= factor;
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/*      */     } 
/*  606 */     return sum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toNumber(String s) {
/*      */     char startChar;
/*  615 */     int len = s.length();
/*      */ 
/*      */     
/*  618 */     int start = 0;
/*      */     
/*      */     while (true) {
/*  621 */       if (start == len)
/*      */       {
/*  623 */         return 0.0D;
/*      */       }
/*  625 */       startChar = s.charAt(start);
/*  626 */       if (!isStrWhiteSpaceChar(startChar)) {
/*      */         break;
/*      */       }
/*      */       
/*  630 */       start++;
/*      */     } 
/*      */ 
/*      */     
/*  634 */     int end = len - 1;
/*      */     char endChar;
/*  636 */     while (isStrWhiteSpaceChar(endChar = s.charAt(end))) {
/*  637 */       end--;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  649 */     Context cx = Context.getCurrentContext();
/*  650 */     boolean oldParsingMode = (cx == null || cx.getLanguageVersion() < 200);
/*      */ 
/*      */     
/*  653 */     if (startChar == '0') {
/*  654 */       if (start + 2 <= end) {
/*  655 */         char radixC = s.charAt(start + 1);
/*  656 */         int radix = -1;
/*  657 */         if (radixC == 'x' || radixC == 'X') {
/*  658 */           radix = 16;
/*  659 */         } else if (!oldParsingMode && (radixC == 'o' || radixC == 'O')) {
/*  660 */           radix = 8;
/*  661 */         } else if (!oldParsingMode && (radixC == 'b' || radixC == 'B')) {
/*  662 */           radix = 2;
/*      */         } 
/*  664 */         if (radix != -1) {
/*  665 */           if (oldParsingMode) {
/*  666 */             return stringPrefixToNumber(s, start + 2, radix);
/*      */           }
/*  668 */           return stringToNumber(s, start + 2, end, radix);
/*      */         } 
/*      */       } 
/*  671 */     } else if (oldParsingMode && (startChar == '+' || startChar == '-')) {
/*      */       
/*  673 */       if (start + 3 <= end && s.charAt(start + 1) == '0') {
/*  674 */         char radixC = s.charAt(start + 2);
/*  675 */         if (radixC == 'x' || radixC == 'X') {
/*  676 */           double val = stringPrefixToNumber(s, start + 3, 16);
/*  677 */           return (startChar == '-') ? -val : val;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  682 */     if (endChar == 'y') {
/*      */       
/*  684 */       if (startChar == '+' || startChar == '-') {
/*  685 */         start++;
/*      */       }
/*  687 */       if (start + 7 == end && s.regionMatches(start, "Infinity", 0, 8)) {
/*  688 */         return (startChar == '-') ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY;
/*      */       }
/*  690 */       return Double.NaN;
/*      */     } 
/*      */ 
/*      */     
/*  694 */     String sub = s.substring(start, end + 1);
/*      */ 
/*      */     
/*  697 */     for (int i = sub.length() - 1; i >= 0; ) {
/*  698 */       char c = sub.charAt(i);
/*  699 */       if (('0' <= c && c <= '9') || c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-') {
/*      */         i--; continue;
/*  701 */       }  return Double.NaN;
/*      */     } 
/*      */     try {
/*  704 */       return Double.parseDouble(sub);
/*  705 */     } catch (NumberFormatException ex) {
/*  706 */       return Double.NaN;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static BigInteger toBigInt(Object val) {
/*      */     while (true) {
/*  713 */       if (val instanceof BigInteger) {
/*  714 */         return (BigInteger)val;
/*      */       }
/*  716 */       if (val instanceof BigDecimal) {
/*  717 */         return ((BigDecimal)val).toBigInteger();
/*      */       }
/*  719 */       if (val instanceof Number) {
/*  720 */         if (val instanceof Long) {
/*  721 */           return BigInteger.valueOf(((Long)val).longValue());
/*      */         }
/*  723 */         double d = ((Number)val).doubleValue();
/*  724 */         if (Double.isNaN(d) || Double.isInfinite(d))
/*  725 */           throw rangeErrorById("msg.cant.convert.to.bigint.isnt.integer", new Object[] {
/*  726 */                 toString(val)
/*      */               }); 
/*  728 */         BigDecimal bd = new BigDecimal(d, MathContext.UNLIMITED);
/*      */         try {
/*  730 */           return bd.toBigIntegerExact();
/*  731 */         } catch (ArithmeticException e) {
/*  732 */           throw rangeErrorById("msg.cant.convert.to.bigint.isnt.integer", new Object[] {
/*  733 */                 toString(val)
/*      */               });
/*      */         } 
/*      */       } 
/*  737 */       if (val == null || Undefined.isUndefined(val)) {
/*  738 */         throw typeErrorById("msg.cant.convert.to.bigint", new Object[] { toString(val) });
/*      */       }
/*  740 */       if (val instanceof String) {
/*  741 */         return toBigInt((String)val);
/*      */       }
/*  743 */       if (val instanceof CharSequence) {
/*  744 */         return toBigInt(val.toString());
/*      */       }
/*  746 */       if (val instanceof Boolean) {
/*  747 */         return ((Boolean)val).booleanValue() ? BigInteger.ONE : BigInteger.ZERO;
/*      */       }
/*  749 */       if (val instanceof Symbol) {
/*  750 */         throw typeErrorById("msg.cant.convert.to.bigint", new Object[] { toString(val) });
/*      */       }
/*  752 */       if (val instanceof Scriptable) {
/*  753 */         val = ((Scriptable)val).getDefaultValue(BigIntegerClass);
/*  754 */         if (val instanceof Scriptable && !isSymbol(val))
/*  755 */           throw errorWithClassName("msg.primitive.expected", val);  continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  759 */     warnAboutNonJSObject(val);
/*  760 */     return BigInteger.ZERO;
/*      */   }
/*      */ 
/*      */   
/*      */   public static BigInteger toBigInt(String s) {
/*      */     char startChar;
/*  766 */     int len = s.length();
/*      */ 
/*      */     
/*  769 */     int start = 0;
/*      */     
/*      */     while (true) {
/*  772 */       if (start == len)
/*      */       {
/*  774 */         return BigInteger.ZERO;
/*      */       }
/*  776 */       startChar = s.charAt(start);
/*  777 */       if (!isStrWhiteSpaceChar(startChar)) {
/*      */         break;
/*      */       }
/*      */       
/*  781 */       start++;
/*      */     } 
/*      */ 
/*      */     
/*  785 */     int end = len - 1;
/*  786 */     while (isStrWhiteSpaceChar(s.charAt(end))) {
/*  787 */       end--;
/*      */     }
/*      */ 
/*      */     
/*  791 */     if (startChar == '0' && 
/*  792 */       start + 2 <= end) {
/*  793 */       char radixC = s.charAt(start + 1);
/*  794 */       int radix = -1;
/*  795 */       if (radixC == 'x' || radixC == 'X') {
/*  796 */         radix = 16;
/*  797 */       } else if (radixC == 'o' || radixC == 'O') {
/*  798 */         radix = 8;
/*  799 */       } else if (radixC == 'b' || radixC == 'B') {
/*  800 */         radix = 2;
/*      */       } 
/*  802 */       if (radix != -1) {
/*      */         try {
/*  804 */           return new BigInteger(s.substring(start + 2, end + 1), radix);
/*  805 */         } catch (NumberFormatException ex) {
/*  806 */           throw syntaxErrorById("msg.bigint.bad.form", new Object[0]);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  814 */     String sub = s.substring(start, end + 1);
/*  815 */     for (int i = sub.length() - 1; i >= 0; i--) {
/*  816 */       char c = sub.charAt(i);
/*  817 */       if (i != 0 || (c != '+' && c != '-'))
/*      */       {
/*      */         
/*  820 */         if ('0' > c || c > '9')
/*      */         {
/*      */           
/*  823 */           throw syntaxErrorById("msg.bigint.bad.form", new Object[0]); }  } 
/*      */     } 
/*      */     try {
/*  826 */       return new BigInteger(sub);
/*  827 */     } catch (NumberFormatException ex) {
/*  828 */       throw syntaxErrorById("msg.bigint.bad.form", new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Number toNumeric(Object val) {
/*  840 */     if (val instanceof Number) {
/*  841 */       return (Number)val;
/*      */     }
/*  843 */     return Double.valueOf(toNumber(val));
/*      */   }
/*      */   
/*      */   public static int toIndex(Object val) {
/*  847 */     if (Undefined.isUndefined(val)) {
/*  848 */       return 0;
/*      */     }
/*  850 */     double integerIndex = toInteger(val);
/*  851 */     if (integerIndex < 0.0D) {
/*  852 */       throw rangeError("index out of range");
/*      */     }
/*      */     
/*  855 */     double index = Math.min(integerIndex, 9.007199254740991E15D);
/*  856 */     if (integerIndex != index) {
/*  857 */       throw rangeError("index out of range");
/*      */     }
/*  859 */     return (int)index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] padArguments(Object[] args, int count) {
/*  868 */     if (count < args.length) return args;
/*      */     
/*  870 */     Object[] result = new Object[count];
/*  871 */     System.arraycopy(args, 0, result, 0, args.length);
/*  872 */     if (args.length < count) {
/*  873 */       Arrays.fill(result, args.length, count, Undefined.instance);
/*      */     }
/*  875 */     return result;
/*      */   }
/*      */   
/*      */   public static String escapeString(String s) {
/*  879 */     return escapeString(s, '"');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String escapeString(String s, char escapeQuote) {
/*  886 */     if (escapeQuote != '"' && escapeQuote != '\'') Kit.codeBug(); 
/*  887 */     StringBuilder sb = null;
/*      */     
/*  889 */     for (int i = 0, L = s.length(); i != L; i++) {
/*  890 */       int c = s.charAt(i);
/*      */       
/*  892 */       if (32 <= c && c <= 126 && c != escapeQuote && c != 92) {
/*      */ 
/*      */         
/*  895 */         if (sb != null) {
/*  896 */           sb.append((char)c);
/*      */         }
/*      */       } else {
/*      */         
/*  900 */         if (sb == null) {
/*  901 */           sb = new StringBuilder(L + 3);
/*  902 */           sb.append(s);
/*  903 */           sb.setLength(i);
/*      */         } 
/*      */         
/*  906 */         int escape = -1;
/*  907 */         switch (c) {
/*      */           case 8:
/*  909 */             escape = 98;
/*      */             break;
/*      */           case 12:
/*  912 */             escape = 102;
/*      */             break;
/*      */           case 10:
/*  915 */             escape = 110;
/*      */             break;
/*      */           case 13:
/*  918 */             escape = 114;
/*      */             break;
/*      */           case 9:
/*  921 */             escape = 116;
/*      */             break;
/*      */           case 11:
/*  924 */             escape = 118;
/*      */             break;
/*      */           case 32:
/*  927 */             escape = 32;
/*      */             break;
/*      */           case 92:
/*  930 */             escape = 92;
/*      */             break;
/*      */         } 
/*  933 */         if (escape >= 0) {
/*      */           
/*  935 */           sb.append('\\');
/*  936 */           sb.append((char)escape);
/*  937 */         } else if (c == escapeQuote) {
/*  938 */           sb.append('\\');
/*  939 */           sb.append(escapeQuote);
/*      */         } else {
/*      */           int hexSize;
/*  942 */           if (c < 256) {
/*      */             
/*  944 */             sb.append("\\x");
/*  945 */             hexSize = 2;
/*      */           } else {
/*      */             
/*  948 */             sb.append("\\u");
/*  949 */             hexSize = 4;
/*      */           } 
/*      */           
/*  952 */           for (int shift = (hexSize - 1) * 4; shift >= 0; shift -= 4) {
/*  953 */             int digit = 0xF & c >> shift;
/*  954 */             int hc = (digit < 10) ? (48 + digit) : (87 + digit);
/*  955 */             sb.append((char)hc);
/*      */           } 
/*      */         } 
/*      */       } 
/*  959 */     }  return (sb == null) ? s : sb.toString();
/*      */   }
/*      */   
/*      */   static boolean isValidIdentifierName(String s, Context cx, boolean isStrict) {
/*  963 */     int L = s.length();
/*  964 */     if (L == 0) return false; 
/*  965 */     if (!Character.isJavaIdentifierStart(s.charAt(0))) return false; 
/*  966 */     for (int i = 1; i != L; i++) {
/*  967 */       if (!Character.isJavaIdentifierPart(s.charAt(i))) return false; 
/*      */     } 
/*  969 */     return !TokenStream.isKeyword(s, cx.getLanguageVersion(), isStrict);
/*      */   }
/*      */   
/*      */   public static CharSequence toCharSequence(Object val) {
/*  973 */     if (val instanceof NativeString) {
/*  974 */       return ((NativeString)val).toCharSequence();
/*      */     }
/*  976 */     return (val instanceof CharSequence) ? (CharSequence)val : toString(val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(Object val) {
/*      */     while (true) {
/*  986 */       if (val == null) {
/*  987 */         return "null";
/*      */       }
/*  989 */       if (Undefined.isUndefined(val)) {
/*  990 */         return "undefined";
/*      */       }
/*  992 */       if (val instanceof String) {
/*  993 */         return (String)val;
/*      */       }
/*  995 */       if (val instanceof CharSequence) {
/*  996 */         return val.toString();
/*      */       }
/*  998 */       if (val instanceof BigInteger) {
/*  999 */         return val.toString();
/*      */       }
/* 1001 */       if (val instanceof Number)
/*      */       {
/*      */         
/* 1004 */         return numberToString(((Number)val).doubleValue(), 10);
/*      */       }
/* 1006 */       if (val instanceof Symbol) {
/* 1007 */         throw typeErrorById("msg.not.a.string", new Object[0]);
/*      */       }
/* 1009 */       if (val instanceof Scriptable) {
/* 1010 */         val = ((Scriptable)val).getDefaultValue(StringClass);
/* 1011 */         if (val instanceof Scriptable && !isSymbol(val))
/* 1012 */           throw errorWithClassName("msg.primitive.expected", val);  continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 1016 */     return val.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   static String defaultObjectToString(Scriptable obj) {
/* 1021 */     if (obj == null) return "[object Null]"; 
/* 1022 */     if (Undefined.isUndefined(obj)) return "[object Undefined]"; 
/* 1023 */     return "[object " + obj.getClassName() + ']';
/*      */   }
/*      */   
/*      */   public static String toString(Object[] args, int index) {
/* 1027 */     return (index < args.length) ? toString(args[index]) : "undefined";
/*      */   }
/*      */ 
/*      */   
/*      */   public static String toString(double val) {
/* 1032 */     return numberToString(val, 10);
/*      */   }
/*      */   
/*      */   public static String numberToString(double d, int base) {
/* 1036 */     if (base < 2 || base > 36) {
/* 1037 */       throw Context.reportRuntimeErrorById("msg.bad.radix", new Object[] { Integer.toString(base) });
/*      */     }
/*      */     
/* 1040 */     if (Double.isNaN(d)) return "NaN"; 
/* 1041 */     if (d == Double.POSITIVE_INFINITY) return "Infinity"; 
/* 1042 */     if (d == Double.NEGATIVE_INFINITY) return "-Infinity"; 
/* 1043 */     if (d == 0.0D) return "0";
/*      */     
/* 1045 */     if (base != 10) {
/* 1046 */       return DToA.JS_dtobasestr(base, d);
/*      */     }
/*      */ 
/*      */     
/* 1050 */     String result = FastDtoa.numberToString(d);
/* 1051 */     if (result != null) {
/* 1052 */       return result;
/*      */     }
/* 1054 */     StringBuilder buffer = new StringBuilder();
/* 1055 */     DToA.JS_dtostr(buffer, 0, 0, d);
/* 1056 */     return buffer.toString();
/*      */   }
/*      */   
/*      */   public static String bigIntToString(BigInteger n, int base) {
/* 1060 */     if (base < 2 || base > 36) {
/* 1061 */       throw rangeErrorById("msg.bad.radix", new Object[] { Integer.toString(base) });
/*      */     }
/*      */     
/* 1064 */     return n.toString(base);
/*      */   }
/*      */   
/*      */   static String uneval(Context cx, Scriptable scope, Object value) {
/* 1068 */     if (value == null) {
/* 1069 */       return "null";
/*      */     }
/* 1071 */     if (Undefined.isUndefined(value)) {
/* 1072 */       return "undefined";
/*      */     }
/* 1074 */     if (value instanceof CharSequence) {
/* 1075 */       String escaped = escapeString(value.toString());
/* 1076 */       StringBuilder sb = new StringBuilder(escaped.length() + 2);
/* 1077 */       sb.append('"');
/* 1078 */       sb.append(escaped);
/* 1079 */       sb.append('"');
/* 1080 */       return sb.toString();
/*      */     } 
/* 1082 */     if (value instanceof Number) {
/* 1083 */       double d = ((Number)value).doubleValue();
/* 1084 */       if (d == 0.0D && 1.0D / d < 0.0D) {
/* 1085 */         return "-0";
/*      */       }
/* 1087 */       return toString(d);
/*      */     } 
/* 1089 */     if (value instanceof Boolean) {
/* 1090 */       return toString(value);
/*      */     }
/* 1092 */     if (value instanceof Scriptable) {
/* 1093 */       Scriptable obj = (Scriptable)value;
/*      */ 
/*      */       
/* 1096 */       if (ScriptableObject.hasProperty(obj, "toSource")) {
/* 1097 */         Object v = ScriptableObject.getProperty(obj, "toSource");
/* 1098 */         if (v instanceof Function) {
/* 1099 */           Function f = (Function)v;
/* 1100 */           return toString(f.call(cx, scope, obj, emptyArgs));
/*      */         } 
/*      */       } 
/* 1103 */       return toString(value);
/*      */     } 
/* 1105 */     warnAboutNonJSObject(value);
/* 1106 */     return value.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   static String defaultObjectToSource(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*      */     boolean toplevel, iterating;
/* 1112 */     if (cx.iterating == null) {
/* 1113 */       toplevel = true;
/* 1114 */       iterating = false;
/* 1115 */       cx.iterating = new ObjToIntMap(31);
/*      */     } else {
/* 1117 */       toplevel = false;
/* 1118 */       iterating = cx.iterating.has(thisObj);
/*      */     } 
/*      */     
/* 1121 */     StringBuilder result = new StringBuilder(128);
/* 1122 */     if (toplevel) {
/* 1123 */       result.append("(");
/*      */     }
/* 1125 */     result.append('{');
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1130 */       if (!iterating) {
/* 1131 */         cx.iterating.intern(thisObj);
/* 1132 */         Object[] ids = thisObj.getIds();
/* 1133 */         for (int i = 0; i < ids.length; i++) {
/* 1134 */           Object value, id = ids[i];
/*      */           
/* 1136 */           if (id instanceof Integer) {
/* 1137 */             int intId = ((Integer)id).intValue();
/* 1138 */             value = thisObj.get(intId, thisObj);
/* 1139 */             if (value == Scriptable.NOT_FOUND)
/* 1140 */               continue;  if (i > 0) result.append(", "); 
/* 1141 */             result.append(intId);
/*      */           } else {
/* 1143 */             String strId = (String)id;
/* 1144 */             value = thisObj.get(strId, thisObj);
/* 1145 */             if (value == Scriptable.NOT_FOUND)
/* 1146 */               continue;  if (i > 0) result.append(", "); 
/* 1147 */             if (isValidIdentifierName(strId, cx, cx.isStrictMode())) {
/* 1148 */               result.append(strId);
/*      */             } else {
/* 1150 */               result.append('\'');
/* 1151 */               result.append(escapeString(strId, '\''));
/* 1152 */               result.append('\'');
/*      */             } 
/*      */           } 
/* 1155 */           result.append(':');
/* 1156 */           result.append(uneval(cx, scope, value)); continue;
/*      */         } 
/*      */       } 
/*      */     } finally {
/* 1160 */       if (toplevel) {
/* 1161 */         cx.iterating = null;
/*      */       }
/*      */     } 
/*      */     
/* 1165 */     result.append('}');
/* 1166 */     if (toplevel) {
/* 1167 */       result.append(')');
/*      */     }
/* 1169 */     return result.toString();
/*      */   }
/*      */   
/*      */   public static Scriptable toObject(Scriptable scope, Object val) {
/* 1173 */     if (val instanceof Scriptable) {
/* 1174 */       return (Scriptable)val;
/*      */     }
/* 1176 */     return toObject(Context.getContext(), scope, val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scriptable toObjectOrNull(Context cx, Object obj) {
/* 1187 */     if (obj instanceof Scriptable)
/* 1188 */       return (Scriptable)obj; 
/* 1189 */     if (obj != null && !Undefined.isUndefined(obj)) {
/* 1190 */       return toObject(cx, getTopCallScope(cx), obj);
/*      */     }
/* 1192 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable toObjectOrNull(Context cx, Object obj, Scriptable scope) {
/* 1197 */     if (obj instanceof Scriptable)
/* 1198 */       return (Scriptable)obj; 
/* 1199 */     if (obj != null && !Undefined.isUndefined(obj)) {
/* 1200 */       return toObject(cx, scope, obj);
/*      */     }
/* 1202 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scriptable toObject(Scriptable scope, Object val, Class<?> staticClass) {
/* 1208 */     if (val instanceof Scriptable) {
/* 1209 */       return (Scriptable)val;
/*      */     }
/* 1211 */     return toObject(Context.getContext(), scope, val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable toObject(Context cx, Scriptable scope, Object val) {
/* 1220 */     if (val == null) {
/* 1221 */       throw typeErrorById("msg.null.to.object", new Object[0]);
/*      */     }
/* 1223 */     if (Undefined.isUndefined(val)) {
/* 1224 */       throw typeErrorById("msg.undef.to.object", new Object[0]);
/*      */     }
/*      */     
/* 1227 */     if (isSymbol(val)) {
/* 1228 */       NativeSymbol result = new NativeSymbol((NativeSymbol)val);
/* 1229 */       setBuiltinProtoAndParent(result, scope, TopLevel.Builtins.Symbol);
/* 1230 */       return result;
/*      */     } 
/* 1232 */     if (val instanceof Scriptable) {
/* 1233 */       return (Scriptable)val;
/*      */     }
/* 1235 */     if (val instanceof CharSequence) {
/*      */       
/* 1237 */       NativeString result = new NativeString((CharSequence)val);
/* 1238 */       setBuiltinProtoAndParent(result, scope, TopLevel.Builtins.String);
/* 1239 */       return result;
/*      */     } 
/* 1241 */     if (cx.getLanguageVersion() >= 200 && val instanceof BigInteger) {
/* 1242 */       NativeBigInt result = new NativeBigInt((BigInteger)val);
/* 1243 */       setBuiltinProtoAndParent(result, scope, TopLevel.Builtins.BigInt);
/* 1244 */       return result;
/*      */     } 
/* 1246 */     if (val instanceof Number) {
/* 1247 */       NativeNumber result = new NativeNumber(((Number)val).doubleValue());
/* 1248 */       setBuiltinProtoAndParent(result, scope, TopLevel.Builtins.Number);
/* 1249 */       return result;
/*      */     } 
/* 1251 */     if (val instanceof Boolean) {
/* 1252 */       NativeBoolean result = new NativeBoolean(((Boolean)val).booleanValue());
/* 1253 */       setBuiltinProtoAndParent(result, scope, TopLevel.Builtins.Boolean);
/* 1254 */       return result;
/*      */     } 
/*      */ 
/*      */     
/* 1258 */     Object wrapped = cx.getWrapFactory().wrap(cx, scope, val, null);
/* 1259 */     if (wrapped instanceof Scriptable) return (Scriptable)wrapped; 
/* 1260 */     throw errorWithClassName("msg.invalid.type", val);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scriptable toObject(Context cx, Scriptable scope, Object val, Class<?> staticClass) {
/* 1267 */     return toObject(cx, scope, val);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object call(Context cx, Object fun, Object thisArg, Object[] args, Scriptable scope) {
/* 1274 */     if (!(fun instanceof Function)) {
/* 1275 */       throw notFunctionError(toString(fun));
/*      */     }
/* 1277 */     Function function = (Function)fun;
/* 1278 */     Scriptable thisObj = toObjectOrNull(cx, thisArg, scope);
/* 1279 */     if (thisObj == null) {
/* 1280 */       throw undefCallError(null, "function");
/*      */     }
/* 1282 */     return function.call(cx, scope, thisObj, args);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable newObject(Context cx, Scriptable scope, String constructorName, Object[] args) {
/* 1287 */     scope = ScriptableObject.getTopLevelScope(scope);
/* 1288 */     Function ctor = getExistingCtor(cx, scope, constructorName);
/* 1289 */     if (args == null) {
/* 1290 */       args = emptyArgs;
/*      */     }
/* 1292 */     return ctor.construct(cx, scope, args);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable newBuiltinObject(Context cx, Scriptable scope, TopLevel.Builtins type, Object[] args) {
/* 1297 */     scope = ScriptableObject.getTopLevelScope(scope);
/* 1298 */     Function ctor = TopLevel.getBuiltinCtor(cx, scope, type);
/* 1299 */     if (args == null) {
/* 1300 */       args = emptyArgs;
/*      */     }
/* 1302 */     return ctor.construct(cx, scope, args);
/*      */   }
/*      */ 
/*      */   
/*      */   static Scriptable newNativeError(Context cx, Scriptable scope, TopLevel.NativeErrors type, Object[] args) {
/* 1307 */     scope = ScriptableObject.getTopLevelScope(scope);
/* 1308 */     Function ctor = TopLevel.getNativeErrorCtor(cx, scope, type);
/* 1309 */     if (args == null) {
/* 1310 */       args = emptyArgs;
/*      */     }
/* 1312 */     return ctor.construct(cx, scope, args);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double toInteger(Object val) {
/* 1317 */     return toInteger(toNumber(val));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toInteger(double d) {
/* 1323 */     if (Double.isNaN(d)) return 0.0D;
/*      */     
/* 1325 */     if (d == 0.0D || Double.isInfinite(d)) return d;
/*      */     
/* 1327 */     if (d > 0.0D) return Math.floor(d);
/*      */     
/* 1329 */     return Math.ceil(d);
/*      */   }
/*      */   
/*      */   public static double toInteger(Object[] args, int index) {
/* 1333 */     return (index < args.length) ? toInteger(args[index]) : 0.0D;
/*      */   }
/*      */   
/*      */   public static long toLength(Object[] args, int index) {
/* 1337 */     double len = toInteger(args, index);
/* 1338 */     if (len <= 0.0D) {
/* 1339 */       return 0L;
/*      */     }
/* 1341 */     return (long)Math.min(len, 9.007199254740991E15D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int toInt32(Object val) {
/* 1347 */     if (val instanceof Integer) return ((Integer)val).intValue();
/*      */     
/* 1349 */     return toInt32(toNumber(val));
/*      */   }
/*      */   
/*      */   public static int toInt32(Object[] args, int index) {
/* 1353 */     return (index < args.length) ? toInt32(args[index]) : 0;
/*      */   }
/*      */   
/*      */   public static int toInt32(double d) {
/* 1357 */     return DoubleConversion.doubleToInt32(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long toUint32(double d) {
/* 1366 */     return DoubleConversion.doubleToInt32(d) & 0xFFFFFFFFL;
/*      */   }
/*      */   
/*      */   public static long toUint32(Object val) {
/* 1370 */     return toUint32(toNumber(val));
/*      */   }
/*      */ 
/*      */   
/*      */   public static char toUint16(Object val) {
/* 1375 */     double d = toNumber(val);
/* 1376 */     return (char)DoubleConversion.doubleToInt32(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setDefaultNamespace(Object namespace, Context cx) {
/* 1384 */     Scriptable scope = cx.currentActivationCall;
/* 1385 */     if (scope == null) {
/* 1386 */       scope = getTopCallScope(cx);
/*      */     }
/*      */     
/* 1389 */     XMLLib xmlLib = currentXMLLib(cx);
/* 1390 */     Object ns = xmlLib.toDefaultXmlNamespace(cx, namespace);
/*      */ 
/*      */     
/* 1393 */     if (!scope.has("__default_namespace__", scope)) {
/*      */       
/* 1395 */       ScriptableObject.defineProperty(scope, "__default_namespace__", ns, 6);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1401 */       scope.put("__default_namespace__", scope, ns);
/*      */     } 
/*      */     
/* 1404 */     return Undefined.instance;
/*      */   }
/*      */   public static Object searchDefaultNamespace(Context cx) {
/*      */     Object nsObject;
/* 1408 */     Scriptable scope = cx.currentActivationCall;
/* 1409 */     if (scope == null) {
/* 1410 */       scope = getTopCallScope(cx);
/*      */     }
/*      */     
/*      */     while (true) {
/* 1414 */       Scriptable parent = scope.getParentScope();
/* 1415 */       if (parent == null) {
/* 1416 */         Object object = ScriptableObject.getProperty(scope, "__default_namespace__");
/* 1417 */         if (object == Scriptable.NOT_FOUND) {
/* 1418 */           return null;
/*      */         }
/*      */         break;
/*      */       } 
/* 1422 */       nsObject = scope.get("__default_namespace__", scope);
/* 1423 */       if (nsObject != Scriptable.NOT_FOUND) {
/*      */         break;
/*      */       }
/* 1426 */       scope = parent;
/*      */     } 
/* 1428 */     return nsObject;
/*      */   }
/*      */   
/*      */   public static Object getTopLevelProp(Scriptable scope, String id) {
/* 1432 */     scope = ScriptableObject.getTopLevelScope(scope);
/* 1433 */     return ScriptableObject.getProperty(scope, id);
/*      */   }
/*      */   
/*      */   static Function getExistingCtor(Context cx, Scriptable scope, String constructorName) {
/* 1437 */     Object ctorVal = ScriptableObject.getProperty(scope, constructorName);
/* 1438 */     if (ctorVal instanceof Function) {
/* 1439 */       return (Function)ctorVal;
/*      */     }
/* 1441 */     if (ctorVal == Scriptable.NOT_FOUND) {
/* 1442 */       throw Context.reportRuntimeErrorById("msg.ctor.not.found", new Object[] { constructorName });
/*      */     }
/* 1444 */     throw Context.reportRuntimeErrorById("msg.not.ctor", new Object[] { constructorName });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long indexFromString(String str) {
/* 1455 */     int MAX_VALUE_LENGTH = 10;
/*      */     
/* 1457 */     int len = str.length();
/* 1458 */     if (len > 0) {
/* 1459 */       int i = 0;
/* 1460 */       boolean negate = false;
/* 1461 */       int c = str.charAt(0);
/* 1462 */       if (c == 45 && 
/* 1463 */         len > 1) {
/* 1464 */         c = str.charAt(1);
/* 1465 */         if (c == 48) return -1L; 
/* 1466 */         i = 1;
/* 1467 */         negate = true;
/*      */       } 
/*      */       
/* 1470 */       c -= 48;
/* 1471 */       if (0 <= c && c <= 9 && len <= (negate ? 11 : 10)) {
/*      */ 
/*      */ 
/*      */         
/* 1475 */         int index = -c;
/* 1476 */         int oldIndex = 0;
/* 1477 */         i++;
/* 1478 */         if (index != 0)
/*      */         {
/* 1480 */           while (i != len && 0 <= (c = str.charAt(i) - 48) && c <= 9) {
/* 1481 */             oldIndex = index;
/* 1482 */             index = 10 * index - c;
/* 1483 */             i++;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 1488 */         if (i == len && (oldIndex > -214748364 || (oldIndex == -214748364 && c <= (negate ? 8 : 7))))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1495 */           return 0xFFFFFFFFL & (negate ? index : -index);
/*      */         }
/*      */       } 
/*      */     } 
/* 1499 */     return -1L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long testUint32String(String str) {
/* 1506 */     int MAX_VALUE_LENGTH = 10;
/*      */     
/* 1508 */     int len = str.length();
/* 1509 */     if (1 <= len && len <= 10) {
/* 1510 */       int c = str.charAt(0);
/* 1511 */       c -= 48;
/* 1512 */       if (c == 0)
/*      */       {
/* 1514 */         return (len == 1) ? 0L : -1L;
/*      */       }
/* 1516 */       if (1 <= c && c <= 9) {
/* 1517 */         long v = c;
/* 1518 */         for (int i = 1; i != len; i++) {
/* 1519 */           c = str.charAt(i) - 48;
/* 1520 */           if (0 > c || c > 9) {
/* 1521 */             return -1L;
/*      */           }
/* 1523 */           v = 10L * v + c;
/*      */         } 
/*      */         
/* 1526 */         if (v >>> 32L == 0L) {
/* 1527 */           return v;
/*      */         }
/*      */       } 
/*      */     } 
/* 1531 */     return -1L;
/*      */   }
/*      */ 
/*      */   
/*      */   static Object getIndexObject(String s) {
/* 1536 */     long indexTest = indexFromString(s);
/* 1537 */     if (indexTest >= 0L) {
/* 1538 */       return Integer.valueOf((int)indexTest);
/*      */     }
/* 1540 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Object getIndexObject(double d) {
/* 1548 */     int i = (int)d;
/* 1549 */     if (i == d) {
/* 1550 */       return Integer.valueOf(i);
/*      */     }
/* 1552 */     return toString(d);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class StringIdOrIndex
/*      */   {
/*      */     final String stringId;
/*      */ 
/*      */     
/*      */     final int index;
/*      */ 
/*      */     
/*      */     StringIdOrIndex(String stringId) {
/* 1566 */       this.stringId = stringId;
/* 1567 */       this.index = -1;
/*      */     }
/*      */     
/*      */     StringIdOrIndex(int index) {
/* 1571 */       this.stringId = null;
/* 1572 */       this.index = index;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static StringIdOrIndex toStringIdOrIndex(Context cx, Object id) {
/*      */     String s;
/* 1582 */     if (id instanceof Number) {
/* 1583 */       double d = ((Number)id).doubleValue();
/* 1584 */       int index = (int)d;
/* 1585 */       if (index == d) {
/* 1586 */         return new StringIdOrIndex(index);
/*      */       }
/* 1588 */       return new StringIdOrIndex(toString(id));
/*      */     } 
/*      */     
/* 1591 */     if (id instanceof String) {
/* 1592 */       s = (String)id;
/*      */     } else {
/* 1594 */       s = toString(id);
/*      */     } 
/* 1596 */     long indexTest = indexFromString(s);
/* 1597 */     if (indexTest >= 0L) {
/* 1598 */       return new StringIdOrIndex((int)indexTest);
/*      */     }
/* 1600 */     return new StringIdOrIndex(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object getObjectElem(Object obj, Object elem, Context cx) {
/* 1610 */     return getObjectElem(obj, elem, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object getObjectElem(Object obj, Object elem, Context cx, Scriptable scope) {
/* 1615 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 1616 */     if (sobj == null) {
/* 1617 */       throw undefReadError(obj, elem);
/*      */     }
/* 1619 */     return getObjectElem(sobj, elem, cx);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getObjectElem(Scriptable obj, Object elem, Context cx) {
/*      */     Object result;
/* 1626 */     if (obj instanceof XMLObject) {
/* 1627 */       result = ((XMLObject)obj).get(cx, elem);
/* 1628 */     } else if (isSymbol(elem)) {
/* 1629 */       result = ScriptableObject.getProperty(obj, (Symbol)elem);
/*      */     } else {
/* 1631 */       StringIdOrIndex s = toStringIdOrIndex(cx, elem);
/* 1632 */       if (s.stringId == null) {
/* 1633 */         int index = s.index;
/* 1634 */         result = ScriptableObject.getProperty(obj, index);
/*      */       } else {
/* 1636 */         result = ScriptableObject.getProperty(obj, s.stringId);
/*      */       } 
/*      */     } 
/*      */     
/* 1640 */     if (result == Scriptable.NOT_FOUND) {
/* 1641 */       result = Undefined.instance;
/*      */     }
/*      */     
/* 1644 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object getObjectProp(Object obj, String property, Context cx) {
/* 1654 */     return getObjectProp(obj, property, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getObjectProp(Object obj, String property, Context cx, Scriptable scope) {
/* 1663 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 1664 */     if (sobj == null) {
/* 1665 */       throw undefReadError(obj, property);
/*      */     }
/* 1667 */     return getObjectProp(sobj, property, cx);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object getObjectProp(Scriptable obj, String property, Context cx) {
/* 1672 */     Object result = ScriptableObject.getProperty(obj, property);
/* 1673 */     if (result == Scriptable.NOT_FOUND) {
/* 1674 */       if (cx.hasFeature(11)) {
/* 1675 */         Context.reportWarning(
/* 1676 */             getMessageById("msg.ref.undefined.prop", new Object[] { property }));
/*      */       }
/* 1678 */       result = Undefined.instance;
/*      */     } 
/*      */     
/* 1681 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object getObjectPropNoWarn(Object obj, String property, Context cx) {
/* 1687 */     return getObjectPropNoWarn(obj, property, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object getObjectPropNoWarn(Object obj, String property, Context cx, Scriptable scope) {
/* 1692 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 1693 */     if (sobj == null) {
/* 1694 */       throw undefReadError(obj, property);
/*      */     }
/* 1696 */     Object result = ScriptableObject.getProperty(sobj, property);
/* 1697 */     if (result == Scriptable.NOT_FOUND) {
/* 1698 */       return Undefined.instance;
/*      */     }
/* 1700 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object getObjectIndex(Object obj, double dblIndex, Context cx) {
/* 1710 */     return getObjectIndex(obj, dblIndex, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object getObjectIndex(Object obj, double dblIndex, Context cx, Scriptable scope) {
/* 1715 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 1716 */     if (sobj == null) {
/* 1717 */       throw undefReadError(obj, toString(dblIndex));
/*      */     }
/*      */     
/* 1720 */     int index = (int)dblIndex;
/* 1721 */     if (index == dblIndex) {
/* 1722 */       return getObjectIndex(sobj, index, cx);
/*      */     }
/* 1724 */     String s = toString(dblIndex);
/* 1725 */     return getObjectProp(sobj, s, cx);
/*      */   }
/*      */   
/*      */   public static Object getObjectIndex(Scriptable obj, int index, Context cx) {
/* 1729 */     Object result = ScriptableObject.getProperty(obj, index);
/* 1730 */     if (result == Scriptable.NOT_FOUND) {
/* 1731 */       result = Undefined.instance;
/*      */     }
/*      */     
/* 1734 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object setObjectElem(Object obj, Object elem, Object value, Context cx) {
/* 1744 */     return setObjectElem(obj, elem, value, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setObjectElem(Object obj, Object elem, Object value, Context cx, Scriptable scope) {
/* 1750 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 1751 */     if (sobj == null) {
/* 1752 */       throw undefWriteError(obj, elem, value);
/*      */     }
/* 1754 */     return setObjectElem(sobj, elem, value, cx);
/*      */   }
/*      */   
/*      */   public static Object setObjectElem(Scriptable obj, Object elem, Object value, Context cx) {
/* 1758 */     if (obj instanceof XMLObject) {
/* 1759 */       ((XMLObject)obj).put(cx, elem, value);
/* 1760 */     } else if (isSymbol(elem)) {
/* 1761 */       ScriptableObject.putProperty(obj, (Symbol)elem, value);
/*      */     } else {
/* 1763 */       StringIdOrIndex s = toStringIdOrIndex(cx, elem);
/* 1764 */       if (s.stringId == null) {
/* 1765 */         ScriptableObject.putProperty(obj, s.index, value);
/*      */       } else {
/* 1767 */         ScriptableObject.putProperty(obj, s.stringId, value);
/*      */       } 
/*      */     } 
/*      */     
/* 1771 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object setObjectProp(Object obj, String property, Object value, Context cx) {
/* 1781 */     return setObjectProp(obj, property, value, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setObjectProp(Object obj, String property, Object value, Context cx, Scriptable scope) {
/* 1787 */     if (!(obj instanceof Scriptable) && cx
/* 1788 */       .isStrictMode() && cx
/* 1789 */       .getLanguageVersion() >= 180) {
/* 1790 */       throw undefWriteError(obj, property, value);
/*      */     }
/*      */     
/* 1793 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 1794 */     if (sobj == null) {
/* 1795 */       throw undefWriteError(obj, property, value);
/*      */     }
/*      */     
/* 1798 */     return setObjectProp(sobj, property, value, cx);
/*      */   }
/*      */   
/*      */   public static Object setObjectProp(Scriptable obj, String property, Object value, Context cx) {
/* 1802 */     ScriptableObject.putProperty(obj, property, value);
/* 1803 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object setObjectIndex(Object obj, double dblIndex, Object value, Context cx) {
/* 1813 */     return setObjectIndex(obj, dblIndex, value, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object setObjectIndex(Object obj, double dblIndex, Object value, Context cx, Scriptable scope) {
/* 1819 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 1820 */     if (sobj == null) {
/* 1821 */       throw undefWriteError(obj, String.valueOf(dblIndex), value);
/*      */     }
/*      */     
/* 1824 */     int index = (int)dblIndex;
/* 1825 */     if (index == dblIndex) {
/* 1826 */       return setObjectIndex(sobj, index, value, cx);
/*      */     }
/* 1828 */     String s = toString(dblIndex);
/* 1829 */     return setObjectProp(sobj, s, value, cx);
/*      */   }
/*      */   
/*      */   public static Object setObjectIndex(Scriptable obj, int index, Object value, Context cx) {
/* 1833 */     ScriptableObject.putProperty(obj, index, value);
/* 1834 */     return value;
/*      */   }
/*      */   
/*      */   public static boolean deleteObjectElem(Scriptable target, Object elem, Context cx) {
/* 1838 */     if (isSymbol(elem)) {
/* 1839 */       SymbolScriptable so = ScriptableObject.ensureSymbolScriptable(target);
/* 1840 */       Symbol symbol = (Symbol)elem;
/* 1841 */       so.delete(symbol);
/* 1842 */       return !so.has(symbol, target);
/*      */     } 
/* 1844 */     StringIdOrIndex s = toStringIdOrIndex(cx, elem);
/* 1845 */     if (s.stringId == null) {
/* 1846 */       target.delete(s.index);
/* 1847 */       return !target.has(s.index, target);
/*      */     } 
/* 1849 */     target.delete(s.stringId);
/* 1850 */     return !target.has(s.stringId, target);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean hasObjectElem(Scriptable target, Object elem, Context cx) {
/*      */     boolean result;
/* 1856 */     if (isSymbol(elem)) {
/* 1857 */       result = ScriptableObject.hasProperty(target, (Symbol)elem);
/*      */     } else {
/* 1859 */       StringIdOrIndex s = toStringIdOrIndex(cx, elem);
/* 1860 */       if (s.stringId == null) {
/* 1861 */         result = ScriptableObject.hasProperty(target, s.index);
/*      */       } else {
/* 1863 */         result = ScriptableObject.hasProperty(target, s.stringId);
/*      */       } 
/*      */     } 
/*      */     
/* 1867 */     return result;
/*      */   }
/*      */   
/*      */   public static Object refGet(Ref ref, Context cx) {
/* 1871 */     return ref.get(cx);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object refSet(Ref ref, Object value, Context cx) {
/* 1877 */     return refSet(ref, value, cx, getTopCallScope(cx));
/*      */   }
/*      */   
/*      */   public static Object refSet(Ref ref, Object value, Context cx, Scriptable scope) {
/* 1881 */     return ref.set(cx, scope, value);
/*      */   }
/*      */   
/*      */   public static Object refDel(Ref ref, Context cx) {
/* 1885 */     return wrapBoolean(ref.delete(cx));
/*      */   }
/*      */   
/*      */   static boolean isSpecialProperty(String s) {
/* 1889 */     return (s.equals("__proto__") || s.equals("__parent__"));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Ref specialRef(Object obj, String specialProperty, Context cx) {
/* 1895 */     return specialRef(obj, specialProperty, cx, getTopCallScope(cx));
/*      */   }
/*      */   
/*      */   public static Ref specialRef(Object obj, String specialProperty, Context cx, Scriptable scope) {
/* 1899 */     return SpecialRef.createSpecial(cx, scope, obj, specialProperty);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object delete(Object obj, Object id, Context cx) {
/* 1905 */     return delete(obj, id, cx, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object delete(Object obj, Object id, Context cx, boolean isName) {
/* 1921 */     return delete(obj, id, cx, getTopCallScope(cx), isName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object delete(Object obj, Object id, Context cx, Scriptable scope, boolean isName) {
/* 1935 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 1936 */     if (sobj == null) {
/* 1937 */       if (isName) {
/* 1938 */         return Boolean.TRUE;
/*      */       }
/* 1940 */       throw undefDeleteError(obj, id);
/*      */     } 
/* 1942 */     boolean result = deleteObjectElem(sobj, id, cx);
/* 1943 */     return wrapBoolean(result);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object name(Context cx, Scriptable scope, String name) {
/* 1948 */     Scriptable parent = scope.getParentScope();
/* 1949 */     if (parent == null) {
/* 1950 */       Object result = topScopeName(cx, scope, name);
/* 1951 */       if (result == Scriptable.NOT_FOUND) {
/* 1952 */         throw notFoundError(scope, name);
/*      */       }
/* 1954 */       return result;
/*      */     } 
/*      */     
/* 1957 */     return nameOrFunction(cx, scope, parent, name, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object nameOrFunction(Context cx, Scriptable scope, Scriptable parentScope, String name, boolean asFunctionCall) {
/*      */     Object result;
/* 1967 */     Scriptable thisObj = scope;
/*      */     
/* 1969 */     XMLObject firstXMLObject = null;
/*      */     while (true) {
/* 1971 */       if (scope instanceof NativeWith) {
/* 1972 */         Scriptable withObj = scope.getPrototype();
/* 1973 */         if (withObj instanceof XMLObject) {
/* 1974 */           XMLObject xmlObj = (XMLObject)withObj;
/* 1975 */           if (xmlObj.has(name, (Scriptable)xmlObj)) {
/*      */             
/* 1977 */             XMLObject xMLObject = xmlObj;
/* 1978 */             result = xmlObj.get(name, (Scriptable)xmlObj);
/*      */             break;
/*      */           } 
/* 1981 */           if (firstXMLObject == null) {
/* 1982 */             firstXMLObject = xmlObj;
/*      */           }
/*      */         } else {
/* 1985 */           result = ScriptableObject.getProperty(withObj, name);
/* 1986 */           if (result != Scriptable.NOT_FOUND) {
/*      */             
/* 1988 */             thisObj = withObj;
/*      */             break;
/*      */           } 
/*      */         } 
/* 1992 */       } else if (scope instanceof NativeCall) {
/*      */ 
/*      */         
/* 1995 */         result = scope.get(name, scope);
/* 1996 */         if (result != Scriptable.NOT_FOUND) {
/* 1997 */           if (asFunctionCall)
/*      */           {
/*      */             
/* 2000 */             thisObj = ScriptableObject.getTopLevelScope(parentScope);
/*      */           }
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */       } else {
/* 2007 */         result = ScriptableObject.getProperty(scope, name);
/* 2008 */         if (result != Scriptable.NOT_FOUND) {
/* 2009 */           thisObj = scope;
/*      */           break;
/*      */         } 
/*      */       } 
/* 2013 */       scope = parentScope;
/* 2014 */       parentScope = parentScope.getParentScope();
/* 2015 */       if (parentScope == null) {
/* 2016 */         result = topScopeName(cx, scope, name);
/* 2017 */         if (result == Scriptable.NOT_FOUND) {
/* 2018 */           if (firstXMLObject == null || asFunctionCall) {
/* 2019 */             throw notFoundError(scope, name);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2025 */           result = firstXMLObject.get(name, (Scriptable)firstXMLObject);
/*      */         } 
/*      */         
/* 2028 */         thisObj = scope;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 2033 */     if (asFunctionCall) {
/* 2034 */       if (!(result instanceof Callable)) {
/* 2035 */         throw notFunctionError(result, name);
/*      */       }
/* 2037 */       storeScriptable(cx, thisObj);
/*      */     } 
/*      */     
/* 2040 */     return result;
/*      */   }
/*      */   
/*      */   private static Object topScopeName(Context cx, Scriptable scope, String name) {
/* 2044 */     if (cx.useDynamicScope) {
/* 2045 */       scope = checkDynamicScope(cx.topCallScope, scope);
/*      */     }
/* 2047 */     return ScriptableObject.getProperty(scope, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable bind(Context cx, Scriptable scope, String id) {
/*      */     XMLObject xMLObject;
/* 2062 */     Scriptable firstXMLObject = null;
/* 2063 */     Scriptable parent = scope.getParentScope();
/*      */     
/* 2065 */     if (parent != null) {
/*      */       while (true) {
/* 2067 */         if (scope instanceof NativeWith) {
/* 2068 */           Scriptable withObj = scope.getPrototype();
/* 2069 */           if (withObj instanceof XMLObject) {
/* 2070 */             XMLObject xmlObject = (XMLObject)withObj;
/* 2071 */             if (xmlObject.has(cx, id)) {
/* 2072 */               return (Scriptable)xmlObject;
/*      */             }
/* 2074 */             if (firstXMLObject == null) {
/* 2075 */               xMLObject = xmlObject;
/*      */             }
/*      */           }
/* 2078 */           else if (ScriptableObject.hasProperty(withObj, id)) {
/* 2079 */             return withObj;
/*      */           } 
/*      */           
/* 2082 */           scope = parent;
/* 2083 */           parent = parent.getParentScope();
/* 2084 */           if (parent == null)
/*      */             break; 
/*      */           continue;
/*      */         } 
/*      */         do {
/* 2089 */           if (ScriptableObject.hasProperty(scope, id)) {
/* 2090 */             return scope;
/*      */           }
/* 2092 */           scope = parent;
/* 2093 */           parent = parent.getParentScope();
/* 2094 */         } while (parent != null);
/*      */         
/*      */         break;
/*      */       } 
/*      */     }
/*      */     
/* 2100 */     if (cx.useDynamicScope) {
/* 2101 */       scope = checkDynamicScope(cx.topCallScope, scope);
/*      */     }
/* 2103 */     if (ScriptableObject.hasProperty(scope, id)) {
/* 2104 */       return scope;
/*      */     }
/*      */ 
/*      */     
/* 2108 */     return (Scriptable)xMLObject;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object setName(Scriptable bound, Object value, Context cx, Scriptable scope, String id) {
/* 2113 */     if (bound != null) {
/*      */ 
/*      */       
/* 2116 */       ScriptableObject.putProperty(bound, id, value);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2121 */       if (cx.hasFeature(11) || cx
/* 2122 */         .hasFeature(8)) {
/* 2123 */         Context.reportWarning(getMessageById("msg.assn.create.strict", new Object[] { id }));
/*      */       }
/*      */       
/* 2126 */       bound = ScriptableObject.getTopLevelScope(scope);
/* 2127 */       if (cx.useDynamicScope) {
/* 2128 */         bound = checkDynamicScope(cx.topCallScope, bound);
/*      */       }
/* 2130 */       bound.put(id, bound, value);
/*      */     } 
/* 2132 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object strictSetName(Scriptable bound, Object value, Context cx, Scriptable scope, String id) {
/* 2137 */     if (bound != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2146 */       ScriptableObject.putProperty(bound, id, value);
/* 2147 */       return value;
/*      */     } 
/*      */     
/* 2150 */     String msg = "Assignment to undefined \"" + id + "\" in strict mode";
/* 2151 */     throw constructError("ReferenceError", msg);
/*      */   }
/*      */   
/*      */   public static Object setConst(Scriptable bound, Object value, Context cx, String id) {
/* 2155 */     if (bound instanceof XMLObject) {
/* 2156 */       bound.put(id, bound, value);
/*      */     } else {
/* 2158 */       ScriptableObject.putConstProperty(bound, id, value);
/*      */     } 
/* 2160 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class IdEnumeration
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     
/*      */     Scriptable obj;
/*      */     
/*      */     Object[] ids;
/*      */     
/*      */     ObjToIntMap used;
/*      */     
/*      */     Object currentId;
/*      */     
/*      */     int index;
/*      */     
/*      */     int enumType;
/*      */     
/*      */     boolean enumNumbers;
/*      */     
/*      */     Scriptable iterator;
/*      */ 
/*      */     
/*      */     private IdEnumeration() {}
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable toIterator(Context cx, Scriptable scope, Scriptable obj, boolean keyOnly) {
/* 2193 */     if (ScriptableObject.hasProperty(obj, "__iterator__")) {
/* 2194 */       Object v = ScriptableObject.getProperty(obj, "__iterator__");
/* 2195 */       if (!(v instanceof Callable)) {
/* 2196 */         throw typeErrorById("msg.invalid.iterator", new Object[0]);
/*      */       }
/* 2198 */       Callable f = (Callable)v;
/* 2199 */       Object[] args = { keyOnly ? Boolean.TRUE : Boolean.FALSE };
/* 2200 */       v = f.call(cx, scope, obj, args);
/* 2201 */       if (!(v instanceof Scriptable)) {
/* 2202 */         throw typeErrorById("msg.iterator.primitive", new Object[0]);
/*      */       }
/* 2204 */       return (Scriptable)v;
/*      */     } 
/* 2206 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object enumInit(Object value, Context cx, boolean enumValues) {
/* 2216 */     return enumInit(value, cx, enumValues ? 1 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object enumInit(Object value, Context cx, int enumType) {
/* 2230 */     return enumInit(value, cx, getTopCallScope(cx), enumType);
/*      */   }
/*      */   
/*      */   public static Object enumInit(Object value, Context cx, Scriptable scope, int enumType) {
/* 2234 */     IdEnumeration x = new IdEnumeration();
/* 2235 */     x.obj = toObjectOrNull(cx, value, scope);
/*      */     
/* 2237 */     if (enumType == 6) {
/* 2238 */       x.enumType = enumType;
/* 2239 */       x.iterator = null;
/* 2240 */       return enumInitInOrder(cx, x);
/*      */     } 
/* 2242 */     if (x.obj == null)
/*      */     {
/*      */       
/* 2245 */       return x;
/*      */     }
/* 2247 */     x.enumType = enumType;
/* 2248 */     x.iterator = null;
/* 2249 */     if (enumType != 3 && enumType != 4 && enumType != 5)
/*      */     {
/*      */       
/* 2252 */       x
/* 2253 */         .iterator = toIterator(cx, x.obj
/*      */           
/* 2255 */           .getParentScope(), x.obj, (enumType == 0));
/*      */     }
/*      */ 
/*      */     
/* 2259 */     if (x.iterator == null)
/*      */     {
/*      */       
/* 2262 */       enumChangeObject(x);
/*      */     }
/*      */     
/* 2265 */     return x;
/*      */   }
/*      */   
/*      */   private static Object enumInitInOrder(Context cx, IdEnumeration x) {
/* 2269 */     if (!(x.obj instanceof SymbolScriptable) || 
/* 2270 */       !ScriptableObject.hasProperty(x.obj, SymbolKey.ITERATOR)) {
/* 2271 */       throw typeErrorById("msg.not.iterable", new Object[] { toString(x.obj) });
/*      */     }
/*      */     
/* 2274 */     Object iterator = ScriptableObject.getProperty(x.obj, SymbolKey.ITERATOR);
/* 2275 */     if (!(iterator instanceof Callable)) {
/* 2276 */       throw typeErrorById("msg.not.iterable", new Object[] { toString(x.obj) });
/*      */     }
/* 2278 */     Callable f = (Callable)iterator;
/* 2279 */     Scriptable scope = x.obj.getParentScope();
/* 2280 */     Object[] args = new Object[0];
/* 2281 */     Object v = f.call(cx, scope, x.obj, args);
/* 2282 */     if (!(v instanceof Scriptable)) {
/* 2283 */       throw typeErrorById("msg.not.iterable", new Object[] { toString(x.obj) });
/*      */     }
/* 2285 */     x.iterator = (Scriptable)v;
/* 2286 */     return x;
/*      */   }
/*      */   
/*      */   public static void setEnumNumbers(Object enumObj, boolean enumNumbers) {
/* 2290 */     ((IdEnumeration)enumObj).enumNumbers = enumNumbers;
/*      */   }
/*      */   
/*      */   public static Boolean enumNext(Object enumObj) {
/* 2294 */     IdEnumeration x = (IdEnumeration)enumObj;
/* 2295 */     if (x.iterator != null) {
/* 2296 */       if (x.enumType == 6) {
/* 2297 */         return enumNextInOrder(x);
/*      */       }
/* 2299 */       Object v = ScriptableObject.getProperty(x.iterator, "next");
/* 2300 */       if (!(v instanceof Callable)) return Boolean.FALSE; 
/* 2301 */       Callable f = (Callable)v;
/* 2302 */       Context cx = Context.getContext();
/*      */       try {
/* 2304 */         x.currentId = f.call(cx, x.iterator.getParentScope(), x.iterator, emptyArgs);
/* 2305 */         return Boolean.TRUE;
/* 2306 */       } catch (JavaScriptException e) {
/* 2307 */         if (e.getValue() instanceof NativeIterator.StopIteration) {
/* 2308 */           return Boolean.FALSE;
/*      */         }
/* 2310 */         throw e;
/*      */       } 
/*      */     } 
/*      */     while (true) {
/* 2314 */       if (x.obj == null) {
/* 2315 */         return Boolean.FALSE;
/*      */       }
/* 2317 */       if (x.index == x.ids.length) {
/* 2318 */         x.obj = x.obj.getPrototype();
/* 2319 */         enumChangeObject(x);
/*      */         continue;
/*      */       } 
/* 2322 */       Object id = x.ids[x.index++];
/* 2323 */       if (x.used != null && x.used.has(id)) {
/*      */         continue;
/*      */       }
/* 2326 */       if (id instanceof Symbol)
/*      */         continue; 
/* 2328 */       if (id instanceof String) {
/* 2329 */         String strId = (String)id;
/* 2330 */         if (!x.obj.has(strId, x.obj))
/* 2331 */           continue;  x.currentId = strId; break;
/*      */       } 
/* 2333 */       int intId = ((Number)id).intValue();
/* 2334 */       if (!x.obj.has(intId, x.obj))
/* 2335 */         continue;  x
/* 2336 */         .currentId = x.enumNumbers ? Integer.valueOf(intId) : String.valueOf(intId); break;
/*      */     } 
/* 2338 */     return Boolean.TRUE;
/*      */   }
/*      */ 
/*      */   
/*      */   private static Boolean enumNextInOrder(IdEnumeration enumObj) {
/* 2343 */     Object v = ScriptableObject.getProperty(enumObj.iterator, "next");
/* 2344 */     if (!(v instanceof Callable)) {
/* 2345 */       throw notFunctionError(enumObj.iterator, "next");
/*      */     }
/* 2347 */     Callable f = (Callable)v;
/* 2348 */     Context cx = Context.getContext();
/* 2349 */     Scriptable scope = enumObj.iterator.getParentScope();
/* 2350 */     Object r = f.call(cx, scope, enumObj.iterator, emptyArgs);
/* 2351 */     Scriptable iteratorResult = toObject(cx, scope, r);
/* 2352 */     Object done = ScriptableObject.getProperty(iteratorResult, "done");
/* 2353 */     if (done != Scriptable.NOT_FOUND && toBoolean(done)) {
/* 2354 */       return Boolean.FALSE;
/*      */     }
/* 2356 */     enumObj
/* 2357 */       .currentId = ScriptableObject.getProperty(iteratorResult, "value");
/* 2358 */     return Boolean.TRUE;
/*      */   }
/*      */   public static Object enumId(Object enumObj, Context cx) {
/*      */     Object[] elements;
/* 2362 */     IdEnumeration x = (IdEnumeration)enumObj;
/* 2363 */     if (x.iterator != null) {
/* 2364 */       return x.currentId;
/*      */     }
/* 2366 */     switch (x.enumType) {
/*      */       case 0:
/*      */       case 3:
/* 2369 */         return x.currentId;
/*      */       case 1:
/*      */       case 4:
/* 2372 */         return enumValue(enumObj, cx);
/*      */       case 2:
/*      */       case 5:
/* 2375 */         elements = new Object[] { x.currentId, enumValue(enumObj, cx) };
/* 2376 */         return cx.newArray(ScriptableObject.getTopLevelScope(x.obj), elements);
/*      */     } 
/* 2378 */     throw Kit.codeBug();
/*      */   }
/*      */   
/*      */   public static Object enumValue(Object enumObj, Context cx) {
/*      */     Object result;
/* 2383 */     IdEnumeration x = (IdEnumeration)enumObj;
/*      */ 
/*      */ 
/*      */     
/* 2387 */     if (isSymbol(x.currentId)) {
/* 2388 */       SymbolScriptable so = ScriptableObject.ensureSymbolScriptable(x.obj);
/* 2389 */       result = so.get((Symbol)x.currentId, x.obj);
/*      */     } else {
/* 2391 */       StringIdOrIndex s = toStringIdOrIndex(cx, x.currentId);
/* 2392 */       if (s.stringId == null) {
/* 2393 */         result = x.obj.get(s.index, x.obj);
/*      */       } else {
/* 2395 */         result = x.obj.get(s.stringId, x.obj);
/*      */       } 
/*      */     } 
/*      */     
/* 2399 */     return result;
/*      */   }
/*      */   
/*      */   private static void enumChangeObject(IdEnumeration x) {
/* 2403 */     Object[] ids = null;
/* 2404 */     while (x.obj != null) {
/* 2405 */       ids = x.obj.getIds();
/* 2406 */       if (ids.length != 0) {
/*      */         break;
/*      */       }
/* 2409 */       x.obj = x.obj.getPrototype();
/*      */     } 
/* 2411 */     if (x.obj != null && x.ids != null) {
/* 2412 */       Object[] previous = x.ids;
/* 2413 */       int L = previous.length;
/* 2414 */       if (x.used == null) {
/* 2415 */         x.used = new ObjToIntMap(L);
/*      */       }
/* 2417 */       for (int i = 0; i != L; i++) {
/* 2418 */         x.used.intern(previous[i]);
/*      */       }
/*      */     } 
/* 2421 */     x.ids = ids;
/* 2422 */     x.index = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean loadFromIterable(Context cx, Scriptable scope, Object arg1, BiConsumer<Object, Object> setter) {
/* 2437 */     if (arg1 == null || Undefined.isUndefined(arg1)) return false;
/*      */ 
/*      */     
/* 2440 */     Object ito = callIterator(arg1, cx, scope);
/* 2441 */     if (Undefined.isUndefined(ito))
/*      */     {
/* 2443 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2447 */     try (IteratorLikeIterable it = new IteratorLikeIterable(cx, scope, ito)) {
/* 2448 */       for (IteratorLikeIterable.Itr itr = it.iterator(); itr.hasNext(); ) { Object val = itr.next();
/* 2449 */         Scriptable sVal = ScriptableObject.ensureScriptable(val);
/* 2450 */         if (sVal instanceof Symbol)
/* 2451 */           throw typeErrorById("msg.arg.not.object", new Object[] {
/* 2452 */                 typeof(sVal)
/*      */               }); 
/* 2454 */         Object finalKey = sVal.get(0, sVal);
/* 2455 */         if (finalKey == Scriptable.NOT_FOUND) {
/* 2456 */           finalKey = Undefined.instance;
/*      */         }
/* 2458 */         Object finalVal = sVal.get(1, sVal);
/* 2459 */         if (finalVal == Scriptable.NOT_FOUND) {
/* 2460 */           finalVal = Undefined.instance;
/*      */         }
/* 2462 */         setter.accept(finalKey, finalVal); }
/*      */     
/*      */     } 
/* 2465 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Callable getNameFunctionAndThis(String name, Context cx, Scriptable scope) {
/* 2473 */     Scriptable parent = scope.getParentScope();
/* 2474 */     if (parent == null) {
/* 2475 */       Object result = topScopeName(cx, scope, name);
/* 2476 */       if (!(result instanceof Callable)) {
/* 2477 */         if (result == Scriptable.NOT_FOUND) {
/* 2478 */           throw notFoundError(scope, name);
/*      */         }
/* 2480 */         throw notFunctionError(result, name);
/*      */       } 
/*      */       
/* 2483 */       Scriptable thisObj = scope;
/* 2484 */       storeScriptable(cx, thisObj);
/* 2485 */       return (Callable)result;
/*      */     } 
/*      */ 
/*      */     
/* 2489 */     return (Callable)nameOrFunction(cx, scope, parent, name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Callable getElemFunctionAndThis(Object obj, Object elem, Context cx) {
/* 2502 */     return getElemFunctionAndThis(obj, elem, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Callable getElemFunctionAndThis(Object obj, Object elem, Context cx, Scriptable scope) {
/*      */     Scriptable thisObj;
/*      */     Object value;
/* 2516 */     if (isSymbol(elem)) {
/* 2517 */       thisObj = toObjectOrNull(cx, obj, scope);
/* 2518 */       if (thisObj == null) {
/* 2519 */         throw undefCallError(obj, String.valueOf(elem));
/*      */       }
/* 2521 */       value = ScriptableObject.getProperty(thisObj, (Symbol)elem);
/*      */     } else {
/*      */       
/* 2524 */       StringIdOrIndex s = toStringIdOrIndex(cx, elem);
/* 2525 */       if (s.stringId != null) {
/* 2526 */         return getPropFunctionAndThis(obj, s.stringId, cx, scope);
/*      */       }
/*      */       
/* 2529 */       thisObj = toObjectOrNull(cx, obj, scope);
/* 2530 */       if (thisObj == null) {
/* 2531 */         throw undefCallError(obj, String.valueOf(elem));
/*      */       }
/*      */       
/* 2534 */       value = ScriptableObject.getProperty(thisObj, s.index);
/*      */     } 
/*      */     
/* 2537 */     if (!(value instanceof Callable)) {
/* 2538 */       throw notFunctionError(value, elem);
/*      */     }
/*      */     
/* 2541 */     storeScriptable(cx, thisObj);
/* 2542 */     return (Callable)value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Callable getPropFunctionAndThis(Object obj, String property, Context cx) {
/* 2556 */     return getPropFunctionAndThis(obj, property, cx, getTopCallScope(cx));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Callable getPropFunctionAndThis(Object obj, String property, Context cx, Scriptable scope) {
/* 2567 */     Scriptable thisObj = toObjectOrNull(cx, obj, scope);
/* 2568 */     return getPropFunctionAndThisHelper(obj, property, cx, thisObj);
/*      */   }
/*      */ 
/*      */   
/*      */   private static Callable getPropFunctionAndThisHelper(Object obj, String property, Context cx, Scriptable thisObj) {
/* 2573 */     if (thisObj == null) {
/* 2574 */       throw undefCallError(obj, property);
/*      */     }
/*      */     
/* 2577 */     Object value = ScriptableObject.getProperty(thisObj, property);
/* 2578 */     if (!(value instanceof Callable)) {
/* 2579 */       Object noSuchMethod = ScriptableObject.getProperty(thisObj, "__noSuchMethod__");
/* 2580 */       if (noSuchMethod instanceof Callable) {
/* 2581 */         value = new NoSuchMethodShim((Callable)noSuchMethod, property);
/*      */       }
/*      */     } 
/* 2584 */     if (!(value instanceof Callable)) {
/* 2585 */       throw notFunctionError(thisObj, value, property);
/*      */     }
/*      */     
/* 2588 */     storeScriptable(cx, thisObj);
/* 2589 */     return (Callable)value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Callable getValueFunctionAndThis(Object value, Context cx) {
/* 2599 */     if (!(value instanceof Callable)) {
/* 2600 */       throw notFunctionError(value);
/*      */     }
/*      */     
/* 2603 */     Callable f = (Callable)value;
/* 2604 */     Scriptable thisObj = null;
/* 2605 */     if (f instanceof Scriptable) {
/* 2606 */       thisObj = ((Scriptable)f).getParentScope();
/*      */     }
/* 2608 */     if (thisObj == null) {
/* 2609 */       if (cx.topCallScope == null) throw new IllegalStateException(); 
/* 2610 */       thisObj = cx.topCallScope;
/*      */     } 
/* 2612 */     if (thisObj.getParentScope() != null && 
/* 2613 */       !(thisObj instanceof NativeWith))
/*      */     {
/*      */       
/* 2616 */       if (thisObj instanceof NativeCall)
/*      */       {
/* 2618 */         thisObj = ScriptableObject.getTopLevelScope(thisObj);
/*      */       }
/*      */     }
/* 2621 */     storeScriptable(cx, thisObj);
/* 2622 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callIterator(Object obj, Context cx, Scriptable scope) {
/* 2632 */     Callable getIterator = getElemFunctionAndThis(obj, SymbolKey.ITERATOR, cx, scope);
/* 2633 */     Scriptable iterable = lastStoredScriptable(cx);
/* 2634 */     return getIterator.call(cx, scope, iterable, emptyArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIteratorDone(Context cx, Object result) {
/* 2641 */     if (!(result instanceof Scriptable)) {
/* 2642 */       return false;
/*      */     }
/* 2644 */     Object prop = getObjectProp((Scriptable)result, "done", cx);
/* 2645 */     return toBoolean(prop);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ref callRef(Callable function, Scriptable thisObj, Object[] args, Context cx) {
/* 2656 */     if (function instanceof RefCallable) {
/* 2657 */       RefCallable rfunction = (RefCallable)function;
/* 2658 */       Ref ref = rfunction.refCall(cx, thisObj, args);
/* 2659 */       if (ref == null) {
/* 2660 */         throw new IllegalStateException(rfunction
/* 2661 */             .getClass().getName() + ".refCall() returned null");
/*      */       }
/* 2663 */       return ref;
/*      */     } 
/*      */     
/* 2666 */     String msg = getMessageById("msg.no.ref.from.function", new Object[] { toString(function) });
/* 2667 */     throw constructError("ReferenceError", msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable newObject(Object fun, Context cx, Scriptable scope, Object[] args) {
/* 2676 */     if (!(fun instanceof Function)) {
/* 2677 */       throw notFunctionError(fun);
/*      */     }
/* 2679 */     Function function = (Function)fun;
/* 2680 */     return function.construct(cx, scope, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callSpecial(Context cx, Callable fun, Scriptable thisObj, Object[] args, Scriptable scope, Scriptable callerThis, int callType, String filename, int lineNumber) {
/* 2693 */     if (callType == 1) {
/* 2694 */       if (thisObj.getParentScope() == null && NativeGlobal.isEvalFunction(fun)) {
/* 2695 */         return evalSpecial(cx, scope, callerThis, args, filename, lineNumber);
/*      */       }
/* 2697 */     } else if (callType == 2) {
/* 2698 */       if (NativeWith.isWithFunction(fun)) {
/* 2699 */         throw Context.reportRuntimeErrorById("msg.only.from.new", new Object[] { "With" });
/*      */       }
/*      */     } else {
/* 2702 */       throw Kit.codeBug();
/*      */     } 
/*      */     
/* 2705 */     return fun.call(cx, scope, thisObj, args);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object newSpecial(Context cx, Object fun, Object[] args, Scriptable scope, int callType) {
/* 2710 */     if (callType == 1) {
/* 2711 */       if (NativeGlobal.isEvalFunction(fun)) {
/* 2712 */         throw typeErrorById("msg.not.ctor", new Object[] { "eval" });
/*      */       }
/* 2714 */     } else if (callType == 2) {
/* 2715 */       if (NativeWith.isWithFunction(fun)) {
/* 2716 */         return NativeWith.newWithSpecial(cx, scope, args);
/*      */       }
/*      */     } else {
/* 2719 */       throw Kit.codeBug();
/*      */     } 
/*      */     
/* 2722 */     return newObject(fun, cx, scope, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object applyOrCall(boolean isApply, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*      */     Object[] callArgs;
/* 2732 */     int L = args.length;
/* 2733 */     Callable function = getCallable(thisObj);
/*      */     
/* 2735 */     Scriptable callThis = null;
/* 2736 */     if (L != 0) {
/* 2737 */       if (cx.hasFeature(15)) {
/* 2738 */         callThis = toObjectOrNull(cx, args[0], scope);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2743 */         callThis = (args[0] == Undefined.instance) ? Undefined.SCRIPTABLE_UNDEFINED : toObjectOrNull(cx, args[0], scope);
/*      */       } 
/*      */     }
/* 2746 */     if (callThis == null && cx.hasFeature(15))
/*      */     {
/* 2748 */       callThis = getTopCallScope(cx);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2753 */     if (isApply) {
/*      */       
/* 2755 */       callArgs = (L <= 1) ? emptyArgs : getApplyArguments(cx, args[1]);
/*      */     
/*      */     }
/* 2758 */     else if (L <= 1) {
/* 2759 */       callArgs = emptyArgs;
/*      */     } else {
/* 2761 */       callArgs = new Object[L - 1];
/* 2762 */       System.arraycopy(args, 1, callArgs, 0, L - 1);
/*      */     } 
/*      */ 
/*      */     
/* 2766 */     return function.call(cx, scope, callThis, callArgs);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isArrayLike(Scriptable obj) {
/* 2771 */     return (obj != null && (obj instanceof NativeArray || obj instanceof Arguments || 
/*      */ 
/*      */       
/* 2774 */       ScriptableObject.hasProperty(obj, "length")));
/*      */   }
/*      */   
/*      */   static Object[] getApplyArguments(Context cx, Object arg1) {
/* 2778 */     if (arg1 == null || Undefined.isUndefined(arg1))
/* 2779 */       return emptyArgs; 
/* 2780 */     if (arg1 instanceof Scriptable && isArrayLike((Scriptable)arg1))
/* 2781 */       return cx.getElements((Scriptable)arg1); 
/* 2782 */     if (arg1 instanceof ScriptableObject) {
/* 2783 */       return emptyArgs;
/*      */     }
/* 2785 */     throw typeErrorById("msg.arg.isnt.array", new Object[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   static Callable getCallable(Scriptable thisObj) {
/*      */     Callable function;
/* 2791 */     if (thisObj instanceof Callable)
/* 2792 */     { function = (Callable)thisObj; }
/* 2793 */     else { if (thisObj == null) {
/* 2794 */         throw notFunctionError(null, null);
/*      */       }
/* 2796 */       Object value = thisObj.getDefaultValue(FunctionClass);
/* 2797 */       if (!(value instanceof Callable)) {
/* 2798 */         throw notFunctionError(value, thisObj);
/*      */       }
/* 2800 */       function = (Callable)value; }
/*      */     
/* 2802 */     return function;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object evalSpecial(Context cx, Scriptable scope, Object thisArg, Object[] args, String filename, int lineNumber) {
/* 2817 */     if (args.length < 1) return Undefined.instance; 
/* 2818 */     Object x = args[0];
/* 2819 */     if (!(x instanceof CharSequence)) {
/* 2820 */       if (cx.hasFeature(11) || cx
/* 2821 */         .hasFeature(9)) {
/* 2822 */         throw Context.reportRuntimeErrorById("msg.eval.nonstring.strict", new Object[0]);
/*      */       }
/* 2824 */       String message = getMessageById("msg.eval.nonstring", new Object[0]);
/* 2825 */       Context.reportWarning(message);
/* 2826 */       return x;
/*      */     } 
/* 2828 */     if (filename == null) {
/* 2829 */       int[] linep = new int[1];
/* 2830 */       filename = Context.getSourcePositionFromStack(linep);
/* 2831 */       if (filename != null) {
/* 2832 */         lineNumber = linep[0];
/*      */       } else {
/* 2834 */         filename = "";
/*      */       } 
/*      */     } 
/* 2837 */     String sourceName = makeUrlForGeneratedScript(true, filename, lineNumber);
/*      */ 
/*      */     
/* 2840 */     ErrorReporter reporter = DefaultErrorReporter.forEval(cx.getErrorReporter());
/*      */     
/* 2842 */     Evaluator evaluator = Context.createInterpreter();
/* 2843 */     if (evaluator == null) {
/* 2844 */       throw new JavaScriptException("Interpreter not present", filename, lineNumber);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2849 */     Script script = cx.compileString(x.toString(), evaluator, reporter, sourceName, 1, null);
/* 2850 */     evaluator.setEvalScriptFlag(script);
/* 2851 */     Callable c = (Callable)script;
/* 2852 */     return c.call(cx, scope, (Scriptable)thisArg, emptyArgs);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String typeof(Object value) {
/* 2857 */     if (value == null) return "object"; 
/* 2858 */     if (value == Undefined.instance) return "undefined"; 
/* 2859 */     if (value instanceof Delegator) return typeof(((Delegator)value).getDelegee()); 
/* 2860 */     if (value instanceof ScriptableObject) return ((ScriptableObject)value).getTypeOf(); 
/* 2861 */     if (value instanceof Scriptable) return (value instanceof Callable) ? "function" : "object"; 
/* 2862 */     if (value instanceof CharSequence) return "string"; 
/* 2863 */     if (value instanceof BigInteger) return "bigint"; 
/* 2864 */     if (value instanceof Number) return "number"; 
/* 2865 */     if (value instanceof Boolean) return "boolean"; 
/* 2866 */     throw errorWithClassName("msg.invalid.type", value);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String typeofName(Scriptable scope, String id) {
/* 2871 */     Context cx = Context.getContext();
/* 2872 */     Scriptable val = bind(cx, scope, id);
/* 2873 */     if (val == null) return "undefined"; 
/* 2874 */     return typeof(getObjectProp(val, id, cx));
/*      */   }
/*      */   
/*      */   public static boolean isObject(Object value) {
/* 2878 */     if (value == null) {
/* 2879 */       return false;
/*      */     }
/* 2881 */     if (Undefined.isUndefined(value)) {
/* 2882 */       return false;
/*      */     }
/* 2884 */     if (value instanceof ScriptableObject) {
/* 2885 */       String type = ((ScriptableObject)value).getTypeOf();
/* 2886 */       return ("object".equals(type) || "function".equals(type));
/*      */     } 
/* 2888 */     if (value instanceof Scriptable) {
/* 2889 */       return !(value instanceof Callable);
/*      */     }
/* 2891 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object add(Object val1, Object val2, Context cx) {
/* 2907 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger) {
/* 2908 */       return ((BigInteger)val1).add((BigInteger)val2);
/*      */     }
/* 2910 */     if ((val1 instanceof Number && val2 instanceof BigInteger) || (val1 instanceof BigInteger && val2 instanceof Number))
/*      */     {
/* 2912 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 2914 */     if (val1 instanceof Number && val2 instanceof Number) {
/* 2915 */       return wrapNumber(((Number)val1).doubleValue() + ((Number)val2).doubleValue());
/*      */     }
/* 2917 */     if (val1 instanceof CharSequence && val2 instanceof CharSequence)
/*      */     {
/*      */       
/* 2920 */       return new ConsString((CharSequence)val1, (CharSequence)val2);
/*      */     }
/* 2922 */     if (val1 instanceof XMLObject) {
/* 2923 */       Object test = ((XMLObject)val1).addValues(cx, true, val2);
/* 2924 */       if (test != Scriptable.NOT_FOUND) {
/* 2925 */         return test;
/*      */       }
/*      */     } 
/* 2928 */     if (val2 instanceof XMLObject) {
/* 2929 */       Object test = ((XMLObject)val2).addValues(cx, false, val1);
/* 2930 */       if (test != Scriptable.NOT_FOUND) {
/* 2931 */         return test;
/*      */       }
/*      */     } 
/* 2934 */     if (val1 instanceof Symbol || val2 instanceof Symbol) {
/* 2935 */       throw typeErrorById("msg.not.a.number", new Object[0]);
/*      */     }
/* 2937 */     if (val1 instanceof Scriptable) val1 = ((Scriptable)val1).getDefaultValue(null); 
/* 2938 */     if (val2 instanceof Scriptable) val2 = ((Scriptable)val2).getDefaultValue(null); 
/* 2939 */     if (!(val1 instanceof CharSequence) && !(val2 instanceof CharSequence)) {
/* 2940 */       Number num1 = (val1 instanceof Number) ? (Number)val1 : toNumeric(val1);
/* 2941 */       Number num2 = (val2 instanceof Number) ? (Number)val2 : toNumeric(val2);
/*      */       
/* 2943 */       if (num1 instanceof BigInteger && num2 instanceof BigInteger) {
/* 2944 */         return ((BigInteger)num1).add((BigInteger)num2);
/*      */       }
/* 2946 */       if (num1 instanceof BigInteger || num2 instanceof BigInteger) {
/* 2947 */         throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */       }
/* 2949 */       return Double.valueOf(num1.doubleValue() + num2.doubleValue());
/*      */     } 
/* 2951 */     return new ConsString(toCharSequence(val1), toCharSequence(val2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static CharSequence add(CharSequence val1, Object val2) {
/* 2965 */     return new ConsString(val1, toCharSequence(val2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static CharSequence add(Object val1, CharSequence val2) {
/* 2979 */     return new ConsString(toCharSequence(val1), val2);
/*      */   }
/*      */   
/*      */   public static Number subtract(Number val1, Number val2) {
/* 2983 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger)
/* 2984 */       return ((BigInteger)val1).subtract((BigInteger)val2); 
/* 2985 */     if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 2986 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 2988 */     return Double.valueOf(val1.doubleValue() - val2.doubleValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number multiply(Number val1, Number val2) {
/* 2993 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger)
/* 2994 */       return ((BigInteger)val1).multiply((BigInteger)val2); 
/* 2995 */     if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 2996 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 2998 */     return Double.valueOf(val1.doubleValue() * val2.doubleValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number divide(Number val1, Number val2) {
/* 3003 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger) {
/* 3004 */       if (val2.equals(BigInteger.ZERO)) {
/* 3005 */         throw rangeErrorById("msg.division.zero", new Object[0]);
/*      */       }
/* 3007 */       return ((BigInteger)val1).divide((BigInteger)val2);
/* 3008 */     }  if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 3009 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 3011 */     return Double.valueOf(val1.doubleValue() / val2.doubleValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number remainder(Number val1, Number val2) {
/* 3016 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger) {
/* 3017 */       if (val2.equals(BigInteger.ZERO)) {
/* 3018 */         throw rangeErrorById("msg.division.zero", new Object[0]);
/*      */       }
/* 3020 */       return ((BigInteger)val1).remainder((BigInteger)val2);
/* 3021 */     }  if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 3022 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 3024 */     return Double.valueOf(val1.doubleValue() % val2.doubleValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number exponentiate(Number val1, Number val2) {
/* 3029 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger) {
/* 3030 */       if (((BigInteger)val2).signum() == -1) {
/* 3031 */         throw rangeErrorById("msg.bigint.negative.exponent", new Object[0]);
/*      */       }
/*      */       
/*      */       try {
/* 3035 */         int intVal2 = ((BigInteger)val2).intValueExact();
/* 3036 */         return ((BigInteger)val1).pow(intVal2);
/* 3037 */       } catch (ArithmeticException e) {
/*      */         
/* 3039 */         throw rangeErrorById("msg.bigint.out.of.range.arithmetic", new Object[0]);
/*      */       } 
/* 3041 */     }  if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 3042 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 3044 */     return Double.valueOf(Math.pow(val1.doubleValue(), val2.doubleValue()));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number bitwiseAND(Number val1, Number val2) {
/* 3049 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger)
/* 3050 */       return ((BigInteger)val1).and((BigInteger)val2); 
/* 3051 */     if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 3052 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 3054 */     int result = toInt32(val1.doubleValue()) & toInt32(val2.doubleValue());
/* 3055 */     return Double.valueOf(result);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number bitwiseOR(Number val1, Number val2) {
/* 3060 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger)
/* 3061 */       return ((BigInteger)val1).or((BigInteger)val2); 
/* 3062 */     if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 3063 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 3065 */     int result = toInt32(val1.doubleValue()) | toInt32(val2.doubleValue());
/* 3066 */     return Double.valueOf(result);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number bitwiseXOR(Number val1, Number val2) {
/* 3071 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger)
/* 3072 */       return ((BigInteger)val1).xor((BigInteger)val2); 
/* 3073 */     if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 3074 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 3076 */     int result = toInt32(val1.doubleValue()) ^ toInt32(val2.doubleValue());
/* 3077 */     return Double.valueOf(result);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number leftShift(Number val1, Number val2) {
/* 3082 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger)
/*      */       try {
/* 3084 */         int intVal2 = ((BigInteger)val2).intValueExact();
/* 3085 */         return ((BigInteger)val1).shiftLeft(intVal2);
/* 3086 */       } catch (ArithmeticException e) {
/*      */         
/* 3088 */         throw rangeErrorById("msg.bigint.out.of.range.arithmetic", new Object[0]);
/*      */       }  
/* 3090 */     if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 3091 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 3093 */     int result = toInt32(val1.doubleValue()) << toInt32(val2.doubleValue());
/* 3094 */     return Double.valueOf(result);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number signedRightShift(Number val1, Number val2) {
/* 3099 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger)
/*      */       try {
/* 3101 */         int intVal2 = ((BigInteger)val2).intValueExact();
/* 3102 */         return ((BigInteger)val1).shiftRight(intVal2);
/* 3103 */       } catch (ArithmeticException e) {
/*      */         
/* 3105 */         throw rangeErrorById("msg.bigint.out.of.range.arithmetic", new Object[0]);
/*      */       }  
/* 3107 */     if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/* 3108 */       throw typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */     }
/* 3110 */     int result = toInt32(val1.doubleValue()) >> toInt32(val2.doubleValue());
/* 3111 */     return Double.valueOf(result);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Number bitwiseNOT(Number val) {
/* 3116 */     if (val instanceof BigInteger) {
/* 3117 */       return ((BigInteger)val).not();
/*      */     }
/* 3119 */     int result = toInt32(val.doubleValue()) ^ 0xFFFFFFFF;
/* 3120 */     return Double.valueOf(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object nameIncrDecr(Scriptable scopeChain, String id, int incrDecrMask) {
/* 3131 */     return nameIncrDecr(scopeChain, id, Context.getContext(), incrDecrMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object nameIncrDecr(Scriptable scopeChain, String id, Context cx, int incrDecrMask) {
/*      */     // Byte code:
/*      */     //   0: aload_2
/*      */     //   1: getfield useDynamicScope : Z
/*      */     //   4: ifeq -> 25
/*      */     //   7: aload_0
/*      */     //   8: invokeinterface getParentScope : ()Lorg/mozilla/javascript/Scriptable;
/*      */     //   13: ifnonnull -> 25
/*      */     //   16: aload_2
/*      */     //   17: getfield topCallScope : Lorg/mozilla/javascript/Scriptable;
/*      */     //   20: aload_0
/*      */     //   21: invokestatic checkDynamicScope : (Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;)Lorg/mozilla/javascript/Scriptable;
/*      */     //   24: astore_0
/*      */     //   25: aload_0
/*      */     //   26: astore #4
/*      */     //   28: aload #4
/*      */     //   30: instanceof org/mozilla/javascript/NativeWith
/*      */     //   33: ifeq -> 52
/*      */     //   36: aload #4
/*      */     //   38: invokeinterface getPrototype : ()Lorg/mozilla/javascript/Scriptable;
/*      */     //   43: instanceof org/mozilla/javascript/xml/XMLObject
/*      */     //   46: ifeq -> 52
/*      */     //   49: goto -> 88
/*      */     //   52: aload #4
/*      */     //   54: aload_1
/*      */     //   55: aload_0
/*      */     //   56: invokeinterface get : (Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;)Ljava/lang/Object;
/*      */     //   61: astore #5
/*      */     //   63: aload #5
/*      */     //   65: getstatic org/mozilla/javascript/Scriptable.NOT_FOUND : Ljava/lang/Object;
/*      */     //   68: if_acmpeq -> 74
/*      */     //   71: goto -> 105
/*      */     //   74: aload #4
/*      */     //   76: invokeinterface getPrototype : ()Lorg/mozilla/javascript/Scriptable;
/*      */     //   81: astore #4
/*      */     //   83: aload #4
/*      */     //   85: ifnonnull -> 28
/*      */     //   88: aload_0
/*      */     //   89: invokeinterface getParentScope : ()Lorg/mozilla/javascript/Scriptable;
/*      */     //   94: astore_0
/*      */     //   95: aload_0
/*      */     //   96: ifnonnull -> 0
/*      */     //   99: aconst_null
/*      */     //   100: aload_1
/*      */     //   101: invokestatic notFoundError : (Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Ljava/lang/RuntimeException;
/*      */     //   104: athrow
/*      */     //   105: aload #4
/*      */     //   107: aload_1
/*      */     //   108: aload_0
/*      */     //   109: aload #5
/*      */     //   111: iload_3
/*      */     //   112: invokestatic doScriptableIncrDecr : (Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;I)Ljava/lang/Object;
/*      */     //   115: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #3141	-> 0
/*      */     //   #3142	-> 16
/*      */     //   #3144	-> 25
/*      */     //   #3146	-> 28
/*      */     //   #3147	-> 38
/*      */     //   #3148	-> 49
/*      */     //   #3150	-> 52
/*      */     //   #3151	-> 63
/*      */     //   #3152	-> 71
/*      */     //   #3154	-> 74
/*      */     //   #3155	-> 83
/*      */     //   #3156	-> 88
/*      */     //   #3157	-> 95
/*      */     //   #3158	-> 99
/*      */     //   #3160	-> 105
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   63	25	5	value	Ljava/lang/Object;
/*      */     //   0	116	0	scopeChain	Lorg/mozilla/javascript/Scriptable;
/*      */     //   0	116	1	id	Ljava/lang/String;
/*      */     //   0	116	2	cx	Lorg/mozilla/javascript/Context;
/*      */     //   0	116	3	incrDecrMask	I
/*      */     //   28	88	4	target	Lorg/mozilla/javascript/Scriptable;
/*      */     //   105	11	5	value	Ljava/lang/Object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object propIncrDecr(Object obj, String id, Context cx, int incrDecrMask) {
/* 3166 */     return propIncrDecr(obj, id, cx, getTopCallScope(cx), incrDecrMask);
/*      */   }
/*      */   
/*      */   public static Object propIncrDecr(Object obj, String id, Context cx, Scriptable scope, int incrDecrMask) {
/*      */     Object value;
/* 3171 */     Scriptable start = toObjectOrNull(cx, obj, scope);
/* 3172 */     if (start == null) {
/* 3173 */       throw undefReadError(obj, id);
/*      */     }
/*      */     
/* 3176 */     Scriptable target = start;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 3181 */       value = target.get(id, start);
/* 3182 */       if (value != Scriptable.NOT_FOUND) {
/*      */         break;
/*      */       }
/* 3185 */       target = target.getPrototype();
/* 3186 */       if (target == null) {
/* 3187 */         start.put(id, start, NaNobj);
/* 3188 */         return NaNobj;
/*      */       } 
/* 3190 */     }  return doScriptableIncrDecr(target, id, start, value, incrDecrMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object doScriptableIncrDecr(Scriptable target, String id, Scriptable protoChainStart, Object value, int incrDecrMask) {
/*      */     Number number, result;
/* 3199 */     boolean post = ((incrDecrMask & 0x2) != 0);
/*      */ 
/*      */     
/* 3202 */     if (value instanceof Number) {
/* 3203 */       number = (Number)value;
/*      */     } else {
/* 3205 */       number = toNumeric(value);
/*      */     } 
/*      */ 
/*      */     
/* 3209 */     if (number instanceof BigInteger) {
/* 3210 */       if ((incrDecrMask & 0x1) == 0) {
/* 3211 */         result = ((BigInteger)number).add(BigInteger.ONE);
/*      */       } else {
/* 3213 */         result = ((BigInteger)number).subtract(BigInteger.ONE);
/*      */       }
/*      */     
/* 3216 */     } else if ((incrDecrMask & 0x1) == 0) {
/* 3217 */       result = Double.valueOf(number.doubleValue() + 1.0D);
/*      */     } else {
/* 3219 */       result = Double.valueOf(number.doubleValue() - 1.0D);
/*      */     } 
/*      */ 
/*      */     
/* 3223 */     target.put(id, protoChainStart, result);
/* 3224 */     if (post) {
/* 3225 */       return number;
/*      */     }
/* 3227 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object elemIncrDecr(Object obj, Object index, Context cx, int incrDecrMask) {
/* 3233 */     return elemIncrDecr(obj, index, cx, getTopCallScope(cx), incrDecrMask);
/*      */   }
/*      */   
/*      */   public static Object elemIncrDecr(Object obj, Object index, Context cx, Scriptable scope, int incrDecrMask) {
/*      */     Number number, result;
/* 3238 */     Object value = getObjectElem(obj, index, cx, scope);
/* 3239 */     boolean post = ((incrDecrMask & 0x2) != 0);
/*      */ 
/*      */     
/* 3242 */     if (value instanceof Number) {
/* 3243 */       number = (Number)value;
/*      */     } else {
/* 3245 */       number = toNumeric(value);
/*      */     } 
/*      */ 
/*      */     
/* 3249 */     if (number instanceof BigInteger) {
/* 3250 */       if ((incrDecrMask & 0x1) == 0) {
/* 3251 */         result = ((BigInteger)number).add(BigInteger.ONE);
/*      */       } else {
/* 3253 */         result = ((BigInteger)number).subtract(BigInteger.ONE);
/*      */       }
/*      */     
/* 3256 */     } else if ((incrDecrMask & 0x1) == 0) {
/* 3257 */       result = Double.valueOf(number.doubleValue() + 1.0D);
/*      */     } else {
/* 3259 */       result = Double.valueOf(number.doubleValue() - 1.0D);
/*      */     } 
/*      */ 
/*      */     
/* 3263 */     setObjectElem(obj, index, result, cx, scope);
/* 3264 */     if (post) {
/* 3265 */       return number;
/*      */     }
/* 3267 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object refIncrDecr(Ref ref, Context cx, int incrDecrMask) {
/* 3273 */     return refIncrDecr(ref, cx, getTopCallScope(cx), incrDecrMask);
/*      */   }
/*      */   public static Object refIncrDecr(Ref ref, Context cx, Scriptable scope, int incrDecrMask) {
/*      */     Number number, result;
/* 3277 */     Object value = ref.get(cx);
/* 3278 */     boolean post = ((incrDecrMask & 0x2) != 0);
/*      */ 
/*      */     
/* 3281 */     if (value instanceof Number) {
/* 3282 */       number = (Number)value;
/*      */     } else {
/* 3284 */       number = toNumeric(value);
/*      */     } 
/*      */ 
/*      */     
/* 3288 */     if (number instanceof BigInteger) {
/* 3289 */       if ((incrDecrMask & 0x1) == 0) {
/* 3290 */         result = ((BigInteger)number).add(BigInteger.ONE);
/*      */       } else {
/* 3292 */         result = ((BigInteger)number).subtract(BigInteger.ONE);
/*      */       }
/*      */     
/* 3295 */     } else if ((incrDecrMask & 0x1) == 0) {
/* 3296 */       result = Double.valueOf(number.doubleValue() + 1.0D);
/*      */     } else {
/* 3298 */       result = Double.valueOf(number.doubleValue() - 1.0D);
/*      */     } 
/*      */ 
/*      */     
/* 3302 */     ref.set(cx, scope, result);
/* 3303 */     if (post) {
/* 3304 */       return number;
/*      */     }
/* 3306 */     return result;
/*      */   }
/*      */   
/*      */   public static Number negate(Number val) {
/* 3310 */     if (val instanceof BigInteger) {
/* 3311 */       return ((BigInteger)val).negate();
/*      */     }
/* 3313 */     return Double.valueOf(-val.doubleValue());
/*      */   }
/*      */   
/*      */   public static Object toPrimitive(Object val) {
/* 3317 */     return toPrimitive(val, null);
/*      */   }
/*      */   
/*      */   public static Object toPrimitive(Object val, Class<?> typeHint) {
/* 3321 */     if (!(val instanceof Scriptable)) {
/* 3322 */       return val;
/*      */     }
/* 3324 */     Scriptable s = (Scriptable)val;
/* 3325 */     Object result = s.getDefaultValue(typeHint);
/* 3326 */     if (result instanceof Scriptable && !isSymbol(result))
/* 3327 */       throw typeErrorById("msg.bad.default.value", new Object[0]); 
/* 3328 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean eq(Object x, Object y) {
/* 3337 */     if (x == null || Undefined.isUndefined(x)) {
/* 3338 */       if (y == null || Undefined.isUndefined(y)) {
/* 3339 */         return true;
/*      */       }
/* 3341 */       if (y instanceof ScriptableObject) {
/* 3342 */         Object test = ((ScriptableObject)y).equivalentValues(x);
/* 3343 */         if (test != Scriptable.NOT_FOUND) {
/* 3344 */           return ((Boolean)test).booleanValue();
/*      */         }
/*      */       } 
/* 3347 */       return false;
/* 3348 */     }  if (x instanceof BigInteger)
/* 3349 */       return eqBigInt((BigInteger)x, y); 
/* 3350 */     if (x instanceof Number)
/* 3351 */       return eqNumber(((Number)x).doubleValue(), y); 
/* 3352 */     if (x == y)
/* 3353 */       return true; 
/* 3354 */     if (x instanceof CharSequence)
/* 3355 */       return eqString((CharSequence)x, y); 
/* 3356 */     if (x instanceof Boolean) {
/* 3357 */       boolean b = ((Boolean)x).booleanValue();
/* 3358 */       if (y instanceof Boolean) {
/* 3359 */         return (b == ((Boolean)y).booleanValue());
/*      */       }
/* 3361 */       if (y instanceof ScriptableObject) {
/* 3362 */         Object test = ((ScriptableObject)y).equivalentValues(x);
/* 3363 */         if (test != Scriptable.NOT_FOUND) {
/* 3364 */           return ((Boolean)test).booleanValue();
/*      */         }
/*      */       } 
/* 3367 */       return eqNumber(b ? 1.0D : 0.0D, y);
/* 3368 */     }  if (x instanceof Scriptable) {
/* 3369 */       if (x instanceof Delegator) {
/* 3370 */         x = ((Delegator)x).getDelegee();
/* 3371 */         if (y instanceof Delegator) {
/* 3372 */           return eq(x, ((Delegator)y).getDelegee());
/*      */         }
/* 3374 */         if (x == y) {
/* 3375 */           return true;
/*      */         }
/*      */       } 
/* 3378 */       if (y instanceof Delegator && ((Delegator)y).getDelegee() == x) {
/* 3379 */         return true;
/*      */       }
/*      */       
/* 3382 */       if (y instanceof Scriptable) {
/* 3383 */         if (x instanceof ScriptableObject) {
/* 3384 */           Object test = ((ScriptableObject)x).equivalentValues(y);
/* 3385 */           if (test != Scriptable.NOT_FOUND) {
/* 3386 */             return ((Boolean)test).booleanValue();
/*      */           }
/*      */         } 
/* 3389 */         if (y instanceof ScriptableObject) {
/* 3390 */           Object test = ((ScriptableObject)y).equivalentValues(x);
/* 3391 */           if (test != Scriptable.NOT_FOUND) {
/* 3392 */             return ((Boolean)test).booleanValue();
/*      */           }
/*      */         } 
/* 3395 */         if (x instanceof Wrapper && y instanceof Wrapper) {
/*      */ 
/*      */           
/* 3398 */           Object unwrappedX = ((Wrapper)x).unwrap();
/* 3399 */           Object unwrappedY = ((Wrapper)y).unwrap();
/* 3400 */           return (unwrappedX == unwrappedY || (
/* 3401 */             isPrimitive(unwrappedX) && 
/* 3402 */             isPrimitive(unwrappedY) && 
/* 3403 */             eq(unwrappedX, unwrappedY)));
/*      */         } 
/* 3405 */         return false;
/* 3406 */       }  if (y instanceof Boolean) {
/* 3407 */         if (x instanceof ScriptableObject) {
/* 3408 */           Object test = ((ScriptableObject)x).equivalentValues(y);
/* 3409 */           if (test != Scriptable.NOT_FOUND) {
/* 3410 */             return ((Boolean)test).booleanValue();
/*      */           }
/*      */         } 
/* 3413 */         double d = ((Boolean)y).booleanValue() ? 1.0D : 0.0D;
/* 3414 */         return eqNumber(d, x);
/* 3415 */       }  if (y instanceof BigInteger)
/* 3416 */         return eqBigInt((BigInteger)y, x); 
/* 3417 */       if (y instanceof Number)
/* 3418 */         return eqNumber(((Number)y).doubleValue(), x); 
/* 3419 */       if (y instanceof CharSequence) {
/* 3420 */         return eqString((CharSequence)y, x);
/*      */       }
/*      */       
/* 3423 */       return false;
/*      */     } 
/* 3425 */     warnAboutNonJSObject(x);
/* 3426 */     return (x == y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean same(Object x, Object y) {
/* 3435 */     if (!typeof(x).equals(typeof(y))) {
/* 3436 */       return false;
/*      */     }
/* 3438 */     if (x instanceof Number) {
/* 3439 */       if (isNaN(x) && isNaN(y)) {
/* 3440 */         return true;
/*      */       }
/* 3442 */       return x.equals(y);
/*      */     } 
/* 3444 */     return eq(x, y);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean sameZero(Object x, Object y) {
/* 3449 */     if (!typeof(x).equals(typeof(y))) {
/* 3450 */       return false;
/*      */     }
/* 3452 */     if (x instanceof BigInteger) {
/* 3453 */       return x.equals(y);
/*      */     }
/* 3455 */     if (x instanceof Number) {
/* 3456 */       if (isNaN(x) && isNaN(y)) {
/* 3457 */         return true;
/*      */       }
/* 3459 */       double dx = ((Number)x).doubleValue();
/* 3460 */       if (y instanceof Number) {
/* 3461 */         double dy = ((Number)y).doubleValue();
/* 3462 */         if ((dx == negativeZero && dy == 0.0D) || (dx == 0.0D && dy == negativeZero)) {
/* 3463 */           return true;
/*      */         }
/*      */       } 
/* 3466 */       return eqNumber(dx, y);
/*      */     } 
/* 3468 */     return eq(x, y);
/*      */   }
/*      */   
/*      */   public static boolean isNaN(Object n) {
/* 3472 */     if (n instanceof Double) {
/* 3473 */       return ((Double)n).isNaN();
/*      */     }
/* 3475 */     if (n instanceof Float) {
/* 3476 */       return ((Float)n).isNaN();
/*      */     }
/* 3478 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isPrimitive(Object obj) {
/* 3482 */     return (obj == null || 
/* 3483 */       Undefined.isUndefined(obj) || obj instanceof Number || obj instanceof String || obj instanceof Boolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean eqNumber(double x, Object y) {
/*      */     while (true) {
/* 3491 */       if (y == null || Undefined.isUndefined(y))
/* 3492 */         return false; 
/* 3493 */       if (y instanceof BigInteger)
/* 3494 */         return eqBigInt((BigInteger)y, x); 
/* 3495 */       if (y instanceof Number)
/* 3496 */         return (x == ((Number)y).doubleValue()); 
/* 3497 */       if (y instanceof CharSequence)
/* 3498 */         return (x == toNumber(y)); 
/* 3499 */       if (y instanceof Boolean)
/* 3500 */         return (x == (((Boolean)y).booleanValue() ? 1.0D : 0.0D)); 
/* 3501 */       if (isSymbol(y))
/* 3502 */         return false; 
/* 3503 */       if (y instanceof Scriptable) {
/* 3504 */         if (y instanceof ScriptableObject) {
/* 3505 */           Object xval = wrapNumber(x);
/* 3506 */           Object test = ((ScriptableObject)y).equivalentValues(xval);
/* 3507 */           if (test != Scriptable.NOT_FOUND) {
/* 3508 */             return ((Boolean)test).booleanValue();
/*      */           }
/*      */         } 
/* 3511 */         y = toPrimitive(y); continue;
/*      */       }  break;
/* 3513 */     }  warnAboutNonJSObject(y);
/* 3514 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean eqBigInt(BigInteger x, Object y) {
/*      */     while (true) {
/* 3521 */       if (y == null || Undefined.isUndefined(y))
/* 3522 */         return false; 
/* 3523 */       if (y instanceof BigInteger)
/* 3524 */         return x.equals(y); 
/* 3525 */       if (y instanceof Number)
/* 3526 */         return eqBigInt(x, ((Number)y).doubleValue()); 
/* 3527 */       if (y instanceof CharSequence) {
/*      */         BigInteger biy;
/*      */         try {
/* 3530 */           biy = toBigInt(y);
/* 3531 */         } catch (EcmaError e) {
/* 3532 */           return false;
/*      */         } 
/* 3534 */         return x.equals(biy);
/* 3535 */       }  if (y instanceof Boolean) {
/* 3536 */         BigInteger biy = ((Boolean)y).booleanValue() ? BigInteger.ONE : BigInteger.ZERO;
/* 3537 */         return x.equals(biy);
/* 3538 */       }  if (isSymbol(y))
/* 3539 */         return false; 
/* 3540 */       if (y instanceof Scriptable) {
/* 3541 */         if (y instanceof ScriptableObject) {
/* 3542 */           Object test = ((ScriptableObject)y).equivalentValues(x);
/* 3543 */           if (test != Scriptable.NOT_FOUND) {
/* 3544 */             return ((Boolean)test).booleanValue();
/*      */           }
/*      */         } 
/* 3547 */         y = toPrimitive(y); continue;
/*      */       }  break;
/* 3549 */     }  warnAboutNonJSObject(y);
/* 3550 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean eqBigInt(BigInteger x, double y) {
/* 3556 */     if (Double.isNaN(y) || Double.isInfinite(y)) {
/* 3557 */       return false;
/*      */     }
/*      */     
/* 3560 */     double d = Math.ceil(y);
/* 3561 */     if (d != y) {
/* 3562 */       return false;
/*      */     }
/*      */     
/* 3565 */     BigDecimal bdx = new BigDecimal(x);
/* 3566 */     BigDecimal bdy = new BigDecimal(d, MathContext.UNLIMITED);
/* 3567 */     return (bdx.compareTo(bdy) == 0);
/*      */   }
/*      */   
/*      */   private static boolean eqString(CharSequence x, Object y) {
/*      */     while (true) {
/* 3572 */       if (y == null || Undefined.isUndefined(y))
/* 3573 */         return false; 
/* 3574 */       if (y instanceof CharSequence) {
/* 3575 */         CharSequence c = (CharSequence)y;
/* 3576 */         return (x.length() == c.length() && x.toString().equals(c.toString()));
/* 3577 */       }  if (y instanceof BigInteger) {
/*      */         BigInteger bix;
/*      */         try {
/* 3580 */           bix = toBigInt(x);
/* 3581 */         } catch (EcmaError e) {
/* 3582 */           return false;
/*      */         } 
/* 3584 */         return bix.equals(y);
/* 3585 */       }  if (y instanceof Number)
/* 3586 */         return (toNumber(x.toString()) == ((Number)y).doubleValue()); 
/* 3587 */       if (y instanceof Boolean)
/* 3588 */         return (toNumber(x.toString()) == (((Boolean)y).booleanValue() ? 1.0D : 0.0D)); 
/* 3589 */       if (isSymbol(y))
/* 3590 */         return false; 
/* 3591 */       if (y instanceof Scriptable) {
/* 3592 */         if (y instanceof ScriptableObject) {
/* 3593 */           Object test = ((ScriptableObject)y).equivalentValues(x.toString());
/* 3594 */           if (test != Scriptable.NOT_FOUND) {
/* 3595 */             return ((Boolean)test).booleanValue();
/*      */           }
/*      */         } 
/* 3598 */         y = toPrimitive(y); continue;
/*      */       }  break;
/*      */     } 
/* 3601 */     warnAboutNonJSObject(y);
/* 3602 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean shallowEq(Object x, Object y) {
/* 3608 */     if (x == y) {
/* 3609 */       if (!(x instanceof Number)) {
/* 3610 */         return true;
/*      */       }
/*      */       
/* 3613 */       double d = ((Number)x).doubleValue();
/* 3614 */       return !Double.isNaN(d);
/*      */     } 
/* 3616 */     if (x == null || x == Undefined.instance || x == Undefined.SCRIPTABLE_UNDEFINED) {
/* 3617 */       if ((x == Undefined.instance && y == Undefined.SCRIPTABLE_UNDEFINED) || (x == Undefined.SCRIPTABLE_UNDEFINED && y == Undefined.instance))
/*      */       {
/* 3619 */         return true; } 
/* 3620 */       return false;
/* 3621 */     }  if (x instanceof BigInteger) {
/* 3622 */       if (y instanceof BigInteger) {
/* 3623 */         return x.equals(y);
/*      */       }
/* 3625 */     } else if (x instanceof Number && !(x instanceof BigInteger)) {
/* 3626 */       if (y instanceof Number && !(y instanceof BigInteger)) {
/* 3627 */         return (((Number)x).doubleValue() == ((Number)y).doubleValue());
/*      */       }
/* 3629 */     } else if (x instanceof CharSequence) {
/* 3630 */       if (y instanceof CharSequence) {
/* 3631 */         return x.toString().equals(y.toString());
/*      */       }
/* 3633 */     } else if (x instanceof Boolean) {
/* 3634 */       if (y instanceof Boolean) {
/* 3635 */         return x.equals(y);
/*      */       }
/* 3637 */     } else if (x instanceof Scriptable) {
/* 3638 */       if (x instanceof Wrapper && y instanceof Wrapper) {
/* 3639 */         return (((Wrapper)x).unwrap() == ((Wrapper)y).unwrap());
/*      */       }
/* 3641 */       if (x instanceof Delegator) {
/* 3642 */         x = ((Delegator)x).getDelegee();
/* 3643 */         if (y instanceof Delegator) {
/* 3644 */           return shallowEq(x, ((Delegator)y).getDelegee());
/*      */         }
/* 3646 */         if (x == y) {
/* 3647 */           return true;
/*      */         }
/*      */       } 
/* 3650 */       if (y instanceof Delegator && ((Delegator)y).getDelegee() == x) {
/* 3651 */         return true;
/*      */       }
/*      */     } else {
/* 3654 */       warnAboutNonJSObject(x);
/* 3655 */       return (x == y);
/*      */     } 
/* 3657 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean instanceOf(Object a, Object b, Context cx) {
/* 3667 */     if (!(b instanceof Scriptable)) {
/* 3668 */       throw typeErrorById("msg.instanceof.not.object", new Object[0]);
/*      */     }
/*      */ 
/*      */     
/* 3672 */     if (!(a instanceof Scriptable)) return false;
/*      */     
/* 3674 */     return ((Scriptable)b).hasInstance((Scriptable)a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean jsDelegatesTo(Scriptable lhs, Scriptable rhs) {
/* 3683 */     Scriptable proto = lhs.getPrototype();
/*      */     
/* 3685 */     while (proto != null) {
/* 3686 */       if (proto.equals(rhs)) return true; 
/* 3687 */       proto = proto.getPrototype();
/*      */     } 
/*      */     
/* 3690 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean in(Object a, Object b, Context cx) {
/* 3707 */     if (!(b instanceof Scriptable)) {
/* 3708 */       throw typeErrorById("msg.in.not.object", new Object[0]);
/*      */     }
/*      */     
/* 3711 */     return hasObjectElem((Scriptable)b, a, cx);
/*      */   }
/*      */   
/*      */   public static boolean compare(Object val1, Object val2, int op) {
/* 3715 */     assert op == 17 || op == 15 || op == 16 || op == 14;
/*      */     
/* 3717 */     if (val1 instanceof Number && val2 instanceof Number) {
/* 3718 */       return compare((Number)val1, (Number)val2, op);
/*      */     }
/* 3720 */     if (val1 instanceof Symbol || val2 instanceof Symbol) {
/* 3721 */       throw typeErrorById("msg.compare.symbol", new Object[0]);
/*      */     }
/* 3723 */     if (val1 instanceof Scriptable) {
/* 3724 */       val1 = ((Scriptable)val1).getDefaultValue(NumberClass);
/*      */     }
/* 3726 */     if (val2 instanceof Scriptable) {
/* 3727 */       val2 = ((Scriptable)val2).getDefaultValue(NumberClass);
/*      */     }
/* 3729 */     if (val1 instanceof CharSequence && val2 instanceof CharSequence) {
/* 3730 */       return compareTo(val1.toString(), val2.toString(), op);
/*      */     }
/* 3732 */     return compare(toNumeric(val1), toNumeric(val2), op);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean compare(Number val1, Number val2, int op) {
/* 3737 */     assert op == 17 || op == 15 || op == 16 || op == 14;
/*      */     
/* 3739 */     if (val1 instanceof BigInteger && val2 instanceof BigInteger)
/* 3740 */       return compareTo((BigInteger)val1, (BigInteger)val2, op); 
/* 3741 */     if (val1 instanceof BigInteger || val2 instanceof BigInteger) {
/*      */       BigDecimal bd1; BigDecimal bd2;
/* 3743 */       if (val1 instanceof BigInteger) {
/* 3744 */         bd1 = new BigDecimal((BigInteger)val1);
/*      */       } else {
/* 3746 */         double d = val1.doubleValue();
/* 3747 */         if (Double.isNaN(d))
/* 3748 */           return false; 
/* 3749 */         if (d == Double.POSITIVE_INFINITY)
/* 3750 */           return (op == 17 || op == 16); 
/* 3751 */         if (d == Double.NEGATIVE_INFINITY) {
/* 3752 */           return (op == 15 || op == 14);
/*      */         }
/* 3754 */         bd1 = new BigDecimal(d, MathContext.UNLIMITED);
/*      */       } 
/*      */ 
/*      */       
/* 3758 */       if (val2 instanceof BigInteger) {
/* 3759 */         bd2 = new BigDecimal((BigInteger)val2);
/*      */       } else {
/* 3761 */         double d = val2.doubleValue();
/* 3762 */         if (Double.isNaN(d))
/* 3763 */           return false; 
/* 3764 */         if (d == Double.POSITIVE_INFINITY)
/* 3765 */           return (op == 15 || op == 14); 
/* 3766 */         if (d == Double.NEGATIVE_INFINITY) {
/* 3767 */           return (op == 17 || op == 16);
/*      */         }
/* 3769 */         bd2 = new BigDecimal(d, MathContext.UNLIMITED);
/*      */       } 
/*      */       
/* 3772 */       return compareTo(bd1, bd2, op);
/*      */     } 
/* 3774 */     return compareTo(val1.doubleValue(), val2.doubleValue(), op);
/*      */   }
/*      */   
/*      */   private static <T> boolean compareTo(Comparable<T> val1, T val2, int op) {
/* 3778 */     switch (op) {
/*      */       case 17:
/* 3780 */         return (val1.compareTo(val2) >= 0);
/*      */       case 15:
/* 3782 */         return (val1.compareTo(val2) <= 0);
/*      */       case 16:
/* 3784 */         return (val1.compareTo(val2) > 0);
/*      */       case 14:
/* 3786 */         return (val1.compareTo(val2) < 0);
/*      */     } 
/* 3788 */     throw Kit.codeBug();
/*      */   }
/*      */ 
/*      */   
/*      */   private static <T> boolean compareTo(double d1, double d2, int op) {
/* 3793 */     switch (op) {
/*      */       case 17:
/* 3795 */         return (d1 >= d2);
/*      */       case 15:
/* 3797 */         return (d1 <= d2);
/*      */       case 16:
/* 3799 */         return (d1 > d2);
/*      */       case 14:
/* 3801 */         return (d1 < d2);
/*      */     } 
/* 3803 */     throw Kit.codeBug();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ScriptableObject getGlobal(Context cx) {
/* 3812 */     String GLOBAL_CLASS = "org.mozilla.javascript.tools.shell.Global";
/* 3813 */     Class<?> globalClass = Kit.classOrNull("org.mozilla.javascript.tools.shell.Global");
/* 3814 */     if (globalClass != null) {
/*      */       try {
/* 3816 */         Class<?>[] parm = new Class[] { ContextClass };
/* 3817 */         Constructor<?> globalClassCtor = globalClass.getConstructor(parm);
/* 3818 */         Object[] arg = { cx };
/* 3819 */         return (ScriptableObject)globalClassCtor.newInstance(arg);
/* 3820 */       } catch (RuntimeException e) {
/* 3821 */         throw e;
/* 3822 */       } catch (Exception exception) {}
/*      */     }
/*      */ 
/*      */     
/* 3826 */     return new ImporterTopLevel(cx);
/*      */   }
/*      */   
/*      */   public static boolean hasTopCall(Context cx) {
/* 3830 */     return (cx.topCallScope != null);
/*      */   }
/*      */   
/*      */   public static Scriptable getTopCallScope(Context cx) {
/* 3834 */     Scriptable scope = cx.topCallScope;
/* 3835 */     if (scope == null) {
/* 3836 */       throw new IllegalStateException();
/*      */     }
/* 3838 */     return scope;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object doTopCall(Callable callable, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 3848 */     return doTopCall(callable, cx, scope, thisObj, args, cx.isTopLevelStrict);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object doTopCall(Callable callable, Context cx, Scriptable scope, Scriptable thisObj, Object[] args, boolean isTopLevelStrict) {
/*      */     Object result;
/* 3858 */     if (scope == null) throw new IllegalArgumentException(); 
/* 3859 */     if (cx.topCallScope != null) throw new IllegalStateException();
/*      */ 
/*      */     
/* 3862 */     cx.topCallScope = ScriptableObject.getTopLevelScope(scope);
/* 3863 */     cx.useDynamicScope = cx.hasFeature(7);
/* 3864 */     boolean previousTopLevelStrict = cx.isTopLevelStrict;
/* 3865 */     cx.isTopLevelStrict = isTopLevelStrict;
/* 3866 */     ContextFactory f = cx.getFactory();
/*      */     try {
/* 3868 */       result = f.doTopCall(callable, cx, scope, thisObj, args);
/*      */     } finally {
/* 3870 */       cx.topCallScope = null;
/*      */       
/* 3872 */       cx.cachedXMLLib = null;
/* 3873 */       cx.isTopLevelStrict = previousTopLevelStrict;
/*      */       
/* 3875 */       if (cx.currentActivationCall != null)
/*      */       {
/*      */         
/* 3878 */         throw new IllegalStateException();
/*      */       }
/*      */     } 
/* 3881 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Scriptable checkDynamicScope(Scriptable possibleDynamicScope, Scriptable staticTopScope) {
/* 3892 */     if (possibleDynamicScope == staticTopScope) {
/* 3893 */       return possibleDynamicScope;
/*      */     }
/* 3895 */     Scriptable proto = possibleDynamicScope;
/*      */     while (true) {
/* 3897 */       proto = proto.getPrototype();
/* 3898 */       if (proto == staticTopScope) {
/* 3899 */         return possibleDynamicScope;
/*      */       }
/* 3901 */       if (proto == null) {
/* 3902 */         return staticTopScope;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void addInstructionCount(Context cx, int instructionsToAdd) {
/* 3908 */     cx.instructionCount += instructionsToAdd;
/* 3909 */     if (cx.instructionCount > cx.instructionThreshold) {
/* 3910 */       cx.observeInstructionCount(cx.instructionCount);
/* 3911 */       cx.instructionCount = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void initScript(NativeFunction funObj, Scriptable thisObj, Context cx, Scriptable scope, boolean evalScript) {
/* 3921 */     if (cx.topCallScope == null) throw new IllegalStateException();
/*      */     
/* 3923 */     int varCount = funObj.getParamAndVarCount();
/* 3924 */     if (varCount != 0) {
/*      */       
/* 3926 */       Scriptable varScope = scope;
/*      */ 
/*      */       
/* 3929 */       while (varScope instanceof NativeWith) {
/* 3930 */         varScope = varScope.getParentScope();
/*      */       }
/*      */       
/* 3933 */       for (int i = varCount; i-- != 0; ) {
/* 3934 */         String name = funObj.getParamOrVarName(i);
/* 3935 */         boolean isConst = funObj.getParamOrVarConst(i);
/*      */ 
/*      */         
/* 3938 */         if (!ScriptableObject.hasProperty(scope, name)) {
/* 3939 */           if (isConst) {
/* 3940 */             ScriptableObject.defineConstProperty(varScope, name); continue;
/* 3941 */           }  if (!evalScript) {
/* 3942 */             if (!(funObj instanceof InterpretedFunction) || ((InterpretedFunction)funObj)
/* 3943 */               .hasFunctionNamed(name))
/*      */             {
/* 3945 */               ScriptableObject.defineProperty(varScope, name, Undefined.instance, 4);
/*      */             }
/*      */             continue;
/*      */           } 
/* 3949 */           varScope.put(name, varScope, Undefined.instance);
/*      */           continue;
/*      */         } 
/* 3952 */         ScriptableObject.redefineProperty(scope, name, isConst);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scriptable createFunctionActivation(NativeFunction funObj, Scriptable scope, Object[] args) {
/* 3965 */     return createFunctionActivation(funObj, scope, args, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable createFunctionActivation(NativeFunction funObj, Scriptable scope, Object[] args, boolean isStrict) {
/* 3970 */     return new NativeCall(funObj, scope, args, false, isStrict);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable createArrowFunctionActivation(NativeFunction funObj, Scriptable scope, Object[] args, boolean isStrict) {
/* 3975 */     return new NativeCall(funObj, scope, args, true, isStrict);
/*      */   }
/*      */   
/*      */   public static void enterActivationFunction(Context cx, Scriptable scope) {
/* 3979 */     if (cx.topCallScope == null) throw new IllegalStateException(); 
/* 3980 */     NativeCall call = (NativeCall)scope;
/* 3981 */     call.parentActivationCall = cx.currentActivationCall;
/* 3982 */     cx.currentActivationCall = call;
/* 3983 */     call.defineAttributesForArguments();
/*      */   }
/*      */   
/*      */   public static void exitActivationFunction(Context cx) {
/* 3987 */     NativeCall call = cx.currentActivationCall;
/* 3988 */     cx.currentActivationCall = call.parentActivationCall;
/* 3989 */     call.parentActivationCall = null;
/*      */   }
/*      */   
/*      */   static NativeCall findFunctionActivation(Context cx, Function f) {
/* 3993 */     NativeCall call = cx.currentActivationCall;
/* 3994 */     while (call != null) {
/* 3995 */       if (call.function == f) return call; 
/* 3996 */       call = call.parentActivationCall;
/*      */     } 
/* 3998 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable newCatchScope(Throwable t, Scriptable lastCatchScope, String exceptionName, Context cx, Scriptable scope) {
/*      */     Object obj;
/*      */     boolean cacheObj;
/* 4011 */     if (t instanceof JavaScriptException) {
/* 4012 */       cacheObj = false;
/* 4013 */       obj = ((JavaScriptException)t).getValue();
/*      */     } else {
/* 4015 */       cacheObj = true;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4020 */       if (lastCatchScope != null) {
/* 4021 */         NativeObject last = (NativeObject)lastCatchScope;
/* 4022 */         obj = last.getAssociatedValue(t);
/* 4023 */         if (obj == null) Kit.codeBug();
/*      */       
/*      */       } else {
/*      */         RhinoException re;
/*      */         TopLevel.NativeErrors type;
/*      */         String errorMsg;
/*      */         Object[] args;
/* 4030 */         Throwable javaException = null;
/*      */         
/* 4032 */         if (t instanceof EcmaError) {
/* 4033 */           EcmaError ee = (EcmaError)t;
/* 4034 */           re = ee;
/* 4035 */           type = TopLevel.NativeErrors.valueOf(ee.getName());
/* 4036 */           errorMsg = ee.getErrorMessage();
/* 4037 */         } else if (t instanceof WrappedException) {
/* 4038 */           WrappedException we = (WrappedException)t;
/* 4039 */           re = we;
/* 4040 */           javaException = we.getWrappedException();
/*      */           
/* 4042 */           if (!isVisible(cx, javaException)) {
/* 4043 */             type = TopLevel.NativeErrors.InternalError;
/* 4044 */             errorMsg = javaException.getMessage();
/*      */           } else {
/* 4046 */             type = TopLevel.NativeErrors.JavaException;
/*      */             
/* 4048 */             errorMsg = javaException.getClass().getName() + ": " + javaException.getMessage();
/*      */           } 
/* 4050 */         } else if (t instanceof EvaluatorException) {
/*      */           
/* 4052 */           EvaluatorException ee = (EvaluatorException)t;
/* 4053 */           re = ee;
/* 4054 */           type = TopLevel.NativeErrors.InternalError;
/* 4055 */           errorMsg = ee.getMessage();
/* 4056 */         } else if (cx.hasFeature(13)) {
/*      */ 
/*      */           
/* 4059 */           re = new WrappedException(t);
/* 4060 */           type = TopLevel.NativeErrors.JavaException;
/* 4061 */           errorMsg = t.toString();
/*      */         }
/*      */         else {
/*      */           
/* 4065 */           throw Kit.codeBug();
/*      */         } 
/*      */         
/* 4068 */         String sourceUri = re.sourceName();
/* 4069 */         if (sourceUri == null) {
/* 4070 */           sourceUri = "";
/*      */         }
/* 4072 */         int line = re.lineNumber();
/*      */         
/* 4074 */         if (line > 0) {
/* 4075 */           args = new Object[] { errorMsg, sourceUri, Integer.valueOf(line) };
/*      */         } else {
/* 4077 */           args = new Object[] { errorMsg, sourceUri };
/*      */         } 
/*      */         
/* 4080 */         Scriptable errorObject = newNativeError(cx, scope, type, args);
/*      */         
/* 4082 */         if (errorObject instanceof NativeError) {
/* 4083 */           ((NativeError)errorObject).setStackProvider(re);
/*      */         }
/*      */         
/* 4086 */         if (javaException != null && isVisible(cx, javaException)) {
/* 4087 */           Object wrap = cx.getWrapFactory().wrap(cx, scope, javaException, null);
/* 4088 */           ScriptableObject.defineProperty(errorObject, "javaException", wrap, 7);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4096 */         if (isVisible(cx, re)) {
/* 4097 */           Object wrap = cx.getWrapFactory().wrap(cx, scope, re, null);
/* 4098 */           ScriptableObject.defineProperty(errorObject, "rhinoException", wrap, 7);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4106 */         obj = errorObject;
/*      */       } 
/*      */     } 
/* 4109 */     NativeObject catchScopeObject = new NativeObject();
/*      */     
/* 4111 */     catchScopeObject.defineProperty(exceptionName, obj, 4);
/*      */     
/* 4113 */     if (isVisible(cx, t))
/*      */     {
/*      */ 
/*      */       
/* 4117 */       catchScopeObject.defineProperty("__exception__", 
/*      */           
/* 4119 */           Context.javaToJS(t, scope), 6);
/*      */     }
/*      */ 
/*      */     
/* 4123 */     if (cacheObj) {
/* 4124 */       catchScopeObject.associateValue(t, obj);
/*      */     }
/* 4126 */     return catchScopeObject;
/*      */   }
/*      */   
/*      */   public static Scriptable wrapException(Throwable t, Scriptable scope, Context cx) {
/*      */     RhinoException re;
/*      */     String errorName, errorMsg;
/*      */     Object[] args;
/* 4133 */     Throwable javaException = null;
/*      */     
/* 4135 */     if (t instanceof EcmaError) {
/* 4136 */       EcmaError ee = (EcmaError)t;
/* 4137 */       re = ee;
/* 4138 */       errorName = ee.getName();
/* 4139 */       errorMsg = ee.getErrorMessage();
/* 4140 */     } else if (t instanceof WrappedException) {
/* 4141 */       WrappedException we = (WrappedException)t;
/* 4142 */       re = we;
/* 4143 */       javaException = we.getWrappedException();
/* 4144 */       errorName = "JavaException";
/* 4145 */       errorMsg = javaException.getClass().getName() + ": " + javaException.getMessage();
/* 4146 */     } else if (t instanceof EvaluatorException) {
/*      */       
/* 4148 */       EvaluatorException ee = (EvaluatorException)t;
/* 4149 */       re = ee;
/* 4150 */       errorName = "InternalError";
/* 4151 */       errorMsg = ee.getMessage();
/* 4152 */     } else if (cx.hasFeature(13)) {
/*      */ 
/*      */       
/* 4155 */       re = new WrappedException(t);
/* 4156 */       errorName = "JavaException";
/* 4157 */       errorMsg = t.toString();
/*      */     }
/*      */     else {
/*      */       
/* 4161 */       throw Kit.codeBug();
/*      */     } 
/*      */     
/* 4164 */     String sourceUri = re.sourceName();
/* 4165 */     if (sourceUri == null) {
/* 4166 */       sourceUri = "";
/*      */     }
/* 4168 */     int line = re.lineNumber();
/*      */     
/* 4170 */     if (line > 0) {
/* 4171 */       args = new Object[] { errorMsg, sourceUri, Integer.valueOf(line) };
/*      */     } else {
/* 4173 */       args = new Object[] { errorMsg, sourceUri };
/*      */     } 
/*      */     
/* 4176 */     Scriptable errorObject = cx.newObject(scope, errorName, args);
/* 4177 */     ScriptableObject.putProperty(errorObject, "name", errorName);
/*      */     
/* 4179 */     if (errorObject instanceof NativeError) {
/* 4180 */       ((NativeError)errorObject).setStackProvider(re);
/*      */     }
/*      */     
/* 4183 */     if (javaException != null && isVisible(cx, javaException)) {
/* 4184 */       Object wrap = cx.getWrapFactory().wrap(cx, scope, javaException, null);
/* 4185 */       ScriptableObject.defineProperty(errorObject, "javaException", wrap, 7);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4193 */     if (isVisible(cx, re)) {
/* 4194 */       Object wrap = cx.getWrapFactory().wrap(cx, scope, re, null);
/* 4195 */       ScriptableObject.defineProperty(errorObject, "rhinoException", wrap, 7);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4203 */     return errorObject;
/*      */   }
/*      */   
/*      */   private static boolean isVisible(Context cx, Object obj) {
/* 4207 */     ClassShutter shutter = cx.getClassShutter();
/* 4208 */     return (shutter == null || shutter.visibleToScripts(obj.getClass().getName()));
/*      */   }
/*      */   
/*      */   public static Scriptable enterWith(Object obj, Context cx, Scriptable scope) {
/* 4212 */     Scriptable sobj = toObjectOrNull(cx, obj, scope);
/* 4213 */     if (sobj == null) {
/* 4214 */       throw typeErrorById("msg.undef.with", new Object[] { toString(obj) });
/*      */     }
/* 4216 */     if (sobj instanceof XMLObject) {
/* 4217 */       XMLObject xmlObject = (XMLObject)sobj;
/* 4218 */       return xmlObject.enterWith(scope);
/*      */     } 
/* 4220 */     return new NativeWith(scope, sobj);
/*      */   }
/*      */   
/*      */   public static Scriptable leaveWith(Scriptable scope) {
/* 4224 */     NativeWith nw = (NativeWith)scope;
/* 4225 */     return nw.getParentScope();
/*      */   }
/*      */   
/*      */   public static Scriptable enterDotQuery(Object value, Scriptable scope) {
/* 4229 */     if (!(value instanceof XMLObject)) {
/* 4230 */       throw notXmlError(value);
/*      */     }
/* 4232 */     XMLObject object = (XMLObject)value;
/* 4233 */     return object.enterDotQuery(scope);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object updateDotQuery(boolean value, Scriptable scope) {
/* 4238 */     NativeWith nw = (NativeWith)scope;
/* 4239 */     return nw.updateDotQuery(value);
/*      */   }
/*      */   
/*      */   public static Scriptable leaveDotQuery(Scriptable scope) {
/* 4243 */     NativeWith nw = (NativeWith)scope;
/* 4244 */     return nw.getParentScope();
/*      */   }
/*      */   
/*      */   public static void setFunctionProtoAndParent(BaseFunction fn, Scriptable scope) {
/* 4248 */     setFunctionProtoAndParent(fn, scope, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setFunctionProtoAndParent(BaseFunction fn, Scriptable scope, boolean es6GeneratorFunction) {
/* 4253 */     fn.setParentScope(scope);
/* 4254 */     if (es6GeneratorFunction) {
/* 4255 */       fn.setPrototype(ScriptableObject.getGeneratorFunctionPrototype(scope));
/*      */     } else {
/* 4257 */       fn.setPrototype(ScriptableObject.getFunctionPrototype(scope));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setObjectProtoAndParent(ScriptableObject object, Scriptable scope) {
/* 4263 */     scope = ScriptableObject.getTopLevelScope(scope);
/* 4264 */     object.setParentScope(scope);
/* 4265 */     Scriptable proto = ScriptableObject.getClassPrototype(scope, object.getClassName());
/* 4266 */     object.setPrototype(proto);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setBuiltinProtoAndParent(ScriptableObject object, Scriptable scope, TopLevel.Builtins type) {
/* 4271 */     scope = ScriptableObject.getTopLevelScope(scope);
/* 4272 */     object.setParentScope(scope);
/* 4273 */     object.setPrototype(TopLevel.getBuiltinPrototype(scope, type));
/*      */   }
/*      */ 
/*      */   
/*      */   public static void initFunction(Context cx, Scriptable scope, NativeFunction function, int type, boolean fromEvalCode) {
/* 4278 */     if (type == 1) {
/* 4279 */       String name = function.getFunctionName();
/* 4280 */       if (name != null && name.length() != 0) {
/* 4281 */         if (!fromEvalCode) {
/*      */ 
/*      */           
/* 4284 */           ScriptableObject.defineProperty(scope, name, function, 4);
/*      */         } else {
/*      */           
/* 4287 */           scope.put(name, scope, function);
/*      */         } 
/*      */       }
/* 4290 */     } else if (type == 3) {
/* 4291 */       String name = function.getFunctionName();
/* 4292 */       if (name != null && name.length() != 0) {
/*      */ 
/*      */ 
/*      */         
/* 4296 */         while (scope instanceof NativeWith) {
/* 4297 */           scope = scope.getParentScope();
/*      */         }
/* 4299 */         scope.put(name, scope, function);
/*      */       } 
/*      */     } else {
/* 4302 */       throw Kit.codeBug();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable newArrayLiteral(Object[] objects, int[] skipIndices, Context cx, Scriptable scope) {
/* 4308 */     int SKIP_DENSITY = 2;
/* 4309 */     int count = objects.length;
/* 4310 */     int skipCount = 0;
/* 4311 */     if (skipIndices != null) {
/* 4312 */       skipCount = skipIndices.length;
/*      */     }
/* 4314 */     int length = count + skipCount;
/* 4315 */     if (length > 1 && skipCount * 2 < length) {
/*      */       Object[] sparse;
/*      */       
/* 4318 */       if (skipCount == 0) {
/* 4319 */         sparse = objects;
/*      */       } else {
/* 4321 */         sparse = new Object[length];
/* 4322 */         int k = 0;
/* 4323 */         for (int m = 0, n = 0; m != length; m++) {
/* 4324 */           if (k != skipCount && skipIndices[k] == m) {
/* 4325 */             sparse[m] = Scriptable.NOT_FOUND;
/* 4326 */             k++;
/*      */           } else {
/*      */             
/* 4329 */             sparse[m] = objects[n];
/* 4330 */             n++;
/*      */           } 
/*      */         } 
/* 4333 */       }  return cx.newArray(scope, sparse);
/*      */     } 
/*      */     
/* 4336 */     Scriptable array = cx.newArray(scope, length);
/*      */     
/* 4338 */     int skip = 0;
/* 4339 */     for (int i = 0, j = 0; i != length; i++) {
/* 4340 */       if (skip != skipCount && skipIndices[skip] == i) {
/* 4341 */         skip++;
/*      */       } else {
/*      */         
/* 4344 */         array.put(i, array, objects[j]);
/* 4345 */         j++;
/*      */       } 
/* 4347 */     }  return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scriptable newObjectLiteral(Object[] propertyIds, Object[] propertyValues, Context cx, Scriptable scope) {
/* 4362 */     return newObjectLiteral(propertyIds, propertyValues, null, cx, scope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable newObjectLiteral(Object[] propertyIds, Object[] propertyValues, int[] getterSetters, Context cx, Scriptable scope) {
/* 4371 */     Scriptable object = cx.newObject(scope);
/* 4372 */     int end = (propertyIds == null) ? 0 : propertyIds.length;
/* 4373 */     for (int i = 0; i != end; i++) {
/* 4374 */       Object id = propertyIds[i];
/*      */ 
/*      */       
/* 4377 */       int getterSetter = (getterSetters == null) ? 0 : getterSetters[i];
/* 4378 */       Object value = propertyValues[i];
/*      */       
/* 4380 */       if (getterSetter == 0) {
/* 4381 */         if (id instanceof Symbol) {
/* 4382 */           Symbol sym = (Symbol)id;
/* 4383 */           SymbolScriptable so = (SymbolScriptable)object;
/* 4384 */           so.put(sym, object, value);
/* 4385 */         } else if (id instanceof Integer) {
/* 4386 */           int index = ((Integer)id).intValue();
/* 4387 */           object.put(index, object, value);
/*      */         } else {
/* 4389 */           String stringId = toString(id);
/* 4390 */           if (isSpecialProperty(stringId)) {
/* 4391 */             Ref ref = specialRef(object, stringId, cx, scope);
/* 4392 */             ref.set(cx, scope, value);
/*      */           } else {
/* 4394 */             object.put(stringId, object, value);
/*      */           } 
/*      */         } 
/*      */       } else {
/* 4398 */         ScriptableObject so = (ScriptableObject)object;
/* 4399 */         Callable getterOrSetter = (Callable)value;
/* 4400 */         boolean isSetter = (getterSetter == 1);
/*      */ 
/*      */         
/* 4403 */         String key = (id instanceof String) ? (String)id : null;
/* 4404 */         int index = (key == null) ? ((Integer)id).intValue() : 0;
/* 4405 */         so.setGetterOrSetter(key, index, getterOrSetter, isSetter);
/*      */       } 
/*      */     } 
/* 4408 */     return object;
/*      */   }
/*      */   
/*      */   public static boolean isArrayObject(Object obj) {
/* 4412 */     return (obj instanceof NativeArray || obj instanceof Arguments);
/*      */   }
/*      */   
/*      */   public static Object[] getArrayElements(Scriptable object) {
/* 4416 */     Context cx = Context.getContext();
/* 4417 */     long longLen = NativeArray.getLengthProperty(cx, object);
/* 4418 */     if (longLen > 2147483647L)
/*      */     {
/* 4420 */       throw new IllegalArgumentException();
/*      */     }
/* 4422 */     int len = (int)longLen;
/* 4423 */     if (len == 0) {
/* 4424 */       return emptyArgs;
/*      */     }
/* 4426 */     Object[] result = new Object[len];
/* 4427 */     for (int i = 0; i < len; i++) {
/* 4428 */       Object elem = ScriptableObject.getProperty(object, i);
/* 4429 */       result[i] = (elem == Scriptable.NOT_FOUND) ? Undefined.instance : elem;
/*      */     } 
/* 4431 */     return result;
/*      */   }
/*      */   
/*      */   static void checkDeprecated(Context cx, String name) {
/* 4435 */     int version = cx.getLanguageVersion();
/* 4436 */     if (version >= 140 || version == 0) {
/* 4437 */       String msg = getMessageById("msg.deprec.ctor", new Object[] { name });
/* 4438 */       if (version == 0) { Context.reportWarning(msg); }
/* 4439 */       else { throw Context.reportRuntimeError(msg); }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static String getMessage0(String messageId) {
/* 4446 */     return getMessage(messageId, null);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String getMessage1(String messageId, Object arg1) {
/* 4452 */     Object[] arguments = { arg1 };
/* 4453 */     return getMessage(messageId, arguments);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String getMessage2(String messageId, Object arg1, Object arg2) {
/* 4459 */     Object[] arguments = { arg1, arg2 };
/* 4460 */     return getMessage(messageId, arguments);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String getMessage3(String messageId, Object arg1, Object arg2, Object arg3) {
/* 4466 */     Object[] arguments = { arg1, arg2, arg3 };
/* 4467 */     return getMessage(messageId, arguments);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String getMessage4(String messageId, Object arg1, Object arg2, Object arg3, Object arg4) {
/* 4474 */     Object[] arguments = { arg1, arg2, arg3, arg4 };
/* 4475 */     return getMessage(messageId, arguments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4496 */   public static final MessageProvider messageProvider = new DefaultMessageProvider();
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String getMessage(String messageId, Object[] arguments) {
/* 4501 */     return messageProvider.getMessage(messageId, arguments);
/*      */   }
/*      */   
/*      */   public static String getMessageById(String messageId, Object... args) {
/* 4505 */     return messageProvider.getMessage(messageId, args);
/*      */   }
/*      */   
/*      */   public static interface MessageProvider {
/*      */     String getMessage(String param1String, Object[] param1ArrayOfObject); }
/*      */   
/*      */   private static class DefaultMessageProvider implements MessageProvider {
/*      */     private DefaultMessageProvider() {}
/*      */     
/*      */     public String getMessage(String messageId, Object[] arguments) {
/* 4515 */       String formatString, defaultResource = "org.mozilla.javascript.resources.Messages";
/*      */       
/* 4517 */       Context cx = Context.getCurrentContext();
/* 4518 */       Locale locale = (cx != null) ? cx.getLocale() : Locale.getDefault();
/*      */ 
/*      */       
/* 4521 */       ResourceBundle rb = ResourceBundle.getBundle("org.mozilla.javascript.resources.Messages", locale);
/*      */ 
/*      */       
/*      */       try {
/* 4525 */         formatString = rb.getString(messageId);
/* 4526 */       } catch (MissingResourceException mre) {
/* 4527 */         throw new RuntimeException("no message resource found for message property " + messageId);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4536 */       MessageFormat formatter = new MessageFormat(formatString);
/* 4537 */       return formatter.format(arguments);
/*      */     }
/*      */   }
/*      */   
/*      */   public static EcmaError constructError(String error, String message) {
/* 4542 */     int[] linep = new int[1];
/* 4543 */     String filename = Context.getSourcePositionFromStack(linep);
/* 4544 */     return constructError(error, message, filename, linep[0], null, 0);
/*      */   }
/*      */   
/*      */   public static EcmaError constructError(String error, String message, int lineNumberDelta) {
/* 4548 */     int[] linep = new int[1];
/* 4549 */     String filename = Context.getSourcePositionFromStack(linep);
/* 4550 */     if (linep[0] != 0) {
/* 4551 */       linep[0] = linep[0] + lineNumberDelta;
/*      */     }
/* 4553 */     return constructError(error, message, filename, linep[0], null, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static EcmaError constructError(String error, String message, String sourceName, int lineNumber, String lineSource, int columnNumber) {
/* 4563 */     return new EcmaError(error, message, sourceName, lineNumber, lineSource, columnNumber);
/*      */   }
/*      */   
/*      */   public static EcmaError rangeError(String message) {
/* 4567 */     return constructError("RangeError", message);
/*      */   }
/*      */   
/*      */   public static EcmaError rangeErrorById(String messageId, Object... args) {
/* 4571 */     String msg = getMessageById(messageId, args);
/* 4572 */     return rangeError(msg);
/*      */   }
/*      */   
/*      */   public static EcmaError typeError(String message) {
/* 4576 */     return constructError("TypeError", message);
/*      */   }
/*      */   
/*      */   public static EcmaError typeErrorById(String messageId, Object... args) {
/* 4580 */     String msg = getMessageById(messageId, args);
/* 4581 */     return typeError(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static EcmaError typeError0(String messageId) {
/* 4587 */     String msg = getMessage0(messageId);
/* 4588 */     return typeError(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static EcmaError typeError1(String messageId, Object arg1) {
/* 4594 */     String msg = getMessage1(messageId, arg1);
/* 4595 */     return typeError(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static EcmaError typeError2(String messageId, Object arg1, Object arg2) {
/* 4601 */     String msg = getMessage2(messageId, arg1, arg2);
/* 4602 */     return typeError(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static EcmaError typeError3(String messageId, String arg1, String arg2, String arg3) {
/* 4608 */     String msg = getMessage3(messageId, arg1, arg2, arg3);
/* 4609 */     return typeError(msg);
/*      */   }
/*      */   
/*      */   public static RuntimeException undefReadError(Object object, Object id) {
/* 4613 */     return typeErrorById("msg.undef.prop.read", new Object[] { toString(object), toString(id) });
/*      */   }
/*      */   
/*      */   public static RuntimeException undefCallError(Object object, Object id) {
/* 4617 */     return typeErrorById("msg.undef.method.call", new Object[] { toString(object), toString(id) });
/*      */   }
/*      */   
/*      */   public static RuntimeException undefWriteError(Object object, Object id, Object value) {
/* 4621 */     return typeErrorById("msg.undef.prop.write", new Object[] {
/* 4622 */           toString(object), toString(id), toString(value) });
/*      */   }
/*      */   
/*      */   private static RuntimeException undefDeleteError(Object object, Object id) {
/* 4626 */     throw typeErrorById("msg.undef.prop.delete", new Object[] { toString(object), toString(id) });
/*      */   }
/*      */ 
/*      */   
/*      */   public static RuntimeException notFoundError(Scriptable object, String property) {
/* 4631 */     String msg = getMessageById("msg.is.not.defined", new Object[] { property });
/* 4632 */     throw constructError("ReferenceError", msg);
/*      */   }
/*      */   
/*      */   public static RuntimeException notFunctionError(Object value) {
/* 4636 */     return notFunctionError(value, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public static RuntimeException notFunctionError(Object value, Object messageHelper) {
/* 4641 */     String msg = (messageHelper == null) ? "null" : messageHelper.toString();
/* 4642 */     if (value == Scriptable.NOT_FOUND) {
/* 4643 */       return typeErrorById("msg.function.not.found", new Object[] { msg });
/*      */     }
/* 4645 */     return typeErrorById("msg.isnt.function", new Object[] { msg, typeof(value) });
/*      */   }
/*      */ 
/*      */   
/*      */   public static RuntimeException notFunctionError(Object obj, Object value, String propertyName) {
/* 4650 */     String objString = toString(obj);
/* 4651 */     if (obj instanceof NativeFunction) {
/*      */       
/* 4653 */       int paren = objString.indexOf(')');
/* 4654 */       int curly = objString.indexOf('{', paren);
/* 4655 */       if (curly > -1) {
/* 4656 */         objString = objString.substring(0, curly + 1) + "...}";
/*      */       }
/*      */     } 
/* 4659 */     if (value == Scriptable.NOT_FOUND) {
/* 4660 */       return typeErrorById("msg.function.not.found.in", new Object[] { propertyName, objString });
/*      */     }
/* 4662 */     return typeErrorById("msg.isnt.function.in", new Object[] { propertyName, objString, typeof(value) });
/*      */   }
/*      */   
/*      */   private static RuntimeException notXmlError(Object value) {
/* 4666 */     throw typeErrorById("msg.isnt.xml.object", new Object[] { toString(value) });
/*      */   }
/*      */   
/*      */   public static EcmaError syntaxError(String message) {
/* 4670 */     return constructError("SyntaxError", message);
/*      */   }
/*      */   
/*      */   public static EcmaError syntaxErrorById(String messageId, Object... args) {
/* 4674 */     String msg = getMessageById(messageId, args);
/* 4675 */     return syntaxError(msg);
/*      */   }
/*      */   
/*      */   private static void warnAboutNonJSObject(Object nonJSObject) {
/* 4679 */     String omitParam = getMessageById("params.omit.non.js.object.warning", new Object[0]);
/* 4680 */     if (!"true".equals(omitParam)) {
/*      */       
/* 4682 */       String message = getMessageById("msg.non.js.object.warning", new Object[] {
/*      */ 
/*      */             
/* 4685 */             nonJSObject, nonJSObject.getClass().getName() });
/* 4686 */       Context.reportWarning(message);
/*      */       
/* 4688 */       System.err.println(message);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static RegExpProxy getRegExpProxy(Context cx) {
/* 4693 */     return cx.getRegExpProxy();
/*      */   }
/*      */   
/*      */   public static void setRegExpProxy(Context cx, RegExpProxy proxy) {
/* 4697 */     if (proxy == null) throw new IllegalArgumentException(); 
/* 4698 */     cx.regExpProxy = proxy;
/*      */   }
/*      */   
/*      */   public static RegExpProxy checkRegExpProxy(Context cx) {
/* 4702 */     RegExpProxy result = getRegExpProxy(cx);
/* 4703 */     if (result == null) {
/* 4704 */       throw Context.reportRuntimeErrorById("msg.no.regexp", new Object[0]);
/*      */     }
/* 4706 */     return result;
/*      */   }
/*      */   
/*      */   public static Scriptable wrapRegExp(Context cx, Scriptable scope, Object compiled) {
/* 4710 */     return cx.getRegExpProxy().wrapRegExp(cx, scope, compiled);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable getTemplateLiteralCallSite(Context cx, Scriptable scope, Object[] strings, int index) {
/* 4715 */     Object callsite = strings[index];
/*      */     
/* 4717 */     if (callsite instanceof Scriptable) return (Scriptable)callsite;
/*      */     
/* 4719 */     assert callsite instanceof String[];
/* 4720 */     String[] vals = (String[])callsite;
/* 4721 */     assert (vals.length & 0x1) == 0;
/*      */     
/* 4723 */     ScriptableObject siteObj = (ScriptableObject)cx.newArray(scope, vals.length >>> 1);
/* 4724 */     ScriptableObject rawObj = (ScriptableObject)cx.newArray(scope, vals.length >>> 1);
/*      */     
/* 4726 */     siteObj.put("raw", siteObj, rawObj);
/* 4727 */     siteObj.setAttributes("raw", 2);
/*      */     
/* 4729 */     for (int i = 0, n = vals.length; i < n; i += 2) {
/* 4730 */       int idx = i >>> 1;
/* 4731 */       siteObj.put(idx, siteObj, (vals[i] == null) ? Undefined.instance : vals[i]);
/*      */       
/* 4733 */       rawObj.put(idx, rawObj, vals[i + 1]);
/*      */     } 
/*      */     
/* 4736 */     AbstractEcmaObjectOperations.setIntegrityLevel(cx, rawObj, AbstractEcmaObjectOperations.INTEGRITY_LEVEL.FROZEN);
/*      */     
/* 4738 */     AbstractEcmaObjectOperations.setIntegrityLevel(cx, siteObj, AbstractEcmaObjectOperations.INTEGRITY_LEVEL.FROZEN);
/*      */ 
/*      */     
/* 4741 */     strings[index] = siteObj;
/*      */     
/* 4743 */     return siteObj;
/*      */   }
/*      */ 
/*      */   
/*      */   private static XMLLib currentXMLLib(Context cx) {
/* 4748 */     if (cx.topCallScope == null) throw new IllegalStateException();
/*      */     
/* 4750 */     XMLLib xmlLib = cx.cachedXMLLib;
/* 4751 */     if (xmlLib == null) {
/* 4752 */       xmlLib = XMLLib.extractFromScope(cx.topCallScope);
/* 4753 */       if (xmlLib == null) throw new IllegalStateException(); 
/* 4754 */       cx.cachedXMLLib = xmlLib;
/*      */     } 
/*      */     
/* 4757 */     return xmlLib;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String escapeAttributeValue(Object value, Context cx) {
/* 4767 */     XMLLib xmlLib = currentXMLLib(cx);
/* 4768 */     return xmlLib.escapeAttributeValue(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String escapeTextValue(Object value, Context cx) {
/* 4778 */     XMLLib xmlLib = currentXMLLib(cx);
/* 4779 */     return xmlLib.escapeTextValue(value);
/*      */   }
/*      */   
/*      */   public static Ref memberRef(Object obj, Object elem, Context cx, int memberTypeFlags) {
/* 4783 */     if (!(obj instanceof XMLObject)) {
/* 4784 */       throw notXmlError(obj);
/*      */     }
/* 4786 */     XMLObject xmlObject = (XMLObject)obj;
/* 4787 */     return xmlObject.memberRef(cx, elem, memberTypeFlags);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ref memberRef(Object obj, Object namespace, Object elem, Context cx, int memberTypeFlags) {
/* 4792 */     if (!(obj instanceof XMLObject)) {
/* 4793 */       throw notXmlError(obj);
/*      */     }
/* 4795 */     XMLObject xmlObject = (XMLObject)obj;
/* 4796 */     return xmlObject.memberRef(cx, namespace, elem, memberTypeFlags);
/*      */   }
/*      */   
/*      */   public static Ref nameRef(Object name, Context cx, Scriptable scope, int memberTypeFlags) {
/* 4800 */     XMLLib xmlLib = currentXMLLib(cx);
/* 4801 */     return xmlLib.nameRef(cx, name, scope, memberTypeFlags);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ref nameRef(Object namespace, Object name, Context cx, Scriptable scope, int memberTypeFlags) {
/* 4806 */     XMLLib xmlLib = currentXMLLib(cx);
/* 4807 */     return xmlLib.nameRef(cx, namespace, name, scope, memberTypeFlags);
/*      */   }
/*      */   
/*      */   public static void storeUint32Result(Context cx, long value) {
/* 4811 */     if (value >>> 32L != 0L) throw new IllegalArgumentException(); 
/* 4812 */     cx.scratchUint32 = value;
/*      */   }
/*      */   
/*      */   public static long lastUint32Result(Context cx) {
/* 4816 */     long value = cx.scratchUint32;
/* 4817 */     if (value >>> 32L != 0L) throw new IllegalStateException(); 
/* 4818 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void storeScriptable(Context cx, Scriptable value) {
/* 4823 */     if (cx.scratchScriptable != null) throw new IllegalStateException(); 
/* 4824 */     cx.scratchScriptable = value;
/*      */   }
/*      */   
/*      */   public static Scriptable lastStoredScriptable(Context cx) {
/* 4828 */     Scriptable result = cx.scratchScriptable;
/* 4829 */     cx.scratchScriptable = null;
/* 4830 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   static String makeUrlForGeneratedScript(boolean isEval, String masterScriptUrl, int masterScriptLine) {
/* 4835 */     if (isEval) {
/* 4836 */       return masterScriptUrl + '#' + masterScriptLine + "(eval)";
/*      */     }
/* 4838 */     return masterScriptUrl + '#' + masterScriptLine + "(Function)";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isGeneratedScript(String sourceUrl) {
/* 4844 */     return (sourceUrl.indexOf("(eval)") >= 0 || sourceUrl.indexOf("(Function)") >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isSymbol(Object obj) {
/* 4852 */     return ((obj instanceof NativeSymbol && ((NativeSymbol)obj).isSymbol()) || obj instanceof SymbolKey);
/*      */   }
/*      */ 
/*      */   
/*      */   private static RuntimeException errorWithClassName(String msg, Object val) {
/* 4857 */     return Context.reportRuntimeErrorById(msg, new Object[] { val.getClass().getName() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JavaScriptException throwError(Context cx, Scriptable scope, String message) {
/* 4869 */     int[] linep = { 0 };
/* 4870 */     String filename = Context.getSourcePositionFromStack(linep);
/*      */     
/* 4872 */     Scriptable error = newBuiltinObject(cx, scope, TopLevel.Builtins.Error, new Object[] {
/*      */ 
/*      */ 
/*      */           
/* 4876 */           message, filename, Integer.valueOf(linep[0]) });
/* 4877 */     return new JavaScriptException(error, filename, linep[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JavaScriptException throwCustomError(Context cx, Scriptable scope, String constructorName, String message) {
/* 4891 */     int[] linep = { 0 };
/* 4892 */     String filename = Context.getSourcePositionFromStack(linep);
/*      */     
/* 4894 */     Scriptable error = cx.newObject(scope, constructorName, new Object[] {
/*      */ 
/*      */           
/* 4897 */           message, filename, Integer.valueOf(linep[0]) });
/* 4898 */     return new JavaScriptException(error, filename, linep[0]);
/*      */   }
/*      */   
/* 4901 */   public static final Object[] emptyArgs = new Object[0];
/* 4902 */   public static final String[] emptyStrings = new String[0];
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ScriptRuntime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */