/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.Arrays;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Supplier;
/*      */ import org.mozilla.javascript.annotations.JSConstructor;
/*      */ import org.mozilla.javascript.annotations.JSFunction;
/*      */ import org.mozilla.javascript.annotations.JSGetter;
/*      */ import org.mozilla.javascript.annotations.JSSetter;
/*      */ import org.mozilla.javascript.annotations.JSStaticFunction;
/*      */ import org.mozilla.javascript.debug.DebuggableObject;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ScriptableObject
/*      */   implements Scriptable, SymbolScriptable, Serializable, DebuggableObject, ConstProperties
/*      */ {
/*      */   private static final long serialVersionUID = 2829861078851942586L;
/*      */   public static final int EMPTY = 0;
/*      */   public static final int READONLY = 1;
/*      */   public static final int DONTENUM = 2;
/*      */   public static final int PERMANENT = 4;
/*      */   public static final int UNINITIALIZED_CONST = 8;
/*      */   public static final int CONST = 13;
/*      */   private Scriptable prototypeObject;
/*      */   private Scriptable parentScopeObject;
/*      */   private transient SlotMapContainer slotMap;
/*      */   private transient ExternalArrayData externalData;
/*      */   private volatile Map<Object, Object> associatedValues;
/*      */   private boolean isExtensible = true;
/*      */   private boolean isSealed = false;
/*      */   private static final Method GET_ARRAY_LENGTH;
/*      */   
/*      */   static {
/*      */     try {
/*  124 */       GET_ARRAY_LENGTH = ScriptableObject.class.getMethod("getExternalArrayLength", new Class[0]);
/*  125 */     } catch (NoSuchMethodException nsm) {
/*  126 */       throw new RuntimeException(nsm);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected static ScriptableObject buildDataDescriptor(Scriptable scope, Object value, int attributes) {
/*  132 */     ScriptableObject desc = new NativeObject();
/*  133 */     ScriptRuntime.setBuiltinProtoAndParent(desc, scope, TopLevel.Builtins.Object);
/*  134 */     desc.defineProperty("value", value, 0);
/*  135 */     desc.setCommonDescriptorProperties(attributes, true);
/*  136 */     return desc;
/*      */   }
/*      */   
/*      */   protected void setCommonDescriptorProperties(int attributes, boolean defineWritable) {
/*  140 */     if (defineWritable) {
/*  141 */       defineProperty("writable", Boolean.valueOf(((attributes & 0x1) == 0)), 0);
/*      */     }
/*  143 */     defineProperty("enumerable", Boolean.valueOf(((attributes & 0x2) == 0)), 0);
/*  144 */     defineProperty("configurable", Boolean.valueOf(((attributes & 0x4) == 0)), 0);
/*      */   }
/*      */   
/*      */   static void checkValidAttributes(int attributes) {
/*  148 */     int mask = 15;
/*  149 */     if ((attributes & 0xFFFFFFF0) != 0) {
/*  150 */       throw new IllegalArgumentException(String.valueOf(attributes));
/*      */     }
/*      */   }
/*      */   
/*      */   private static SlotMapContainer createSlotMap(int initialSize) {
/*  155 */     Context cx = Context.getCurrentContext();
/*  156 */     if (cx != null && cx.hasFeature(17)) {
/*  157 */       return new ThreadSafeSlotMapContainer(initialSize);
/*      */     }
/*  159 */     return new SlotMapContainer(initialSize);
/*      */   }
/*      */   
/*      */   public ScriptableObject() {
/*  163 */     this.slotMap = createSlotMap(0);
/*      */   }
/*      */   
/*      */   public ScriptableObject(Scriptable scope, Scriptable prototype) {
/*  167 */     if (scope == null) throw new IllegalArgumentException();
/*      */     
/*  169 */     this.parentScopeObject = scope;
/*  170 */     this.prototypeObject = prototype;
/*  171 */     this.slotMap = createSlotMap(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTypeOf() {
/*  181 */     return avoidObjectDetection() ? "undefined" : "object";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean has(String name, Scriptable start) {
/*  202 */     return (null != this.slotMap.query(name, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean has(int index, Scriptable start) {
/*  214 */     if (this.externalData != null) {
/*  215 */       return (index < this.externalData.getArrayLength());
/*      */     }
/*  217 */     return (null != this.slotMap.query(null, index));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean has(Symbol key, Scriptable start) {
/*  223 */     return (null != this.slotMap.query(key, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(String name, Scriptable start) {
/*  237 */     Slot slot = this.slotMap.query(name, 0);
/*  238 */     if (slot == null) {
/*  239 */       return Scriptable.NOT_FOUND;
/*      */     }
/*  241 */     return slot.getValue(start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(int index, Scriptable start) {
/*  253 */     if (this.externalData != null) {
/*  254 */       if (index < this.externalData.getArrayLength()) {
/*  255 */         return this.externalData.getArrayElement(index);
/*      */       }
/*  257 */       return Scriptable.NOT_FOUND;
/*      */     } 
/*      */     
/*  260 */     Slot slot = this.slotMap.query(null, index);
/*  261 */     if (slot == null) {
/*  262 */       return Scriptable.NOT_FOUND;
/*      */     }
/*  264 */     return slot.getValue(start);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(Symbol key, Scriptable start) {
/*  270 */     Slot slot = this.slotMap.query(key, 0);
/*  271 */     if (slot == null) {
/*  272 */       return Scriptable.NOT_FOUND;
/*      */     }
/*  274 */     return slot.getValue(start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void put(String name, Scriptable start, Object value) {
/*  291 */     if (putImpl(name, 0, start, value))
/*      */       return; 
/*  293 */     if (start == this) throw Kit.codeBug(); 
/*  294 */     start.put(name, start, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void put(int index, Scriptable start, Object value) {
/*  306 */     if (this.externalData != null) {
/*  307 */       if (index < this.externalData.getArrayLength()) {
/*  308 */         this.externalData.setArrayElement(index, value);
/*      */       } else {
/*  310 */         throw new JavaScriptException(
/*  311 */             ScriptRuntime.newNativeError(
/*  312 */               Context.getCurrentContext(), this, TopLevel.NativeErrors.RangeError, new Object[] { "External array index out of bounds " }), null, 0);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  322 */     if (putImpl(null, index, start, value))
/*      */       return; 
/*  324 */     if (start == this) throw Kit.codeBug(); 
/*  325 */     start.put(index, start, value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void put(Symbol key, Scriptable start, Object value) {
/*  331 */     if (putImpl(key, 0, start, value))
/*      */       return; 
/*  333 */     if (start == this) throw Kit.codeBug(); 
/*  334 */     ensureSymbolScriptable(start).put(key, start, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void delete(String name) {
/*  346 */     checkNotSealed(name, 0);
/*  347 */     this.slotMap.remove(name, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void delete(int index) {
/*  359 */     checkNotSealed(null, index);
/*  360 */     this.slotMap.remove(null, index);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void delete(Symbol key) {
/*  366 */     checkNotSealed(key, 0);
/*  367 */     this.slotMap.remove(key, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void putConst(String name, Scriptable start, Object value) {
/*  384 */     if (putConstImpl(name, 0, start, value, 1))
/*      */       return; 
/*  386 */     if (start == this) throw Kit.codeBug(); 
/*  387 */     if (start instanceof ConstProperties)
/*  388 */     { ((ConstProperties)start).putConst(name, start, value); }
/*  389 */     else { start.put(name, start, value); }
/*      */   
/*      */   }
/*      */   
/*      */   public void defineConst(String name, Scriptable start) {
/*  394 */     if (putConstImpl(name, 0, start, Undefined.instance, 8))
/*      */       return; 
/*  396 */     if (start == this) throw Kit.codeBug(); 
/*  397 */     if (start instanceof ConstProperties) ((ConstProperties)start).defineConst(name, start);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConst(String name) {
/*  408 */     Slot slot = this.slotMap.query(name, 0);
/*  409 */     if (slot == null) {
/*  410 */       return false;
/*      */     }
/*  412 */     return ((slot.getAttributes() & 0x5) == 5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final int getAttributes(String name, Scriptable start) {
/*  421 */     return getAttributes(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final int getAttributes(int index, Scriptable start) {
/*  430 */     return getAttributes(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void setAttributes(String name, Scriptable start, int attributes) {
/*  439 */     setAttributes(name, attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setAttributes(int index, Scriptable start, int attributes) {
/*  448 */     setAttributes(index, attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAttributes(String name) {
/*  468 */     return getAttributeSlot(name, 0).getAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAttributes(int index) {
/*  484 */     return getAttributeSlot(null, index).getAttributes();
/*      */   }
/*      */   
/*      */   public int getAttributes(Symbol sym) {
/*  488 */     return getAttributeSlot(sym).getAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributes(String name, int attributes) {
/*  510 */     checkNotSealed(name, 0);
/*  511 */     Slot attrSlot = this.slotMap.modify(name, 0, 0);
/*  512 */     attrSlot.setAttributes(attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributes(int index, int attributes) {
/*  528 */     checkNotSealed(null, index);
/*  529 */     Slot attrSlot = this.slotMap.modify(null, index, 0);
/*  530 */     attrSlot.setAttributes(attributes);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAttributes(Symbol key, int attributes) {
/*  535 */     checkNotSealed(key, 0);
/*  536 */     Slot attrSlot = this.slotMap.modify(key, 0, 0);
/*  537 */     attrSlot.setAttributes(attributes);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setGetterOrSetter(String name, int index, Callable getterOrSetter, boolean isSetter) {
/*      */     AccessorSlot aSlot;
/*  543 */     if (name != null && index != 0) throw new IllegalArgumentException(name); 
/*  544 */     checkNotSealed(name, index);
/*      */ 
/*      */     
/*  547 */     if (isExtensible()) {
/*  548 */       Slot slot = this.slotMap.modify(name, index, 0);
/*  549 */       if (slot instanceof AccessorSlot) {
/*  550 */         aSlot = (AccessorSlot)slot;
/*      */       } else {
/*  552 */         aSlot = new AccessorSlot(slot);
/*  553 */         this.slotMap.replace(slot, aSlot);
/*      */       } 
/*      */     } else {
/*  556 */       Slot slot = this.slotMap.query(name, index);
/*  557 */       if (slot instanceof AccessorSlot) {
/*  558 */         aSlot = (AccessorSlot)slot;
/*      */       } else {
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*  564 */     int attributes = aSlot.getAttributes();
/*  565 */     if ((attributes & 0x1) != 0) {
/*  566 */       throw Context.reportRuntimeErrorById("msg.modify.readonly", new Object[] { name });
/*      */     }
/*      */ 
/*      */     
/*  570 */     if (isSetter) {
/*  571 */       if (getterOrSetter instanceof Function) {
/*  572 */         aSlot.setter = new AccessorSlot.FunctionSetter(getterOrSetter);
/*      */       } else {
/*  574 */         aSlot.setter = null;
/*      */       }
/*      */     
/*  577 */     } else if (getterOrSetter instanceof Function) {
/*  578 */       aSlot.getter = new AccessorSlot.FunctionGetter(getterOrSetter);
/*      */     } else {
/*  580 */       aSlot.getter = null;
/*      */     } 
/*      */ 
/*      */     
/*  584 */     aSlot.value = Undefined.instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getGetterOrSetter(String name, int index, Scriptable scope, boolean isSetter) {
/*  601 */     if (name != null && index != 0) throw new IllegalArgumentException(name); 
/*  602 */     Slot slot = this.slotMap.query(name, index);
/*  603 */     if (slot == null) return null;
/*      */ 
/*      */ 
/*      */     
/*  607 */     Function getterOrSetter = isSetter ? slot.getSetterFunction(name, scope) : slot.getGetterFunction(name, scope);
/*  608 */     return (getterOrSetter == null) ? Undefined.instance : getterOrSetter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Object getGetterOrSetter(String name, int index, boolean isSetter) {
/*  626 */     return getGetterOrSetter(name, index, this, isSetter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isGetterOrSetter(String name, int index, boolean setter) {
/*  638 */     Slot slot = this.slotMap.query(name, index);
/*  639 */     return (slot != null && slot.isSetterSlot());
/*      */   }
/*      */   void addLazilyInitializedValue(String name, int index, LazilyLoadedCtor init, int attributes) {
/*      */     LazyLoadSlot lslot;
/*  643 */     if (name != null && index != 0) throw new IllegalArgumentException(name); 
/*  644 */     checkNotSealed(name, index);
/*  645 */     Slot slot = this.slotMap.modify(name, index, 0);
/*      */     
/*  647 */     if (slot instanceof LazyLoadSlot) {
/*  648 */       lslot = (LazyLoadSlot)slot;
/*      */     } else {
/*  650 */       lslot = new LazyLoadSlot(slot);
/*  651 */       this.slotMap.replace(slot, lslot);
/*      */     } 
/*      */     
/*  654 */     lslot.setAttributes(attributes);
/*  655 */     lslot.value = init;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExternalArrayData(ExternalArrayData array) {
/*  670 */     this.externalData = array;
/*      */     
/*  672 */     if (array == null) {
/*  673 */       delete("length");
/*      */     } else {
/*      */       
/*  676 */       defineProperty("length", null, GET_ARRAY_LENGTH, null, 3);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExternalArrayData getExternalArrayData() {
/*  687 */     return this.externalData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getExternalArrayLength() {
/*  695 */     return Integer.valueOf((this.externalData == null) ? 0 : this.externalData.getArrayLength());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Scriptable getPrototype() {
/*  701 */     return this.prototypeObject;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPrototype(Scriptable m) {
/*  707 */     this.prototypeObject = m;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Scriptable getParentScope() {
/*  713 */     return this.parentScopeObject;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParentScope(Scriptable m) {
/*  719 */     this.parentScopeObject = m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getIds() {
/*  735 */     return getIds(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getAllIds() {
/*  749 */     return getIds(true, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getDefaultValue(Class<?> typeHint) {
/*  766 */     return getDefaultValue(this, typeHint);
/*      */   }
/*      */   
/*      */   public static Object getDefaultValue(Scriptable object, Class<?> typeHint) {
/*  770 */     Context cx = null;
/*  771 */     for (int i = 0; i < 2; i++) {
/*      */       boolean tryToString; String methodName;
/*  773 */       if (typeHint == ScriptRuntime.StringClass) {
/*  774 */         tryToString = (i == 0);
/*      */       } else {
/*  776 */         tryToString = (i == 1);
/*      */       } 
/*      */ 
/*      */       
/*  780 */       if (tryToString) {
/*  781 */         methodName = "toString";
/*      */       } else {
/*  783 */         methodName = "valueOf";
/*      */       } 
/*  785 */       Object v = getProperty(object, methodName);
/*  786 */       if (v instanceof Function) {
/*  787 */         Function fun = (Function)v;
/*  788 */         if (cx == null) {
/*  789 */           cx = Context.getContext();
/*      */         }
/*  791 */         v = fun.call(cx, fun.getParentScope(), object, ScriptRuntime.emptyArgs);
/*  792 */         if (v != null) {
/*  793 */           if (!(v instanceof Scriptable)) {
/*  794 */             return v;
/*      */           }
/*  796 */           if (typeHint == ScriptRuntime.ScriptableClass || typeHint == ScriptRuntime.FunctionClass)
/*      */           {
/*  798 */             return v;
/*      */           }
/*  800 */           if (tryToString && v instanceof Wrapper) {
/*      */ 
/*      */             
/*  803 */             Object u = ((Wrapper)v).unwrap();
/*  804 */             if (u instanceof String) return u; 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  809 */     String arg = (typeHint == null) ? "undefined" : typeHint.getName();
/*  810 */     throw ScriptRuntime.typeErrorById("msg.default.value", new Object[] { arg });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasInstance(Scriptable instance) {
/*  827 */     return ScriptRuntime.jsDelegatesTo(instance, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean avoidObjectDetection() {
/*  841 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object equivalentValues(Object value) {
/*  855 */     return (this == value) ? Boolean.TRUE : Scriptable.NOT_FOUND;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Scriptable> void defineClass(Scriptable scope, Class<T> clazz) throws IllegalAccessException, InstantiationException, InvocationTargetException {
/*  944 */     defineClass(scope, clazz, false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Scriptable> void defineClass(Scriptable scope, Class<T> clazz, boolean sealed) throws IllegalAccessException, InstantiationException, InvocationTargetException {
/*  968 */     defineClass(scope, clazz, sealed, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Scriptable> String defineClass(Scriptable scope, Class<T> clazz, boolean sealed, boolean mapInheritance) throws IllegalAccessException, InstantiationException, InvocationTargetException {
/*  996 */     BaseFunction ctor = buildClassCtor(scope, clazz, sealed, mapInheritance);
/*  997 */     if (ctor == null) return null; 
/*  998 */     String name = ctor.getClassPrototype().getClassName();
/*  999 */     defineProperty(scope, name, ctor, 2);
/* 1000 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Scriptable> BaseFunction buildClassCtor(Scriptable scope, Class<T> clazz, boolean sealed, boolean mapInheritance) throws IllegalAccessException, InstantiationException, InvocationTargetException {
/* 1006 */     Method[] methods = FunctionObject.getMethodList(clazz);
/* 1007 */     for (int i = 0; i < methods.length; i++) {
/* 1008 */       Method method = methods[i];
/* 1009 */       if (method.getName().equals("init")) {
/* 1010 */         Class<?>[] parmTypes = method.getParameterTypes();
/* 1011 */         if (parmTypes.length == 3 && parmTypes[0] == ScriptRuntime.ContextClass && parmTypes[1] == ScriptRuntime.ScriptableClass && parmTypes[2] == boolean.class && 
/*      */ 
/*      */ 
/*      */           
/* 1015 */           Modifier.isStatic(method.getModifiers())) {
/*      */           
/* 1017 */           Object[] args = { Context.getContext(), scope, sealed ? Boolean.TRUE : Boolean.FALSE };
/*      */           
/* 1019 */           method.invoke((Object)null, args);
/* 1020 */           return null;
/*      */         } 
/* 1022 */         if (parmTypes.length == 1 && parmTypes[0] == ScriptRuntime.ScriptableClass && 
/*      */           
/* 1024 */           Modifier.isStatic(method.getModifiers())) {
/* 1025 */           Object[] args = { scope };
/* 1026 */           method.invoke((Object)null, args);
/* 1027 */           return null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1034 */     Constructor[] arrayOfConstructor = (Constructor[])clazz.getConstructors();
/* 1035 */     Constructor<?> protoCtor = null;
/* 1036 */     for (int j = 0; j < arrayOfConstructor.length; j++) {
/* 1037 */       if ((arrayOfConstructor[j].getParameterTypes()).length == 0) {
/* 1038 */         protoCtor = arrayOfConstructor[j];
/*      */         break;
/*      */       } 
/*      */     } 
/* 1042 */     if (protoCtor == null) {
/* 1043 */       throw Context.reportRuntimeErrorById("msg.zero.arg.ctor", new Object[] { clazz.getName() });
/*      */     }
/*      */     
/* 1046 */     Scriptable proto = (Scriptable)protoCtor.newInstance(ScriptRuntime.emptyArgs);
/* 1047 */     String className = proto.getClassName();
/*      */ 
/*      */     
/* 1050 */     Object existing = getProperty(getTopLevelScope(scope), className);
/* 1051 */     if (existing instanceof BaseFunction) {
/* 1052 */       Object existingProto = ((BaseFunction)existing).getPrototypeProperty();
/* 1053 */       if (existingProto != null && clazz.equals(existingProto.getClass())) {
/* 1054 */         return (BaseFunction)existing;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1060 */     Scriptable superProto = null;
/* 1061 */     if (mapInheritance) {
/* 1062 */       Class<? super T> superClass = clazz.getSuperclass();
/* 1063 */       if (ScriptRuntime.ScriptableClass.isAssignableFrom(superClass) && 
/* 1064 */         !Modifier.isAbstract(superClass.getModifiers())) {
/* 1065 */         Class<? extends Scriptable> superScriptable = extendsScriptable(superClass);
/*      */         
/* 1067 */         String name = defineClass(scope, superScriptable, sealed, mapInheritance);
/*      */         
/* 1069 */         if (name != null) {
/* 1070 */           superProto = getClassPrototype(scope, name);
/*      */         }
/*      */       } 
/*      */     } 
/* 1074 */     if (superProto == null) {
/* 1075 */       superProto = getObjectPrototype(scope);
/*      */     }
/* 1077 */     proto.setPrototype(superProto);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1082 */     String functionPrefix = "jsFunction_";
/* 1083 */     String staticFunctionPrefix = "jsStaticFunction_";
/* 1084 */     String getterPrefix = "jsGet_";
/* 1085 */     String setterPrefix = "jsSet_";
/* 1086 */     String ctorName = "jsConstructor";
/*      */     
/* 1088 */     Member ctorMember = findAnnotatedMember((AccessibleObject[])methods, (Class)JSConstructor.class);
/* 1089 */     if (ctorMember == null) {
/* 1090 */       ctorMember = findAnnotatedMember((AccessibleObject[])arrayOfConstructor, (Class)JSConstructor.class);
/*      */     }
/* 1092 */     if (ctorMember == null) {
/* 1093 */       ctorMember = FunctionObject.findSingleMethod(methods, "jsConstructor");
/*      */     }
/* 1095 */     if (ctorMember == null) {
/* 1096 */       if (arrayOfConstructor.length == 1) {
/* 1097 */         ctorMember = arrayOfConstructor[0];
/* 1098 */       } else if (arrayOfConstructor.length == 2) {
/* 1099 */         if ((arrayOfConstructor[0].getParameterTypes()).length == 0) { ctorMember = arrayOfConstructor[1]; }
/* 1100 */         else if ((arrayOfConstructor[1].getParameterTypes()).length == 0) { ctorMember = arrayOfConstructor[0]; }
/*      */       
/* 1102 */       }  if (ctorMember == null) {
/* 1103 */         throw Context.reportRuntimeErrorById("msg.ctor.multiple.parms", new Object[] { clazz.getName() });
/*      */       }
/*      */     } 
/*      */     
/* 1107 */     FunctionObject ctor = new FunctionObject(className, ctorMember, scope);
/* 1108 */     if (ctor.isVarArgsMethod()) {
/* 1109 */       throw Context.reportRuntimeErrorById("msg.varargs.ctor", new Object[] { ctorMember.getName() });
/*      */     }
/* 1111 */     ctor.initAsConstructor(scope, proto);
/*      */     
/* 1113 */     Method finishInit = null;
/* 1114 */     HashSet<String> staticNames = new HashSet<>(), instanceNames = new HashSet<>();
/* 1115 */     for (Method method : methods) {
/* 1116 */       if (method == ctorMember) {
/*      */         continue;
/*      */       }
/* 1119 */       String name = method.getName();
/* 1120 */       if (name.equals("finishInit")) {
/* 1121 */         Class<?>[] parmTypes = method.getParameterTypes();
/* 1122 */         if (parmTypes.length == 3 && parmTypes[0] == ScriptRuntime.ScriptableClass && parmTypes[1] == FunctionObject.class && parmTypes[2] == ScriptRuntime.ScriptableClass && 
/*      */ 
/*      */ 
/*      */           
/* 1126 */           Modifier.isStatic(method.getModifiers())) {
/* 1127 */           finishInit = method;
/*      */           
/*      */           continue;
/*      */         } 
/*      */       } 
/* 1132 */       if (name.indexOf('$') != -1 || 
/* 1133 */         name.equals("jsConstructor"))
/*      */         continue; 
/* 1135 */       Annotation annotation = null;
/* 1136 */       String prefix = null;
/* 1137 */       if (method.isAnnotationPresent((Class)JSFunction.class)) {
/* 1138 */         annotation = method.getAnnotation(JSFunction.class);
/* 1139 */       } else if (method.isAnnotationPresent((Class)JSStaticFunction.class)) {
/* 1140 */         annotation = method.getAnnotation(JSStaticFunction.class);
/* 1141 */       } else if (method.isAnnotationPresent((Class)JSGetter.class)) {
/* 1142 */         annotation = method.getAnnotation(JSGetter.class);
/* 1143 */       } else if (method.isAnnotationPresent((Class)JSSetter.class)) {
/*      */         continue;
/*      */       } 
/*      */       
/* 1147 */       if (annotation == null) {
/* 1148 */         if (name.startsWith("jsFunction_")) {
/* 1149 */           prefix = "jsFunction_";
/* 1150 */         } else if (name.startsWith("jsStaticFunction_")) {
/* 1151 */           prefix = "jsStaticFunction_";
/* 1152 */         } else if (name.startsWith("jsGet_")) {
/* 1153 */           prefix = "jsGet_";
/*      */         } else {
/*      */           continue;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1161 */       boolean isStatic = (annotation instanceof JSStaticFunction || prefix == "jsStaticFunction_");
/*      */       
/* 1163 */       HashSet<String> names = isStatic ? staticNames : instanceNames;
/* 1164 */       String propName = getPropertyName(name, prefix, annotation);
/* 1165 */       if (names.contains(propName)) {
/* 1166 */         throw Context.reportRuntimeErrorById("duplicate.defineClass.name", new Object[] { name, propName });
/*      */       }
/* 1168 */       names.add(propName);
/* 1169 */       name = propName;
/*      */       
/* 1171 */       if (annotation instanceof JSGetter || prefix == "jsGet_") {
/* 1172 */         if (!(proto instanceof ScriptableObject)) {
/* 1173 */           throw Context.reportRuntimeErrorById("msg.extend.scriptable", new Object[] { proto
/* 1174 */                 .getClass().toString(), name });
/*      */         }
/* 1176 */         Method setter = findSetterMethod(methods, name, "jsSet_");
/* 1177 */         int attr = 0x6 | ((setter != null) ? 0 : 1);
/*      */ 
/*      */ 
/*      */         
/* 1181 */         ((ScriptableObject)proto).defineProperty(name, null, method, setter, attr);
/*      */       }
/*      */       else {
/*      */         
/* 1185 */         if (isStatic && !Modifier.isStatic(method.getModifiers())) {
/* 1186 */           throw Context.reportRuntimeError("jsStaticFunction must be used with static method.");
/*      */         }
/*      */ 
/*      */         
/* 1190 */         FunctionObject f = new FunctionObject(name, method, proto);
/* 1191 */         if (f.isVarArgsConstructor()) {
/* 1192 */           throw Context.reportRuntimeErrorById("msg.varargs.fun", new Object[] { ctorMember.getName() });
/*      */         }
/* 1194 */         defineProperty(isStatic ? ctor : proto, name, f, 2);
/* 1195 */         if (sealed) {
/* 1196 */           f.sealObject();
/*      */         }
/*      */       } 
/*      */       continue;
/*      */     } 
/* 1201 */     if (finishInit != null) {
/* 1202 */       Object[] finishArgs = { scope, ctor, proto };
/* 1203 */       finishInit.invoke((Object)null, finishArgs);
/*      */     } 
/*      */ 
/*      */     
/* 1207 */     if (sealed) {
/* 1208 */       ctor.sealObject();
/* 1209 */       if (proto instanceof ScriptableObject) {
/* 1210 */         ((ScriptableObject)proto).sealObject();
/*      */       }
/*      */     } 
/*      */     
/* 1214 */     return ctor;
/*      */   }
/*      */ 
/*      */   
/*      */   private static Member findAnnotatedMember(AccessibleObject[] members, Class<? extends Annotation> annotation) {
/* 1219 */     for (AccessibleObject member : members) {
/* 1220 */       if (member.isAnnotationPresent(annotation)) {
/* 1221 */         return (Member)member;
/*      */       }
/*      */     } 
/* 1224 */     return null;
/*      */   }
/*      */   
/*      */   private static Method findSetterMethod(Method[] methods, String name, String prefix) {
/* 1228 */     String newStyleName = "set" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
/* 1229 */     for (Method method : methods) {
/* 1230 */       JSSetter annotation = method.<JSSetter>getAnnotation(JSSetter.class);
/* 1231 */       if (annotation != null && (
/* 1232 */         name.equals(annotation.value()) || (""
/* 1233 */         .equals(annotation.value()) && newStyleName
/* 1234 */         .equals(method.getName())))) {
/* 1235 */         return method;
/*      */       }
/*      */     } 
/*      */     
/* 1239 */     String oldStyleName = prefix + name;
/* 1240 */     for (Method method : methods) {
/* 1241 */       if (oldStyleName.equals(method.getName())) {
/* 1242 */         return method;
/*      */       }
/*      */     } 
/* 1245 */     return null;
/*      */   }
/*      */   
/*      */   private static String getPropertyName(String methodName, String prefix, Annotation annotation) {
/* 1249 */     if (prefix != null) {
/* 1250 */       return methodName.substring(prefix.length());
/*      */     }
/* 1252 */     String propName = null;
/* 1253 */     if (annotation instanceof JSGetter) {
/* 1254 */       propName = ((JSGetter)annotation).value();
/* 1255 */       if ((propName == null || propName.length() == 0) && 
/* 1256 */         methodName.length() > 3 && methodName.startsWith("get")) {
/* 1257 */         propName = methodName.substring(3);
/* 1258 */         if (Character.isUpperCase(propName.charAt(0))) {
/* 1259 */           if (propName.length() == 1) {
/* 1260 */             propName = propName.toLowerCase();
/* 1261 */           } else if (!Character.isUpperCase(propName.charAt(1))) {
/*      */ 
/*      */             
/* 1264 */             propName = Character.toLowerCase(propName.charAt(0)) + propName.substring(1);
/*      */           }
/*      */         
/*      */         }
/*      */       } 
/* 1269 */     } else if (annotation instanceof JSFunction) {
/* 1270 */       propName = ((JSFunction)annotation).value();
/* 1271 */     } else if (annotation instanceof JSStaticFunction) {
/* 1272 */       propName = ((JSStaticFunction)annotation).value();
/*      */     } 
/* 1274 */     if (propName == null || propName.length() == 0) {
/* 1275 */       propName = methodName;
/*      */     }
/* 1277 */     return propName;
/*      */   }
/*      */ 
/*      */   
/*      */   private static <T extends Scriptable> Class<T> extendsScriptable(Class<?> c) {
/* 1282 */     if (ScriptRuntime.ScriptableClass.isAssignableFrom(c)) return (Class)c; 
/* 1283 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineProperty(String propertyName, Object value, int attributes) {
/* 1297 */     checkNotSealed(propertyName, 0);
/* 1298 */     put(propertyName, this, value);
/* 1299 */     setAttributes(propertyName, attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineProperty(Symbol key, Object value, int attributes) {
/* 1310 */     checkNotSealed(key, 0);
/* 1311 */     put(key, this, value);
/* 1312 */     setAttributes(key, attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void defineProperty(Scriptable destination, String propertyName, Object value, int attributes) {
/* 1327 */     if (!(destination instanceof ScriptableObject)) {
/* 1328 */       destination.put(propertyName, destination, value);
/*      */       return;
/*      */     } 
/* 1331 */     ScriptableObject so = (ScriptableObject)destination;
/* 1332 */     so.defineProperty(propertyName, value, attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void defineConstProperty(Scriptable destination, String propertyName) {
/* 1344 */     if (destination instanceof ConstProperties)
/* 1345 */     { ConstProperties cp = (ConstProperties)destination;
/* 1346 */       cp.defineConst(propertyName, destination); }
/* 1347 */     else { defineProperty(destination, propertyName, Undefined.instance, 13); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineProperty(String propertyName, Class<?> clazz, int attributes) {
/* 1368 */     int length = propertyName.length();
/* 1369 */     if (length == 0) throw new IllegalArgumentException(); 
/* 1370 */     char[] buf = new char[3 + length];
/* 1371 */     propertyName.getChars(0, length, buf, 3);
/* 1372 */     buf[3] = Character.toUpperCase(buf[3]);
/* 1373 */     buf[0] = 'g';
/* 1374 */     buf[1] = 'e';
/* 1375 */     buf[2] = 't';
/* 1376 */     String getterName = new String(buf);
/* 1377 */     buf[0] = 's';
/* 1378 */     String setterName = new String(buf);
/*      */     
/* 1380 */     Method[] methods = FunctionObject.getMethodList(clazz);
/* 1381 */     Method getter = FunctionObject.findSingleMethod(methods, getterName);
/* 1382 */     Method setter = FunctionObject.findSingleMethod(methods, setterName);
/* 1383 */     if (setter == null) attributes |= 0x1; 
/* 1384 */     defineProperty(propertyName, null, getter, (setter == null) ? null : setter, attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineProperty(String propertyName, Object delegateTo, Method getter, Method setter, int attributes) {
/*      */     AccessorSlot aSlot;
/* 1430 */     MemberBox getterBox = null;
/* 1431 */     if (getter != null) {
/* 1432 */       boolean delegatedForm; getterBox = new MemberBox(getter);
/*      */ 
/*      */       
/* 1435 */       if (!Modifier.isStatic(getter.getModifiers())) {
/* 1436 */         delegatedForm = (delegateTo != null);
/* 1437 */         getterBox.delegateTo = delegateTo;
/*      */       } else {
/* 1439 */         delegatedForm = true;
/*      */ 
/*      */         
/* 1442 */         getterBox.delegateTo = void.class;
/*      */       } 
/*      */       
/* 1445 */       String errorId = null;
/* 1446 */       Class<?>[] parmTypes = getter.getParameterTypes();
/* 1447 */       if (parmTypes.length == 0) {
/* 1448 */         if (delegatedForm) {
/* 1449 */           errorId = "msg.obj.getter.parms";
/*      */         }
/* 1451 */       } else if (parmTypes.length == 1) {
/* 1452 */         Object<?> argType = (Object<?>)parmTypes[0];
/*      */         
/* 1454 */         if (argType != ScriptRuntime.ScriptableClass && argType != ScriptRuntime.ScriptableObjectClass) {
/*      */           
/* 1456 */           errorId = "msg.bad.getter.parms";
/* 1457 */         } else if (!delegatedForm) {
/* 1458 */           errorId = "msg.bad.getter.parms";
/*      */         } 
/*      */       } else {
/* 1461 */         errorId = "msg.bad.getter.parms";
/*      */       } 
/* 1463 */       if (errorId != null) {
/* 1464 */         throw Context.reportRuntimeErrorById(errorId, new Object[] { getter.toString() });
/*      */       }
/*      */     } 
/*      */     
/* 1468 */     MemberBox setterBox = null;
/* 1469 */     if (setter != null) {
/* 1470 */       boolean delegatedForm; if (setter.getReturnType() != void.class) {
/* 1471 */         throw Context.reportRuntimeErrorById("msg.setter.return", new Object[] { setter.toString() });
/*      */       }
/* 1473 */       setterBox = new MemberBox(setter);
/*      */ 
/*      */       
/* 1476 */       if (!Modifier.isStatic(setter.getModifiers())) {
/* 1477 */         delegatedForm = (delegateTo != null);
/* 1478 */         setterBox.delegateTo = delegateTo;
/*      */       } else {
/* 1480 */         delegatedForm = true;
/*      */ 
/*      */         
/* 1483 */         setterBox.delegateTo = void.class;
/*      */       } 
/*      */       
/* 1486 */       String errorId = null;
/* 1487 */       Class<?>[] parmTypes = setter.getParameterTypes();
/* 1488 */       if (parmTypes.length == 1) {
/* 1489 */         if (delegatedForm) {
/* 1490 */           errorId = "msg.setter2.expected";
/*      */         }
/* 1492 */       } else if (parmTypes.length == 2) {
/* 1493 */         Object<?> argType = (Object<?>)parmTypes[0];
/*      */         
/* 1495 */         if (argType != ScriptRuntime.ScriptableClass && argType != ScriptRuntime.ScriptableObjectClass) {
/*      */           
/* 1497 */           errorId = "msg.setter2.parms";
/* 1498 */         } else if (!delegatedForm) {
/* 1499 */           errorId = "msg.setter1.parms";
/*      */         } 
/*      */       } else {
/* 1502 */         errorId = "msg.setter.parms";
/*      */       } 
/* 1504 */       if (errorId != null) {
/* 1505 */         throw Context.reportRuntimeErrorById(errorId, new Object[] { setter.toString() });
/*      */       }
/*      */     } 
/*      */     
/* 1509 */     Slot slot = this.slotMap.modify(propertyName, 0, 0);
/*      */     
/* 1511 */     if (slot instanceof AccessorSlot) {
/* 1512 */       aSlot = (AccessorSlot)slot;
/*      */     } else {
/* 1514 */       aSlot = new AccessorSlot(slot);
/* 1515 */       this.slotMap.replace(slot, aSlot);
/*      */     } 
/*      */     
/* 1518 */     aSlot.setAttributes(attributes);
/* 1519 */     if (getterBox != null) {
/* 1520 */       aSlot.getter = new AccessorSlot.MemberBoxGetter(getterBox);
/*      */     }
/* 1522 */     if (setterBox != null) {
/* 1523 */       aSlot.setter = new AccessorSlot.MemberBoxSetter(setterBox);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineOwnProperties(Context cx, ScriptableObject props) {
/* 1534 */     Object[] ids = props.getIds(false, true);
/* 1535 */     ScriptableObject[] descs = new ScriptableObject[ids.length]; int i, len;
/* 1536 */     for (i = 0, len = ids.length; i < len; i++) {
/* 1537 */       Object descObj = ScriptRuntime.getObjectElem(props, ids[i], cx);
/* 1538 */       ScriptableObject desc = ensureScriptableObject(descObj);
/* 1539 */       checkPropertyDefinition(desc);
/* 1540 */       descs[i] = desc;
/*      */     } 
/* 1542 */     for (i = 0, len = ids.length; i < len; i++) {
/* 1543 */       defineOwnProperty(cx, ids[i], descs[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineOwnProperty(Context cx, Object id, ScriptableObject desc) {
/* 1555 */     checkPropertyDefinition(desc);
/* 1556 */     defineOwnProperty(cx, id, desc, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineOwnProperty(Context cx, Object id, ScriptableObject desc, boolean checkValid) {
/*      */     int attributes;
/* 1572 */     Object key = null;
/* 1573 */     int index = 0;
/* 1574 */     if (id instanceof Symbol) {
/* 1575 */       key = id;
/*      */     } else {
/* 1577 */       ScriptRuntime.StringIdOrIndex s = ScriptRuntime.toStringIdOrIndex(cx, id);
/* 1578 */       if (s.stringId == null) {
/* 1579 */         index = s.index;
/*      */       } else {
/* 1581 */         key = s.stringId;
/*      */       } 
/*      */     } 
/*      */     
/* 1585 */     Slot slot = this.slotMap.query(key, index);
/* 1586 */     boolean isNew = (slot == null);
/*      */     
/* 1588 */     if (checkValid) {
/* 1589 */       ScriptableObject current = (slot == null) ? null : slot.getPropertyDescriptor(cx, this);
/* 1590 */       checkPropertyChange(id, current, desc);
/*      */     } 
/*      */     
/* 1593 */     boolean isAccessor = isAccessorDescriptor(desc);
/*      */ 
/*      */     
/* 1596 */     if (slot == null) {
/* 1597 */       slot = this.slotMap.modify(key, index, 0);
/* 1598 */       attributes = applyDescriptorToAttributeBitset(7, desc);
/*      */     } else {
/* 1600 */       attributes = applyDescriptorToAttributeBitset(slot.getAttributes(), desc);
/*      */     } 
/*      */     
/* 1603 */     if (isAccessor) {
/*      */       AccessorSlot fslot;
/*      */       
/* 1606 */       if (slot instanceof AccessorSlot) {
/* 1607 */         fslot = (AccessorSlot)slot;
/*      */       } else {
/* 1609 */         fslot = new AccessorSlot(slot);
/* 1610 */         this.slotMap.replace(slot, fslot);
/*      */       } 
/*      */       
/* 1613 */       Object getter = getProperty(desc, "get");
/* 1614 */       if (getter != NOT_FOUND) {
/* 1615 */         fslot.getter = new AccessorSlot.FunctionGetter(getter);
/*      */       }
/* 1617 */       Object setter = getProperty(desc, "set");
/* 1618 */       if (setter != NOT_FOUND) {
/* 1619 */         fslot.setter = new AccessorSlot.FunctionSetter(setter);
/*      */       }
/*      */       
/* 1622 */       fslot.value = Undefined.instance;
/* 1623 */       fslot.setAttributes(attributes);
/*      */     } else {
/* 1625 */       if (!slot.isValueSlot() && isDataDescriptor(desc)) {
/* 1626 */         Slot newSlot = new Slot(slot);
/* 1627 */         this.slotMap.replace(slot, newSlot);
/* 1628 */         slot = newSlot;
/*      */       } 
/* 1630 */       Object value = getProperty(desc, "value");
/* 1631 */       if (value != NOT_FOUND) {
/* 1632 */         slot.value = value;
/* 1633 */       } else if (isNew) {
/* 1634 */         slot.value = Undefined.instance;
/*      */       } 
/* 1636 */       slot.setAttributes(attributes);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineProperty(String name, Supplier<Object> getter, Consumer<Object> setter, int attributes) {
/*      */     LambdaSlot lSlot;
/* 1656 */     Slot slot = this.slotMap.modify(name, 0, attributes);
/*      */ 
/*      */     
/* 1659 */     if (slot instanceof LambdaSlot) {
/* 1660 */       lSlot = (LambdaSlot)slot;
/*      */     } else {
/* 1662 */       lSlot = new LambdaSlot(slot);
/* 1663 */       this.slotMap.replace(slot, lSlot);
/*      */     } 
/*      */     
/* 1666 */     lSlot.getter = getter;
/* 1667 */     lSlot.setter = setter;
/* 1668 */     setAttributes(name, attributes);
/*      */   }
/*      */   
/*      */   protected void checkPropertyDefinition(ScriptableObject desc) {
/* 1672 */     Object getter = getProperty(desc, "get");
/* 1673 */     if (getter != NOT_FOUND && getter != Undefined.instance && !(getter instanceof Callable)) {
/* 1674 */       throw ScriptRuntime.notFunctionError(getter);
/*      */     }
/* 1676 */     Object setter = getProperty(desc, "set");
/* 1677 */     if (setter != NOT_FOUND && setter != Undefined.instance && !(setter instanceof Callable)) {
/* 1678 */       throw ScriptRuntime.notFunctionError(setter);
/*      */     }
/* 1680 */     if (isDataDescriptor(desc) && isAccessorDescriptor(desc)) {
/* 1681 */       throw ScriptRuntime.typeErrorById("msg.both.data.and.accessor.desc", new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void checkPropertyChange(Object id, ScriptableObject current, ScriptableObject desc) {
/* 1686 */     if (current == null) {
/* 1687 */       if (!isExtensible()) throw ScriptRuntime.typeErrorById("msg.not.extensible", new Object[0]);
/*      */     
/* 1689 */     } else if (isFalse(current.get("configurable", current))) {
/* 1690 */       if (isTrue(getProperty(desc, "configurable")))
/* 1691 */         throw ScriptRuntime.typeErrorById("msg.change.configurable.false.to.true", new Object[] { id }); 
/* 1692 */       if (isTrue(current.get("enumerable", current)) != 
/* 1693 */         isTrue(getProperty(desc, "enumerable"))) {
/* 1694 */         throw ScriptRuntime.typeErrorById("msg.change.enumerable.with.configurable.false", new Object[] { id });
/*      */       }
/* 1696 */       boolean isData = isDataDescriptor(desc);
/* 1697 */       boolean isAccessor = isAccessorDescriptor(desc);
/* 1698 */       if (isData || isAccessor)
/*      */       {
/* 1700 */         if (isData && isDataDescriptor(current)) {
/* 1701 */           if (isFalse(current.get("writable", current))) {
/* 1702 */             if (isTrue(getProperty(desc, "writable"))) {
/* 1703 */               throw ScriptRuntime.typeErrorById("msg.change.writable.false.to.true.with.configurable.false", new Object[] { id });
/*      */             }
/*      */ 
/*      */             
/* 1707 */             if (!sameValue(getProperty(desc, "value"), current.get("value", current))) {
/* 1708 */               throw ScriptRuntime.typeErrorById("msg.change.value.with.writable.false", new Object[] { id });
/*      */             }
/*      */           } 
/* 1711 */         } else if (isAccessor && isAccessorDescriptor(current)) {
/* 1712 */           if (!sameValue(getProperty(desc, "set"), current.get("set", current))) {
/* 1713 */             throw ScriptRuntime.typeErrorById("msg.change.setter.with.configurable.false", new Object[] { id });
/*      */           }
/*      */           
/* 1716 */           if (!sameValue(getProperty(desc, "get"), current.get("get", current))) {
/* 1717 */             throw ScriptRuntime.typeErrorById("msg.change.getter.with.configurable.false", new Object[] { id });
/*      */           }
/*      */         } else {
/* 1720 */           if (isDataDescriptor(current)) {
/* 1721 */             throw ScriptRuntime.typeErrorById("msg.change.property.data.to.accessor.with.configurable.false", new Object[] { id });
/*      */           }
/* 1723 */           throw ScriptRuntime.typeErrorById("msg.change.property.accessor.to.data.with.configurable.false", new Object[] { id });
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected static boolean isTrue(Object value) {
/* 1731 */     return (value != NOT_FOUND && ScriptRuntime.toBoolean(value));
/*      */   }
/*      */   
/*      */   protected static boolean isFalse(Object value) {
/* 1735 */     return !isTrue(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean sameValue(Object newValue, Object currentValue) {
/* 1746 */     if (newValue == NOT_FOUND) {
/* 1747 */       return true;
/*      */     }
/* 1749 */     if (currentValue == NOT_FOUND) {
/* 1750 */       currentValue = Undefined.instance;
/*      */     }
/*      */ 
/*      */     
/* 1754 */     if (currentValue instanceof Number && newValue instanceof Number) {
/* 1755 */       double d1 = ((Number)currentValue).doubleValue();
/* 1756 */       double d2 = ((Number)newValue).doubleValue();
/* 1757 */       if (Double.isNaN(d1) && Double.isNaN(d2)) {
/* 1758 */         return true;
/*      */       }
/* 1760 */       if (d1 == 0.0D && Double.doubleToLongBits(d1) != Double.doubleToLongBits(d2)) {
/* 1761 */         return false;
/*      */       }
/*      */     } 
/* 1764 */     return ScriptRuntime.shallowEq(currentValue, newValue);
/*      */   }
/*      */   
/*      */   protected int applyDescriptorToAttributeBitset(int attributes, ScriptableObject desc) {
/* 1768 */     Object enumerable = getProperty(desc, "enumerable");
/* 1769 */     if (enumerable != NOT_FOUND)
/*      */     {
/* 1771 */       attributes = ScriptRuntime.toBoolean(enumerable) ? (attributes & 0xFFFFFFFD) : (attributes | 0x2);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1776 */     Object writable = getProperty(desc, "writable");
/* 1777 */     if (writable != NOT_FOUND)
/*      */     {
/* 1779 */       attributes = ScriptRuntime.toBoolean(writable) ? (attributes & 0xFFFFFFFE) : (attributes | 0x1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1784 */     Object configurable = getProperty(desc, "configurable");
/* 1785 */     if (configurable != NOT_FOUND)
/*      */     {
/* 1787 */       attributes = ScriptRuntime.toBoolean(configurable) ? (attributes & 0xFFFFFFFB) : (attributes | 0x4);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1792 */     return attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isDataDescriptor(ScriptableObject desc) {
/* 1802 */     return (hasProperty(desc, "value") || hasProperty(desc, "writable"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isAccessorDescriptor(ScriptableObject desc) {
/* 1812 */     return (hasProperty(desc, "get") || hasProperty(desc, "set"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isGenericDescriptor(ScriptableObject desc) {
/* 1822 */     return (!isDataDescriptor(desc) && !isAccessorDescriptor(desc));
/*      */   }
/*      */   
/*      */   protected static Scriptable ensureScriptable(Object arg) {
/* 1826 */     if (!(arg instanceof Scriptable))
/* 1827 */       throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] { ScriptRuntime.typeof(arg) }); 
/* 1828 */     return (Scriptable)arg;
/*      */   }
/*      */   
/*      */   protected static SymbolScriptable ensureSymbolScriptable(Object arg) {
/* 1832 */     if (!(arg instanceof SymbolScriptable))
/* 1833 */       throw ScriptRuntime.typeErrorById("msg.object.not.symbolscriptable", new Object[] {
/* 1834 */             ScriptRuntime.typeof(arg) }); 
/* 1835 */     return (SymbolScriptable)arg;
/*      */   }
/*      */   
/*      */   protected static ScriptableObject ensureScriptableObject(Object arg) {
/* 1839 */     if (arg instanceof ScriptableObject) {
/* 1840 */       return (ScriptableObject)arg;
/*      */     }
/* 1842 */     if (arg instanceof Delegator) {
/* 1843 */       return (ScriptableObject)((Delegator)arg).getDelegee();
/*      */     }
/* 1845 */     throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] { ScriptRuntime.typeof(arg) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineFunctionProperties(String[] names, Class<?> clazz, int attributes) {
/* 1861 */     Method[] methods = FunctionObject.getMethodList(clazz);
/* 1862 */     for (int i = 0; i < names.length; i++) {
/* 1863 */       String name = names[i];
/* 1864 */       Method m = FunctionObject.findSingleMethod(methods, name);
/* 1865 */       if (m == null) {
/* 1866 */         throw Context.reportRuntimeErrorById("msg.method.not.found", new Object[] { name, clazz.getName() });
/*      */       }
/* 1868 */       FunctionObject f = new FunctionObject(name, m, this);
/* 1869 */       defineProperty(name, f, attributes);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable getObjectPrototype(Scriptable scope) {
/* 1879 */     return TopLevel.getBuiltinPrototype(getTopLevelScope(scope), TopLevel.Builtins.Object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable getFunctionPrototype(Scriptable scope) {
/* 1888 */     return TopLevel.getBuiltinPrototype(getTopLevelScope(scope), TopLevel.Builtins.Function);
/*      */   }
/*      */   
/*      */   public static Scriptable getGeneratorFunctionPrototype(Scriptable scope) {
/* 1892 */     return TopLevel.getBuiltinPrototype(
/* 1893 */         getTopLevelScope(scope), TopLevel.Builtins.GeneratorFunction);
/*      */   }
/*      */   
/*      */   public static Scriptable getArrayPrototype(Scriptable scope) {
/* 1897 */     return TopLevel.getBuiltinPrototype(getTopLevelScope(scope), TopLevel.Builtins.Array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable getClassPrototype(Scriptable scope, String className) {
/*      */     Object proto;
/* 1913 */     scope = getTopLevelScope(scope);
/* 1914 */     Object ctor = getProperty(scope, className);
/*      */     
/* 1916 */     if (ctor instanceof BaseFunction) {
/* 1917 */       proto = ((BaseFunction)ctor).getPrototypeProperty();
/* 1918 */     } else if (ctor instanceof Scriptable) {
/* 1919 */       Scriptable ctorObj = (Scriptable)ctor;
/* 1920 */       proto = ctorObj.get("prototype", ctorObj);
/*      */     } else {
/* 1922 */       return null;
/*      */     } 
/* 1924 */     if (proto instanceof Scriptable) {
/* 1925 */       return (Scriptable)proto;
/*      */     }
/* 1927 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable getTopLevelScope(Scriptable obj) {
/*      */     while (true) {
/* 1941 */       Scriptable parent = obj.getParentScope();
/* 1942 */       if (parent == null) {
/* 1943 */         return obj;
/*      */       }
/* 1945 */       obj = parent;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isExtensible() {
/* 1950 */     return this.isExtensible;
/*      */   }
/*      */   
/*      */   public void preventExtensions() {
/* 1954 */     this.isExtensible = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sealObject() {
/* 1967 */     if (!this.isSealed) {
/* 1968 */       long stamp = this.slotMap.readLock();
/*      */       try {
/* 1970 */         for (Slot slot : this.slotMap) {
/* 1971 */           Object value = slot.value;
/* 1972 */           if (value instanceof LazilyLoadedCtor) {
/* 1973 */             LazilyLoadedCtor initializer = (LazilyLoadedCtor)value;
/*      */             try {
/* 1975 */               initializer.init();
/*      */             } finally {
/* 1977 */               slot.value = initializer.getValue();
/*      */             } 
/*      */           } 
/*      */         } 
/* 1981 */         this.isSealed = true;
/*      */       } finally {
/* 1983 */         this.slotMap.unlockRead(stamp);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isSealed() {
/* 1996 */     return this.isSealed;
/*      */   }
/*      */   
/*      */   private void checkNotSealed(Object key, int index) {
/* 2000 */     if (!isSealed())
/*      */       return; 
/* 2002 */     String str = (key != null) ? key.toString() : Integer.toString(index);
/* 2003 */     throw Context.reportRuntimeErrorById("msg.modify.sealed", new Object[] { str });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getProperty(Scriptable obj, String name) {
/*      */     Object result;
/* 2020 */     Scriptable start = obj;
/*      */     
/*      */     do {
/* 2023 */       result = obj.get(name, start);
/* 2024 */       if (result != Scriptable.NOT_FOUND)
/* 2025 */         break;  obj = obj.getPrototype();
/* 2026 */     } while (obj != null);
/* 2027 */     return result;
/*      */   }
/*      */   
/*      */   public static Object getProperty(Scriptable obj, Symbol key) {
/*      */     Object result;
/* 2032 */     Scriptable start = obj;
/*      */     
/*      */     do {
/* 2035 */       result = ensureSymbolScriptable(obj).get(key, start);
/* 2036 */       if (result != Scriptable.NOT_FOUND)
/* 2037 */         break;  obj = obj.getPrototype();
/* 2038 */     } while (obj != null);
/* 2039 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T getTypedProperty(Scriptable s, int index, Class<T> type) {
/* 2061 */     Object val = getProperty(s, index);
/* 2062 */     if (val == Scriptable.NOT_FOUND) {
/* 2063 */       val = null;
/*      */     }
/* 2065 */     return type.cast(Context.jsToJava(val, type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getProperty(Scriptable obj, int index) {
/*      */     Object result;
/* 2084 */     Scriptable start = obj;
/*      */     
/*      */     do {
/* 2087 */       result = obj.get(index, start);
/* 2088 */       if (result != Scriptable.NOT_FOUND)
/* 2089 */         break;  obj = obj.getPrototype();
/* 2090 */     } while (obj != null);
/* 2091 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T getTypedProperty(Scriptable s, String name, Class<T> type) {
/* 2111 */     Object val = getProperty(s, name);
/* 2112 */     if (val == Scriptable.NOT_FOUND) {
/* 2113 */       val = null;
/*      */     }
/* 2115 */     return type.cast(Context.jsToJava(val, type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasProperty(Scriptable obj, String name) {
/* 2132 */     return (null != getBase(obj, name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void redefineProperty(Scriptable obj, String name, boolean isConst) {
/* 2144 */     Scriptable base = getBase(obj, name);
/* 2145 */     if (base == null)
/* 2146 */       return;  if (base instanceof ConstProperties) {
/* 2147 */       ConstProperties cp = (ConstProperties)base;
/*      */       
/* 2149 */       if (cp.isConst(name)) throw ScriptRuntime.typeErrorById("msg.const.redecl", new Object[] { name }); 
/*      */     } 
/* 2151 */     if (isConst) throw ScriptRuntime.typeErrorById("msg.var.redecl", new Object[] { name });
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasProperty(Scriptable obj, int index) {
/* 2168 */     return (null != getBase(obj, index));
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean hasProperty(Scriptable obj, Symbol key) {
/* 2173 */     return (null != getBase(obj, key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void putProperty(Scriptable obj, String name, Object value) {
/* 2192 */     Scriptable base = getBase(obj, name);
/* 2193 */     if (base == null) base = obj; 
/* 2194 */     base.put(name, obj, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void putProperty(Scriptable obj, Symbol key, Object value) {
/* 2199 */     Scriptable base = getBase(obj, key);
/* 2200 */     if (base == null) base = obj; 
/* 2201 */     ensureSymbolScriptable(base).put(key, obj, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void putConstProperty(Scriptable obj, String name, Object value) {
/* 2220 */     Scriptable base = getBase(obj, name);
/* 2221 */     if (base == null) base = obj; 
/* 2222 */     if (base instanceof ConstProperties) ((ConstProperties)base).putConst(name, obj, value);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void putProperty(Scriptable obj, int index, Object value) {
/* 2241 */     Scriptable base = getBase(obj, index);
/* 2242 */     if (base == null) base = obj; 
/* 2243 */     base.put(index, obj, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean deleteProperty(Scriptable obj, String name) {
/* 2258 */     Scriptable base = getBase(obj, name);
/* 2259 */     if (base == null) return true; 
/* 2260 */     base.delete(name);
/* 2261 */     return !base.has(name, obj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean deleteProperty(Scriptable obj, int index) {
/* 2276 */     Scriptable base = getBase(obj, index);
/* 2277 */     if (base == null) return true; 
/* 2278 */     base.delete(index);
/* 2279 */     return !base.has(index, obj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] getPropertyIds(Scriptable obj) {
/* 2293 */     if (obj == null) {
/* 2294 */       return ScriptRuntime.emptyArgs;
/*      */     }
/* 2296 */     Object[] result = obj.getIds();
/* 2297 */     ObjToIntMap map = null;
/*      */     while (true) {
/* 2299 */       obj = obj.getPrototype();
/* 2300 */       if (obj == null) {
/*      */         break;
/*      */       }
/* 2303 */       Object[] ids = obj.getIds();
/* 2304 */       if (ids.length == 0) {
/*      */         continue;
/*      */       }
/* 2307 */       if (map == null) {
/* 2308 */         if (result.length == 0) {
/* 2309 */           result = ids;
/*      */           continue;
/*      */         } 
/* 2312 */         map = new ObjToIntMap(result.length + ids.length);
/* 2313 */         for (int j = 0; j != result.length; j++) {
/* 2314 */           map.intern(result[j]);
/*      */         }
/* 2316 */         result = null;
/*      */       } 
/* 2318 */       for (int i = 0; i != ids.length; i++) {
/* 2319 */         map.intern(ids[i]);
/*      */       }
/*      */     } 
/* 2322 */     if (map != null) {
/* 2323 */       result = map.getKeys();
/*      */     }
/* 2325 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callMethod(Scriptable obj, String methodName, Object[] args) {
/* 2337 */     return callMethod(null, obj, methodName, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callMethod(Context cx, Scriptable obj, String methodName, Object[] args) {
/* 2349 */     Object funObj = getProperty(obj, methodName);
/* 2350 */     if (!(funObj instanceof Function)) {
/* 2351 */       throw ScriptRuntime.notFunctionError(obj, methodName);
/*      */     }
/* 2353 */     Function fun = (Function)funObj;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2361 */     Scriptable scope = getTopLevelScope(obj);
/* 2362 */     if (cx != null) {
/* 2363 */       return fun.call(cx, scope, obj, args);
/*      */     }
/* 2365 */     return Context.call(null, fun, scope, obj, args);
/*      */   }
/*      */ 
/*      */   
/*      */   private static Scriptable getBase(Scriptable obj, String name) {
/* 2370 */     while (!obj.has(name, obj))
/* 2371 */     { obj = obj.getPrototype();
/* 2372 */       if (obj == null)
/* 2373 */         break;  }  return obj;
/*      */   }
/*      */ 
/*      */   
/*      */   private static Scriptable getBase(Scriptable obj, int index) {
/* 2378 */     while (!obj.has(index, obj))
/* 2379 */     { obj = obj.getPrototype();
/* 2380 */       if (obj == null)
/* 2381 */         break;  }  return obj;
/*      */   }
/*      */ 
/*      */   
/*      */   private static Scriptable getBase(Scriptable obj, Symbol key) {
/* 2386 */     while (!ensureSymbolScriptable(obj).has(key, obj))
/* 2387 */     { obj = obj.getPrototype();
/* 2388 */       if (obj == null)
/* 2389 */         break;  }  return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object getAssociatedValue(Object key) {
/* 2399 */     Map<Object, Object> h = this.associatedValues;
/* 2400 */     if (h == null) return null; 
/* 2401 */     return h.get(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getTopScopeValue(Scriptable scope, Object key) {
/* 2415 */     scope = getTopLevelScope(scope);
/*      */     while (true) {
/* 2417 */       if (scope instanceof ScriptableObject) {
/* 2418 */         ScriptableObject so = (ScriptableObject)scope;
/* 2419 */         Object value = so.getAssociatedValue(key);
/* 2420 */         if (value != null) {
/* 2421 */           return value;
/*      */         }
/*      */       } 
/* 2424 */       scope = scope.getPrototype();
/* 2425 */       if (scope == null) {
/* 2426 */         return null;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized Object associateValue(Object key, Object value) {
/* 2445 */     if (value == null) throw new IllegalArgumentException(); 
/* 2446 */     Map<Object, Object> h = this.associatedValues;
/* 2447 */     if (h == null) {
/* 2448 */       h = new HashMap<>();
/* 2449 */       this.associatedValues = h;
/*      */     } 
/* 2451 */     return Kit.initHash(h, key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean putImpl(Object key, int index, Scriptable start, Object value) {
/*      */     Slot slot;
/* 2466 */     if (this != start) {
/* 2467 */       slot = this.slotMap.query(key, index);
/* 2468 */       if (!this.isExtensible && (slot == null || (!(slot instanceof AccessorSlot) && (slot
/*      */ 
/*      */         
/* 2471 */         .getAttributes() & 0x1) != 0)) && 
/* 2472 */         Context.isCurrentContextStrict()) {
/* 2473 */         throw ScriptRuntime.typeErrorById("msg.not.extensible", new Object[0]);
/*      */       }
/* 2475 */       if (slot == null) {
/* 2476 */         return false;
/*      */       }
/* 2478 */     } else if (!this.isExtensible) {
/* 2479 */       slot = this.slotMap.query(key, index);
/* 2480 */       if ((slot == null || (!(slot instanceof AccessorSlot) && (slot
/*      */         
/* 2482 */         .getAttributes() & 0x1) != 0)) && 
/* 2483 */         Context.isCurrentContextStrict()) {
/* 2484 */         throw ScriptRuntime.typeErrorById("msg.not.extensible", new Object[0]);
/*      */       }
/* 2486 */       if (slot == null) {
/* 2487 */         return true;
/*      */       }
/*      */     } else {
/* 2490 */       if (this.isSealed) {
/* 2491 */         checkNotSealed(key, index);
/*      */       }
/* 2493 */       slot = this.slotMap.modify(key, index, 0);
/*      */     } 
/* 2495 */     return slot.setValue(value, this, start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean putConstImpl(String name, int index, Scriptable start, Object value, int constFlag) {
/*      */     Slot slot;
/* 2510 */     assert constFlag != 0;
/* 2511 */     if (!this.isExtensible) {
/* 2512 */       Context cx = Context.getContext();
/* 2513 */       if (cx.isStrictMode()) {
/* 2514 */         throw ScriptRuntime.typeErrorById("msg.not.extensible", new Object[0]);
/*      */       }
/*      */     } 
/*      */     
/* 2518 */     if (this != start) {
/* 2519 */       slot = this.slotMap.query(name, index);
/* 2520 */       if (slot == null) {
/* 2521 */         return false;
/*      */       }
/* 2523 */     } else if (!isExtensible()) {
/* 2524 */       slot = this.slotMap.query(name, index);
/* 2525 */       if (slot == null) {
/* 2526 */         return true;
/*      */       }
/*      */     } else {
/* 2529 */       checkNotSealed(name, index);
/*      */       
/* 2531 */       slot = this.slotMap.modify(name, index, 13);
/* 2532 */       int attr = slot.getAttributes();
/* 2533 */       if ((attr & 0x1) == 0)
/* 2534 */         throw Context.reportRuntimeErrorById("msg.var.redecl", new Object[] { name }); 
/* 2535 */       if ((attr & 0x8) != 0) {
/* 2536 */         slot.value = value;
/*      */         
/* 2538 */         if (constFlag != 8)
/* 2539 */           slot.setAttributes(attr & 0xFFFFFFF7); 
/*      */       } 
/* 2541 */       return true;
/*      */     } 
/* 2543 */     return slot.setValue(value, this, start);
/*      */   }
/*      */   
/*      */   private Slot getAttributeSlot(String name, int index) {
/* 2547 */     Slot slot = this.slotMap.query(name, index);
/* 2548 */     if (slot == null) {
/* 2549 */       String str = (name != null) ? name : Integer.toString(index);
/* 2550 */       throw Context.reportRuntimeErrorById("msg.prop.not.found", new Object[] { str });
/*      */     } 
/* 2552 */     return slot;
/*      */   }
/*      */   
/*      */   private Slot getAttributeSlot(Symbol key) {
/* 2556 */     Slot slot = this.slotMap.query(key, 0);
/* 2557 */     if (slot == null) {
/* 2558 */       throw Context.reportRuntimeErrorById("msg.prop.not.found", new Object[] { key });
/*      */     }
/* 2560 */     return slot;
/*      */   }
/*      */   
/*      */   Object[] getIds(boolean getNonEnumerable, boolean getSymbols) {
/*      */     Object[] a, result;
/* 2565 */     int externalLen = (this.externalData == null) ? 0 : this.externalData.getArrayLength();
/*      */     
/* 2567 */     if (externalLen == 0) {
/* 2568 */       a = ScriptRuntime.emptyArgs;
/*      */     } else {
/* 2570 */       a = new Object[externalLen];
/* 2571 */       for (int i = 0; i < externalLen; i++) {
/* 2572 */         a[i] = Integer.valueOf(i);
/*      */       }
/*      */     } 
/* 2575 */     if (this.slotMap.isEmpty()) {
/* 2576 */       return a;
/*      */     }
/*      */     
/* 2579 */     int c = externalLen;
/* 2580 */     long stamp = this.slotMap.readLock();
/*      */     try {
/* 2582 */       for (Slot slot : this.slotMap) {
/* 2583 */         if ((getNonEnumerable || (slot.getAttributes() & 0x2) == 0) && (getSymbols || !(slot.name instanceof Symbol))) {
/*      */           
/* 2585 */           if (c == externalLen) {
/*      */             
/* 2587 */             Object[] oldA = a;
/* 2588 */             a = new Object[this.slotMap.dirtySize() + externalLen];
/* 2589 */             if (oldA != null) {
/* 2590 */               System.arraycopy(oldA, 0, a, 0, externalLen);
/*      */             }
/*      */           } 
/* 2593 */           a[c++] = (slot.name != null) ? slot.name : Integer.valueOf(slot.indexOrHash);
/*      */         } 
/*      */       } 
/*      */     } finally {
/* 2597 */       this.slotMap.unlockRead(stamp);
/*      */     } 
/*      */ 
/*      */     
/* 2601 */     if (c == a.length + externalLen) {
/* 2602 */       result = a;
/*      */     } else {
/* 2604 */       result = new Object[c];
/* 2605 */       System.arraycopy(a, 0, result, 0, c);
/*      */     } 
/*      */     
/* 2608 */     Context cx = Context.getCurrentContext();
/* 2609 */     if (cx != null && cx.hasFeature(16))
/*      */     {
/* 2611 */       Arrays.sort(result, KEY_COMPARATOR);
/*      */     }
/*      */     
/* 2614 */     return result;
/*      */   }
/*      */   
/*      */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 2618 */     out.defaultWriteObject();
/* 2619 */     long stamp = this.slotMap.readLock();
/*      */     try {
/* 2621 */       int objectsCount = this.slotMap.dirtySize();
/* 2622 */       if (objectsCount == 0) {
/* 2623 */         out.writeInt(0);
/*      */       } else {
/* 2625 */         out.writeInt(objectsCount);
/* 2626 */         for (Slot slot : this.slotMap) {
/* 2627 */           out.writeObject(slot);
/*      */         }
/*      */       } 
/*      */     } finally {
/* 2631 */       this.slotMap.unlockRead(stamp);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 2636 */     in.defaultReadObject();
/*      */     
/* 2638 */     int tableSize = in.readInt();
/* 2639 */     this.slotMap = createSlotMap(tableSize);
/* 2640 */     for (int i = 0; i < tableSize; i++) {
/* 2641 */       Slot slot = (Slot)in.readObject();
/* 2642 */       this.slotMap.add(slot);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected ScriptableObject getOwnPropertyDescriptor(Context cx, Object id) {
/* 2647 */     Slot slot = querySlot(cx, id);
/* 2648 */     if (slot == null) return null; 
/* 2649 */     Scriptable scope = getParentScope();
/* 2650 */     return slot.getPropertyDescriptor(cx, (scope == null) ? this : scope);
/*      */   }
/*      */   
/*      */   protected Slot querySlot(Context cx, Object id) {
/* 2654 */     if (id instanceof Symbol) {
/* 2655 */       return this.slotMap.query(id, 0);
/*      */     }
/* 2657 */     ScriptRuntime.StringIdOrIndex s = ScriptRuntime.toStringIdOrIndex(cx, id);
/* 2658 */     if (s.stringId == null) {
/* 2659 */       return this.slotMap.query(null, s.index);
/*      */     }
/* 2661 */     return this.slotMap.query(s.stringId, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/* 2668 */     return this.slotMap.size();
/*      */   }
/*      */   
/*      */   public boolean isEmpty() {
/* 2672 */     return this.slotMap.isEmpty();
/*      */   }
/*      */   
/*      */   public Object get(Object key) {
/* 2676 */     Object value = null;
/* 2677 */     if (key instanceof String) {
/* 2678 */       value = get((String)key, this);
/* 2679 */     } else if (key instanceof Symbol) {
/* 2680 */       value = get((Symbol)key, this);
/* 2681 */     } else if (key instanceof Number) {
/* 2682 */       value = get(((Number)key).intValue(), this);
/*      */     } 
/* 2684 */     if (value == Scriptable.NOT_FOUND || value == Undefined.instance)
/* 2685 */       return null; 
/* 2686 */     if (value instanceof Wrapper) {
/* 2687 */       return ((Wrapper)value).unwrap();
/*      */     }
/* 2689 */     return value;
/*      */   }
/*      */ 
/*      */   
/* 2693 */   private static final Comparator<Object> KEY_COMPARATOR = new KeyComparator();
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract String getClassName();
/*      */ 
/*      */   
/*      */   public static final class KeyComparator
/*      */     implements Comparator<Object>, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 6411335891523988149L;
/*      */ 
/*      */     
/*      */     public int compare(Object o1, Object o2) {
/* 2707 */       if (o1 instanceof Integer) {
/* 2708 */         if (o2 instanceof Integer) {
/* 2709 */           return ((Integer)o1).compareTo((Integer)o2);
/*      */         }
/* 2711 */         return -1;
/*      */       } 
/* 2713 */       if (o2 instanceof Integer) {
/* 2714 */         return 1;
/*      */       }
/* 2716 */       return 0;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ScriptableObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */