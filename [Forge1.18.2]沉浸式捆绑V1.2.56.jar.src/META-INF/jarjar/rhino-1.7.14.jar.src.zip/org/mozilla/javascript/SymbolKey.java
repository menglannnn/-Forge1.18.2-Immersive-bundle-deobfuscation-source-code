/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SymbolKey
/*    */   implements Symbol, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6019782713330994754L;
/* 19 */   public static final SymbolKey ITERATOR = new SymbolKey("Symbol.iterator");
/* 20 */   public static final SymbolKey TO_STRING_TAG = new SymbolKey("Symbol.toStringTag");
/* 21 */   public static final SymbolKey SPECIES = new SymbolKey("Symbol.species");
/* 22 */   public static final SymbolKey HAS_INSTANCE = new SymbolKey("Symbol.hasInstance");
/* 23 */   public static final SymbolKey IS_CONCAT_SPREADABLE = new SymbolKey("Symbol.isConcatSpreadable");
/* 24 */   public static final SymbolKey IS_REGEXP = new SymbolKey("Symbol.isRegExp");
/* 25 */   public static final SymbolKey TO_PRIMITIVE = new SymbolKey("Symbol.toPrimitive");
/* 26 */   public static final SymbolKey MATCH = new SymbolKey("Symbol.match");
/* 27 */   public static final SymbolKey REPLACE = new SymbolKey("Symbol.replace");
/* 28 */   public static final SymbolKey SEARCH = new SymbolKey("Symbol.search");
/* 29 */   public static final SymbolKey SPLIT = new SymbolKey("Symbol.split");
/* 30 */   public static final SymbolKey UNSCOPABLES = new SymbolKey("Symbol.unscopables");
/*    */   
/*    */   private String name;
/*    */ 
/*    */   
/*    */   public SymbolKey(String name) {
/* 36 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 40 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 46 */     return System.identityHashCode(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 52 */     if (o instanceof SymbolKey) {
/* 53 */       return (o == this);
/*    */     }
/* 55 */     if (o instanceof NativeSymbol) {
/* 56 */       return (((NativeSymbol)o).getKey() == this);
/*    */     }
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 64 */     if (this.name == null) {
/* 65 */       return "Symbol()";
/*    */     }
/* 67 */     return "Symbol(" + this.name + ')';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\SymbolKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */