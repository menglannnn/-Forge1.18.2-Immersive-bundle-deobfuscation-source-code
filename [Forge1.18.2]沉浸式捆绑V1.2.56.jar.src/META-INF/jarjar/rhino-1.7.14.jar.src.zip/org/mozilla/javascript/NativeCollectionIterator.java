/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class NativeCollectionIterator extends ES6Iterator {
/*    */   private static final long serialVersionUID = 7094840979404373443L;
/*    */   private String className;
/*    */   private Type type;
/* 13 */   private transient Iterator<Hashtable.Entry> iterator = Collections.emptyIterator();
/* 14 */   enum Type { KEYS, VALUES, BOTH; }
/*    */   
/*    */   static void init(ScriptableObject scope, String tag, boolean sealed) {
/* 17 */     ES6Iterator.init(scope, sealed, new NativeCollectionIterator(tag), tag);
/*    */   }
/*    */ 
/*    */   
/*    */   public NativeCollectionIterator(String tag) {
/* 22 */     this.className = tag;
/* 23 */     this.iterator = Collections.emptyIterator();
/* 24 */     this.type = Type.BOTH;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NativeCollectionIterator(Scriptable scope, String className, Type type, Iterator<Hashtable.Entry> iterator) {
/* 31 */     super(scope, className);
/* 32 */     this.className = className;
/* 33 */     this.iterator = iterator;
/* 34 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 39 */     return this.className;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isDone(Context cx, Scriptable scope) {
/* 44 */     return !this.iterator.hasNext();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object nextValue(Context cx, Scriptable scope) {
/* 49 */     Hashtable.Entry e = this.iterator.next();
/* 50 */     switch (this.type) {
/*    */       case KEYS:
/* 52 */         return e.key;
/*    */       case VALUES:
/* 54 */         return e.value;
/*    */       case BOTH:
/* 56 */         return cx.newArray(scope, new Object[] { e.key, e.value });
/*    */     } 
/* 58 */     throw new AssertionError();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 65 */     stream.defaultReadObject();
/* 66 */     this.className = (String)stream.readObject();
/* 67 */     this.type = (Type)stream.readObject();
/* 68 */     this.iterator = Collections.emptyIterator();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 74 */     stream.defaultWriteObject();
/* 75 */     stream.writeObject(this.className);
/* 76 */     stream.writeObject(this.type);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeCollectionIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */