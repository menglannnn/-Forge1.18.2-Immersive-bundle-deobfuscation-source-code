/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterfaceAdapter
/*     */ {
/*     */   private final Object proxyHelper;
/*     */   
/*     */   static Object create(Context cx, Class<?> cl, ScriptableObject object) {
/*  32 */     if (!cl.isInterface()) throw new IllegalArgumentException();
/*     */     
/*  34 */     Scriptable topScope = ScriptRuntime.getTopCallScope(cx);
/*  35 */     ClassCache cache = ClassCache.get(topScope);
/*     */     
/*  37 */     InterfaceAdapter adapter = (InterfaceAdapter)cache.getInterfaceAdapter(cl);
/*  38 */     ContextFactory cf = cx.getFactory();
/*  39 */     if (adapter == null) {
/*  40 */       if (object instanceof Callable) {
/*  41 */         Method[] methods = cl.getMethods();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  46 */         HashSet<String> functionalMethodNames = new HashSet<>();
/*  47 */         HashSet<String> defaultMethodNames = new HashSet<>();
/*  48 */         for (Method method : methods) {
/*     */ 
/*     */           
/*  51 */           if (isFunctionalMethodCandidate(method)) {
/*  52 */             functionalMethodNames.add(method.getName());
/*  53 */             if (functionalMethodNames.size() > 1) {
/*     */               break;
/*     */             }
/*     */           } else {
/*  57 */             defaultMethodNames.add(method.getName());
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*  63 */         boolean canConvert = (functionalMethodNames.size() == 1 || (functionalMethodNames.isEmpty() && defaultMethodNames.size() == 1));
/*     */         
/*  65 */         if (!canConvert) {
/*  66 */           if (functionalMethodNames.isEmpty() && defaultMethodNames.isEmpty()) {
/*  67 */             throw Context.reportRuntimeErrorById("msg.no.empty.interface.conversion", new Object[] { cl
/*     */                   
/*  69 */                   .getName() });
/*     */           }
/*  71 */           throw Context.reportRuntimeErrorById("msg.no.function.interface.conversion", new Object[] { cl
/*     */                 
/*  73 */                 .getName() });
/*     */         } 
/*     */       } 
/*     */       
/*  77 */       adapter = new InterfaceAdapter(cf, cl);
/*  78 */       cache.cacheInterfaceAdapter(cl, adapter);
/*     */     } 
/*  80 */     return VMBridge.instance.newInterfaceProxy(adapter.proxyHelper, cf, adapter, object, topScope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isFunctionalMethodCandidate(Method method) {
/*  91 */     if (method.getName().equals("equals") || method
/*  92 */       .getName().equals("hashCode") || method
/*  93 */       .getName().equals("toString"))
/*     */     {
/*     */       
/*  96 */       return false;
/*     */     }
/*  98 */     return Modifier.isAbstract(method.getModifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private InterfaceAdapter(ContextFactory cf, Class<?> cl) {
/* 104 */     this
/* 105 */       .proxyHelper = VMBridge.instance.getInterfaceProxyHelper(cf, new Class[] { cl });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(ContextFactory cf, Object target, Scriptable topScope, Object thisObject, Method method, Object[] args) {
/* 116 */     return cf.call(cx -> invokeImpl(cx, target, topScope, thisObject, method, args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object invokeImpl(Context cx, Object target, Scriptable topScope, Object thisObject, Method method, Object[] args) {
/*     */     Callable function;
/* 127 */     if (target instanceof Callable) {
/* 128 */       function = (Callable)target;
/*     */     } else {
/* 130 */       Scriptable s = (Scriptable)target;
/* 131 */       String methodName = method.getName();
/* 132 */       Object value = ScriptableObject.getProperty(s, methodName);
/* 133 */       if (value == Scriptable.NOT_FOUND) {
/*     */ 
/*     */ 
/*     */         
/* 137 */         Context.reportWarning(ScriptRuntime.getMessageById("msg.undefined.function.interface", new Object[] { methodName }));
/*     */         
/* 139 */         Class<?> resultType = method.getReturnType();
/* 140 */         if (resultType == void.class) {
/* 141 */           return null;
/*     */         }
/* 143 */         return Context.jsToJava(null, resultType);
/*     */       } 
/* 145 */       if (!(value instanceof Callable)) {
/* 146 */         throw Context.reportRuntimeErrorById("msg.not.function.interface", new Object[] { methodName });
/*     */       }
/*     */       
/* 149 */       function = (Callable)value;
/*     */     } 
/* 151 */     WrapFactory wf = cx.getWrapFactory();
/* 152 */     if (args == null) {
/* 153 */       args = ScriptRuntime.emptyArgs;
/*     */     } else {
/* 155 */       for (int i = 0, N = args.length; i != N; i++) {
/* 156 */         Object arg = args[i];
/*     */         
/* 158 */         if (!(arg instanceof String) && !(arg instanceof Number) && !(arg instanceof Boolean))
/*     */         {
/* 160 */           args[i] = wf.wrap(cx, topScope, arg, null);
/*     */         }
/*     */       } 
/*     */     } 
/* 164 */     Scriptable thisObj = wf.wrapAsJavaObject(cx, topScope, thisObject, null);
/*     */     
/* 166 */     Object result = function.call(cx, topScope, thisObj, args);
/* 167 */     Class<?> javaResultType = method.getReturnType();
/* 168 */     if (javaResultType == void.class) {
/* 169 */       result = null;
/*     */     } else {
/* 171 */       result = Context.jsToJava(result, javaResultType);
/*     */     } 
/* 173 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\InterfaceAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */