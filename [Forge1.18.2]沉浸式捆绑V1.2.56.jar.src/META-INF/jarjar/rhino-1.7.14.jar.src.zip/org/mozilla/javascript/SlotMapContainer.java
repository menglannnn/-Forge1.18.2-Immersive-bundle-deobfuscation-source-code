/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SlotMapContainer
/*     */   implements SlotMap
/*     */ {
/*     */   private static final int LARGE_HASH_SIZE = 2000;
/*     */   private static final int DEFAULT_SIZE = 10;
/*     */   protected SlotMap map;
/*     */   
/*     */   SlotMapContainer() {
/*  29 */     this(10);
/*     */   }
/*     */   
/*     */   SlotMapContainer(int initialSize) {
/*  33 */     if (initialSize > 2000) {
/*  34 */       this.map = new HashSlotMap();
/*     */     } else {
/*  36 */       this.map = new EmbeddedSlotMap();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  42 */     return this.map.size();
/*     */   }
/*     */   
/*     */   public int dirtySize() {
/*  46 */     return this.map.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  51 */     return this.map.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Slot modify(Object key, int index, int attributes) {
/*  56 */     checkMapSize();
/*  57 */     return this.map.modify(key, index, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(Slot oldSlot, Slot newSlot) {
/*  62 */     this.map.replace(oldSlot, newSlot);
/*     */   }
/*     */ 
/*     */   
/*     */   public Slot query(Object key, int index) {
/*  67 */     return this.map.query(key, index);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Slot newSlot) {
/*  72 */     checkMapSize();
/*  73 */     this.map.add(newSlot);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(Object key, int index) {
/*  78 */     this.map.remove(key, index);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Slot> iterator() {
/*  83 */     return this.map.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLock() {
/*  88 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unlockRead(long stamp) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkMapSize() {
/* 100 */     if (this.map instanceof EmbeddedSlotMap && this.map.size() >= 2000) {
/* 101 */       SlotMap newMap = new HashSlotMap();
/* 102 */       for (Slot s : this.map) {
/* 103 */         newMap.add(s);
/*     */       }
/* 105 */       this.map = newMap;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\SlotMapContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */