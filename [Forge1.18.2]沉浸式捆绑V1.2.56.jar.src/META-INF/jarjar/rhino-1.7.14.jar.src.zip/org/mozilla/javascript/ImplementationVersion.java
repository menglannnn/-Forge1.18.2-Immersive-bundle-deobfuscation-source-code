/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.util.Enumeration;
/*    */ import java.util.jar.Attributes;
/*    */ import java.util.jar.Manifest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImplementationVersion
/*    */ {
/*    */   private String versionString;
/* 18 */   private static final ImplementationVersion version = new ImplementationVersion();
/*    */   
/*    */   public static String get() {
/* 21 */     return version.versionString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ImplementationVersion() {
/*    */     Enumeration<URL> urls;
/*    */     try {
/* 30 */       urls = ImplementationVersion.class.getClassLoader().getResources("META-INF/MANIFEST.MF");
/* 31 */     } catch (IOException ioe) {
/*    */       return;
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 37 */     while (urls.hasMoreElements()) {
/* 38 */       URL metaUrl = urls.nextElement();
/* 39 */       try (InputStream is = metaUrl.openStream()) {
/* 40 */         Manifest mf = new Manifest(is);
/* 41 */         Attributes attrs = mf.getMainAttributes();
/* 42 */         if ("Mozilla Rhino".equals(attrs.getValue("Implementation-Title"))) {
/* 43 */           StringBuilder buf = new StringBuilder(23);
/* 44 */           buf.append("Rhino ").append(attrs.getValue("Implementation-Version"));
/* 45 */           String builtDate = attrs.getValue("Built-Date");
/* 46 */           if (builtDate != null) {
/* 47 */             builtDate = builtDate.replaceAll("-", " ");
/* 48 */             buf.append(' ').append(builtDate);
/*    */           } 
/* 50 */           this.versionString = buf.toString();
/*    */           return;
/*    */         } 
/* 53 */       } catch (IOException iOException) {}
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 58 */     this.versionString = "Rhino Snapshot";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ImplementationVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */