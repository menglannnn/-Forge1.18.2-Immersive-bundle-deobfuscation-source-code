/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import org.mozilla.javascript.ast.ScriptNode;
/*      */ import org.mozilla.javascript.debug.DebugFrame;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Interpreter
/*      */   extends Icode
/*      */   implements Evaluator
/*      */ {
/*      */   InterpreterData itsData;
/*      */   static final int EXCEPTION_TRY_START_SLOT = 0;
/*      */   static final int EXCEPTION_TRY_END_SLOT = 1;
/*      */   static final int EXCEPTION_HANDLER_SLOT = 2;
/*      */   static final int EXCEPTION_TYPE_SLOT = 3;
/*      */   static final int EXCEPTION_LOCAL_SLOT = 4;
/*      */   static final int EXCEPTION_SCOPE_SLOT = 5;
/*      */   static final int EXCEPTION_SLOT_SIZE = 6;
/*      */   
/*      */   private static class CallFrame
/*      */     implements Cloneable, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -2843792508994958978L;
/*      */     CallFrame parentFrame;
/*      */     int frameIndex;
/*      */     boolean frozen;
/*      */     final InterpretedFunction fnOrScript;
/*      */     final InterpreterData idata;
/*      */     Object[] stack;
/*      */     int[] stackAttributes;
/*      */     double[] sDbl;
/*      */     final CallFrame varSource;
/*      */     final int localShift;
/*      */     final int emptyStackTop;
/*      */     final DebugFrame debuggerFrame;
/*      */     final boolean useActivation;
/*      */     boolean isContinuationsTopFrame;
/*      */     final Scriptable thisObj;
/*      */     Object result;
/*      */     double resultDbl;
/*      */     int pc;
/*      */     int pcPrevBranch;
/*      */     int pcSourceLineStart;
/*      */     Scriptable scope;
/*      */     int savedStackTop;
/*      */     int savedCallOp;
/*      */     Object throwable;
/*      */     
/*      */     CallFrame(Context cx, Scriptable thisObj, InterpretedFunction fnOrScript, CallFrame parentFrame) {
/*   91 */       this.idata = fnOrScript.idata;
/*      */       
/*   93 */       this.debuggerFrame = (cx.debugger != null) ? cx.debugger.getFrame(cx, this.idata) : null;
/*   94 */       this.useActivation = (this.debuggerFrame != null || this.idata.itsNeedsActivation);
/*      */       
/*   96 */       this.emptyStackTop = this.idata.itsMaxVars + this.idata.itsMaxLocals - 1;
/*   97 */       this.fnOrScript = fnOrScript;
/*   98 */       this.varSource = this;
/*   99 */       this.localShift = this.idata.itsMaxVars;
/*  100 */       this.thisObj = thisObj;
/*      */       
/*  102 */       this.parentFrame = parentFrame;
/*  103 */       this.frameIndex = (parentFrame == null) ? 0 : (parentFrame.frameIndex + 1);
/*  104 */       if (this.frameIndex > cx.getMaximumInterpreterStackDepth()) {
/*  105 */         throw Context.reportRuntimeError("Exceeded maximum stack depth");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  110 */       this.result = Undefined.instance;
/*  111 */       this.pcSourceLineStart = this.idata.firstLinePC;
/*      */       
/*  113 */       this.savedStackTop = this.emptyStackTop;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void initializeArgs(Context cx, Scriptable callerScope, Object[] args, double[] argsDbl, int argShift, int argCount) {
/*  123 */       if (this.useActivation) {
/*      */ 
/*      */         
/*  126 */         if (argsDbl != null) {
/*  127 */           args = Interpreter.getArgsArray(args, argsDbl, argShift, argCount);
/*      */         }
/*  129 */         argShift = 0;
/*  130 */         argsDbl = null;
/*      */       } 
/*      */       
/*  133 */       if (this.idata.itsFunctionType != 0) {
/*  134 */         this.scope = this.fnOrScript.getParentScope();
/*      */         
/*  136 */         if (this.useActivation) {
/*  137 */           if (this.idata.itsFunctionType == 4) {
/*  138 */             this
/*  139 */               .scope = ScriptRuntime.createArrowFunctionActivation(this.fnOrScript, this.scope, args, this.idata.isStrict);
/*      */           } else {
/*      */             
/*  142 */             this
/*  143 */               .scope = ScriptRuntime.createFunctionActivation(this.fnOrScript, this.scope, args, this.idata.isStrict);
/*      */           } 
/*      */         }
/*      */       } else {
/*      */         
/*  148 */         this.scope = callerScope;
/*  149 */         ScriptRuntime.initScript(this.fnOrScript, this.thisObj, cx, this.scope, this.fnOrScript.idata.evalScriptFlag);
/*      */       } 
/*      */ 
/*      */       
/*  153 */       if (this.idata.itsNestedFunctions != null) {
/*  154 */         if (this.idata.itsFunctionType != 0 && !this.idata.itsNeedsActivation) Kit.codeBug(); 
/*  155 */         for (int k = 0; k < this.idata.itsNestedFunctions.length; k++) {
/*  156 */           InterpreterData fdata = this.idata.itsNestedFunctions[k];
/*  157 */           if (fdata.itsFunctionType == 1) {
/*  158 */             Interpreter.initFunction(cx, this.scope, this.fnOrScript, k);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  163 */       int maxFrameArray = this.idata.itsMaxFrameArray;
/*      */       
/*  165 */       if (maxFrameArray != this.emptyStackTop + this.idata.itsMaxStack + 1) Kit.codeBug();
/*      */ 
/*      */ 
/*      */       
/*  169 */       this.stack = new Object[maxFrameArray];
/*  170 */       this.stackAttributes = new int[maxFrameArray];
/*  171 */       this.sDbl = new double[maxFrameArray];
/*      */       
/*  173 */       int varCount = this.idata.getParamAndVarCount();
/*  174 */       for (int i = 0; i < varCount; i++) {
/*  175 */         if (this.idata.getParamOrVarConst(i)) this.stackAttributes[i] = 13; 
/*      */       } 
/*  177 */       int definedArgs = this.idata.argCount;
/*  178 */       if (definedArgs > argCount) {
/*  179 */         definedArgs = argCount;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  184 */       System.arraycopy(args, argShift, this.stack, 0, definedArgs);
/*  185 */       if (argsDbl != null) {
/*  186 */         System.arraycopy(argsDbl, argShift, this.sDbl, 0, definedArgs);
/*      */       }
/*  188 */       for (int j = definedArgs; j != this.idata.itsMaxVars; j++)
/*  189 */         this.stack[j] = Undefined.instance; 
/*      */     }
/*      */     
/*      */     CallFrame cloneFrozen() {
/*      */       CallFrame copy;
/*  194 */       if (!this.frozen) Kit.codeBug();
/*      */ 
/*      */       
/*      */       try {
/*  198 */         copy = (CallFrame)clone();
/*  199 */       } catch (CloneNotSupportedException ex) {
/*  200 */         throw new IllegalStateException();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  206 */       copy.stack = (Object[])this.stack.clone();
/*  207 */       copy.stackAttributes = (int[])this.stackAttributes.clone();
/*  208 */       copy.sDbl = (double[])this.sDbl.clone();
/*      */       
/*  210 */       copy.frozen = false;
/*  211 */       return copy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(Object other) {
/*  220 */       if (other instanceof CallFrame) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  225 */         Context cx = Context.enter();
/*      */         try {
/*  227 */           if (ScriptRuntime.hasTopCall(cx)) {
/*  228 */             return equalsInTopScope(other).booleanValue();
/*      */           }
/*  230 */           Scriptable top = ScriptableObject.getTopLevelScope(this.scope);
/*  231 */           return (
/*  232 */             (Boolean)ScriptRuntime.doTopCall((c, scope, thisObj, args) -> equalsInTopScope(other), cx, top, top, ScriptRuntime.emptyArgs, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  240 */               isStrictTopFrame()))
/*  241 */             .booleanValue();
/*      */         } finally {
/*  243 */           Context.exit();
/*      */         } 
/*      */       } 
/*  246 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  255 */       int depth = 0;
/*  256 */       CallFrame f = this;
/*  257 */       int h = 0;
/*      */       do {
/*  259 */         h = 31 * (31 * h + f.pc) + f.idata.icodeHashCode();
/*  260 */         f = f.parentFrame;
/*  261 */       } while (f != null && depth++ < 8);
/*  262 */       return h;
/*      */     }
/*      */     
/*      */     private Boolean equalsInTopScope(Object other) {
/*  266 */       return EqualObjectGraphs.<Boolean>withThreadLocal(eq -> equals(this, (CallFrame)other, eq));
/*      */     }
/*      */     
/*      */     private boolean isStrictTopFrame() {
/*  270 */       CallFrame f = this;
/*      */       while (true) {
/*  272 */         CallFrame p = f.parentFrame;
/*  273 */         if (p == null) {
/*  274 */           return f.idata.isStrict;
/*      */         }
/*  276 */         f = p;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static Boolean equals(CallFrame f1, CallFrame f2, EqualObjectGraphs equal) {
/*      */       while (true) {
/*  284 */         if (f1 == f2)
/*  285 */           return Boolean.TRUE; 
/*  286 */         if (f1 == null || f2 == null)
/*  287 */           return Boolean.FALSE; 
/*  288 */         if (!f1.fieldsEqual(f2, equal)) {
/*  289 */           return Boolean.FALSE;
/*      */         }
/*  291 */         f1 = f1.parentFrame;
/*  292 */         f2 = f2.parentFrame;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean fieldsEqual(CallFrame other, EqualObjectGraphs equal) {
/*  298 */       return (this.frameIndex == other.frameIndex && this.pc == other.pc && Interpreter
/*      */         
/*  300 */         .compareIdata(this.idata, other.idata) && equal
/*  301 */         .equalGraphs(this.varSource.stack, other.varSource.stack) && 
/*  302 */         Arrays.equals(this.varSource.sDbl, other.varSource.sDbl) && equal
/*  303 */         .equalGraphs(this.thisObj, other.thisObj) && equal
/*  304 */         .equalGraphs(this.fnOrScript, other.fnOrScript) && equal
/*  305 */         .equalGraphs(this.scope, other.scope));
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean compareIdata(InterpreterData i1, InterpreterData i2) {
/*  310 */     return (i1 == i2 || Objects.equals(getEncodedSource(i1), getEncodedSource(i2)));
/*      */   }
/*      */   
/*      */   private static final class ContinuationJump
/*      */     implements Serializable {
/*      */     private static final long serialVersionUID = 7687739156004308247L;
/*      */     Interpreter.CallFrame capturedFrame;
/*      */     Interpreter.CallFrame branchFrame;
/*      */     Object result;
/*      */     double resultDbl;
/*      */     
/*      */     ContinuationJump(NativeContinuation c, Interpreter.CallFrame current) {
/*  322 */       this.capturedFrame = (Interpreter.CallFrame)c.getImplementation();
/*  323 */       if (this.capturedFrame == null || current == null) {
/*      */ 
/*      */ 
/*      */         
/*  327 */         this.branchFrame = null;
/*      */       }
/*      */       else {
/*      */         
/*  331 */         Interpreter.CallFrame chain1 = this.capturedFrame;
/*  332 */         Interpreter.CallFrame chain2 = current;
/*      */ 
/*      */ 
/*      */         
/*  336 */         int diff = chain1.frameIndex - chain2.frameIndex;
/*  337 */         if (diff != 0) {
/*  338 */           if (diff < 0) {
/*      */ 
/*      */             
/*  341 */             chain1 = current;
/*  342 */             chain2 = this.capturedFrame;
/*  343 */             diff = -diff;
/*      */           } 
/*      */           while (true) {
/*  346 */             chain1 = chain1.parentFrame;
/*  347 */             if (--diff == 0) {
/*  348 */               if (chain1.frameIndex != chain2.frameIndex) Kit.codeBug(); 
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*  353 */         while (chain1 != chain2 && chain1 != null) {
/*  354 */           chain1 = chain1.parentFrame;
/*  355 */           chain2 = chain2.parentFrame;
/*      */         } 
/*      */         
/*  358 */         this.branchFrame = chain1;
/*  359 */         if (this.branchFrame != null && !this.branchFrame.frozen) Kit.codeBug(); 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static CallFrame captureFrameForGenerator(CallFrame frame) {
/*  365 */     frame.frozen = true;
/*  366 */     CallFrame result = frame.cloneFrozen();
/*  367 */     frame.frozen = false;
/*      */ 
/*      */     
/*  370 */     result.parentFrame = null;
/*  371 */     result.frameIndex = 0;
/*      */     
/*  373 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object compile(CompilerEnvirons compilerEnv, ScriptNode tree, String encodedSource, boolean returnFunction) {
/*  397 */     CodeGenerator cgen = new CodeGenerator();
/*  398 */     this.itsData = cgen.compile(compilerEnv, tree, encodedSource, returnFunction);
/*  399 */     return this.itsData;
/*      */   }
/*      */ 
/*      */   
/*      */   public Script createScriptObject(Object bytecode, Object staticSecurityDomain) {
/*  404 */     if (bytecode != this.itsData) {
/*  405 */       Kit.codeBug();
/*      */     }
/*  407 */     return InterpretedFunction.createScript(this.itsData, staticSecurityDomain);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEvalScriptFlag(Script script) {
/*  412 */     ((InterpretedFunction)script).idata.evalScriptFlag = true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Function createFunctionObject(Context cx, Scriptable scope, Object bytecode, Object staticSecurityDomain) {
/*  418 */     if (bytecode != this.itsData) {
/*  419 */       Kit.codeBug();
/*      */     }
/*  421 */     return InterpretedFunction.createFunction(cx, scope, this.itsData, staticSecurityDomain);
/*      */   }
/*      */   
/*      */   private static int getShort(byte[] iCode, int pc) {
/*  425 */     return iCode[pc] << 8 | iCode[pc + 1] & 0xFF;
/*      */   }
/*      */   
/*      */   private static int getIndex(byte[] iCode, int pc) {
/*  429 */     return (iCode[pc] & 0xFF) << 8 | iCode[pc + 1] & 0xFF;
/*      */   }
/*      */   
/*      */   private static int getInt(byte[] iCode, int pc) {
/*  433 */     return iCode[pc] << 24 | (iCode[pc + 1] & 0xFF) << 16 | (iCode[pc + 2] & 0xFF) << 8 | iCode[pc + 3] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getExceptionHandler(CallFrame frame, boolean onlyFinally) {
/*  440 */     int[] exceptionTable = frame.idata.itsExceptionTable;
/*  441 */     if (exceptionTable == null)
/*      */     {
/*  443 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  449 */     int pc = frame.pc - 1;
/*      */ 
/*      */     
/*  452 */     int best = -1, bestStart = 0, bestEnd = 0;
/*  453 */     for (int i = 0; i != exceptionTable.length; i += 6) {
/*  454 */       int start = exceptionTable[i + 0];
/*  455 */       int end = exceptionTable[i + 1];
/*  456 */       if (start > pc || pc >= end) {
/*      */         continue;
/*      */       }
/*  459 */       if (onlyFinally && exceptionTable[i + 3] != 1) {
/*      */         continue;
/*      */       }
/*  462 */       if (best >= 0) {
/*      */ 
/*      */ 
/*      */         
/*  466 */         if (bestEnd < end) {
/*      */           continue;
/*      */         }
/*      */         
/*  470 */         if (bestStart > start) Kit.codeBug(); 
/*  471 */         if (bestEnd == end) Kit.codeBug(); 
/*      */       } 
/*  473 */       best = i;
/*  474 */       bestStart = start;
/*  475 */       bestEnd = end; continue;
/*      */     } 
/*  477 */     return best;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void dumpICode(InterpreterData idata) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int bytecodeSpan(int bytecode) {
/*  738 */     switch (bytecode) {
/*      */       
/*      */       case -66:
/*      */       case -65:
/*      */       case -63:
/*      */       case -62:
/*      */       case 50:
/*      */       case 73:
/*  746 */         return 3;
/*      */ 
/*      */       
/*      */       case -54:
/*      */       case -23:
/*      */       case -6:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*  755 */         return 3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -21:
/*  761 */         return 5;
/*      */ 
/*      */       
/*      */       case 57:
/*  765 */         return 2;
/*      */ 
/*      */       
/*      */       case -11:
/*      */       case -10:
/*      */       case -9:
/*      */       case -8:
/*      */       case -7:
/*  773 */         return 2;
/*      */ 
/*      */       
/*      */       case -27:
/*  777 */         return 3;
/*      */ 
/*      */       
/*      */       case -28:
/*  781 */         return 5;
/*      */ 
/*      */       
/*      */       case -38:
/*  785 */         return 2;
/*      */ 
/*      */       
/*      */       case -39:
/*  789 */         return 3;
/*      */ 
/*      */       
/*      */       case -40:
/*  793 */         return 5;
/*      */ 
/*      */       
/*      */       case -45:
/*  797 */         return 2;
/*      */ 
/*      */       
/*      */       case -46:
/*  801 */         return 3;
/*      */ 
/*      */       
/*      */       case -47:
/*  805 */         return 5;
/*      */ 
/*      */       
/*      */       case -61:
/*      */       case -49:
/*      */       case -48:
/*  811 */         return 2;
/*      */ 
/*      */       
/*      */       case -26:
/*  815 */         return 3;
/*      */     } 
/*  817 */     if (!validBytecode(bytecode)) throw Kit.codeBug(); 
/*  818 */     return 1;
/*      */   }
/*      */   
/*      */   static int[] getLineNumbers(InterpreterData data) {
/*  822 */     UintMap presentLines = new UintMap();
/*      */     
/*  824 */     byte[] iCode = data.itsICode;
/*  825 */     int iCodeLength = iCode.length; int pc;
/*  826 */     for (pc = 0; pc != iCodeLength; ) {
/*  827 */       int bytecode = iCode[pc];
/*  828 */       int span = bytecodeSpan(bytecode);
/*  829 */       if (bytecode == -26) {
/*  830 */         if (span != 3) Kit.codeBug(); 
/*  831 */         int line = getIndex(iCode, pc + 1);
/*  832 */         presentLines.put(line, 0);
/*      */       } 
/*  834 */       pc += span;
/*      */     } 
/*      */     
/*  837 */     return presentLines.getKeys();
/*      */   }
/*      */   
/*      */   public void captureStackInfo(RhinoException ex) {
/*      */     CallFrame[] array;
/*  842 */     Context cx = Context.getCurrentContext();
/*  843 */     if (cx == null || cx.lastInterpreterFrame == null) {
/*      */       
/*  845 */       ex.interpreterStackInfo = null;
/*  846 */       ex.interpreterLineData = null;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  851 */     if (cx.previousInterpreterInvocations == null || cx.previousInterpreterInvocations
/*  852 */       .size() == 0) {
/*  853 */       array = new CallFrame[1];
/*      */     } else {
/*  855 */       int previousCount = cx.previousInterpreterInvocations.size();
/*  856 */       if (cx.previousInterpreterInvocations.peek() == cx.lastInterpreterFrame)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  861 */         previousCount--;
/*      */       }
/*  863 */       array = new CallFrame[previousCount + 1];
/*  864 */       cx.previousInterpreterInvocations.toArray((Object[])array);
/*      */     } 
/*  866 */     array[array.length - 1] = (CallFrame)cx.lastInterpreterFrame;
/*      */     
/*  868 */     int interpreterFrameCount = 0;
/*  869 */     for (int i = 0; i != array.length; i++) {
/*  870 */       interpreterFrameCount += 1 + (array[i]).frameIndex;
/*      */     }
/*      */     
/*  873 */     int[] linePC = new int[interpreterFrameCount];
/*      */ 
/*      */     
/*  876 */     int linePCIndex = interpreterFrameCount;
/*  877 */     for (int j = array.length; j != 0; ) {
/*  878 */       j--;
/*  879 */       CallFrame frame = array[j];
/*  880 */       while (frame != null) {
/*  881 */         linePCIndex--;
/*  882 */         linePC[linePCIndex] = frame.pcSourceLineStart;
/*  883 */         frame = frame.parentFrame;
/*      */       } 
/*      */     } 
/*  886 */     if (linePCIndex != 0) Kit.codeBug();
/*      */     
/*  888 */     ex.interpreterStackInfo = array;
/*  889 */     ex.interpreterLineData = linePC;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSourcePositionFromStack(Context cx, int[] linep) {
/*  894 */     CallFrame frame = (CallFrame)cx.lastInterpreterFrame;
/*  895 */     InterpreterData idata = frame.idata;
/*  896 */     if (frame.pcSourceLineStart >= 0) {
/*  897 */       linep[0] = getIndex(idata.itsICode, frame.pcSourceLineStart);
/*      */     } else {
/*  899 */       linep[0] = 0;
/*      */     } 
/*  901 */     return idata.itsSourceFile;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getPatchedStack(RhinoException ex, String nativeStackTrace) {
/*  906 */     String tag = "org.mozilla.javascript.Interpreter.interpretLoop";
/*  907 */     StringBuilder sb = new StringBuilder(nativeStackTrace.length() + 1000);
/*  908 */     String lineSeparator = SecurityUtilities.getSystemProperty("line.separator");
/*      */     
/*  910 */     CallFrame[] array = (CallFrame[])ex.interpreterStackInfo;
/*  911 */     int[] linePC = ex.interpreterLineData;
/*  912 */     int arrayIndex = array.length;
/*  913 */     int linePCIndex = linePC.length;
/*  914 */     int offset = 0;
/*  915 */     while (arrayIndex != 0) {
/*  916 */       arrayIndex--;
/*  917 */       int pos = nativeStackTrace.indexOf(tag, offset);
/*  918 */       if (pos < 0) {
/*      */         break;
/*      */       }
/*      */ 
/*      */       
/*  923 */       pos += tag.length();
/*      */       
/*  925 */       for (; pos != nativeStackTrace.length(); pos++) {
/*  926 */         char c = nativeStackTrace.charAt(pos);
/*  927 */         if (c == '\n' || c == '\r') {
/*      */           break;
/*      */         }
/*      */       } 
/*  931 */       sb.append(nativeStackTrace.substring(offset, pos));
/*  932 */       offset = pos;
/*      */       
/*  934 */       CallFrame frame = array[arrayIndex];
/*  935 */       while (frame != null) {
/*  936 */         if (linePCIndex == 0) Kit.codeBug(); 
/*  937 */         linePCIndex--;
/*  938 */         InterpreterData idata = frame.idata;
/*  939 */         sb.append(lineSeparator);
/*  940 */         sb.append("\tat script");
/*  941 */         if (idata.itsName != null && idata.itsName.length() != 0) {
/*  942 */           sb.append('.');
/*  943 */           sb.append(idata.itsName);
/*      */         } 
/*  945 */         sb.append('(');
/*  946 */         sb.append(idata.itsSourceFile);
/*  947 */         int pc = linePC[linePCIndex];
/*  948 */         if (pc >= 0) {
/*      */           
/*  950 */           sb.append(':');
/*  951 */           sb.append(getIndex(idata.itsICode, pc));
/*      */         } 
/*  953 */         sb.append(')');
/*  954 */         frame = frame.parentFrame;
/*      */       } 
/*      */     } 
/*  957 */     sb.append(nativeStackTrace.substring(offset));
/*      */     
/*  959 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> getScriptStack(RhinoException ex) {
/*  964 */     ScriptStackElement[][] stack = getScriptStackElements(ex);
/*  965 */     List<String> list = new ArrayList<>(stack.length);
/*  966 */     String lineSeparator = SecurityUtilities.getSystemProperty("line.separator");
/*  967 */     for (ScriptStackElement[] group : stack) {
/*  968 */       StringBuilder sb = new StringBuilder();
/*  969 */       for (ScriptStackElement elem : group) {
/*  970 */         elem.renderJavaStyle(sb);
/*  971 */         sb.append(lineSeparator);
/*      */       } 
/*  973 */       list.add(sb.toString());
/*      */     } 
/*  975 */     return list;
/*      */   }
/*      */   
/*      */   public ScriptStackElement[][] getScriptStackElements(RhinoException ex) {
/*  979 */     if (ex.interpreterStackInfo == null) {
/*  980 */       return (ScriptStackElement[][])null;
/*      */     }
/*      */     
/*  983 */     List<ScriptStackElement[]> list = (List)new ArrayList<>();
/*      */     
/*  985 */     CallFrame[] array = (CallFrame[])ex.interpreterStackInfo;
/*  986 */     int[] linePC = ex.interpreterLineData;
/*  987 */     int arrayIndex = array.length;
/*  988 */     int linePCIndex = linePC.length;
/*  989 */     while (arrayIndex != 0) {
/*  990 */       arrayIndex--;
/*  991 */       CallFrame frame = array[arrayIndex];
/*  992 */       List<ScriptStackElement> group = new ArrayList<>();
/*  993 */       while (frame != null) {
/*  994 */         if (linePCIndex == 0) Kit.codeBug(); 
/*  995 */         linePCIndex--;
/*  996 */         InterpreterData idata = frame.idata;
/*  997 */         String fileName = idata.itsSourceFile;
/*  998 */         String functionName = null;
/*  999 */         int lineNumber = -1;
/* 1000 */         int pc = linePC[linePCIndex];
/* 1001 */         if (pc >= 0) {
/* 1002 */           lineNumber = getIndex(idata.itsICode, pc);
/*      */         }
/* 1004 */         if (idata.itsName != null && idata.itsName.length() != 0) {
/* 1005 */           functionName = idata.itsName;
/*      */         }
/* 1007 */         frame = frame.parentFrame;
/* 1008 */         group.add(new ScriptStackElement(fileName, functionName, lineNumber));
/*      */       } 
/* 1010 */       list.add(group.toArray(new ScriptStackElement[group.size()]));
/*      */     } 
/* 1012 */     return list.<ScriptStackElement[]>toArray(new ScriptStackElement[list.size()][]);
/*      */   }
/*      */   
/*      */   static String getEncodedSource(InterpreterData idata) {
/* 1016 */     if (idata.encodedSource == null) {
/* 1017 */       return null;
/*      */     }
/* 1019 */     return idata.encodedSource.substring(idata.encodedSourceStart, idata.encodedSourceEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void initFunction(Context cx, Scriptable scope, InterpretedFunction parent, int index) {
/* 1025 */     InterpretedFunction fn = InterpretedFunction.createFunction(cx, scope, parent, index);
/* 1026 */     ScriptRuntime.initFunction(cx, scope, fn, fn.idata.itsFunctionType, parent.idata.evalScriptFlag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Object interpret(InterpretedFunction ifun, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 1036 */     if (!ScriptRuntime.hasTopCall(cx)) Kit.codeBug();
/*      */     
/* 1038 */     if (cx.interpreterSecurityDomain != ifun.securityDomain) {
/* 1039 */       Object savedDomain = cx.interpreterSecurityDomain;
/* 1040 */       cx.interpreterSecurityDomain = ifun.securityDomain;
/*      */       try {
/* 1042 */         return ifun.securityController.callWithDomain(ifun.securityDomain, cx, ifun, scope, thisObj, args);
/*      */       } finally {
/*      */         
/* 1045 */         cx.interpreterSecurityDomain = savedDomain;
/*      */       } 
/*      */     } 
/*      */     
/* 1049 */     CallFrame frame = initFrame(cx, scope, thisObj, args, (double[])null, 0, args.length, ifun, (CallFrame)null);
/* 1050 */     frame.isContinuationsTopFrame = cx.isContinuationsTopCall;
/* 1051 */     cx.isContinuationsTopCall = false;
/*      */     
/* 1053 */     return interpretLoop(cx, frame, (Object)null);
/*      */   }
/*      */   static class GeneratorState { int operation; Object value; RuntimeException returnedException;
/*      */     
/*      */     GeneratorState(int operation, Object value) {
/* 1058 */       this.operation = operation;
/* 1059 */       this.value = value;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object resumeGenerator(Context cx, Scriptable scope, int operation, Object savedState, Object value) {
/* 1069 */     CallFrame frame = (CallFrame)savedState;
/* 1070 */     GeneratorState generatorState = new GeneratorState(operation, value);
/* 1071 */     if (operation == 2)
/*      */       try {
/* 1073 */         return interpretLoop(cx, frame, generatorState);
/* 1074 */       } catch (RuntimeException e) {
/*      */         
/* 1076 */         if (e != value) throw e;
/*      */         
/* 1078 */         return Undefined.instance;
/*      */       }  
/* 1080 */     Object result = interpretLoop(cx, frame, generatorState);
/* 1081 */     if (generatorState.returnedException != null) throw generatorState.returnedException; 
/* 1082 */     return result;
/*      */   }
/*      */   
/*      */   public static Object restartContinuation(NativeContinuation c, Context cx, Scriptable scope, Object[] args) {
/*      */     Object arg;
/* 1087 */     if (!ScriptRuntime.hasTopCall(cx)) {
/* 1088 */       return ScriptRuntime.doTopCall(c, cx, scope, null, args, cx.isTopLevelStrict);
/*      */     }
/*      */ 
/*      */     
/* 1092 */     if (args.length == 0) {
/* 1093 */       arg = Undefined.instance;
/*      */     } else {
/* 1095 */       arg = args[0];
/*      */     } 
/*      */     
/* 1098 */     CallFrame capturedFrame = (CallFrame)c.getImplementation();
/* 1099 */     if (capturedFrame == null)
/*      */     {
/* 1101 */       return arg;
/*      */     }
/*      */     
/* 1104 */     ContinuationJump cjump = new ContinuationJump(c, null);
/*      */     
/* 1106 */     cjump.result = arg;
/* 1107 */     return interpretLoop(cx, (CallFrame)null, cjump);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object interpretLoop(Context cx, CallFrame frame, Object throwable) {
/* 1115 */     Object DBL_MRK = UniqueTag.DOUBLE_MARK;
/* 1116 */     Object undefined = Undefined.instance;
/*      */     
/* 1118 */     boolean instructionCounting = (cx.instructionThreshold != 0);
/*      */ 
/*      */     
/* 1121 */     int INVOCATION_COST = 100;
/*      */     
/* 1123 */     int EXCEPTION_COST = 100;
/*      */     
/* 1125 */     String stringReg = null;
/* 1126 */     BigInteger bigIntReg = null;
/* 1127 */     int indexReg = -1;
/*      */     
/* 1129 */     if (cx.lastInterpreterFrame != null) {
/*      */ 
/*      */       
/* 1132 */       if (cx.previousInterpreterInvocations == null) {
/* 1133 */         cx.previousInterpreterInvocations = new ObjArray();
/*      */       }
/* 1135 */       cx.previousInterpreterInvocations.push(cx.lastInterpreterFrame);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1145 */     GeneratorState generatorState = null;
/* 1146 */     if (throwable != null) {
/* 1147 */       if (throwable instanceof GeneratorState) {
/* 1148 */         generatorState = (GeneratorState)throwable;
/*      */ 
/*      */         
/* 1151 */         enterFrame(cx, frame, ScriptRuntime.emptyArgs, true);
/* 1152 */         throwable = null;
/* 1153 */       } else if (!(throwable instanceof ContinuationJump)) {
/*      */         
/* 1155 */         Kit.codeBug();
/*      */       } 
/*      */     }
/*      */     
/* 1159 */     Object interpreterResult = null;
/* 1160 */     double interpreterResultDbl = 0.0D;
/*      */ 
/*      */     
/*      */     label638: while (true) {
/*      */       boolean bool;
/*      */       
/*      */       try {
/* 1167 */         if (throwable != null)
/*      */         
/*      */         { 
/*      */           
/* 1171 */           frame = processThrowable(cx, throwable, frame, indexReg, instructionCounting);
/* 1172 */           throwable = frame.throwable;
/* 1173 */           frame.throwable = null; }
/*      */         
/* 1175 */         else if (generatorState == null && frame.frozen) { Kit.codeBug(); }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1180 */         Object[] stack = frame.stack;
/* 1181 */         double[] sDbl = frame.sDbl;
/* 1182 */         Object[] vars = frame.varSource.stack;
/* 1183 */         double[] varDbls = frame.varSource.sDbl;
/* 1184 */         int[] varAttributes = frame.varSource.stackAttributes;
/* 1185 */         byte[] iCode = frame.idata.itsICode;
/* 1186 */         String[] strings = frame.idata.itsStringTable;
/* 1187 */         BigInteger[] bigInts = frame.idata.itsBigIntTable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1193 */         int stackTop = frame.savedStackTop;
/*      */ 
/*      */         
/* 1196 */         cx.lastInterpreterFrame = frame; while (true) {
/*      */           Object object9; int sourceLine; NativeIterator.StopIteration si; Object object8; boolean bool1; int k; boolean valBln; int j, offset; Object object7, o; double lDbl, rDbl; Number rNum; Object object6, object5, rhs, object4; Ref ref1; Object object3; Ref ref; Object object2, value; Callable fun; Object object1; boolean afterFirstScope; Object lhs, val, obj, name; InterpretedFunction fn; int m; double d; Number rNegNum; Scriptable scriptable1; Object object10; Ref ref2; Object id; Scriptable funThisObj; Function function; Throwable caughtException; int enumType; Object re; int rIntValue; Scriptable calleeScope; Object[] outArgs;
/*      */           Scriptable lastCatchScope;
/*      */           Object templateLiterals[], object13, data[], object12;
/*      */           boolean bool2;
/*      */           Object object11;
/*      */           int i, getterSetters[];
/*      */           Object x, object14;
/* 1204 */           int op = iCode[frame.pc++];
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1209 */           switch (op)
/*      */           
/*      */           { case -62:
/* 1212 */               if (!frame.frozen) {
/*      */ 
/*      */                 
/* 1215 */                 frame.pc--;
/* 1216 */                 CallFrame generatorFrame = captureFrameForGenerator(frame);
/* 1217 */                 generatorFrame.frozen = true;
/* 1218 */                 if (cx.getLanguageVersion() >= 200) {
/* 1219 */                   frame.result = new ES6Generator(frame.scope, generatorFrame.fnOrScript, generatorFrame);
/*      */ 
/*      */                   
/*      */                   continue label638;
/*      */                 } 
/*      */                 
/* 1225 */                 frame.result = new NativeGenerator(frame.scope, generatorFrame.fnOrScript, generatorFrame);
/*      */                 continue label638;
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case -66:
/*      */             case 73:
/* 1239 */               if (!frame.frozen) {
/* 1240 */                 return freezeGenerator(cx, frame, stackTop, generatorState, (op == -66));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1247 */               object9 = thawGenerator(frame, stackTop, generatorState, op);
/* 1248 */               if (object9 != Scriptable.NOT_FOUND) {
/* 1249 */                 throwable = object9;
/*      */                 break;
/*      */               } 
/*      */               continue;
/*      */ 
/*      */ 
/*      */             
/*      */             case -63:
/* 1257 */               frame.frozen = true;
/* 1258 */               sourceLine = getIndex(iCode, frame.pc);
/* 1259 */               generatorState
/*      */                 
/* 1261 */                 .returnedException = new JavaScriptException(NativeIterator.getStopIterationObject(frame.scope), frame.idata.itsSourceFile, sourceLine);
/*      */               continue label638;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case -65:
/* 1270 */               frame.frozen = true;
/* 1271 */               frame.result = stack[stackTop];
/* 1272 */               frame.resultDbl = sDbl[stackTop];
/* 1273 */               stackTop--;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1278 */               si = new NativeIterator.StopIteration((frame.result == UniqueTag.DOUBLE_MARK) ? Double.valueOf(frame.resultDbl) : frame.result);
/*      */ 
/*      */               
/* 1281 */               m = getIndex(iCode, frame.pc);
/* 1282 */               generatorState.returnedException = new JavaScriptException(si, frame.idata.itsSourceFile, m);
/*      */               continue label638;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 50:
/* 1289 */               object8 = stack[stackTop];
/* 1290 */               if (object8 == DBL_MRK)
/* 1291 */                 object8 = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 1292 */               stackTop--;
/*      */               
/* 1294 */               m = getIndex(iCode, frame.pc);
/* 1295 */               throwable = new JavaScriptException(object8, frame.idata.itsSourceFile, m);
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 51:
/* 1302 */               indexReg += frame.localShift;
/* 1303 */               throwable = stack[indexReg];
/*      */               break;
/*      */ 
/*      */             
/*      */             case 14:
/*      */             case 15:
/*      */             case 16:
/*      */             case 17:
/* 1311 */               stackTop = doCompare(frame, op, stack, sDbl, stackTop);
/*      */               continue;
/*      */ 
/*      */             
/*      */             case 52:
/*      */             case 53:
/* 1317 */               stackTop = doInOrInstanceof(cx, op, stack, sDbl, stackTop);
/*      */               continue;
/*      */ 
/*      */             
/*      */             case 12:
/*      */             case 13:
/* 1323 */               stackTop--;
/* 1324 */               bool1 = doEquals(stack, sDbl, stackTop);
/* 1325 */               k = bool1 ^ ((op == 13) ? 1 : 0);
/* 1326 */               stack[stackTop] = ScriptRuntime.wrapBoolean(k);
/*      */               continue;
/*      */ 
/*      */             
/*      */             case 46:
/*      */             case 47:
/* 1332 */               stackTop--;
/* 1333 */               valBln = doShallowEquals(stack, sDbl, stackTop);
/* 1334 */               j = valBln ^ ((op == 47) ? 1 : 0);
/* 1335 */               stack[stackTop] = ScriptRuntime.wrapBoolean(j);
/*      */               continue;
/*      */             
/*      */             case 7:
/* 1339 */               if (stack_boolean(frame, stackTop--)) {
/* 1340 */                 frame.pc += 2;
/*      */                 continue;
/*      */               } 
/*      */             
/*      */             case 6:
/* 1345 */               if (!stack_boolean(frame, stackTop--)) {
/* 1346 */                 frame.pc += 2;
/*      */                 continue;
/*      */               } 
/*      */             
/*      */             case -6:
/* 1351 */               if (!stack_boolean(frame, stackTop--)) {
/* 1352 */                 frame.pc += 2;
/*      */                 continue;
/*      */               } 
/* 1355 */               stack[stackTop--] = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 5:
/* 2419 */               if (instructionCounting) {
/* 2420 */                 addInstructionCount(cx, frame, 2);
/*      */               }
/* 2422 */               offset = getShort(iCode, frame.pc);
/* 2423 */               if (offset != 0) {
/*      */                 
/* 2425 */                 frame.pc += offset - 1;
/*      */               } else {
/* 2427 */                 frame.pc = frame.idata.longJumps.getExistingInt(frame.pc);
/*      */               } 
/* 2429 */               if (instructionCounting)
/* 2430 */                 frame.pcPrevBranch = frame.pc;  continue;case -23: stackTop++; stack[stackTop] = DBL_MRK; sDbl[stackTop] = (frame.pc + 2);case -24: if (stackTop == frame.emptyStackTop + 1) { indexReg += frame.localShift; stack[indexReg] = stack[stackTop]; sDbl[indexReg] = sDbl[stackTop]; stackTop--; continue; }  if (stackTop != frame.emptyStackTop) Kit.codeBug();  continue;case -25: if (instructionCounting) addInstructionCount(cx, frame, 0);  indexReg += frame.localShift; object7 = stack[indexReg]; if (object7 != DBL_MRK) { throwable = object7; break; }  frame.pc = (int)sDbl[indexReg]; if (instructionCounting) frame.pcPrevBranch = frame.pc;  continue;case -4: stack[stackTop] = null; stackTop--; continue;case -5: frame.result = stack[stackTop]; frame.resultDbl = sDbl[stackTop]; stack[stackTop] = null; stackTop--; continue;case -1: stack[stackTop + 1] = stack[stackTop]; sDbl[stackTop + 1] = sDbl[stackTop]; stackTop++; continue;case -2: stack[stackTop + 1] = stack[stackTop - 1]; sDbl[stackTop + 1] = sDbl[stackTop - 1]; stack[stackTop + 2] = stack[stackTop]; sDbl[stackTop + 2] = sDbl[stackTop]; stackTop += 2; continue;case -3: o = stack[stackTop]; stack[stackTop] = stack[stackTop - 1]; stack[stackTop - 1] = o; d = sDbl[stackTop]; sDbl[stackTop] = sDbl[stackTop - 1]; sDbl[stackTop - 1] = d; continue;case 4: frame.result = stack[stackTop]; frame.resultDbl = sDbl[stackTop]; stackTop--; continue label638;case 65: break;case -22: frame.result = undefined; continue label638;case 27: stackTop = doBitNOT(frame, stack, sDbl, stackTop); continue;case 9: case 10: case 11: case 18: case 19: stackTop = doBitOp(frame, op, stack, sDbl, stackTop); continue;case 20: lDbl = stack_double(frame, stackTop - 1); rIntValue = stack_int32(frame, stackTop) & 0x1F; stack[--stackTop] = DBL_MRK; sDbl[stackTop] = (ScriptRuntime.toUint32(lDbl) >>> rIntValue); continue;case 28: rDbl = stack_double(frame, stackTop); stack[stackTop] = DBL_MRK; sDbl[stackTop] = rDbl; continue;case 29: rNum = stack_numeric(frame, stackTop); rNegNum = ScriptRuntime.negate(rNum); if (rNegNum instanceof BigInteger) { stack[stackTop] = rNegNum; continue; }  stack[stackTop] = DBL_MRK; sDbl[stackTop] = rNegNum.doubleValue(); continue;case 21: stackTop--; doAdd(stack, sDbl, stackTop, cx); continue;case 22: case 23: case 24: case 25: case 75: stackTop = doArithmetic(frame, op, stack, sDbl, stackTop); continue;case 26: stack[stackTop] = ScriptRuntime.wrapBoolean(!stack_boolean(frame, stackTop)); continue;case 49: stack[++stackTop] = ScriptRuntime.bind(cx, frame.scope, stringReg); continue;case 8: case 74: object6 = stack[stackTop]; if (object6 == DBL_MRK) object6 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stackTop--; scriptable1 = (Scriptable)stack[stackTop]; stack[stackTop] = (op == 8) ? ScriptRuntime.setName(scriptable1, object6, cx, frame.scope, stringReg) : ScriptRuntime.strictSetName(scriptable1, object6, cx, frame.scope, stringReg); continue;case -59: object6 = stack[stackTop]; if (object6 == DBL_MRK) object6 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stackTop--; scriptable1 = (Scriptable)stack[stackTop]; stack[stackTop] = ScriptRuntime.setConst(scriptable1, object6, cx, stringReg); continue;case 0: case 31: stackTop = doDelName(cx, frame, op, stack, sDbl, stackTop); continue;case 34: object5 = stack[stackTop]; if (object5 == DBL_MRK) object5 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.getObjectPropNoWarn(object5, stringReg, cx, frame.scope); continue;case 33: object5 = stack[stackTop]; if (object5 == DBL_MRK) object5 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.getObjectProp(object5, stringReg, cx, frame.scope); continue;case 35: rhs = stack[stackTop]; if (rhs == DBL_MRK) rhs = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stackTop--; object10 = stack[stackTop]; if (object10 == DBL_MRK) object10 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.setObjectProp(object10, stringReg, rhs, cx, frame.scope); continue;case -9: object4 = stack[stackTop]; if (object4 == DBL_MRK) object4 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.propIncrDecr(object4, stringReg, cx, frame.scope, iCode[frame.pc]); frame.pc++; continue;case 36: stackTop = doGetElem(cx, frame, stack, sDbl, stackTop); continue;case 37: stackTop = doSetElem(cx, frame, stack, sDbl, stackTop); continue;case -10: stackTop = doElemIncDec(cx, frame, iCode, stack, sDbl, stackTop); continue;case 68: ref1 = (Ref)stack[stackTop]; stack[stackTop] = ScriptRuntime.refGet(ref1, cx); continue;case 69: object3 = stack[stackTop]; if (object3 == DBL_MRK) object3 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stackTop--; ref2 = (Ref)stack[stackTop]; stack[stackTop] = ScriptRuntime.refSet(ref2, object3, cx, frame.scope); continue;case 70: ref = (Ref)stack[stackTop]; stack[stackTop] = ScriptRuntime.refDel(ref, cx); continue;case -11: ref = (Ref)stack[stackTop]; stack[stackTop] = ScriptRuntime.refIncrDecr(ref, cx, frame.scope, iCode[frame.pc]); frame.pc++; continue;case 54: stackTop++; indexReg += frame.localShift; stack[stackTop] = stack[indexReg]; sDbl[stackTop] = sDbl[indexReg]; continue;case -56: indexReg += frame.localShift; stack[indexReg] = null; continue;case -15: stackTop++; stack[stackTop] = ScriptRuntime.getNameFunctionAndThis(stringReg, cx, frame.scope); stackTop++; stack[stackTop] = ScriptRuntime.lastStoredScriptable(cx); continue;case -16: object2 = stack[stackTop]; if (object2 == DBL_MRK) object2 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.getPropFunctionAndThis(object2, stringReg, cx, frame.scope); stackTop++; stack[stackTop] = ScriptRuntime.lastStoredScriptable(cx); continue;case -17: object2 = stack[stackTop - 1]; if (object2 == DBL_MRK) object2 = ScriptRuntime.wrapNumber(sDbl[stackTop - 1]);  id = stack[stackTop]; if (id == DBL_MRK) id = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop - 1] = ScriptRuntime.getElemFunctionAndThis(object2, id, cx, frame.scope); stack[stackTop] = ScriptRuntime.lastStoredScriptable(cx); continue;case -18: value = stack[stackTop]; if (value == DBL_MRK) value = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.getValueFunctionAndThis(value, cx); stackTop++; stack[stackTop] = ScriptRuntime.lastStoredScriptable(cx); continue;case -21: if (instructionCounting) cx.instructionCount += 100;  stackTop = doCallSpecial(cx, frame, stack, sDbl, stackTop, iCode, indexReg); continue;case -55: case 38: case 71: if (instructionCounting) cx.instructionCount += 100;  stackTop -= 1 + indexReg; fun = (Callable)stack[stackTop]; funThisObj = (Scriptable)stack[stackTop + 1]; if (op == 71) { Object[] arrayOfObject = getArgsArray(stack, sDbl, stackTop + 2, indexReg); stack[stackTop] = ScriptRuntime.callRef(fun, funThisObj, arrayOfObject, cx); continue; }  calleeScope = frame.scope; if (frame.useActivation) calleeScope = ScriptableObject.getTopLevelScope(frame.scope);  if (fun instanceof InterpretedFunction) { InterpretedFunction ifun = (InterpretedFunction)fun; if (frame.fnOrScript.securityDomain == ifun.securityDomain) { CallFrame callParentFrame = frame; if (op == -55) { callParentFrame = frame.parentFrame; exitFrame(cx, frame, (Object)null); }  CallFrame calleeFrame = initFrame(cx, calleeScope, funThisObj, stack, sDbl, stackTop + 2, indexReg, ifun, callParentFrame); if (op != -55) { frame.savedStackTop = stackTop; frame.savedCallOp = op; }  frame = calleeFrame; continue label638; }  }  if (fun instanceof NativeContinuation) { ContinuationJump continuationJump = new ContinuationJump((NativeContinuation)fun, frame); if (indexReg == 0) { continuationJump.result = undefined; } else { continuationJump.result = stack[stackTop + 2]; continuationJump.resultDbl = sDbl[stackTop + 2]; }  throwable = continuationJump; break; }  if (fun instanceof IdFunctionObject) { IdFunctionObject ifun = (IdFunctionObject)fun; if (NativeContinuation.isContinuationConstructor(ifun)) { frame.stack[stackTop] = captureContinuation(cx, frame.parentFrame, false); continue; }  if (BaseFunction.isApplyOrCall(ifun)) { Callable applyCallable = ScriptRuntime.getCallable(funThisObj); if (applyCallable instanceof InterpretedFunction) { InterpretedFunction iApplyCallable = (InterpretedFunction)applyCallable; if (frame.fnOrScript.securityDomain == iApplyCallable.securityDomain) { frame = initFrameForApplyOrCall(cx, frame, indexReg, stack, sDbl, stackTop, op, calleeScope, ifun, iApplyCallable); continue label638; }  }  }  }  if (fun instanceof ScriptRuntime.NoSuchMethodShim) { ScriptRuntime.NoSuchMethodShim noSuchMethodShim = (ScriptRuntime.NoSuchMethodShim)fun; Callable noSuchMethodMethod = noSuchMethodShim.noSuchMethodMethod; if (noSuchMethodMethod instanceof InterpretedFunction) { InterpretedFunction ifun = (InterpretedFunction)noSuchMethodMethod; if (frame.fnOrScript.securityDomain == ifun.securityDomain) { frame = initFrameForNoSuchMethod(cx, frame, indexReg, stack, sDbl, stackTop, op, funThisObj, calleeScope, noSuchMethodShim, ifun); continue label638; }  }  }  cx.lastInterpreterFrame = frame; frame.savedCallOp = op; frame.savedStackTop = stackTop; stack[stackTop] = fun.call(cx, calleeScope, funThisObj, getArgsArray(stack, sDbl, stackTop + 2, indexReg)); continue;case 30: if (instructionCounting) cx.instructionCount += 100;  stackTop -= indexReg; object1 = stack[stackTop]; if (object1 instanceof InterpretedFunction) { InterpretedFunction f = (InterpretedFunction)object1; if (frame.fnOrScript.securityDomain == f.securityDomain) { Scriptable newInstance = f.createObject(cx, frame.scope); CallFrame calleeFrame = initFrame(cx, frame.scope, newInstance, stack, sDbl, stackTop + 1, indexReg, f, frame); stack[stackTop] = newInstance; frame.savedStackTop = stackTop; frame.savedCallOp = op; frame = calleeFrame; continue label638; }  }  if (!(object1 instanceof Function)) { if (object1 == DBL_MRK) object1 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  throw ScriptRuntime.notFunctionError(object1); }  function = (Function)object1; if (function instanceof IdFunctionObject) { IdFunctionObject ifun = (IdFunctionObject)function; if (NativeContinuation.isContinuationConstructor(ifun)) { frame.stack[stackTop] = captureContinuation(cx, frame.parentFrame, false); continue; }  }  outArgs = getArgsArray(stack, sDbl, stackTop + 1, indexReg); stack[stackTop] = function.construct(cx, frame.scope, outArgs); continue;case 32: object1 = stack[stackTop]; if (object1 == DBL_MRK) object1 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.typeof(object1); continue;case -14: stack[++stackTop] = ScriptRuntime.typeofName(frame.scope, stringReg); continue;case 41: stack[++stackTop] = stringReg; continue;case -27: stackTop++; stack[stackTop] = DBL_MRK; sDbl[stackTop] = getShort(iCode, frame.pc); frame.pc += 2; continue;case -28: stackTop++; stack[stackTop] = DBL_MRK; sDbl[stackTop] = getInt(iCode, frame.pc); frame.pc += 4; continue;case 40: stackTop++; stack[stackTop] = DBL_MRK; sDbl[stackTop] = frame.idata.itsDoubleTable[indexReg]; continue;case 83: stack[++stackTop] = bigIntReg; continue;case 39: stack[++stackTop] = ScriptRuntime.name(cx, frame.scope, stringReg); continue;case -8: stack[++stackTop] = ScriptRuntime.nameIncrDecr(frame.scope, stringReg, cx, iCode[frame.pc]); frame.pc++; continue;case -61: indexReg = iCode[frame.pc++];case 160: stackTop = doSetConstVar(frame, stack, sDbl, stackTop, vars, varDbls, varAttributes, indexReg); continue;case -49: indexReg = iCode[frame.pc++];case 56: stackTop = doSetVar(frame, stack, sDbl, stackTop, vars, varDbls, varAttributes, indexReg); continue;case -48: indexReg = iCode[frame.pc++];case 55: stackTop = doGetVar(frame, stack, sDbl, stackTop, vars, varDbls, indexReg); continue;case -7: stackTop = doVarIncDec(cx, frame, stack, sDbl, stackTop, vars, varDbls, varAttributes, indexReg); continue;case -51: stackTop++; stack[stackTop] = DBL_MRK; sDbl[stackTop] = 0.0D; continue;case -52: stackTop++; stack[stackTop] = DBL_MRK; sDbl[stackTop] = 1.0D; continue;case 42: stack[++stackTop] = null; continue;case 43: stack[++stackTop] = frame.thisObj; continue;case 64: stack[++stackTop] = frame.fnOrScript; continue;case 44: stack[++stackTop] = Boolean.FALSE; continue;case 45: stack[++stackTop] = Boolean.TRUE; continue;case -50: stack[++stackTop] = undefined; continue;case 2: object1 = stack[stackTop]; if (object1 == DBL_MRK) object1 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stackTop--; frame.scope = ScriptRuntime.enterWith(object1, cx, frame.scope); continue;case 3: frame.scope = ScriptRuntime.leaveWith(frame.scope); continue;case 57: stackTop--; indexReg += frame.localShift; afterFirstScope = (frame.idata.itsICode[frame.pc] != 0); caughtException = (Throwable)stack[stackTop + 1]; if (!afterFirstScope) { lastCatchScope = null; } else { lastCatchScope = (Scriptable)stack[indexReg]; }  stack[indexReg] = ScriptRuntime.newCatchScope(caughtException, lastCatchScope, stringReg, cx, frame.scope); frame.pc++; continue;case 58: case 59: case 60: case 61: lhs = stack[stackTop]; if (lhs == DBL_MRK) lhs = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stackTop--; indexReg += frame.localShift; enumType = (op == 58) ? 0 : ((op == 59) ? 1 : ((op == 61) ? 6 : 2)); stack[indexReg] = ScriptRuntime.enumInit(lhs, cx, frame.scope, enumType); continue;case 62: case 63: indexReg += frame.localShift; val = stack[indexReg]; stackTop++; stack[stackTop] = (op == 62) ? ScriptRuntime.enumNext(val) : ScriptRuntime.enumId(val, cx); continue;case 72: obj = stack[stackTop]; if (obj == DBL_MRK) obj = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.specialRef(obj, stringReg, cx, frame.scope); continue;case 79: stackTop = doRefMember(cx, stack, sDbl, stackTop, indexReg); continue;case 80: stackTop = doRefNsMember(cx, stack, sDbl, stackTop, indexReg); continue;case 81: name = stack[stackTop]; if (name == DBL_MRK) name = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.nameRef(name, cx, frame.scope, indexReg); continue;case 82: stackTop = doRefNsName(cx, frame, stack, sDbl, stackTop, indexReg); continue;case -12: indexReg += frame.localShift; frame.scope = (Scriptable)stack[indexReg]; continue;case -13: indexReg += frame.localShift; stack[indexReg] = frame.scope; continue;case -19: fn = InterpretedFunction.createFunction(cx, frame.scope, frame.fnOrScript, indexReg); if (fn.idata.itsFunctionType == 4) { stack[++stackTop] = new ArrowFunction(cx, frame.scope, fn, frame.thisObj); continue; }  stack[++stackTop] = fn; continue;case -20: initFunction(cx, frame.scope, frame.fnOrScript, indexReg); continue;case 48: re = frame.idata.itsRegExpLiterals[indexReg]; stack[++stackTop] = ScriptRuntime.wrapRegExp(cx, frame.scope, re); continue;case -74: templateLiterals = frame.idata.itsTemplateLiterals; stack[++stackTop] = ScriptRuntime.getTemplateLiteralCallSite(cx, frame.scope, templateLiterals, indexReg); continue;case -29: stackTop++; stack[stackTop] = new int[indexReg]; stackTop++; stack[stackTop] = new Object[indexReg]; sDbl[stackTop] = 0.0D; continue;case -30: object13 = stack[stackTop]; if (object13 == DBL_MRK) object13 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stackTop--; i = (int)sDbl[stackTop]; ((Object[])stack[stackTop])[i] = object13; sDbl[stackTop] = (i + 1); continue;case -57: object13 = stack[stackTop]; stackTop--; i = (int)sDbl[stackTop]; ((Object[])stack[stackTop])[i] = object13; ((int[])stack[stackTop - 1])[i] = -1; sDbl[stackTop] = (i + 1); continue;case -58: object13 = stack[stackTop]; stackTop--; i = (int)sDbl[stackTop]; ((Object[])stack[stackTop])[i] = object13; ((int[])stack[stackTop - 1])[i] = 1; sDbl[stackTop] = (i + 1); continue;case -31: case 66: case 67: data = (Object[])stack[stackTop]; stackTop--; getterSetters = (int[])stack[stackTop]; if (op == 67) { Object[] ids = (Object[])frame.idata.literalIds[indexReg]; object14 = ScriptRuntime.newObjectLiteral(ids, data, getterSetters, cx, frame.scope); } else { int[] skipIndexces = null; if (op == -31) skipIndexces = (int[])frame.idata.literalIds[indexReg];  object14 = ScriptRuntime.newArrayLiteral(data, skipIndexces, cx, frame.scope); }  stack[stackTop] = object14; continue;case -53: object12 = stack[stackTop]; if (object12 == DBL_MRK)
/*      */                 object12 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stackTop--; frame.scope = ScriptRuntime.enterDotQuery(object12, frame.scope); continue;case -54: bool2 = stack_boolean(frame, stackTop); x = ScriptRuntime.updateDotQuery(bool2, frame.scope); if (x != null) { stack[stackTop] = x; frame.scope = ScriptRuntime.leaveDotQuery(frame.scope); frame.pc += 2; continue; }  stackTop--;case 76: object11 = stack[stackTop]; if (object11 == DBL_MRK)
/*      */                 object11 = ScriptRuntime.wrapNumber(sDbl[stackTop]);  stack[stackTop] = ScriptRuntime.setDefaultNamespace(object11, cx); continue;case 77: object11 = stack[stackTop]; if (object11 != DBL_MRK)
/*      */                 stack[stackTop] = ScriptRuntime.escapeAttributeValue(object11, cx);  continue;case 78: object11 = stack[stackTop]; if (object11 != DBL_MRK)
/*      */                 stack[stackTop] = ScriptRuntime.escapeTextValue(object11, cx);  continue;case -64: if (frame.debuggerFrame != null)
/* 2435 */                 frame.debuggerFrame.onDebuggerStatement(cx);  continue;case -26: frame.pcSourceLineStart = frame.pc; if (frame.debuggerFrame != null) { int line = getIndex(iCode, frame.pc); frame.debuggerFrame.onLineChange(cx, line); }  frame.pc += 2; continue;case -32: indexReg = 0; continue;case -33: indexReg = 1; continue;case -34: indexReg = 2; continue;case -35: indexReg = 3; continue;case -36: indexReg = 4; continue;case -37: indexReg = 5; continue;case -38: indexReg = 0xFF & iCode[frame.pc]; frame.pc++; continue;case -39: indexReg = getIndex(iCode, frame.pc); frame.pc += 2; continue;case -40: indexReg = getInt(iCode, frame.pc); frame.pc += 4; continue;case -41: stringReg = strings[0]; continue;case -42: stringReg = strings[1]; continue;case -43: stringReg = strings[2]; continue;case -44: stringReg = strings[3]; continue;case -45: stringReg = strings[0xFF & iCode[frame.pc]]; frame.pc++; continue;case -46: stringReg = strings[getIndex(iCode, frame.pc)]; frame.pc += 2; continue;case -47: stringReg = strings[getInt(iCode, frame.pc)]; frame.pc += 4; continue;case -67: bigIntReg = bigInts[0]; continue;case -68: bigIntReg = bigInts[1]; continue;case -69: bigIntReg = bigInts[2]; continue;case -70: bigIntReg = bigInts[3]; continue;case -71: bigIntReg = bigInts[0xFF & iCode[frame.pc]]; frame.pc++; continue;case -72: bigIntReg = bigInts[getIndex(iCode, frame.pc)]; frame.pc += 2; continue;case -73: bigIntReg = bigInts[getInt(iCode, frame.pc)]; frame.pc += 4; continue;default: dumpICode(frame.idata); throw new RuntimeException("Unknown icode : " + op + " @ pc : " + (frame.pc - 1)); }  exitFrame(cx, frame, (Object)null);
/* 2436 */           interpreterResult = frame.result;
/* 2437 */           interpreterResultDbl = frame.resultDbl;
/* 2438 */           if (frame.parentFrame != null) {
/* 2439 */             frame = frame.parentFrame;
/* 2440 */             if (frame.frozen) {
/* 2441 */               frame = frame.cloneFrozen();
/*      */             }
/* 2443 */             setCallResult(frame, interpreterResult, interpreterResultDbl);
/* 2444 */             interpreterResult = null;
/*      */             
/*      */             continue;
/*      */           } 
/*      */           break;
/*      */         } 
/* 2450 */       } catch (Throwable ex) {
/* 2451 */         if (throwable != null) {
/*      */           
/* 2453 */           ex.printStackTrace(System.err);
/* 2454 */           throw new IllegalStateException();
/*      */         } 
/* 2456 */         throwable = ex;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2462 */       if (throwable == null) Kit.codeBug();
/*      */ 
/*      */       
/* 2465 */       int EX_CATCH_STATE = 2;
/* 2466 */       int EX_FINALLY_STATE = 1;
/* 2467 */       int EX_NO_JS_STATE = 0;
/*      */ 
/*      */       
/* 2470 */       ContinuationJump cjump = null;
/*      */       
/* 2472 */       if (generatorState != null && generatorState.operation == 2 && throwable == generatorState.value) {
/*      */ 
/*      */         
/* 2475 */         bool = true;
/* 2476 */       } else if (throwable instanceof JavaScriptException) {
/* 2477 */         bool = true;
/* 2478 */       } else if (throwable instanceof EcmaError) {
/*      */         
/* 2480 */         bool = true;
/* 2481 */       } else if (throwable instanceof EvaluatorException) {
/* 2482 */         bool = true;
/* 2483 */       } else if (throwable instanceof ContinuationPending) {
/* 2484 */         bool = false;
/* 2485 */       } else if (throwable instanceof RuntimeException) {
/*      */         
/* 2487 */         bool = cx.hasFeature(13) ? true : true;
/*      */       
/*      */       }
/* 2490 */       else if (throwable instanceof Error) {
/*      */         
/* 2492 */         bool = cx.hasFeature(13) ? true : false;
/*      */       
/*      */       }
/* 2495 */       else if (throwable instanceof ContinuationJump) {
/*      */         
/* 2497 */         bool = true;
/* 2498 */         cjump = (ContinuationJump)throwable;
/*      */       } else {
/*      */         
/* 2501 */         bool = cx.hasFeature(13) ? true : true;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2506 */       if (instructionCounting) {
/*      */         try {
/* 2508 */           addInstructionCount(cx, frame, 100);
/* 2509 */         } catch (RuntimeException ex) {
/* 2510 */           throwable = ex;
/* 2511 */           bool = true;
/* 2512 */         } catch (Error ex) {
/*      */ 
/*      */           
/* 2515 */           throwable = ex;
/* 2516 */           cjump = null;
/* 2517 */           bool = false;
/*      */         } 
/*      */       }
/* 2520 */       if (frame.debuggerFrame != null && throwable instanceof RuntimeException) {
/*      */         
/* 2522 */         RuntimeException rex = (RuntimeException)throwable;
/*      */         try {
/* 2524 */           frame.debuggerFrame.onExceptionThrown(cx, rex);
/* 2525 */         } catch (Throwable ex) {
/*      */ 
/*      */           
/* 2528 */           throwable = ex;
/* 2529 */           cjump = null;
/* 2530 */           bool = false;
/*      */         } 
/*      */       } 
/*      */       
/*      */       while (true) {
/* 2535 */         if (bool) {
/* 2536 */           boolean onlyFinally = (bool != 2);
/* 2537 */           indexReg = getExceptionHandler(frame, onlyFinally);
/* 2538 */           if (indexReg >= 0) {
/*      */             continue label638;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2548 */         exitFrame(cx, frame, throwable);
/*      */         
/* 2550 */         frame = frame.parentFrame;
/* 2551 */         if (frame == null) {
/*      */           break;
/*      */         }
/* 2554 */         if (cjump != null && cjump.branchFrame == frame)
/*      */         {
/*      */           
/* 2557 */           indexReg = -1;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2563 */       if (cjump != null) {
/* 2564 */         if (cjump.branchFrame != null)
/*      */         {
/* 2566 */           Kit.codeBug();
/*      */         }
/* 2568 */         if (cjump.capturedFrame != null) {
/*      */           
/* 2570 */           indexReg = -1;
/*      */           
/*      */           continue;
/*      */         } 
/* 2574 */         interpreterResult = cjump.result;
/* 2575 */         interpreterResultDbl = cjump.resultDbl;
/* 2576 */         throwable = null;
/*      */       } 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 2583 */     if (cx.previousInterpreterInvocations != null && cx.previousInterpreterInvocations
/* 2584 */       .size() != 0) {
/* 2585 */       cx.lastInterpreterFrame = cx.previousInterpreterInvocations.pop();
/*      */     } else {
/*      */       
/* 2588 */       cx.lastInterpreterFrame = null;
/*      */       
/* 2590 */       cx.previousInterpreterInvocations = null;
/*      */     } 
/*      */     
/* 2593 */     if (throwable != null) {
/* 2594 */       if (throwable instanceof RuntimeException) {
/* 2595 */         throw (RuntimeException)throwable;
/*      */       }
/*      */       
/* 2598 */       throw (Error)throwable;
/*      */     } 
/*      */     
/* 2601 */     return (interpreterResult != DBL_MRK) ? interpreterResult : 
/*      */       
/* 2603 */       ScriptRuntime.wrapNumber(interpreterResultDbl);
/*      */   }
/*      */   
/*      */   private static int doInOrInstanceof(Context cx, int op, Object[] stack, double[] sDbl, int stackTop) {
/*      */     boolean valBln;
/* 2608 */     Object rhs = stack[stackTop];
/* 2609 */     if (rhs == UniqueTag.DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2610 */     stackTop--;
/* 2611 */     Object lhs = stack[stackTop];
/* 2612 */     if (lhs == UniqueTag.DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[stackTop]);
/*      */     
/* 2614 */     if (op == 52) {
/* 2615 */       valBln = ScriptRuntime.in(lhs, rhs, cx);
/*      */     } else {
/* 2617 */       valBln = ScriptRuntime.instanceOf(lhs, rhs, cx);
/*      */     } 
/* 2619 */     stack[stackTop] = ScriptRuntime.wrapBoolean(valBln);
/* 2620 */     return stackTop;
/*      */   }
/*      */   
/*      */   private static int doCompare(CallFrame frame, int op, Object[] stack, double[] sDbl, int stackTop) {
/*      */     Number rNum, lNum;
/* 2625 */     stackTop--;
/* 2626 */     Object rhs = stack[stackTop + 1];
/* 2627 */     Object lhs = stack[stackTop];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2634 */     if (rhs == UniqueTag.DOUBLE_MARK)
/* 2635 */     { rNum = Double.valueOf(sDbl[stackTop + 1]);
/* 2636 */       lNum = stack_numeric(frame, stackTop); }
/* 2637 */     else if (lhs == UniqueTag.DOUBLE_MARK)
/* 2638 */     { rNum = ScriptRuntime.toNumeric(rhs);
/* 2639 */       lNum = Double.valueOf(sDbl[stackTop]);
/*      */       
/*      */        }
/*      */     
/*      */     else
/*      */     
/*      */     { 
/* 2646 */       boolean bool = ScriptRuntime.compare(lhs, rhs, op);
/*      */       
/* 2648 */       stack[stackTop] = ScriptRuntime.wrapBoolean(bool);
/* 2649 */       return stackTop; }  boolean valBln = ScriptRuntime.compare(lNum, rNum, op); stack[stackTop] = ScriptRuntime.wrapBoolean(valBln); return stackTop;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int doBitOp(CallFrame frame, int op, Object[] stack, double[] sDbl, int stackTop) {
/* 2654 */     Number lValue = stack_numeric(frame, stackTop - 1);
/* 2655 */     Number rValue = stack_numeric(frame, stackTop);
/* 2656 */     stackTop--;
/*      */     
/* 2658 */     Number result = null;
/* 2659 */     switch (op) {
/*      */       case 11:
/* 2661 */         result = ScriptRuntime.bitwiseAND(lValue, rValue);
/*      */         break;
/*      */       case 9:
/* 2664 */         result = ScriptRuntime.bitwiseOR(lValue, rValue);
/*      */         break;
/*      */       case 10:
/* 2667 */         result = ScriptRuntime.bitwiseXOR(lValue, rValue);
/*      */         break;
/*      */       case 18:
/* 2670 */         result = ScriptRuntime.leftShift(lValue, rValue);
/*      */         break;
/*      */       case 19:
/* 2673 */         result = ScriptRuntime.signedRightShift(lValue, rValue);
/*      */         break;
/*      */     } 
/*      */     
/* 2677 */     if (result instanceof BigInteger) {
/* 2678 */       stack[stackTop] = result;
/*      */     } else {
/* 2680 */       stack[stackTop] = UniqueTag.DOUBLE_MARK;
/* 2681 */       sDbl[stackTop] = result.doubleValue();
/*      */     } 
/* 2683 */     return stackTop;
/*      */   }
/*      */   
/*      */   private static int doBitNOT(CallFrame frame, Object[] stack, double[] sDbl, int stackTop) {
/* 2687 */     Number value = stack_numeric(frame, stackTop);
/* 2688 */     Number result = ScriptRuntime.bitwiseNOT(value);
/* 2689 */     if (result instanceof BigInteger) {
/* 2690 */       stack[stackTop] = result;
/*      */     } else {
/* 2692 */       stack[stackTop] = UniqueTag.DOUBLE_MARK;
/* 2693 */       sDbl[stackTop] = result.doubleValue();
/*      */     } 
/* 2695 */     return stackTop;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int doDelName(Context cx, CallFrame frame, int op, Object[] stack, double[] sDbl, int stackTop) {
/* 2700 */     Object rhs = stack[stackTop];
/* 2701 */     if (rhs == UniqueTag.DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2702 */     stackTop--;
/* 2703 */     Object lhs = stack[stackTop];
/* 2704 */     if (lhs == UniqueTag.DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2705 */     stack[stackTop] = ScriptRuntime.delete(lhs, rhs, cx, frame.scope, (op == 0));
/* 2706 */     return stackTop;
/*      */   }
/*      */   
/*      */   private static int doGetElem(Context cx, CallFrame frame, Object[] stack, double[] sDbl, int stackTop) {
/*      */     Object value;
/* 2711 */     stackTop--;
/* 2712 */     Object lhs = stack[stackTop];
/* 2713 */     if (lhs == UniqueTag.DOUBLE_MARK) {
/* 2714 */       lhs = ScriptRuntime.wrapNumber(sDbl[stackTop]);
/*      */     }
/*      */     
/* 2717 */     Object id = stack[stackTop + 1];
/* 2718 */     if (id != UniqueTag.DOUBLE_MARK) {
/* 2719 */       value = ScriptRuntime.getObjectElem(lhs, id, cx, frame.scope);
/*      */     } else {
/* 2721 */       double d = sDbl[stackTop + 1];
/* 2722 */       value = ScriptRuntime.getObjectIndex(lhs, d, cx, frame.scope);
/*      */     } 
/* 2724 */     stack[stackTop] = value;
/* 2725 */     return stackTop;
/*      */   }
/*      */   
/*      */   private static int doSetElem(Context cx, CallFrame frame, Object[] stack, double[] sDbl, int stackTop) {
/*      */     Object value;
/* 2730 */     stackTop -= 2;
/* 2731 */     Object rhs = stack[stackTop + 2];
/* 2732 */     if (rhs == UniqueTag.DOUBLE_MARK) {
/* 2733 */       rhs = ScriptRuntime.wrapNumber(sDbl[stackTop + 2]);
/*      */     }
/* 2735 */     Object lhs = stack[stackTop];
/* 2736 */     if (lhs == UniqueTag.DOUBLE_MARK) {
/* 2737 */       lhs = ScriptRuntime.wrapNumber(sDbl[stackTop]);
/*      */     }
/*      */     
/* 2740 */     Object id = stack[stackTop + 1];
/* 2741 */     if (id != UniqueTag.DOUBLE_MARK) {
/* 2742 */       value = ScriptRuntime.setObjectElem(lhs, id, rhs, cx, frame.scope);
/*      */     } else {
/* 2744 */       double d = sDbl[stackTop + 1];
/* 2745 */       value = ScriptRuntime.setObjectIndex(lhs, d, rhs, cx, frame.scope);
/*      */     } 
/* 2747 */     stack[stackTop] = value;
/* 2748 */     return stackTop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int doElemIncDec(Context cx, CallFrame frame, byte[] iCode, Object[] stack, double[] sDbl, int stackTop) {
/* 2758 */     Object rhs = stack[stackTop];
/* 2759 */     if (rhs == UniqueTag.DOUBLE_MARK) rhs = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2760 */     stackTop--;
/* 2761 */     Object lhs = stack[stackTop];
/* 2762 */     if (lhs == UniqueTag.DOUBLE_MARK) lhs = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2763 */     stack[stackTop] = ScriptRuntime.elemIncrDecr(lhs, rhs, cx, frame.scope, iCode[frame.pc]);
/* 2764 */     frame.pc++;
/* 2765 */     return stackTop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int doCallSpecial(Context cx, CallFrame frame, Object[] stack, double[] sDbl, int stackTop, byte[] iCode, int indexReg) {
/* 2776 */     int callType = iCode[frame.pc] & 0xFF;
/* 2777 */     boolean isNew = (iCode[frame.pc + 1] != 0);
/* 2778 */     int sourceLine = getIndex(iCode, frame.pc + 2);
/*      */ 
/*      */     
/* 2781 */     if (isNew) {
/*      */       
/* 2783 */       stackTop -= indexReg;
/*      */       
/* 2785 */       Object function = stack[stackTop];
/* 2786 */       if (function == UniqueTag.DOUBLE_MARK) function = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2787 */       Object[] outArgs = getArgsArray(stack, sDbl, stackTop + 1, indexReg);
/* 2788 */       stack[stackTop] = 
/* 2789 */         ScriptRuntime.newSpecial(cx, function, outArgs, frame.scope, callType);
/*      */     } else {
/*      */       
/* 2792 */       stackTop -= 1 + indexReg;
/*      */ 
/*      */ 
/*      */       
/* 2796 */       Scriptable functionThis = (Scriptable)stack[stackTop + 1];
/* 2797 */       Callable function = (Callable)stack[stackTop];
/* 2798 */       Object[] outArgs = getArgsArray(stack, sDbl, stackTop + 2, indexReg);
/* 2799 */       stack[stackTop] = 
/* 2800 */         ScriptRuntime.callSpecial(cx, function, functionThis, outArgs, frame.scope, frame.thisObj, callType, frame.idata.itsSourceFile, sourceLine);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2811 */     frame.pc += 4;
/* 2812 */     return stackTop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int doSetConstVar(CallFrame frame, Object[] stack, double[] sDbl, int stackTop, Object[] vars, double[] varDbls, int[] varAttributes, int indexReg) {
/* 2824 */     if (!frame.useActivation) {
/* 2825 */       if ((varAttributes[indexReg] & 0x1) == 0) {
/* 2826 */         throw Context.reportRuntimeErrorById("msg.var.redecl", new Object[] { frame.idata.argNames[indexReg] });
/*      */       }
/*      */       
/* 2829 */       if ((varAttributes[indexReg] & 0x8) != 0) {
/* 2830 */         vars[indexReg] = stack[stackTop];
/* 2831 */         varAttributes[indexReg] = varAttributes[indexReg] & 0xFFFFFFF7;
/* 2832 */         varDbls[indexReg] = sDbl[stackTop];
/*      */       } 
/*      */     } else {
/* 2835 */       Object val = stack[stackTop];
/* 2836 */       if (val == UniqueTag.DOUBLE_MARK) val = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2837 */       String stringReg = frame.idata.argNames[indexReg];
/* 2838 */       if (frame.scope instanceof ConstProperties)
/* 2839 */       { ConstProperties cp = (ConstProperties)frame.scope;
/* 2840 */         cp.putConst(stringReg, frame.scope, val); }
/* 2841 */       else { throw Kit.codeBug(); }
/*      */     
/* 2843 */     }  return stackTop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int doSetVar(CallFrame frame, Object[] stack, double[] sDbl, int stackTop, Object[] vars, double[] varDbls, int[] varAttributes, int indexReg) {
/* 2855 */     if (!frame.useActivation) {
/* 2856 */       if ((varAttributes[indexReg] & 0x1) == 0) {
/* 2857 */         vars[indexReg] = stack[stackTop];
/* 2858 */         varDbls[indexReg] = sDbl[stackTop];
/*      */       } 
/*      */     } else {
/* 2861 */       Object val = stack[stackTop];
/* 2862 */       if (val == UniqueTag.DOUBLE_MARK) val = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2863 */       String stringReg = frame.idata.argNames[indexReg];
/* 2864 */       frame.scope.put(stringReg, frame.scope, val);
/*      */     } 
/* 2866 */     return stackTop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int doGetVar(CallFrame frame, Object[] stack, double[] sDbl, int stackTop, Object[] vars, double[] varDbls, int indexReg) {
/* 2877 */     stackTop++;
/* 2878 */     if (!frame.useActivation) {
/* 2879 */       stack[stackTop] = vars[indexReg];
/* 2880 */       sDbl[stackTop] = varDbls[indexReg];
/*      */     } else {
/* 2882 */       String stringReg = frame.idata.argNames[indexReg];
/* 2883 */       stack[stackTop] = frame.scope.get(stringReg, frame.scope);
/*      */     } 
/* 2885 */     return stackTop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int doVarIncDec(Context cx, CallFrame frame, Object[] stack, double[] sDbl, int stackTop, Object[] vars, double[] varDbls, int[] varAttributes, int indexReg) {
/* 2899 */     stackTop++;
/* 2900 */     int incrDecrMask = frame.idata.itsICode[frame.pc];
/* 2901 */     if (!frame.useActivation) {
/* 2902 */       Object varValue = vars[indexReg];
/* 2903 */       double d = 0.0D;
/* 2904 */       BigInteger bi = null;
/* 2905 */       if (varValue == UniqueTag.DOUBLE_MARK) {
/* 2906 */         d = varDbls[indexReg];
/*      */       } else {
/* 2908 */         Number num = ScriptRuntime.toNumeric(varValue);
/* 2909 */         if (num instanceof BigInteger) {
/* 2910 */           bi = (BigInteger)num;
/*      */         } else {
/* 2912 */           d = num.doubleValue();
/*      */         } 
/*      */       } 
/* 2915 */       if (bi == null) {
/*      */         
/* 2917 */         double d2 = ((incrDecrMask & 0x1) == 0) ? (d + 1.0D) : (d - 1.0D);
/* 2918 */         boolean post = ((incrDecrMask & 0x2) != 0);
/* 2919 */         if ((varAttributes[indexReg] & 0x1) == 0) {
/* 2920 */           if (varValue != UniqueTag.DOUBLE_MARK) {
/* 2921 */             vars[indexReg] = UniqueTag.DOUBLE_MARK;
/*      */           }
/* 2923 */           varDbls[indexReg] = d2;
/* 2924 */           stack[stackTop] = UniqueTag.DOUBLE_MARK;
/* 2925 */           sDbl[stackTop] = post ? d : d2;
/*      */         }
/* 2927 */         else if (post && varValue != UniqueTag.DOUBLE_MARK) {
/* 2928 */           stack[stackTop] = varValue;
/*      */         } else {
/* 2930 */           stack[stackTop] = UniqueTag.DOUBLE_MARK;
/* 2931 */           sDbl[stackTop] = post ? d : d2;
/*      */         } 
/*      */       } else {
/*      */         BigInteger result;
/*      */ 
/*      */         
/* 2937 */         if ((incrDecrMask & 0x1) == 0) {
/* 2938 */           result = bi.add(BigInteger.ONE);
/*      */         } else {
/* 2940 */           result = bi.subtract(BigInteger.ONE);
/*      */         } 
/*      */         
/* 2943 */         boolean post = ((incrDecrMask & 0x2) != 0);
/* 2944 */         if ((varAttributes[indexReg] & 0x1) == 0) {
/* 2945 */           vars[indexReg] = result;
/* 2946 */           stack[stackTop] = post ? bi : result;
/*      */         }
/* 2948 */         else if (post && varValue != UniqueTag.DOUBLE_MARK) {
/* 2949 */           stack[stackTop] = varValue;
/*      */         } else {
/* 2951 */           stack[stackTop] = post ? bi : result;
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 2956 */       String varName = frame.idata.argNames[indexReg];
/* 2957 */       stack[stackTop] = ScriptRuntime.nameIncrDecr(frame.scope, varName, cx, incrDecrMask);
/*      */     } 
/* 2959 */     frame.pc++;
/* 2960 */     return stackTop;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int doRefMember(Context cx, Object[] stack, double[] sDbl, int stackTop, int flags) {
/* 2965 */     Object elem = stack[stackTop];
/* 2966 */     if (elem == UniqueTag.DOUBLE_MARK) elem = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2967 */     stackTop--;
/* 2968 */     Object obj = stack[stackTop];
/* 2969 */     if (obj == UniqueTag.DOUBLE_MARK) obj = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2970 */     stack[stackTop] = ScriptRuntime.memberRef(obj, elem, cx, flags);
/* 2971 */     return stackTop;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int doRefNsMember(Context cx, Object[] stack, double[] sDbl, int stackTop, int flags) {
/* 2976 */     Object elem = stack[stackTop];
/* 2977 */     if (elem == UniqueTag.DOUBLE_MARK) elem = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2978 */     stackTop--;
/* 2979 */     Object ns = stack[stackTop];
/* 2980 */     if (ns == UniqueTag.DOUBLE_MARK) ns = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2981 */     stackTop--;
/* 2982 */     Object obj = stack[stackTop];
/* 2983 */     if (obj == UniqueTag.DOUBLE_MARK) obj = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2984 */     stack[stackTop] = ScriptRuntime.memberRef(obj, ns, elem, cx, flags);
/* 2985 */     return stackTop;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int doRefNsName(Context cx, CallFrame frame, Object[] stack, double[] sDbl, int stackTop, int flags) {
/* 2990 */     Object name = stack[stackTop];
/* 2991 */     if (name == UniqueTag.DOUBLE_MARK) name = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2992 */     stackTop--;
/* 2993 */     Object ns = stack[stackTop];
/* 2994 */     if (ns == UniqueTag.DOUBLE_MARK) ns = ScriptRuntime.wrapNumber(sDbl[stackTop]); 
/* 2995 */     stack[stackTop] = ScriptRuntime.nameRef(ns, name, cx, frame.scope, flags);
/* 2996 */     return stackTop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static CallFrame initFrameForNoSuchMethod(Context cx, CallFrame frame, int indexReg, Object[] stack, double[] sDbl, int stackTop, int op, Scriptable funThisObj, Scriptable calleeScope, ScriptRuntime.NoSuchMethodShim noSuchMethodShim, InterpretedFunction ifun) {
/* 3013 */     Object[] argsArray = null;
/*      */ 
/*      */     
/* 3016 */     int shift = stackTop + 2;
/* 3017 */     Object[] elements = new Object[indexReg];
/* 3018 */     for (int i = 0; i < indexReg; i++, shift++) {
/* 3019 */       Object val = stack[shift];
/* 3020 */       if (val == UniqueTag.DOUBLE_MARK) {
/* 3021 */         val = ScriptRuntime.wrapNumber(sDbl[shift]);
/*      */       }
/* 3023 */       elements[i] = val;
/*      */     } 
/* 3025 */     argsArray = new Object[2];
/* 3026 */     argsArray[0] = noSuchMethodShim.methodName;
/* 3027 */     argsArray[1] = cx.newArray(calleeScope, elements);
/*      */ 
/*      */     
/* 3030 */     CallFrame callParentFrame = frame;
/* 3031 */     if (op == -55) {
/* 3032 */       callParentFrame = frame.parentFrame;
/* 3033 */       exitFrame(cx, frame, (Object)null);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3038 */     CallFrame calleeFrame = initFrame(cx, calleeScope, funThisObj, argsArray, (double[])null, 0, 2, ifun, callParentFrame);
/*      */     
/* 3040 */     if (op != -55) {
/* 3041 */       frame.savedStackTop = stackTop;
/* 3042 */       frame.savedCallOp = op;
/*      */     } 
/* 3044 */     return calleeFrame;
/*      */   }
/*      */   
/*      */   private static boolean doEquals(Object[] stack, double[] sDbl, int stackTop) {
/* 3048 */     Object rhs = stack[stackTop + 1];
/* 3049 */     Object lhs = stack[stackTop];
/* 3050 */     if (rhs == UniqueTag.DOUBLE_MARK) {
/* 3051 */       if (lhs == UniqueTag.DOUBLE_MARK) {
/* 3052 */         return (sDbl[stackTop] == sDbl[stackTop + 1]);
/*      */       }
/* 3054 */       return ScriptRuntime.eqNumber(sDbl[stackTop + 1], lhs);
/*      */     } 
/* 3056 */     if (lhs == UniqueTag.DOUBLE_MARK) {
/* 3057 */       return ScriptRuntime.eqNumber(sDbl[stackTop], rhs);
/*      */     }
/* 3059 */     return ScriptRuntime.eq(lhs, rhs);
/*      */   }
/*      */   private static boolean doShallowEquals(Object[] stack, double[] sDbl, int stackTop) {
/*      */     double rdbl, ldbl;
/* 3063 */     Object rhs = stack[stackTop + 1];
/* 3064 */     Object lhs = stack[stackTop];
/* 3065 */     Object DBL_MRK = UniqueTag.DOUBLE_MARK;
/*      */     
/* 3067 */     if (rhs == DBL_MRK) {
/* 3068 */       rdbl = sDbl[stackTop + 1];
/* 3069 */       if (lhs == DBL_MRK) {
/* 3070 */         ldbl = sDbl[stackTop];
/* 3071 */       } else if (lhs instanceof Number && !(lhs instanceof BigInteger)) {
/* 3072 */         ldbl = ((Number)lhs).doubleValue();
/*      */       } else {
/* 3074 */         return false;
/*      */       } 
/* 3076 */     } else if (lhs == DBL_MRK) {
/* 3077 */       ldbl = sDbl[stackTop];
/* 3078 */       if (rhs instanceof Number && !(rhs instanceof BigInteger)) {
/* 3079 */         rdbl = ((Number)rhs).doubleValue();
/*      */       } else {
/* 3081 */         return false;
/*      */       } 
/*      */     } else {
/* 3084 */       return ScriptRuntime.shallowEq(lhs, rhs);
/*      */     } 
/* 3086 */     return (ldbl == rdbl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static CallFrame processThrowable(Context cx, Object throwable, CallFrame frame, int indexReg, boolean instructionCounting) {
/* 3098 */     if (indexReg >= 0) {
/*      */ 
/*      */ 
/*      */       
/* 3102 */       if (frame.frozen)
/*      */       {
/* 3104 */         frame = frame.cloneFrozen();
/*      */       }
/*      */       
/* 3107 */       int[] table = frame.idata.itsExceptionTable;
/*      */       
/* 3109 */       frame.pc = table[indexReg + 2];
/* 3110 */       if (instructionCounting) {
/* 3111 */         frame.pcPrevBranch = frame.pc;
/*      */       }
/*      */       
/* 3114 */       frame.savedStackTop = frame.emptyStackTop;
/* 3115 */       int scopeLocal = frame.localShift + table[indexReg + 5];
/* 3116 */       int exLocal = frame.localShift + table[indexReg + 4];
/* 3117 */       frame.scope = (Scriptable)frame.stack[scopeLocal];
/* 3118 */       frame.stack[exLocal] = throwable;
/*      */       
/* 3120 */       throwable = null;
/*      */     } else {
/*      */       
/* 3123 */       ContinuationJump cjump = (ContinuationJump)throwable;
/*      */ 
/*      */       
/* 3126 */       throwable = null;
/*      */       
/* 3128 */       if (cjump.branchFrame != frame) Kit.codeBug();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3133 */       if (cjump.capturedFrame == null) Kit.codeBug();
/*      */ 
/*      */ 
/*      */       
/* 3137 */       int rewindCount = cjump.capturedFrame.frameIndex + 1;
/* 3138 */       if (cjump.branchFrame != null) {
/* 3139 */         rewindCount -= cjump.branchFrame.frameIndex;
/*      */       }
/*      */       
/* 3142 */       int enterCount = 0;
/* 3143 */       CallFrame[] enterFrames = null;
/*      */       
/* 3145 */       CallFrame x = cjump.capturedFrame;
/* 3146 */       for (int i = 0; i != rewindCount; i++) {
/* 3147 */         if (!x.frozen) Kit.codeBug(); 
/* 3148 */         if (x.useActivation) {
/* 3149 */           if (enterFrames == null)
/*      */           {
/*      */ 
/*      */             
/* 3153 */             enterFrames = new CallFrame[rewindCount - i];
/*      */           }
/* 3155 */           enterFrames[enterCount] = x;
/* 3156 */           enterCount++;
/*      */         } 
/* 3158 */         x = x.parentFrame;
/*      */       } 
/*      */       
/* 3161 */       while (enterCount != 0) {
/*      */ 
/*      */ 
/*      */         
/* 3165 */         enterCount--;
/* 3166 */         x = enterFrames[enterCount];
/* 3167 */         enterFrame(cx, x, ScriptRuntime.emptyArgs, true);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3174 */       frame = cjump.capturedFrame.cloneFrozen();
/* 3175 */       setCallResult(frame, cjump.result, cjump.resultDbl);
/*      */     } 
/*      */     
/* 3178 */     frame.throwable = throwable;
/* 3179 */     return frame;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object freezeGenerator(Context cx, CallFrame frame, int stackTop, GeneratorState generatorState, boolean yieldStar) {
/* 3188 */     if (generatorState.operation == 2)
/*      */     {
/* 3190 */       throw ScriptRuntime.typeErrorById("msg.yield.closing", new Object[0]);
/*      */     }
/*      */     
/* 3193 */     frame.frozen = true;
/* 3194 */     frame.result = frame.stack[stackTop];
/* 3195 */     frame.resultDbl = frame.sDbl[stackTop];
/* 3196 */     frame.savedStackTop = stackTop;
/* 3197 */     frame.pc--;
/* 3198 */     ScriptRuntime.exitActivationFunction(cx);
/*      */ 
/*      */ 
/*      */     
/* 3202 */     Object result = (frame.result != UniqueTag.DOUBLE_MARK) ? frame.result : ScriptRuntime.wrapNumber(frame.resultDbl);
/* 3203 */     if (yieldStar) {
/* 3204 */       return new ES6Generator.YieldStarResult(result);
/*      */     }
/* 3206 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object thawGenerator(CallFrame frame, int stackTop, GeneratorState generatorState, int op) {
/* 3212 */     frame.frozen = false;
/* 3213 */     int sourceLine = getIndex(frame.idata.itsICode, frame.pc);
/* 3214 */     frame.pc += 2;
/* 3215 */     if (generatorState.operation == 1)
/*      */     {
/*      */       
/* 3218 */       return new JavaScriptException(generatorState.value, frame.idata.itsSourceFile, sourceLine);
/*      */     }
/*      */     
/* 3221 */     if (generatorState.operation == 2) {
/* 3222 */       return generatorState.value;
/*      */     }
/* 3224 */     if (generatorState.operation != 0) throw Kit.codeBug(); 
/* 3225 */     if (op == 73 || op == -66) {
/* 3226 */       frame.stack[stackTop] = generatorState.value;
/*      */     }
/* 3228 */     return Scriptable.NOT_FOUND;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static CallFrame initFrameForApplyOrCall(Context cx, CallFrame frame, int indexReg, Object[] stack, double[] sDbl, int stackTop, int op, Scriptable calleeScope, IdFunctionObject ifun, InterpretedFunction iApplyCallable) {
/*      */     Scriptable applyThis;
/*      */     CallFrame calleeFrame;
/* 3243 */     if (indexReg != 0) {
/* 3244 */       Object obj = stack[stackTop + 2];
/* 3245 */       if (obj == UniqueTag.DOUBLE_MARK) obj = ScriptRuntime.wrapNumber(sDbl[stackTop + 2]); 
/* 3246 */       applyThis = ScriptRuntime.toObjectOrNull(cx, obj, frame.scope);
/*      */     } else {
/* 3248 */       applyThis = null;
/*      */     } 
/* 3250 */     if (applyThis == null)
/*      */     {
/* 3252 */       applyThis = ScriptRuntime.getTopCallScope(cx);
/*      */     }
/* 3254 */     if (op == -55) {
/* 3255 */       exitFrame(cx, frame, (Object)null);
/* 3256 */       frame = frame.parentFrame;
/*      */     } else {
/* 3258 */       frame.savedStackTop = stackTop;
/* 3259 */       frame.savedCallOp = op;
/*      */     } 
/*      */     
/* 3262 */     if (BaseFunction.isApply(ifun)) {
/*      */ 
/*      */ 
/*      */       
/* 3266 */       Object[] callArgs = (indexReg < 2) ? ScriptRuntime.emptyArgs : ScriptRuntime.getApplyArguments(cx, stack[stackTop + 3]);
/*      */       
/* 3268 */       calleeFrame = initFrame(cx, calleeScope, applyThis, callArgs, (double[])null, 0, callArgs.length, iApplyCallable, frame);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3280 */       for (int i = 1; i < indexReg; i++) {
/* 3281 */         stack[stackTop + 1 + i] = stack[stackTop + 2 + i];
/* 3282 */         sDbl[stackTop + 1 + i] = sDbl[stackTop + 2 + i];
/*      */       } 
/* 3284 */       int argCount = (indexReg < 2) ? 0 : (indexReg - 1);
/*      */       
/* 3286 */       calleeFrame = initFrame(cx, calleeScope, applyThis, stack, sDbl, stackTop + 2, argCount, iApplyCallable, frame);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3298 */     return calleeFrame;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static CallFrame initFrame(Context cx, Scriptable callerScope, Scriptable thisObj, Object[] args, double[] argsDbl, int argShift, int argCount, InterpretedFunction fnOrScript, CallFrame parentFrame) {
/* 3311 */     CallFrame frame = new CallFrame(cx, thisObj, fnOrScript, parentFrame);
/* 3312 */     frame.initializeArgs(cx, callerScope, args, argsDbl, argShift, argCount);
/* 3313 */     enterFrame(cx, frame, args, false);
/* 3314 */     return frame;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void enterFrame(Context cx, CallFrame frame, Object[] args, boolean continuationRestart) {
/* 3319 */     boolean usesActivation = frame.idata.itsNeedsActivation;
/* 3320 */     boolean isDebugged = (frame.debuggerFrame != null);
/* 3321 */     if (usesActivation || isDebugged) {
/* 3322 */       Scriptable scope = frame.scope;
/* 3323 */       if (scope == null) {
/* 3324 */         Kit.codeBug();
/* 3325 */       } else if (continuationRestart) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3335 */         while (scope instanceof NativeWith) {
/* 3336 */           scope = scope.getParentScope();
/* 3337 */           if (scope == null || (frame.parentFrame != null && frame.parentFrame.scope == scope)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3343 */             Kit.codeBug();
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 3352 */       if (isDebugged) {
/* 3353 */         frame.debuggerFrame.onEnter(cx, scope, frame.thisObj, args);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3358 */       if (usesActivation) {
/* 3359 */         ScriptRuntime.enterActivationFunction(cx, scope);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void exitFrame(Context cx, CallFrame frame, Object throwable) {
/* 3365 */     if (frame.idata.itsNeedsActivation) {
/* 3366 */       ScriptRuntime.exitActivationFunction(cx);
/*      */     }
/*      */     
/* 3369 */     if (frame.debuggerFrame != null) {
/*      */       try {
/* 3371 */         if (throwable instanceof Throwable) {
/* 3372 */           frame.debuggerFrame.onExit(cx, true, throwable);
/*      */         } else {
/*      */           Object result;
/* 3375 */           ContinuationJump cjump = (ContinuationJump)throwable;
/* 3376 */           if (cjump == null) {
/* 3377 */             result = frame.result;
/*      */           } else {
/* 3379 */             result = cjump.result;
/*      */           } 
/* 3381 */           if (result == UniqueTag.DOUBLE_MARK) {
/*      */             double resultDbl;
/* 3383 */             if (cjump == null) {
/* 3384 */               resultDbl = frame.resultDbl;
/*      */             } else {
/* 3386 */               resultDbl = cjump.resultDbl;
/*      */             } 
/* 3388 */             result = ScriptRuntime.wrapNumber(resultDbl);
/*      */           } 
/* 3390 */           frame.debuggerFrame.onExit(cx, false, result);
/*      */         } 
/* 3392 */       } catch (Throwable ex) {
/* 3393 */         System.err.println("RHINO USAGE WARNING: onExit terminated with exception");
/* 3394 */         ex.printStackTrace(System.err);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static void setCallResult(CallFrame frame, Object callResult, double callResultDbl) {
/* 3400 */     if (frame.savedCallOp == 38) {
/* 3401 */       frame.stack[frame.savedStackTop] = callResult;
/* 3402 */       frame.sDbl[frame.savedStackTop] = callResultDbl;
/* 3403 */     } else if (frame.savedCallOp == 30) {
/*      */ 
/*      */ 
/*      */       
/* 3407 */       if (callResult instanceof Scriptable) {
/* 3408 */         frame.stack[frame.savedStackTop] = callResult;
/*      */       }
/*      */     } else {
/* 3411 */       Kit.codeBug();
/*      */     } 
/* 3413 */     frame.savedCallOp = 0;
/*      */   }
/*      */   
/*      */   public static NativeContinuation captureContinuation(Context cx) {
/* 3417 */     if (cx.lastInterpreterFrame == null || !(cx.lastInterpreterFrame instanceof CallFrame)) {
/* 3418 */       throw new IllegalStateException("Interpreter frames not found");
/*      */     }
/* 3420 */     return captureContinuation(cx, (CallFrame)cx.lastInterpreterFrame, true);
/*      */   }
/*      */ 
/*      */   
/*      */   private static NativeContinuation captureContinuation(Context cx, CallFrame frame, boolean requireContinuationsTopFrame) {
/* 3425 */     NativeContinuation c = new NativeContinuation();
/* 3426 */     ScriptRuntime.setObjectProtoAndParent(c, ScriptRuntime.getTopCallScope(cx));
/*      */ 
/*      */     
/* 3429 */     CallFrame x = frame;
/* 3430 */     CallFrame outermost = frame;
/* 3431 */     while (x != null && !x.frozen) {
/* 3432 */       x.frozen = true;
/*      */       
/* 3434 */       for (int i = x.savedStackTop + 1; i != x.stack.length; i++) {
/*      */         
/* 3436 */         x.stack[i] = null;
/* 3437 */         x.stackAttributes[i] = 0;
/*      */       } 
/* 3439 */       if (x.savedCallOp == 38)
/*      */       
/* 3441 */       { x.stack[x.savedStackTop] = null; }
/*      */       
/* 3443 */       else if (x.savedCallOp != 30) { Kit.codeBug(); }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3448 */       outermost = x;
/* 3449 */       x = x.parentFrame;
/*      */     } 
/*      */     
/* 3452 */     if (requireContinuationsTopFrame) {
/* 3453 */       for (; outermost.parentFrame != null; outermost = outermost.parentFrame);
/*      */       
/* 3455 */       if (!outermost.isContinuationsTopFrame) {
/* 3456 */         throw new IllegalStateException("Cannot capture continuation from JavaScript code not called directly by executeScriptWithContinuations or callFunctionWithContinuations");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3464 */     c.initImplementation(frame);
/* 3465 */     return c;
/*      */   }
/*      */   
/*      */   private static int stack_int32(CallFrame frame, int i) {
/* 3469 */     Object x = frame.stack[i];
/* 3470 */     if (x == UniqueTag.DOUBLE_MARK) {
/* 3471 */       return ScriptRuntime.toInt32(frame.sDbl[i]);
/*      */     }
/* 3473 */     return ScriptRuntime.toInt32(x);
/*      */   }
/*      */   
/*      */   private static double stack_double(CallFrame frame, int i) {
/* 3477 */     Object x = frame.stack[i];
/* 3478 */     if (x != UniqueTag.DOUBLE_MARK) {
/* 3479 */       return ScriptRuntime.toNumber(x);
/*      */     }
/* 3481 */     return frame.sDbl[i];
/*      */   }
/*      */   
/*      */   private static Number stack_numeric(CallFrame frame, int i) {
/* 3485 */     Object x = frame.stack[i];
/* 3486 */     if (x != UniqueTag.DOUBLE_MARK) {
/* 3487 */       return ScriptRuntime.toNumeric(x);
/*      */     }
/* 3489 */     return Double.valueOf(frame.sDbl[i]);
/*      */   }
/*      */   
/*      */   private static boolean stack_boolean(CallFrame frame, int i) {
/* 3493 */     Object x = frame.stack[i];
/* 3494 */     if (Boolean.TRUE.equals(x))
/* 3495 */       return true; 
/* 3496 */     if (Boolean.FALSE.equals(x))
/* 3497 */       return false; 
/* 3498 */     if (x == UniqueTag.DOUBLE_MARK) {
/* 3499 */       double d = frame.sDbl[i];
/* 3500 */       return (!Double.isNaN(d) && d != 0.0D);
/* 3501 */     }  if (x == null || x == Undefined.instance)
/* 3502 */       return false; 
/* 3503 */     if (x instanceof BigInteger)
/* 3504 */       return !((BigInteger)x).equals(BigInteger.ZERO); 
/* 3505 */     if (x instanceof Number) {
/* 3506 */       double d = ((Number)x).doubleValue();
/* 3507 */       return (!Double.isNaN(d) && d != 0.0D);
/*      */     } 
/* 3509 */     return ScriptRuntime.toBoolean(x);
/*      */   }
/*      */   private static void doAdd(Object[] stack, double[] sDbl, int stackTop, Context cx) {
/*      */     double d;
/*      */     boolean leftRightOrder;
/* 3514 */     Object rhs = stack[stackTop + 1];
/* 3515 */     Object lhs = stack[stackTop];
/*      */ 
/*      */     
/* 3518 */     if (rhs == UniqueTag.DOUBLE_MARK) {
/* 3519 */       d = sDbl[stackTop + 1];
/* 3520 */       if (lhs == UniqueTag.DOUBLE_MARK) {
/* 3521 */         sDbl[stackTop] = sDbl[stackTop] + d;
/*      */         return;
/*      */       } 
/* 3524 */       leftRightOrder = true;
/*      */     }
/* 3526 */     else if (lhs == UniqueTag.DOUBLE_MARK) {
/* 3527 */       d = sDbl[stackTop];
/* 3528 */       lhs = rhs;
/* 3529 */       leftRightOrder = false;
/*      */     } else {
/*      */       
/* 3532 */       if (lhs instanceof Scriptable || rhs instanceof Scriptable) {
/* 3533 */         stack[stackTop] = ScriptRuntime.add(lhs, rhs, cx);
/*      */ 
/*      */       
/*      */       }
/* 3537 */       else if (lhs instanceof CharSequence) {
/* 3538 */         if (rhs instanceof CharSequence) {
/* 3539 */           stack[stackTop] = new ConsString((CharSequence)lhs, (CharSequence)rhs);
/*      */         } else {
/* 3541 */           stack[stackTop] = new ConsString((CharSequence)lhs, 
/* 3542 */               ScriptRuntime.toCharSequence(rhs));
/*      */         } 
/* 3544 */       } else if (rhs instanceof CharSequence) {
/* 3545 */         stack[stackTop] = new ConsString(
/* 3546 */             ScriptRuntime.toCharSequence(lhs), (CharSequence)rhs);
/*      */       } else {
/*      */         
/* 3549 */         Number lNum = (lhs instanceof Number) ? (Number)lhs : ScriptRuntime.toNumeric(lhs);
/* 3550 */         Number rNum = (rhs instanceof Number) ? (Number)rhs : ScriptRuntime.toNumeric(rhs);
/*      */         
/* 3552 */         if (lNum instanceof BigInteger && rNum instanceof BigInteger)
/* 3553 */         { stack[stackTop] = ((BigInteger)lNum).add((BigInteger)rNum); }
/* 3554 */         else { if (lNum instanceof BigInteger || rNum instanceof BigInteger) {
/* 3555 */             throw ScriptRuntime.typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */           }
/* 3557 */           stack[stackTop] = UniqueTag.DOUBLE_MARK;
/* 3558 */           sDbl[stackTop] = lNum.doubleValue() + rNum.doubleValue(); }
/*      */       
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3565 */     if (lhs instanceof Scriptable) {
/* 3566 */       rhs = ScriptRuntime.wrapNumber(d);
/* 3567 */       if (!leftRightOrder) {
/* 3568 */         Object tmp = lhs;
/* 3569 */         lhs = rhs;
/* 3570 */         rhs = tmp;
/*      */       } 
/* 3572 */       stack[stackTop] = ScriptRuntime.add(lhs, rhs, cx);
/* 3573 */     } else if (lhs instanceof CharSequence) {
/* 3574 */       CharSequence rstr = ScriptRuntime.numberToString(d, 10);
/* 3575 */       if (leftRightOrder) {
/* 3576 */         stack[stackTop] = new ConsString((CharSequence)lhs, rstr);
/*      */       } else {
/* 3578 */         stack[stackTop] = new ConsString(rstr, (CharSequence)lhs);
/*      */       } 
/*      */     } else {
/* 3581 */       Number lNum = (lhs instanceof Number) ? (Number)lhs : ScriptRuntime.toNumeric(lhs);
/* 3582 */       if (lNum instanceof BigInteger) {
/* 3583 */         throw ScriptRuntime.typeErrorById("msg.cant.convert.to.number", new Object[] { "BigInt" });
/*      */       }
/* 3585 */       stack[stackTop] = UniqueTag.DOUBLE_MARK;
/* 3586 */       sDbl[stackTop] = lNum.doubleValue() + d;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int doArithmetic(CallFrame frame, int op, Object[] stack, double[] sDbl, int stackTop) {
/* 3593 */     Number lNum = stack_numeric(frame, stackTop - 1);
/* 3594 */     Number rNum = stack_numeric(frame, stackTop);
/* 3595 */     stackTop--;
/*      */     
/* 3597 */     Number result = null;
/* 3598 */     switch (op) {
/*      */       case 22:
/* 3600 */         result = ScriptRuntime.subtract(lNum, rNum);
/*      */         break;
/*      */       case 23:
/* 3603 */         result = ScriptRuntime.multiply(lNum, rNum);
/*      */         break;
/*      */       case 24:
/* 3606 */         result = ScriptRuntime.divide(lNum, rNum);
/*      */         break;
/*      */       case 25:
/* 3609 */         result = ScriptRuntime.remainder(lNum, rNum);
/*      */         break;
/*      */       case 75:
/* 3612 */         result = ScriptRuntime.exponentiate(lNum, rNum);
/*      */         break;
/*      */     } 
/*      */     
/* 3616 */     if (result instanceof BigInteger) {
/* 3617 */       stack[stackTop] = result;
/*      */     } else {
/* 3619 */       stack[stackTop] = UniqueTag.DOUBLE_MARK;
/* 3620 */       sDbl[stackTop] = result.doubleValue();
/*      */     } 
/* 3622 */     return stackTop;
/*      */   }
/*      */   
/*      */   private static Object[] getArgsArray(Object[] stack, double[] sDbl, int shift, int count) {
/* 3626 */     if (count == 0) {
/* 3627 */       return ScriptRuntime.emptyArgs;
/*      */     }
/* 3629 */     Object[] args = new Object[count];
/* 3630 */     for (int i = 0; i != count; i++, shift++) {
/* 3631 */       Object val = stack[shift];
/* 3632 */       if (val == UniqueTag.DOUBLE_MARK) {
/* 3633 */         val = ScriptRuntime.wrapNumber(sDbl[shift]);
/*      */       }
/* 3635 */       args[i] = val;
/*      */     } 
/* 3637 */     return args;
/*      */   }
/*      */   
/*      */   private static void addInstructionCount(Context cx, CallFrame frame, int extra) {
/* 3641 */     cx.instructionCount += frame.pc - frame.pcPrevBranch + extra;
/* 3642 */     if (cx.instructionCount > cx.instructionThreshold) {
/* 3643 */       cx.observeInstructionCount(cx.instructionCount);
/* 3644 */       cx.instructionCount = 0;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Interpreter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */