/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.CodeSource;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.SecureClassLoader;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SecureCaller
/*     */ {
/*  27 */   private static final byte[] secureCallerImplBytecode = loadBytecode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   private static final Map<CodeSource, Map<ClassLoader, SoftReference<SecureCaller>>> callers = new WeakHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object callSecurely(final CodeSource codeSource, Callable callable, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     Map<ClassLoader, SoftReference<SecureCaller>> classLoaderMap;
/*     */     SecureCaller caller;
/*  47 */     final Thread thread = Thread.currentThread();
/*     */ 
/*     */     
/*  50 */     final ClassLoader classLoader = AccessController.<ClassLoader>doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run()
/*     */           {
/*  54 */             return thread.getContextClassLoader();
/*     */           }
/*     */         });
/*     */     
/*  58 */     synchronized (callers) {
/*     */       
/*  60 */       classLoaderMap = callers.get(codeSource);
/*  61 */       if (classLoaderMap == null) {
/*     */         
/*  63 */         classLoaderMap = new WeakHashMap<>();
/*  64 */         callers.put(codeSource, classLoaderMap);
/*     */       } 
/*     */     } 
/*     */     
/*  68 */     synchronized (classLoaderMap) {
/*     */       
/*  70 */       SoftReference<SecureCaller> ref = classLoaderMap.get(classLoader);
/*  71 */       if (ref != null) {
/*  72 */         caller = ref.get();
/*     */       } else {
/*  74 */         caller = null;
/*     */       } 
/*  76 */       if (caller == null) {
/*     */         
/*     */         try {
/*     */ 
/*     */           
/*  81 */           caller = AccessController.<SecureCaller>doPrivileged(new PrivilegedExceptionAction()
/*     */               {
/*     */                 public Object run() throws Exception
/*     */                 {
/*     */                   ClassLoader effectiveClassLoader;
/*     */ 
/*     */                   
/*  88 */                   Class<?> thisClass = getClass();
/*  89 */                   if (classLoader.loadClass(thisClass.getName()) != thisClass) {
/*  90 */                     effectiveClassLoader = thisClass.getClassLoader();
/*     */                   } else {
/*  92 */                     effectiveClassLoader = classLoader;
/*     */                   } 
/*  94 */                   SecureCaller.SecureClassLoaderImpl secCl = new SecureCaller.SecureClassLoaderImpl(effectiveClassLoader);
/*     */                   
/*  96 */                   Class<?> c = secCl.defineAndLinkClass(SecureCaller.class
/*  97 */                       .getName() + "Impl", SecureCaller
/*  98 */                       .secureCallerImplBytecode, codeSource);
/*  99 */                   return c.newInstance();
/*     */                 }
/*     */               });
/* 102 */           classLoaderMap.put(classLoader, new SoftReference<>(caller));
/*     */         }
/* 104 */         catch (PrivilegedActionException ex) {
/*     */           
/* 106 */           throw new UndeclaredThrowableException(ex.getCause());
/*     */         } 
/*     */       }
/*     */     } 
/* 110 */     return caller.call(callable, cx, scope, thisObj, args);
/*     */   }
/*     */   
/*     */   private static class SecureClassLoaderImpl
/*     */     extends SecureClassLoader
/*     */   {
/*     */     SecureClassLoaderImpl(ClassLoader parent) {
/* 117 */       super(parent);
/*     */     }
/*     */ 
/*     */     
/*     */     Class<?> defineAndLinkClass(String name, byte[] bytes, CodeSource cs) {
/* 122 */       Class<?> cl = defineClass(name, bytes, 0, bytes.length, cs);
/* 123 */       resolveClass(cl);
/* 124 */       return cl;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] loadBytecode() {
/* 130 */     return AccessController.<byte[]>doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           
/*     */           public Object run()
/*     */           {
/* 135 */             return SecureCaller.loadBytecodePrivileged();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] loadBytecodePrivileged() {
/* 142 */     URL url = SecureCaller.class.getResource("SecureCallerImpl.clazz");
/*     */     
/*     */     try {
/* 145 */       InputStream in = url.openStream();
/*     */       
/*     */       try {
/* 148 */         ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*     */         
/*     */         while (true) {
/* 151 */           int r = in.read();
/* 152 */           if (r == -1)
/*     */           {
/* 154 */             return bout.toByteArray();
/*     */           }
/* 156 */           bout.write(r);
/*     */         }
/*     */       
/*     */       } finally {
/*     */         
/* 161 */         in.close();
/*     */       }
/*     */     
/* 164 */     } catch (IOException e) {
/*     */       
/* 166 */       throw new UndeclaredThrowableException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract Object call(Callable paramCallable, Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\SecureCaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */