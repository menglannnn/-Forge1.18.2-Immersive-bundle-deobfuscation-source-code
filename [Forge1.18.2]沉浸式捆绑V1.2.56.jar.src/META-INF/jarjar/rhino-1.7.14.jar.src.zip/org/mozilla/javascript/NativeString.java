/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class NativeString
/*      */   extends IdScriptableObject
/*      */ {
/*      */   private static final long serialVersionUID = 920268368584188687L;
/*   33 */   private static final Object STRING_TAG = "String"; private static final int Id_length = 1; private static final int MAX_INSTANCE_ID = 1; private static final int ConstructorId_fromCharCode = -1; private static final int ConstructorId_fromCodePoint = -2; private static final int ConstructorId_raw = -3; private static final int Id_constructor = 1; private static final int Id_toString = 2; private static final int Id_toSource = 3; private static final int Id_valueOf = 4; private static final int Id_charAt = 5; private static final int Id_charCodeAt = 6; private static final int Id_indexOf = 7; private static final int Id_lastIndexOf = 8; private static final int Id_split = 9; private static final int Id_substring = 10; private static final int Id_toLowerCase = 11; private static final int Id_toUpperCase = 12; private static final int Id_substr = 13; private static final int Id_concat = 14; private static final int Id_slice = 15; private static final int Id_bold = 16; private static final int Id_italics = 17; private static final int Id_fixed = 18; private static final int Id_strike = 19; private static final int Id_small = 20; private static final int Id_big = 21; private static final int Id_blink = 22; private static final int Id_sup = 23; private static final int Id_sub = 24; private static final int Id_fontsize = 25; private static final int Id_fontcolor = 26; private static final int Id_link = 27; private static final int Id_anchor = 28; private static final int Id_equals = 29; private static final int Id_equalsIgnoreCase = 30; private static final int Id_match = 31; private static final int Id_search = 32;
/*      */   
/*      */   static void init(Scriptable scope, boolean sealed) {
/*   36 */     NativeString obj = new NativeString("");
/*   37 */     obj.exportAsJSClass(50, scope, sealed);
/*      */   }
/*      */   private static final int Id_replace = 33; private static final int Id_localeCompare = 34; private static final int Id_toLocaleLowerCase = 35; private static final int Id_toLocaleUpperCase = 36; private static final int Id_trim = 37; private static final int Id_trimLeft = 38; private static final int Id_trimRight = 39; private static final int Id_includes = 40; private static final int Id_startsWith = 41; private static final int Id_endsWith = 42; private static final int Id_normalize = 43; private static final int Id_repeat = 44; private static final int Id_codePointAt = 45; private static final int Id_padStart = 46; private static final int Id_padEnd = 47; private static final int SymbolId_iterator = 48; private static final int Id_trimStart = 49; private static final int Id_trimEnd = 50; private static final int MAX_PROTOTYPE_ID = 50; private static final int ConstructorId_charAt = -5; private static final int ConstructorId_charCodeAt = -6; private static final int ConstructorId_indexOf = -7; private static final int ConstructorId_lastIndexOf = -8; private static final int ConstructorId_split = -9; private static final int ConstructorId_substring = -10; private static final int ConstructorId_toLowerCase = -11; private static final int ConstructorId_toUpperCase = -12; private static final int ConstructorId_substr = -13; private static final int ConstructorId_concat = -14; private static final int ConstructorId_slice = -15; private static final int ConstructorId_equalsIgnoreCase = -30; private static final int ConstructorId_match = -31; private static final int ConstructorId_search = -32; private static final int ConstructorId_replace = -33; private static final int ConstructorId_localeCompare = -34; private static final int ConstructorId_toLocaleLowerCase = -35; private CharSequence string;
/*      */   NativeString(CharSequence s) {
/*   41 */     this.string = s;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getClassName() {
/*   46 */     return "String";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getMaxInstanceId() {
/*   53 */     return 1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int findInstanceIdInfo(String s) {
/*   58 */     if (s.equals("length")) {
/*   59 */       return instanceIdInfo(7, 1);
/*      */     }
/*   61 */     return super.findInstanceIdInfo(s);
/*      */   }
/*      */ 
/*      */   
/*      */   protected String getInstanceIdName(int id) {
/*   66 */     if (id == 1) {
/*   67 */       return "length";
/*      */     }
/*   69 */     return super.getInstanceIdName(id);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object getInstanceIdValue(int id) {
/*   74 */     if (id == 1) {
/*   75 */       return ScriptRuntime.wrapInt(this.string.length());
/*      */     }
/*   77 */     return super.getInstanceIdValue(id);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/*   82 */     addIdFunctionProperty(ctor, STRING_TAG, -1, "fromCharCode", 1);
/*   83 */     addIdFunctionProperty(ctor, STRING_TAG, -2, "fromCodePoint", 1);
/*   84 */     addIdFunctionProperty(ctor, STRING_TAG, -3, "raw", 1);
/*   85 */     addIdFunctionProperty(ctor, STRING_TAG, -5, "charAt", 2);
/*   86 */     addIdFunctionProperty(ctor, STRING_TAG, -6, "charCodeAt", 2);
/*   87 */     addIdFunctionProperty(ctor, STRING_TAG, -7, "indexOf", 2);
/*   88 */     addIdFunctionProperty(ctor, STRING_TAG, -8, "lastIndexOf", 2);
/*   89 */     addIdFunctionProperty(ctor, STRING_TAG, -9, "split", 3);
/*   90 */     addIdFunctionProperty(ctor, STRING_TAG, -10, "substring", 3);
/*   91 */     addIdFunctionProperty(ctor, STRING_TAG, -11, "toLowerCase", 1);
/*   92 */     addIdFunctionProperty(ctor, STRING_TAG, -12, "toUpperCase", 1);
/*   93 */     addIdFunctionProperty(ctor, STRING_TAG, -13, "substr", 3);
/*   94 */     addIdFunctionProperty(ctor, STRING_TAG, -14, "concat", 2);
/*   95 */     addIdFunctionProperty(ctor, STRING_TAG, -15, "slice", 3);
/*   96 */     addIdFunctionProperty(ctor, STRING_TAG, -30, "equalsIgnoreCase", 2);
/*      */     
/*   98 */     addIdFunctionProperty(ctor, STRING_TAG, -31, "match", 2);
/*   99 */     addIdFunctionProperty(ctor, STRING_TAG, -32, "search", 2);
/*  100 */     addIdFunctionProperty(ctor, STRING_TAG, -33, "replace", 2);
/*  101 */     addIdFunctionProperty(ctor, STRING_TAG, -34, "localeCompare", 2);
/*  102 */     addIdFunctionProperty(ctor, STRING_TAG, -35, "toLocaleLowerCase", 1);
/*      */     
/*  104 */     super.fillConstructorProperties(ctor);
/*      */   }
/*      */   protected void initPrototypeId(int id) {
/*      */     String s;
/*      */     int arity;
/*  109 */     if (id == 48) {
/*  110 */       initPrototypeMethod(STRING_TAG, id, SymbolKey.ITERATOR, "[Symbol.iterator]", 0);
/*      */       
/*      */       return;
/*      */     } 
/*  114 */     String fnName = null;
/*      */     
/*  116 */     switch (id) {
/*      */       case 1:
/*  118 */         arity = 1;
/*  119 */         s = "constructor";
/*      */         break;
/*      */       case 2:
/*  122 */         arity = 0;
/*  123 */         s = "toString";
/*      */         break;
/*      */       case 3:
/*  126 */         arity = 0;
/*  127 */         s = "toSource";
/*      */         break;
/*      */       case 4:
/*  130 */         arity = 0;
/*  131 */         s = "valueOf";
/*      */         break;
/*      */       case 5:
/*  134 */         arity = 1;
/*  135 */         s = "charAt";
/*      */         break;
/*      */       case 6:
/*  138 */         arity = 1;
/*  139 */         s = "charCodeAt";
/*      */         break;
/*      */       case 7:
/*  142 */         arity = 1;
/*  143 */         s = "indexOf";
/*      */         break;
/*      */       case 8:
/*  146 */         arity = 1;
/*  147 */         s = "lastIndexOf";
/*      */         break;
/*      */       case 9:
/*  150 */         arity = 2;
/*  151 */         s = "split";
/*      */         break;
/*      */       case 10:
/*  154 */         arity = 2;
/*  155 */         s = "substring";
/*      */         break;
/*      */       case 11:
/*  158 */         arity = 0;
/*  159 */         s = "toLowerCase";
/*      */         break;
/*      */       case 12:
/*  162 */         arity = 0;
/*  163 */         s = "toUpperCase";
/*      */         break;
/*      */       case 13:
/*  166 */         arity = 2;
/*  167 */         s = "substr";
/*      */         break;
/*      */       case 14:
/*  170 */         arity = 1;
/*  171 */         s = "concat";
/*      */         break;
/*      */       case 15:
/*  174 */         arity = 2;
/*  175 */         s = "slice";
/*      */         break;
/*      */       case 16:
/*  178 */         arity = 0;
/*  179 */         s = "bold";
/*      */         break;
/*      */       case 17:
/*  182 */         arity = 0;
/*  183 */         s = "italics";
/*      */         break;
/*      */       case 18:
/*  186 */         arity = 0;
/*  187 */         s = "fixed";
/*      */         break;
/*      */       case 19:
/*  190 */         arity = 0;
/*  191 */         s = "strike";
/*      */         break;
/*      */       case 20:
/*  194 */         arity = 0;
/*  195 */         s = "small";
/*      */         break;
/*      */       case 21:
/*  198 */         arity = 0;
/*  199 */         s = "big";
/*      */         break;
/*      */       case 22:
/*  202 */         arity = 0;
/*  203 */         s = "blink";
/*      */         break;
/*      */       case 23:
/*  206 */         arity = 0;
/*  207 */         s = "sup";
/*      */         break;
/*      */       case 24:
/*  210 */         arity = 0;
/*  211 */         s = "sub";
/*      */         break;
/*      */       case 25:
/*  214 */         arity = 0;
/*  215 */         s = "fontsize";
/*      */         break;
/*      */       case 26:
/*  218 */         arity = 0;
/*  219 */         s = "fontcolor";
/*      */         break;
/*      */       case 27:
/*  222 */         arity = 0;
/*  223 */         s = "link";
/*      */         break;
/*      */       case 28:
/*  226 */         arity = 0;
/*  227 */         s = "anchor";
/*      */         break;
/*      */       case 29:
/*  230 */         arity = 1;
/*  231 */         s = "equals";
/*      */         break;
/*      */       case 30:
/*  234 */         arity = 1;
/*  235 */         s = "equalsIgnoreCase";
/*      */         break;
/*      */       case 31:
/*  238 */         arity = 1;
/*  239 */         s = "match";
/*      */         break;
/*      */       case 32:
/*  242 */         arity = 1;
/*  243 */         s = "search";
/*      */         break;
/*      */       case 33:
/*  246 */         arity = 2;
/*  247 */         s = "replace";
/*      */         break;
/*      */       case 34:
/*  250 */         arity = 1;
/*  251 */         s = "localeCompare";
/*      */         break;
/*      */       case 35:
/*  254 */         arity = 0;
/*  255 */         s = "toLocaleLowerCase";
/*      */         break;
/*      */       case 36:
/*  258 */         arity = 0;
/*  259 */         s = "toLocaleUpperCase";
/*      */         break;
/*      */       case 37:
/*  262 */         arity = 0;
/*  263 */         s = "trim";
/*      */         break;
/*      */       case 38:
/*  266 */         arity = 0;
/*  267 */         s = "trimLeft";
/*      */         break;
/*      */       case 39:
/*  270 */         arity = 0;
/*  271 */         s = "trimRight";
/*      */         break;
/*      */       case 40:
/*  274 */         arity = 1;
/*  275 */         s = "includes";
/*      */         break;
/*      */       case 41:
/*  278 */         arity = 1;
/*  279 */         s = "startsWith";
/*      */         break;
/*      */       case 42:
/*  282 */         arity = 1;
/*  283 */         s = "endsWith";
/*      */         break;
/*      */       case 43:
/*  286 */         arity = 0;
/*  287 */         s = "normalize";
/*      */         break;
/*      */       case 44:
/*  290 */         arity = 1;
/*  291 */         s = "repeat";
/*      */         break;
/*      */       case 45:
/*  294 */         arity = 1;
/*  295 */         s = "codePointAt";
/*      */         break;
/*      */       case 46:
/*  298 */         arity = 1;
/*  299 */         s = "padStart";
/*      */         break;
/*      */       case 47:
/*  302 */         arity = 1;
/*  303 */         s = "padEnd";
/*      */         break;
/*      */       case 49:
/*  306 */         arity = 0;
/*  307 */         s = "trimStart";
/*      */         break;
/*      */       case 50:
/*  310 */         arity = 0;
/*  311 */         s = "trimEnd";
/*      */         break;
/*      */       default:
/*  314 */         throw new IllegalArgumentException(String.valueOf(id));
/*      */     } 
/*  316 */     initPrototypeMethod(STRING_TAG, id, s, fnName, arity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: getstatic org/mozilla/javascript/NativeString.STRING_TAG : Ljava/lang/Object;
/*      */     //   4: invokevirtual hasTag : (Ljava/lang/Object;)Z
/*      */     //   7: ifne -> 22
/*      */     //   10: aload_0
/*      */     //   11: aload_1
/*      */     //   12: aload_2
/*      */     //   13: aload_3
/*      */     //   14: aload #4
/*      */     //   16: aload #5
/*      */     //   18: invokespecial execIdCall : (Lorg/mozilla/javascript/IdFunctionObject;Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   21: areturn
/*      */     //   22: aload_1
/*      */     //   23: invokevirtual methodId : ()I
/*      */     //   26: istore #6
/*      */     //   28: iload #6
/*      */     //   30: tableswitch default -> 2066, -35 -> 388, -34 -> 388, -33 -> 388, -32 -> 388, -31 -> 388, -30 -> 388, -29 -> 2066, -28 -> 2066, -27 -> 2066, -26 -> 2066, -25 -> 2066, -24 -> 2066, -23 -> 2066, -22 -> 2066, -21 -> 2066, -20 -> 2066, -19 -> 2066, -18 -> 2066, -17 -> 2066, -16 -> 2066, -15 -> 388, -14 -> 388, -13 -> 388, -12 -> 388, -11 -> 388, -10 -> 388, -9 -> 388, -8 -> 388, -7 -> 388, -6 -> 388, -5 -> 388, -4 -> 2066, -3 -> 658, -2 -> 474, -1 -> 599, 0 -> 2066, 1 -> 666, 2 -> 751, 3 -> 783, 4 -> 751, 5 -> 828, 6 -> 828, 7 -> 912, 8 -> 1088, 9 -> 1111, 10 -> 1139, 11 -> 1160, 12 -> 1181, 13 -> 1202, 14 -> 1222, 15 -> 1242, 16 -> 1262, 17 -> 1274, 18 -> 1286, 19 -> 1298, 20 -> 1310, 21 -> 1322, 22 -> 1334, 23 -> 1346, 24 -> 1358, 25 -> 1370, 26 -> 1384, 27 -> 1398, 28 -> 1412, 29 -> 1426, 30 -> 1426, 31 -> 1469, 32 -> 1469, 33 -> 1469, 34 -> 1524, 35 -> 1575, 36 -> 1597, 37 -> 1619, 38 -> 1707, 39 -> 1769, 40 -> 937, 41 -> 937, 42 -> 937, 43 -> 1832, 44 -> 1983, 45 -> 1993, 46 -> 1066, 47 -> 1066, 48 -> 2050, 49 -> 1707, 50 -> 1769
/*      */     //   388: aload #5
/*      */     //   390: arraylength
/*      */     //   391: ifle -> 454
/*      */     //   394: aload_2
/*      */     //   395: aload_3
/*      */     //   396: aload #5
/*      */     //   398: iconst_0
/*      */     //   399: aaload
/*      */     //   400: invokestatic toCharSequence : (Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   403: invokestatic toObject : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;
/*      */     //   406: astore #4
/*      */     //   408: aload #5
/*      */     //   410: arraylength
/*      */     //   411: iconst_1
/*      */     //   412: isub
/*      */     //   413: anewarray java/lang/Object
/*      */     //   416: astore #7
/*      */     //   418: iconst_0
/*      */     //   419: istore #8
/*      */     //   421: iload #8
/*      */     //   423: aload #7
/*      */     //   425: arraylength
/*      */     //   426: if_icmpge -> 447
/*      */     //   429: aload #7
/*      */     //   431: iload #8
/*      */     //   433: aload #5
/*      */     //   435: iload #8
/*      */     //   437: iconst_1
/*      */     //   438: iadd
/*      */     //   439: aaload
/*      */     //   440: aastore
/*      */     //   441: iinc #8, 1
/*      */     //   444: goto -> 421
/*      */     //   447: aload #7
/*      */     //   449: astore #5
/*      */     //   451: goto -> 466
/*      */     //   454: aload_2
/*      */     //   455: aload_3
/*      */     //   456: aload #4
/*      */     //   458: invokestatic toCharSequence : (Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   461: invokestatic toObject : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;
/*      */     //   464: astore #4
/*      */     //   466: iload #6
/*      */     //   468: ineg
/*      */     //   469: istore #6
/*      */     //   471: goto -> 28
/*      */     //   474: aload #5
/*      */     //   476: arraylength
/*      */     //   477: istore #7
/*      */     //   479: iload #7
/*      */     //   481: iconst_1
/*      */     //   482: if_icmpge -> 488
/*      */     //   485: ldc ''
/*      */     //   487: areturn
/*      */     //   488: iload #7
/*      */     //   490: newarray int
/*      */     //   492: astore #8
/*      */     //   494: iconst_0
/*      */     //   495: istore #9
/*      */     //   497: iload #9
/*      */     //   499: iload #7
/*      */     //   501: if_icmpeq -> 586
/*      */     //   504: aload #5
/*      */     //   506: iload #9
/*      */     //   508: aaload
/*      */     //   509: astore #10
/*      */     //   511: aload #10
/*      */     //   513: invokestatic toInt32 : (Ljava/lang/Object;)I
/*      */     //   516: istore #11
/*      */     //   518: aload #10
/*      */     //   520: invokestatic toNumber : (Ljava/lang/Object;)D
/*      */     //   523: dstore #12
/*      */     //   525: dload #12
/*      */     //   527: iload #11
/*      */     //   529: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   532: invokestatic eqNumber : (DLjava/lang/Object;)Z
/*      */     //   535: ifeq -> 546
/*      */     //   538: iload #11
/*      */     //   540: invokestatic isValidCodePoint : (I)Z
/*      */     //   543: ifne -> 573
/*      */     //   546: new java/lang/StringBuilder
/*      */     //   549: dup
/*      */     //   550: invokespecial <init> : ()V
/*      */     //   553: ldc 'Invalid code point '
/*      */     //   555: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   558: aload #10
/*      */     //   560: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   563: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   566: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   569: invokestatic rangeError : (Ljava/lang/String;)Lorg/mozilla/javascript/EcmaError;
/*      */     //   572: athrow
/*      */     //   573: aload #8
/*      */     //   575: iload #9
/*      */     //   577: iload #11
/*      */     //   579: iastore
/*      */     //   580: iinc #9, 1
/*      */     //   583: goto -> 497
/*      */     //   586: new java/lang/String
/*      */     //   589: dup
/*      */     //   590: aload #8
/*      */     //   592: iconst_0
/*      */     //   593: iload #7
/*      */     //   595: invokespecial <init> : ([III)V
/*      */     //   598: areturn
/*      */     //   599: aload #5
/*      */     //   601: arraylength
/*      */     //   602: istore #7
/*      */     //   604: iload #7
/*      */     //   606: iconst_1
/*      */     //   607: if_icmpge -> 613
/*      */     //   610: ldc ''
/*      */     //   612: areturn
/*      */     //   613: iload #7
/*      */     //   615: newarray char
/*      */     //   617: astore #8
/*      */     //   619: iconst_0
/*      */     //   620: istore #9
/*      */     //   622: iload #9
/*      */     //   624: iload #7
/*      */     //   626: if_icmpeq -> 648
/*      */     //   629: aload #8
/*      */     //   631: iload #9
/*      */     //   633: aload #5
/*      */     //   635: iload #9
/*      */     //   637: aaload
/*      */     //   638: invokestatic toUint16 : (Ljava/lang/Object;)C
/*      */     //   641: castore
/*      */     //   642: iinc #9, 1
/*      */     //   645: goto -> 622
/*      */     //   648: new java/lang/String
/*      */     //   651: dup
/*      */     //   652: aload #8
/*      */     //   654: invokespecial <init> : ([C)V
/*      */     //   657: areturn
/*      */     //   658: aload_2
/*      */     //   659: aload_3
/*      */     //   660: aload #5
/*      */     //   662: invokestatic js_raw : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   665: areturn
/*      */     //   666: aload #5
/*      */     //   668: arraylength
/*      */     //   669: ifne -> 679
/*      */     //   672: ldc ''
/*      */     //   674: astore #7
/*      */     //   676: goto -> 715
/*      */     //   679: aload #5
/*      */     //   681: iconst_0
/*      */     //   682: aaload
/*      */     //   683: invokestatic isSymbol : (Ljava/lang/Object;)Z
/*      */     //   686: ifeq -> 706
/*      */     //   689: aload #4
/*      */     //   691: ifnull -> 706
/*      */     //   694: aload #5
/*      */     //   696: iconst_0
/*      */     //   697: aaload
/*      */     //   698: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   701: astore #7
/*      */     //   703: goto -> 715
/*      */     //   706: aload #5
/*      */     //   708: iconst_0
/*      */     //   709: aaload
/*      */     //   710: invokestatic toCharSequence : (Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   713: astore #7
/*      */     //   715: aload #4
/*      */     //   717: ifnonnull -> 730
/*      */     //   720: new org/mozilla/javascript/NativeString
/*      */     //   723: dup
/*      */     //   724: aload #7
/*      */     //   726: invokespecial <init> : (Ljava/lang/CharSequence;)V
/*      */     //   729: areturn
/*      */     //   730: aload #7
/*      */     //   732: instanceof java/lang/String
/*      */     //   735: ifeq -> 743
/*      */     //   738: aload #7
/*      */     //   740: goto -> 750
/*      */     //   743: aload #7
/*      */     //   745: invokeinterface toString : ()Ljava/lang/String;
/*      */     //   750: areturn
/*      */     //   751: aload #4
/*      */     //   753: aload_1
/*      */     //   754: invokestatic realThis : (Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;)Lorg/mozilla/javascript/NativeString;
/*      */     //   757: getfield string : Ljava/lang/CharSequence;
/*      */     //   760: astore #7
/*      */     //   762: aload #7
/*      */     //   764: instanceof java/lang/String
/*      */     //   767: ifeq -> 775
/*      */     //   770: aload #7
/*      */     //   772: goto -> 782
/*      */     //   775: aload #7
/*      */     //   777: invokeinterface toString : ()Ljava/lang/String;
/*      */     //   782: areturn
/*      */     //   783: aload #4
/*      */     //   785: aload_1
/*      */     //   786: invokestatic realThis : (Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;)Lorg/mozilla/javascript/NativeString;
/*      */     //   789: getfield string : Ljava/lang/CharSequence;
/*      */     //   792: astore #8
/*      */     //   794: new java/lang/StringBuilder
/*      */     //   797: dup
/*      */     //   798: invokespecial <init> : ()V
/*      */     //   801: ldc '(new String("'
/*      */     //   803: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   806: aload #8
/*      */     //   808: invokeinterface toString : ()Ljava/lang/String;
/*      */     //   813: invokestatic escapeString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   816: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   819: ldc '"))'
/*      */     //   821: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   824: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   827: areturn
/*      */     //   828: aload_2
/*      */     //   829: aload #4
/*      */     //   831: aload_1
/*      */     //   832: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   835: invokestatic toCharSequence : (Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   838: astore #8
/*      */     //   840: aload #5
/*      */     //   842: iconst_0
/*      */     //   843: invokestatic toInteger : ([Ljava/lang/Object;I)D
/*      */     //   846: dstore #9
/*      */     //   848: dload #9
/*      */     //   850: dconst_0
/*      */     //   851: dcmpg
/*      */     //   852: iflt -> 869
/*      */     //   855: dload #9
/*      */     //   857: aload #8
/*      */     //   859: invokeinterface length : ()I
/*      */     //   864: i2d
/*      */     //   865: dcmpl
/*      */     //   866: iflt -> 882
/*      */     //   869: iload #6
/*      */     //   871: iconst_5
/*      */     //   872: if_icmpne -> 878
/*      */     //   875: ldc ''
/*      */     //   877: areturn
/*      */     //   878: getstatic org/mozilla/javascript/ScriptRuntime.NaNobj : Ljava/lang/Double;
/*      */     //   881: areturn
/*      */     //   882: aload #8
/*      */     //   884: dload #9
/*      */     //   886: d2i
/*      */     //   887: invokeinterface charAt : (I)C
/*      */     //   892: istore #11
/*      */     //   894: iload #6
/*      */     //   896: iconst_5
/*      */     //   897: if_icmpne -> 906
/*      */     //   900: iload #11
/*      */     //   902: invokestatic valueOf : (C)Ljava/lang/String;
/*      */     //   905: areturn
/*      */     //   906: iload #11
/*      */     //   908: invokestatic wrapInt : (I)Ljava/lang/Integer;
/*      */     //   911: areturn
/*      */     //   912: aload_2
/*      */     //   913: aload #4
/*      */     //   915: aload_1
/*      */     //   916: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   919: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   922: astore #8
/*      */     //   924: bipush #7
/*      */     //   926: aload #8
/*      */     //   928: aload #5
/*      */     //   930: invokestatic js_indexOf : (ILjava/lang/String;[Ljava/lang/Object;)I
/*      */     //   933: invokestatic wrapInt : (I)Ljava/lang/Integer;
/*      */     //   936: areturn
/*      */     //   937: aload_2
/*      */     //   938: aload #4
/*      */     //   940: aload_1
/*      */     //   941: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   944: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   947: astore #8
/*      */     //   949: aload #5
/*      */     //   951: arraylength
/*      */     //   952: ifle -> 990
/*      */     //   955: aload #5
/*      */     //   957: iconst_0
/*      */     //   958: aaload
/*      */     //   959: instanceof org/mozilla/javascript/regexp/NativeRegExp
/*      */     //   962: ifeq -> 990
/*      */     //   965: ldc 'msg.first.arg.not.regexp'
/*      */     //   967: iconst_2
/*      */     //   968: anewarray java/lang/Object
/*      */     //   971: dup
/*      */     //   972: iconst_0
/*      */     //   973: ldc java/lang/String
/*      */     //   975: invokevirtual getSimpleName : ()Ljava/lang/String;
/*      */     //   978: aastore
/*      */     //   979: dup
/*      */     //   980: iconst_1
/*      */     //   981: aload_1
/*      */     //   982: invokevirtual getFunctionName : ()Ljava/lang/String;
/*      */     //   985: aastore
/*      */     //   986: invokestatic typeErrorById : (Ljava/lang/String;[Ljava/lang/Object;)Lorg/mozilla/javascript/EcmaError;
/*      */     //   989: athrow
/*      */     //   990: iload #6
/*      */     //   992: aload #8
/*      */     //   994: aload #5
/*      */     //   996: invokestatic js_indexOf : (ILjava/lang/String;[Ljava/lang/Object;)I
/*      */     //   999: istore #9
/*      */     //   1001: iload #6
/*      */     //   1003: bipush #40
/*      */     //   1005: if_icmpne -> 1023
/*      */     //   1008: iload #9
/*      */     //   1010: iconst_m1
/*      */     //   1011: if_icmpeq -> 1018
/*      */     //   1014: iconst_1
/*      */     //   1015: goto -> 1019
/*      */     //   1018: iconst_0
/*      */     //   1019: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   1022: areturn
/*      */     //   1023: iload #6
/*      */     //   1025: bipush #41
/*      */     //   1027: if_icmpne -> 1044
/*      */     //   1030: iload #9
/*      */     //   1032: ifne -> 1039
/*      */     //   1035: iconst_1
/*      */     //   1036: goto -> 1040
/*      */     //   1039: iconst_0
/*      */     //   1040: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   1043: areturn
/*      */     //   1044: iload #6
/*      */     //   1046: bipush #42
/*      */     //   1048: if_icmpne -> 1066
/*      */     //   1051: iload #9
/*      */     //   1053: iconst_m1
/*      */     //   1054: if_icmpeq -> 1061
/*      */     //   1057: iconst_1
/*      */     //   1058: goto -> 1062
/*      */     //   1061: iconst_0
/*      */     //   1062: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   1065: areturn
/*      */     //   1066: aload_2
/*      */     //   1067: aload #4
/*      */     //   1069: aload_1
/*      */     //   1070: aload #5
/*      */     //   1072: iload #6
/*      */     //   1074: bipush #46
/*      */     //   1076: if_icmpne -> 1083
/*      */     //   1079: iconst_1
/*      */     //   1080: goto -> 1084
/*      */     //   1083: iconst_0
/*      */     //   1084: invokestatic js_pad : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;[Ljava/lang/Object;Z)Ljava/lang/String;
/*      */     //   1087: areturn
/*      */     //   1088: aload_2
/*      */     //   1089: aload #4
/*      */     //   1091: aload_1
/*      */     //   1092: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1095: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1098: astore #10
/*      */     //   1100: aload #10
/*      */     //   1102: aload #5
/*      */     //   1104: invokestatic js_lastIndexOf : (Ljava/lang/String;[Ljava/lang/Object;)I
/*      */     //   1107: invokestatic wrapInt : (I)Ljava/lang/Integer;
/*      */     //   1110: areturn
/*      */     //   1111: aload_2
/*      */     //   1112: aload #4
/*      */     //   1114: aload_1
/*      */     //   1115: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1118: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1121: astore #10
/*      */     //   1123: aload_2
/*      */     //   1124: invokestatic checkRegExpProxy : (Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/RegExpProxy;
/*      */     //   1127: aload_2
/*      */     //   1128: aload_3
/*      */     //   1129: aload #10
/*      */     //   1131: aload #5
/*      */     //   1133: invokeinterface js_split : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   1138: areturn
/*      */     //   1139: aload_2
/*      */     //   1140: aload #4
/*      */     //   1142: aload_1
/*      */     //   1143: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1146: invokestatic toCharSequence : (Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   1149: astore #10
/*      */     //   1151: aload_2
/*      */     //   1152: aload #10
/*      */     //   1154: aload #5
/*      */     //   1156: invokestatic js_substring : (Lorg/mozilla/javascript/Context;Ljava/lang/CharSequence;[Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   1159: areturn
/*      */     //   1160: aload_2
/*      */     //   1161: aload #4
/*      */     //   1163: aload_1
/*      */     //   1164: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1167: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1170: astore #10
/*      */     //   1172: aload #10
/*      */     //   1174: getstatic java/util/Locale.ROOT : Ljava/util/Locale;
/*      */     //   1177: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
/*      */     //   1180: areturn
/*      */     //   1181: aload_2
/*      */     //   1182: aload #4
/*      */     //   1184: aload_1
/*      */     //   1185: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1188: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1191: astore #10
/*      */     //   1193: aload #10
/*      */     //   1195: getstatic java/util/Locale.ROOT : Ljava/util/Locale;
/*      */     //   1198: invokevirtual toUpperCase : (Ljava/util/Locale;)Ljava/lang/String;
/*      */     //   1201: areturn
/*      */     //   1202: aload_2
/*      */     //   1203: aload #4
/*      */     //   1205: aload_1
/*      */     //   1206: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1209: invokestatic toCharSequence : (Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   1212: astore #10
/*      */     //   1214: aload #10
/*      */     //   1216: aload #5
/*      */     //   1218: invokestatic js_substr : (Ljava/lang/CharSequence;[Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   1221: areturn
/*      */     //   1222: aload_2
/*      */     //   1223: aload #4
/*      */     //   1225: aload_1
/*      */     //   1226: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1229: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1232: astore #10
/*      */     //   1234: aload #10
/*      */     //   1236: aload #5
/*      */     //   1238: invokestatic js_concat : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1241: areturn
/*      */     //   1242: aload_2
/*      */     //   1243: aload #4
/*      */     //   1245: aload_1
/*      */     //   1246: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1249: invokestatic toCharSequence : (Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   1252: astore #10
/*      */     //   1254: aload #10
/*      */     //   1256: aload #5
/*      */     //   1258: invokestatic js_slice : (Ljava/lang/CharSequence;[Ljava/lang/Object;)Ljava/lang/CharSequence;
/*      */     //   1261: areturn
/*      */     //   1262: aload_2
/*      */     //   1263: aload #4
/*      */     //   1265: aload_1
/*      */     //   1266: ldc 'b'
/*      */     //   1268: aconst_null
/*      */     //   1269: aconst_null
/*      */     //   1270: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1273: areturn
/*      */     //   1274: aload_2
/*      */     //   1275: aload #4
/*      */     //   1277: aload_1
/*      */     //   1278: ldc 'i'
/*      */     //   1280: aconst_null
/*      */     //   1281: aconst_null
/*      */     //   1282: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1285: areturn
/*      */     //   1286: aload_2
/*      */     //   1287: aload #4
/*      */     //   1289: aload_1
/*      */     //   1290: ldc 'tt'
/*      */     //   1292: aconst_null
/*      */     //   1293: aconst_null
/*      */     //   1294: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1297: areturn
/*      */     //   1298: aload_2
/*      */     //   1299: aload #4
/*      */     //   1301: aload_1
/*      */     //   1302: ldc 'strike'
/*      */     //   1304: aconst_null
/*      */     //   1305: aconst_null
/*      */     //   1306: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1309: areturn
/*      */     //   1310: aload_2
/*      */     //   1311: aload #4
/*      */     //   1313: aload_1
/*      */     //   1314: ldc 'small'
/*      */     //   1316: aconst_null
/*      */     //   1317: aconst_null
/*      */     //   1318: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1321: areturn
/*      */     //   1322: aload_2
/*      */     //   1323: aload #4
/*      */     //   1325: aload_1
/*      */     //   1326: ldc 'big'
/*      */     //   1328: aconst_null
/*      */     //   1329: aconst_null
/*      */     //   1330: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1333: areturn
/*      */     //   1334: aload_2
/*      */     //   1335: aload #4
/*      */     //   1337: aload_1
/*      */     //   1338: ldc 'blink'
/*      */     //   1340: aconst_null
/*      */     //   1341: aconst_null
/*      */     //   1342: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1345: areturn
/*      */     //   1346: aload_2
/*      */     //   1347: aload #4
/*      */     //   1349: aload_1
/*      */     //   1350: ldc 'sup'
/*      */     //   1352: aconst_null
/*      */     //   1353: aconst_null
/*      */     //   1354: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1357: areturn
/*      */     //   1358: aload_2
/*      */     //   1359: aload #4
/*      */     //   1361: aload_1
/*      */     //   1362: ldc 'sub'
/*      */     //   1364: aconst_null
/*      */     //   1365: aconst_null
/*      */     //   1366: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1369: areturn
/*      */     //   1370: aload_2
/*      */     //   1371: aload #4
/*      */     //   1373: aload_1
/*      */     //   1374: ldc 'font'
/*      */     //   1376: ldc 'size'
/*      */     //   1378: aload #5
/*      */     //   1380: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1383: areturn
/*      */     //   1384: aload_2
/*      */     //   1385: aload #4
/*      */     //   1387: aload_1
/*      */     //   1388: ldc 'font'
/*      */     //   1390: ldc 'color'
/*      */     //   1392: aload #5
/*      */     //   1394: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1397: areturn
/*      */     //   1398: aload_2
/*      */     //   1399: aload #4
/*      */     //   1401: aload_1
/*      */     //   1402: ldc 'a'
/*      */     //   1404: ldc 'href'
/*      */     //   1406: aload #5
/*      */     //   1408: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1411: areturn
/*      */     //   1412: aload_2
/*      */     //   1413: aload #4
/*      */     //   1415: aload_1
/*      */     //   1416: ldc 'a'
/*      */     //   1418: ldc 'name'
/*      */     //   1420: aload #5
/*      */     //   1422: invokestatic tagify : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1425: areturn
/*      */     //   1426: aload #4
/*      */     //   1428: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1431: astore #10
/*      */     //   1433: aload #5
/*      */     //   1435: iconst_0
/*      */     //   1436: invokestatic toString : ([Ljava/lang/Object;I)Ljava/lang/String;
/*      */     //   1439: astore #11
/*      */     //   1441: iload #6
/*      */     //   1443: bipush #29
/*      */     //   1445: if_icmpne -> 1458
/*      */     //   1448: aload #10
/*      */     //   1450: aload #11
/*      */     //   1452: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1455: goto -> 1465
/*      */     //   1458: aload #10
/*      */     //   1460: aload #11
/*      */     //   1462: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
/*      */     //   1465: invokestatic wrapBoolean : (Z)Ljava/lang/Boolean;
/*      */     //   1468: areturn
/*      */     //   1469: iload #6
/*      */     //   1471: bipush #31
/*      */     //   1473: if_icmpne -> 1482
/*      */     //   1476: iconst_1
/*      */     //   1477: istore #10
/*      */     //   1479: goto -> 1498
/*      */     //   1482: iload #6
/*      */     //   1484: bipush #32
/*      */     //   1486: if_icmpne -> 1495
/*      */     //   1489: iconst_3
/*      */     //   1490: istore #10
/*      */     //   1492: goto -> 1498
/*      */     //   1495: iconst_2
/*      */     //   1496: istore #10
/*      */     //   1498: aload_2
/*      */     //   1499: aload #4
/*      */     //   1501: aload_1
/*      */     //   1502: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1505: pop
/*      */     //   1506: aload_2
/*      */     //   1507: invokestatic checkRegExpProxy : (Lorg/mozilla/javascript/Context;)Lorg/mozilla/javascript/RegExpProxy;
/*      */     //   1510: aload_2
/*      */     //   1511: aload_3
/*      */     //   1512: aload #4
/*      */     //   1514: aload #5
/*      */     //   1516: iload #10
/*      */     //   1518: invokeinterface action : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;I)Ljava/lang/Object;
/*      */     //   1523: areturn
/*      */     //   1524: aload_2
/*      */     //   1525: aload #4
/*      */     //   1527: aload_1
/*      */     //   1528: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1531: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1534: astore #10
/*      */     //   1536: aload_2
/*      */     //   1537: invokevirtual getLocale : ()Ljava/util/Locale;
/*      */     //   1540: invokestatic getInstance : (Ljava/util/Locale;)Ljava/text/Collator;
/*      */     //   1543: astore #11
/*      */     //   1545: aload #11
/*      */     //   1547: iconst_3
/*      */     //   1548: invokevirtual setStrength : (I)V
/*      */     //   1551: aload #11
/*      */     //   1553: iconst_1
/*      */     //   1554: invokevirtual setDecomposition : (I)V
/*      */     //   1557: aload #11
/*      */     //   1559: aload #10
/*      */     //   1561: aload #5
/*      */     //   1563: iconst_0
/*      */     //   1564: invokestatic toString : ([Ljava/lang/Object;I)Ljava/lang/String;
/*      */     //   1567: invokevirtual compare : (Ljava/lang/String;Ljava/lang/String;)I
/*      */     //   1570: i2d
/*      */     //   1571: invokestatic wrapNumber : (D)Ljava/lang/Number;
/*      */     //   1574: areturn
/*      */     //   1575: aload_2
/*      */     //   1576: aload #4
/*      */     //   1578: aload_1
/*      */     //   1579: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1582: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1585: astore #10
/*      */     //   1587: aload #10
/*      */     //   1589: aload_2
/*      */     //   1590: invokevirtual getLocale : ()Ljava/util/Locale;
/*      */     //   1593: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
/*      */     //   1596: areturn
/*      */     //   1597: aload_2
/*      */     //   1598: aload #4
/*      */     //   1600: aload_1
/*      */     //   1601: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1604: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1607: astore #10
/*      */     //   1609: aload #10
/*      */     //   1611: aload_2
/*      */     //   1612: invokevirtual getLocale : ()Ljava/util/Locale;
/*      */     //   1615: invokevirtual toUpperCase : (Ljava/util/Locale;)Ljava/lang/String;
/*      */     //   1618: areturn
/*      */     //   1619: aload_2
/*      */     //   1620: aload #4
/*      */     //   1622: aload_1
/*      */     //   1623: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1626: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1629: astore #10
/*      */     //   1631: aload #10
/*      */     //   1633: invokevirtual toCharArray : ()[C
/*      */     //   1636: astore #11
/*      */     //   1638: iconst_0
/*      */     //   1639: istore #12
/*      */     //   1641: iload #12
/*      */     //   1643: aload #11
/*      */     //   1645: arraylength
/*      */     //   1646: if_icmpge -> 1666
/*      */     //   1649: aload #11
/*      */     //   1651: iload #12
/*      */     //   1653: caload
/*      */     //   1654: invokestatic isJSWhitespaceOrLineTerminator : (I)Z
/*      */     //   1657: ifeq -> 1666
/*      */     //   1660: iinc #12, 1
/*      */     //   1663: goto -> 1641
/*      */     //   1666: aload #11
/*      */     //   1668: arraylength
/*      */     //   1669: istore #13
/*      */     //   1671: iload #13
/*      */     //   1673: iload #12
/*      */     //   1675: if_icmple -> 1697
/*      */     //   1678: aload #11
/*      */     //   1680: iload #13
/*      */     //   1682: iconst_1
/*      */     //   1683: isub
/*      */     //   1684: caload
/*      */     //   1685: invokestatic isJSWhitespaceOrLineTerminator : (I)Z
/*      */     //   1688: ifeq -> 1697
/*      */     //   1691: iinc #13, -1
/*      */     //   1694: goto -> 1671
/*      */     //   1697: aload #10
/*      */     //   1699: iload #12
/*      */     //   1701: iload #13
/*      */     //   1703: invokevirtual substring : (II)Ljava/lang/String;
/*      */     //   1706: areturn
/*      */     //   1707: aload_2
/*      */     //   1708: aload #4
/*      */     //   1710: aload_1
/*      */     //   1711: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1714: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1717: astore #10
/*      */     //   1719: aload #10
/*      */     //   1721: invokevirtual toCharArray : ()[C
/*      */     //   1724: astore #11
/*      */     //   1726: iconst_0
/*      */     //   1727: istore #12
/*      */     //   1729: iload #12
/*      */     //   1731: aload #11
/*      */     //   1733: arraylength
/*      */     //   1734: if_icmpge -> 1754
/*      */     //   1737: aload #11
/*      */     //   1739: iload #12
/*      */     //   1741: caload
/*      */     //   1742: invokestatic isJSWhitespaceOrLineTerminator : (I)Z
/*      */     //   1745: ifeq -> 1754
/*      */     //   1748: iinc #12, 1
/*      */     //   1751: goto -> 1729
/*      */     //   1754: aload #11
/*      */     //   1756: arraylength
/*      */     //   1757: istore #13
/*      */     //   1759: aload #10
/*      */     //   1761: iload #12
/*      */     //   1763: iload #13
/*      */     //   1765: invokevirtual substring : (II)Ljava/lang/String;
/*      */     //   1768: areturn
/*      */     //   1769: aload_2
/*      */     //   1770: aload #4
/*      */     //   1772: aload_1
/*      */     //   1773: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1776: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1779: astore #10
/*      */     //   1781: aload #10
/*      */     //   1783: invokevirtual toCharArray : ()[C
/*      */     //   1786: astore #11
/*      */     //   1788: iconst_0
/*      */     //   1789: istore #12
/*      */     //   1791: aload #11
/*      */     //   1793: arraylength
/*      */     //   1794: istore #13
/*      */     //   1796: iload #13
/*      */     //   1798: iload #12
/*      */     //   1800: if_icmple -> 1822
/*      */     //   1803: aload #11
/*      */     //   1805: iload #13
/*      */     //   1807: iconst_1
/*      */     //   1808: isub
/*      */     //   1809: caload
/*      */     //   1810: invokestatic isJSWhitespaceOrLineTerminator : (I)Z
/*      */     //   1813: ifeq -> 1822
/*      */     //   1816: iinc #13, -1
/*      */     //   1819: goto -> 1796
/*      */     //   1822: aload #10
/*      */     //   1824: iload #12
/*      */     //   1826: iload #13
/*      */     //   1828: invokevirtual substring : (II)Ljava/lang/String;
/*      */     //   1831: areturn
/*      */     //   1832: aload #5
/*      */     //   1834: arraylength
/*      */     //   1835: ifeq -> 1848
/*      */     //   1838: aload #5
/*      */     //   1840: iconst_0
/*      */     //   1841: aaload
/*      */     //   1842: invokestatic isUndefined : (Ljava/lang/Object;)Z
/*      */     //   1845: ifeq -> 1865
/*      */     //   1848: aload_2
/*      */     //   1849: aload #4
/*      */     //   1851: aload_1
/*      */     //   1852: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1855: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1858: getstatic java/text/Normalizer$Form.NFC : Ljava/text/Normalizer$Form;
/*      */     //   1861: invokestatic normalize : (Ljava/lang/CharSequence;Ljava/text/Normalizer$Form;)Ljava/lang/String;
/*      */     //   1864: areturn
/*      */     //   1865: aload #5
/*      */     //   1867: iconst_0
/*      */     //   1868: invokestatic toString : ([Ljava/lang/Object;I)Ljava/lang/String;
/*      */     //   1871: astore #10
/*      */     //   1873: getstatic java/text/Normalizer$Form.NFD : Ljava/text/Normalizer$Form;
/*      */     //   1876: invokevirtual name : ()Ljava/lang/String;
/*      */     //   1879: aload #10
/*      */     //   1881: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1884: ifeq -> 1895
/*      */     //   1887: getstatic java/text/Normalizer$Form.NFD : Ljava/text/Normalizer$Form;
/*      */     //   1890: astore #11
/*      */     //   1892: goto -> 1967
/*      */     //   1895: getstatic java/text/Normalizer$Form.NFKC : Ljava/text/Normalizer$Form;
/*      */     //   1898: invokevirtual name : ()Ljava/lang/String;
/*      */     //   1901: aload #10
/*      */     //   1903: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1906: ifeq -> 1917
/*      */     //   1909: getstatic java/text/Normalizer$Form.NFKC : Ljava/text/Normalizer$Form;
/*      */     //   1912: astore #11
/*      */     //   1914: goto -> 1967
/*      */     //   1917: getstatic java/text/Normalizer$Form.NFKD : Ljava/text/Normalizer$Form;
/*      */     //   1920: invokevirtual name : ()Ljava/lang/String;
/*      */     //   1923: aload #10
/*      */     //   1925: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1928: ifeq -> 1939
/*      */     //   1931: getstatic java/text/Normalizer$Form.NFKD : Ljava/text/Normalizer$Form;
/*      */     //   1934: astore #11
/*      */     //   1936: goto -> 1967
/*      */     //   1939: getstatic java/text/Normalizer$Form.NFC : Ljava/text/Normalizer$Form;
/*      */     //   1942: invokevirtual name : ()Ljava/lang/String;
/*      */     //   1945: aload #10
/*      */     //   1947: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   1950: ifeq -> 1961
/*      */     //   1953: getstatic java/text/Normalizer$Form.NFC : Ljava/text/Normalizer$Form;
/*      */     //   1956: astore #11
/*      */     //   1958: goto -> 1967
/*      */     //   1961: ldc 'The normalization form should be one of 'NFC', 'NFD', 'NFKC', 'NFKD'.'
/*      */     //   1963: invokestatic rangeError : (Ljava/lang/String;)Lorg/mozilla/javascript/EcmaError;
/*      */     //   1966: athrow
/*      */     //   1967: aload_2
/*      */     //   1968: aload #4
/*      */     //   1970: aload_1
/*      */     //   1971: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   1974: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1977: aload #11
/*      */     //   1979: invokestatic normalize : (Ljava/lang/CharSequence;Ljava/text/Normalizer$Form;)Ljava/lang/String;
/*      */     //   1982: areturn
/*      */     //   1983: aload_2
/*      */     //   1984: aload #4
/*      */     //   1986: aload_1
/*      */     //   1987: aload #5
/*      */     //   1989: invokestatic js_repeat : (Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/IdFunctionObject;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1992: areturn
/*      */     //   1993: aload_2
/*      */     //   1994: aload #4
/*      */     //   1996: aload_1
/*      */     //   1997: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   2000: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   2003: astore #10
/*      */     //   2005: aload #5
/*      */     //   2007: iconst_0
/*      */     //   2008: invokestatic toInteger : ([Ljava/lang/Object;I)D
/*      */     //   2011: dstore #11
/*      */     //   2013: dload #11
/*      */     //   2015: dconst_0
/*      */     //   2016: dcmpg
/*      */     //   2017: iflt -> 2032
/*      */     //   2020: dload #11
/*      */     //   2022: aload #10
/*      */     //   2024: invokevirtual length : ()I
/*      */     //   2027: i2d
/*      */     //   2028: dcmpl
/*      */     //   2029: iflt -> 2038
/*      */     //   2032: getstatic org/mozilla/javascript/Undefined.instance : Ljava/lang/Object;
/*      */     //   2035: goto -> 2049
/*      */     //   2038: aload #10
/*      */     //   2040: dload #11
/*      */     //   2042: d2i
/*      */     //   2043: invokevirtual codePointAt : (I)I
/*      */     //   2046: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   2049: areturn
/*      */     //   2050: new org/mozilla/javascript/NativeStringIterator
/*      */     //   2053: dup
/*      */     //   2054: aload_3
/*      */     //   2055: aload_2
/*      */     //   2056: aload #4
/*      */     //   2058: aload_1
/*      */     //   2059: invokestatic requireObjectCoercible : (Lorg/mozilla/javascript/Context;Ljava/lang/Object;Lorg/mozilla/javascript/IdFunctionObject;)Ljava/lang/Object;
/*      */     //   2062: invokespecial <init> : (Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)V
/*      */     //   2065: areturn
/*      */     //   2066: new java/lang/IllegalArgumentException
/*      */     //   2069: dup
/*      */     //   2070: new java/lang/StringBuilder
/*      */     //   2073: dup
/*      */     //   2074: invokespecial <init> : ()V
/*      */     //   2077: ldc 'String.prototype has no method: '
/*      */     //   2079: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   2082: aload_1
/*      */     //   2083: invokevirtual getFunctionName : ()Ljava/lang/String;
/*      */     //   2086: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   2089: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   2092: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   2095: athrow
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #322	-> 0
/*      */     //   #323	-> 10
/*      */     //   #325	-> 22
/*      */     //   #328	-> 28
/*      */     //   #347	-> 388
/*      */     //   #348	-> 394
/*      */     //   #350	-> 400
/*      */     //   #349	-> 403
/*      */     //   #351	-> 408
/*      */     //   #352	-> 418
/*      */     //   #353	-> 447
/*      */     //   #354	-> 451
/*      */     //   #355	-> 454
/*      */     //   #357	-> 458
/*      */     //   #356	-> 461
/*      */     //   #359	-> 466
/*      */     //   #360	-> 471
/*      */     //   #365	-> 474
/*      */     //   #366	-> 479
/*      */     //   #367	-> 485
/*      */     //   #369	-> 488
/*      */     //   #370	-> 494
/*      */     //   #371	-> 504
/*      */     //   #372	-> 511
/*      */     //   #373	-> 518
/*      */     //   #374	-> 525
/*      */     //   #375	-> 540
/*      */     //   #376	-> 546
/*      */     //   #377	-> 560
/*      */     //   #376	-> 569
/*      */     //   #379	-> 573
/*      */     //   #370	-> 580
/*      */     //   #381	-> 586
/*      */     //   #386	-> 599
/*      */     //   #387	-> 604
/*      */     //   #388	-> 610
/*      */     //   #390	-> 613
/*      */     //   #391	-> 619
/*      */     //   #392	-> 629
/*      */     //   #391	-> 642
/*      */     //   #394	-> 648
/*      */     //   #398	-> 658
/*      */     //   #403	-> 666
/*      */     //   #404	-> 672
/*      */     //   #405	-> 679
/*      */     //   #408	-> 694
/*      */     //   #410	-> 706
/*      */     //   #412	-> 715
/*      */     //   #414	-> 720
/*      */     //   #417	-> 730
/*      */     //   #423	-> 751
/*      */     //   #424	-> 762
/*      */     //   #428	-> 783
/*      */     //   #429	-> 794
/*      */     //   #436	-> 828
/*      */     //   #438	-> 832
/*      */     //   #437	-> 835
/*      */     //   #439	-> 840
/*      */     //   #440	-> 848
/*      */     //   #441	-> 869
/*      */     //   #442	-> 878
/*      */     //   #444	-> 882
/*      */     //   #445	-> 894
/*      */     //   #446	-> 906
/*      */     //   #451	-> 912
/*      */     //   #452	-> 916
/*      */     //   #453	-> 924
/*      */     //   #459	-> 937
/*      */     //   #460	-> 941
/*      */     //   #461	-> 949
/*      */     //   #462	-> 965
/*      */     //   #464	-> 975
/*      */     //   #465	-> 982
/*      */     //   #462	-> 986
/*      */     //   #468	-> 990
/*      */     //   #470	-> 1001
/*      */     //   #471	-> 1008
/*      */     //   #473	-> 1023
/*      */     //   #474	-> 1030
/*      */     //   #476	-> 1044
/*      */     //   #477	-> 1051
/*      */     //   #483	-> 1066
/*      */     //   #487	-> 1088
/*      */     //   #488	-> 1092
/*      */     //   #489	-> 1100
/*      */     //   #494	-> 1111
/*      */     //   #495	-> 1115
/*      */     //   #496	-> 1123
/*      */     //   #497	-> 1133
/*      */     //   #496	-> 1138
/*      */     //   #502	-> 1139
/*      */     //   #504	-> 1143
/*      */     //   #503	-> 1146
/*      */     //   #505	-> 1151
/*      */     //   #511	-> 1160
/*      */     //   #512	-> 1164
/*      */     //   #513	-> 1172
/*      */     //   #519	-> 1181
/*      */     //   #520	-> 1185
/*      */     //   #521	-> 1193
/*      */     //   #526	-> 1202
/*      */     //   #528	-> 1206
/*      */     //   #527	-> 1209
/*      */     //   #529	-> 1214
/*      */     //   #534	-> 1222
/*      */     //   #535	-> 1226
/*      */     //   #536	-> 1234
/*      */     //   #541	-> 1242
/*      */     //   #543	-> 1246
/*      */     //   #542	-> 1249
/*      */     //   #544	-> 1254
/*      */     //   #548	-> 1262
/*      */     //   #551	-> 1274
/*      */     //   #554	-> 1286
/*      */     //   #557	-> 1298
/*      */     //   #560	-> 1310
/*      */     //   #563	-> 1322
/*      */     //   #566	-> 1334
/*      */     //   #569	-> 1346
/*      */     //   #572	-> 1358
/*      */     //   #575	-> 1370
/*      */     //   #578	-> 1384
/*      */     //   #581	-> 1398
/*      */     //   #584	-> 1412
/*      */     //   #589	-> 1426
/*      */     //   #590	-> 1433
/*      */     //   #591	-> 1441
/*      */     //   #592	-> 1452
/*      */     //   #591	-> 1465
/*      */     //   #600	-> 1469
/*      */     //   #601	-> 1476
/*      */     //   #602	-> 1482
/*      */     //   #603	-> 1489
/*      */     //   #605	-> 1495
/*      */     //   #608	-> 1498
/*      */     //   #609	-> 1506
/*      */     //   #610	-> 1518
/*      */     //   #609	-> 1523
/*      */     //   #619	-> 1524
/*      */     //   #620	-> 1528
/*      */     //   #621	-> 1536
/*      */     //   #622	-> 1545
/*      */     //   #623	-> 1551
/*      */     //   #624	-> 1557
/*      */     //   #625	-> 1564
/*      */     //   #624	-> 1571
/*      */     //   #629	-> 1575
/*      */     //   #630	-> 1579
/*      */     //   #631	-> 1587
/*      */     //   #635	-> 1597
/*      */     //   #636	-> 1601
/*      */     //   #637	-> 1609
/*      */     //   #641	-> 1619
/*      */     //   #642	-> 1631
/*      */     //   #644	-> 1638
/*      */     //   #645	-> 1641
/*      */     //   #646	-> 1654
/*      */     //   #647	-> 1660
/*      */     //   #649	-> 1666
/*      */     //   #650	-> 1671
/*      */     //   #651	-> 1685
/*      */     //   #652	-> 1691
/*      */     //   #655	-> 1697
/*      */     //   #660	-> 1707
/*      */     //   #661	-> 1719
/*      */     //   #663	-> 1726
/*      */     //   #664	-> 1729
/*      */     //   #665	-> 1742
/*      */     //   #666	-> 1748
/*      */     //   #668	-> 1754
/*      */     //   #670	-> 1759
/*      */     //   #675	-> 1769
/*      */     //   #676	-> 1781
/*      */     //   #678	-> 1788
/*      */     //   #680	-> 1791
/*      */     //   #681	-> 1796
/*      */     //   #682	-> 1810
/*      */     //   #683	-> 1816
/*      */     //   #686	-> 1822
/*      */     //   #690	-> 1832
/*      */     //   #691	-> 1848
/*      */     //   #692	-> 1852
/*      */     //   #691	-> 1861
/*      */     //   #696	-> 1865
/*      */     //   #699	-> 1873
/*      */     //   #700	-> 1895
/*      */     //   #701	-> 1909
/*      */     //   #702	-> 1917
/*      */     //   #703	-> 1931
/*      */     //   #704	-> 1939
/*      */     //   #705	-> 1953
/*      */     //   #707	-> 1961
/*      */     //   #710	-> 1967
/*      */     //   #711	-> 1971
/*      */     //   #710	-> 1979
/*      */     //   #717	-> 1983
/*      */     //   #721	-> 1993
/*      */     //   #722	-> 2005
/*      */     //   #724	-> 2013
/*      */     //   #726	-> 2043
/*      */     //   #724	-> 2049
/*      */     //   #730	-> 2050
/*      */     //   #732	-> 2066
/*      */     //   #733	-> 2083
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   421	26	8	i	I
/*      */     //   418	33	7	newArgs	[Ljava/lang/Object;
/*      */     //   511	69	10	arg	Ljava/lang/Object;
/*      */     //   518	62	11	codePoint	I
/*      */     //   525	55	12	num	D
/*      */     //   497	89	9	i	I
/*      */     //   479	120	7	n	I
/*      */     //   494	105	8	codePoints	[I
/*      */     //   622	26	9	i	I
/*      */     //   604	54	7	n	I
/*      */     //   619	39	8	chars	[C
/*      */     //   676	3	7	s	Ljava/lang/CharSequence;
/*      */     //   703	3	7	s	Ljava/lang/CharSequence;
/*      */     //   715	36	7	s	Ljava/lang/CharSequence;
/*      */     //   762	21	7	cs	Ljava/lang/CharSequence;
/*      */     //   794	34	8	s	Ljava/lang/CharSequence;
/*      */     //   840	72	8	target	Ljava/lang/CharSequence;
/*      */     //   848	64	9	pos	D
/*      */     //   894	18	11	c	C
/*      */     //   924	13	8	thisString	Ljava/lang/String;
/*      */     //   949	117	8	thisString	Ljava/lang/String;
/*      */     //   1001	65	9	idx	I
/*      */     //   1100	11	10	thisStr	Ljava/lang/String;
/*      */     //   1123	16	10	thisStr	Ljava/lang/String;
/*      */     //   1151	9	10	target	Ljava/lang/CharSequence;
/*      */     //   1172	9	10	thisStr	Ljava/lang/String;
/*      */     //   1193	9	10	thisStr	Ljava/lang/String;
/*      */     //   1214	8	10	target	Ljava/lang/CharSequence;
/*      */     //   1234	8	10	thisStr	Ljava/lang/String;
/*      */     //   1254	8	10	target	Ljava/lang/CharSequence;
/*      */     //   1433	36	10	s1	Ljava/lang/String;
/*      */     //   1441	28	11	s2	Ljava/lang/String;
/*      */     //   1479	3	10	actionType	I
/*      */     //   1492	3	10	actionType	I
/*      */     //   1498	26	10	actionType	I
/*      */     //   1536	39	10	thisStr	Ljava/lang/String;
/*      */     //   1545	30	11	collator	Ljava/text/Collator;
/*      */     //   1587	10	10	thisStr	Ljava/lang/String;
/*      */     //   1609	10	10	thisStr	Ljava/lang/String;
/*      */     //   1631	76	10	str	Ljava/lang/String;
/*      */     //   1638	69	11	chars	[C
/*      */     //   1641	66	12	start	I
/*      */     //   1671	36	13	end	I
/*      */     //   1719	50	10	str	Ljava/lang/String;
/*      */     //   1726	43	11	chars	[C
/*      */     //   1729	40	12	start	I
/*      */     //   1759	10	13	end	I
/*      */     //   1781	51	10	str	Ljava/lang/String;
/*      */     //   1788	44	11	chars	[C
/*      */     //   1791	41	12	start	I
/*      */     //   1796	36	13	end	I
/*      */     //   1892	3	11	form	Ljava/text/Normalizer$Form;
/*      */     //   1914	3	11	form	Ljava/text/Normalizer$Form;
/*      */     //   1936	3	11	form	Ljava/text/Normalizer$Form;
/*      */     //   1958	3	11	form	Ljava/text/Normalizer$Form;
/*      */     //   1873	110	10	formStr	Ljava/lang/String;
/*      */     //   1967	16	11	form	Ljava/text/Normalizer$Form;
/*      */     //   2005	45	10	str	Ljava/lang/String;
/*      */     //   2013	37	11	cnt	D
/*      */     //   0	2096	0	this	Lorg/mozilla/javascript/NativeString;
/*      */     //   0	2096	1	f	Lorg/mozilla/javascript/IdFunctionObject;
/*      */     //   0	2096	2	cx	Lorg/mozilla/javascript/Context;
/*      */     //   0	2096	3	scope	Lorg/mozilla/javascript/Scriptable;
/*      */     //   0	2096	4	thisObj	Lorg/mozilla/javascript/Scriptable;
/*      */     //   0	2096	5	args	[Ljava/lang/Object;
/*      */     //   28	2068	6	id	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NativeString realThis(Scriptable thisObj, IdFunctionObject f) {
/*  738 */     return ensureType(thisObj, NativeString.class, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String tagify(Context cx, Scriptable thisObj, IdFunctionObject f, String tag, String attribute, Object[] args) {
/*  751 */     String str = ScriptRuntime.toString(ScriptRuntimeES6.requireObjectCoercible(cx, thisObj, f));
/*  752 */     StringBuilder result = new StringBuilder();
/*  753 */     result.append('<').append(tag);
/*      */     
/*  755 */     if (attribute != null && attribute.length() > 0) {
/*  756 */       String attributeValue = ScriptRuntime.toString(args, 0);
/*  757 */       attributeValue = attributeValue.replace("\"", "&quot;");
/*  758 */       result.append(' ').append(attribute).append("=\"").append(attributeValue).append('"');
/*      */     } 
/*  760 */     result.append('>').append(str).append("</").append(tag).append('>');
/*  761 */     return result.toString();
/*      */   }
/*      */   
/*      */   public CharSequence toCharSequence() {
/*  765 */     return this.string;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  770 */     return (this.string instanceof String) ? (String)this.string : this.string.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(int index, Scriptable start) {
/*  778 */     if (0 <= index && index < this.string.length()) {
/*  779 */       return String.valueOf(this.string.charAt(index));
/*      */     }
/*  781 */     return super.get(index, start);
/*      */   }
/*      */ 
/*      */   
/*      */   public void put(int index, Scriptable start, Object value) {
/*  786 */     if (0 <= index && index < this.string.length()) {
/*      */       return;
/*      */     }
/*  789 */     super.put(index, start, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean has(int index, Scriptable start) {
/*  794 */     if (0 <= index && index < this.string.length()) {
/*  795 */       return true;
/*      */     }
/*  797 */     return super.has(index, start);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getAttributes(int index) {
/*  802 */     if (0 <= index && index < this.string.length()) {
/*  803 */       int attribs = 5;
/*  804 */       if (Context.getContext().getLanguageVersion() < 200) {
/*  805 */         attribs |= 0x2;
/*      */       }
/*  807 */       return attribs;
/*      */     } 
/*  809 */     return super.getAttributes(index);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object[] getIds(boolean nonEnumerable, boolean getSymbols) {
/*  815 */     Context cx = Context.getCurrentContext();
/*  816 */     if (cx != null && cx.getLanguageVersion() >= 200) {
/*  817 */       Object[] sids = super.getIds(nonEnumerable, getSymbols);
/*  818 */       Object[] a = new Object[sids.length + this.string.length()];
/*      */       int i;
/*  820 */       for (i = 0; i < this.string.length(); i++) {
/*  821 */         a[i] = Integer.valueOf(i);
/*      */       }
/*  823 */       System.arraycopy(sids, 0, a, i, sids.length);
/*  824 */       return a;
/*      */     } 
/*  826 */     return super.getIds(nonEnumerable, getSymbols);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ScriptableObject getOwnPropertyDescriptor(Context cx, Object id) {
/*  831 */     if (!(id instanceof Symbol) && cx != null && cx
/*      */       
/*  833 */       .getLanguageVersion() >= 200) {
/*  834 */       ScriptRuntime.StringIdOrIndex s = ScriptRuntime.toStringIdOrIndex(cx, id);
/*  835 */       if (s.stringId == null && 0 <= s.index && s.index < this.string.length()) {
/*  836 */         String value = String.valueOf(this.string.charAt(s.index));
/*  837 */         return defaultIndexPropertyDescriptor(value);
/*      */       } 
/*      */     } 
/*  840 */     return super.getOwnPropertyDescriptor(cx, id);
/*      */   }
/*      */   
/*      */   private ScriptableObject defaultIndexPropertyDescriptor(Object value) {
/*  844 */     Scriptable scope = getParentScope();
/*  845 */     if (scope == null) scope = this; 
/*  846 */     ScriptableObject desc = new NativeObject();
/*  847 */     ScriptRuntime.setBuiltinProtoAndParent(desc, scope, TopLevel.Builtins.Object);
/*  848 */     desc.defineProperty("value", value, 0);
/*  849 */     desc.defineProperty("writable", Boolean.FALSE, 0);
/*  850 */     desc.defineProperty("enumerable", Boolean.TRUE, 0);
/*  851 */     desc.defineProperty("configurable", Boolean.FALSE, 0);
/*  852 */     return desc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int js_indexOf(int methodId, String target, Object[] args) {
/*  861 */     String searchStr = ScriptRuntime.toString(args, 0);
/*  862 */     double position = ScriptRuntime.toInteger(args, 1);
/*      */     
/*  864 */     if (methodId != 41 && methodId != 42 && searchStr.length() == 0) {
/*  865 */       return (position > target.length()) ? target.length() : (int)position;
/*      */     }
/*      */     
/*  868 */     if (methodId != 41 && methodId != 42 && position > target.length()) {
/*  869 */       return -1;
/*      */     }
/*      */     
/*  872 */     if (position < 0.0D) { position = 0.0D; }
/*  873 */     else if (position > target.length()) { position = target.length(); }
/*  874 */     else if (methodId == 42 && (Double.isNaN(position) || position > target.length()))
/*  875 */     { position = target.length(); }
/*      */     
/*  877 */     if (42 == methodId) {
/*  878 */       if (args.length == 0 || args.length == 1 || (args.length == 2 && args[1] == Undefined.instance))
/*      */       {
/*      */         
/*  881 */         position = target.length(); } 
/*  882 */       return target.substring(0, (int)position).endsWith(searchStr) ? 0 : -1;
/*      */     } 
/*  884 */     return (methodId == 41) ? (
/*  885 */       target.startsWith(searchStr, (int)position) ? 0 : -1) : target
/*  886 */       .indexOf(searchStr, (int)position);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int js_lastIndexOf(String target, Object[] args) {
/*  895 */     String search = ScriptRuntime.toString(args, 0);
/*  896 */     double end = ScriptRuntime.toNumber(args, 1);
/*      */     
/*  898 */     if (Double.isNaN(end) || end > target.length()) { end = target.length(); }
/*  899 */     else if (end < 0.0D) { end = 0.0D; }
/*      */     
/*  901 */     return target.lastIndexOf(search, (int)end);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static CharSequence js_substring(Context cx, CharSequence target, Object[] args) {
/*      */     double end;
/*  908 */     int length = target.length();
/*  909 */     double start = ScriptRuntime.toInteger(args, 0);
/*      */ 
/*      */     
/*  912 */     if (start < 0.0D) { start = 0.0D; }
/*  913 */     else if (start > length) { start = length; }
/*      */     
/*  915 */     if (args.length <= 1 || args[1] == Undefined.instance) {
/*  916 */       end = length;
/*      */     } else {
/*  918 */       end = ScriptRuntime.toInteger(args[1]);
/*  919 */       if (end < 0.0D) { end = 0.0D; }
/*  920 */       else if (end > length) { end = length; }
/*      */ 
/*      */       
/*  923 */       if (end < start) {
/*  924 */         if (cx.getLanguageVersion() != 120) {
/*  925 */           double temp = start;
/*  926 */           start = end;
/*  927 */           end = temp;
/*      */         } else {
/*      */           
/*  930 */           end = start;
/*      */         } 
/*      */       }
/*      */     } 
/*  934 */     return target.subSequence((int)start, (int)end);
/*      */   }
/*      */   
/*      */   int getLength() {
/*  938 */     return this.string.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static CharSequence js_substr(CharSequence target, Object[] args) {
/*  945 */     if (args.length < 1) {
/*  946 */       return target;
/*      */     }
/*      */     
/*  949 */     double begin = ScriptRuntime.toInteger(args[0]);
/*      */     
/*  951 */     int length = target.length();
/*      */     
/*  953 */     if (begin < 0.0D) {
/*  954 */       begin += length;
/*  955 */       if (begin < 0.0D) begin = 0.0D; 
/*  956 */     } else if (begin > length) {
/*  957 */       begin = length;
/*      */     } 
/*      */     
/*  960 */     double end = length;
/*  961 */     if (args.length > 1) {
/*  962 */       Object lengthArg = args[1];
/*      */       
/*  964 */       if (!Undefined.isUndefined(lengthArg)) {
/*  965 */         end = ScriptRuntime.toInteger(lengthArg);
/*  966 */         if (end < 0.0D) {
/*  967 */           end = 0.0D;
/*      */         }
/*  969 */         end += begin;
/*  970 */         if (end > length) {
/*  971 */           end = length;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  976 */     return target.subSequence((int)begin, (int)end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String js_concat(String target, Object[] args) {
/*  983 */     int N = args.length;
/*  984 */     if (N == 0)
/*  985 */       return target; 
/*  986 */     if (N == 1) {
/*  987 */       String arg = ScriptRuntime.toString(args[0]);
/*  988 */       return target.concat(arg);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  993 */     int size = target.length();
/*  994 */     String[] argsAsStrings = new String[N];
/*  995 */     for (int i = 0; i != N; i++) {
/*  996 */       String s = ScriptRuntime.toString(args[i]);
/*  997 */       argsAsStrings[i] = s;
/*  998 */       size += s.length();
/*      */     } 
/*      */     
/* 1001 */     StringBuilder result = new StringBuilder(size);
/* 1002 */     result.append(target);
/* 1003 */     for (int j = 0; j != N; j++) {
/* 1004 */       result.append(argsAsStrings[j]);
/*      */     }
/* 1006 */     return result.toString();
/*      */   }
/*      */   
/*      */   private static CharSequence js_slice(CharSequence target, Object[] args) {
/* 1010 */     double end, begin = (args.length < 1) ? 0.0D : ScriptRuntime.toInteger(args[0]);
/*      */     
/* 1012 */     int length = target.length();
/* 1013 */     if (begin < 0.0D) {
/* 1014 */       begin += length;
/* 1015 */       if (begin < 0.0D) begin = 0.0D; 
/* 1016 */     } else if (begin > length) {
/* 1017 */       begin = length;
/*      */     } 
/*      */     
/* 1020 */     if (args.length < 2 || args[1] == Undefined.instance) {
/* 1021 */       end = length;
/*      */     } else {
/* 1023 */       end = ScriptRuntime.toInteger(args[1]);
/* 1024 */       if (end < 0.0D) {
/* 1025 */         end += length;
/* 1026 */         if (end < 0.0D) end = 0.0D; 
/* 1027 */       } else if (end > length) {
/* 1028 */         end = length;
/*      */       } 
/* 1030 */       if (end < begin) end = begin; 
/*      */     } 
/* 1032 */     return target.subSequence((int)begin, (int)end);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String js_repeat(Context cx, Scriptable thisObj, IdFunctionObject f, Object[] args) {
/* 1037 */     String str = ScriptRuntime.toString(ScriptRuntimeES6.requireObjectCoercible(cx, thisObj, f));
/* 1038 */     double cnt = ScriptRuntime.toInteger(args, 0);
/*      */     
/* 1040 */     if (cnt < 0.0D || cnt == Double.POSITIVE_INFINITY) {
/* 1041 */       throw ScriptRuntime.rangeError("Invalid count value");
/*      */     }
/*      */     
/* 1044 */     if (cnt == 0.0D || str.length() == 0) {
/* 1045 */       return "";
/*      */     }
/*      */     
/* 1048 */     long size = str.length() * (long)cnt;
/*      */     
/* 1050 */     if (cnt > 2.147483647E9D || size > 2147483647L) {
/* 1051 */       throw ScriptRuntime.rangeError("Invalid size or count value");
/*      */     }
/*      */     
/* 1054 */     StringBuilder retval = new StringBuilder((int)size);
/* 1055 */     retval.append(str);
/*      */     
/* 1057 */     int i = 1;
/* 1058 */     int icnt = (int)cnt;
/* 1059 */     while (i <= icnt / 2) {
/* 1060 */       retval.append(retval);
/* 1061 */       i *= 2;
/*      */     } 
/* 1063 */     if (i < icnt) {
/* 1064 */       retval.append(retval.substring(0, str.length() * (icnt - i)));
/*      */     }
/*      */     
/* 1067 */     return retval.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String js_pad(Context cx, Scriptable thisObj, IdFunctionObject f, Object[] args, boolean atStart) {
/* 1076 */     String pad = ScriptRuntime.toString(ScriptRuntimeES6.requireObjectCoercible(cx, thisObj, f));
/* 1077 */     long intMaxLength = ScriptRuntime.toLength(args, 0);
/* 1078 */     if (intMaxLength <= pad.length()) {
/* 1079 */       return pad;
/*      */     }
/*      */     
/* 1082 */     String filler = " ";
/* 1083 */     if (args.length >= 2 && !Undefined.isUndefined(args[1])) {
/* 1084 */       filler = ScriptRuntime.toString(args[1]);
/* 1085 */       if (filler.length() < 1) {
/* 1086 */         return pad;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1091 */     int fillLen = (int)(intMaxLength - pad.length());
/* 1092 */     StringBuilder concat = new StringBuilder();
/*      */     while (true) {
/* 1094 */       concat.append(filler);
/* 1095 */       if (concat.length() >= fillLen) {
/* 1096 */         concat.setLength(fillLen);
/*      */         
/* 1098 */         if (atStart) {
/* 1099 */           return concat.append(pad).toString();
/*      */         }
/*      */         
/* 1102 */         return concat.insert(0, pad).toString();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   protected int findPrototypeId(Symbol k) {
/* 1107 */     if (SymbolKey.ITERATOR.equals(k)) {
/* 1108 */       return 48;
/*      */     }
/* 1110 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static CharSequence js_raw(Context cx, Scriptable scope, Object[] args) {
/* 1122 */     Object arg0 = (args.length > 0) ? args[0] : Undefined.instance;
/* 1123 */     Scriptable cooked = ScriptRuntime.toObject(cx, scope, arg0);
/*      */     
/* 1125 */     Object rawValue = ScriptRuntime.getObjectProp(cooked, "raw", cx);
/* 1126 */     Scriptable raw = ScriptRuntime.toObject(cx, scope, rawValue);
/*      */     
/* 1128 */     long rawLength = NativeArray.getLengthProperty(cx, raw);
/* 1129 */     if (rawLength > 2147483647L) {
/* 1130 */       throw ScriptRuntime.rangeError("raw.length > " + Integer.toString(2147483647));
/*      */     }
/* 1132 */     int literalSegments = (int)rawLength;
/* 1133 */     if (literalSegments <= 0) return "";
/*      */     
/* 1135 */     StringBuilder elements = new StringBuilder();
/* 1136 */     int nextIndex = 0;
/*      */ 
/*      */     
/*      */     while (true) {
/* 1140 */       Object next = ScriptRuntime.getObjectIndex(raw, nextIndex, cx);
/* 1141 */       String nextSeg = ScriptRuntime.toString(next);
/* 1142 */       elements.append(nextSeg);
/* 1143 */       nextIndex++;
/* 1144 */       if (nextIndex == literalSegments) {
/*      */         break;
/*      */       }
/*      */       
/* 1148 */       if (args.length > nextIndex) {
/* 1149 */         next = args[nextIndex];
/* 1150 */         String nextSub = ScriptRuntime.toString(next);
/* 1151 */         elements.append(nextSub);
/*      */       } 
/*      */     } 
/* 1154 */     return elements;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int findPrototypeId(String s) {
/* 1160 */     switch (s)
/*      */     { case "constructor":
/* 1162 */         id = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1312 */         return id;case "toString": id = 2; return id;case "toSource": id = 3; return id;case "valueOf": id = 4; return id;case "charAt": id = 5; return id;case "charCodeAt": id = 6; return id;case "indexOf": id = 7; return id;case "lastIndexOf": id = 8; return id;case "split": id = 9; return id;case "substring": id = 10; return id;case "toLowerCase": id = 11; return id;case "toUpperCase": id = 12; return id;case "substr": id = 13; return id;case "concat": id = 14; return id;case "slice": id = 15; return id;case "bold": id = 16; return id;case "italics": id = 17; return id;case "fixed": id = 18; return id;case "strike": id = 19; return id;case "small": id = 20; return id;case "big": id = 21; return id;case "blink": id = 22; return id;case "sup": id = 23; return id;case "sub": id = 24; return id;case "fontsize": id = 25; return id;case "fontcolor": id = 26; return id;case "link": id = 27; return id;case "anchor": id = 28; return id;case "equals": id = 29; return id;case "equalsIgnoreCase": id = 30; return id;case "match": id = 31; return id;case "search": id = 32; return id;case "replace": id = 33; return id;case "localeCompare": id = 34; return id;case "toLocaleLowerCase": id = 35; return id;case "toLocaleUpperCase": id = 36; return id;case "trim": id = 37; return id;case "trimLeft": id = 38; return id;case "trimRight": id = 39; return id;case "includes": id = 40; return id;case "startsWith": id = 41; return id;case "endsWith": id = 42; return id;case "normalize": id = 43; return id;case "repeat": id = 44; return id;case "codePointAt": id = 45; return id;case "padStart": id = 46; return id;case "padEnd": id = 47; return id;case "trimStart": id = 49; return id;case "trimEnd": id = 50; return id; }  int id = 0; return id;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */