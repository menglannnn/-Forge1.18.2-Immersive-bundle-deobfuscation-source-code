/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.mozilla.javascript.ast.ArrayComprehension;
/*      */ import org.mozilla.javascript.ast.ArrayComprehensionLoop;
/*      */ import org.mozilla.javascript.ast.ArrayLiteral;
/*      */ import org.mozilla.javascript.ast.Assignment;
/*      */ import org.mozilla.javascript.ast.AstNode;
/*      */ import org.mozilla.javascript.ast.AstRoot;
/*      */ import org.mozilla.javascript.ast.BigIntLiteral;
/*      */ import org.mozilla.javascript.ast.Block;
/*      */ import org.mozilla.javascript.ast.BreakStatement;
/*      */ import org.mozilla.javascript.ast.CatchClause;
/*      */ import org.mozilla.javascript.ast.Comment;
/*      */ import org.mozilla.javascript.ast.ConditionalExpression;
/*      */ import org.mozilla.javascript.ast.ContinueStatement;
/*      */ import org.mozilla.javascript.ast.DestructuringForm;
/*      */ import org.mozilla.javascript.ast.DoLoop;
/*      */ import org.mozilla.javascript.ast.ElementGet;
/*      */ import org.mozilla.javascript.ast.EmptyExpression;
/*      */ import org.mozilla.javascript.ast.EmptyStatement;
/*      */ import org.mozilla.javascript.ast.ErrorNode;
/*      */ import org.mozilla.javascript.ast.ExpressionStatement;
/*      */ import org.mozilla.javascript.ast.ForInLoop;
/*      */ import org.mozilla.javascript.ast.ForLoop;
/*      */ import org.mozilla.javascript.ast.FunctionCall;
/*      */ import org.mozilla.javascript.ast.FunctionNode;
/*      */ import org.mozilla.javascript.ast.GeneratorExpression;
/*      */ import org.mozilla.javascript.ast.GeneratorExpressionLoop;
/*      */ import org.mozilla.javascript.ast.IdeErrorReporter;
/*      */ import org.mozilla.javascript.ast.IfStatement;
/*      */ import org.mozilla.javascript.ast.InfixExpression;
/*      */ import org.mozilla.javascript.ast.Jump;
/*      */ import org.mozilla.javascript.ast.KeywordLiteral;
/*      */ import org.mozilla.javascript.ast.Label;
/*      */ import org.mozilla.javascript.ast.LabeledStatement;
/*      */ import org.mozilla.javascript.ast.LetNode;
/*      */ import org.mozilla.javascript.ast.Loop;
/*      */ import org.mozilla.javascript.ast.Name;
/*      */ import org.mozilla.javascript.ast.NewExpression;
/*      */ import org.mozilla.javascript.ast.NumberLiteral;
/*      */ import org.mozilla.javascript.ast.ObjectLiteral;
/*      */ import org.mozilla.javascript.ast.ObjectProperty;
/*      */ import org.mozilla.javascript.ast.ParenthesizedExpression;
/*      */ import org.mozilla.javascript.ast.PropertyGet;
/*      */ import org.mozilla.javascript.ast.RegExpLiteral;
/*      */ import org.mozilla.javascript.ast.ReturnStatement;
/*      */ import org.mozilla.javascript.ast.Scope;
/*      */ import org.mozilla.javascript.ast.ScriptNode;
/*      */ import org.mozilla.javascript.ast.StringLiteral;
/*      */ import org.mozilla.javascript.ast.SwitchCase;
/*      */ import org.mozilla.javascript.ast.SwitchStatement;
/*      */ import org.mozilla.javascript.ast.Symbol;
/*      */ import org.mozilla.javascript.ast.TaggedTemplateLiteral;
/*      */ import org.mozilla.javascript.ast.TemplateCharacters;
/*      */ import org.mozilla.javascript.ast.TemplateLiteral;
/*      */ import org.mozilla.javascript.ast.ThrowStatement;
/*      */ import org.mozilla.javascript.ast.TryStatement;
/*      */ import org.mozilla.javascript.ast.UnaryExpression;
/*      */ import org.mozilla.javascript.ast.UpdateExpression;
/*      */ import org.mozilla.javascript.ast.VariableDeclaration;
/*      */ import org.mozilla.javascript.ast.VariableInitializer;
/*      */ import org.mozilla.javascript.ast.WhileLoop;
/*      */ import org.mozilla.javascript.ast.WithStatement;
/*      */ import org.mozilla.javascript.ast.XmlDotQuery;
/*      */ import org.mozilla.javascript.ast.XmlElemRef;
/*      */ import org.mozilla.javascript.ast.XmlExpression;
/*      */ import org.mozilla.javascript.ast.XmlFragment;
/*      */ import org.mozilla.javascript.ast.XmlLiteral;
/*      */ import org.mozilla.javascript.ast.XmlMemberGet;
/*      */ import org.mozilla.javascript.ast.XmlPropRef;
/*      */ import org.mozilla.javascript.ast.XmlString;
/*      */ import org.mozilla.javascript.ast.Yield;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Parser
/*      */ {
/*      */   public static final int ARGC_LIMIT = 65536;
/*      */   static final int CLEAR_TI_MASK = 65535;
/*      */   static final int TI_AFTER_EOL = 65536;
/*      */   static final int TI_CHECK_LABEL = 131072;
/*      */   CompilerEnvirons compilerEnv;
/*      */   private ErrorReporter errorReporter;
/*      */   private IdeErrorReporter errorCollector;
/*      */   private String sourceURI;
/*      */   private char[] sourceChars;
/*      */   boolean calledByCompileFunction;
/*      */   private boolean parseFinished;
/*      */   private TokenStream ts;
/*  126 */   private int currentFlaggedToken = 0;
/*      */   
/*      */   private int currentToken;
/*      */   
/*      */   private int syntaxErrorCount;
/*      */   
/*      */   private List<Comment> scannedComments;
/*      */   
/*      */   private Comment currentJsDocComment;
/*      */   
/*      */   protected int nestingOfFunction;
/*      */   
/*      */   private LabeledStatement currentLabel;
/*      */   
/*      */   private boolean inDestructuringAssignment;
/*      */   
/*      */   protected boolean inUseStrictDirective;
/*      */   
/*      */   ScriptNode currentScriptOrFn;
/*      */   
/*      */   Scope currentScope;
/*      */   private int endFlags;
/*      */   private boolean inForInit;
/*      */   private Map<String, LabeledStatement> labelSet;
/*      */   private List<Loop> loopSet;
/*      */   private List<Jump> loopAndSwitchSet;
/*      */   private int prevNameTokenStart;
/*  153 */   private String prevNameTokenString = ""; private int prevNameTokenLineno; private boolean defaultUseStrictDirective; private static final int PROP_ENTRY = 1;
/*      */   private static final int GET_ENTRY = 2;
/*      */   private static final int SET_ENTRY = 4;
/*      */   private static final int METHOD_ENTRY = 8;
/*      */   
/*      */   private static class ParserException extends RuntimeException {
/*      */     private static final long serialVersionUID = 5882582646773765630L;
/*      */     
/*      */     private ParserException() {} }
/*      */   
/*      */   public Parser() {
/*  164 */     this(new CompilerEnvirons());
/*      */   }
/*      */   
/*      */   public Parser(CompilerEnvirons compilerEnv) {
/*  168 */     this(compilerEnv, compilerEnv.getErrorReporter());
/*      */   }
/*      */   
/*      */   public Parser(CompilerEnvirons compilerEnv, ErrorReporter errorReporter) {
/*  172 */     this.compilerEnv = compilerEnv;
/*  173 */     this.errorReporter = errorReporter;
/*  174 */     if (errorReporter instanceof IdeErrorReporter) {
/*  175 */       this.errorCollector = (IdeErrorReporter)errorReporter;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void addStrictWarning(String messageId, String messageArg) {
/*  181 */     int beg = -1, end = -1;
/*  182 */     if (this.ts != null) {
/*  183 */       beg = this.ts.tokenBeg;
/*  184 */       end = this.ts.tokenEnd - this.ts.tokenBeg;
/*      */     } 
/*  186 */     addStrictWarning(messageId, messageArg, beg, end);
/*      */   }
/*      */   
/*      */   void addStrictWarning(String messageId, String messageArg, int position, int length) {
/*  190 */     if (this.compilerEnv.isStrictMode()) addWarning(messageId, messageArg, position, length); 
/*      */   }
/*      */   
/*      */   void addWarning(String messageId, String messageArg) {
/*  194 */     int beg = -1, end = -1;
/*  195 */     if (this.ts != null) {
/*  196 */       beg = this.ts.tokenBeg;
/*  197 */       end = this.ts.tokenEnd - this.ts.tokenBeg;
/*      */     } 
/*  199 */     addWarning(messageId, messageArg, beg, end);
/*      */   }
/*      */   
/*      */   void addWarning(String messageId, int position, int length) {
/*  203 */     addWarning(messageId, null, position, length);
/*      */   }
/*      */   
/*      */   void addWarning(String messageId, String messageArg, int position, int length) {
/*  207 */     String message = lookupMessage(messageId, messageArg);
/*  208 */     if (this.compilerEnv.reportWarningAsError()) {
/*  209 */       addError(messageId, messageArg, position, length);
/*  210 */     } else if (this.errorCollector != null) {
/*  211 */       this.errorCollector.warning(message, this.sourceURI, position, length);
/*  212 */     } else if (this.ts != null) {
/*  213 */       this.errorReporter.warning(message, this.sourceURI, this.ts.getLineno(), this.ts.getLine(), this.ts.getOffset());
/*      */     } else {
/*  215 */       this.errorReporter.warning(message, this.sourceURI, 1, "", 1);
/*      */     } 
/*      */   }
/*      */   
/*      */   void addError(String messageId) {
/*  220 */     if (this.ts == null) {
/*  221 */       addError(messageId, 0, 0);
/*      */     } else {
/*  223 */       addError(messageId, this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
/*      */     } 
/*      */   }
/*      */   
/*      */   void addError(String messageId, int position, int length) {
/*  228 */     addError(messageId, null, position, length);
/*      */   }
/*      */   
/*      */   void addError(String messageId, String messageArg) {
/*  232 */     if (this.ts == null) {
/*  233 */       addError(messageId, messageArg, 0, 0);
/*      */     } else {
/*  235 */       addError(messageId, messageArg, this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
/*      */     } 
/*      */   }
/*      */   
/*      */   void addError(String messageId, int c) {
/*  240 */     String messageArg = Character.toString((char)c);
/*  241 */     addError(messageId, messageArg);
/*      */   }
/*      */   
/*      */   void addError(String messageId, String messageArg, int position, int length) {
/*  245 */     this.syntaxErrorCount++;
/*  246 */     String message = lookupMessage(messageId, messageArg);
/*  247 */     if (this.errorCollector != null) {
/*  248 */       this.errorCollector.error(message, this.sourceURI, position, length);
/*      */     } else {
/*  250 */       int lineno = 1, offset = 1;
/*  251 */       String line = "";
/*  252 */       if (this.ts != null) {
/*  253 */         lineno = this.ts.getLineno();
/*  254 */         line = this.ts.getLine();
/*  255 */         offset = this.ts.getOffset();
/*      */       } 
/*  257 */       this.errorReporter.error(message, this.sourceURI, lineno, line, offset);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addStrictWarning(String messageId, String messageArg, int position, int length, int line, String lineSource, int lineOffset) {
/*  269 */     if (this.compilerEnv.isStrictMode()) {
/*  270 */       addWarning(messageId, messageArg, position, length, line, lineSource, lineOffset);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addWarning(String messageId, String messageArg, int position, int length, int line, String lineSource, int lineOffset) {
/*  282 */     String message = lookupMessage(messageId, messageArg);
/*  283 */     if (this.compilerEnv.reportWarningAsError()) {
/*  284 */       addError(messageId, messageArg, position, length, line, lineSource, lineOffset);
/*  285 */     } else if (this.errorCollector != null) {
/*  286 */       this.errorCollector.warning(message, this.sourceURI, position, length);
/*      */     } else {
/*  288 */       this.errorReporter.warning(message, this.sourceURI, line, lineSource, lineOffset);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addError(String messageId, String messageArg, int position, int length, int line, String lineSource, int lineOffset) {
/*  300 */     this.syntaxErrorCount++;
/*  301 */     String message = lookupMessage(messageId, messageArg);
/*  302 */     if (this.errorCollector != null) {
/*  303 */       this.errorCollector.error(message, this.sourceURI, position, length);
/*      */     } else {
/*  305 */       this.errorReporter.error(message, this.sourceURI, line, lineSource, lineOffset);
/*      */     } 
/*      */   }
/*      */   
/*      */   String lookupMessage(String messageId) {
/*  310 */     return lookupMessage(messageId, null);
/*      */   }
/*      */   
/*      */   String lookupMessage(String messageId, String messageArg) {
/*  314 */     return (messageArg == null) ? 
/*  315 */       ScriptRuntime.getMessageById(messageId, new Object[0]) : 
/*  316 */       ScriptRuntime.getMessageById(messageId, new Object[] { messageArg });
/*      */   }
/*      */   
/*      */   void reportError(String messageId) {
/*  320 */     reportError(messageId, null);
/*      */   }
/*      */   
/*      */   void reportError(String messageId, String messageArg) {
/*  324 */     if (this.ts == null) {
/*  325 */       reportError(messageId, messageArg, 1, 1);
/*      */     } else {
/*  327 */       reportError(messageId, messageArg, this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
/*      */     } 
/*      */   }
/*      */   
/*      */   void reportError(String messageId, int position, int length) {
/*  332 */     reportError(messageId, null, position, length);
/*      */   }
/*      */   
/*      */   void reportError(String messageId, String messageArg, int position, int length) {
/*  336 */     addError(messageId, messageArg, position, length);
/*      */     
/*  338 */     if (!this.compilerEnv.recoverFromErrors()) {
/*  339 */       throw new ParserException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getNodeEnd(AstNode n) {
/*  347 */     return n.getPosition() + n.getLength();
/*      */   }
/*      */   
/*      */   private void recordComment(int lineno, String comment) {
/*  351 */     if (this.scannedComments == null) {
/*  352 */       this.scannedComments = new ArrayList<>();
/*      */     }
/*      */     
/*  355 */     Comment commentNode = new Comment(this.ts.tokenBeg, this.ts.getTokenLength(), this.ts.commentType, comment);
/*  356 */     if (this.ts.commentType == Token.CommentType.JSDOC && this.compilerEnv
/*  357 */       .isRecordingLocalJsDocComments()) {
/*      */       
/*  359 */       Comment jsDocCommentNode = new Comment(this.ts.tokenBeg, this.ts.getTokenLength(), this.ts.commentType, comment);
/*  360 */       this.currentJsDocComment = jsDocCommentNode;
/*  361 */       this.currentJsDocComment.setLineno(lineno);
/*      */     } 
/*  363 */     commentNode.setLineno(lineno);
/*  364 */     this.scannedComments.add(commentNode);
/*      */   }
/*      */   
/*      */   private Comment getAndResetJsDoc() {
/*  368 */     Comment saved = this.currentJsDocComment;
/*  369 */     this.currentJsDocComment = null;
/*  370 */     return saved;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int peekToken() throws IOException {
/*  391 */     if (this.currentFlaggedToken != 0) {
/*  392 */       return this.currentToken;
/*      */     }
/*      */     
/*  395 */     int lineno = this.ts.getLineno();
/*  396 */     int tt = this.ts.getToken();
/*  397 */     boolean sawEOL = false;
/*      */ 
/*      */     
/*  400 */     while (tt == 1 || tt == 165) {
/*  401 */       if (tt == 1) {
/*  402 */         lineno++;
/*  403 */         sawEOL = true;
/*  404 */         tt = this.ts.getToken(); continue;
/*      */       } 
/*  406 */       if (this.compilerEnv.isRecordingComments()) {
/*  407 */         String comment = this.ts.getAndResetCurrentComment();
/*  408 */         recordComment(lineno, comment);
/*      */         break;
/*      */       } 
/*  411 */       tt = this.ts.getToken();
/*      */     } 
/*      */ 
/*      */     
/*  415 */     this.currentToken = tt;
/*  416 */     this.currentFlaggedToken = tt | (sawEOL ? 65536 : 0);
/*  417 */     return this.currentToken;
/*      */   }
/*      */   
/*      */   private int peekFlaggedToken() throws IOException {
/*  421 */     peekToken();
/*  422 */     return this.currentFlaggedToken;
/*      */   }
/*      */   
/*      */   private void consumeToken() {
/*  426 */     this.currentFlaggedToken = 0;
/*      */   }
/*      */   
/*      */   private int nextToken() throws IOException {
/*  430 */     int tt = peekToken();
/*  431 */     consumeToken();
/*  432 */     return tt;
/*      */   }
/*      */   
/*      */   private boolean matchToken(int toMatch, boolean ignoreComment) throws IOException {
/*  436 */     int tt = peekToken();
/*  437 */     while (tt == 165 && ignoreComment) {
/*  438 */       consumeToken();
/*  439 */       tt = peekToken();
/*      */     } 
/*  441 */     if (tt != toMatch) {
/*  442 */       return false;
/*      */     }
/*  444 */     consumeToken();
/*  445 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int peekTokenOrEOL() throws IOException {
/*  454 */     int tt = peekToken();
/*      */     
/*  456 */     if ((this.currentFlaggedToken & 0x10000) != 0) {
/*  457 */       tt = 1;
/*      */     }
/*  459 */     return tt;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean mustMatchToken(int toMatch, String messageId, boolean ignoreComment) throws IOException {
/*  464 */     return mustMatchToken(toMatch, messageId, this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg, ignoreComment);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean mustMatchToken(int toMatch, String msgId, int pos, int len, boolean ignoreComment) throws IOException {
/*  470 */     if (matchToken(toMatch, ignoreComment)) {
/*  471 */       return true;
/*      */     }
/*  473 */     reportError(msgId, pos, len);
/*  474 */     return false;
/*      */   }
/*      */   
/*      */   private void mustHaveXML() {
/*  478 */     if (!this.compilerEnv.isXmlAvailable()) {
/*  479 */       reportError("msg.XML.not.available");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean eof() {
/*  484 */     return this.ts.eof();
/*      */   }
/*      */   
/*      */   boolean insideFunction() {
/*  488 */     return (this.nestingOfFunction != 0);
/*      */   }
/*      */   
/*      */   void pushScope(Scope scope) {
/*  492 */     Scope parent = scope.getParentScope();
/*      */ 
/*      */     
/*  495 */     if (parent != null) {
/*  496 */       if (parent != this.currentScope) codeBug(); 
/*      */     } else {
/*  498 */       this.currentScope.addChildScope(scope);
/*      */     } 
/*  500 */     this.currentScope = scope;
/*      */   }
/*      */   
/*      */   void popScope() {
/*  504 */     this.currentScope = this.currentScope.getParentScope();
/*      */   }
/*      */   
/*      */   private void enterLoop(Loop loop) {
/*  508 */     if (this.loopSet == null) this.loopSet = new ArrayList<>(); 
/*  509 */     this.loopSet.add(loop);
/*  510 */     if (this.loopAndSwitchSet == null) this.loopAndSwitchSet = new ArrayList<>(); 
/*  511 */     this.loopAndSwitchSet.add(loop);
/*  512 */     pushScope((Scope)loop);
/*  513 */     if (this.currentLabel != null) {
/*  514 */       this.currentLabel.setStatement((AstNode)loop);
/*  515 */       this.currentLabel.getFirstLabel().setLoop((Jump)loop);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  522 */       loop.setRelative(-this.currentLabel.getPosition());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void exitLoop() {
/*  527 */     this.loopSet.remove(this.loopSet.size() - 1);
/*  528 */     this.loopAndSwitchSet.remove(this.loopAndSwitchSet.size() - 1);
/*  529 */     popScope();
/*      */   }
/*      */   
/*      */   private void restoreRelativeLoopPosition(Loop loop) {
/*  533 */     if (loop.getParent() != null) {
/*  534 */       loop.setRelative(loop.getParent().getPosition());
/*      */     }
/*      */   }
/*      */   
/*      */   private void enterSwitch(SwitchStatement node) {
/*  539 */     if (this.loopAndSwitchSet == null) this.loopAndSwitchSet = new ArrayList<>(); 
/*  540 */     this.loopAndSwitchSet.add(node);
/*      */   }
/*      */   
/*      */   private void exitSwitch() {
/*  544 */     this.loopAndSwitchSet.remove(this.loopAndSwitchSet.size() - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AstRoot parse(String sourceString, String sourceURI, int lineno) {
/*  555 */     if (this.parseFinished) throw new IllegalStateException("parser reused"); 
/*  556 */     this.sourceURI = sourceURI;
/*  557 */     if (this.compilerEnv.isIdeMode()) {
/*  558 */       this.sourceChars = sourceString.toCharArray();
/*      */     }
/*  560 */     this.ts = new TokenStream(this, null, sourceString, lineno);
/*      */     try {
/*  562 */       return parse();
/*  563 */     } catch (IOException iox) {
/*      */       
/*  565 */       throw new IllegalStateException();
/*      */     } finally {
/*  567 */       this.parseFinished = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public AstRoot parse(Reader sourceReader, String sourceURI, int lineno) throws IOException {
/*  580 */     if (this.parseFinished) throw new IllegalStateException("parser reused"); 
/*  581 */     if (this.compilerEnv.isIdeMode()) {
/*  582 */       return parse(Kit.readReader(sourceReader), sourceURI, lineno);
/*      */     }
/*      */     try {
/*  585 */       this.sourceURI = sourceURI;
/*  586 */       this.ts = new TokenStream(this, sourceReader, null, lineno);
/*  587 */       return parse();
/*      */     } finally {
/*  589 */       this.parseFinished = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstRoot parse() throws IOException {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_1
/*      */     //   2: new org/mozilla/javascript/ast/AstRoot
/*      */     //   5: dup
/*      */     //   6: iload_1
/*      */     //   7: invokespecial <init> : (I)V
/*      */     //   10: astore_2
/*      */     //   11: aload_0
/*      */     //   12: aload_0
/*      */     //   13: aload_2
/*      */     //   14: dup_x1
/*      */     //   15: putfield currentScriptOrFn : Lorg/mozilla/javascript/ast/ScriptNode;
/*      */     //   18: putfield currentScope : Lorg/mozilla/javascript/ast/Scope;
/*      */     //   21: aload_0
/*      */     //   22: getfield ts : Lorg/mozilla/javascript/TokenStream;
/*      */     //   25: getfield lineno : I
/*      */     //   28: istore_3
/*      */     //   29: iload_1
/*      */     //   30: istore #4
/*      */     //   32: iconst_1
/*      */     //   33: istore #5
/*      */     //   35: aload_0
/*      */     //   36: getfield inUseStrictDirective : Z
/*      */     //   39: istore #6
/*      */     //   41: aload_0
/*      */     //   42: aload_0
/*      */     //   43: getfield defaultUseStrictDirective : Z
/*      */     //   46: putfield inUseStrictDirective : Z
/*      */     //   49: aload_0
/*      */     //   50: getfield inUseStrictDirective : Z
/*      */     //   53: ifeq -> 61
/*      */     //   56: aload_2
/*      */     //   57: iconst_1
/*      */     //   58: invokevirtual setInStrictMode : (Z)V
/*      */     //   61: aload_0
/*      */     //   62: invokespecial peekToken : ()I
/*      */     //   65: istore #7
/*      */     //   67: iload #7
/*      */     //   69: ifgt -> 75
/*      */     //   72: goto -> 223
/*      */     //   75: iload #7
/*      */     //   77: bipush #113
/*      */     //   79: if_icmpne -> 112
/*      */     //   82: aload_0
/*      */     //   83: invokespecial consumeToken : ()V
/*      */     //   86: aload_0
/*      */     //   87: aload_0
/*      */     //   88: getfield calledByCompileFunction : Z
/*      */     //   91: ifeq -> 98
/*      */     //   94: iconst_2
/*      */     //   95: goto -> 99
/*      */     //   98: iconst_1
/*      */     //   99: invokespecial function : (I)Lorg/mozilla/javascript/ast/FunctionNode;
/*      */     //   102: astore #8
/*      */     //   104: goto -> 201
/*      */     //   107: astore #9
/*      */     //   109: goto -> 223
/*      */     //   112: iload #7
/*      */     //   114: sipush #165
/*      */     //   117: if_icmpne -> 152
/*      */     //   120: aload_0
/*      */     //   121: getfield scannedComments : Ljava/util/List;
/*      */     //   124: aload_0
/*      */     //   125: getfield scannedComments : Ljava/util/List;
/*      */     //   128: invokeinterface size : ()I
/*      */     //   133: iconst_1
/*      */     //   134: isub
/*      */     //   135: invokeinterface get : (I)Ljava/lang/Object;
/*      */     //   140: checkcast org/mozilla/javascript/ast/AstNode
/*      */     //   143: astore #8
/*      */     //   145: aload_0
/*      */     //   146: invokespecial consumeToken : ()V
/*      */     //   149: goto -> 201
/*      */     //   152: aload_0
/*      */     //   153: invokespecial statement : ()Lorg/mozilla/javascript/ast/AstNode;
/*      */     //   156: astore #8
/*      */     //   158: iload #5
/*      */     //   160: ifeq -> 201
/*      */     //   163: aload #8
/*      */     //   165: invokestatic getDirective : (Lorg/mozilla/javascript/ast/AstNode;)Ljava/lang/String;
/*      */     //   168: astore #9
/*      */     //   170: aload #9
/*      */     //   172: ifnonnull -> 181
/*      */     //   175: iconst_0
/*      */     //   176: istore #5
/*      */     //   178: goto -> 201
/*      */     //   181: aload #9
/*      */     //   183: ldc 'use strict'
/*      */     //   185: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   188: ifeq -> 201
/*      */     //   191: aload_0
/*      */     //   192: iconst_1
/*      */     //   193: putfield inUseStrictDirective : Z
/*      */     //   196: aload_2
/*      */     //   197: iconst_1
/*      */     //   198: invokevirtual setInStrictMode : (Z)V
/*      */     //   201: aload #8
/*      */     //   203: invokestatic getNodeEnd : (Lorg/mozilla/javascript/ast/AstNode;)I
/*      */     //   206: istore #4
/*      */     //   208: aload_2
/*      */     //   209: aload #8
/*      */     //   211: invokevirtual addChildToBack : (Lorg/mozilla/javascript/Node;)V
/*      */     //   214: aload #8
/*      */     //   216: aload_2
/*      */     //   217: invokevirtual setParent : (Lorg/mozilla/javascript/ast/AstNode;)V
/*      */     //   220: goto -> 61
/*      */     //   223: aload_0
/*      */     //   224: iload #6
/*      */     //   226: putfield inUseStrictDirective : Z
/*      */     //   229: goto -> 291
/*      */     //   232: astore #7
/*      */     //   234: aload_0
/*      */     //   235: ldc 'msg.too.deep.parser.recursion'
/*      */     //   237: invokevirtual lookupMessage : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   240: astore #8
/*      */     //   242: aload_0
/*      */     //   243: getfield compilerEnv : Lorg/mozilla/javascript/CompilerEnvirons;
/*      */     //   246: invokevirtual isIdeMode : ()Z
/*      */     //   249: ifne -> 271
/*      */     //   252: aload #8
/*      */     //   254: aload_0
/*      */     //   255: getfield sourceURI : Ljava/lang/String;
/*      */     //   258: aload_0
/*      */     //   259: getfield ts : Lorg/mozilla/javascript/TokenStream;
/*      */     //   262: getfield lineno : I
/*      */     //   265: aconst_null
/*      */     //   266: iconst_0
/*      */     //   267: invokestatic reportRuntimeError : (Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;I)Lorg/mozilla/javascript/EvaluatorException;
/*      */     //   270: athrow
/*      */     //   271: aload_0
/*      */     //   272: iload #6
/*      */     //   274: putfield inUseStrictDirective : Z
/*      */     //   277: goto -> 291
/*      */     //   280: astore #10
/*      */     //   282: aload_0
/*      */     //   283: iload #6
/*      */     //   285: putfield inUseStrictDirective : Z
/*      */     //   288: aload #10
/*      */     //   290: athrow
/*      */     //   291: aload_0
/*      */     //   292: getfield syntaxErrorCount : I
/*      */     //   295: ifeq -> 346
/*      */     //   298: aload_0
/*      */     //   299: getfield syntaxErrorCount : I
/*      */     //   302: invokestatic valueOf : (I)Ljava/lang/String;
/*      */     //   305: astore #7
/*      */     //   307: aload_0
/*      */     //   308: ldc 'msg.got.syntax.errors'
/*      */     //   310: aload #7
/*      */     //   312: invokevirtual lookupMessage : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   315: astore #7
/*      */     //   317: aload_0
/*      */     //   318: getfield compilerEnv : Lorg/mozilla/javascript/CompilerEnvirons;
/*      */     //   321: invokevirtual isIdeMode : ()Z
/*      */     //   324: ifne -> 346
/*      */     //   327: aload_0
/*      */     //   328: getfield errorReporter : Lorg/mozilla/javascript/ErrorReporter;
/*      */     //   331: aload #7
/*      */     //   333: aload_0
/*      */     //   334: getfield sourceURI : Ljava/lang/String;
/*      */     //   337: iload_3
/*      */     //   338: aconst_null
/*      */     //   339: iconst_0
/*      */     //   340: invokeinterface runtimeError : (Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;I)Lorg/mozilla/javascript/EvaluatorException;
/*      */     //   345: athrow
/*      */     //   346: aload_0
/*      */     //   347: getfield scannedComments : Ljava/util/List;
/*      */     //   350: ifnull -> 432
/*      */     //   353: aload_0
/*      */     //   354: getfield scannedComments : Ljava/util/List;
/*      */     //   357: invokeinterface size : ()I
/*      */     //   362: iconst_1
/*      */     //   363: isub
/*      */     //   364: istore #7
/*      */     //   366: iload #4
/*      */     //   368: aload_0
/*      */     //   369: getfield scannedComments : Ljava/util/List;
/*      */     //   372: iload #7
/*      */     //   374: invokeinterface get : (I)Ljava/lang/Object;
/*      */     //   379: checkcast org/mozilla/javascript/ast/AstNode
/*      */     //   382: invokestatic getNodeEnd : (Lorg/mozilla/javascript/ast/AstNode;)I
/*      */     //   385: invokestatic max : (II)I
/*      */     //   388: istore #4
/*      */     //   390: aload_0
/*      */     //   391: getfield scannedComments : Ljava/util/List;
/*      */     //   394: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   399: astore #8
/*      */     //   401: aload #8
/*      */     //   403: invokeinterface hasNext : ()Z
/*      */     //   408: ifeq -> 432
/*      */     //   411: aload #8
/*      */     //   413: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   418: checkcast org/mozilla/javascript/ast/Comment
/*      */     //   421: astore #9
/*      */     //   423: aload_2
/*      */     //   424: aload #9
/*      */     //   426: invokevirtual addComment : (Lorg/mozilla/javascript/ast/Comment;)V
/*      */     //   429: goto -> 401
/*      */     //   432: aload_2
/*      */     //   433: iload #4
/*      */     //   435: iload_1
/*      */     //   436: isub
/*      */     //   437: invokevirtual setLength : (I)V
/*      */     //   440: aload_2
/*      */     //   441: aload_0
/*      */     //   442: getfield sourceURI : Ljava/lang/String;
/*      */     //   445: invokevirtual setSourceName : (Ljava/lang/String;)V
/*      */     //   448: aload_2
/*      */     //   449: iload_3
/*      */     //   450: invokevirtual setBaseLineno : (I)V
/*      */     //   453: aload_2
/*      */     //   454: aload_0
/*      */     //   455: getfield ts : Lorg/mozilla/javascript/TokenStream;
/*      */     //   458: getfield lineno : I
/*      */     //   461: invokevirtual setEndLineno : (I)V
/*      */     //   464: aload_2
/*      */     //   465: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #594	-> 0
/*      */     //   #595	-> 2
/*      */     //   #596	-> 11
/*      */     //   #598	-> 21
/*      */     //   #599	-> 29
/*      */     //   #601	-> 32
/*      */     //   #602	-> 35
/*      */     //   #604	-> 41
/*      */     //   #605	-> 49
/*      */     //   #606	-> 56
/*      */     //   #611	-> 61
/*      */     //   #612	-> 67
/*      */     //   #613	-> 72
/*      */     //   #617	-> 75
/*      */     //   #618	-> 82
/*      */     //   #620	-> 86
/*      */     //   #621	-> 99
/*      */     //   #627	-> 104
/*      */     //   #625	-> 107
/*      */     //   #626	-> 109
/*      */     //   #628	-> 112
/*      */     //   #629	-> 120
/*      */     //   #630	-> 145
/*      */     //   #632	-> 152
/*      */     //   #633	-> 158
/*      */     //   #634	-> 163
/*      */     //   #635	-> 170
/*      */     //   #636	-> 175
/*      */     //   #637	-> 181
/*      */     //   #638	-> 191
/*      */     //   #639	-> 196
/*      */     //   #643	-> 201
/*      */     //   #644	-> 208
/*      */     //   #645	-> 214
/*      */     //   #646	-> 220
/*      */     //   #652	-> 223
/*      */     //   #653	-> 229
/*      */     //   #647	-> 232
/*      */     //   #648	-> 234
/*      */     //   #649	-> 242
/*      */     //   #650	-> 252
/*      */     //   #652	-> 271
/*      */     //   #653	-> 277
/*      */     //   #652	-> 280
/*      */     //   #653	-> 288
/*      */     //   #655	-> 291
/*      */     //   #656	-> 298
/*      */     //   #657	-> 307
/*      */     //   #658	-> 317
/*      */     //   #659	-> 327
/*      */     //   #663	-> 346
/*      */     //   #666	-> 353
/*      */     //   #667	-> 366
/*      */     //   #668	-> 390
/*      */     //   #669	-> 423
/*      */     //   #670	-> 429
/*      */     //   #673	-> 432
/*      */     //   #674	-> 440
/*      */     //   #675	-> 448
/*      */     //   #676	-> 453
/*      */     //   #677	-> 464
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   104	3	8	n	Lorg/mozilla/javascript/ast/AstNode;
/*      */     //   109	3	9	e	Lorg/mozilla/javascript/Parser$ParserException;
/*      */     //   145	7	8	n	Lorg/mozilla/javascript/ast/AstNode;
/*      */     //   170	31	9	directive	Ljava/lang/String;
/*      */     //   67	153	7	tt	I
/*      */     //   158	62	8	n	Lorg/mozilla/javascript/ast/AstNode;
/*      */     //   242	29	8	msg	Ljava/lang/String;
/*      */     //   234	37	7	ex	Ljava/lang/StackOverflowError;
/*      */     //   307	39	7	msg	Ljava/lang/String;
/*      */     //   423	6	9	c	Lorg/mozilla/javascript/ast/Comment;
/*      */     //   366	66	7	last	I
/*      */     //   0	466	0	this	Lorg/mozilla/javascript/Parser;
/*      */     //   2	464	1	pos	I
/*      */     //   11	455	2	root	Lorg/mozilla/javascript/ast/AstRoot;
/*      */     //   29	437	3	baseLineno	I
/*      */     //   32	434	4	end	I
/*      */     //   35	431	5	inDirectivePrologue	Z
/*      */     //   41	425	6	savedStrictMode	Z
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   61	223	232	java/lang/StackOverflowError
/*      */     //   61	223	280	finally
/*      */     //   86	104	107	org/mozilla/javascript/Parser$ParserException
/*      */     //   232	271	280	finally
/*      */     //   280	282	280	finally
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode parseFunctionBody(int type, FunctionNode fnNode) throws IOException {
/*  681 */     boolean isExpressionClosure = false;
/*  682 */     if (!matchToken(88, true)) {
/*  683 */       if (this.compilerEnv.getLanguageVersion() < 180 && type != 4) {
/*      */         
/*  685 */         reportError("msg.no.brace.body");
/*      */       } else {
/*  687 */         isExpressionClosure = true;
/*      */       } 
/*      */     }
/*  690 */     boolean isArrow = (type == 4);
/*  691 */     this.nestingOfFunction++;
/*  692 */     int pos = this.ts.tokenBeg;
/*  693 */     Block pn = new Block(pos);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  699 */     boolean inDirectivePrologue = true;
/*  700 */     boolean savedStrictMode = this.inUseStrictDirective;
/*  701 */     this.inUseStrictDirective = false;
/*      */     
/*  703 */     pn.setLineno(this.ts.lineno);
/*      */     try {
/*  705 */       if (isExpressionClosure) {
/*  706 */         AstNode returnValue = assignExpr();
/*      */ 
/*      */         
/*  709 */         ReturnStatement n = new ReturnStatement(returnValue.getPosition(), returnValue.getLength(), returnValue);
/*      */         
/*  711 */         n.putProp(25, Boolean.TRUE);
/*  712 */         pn.putProp(25, Boolean.TRUE);
/*  713 */         if (isArrow) {
/*  714 */           n.putProp(27, Boolean.TRUE);
/*      */         }
/*  716 */         pn.addStatement((AstNode)n);
/*      */       } else {
/*      */         while (true) {
/*      */           AstNode astNode1; FunctionNode functionNode;
/*      */           AstNode n;
/*  721 */           int tt = peekToken();
/*  722 */           switch (tt) {
/*      */             case -1:
/*      */             case 0:
/*      */             case 89:
/*      */               break;
/*      */             case 165:
/*  728 */               consumeToken();
/*  729 */               astNode1 = (AstNode)this.scannedComments.get(this.scannedComments.size() - 1);
/*      */               break;
/*      */             case 113:
/*  732 */               consumeToken();
/*  733 */               functionNode = function(1);
/*      */               break;
/*      */             default:
/*  736 */               n = statement();
/*  737 */               if (inDirectivePrologue) {
/*  738 */                 String directive = getDirective(n);
/*  739 */                 if (directive == null) {
/*  740 */                   inDirectivePrologue = false; break;
/*  741 */                 }  if (directive.equals("use strict")) {
/*  742 */                   this.inUseStrictDirective = true;
/*  743 */                   fnNode.setInStrictMode(true);
/*  744 */                   if (!savedStrictMode) {
/*  745 */                     setRequiresActivation();
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */               break;
/*      */           } 
/*  751 */           pn.addStatement(n);
/*      */         } 
/*      */       } 
/*  754 */     } catch (ParserException parserException) {
/*      */     
/*      */     } finally {
/*  757 */       this.nestingOfFunction--;
/*  758 */       this.inUseStrictDirective = savedStrictMode;
/*      */     } 
/*      */     
/*  761 */     int end = this.ts.tokenEnd;
/*  762 */     getAndResetJsDoc();
/*  763 */     if (!isExpressionClosure && mustMatchToken(89, "msg.no.brace.after.body", true))
/*  764 */       end = this.ts.tokenEnd; 
/*  765 */     pn.setLength(end - pos);
/*  766 */     return (AstNode)pn;
/*      */   }
/*      */   
/*      */   private static String getDirective(AstNode n) {
/*  770 */     if (n instanceof ExpressionStatement) {
/*  771 */       AstNode e = ((ExpressionStatement)n).getExpression();
/*  772 */       if (e instanceof StringLiteral) {
/*  773 */         return ((StringLiteral)e).getValue();
/*      */       }
/*      */     } 
/*  776 */     return null;
/*      */   }
/*      */   
/*      */   private void parseFunctionParams(FunctionNode fnNode) throws IOException {
/*  780 */     if (matchToken(91, true)) {
/*  781 */       fnNode.setRp(this.ts.tokenBeg - fnNode.getPosition());
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  786 */     Map<String, Node> destructuring = null;
/*  787 */     Set<String> paramNames = new HashSet<>();
/*      */     do {
/*  789 */       int tt = peekToken();
/*  790 */       if (tt == 86 || tt == 88) {
/*  791 */         AstNode expr = destructuringPrimaryExpr();
/*  792 */         markDestructuring(expr);
/*  793 */         fnNode.addParam(expr);
/*      */ 
/*      */ 
/*      */         
/*  797 */         if (destructuring == null) {
/*  798 */           destructuring = new HashMap<>();
/*      */         }
/*  800 */         String pname = this.currentScriptOrFn.getNextTempName();
/*  801 */         defineSymbol(90, pname, false);
/*  802 */         destructuring.put(pname, expr);
/*      */       }
/*  804 */       else if (mustMatchToken(39, "msg.no.parm", true)) {
/*  805 */         Name paramNameNode = createNameNode();
/*  806 */         Comment jsdocNodeForName = getAndResetJsDoc();
/*  807 */         if (jsdocNodeForName != null) {
/*  808 */           paramNameNode.setJsDocNode(jsdocNodeForName);
/*      */         }
/*  810 */         fnNode.addParam((AstNode)paramNameNode);
/*  811 */         String paramName = this.ts.getString();
/*  812 */         defineSymbol(90, paramName);
/*  813 */         if (this.inUseStrictDirective) {
/*  814 */           if ("eval".equals(paramName) || "arguments".equals(paramName)) {
/*  815 */             reportError("msg.bad.id.strict", paramName);
/*      */           }
/*  817 */           if (paramNames.contains(paramName))
/*  818 */             addError("msg.dup.param.strict", paramName); 
/*  819 */           paramNames.add(paramName);
/*      */         } 
/*      */       } else {
/*  822 */         fnNode.addParam((AstNode)makeErrorNode());
/*      */       }
/*      */     
/*  825 */     } while (matchToken(92, true));
/*      */     
/*  827 */     if (destructuring != null) {
/*  828 */       Node destructuringNode = new Node(92);
/*      */       
/*  830 */       for (Map.Entry<String, Node> param : destructuring.entrySet()) {
/*      */         
/*  832 */         Node assign = createDestructuringAssignment(126, param
/*  833 */             .getValue(), createName(param.getKey()));
/*  834 */         destructuringNode.addChildToBack(assign);
/*      */       } 
/*  836 */       fnNode.putProp(23, destructuringNode);
/*      */     } 
/*      */     
/*  839 */     if (mustMatchToken(91, "msg.no.paren.after.parms", true)) {
/*  840 */       fnNode.setRp(this.ts.tokenBeg - fnNode.getPosition());
/*      */     }
/*      */   }
/*      */   
/*      */   private FunctionNode function(int type) throws IOException {
/*  845 */     return function(type, false);
/*      */   }
/*      */   
/*      */   private FunctionNode function(int type, boolean isGenerator) throws IOException {
/*  849 */     int syntheticType = type;
/*  850 */     int baseLineno = this.ts.lineno;
/*  851 */     int functionSourceStart = this.ts.tokenBeg;
/*  852 */     Name name = null;
/*  853 */     AstNode memberExprNode = null;
/*      */     
/*  855 */     if (matchToken(39, true)) {
/*  856 */       name = createNameNode(true, 39);
/*  857 */       if (this.inUseStrictDirective) {
/*  858 */         String id = name.getIdentifier();
/*  859 */         if ("eval".equals(id) || "arguments".equals(id)) {
/*  860 */           reportError("msg.bad.id.strict", id);
/*      */         }
/*      */       } 
/*  863 */       if (!matchToken(90, true)) {
/*  864 */         if (this.compilerEnv.isAllowMemberExprAsFunctionName()) {
/*  865 */           Name name1 = name;
/*  866 */           name = null;
/*  867 */           memberExprNode = memberExprTail(false, (AstNode)name1);
/*      */         } 
/*  869 */         mustMatchToken(90, "msg.no.paren.parms", true);
/*      */       } 
/*  871 */     } else if (!matchToken(90, true)) {
/*      */       
/*  873 */       if (matchToken(23, true) && this.compilerEnv
/*  874 */         .getLanguageVersion() >= 200)
/*      */       {
/*  876 */         return function(type, true);
/*      */       }
/*  878 */       if (this.compilerEnv.isAllowMemberExprAsFunctionName())
/*      */       {
/*      */ 
/*      */         
/*  882 */         memberExprNode = memberExpr(false);
/*      */       }
/*  884 */       mustMatchToken(90, "msg.no.paren.parms", true);
/*      */     } 
/*  886 */     int lpPos = (this.currentToken == 90) ? this.ts.tokenBeg : -1;
/*      */     
/*  888 */     if (memberExprNode != null) {
/*  889 */       syntheticType = 2;
/*      */     }
/*      */     
/*  892 */     if (syntheticType != 2 && name != null && name
/*      */       
/*  894 */       .length() > 0)
/*      */     {
/*  896 */       defineSymbol(113, name.getIdentifier());
/*      */     }
/*      */     
/*  899 */     FunctionNode fnNode = new FunctionNode(functionSourceStart, name);
/*  900 */     fnNode.setFunctionType(type);
/*  901 */     if (isGenerator) {
/*  902 */       fnNode.setIsES6Generator();
/*      */     }
/*  904 */     if (lpPos != -1) fnNode.setLp(lpPos - functionSourceStart);
/*      */     
/*  906 */     fnNode.setJsDocNode(getAndResetJsDoc());
/*      */     
/*  908 */     PerFunctionVariables savedVars = new PerFunctionVariables(fnNode);
/*      */     try {
/*  910 */       parseFunctionParams(fnNode);
/*  911 */       fnNode.setBody(parseFunctionBody(type, fnNode));
/*  912 */       fnNode.setEncodedSourceBounds(functionSourceStart, this.ts.tokenEnd);
/*  913 */       fnNode.setLength(this.ts.tokenEnd - functionSourceStart);
/*      */       
/*  915 */       if (this.compilerEnv.isStrictMode() && !fnNode.getBody().hasConsistentReturnUsage()) {
/*      */         
/*  917 */         String msg = (name != null && name.length() > 0) ? "msg.no.return.value" : "msg.anon.no.return.value";
/*      */ 
/*      */         
/*  920 */         addStrictWarning(msg, (name == null) ? "" : name.getIdentifier());
/*      */       } 
/*      */     } finally {
/*  923 */       savedVars.restore();
/*      */     } 
/*      */     
/*  926 */     if (memberExprNode != null) {
/*      */       
/*  928 */       Kit.codeBug();
/*  929 */       fnNode.setMemberExprNode(memberExprNode);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  941 */     fnNode.setSourceName(this.sourceURI);
/*  942 */     fnNode.setBaseLineno(baseLineno);
/*  943 */     fnNode.setEndLineno(this.ts.lineno);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  949 */     if (this.compilerEnv.isIdeMode()) {
/*  950 */       fnNode.setParentScope(this.currentScope);
/*      */     }
/*  952 */     return fnNode;
/*      */   }
/*      */   
/*      */   private AstNode arrowFunction(AstNode params) throws IOException {
/*  956 */     int baseLineno = this.ts.lineno;
/*      */     
/*  958 */     int functionSourceStart = (params != null) ? params.getPosition() : -1;
/*      */     
/*  960 */     FunctionNode fnNode = new FunctionNode(functionSourceStart);
/*  961 */     fnNode.setFunctionType(4);
/*  962 */     fnNode.setJsDocNode(getAndResetJsDoc());
/*      */ 
/*      */ 
/*      */     
/*  966 */     Map<String, Node> destructuring = new HashMap<>();
/*  967 */     Set<String> paramNames = new HashSet<>();
/*      */     
/*  969 */     PerFunctionVariables savedVars = new PerFunctionVariables(fnNode);
/*      */     try {
/*  971 */       if (params instanceof ParenthesizedExpression) {
/*  972 */         fnNode.setParens(0, params.getLength());
/*  973 */         AstNode p = ((ParenthesizedExpression)params).getExpression();
/*  974 */         if (!(p instanceof EmptyExpression)) {
/*  975 */           arrowFunctionParams(fnNode, p, destructuring, paramNames);
/*      */         }
/*      */       } else {
/*  978 */         arrowFunctionParams(fnNode, params, destructuring, paramNames);
/*      */       } 
/*      */       
/*  981 */       if (!destructuring.isEmpty()) {
/*  982 */         Node destructuringNode = new Node(92);
/*      */         
/*  984 */         for (Map.Entry<String, Node> param : destructuring.entrySet()) {
/*      */           
/*  986 */           Node assign = createDestructuringAssignment(126, param
/*  987 */               .getValue(), createName(param.getKey()));
/*  988 */           destructuringNode.addChildToBack(assign);
/*      */         } 
/*  990 */         fnNode.putProp(23, destructuringNode);
/*      */       } 
/*      */       
/*  993 */       fnNode.setBody(parseFunctionBody(4, fnNode));
/*  994 */       fnNode.setEncodedSourceBounds(functionSourceStart, this.ts.tokenEnd);
/*  995 */       fnNode.setLength(this.ts.tokenEnd - functionSourceStart);
/*      */     } finally {
/*  997 */       savedVars.restore();
/*      */     } 
/*      */     
/* 1000 */     if (fnNode.isGenerator()) {
/* 1001 */       reportError("msg.arrowfunction.generator");
/* 1002 */       return (AstNode)makeErrorNode();
/*      */     } 
/*      */     
/* 1005 */     fnNode.setSourceName(this.sourceURI);
/* 1006 */     fnNode.setBaseLineno(baseLineno);
/* 1007 */     fnNode.setEndLineno(this.ts.lineno);
/*      */     
/* 1009 */     return (AstNode)fnNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void arrowFunctionParams(FunctionNode fnNode, AstNode params, Map<String, Node> destructuring, Set<String> paramNames) {
/* 1017 */     if (params instanceof ArrayLiteral || params instanceof ObjectLiteral) {
/* 1018 */       markDestructuring(params);
/* 1019 */       fnNode.addParam(params);
/* 1020 */       String pname = this.currentScriptOrFn.getNextTempName();
/* 1021 */       defineSymbol(90, pname, false);
/* 1022 */       destructuring.put(pname, params);
/* 1023 */     } else if (params instanceof InfixExpression && params.getType() == 92) {
/* 1024 */       arrowFunctionParams(fnNode, ((InfixExpression)params)
/* 1025 */           .getLeft(), destructuring, paramNames);
/* 1026 */       arrowFunctionParams(fnNode, ((InfixExpression)params)
/* 1027 */           .getRight(), destructuring, paramNames);
/* 1028 */     } else if (params instanceof Name) {
/* 1029 */       fnNode.addParam(params);
/* 1030 */       String paramName = ((Name)params).getIdentifier();
/* 1031 */       defineSymbol(90, paramName);
/*      */       
/* 1033 */       if (this.inUseStrictDirective) {
/* 1034 */         if ("eval".equals(paramName) || "arguments".equals(paramName)) {
/* 1035 */           reportError("msg.bad.id.strict", paramName);
/*      */         }
/* 1037 */         if (paramNames.contains(paramName)) addError("msg.dup.param.strict", paramName); 
/* 1038 */         paramNames.add(paramName);
/*      */       } 
/*      */     } else {
/* 1041 */       reportError("msg.no.parm", params.getPosition(), params.getLength());
/* 1042 */       fnNode.addParam((AstNode)makeErrorNode());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode statements(AstNode parent) throws IOException {
/* 1055 */     if (this.currentToken != 88 && 
/* 1056 */       !this.compilerEnv.isIdeMode()) codeBug(); 
/* 1057 */     int pos = this.ts.tokenBeg;
/* 1058 */     AstNode block = (parent != null) ? parent : (AstNode)new Block(pos);
/* 1059 */     block.setLineno(this.ts.lineno);
/*      */     
/*      */     int tt;
/* 1062 */     while ((tt = peekToken()) > 0 && tt != 89) {
/* 1063 */       block.addChild(statement());
/*      */     }
/* 1065 */     block.setLength(this.ts.tokenBeg - pos);
/* 1066 */     return block;
/*      */   }
/*      */   
/*      */   private AstNode statements() throws IOException {
/* 1070 */     return statements(null);
/*      */   }
/*      */   private static class ConditionData { AstNode condition;
/*      */     private ConditionData() {}
/*      */     
/* 1075 */     int lp = -1;
/* 1076 */     int rp = -1; }
/*      */ 
/*      */ 
/*      */   
/*      */   private ConditionData condition() throws IOException {
/* 1081 */     ConditionData data = new ConditionData();
/*      */     
/* 1083 */     if (mustMatchToken(90, "msg.no.paren.cond", true)) data.lp = this.ts.tokenBeg;
/*      */     
/* 1085 */     data.condition = expr();
/*      */     
/* 1087 */     if (mustMatchToken(91, "msg.no.paren.after.cond", true)) data.rp = this.ts.tokenBeg;
/*      */ 
/*      */ 
/*      */     
/* 1091 */     if (data.condition instanceof Assignment) {
/* 1092 */       addStrictWarning("msg.equal.as.assign", "", data.condition
/*      */ 
/*      */           
/* 1095 */           .getPosition(), data.condition
/* 1096 */           .getLength());
/*      */     }
/* 1098 */     return data;
/*      */   }
/*      */   
/*      */   private AstNode statement() throws IOException {
/* 1102 */     int pos = this.ts.tokenBeg;
/*      */     try {
/* 1104 */       AstNode pn = statementHelper();
/* 1105 */       if (pn != null) {
/* 1106 */         if (this.compilerEnv.isStrictMode() && !pn.hasSideEffects()) {
/* 1107 */           int beg = pn.getPosition();
/* 1108 */           beg = Math.max(beg, lineBeginningFor(beg));
/* 1109 */           addStrictWarning((pn instanceof EmptyStatement) ? "msg.extra.trailing.semi" : "msg.no.side.effects", "", beg, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1115 */               nodeEnd(pn) - beg);
/*      */         } 
/* 1117 */         int ntt = peekToken();
/* 1118 */         if (ntt == 165 && pn
/* 1119 */           .getLineno() == ((Comment)this.scannedComments
/* 1120 */           .get(this.scannedComments.size() - 1)).getLineno()) {
/* 1121 */           pn.setInlineComment((AstNode)this.scannedComments.get(this.scannedComments.size() - 1));
/* 1122 */           consumeToken();
/*      */         } 
/* 1124 */         return pn;
/*      */       } 
/* 1126 */     } catch (ParserException parserException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1133 */       int tt = peekTokenOrEOL();
/* 1134 */       consumeToken();
/* 1135 */       switch (tt) {
/*      */         case -1:
/*      */         case 0:
/*      */         case 1:
/*      */         case 85:
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 1146 */     return (AstNode)new EmptyStatement(pos, this.ts.tokenBeg - pos); } private AstNode statementHelper() throws IOException { ThrowStatement throwStatement; BreakStatement breakStatement; ContinueStatement continueStatement; VariableDeclaration variableDeclaration;
/*      */     AstNode astNode2;
/*      */     KeywordLiteral keywordLiteral;
/*      */     EmptyStatement emptyStatement;
/*      */     AstNode astNode1;
/* 1151 */     if (this.currentLabel != null && this.currentLabel.getStatement() != null) this.currentLabel = null;
/*      */     
/* 1153 */     AstNode pn = null;
/* 1154 */     int tt = peekToken(), pos = this.ts.tokenBeg;
/*      */     
/* 1156 */     switch (tt)
/*      */     { case 116:
/* 1158 */         return (AstNode)ifStatement();
/*      */       
/*      */       case 118:
/* 1161 */         return (AstNode)switchStatement();
/*      */       
/*      */       case 121:
/* 1164 */         return (AstNode)whileLoop();
/*      */       
/*      */       case 122:
/* 1167 */         return (AstNode)doLoop();
/*      */       
/*      */       case 123:
/* 1170 */         return (AstNode)forLoop();
/*      */       
/*      */       case 84:
/* 1173 */         return (AstNode)tryStatement();
/*      */       
/*      */       case 50:
/* 1176 */         throwStatement = throwStatement();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1254 */         autoInsertSemicolon((AstNode)throwStatement);
/* 1255 */         return (AstNode)throwStatement;case 124: breakStatement = breakStatement(); autoInsertSemicolon((AstNode)breakStatement); return (AstNode)breakStatement;case 125: continueStatement = continueStatement(); autoInsertSemicolon((AstNode)continueStatement); return (AstNode)continueStatement;case 127: if (this.inUseStrictDirective) reportError("msg.no.with.strict");  return (AstNode)withStatement();case 126: case 158: consumeToken(); lineno = this.ts.lineno; variableDeclaration = variables(this.currentToken, this.ts.tokenBeg, true); variableDeclaration.setLineno(lineno); autoInsertSemicolon((AstNode)variableDeclaration); return (AstNode)variableDeclaration;case 157: astNode2 = letStatement(); if (!(astNode2 instanceof VariableDeclaration) || peekToken() != 85) return astNode2;  autoInsertSemicolon(astNode2); return astNode2;case 4: case 73: astNode2 = returnOrYield(tt, false); autoInsertSemicolon(astNode2); return astNode2;case 164: consumeToken(); keywordLiteral = new KeywordLiteral(this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg, tt); keywordLiteral.setLineno(this.ts.lineno); autoInsertSemicolon((AstNode)keywordLiteral); return (AstNode)keywordLiteral;case 88: return block();case -1: consumeToken(); return (AstNode)makeErrorNode();case 85: consumeToken(); pos = this.ts.tokenBeg; emptyStatement = new EmptyStatement(pos, this.ts.tokenEnd - pos); emptyStatement.setLineno(this.ts.lineno); return (AstNode)emptyStatement;case 113: consumeToken(); return (AstNode)function(3);case 120: astNode1 = defaultXmlNamespace(); autoInsertSemicolon(astNode1); return astNode1;case 39: astNode1 = nameOrLabel(); if (!(astNode1 instanceof ExpressionStatement)) return astNode1;  autoInsertSemicolon(astNode1); return astNode1;case 165: astNode1 = (AstNode)this.scannedComments.get(this.scannedComments.size() - 1); return astNode1; }  int lineno = this.ts.lineno; ExpressionStatement expressionStatement = new ExpressionStatement(expr(), !insideFunction()); expressionStatement.setLineno(lineno); autoInsertSemicolon((AstNode)expressionStatement); return (AstNode)expressionStatement; }
/*      */ 
/*      */   
/*      */   private void autoInsertSemicolon(AstNode pn) throws IOException {
/* 1259 */     int ttFlagged = peekFlaggedToken();
/* 1260 */     int pos = pn.getPosition();
/* 1261 */     switch (ttFlagged & 0xFFFF) {
/*      */       
/*      */       case 85:
/* 1264 */         consumeToken();
/*      */         
/* 1266 */         pn.setLength(this.ts.tokenEnd - pos);
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 0:
/*      */       case 89:
/* 1274 */         warnMissingSemi(pos, Math.max(pos + 1, nodeEnd(pn)));
/*      */         return;
/*      */     } 
/* 1277 */     if ((ttFlagged & 0x10000) == 0) {
/*      */       
/* 1279 */       reportError("msg.no.semi.stmt");
/*      */     } else {
/* 1281 */       warnMissingSemi(pos, nodeEnd(pn));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private IfStatement ifStatement() throws IOException {
/* 1288 */     if (this.currentToken != 116) codeBug(); 
/* 1289 */     consumeToken();
/* 1290 */     int pos = this.ts.tokenBeg, lineno = this.ts.lineno, elsePos = -1;
/* 1291 */     IfStatement pn = new IfStatement(pos);
/* 1292 */     ConditionData data = condition();
/* 1293 */     AstNode ifTrue = getNextStatementAfterInlineComments((AstNode)pn), ifFalse = null;
/* 1294 */     if (matchToken(117, true)) {
/* 1295 */       int tt = peekToken();
/* 1296 */       if (tt == 165) {
/* 1297 */         pn.setElseKeyWordInlineComment((AstNode)this.scannedComments.get(this.scannedComments.size() - 1));
/* 1298 */         consumeToken();
/*      */       } 
/* 1300 */       elsePos = this.ts.tokenBeg - pos;
/* 1301 */       ifFalse = statement();
/*      */     } 
/* 1303 */     int end = getNodeEnd((ifFalse != null) ? ifFalse : ifTrue);
/* 1304 */     pn.setLength(end - pos);
/* 1305 */     pn.setCondition(data.condition);
/* 1306 */     pn.setParens(data.lp - pos, data.rp - pos);
/* 1307 */     pn.setThenPart(ifTrue);
/* 1308 */     pn.setElsePart(ifFalse);
/* 1309 */     pn.setElsePosition(elsePos);
/* 1310 */     pn.setLineno(lineno);
/* 1311 */     return pn;
/*      */   }
/*      */   
/*      */   private SwitchStatement switchStatement() throws IOException {
/* 1315 */     if (this.currentToken != 118) codeBug(); 
/* 1316 */     consumeToken();
/* 1317 */     int pos = this.ts.tokenBeg;
/*      */     
/* 1319 */     SwitchStatement pn = new SwitchStatement(pos);
/* 1320 */     if (mustMatchToken(90, "msg.no.paren.switch", true)) pn.setLp(this.ts.tokenBeg - pos); 
/* 1321 */     pn.setLineno(this.ts.lineno);
/*      */     
/* 1323 */     AstNode discriminant = expr();
/* 1324 */     pn.setExpression(discriminant);
/* 1325 */     enterSwitch(pn);
/*      */     
/*      */     try {
/* 1328 */       if (mustMatchToken(91, "msg.no.paren.after.switch", true)) {
/* 1329 */         pn.setRp(this.ts.tokenBeg - pos);
/*      */       }
/* 1331 */       mustMatchToken(88, "msg.no.brace.switch", true);
/*      */       
/* 1333 */       boolean hasDefault = false;
/*      */       
/*      */       while (true) {
/*      */         AstNode n;
/* 1337 */         int tt = nextToken();
/* 1338 */         int casePos = this.ts.tokenBeg;
/* 1339 */         int caseLineno = this.ts.lineno;
/* 1340 */         AstNode caseExpression = null;
/* 1341 */         switch (tt) {
/*      */           case 89:
/* 1343 */             pn.setLength(this.ts.tokenEnd - pos);
/*      */             break;
/*      */           
/*      */           case 119:
/* 1347 */             caseExpression = expr();
/* 1348 */             mustMatchToken(107, "msg.no.colon.case", true);
/*      */             break;
/*      */           
/*      */           case 120:
/* 1352 */             if (hasDefault) {
/* 1353 */               reportError("msg.double.switch.default");
/*      */             }
/* 1355 */             hasDefault = true;
/* 1356 */             mustMatchToken(107, "msg.no.colon.case", true);
/*      */             break;
/*      */           case 165:
/* 1359 */             n = (AstNode)this.scannedComments.get(this.scannedComments.size() - 1);
/* 1360 */             pn.addChild(n);
/*      */             continue;
/*      */           default:
/* 1363 */             reportError("msg.bad.switch");
/*      */             break;
/*      */         } 
/*      */         
/* 1367 */         SwitchCase caseNode = new SwitchCase(casePos);
/* 1368 */         caseNode.setExpression(caseExpression);
/* 1369 */         caseNode.setLength(this.ts.tokenEnd - pos);
/* 1370 */         caseNode.setLineno(caseLineno);
/*      */         
/* 1372 */         while ((tt = peekToken()) != 89 && tt != 119 && tt != 120 && tt != 0) {
/*      */ 
/*      */ 
/*      */           
/* 1376 */           if (tt == 165) {
/* 1377 */             Comment inlineComment = this.scannedComments.get(this.scannedComments.size() - 1);
/* 1378 */             if (caseNode.getInlineComment() == null && inlineComment
/* 1379 */               .getLineno() == caseNode.getLineno()) {
/* 1380 */               caseNode.setInlineComment((AstNode)inlineComment);
/*      */             } else {
/* 1382 */               caseNode.addStatement((AstNode)inlineComment);
/*      */             } 
/* 1384 */             consumeToken();
/*      */             continue;
/*      */           } 
/* 1387 */           AstNode nextStmt = statement();
/* 1388 */           caseNode.addStatement(nextStmt);
/*      */         } 
/* 1390 */         pn.addCase(caseNode);
/*      */       } 
/*      */     } finally {
/* 1393 */       exitSwitch();
/*      */     } 
/* 1395 */     return pn;
/*      */   }
/*      */   
/*      */   private WhileLoop whileLoop() throws IOException {
/* 1399 */     if (this.currentToken != 121) codeBug(); 
/* 1400 */     consumeToken();
/* 1401 */     int pos = this.ts.tokenBeg;
/* 1402 */     WhileLoop pn = new WhileLoop(pos);
/* 1403 */     pn.setLineno(this.ts.lineno);
/* 1404 */     enterLoop((Loop)pn);
/*      */     try {
/* 1406 */       ConditionData data = condition();
/* 1407 */       pn.setCondition(data.condition);
/* 1408 */       pn.setParens(data.lp - pos, data.rp - pos);
/* 1409 */       AstNode body = getNextStatementAfterInlineComments((AstNode)pn);
/* 1410 */       pn.setLength(getNodeEnd(body) - pos);
/* 1411 */       restoreRelativeLoopPosition((Loop)pn);
/* 1412 */       pn.setBody(body);
/*      */     } finally {
/* 1414 */       exitLoop();
/*      */     } 
/* 1416 */     return pn;
/*      */   }
/*      */   private DoLoop doLoop() throws IOException {
/*      */     int end;
/* 1420 */     if (this.currentToken != 122) codeBug(); 
/* 1421 */     consumeToken();
/* 1422 */     int pos = this.ts.tokenBeg;
/* 1423 */     DoLoop pn = new DoLoop(pos);
/* 1424 */     pn.setLineno(this.ts.lineno);
/* 1425 */     enterLoop((Loop)pn);
/*      */     try {
/* 1427 */       AstNode body = getNextStatementAfterInlineComments((AstNode)pn);
/* 1428 */       mustMatchToken(121, "msg.no.while.do", true);
/* 1429 */       pn.setWhilePosition(this.ts.tokenBeg - pos);
/* 1430 */       ConditionData data = condition();
/* 1431 */       pn.setCondition(data.condition);
/* 1432 */       pn.setParens(data.lp - pos, data.rp - pos);
/* 1433 */       end = getNodeEnd(body);
/* 1434 */       restoreRelativeLoopPosition((Loop)pn);
/* 1435 */       pn.setBody(body);
/*      */     } finally {
/* 1437 */       exitLoop();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1442 */     if (matchToken(85, true)) {
/* 1443 */       end = this.ts.tokenEnd;
/*      */     }
/* 1445 */     pn.setLength(end - pos);
/* 1446 */     return pn;
/*      */   }
/*      */   
/*      */   private int peekUntilNonComment(int tt) throws IOException {
/* 1450 */     while (tt == 165) {
/* 1451 */       consumeToken();
/* 1452 */       tt = peekToken();
/*      */     } 
/* 1454 */     return tt;
/*      */   }
/*      */   
/*      */   private AstNode getNextStatementAfterInlineComments(AstNode pn) throws IOException {
/* 1458 */     AstNode body = statement();
/* 1459 */     if (165 == body.getType()) {
/* 1460 */       AstNode commentNode = body;
/* 1461 */       body = statement();
/* 1462 */       if (pn != null) {
/* 1463 */         pn.setInlineComment(commentNode);
/*      */       } else {
/* 1465 */         body.setInlineComment(commentNode);
/*      */       } 
/*      */     } 
/* 1468 */     return body;
/*      */   }
/*      */   private Loop forLoop() throws IOException {
/*      */     ForLoop forLoop;
/* 1472 */     if (this.currentToken != 123) codeBug(); 
/* 1473 */     consumeToken();
/* 1474 */     int forPos = this.ts.tokenBeg, lineno = this.ts.lineno;
/* 1475 */     boolean isForEach = false, isForIn = false, isForOf = false;
/* 1476 */     int eachPos = -1, inPos = -1, lp = -1, rp = -1;
/* 1477 */     AstNode init = null;
/* 1478 */     AstNode cond = null;
/* 1479 */     AstNode incr = null;
/* 1480 */     Loop pn = null;
/*      */     
/* 1482 */     Scope tempScope = new Scope();
/* 1483 */     pushScope(tempScope);
/*      */     
/*      */     try {
/* 1486 */       if (matchToken(39, true)) {
/* 1487 */         if ("each".equals(this.ts.getString())) {
/* 1488 */           isForEach = true;
/* 1489 */           eachPos = this.ts.tokenBeg - forPos;
/*      */         } else {
/* 1491 */           reportError("msg.no.paren.for");
/*      */         } 
/*      */       }
/*      */       
/* 1495 */       if (mustMatchToken(90, "msg.no.paren.for", true)) lp = this.ts.tokenBeg - forPos; 
/* 1496 */       int tt = peekToken();
/*      */       
/* 1498 */       init = forLoopInit(tt);
/* 1499 */       if (matchToken(52, true)) {
/* 1500 */         isForIn = true;
/* 1501 */         inPos = this.ts.tokenBeg - forPos;
/* 1502 */         markDestructuring(init);
/* 1503 */         cond = expr();
/* 1504 */       } else if (this.compilerEnv.getLanguageVersion() >= 200 && 
/* 1505 */         matchToken(39, true) && "of"
/* 1506 */         .equals(this.ts.getString())) {
/* 1507 */         isForOf = true;
/* 1508 */         inPos = this.ts.tokenBeg - forPos;
/* 1509 */         markDestructuring(init);
/* 1510 */         cond = expr();
/*      */       } else {
/* 1512 */         mustMatchToken(85, "msg.no.semi.for", true);
/* 1513 */         if (peekToken() == 85) {
/*      */           
/* 1515 */           EmptyExpression emptyExpression = new EmptyExpression(this.ts.tokenBeg, 1);
/* 1516 */           emptyExpression.setLineno(this.ts.lineno);
/*      */         } else {
/* 1518 */           cond = expr();
/*      */         } 
/*      */         
/* 1521 */         mustMatchToken(85, "msg.no.semi.for.cond", true);
/* 1522 */         int tmpPos = this.ts.tokenEnd;
/* 1523 */         if (peekToken() == 91) {
/* 1524 */           EmptyExpression emptyExpression = new EmptyExpression(tmpPos, 1);
/* 1525 */           emptyExpression.setLineno(this.ts.lineno);
/*      */         } else {
/* 1527 */           incr = expr();
/*      */         } 
/*      */       } 
/*      */       
/* 1531 */       if (mustMatchToken(91, "msg.no.paren.for.ctrl", true)) rp = this.ts.tokenBeg - forPos;
/*      */       
/* 1533 */       if (isForIn || isForOf) {
/* 1534 */         ForInLoop fis = new ForInLoop(forPos);
/* 1535 */         if (init instanceof VariableDeclaration)
/*      */         {
/* 1537 */           if (((VariableDeclaration)init).getVariables().size() > 1) {
/* 1538 */             reportError("msg.mult.index");
/*      */           }
/*      */         }
/* 1541 */         if (isForOf && isForEach) {
/* 1542 */           reportError("msg.invalid.for.each");
/*      */         }
/* 1544 */         fis.setIterator(init);
/* 1545 */         fis.setIteratedObject(cond);
/* 1546 */         fis.setInPosition(inPos);
/* 1547 */         fis.setIsForEach(isForEach);
/* 1548 */         fis.setEachPosition(eachPos);
/* 1549 */         fis.setIsForOf(isForOf);
/* 1550 */         ForInLoop forInLoop1 = fis;
/*      */       } else {
/* 1552 */         ForLoop fl = new ForLoop(forPos);
/* 1553 */         fl.setInitializer(init);
/* 1554 */         fl.setCondition(cond);
/* 1555 */         fl.setIncrement(incr);
/* 1556 */         forLoop = fl;
/*      */       } 
/*      */ 
/*      */       
/* 1560 */       this.currentScope.replaceWith((Scope)forLoop);
/* 1561 */       popScope();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1566 */       enterLoop((Loop)forLoop);
/*      */       try {
/* 1568 */         AstNode body = getNextStatementAfterInlineComments((AstNode)forLoop);
/* 1569 */         forLoop.setLength(getNodeEnd(body) - forPos);
/* 1570 */         restoreRelativeLoopPosition((Loop)forLoop);
/* 1571 */         forLoop.setBody(body);
/*      */       } finally {
/* 1573 */         exitLoop();
/*      */       } 
/*      */     } finally {
/*      */       
/* 1577 */       if (this.currentScope == tempScope) {
/* 1578 */         popScope();
/*      */       }
/*      */     } 
/* 1581 */     forLoop.setParens(lp, rp);
/* 1582 */     forLoop.setLineno(lineno);
/* 1583 */     return (Loop)forLoop;
/*      */   }
/*      */   
/*      */   private AstNode forLoopInit(int tt) throws IOException {
/*      */     try {
/* 1588 */       this.inForInit = true;
/* 1589 */       AstNode init = null;
/* 1590 */       if (tt == 85) {
/* 1591 */         EmptyExpression emptyExpression = new EmptyExpression(this.ts.tokenBeg, 1);
/* 1592 */         emptyExpression.setLineno(this.ts.lineno);
/* 1593 */       } else if (tt == 126 || tt == 157) {
/* 1594 */         consumeToken();
/* 1595 */         VariableDeclaration variableDeclaration = variables(tt, this.ts.tokenBeg, false);
/*      */       } else {
/* 1597 */         init = expr();
/*      */       } 
/* 1599 */       return init;
/*      */     } finally {
/* 1601 */       this.inForInit = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   private TryStatement tryStatement() throws IOException {
/* 1606 */     if (this.currentToken != 84) codeBug(); 
/* 1607 */     consumeToken();
/*      */ 
/*      */     
/* 1610 */     Comment jsdocNode = getAndResetJsDoc();
/*      */     
/* 1612 */     int tryPos = this.ts.tokenBeg, lineno = this.ts.lineno, finallyPos = -1;
/*      */     
/* 1614 */     TryStatement pn = new TryStatement(tryPos);
/*      */     
/* 1616 */     int lctt = peekToken();
/* 1617 */     while (lctt == 165) {
/* 1618 */       Comment commentNode = this.scannedComments.get(this.scannedComments.size() - 1);
/* 1619 */       pn.setInlineComment((AstNode)commentNode);
/* 1620 */       consumeToken();
/* 1621 */       lctt = peekToken();
/*      */     } 
/* 1623 */     if (lctt != 88) {
/* 1624 */       reportError("msg.no.brace.try");
/*      */     }
/* 1626 */     AstNode tryBlock = getNextStatementAfterInlineComments((AstNode)pn);
/* 1627 */     int tryEnd = getNodeEnd(tryBlock);
/*      */     
/* 1629 */     List<CatchClause> clauses = null;
/*      */     
/* 1631 */     boolean sawDefaultCatch = false;
/* 1632 */     int peek = peekToken();
/* 1633 */     while (peek == 165) {
/* 1634 */       Comment commentNode = this.scannedComments.get(this.scannedComments.size() - 1);
/* 1635 */       pn.setInlineComment((AstNode)commentNode);
/* 1636 */       consumeToken();
/* 1637 */       peek = peekToken();
/*      */     } 
/* 1639 */     if (peek == 128) {
/* 1640 */       while (matchToken(128, true)) {
/* 1641 */         int catchLineNum = this.ts.lineno;
/* 1642 */         if (sawDefaultCatch) {
/* 1643 */           reportError("msg.catch.unreachable");
/*      */         }
/* 1645 */         int catchPos = this.ts.tokenBeg, lp = -1, rp = -1, guardPos = -1;
/* 1646 */         if (mustMatchToken(90, "msg.no.paren.catch", true)) lp = this.ts.tokenBeg;
/*      */         
/* 1648 */         mustMatchToken(39, "msg.bad.catchcond", true);
/*      */         
/* 1650 */         Name varName = createNameNode();
/* 1651 */         Comment jsdocNodeForName = getAndResetJsDoc();
/* 1652 */         if (jsdocNodeForName != null) {
/* 1653 */           varName.setJsDocNode(jsdocNodeForName);
/*      */         }
/* 1655 */         String varNameString = varName.getIdentifier();
/* 1656 */         if (this.inUseStrictDirective && (
/* 1657 */           "eval".equals(varNameString) || "arguments".equals(varNameString))) {
/* 1658 */           reportError("msg.bad.id.strict", varNameString);
/*      */         }
/*      */ 
/*      */         
/* 1662 */         AstNode catchCond = null;
/* 1663 */         if (matchToken(116, true)) {
/* 1664 */           guardPos = this.ts.tokenBeg;
/* 1665 */           catchCond = expr();
/*      */         } else {
/* 1667 */           sawDefaultCatch = true;
/*      */         } 
/*      */         
/* 1670 */         if (mustMatchToken(91, "msg.bad.catchcond", true)) rp = this.ts.tokenBeg; 
/* 1671 */         mustMatchToken(88, "msg.no.brace.catchblock", true);
/*      */         
/* 1673 */         Block catchBlock = (Block)statements();
/* 1674 */         tryEnd = getNodeEnd((AstNode)catchBlock);
/* 1675 */         CatchClause catchNode = new CatchClause(catchPos);
/* 1676 */         catchNode.setVarName(varName);
/* 1677 */         catchNode.setCatchCondition(catchCond);
/* 1678 */         catchNode.setBody(catchBlock);
/* 1679 */         if (guardPos != -1) {
/* 1680 */           catchNode.setIfPosition(guardPos - catchPos);
/*      */         }
/* 1682 */         catchNode.setParens(lp, rp);
/* 1683 */         catchNode.setLineno(catchLineNum);
/*      */         
/* 1685 */         if (mustMatchToken(89, "msg.no.brace.after.body", true)) tryEnd = this.ts.tokenEnd; 
/* 1686 */         catchNode.setLength(tryEnd - catchPos);
/* 1687 */         if (clauses == null) clauses = new ArrayList<>(); 
/* 1688 */         clauses.add(catchNode);
/*      */       } 
/* 1690 */     } else if (peek != 129) {
/* 1691 */       mustMatchToken(129, "msg.try.no.catchfinally", true);
/*      */     } 
/*      */     
/* 1694 */     AstNode finallyBlock = null;
/* 1695 */     if (matchToken(129, true)) {
/* 1696 */       finallyPos = this.ts.tokenBeg;
/* 1697 */       finallyBlock = statement();
/* 1698 */       tryEnd = getNodeEnd(finallyBlock);
/*      */     } 
/*      */     
/* 1701 */     pn.setLength(tryEnd - tryPos);
/* 1702 */     pn.setTryBlock(tryBlock);
/* 1703 */     pn.setCatchClauses(clauses);
/* 1704 */     pn.setFinallyBlock(finallyBlock);
/* 1705 */     if (finallyPos != -1) {
/* 1706 */       pn.setFinallyPosition(finallyPos - tryPos);
/*      */     }
/* 1708 */     pn.setLineno(lineno);
/*      */     
/* 1710 */     if (jsdocNode != null) {
/* 1711 */       pn.setJsDocNode(jsdocNode);
/*      */     }
/*      */     
/* 1714 */     return pn;
/*      */   }
/*      */   
/*      */   private ThrowStatement throwStatement() throws IOException {
/* 1718 */     if (this.currentToken != 50) codeBug(); 
/* 1719 */     consumeToken();
/* 1720 */     int pos = this.ts.tokenBeg, lineno = this.ts.lineno;
/* 1721 */     if (peekTokenOrEOL() == 1)
/*      */     {
/*      */       
/* 1724 */       reportError("msg.bad.throw.eol");
/*      */     }
/* 1726 */     AstNode expr = expr();
/* 1727 */     ThrowStatement pn = new ThrowStatement(pos, expr);
/* 1728 */     pn.setLineno(lineno);
/* 1729 */     return pn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LabeledStatement matchJumpLabelName() throws IOException {
/* 1739 */     LabeledStatement label = null;
/*      */     
/* 1741 */     if (peekTokenOrEOL() == 39) {
/* 1742 */       consumeToken();
/* 1743 */       if (this.labelSet != null) {
/* 1744 */         label = this.labelSet.get(this.ts.getString());
/*      */       }
/* 1746 */       if (label == null) {
/* 1747 */         reportError("msg.undef.label");
/*      */       }
/*      */     } 
/*      */     
/* 1751 */     return label;
/*      */   }
/*      */   private BreakStatement breakStatement() throws IOException {
/*      */     Jump jump;
/* 1755 */     if (this.currentToken != 124) codeBug(); 
/* 1756 */     consumeToken();
/* 1757 */     int lineno = this.ts.lineno, pos = this.ts.tokenBeg, end = this.ts.tokenEnd;
/* 1758 */     Name breakLabel = null;
/* 1759 */     if (peekTokenOrEOL() == 39) {
/* 1760 */       breakLabel = createNameNode();
/* 1761 */       end = getNodeEnd((AstNode)breakLabel);
/*      */     } 
/*      */ 
/*      */     
/* 1765 */     LabeledStatement labels = matchJumpLabelName();
/*      */     
/* 1767 */     Label label = (labels == null) ? null : labels.getFirstLabel();
/*      */     
/* 1769 */     if (label == null && breakLabel == null) {
/* 1770 */       if (this.loopAndSwitchSet == null || this.loopAndSwitchSet.size() == 0) {
/* 1771 */         reportError("msg.bad.break", pos, end - pos);
/*      */       } else {
/* 1773 */         jump = this.loopAndSwitchSet.get(this.loopAndSwitchSet.size() - 1);
/*      */       } 
/*      */     }
/*      */     
/* 1777 */     BreakStatement pn = new BreakStatement(pos, end - pos);
/* 1778 */     pn.setBreakLabel(breakLabel);
/*      */     
/* 1780 */     if (jump != null) pn.setBreakTarget(jump); 
/* 1781 */     pn.setLineno(lineno);
/* 1782 */     return pn;
/*      */   }
/*      */   
/*      */   private ContinueStatement continueStatement() throws IOException {
/* 1786 */     if (this.currentToken != 125) codeBug(); 
/* 1787 */     consumeToken();
/* 1788 */     int lineno = this.ts.lineno, pos = this.ts.tokenBeg, end = this.ts.tokenEnd;
/* 1789 */     Name label = null;
/* 1790 */     if (peekTokenOrEOL() == 39) {
/* 1791 */       label = createNameNode();
/* 1792 */       end = getNodeEnd((AstNode)label);
/*      */     } 
/*      */ 
/*      */     
/* 1796 */     LabeledStatement labels = matchJumpLabelName();
/* 1797 */     Loop target = null;
/* 1798 */     if (labels == null && label == null) {
/* 1799 */       if (this.loopSet == null || this.loopSet.size() == 0) {
/* 1800 */         reportError("msg.continue.outside");
/*      */       } else {
/* 1802 */         target = this.loopSet.get(this.loopSet.size() - 1);
/*      */       } 
/*      */     } else {
/* 1805 */       if (labels == null || !(labels.getStatement() instanceof Loop)) {
/* 1806 */         reportError("msg.continue.nonloop", pos, end - pos);
/*      */       }
/* 1808 */       target = (labels == null) ? null : (Loop)labels.getStatement();
/*      */     } 
/*      */     
/* 1811 */     ContinueStatement pn = new ContinueStatement(pos, end - pos);
/* 1812 */     if (target != null)
/* 1813 */       pn.setTarget(target); 
/* 1814 */     pn.setLabel(label);
/* 1815 */     pn.setLineno(lineno);
/* 1816 */     return pn;
/*      */   }
/*      */   
/*      */   private WithStatement withStatement() throws IOException {
/* 1820 */     if (this.currentToken != 127) codeBug(); 
/* 1821 */     consumeToken();
/*      */     
/* 1823 */     Comment withComment = getAndResetJsDoc();
/*      */     
/* 1825 */     int lineno = this.ts.lineno, pos = this.ts.tokenBeg, lp = -1, rp = -1;
/* 1826 */     if (mustMatchToken(90, "msg.no.paren.with", true)) lp = this.ts.tokenBeg;
/*      */     
/* 1828 */     AstNode obj = expr();
/*      */     
/* 1830 */     if (mustMatchToken(91, "msg.no.paren.after.with", true)) rp = this.ts.tokenBeg;
/*      */     
/* 1832 */     WithStatement pn = new WithStatement(pos);
/* 1833 */     AstNode body = getNextStatementAfterInlineComments((AstNode)pn);
/* 1834 */     pn.setLength(getNodeEnd(body) - pos);
/* 1835 */     pn.setJsDocNode(withComment);
/* 1836 */     pn.setExpression(obj);
/* 1837 */     pn.setStatement(body);
/* 1838 */     pn.setParens(lp, rp);
/* 1839 */     pn.setLineno(lineno);
/* 1840 */     return pn;
/*      */   }
/*      */   private AstNode letStatement() throws IOException {
/*      */     VariableDeclaration variableDeclaration;
/* 1844 */     if (this.currentToken != 157) codeBug(); 
/* 1845 */     consumeToken();
/* 1846 */     int lineno = this.ts.lineno, pos = this.ts.tokenBeg;
/*      */     
/* 1848 */     if (peekToken() == 90) {
/* 1849 */       AstNode pn = let(true, pos);
/*      */     } else {
/* 1851 */       variableDeclaration = variables(157, pos, true);
/*      */     } 
/* 1853 */     variableDeclaration.setLineno(lineno);
/* 1854 */     return (AstNode)variableDeclaration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean nowAllSet(int before, int after, int mask) {
/* 1866 */     return ((before & mask) != mask && (after & mask) == mask);
/*      */   }
/*      */   private AstNode returnOrYield(int tt, boolean exprContext) throws IOException {
/*      */     ExpressionStatement expressionStatement;
/* 1870 */     if (!insideFunction()) {
/* 1871 */       reportError((tt == 4) ? "msg.bad.return" : "msg.bad.yield");
/*      */     }
/* 1873 */     consumeToken();
/* 1874 */     int lineno = this.ts.lineno, pos = this.ts.tokenBeg, end = this.ts.tokenEnd;
/*      */     
/* 1876 */     boolean yieldStar = false;
/* 1877 */     if (tt == 73 && this.compilerEnv
/* 1878 */       .getLanguageVersion() >= 200 && 
/* 1879 */       peekToken() == 23) {
/* 1880 */       yieldStar = true;
/* 1881 */       consumeToken();
/*      */     } 
/*      */     
/* 1884 */     AstNode e = null;
/*      */     
/* 1886 */     switch (peekTokenOrEOL()) {
/*      */       case -1:
/*      */       case 0:
/*      */       case 1:
/*      */       case 85:
/*      */       case 87:
/*      */       case 89:
/*      */       case 91:
/*      */         break;
/*      */       case 73:
/* 1896 */         if (this.compilerEnv.getLanguageVersion() < 200) {
/*      */           break;
/*      */         }
/*      */ 
/*      */       
/*      */       default:
/* 1902 */         e = expr();
/* 1903 */         end = getNodeEnd(e);
/*      */         break;
/*      */     } 
/* 1906 */     int before = this.endFlags;
/*      */ 
/*      */     
/* 1909 */     if (tt == 4) {
/* 1910 */       this.endFlags |= (e == null) ? 2 : 4;
/* 1911 */       ReturnStatement returnStatement = new ReturnStatement(pos, end - pos, e);
/*      */ 
/*      */       
/* 1914 */       if (nowAllSet(before, this.endFlags, 6))
/* 1915 */         addStrictWarning("msg.return.inconsistent", "", pos, end - pos); 
/*      */     } else {
/* 1917 */       if (!insideFunction()) reportError("msg.bad.yield"); 
/* 1918 */       this.endFlags |= 0x8;
/* 1919 */       Yield yield = new Yield(pos, end - pos, e, yieldStar);
/* 1920 */       setRequiresActivation();
/* 1921 */       setIsGenerator();
/* 1922 */       if (!exprContext) {
/* 1923 */         expressionStatement = new ExpressionStatement((AstNode)yield);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1928 */     if (insideFunction() && 
/* 1929 */       nowAllSet(before, this.endFlags, 12)) {
/* 1930 */       FunctionNode fn = (FunctionNode)this.currentScriptOrFn;
/* 1931 */       if (!fn.isES6Generator()) {
/* 1932 */         Name name = ((FunctionNode)this.currentScriptOrFn).getFunctionName();
/* 1933 */         if (name == null || name.length() == 0) {
/* 1934 */           addError("msg.anon.generator.returns", "");
/*      */         } else {
/* 1936 */           addError("msg.generator.returns", name.getIdentifier());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1941 */     expressionStatement.setLineno(lineno);
/* 1942 */     return (AstNode)expressionStatement;
/*      */   }
/*      */   
/*      */   private AstNode block() throws IOException {
/* 1946 */     if (this.currentToken != 88) codeBug(); 
/* 1947 */     consumeToken();
/* 1948 */     int pos = this.ts.tokenBeg;
/* 1949 */     Scope block = new Scope(pos);
/* 1950 */     block.setLineno(this.ts.lineno);
/* 1951 */     pushScope(block);
/*      */     try {
/* 1953 */       statements((AstNode)block);
/* 1954 */       mustMatchToken(89, "msg.no.brace.block", true);
/* 1955 */       block.setLength(this.ts.tokenEnd - pos);
/* 1956 */       return (AstNode)block;
/*      */     } finally {
/* 1958 */       popScope();
/*      */     } 
/*      */   }
/*      */   
/*      */   private AstNode defaultXmlNamespace() throws IOException {
/* 1963 */     if (this.currentToken != 120) codeBug(); 
/* 1964 */     consumeToken();
/* 1965 */     mustHaveXML();
/* 1966 */     setRequiresActivation();
/* 1967 */     int lineno = this.ts.lineno, pos = this.ts.tokenBeg;
/*      */     
/* 1969 */     if (!matchToken(39, true) || !"xml".equals(this.ts.getString())) {
/* 1970 */       reportError("msg.bad.namespace");
/*      */     }
/* 1972 */     if (!matchToken(39, true) || !"namespace".equals(this.ts.getString())) {
/* 1973 */       reportError("msg.bad.namespace");
/*      */     }
/* 1975 */     if (!matchToken(93, true)) {
/* 1976 */       reportError("msg.bad.namespace");
/*      */     }
/*      */     
/* 1979 */     AstNode e = expr();
/* 1980 */     UnaryExpression dxmln = new UnaryExpression(pos, getNodeEnd(e) - pos);
/* 1981 */     dxmln.setOperator(76);
/* 1982 */     dxmln.setOperand(e);
/* 1983 */     dxmln.setLineno(lineno);
/*      */     
/* 1985 */     ExpressionStatement es = new ExpressionStatement((AstNode)dxmln, true);
/* 1986 */     return (AstNode)es;
/*      */   }
/*      */ 
/*      */   
/*      */   private void recordLabel(Label label, LabeledStatement bundle) throws IOException {
/* 1991 */     if (peekToken() != 107) codeBug(); 
/* 1992 */     consumeToken();
/* 1993 */     String name = label.getName();
/* 1994 */     if (this.labelSet == null) {
/* 1995 */       this.labelSet = new HashMap<>();
/*      */     } else {
/* 1997 */       LabeledStatement ls = this.labelSet.get(name);
/* 1998 */       if (ls != null) {
/* 1999 */         if (this.compilerEnv.isIdeMode()) {
/* 2000 */           Label dup = ls.getLabelByName(name);
/* 2001 */           reportError("msg.dup.label", dup.getAbsolutePosition(), dup.getLength());
/*      */         } 
/* 2003 */         reportError("msg.dup.label", label.getPosition(), label.getLength());
/*      */       } 
/*      */     } 
/* 2006 */     bundle.addLabel(label);
/* 2007 */     this.labelSet.put(name, bundle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode nameOrLabel() throws IOException {
/*      */     ExpressionStatement expressionStatement;
/*      */     AstNode astNode1;
/* 2016 */     if (this.currentToken != 39) throw codeBug(); 
/* 2017 */     int pos = this.ts.tokenBeg;
/*      */ 
/*      */     
/* 2020 */     this.currentFlaggedToken |= 0x20000;
/* 2021 */     AstNode expr = expr();
/*      */     
/* 2023 */     if (expr.getType() != 134) {
/* 2024 */       ExpressionStatement expressionStatement1 = new ExpressionStatement(expr, !insideFunction());
/* 2025 */       ((AstNode)expressionStatement1).lineno = expr.lineno;
/* 2026 */       return (AstNode)expressionStatement1;
/*      */     } 
/*      */     
/* 2029 */     LabeledStatement bundle = new LabeledStatement(pos);
/* 2030 */     recordLabel((Label)expr, bundle);
/* 2031 */     bundle.setLineno(this.ts.lineno);
/*      */     
/* 2033 */     AstNode stmt = null;
/* 2034 */     while (peekToken() == 39) {
/* 2035 */       this.currentFlaggedToken |= 0x20000;
/* 2036 */       expr = expr();
/* 2037 */       if (expr.getType() != 134) {
/* 2038 */         expressionStatement = new ExpressionStatement(expr, !insideFunction());
/* 2039 */         autoInsertSemicolon((AstNode)expressionStatement);
/*      */         break;
/*      */       } 
/* 2042 */       recordLabel((Label)expr, bundle);
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 2047 */       this.currentLabel = bundle;
/* 2048 */       if (expressionStatement == null) {
/* 2049 */         astNode1 = statementHelper();
/* 2050 */         int ntt = peekToken();
/* 2051 */         if (ntt == 165 && astNode1
/* 2052 */           .getLineno() == ((Comment)this.scannedComments
/* 2053 */           .get(this.scannedComments.size() - 1)).getLineno()) {
/* 2054 */           astNode1.setInlineComment((AstNode)this.scannedComments.get(this.scannedComments.size() - 1));
/* 2055 */           consumeToken();
/*      */         } 
/*      */       } 
/*      */     } finally {
/* 2059 */       this.currentLabel = null;
/*      */       
/* 2061 */       for (Label lb : bundle.getLabels()) {
/* 2062 */         this.labelSet.remove(lb.getName());
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2068 */     bundle.setLength((astNode1.getParent() == null) ? (getNodeEnd(astNode1) - pos) : getNodeEnd(astNode1));
/* 2069 */     bundle.setStatement(astNode1);
/* 2070 */     return (AstNode)bundle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private VariableDeclaration variables(int declType, int pos, boolean isStatement) throws IOException {
/*      */     int end;
/* 2085 */     VariableDeclaration pn = new VariableDeclaration(pos);
/* 2086 */     pn.setType(declType);
/* 2087 */     pn.setLineno(this.ts.lineno);
/* 2088 */     Comment varjsdocNode = getAndResetJsDoc();
/* 2089 */     if (varjsdocNode != null) {
/* 2090 */       pn.setJsDocNode(varjsdocNode);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 2096 */       AstNode destructuring = null;
/* 2097 */       Name name = null;
/* 2098 */       int tt = peekToken(), kidPos = this.ts.tokenBeg;
/* 2099 */       end = this.ts.tokenEnd;
/*      */       
/* 2101 */       if (tt == 86 || tt == 88) {
/*      */         
/* 2103 */         destructuring = destructuringPrimaryExpr();
/* 2104 */         end = getNodeEnd(destructuring);
/* 2105 */         if (!(destructuring instanceof DestructuringForm))
/* 2106 */           reportError("msg.bad.assign.left", kidPos, end - kidPos); 
/* 2107 */         markDestructuring(destructuring);
/*      */       } else {
/*      */         
/* 2110 */         mustMatchToken(39, "msg.bad.var", true);
/* 2111 */         name = createNameNode();
/* 2112 */         name.setLineno(this.ts.getLineno());
/* 2113 */         if (this.inUseStrictDirective) {
/* 2114 */           String id = this.ts.getString();
/* 2115 */           if ("eval".equals(id) || "arguments".equals(this.ts.getString())) {
/* 2116 */             reportError("msg.bad.id.strict", id);
/*      */           }
/*      */         } 
/* 2119 */         defineSymbol(declType, this.ts.getString(), this.inForInit);
/*      */       } 
/*      */       
/* 2122 */       int lineno = this.ts.lineno;
/*      */       
/* 2124 */       Comment jsdocNode = getAndResetJsDoc();
/*      */       
/* 2126 */       AstNode init = null;
/* 2127 */       if (matchToken(93, true)) {
/* 2128 */         init = assignExpr();
/* 2129 */         end = getNodeEnd(init);
/*      */       } 
/*      */       
/* 2132 */       VariableInitializer vi = new VariableInitializer(kidPos, end - kidPos);
/* 2133 */       if (destructuring != null) {
/* 2134 */         if (init == null && !this.inForInit) {
/* 2135 */           reportError("msg.destruct.assign.no.init");
/*      */         }
/* 2137 */         vi.setTarget(destructuring);
/*      */       } else {
/* 2139 */         vi.setTarget((AstNode)name);
/*      */       } 
/* 2141 */       vi.setInitializer(init);
/* 2142 */       vi.setType(declType);
/* 2143 */       vi.setJsDocNode(jsdocNode);
/* 2144 */       vi.setLineno(lineno);
/* 2145 */       pn.addVariable(vi);
/*      */     }
/* 2147 */     while (matchToken(92, true));
/*      */     
/* 2149 */     pn.setLength(end - pos);
/* 2150 */     pn.setIsStatement(isStatement);
/* 2151 */     return pn;
/*      */   }
/*      */ 
/*      */   
/*      */   private AstNode let(boolean isStatement, int pos) throws IOException {
/* 2156 */     LetNode pn = new LetNode(pos);
/* 2157 */     pn.setLineno(this.ts.lineno);
/* 2158 */     if (mustMatchToken(90, "msg.no.paren.after.let", true)) pn.setLp(this.ts.tokenBeg - pos); 
/* 2159 */     pushScope((Scope)pn);
/*      */     try {
/* 2161 */       VariableDeclaration vars = variables(157, this.ts.tokenBeg, isStatement);
/* 2162 */       pn.setVariables(vars);
/* 2163 */       if (mustMatchToken(91, "msg.no.paren.let", true)) {
/* 2164 */         pn.setRp(this.ts.tokenBeg - pos);
/*      */       }
/* 2166 */       if (isStatement && peekToken() == 88) {
/*      */         
/* 2168 */         consumeToken();
/* 2169 */         int beg = this.ts.tokenBeg;
/* 2170 */         AstNode stmt = statements();
/* 2171 */         mustMatchToken(89, "msg.no.curly.let", true);
/* 2172 */         stmt.setLength(this.ts.tokenEnd - beg);
/* 2173 */         pn.setLength(this.ts.tokenEnd - pos);
/* 2174 */         pn.setBody(stmt);
/* 2175 */         pn.setType(157);
/*      */       } else {
/*      */         
/* 2178 */         AstNode expr = expr();
/* 2179 */         pn.setLength(getNodeEnd(expr) - pos);
/* 2180 */         pn.setBody(expr);
/* 2181 */         if (isStatement) {
/*      */           
/* 2183 */           ExpressionStatement es = new ExpressionStatement((AstNode)pn, !insideFunction());
/* 2184 */           es.setLineno(pn.getLineno());
/* 2185 */           return (AstNode)es;
/*      */         } 
/*      */       } 
/*      */     } finally {
/* 2189 */       popScope();
/*      */     } 
/* 2191 */     return (AstNode)pn;
/*      */   }
/*      */   
/*      */   void defineSymbol(int declType, String name) {
/* 2195 */     defineSymbol(declType, name, false);
/*      */   }
/*      */   
/*      */   void defineSymbol(int declType, String name, boolean ignoreNotInBlock) {
/* 2199 */     if (name == null) {
/* 2200 */       if (this.compilerEnv.isIdeMode()) {
/*      */         return;
/*      */       }
/* 2203 */       codeBug();
/*      */     } 
/* 2205 */     Scope definingScope = this.currentScope.getDefiningScope(name);
/* 2206 */     Symbol symbol = (definingScope != null) ? definingScope.getSymbol(name) : null;
/* 2207 */     int symDeclType = (symbol != null) ? symbol.getDeclType() : -1;
/* 2208 */     if (symbol != null && (symDeclType == 158 || declType == 158 || (definingScope == this.currentScope && symDeclType == 157))) {
/*      */ 
/*      */ 
/*      */       
/* 2212 */       addError((symDeclType == 158) ? "msg.const.redecl" : ((symDeclType == 157) ? "msg.let.redecl" : ((symDeclType == 126) ? "msg.var.redecl" : ((symDeclType == 113) ? "msg.fn.redecl" : "msg.parm.redecl"))), name);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2225 */     switch (declType) {
/*      */       case 157:
/* 2227 */         if (!ignoreNotInBlock && (this.currentScope
/* 2228 */           .getType() == 116 || this.currentScope instanceof Loop)) {
/* 2229 */           addError("msg.let.decl.not.in.block");
/*      */           return;
/*      */         } 
/* 2232 */         this.currentScope.putSymbol(new Symbol(declType, name));
/*      */         return;
/*      */       
/*      */       case 113:
/*      */       case 126:
/*      */       case 158:
/* 2238 */         if (symbol != null) {
/* 2239 */           if (symDeclType == 126) { addStrictWarning("msg.var.redecl", name); }
/* 2240 */           else if (symDeclType == 90)
/* 2241 */           { addStrictWarning("msg.var.hides.arg", name); }
/*      */         
/*      */         } else {
/* 2244 */           this.currentScriptOrFn.putSymbol(new Symbol(declType, name));
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 90:
/* 2249 */         if (symbol != null)
/*      */         {
/*      */           
/* 2252 */           addWarning("msg.dup.parms", name);
/*      */         }
/* 2254 */         this.currentScriptOrFn.putSymbol(new Symbol(declType, name));
/*      */         return;
/*      */     } 
/*      */     
/* 2258 */     throw codeBug();
/*      */   }
/*      */   
/*      */   private AstNode expr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2263 */     AstNode pn = assignExpr();
/* 2264 */     int pos = pn.getPosition();
/* 2265 */     while (matchToken(92, true)) {
/* 2266 */       int opPos = this.ts.tokenBeg;
/* 2267 */       if (this.compilerEnv.isStrictMode() && !pn.hasSideEffects())
/* 2268 */         addStrictWarning("msg.no.side.effects", "", pos, nodeEnd(pn) - pos); 
/* 2269 */       if (peekToken() == 73) reportError("msg.yield.parenthesized"); 
/* 2270 */       infixExpression = new InfixExpression(92, pn, assignExpr(), opPos);
/*      */     } 
/* 2272 */     return (AstNode)infixExpression;
/*      */   } private AstNode assignExpr() throws IOException {
/*      */     Assignment assignment;
/*      */     AstNode astNode1;
/* 2276 */     int tt = peekToken();
/* 2277 */     if (tt == 73) {
/* 2278 */       return returnOrYield(tt, true);
/*      */     }
/* 2280 */     AstNode pn = condExpr();
/* 2281 */     boolean hasEOL = false;
/* 2282 */     tt = peekTokenOrEOL();
/* 2283 */     if (tt == 1) {
/* 2284 */       hasEOL = true;
/* 2285 */       tt = peekToken();
/*      */     } 
/* 2287 */     if (93 <= tt && tt <= 105) {
/* 2288 */       if (this.inDestructuringAssignment)
/*      */       {
/*      */ 
/*      */         
/* 2292 */         reportError("msg.destruct.default.vals");
/*      */       }
/*      */       
/* 2295 */       consumeToken();
/*      */ 
/*      */       
/* 2298 */       Comment jsdocNode = getAndResetJsDoc();
/*      */       
/* 2300 */       markDestructuring(pn);
/* 2301 */       int opPos = this.ts.tokenBeg;
/*      */       
/* 2303 */       assignment = new Assignment(tt, pn, assignExpr(), opPos);
/*      */       
/* 2305 */       if (jsdocNode != null) {
/* 2306 */         assignment.setJsDocNode(jsdocNode);
/*      */       }
/* 2308 */     } else if (tt == 85) {
/*      */ 
/*      */       
/* 2311 */       if (this.currentJsDocComment != null) {
/* 2312 */         assignment.setJsDocNode(getAndResetJsDoc());
/*      */       }
/* 2314 */     } else if (!hasEOL && tt == 168) {
/* 2315 */       consumeToken();
/* 2316 */       astNode1 = arrowFunction((AstNode)assignment);
/*      */     } 
/* 2318 */     return astNode1;
/*      */   }
/*      */   private AstNode condExpr() throws IOException {
/*      */     ConditionalExpression conditionalExpression;
/* 2322 */     AstNode pn = orExpr();
/* 2323 */     if (matchToken(106, true)) {
/* 2324 */       AstNode ifTrue; int line = this.ts.lineno;
/* 2325 */       int qmarkPos = this.ts.tokenBeg, colonPos = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2331 */       boolean wasInForInit = this.inForInit;
/* 2332 */       this.inForInit = false;
/*      */       
/*      */       try {
/* 2335 */         ifTrue = assignExpr();
/*      */       } finally {
/* 2337 */         this.inForInit = wasInForInit;
/*      */       } 
/* 2339 */       if (mustMatchToken(107, "msg.no.colon.cond", true)) colonPos = this.ts.tokenBeg; 
/* 2340 */       AstNode ifFalse = assignExpr();
/* 2341 */       int beg = pn.getPosition(), len = getNodeEnd(ifFalse) - beg;
/* 2342 */       ConditionalExpression ce = new ConditionalExpression(beg, len);
/* 2343 */       ce.setLineno(line);
/* 2344 */       ce.setTestExpression(pn);
/* 2345 */       ce.setTrueExpression(ifTrue);
/* 2346 */       ce.setFalseExpression(ifFalse);
/* 2347 */       ce.setQuestionMarkPosition(qmarkPos - beg);
/* 2348 */       ce.setColonPosition(colonPos - beg);
/* 2349 */       conditionalExpression = ce;
/*      */     } 
/* 2351 */     return (AstNode)conditionalExpression;
/*      */   }
/*      */   private AstNode orExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2355 */     AstNode pn = andExpr();
/* 2356 */     if (matchToken(108, true)) {
/* 2357 */       int opPos = this.ts.tokenBeg;
/* 2358 */       infixExpression = new InfixExpression(108, pn, orExpr(), opPos);
/*      */     } 
/* 2360 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode andExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2364 */     AstNode pn = bitOrExpr();
/* 2365 */     if (matchToken(109, true)) {
/* 2366 */       int opPos = this.ts.tokenBeg;
/* 2367 */       infixExpression = new InfixExpression(109, pn, andExpr(), opPos);
/*      */     } 
/* 2369 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode bitOrExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2373 */     AstNode pn = bitXorExpr();
/* 2374 */     while (matchToken(9, true)) {
/* 2375 */       int opPos = this.ts.tokenBeg;
/* 2376 */       infixExpression = new InfixExpression(9, pn, bitXorExpr(), opPos);
/*      */     } 
/* 2378 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode bitXorExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2382 */     AstNode pn = bitAndExpr();
/* 2383 */     while (matchToken(10, true)) {
/* 2384 */       int opPos = this.ts.tokenBeg;
/* 2385 */       infixExpression = new InfixExpression(10, pn, bitAndExpr(), opPos);
/*      */     } 
/* 2387 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode bitAndExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2391 */     AstNode pn = eqExpr();
/* 2392 */     while (matchToken(11, true)) {
/* 2393 */       int opPos = this.ts.tokenBeg;
/* 2394 */       infixExpression = new InfixExpression(11, pn, eqExpr(), opPos);
/*      */     } 
/* 2396 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode eqExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2400 */     AstNode pn = relExpr();
/*      */     while (true) {
/* 2402 */       int parseToken, tt = peekToken(), opPos = this.ts.tokenBeg;
/* 2403 */       switch (tt) {
/*      */         case 12:
/*      */         case 13:
/*      */         case 46:
/*      */         case 47:
/* 2408 */           consumeToken();
/* 2409 */           parseToken = tt;
/* 2410 */           if (this.compilerEnv.getLanguageVersion() == 120)
/*      */           {
/* 2412 */             if (tt == 12) { parseToken = 46; }
/* 2413 */             else if (tt == 13) { parseToken = 47; }
/*      */              } 
/* 2415 */           infixExpression = new InfixExpression(parseToken, pn, relExpr(), opPos);
/*      */           continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 2420 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode relExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2424 */     AstNode pn = shiftExpr();
/*      */     while (true) {
/* 2426 */       int tt = peekToken(), opPos = this.ts.tokenBeg;
/* 2427 */       switch (tt) {
/*      */         case 52:
/* 2429 */           if (this.inForInit)
/*      */             break; 
/*      */         case 14:
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/*      */         case 53:
/* 2436 */           consumeToken();
/* 2437 */           infixExpression = new InfixExpression(tt, pn, shiftExpr(), opPos);
/*      */           continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 2442 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode shiftExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2446 */     AstNode pn = addExpr();
/*      */     while (true) {
/* 2448 */       int tt = peekToken(), opPos = this.ts.tokenBeg;
/* 2449 */       switch (tt) {
/*      */         case 18:
/*      */         case 19:
/*      */         case 20:
/* 2453 */           consumeToken();
/* 2454 */           infixExpression = new InfixExpression(tt, pn, addExpr(), opPos);
/*      */           continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 2459 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode addExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2463 */     AstNode pn = mulExpr();
/*      */     while (true) {
/* 2465 */       int tt = peekToken(), opPos = this.ts.tokenBeg;
/* 2466 */       if (tt == 21 || tt == 22) {
/* 2467 */         consumeToken();
/* 2468 */         infixExpression = new InfixExpression(tt, pn, mulExpr(), opPos);
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 2473 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode mulExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2477 */     AstNode pn = expExpr();
/*      */     while (true) {
/* 2479 */       int tt = peekToken(), opPos = this.ts.tokenBeg;
/* 2480 */       switch (tt) {
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/* 2484 */           consumeToken();
/* 2485 */           infixExpression = new InfixExpression(tt, pn, expExpr(), opPos);
/*      */           continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 2490 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode expExpr() throws IOException {
/*      */     InfixExpression infixExpression;
/* 2494 */     AstNode pn = unaryExpr();
/*      */     while (true) {
/* 2496 */       int tt = peekToken(), opPos = this.ts.tokenBeg;
/* 2497 */       switch (tt) {
/*      */         case 75:
/* 2499 */           if (pn instanceof UnaryExpression) {
/* 2500 */             reportError("msg.no.unary.expr.on.left.exp", 
/*      */                 
/* 2502 */                 AstNode.operatorToString(pn.getType()));
/* 2503 */             return (AstNode)makeErrorNode();
/*      */           } 
/* 2505 */           consumeToken();
/* 2506 */           infixExpression = new InfixExpression(tt, pn, expExpr(), opPos);
/*      */           continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 2511 */     return (AstNode)infixExpression;
/*      */   }
/*      */   private AstNode unaryExpr() throws IOException {
/*      */     UnaryExpression unaryExpression4, unaryExpression3, unaryExpression2, unaryExpression1;
/*      */     UpdateExpression expr;
/* 2516 */     int tt = peekToken();
/* 2517 */     if (tt == 165) {
/* 2518 */       consumeToken();
/* 2519 */       tt = peekUntilNonComment(tt);
/*      */     } 
/* 2521 */     int line = this.ts.lineno;
/*      */     
/* 2523 */     switch (tt) {
/*      */       case 26:
/*      */       case 27:
/*      */       case 32:
/*      */       case 130:
/* 2528 */         consumeToken();
/* 2529 */         unaryExpression4 = new UnaryExpression(tt, this.ts.tokenBeg, unaryExpr());
/* 2530 */         unaryExpression4.setLineno(line);
/* 2531 */         return (AstNode)unaryExpression4;
/*      */       
/*      */       case 21:
/* 2534 */         consumeToken();
/*      */         
/* 2536 */         unaryExpression3 = new UnaryExpression(28, this.ts.tokenBeg, unaryExpr());
/* 2537 */         unaryExpression3.setLineno(line);
/* 2538 */         return (AstNode)unaryExpression3;
/*      */       
/*      */       case 22:
/* 2541 */         consumeToken();
/*      */         
/* 2543 */         unaryExpression2 = new UnaryExpression(29, this.ts.tokenBeg, unaryExpr());
/* 2544 */         unaryExpression2.setLineno(line);
/* 2545 */         return (AstNode)unaryExpression2;
/*      */       
/*      */       case 110:
/*      */       case 111:
/* 2549 */         consumeToken();
/* 2550 */         expr = new UpdateExpression(tt, this.ts.tokenBeg, memberExpr(true));
/* 2551 */         expr.setLineno(line);
/* 2552 */         checkBadIncDec(expr);
/* 2553 */         return (AstNode)expr;
/*      */       
/*      */       case 31:
/* 2556 */         consumeToken();
/* 2557 */         unaryExpression1 = new UnaryExpression(tt, this.ts.tokenBeg, unaryExpr());
/* 2558 */         unaryExpression1.setLineno(line);
/* 2559 */         return (AstNode)unaryExpression1;
/*      */       
/*      */       case -1:
/* 2562 */         consumeToken();
/* 2563 */         return (AstNode)makeErrorNode();
/*      */       
/*      */       case 14:
/* 2566 */         if (this.compilerEnv.isXmlAvailable()) {
/* 2567 */           consumeToken();
/* 2568 */           return memberExprTail(true, xmlInitializer());
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 2574 */     AstNode pn = memberExpr(true);
/*      */     
/* 2576 */     tt = peekTokenOrEOL();
/* 2577 */     if (tt != 110 && tt != 111) {
/* 2578 */       return pn;
/*      */     }
/* 2580 */     consumeToken();
/* 2581 */     UpdateExpression uexpr = new UpdateExpression(tt, this.ts.tokenBeg, pn, true);
/* 2582 */     uexpr.setLineno(line);
/* 2583 */     checkBadIncDec(uexpr);
/* 2584 */     return (AstNode)uexpr;
/*      */   }
/*      */ 
/*      */   
/*      */   private AstNode xmlInitializer() throws IOException {
/* 2589 */     if (this.currentToken != 14) codeBug(); 
/* 2590 */     int pos = this.ts.tokenBeg, tt = this.ts.getFirstXMLToken();
/* 2591 */     if (tt != 149 && tt != 152) {
/* 2592 */       reportError("msg.syntax");
/* 2593 */       return (AstNode)makeErrorNode();
/*      */     } 
/*      */     
/* 2596 */     XmlLiteral pn = new XmlLiteral(pos);
/* 2597 */     pn.setLineno(this.ts.lineno);
/*      */     
/* 2599 */     for (;; tt = this.ts.getNextXMLToken()) {
/* 2600 */       int beg; AstNode expr; XmlExpression xexpr; switch (tt) {
/*      */         case 149:
/* 2602 */           pn.addFragment((XmlFragment)new XmlString(this.ts.tokenBeg, this.ts.getString()));
/* 2603 */           mustMatchToken(88, "msg.syntax", true);
/* 2604 */           beg = this.ts.tokenBeg;
/*      */ 
/*      */ 
/*      */           
/* 2608 */           expr = (peekToken() == 89) ? (AstNode)new EmptyExpression(beg, this.ts.tokenEnd - beg) : expr();
/* 2609 */           mustMatchToken(89, "msg.syntax", true);
/* 2610 */           xexpr = new XmlExpression(beg, expr);
/* 2611 */           xexpr.setIsXmlAttribute(this.ts.isXMLAttribute());
/* 2612 */           xexpr.setLength(this.ts.tokenEnd - beg);
/* 2613 */           pn.addFragment((XmlFragment)xexpr);
/*      */           break;
/*      */         
/*      */         case 152:
/* 2617 */           pn.addFragment((XmlFragment)new XmlString(this.ts.tokenBeg, this.ts.getString()));
/* 2618 */           return (AstNode)pn;
/*      */         
/*      */         default:
/* 2621 */           reportError("msg.syntax");
/* 2622 */           return (AstNode)makeErrorNode();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private List<AstNode> argumentList() throws IOException {
/* 2628 */     if (matchToken(91, true)) return null;
/*      */     
/* 2630 */     List<AstNode> result = new ArrayList<>();
/* 2631 */     boolean wasInForInit = this.inForInit;
/* 2632 */     this.inForInit = false;
/*      */ 
/*      */     
/* 2635 */     try { while (peekToken() != 91)
/*      */       
/*      */       { 
/*      */         
/* 2639 */         if (peekToken() == 73) {
/* 2640 */           reportError("msg.yield.parenthesized");
/*      */         }
/* 2642 */         AstNode en = assignExpr();
/* 2643 */         if (peekToken() == 123) {
/*      */           try {
/* 2645 */             result.add(generatorExpression(en, 0, true));
/* 2646 */           } catch (IOException iOException) {}
/*      */         }
/*      */         else {
/*      */           
/* 2650 */           result.add(en);
/*      */         } 
/* 2652 */         if (!matchToken(92, true))
/*      */           break;  }  }
/* 2654 */     finally { this.inForInit = wasInForInit; }
/*      */ 
/*      */     
/* 2657 */     mustMatchToken(91, "msg.no.paren.arg", true);
/* 2658 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode memberExpr(boolean allowCallSyntax) throws IOException {
/*      */     NewExpression newExpression;
/* 2667 */     int tt = peekToken(), lineno = this.ts.lineno;
/*      */ 
/*      */     
/* 2670 */     if (tt != 30) {
/* 2671 */       AstNode pn = primaryExpr();
/*      */     } else {
/* 2673 */       consumeToken();
/* 2674 */       int pos = this.ts.tokenBeg;
/* 2675 */       NewExpression nx = new NewExpression(pos);
/*      */       
/* 2677 */       AstNode target = memberExpr(false);
/* 2678 */       int end = getNodeEnd(target);
/* 2679 */       nx.setTarget(target);
/*      */       
/* 2681 */       int lp = -1;
/* 2682 */       if (matchToken(90, true)) {
/* 2683 */         lp = this.ts.tokenBeg;
/* 2684 */         List<AstNode> args = argumentList();
/* 2685 */         if (args != null && args.size() > 65536)
/* 2686 */           reportError("msg.too.many.constructor.args"); 
/* 2687 */         int rp = this.ts.tokenBeg;
/* 2688 */         end = this.ts.tokenEnd;
/* 2689 */         if (args != null) nx.setArguments(args); 
/* 2690 */         nx.setParens(lp - pos, rp - pos);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2697 */       if (matchToken(88, true)) {
/* 2698 */         ObjectLiteral initializer = objectLiteral();
/* 2699 */         end = getNodeEnd((AstNode)initializer);
/* 2700 */         nx.setInitializer(initializer);
/*      */       } 
/* 2702 */       nx.setLength(end - pos);
/* 2703 */       newExpression = nx;
/*      */     } 
/* 2705 */     newExpression.setLineno(lineno);
/* 2706 */     AstNode tail = memberExprTail(allowCallSyntax, (AstNode)newExpression);
/* 2707 */     return tail;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode memberExprTail(boolean allowCallSyntax, AstNode pn) throws IOException {
/*      */     AstNode astNode;
/* 2720 */     if (pn == null) codeBug(); 
/* 2721 */     int pos = pn.getPosition(); while (true) {
/*      */       XmlDotQuery xmlDotQuery1; ElementGet elementGet1; FunctionCall functionCall1; int lineno, opPos, rp; AstNode filter; int end; XmlDotQuery q; int lb, rb; AstNode expr; ElementGet g;
/*      */       FunctionCall f;
/*      */       List<AstNode> args;
/* 2725 */       int currentFlagTOken, tt = peekToken();
/* 2726 */       switch (tt) {
/*      */         case 112:
/*      */         case 147:
/* 2729 */           lineno = this.ts.lineno;
/* 2730 */           pn = propertyAccess(tt, pn);
/* 2731 */           pn.setLineno(lineno);
/*      */           continue;
/*      */         
/*      */         case 150:
/* 2735 */           consumeToken();
/* 2736 */           opPos = this.ts.tokenBeg; rp = -1;
/* 2737 */           lineno = this.ts.lineno;
/* 2738 */           mustHaveXML();
/* 2739 */           setRequiresActivation();
/* 2740 */           filter = expr();
/* 2741 */           end = getNodeEnd(filter);
/* 2742 */           if (mustMatchToken(91, "msg.no.paren", true)) {
/* 2743 */             rp = this.ts.tokenBeg;
/* 2744 */             end = this.ts.tokenEnd;
/*      */           } 
/* 2746 */           q = new XmlDotQuery(pos, end - pos);
/* 2747 */           q.setLeft(pn);
/* 2748 */           q.setRight(filter);
/* 2749 */           q.setOperatorPosition(opPos);
/* 2750 */           q.setRp(rp - pos);
/* 2751 */           q.setLineno(lineno);
/* 2752 */           xmlDotQuery1 = q;
/*      */           continue;
/*      */         
/*      */         case 86:
/* 2756 */           consumeToken();
/* 2757 */           lb = this.ts.tokenBeg; rb = -1;
/* 2758 */           lineno = this.ts.lineno;
/* 2759 */           expr = expr();
/* 2760 */           end = getNodeEnd(expr);
/* 2761 */           if (mustMatchToken(87, "msg.no.bracket.index", true)) {
/* 2762 */             rb = this.ts.tokenBeg;
/* 2763 */             end = this.ts.tokenEnd;
/*      */           } 
/* 2765 */           g = new ElementGet(pos, end - pos);
/* 2766 */           g.setTarget((AstNode)xmlDotQuery1);
/* 2767 */           g.setElement(expr);
/* 2768 */           g.setParens(lb, rb);
/* 2769 */           g.setLineno(lineno);
/* 2770 */           elementGet1 = g;
/*      */           continue;
/*      */         
/*      */         case 90:
/* 2774 */           if (!allowCallSyntax) {
/*      */             break;
/*      */           }
/* 2777 */           lineno = this.ts.lineno;
/* 2778 */           consumeToken();
/* 2779 */           checkCallRequiresActivation((AstNode)elementGet1);
/* 2780 */           f = new FunctionCall(pos);
/* 2781 */           f.setTarget((AstNode)elementGet1);
/*      */ 
/*      */           
/* 2784 */           f.setLineno(lineno);
/* 2785 */           f.setLp(this.ts.tokenBeg - pos);
/* 2786 */           args = argumentList();
/* 2787 */           if (args != null && args.size() > 65536)
/* 2788 */             reportError("msg.too.many.function.args"); 
/* 2789 */           f.setArguments(args);
/* 2790 */           f.setRp(this.ts.tokenBeg - pos);
/* 2791 */           f.setLength(this.ts.tokenEnd - pos);
/* 2792 */           functionCall1 = f;
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 165:
/* 2797 */           currentFlagTOken = this.currentFlaggedToken;
/* 2798 */           peekUntilNonComment(tt);
/* 2799 */           this.currentFlaggedToken = ((this.currentFlaggedToken & 0x10000) != 0) ? this.currentFlaggedToken : currentFlagTOken;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 170:
/* 2805 */           consumeToken();
/* 2806 */           astNode = taggedTemplateLiteral((AstNode)functionCall1);
/*      */           continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/* 2812 */     return astNode;
/*      */   }
/*      */   
/*      */   private AstNode taggedTemplateLiteral(AstNode pn) throws IOException {
/* 2816 */     AstNode templateLiteral = templateLiteral(true);
/* 2817 */     TaggedTemplateLiteral tagged = new TaggedTemplateLiteral();
/* 2818 */     tagged.setTarget(pn);
/* 2819 */     tagged.setTemplateLiteral(templateLiteral);
/* 2820 */     return (AstNode)tagged;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode propertyAccess(int tt, AstNode pn) throws IOException {
/*      */     String name;
/* 2830 */     if (pn == null) codeBug(); 
/* 2831 */     int memberTypeFlags = 0, lineno = this.ts.lineno, dotPos = this.ts.tokenBeg;
/* 2832 */     consumeToken();
/*      */     
/* 2834 */     if (tt == 147) {
/* 2835 */       mustHaveXML();
/* 2836 */       memberTypeFlags = 4;
/*      */     } 
/*      */     
/* 2839 */     if (!this.compilerEnv.isXmlAvailable()) {
/* 2840 */       int maybeName = nextToken();
/* 2841 */       if (maybeName != 39 && (
/* 2842 */         !this.compilerEnv.isReservedKeywordAsIdentifier() || 
/* 2843 */         !TokenStream.isKeyword(this.ts
/* 2844 */           .getString(), this.compilerEnv
/* 2845 */           .getLanguageVersion(), this.inUseStrictDirective)))
/*      */       {
/* 2847 */         reportError("msg.no.name.after.dot");
/*      */       }
/*      */       
/* 2850 */       Name name1 = createNameNode(true, 33);
/* 2851 */       PropertyGet pg = new PropertyGet(pn, name1, dotPos);
/* 2852 */       pg.setLineno(lineno);
/* 2853 */       return (AstNode)pg;
/*      */     } 
/*      */     
/* 2856 */     AstNode ref = null;
/*      */     
/* 2858 */     int token = nextToken();
/* 2859 */     switch (token) {
/*      */       
/*      */       case 50:
/* 2862 */         saveNameTokenData(this.ts.tokenBeg, "throw", this.ts.lineno);
/* 2863 */         ref = propertyName(-1, memberTypeFlags);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 39:
/* 2868 */         ref = propertyName(-1, memberTypeFlags);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 23:
/* 2873 */         saveNameTokenData(this.ts.tokenBeg, "*", this.ts.lineno);
/* 2874 */         ref = propertyName(-1, memberTypeFlags);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 151:
/* 2880 */         ref = attributeAccess();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 131:
/* 2885 */         name = this.ts.getString();
/* 2886 */         saveNameTokenData(this.ts.tokenBeg, name, this.ts.lineno);
/* 2887 */         ref = propertyName(-1, memberTypeFlags);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2892 */         if (this.compilerEnv.isReservedKeywordAsIdentifier()) {
/*      */           
/* 2894 */           name = Token.keywordToName(token);
/* 2895 */           if (name != null) {
/* 2896 */             saveNameTokenData(this.ts.tokenBeg, name, this.ts.lineno);
/* 2897 */             ref = propertyName(-1, memberTypeFlags);
/*      */             break;
/*      */           } 
/*      */         } 
/* 2901 */         reportError("msg.no.name.after.dot");
/* 2902 */         return (AstNode)makeErrorNode();
/*      */     } 
/*      */     
/* 2905 */     boolean xml = ref instanceof org.mozilla.javascript.ast.XmlRef;
/* 2906 */     InfixExpression result = xml ? (InfixExpression)new XmlMemberGet() : (InfixExpression)new PropertyGet();
/* 2907 */     if (xml && tt == 112) result.setType(112); 
/* 2908 */     int pos = pn.getPosition();
/* 2909 */     result.setPosition(pos);
/* 2910 */     result.setLength(getNodeEnd(ref) - pos);
/* 2911 */     result.setOperatorPosition(dotPos - pos);
/* 2912 */     result.setLineno(pn.getLineno());
/* 2913 */     result.setLeft(pn);
/* 2914 */     result.setRight(ref);
/* 2915 */     return (AstNode)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode attributeAccess() throws IOException {
/* 2927 */     int tt = nextToken(), atPos = this.ts.tokenBeg;
/*      */     
/* 2929 */     switch (tt) {
/*      */       
/*      */       case 39:
/* 2932 */         return propertyName(atPos, 0);
/*      */ 
/*      */       
/*      */       case 23:
/* 2936 */         saveNameTokenData(this.ts.tokenBeg, "*", this.ts.lineno);
/* 2937 */         return propertyName(atPos, 0);
/*      */ 
/*      */       
/*      */       case 86:
/* 2941 */         return (AstNode)xmlElemRef(atPos, null, -1);
/*      */     } 
/*      */     
/* 2944 */     reportError("msg.no.name.after.xmlAttr");
/* 2945 */     return (AstNode)makeErrorNode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode propertyName(int atPos, int memberTypeFlags) throws IOException {
/* 2960 */     int pos = (atPos != -1) ? atPos : this.ts.tokenBeg, lineno = this.ts.lineno;
/* 2961 */     int colonPos = -1;
/* 2962 */     Name name = createNameNode(true, this.currentToken);
/* 2963 */     Name ns = null;
/*      */     
/* 2965 */     if (matchToken(148, true)) {
/* 2966 */       ns = name;
/* 2967 */       colonPos = this.ts.tokenBeg;
/*      */       
/* 2969 */       switch (nextToken()) {
/*      */         
/*      */         case 39:
/* 2972 */           name = createNameNode();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 23:
/* 2977 */           saveNameTokenData(this.ts.tokenBeg, "*", this.ts.lineno);
/* 2978 */           name = createNameNode(false, -1);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 86:
/* 2983 */           return (AstNode)xmlElemRef(atPos, ns, colonPos);
/*      */         
/*      */         default:
/* 2986 */           reportError("msg.no.name.after.coloncolon");
/* 2987 */           return (AstNode)makeErrorNode();
/*      */       } 
/*      */     
/*      */     } 
/* 2991 */     if (ns == null && memberTypeFlags == 0 && atPos == -1) {
/* 2992 */       return (AstNode)name;
/*      */     }
/*      */     
/* 2995 */     XmlPropRef ref = new XmlPropRef(pos, getNodeEnd((AstNode)name) - pos);
/* 2996 */     ref.setAtPos(atPos);
/* 2997 */     ref.setNamespace(ns);
/* 2998 */     ref.setColonPos(colonPos);
/* 2999 */     ref.setPropName(name);
/* 3000 */     ref.setLineno(lineno);
/* 3001 */     return (AstNode)ref;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XmlElemRef xmlElemRef(int atPos, Name namespace, int colonPos) throws IOException {
/* 3009 */     int lb = this.ts.tokenBeg, rb = -1, pos = (atPos != -1) ? atPos : lb;
/* 3010 */     AstNode expr = expr();
/* 3011 */     int end = getNodeEnd(expr);
/* 3012 */     if (mustMatchToken(87, "msg.no.bracket.index", true)) {
/* 3013 */       rb = this.ts.tokenBeg;
/* 3014 */       end = this.ts.tokenEnd;
/*      */     } 
/* 3016 */     XmlElemRef ref = new XmlElemRef(pos, end - pos);
/* 3017 */     ref.setNamespace(namespace);
/* 3018 */     ref.setColonPos(colonPos);
/* 3019 */     ref.setAtPos(atPos);
/* 3020 */     ref.setExpression(expr);
/* 3021 */     ref.setBrackets(lb, rb);
/* 3022 */     return ref;
/*      */   }
/*      */   
/*      */   private AstNode destructuringPrimaryExpr() throws IOException, ParserException {
/*      */     try {
/* 3027 */       this.inDestructuringAssignment = true;
/* 3028 */       return primaryExpr();
/*      */     } finally {
/* 3030 */       this.inDestructuringAssignment = false;
/*      */     } 
/*      */   } private AstNode primaryExpr() throws IOException {
/*      */     int pos, end;
/*      */     RegExpLiteral re;
/* 3035 */     int ttFlagged = peekFlaggedToken();
/* 3036 */     int tt = ttFlagged & 0xFFFF;
/*      */     
/* 3038 */     switch (tt)
/*      */     { case 113:
/* 3040 */         consumeToken();
/* 3041 */         return (AstNode)function(2);
/*      */       
/*      */       case 86:
/* 3044 */         consumeToken();
/* 3045 */         return arrayLiteral();
/*      */       
/*      */       case 88:
/* 3048 */         consumeToken();
/* 3049 */         return (AstNode)objectLiteral();
/*      */       
/*      */       case 157:
/* 3052 */         consumeToken();
/* 3053 */         return let(false, this.ts.tokenBeg);
/*      */       
/*      */       case 90:
/* 3056 */         consumeToken();
/* 3057 */         return parenExpr();
/*      */       
/*      */       case 151:
/* 3060 */         consumeToken();
/* 3061 */         mustHaveXML();
/* 3062 */         return attributeAccess();
/*      */       
/*      */       case 39:
/* 3065 */         consumeToken();
/* 3066 */         return name(ttFlagged, tt);
/*      */ 
/*      */       
/*      */       case 40:
/*      */       case 83:
/* 3071 */         consumeToken();
/* 3072 */         return createNumericLiteral(tt, false);
/*      */ 
/*      */       
/*      */       case 41:
/* 3076 */         consumeToken();
/* 3077 */         return (AstNode)createStringLiteral();
/*      */       
/*      */       case 24:
/*      */       case 103:
/* 3081 */         consumeToken();
/*      */         
/* 3083 */         this.ts.readRegExp(tt);
/* 3084 */         pos = this.ts.tokenBeg; end = this.ts.tokenEnd;
/* 3085 */         re = new RegExpLiteral(pos, end - pos);
/* 3086 */         re.setValue(this.ts.getString());
/* 3087 */         re.setFlags(this.ts.readAndClearRegExpFlags());
/* 3088 */         return (AstNode)re;
/*      */       
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 45:
/* 3094 */         consumeToken();
/* 3095 */         pos = this.ts.tokenBeg;
/* 3096 */         end = this.ts.tokenEnd;
/* 3097 */         return (AstNode)new KeywordLiteral(pos, end - pos, tt);
/*      */       
/*      */       case 170:
/* 3100 */         consumeToken();
/* 3101 */         return templateLiteral(false);
/*      */       
/*      */       case 131:
/* 3104 */         consumeToken();
/* 3105 */         reportError("msg.reserved.id", this.ts.getString());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3124 */         consumeToken();
/* 3125 */         return (AstNode)makeErrorNode();case -1: consumeToken(); consumeToken(); return (AstNode)makeErrorNode();case 0: consumeToken(); reportError("msg.unexpected.eof"); consumeToken(); return (AstNode)makeErrorNode(); }  consumeToken(); reportError("msg.syntax"); consumeToken(); return (AstNode)makeErrorNode();
/*      */   }
/*      */   
/*      */   private AstNode parenExpr() throws IOException {
/* 3129 */     boolean wasInForInit = this.inForInit;
/* 3130 */     this.inForInit = false;
/*      */     try {
/* 3132 */       Comment jsdocNode = getAndResetJsDoc();
/* 3133 */       int lineno = this.ts.lineno;
/* 3134 */       int begin = this.ts.tokenBeg;
/* 3135 */       AstNode e = (peekToken() == 91) ? (AstNode)new EmptyExpression(begin) : expr();
/* 3136 */       if (peekToken() == 123) {
/* 3137 */         return generatorExpression(e, begin);
/*      */       }
/* 3139 */       mustMatchToken(91, "msg.no.paren", true);
/* 3140 */       if (e.getType() == 132 && peekToken() != 168) {
/* 3141 */         reportError("msg.syntax");
/* 3142 */         return (AstNode)makeErrorNode();
/*      */       } 
/* 3144 */       int length = this.ts.tokenEnd - begin;
/* 3145 */       ParenthesizedExpression pn = new ParenthesizedExpression(begin, length, e);
/* 3146 */       pn.setLineno(lineno);
/* 3147 */       if (jsdocNode == null) {
/* 3148 */         jsdocNode = getAndResetJsDoc();
/*      */       }
/* 3150 */       if (jsdocNode != null) {
/* 3151 */         pn.setJsDocNode(jsdocNode);
/*      */       }
/* 3153 */       return (AstNode)pn;
/*      */     } finally {
/* 3155 */       this.inForInit = wasInForInit;
/*      */     } 
/*      */   }
/*      */   
/*      */   private AstNode name(int ttFlagged, int tt) throws IOException {
/* 3160 */     String nameString = this.ts.getString();
/* 3161 */     int namePos = this.ts.tokenBeg, nameLineno = this.ts.lineno;
/* 3162 */     if (0 != (ttFlagged & 0x20000) && peekToken() == 107) {
/*      */ 
/*      */       
/* 3165 */       Label label = new Label(namePos, this.ts.tokenEnd - namePos);
/* 3166 */       label.setName(nameString);
/* 3167 */       label.setLineno(this.ts.lineno);
/* 3168 */       return (AstNode)label;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3173 */     saveNameTokenData(namePos, nameString, nameLineno);
/*      */     
/* 3175 */     if (this.compilerEnv.isXmlAvailable()) {
/* 3176 */       return propertyName(-1, 0);
/*      */     }
/* 3178 */     return (AstNode)createNameNode(true, 39);
/*      */   }
/*      */ 
/*      */   
/*      */   private AstNode arrayLiteral() throws IOException {
/* 3183 */     if (this.currentToken != 86) codeBug(); 
/* 3184 */     int pos = this.ts.tokenBeg, end = this.ts.tokenEnd;
/* 3185 */     List<AstNode> elements = new ArrayList<>();
/* 3186 */     ArrayLiteral pn = new ArrayLiteral(pos);
/* 3187 */     boolean after_lb_or_comma = true;
/* 3188 */     int afterComma = -1;
/* 3189 */     int skipCount = 0;
/*      */     while (true) {
/* 3191 */       int tt = peekToken();
/* 3192 */       if (tt == 92) {
/* 3193 */         consumeToken();
/* 3194 */         afterComma = this.ts.tokenEnd;
/* 3195 */         if (!after_lb_or_comma) {
/* 3196 */           after_lb_or_comma = true; continue;
/*      */         } 
/* 3198 */         elements.add(new EmptyExpression(this.ts.tokenBeg, 1));
/* 3199 */         skipCount++; continue;
/*      */       } 
/* 3201 */       if (tt == 165) {
/* 3202 */         consumeToken(); continue;
/* 3203 */       }  if (tt == 87) {
/* 3204 */         consumeToken();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3210 */         end = this.ts.tokenEnd;
/* 3211 */         pn.setDestructuringLength(elements.size() + (after_lb_or_comma ? 1 : 0));
/* 3212 */         pn.setSkipCount(skipCount);
/* 3213 */         if (afterComma != -1) warnTrailingComma(pos, elements, afterComma);  break;
/*      */       } 
/* 3215 */       if (tt == 123 && !after_lb_or_comma && elements.size() == 1)
/* 3216 */         return arrayComprehension(elements.get(0), pos); 
/* 3217 */       if (tt == 0) {
/* 3218 */         reportError("msg.no.bracket.arg");
/*      */         break;
/*      */       } 
/* 3221 */       if (!after_lb_or_comma) {
/* 3222 */         reportError("msg.no.bracket.arg");
/*      */       }
/* 3224 */       elements.add(assignExpr());
/* 3225 */       after_lb_or_comma = false;
/* 3226 */       afterComma = -1;
/*      */     } 
/*      */     
/* 3229 */     for (AstNode e : elements) {
/* 3230 */       pn.addElement(e);
/*      */     }
/* 3232 */     pn.setLength(end - pos);
/* 3233 */     return (AstNode)pn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode arrayComprehension(AstNode result, int pos) throws IOException {
/* 3244 */     List<ArrayComprehensionLoop> loops = new ArrayList<>();
/* 3245 */     while (peekToken() == 123) {
/* 3246 */       loops.add(arrayComprehensionLoop());
/*      */     }
/* 3248 */     int ifPos = -1;
/* 3249 */     ConditionData data = null;
/* 3250 */     if (peekToken() == 116) {
/* 3251 */       consumeToken();
/* 3252 */       ifPos = this.ts.tokenBeg - pos;
/* 3253 */       data = condition();
/*      */     } 
/* 3255 */     mustMatchToken(87, "msg.no.bracket.arg", true);
/* 3256 */     ArrayComprehension pn = new ArrayComprehension(pos, this.ts.tokenEnd - pos);
/* 3257 */     pn.setResult(result);
/* 3258 */     pn.setLoops(loops);
/* 3259 */     if (data != null) {
/* 3260 */       pn.setIfPosition(ifPos);
/* 3261 */       pn.setFilter(data.condition);
/* 3262 */       pn.setFilterLp(data.lp - pos);
/* 3263 */       pn.setFilterRp(data.rp - pos);
/*      */     } 
/* 3265 */     return (AstNode)pn;
/*      */   }
/*      */   
/*      */   private ArrayComprehensionLoop arrayComprehensionLoop() throws IOException {
/* 3269 */     if (nextToken() != 123) codeBug(); 
/* 3270 */     int pos = this.ts.tokenBeg;
/* 3271 */     int eachPos = -1, lp = -1, rp = -1, inPos = -1;
/* 3272 */     boolean isForOf = false;
/* 3273 */     ArrayComprehensionLoop pn = new ArrayComprehensionLoop(pos);
/*      */     
/* 3275 */     pushScope((Scope)pn); try {
/*      */       Name name;
/* 3277 */       if (matchToken(39, true)) {
/* 3278 */         if (this.ts.getString().equals("each")) {
/* 3279 */           eachPos = this.ts.tokenBeg - pos;
/*      */         } else {
/* 3281 */           reportError("msg.no.paren.for");
/*      */         } 
/*      */       }
/* 3284 */       if (mustMatchToken(90, "msg.no.paren.for", true)) {
/* 3285 */         lp = this.ts.tokenBeg - pos;
/*      */       }
/*      */       
/* 3288 */       AstNode iter = null;
/* 3289 */       switch (peekToken()) {
/*      */         
/*      */         case 86:
/*      */         case 88:
/* 3293 */           iter = destructuringPrimaryExpr();
/* 3294 */           markDestructuring(iter);
/*      */           break;
/*      */         case 39:
/* 3297 */           consumeToken();
/* 3298 */           name = createNameNode();
/*      */           break;
/*      */         default:
/* 3301 */           reportError("msg.bad.var");
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 3306 */       if (name.getType() == 39) {
/* 3307 */         defineSymbol(157, this.ts.getString(), true);
/*      */       }
/*      */       
/* 3310 */       switch (nextToken()) {
/*      */         case 52:
/* 3312 */           inPos = this.ts.tokenBeg - pos;
/*      */           break;
/*      */         case 39:
/* 3315 */           if ("of".equals(this.ts.getString())) {
/* 3316 */             if (eachPos != -1) {
/* 3317 */               reportError("msg.invalid.for.each");
/*      */             }
/* 3319 */             inPos = this.ts.tokenBeg - pos;
/* 3320 */             isForOf = true;
/*      */             break;
/*      */           } 
/*      */         
/*      */         default:
/* 3325 */           reportError("msg.in.after.for.name"); break;
/*      */       } 
/* 3327 */       AstNode obj = expr();
/* 3328 */       if (mustMatchToken(91, "msg.no.paren.for.ctrl", true)) rp = this.ts.tokenBeg - pos;
/*      */       
/* 3330 */       pn.setLength(this.ts.tokenEnd - pos);
/* 3331 */       pn.setIterator((AstNode)name);
/* 3332 */       pn.setIteratedObject(obj);
/* 3333 */       pn.setInPosition(inPos);
/* 3334 */       pn.setEachPosition(eachPos);
/* 3335 */       pn.setIsForEach((eachPos != -1));
/* 3336 */       pn.setParens(lp, rp);
/* 3337 */       pn.setIsForOf(isForOf);
/* 3338 */       return pn;
/*      */     } finally {
/* 3340 */       popScope();
/*      */     } 
/*      */   }
/*      */   
/*      */   private AstNode generatorExpression(AstNode result, int pos) throws IOException {
/* 3345 */     return generatorExpression(result, pos, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private AstNode generatorExpression(AstNode result, int pos, boolean inFunctionParams) throws IOException {
/* 3351 */     List<GeneratorExpressionLoop> loops = new ArrayList<>();
/* 3352 */     while (peekToken() == 123) {
/* 3353 */       loops.add(generatorExpressionLoop());
/*      */     }
/* 3355 */     int ifPos = -1;
/* 3356 */     ConditionData data = null;
/* 3357 */     if (peekToken() == 116) {
/* 3358 */       consumeToken();
/* 3359 */       ifPos = this.ts.tokenBeg - pos;
/* 3360 */       data = condition();
/*      */     } 
/* 3362 */     if (!inFunctionParams) {
/* 3363 */       mustMatchToken(91, "msg.no.paren.let", true);
/*      */     }
/* 3365 */     GeneratorExpression pn = new GeneratorExpression(pos, this.ts.tokenEnd - pos);
/* 3366 */     pn.setResult(result);
/* 3367 */     pn.setLoops(loops);
/* 3368 */     if (data != null) {
/* 3369 */       pn.setIfPosition(ifPos);
/* 3370 */       pn.setFilter(data.condition);
/* 3371 */       pn.setFilterLp(data.lp - pos);
/* 3372 */       pn.setFilterRp(data.rp - pos);
/*      */     } 
/* 3374 */     return (AstNode)pn;
/*      */   }
/*      */   
/*      */   private GeneratorExpressionLoop generatorExpressionLoop() throws IOException {
/* 3378 */     if (nextToken() != 123) codeBug(); 
/* 3379 */     int pos = this.ts.tokenBeg;
/* 3380 */     int lp = -1, rp = -1, inPos = -1;
/* 3381 */     GeneratorExpressionLoop pn = new GeneratorExpressionLoop(pos);
/*      */     
/* 3383 */     pushScope((Scope)pn); try {
/*      */       Name name;
/* 3385 */       if (mustMatchToken(90, "msg.no.paren.for", true)) {
/* 3386 */         lp = this.ts.tokenBeg - pos;
/*      */       }
/*      */       
/* 3389 */       AstNode iter = null;
/* 3390 */       switch (peekToken()) {
/*      */         
/*      */         case 86:
/*      */         case 88:
/* 3394 */           iter = destructuringPrimaryExpr();
/* 3395 */           markDestructuring(iter);
/*      */           break;
/*      */         case 39:
/* 3398 */           consumeToken();
/* 3399 */           name = createNameNode();
/*      */           break;
/*      */         default:
/* 3402 */           reportError("msg.bad.var");
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 3407 */       if (name.getType() == 39) {
/* 3408 */         defineSymbol(157, this.ts.getString(), true);
/*      */       }
/*      */       
/* 3411 */       if (mustMatchToken(52, "msg.in.after.for.name", true)) inPos = this.ts.tokenBeg - pos; 
/* 3412 */       AstNode obj = expr();
/* 3413 */       if (mustMatchToken(91, "msg.no.paren.for.ctrl", true)) rp = this.ts.tokenBeg - pos;
/*      */       
/* 3415 */       pn.setLength(this.ts.tokenEnd - pos);
/* 3416 */       pn.setIterator((AstNode)name);
/* 3417 */       pn.setIteratedObject(obj);
/* 3418 */       pn.setInPosition(inPos);
/* 3419 */       pn.setParens(lp, rp);
/* 3420 */       return pn;
/*      */     } finally {
/* 3422 */       popScope();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ObjectLiteral objectLiteral() throws IOException {
/* 3432 */     int pos = this.ts.tokenBeg, lineno = this.ts.lineno;
/* 3433 */     int afterComma = -1;
/* 3434 */     List<ObjectProperty> elems = new ArrayList<>();
/* 3435 */     Set<String> getterNames = null;
/* 3436 */     Set<String> setterNames = null;
/* 3437 */     if (this.inUseStrictDirective) {
/* 3438 */       getterNames = new HashSet<>();
/* 3439 */       setterNames = new HashSet<>();
/*      */     } 
/* 3441 */     Comment objJsdocNode = getAndResetJsDoc();
/*      */ 
/*      */     
/*      */     while (true) {
/* 3445 */       String propertyName = null;
/* 3446 */       int entryKind = 1;
/* 3447 */       int tt = peekToken();
/* 3448 */       Comment jsdocNode = getAndResetJsDoc();
/* 3449 */       if (tt == 165) {
/* 3450 */         consumeToken();
/* 3451 */         tt = peekUntilNonComment(tt);
/*      */       } 
/* 3453 */       if (tt == 89) {
/* 3454 */         if (afterComma != -1) warnTrailingComma(pos, elems, afterComma); 
/*      */         break;
/*      */       } 
/* 3457 */       AstNode pname = objliteralProperty();
/* 3458 */       if (pname == null) {
/* 3459 */         reportError("msg.bad.prop");
/*      */       } else {
/* 3461 */         propertyName = this.ts.getString();
/* 3462 */         int ppos = this.ts.tokenBeg;
/* 3463 */         consumeToken();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3473 */         int peeked = peekToken();
/* 3474 */         if (peeked != 92 && peeked != 107 && peeked != 89) {
/* 3475 */           if (peeked == 90) {
/* 3476 */             entryKind = 8;
/* 3477 */           } else if (pname.getType() == 39) {
/* 3478 */             if ("get".equals(propertyName)) {
/* 3479 */               entryKind = 2;
/* 3480 */             } else if ("set".equals(propertyName)) {
/* 3481 */               entryKind = 4;
/*      */             } 
/*      */           } 
/* 3484 */           if (entryKind == 2 || entryKind == 4) {
/* 3485 */             pname = objliteralProperty();
/* 3486 */             if (pname == null) {
/* 3487 */               reportError("msg.bad.prop");
/*      */             }
/* 3489 */             consumeToken();
/*      */           } 
/* 3491 */           if (pname == null) {
/* 3492 */             propertyName = null;
/*      */           } else {
/* 3494 */             propertyName = this.ts.getString();
/* 3495 */             ObjectProperty objectProp = methodDefinition(ppos, pname, entryKind);
/* 3496 */             pname.setJsDocNode(jsdocNode);
/* 3497 */             elems.add(objectProp);
/*      */           } 
/*      */         } else {
/* 3500 */           pname.setJsDocNode(jsdocNode);
/* 3501 */           elems.add(plainProperty(pname, tt));
/*      */         } 
/*      */       } 
/*      */       
/* 3505 */       if (this.inUseStrictDirective && propertyName != null) {
/* 3506 */         switch (entryKind) {
/*      */           case 1:
/*      */           case 8:
/* 3509 */             if (getterNames.contains(propertyName) || setterNames
/* 3510 */               .contains(propertyName)) {
/* 3511 */               addError("msg.dup.obj.lit.prop.strict", propertyName);
/*      */             }
/* 3513 */             getterNames.add(propertyName);
/* 3514 */             setterNames.add(propertyName);
/*      */             break;
/*      */           case 2:
/* 3517 */             if (getterNames.contains(propertyName)) {
/* 3518 */               addError("msg.dup.obj.lit.prop.strict", propertyName);
/*      */             }
/* 3520 */             getterNames.add(propertyName);
/*      */             break;
/*      */           case 4:
/* 3523 */             if (setterNames.contains(propertyName)) {
/* 3524 */               addError("msg.dup.obj.lit.prop.strict", propertyName);
/*      */             }
/* 3526 */             setterNames.add(propertyName);
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       }
/* 3532 */       getAndResetJsDoc();
/*      */       
/* 3534 */       if (matchToken(92, true)) {
/* 3535 */         afterComma = this.ts.tokenEnd;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 3541 */     mustMatchToken(89, "msg.no.brace.prop", true);
/* 3542 */     ObjectLiteral pn = new ObjectLiteral(pos, this.ts.tokenEnd - pos);
/* 3543 */     if (objJsdocNode != null) {
/* 3544 */       pn.setJsDocNode(objJsdocNode);
/*      */     }
/* 3546 */     pn.setElements(elems);
/* 3547 */     pn.setLineno(lineno);
/* 3548 */     return pn; } private AstNode objliteralProperty() throws IOException {
/*      */     Name name2;
/*      */     StringLiteral stringLiteral;
/*      */     AstNode pname;
/*      */     Name name1;
/* 3553 */     int tt = peekToken();
/* 3554 */     switch (tt)
/*      */     { case 39:
/* 3556 */         return (AstNode)createNameNode();
/*      */ 
/*      */       
/*      */       case 41:
/* 3560 */         return (AstNode)createStringLiteral();
/*      */ 
/*      */       
/*      */       case 40:
/*      */       case 83:
/* 3565 */         pname = createNumericLiteral(tt, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3581 */         return pname; }  if (this.compilerEnv.isReservedKeywordAsIdentifier() && TokenStream.isKeyword(this.ts.getString(), this.compilerEnv.getLanguageVersion(), this.inUseStrictDirective)) { name1 = createNameNode(); } else { return null; }  return (AstNode)name1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ObjectProperty plainProperty(AstNode property, int ptt) throws IOException {
/* 3587 */     int tt = peekToken();
/* 3588 */     if ((tt == 92 || tt == 89) && ptt == 39 && this.compilerEnv
/*      */       
/* 3590 */       .getLanguageVersion() >= 180) {
/* 3591 */       if (!this.inDestructuringAssignment && this.compilerEnv
/* 3592 */         .getLanguageVersion() < 200) {
/* 3593 */         reportError("msg.bad.object.init");
/*      */       }
/* 3595 */       Name name = new Name(property.getPosition(), property.getString());
/* 3596 */       ObjectProperty objectProperty = new ObjectProperty();
/* 3597 */       objectProperty.putProp(26, Boolean.TRUE);
/* 3598 */       objectProperty.setLeftAndRight(property, (AstNode)name);
/* 3599 */       return objectProperty;
/*      */     } 
/* 3601 */     mustMatchToken(107, "msg.no.colon.prop", true);
/* 3602 */     ObjectProperty pn = new ObjectProperty();
/* 3603 */     pn.setOperatorPosition(this.ts.tokenBeg);
/* 3604 */     pn.setLeftAndRight(property, assignExpr());
/* 3605 */     return pn;
/*      */   }
/*      */ 
/*      */   
/*      */   private ObjectProperty methodDefinition(int pos, AstNode propName, int entryKind) throws IOException {
/* 3610 */     FunctionNode fn = function(2);
/*      */     
/* 3612 */     Name name = fn.getFunctionName();
/* 3613 */     if (name != null && name.length() != 0) {
/* 3614 */       reportError("msg.bad.prop");
/*      */     }
/* 3616 */     ObjectProperty pn = new ObjectProperty(pos);
/* 3617 */     switch (entryKind) {
/*      */       case 2:
/* 3619 */         pn.setIsGetterMethod();
/* 3620 */         fn.setFunctionIsGetterMethod();
/*      */         break;
/*      */       case 4:
/* 3623 */         pn.setIsSetterMethod();
/* 3624 */         fn.setFunctionIsSetterMethod();
/*      */         break;
/*      */       case 8:
/* 3627 */         pn.setIsNormalMethod();
/* 3628 */         fn.setFunctionIsNormalMethod();
/*      */         break;
/*      */     } 
/* 3631 */     int end = getNodeEnd((AstNode)fn);
/* 3632 */     pn.setLeft(propName);
/* 3633 */     pn.setRight((AstNode)fn);
/* 3634 */     pn.setLength(end - pos);
/* 3635 */     return pn;
/*      */   }
/*      */   
/*      */   private Name createNameNode() {
/* 3639 */     return createNameNode(false, 39);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Name createNameNode(boolean checkActivation, int token) {
/* 3649 */     int beg = this.ts.tokenBeg;
/* 3650 */     String s = this.ts.getString();
/* 3651 */     int lineno = this.ts.lineno;
/* 3652 */     if (!"".equals(this.prevNameTokenString)) {
/* 3653 */       beg = this.prevNameTokenStart;
/* 3654 */       s = this.prevNameTokenString;
/* 3655 */       lineno = this.prevNameTokenLineno;
/* 3656 */       this.prevNameTokenStart = 0;
/* 3657 */       this.prevNameTokenString = "";
/* 3658 */       this.prevNameTokenLineno = 0;
/*      */     } 
/* 3660 */     if (s == null) {
/* 3661 */       if (this.compilerEnv.isIdeMode()) {
/* 3662 */         s = "";
/*      */       } else {
/* 3664 */         codeBug();
/*      */       } 
/*      */     }
/* 3667 */     Name name = new Name(beg, s);
/* 3668 */     name.setLineno(lineno);
/* 3669 */     if (checkActivation) {
/* 3670 */       checkActivationName(s, token);
/*      */     }
/* 3672 */     return name;
/*      */   }
/*      */   
/*      */   private StringLiteral createStringLiteral() {
/* 3676 */     int pos = this.ts.tokenBeg, end = this.ts.tokenEnd;
/* 3677 */     StringLiteral s = new StringLiteral(pos, end - pos);
/* 3678 */     s.setLineno(this.ts.lineno);
/* 3679 */     s.setValue(this.ts.getString());
/* 3680 */     s.setQuoteCharacter(this.ts.getQuoteChar());
/* 3681 */     return s;
/*      */   }
/*      */   
/*      */   private AstNode templateLiteral(boolean isTaggedLiteral) throws IOException {
/* 3685 */     if (this.currentToken != 170) codeBug(); 
/* 3686 */     int pos = this.ts.tokenBeg, end = this.ts.tokenEnd;
/* 3687 */     List<AstNode> elements = new ArrayList<>();
/* 3688 */     TemplateLiteral pn = new TemplateLiteral(pos);
/*      */     
/* 3690 */     int posChars = this.ts.tokenBeg + 1;
/* 3691 */     int tt = this.ts.readTemplateLiteral(isTaggedLiteral);
/* 3692 */     while (tt == 172) {
/* 3693 */       elements.add(createTemplateLiteralCharacters(posChars));
/* 3694 */       elements.add(expr());
/* 3695 */       mustMatchToken(89, "msg.syntax", true);
/* 3696 */       posChars = this.ts.tokenBeg + 1;
/* 3697 */       tt = this.ts.readTemplateLiteral(isTaggedLiteral);
/*      */     } 
/* 3699 */     if (tt == -1) {
/* 3700 */       return (AstNode)makeErrorNode();
/*      */     }
/* 3702 */     assert tt == 170;
/* 3703 */     elements.add(createTemplateLiteralCharacters(posChars));
/* 3704 */     end = this.ts.tokenEnd;
/* 3705 */     pn.setElements(elements);
/* 3706 */     pn.setLength(end - pos);
/*      */     
/* 3708 */     return (AstNode)pn;
/*      */   }
/*      */   
/*      */   private TemplateCharacters createTemplateLiteralCharacters(int pos) {
/* 3712 */     TemplateCharacters chars = new TemplateCharacters(pos, this.ts.tokenEnd - pos - 1);
/* 3713 */     chars.setValue(this.ts.getString());
/* 3714 */     chars.setRawValue(this.ts.getRawString());
/* 3715 */     return chars;
/*      */   }
/*      */   
/*      */   private AstNode createNumericLiteral(int tt, boolean isProperty) {
/* 3719 */     String s = this.ts.getString();
/* 3720 */     if (this.inUseStrictDirective && this.ts.isNumericOldOctal() && (
/* 3721 */       this.compilerEnv.getLanguageVersion() >= 200 || !isProperty)) {
/* 3722 */       if (tt == 83) {
/* 3723 */         reportError("msg.no.old.octal.bigint");
/*      */       } else {
/* 3725 */         reportError("msg.no.old.octal.strict");
/*      */       } 
/*      */     }
/*      */     
/* 3729 */     if (this.compilerEnv.getLanguageVersion() >= 200 || !isProperty) {
/* 3730 */       if (this.ts.isNumericBinary()) {
/* 3731 */         s = "0b" + s;
/* 3732 */       } else if (this.ts.isNumericOldOctal()) {
/* 3733 */         s = "0" + s;
/* 3734 */       } else if (this.ts.isNumericOctal()) {
/* 3735 */         s = "0o" + s;
/* 3736 */       } else if (this.ts.isNumericHex()) {
/* 3737 */         s = "0x" + s;
/*      */       } 
/*      */     }
/* 3740 */     if (tt == 83) {
/* 3741 */       return (AstNode)new BigIntLiteral(this.ts.tokenBeg, s + "n", this.ts.getBigInt());
/*      */     }
/* 3743 */     return (AstNode)new NumberLiteral(this.ts.tokenBeg, s, this.ts.getNumber());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void checkActivationName(String name, int token) {
/* 3748 */     if (!insideFunction()) {
/*      */       return;
/*      */     }
/* 3751 */     boolean activation = false;
/* 3752 */     if ("arguments".equals(name) && ((FunctionNode)this.currentScriptOrFn)
/*      */ 
/*      */       
/* 3755 */       .getFunctionType() != 4) {
/*      */       
/* 3757 */       activation = true;
/* 3758 */     } else if (this.compilerEnv.getActivationNames() != null && this.compilerEnv
/* 3759 */       .getActivationNames().contains(name)) {
/* 3760 */       activation = true;
/* 3761 */     } else if ("length".equals(name) && 
/* 3762 */       token == 33 && this.compilerEnv.getLanguageVersion() == 120) {
/*      */       
/* 3764 */       activation = true;
/*      */     } 
/*      */     
/* 3767 */     if (activation) {
/* 3768 */       setRequiresActivation();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setRequiresActivation() {
/* 3773 */     if (insideFunction()) {
/* 3774 */       ((FunctionNode)this.currentScriptOrFn).setRequiresActivation();
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkCallRequiresActivation(AstNode pn) {
/* 3779 */     if ((pn.getType() == 39 && "eval".equals(((Name)pn).getIdentifier())) || (pn
/* 3780 */       .getType() == 33 && "eval"
/* 3781 */       .equals(((PropertyGet)pn).getProperty().getIdentifier())))
/* 3782 */       setRequiresActivation(); 
/*      */   }
/*      */   
/*      */   protected void setIsGenerator() {
/* 3786 */     if (insideFunction()) {
/* 3787 */       ((FunctionNode)this.currentScriptOrFn).setIsGenerator();
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkBadIncDec(UpdateExpression expr) {
/* 3792 */     AstNode op = removeParens(expr.getOperand());
/* 3793 */     int tt = op.getType();
/* 3794 */     if (tt != 39 && tt != 33 && tt != 36 && tt != 68 && tt != 38)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 3799 */       reportError((expr.getType() == 110) ? "msg.bad.incr" : "msg.bad.decr"); } 
/*      */   }
/*      */   
/*      */   private ErrorNode makeErrorNode() {
/* 3803 */     ErrorNode pn = new ErrorNode(this.ts.tokenBeg, this.ts.tokenEnd - this.ts.tokenBeg);
/* 3804 */     pn.setLineno(this.ts.lineno);
/* 3805 */     return pn;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int nodeEnd(AstNode node) {
/* 3810 */     return node.getPosition() + node.getLength();
/*      */   }
/*      */   
/*      */   private void saveNameTokenData(int pos, String name, int lineno) {
/* 3814 */     this.prevNameTokenStart = pos;
/* 3815 */     this.prevNameTokenString = name;
/* 3816 */     this.prevNameTokenLineno = lineno;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lineBeginningFor(int pos) {
/* 3830 */     if (this.sourceChars == null) {
/* 3831 */       return -1;
/*      */     }
/* 3833 */     if (pos <= 0) {
/* 3834 */       return 0;
/*      */     }
/* 3836 */     char[] buf = this.sourceChars;
/* 3837 */     if (pos >= buf.length) {
/* 3838 */       pos = buf.length - 1;
/*      */     }
/* 3840 */     while (--pos >= 0) {
/* 3841 */       char c = buf[pos];
/* 3842 */       if (ScriptRuntime.isJSLineTerminator(c)) {
/* 3843 */         return pos + 1;
/*      */       }
/*      */     } 
/* 3846 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void warnMissingSemi(int pos, int end) {
/* 3853 */     if (this.compilerEnv.isStrictMode()) {
/* 3854 */       int[] linep = new int[2];
/* 3855 */       String line = this.ts.getLine(end, linep);
/*      */ 
/*      */ 
/*      */       
/* 3859 */       int beg = this.compilerEnv.isIdeMode() ? Math.max(pos, end - linep[1]) : pos;
/* 3860 */       if (line != null) {
/* 3861 */         addStrictWarning("msg.missing.semi", "", beg, end - beg, linep[0], line, linep[1]);
/*      */       } else {
/*      */         
/* 3864 */         addStrictWarning("msg.missing.semi", "", beg, end - beg);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void warnTrailingComma(int pos, List<?> elems, int commaPos) {
/* 3870 */     if (this.compilerEnv.getWarnTrailingComma()) {
/*      */       
/* 3872 */       if (!elems.isEmpty()) {
/* 3873 */         pos = ((AstNode)elems.get(0)).getPosition();
/*      */       }
/* 3875 */       pos = Math.max(pos, lineBeginningFor(commaPos));
/* 3876 */       addWarning("msg.extra.trailing.comma", pos, commaPos - pos);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected class PerFunctionVariables
/*      */   {
/*      */     private ScriptNode savedCurrentScriptOrFn;
/*      */     private Scope savedCurrentScope;
/*      */     private int savedEndFlags;
/*      */     private boolean savedInForInit;
/*      */     private Map<String, LabeledStatement> savedLabelSet;
/*      */     private List<Loop> savedLoopSet;
/*      */     private List<Jump> savedLoopAndSwitchSet;
/*      */     
/*      */     PerFunctionVariables(FunctionNode fnNode) {
/* 3891 */       this.savedCurrentScriptOrFn = Parser.this.currentScriptOrFn;
/* 3892 */       Parser.this.currentScriptOrFn = (ScriptNode)fnNode;
/*      */       
/* 3894 */       this.savedCurrentScope = Parser.this.currentScope;
/* 3895 */       Parser.this.currentScope = (Scope)fnNode;
/*      */       
/* 3897 */       this.savedLabelSet = Parser.this.labelSet;
/* 3898 */       Parser.this.labelSet = null;
/*      */       
/* 3900 */       this.savedLoopSet = Parser.this.loopSet;
/* 3901 */       Parser.this.loopSet = null;
/*      */       
/* 3903 */       this.savedLoopAndSwitchSet = Parser.this.loopAndSwitchSet;
/* 3904 */       Parser.this.loopAndSwitchSet = null;
/*      */       
/* 3906 */       this.savedEndFlags = Parser.this.endFlags;
/* 3907 */       Parser.this.endFlags = 0;
/*      */       
/* 3909 */       this.savedInForInit = Parser.this.inForInit;
/* 3910 */       Parser.this.inForInit = false;
/*      */     }
/*      */     
/*      */     void restore() {
/* 3914 */       Parser.this.currentScriptOrFn = this.savedCurrentScriptOrFn;
/* 3915 */       Parser.this.currentScope = this.savedCurrentScope;
/* 3916 */       Parser.this.labelSet = this.savedLabelSet;
/* 3917 */       Parser.this.loopSet = this.savedLoopSet;
/* 3918 */       Parser.this.loopAndSwitchSet = this.savedLoopAndSwitchSet;
/* 3919 */       Parser.this.endFlags = this.savedEndFlags;
/* 3920 */       Parser.this.inForInit = this.savedInForInit;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Node createDestructuringAssignment(int type, Node left, Node right) {
/* 3935 */     String tempName = this.currentScriptOrFn.getNextTempName();
/* 3936 */     Node result = destructuringAssignmentHelper(type, left, right, tempName);
/* 3937 */     Node comma = result.getLastChild();
/* 3938 */     comma.addChildToBack(createName(tempName));
/* 3939 */     return result;
/*      */   }
/*      */   
/*      */   Node destructuringAssignmentHelper(int variableType, Node left, Node right, String tempName) {
/* 3943 */     Scope result = createScopeNode(162, left.getLineno());
/* 3944 */     result.addChildToFront(new Node(157, createName(39, tempName, right)));
/*      */     try {
/* 3946 */       pushScope(result);
/* 3947 */       defineSymbol(157, tempName, true);
/*      */     } finally {
/* 3949 */       popScope();
/*      */     } 
/* 3951 */     Node comma = new Node(92);
/* 3952 */     result.addChildToBack(comma);
/* 3953 */     List<String> destructuringNames = new ArrayList<>();
/* 3954 */     boolean empty = true;
/* 3955 */     switch (left.getType()) {
/*      */       
/*      */       case 66:
/* 3958 */         empty = destructuringArray((ArrayLiteral)left, variableType, tempName, comma, destructuringNames);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 67:
/* 3967 */         empty = destructuringObject((ObjectLiteral)left, variableType, tempName, comma, destructuringNames);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 36:
/* 3976 */         switch (variableType) {
/*      */           case 126:
/*      */           case 157:
/*      */           case 158:
/* 3980 */             reportError("msg.bad.assign.left"); break;
/*      */         } 
/* 3982 */         comma.addChildToBack(simpleAssignment(left, createName(tempName)));
/*      */         break;
/*      */       default:
/* 3985 */         reportError("msg.bad.assign.left"); break;
/*      */     } 
/* 3987 */     if (empty)
/*      */     {
/* 3989 */       comma.addChildToBack(createNumber(0.0D));
/*      */     }
/* 3991 */     result.putProp(22, destructuringNames);
/* 3992 */     return (Node)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean destructuringArray(ArrayLiteral array, int variableType, String tempName, Node parent, List<String> destructuringNames) {
/* 4001 */     boolean empty = true;
/* 4002 */     int setOp = (variableType == 158) ? 159 : 8;
/* 4003 */     int index = 0;
/* 4004 */     for (AstNode n : array.getElements()) {
/* 4005 */       if (n.getType() == 132) {
/* 4006 */         index++;
/*      */         continue;
/*      */       } 
/* 4009 */       Node rightElem = new Node(36, createName(tempName), createNumber(index));
/* 4010 */       if (n.getType() == 39) {
/* 4011 */         String name = n.getString();
/* 4012 */         parent.addChildToBack(new Node(setOp, 
/* 4013 */               createName(49, name, null), rightElem));
/* 4014 */         if (variableType != -1) {
/* 4015 */           defineSymbol(variableType, name, true);
/* 4016 */           destructuringNames.add(name);
/*      */         } 
/*      */       } else {
/* 4019 */         parent.addChildToBack(
/* 4020 */             destructuringAssignmentHelper(variableType, (Node)n, rightElem, this.currentScriptOrFn
/* 4021 */               .getNextTempName()));
/*      */       } 
/* 4023 */       index++;
/* 4024 */       empty = false;
/*      */     } 
/* 4026 */     return empty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean destructuringObject(ObjectLiteral node, int variableType, String tempName, Node parent, List<String> destructuringNames) {
/* 4035 */     boolean empty = true;
/* 4036 */     int setOp = (variableType == 158) ? 159 : 8;
/*      */     
/* 4038 */     for (ObjectProperty prop : node.getElements()) {
/* 4039 */       int lineno = 0;
/*      */ 
/*      */ 
/*      */       
/* 4043 */       if (this.ts != null) {
/* 4044 */         lineno = this.ts.lineno;
/*      */       }
/* 4046 */       AstNode id = prop.getLeft();
/* 4047 */       Node rightElem = null;
/* 4048 */       if (id instanceof Name) {
/* 4049 */         Node s = Node.newString(((Name)id).getIdentifier());
/* 4050 */         rightElem = new Node(33, createName(tempName), s);
/* 4051 */       } else if (id instanceof StringLiteral) {
/* 4052 */         Node s = Node.newString(((StringLiteral)id).getValue());
/* 4053 */         rightElem = new Node(33, createName(tempName), s);
/* 4054 */       } else if (id instanceof NumberLiteral) {
/* 4055 */         Node s = createNumber((int)((NumberLiteral)id).getNumber());
/* 4056 */         rightElem = new Node(36, createName(tempName), s);
/*      */       } else {
/* 4058 */         throw codeBug();
/*      */       } 
/* 4060 */       rightElem.setLineno(lineno);
/* 4061 */       AstNode value = prop.getRight();
/* 4062 */       if (value.getType() == 39) {
/* 4063 */         String name = ((Name)value).getIdentifier();
/* 4064 */         parent.addChildToBack(new Node(setOp, 
/* 4065 */               createName(49, name, null), rightElem));
/* 4066 */         if (variableType != -1) {
/* 4067 */           defineSymbol(variableType, name, true);
/* 4068 */           destructuringNames.add(name);
/*      */         } 
/*      */       } else {
/* 4071 */         parent.addChildToBack(
/* 4072 */             destructuringAssignmentHelper(variableType, (Node)value, rightElem, this.currentScriptOrFn
/*      */ 
/*      */ 
/*      */               
/* 4076 */               .getNextTempName()));
/*      */       } 
/* 4078 */       empty = false;
/*      */     } 
/* 4080 */     return empty;
/*      */   }
/*      */   
/*      */   protected Node createName(String name) {
/* 4084 */     checkActivationName(name, 39);
/* 4085 */     return Node.newString(39, name);
/*      */   }
/*      */   
/*      */   protected Node createName(int type, String name, Node child) {
/* 4089 */     Node result = createName(name);
/* 4090 */     result.setType(type);
/* 4091 */     if (child != null) result.addChildToBack(child); 
/* 4092 */     return result;
/*      */   }
/*      */   
/*      */   protected Node createNumber(double number) {
/* 4096 */     return Node.newNumber(number);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Scope createScopeNode(int token, int lineno) {
/* 4108 */     Scope scope = new Scope();
/* 4109 */     scope.setType(token);
/* 4110 */     scope.setLineno(lineno);
/* 4111 */     return scope;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Node simpleAssignment(Node left, Node right) {
/*      */     String name;
/*      */     Node obj, ref, id;
/* 4137 */     int type, nodeType = left.getType();
/* 4138 */     switch (nodeType) {
/*      */       case 39:
/* 4140 */         name = ((Name)left).getIdentifier();
/* 4141 */         if (this.inUseStrictDirective && ("eval".equals(name) || "arguments".equals(name))) {
/* 4142 */           reportError("msg.bad.id.strict", name);
/*      */         }
/* 4144 */         left.setType(49);
/* 4145 */         return new Node(8, left, right);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 36:
/* 4155 */         if (left instanceof PropertyGet) {
/* 4156 */           AstNode astNode = ((PropertyGet)left).getTarget();
/* 4157 */           Name name1 = ((PropertyGet)left).getProperty();
/* 4158 */         } else if (left instanceof ElementGet) {
/* 4159 */           AstNode astNode1 = ((ElementGet)left).getTarget();
/* 4160 */           AstNode astNode2 = ((ElementGet)left).getElement();
/*      */         } else {
/*      */           
/* 4163 */           obj = left.getFirstChild();
/* 4164 */           id = left.getLastChild();
/*      */         } 
/*      */         
/* 4167 */         if (nodeType == 33) {
/* 4168 */           type = 35;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4176 */           id.setType(41);
/*      */         } else {
/* 4178 */           type = 37;
/*      */         } 
/* 4180 */         return new Node(type, obj, id, right);
/*      */ 
/*      */       
/*      */       case 68:
/* 4184 */         ref = left.getFirstChild();
/* 4185 */         checkMutableReference(ref);
/* 4186 */         return new Node(69, ref, right);
/*      */     } 
/*      */ 
/*      */     
/* 4190 */     throw codeBug();
/*      */   }
/*      */   
/*      */   protected void checkMutableReference(Node n) {
/* 4194 */     int memberTypeFlags = n.getIntProp(16, 0);
/* 4195 */     if ((memberTypeFlags & 0x4) != 0) {
/* 4196 */       reportError("msg.bad.assign.left");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected AstNode removeParens(AstNode node) {
/* 4202 */     while (node instanceof ParenthesizedExpression) {
/* 4203 */       node = ((ParenthesizedExpression)node).getExpression();
/*      */     }
/* 4205 */     return node;
/*      */   }
/*      */   
/*      */   void markDestructuring(AstNode node) {
/* 4209 */     if (node instanceof DestructuringForm) {
/* 4210 */       ((DestructuringForm)node).setIsDestructuring(true);
/* 4211 */     } else if (node instanceof ParenthesizedExpression) {
/* 4212 */       markDestructuring(((ParenthesizedExpression)node).getExpression());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private RuntimeException codeBug() throws RuntimeException {
/* 4218 */     throw Kit.codeBug("ts.cursor=" + this.ts.cursor + ", ts.tokenBeg=" + this.ts.tokenBeg + ", currentToken=" + this.currentToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultUseStrictDirective(boolean useStrict) {
/* 4228 */     this.defaultUseStrictDirective = useStrict;
/*      */   }
/*      */   
/*      */   public boolean inUseStrictDirective() {
/* 4232 */     return this.inUseStrictDirective;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Parser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */