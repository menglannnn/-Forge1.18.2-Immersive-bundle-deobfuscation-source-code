/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Sorting
/*     */ {
/*     */   private static final int SMALLSORT = 16;
/*  12 */   private static final Sorting sorting = new Sorting();
/*     */ 
/*     */ 
/*     */   
/*     */   public static Sorting get() {
/*  17 */     return sorting;
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertionSort(Object[] a, Comparator<Object> cmp) {
/*  22 */     insertionSort(a, 0, a.length - 1, cmp);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void insertionSort(Object[] a, int start, int end, Comparator<Object> cmp) {
/*  27 */     int i = start;
/*  28 */     while (i <= end) {
/*  29 */       Object x = a[i];
/*  30 */       int j = i - 1;
/*  31 */       while (j >= start && cmp.compare(a[j], x) > 0) {
/*  32 */         a[j + 1] = a[j];
/*  33 */         j--;
/*     */       } 
/*  35 */       a[j + 1] = x;
/*  36 */       i++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hybridSort(Object[] a, Comparator<Object> cmp) {
/*  48 */     hybridSort(a, 0, a.length - 1, cmp, log2(a.length) * 2);
/*     */   }
/*     */ 
/*     */   
/*     */   private void hybridSort(Object[] a, int start, int end, Comparator<Object> cmp, int maxdepth) {
/*  53 */     if (start < end) {
/*  54 */       if (maxdepth == 0 || end - start <= 16) {
/*  55 */         insertionSort(a, start, end, cmp);
/*     */       } else {
/*  57 */         int p = partition(a, start, end, cmp);
/*  58 */         hybridSort(a, start, p, cmp, maxdepth - 1);
/*  59 */         hybridSort(a, p + 1, end, cmp, maxdepth - 1);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int partition(Object[] a, int start, int end, Comparator<Object> cmp) {
/*  71 */     int p = median(a, start, end, cmp);
/*  72 */     Object pivot = a[p];
/*  73 */     a[p] = a[start];
/*  74 */     a[start] = pivot;
/*     */     
/*  76 */     int i = start;
/*  77 */     int j = end + 1;
/*     */     
/*     */     while (true) {
/*  80 */       if (cmp.compare(a[++i], pivot) >= 0 || 
/*  81 */         i == end) {
/*     */         
/*     */         do {
/*     */         
/*  85 */         } while (cmp.compare(a[--j], pivot) >= 0 && 
/*  86 */           j != start);
/*     */ 
/*     */ 
/*     */         
/*  90 */         if (i >= j) {
/*     */           break;
/*     */         }
/*  93 */         swap(a, i, j);
/*     */       } 
/*     */     } 
/*  96 */     swap(a, start, j);
/*  97 */     return j;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void swap(Object[] a, int l, int h) {
/* 102 */     Object tmp = a[l];
/* 103 */     a[l] = a[h];
/* 104 */     a[h] = tmp;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int log2(int n) {
/* 109 */     return (int)(Math.log10(n) / Math.log10(2.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int median(Object[] a, int start, int end, Comparator<Object> cmp) {
/* 118 */     int m = start + (end - start) / 2;
/* 119 */     int smallest = start;
/*     */     
/* 121 */     if (cmp.compare(a[smallest], a[m]) > 0) {
/* 122 */       smallest = m;
/*     */     }
/* 124 */     if (cmp.compare(a[smallest], a[end]) > 0) {
/* 125 */       smallest = end;
/*     */     }
/*     */     
/* 128 */     if (smallest == start) {
/* 129 */       return (cmp.compare(a[m], a[end]) < 0) ? m : end;
/*     */     }
/* 131 */     if (smallest == m) {
/* 132 */       return (cmp.compare(a[start], a[end]) < 0) ? start : end;
/*     */     }
/* 134 */     return (cmp.compare(a[start], a[m]) < 0) ? start : m;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Sorting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */