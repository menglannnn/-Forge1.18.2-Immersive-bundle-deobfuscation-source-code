/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContinuationPending
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 4956008116771118856L;
/*    */   private NativeContinuation continuationState;
/*    */   private Object applicationState;
/*    */   
/*    */   protected ContinuationPending(NativeContinuation continuationState) {
/* 33 */     this.continuationState = continuationState;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getContinuation() {
/* 43 */     return this.continuationState;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setContinuation(NativeContinuation continuation) {
/* 51 */     this.continuationState = continuation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   NativeContinuation getContinuationState() {
/* 58 */     return this.continuationState;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setApplicationState(Object applicationState) {
/* 67 */     this.applicationState = applicationState;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getApplicationState() {
/* 74 */     return this.applicationState;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ContinuationPending.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */