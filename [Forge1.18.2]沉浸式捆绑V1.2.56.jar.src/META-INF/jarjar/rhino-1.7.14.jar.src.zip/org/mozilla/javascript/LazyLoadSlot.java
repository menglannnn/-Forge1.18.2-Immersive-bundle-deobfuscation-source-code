/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LazyLoadSlot
/*    */   extends Slot
/*    */ {
/*    */   LazyLoadSlot(Slot oldSlot) {
/*  9 */     super(oldSlot);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue(Scriptable start) {
/* 14 */     Object val = this.value;
/* 15 */     if (val instanceof LazilyLoadedCtor) {
/* 16 */       LazilyLoadedCtor initializer = (LazilyLoadedCtor)val;
/*    */       try {
/* 18 */         initializer.init();
/*    */       } finally {
/* 20 */         this.value = val = initializer.getValue();
/*    */       } 
/*    */     } 
/* 23 */     return val;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\LazyLoadSlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */