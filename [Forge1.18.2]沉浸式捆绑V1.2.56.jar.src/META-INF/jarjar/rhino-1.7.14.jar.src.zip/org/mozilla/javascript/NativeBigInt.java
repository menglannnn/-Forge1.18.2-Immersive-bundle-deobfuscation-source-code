/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeBigInt
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 1335609231306775449L;
/*  16 */   private static final Object BIG_INT_TAG = "BigInt"; private static final int ConstructorId_asIntN = -1; private static final int ConstructorId_asUintN = -2; private static final int Id_constructor = 1; private static final int Id_toString = 2; private static final int Id_toLocaleString = 3;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  19 */     NativeBigInt obj = new NativeBigInt(BigInteger.ZERO);
/*  20 */     obj.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */   private static final int Id_toSource = 4; private static final int Id_valueOf = 5; private static final int SymbolId_toStringTag = 6; private static final int MAX_PROTOTYPE_ID = 6; private BigInteger bigIntValue;
/*     */   NativeBigInt(BigInteger bigInt) {
/*  24 */     this.bigIntValue = bigInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  29 */     return "BigInt";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/*  34 */     addIdFunctionProperty(ctor, BIG_INT_TAG, -1, "asIntN", 2);
/*  35 */     addIdFunctionProperty(ctor, BIG_INT_TAG, -2, "asUintN", 2);
/*     */     
/*  37 */     super.fillConstructorProperties(ctor);
/*     */   }
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*  42 */     if (id == 6) {
/*  43 */       initPrototypeValue(6, SymbolKey.TO_STRING_TAG, 
/*     */ 
/*     */           
/*  46 */           getClassName(), 3);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  53 */     switch (id) {
/*     */       case 1:
/*  55 */         arity = 1;
/*  56 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/*  59 */         arity = 0;
/*  60 */         s = "toString";
/*     */         break;
/*     */       case 3:
/*  63 */         arity = 0;
/*  64 */         s = "toLocaleString";
/*     */         break;
/*     */       case 4:
/*  67 */         arity = 0;
/*  68 */         s = "toSource";
/*     */         break;
/*     */       case 5:
/*  71 */         arity = 0;
/*  72 */         s = "valueOf";
/*     */         break;
/*     */       default:
/*  75 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/*  77 */     initPrototypeMethod(BIG_INT_TAG, id, s, arity);
/*     */   }
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args)
/*     */   {
/*     */     int base;
/*  83 */     if (!f.hasTag(BIG_INT_TAG)) {
/*  84 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  86 */     int id = f.methodId();
/*  87 */     if (id == 1) {
/*  88 */       if (thisObj == null)
/*     */       {
/*  90 */         throw ScriptRuntime.typeErrorById("msg.not.ctor", new Object[] { BIG_INT_TAG });
/*     */       }
/*  92 */       BigInteger val = (args.length >= 1) ? ScriptRuntime.toBigInt(args[0]) : BigInteger.ZERO;
/*     */       
/*  94 */       return val;
/*     */     } 
/*  96 */     if (id < 1) {
/*  97 */       return execConstructorCall(id, args);
/*     */     }
/*     */ 
/*     */     
/* 101 */     BigInteger value = ((NativeBigInt)ensureType(thisObj, (Class)NativeBigInt.class, f)).bigIntValue;
/*     */     
/* 103 */     switch (id) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 3:
/* 111 */         base = (args.length == 0 || args[0] == Undefined.instance) ? 10 : ScriptRuntime.toInt32(args[0]);
/* 112 */         return ScriptRuntime.bigIntToString(value, base);
/*     */ 
/*     */       
/*     */       case 4:
/* 116 */         return "(new BigInt(" + ScriptRuntime.toString(value) + "))";
/*     */       
/*     */       case 5:
/* 119 */         return value;
/*     */     } 
/*     */     
/* 122 */     throw new IllegalArgumentException(String.valueOf(id)); } private static Object execConstructorCall(int id, Object[] args) { int bits; BigInteger bigInt;
/*     */     byte[] bytes;
/*     */     int newBytesLen;
/*     */     byte[] newBytes;
/*     */     int mod;
/* 127 */     switch (id) {
/*     */ 
/*     */       
/*     */       case -2:
/*     */       case -1:
/* 132 */         bits = ScriptRuntime.toIndex((args.length < 1) ? Undefined.instance : args[0]);
/*     */         
/* 134 */         bigInt = ScriptRuntime.toBigInt((args.length < 2) ? Undefined.instance : args[1]);
/*     */         
/* 136 */         if (bits == 0) {
/* 137 */           return BigInteger.ZERO;
/*     */         }
/*     */         
/* 140 */         bytes = bigInt.toByteArray();
/*     */         
/* 142 */         newBytesLen = bits / 8 + 1;
/* 143 */         if (newBytesLen > bytes.length) {
/* 144 */           return bigInt;
/*     */         }
/*     */ 
/*     */         
/* 148 */         newBytes = Arrays.copyOfRange(bytes, bytes.length - newBytesLen, bytes.length);
/*     */         
/* 150 */         mod = bits % 8;
/* 151 */         switch (id) {
/*     */           case -1:
/* 153 */             if (mod == 0) {
/* 154 */               newBytes[0] = (newBytes[1] < 0) ? -1 : 0; break;
/* 155 */             }  if ((newBytes[0] & 1 << mod - 1) != 0) {
/* 156 */               newBytes[0] = (byte)(newBytes[0] | -1 << mod); break;
/*     */             } 
/* 158 */             newBytes[0] = (byte)(newBytes[0] & (1 << mod) - 1);
/*     */             break;
/*     */           
/*     */           case -2:
/* 162 */             newBytes[0] = (byte)(newBytes[0] & (1 << mod) - 1);
/*     */             break;
/*     */         } 
/* 165 */         return new BigInteger(newBytes);
/*     */     } 
/*     */ 
/*     */     
/* 169 */     throw new IllegalArgumentException(String.valueOf(id)); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 175 */     return ScriptRuntime.bigIntToString(this.bigIntValue, 10);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(Symbol k) {
/* 180 */     if (SymbolKey.TO_STRING_TAG.equals(k)) {
/* 181 */       return 6;
/*     */     }
/* 183 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 189 */     switch (s)
/*     */     { case "constructor":
/* 191 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 209 */         return id;case "toString": id = 2; return id;case "toLocaleString": id = 3; return id;case "toSource": id = 4; return id;case "valueOf": id = 5; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeBigInt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */