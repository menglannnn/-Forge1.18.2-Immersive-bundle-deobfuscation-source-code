/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.locks.StampedLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ThreadSafeSlotMapContainer
/*     */   extends SlotMapContainer
/*     */ {
/*  18 */   private final StampedLock lock = new StampedLock();
/*     */   
/*     */   ThreadSafeSlotMapContainer() {}
/*     */   
/*     */   ThreadSafeSlotMapContainer(int initialSize) {
/*  23 */     super(initialSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  28 */     long stamp = this.lock.tryOptimisticRead();
/*  29 */     int s = this.map.size();
/*  30 */     if (this.lock.validate(stamp)) {
/*  31 */       return s;
/*     */     }
/*     */     
/*  34 */     stamp = this.lock.readLock();
/*     */     try {
/*  36 */       return this.map.size();
/*     */     } finally {
/*  38 */       this.lock.unlockRead(stamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int dirtySize() {
/*  44 */     assert this.lock.isReadLocked();
/*  45 */     return this.map.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  50 */     long stamp = this.lock.tryOptimisticRead();
/*  51 */     boolean e = this.map.isEmpty();
/*  52 */     if (this.lock.validate(stamp)) {
/*  53 */       return e;
/*     */     }
/*     */     
/*  56 */     stamp = this.lock.readLock();
/*     */     try {
/*  58 */       return this.map.isEmpty();
/*     */     } finally {
/*  60 */       this.lock.unlockRead(stamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Slot modify(Object key, int index, int attributes) {
/*  66 */     long stamp = this.lock.writeLock();
/*     */     try {
/*  68 */       checkMapSize();
/*  69 */       return this.map.modify(key, index, attributes);
/*     */     } finally {
/*  71 */       this.lock.unlockWrite(stamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(Slot oldSlot, Slot newSlot) {
/*  77 */     long stamp = this.lock.writeLock();
/*     */     try {
/*  79 */       this.map.replace(oldSlot, newSlot);
/*     */     } finally {
/*  81 */       this.lock.unlockWrite(stamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Slot query(Object key, int index) {
/*  87 */     long stamp = this.lock.tryOptimisticRead();
/*  88 */     Slot s = this.map.query(key, index);
/*  89 */     if (this.lock.validate(stamp)) {
/*  90 */       return s;
/*     */     }
/*     */     
/*  93 */     stamp = this.lock.readLock();
/*     */     try {
/*  95 */       return this.map.query(key, index);
/*     */     } finally {
/*  97 */       this.lock.unlockRead(stamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Slot newSlot) {
/* 103 */     long stamp = this.lock.writeLock();
/*     */     try {
/* 105 */       checkMapSize();
/* 106 */       this.map.add(newSlot);
/*     */     } finally {
/* 108 */       this.lock.unlockWrite(stamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(Object key, int index) {
/* 114 */     long stamp = this.lock.writeLock();
/*     */     try {
/* 116 */       this.map.remove(key, index);
/*     */     } finally {
/* 118 */       this.lock.unlockWrite(stamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long readLock() {
/* 128 */     return this.lock.readLock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unlockRead(long stamp) {
/* 138 */     this.lock.unlockRead(stamp);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Slot> iterator() {
/* 143 */     assert this.lock.isReadLocked();
/* 144 */     return this.map.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkMapSize() {
/* 153 */     assert this.lock.isWriteLocked();
/* 154 */     super.checkMapSize();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ThreadSafeSlotMapContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */