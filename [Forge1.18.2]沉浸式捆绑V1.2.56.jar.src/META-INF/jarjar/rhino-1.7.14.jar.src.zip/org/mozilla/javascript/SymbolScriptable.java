package org.mozilla.javascript;

public interface SymbolScriptable {
  Object get(Symbol paramSymbol, Scriptable paramScriptable);
  
  boolean has(Symbol paramSymbol, Scriptable paramScriptable);
  
  void put(Symbol paramSymbol, Scriptable paramScriptable, Object paramObject);
  
  void delete(Symbol paramSymbol);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\SymbolScriptable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */