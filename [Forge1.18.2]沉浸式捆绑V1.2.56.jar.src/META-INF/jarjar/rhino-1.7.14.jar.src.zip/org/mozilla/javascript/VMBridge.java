/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class VMBridge
/*    */ {
/* 17 */   static final VMBridge instance = makeInstance();
/*    */ 
/*    */   
/*    */   private static VMBridge makeInstance() {
/* 21 */     String[] classNames = { "org.mozilla.javascript.VMBridge_custom", "org.mozilla.javascript.jdk18.VMBridge_jdk18" };
/*    */ 
/*    */ 
/*    */     
/* 25 */     for (int i = 0; i != classNames.length; i++) {
/* 26 */       String className = classNames[i];
/* 27 */       Class<?> cl = Kit.classOrNull(className);
/* 28 */       if (cl != null) {
/* 29 */         VMBridge bridge = (VMBridge)Kit.newInstanceOrNull(cl);
/* 30 */         if (bridge != null) {
/* 31 */           return bridge;
/*    */         }
/*    */       } 
/*    */     } 
/* 35 */     throw new IllegalStateException("Failed to create VMBridge instance");
/*    */   }
/*    */   
/*    */   protected abstract Object getThreadContextHelper();
/*    */   
/*    */   protected abstract Context getContext(Object paramObject);
/*    */   
/*    */   protected abstract void setContext(Object paramObject, Context paramContext);
/*    */   
/*    */   protected abstract boolean tryToMakeAccessible(AccessibleObject paramAccessibleObject);
/*    */   
/*    */   protected abstract Object getInterfaceProxyHelper(ContextFactory paramContextFactory, Class<?>[] paramArrayOfClass);
/*    */   
/*    */   protected abstract Object newInterfaceProxy(Object paramObject1, ContextFactory paramContextFactory, InterfaceAdapter paramInterfaceAdapter, Object paramObject2, Scriptable paramScriptable);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\VMBridge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */