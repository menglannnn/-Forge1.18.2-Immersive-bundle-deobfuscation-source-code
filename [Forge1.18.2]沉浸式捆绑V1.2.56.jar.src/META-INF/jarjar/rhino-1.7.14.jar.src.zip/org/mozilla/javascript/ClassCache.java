/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassCache
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8866246036237312215L;
/*  23 */   private static final Object AKEY = "ClassCache";
/*     */   
/*     */   private volatile boolean cachingIsEnabled = true;
/*     */   
/*     */   private transient Map<CacheKey, JavaMembers> classTable;
/*     */   
/*     */   private transient Map<JavaAdapter.JavaAdapterSignature, Class<?>> classAdapterCache;
/*     */   private transient Map<Class<?>, Object> interfaceAdapterCache;
/*     */   private int generatedClassSerial;
/*     */   private Scriptable associatedScope;
/*     */   
/*     */   static class CacheKey
/*     */   {
/*     */     final Class<?> cls;
/*     */     final Object sec;
/*     */     
/*     */     public CacheKey(Class<?> cls, Object securityContext) {
/*  40 */       this.cls = cls;
/*  41 */       this.sec = securityContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  46 */       int result = this.cls.hashCode();
/*  47 */       if (this.sec != null) {
/*  48 */         result = this.sec.hashCode() * 31;
/*     */       }
/*  50 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  55 */       return (obj instanceof CacheKey && 
/*  56 */         Objects.equals(this.cls, ((CacheKey)obj).cls) && 
/*  57 */         Objects.equals(this.sec, ((CacheKey)obj).sec));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassCache get(Scriptable scope) {
/*  72 */     ClassCache cache = (ClassCache)ScriptableObject.getTopScopeValue(scope, AKEY);
/*  73 */     if (cache == null) {
/*  74 */       throw new RuntimeException("Can't find top level scope for ClassCache.get");
/*     */     }
/*  76 */     return cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean associate(ScriptableObject topScope) {
/*  89 */     if (topScope.getParentScope() != null)
/*     */     {
/*  91 */       throw new IllegalArgumentException();
/*     */     }
/*  93 */     if (this == topScope.associateValue(AKEY, this)) {
/*  94 */       this.associatedScope = topScope;
/*  95 */       return true;
/*     */     } 
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void clearCaches() {
/* 102 */     this.classTable = null;
/* 103 */     this.classAdapterCache = null;
/* 104 */     this.interfaceAdapterCache = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isCachingEnabled() {
/* 109 */     return this.cachingIsEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setCachingEnabled(boolean enabled) {
/* 129 */     if (enabled == this.cachingIsEnabled)
/* 130 */       return;  if (!enabled) clearCaches(); 
/* 131 */     this.cachingIsEnabled = enabled;
/*     */   }
/*     */ 
/*     */   
/*     */   Map<CacheKey, JavaMembers> getClassCacheMap() {
/* 136 */     if (this.classTable == null)
/*     */     {
/*     */       
/* 139 */       this.classTable = new ConcurrentHashMap<>(16, 0.75F, 1);
/*     */     }
/* 141 */     return this.classTable;
/*     */   }
/*     */   
/*     */   Map<JavaAdapter.JavaAdapterSignature, Class<?>> getInterfaceAdapterCacheMap() {
/* 145 */     if (this.classAdapterCache == null) {
/* 146 */       this.classAdapterCache = new ConcurrentHashMap<>(16, 0.75F, 1);
/*     */     }
/*     */     
/* 149 */     return this.classAdapterCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isInvokerOptimizationEnabled() {
/* 158 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public synchronized void setInvokerOptimizationEnabled(boolean enabled) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized int newClassSerialNumber() {
/* 175 */     return ++this.generatedClassSerial;
/*     */   }
/*     */   
/*     */   Object getInterfaceAdapter(Class<?> cl) {
/* 179 */     return (this.interfaceAdapterCache == null) ? null : this.interfaceAdapterCache.get(cl);
/*     */   }
/*     */   
/*     */   synchronized void cacheInterfaceAdapter(Class<?> cl, Object iadapter) {
/* 183 */     if (this.cachingIsEnabled) {
/* 184 */       if (this.interfaceAdapterCache == null) {
/* 185 */         this.interfaceAdapterCache = new ConcurrentHashMap<>(16, 0.75F, 1);
/*     */       }
/* 187 */       this.interfaceAdapterCache.put(cl, iadapter);
/*     */     } 
/*     */   }
/*     */   
/*     */   Scriptable getAssociatedScope() {
/* 192 */     return this.associatedScope;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ClassCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */