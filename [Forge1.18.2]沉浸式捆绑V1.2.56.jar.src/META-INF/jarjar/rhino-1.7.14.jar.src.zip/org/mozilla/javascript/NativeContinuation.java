/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeContinuation
/*     */   extends IdScriptableObject
/*     */   implements Function
/*     */ {
/*     */   private static final long serialVersionUID = 1794167133757605367L;
/*  14 */   private static final Object FTAG = "Continuation"; private Object implementation;
/*     */   private static final int Id_constructor = 1;
/*     */   private static final int MAX_PROTOTYPE_ID = 1;
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  19 */     NativeContinuation obj = new NativeContinuation();
/*  20 */     obj.exportAsJSClass(1, scope, sealed);
/*     */   }
/*     */   
/*     */   public Object getImplementation() {
/*  24 */     return this.implementation;
/*     */   }
/*     */   
/*     */   public void initImplementation(Object implementation) {
/*  28 */     this.implementation = implementation;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  33 */     return "Continuation";
/*     */   }
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/*  38 */     throw Context.reportRuntimeError("Direct call is not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  43 */     return Interpreter.restartContinuation(this, cx, scope, args);
/*     */   }
/*     */   
/*     */   public static boolean isContinuationConstructor(IdFunctionObject f) {
/*  47 */     if (f.hasTag(FTAG) && f.methodId() == 1) {
/*  48 */       return true;
/*     */     }
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equalImplementations(NativeContinuation c1, NativeContinuation c2) {
/*  62 */     return Objects.equals(c1.implementation, c2.implementation);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*  69 */     switch (id) {
/*     */       case 1:
/*  71 */         arity = 0;
/*  72 */         s = "constructor";
/*     */         break;
/*     */       default:
/*  75 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/*  77 */     initPrototypeMethod(FTAG, id, s, arity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  83 */     if (!f.hasTag(FTAG)) {
/*  84 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  86 */     int id = f.methodId();
/*  87 */     switch (id) {
/*     */       case 1:
/*  89 */         throw Context.reportRuntimeError("Direct call is not supported");
/*     */     } 
/*  91 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/*  97 */     switch (s)
/*     */     { case "constructor":
/*  99 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 105 */         return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeContinuation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */