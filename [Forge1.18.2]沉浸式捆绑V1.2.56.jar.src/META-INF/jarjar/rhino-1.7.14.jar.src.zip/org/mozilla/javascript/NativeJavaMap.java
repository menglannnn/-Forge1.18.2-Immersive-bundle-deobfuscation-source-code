/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeJavaMap
/*     */   extends NativeJavaObject
/*     */ {
/*     */   private static final long serialVersionUID = -3786257752907047381L;
/*     */   private Map<Object, Object> map;
/*     */   private static Callable symbol_iterator;
/*     */   
/*     */   static void init(ScriptableObject scope, boolean sealed) {
/*  31 */     NativeJavaMapIterator.init(scope, sealed);
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeJavaMap(Scriptable scope, Object map) {
/*  36 */     super(scope, map, map.getClass());
/*  37 */     assert map instanceof Map;
/*  38 */     this.map = (Map<Object, Object>)map;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  43 */     return "JavaMap";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(String name, Scriptable start) {
/*  48 */     Context cx = Context.getCurrentContext();
/*  49 */     if (cx != null && cx.hasFeature(21) && 
/*  50 */       this.map.containsKey(name)) {
/*  51 */       return true;
/*     */     }
/*     */     
/*  54 */     return super.has(name, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/*  59 */     Context cx = Context.getCurrentContext();
/*  60 */     if (cx != null && cx.hasFeature(21) && 
/*  61 */       this.map.containsKey(Integer.valueOf(index))) {
/*  62 */       return true;
/*     */     }
/*     */     
/*  65 */     return super.has(index, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(Symbol key, Scriptable start) {
/*  70 */     if (SymbolKey.ITERATOR.equals(key)) {
/*  71 */       return true;
/*     */     }
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String name, Scriptable start) {
/*  78 */     Context cx = Context.getCurrentContext();
/*  79 */     if (cx != null && cx.hasFeature(21) && 
/*  80 */       this.map.containsKey(name)) {
/*  81 */       Object obj = this.map.get(name);
/*  82 */       return cx.getWrapFactory().wrap(cx, this, obj, (obj == null) ? null : obj.getClass());
/*     */     } 
/*     */     
/*  85 */     return super.get(name, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/*  90 */     Context cx = Context.getCurrentContext();
/*  91 */     if (cx != null && cx.hasFeature(21) && 
/*  92 */       this.map.containsKey(Integer.valueOf(index))) {
/*  93 */       Object obj = this.map.get(Integer.valueOf(index));
/*  94 */       return cx.getWrapFactory().wrap(cx, this, obj, (obj == null) ? null : obj.getClass());
/*     */     } 
/*     */     
/*  97 */     return super.get(index, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Symbol key, Scriptable start) {
/* 102 */     if (SymbolKey.ITERATOR.equals(key)) {
/* 103 */       return symbol_iterator;
/*     */     }
/* 105 */     return super.get(key, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String name, Scriptable start, Object value) {
/* 110 */     Context cx = Context.getCurrentContext();
/* 111 */     if (cx != null && cx.hasFeature(21)) {
/* 112 */       this.map.put(name, Context.jsToJava(value, Object.class));
/*     */     } else {
/* 114 */       super.put(name, start, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/* 120 */     Context cx = Context.getContext();
/* 121 */     if (cx != null && cx.hasFeature(21)) {
/* 122 */       this.map.put(Integer.valueOf(index), Context.jsToJava(value, Object.class));
/*     */     } else {
/* 124 */       super.put(index, start, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 130 */     Context cx = Context.getCurrentContext();
/* 131 */     if (cx != null && cx.hasFeature(21)) {
/* 132 */       List<Object> ids = new ArrayList(this.map.size());
/* 133 */       for (Object key : this.map.keySet()) {
/* 134 */         if (key instanceof Integer) {
/* 135 */           ids.add(key); continue;
/*     */         } 
/* 137 */         ids.add(ScriptRuntime.toString(key));
/*     */       } 
/*     */       
/* 140 */       return ids.toArray();
/*     */     } 
/* 142 */     return super.getIds();
/*     */   }
/*     */   static {
/* 145 */     symbol_iterator = ((cx, scope, thisObj, args) -> {
/*     */         if (!(thisObj instanceof NativeJavaMap))
/*     */           throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { SymbolKey.ITERATOR }); 
/*     */         return new NativeJavaMapIterator(scope, ((NativeJavaMap)thisObj).map);
/*     */       });
/*     */   }
/*     */   
/*     */   private static final class NativeJavaMapIterator extends ES6Iterator {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private static final String ITERATOR_TAG = "JavaMapIterator";
/*     */     private Iterator<Map.Entry<Object, Object>> iterator;
/*     */     
/*     */     static void init(ScriptableObject scope, boolean sealed) {
/* 158 */       ES6Iterator.init(scope, sealed, new NativeJavaMapIterator(), "JavaMapIterator");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private NativeJavaMapIterator() {}
/*     */ 
/*     */     
/*     */     NativeJavaMapIterator(Scriptable scope, Map<Object, Object> map) {
/* 167 */       super(scope, "JavaMapIterator");
/* 168 */       this.iterator = map.entrySet().iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getClassName() {
/* 173 */       return "Java Map Iterator";
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isDone(Context cx, Scriptable scope) {
/* 178 */       return !this.iterator.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object nextValue(Context cx, Scriptable scope) {
/* 183 */       if (!this.iterator.hasNext()) {
/* 184 */         return cx.newArray(scope, new Object[] { Undefined.instance, Undefined.instance });
/*     */       }
/* 186 */       Map.Entry e = this.iterator.next();
/* 187 */       return cx.newArray(scope, new Object[] { e.getKey(), e.getValue() });
/*     */     }
/*     */ 
/*     */     
/*     */     protected String getTag() {
/* 192 */       return "JavaMapIterator";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeJavaMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */