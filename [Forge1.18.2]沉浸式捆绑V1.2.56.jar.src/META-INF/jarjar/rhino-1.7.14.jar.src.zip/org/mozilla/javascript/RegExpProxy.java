package org.mozilla.javascript;

public interface RegExpProxy {
  public static final int RA_MATCH = 1;
  
  public static final int RA_REPLACE = 2;
  
  public static final int RA_SEARCH = 3;
  
  boolean isRegExp(Scriptable paramScriptable);
  
  Object compileRegExp(Context paramContext, String paramString1, String paramString2);
  
  Scriptable wrapRegExp(Context paramContext, Scriptable paramScriptable, Object paramObject);
  
  Object action(Context paramContext, Scriptable paramScriptable1, Scriptable paramScriptable2, Object[] paramArrayOfObject, int paramInt);
  
  int find_split(Context paramContext, Scriptable paramScriptable1, String paramString1, String paramString2, Scriptable paramScriptable2, int[] paramArrayOfint1, int[] paramArrayOfint2, boolean[] paramArrayOfboolean, String[][] paramArrayOfString);
  
  Object js_split(Context paramContext, Scriptable paramScriptable, String paramString, Object[] paramArrayOfObject);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\RegExpProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */