/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ES6Iterator
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 2438373029140003950L;
/*     */   
/*     */   protected static void init(ScriptableObject scope, boolean sealed, IdScriptableObject prototype, String tag) {
/*  14 */     if (scope != null) {
/*  15 */       prototype.setParentScope(scope);
/*  16 */       prototype.setPrototype(getObjectPrototype(scope));
/*     */     } 
/*  18 */     prototype.activatePrototypeMap(3);
/*  19 */     if (sealed) {
/*  20 */       prototype.sealObject();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  27 */     if (scope != null) {
/*  28 */       scope.associateValue(tag, prototype);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean exhausted = false;
/*     */   private String tag;
/*     */   private static final int Id_next = 1;
/*     */   private static final int SymbolId_iterator = 2;
/*     */   private static final int SymbolId_toStringTag = 3;
/*     */   private static final int MAX_PROTOTYPE_ID = 3;
/*     */   
/*     */   protected ES6Iterator(Scriptable scope, String tag) {
/*  41 */     this.tag = tag;
/*  42 */     Scriptable top = ScriptableObject.getTopLevelScope(scope);
/*  43 */     setParentScope(top);
/*     */     
/*  45 */     IdScriptableObject prototype = (IdScriptableObject)ScriptableObject.getTopScopeValue(top, tag);
/*  46 */     setPrototype(prototype);
/*     */   }
/*     */   public static final String NEXT_METHOD = "next"; public static final String DONE_PROPERTY = "done"; public static final String RETURN_PROPERTY = "return"; public static final String VALUE_PROPERTY = "value"; public static final String RETURN_METHOD = "return";
/*     */   protected ES6Iterator() {}
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*  52 */     switch (id) {
/*     */       case 1:
/*  54 */         initPrototypeMethod(getTag(), id, "next", 0);
/*     */         return;
/*     */       case 2:
/*  57 */         initPrototypeMethod(getTag(), id, SymbolKey.ITERATOR, "[Symbol.iterator]", 3);
/*     */         return;
/*     */       case 3:
/*  60 */         initPrototypeValue(3, SymbolKey.TO_STRING_TAG, getClassName(), 3); return;
/*     */     } 
/*  62 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  70 */     if (!f.hasTag(getTag())) {
/*  71 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  73 */     int id = f.methodId();
/*     */     
/*  75 */     ES6Iterator iterator = ensureType(thisObj, ES6Iterator.class, f);
/*     */     
/*  77 */     switch (id) {
/*     */       case 1:
/*  79 */         return iterator.next(cx, scope);
/*     */       case 2:
/*  81 */         return iterator;
/*     */     } 
/*  83 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(Symbol k) {
/*  89 */     if (SymbolKey.ITERATOR.equals(k))
/*  90 */       return 2; 
/*  91 */     if (SymbolKey.TO_STRING_TAG.equals(k)) {
/*  92 */       return 3;
/*     */     }
/*  94 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/*  99 */     if ("next".equals(s)) {
/* 100 */       return 1;
/*     */     }
/* 102 */     return 0;
/*     */   }
/*     */   
/*     */   protected abstract boolean isDone(Context paramContext, Scriptable paramScriptable);
/*     */   
/*     */   protected abstract Object nextValue(Context paramContext, Scriptable paramScriptable);
/*     */   
/*     */   protected Object next(Context cx, Scriptable scope) {
/* 110 */     Object value = Undefined.instance;
/* 111 */     boolean done = (isDone(cx, scope) || this.exhausted);
/* 112 */     if (!done) {
/* 113 */       value = nextValue(cx, scope);
/*     */     } else {
/* 115 */       this.exhausted = true;
/*     */     } 
/* 117 */     return makeIteratorResult(cx, scope, Boolean.valueOf(done), value);
/*     */   }
/*     */   
/*     */   protected String getTag() {
/* 121 */     return this.tag;
/*     */   }
/*     */ 
/*     */   
/*     */   static Scriptable makeIteratorResult(Context cx, Scriptable scope, Boolean done) {
/* 126 */     return makeIteratorResult(cx, scope, done, Undefined.instance);
/*     */   }
/*     */   
/*     */   static Scriptable makeIteratorResult(Context cx, Scriptable scope, Boolean done, Object value) {
/* 130 */     Scriptable iteratorResult = cx.newObject(scope);
/* 131 */     ScriptableObject.putProperty(iteratorResult, "value", value);
/* 132 */     ScriptableObject.putProperty(iteratorResult, "done", done);
/* 133 */     return iteratorResult;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ES6Iterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */