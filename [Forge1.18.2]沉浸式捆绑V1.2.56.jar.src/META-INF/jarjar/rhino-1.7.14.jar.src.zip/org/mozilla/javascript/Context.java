/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.UnaryOperator;
/*      */ import org.mozilla.classfile.ClassFileWriter;
/*      */ import org.mozilla.javascript.ast.AstRoot;
/*      */ import org.mozilla.javascript.ast.ScriptNode;
/*      */ import org.mozilla.javascript.debug.DebuggableScript;
/*      */ import org.mozilla.javascript.debug.Debugger;
/*      */ import org.mozilla.javascript.xml.XMLLib;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Context
/*      */   implements Closeable
/*      */ {
/*      */   public static final int VERSION_UNKNOWN = -1;
/*      */   public static final int VERSION_DEFAULT = 0;
/*      */   public static final int VERSION_1_0 = 100;
/*      */   public static final int VERSION_1_1 = 110;
/*      */   public static final int VERSION_1_2 = 120;
/*      */   public static final int VERSION_1_3 = 130;
/*      */   public static final int VERSION_1_4 = 140;
/*      */   public static final int VERSION_1_5 = 150;
/*      */   public static final int VERSION_1_6 = 160;
/*      */   public static final int VERSION_1_7 = 170;
/*      */   public static final int VERSION_1_8 = 180;
/*      */   public static final int VERSION_ES6 = 200;
/*      */   public static final int FEATURE_NON_ECMA_GET_YEAR = 1;
/*      */   public static final int FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME = 2;
/*      */   public static final int FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER = 3;
/*      */   public static final int FEATURE_TO_STRING_AS_SOURCE = 4;
/*      */   public static final int FEATURE_PARENT_PROTO_PROPERTIES = 5;
/*      */   @Deprecated
/*      */   public static final int FEATURE_PARENT_PROTO_PROPRTIES = 5;
/*      */   public static final int FEATURE_E4X = 6;
/*      */   public static final int FEATURE_DYNAMIC_SCOPE = 7;
/*      */   public static final int FEATURE_STRICT_VARS = 8;
/*      */   public static final int FEATURE_STRICT_EVAL = 9;
/*      */   public static final int FEATURE_LOCATION_INFORMATION_IN_ERROR = 10;
/*      */   public static final int FEATURE_STRICT_MODE = 11;
/*      */   public static final int FEATURE_WARNING_AS_ERROR = 12;
/*      */   public static final int FEATURE_ENHANCED_JAVA_ACCESS = 13;
/*      */   public static final int FEATURE_V8_EXTENSIONS = 14;
/*      */   public static final int FEATURE_OLD_UNDEF_NULL_THIS = 15;
/*      */   public static final int FEATURE_ENUMERATE_IDS_FIRST = 16;
/*      */   public static final int FEATURE_THREAD_SAFE_OBJECTS = 17;
/*      */   public static final int FEATURE_INTEGER_WITHOUT_DECIMAL_PLACE = 18;
/*      */   public static final int FEATURE_LITTLE_ENDIAN = 19;
/*      */   public static final int FEATURE_ENABLE_XML_SECURE_PARSING = 20;
/*      */   public static final int FEATURE_ENABLE_JAVA_MAP_ACCESS = 21;
/*      */   public static final String languageVersionProperty = "language version";
/*      */   public static final String errorReporterProperty = "error reporter";
/*  347 */   public static final Object[] emptyArgs = ScriptRuntime.emptyArgs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Context() {
/*  363 */     this(ContextFactory.getGlobal());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Context(ContextFactory factory) {
/*  376 */     if (factory == null) {
/*  377 */       throw new IllegalArgumentException("factory == null");
/*      */     }
/*  379 */     this.factory = factory;
/*  380 */     this.version = 0;
/*  381 */     this.optimizationLevel = (codegenClass != null) ? 0 : -1;
/*  382 */     this.maximumInterpreterStackDepth = Integer.MAX_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Context getCurrentContext() {
/*  399 */     Object helper = VMBridge.instance.getThreadContextHelper();
/*  400 */     return VMBridge.instance.getContext(helper);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Context enter() {
/*  412 */     return enter(null, ContextFactory.getGlobal());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Context enter(Context cx) {
/*  431 */     return enter(cx, ContextFactory.getGlobal());
/*      */   }
/*      */   
/*      */   static final Context enter(Context cx, ContextFactory factory) {
/*  435 */     Object helper = VMBridge.instance.getThreadContextHelper();
/*  436 */     Context old = VMBridge.instance.getContext(helper);
/*  437 */     if (old != null) {
/*  438 */       cx = old;
/*      */     } else {
/*  440 */       if (cx == null) {
/*  441 */         cx = factory.makeContext();
/*  442 */         if (cx.enterCount != 0) {
/*  443 */           throw new IllegalStateException("factory.makeContext() returned Context instance already associated with some thread");
/*      */         }
/*      */         
/*  446 */         factory.onContextCreated(cx);
/*  447 */         if (factory.isSealed() && !cx.isSealed()) {
/*  448 */           cx.seal(null);
/*      */         }
/*      */       }
/*  451 */       else if (cx.enterCount != 0) {
/*  452 */         throw new IllegalStateException("can not use Context instance already associated with some thread");
/*      */       } 
/*      */ 
/*      */       
/*  456 */       VMBridge.instance.setContext(helper, cx);
/*      */     } 
/*  458 */     cx.enterCount++;
/*  459 */     return cx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void exit() {
/*  473 */     Object helper = VMBridge.instance.getThreadContextHelper();
/*  474 */     Context cx = VMBridge.instance.getContext(helper);
/*  475 */     if (cx == null) {
/*  476 */       throw new IllegalStateException("Calling Context.exit without previous Context.enter");
/*      */     }
/*  478 */     if (cx.enterCount < 1) Kit.codeBug(); 
/*  479 */     if (--cx.enterCount == 0) {
/*  480 */       VMBridge.instance.setContext(helper, null);
/*  481 */       cx.factory.onContextReleased(cx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() {
/*  487 */     exit();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> T call(ContextAction<T> action) {
/*  503 */     return call(ContextFactory.getGlobal(), action);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object call(ContextFactory factory, Callable callable, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  525 */     if (factory == null) {
/*  526 */       factory = ContextFactory.getGlobal();
/*      */     }
/*  528 */     return call(factory, cx -> callable.call(cx, scope, thisObj, args));
/*      */   }
/*      */ 
/*      */   
/*      */   static <T> T call(ContextFactory factory, ContextAction<T> action) {
/*  533 */     Context cx = enter(null, factory);
/*      */     try {
/*  535 */       return action.run(cx);
/*      */     } finally {
/*  537 */       exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void addContextListener(ContextListener listener) {
/*  549 */     String DBG = "org.mozilla.javascript.tools.debugger.Main";
/*  550 */     if (DBG.equals(listener.getClass().getName())) {
/*  551 */       Class<?> cl = listener.getClass();
/*  552 */       Class<?> factoryClass = Kit.classOrNull("org.mozilla.javascript.ContextFactory");
/*  553 */       Class<?>[] sig = new Class[] { factoryClass };
/*  554 */       Object[] args = { ContextFactory.getGlobal() };
/*      */       try {
/*  556 */         Method m = cl.getMethod("attachTo", sig);
/*  557 */         m.invoke(listener, args);
/*  558 */       } catch (Exception ex) {
/*  559 */         throw new RuntimeException(ex);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*  564 */     ContextFactory.getGlobal().addListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void removeContextListener(ContextListener listener) {
/*  574 */     ContextFactory.getGlobal().addListener(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final ContextFactory getFactory() {
/*  579 */     return this.factory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isSealed() {
/*  589 */     return this.sealed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void seal(Object sealKey) {
/*  603 */     if (this.sealed) onSealedMutation(); 
/*  604 */     this.sealed = true;
/*  605 */     this.sealKey = sealKey;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void unseal(Object sealKey) {
/*  617 */     if (sealKey == null) throw new IllegalArgumentException(); 
/*  618 */     if (this.sealKey != sealKey) throw new IllegalArgumentException(); 
/*  619 */     if (!this.sealed) throw new IllegalStateException(); 
/*  620 */     this.sealed = false;
/*  621 */     this.sealKey = null;
/*      */   }
/*      */   
/*      */   static void onSealedMutation() {
/*  625 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getLanguageVersion() {
/*  637 */     return this.version;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLanguageVersion(int version) {
/*  649 */     if (this.sealed) onSealedMutation(); 
/*  650 */     checkLanguageVersion(version);
/*  651 */     Object listeners = this.propertyListeners;
/*  652 */     if (listeners != null && version != this.version) {
/*  653 */       firePropertyChangeImpl(listeners, "language version", 
/*      */ 
/*      */           
/*  656 */           Integer.valueOf(this.version), 
/*  657 */           Integer.valueOf(version));
/*      */     }
/*  659 */     this.version = version;
/*      */   }
/*      */   
/*      */   public static boolean isValidLanguageVersion(int version) {
/*  663 */     switch (version) {
/*      */       case 0:
/*      */       case 100:
/*      */       case 110:
/*      */       case 120:
/*      */       case 130:
/*      */       case 140:
/*      */       case 150:
/*      */       case 160:
/*      */       case 170:
/*      */       case 180:
/*      */       case 200:
/*  675 */         return true;
/*      */     } 
/*  677 */     return false;
/*      */   }
/*      */   
/*      */   public static void checkLanguageVersion(int version) {
/*  681 */     if (isValidLanguageVersion(version)) {
/*      */       return;
/*      */     }
/*  684 */     throw new IllegalArgumentException("Bad language version: " + version);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getImplementationVersion() {
/*  703 */     return ImplementationVersion.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ErrorReporter getErrorReporter() {
/*  712 */     if (this.errorReporter == null) {
/*  713 */       return DefaultErrorReporter.instance;
/*      */     }
/*  715 */     return this.errorReporter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ErrorReporter setErrorReporter(ErrorReporter reporter) {
/*  725 */     if (this.sealed) onSealedMutation(); 
/*  726 */     if (reporter == null) throw new IllegalArgumentException(); 
/*  727 */     ErrorReporter old = getErrorReporter();
/*  728 */     if (reporter == old) {
/*  729 */       return old;
/*      */     }
/*  731 */     Object listeners = this.propertyListeners;
/*  732 */     if (listeners != null) {
/*  733 */       firePropertyChangeImpl(listeners, "error reporter", old, reporter);
/*      */     }
/*      */ 
/*      */     
/*  737 */     this.errorReporter = reporter;
/*  738 */     return old;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Locale getLocale() {
/*  747 */     if (this.locale == null) this.locale = Locale.getDefault(); 
/*  748 */     return this.locale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Locale setLocale(Locale loc) {
/*  757 */     if (this.sealed) onSealedMutation(); 
/*  758 */     Locale result = this.locale;
/*  759 */     this.locale = loc;
/*  760 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addPropertyChangeListener(PropertyChangeListener l) {
/*  771 */     if (this.sealed) onSealedMutation(); 
/*  772 */     this.propertyListeners = Kit.addListener(this.propertyListeners, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void removePropertyChangeListener(PropertyChangeListener l) {
/*  784 */     if (this.sealed) onSealedMutation(); 
/*  785 */     this.propertyListeners = Kit.removeListener(this.propertyListeners, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void firePropertyChange(String property, Object oldValue, Object newValue) {
/*  800 */     Object listeners = this.propertyListeners;
/*  801 */     if (listeners != null) {
/*  802 */       firePropertyChangeImpl(listeners, property, oldValue, newValue);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void firePropertyChangeImpl(Object listeners, String property, Object oldValue, Object newValue) {
/*  808 */     for (int i = 0;; i++) {
/*  809 */       Object l = Kit.getListener(listeners, i);
/*  810 */       if (l == null)
/*  811 */         break;  if (l instanceof PropertyChangeListener) {
/*  812 */         PropertyChangeListener pcl = (PropertyChangeListener)l;
/*  813 */         pcl.propertyChange(new PropertyChangeEvent(this, property, oldValue, newValue));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportWarning(String message, String sourceName, int lineno, String lineSource, int lineOffset) {
/*  830 */     Context cx = getContext();
/*  831 */     if (cx.hasFeature(12))
/*  832 */     { reportError(message, sourceName, lineno, lineSource, lineOffset); }
/*  833 */     else { cx.getErrorReporter().warning(message, sourceName, lineno, lineSource, lineOffset); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportWarning(String message) {
/*  843 */     int[] linep = { 0 };
/*  844 */     String filename = getSourcePositionFromStack(linep);
/*  845 */     reportWarning(message, filename, linep[0], null, 0);
/*      */   }
/*      */   
/*      */   public static void reportWarning(String message, Throwable t) {
/*  849 */     int[] linep = { 0 };
/*  850 */     String filename = getSourcePositionFromStack(linep);
/*  851 */     Writer sw = new StringWriter();
/*  852 */     PrintWriter pw = new PrintWriter(sw);
/*  853 */     pw.println(message);
/*  854 */     t.printStackTrace(pw);
/*  855 */     pw.flush();
/*  856 */     reportWarning(sw.toString(), filename, linep[0], null, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportError(String message, String sourceName, int lineno, String lineSource, int lineOffset) {
/*  871 */     Context cx = getCurrentContext();
/*  872 */     if (cx != null) {
/*  873 */       cx.getErrorReporter().error(message, sourceName, lineno, lineSource, lineOffset);
/*      */     } else {
/*  875 */       throw new EvaluatorException(message, sourceName, lineno, lineSource, lineOffset);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reportError(String message) {
/*  886 */     int[] linep = { 0 };
/*  887 */     String filename = getSourcePositionFromStack(linep);
/*  888 */     reportError(message, filename, linep[0], null, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static EvaluatorException reportRuntimeError(String message, String sourceName, int lineno, String lineSource, int lineOffset) {
/*  904 */     Context cx = getCurrentContext();
/*  905 */     if (cx != null) {
/*  906 */       return cx.getErrorReporter()
/*  907 */         .runtimeError(message, sourceName, lineno, lineSource, lineOffset);
/*      */     }
/*  909 */     throw new EvaluatorException(message, sourceName, lineno, lineSource, lineOffset);
/*      */   }
/*      */   
/*      */   static EvaluatorException reportRuntimeErrorById(String messageId, Object... args) {
/*  913 */     String msg = ScriptRuntime.getMessageById(messageId, args);
/*  914 */     return reportRuntimeError(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   static EvaluatorException reportRuntimeError0(String messageId) {
/*  920 */     String msg = ScriptRuntime.getMessageById(messageId, new Object[0]);
/*  921 */     return reportRuntimeError(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   static EvaluatorException reportRuntimeError1(String messageId, Object arg1) {
/*  927 */     String msg = ScriptRuntime.getMessageById(messageId, new Object[] { arg1 });
/*  928 */     return reportRuntimeError(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   static EvaluatorException reportRuntimeError2(String messageId, Object arg1, Object arg2) {
/*  934 */     String msg = ScriptRuntime.getMessageById(messageId, new Object[] { arg1, arg2 });
/*  935 */     return reportRuntimeError(msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   static EvaluatorException reportRuntimeError3(String messageId, Object arg1, Object arg2, Object arg3) {
/*  942 */     String msg = ScriptRuntime.getMessageById(messageId, new Object[] { arg1, arg2, arg3 });
/*  943 */     return reportRuntimeError(msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   static EvaluatorException reportRuntimeError4(String messageId, Object arg1, Object arg2, Object arg3, Object arg4) {
/*  950 */     String msg = ScriptRuntime.getMessageById(messageId, new Object[] { arg1, arg2, arg3, arg4 });
/*  951 */     return reportRuntimeError(msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static EvaluatorException reportRuntimeError(String message) {
/*  961 */     int[] linep = { 0 };
/*  962 */     String filename = getSourcePositionFromStack(linep);
/*  963 */     return reportRuntimeError(message, filename, linep[0], null, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ScriptableObject initStandardObjects() {
/*  980 */     return initStandardObjects(null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ScriptableObject initSafeStandardObjects() {
/* 1003 */     return initSafeStandardObjects(null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Scriptable initStandardObjects(ScriptableObject scope) {
/* 1023 */     return initStandardObjects(scope, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Scriptable initSafeStandardObjects(ScriptableObject scope) {
/* 1049 */     return initSafeStandardObjects(scope, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ScriptableObject initStandardObjects(ScriptableObject scope, boolean sealed) {
/* 1076 */     return ScriptRuntime.initStandardObjects(this, scope, sealed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ScriptableObject initSafeStandardObjects(ScriptableObject scope, boolean sealed) {
/* 1109 */     return ScriptRuntime.initSafeStandardObjects(this, scope, sealed);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object getUndefinedValue() {
/* 1114 */     return Undefined.instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object evaluateString(Scriptable scope, String source, String sourceName, int lineno, Object securityDomain) {
/* 1135 */     Script script = compileString(source, sourceName, lineno, securityDomain);
/* 1136 */     if (script != null) {
/* 1137 */       return script.exec(this, scope);
/*      */     }
/* 1139 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object evaluateReader(Scriptable scope, Reader in, String sourceName, int lineno, Object securityDomain) throws IOException {
/* 1160 */     Script script = compileReader(scope, in, sourceName, lineno, securityDomain);
/* 1161 */     if (script != null) {
/* 1162 */       return script.exec(this, scope);
/*      */     }
/* 1164 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object executeScriptWithContinuations(Script script, Scriptable scope) throws ContinuationPending {
/* 1181 */     if (!(script instanceof InterpretedFunction) || 
/* 1182 */       !((InterpretedFunction)script).isScript())
/*      */     {
/* 1184 */       throw new IllegalArgumentException("Script argument was not a script or was not created by interpreted mode ");
/*      */     }
/*      */ 
/*      */     
/* 1188 */     return callFunctionWithContinuations((InterpretedFunction)script, scope, ScriptRuntime.emptyArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object callFunctionWithContinuations(Callable function, Scriptable scope, Object[] args) throws ContinuationPending {
/* 1207 */     if (!(function instanceof InterpretedFunction))
/*      */     {
/* 1209 */       throw new IllegalArgumentException("Function argument was not created by interpreted mode ");
/*      */     }
/*      */     
/* 1212 */     if (ScriptRuntime.hasTopCall(this)) {
/* 1213 */       throw new IllegalStateException("Cannot have any pending top calls when executing a script with continuations");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1219 */     this.isContinuationsTopCall = true;
/* 1220 */     return ScriptRuntime.doTopCall(function, this, scope, scope, args, this.isTopLevelStrict);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContinuationPending captureContinuation() {
/* 1235 */     return new ContinuationPending(Interpreter.captureContinuation(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object resumeContinuation(Object continuation, Scriptable scope, Object functionResult) throws ContinuationPending {
/* 1253 */     Object[] args = { functionResult };
/* 1254 */     return Interpreter.restartContinuation((NativeContinuation)continuation, this, scope, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean stringIsCompilableUnit(String source) {
/* 1273 */     boolean errorseen = false;
/* 1274 */     CompilerEnvirons compilerEnv = new CompilerEnvirons();
/* 1275 */     compilerEnv.initFromContext(this);
/*      */ 
/*      */     
/* 1278 */     compilerEnv.setGeneratingSource(false);
/* 1279 */     Parser p = new Parser(compilerEnv, DefaultErrorReporter.instance);
/*      */     try {
/* 1281 */       p.parse(source, (String)null, 1);
/* 1282 */     } catch (EvaluatorException ee) {
/* 1283 */       errorseen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1288 */     return (!errorseen || !p.eof());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Script compileReader(Scriptable scope, Reader in, String sourceName, int lineno, Object securityDomain) throws IOException {
/* 1299 */     return compileReader(in, sourceName, lineno, securityDomain);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Script compileReader(Reader in, String sourceName, int lineno, Object securityDomain) throws IOException {
/* 1319 */     if (lineno < 0)
/*      */     {
/* 1321 */       lineno = 0;
/*      */     }
/*      */     
/* 1324 */     return (Script)
/* 1325 */       compileImpl(null, 
/*      */         
/* 1327 */         Kit.readReader(in), sourceName, lineno, securityDomain, false, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Script compileString(String source, String sourceName, int lineno, Object securityDomain) {
/* 1353 */     if (lineno < 0)
/*      */     {
/* 1355 */       lineno = 0;
/*      */     }
/* 1357 */     return compileString(source, null, null, sourceName, lineno, securityDomain);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Script compileString(String source, Evaluator compiler, ErrorReporter compilationErrorReporter, String sourceName, int lineno, Object securityDomain) {
/*      */     try {
/* 1368 */       return (Script)
/* 1369 */         compileImpl(null, source, sourceName, lineno, securityDomain, false, compiler, compilationErrorReporter);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1378 */     catch (IOException ioe) {
/*      */       
/* 1380 */       throw new RuntimeException(ioe);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Function compileFunction(Scriptable scope, String source, String sourceName, int lineno, Object securityDomain) {
/* 1402 */     return compileFunction(scope, source, null, null, sourceName, lineno, securityDomain);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Function compileFunction(Scriptable scope, String source, Evaluator compiler, ErrorReporter compilationErrorReporter, String sourceName, int lineno, Object securityDomain) {
/*      */     try {
/* 1414 */       return (Function)
/* 1415 */         compileImpl(scope, source, sourceName, lineno, securityDomain, true, compiler, compilationErrorReporter);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1424 */     catch (IOException ioe) {
/*      */ 
/*      */       
/* 1427 */       throw new RuntimeException(ioe);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String decompileScript(Script script, int indent) {
/* 1441 */     NativeFunction scriptImpl = (NativeFunction)script;
/* 1442 */     return scriptImpl.decompile(indent, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String decompileFunction(Function fun, int indent) {
/* 1457 */     if (fun instanceof BaseFunction) return ((BaseFunction)fun).decompile(indent, 0);
/*      */     
/* 1459 */     return "function " + fun.getClassName() + "() {\n\t[native code]\n}\n";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String decompileFunctionBody(Function fun, int indent) {
/* 1475 */     if (fun instanceof BaseFunction) {
/* 1476 */       BaseFunction bf = (BaseFunction)fun;
/* 1477 */       return bf.decompile(indent, 1);
/*      */     } 
/*      */     
/* 1480 */     return "[native code]\n";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Scriptable newObject(Scriptable scope) {
/* 1492 */     NativeObject result = new NativeObject();
/* 1493 */     ScriptRuntime.setBuiltinProtoAndParent(result, scope, TopLevel.Builtins.Object);
/* 1494 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Scriptable newObject(Scriptable scope, String constructorName) {
/* 1507 */     return newObject(scope, constructorName, ScriptRuntime.emptyArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Scriptable newObject(Scriptable scope, String constructorName, Object[] args) {
/* 1531 */     return ScriptRuntime.newObject(this, scope, constructorName, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Scriptable newArray(Scriptable scope, int length) {
/* 1545 */     NativeArray result = new NativeArray(length);
/* 1546 */     ScriptRuntime.setBuiltinProtoAndParent(result, scope, TopLevel.Builtins.Array);
/* 1547 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Scriptable newArray(Scriptable scope, Object[] elements) {
/* 1559 */     if (elements.getClass().getComponentType() != ScriptRuntime.ObjectClass)
/* 1560 */       throw new IllegalArgumentException(); 
/* 1561 */     NativeArray result = new NativeArray(elements);
/* 1562 */     ScriptRuntime.setBuiltinProtoAndParent(result, scope, TopLevel.Builtins.Array);
/* 1563 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object[] getElements(Scriptable object) {
/* 1581 */     return ScriptRuntime.getArrayElements(object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean toBoolean(Object value) {
/* 1593 */     return ScriptRuntime.toBoolean(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toNumber(Object value) {
/* 1607 */     return ScriptRuntime.toNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(Object value) {
/* 1621 */     return ScriptRuntime.toString(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Scriptable toObject(Object value, Scriptable scope) {
/* 1640 */     return ScriptRuntime.toObject(scope, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Scriptable toObject(Object value, Scriptable scope, Class<?> staticType) {
/* 1649 */     return ScriptRuntime.toObject(scope, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object javaToJS(Object value, Scriptable scope) {
/* 1679 */     return javaToJS(value, scope, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object javaToJS(Object value, Scriptable scope, Context cx) {
/* 1709 */     if (value instanceof String || value instanceof Number || value instanceof Boolean || value instanceof Scriptable)
/*      */     {
/*      */ 
/*      */       
/* 1713 */       return value; } 
/* 1714 */     if (value instanceof Character) {
/* 1715 */       return String.valueOf(((Character)value).charValue());
/*      */     }
/* 1717 */     if (cx == null) {
/* 1718 */       cx = getContext();
/*      */     }
/* 1720 */     return cx.getWrapFactory().wrap(cx, scope, value, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object jsToJava(Object value, Class<?> desiredType) throws EvaluatorException {
/* 1735 */     return NativeJavaObject.coerceTypeImpl(desiredType, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object toType(Object value, Class<?> desiredType) throws IllegalArgumentException {
/*      */     try {
/* 1748 */       return jsToJava(value, desiredType);
/* 1749 */     } catch (EvaluatorException ex) {
/* 1750 */       throw new IllegalArgumentException(ex.getMessage(), ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UnaryOperator<Object> getJavaToJSONConverter() {
/* 1766 */     if (this.javaToJSONConverter == null) {
/* 1767 */       return JavaToJSONConverters.STRING;
/*      */     }
/* 1769 */     return this.javaToJSONConverter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJavaToJSONConverter(UnaryOperator<Object> javaToJSONConverter) throws IllegalArgumentException {
/* 1787 */     if (javaToJSONConverter == null) {
/* 1788 */       throw new IllegalArgumentException("javaToJSONConverter == null");
/*      */     }
/* 1790 */     this.javaToJSONConverter = javaToJSONConverter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RuntimeException throwAsScriptRuntimeEx(Throwable e) {
/* 1812 */     while (e instanceof InvocationTargetException) {
/* 1813 */       e = ((InvocationTargetException)e).getTargetException();
/*      */     }
/*      */     
/* 1816 */     if (e instanceof Error) {
/* 1817 */       Context cx = getContext();
/* 1818 */       if (cx == null || !cx.hasFeature(13)) {
/* 1819 */         throw (Error)e;
/*      */       }
/*      */     } 
/* 1822 */     if (e instanceof RhinoException) {
/* 1823 */       throw (RhinoException)e;
/*      */     }
/* 1825 */     throw new WrappedException(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isGeneratingDebug() {
/* 1834 */     return this.generatingDebug;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setGeneratingDebug(boolean generatingDebug) {
/* 1845 */     if (this.sealed) onSealedMutation(); 
/* 1846 */     this.generatingDebugChanged = true;
/* 1847 */     if (generatingDebug && getOptimizationLevel() > 0) setOptimizationLevel(0); 
/* 1848 */     this.generatingDebug = generatingDebug;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isGeneratingSource() {
/* 1857 */     return this.generatingSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setGeneratingSource(boolean generatingSource) {
/* 1870 */     if (this.sealed) onSealedMutation(); 
/* 1871 */     this.generatingSource = generatingSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getOptimizationLevel() {
/* 1882 */     return this.optimizationLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOptimizationLevel(int optimizationLevel) {
/* 1899 */     if (this.sealed) onSealedMutation(); 
/* 1900 */     if (optimizationLevel == -2)
/*      */     {
/* 1902 */       optimizationLevel = -1;
/*      */     }
/* 1904 */     checkOptimizationLevel(optimizationLevel);
/* 1905 */     if (codegenClass == null) optimizationLevel = -1; 
/* 1906 */     this.optimizationLevel = optimizationLevel;
/*      */   }
/*      */   
/*      */   public static boolean isValidOptimizationLevel(int optimizationLevel) {
/* 1910 */     return (-1 <= optimizationLevel && optimizationLevel <= 9);
/*      */   }
/*      */   
/*      */   public static void checkOptimizationLevel(int optimizationLevel) {
/* 1914 */     if (isValidOptimizationLevel(optimizationLevel)) {
/*      */       return;
/*      */     }
/* 1917 */     throw new IllegalArgumentException("Optimization level outside [-1..9]: " + optimizationLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getMaximumInterpreterStackDepth() {
/* 1934 */     return this.maximumInterpreterStackDepth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setMaximumInterpreterStackDepth(int max) {
/* 1952 */     if (this.sealed) onSealedMutation(); 
/* 1953 */     if (this.optimizationLevel != -1) {
/* 1954 */       throw new IllegalStateException("Cannot set maximumInterpreterStackDepth when optimizationLevel != -1");
/*      */     }
/*      */     
/* 1957 */     if (max < 1) {
/* 1958 */       throw new IllegalArgumentException("Cannot set maximumInterpreterStackDepth to less than 1");
/*      */     }
/*      */     
/* 1961 */     this.maximumInterpreterStackDepth = max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSecurityController(SecurityController controller) {
/* 1978 */     if (this.sealed) onSealedMutation(); 
/* 1979 */     if (controller == null) throw new IllegalArgumentException(); 
/* 1980 */     if (this.securityController != null) {
/* 1981 */       throw new SecurityException("Can not overwrite existing SecurityController object");
/*      */     }
/* 1983 */     if (SecurityController.hasGlobal()) {
/* 1984 */       throw new SecurityException("Can not overwrite existing global SecurityController object");
/*      */     }
/*      */     
/* 1987 */     this.securityController = controller;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized void setClassShutter(ClassShutter shutter) {
/* 2000 */     if (this.sealed) onSealedMutation(); 
/* 2001 */     if (shutter == null) throw new IllegalArgumentException(); 
/* 2002 */     if (this.hasClassShutter) {
/* 2003 */       throw new SecurityException("Cannot overwrite existing ClassShutter object");
/*      */     }
/* 2005 */     this.classShutter = shutter;
/* 2006 */     this.hasClassShutter = true;
/*      */   }
/*      */   
/*      */   final synchronized ClassShutter getClassShutter() {
/* 2010 */     return this.classShutter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized ClassShutterSetter getClassShutterSetter() {
/* 2020 */     if (this.hasClassShutter) return null; 
/* 2021 */     this.hasClassShutter = true;
/* 2022 */     return new ClassShutterSetter()
/*      */       {
/*      */         public void setClassShutter(ClassShutter shutter)
/*      */         {
/* 2026 */           Context.this.classShutter = shutter;
/*      */         }
/*      */ 
/*      */         
/*      */         public ClassShutter getClassShutter() {
/* 2031 */           return Context.this.classShutter;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface ClassShutterSetter
/*      */   {
/*      */     void setClassShutter(ClassShutter param1ClassShutter);
/*      */ 
/*      */ 
/*      */     
/*      */     ClassShutter getClassShutter();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object getThreadLocal(Object key) {
/* 2051 */     if (this.threadLocalMap == null) return null; 
/* 2052 */     return this.threadLocalMap.get(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized void putThreadLocal(Object key, Object value) {
/* 2064 */     if (this.sealed) onSealedMutation(); 
/* 2065 */     if (this.threadLocalMap == null) this.threadLocalMap = new HashMap<>(); 
/* 2066 */     this.threadLocalMap.put(key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void removeThreadLocal(Object key) {
/* 2076 */     if (this.sealed) onSealedMutation(); 
/* 2077 */     if (this.threadLocalMap == null)
/* 2078 */       return;  this.threadLocalMap.remove(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void setCachingEnabled(boolean cachingEnabled) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setWrapFactory(WrapFactory wrapFactory) {
/* 2099 */     if (this.sealed) onSealedMutation(); 
/* 2100 */     if (wrapFactory == null) throw new IllegalArgumentException(); 
/* 2101 */     this.wrapFactory = wrapFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final WrapFactory getWrapFactory() {
/* 2111 */     if (this.wrapFactory == null) {
/* 2112 */       this.wrapFactory = new WrapFactory();
/*      */     }
/* 2114 */     return this.wrapFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Debugger getDebugger() {
/* 2123 */     return this.debugger;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object getDebuggerContextData() {
/* 2132 */     return this.debuggerData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setDebugger(Debugger debugger, Object contextData) {
/* 2142 */     if (this.sealed) onSealedMutation(); 
/* 2143 */     this.debugger = debugger;
/* 2144 */     this.debuggerData = contextData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DebuggableScript getDebuggableView(Script script) {
/* 2152 */     if (script instanceof NativeFunction) {
/* 2153 */       return ((NativeFunction)script).getDebuggableView();
/*      */     }
/* 2155 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasFeature(int featureIndex) {
/* 2184 */     ContextFactory f = getFactory();
/* 2185 */     return f.hasFeature(this, featureIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMLLib.Factory getE4xImplementationFactory() {
/* 2199 */     return getFactory().getE4xImplementationFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getInstructionObserverThreshold() {
/* 2209 */     return this.instructionThreshold;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setInstructionObserverThreshold(int threshold) {
/* 2226 */     if (this.sealed) onSealedMutation(); 
/* 2227 */     if (threshold < 0) throw new IllegalArgumentException(); 
/* 2228 */     this.instructionThreshold = threshold;
/* 2229 */     setGenerateObserverCount((threshold > 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGenerateObserverCount(boolean generateObserverCount) {
/* 2243 */     this.generateObserverCount = generateObserverCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void observeInstructionCount(int instructionCount) {
/* 2262 */     ContextFactory f = getFactory();
/* 2263 */     f.observeInstructionCount(this, instructionCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeneratedClassLoader createClassLoader(ClassLoader parent) {
/* 2271 */     ContextFactory f = getFactory();
/* 2272 */     return f.createClassLoader(parent);
/*      */   }
/*      */   
/*      */   public final ClassLoader getApplicationClassLoader() {
/* 2276 */     if (this.applicationClassLoader == null) {
/* 2277 */       ContextFactory f = getFactory();
/* 2278 */       ClassLoader loader = f.getApplicationClassLoader();
/* 2279 */       if (loader == null) {
/* 2280 */         ClassLoader threadLoader = Thread.currentThread().getContextClassLoader();
/* 2281 */         if (threadLoader != null && Kit.testIfCanLoadRhinoClasses(threadLoader))
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 2286 */           return threadLoader;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2291 */         Class<?> fClass = f.getClass();
/* 2292 */         if (fClass != ScriptRuntime.ContextFactoryClass) {
/* 2293 */           loader = fClass.getClassLoader();
/*      */         } else {
/* 2295 */           loader = getClass().getClassLoader();
/*      */         } 
/*      */       } 
/* 2298 */       this.applicationClassLoader = loader;
/*      */     } 
/* 2300 */     return this.applicationClassLoader;
/*      */   }
/*      */   
/*      */   public final void setApplicationClassLoader(ClassLoader loader) {
/* 2304 */     if (this.sealed) onSealedMutation(); 
/* 2305 */     if (loader == null) {
/*      */       
/* 2307 */       this.applicationClassLoader = null;
/*      */       return;
/*      */     } 
/* 2310 */     if (!Kit.testIfCanLoadRhinoClasses(loader)) {
/* 2311 */       throw new IllegalArgumentException("Loader can not resolve Rhino classes");
/*      */     }
/* 2313 */     this.applicationClassLoader = loader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enqueueMicrotask(Runnable task) {
/* 2323 */     this.microtasks.add(task);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void processMicrotasks() {
/*      */     Runnable head;
/*      */     do {
/* 2335 */       head = this.microtasks.poll();
/* 2336 */       if (head == null)
/* 2337 */         continue;  head.run();
/*      */     }
/* 2339 */     while (head != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTrackUnhandledPromiseRejections(boolean track) {
/* 2350 */     this.unhandledPromises.enable(track);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UnhandledRejectionTracker getUnhandledPromiseTracker() {
/* 2359 */     return this.unhandledPromises;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Context getContext() {
/* 2366 */     Context cx = getCurrentContext();
/* 2367 */     if (cx == null) {
/* 2368 */       throw new RuntimeException("No Context associated with current Thread");
/*      */     }
/* 2370 */     return cx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object compileImpl(Scriptable scope, String sourceString, String sourceName, int lineno, Object securityDomain, boolean returnFunction, Evaluator compiler, ErrorReporter compilationErrorReporter) throws IOException {
/*      */     Object bytecode, result;
/* 2383 */     if (sourceName == null) {
/* 2384 */       sourceName = "unnamed script";
/*      */     }
/* 2386 */     if (securityDomain != null && getSecurityController() == null) {
/* 2387 */       throw new IllegalArgumentException("securityDomain should be null if setSecurityController() was never called");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2392 */     if ((((scope == null) ? 1 : 0) ^ returnFunction) == 0) Kit.codeBug();
/*      */     
/* 2394 */     CompilerEnvirons compilerEnv = new CompilerEnvirons();
/* 2395 */     compilerEnv.initFromContext(this);
/* 2396 */     if (compilationErrorReporter == null) {
/* 2397 */       compilationErrorReporter = compilerEnv.getErrorReporter();
/*      */     }
/*      */ 
/*      */     
/* 2401 */     ScriptNode tree = parse(sourceString, sourceName, lineno, compilerEnv, compilationErrorReporter, returnFunction);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2411 */       if (compiler == null) {
/* 2412 */         compiler = createCompiler();
/*      */       }
/*      */       
/* 2415 */       bytecode = compiler.compile(compilerEnv, tree, tree.getEncodedSource(), returnFunction);
/* 2416 */     } catch (org.mozilla.classfile.ClassFileWriter.ClassFileFormatException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2422 */       tree = parse(sourceString, sourceName, lineno, compilerEnv, compilationErrorReporter, returnFunction);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2430 */       compiler = createInterpreter();
/* 2431 */       bytecode = compiler.compile(compilerEnv, tree, tree.getEncodedSource(), returnFunction);
/*      */     } 
/*      */     
/* 2434 */     if (this.debugger != null) {
/* 2435 */       if (sourceString == null) Kit.codeBug(); 
/* 2436 */       if (bytecode instanceof DebuggableScript) {
/* 2437 */         DebuggableScript dscript = (DebuggableScript)bytecode;
/* 2438 */         notifyDebugger_r(this, dscript, sourceString);
/*      */       } else {
/* 2440 */         throw new RuntimeException("NOT SUPPORTED");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2445 */     if (returnFunction) {
/* 2446 */       result = compiler.createFunctionObject(this, scope, bytecode, securityDomain);
/*      */     } else {
/* 2448 */       result = compiler.createScriptObject(bytecode, securityDomain);
/*      */     } 
/*      */     
/* 2451 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ScriptNode parse(String sourceString, String sourceName, int lineno, CompilerEnvirons compilerEnv, ErrorReporter compilationErrorReporter, boolean returnFunction) throws IOException {
/* 2462 */     Parser p = new Parser(compilerEnv, compilationErrorReporter);
/* 2463 */     if (returnFunction) {
/* 2464 */       p.calledByCompileFunction = true;
/*      */     }
/* 2466 */     if (isStrictMode()) {
/* 2467 */       p.setDefaultUseStrictDirective(true);
/*      */     }
/*      */     
/* 2470 */     AstRoot ast = p.parse(sourceString, sourceName, lineno);
/* 2471 */     if (returnFunction)
/*      */     {
/* 2473 */       if (ast.getFirstChild() == null || ast.getFirstChild().getType() != 113)
/*      */       {
/*      */ 
/*      */         
/* 2477 */         throw new IllegalArgumentException("compileFunction only accepts source with single JS function: " + sourceString);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2483 */     IRFactory irf = new IRFactory(compilerEnv, compilationErrorReporter);
/* 2484 */     ScriptNode tree = irf.transformTree(ast);
/* 2485 */     return tree;
/*      */   }
/*      */   
/*      */   private static void notifyDebugger_r(Context cx, DebuggableScript dscript, String debugSource) {
/* 2489 */     cx.debugger.handleCompilationDone(cx, dscript, debugSource);
/* 2490 */     for (int i = 0; i != dscript.getFunctionCount(); i++) {
/* 2491 */       notifyDebugger_r(cx, dscript.getFunction(i), debugSource);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/* 2496 */   private static Class<?> codegenClass = Kit.classOrNull("org.mozilla.javascript.optimizer.Codegen");
/*      */   
/* 2498 */   private static Class<?> interpreterClass = Kit.classOrNull("org.mozilla.javascript.Interpreter"); private final ContextFactory factory; private boolean sealed; private Object sealKey; Scriptable topCallScope; boolean isContinuationsTopCall; NativeCall currentActivationCall; XMLLib cachedXMLLib; BaseFunction typeErrorThrower; ObjToIntMap iterating;
/*      */   
/*      */   private Evaluator createCompiler() {
/* 2501 */     Evaluator result = null;
/* 2502 */     if (this.optimizationLevel >= 0 && codegenClass != null) {
/* 2503 */       result = (Evaluator)Kit.newInstanceOrNull(codegenClass);
/*      */     }
/* 2505 */     if (result == null) {
/* 2506 */       result = createInterpreter();
/*      */     }
/* 2508 */     return result;
/*      */   }
/*      */   Object interpreterSecurityDomain; int version; private SecurityController securityController; private boolean hasClassShutter; private ClassShutter classShutter; private ErrorReporter errorReporter; RegExpProxy regExpProxy; private Locale locale; private boolean generatingDebug; private boolean generatingDebugChanged;
/*      */   static Evaluator createInterpreter() {
/* 2512 */     return (Evaluator)Kit.newInstanceOrNull(interpreterClass);
/*      */   }
/*      */   
/*      */   static String getSourcePositionFromStack(int[] linep) {
/* 2516 */     Context cx = getCurrentContext();
/* 2517 */     if (cx == null) return null; 
/* 2518 */     if (cx.lastInterpreterFrame != null) {
/* 2519 */       Evaluator evaluator = createInterpreter();
/* 2520 */       if (evaluator != null) return evaluator.getSourcePositionFromStack(cx, linep);
/*      */     
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2526 */     StackTraceElement[] stackTrace = (new Throwable()).getStackTrace();
/* 2527 */     for (StackTraceElement st : stackTrace) {
/* 2528 */       String file = st.getFileName();
/* 2529 */       if (file != null && !file.endsWith(".java")) {
/* 2530 */         int line = st.getLineNumber();
/* 2531 */         if (line >= 0) {
/* 2532 */           linep[0] = line;
/* 2533 */           return file;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 2538 */     return null;
/*      */   }
/*      */   
/*      */   RegExpProxy getRegExpProxy() {
/* 2542 */     if (this.regExpProxy == null) {
/* 2543 */       Class<?> cl = Kit.classOrNull("org.mozilla.javascript.regexp.RegExpImpl");
/* 2544 */       if (cl != null) {
/* 2545 */         this.regExpProxy = (RegExpProxy)Kit.newInstanceOrNull(cl);
/*      */       }
/*      */     } 
/* 2548 */     return this.regExpProxy;
/*      */   }
/*      */   
/*      */   final boolean isVersionECMA1() {
/* 2552 */     return (this.version == 0 || this.version >= 130);
/*      */   }
/*      */ 
/*      */   
/*      */   SecurityController getSecurityController() {
/* 2557 */     SecurityController global = SecurityController.global();
/* 2558 */     if (global != null) {
/* 2559 */       return global;
/*      */     }
/* 2561 */     return this.securityController;
/*      */   }
/*      */   
/*      */   public final boolean isGeneratingDebugChanged() {
/* 2565 */     return this.generatingDebugChanged;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addActivationName(String name) {
/* 2575 */     if (this.sealed) onSealedMutation(); 
/* 2576 */     if (this.activationNames == null) this.activationNames = new HashSet<>(); 
/* 2577 */     this.activationNames.add(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isActivationNeeded(String name) {
/* 2588 */     return (this.activationNames != null && this.activationNames.contains(name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeActivationName(String name) {
/* 2598 */     if (this.sealed) onSealedMutation(); 
/* 2599 */     if (this.activationNames != null) this.activationNames.remove(name); 
/*      */   }
/*      */   
/*      */   public final boolean isStrictMode() {
/* 2603 */     return (this.isTopLevelStrict || (this.currentActivationCall != null && this.currentActivationCall.isStrict));
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isCurrentContextStrict() {
/* 2608 */     Context cx = getCurrentContext();
/* 2609 */     if (cx == null) {
/* 2610 */       return false;
/*      */     }
/* 2612 */     return cx.isStrictMode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean generatingSource = true;
/*      */ 
/*      */   
/*      */   boolean useDynamicScope;
/*      */ 
/*      */   
/*      */   private int optimizationLevel;
/*      */ 
/*      */   
/*      */   private int maximumInterpreterStackDepth;
/*      */ 
/*      */   
/*      */   private WrapFactory wrapFactory;
/*      */ 
/*      */   
/*      */   Debugger debugger;
/*      */ 
/*      */   
/*      */   private Object debuggerData;
/*      */ 
/*      */   
/*      */   private int enterCount;
/*      */ 
/*      */   
/*      */   private Object propertyListeners;
/*      */ 
/*      */   
/*      */   private Map<Object, Object> threadLocalMap;
/*      */ 
/*      */   
/*      */   private ClassLoader applicationClassLoader;
/*      */ 
/*      */   
/*      */   private UnaryOperator<Object> javaToJSONConverter;
/*      */ 
/*      */   
/* 2654 */   private final ArrayDeque<Runnable> microtasks = new ArrayDeque<>();
/* 2655 */   private final UnhandledRejectionTracker unhandledPromises = new UnhandledRejectionTracker();
/*      */   Set<String> activationNames;
/*      */   Object lastInterpreterFrame;
/*      */   ObjArray previousInterpreterInvocations;
/*      */   int instructionCount;
/*      */   int instructionThreshold;
/*      */   long scratchUint32;
/*      */   Scriptable scratchScriptable;
/*      */   public boolean generateObserverCount = false;
/*      */   boolean isTopLevelStrict;
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */