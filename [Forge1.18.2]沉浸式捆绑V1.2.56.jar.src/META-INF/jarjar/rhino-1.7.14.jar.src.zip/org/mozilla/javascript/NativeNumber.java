/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeNumber
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 3504516769741512101L;
/*     */   public static final double MAX_SAFE_INTEGER = 9.007199254740991E15D;
/*  22 */   private static final Object NUMBER_TAG = "Number"; private static final int MAX_PRECISION = 100; private static final double MIN_SAFE_INTEGER = -9.007199254740991E15D; private static final double EPSILON = 2.220446049250313E-16D; private static final int ConstructorId_isFinite = -1;
/*     */   private static final int ConstructorId_isNaN = -2;
/*     */   private static final int ConstructorId_isInteger = -3;
/*     */   private static final int ConstructorId_isSafeInteger = -4;
/*     */   private static final int Id_constructor = 1;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  29 */     NativeNumber obj = new NativeNumber(0.0D);
/*  30 */     obj.exportAsJSClass(8, scope, sealed);
/*     */   }
/*     */   private static final int Id_toString = 2; private static final int Id_toLocaleString = 3; private static final int Id_toSource = 4; private static final int Id_valueOf = 5; private static final int Id_toFixed = 6; private static final int Id_toExponential = 7; private static final int Id_toPrecision = 8; private static final int MAX_PROTOTYPE_ID = 8; private double doubleValue;
/*     */   NativeNumber(double number) {
/*  34 */     this.doubleValue = number;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  39 */     return "Number";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fillConstructorProperties(IdFunctionObject ctor) {
/*  44 */     int attr = 7;
/*     */ 
/*     */     
/*  47 */     ctor.defineProperty("NaN", ScriptRuntime.NaNobj, 7);
/*  48 */     ctor.defineProperty("POSITIVE_INFINITY", 
/*  49 */         ScriptRuntime.wrapNumber(Double.POSITIVE_INFINITY), 7);
/*  50 */     ctor.defineProperty("NEGATIVE_INFINITY", 
/*  51 */         ScriptRuntime.wrapNumber(Double.NEGATIVE_INFINITY), 7);
/*  52 */     ctor.defineProperty("MAX_VALUE", ScriptRuntime.wrapNumber(Double.MAX_VALUE), 7);
/*  53 */     ctor.defineProperty("MIN_VALUE", ScriptRuntime.wrapNumber(Double.MIN_VALUE), 7);
/*  54 */     ctor.defineProperty("MAX_SAFE_INTEGER", ScriptRuntime.wrapNumber(9.007199254740991E15D), 7);
/*  55 */     ctor.defineProperty("MIN_SAFE_INTEGER", ScriptRuntime.wrapNumber(-9.007199254740991E15D), 7);
/*  56 */     ctor.defineProperty("EPSILON", ScriptRuntime.wrapNumber(2.220446049250313E-16D), 7);
/*     */     
/*  58 */     addIdFunctionProperty(ctor, NUMBER_TAG, -1, "isFinite", 1);
/*  59 */     addIdFunctionProperty(ctor, NUMBER_TAG, -2, "isNaN", 1);
/*  60 */     addIdFunctionProperty(ctor, NUMBER_TAG, -3, "isInteger", 1);
/*  61 */     addIdFunctionProperty(ctor, NUMBER_TAG, -4, "isSafeInteger", 1);
/*  62 */     Object parseFloat = ScriptRuntime.getTopLevelProp(ctor, "parseFloat");
/*  63 */     if (parseFloat instanceof IdFunctionObject) {
/*  64 */       ((IdFunctionObject)parseFloat).addAsProperty(ctor);
/*     */     }
/*  66 */     Object parseInt = ScriptRuntime.getTopLevelProp(ctor, "parseInt");
/*  67 */     if (parseInt instanceof IdFunctionObject) {
/*  68 */       ((IdFunctionObject)parseInt).addAsProperty(ctor);
/*     */     }
/*     */     
/*  71 */     super.fillConstructorProperties(ctor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/*  78 */     switch (id) {
/*     */       case 1:
/*  80 */         arity = 1;
/*  81 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/*  84 */         arity = 1;
/*  85 */         s = "toString";
/*     */         break;
/*     */       case 3:
/*  88 */         arity = 1;
/*  89 */         s = "toLocaleString";
/*     */         break;
/*     */       case 4:
/*  92 */         arity = 0;
/*  93 */         s = "toSource";
/*     */         break;
/*     */       case 5:
/*  96 */         arity = 0;
/*  97 */         s = "valueOf";
/*     */         break;
/*     */       case 6:
/* 100 */         arity = 1;
/* 101 */         s = "toFixed";
/*     */         break;
/*     */       case 7:
/* 104 */         arity = 1;
/* 105 */         s = "toExponential";
/*     */         break;
/*     */       case 8:
/* 108 */         arity = 1;
/* 109 */         s = "toPrecision";
/*     */         break;
/*     */       default:
/* 112 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 114 */     initPrototypeMethod(NUMBER_TAG, id, s, arity);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     int base, precisionMin;
/* 120 */     if (!f.hasTag(NUMBER_TAG)) {
/* 121 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/* 123 */     int id = f.methodId();
/* 124 */     if (id == 1) {
/* 125 */       double val = (args.length >= 1) ? ScriptRuntime.toNumeric(args[0]).doubleValue() : 0.0D;
/* 126 */       if (thisObj == null)
/*     */       {
/* 128 */         return new NativeNumber(val);
/*     */       }
/*     */       
/* 131 */       return ScriptRuntime.wrapNumber(val);
/*     */     } 
/* 133 */     if (id < 1) {
/* 134 */       return execConstructorCall(id, args);
/*     */     }
/*     */ 
/*     */     
/* 138 */     double value = ((NativeNumber)ensureType(thisObj, (Class)NativeNumber.class, f)).doubleValue;
/*     */     
/* 140 */     switch (id) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 3:
/* 148 */         base = (args.length == 0 || Undefined.isUndefined(args[0])) ? 10 : ScriptRuntime.toInt32(args[0]);
/* 149 */         return ScriptRuntime.numberToString(value, base);
/*     */ 
/*     */       
/*     */       case 4:
/* 153 */         return "(new Number(" + ScriptRuntime.toString(value) + "))";
/*     */       
/*     */       case 5:
/* 156 */         return ScriptRuntime.wrapNumber(value);
/*     */       
/*     */       case 6:
/* 159 */         precisionMin = (cx.version < 200) ? -20 : 0;
/* 160 */         return num_to(value, args, 2, 2, precisionMin, 0);
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 165 */         if (Double.isNaN(value)) {
/* 166 */           return "NaN";
/*     */         }
/* 168 */         if (Double.isInfinite(value)) {
/* 169 */           if (value >= 0.0D) {
/* 170 */             return "Infinity";
/*     */           }
/* 172 */           return "-Infinity";
/*     */         } 
/*     */         
/* 175 */         return num_to(value, args, 1, 3, 0, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 187 */         if (args.length == 0 || Undefined.isUndefined(args[0])) {
/* 188 */           return ScriptRuntime.numberToString(value, 10);
/*     */         }
/*     */         
/* 191 */         if (Double.isNaN(value)) {
/* 192 */           return "NaN";
/*     */         }
/* 194 */         if (Double.isInfinite(value)) {
/* 195 */           if (value >= 0.0D) {
/* 196 */             return "Infinity";
/*     */           }
/* 198 */           return "-Infinity";
/*     */         } 
/* 200 */         return num_to(value, args, 0, 4, 1, 0);
/*     */     } 
/*     */ 
/*     */     
/* 204 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object execConstructorCall(int id, Object[] args) {
/* 209 */     switch (id) {
/*     */       case -1:
/* 211 */         if (args.length == 0 || Undefined.isUndefined(args[0])) {
/* 212 */           return Boolean.FALSE;
/*     */         }
/* 214 */         if (args[0] instanceof Number)
/*     */         {
/* 216 */           return isFinite(args[0]);
/*     */         }
/* 218 */         return Boolean.FALSE;
/*     */       
/*     */       case -2:
/* 221 */         if (args.length == 0 || Undefined.isUndefined(args[0])) {
/* 222 */           return Boolean.FALSE;
/*     */         }
/* 224 */         if (args[0] instanceof Number) {
/* 225 */           return isNaN((Number)args[0]);
/*     */         }
/* 227 */         return Boolean.FALSE;
/*     */       
/*     */       case -3:
/* 230 */         if (args.length == 0 || Undefined.isUndefined(args[0])) {
/* 231 */           return Boolean.FALSE;
/*     */         }
/* 233 */         if (args[0] instanceof Number) {
/* 234 */           return Boolean.valueOf(isInteger((Number)args[0]));
/*     */         }
/* 236 */         return Boolean.FALSE;
/*     */       
/*     */       case -4:
/* 239 */         if (args.length == 0 || Undefined.instance == args[0]) {
/* 240 */           return Boolean.FALSE;
/*     */         }
/* 242 */         if (args[0] instanceof Number) {
/* 243 */           return Boolean.valueOf(isSafeInteger((Number)args[0]));
/*     */         }
/* 245 */         return Boolean.FALSE;
/*     */     } 
/*     */     
/* 248 */     throw new IllegalArgumentException(String.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 254 */     return ScriptRuntime.numberToString(this.doubleValue, 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String num_to(double val, Object[] args, int zeroArgMode, int oneArgMode, int precisionMin, int precisionOffset) {
/*     */     int precision;
/* 265 */     if (args.length == 0) {
/* 266 */       precision = 0;
/* 267 */       oneArgMode = zeroArgMode;
/*     */     }
/*     */     else {
/*     */       
/* 271 */       double p = ScriptRuntime.toInteger(args[0]);
/* 272 */       if (p < precisionMin || p > 100.0D) {
/*     */         
/* 274 */         String msg = ScriptRuntime.getMessageById("msg.bad.precision", new Object[] {
/* 275 */               ScriptRuntime.toString(args[0]) });
/* 276 */         throw ScriptRuntime.rangeError(msg);
/*     */       } 
/* 278 */       precision = ScriptRuntime.toInt32(p);
/*     */     } 
/* 280 */     StringBuilder sb = new StringBuilder();
/* 281 */     DToA.JS_dtostr(sb, oneArgMode, precision + precisionOffset, val);
/* 282 */     return sb.toString();
/*     */   }
/*     */   
/*     */   static Object isFinite(Object val) {
/* 286 */     double d = ScriptRuntime.toNumber(val);
/* 287 */     Double nd = Double.valueOf(d);
/* 288 */     return ScriptRuntime.wrapBoolean((!nd.isInfinite() && !nd.isNaN()));
/*     */   }
/*     */   
/*     */   private static Boolean isNaN(Number val) {
/* 292 */     if (val instanceof Double) {
/* 293 */       return Boolean.valueOf(((Double)val).isNaN());
/*     */     }
/*     */     
/* 296 */     double d = val.doubleValue();
/* 297 */     return Boolean.valueOf(Double.isNaN(d));
/*     */   }
/*     */   
/*     */   private static boolean isInteger(Number val) {
/* 301 */     if (val instanceof Double) {
/* 302 */       return isDoubleInteger((Double)val);
/*     */     }
/* 304 */     return isDoubleInteger(val.doubleValue());
/*     */   }
/*     */   
/*     */   private static boolean isDoubleInteger(Double d) {
/* 308 */     return (!d.isInfinite() && !d.isNaN() && Math.floor(d.doubleValue()) == d.doubleValue());
/*     */   }
/*     */   
/*     */   private static boolean isDoubleInteger(double d) {
/* 312 */     return (!Double.isInfinite(d) && !Double.isNaN(d) && Math.floor(d) == d);
/*     */   }
/*     */   
/*     */   private static boolean isSafeInteger(Number val) {
/* 316 */     if (val instanceof Double) {
/* 317 */       return isDoubleSafeInteger((Double)val);
/*     */     }
/* 319 */     return isDoubleSafeInteger(val.doubleValue());
/*     */   }
/*     */   
/*     */   private static boolean isDoubleSafeInteger(Double d) {
/* 323 */     return (isDoubleInteger(d) && d
/* 324 */       .doubleValue() <= 9.007199254740991E15D && d
/* 325 */       .doubleValue() >= -9.007199254740991E15D);
/*     */   }
/*     */   
/*     */   private static boolean isDoubleSafeInteger(double d) {
/* 329 */     return (isDoubleInteger(d) && d <= 9.007199254740991E15D && d >= -9.007199254740991E15D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 335 */     switch (s)
/*     */     { case "constructor":
/* 337 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 364 */         return id;case "toString": id = 2; return id;case "toLocaleString": id = 3; return id;case "toSource": id = 4; return id;case "valueOf": id = 5; return id;case "toFixed": id = 6; return id;case "toExponential": id = 7; return id;case "toPrecision": id = 8; return id; }  int id = 0; return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */