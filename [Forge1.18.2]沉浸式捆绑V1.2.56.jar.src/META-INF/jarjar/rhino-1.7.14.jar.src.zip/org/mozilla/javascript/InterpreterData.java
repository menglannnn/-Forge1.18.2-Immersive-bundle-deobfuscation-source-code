/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Arrays;
/*     */ import org.mozilla.javascript.debug.DebuggableScript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InterpreterData
/*     */   implements Serializable, DebuggableScript
/*     */ {
/*     */   private static final long serialVersionUID = 5067677351589230234L;
/*     */   static final int INITIAL_MAX_ICODE_LENGTH = 1024;
/*     */   static final int INITIAL_STRINGTABLE_SIZE = 64;
/*     */   static final int INITIAL_NUMBERTABLE_SIZE = 64;
/*     */   static final int INITIAL_BIGINTTABLE_SIZE = 64;
/*     */   String itsName;
/*     */   String itsSourceFile;
/*     */   boolean itsNeedsActivation;
/*     */   int itsFunctionType;
/*     */   String[] itsStringTable;
/*     */   double[] itsDoubleTable;
/*     */   BigInteger[] itsBigIntTable;
/*     */   InterpreterData[] itsNestedFunctions;
/*     */   Object[] itsRegExpLiterals;
/*     */   Object[] itsTemplateLiterals;
/*     */   byte[] itsICode;
/*     */   int[] itsExceptionTable;
/*     */   int itsMaxVars;
/*     */   int itsMaxLocals;
/*     */   int itsMaxStack;
/*     */   int itsMaxFrameArray;
/*     */   String[] argNames;
/*     */   boolean[] argIsConst;
/*     */   int argCount;
/*     */   int itsMaxCalleeArgs;
/*     */   String encodedSource;
/*     */   int encodedSourceStart;
/*     */   int encodedSourceEnd;
/*     */   int languageVersion;
/*     */   boolean isStrict;
/*     */   boolean topLevel;
/*     */   boolean isES6Generator;
/*     */   Object[] literalIds;
/*     */   UintMap longJumps;
/*     */   int firstLinePC;
/*     */   InterpreterData parentData;
/*     */   boolean evalScriptFlag;
/*     */   private int icodeHashCode;
/*     */   boolean declaredAsVar;
/*     */   boolean declaredAsFunctionExpression;
/*     */   
/*     */   InterpreterData(int languageVersion, String sourceFile, String encodedSource, boolean isStrict) {
/*  88 */     this.firstLinePC = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     this.icodeHashCode = 0; this.languageVersion = languageVersion; this.itsSourceFile = sourceFile; this.encodedSource = encodedSource; this.isStrict = isStrict; init(); } InterpreterData(InterpreterData parent) { this.firstLinePC = -1; this.icodeHashCode = 0;
/*     */     this.parentData = parent;
/*     */     this.languageVersion = parent.languageVersion;
/*     */     this.itsSourceFile = parent.itsSourceFile;
/*     */     this.encodedSource = parent.encodedSource;
/*     */     this.isStrict = parent.isStrict;
/*     */     init(); }
/*     */   private void init() { this.itsICode = new byte[1024];
/*     */     this.itsStringTable = new String[64];
/*     */     this.itsBigIntTable = new BigInteger[64]; } public boolean isTopLevel() {
/* 104 */     return this.topLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFunction() {
/* 109 */     return (this.itsFunctionType != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFunctionName() {
/* 114 */     return this.itsName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getParamCount() {
/* 119 */     return this.argCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getParamAndVarCount() {
/* 124 */     return this.argNames.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getParamOrVarName(int index) {
/* 129 */     return this.argNames[index];
/*     */   }
/*     */   
/*     */   public boolean getParamOrVarConst(int index) {
/* 133 */     return this.argIsConst[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/* 138 */     return this.itsSourceFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGeneratedScript() {
/* 143 */     return ScriptRuntime.isGeneratedScript(this.itsSourceFile);
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getLineNumbers() {
/* 148 */     return Interpreter.getLineNumbers(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFunctionCount() {
/* 153 */     return (this.itsNestedFunctions == null) ? 0 : this.itsNestedFunctions.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public DebuggableScript getFunction(int index) {
/* 158 */     return this.itsNestedFunctions[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public DebuggableScript getParent() {
/* 163 */     return this.parentData;
/*     */   }
/*     */   
/*     */   public int icodeHashCode() {
/* 167 */     int h = this.icodeHashCode;
/* 168 */     if (h == 0) {
/* 169 */       this.icodeHashCode = h = Arrays.hashCode(this.itsICode);
/*     */     }
/* 171 */     return h;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\InterpreterData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */