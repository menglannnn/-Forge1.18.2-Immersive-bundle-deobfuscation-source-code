/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeWeakMap
/*     */   extends IdScriptableObject
/*     */ {
/*     */   private static final long serialVersionUID = 8670434366883930453L;
/*  24 */   private static final Object MAP_TAG = "WeakMap";
/*     */   
/*     */   private boolean instanceOfWeakMap = false;
/*     */   
/*  28 */   private transient WeakHashMap<Scriptable, Object> map = new WeakHashMap<>();
/*     */   
/*  30 */   private static final Object NULL_VALUE = new Object(); private static final int Id_constructor = 1; private static final int Id_delete = 2; private static final int Id_get = 3;
/*     */   
/*     */   static void init(Scriptable scope, boolean sealed) {
/*  33 */     NativeWeakMap m = new NativeWeakMap();
/*  34 */     m.exportAsJSClass(6, scope, sealed);
/*     */   }
/*     */   private static final int Id_has = 4; private static final int Id_set = 5; private static final int SymbolId_toStringTag = 6; private static final int MAX_PROTOTYPE_ID = 6;
/*     */   
/*     */   public String getClassName() {
/*  39 */     return "WeakMap";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*  46 */     if (!f.hasTag(MAP_TAG)) {
/*  47 */       return super.execIdCall(f, cx, scope, thisObj, args);
/*     */     }
/*  49 */     int id = f.methodId();
/*  50 */     switch (id) {
/*     */       case 1:
/*  52 */         if (thisObj == null) {
/*  53 */           NativeWeakMap nm = new NativeWeakMap();
/*  54 */           nm.instanceOfWeakMap = true;
/*  55 */           if (args.length > 0) {
/*  56 */             NativeMap.loadFromIterable(cx, scope, nm, NativeMap.key(args));
/*     */           }
/*  58 */           return nm;
/*     */         } 
/*  60 */         throw ScriptRuntime.typeErrorById("msg.no.new", new Object[] { "WeakMap" });
/*     */       case 2:
/*  62 */         return realThis(thisObj, f).js_delete(NativeMap.key(args));
/*     */       case 3:
/*  64 */         return realThis(thisObj, f).js_get(NativeMap.key(args));
/*     */       case 4:
/*  66 */         return realThis(thisObj, f).js_has(NativeMap.key(args));
/*     */       case 5:
/*  68 */         return realThis(thisObj, f)
/*  69 */           .js_set(
/*  70 */             NativeMap.key(args), (args.length > 1) ? args[1] : Undefined.instance);
/*     */     } 
/*     */     
/*  73 */     throw new IllegalArgumentException("WeakMap.prototype has no method: " + f
/*  74 */         .getFunctionName());
/*     */   }
/*     */   
/*     */   private Object js_delete(Object key) {
/*  78 */     if (!ScriptRuntime.isObject(key)) {
/*  79 */       return Boolean.FALSE;
/*     */     }
/*  81 */     return Boolean.valueOf((this.map.remove(key) != null));
/*     */   }
/*     */   
/*     */   private Object js_get(Object key) {
/*  85 */     if (!ScriptRuntime.isObject(key)) {
/*  86 */       return Undefined.instance;
/*     */     }
/*  88 */     Object result = this.map.get(key);
/*  89 */     if (result == null)
/*  90 */       return Undefined.instance; 
/*  91 */     if (result == NULL_VALUE) {
/*  92 */       return null;
/*     */     }
/*  94 */     return result;
/*     */   }
/*     */   
/*     */   private Object js_has(Object key) {
/*  98 */     if (!ScriptRuntime.isObject(key)) {
/*  99 */       return Boolean.FALSE;
/*     */     }
/* 101 */     return Boolean.valueOf(this.map.containsKey(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object js_set(Object key, Object v) {
/* 109 */     if (!ScriptRuntime.isObject(key)) {
/* 110 */       throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] { ScriptRuntime.typeof(key) });
/*     */     }
/*     */ 
/*     */     
/* 114 */     Object value = (v == null) ? NULL_VALUE : v;
/* 115 */     this.map.put((Scriptable)key, value);
/* 116 */     return this;
/*     */   }
/*     */   
/*     */   private static NativeWeakMap realThis(Scriptable thisObj, IdFunctionObject f) {
/* 120 */     NativeWeakMap nm = ensureType(thisObj, NativeWeakMap.class, f);
/* 121 */     if (!nm.instanceOfWeakMap)
/*     */     {
/* 123 */       throw ScriptRuntime.typeErrorById("msg.incompat.call", new Object[] { f.getFunctionName() });
/*     */     }
/*     */     
/* 126 */     return nm;
/*     */   }
/*     */   protected void initPrototypeId(int id) {
/*     */     String s;
/*     */     int arity;
/* 131 */     if (id == 6) {
/* 132 */       initPrototypeValue(6, SymbolKey.TO_STRING_TAG, 
/*     */ 
/*     */           
/* 135 */           getClassName(), 3);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 140 */     String fnName = null;
/*     */     
/* 142 */     switch (id) {
/*     */       case 1:
/* 144 */         arity = 0;
/* 145 */         s = "constructor";
/*     */         break;
/*     */       case 2:
/* 148 */         arity = 1;
/* 149 */         s = "delete";
/*     */         break;
/*     */       case 3:
/* 152 */         arity = 1;
/* 153 */         s = "get";
/*     */         break;
/*     */       case 4:
/* 156 */         arity = 1;
/* 157 */         s = "has";
/*     */         break;
/*     */       case 5:
/* 160 */         arity = 2;
/* 161 */         s = "set";
/*     */         break;
/*     */       default:
/* 164 */         throw new IllegalArgumentException(String.valueOf(id));
/*     */     } 
/* 166 */     initPrototypeMethod(MAP_TAG, id, s, fnName, arity);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(Symbol k) {
/* 171 */     if (SymbolKey.TO_STRING_TAG.equals(k)) {
/* 172 */       return 6;
/*     */     }
/* 174 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int findPrototypeId(String s) {
/* 180 */     switch (s)
/*     */     { case "constructor":
/* 182 */         id = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 200 */         return id;case "delete": id = 2; return id;case "get": id = 3; return id;case "has": id = 4; return id;case "set": id = 5; return id; }  int id = 0; return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 212 */     stream.defaultReadObject();
/* 213 */     this.map = new WeakHashMap<>();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativeWeakMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */