/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MemberBox
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6358550398665688245L;
/*     */   private transient Member memberObject;
/*     */   transient Class<?>[] argTypes;
/*     */   transient boolean vararg;
/*     */   transient Function asGetterFunction;
/*     */   transient Function asSetterFunction;
/*     */   transient Object delegateTo;
/*     */   
/*     */   MemberBox(Method method) {
/*  37 */     init(method);
/*     */   }
/*     */   
/*     */   MemberBox(Constructor<?> constructor) {
/*  41 */     init(constructor);
/*     */   }
/*     */   
/*     */   private void init(Method method) {
/*  45 */     this.memberObject = method;
/*  46 */     this.argTypes = method.getParameterTypes();
/*  47 */     this.vararg = method.isVarArgs();
/*     */   }
/*     */   
/*     */   private void init(Constructor<?> constructor) {
/*  51 */     this.memberObject = constructor;
/*  52 */     this.argTypes = constructor.getParameterTypes();
/*  53 */     this.vararg = constructor.isVarArgs();
/*     */   }
/*     */   
/*     */   Method method() {
/*  57 */     return (Method)this.memberObject;
/*     */   }
/*     */   
/*     */   Constructor<?> ctor() {
/*  61 */     return (Constructor)this.memberObject;
/*     */   }
/*     */   
/*     */   Member member() {
/*  65 */     return this.memberObject;
/*     */   }
/*     */   
/*     */   boolean isMethod() {
/*  69 */     return this.memberObject instanceof Method;
/*     */   }
/*     */   
/*     */   boolean isCtor() {
/*  73 */     return this.memberObject instanceof Constructor;
/*     */   }
/*     */   
/*     */   boolean isStatic() {
/*  77 */     return Modifier.isStatic(this.memberObject.getModifiers());
/*     */   }
/*     */   
/*     */   boolean isPublic() {
/*  81 */     return Modifier.isPublic(this.memberObject.getModifiers());
/*     */   }
/*     */   
/*     */   String getName() {
/*  85 */     return this.memberObject.getName();
/*     */   }
/*     */   
/*     */   Class<?> getDeclaringClass() {
/*  89 */     return this.memberObject.getDeclaringClass();
/*     */   }
/*     */   
/*     */   String toJavaDeclaration() {
/*  93 */     StringBuilder sb = new StringBuilder();
/*  94 */     if (isMethod()) {
/*  95 */       Method method = method();
/*  96 */       sb.append(method.getReturnType());
/*  97 */       sb.append(' ');
/*  98 */       sb.append(method.getName());
/*     */     } else {
/* 100 */       Constructor<?> ctor = ctor();
/* 101 */       String name = ctor.getDeclaringClass().getName();
/* 102 */       int lastDot = name.lastIndexOf('.');
/* 103 */       if (lastDot >= 0) {
/* 104 */         name = name.substring(lastDot + 1);
/*     */       }
/* 106 */       sb.append(name);
/*     */     } 
/* 108 */     sb.append(JavaMembers.liveConnectSignature(this.argTypes));
/* 109 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return this.memberObject.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Function asGetterFunction(final String name, Scriptable scope) {
/* 122 */     if (this.asGetterFunction == null) {
/* 123 */       this
/* 124 */         .asGetterFunction = new BaseFunction(scope, ScriptableObject.getFunctionPrototype(scope))
/*     */         {
/*     */           public Object call(Context cx, Scriptable callScope, Scriptable thisObj, Object[] originalArgs)
/*     */           {
/*     */             Object getterThis, args[];
/*     */ 
/*     */             
/* 131 */             MemberBox nativeGetter = MemberBox.this;
/*     */ 
/*     */             
/* 134 */             if (nativeGetter.delegateTo == null) {
/* 135 */               getterThis = thisObj;
/* 136 */               args = ScriptRuntime.emptyArgs;
/*     */             } else {
/* 138 */               getterThis = nativeGetter.delegateTo;
/* 139 */               args = new Object[] { thisObj };
/*     */             } 
/* 141 */             return nativeGetter.invoke(getterThis, args);
/*     */           }
/*     */ 
/*     */           
/*     */           public String getFunctionName() {
/* 146 */             return name;
/*     */           }
/*     */         };
/*     */     }
/* 150 */     return this.asGetterFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Function asSetterFunction(final String name, Scriptable scope) {
/* 158 */     if (this.asSetterFunction == null) {
/* 159 */       this
/* 160 */         .asSetterFunction = new BaseFunction(scope, ScriptableObject.getFunctionPrototype(scope))
/*     */         {
/*     */           public Object call(Context cx, Scriptable callScope, Scriptable thisObj, Object[] originalArgs)
/*     */           {
/*     */             Object setterThis, args[];
/*     */ 
/*     */             
/* 167 */             MemberBox nativeSetter = MemberBox.this;
/*     */ 
/*     */             
/* 170 */             Object value = (originalArgs.length > 0) ? originalArgs[0] : Undefined.instance;
/*     */             
/* 172 */             if (nativeSetter.delegateTo == null) {
/* 173 */               setterThis = thisObj;
/* 174 */               args = new Object[] { value };
/*     */             } else {
/* 176 */               setterThis = nativeSetter.delegateTo;
/* 177 */               args = new Object[] { thisObj, value };
/*     */             } 
/* 179 */             return nativeSetter.invoke(setterThis, args);
/*     */           }
/*     */ 
/*     */           
/*     */           public String getFunctionName() {
/* 184 */             return name;
/*     */           }
/*     */         };
/*     */     }
/* 188 */     return this.asSetterFunction;
/*     */   }
/*     */   
/*     */   Object invoke(Object target, Object[] args) {
/* 192 */     Method method = method();
/*     */ 
/*     */     
/* 195 */     if (target instanceof Delegator) {
/* 196 */       target = ((Delegator)target).getDelegee();
/*     */     }
/* 198 */     for (int i = 0; i < args.length; i++) {
/* 199 */       if (args[i] instanceof Delegator) {
/* 200 */         args[i] = ((Delegator)args[i]).getDelegee();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 206 */       return method.invoke(target, args);
/* 207 */     } catch (IllegalAccessException ex) {
/* 208 */       Method accessible = searchAccessibleMethod(method, this.argTypes);
/* 209 */       if (accessible != null) {
/* 210 */         this.memberObject = accessible;
/* 211 */         method = accessible;
/*     */       }
/* 213 */       else if (!VMBridge.instance.tryToMakeAccessible(method)) {
/* 214 */         throw Context.throwAsScriptRuntimeEx(ex);
/*     */       } 
/*     */ 
/*     */       
/* 218 */       return method.invoke(target, args);
/*     */     }
/* 220 */     catch (InvocationTargetException ite) {
/*     */       
/* 222 */       Throwable e = ite;
/*     */       while (true)
/* 224 */       { e = ((InvocationTargetException)e).getTargetException();
/* 225 */         if (!(e instanceof InvocationTargetException))
/* 226 */         { if (e instanceof ContinuationPending) throw (ContinuationPending)e; 
/* 227 */           throw Context.throwAsScriptRuntimeEx(e); }  } 
/* 228 */     } catch (Exception ex) {
/* 229 */       throw Context.throwAsScriptRuntimeEx(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   Object newInstance(Object[] args) {
/* 234 */     Constructor<?> ctor = ctor();
/*     */     
/*     */     try {
/* 237 */       return ctor.newInstance(args);
/* 238 */     } catch (IllegalAccessException ex) {
/* 239 */       if (!VMBridge.instance.tryToMakeAccessible(ctor)) {
/* 240 */         throw Context.throwAsScriptRuntimeEx(ex);
/*     */       }
/*     */       
/* 243 */       return ctor.newInstance(args);
/* 244 */     } catch (Exception ex) {
/* 245 */       throw Context.throwAsScriptRuntimeEx(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Method searchAccessibleMethod(Method method, Class<?>[] params) {
/* 250 */     int modifiers = method.getModifiers();
/* 251 */     if (Modifier.isPublic(modifiers) && !Modifier.isStatic(modifiers)) {
/* 252 */       Class<?> c = method.getDeclaringClass();
/* 253 */       if (!Modifier.isPublic(c.getModifiers())) {
/* 254 */         String name = method.getName();
/* 255 */         Class<?>[] intfs = c.getInterfaces();
/* 256 */         for (int i = 0, N = intfs.length; i != N; i++) {
/* 257 */           Class<?> intf = intfs[i];
/* 258 */           if (Modifier.isPublic(intf.getModifiers())) {
/*     */             
/* 260 */             try { return intf.getMethod(name, params); }
/* 261 */             catch (NoSuchMethodException noSuchMethodException) {  }
/* 262 */             catch (SecurityException securityException) {}
/*     */           }
/*     */         } 
/*     */         
/*     */         while (true) {
/* 267 */           c = c.getSuperclass();
/* 268 */           if (c == null) {
/*     */             break;
/*     */           }
/* 271 */           if (Modifier.isPublic(c.getModifiers())) {
/*     */             
/* 273 */             try { Method m = c.getMethod(name, params);
/* 274 */               int mModifiers = m.getModifiers();
/* 275 */               if (Modifier.isPublic(mModifiers) && !Modifier.isStatic(mModifiers)) {
/* 276 */                 return m;
/*     */               } }
/* 278 */             catch (NoSuchMethodException noSuchMethodException) {  }
/* 279 */             catch (SecurityException securityException) {}
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 285 */     return null;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 289 */     in.defaultReadObject();
/* 290 */     Member member = readMember(in);
/* 291 */     if (member instanceof Method) {
/* 292 */       init((Method)member);
/*     */     } else {
/* 294 */       init((Constructor)member);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 299 */     out.defaultWriteObject();
/* 300 */     writeMember(out, this.memberObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void writeMember(ObjectOutputStream out, Member member) throws IOException {
/* 310 */     if (member == null) {
/* 311 */       out.writeBoolean(false);
/*     */       return;
/*     */     } 
/* 314 */     out.writeBoolean(true);
/* 315 */     if (!(member instanceof Method) && !(member instanceof Constructor))
/* 316 */       throw new IllegalArgumentException("not Method or Constructor"); 
/* 317 */     out.writeBoolean(member instanceof Method);
/* 318 */     out.writeObject(member.getName());
/* 319 */     out.writeObject(member.getDeclaringClass());
/* 320 */     if (member instanceof Method) {
/* 321 */       writeParameters(out, ((Method)member).getParameterTypes());
/*     */     } else {
/* 323 */       writeParameters(out, ((Constructor)member).getParameterTypes());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Member readMember(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 330 */     if (!in.readBoolean()) return null; 
/* 331 */     boolean isMethod = in.readBoolean();
/* 332 */     String name = (String)in.readObject();
/* 333 */     Class<?> declaring = (Class)in.readObject();
/* 334 */     Class<?>[] parms = readParameters(in);
/*     */     try {
/* 336 */       if (isMethod) {
/* 337 */         return declaring.getMethod(name, parms);
/*     */       }
/* 339 */       return declaring.getConstructor(parms);
/* 340 */     } catch (NoSuchMethodException e) {
/* 341 */       throw new IOException("Cannot find member: " + e);
/*     */     } 
/*     */   }
/*     */   
/* 345 */   private static final Class<?>[] primitives = new Class[] { boolean.class, byte.class, char.class, double.class, float.class, int.class, long.class, short.class, void.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void writeParameters(ObjectOutputStream out, Class<?>[] parms) throws IOException {
/* 365 */     out.writeShort(parms.length);
/*     */     
/* 367 */     for (int i = 0; i < parms.length; i++) {
/* 368 */       Class<?> parm = parms[i];
/* 369 */       boolean primitive = parm.isPrimitive();
/* 370 */       out.writeBoolean(primitive);
/* 371 */       if (!primitive) {
/* 372 */         out.writeObject(parm);
/*     */       } else {
/*     */         
/* 375 */         int j = 0; while (true) { if (j < primitives.length) {
/* 376 */             if (parm.equals(primitives[j])) {
/* 377 */               out.writeByte(j); break;
/*     */             }  j++;
/*     */             continue;
/*     */           } 
/* 381 */           throw new IllegalArgumentException("Primitive " + parm + " not found"); }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Class<?>[] readParameters(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 388 */     Class<?>[] result = new Class[in.readShort()];
/* 389 */     for (int i = 0; i < result.length; i++) {
/* 390 */       if (!in.readBoolean()) {
/* 391 */         result[i] = (Class)in.readObject();
/*     */       } else {
/*     */         
/* 394 */         result[i] = primitives[in.readByte()];
/*     */       } 
/* 396 */     }  return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\MemberBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */