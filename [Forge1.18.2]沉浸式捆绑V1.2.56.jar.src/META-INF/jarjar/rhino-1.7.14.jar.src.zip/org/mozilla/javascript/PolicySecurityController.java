/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.security.AccessController;
/*     */ import java.security.CodeSource;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.SecureClassLoader;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.mozilla.classfile.ClassFileWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PolicySecurityController
/*     */   extends SecurityController
/*     */ {
/*  35 */   private static final byte[] secureCallerImplBytecode = loadBytecode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   private static final Map<CodeSource, Map<ClassLoader, SoftReference<SecureCaller>>> callers = new WeakHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getStaticSecurityDomainClassInternal() {
/*  47 */     return CodeSource.class;
/*     */   }
/*     */   
/*     */   private static class Loader
/*     */     extends SecureClassLoader
/*     */     implements GeneratedClassLoader
/*     */   {
/*     */     private final CodeSource codeSource;
/*     */     
/*     */     Loader(ClassLoader parent, CodeSource codeSource) {
/*  57 */       super(parent);
/*  58 */       this.codeSource = codeSource;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<?> defineClass(String name, byte[] data) {
/*  64 */       return defineClass(name, data, 0, data.length, this.codeSource);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void linkClass(Class<?> cl) {
/*  70 */       resolveClass(cl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneratedClassLoader createClassLoader(final ClassLoader parent, final Object securityDomain) {
/*  78 */     return AccessController.<Loader>doPrivileged(new PrivilegedAction()
/*     */         {
/*     */ 
/*     */           
/*     */           public Object run()
/*     */           {
/*  84 */             return new PolicySecurityController.Loader(parent, (CodeSource)securityDomain);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDynamicSecurityDomain(Object securityDomain) {
/*  94 */     return securityDomain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object callWithDomain(Object securityDomain, final Context cx, Callable callable, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     Map<ClassLoader, SoftReference<SecureCaller>> classLoaderMap;
/*     */     SecureCaller caller;
/* 104 */     final ClassLoader classLoader = AccessController.<ClassLoader>doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           public Object run()
/*     */           {
/* 108 */             return cx.getApplicationClassLoader();
/*     */           }
/*     */         });
/* 111 */     final CodeSource codeSource = (CodeSource)securityDomain;
/*     */     
/* 113 */     synchronized (callers) {
/* 114 */       classLoaderMap = callers.get(codeSource);
/* 115 */       if (classLoaderMap == null) {
/* 116 */         classLoaderMap = new WeakHashMap<>();
/* 117 */         callers.put(codeSource, classLoaderMap);
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     synchronized (classLoaderMap) {
/* 122 */       SoftReference<SecureCaller> ref = classLoaderMap.get(classLoader);
/* 123 */       if (ref != null) {
/* 124 */         caller = ref.get();
/*     */       } else {
/* 126 */         caller = null;
/*     */       } 
/* 128 */       if (caller == null) {
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */           
/* 134 */           caller = AccessController.<SecureCaller>doPrivileged(new PrivilegedExceptionAction()
/*     */               {
/*     */ 
/*     */                 
/*     */                 public Object run() throws Exception
/*     */                 {
/* 140 */                   PolicySecurityController.Loader loader = new PolicySecurityController.Loader(classLoader, codeSource);
/*     */                   
/* 142 */                   Class<?> c = loader.defineClass(PolicySecurityController.SecureCaller.class
/* 143 */                       .getName() + "Impl", PolicySecurityController
/* 144 */                       .secureCallerImplBytecode);
/* 145 */                   return c.newInstance();
/*     */                 }
/*     */               });
/* 148 */           classLoaderMap.put(classLoader, new SoftReference<>(caller));
/*     */         }
/* 150 */         catch (PrivilegedActionException ex) {
/*     */           
/* 152 */           throw new UndeclaredThrowableException(ex.getCause());
/*     */         } 
/*     */       }
/*     */     } 
/* 156 */     return caller.call(callable, cx, scope, thisObj, args);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class SecureCaller
/*     */   {
/*     */     public abstract Object call(Callable param1Callable, Context param1Context, Scriptable param1Scriptable1, Scriptable param1Scriptable2, Object[] param1ArrayOfObject);
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] loadBytecode() {
/* 168 */     String secureCallerClassName = SecureCaller.class.getName();
/* 169 */     ClassFileWriter cfw = new ClassFileWriter(secureCallerClassName + "Impl", secureCallerClassName, "<generated>");
/*     */ 
/*     */     
/* 172 */     cfw.startMethod("<init>", "()V", (short)1);
/* 173 */     cfw.addALoad(0);
/* 174 */     cfw.addInvoke(183, secureCallerClassName, "<init>", "()V");
/*     */     
/* 176 */     cfw.add(177);
/* 177 */     cfw.stopMethod((short)1);
/* 178 */     String callableCallSig = "Lorg/mozilla/javascript/Context;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;[Ljava/lang/Object;)Ljava/lang/Object;";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     cfw.startMethod("call", "(Lorg/mozilla/javascript/Callable;" + callableCallSig, (short)17);
/*     */ 
/*     */ 
/*     */     
/* 188 */     for (int i = 1; i < 6; i++) {
/* 189 */       cfw.addALoad(i);
/*     */     }
/* 191 */     cfw.addInvoke(185, "org/mozilla/javascript/Callable", "call", "(" + callableCallSig);
/*     */ 
/*     */     
/* 194 */     cfw.add(176);
/* 195 */     cfw.stopMethod((short)6);
/* 196 */     return cfw.toByteArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\PolicySecurityController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */