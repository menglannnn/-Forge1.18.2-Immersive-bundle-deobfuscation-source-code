/*      */ package org.mozilla.javascript;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.security.CodeSource;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import org.mozilla.classfile.ClassFileWriter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class JavaAdapter
/*      */   implements IdFunctionCall
/*      */ {
/*      */   static class JavaAdapterSignature
/*      */   {
/*      */     Class<?> superClass;
/*      */     Class<?>[] interfaces;
/*      */     ObjToIntMap names;
/*      */     
/*      */     JavaAdapterSignature(Class<?> superClass, Class<?>[] interfaces, ObjToIntMap names) {
/*   42 */       this.superClass = superClass;
/*   43 */       this.interfaces = interfaces;
/*   44 */       this.names = names;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*   50 */       if (!(obj instanceof JavaAdapterSignature))
/*   51 */         return false; 
/*   52 */       JavaAdapterSignature sig = (JavaAdapterSignature)obj;
/*   53 */       if (this.superClass != sig.superClass)
/*   54 */         return false; 
/*   55 */       if (this.interfaces != sig.interfaces) {
/*   56 */         if (this.interfaces.length != sig.interfaces.length)
/*   57 */           return false; 
/*   58 */         for (int i = 0; i < this.interfaces.length; i++) {
/*   59 */           if (this.interfaces[i] != sig.interfaces[i])
/*   60 */             return false; 
/*      */         } 
/*   62 */       }  if (this.names.size() != sig.names.size())
/*   63 */         return false; 
/*   64 */       ObjToIntMap.Iterator iter = new ObjToIntMap.Iterator(this.names);
/*   65 */       iter.start(); for (; !iter.done(); iter.next()) {
/*   66 */         String name = (String)iter.getKey();
/*   67 */         int arity = iter.getValue();
/*   68 */         if (arity != sig.names.get(name, arity + 1))
/*   69 */           return false; 
/*      */       } 
/*   71 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*   77 */       return this.superClass.hashCode() + Arrays.hashCode((Object[])this.interfaces) ^ this.names.size();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*   83 */     JavaAdapter obj = new JavaAdapter();
/*   84 */     IdFunctionObject ctor = new IdFunctionObject(obj, FTAG, 1, "JavaAdapter", 1, scope);
/*      */     
/*   86 */     ctor.markAsConstructor((Scriptable)null);
/*   87 */     if (sealed) {
/*   88 */       ctor.sealObject();
/*      */     }
/*   90 */     ctor.exportAsScopeProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object execIdCall(IdFunctionObject f, Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*   97 */     if (f.hasTag(FTAG) && 
/*   98 */       f.methodId() == 1) {
/*   99 */       return js_createAdapter(cx, scope, args);
/*      */     }
/*      */     
/*  102 */     throw f.unknown();
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertResult(Object result, Class<?> c) {
/*  107 */     if (result == Undefined.instance && c != ScriptRuntime.ObjectClass && c != ScriptRuntime.StringClass)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  112 */       return null;
/*      */     }
/*  114 */     return Context.jsToJava(result, c);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable createAdapterWrapper(Scriptable obj, Object adapter) {
/*  119 */     Scriptable scope = ScriptableObject.getTopLevelScope(obj);
/*  120 */     NativeJavaObject res = new NativeJavaObject(scope, adapter, null, true);
/*  121 */     res.setPrototype(obj);
/*  122 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getAdapterSelf(Class<?> adapterClass, Object adapter) throws NoSuchFieldException, IllegalAccessException {
/*  128 */     Field self = adapterClass.getDeclaredField("self");
/*  129 */     return self.get(adapter);
/*      */   }
/*      */ 
/*      */   
/*      */   static Object js_createAdapter(Context cx, Scriptable scope, Object[] args) {
/*  134 */     int N = args.length;
/*  135 */     if (N == 0) {
/*  136 */       throw ScriptRuntime.typeErrorById("msg.adapter.zero.args", new Object[0]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int classCount;
/*      */ 
/*      */ 
/*      */     
/*  146 */     for (classCount = 0; classCount < N - 1; classCount++) {
/*  147 */       Object arg = args[classCount];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  152 */       if (arg instanceof NativeObject) {
/*      */         break;
/*      */       }
/*  155 */       if (!(arg instanceof NativeJavaClass))
/*  156 */         throw ScriptRuntime.typeErrorById("msg.not.java.class.arg", new Object[] {
/*  157 */               String.valueOf(classCount), 
/*  158 */               ScriptRuntime.toString(arg)
/*      */             }); 
/*      */     } 
/*  161 */     Class<?> superClass = null;
/*  162 */     Class<?>[] intfs = new Class[classCount];
/*  163 */     int interfaceCount = 0;
/*  164 */     for (int i = 0; i < classCount; i++) {
/*  165 */       Class<?> c = ((NativeJavaClass)args[i]).getClassObject();
/*  166 */       if (!c.isInterface()) {
/*  167 */         if (superClass != null) {
/*  168 */           throw ScriptRuntime.typeErrorById("msg.only.one.super", new Object[] { superClass
/*  169 */                 .getName(), c.getName() });
/*      */         }
/*  171 */         superClass = c;
/*      */       } else {
/*  173 */         intfs[interfaceCount++] = c;
/*      */       } 
/*      */     } 
/*      */     
/*  177 */     if (superClass == null) {
/*  178 */       superClass = ScriptRuntime.ObjectClass;
/*      */     }
/*      */     
/*  181 */     Class<?>[] interfaces = new Class[interfaceCount];
/*  182 */     System.arraycopy(intfs, 0, interfaces, 0, interfaceCount);
/*      */     
/*  184 */     Scriptable obj = ScriptableObject.ensureScriptable(args[classCount]);
/*      */     
/*  186 */     Class<?> adapterClass = getAdapterClass(scope, superClass, interfaces, obj);
/*      */ 
/*      */     
/*  189 */     int argsCount = N - classCount - 1; try {
/*      */       Object adapter;
/*  191 */       if (argsCount > 0) {
/*      */ 
/*      */ 
/*      */         
/*  195 */         Object[] ctorArgs = new Object[argsCount + 2];
/*  196 */         ctorArgs[0] = obj;
/*  197 */         ctorArgs[1] = cx.getFactory();
/*  198 */         System.arraycopy(args, classCount + 1, ctorArgs, 2, argsCount);
/*      */         
/*  200 */         NativeJavaClass classWrapper = new NativeJavaClass(scope, adapterClass, true);
/*      */         
/*  202 */         NativeJavaMethod ctors = classWrapper.members.ctors;
/*  203 */         int index = ctors.findCachedFunction(cx, ctorArgs);
/*  204 */         if (index < 0) {
/*  205 */           String sig = NativeJavaMethod.scriptSignature(args);
/*  206 */           throw Context.reportRuntimeErrorById("msg.no.java.ctor", new Object[] { adapterClass
/*  207 */                 .getName(), sig });
/*      */         } 
/*      */ 
/*      */         
/*  211 */         adapter = NativeJavaClass.constructInternal(ctorArgs, ctors.methods[index]);
/*      */       } else {
/*  213 */         Class<?>[] ctorParms = new Class[] { ScriptRuntime.ScriptableClass, ScriptRuntime.ContextFactoryClass };
/*      */ 
/*      */ 
/*      */         
/*  217 */         Object[] ctorArgs = { obj, cx.getFactory() };
/*  218 */         adapter = adapterClass.getConstructor(ctorParms).newInstance(ctorArgs);
/*      */       } 
/*      */       
/*  221 */       Object self = getAdapterSelf(adapterClass, adapter);
/*      */       
/*  223 */       if (self instanceof Wrapper) {
/*  224 */         Object unwrapped = ((Wrapper)self).unwrap();
/*  225 */         if (unwrapped instanceof Scriptable) {
/*  226 */           if (unwrapped instanceof ScriptableObject) {
/*  227 */             ScriptRuntime.setObjectProtoAndParent((ScriptableObject)unwrapped, scope);
/*      */           }
/*      */           
/*  230 */           return unwrapped;
/*      */         } 
/*      */       } 
/*  233 */       return self;
/*  234 */     } catch (Exception ex) {
/*  235 */       throw Context.throwAsScriptRuntimeEx(ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeAdapterObject(Object javaObject, ObjectOutputStream out) throws IOException {
/*  244 */     Class<?> cl = javaObject.getClass();
/*  245 */     out.writeObject(cl.getSuperclass().getName());
/*      */     
/*  247 */     Class<?>[] interfaces = cl.getInterfaces();
/*  248 */     String[] interfaceNames = new String[interfaces.length];
/*      */     
/*  250 */     for (int i = 0; i < interfaces.length; i++) {
/*  251 */       interfaceNames[i] = interfaces[i].getName();
/*      */     }
/*  253 */     out.writeObject(interfaceNames);
/*      */ 
/*      */     
/*  256 */     try { Object delegee = cl.getField("delegee").get(javaObject);
/*  257 */       out.writeObject(delegee);
/*      */       return; }
/*  259 */     catch (IllegalAccessException illegalAccessException) {  }
/*  260 */     catch (NoSuchFieldException noSuchFieldException) {}
/*      */     
/*  262 */     throw new IOException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object readAdapterObject(Scriptable self, ObjectInputStream in) throws IOException, ClassNotFoundException {
/*      */     ContextFactory factory;
/*  271 */     Context cx = Context.getCurrentContext();
/*  272 */     if (cx != null) {
/*  273 */       factory = cx.getFactory();
/*      */     } else {
/*  275 */       factory = null;
/*      */     } 
/*      */     
/*  278 */     Class<?> superClass = Class.forName((String)in.readObject());
/*      */     
/*  280 */     String[] interfaceNames = (String[])in.readObject();
/*  281 */     Class<?>[] interfaces = new Class[interfaceNames.length];
/*      */     
/*  283 */     for (int i = 0; i < interfaceNames.length; i++) {
/*  284 */       interfaces[i] = Class.forName(interfaceNames[i]);
/*      */     }
/*  286 */     Scriptable delegee = (Scriptable)in.readObject();
/*      */     
/*  288 */     Class<?> adapterClass = getAdapterClass(self, superClass, interfaces, delegee);
/*      */ 
/*      */     
/*  291 */     Class<?>[] ctorParms = new Class[] { ScriptRuntime.ContextFactoryClass, ScriptRuntime.ScriptableClass, ScriptRuntime.ScriptableClass };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  296 */     Object[] ctorArgs = { factory, delegee, self };
/*      */     
/*  298 */     try { return adapterClass.getConstructor(ctorParms).newInstance(ctorArgs); }
/*  299 */     catch (InstantiationException instantiationException) {  }
/*  300 */     catch (IllegalAccessException illegalAccessException) {  }
/*  301 */     catch (InvocationTargetException invocationTargetException) {  }
/*  302 */     catch (NoSuchMethodException noSuchMethodException) {}
/*      */ 
/*      */     
/*  305 */     throw new ClassNotFoundException("adapter");
/*      */   }
/*      */ 
/*      */   
/*      */   private static ObjToIntMap getObjectFunctionNames(Scriptable obj) {
/*  310 */     Object[] ids = ScriptableObject.getPropertyIds(obj);
/*  311 */     ObjToIntMap map = new ObjToIntMap(ids.length);
/*  312 */     for (int i = 0; i != ids.length; i++) {
/*  313 */       if (ids[i] instanceof String) {
/*      */         
/*  315 */         String id = (String)ids[i];
/*  316 */         Object value = ScriptableObject.getProperty(obj, id);
/*  317 */         if (value instanceof Function) {
/*  318 */           Function f = (Function)value;
/*  319 */           int length = ScriptRuntime.toInt32(
/*  320 */               ScriptableObject.getProperty(f, "length"));
/*  321 */           if (length < 0) {
/*  322 */             length = 0;
/*      */           }
/*  324 */           map.put(id, length);
/*      */         } 
/*      */       } 
/*  327 */     }  return map;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Class<?> getAdapterClass(Scriptable scope, Class<?> superClass, Class<?>[] interfaces, Scriptable obj) {
/*  333 */     ClassCache cache = ClassCache.get(scope);
/*      */     
/*  335 */     Map<JavaAdapterSignature, Class<?>> generated = cache.getInterfaceAdapterCacheMap();
/*      */     
/*  337 */     ObjToIntMap names = getObjectFunctionNames(obj);
/*      */     
/*  339 */     JavaAdapterSignature sig = new JavaAdapterSignature(superClass, interfaces, names);
/*  340 */     Class<?> adapterClass = generated.get(sig);
/*  341 */     if (adapterClass == null) {
/*  342 */       String adapterName = "adapter" + cache.newClassSerialNumber();
/*  343 */       byte[] code = createAdapterCode(names, adapterName, superClass, interfaces, null);
/*      */ 
/*      */       
/*  346 */       adapterClass = loadAdapterClass(adapterName, code);
/*  347 */       if (cache.isCachingEnabled()) {
/*  348 */         generated.put(sig, adapterClass);
/*      */       }
/*      */     } 
/*  351 */     return adapterClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] createAdapterCode(ObjToIntMap functionNames, String adapterName, Class<?> superClass, Class<?>[] interfaces, String scriptClassName) {
/*      */     // Byte code:
/*      */     //   0: new org/mozilla/classfile/ClassFileWriter
/*      */     //   3: dup
/*      */     //   4: aload_1
/*      */     //   5: aload_2
/*      */     //   6: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   9: ldc '<adapter>'
/*      */     //   11: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   14: astore #5
/*      */     //   16: aload #5
/*      */     //   18: ldc 'factory'
/*      */     //   20: ldc 'Lorg/mozilla/javascript/ContextFactory;'
/*      */     //   22: bipush #17
/*      */     //   24: invokevirtual addField : (Ljava/lang/String;Ljava/lang/String;S)V
/*      */     //   27: aload #5
/*      */     //   29: ldc 'delegee'
/*      */     //   31: ldc 'Lorg/mozilla/javascript/Scriptable;'
/*      */     //   33: bipush #17
/*      */     //   35: invokevirtual addField : (Ljava/lang/String;Ljava/lang/String;S)V
/*      */     //   38: aload #5
/*      */     //   40: ldc 'self'
/*      */     //   42: ldc 'Lorg/mozilla/javascript/Scriptable;'
/*      */     //   44: bipush #17
/*      */     //   46: invokevirtual addField : (Ljava/lang/String;Ljava/lang/String;S)V
/*      */     //   49: aload_3
/*      */     //   50: ifnonnull -> 57
/*      */     //   53: iconst_0
/*      */     //   54: goto -> 59
/*      */     //   57: aload_3
/*      */     //   58: arraylength
/*      */     //   59: istore #6
/*      */     //   61: iconst_0
/*      */     //   62: istore #7
/*      */     //   64: iload #7
/*      */     //   66: iload #6
/*      */     //   68: if_icmpge -> 96
/*      */     //   71: aload_3
/*      */     //   72: iload #7
/*      */     //   74: aaload
/*      */     //   75: ifnull -> 90
/*      */     //   78: aload #5
/*      */     //   80: aload_3
/*      */     //   81: iload #7
/*      */     //   83: aaload
/*      */     //   84: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   87: invokevirtual addInterface : (Ljava/lang/String;)V
/*      */     //   90: iinc #7, 1
/*      */     //   93: goto -> 64
/*      */     //   96: aload_2
/*      */     //   97: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   100: bipush #46
/*      */     //   102: bipush #47
/*      */     //   104: invokevirtual replace : (CC)Ljava/lang/String;
/*      */     //   107: astore #7
/*      */     //   109: aload_2
/*      */     //   110: invokevirtual getDeclaredConstructors : ()[Ljava/lang/reflect/Constructor;
/*      */     //   113: astore #8
/*      */     //   115: aload #8
/*      */     //   117: astore #9
/*      */     //   119: aload #9
/*      */     //   121: arraylength
/*      */     //   122: istore #10
/*      */     //   124: iconst_0
/*      */     //   125: istore #11
/*      */     //   127: iload #11
/*      */     //   129: iload #10
/*      */     //   131: if_icmpge -> 180
/*      */     //   134: aload #9
/*      */     //   136: iload #11
/*      */     //   138: aaload
/*      */     //   139: astore #12
/*      */     //   141: aload #12
/*      */     //   143: invokevirtual getModifiers : ()I
/*      */     //   146: istore #13
/*      */     //   148: iload #13
/*      */     //   150: invokestatic isPublic : (I)Z
/*      */     //   153: ifne -> 164
/*      */     //   156: iload #13
/*      */     //   158: invokestatic isProtected : (I)Z
/*      */     //   161: ifeq -> 174
/*      */     //   164: aload #5
/*      */     //   166: aload_1
/*      */     //   167: aload #7
/*      */     //   169: aload #12
/*      */     //   171: invokestatic generateCtor : (Lorg/mozilla/classfile/ClassFileWriter;Ljava/lang/String;Ljava/lang/String;Ljava/lang/reflect/Constructor;)V
/*      */     //   174: iinc #11, 1
/*      */     //   177: goto -> 127
/*      */     //   180: aload #5
/*      */     //   182: aload_1
/*      */     //   183: aload #7
/*      */     //   185: invokestatic generateSerialCtor : (Lorg/mozilla/classfile/ClassFileWriter;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   188: aload #4
/*      */     //   190: ifnull -> 203
/*      */     //   193: aload #5
/*      */     //   195: aload_1
/*      */     //   196: aload #7
/*      */     //   198: aload #4
/*      */     //   200: invokestatic generateEmptyCtor : (Lorg/mozilla/classfile/ClassFileWriter;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   203: new org/mozilla/javascript/ObjToIntMap
/*      */     //   206: dup
/*      */     //   207: invokespecial <init> : ()V
/*      */     //   210: astore #9
/*      */     //   212: new org/mozilla/javascript/ObjToIntMap
/*      */     //   215: dup
/*      */     //   216: invokespecial <init> : ()V
/*      */     //   219: astore #10
/*      */     //   221: iconst_0
/*      */     //   222: istore #11
/*      */     //   224: iload #11
/*      */     //   226: iload #6
/*      */     //   228: if_icmpge -> 414
/*      */     //   231: aload_3
/*      */     //   232: iload #11
/*      */     //   234: aaload
/*      */     //   235: invokevirtual getMethods : ()[Ljava/lang/reflect/Method;
/*      */     //   238: astore #12
/*      */     //   240: iconst_0
/*      */     //   241: istore #13
/*      */     //   243: iload #13
/*      */     //   245: aload #12
/*      */     //   247: arraylength
/*      */     //   248: if_icmpge -> 408
/*      */     //   251: aload #12
/*      */     //   253: iload #13
/*      */     //   255: aaload
/*      */     //   256: astore #14
/*      */     //   258: aload #14
/*      */     //   260: invokevirtual getModifiers : ()I
/*      */     //   263: istore #15
/*      */     //   265: iload #15
/*      */     //   267: invokestatic isStatic : (I)Z
/*      */     //   270: ifne -> 402
/*      */     //   273: iload #15
/*      */     //   275: invokestatic isFinal : (I)Z
/*      */     //   278: ifne -> 402
/*      */     //   281: aload #14
/*      */     //   283: invokevirtual isDefault : ()Z
/*      */     //   286: ifeq -> 292
/*      */     //   289: goto -> 402
/*      */     //   292: aload #14
/*      */     //   294: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   297: astore #16
/*      */     //   299: aload #14
/*      */     //   301: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
/*      */     //   304: astore #17
/*      */     //   306: aload_0
/*      */     //   307: aload #16
/*      */     //   309: invokevirtual has : (Ljava/lang/Object;)Z
/*      */     //   312: ifne -> 329
/*      */     //   315: aload_2
/*      */     //   316: aload #16
/*      */     //   318: aload #17
/*      */     //   320: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   323: pop
/*      */     //   324: goto -> 402
/*      */     //   327: astore #18
/*      */     //   329: aload #14
/*      */     //   331: aload #17
/*      */     //   333: invokestatic getMethodSignature : (Ljava/lang/reflect/Method;[Ljava/lang/Class;)Ljava/lang/String;
/*      */     //   336: astore #18
/*      */     //   338: new java/lang/StringBuilder
/*      */     //   341: dup
/*      */     //   342: invokespecial <init> : ()V
/*      */     //   345: aload #16
/*      */     //   347: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   350: aload #18
/*      */     //   352: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   355: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   358: astore #19
/*      */     //   360: aload #9
/*      */     //   362: aload #19
/*      */     //   364: invokevirtual has : (Ljava/lang/Object;)Z
/*      */     //   367: ifne -> 402
/*      */     //   370: aload #5
/*      */     //   372: aload_1
/*      */     //   373: aload #16
/*      */     //   375: aload #17
/*      */     //   377: aload #14
/*      */     //   379: invokevirtual getReturnType : ()Ljava/lang/Class;
/*      */     //   382: iconst_1
/*      */     //   383: invokestatic generateMethod : (Lorg/mozilla/classfile/ClassFileWriter;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;Z)V
/*      */     //   386: aload #9
/*      */     //   388: aload #19
/*      */     //   390: iconst_0
/*      */     //   391: invokevirtual put : (Ljava/lang/Object;I)V
/*      */     //   394: aload #10
/*      */     //   396: aload #16
/*      */     //   398: iconst_0
/*      */     //   399: invokevirtual put : (Ljava/lang/Object;I)V
/*      */     //   402: iinc #13, 1
/*      */     //   405: goto -> 243
/*      */     //   408: iinc #11, 1
/*      */     //   411: goto -> 224
/*      */     //   414: aload_2
/*      */     //   415: invokestatic getOverridableMethods : (Ljava/lang/Class;)[Ljava/lang/reflect/Method;
/*      */     //   418: astore #11
/*      */     //   420: iconst_0
/*      */     //   421: istore #12
/*      */     //   423: iload #12
/*      */     //   425: aload #11
/*      */     //   427: arraylength
/*      */     //   428: if_icmpge -> 583
/*      */     //   431: aload #11
/*      */     //   433: iload #12
/*      */     //   435: aaload
/*      */     //   436: astore #13
/*      */     //   438: aload #13
/*      */     //   440: invokevirtual getModifiers : ()I
/*      */     //   443: istore #14
/*      */     //   445: iload #14
/*      */     //   447: invokestatic isAbstract : (I)Z
/*      */     //   450: istore #15
/*      */     //   452: aload #13
/*      */     //   454: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   457: astore #16
/*      */     //   459: iload #15
/*      */     //   461: ifne -> 473
/*      */     //   464: aload_0
/*      */     //   465: aload #16
/*      */     //   467: invokevirtual has : (Ljava/lang/Object;)Z
/*      */     //   470: ifeq -> 577
/*      */     //   473: aload #13
/*      */     //   475: invokevirtual getParameterTypes : ()[Ljava/lang/Class;
/*      */     //   478: astore #17
/*      */     //   480: aload #13
/*      */     //   482: aload #17
/*      */     //   484: invokestatic getMethodSignature : (Ljava/lang/reflect/Method;[Ljava/lang/Class;)Ljava/lang/String;
/*      */     //   487: astore #18
/*      */     //   489: new java/lang/StringBuilder
/*      */     //   492: dup
/*      */     //   493: invokespecial <init> : ()V
/*      */     //   496: aload #16
/*      */     //   498: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   501: aload #18
/*      */     //   503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   506: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   509: astore #19
/*      */     //   511: aload #9
/*      */     //   513: aload #19
/*      */     //   515: invokevirtual has : (Ljava/lang/Object;)Z
/*      */     //   518: ifne -> 577
/*      */     //   521: aload #5
/*      */     //   523: aload_1
/*      */     //   524: aload #16
/*      */     //   526: aload #17
/*      */     //   528: aload #13
/*      */     //   530: invokevirtual getReturnType : ()Ljava/lang/Class;
/*      */     //   533: iconst_1
/*      */     //   534: invokestatic generateMethod : (Lorg/mozilla/classfile/ClassFileWriter;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;Z)V
/*      */     //   537: aload #9
/*      */     //   539: aload #19
/*      */     //   541: iconst_0
/*      */     //   542: invokevirtual put : (Ljava/lang/Object;I)V
/*      */     //   545: aload #10
/*      */     //   547: aload #16
/*      */     //   549: iconst_0
/*      */     //   550: invokevirtual put : (Ljava/lang/Object;I)V
/*      */     //   553: iload #15
/*      */     //   555: ifne -> 577
/*      */     //   558: aload #5
/*      */     //   560: aload_1
/*      */     //   561: aload #7
/*      */     //   563: aload #16
/*      */     //   565: aload #18
/*      */     //   567: aload #17
/*      */     //   569: aload #13
/*      */     //   571: invokevirtual getReturnType : ()Ljava/lang/Class;
/*      */     //   574: invokestatic generateSuper : (Lorg/mozilla/classfile/ClassFileWriter;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;)V
/*      */     //   577: iinc #12, 1
/*      */     //   580: goto -> 423
/*      */     //   583: new org/mozilla/javascript/ObjToIntMap$Iterator
/*      */     //   586: dup
/*      */     //   587: aload_0
/*      */     //   588: invokespecial <init> : (Lorg/mozilla/javascript/ObjToIntMap;)V
/*      */     //   591: astore #12
/*      */     //   593: aload #12
/*      */     //   595: invokevirtual start : ()V
/*      */     //   598: aload #12
/*      */     //   600: invokevirtual done : ()Z
/*      */     //   603: ifne -> 689
/*      */     //   606: aload #12
/*      */     //   608: invokevirtual getKey : ()Ljava/lang/Object;
/*      */     //   611: checkcast java/lang/String
/*      */     //   614: astore #13
/*      */     //   616: aload #10
/*      */     //   618: aload #13
/*      */     //   620: invokevirtual has : (Ljava/lang/Object;)Z
/*      */     //   623: ifeq -> 629
/*      */     //   626: goto -> 681
/*      */     //   629: aload #12
/*      */     //   631: invokevirtual getValue : ()I
/*      */     //   634: istore #14
/*      */     //   636: iload #14
/*      */     //   638: anewarray java/lang/Class
/*      */     //   641: astore #15
/*      */     //   643: iconst_0
/*      */     //   644: istore #16
/*      */     //   646: iload #16
/*      */     //   648: iload #14
/*      */     //   650: if_icmpge -> 667
/*      */     //   653: aload #15
/*      */     //   655: iload #16
/*      */     //   657: getstatic org/mozilla/javascript/ScriptRuntime.ObjectClass : Ljava/lang/Class;
/*      */     //   660: aastore
/*      */     //   661: iinc #16, 1
/*      */     //   664: goto -> 646
/*      */     //   667: aload #5
/*      */     //   669: aload_1
/*      */     //   670: aload #13
/*      */     //   672: aload #15
/*      */     //   674: getstatic org/mozilla/javascript/ScriptRuntime.ObjectClass : Ljava/lang/Class;
/*      */     //   677: iconst_0
/*      */     //   678: invokestatic generateMethod : (Lorg/mozilla/classfile/ClassFileWriter;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;Z)V
/*      */     //   681: aload #12
/*      */     //   683: invokevirtual next : ()V
/*      */     //   686: goto -> 598
/*      */     //   689: aload #5
/*      */     //   691: invokevirtual toByteArray : ()[B
/*      */     //   694: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #360	-> 0
/*      */     //   #361	-> 6
/*      */     //   #363	-> 16
/*      */     //   #366	-> 27
/*      */     //   #369	-> 38
/*      */     //   #372	-> 49
/*      */     //   #373	-> 61
/*      */     //   #374	-> 71
/*      */     //   #375	-> 78
/*      */     //   #373	-> 90
/*      */     //   #378	-> 96
/*      */     //   #379	-> 109
/*      */     //   #380	-> 115
/*      */     //   #381	-> 141
/*      */     //   #382	-> 148
/*      */     //   #383	-> 164
/*      */     //   #380	-> 174
/*      */     //   #386	-> 180
/*      */     //   #387	-> 188
/*      */     //   #388	-> 193
/*      */     //   #391	-> 203
/*      */     //   #392	-> 212
/*      */     //   #395	-> 221
/*      */     //   #396	-> 231
/*      */     //   #397	-> 240
/*      */     //   #398	-> 251
/*      */     //   #399	-> 258
/*      */     //   #400	-> 265
/*      */     //   #401	-> 289
/*      */     //   #403	-> 292
/*      */     //   #404	-> 299
/*      */     //   #405	-> 306
/*      */     //   #407	-> 315
/*      */     //   #411	-> 324
/*      */     //   #412	-> 327
/*      */     //   #418	-> 329
/*      */     //   #419	-> 338
/*      */     //   #420	-> 360
/*      */     //   #421	-> 370
/*      */     //   #422	-> 379
/*      */     //   #421	-> 383
/*      */     //   #423	-> 386
/*      */     //   #424	-> 394
/*      */     //   #397	-> 402
/*      */     //   #395	-> 408
/*      */     //   #433	-> 414
/*      */     //   #434	-> 420
/*      */     //   #435	-> 431
/*      */     //   #436	-> 438
/*      */     //   #440	-> 445
/*      */     //   #441	-> 452
/*      */     //   #442	-> 459
/*      */     //   #445	-> 473
/*      */     //   #446	-> 480
/*      */     //   #447	-> 489
/*      */     //   #448	-> 511
/*      */     //   #449	-> 521
/*      */     //   #450	-> 530
/*      */     //   #449	-> 534
/*      */     //   #451	-> 537
/*      */     //   #452	-> 545
/*      */     //   #456	-> 553
/*      */     //   #457	-> 558
/*      */     //   #459	-> 571
/*      */     //   #457	-> 574
/*      */     //   #434	-> 577
/*      */     //   #467	-> 583
/*      */     //   #468	-> 593
/*      */     //   #469	-> 606
/*      */     //   #470	-> 616
/*      */     //   #471	-> 626
/*      */     //   #472	-> 629
/*      */     //   #473	-> 636
/*      */     //   #474	-> 643
/*      */     //   #475	-> 653
/*      */     //   #474	-> 661
/*      */     //   #476	-> 667
/*      */     //   #468	-> 681
/*      */     //   #479	-> 689
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   64	32	7	i	I
/*      */     //   148	26	13	mod	I
/*      */     //   141	33	12	ctor	Ljava/lang/reflect/Constructor;
/*      */     //   258	144	14	method	Ljava/lang/reflect/Method;
/*      */     //   265	137	15	mods	I
/*      */     //   299	103	16	methodName	Ljava/lang/String;
/*      */     //   306	96	17	argTypes	[Ljava/lang/Class;
/*      */     //   338	64	18	methodSignature	Ljava/lang/String;
/*      */     //   360	42	19	methodKey	Ljava/lang/String;
/*      */     //   243	165	13	j	I
/*      */     //   240	168	12	methods	[Ljava/lang/reflect/Method;
/*      */     //   224	190	11	i	I
/*      */     //   480	97	17	argTypes	[Ljava/lang/Class;
/*      */     //   489	88	18	methodSignature	Ljava/lang/String;
/*      */     //   511	66	19	methodKey	Ljava/lang/String;
/*      */     //   438	139	13	method	Ljava/lang/reflect/Method;
/*      */     //   445	132	14	mods	I
/*      */     //   452	125	15	isAbstractMethod	Z
/*      */     //   459	118	16	methodName	Ljava/lang/String;
/*      */     //   423	160	12	j	I
/*      */     //   646	21	16	k	I
/*      */     //   616	65	13	functionName	Ljava/lang/String;
/*      */     //   636	45	14	length	I
/*      */     //   643	38	15	parms	[Ljava/lang/Class;
/*      */     //   0	695	0	functionNames	Lorg/mozilla/javascript/ObjToIntMap;
/*      */     //   0	695	1	adapterName	Ljava/lang/String;
/*      */     //   0	695	2	superClass	Ljava/lang/Class;
/*      */     //   0	695	3	interfaces	[Ljava/lang/Class;
/*      */     //   0	695	4	scriptClassName	Ljava/lang/String;
/*      */     //   16	679	5	cfw	Lorg/mozilla/classfile/ClassFileWriter;
/*      */     //   61	634	6	interfacesCount	I
/*      */     //   109	586	7	superName	Ljava/lang/String;
/*      */     //   115	580	8	ctors	[Ljava/lang/reflect/Constructor;
/*      */     //   212	483	9	generatedOverrides	Lorg/mozilla/javascript/ObjToIntMap;
/*      */     //   221	474	10	generatedMethods	Lorg/mozilla/javascript/ObjToIntMap;
/*      */     //   420	275	11	methods	[Ljava/lang/reflect/Method;
/*      */     //   593	102	12	iter	Lorg/mozilla/javascript/ObjToIntMap$Iterator;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   141	33	12	ctor	Ljava/lang/reflect/Constructor<*>;
/*      */     //   306	96	17	argTypes	[Ljava/lang/Class<*>;
/*      */     //   480	97	17	argTypes	[Ljava/lang/Class<*>;
/*      */     //   643	38	15	parms	[Ljava/lang/Class<*>;
/*      */     //   0	695	2	superClass	Ljava/lang/Class<*>;
/*      */     //   0	695	3	interfaces	[Ljava/lang/Class<*>;
/*      */     //   115	580	8	ctors	[Ljava/lang/reflect/Constructor<*>;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   315	324	327	java/lang/NoSuchMethodException
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Method[] getOverridableMethods(Class<?> clazz) {
/*  484 */     ArrayList<Method> list = new ArrayList<>();
/*  485 */     HashSet<String> skip = new HashSet<>();
/*      */ 
/*      */     
/*      */     Class<?> c;
/*      */     
/*  490 */     for (c = clazz; c != null; c = c.getSuperclass()) {
/*  491 */       appendOverridableMethods(c, list, skip);
/*      */     }
/*  493 */     for (c = clazz; c != null; c = c.getSuperclass()) {
/*  494 */       for (Class<?> intf : c.getInterfaces())
/*  495 */         appendOverridableMethods(intf, list, skip); 
/*      */     } 
/*  497 */     return list.<Method>toArray(new Method[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void appendOverridableMethods(Class<?> c, ArrayList<Method> list, HashSet<String> skip) {
/*  503 */     Method[] methods = c.isInterface() ? c.getMethods() : c.getDeclaredMethods();
/*      */     
/*  505 */     for (int i = 0; i < methods.length; i++) {
/*      */       
/*  507 */       String methodKey = methods[i].getName() + getMethodSignature(methods[i], methods[i]
/*  508 */           .getParameterTypes());
/*  509 */       if (!skip.contains(methodKey)) {
/*      */         
/*  511 */         int mods = methods[i].getModifiers();
/*  512 */         if (!Modifier.isStatic(mods))
/*      */         {
/*  514 */           if (Modifier.isFinal(mods)) {
/*      */ 
/*      */             
/*  517 */             skip.add(methodKey);
/*      */           
/*      */           }
/*  520 */           else if (Modifier.isPublic(mods) || Modifier.isProtected(mods)) {
/*  521 */             list.add(methods[i]);
/*  522 */             skip.add(methodKey);
/*      */           }  } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static Class<?> loadAdapterClass(String className, byte[] classBytes) {
/*      */     Object staticDomain;
/*  530 */     Class<?> domainClass = SecurityController.getStaticSecurityDomainClass();
/*  531 */     if (domainClass == CodeSource.class || domainClass == ProtectionDomain.class) {
/*      */       
/*  533 */       ProtectionDomain protectionDomain = SecurityUtilities.getScriptProtectionDomain();
/*  534 */       if (protectionDomain == null) {
/*  535 */         protectionDomain = JavaAdapter.class.getProtectionDomain();
/*      */       }
/*  537 */       if (domainClass == CodeSource.class) {
/*  538 */         staticDomain = (protectionDomain == null) ? null : protectionDomain.getCodeSource();
/*      */       } else {
/*      */         
/*  541 */         staticDomain = protectionDomain;
/*      */       } 
/*      */     } else {
/*      */       
/*  545 */       staticDomain = null;
/*      */     } 
/*  547 */     GeneratedClassLoader loader = SecurityController.createLoader(null, staticDomain);
/*      */     
/*  549 */     Class<?> result = loader.defineClass(className, classBytes);
/*  550 */     loader.linkClass(result);
/*  551 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Function getFunction(Scriptable obj, String functionName) {
/*  556 */     Object x = ScriptableObject.getProperty(obj, functionName);
/*  557 */     if (x == Scriptable.NOT_FOUND)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  563 */       return null;
/*      */     }
/*  565 */     if (!(x instanceof Function)) {
/*  566 */       throw ScriptRuntime.notFunctionError(x, functionName);
/*      */     }
/*  568 */     return (Function)x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callMethod(ContextFactory factory, Scriptable thisObj, Function f, Object[] args, long argsToWrap) {
/*  580 */     if (f == null)
/*      */     {
/*  582 */       return null;
/*      */     }
/*  584 */     if (factory == null) {
/*  585 */       factory = ContextFactory.getGlobal();
/*      */     }
/*      */     
/*  588 */     Scriptable scope = f.getParentScope();
/*  589 */     if (argsToWrap == 0L) {
/*  590 */       return Context.call(factory, f, scope, thisObj, args);
/*      */     }
/*      */     
/*  593 */     Context cx = Context.getCurrentContext();
/*  594 */     if (cx != null) {
/*  595 */       return doCall(cx, scope, thisObj, f, args, argsToWrap);
/*      */     }
/*  597 */     return factory.call(cx2 -> doCall(cx2, scope, thisObj, f, args, argsToWrap));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object doCall(Context cx, Scriptable scope, Scriptable thisObj, Function f, Object[] args, long argsToWrap) {
/*  605 */     for (int i = 0; i != args.length; i++) {
/*  606 */       if (0L != (argsToWrap & (1 << i))) {
/*  607 */         Object arg = args[i];
/*  608 */         if (!(arg instanceof Scriptable)) {
/*  609 */           args[i] = cx.getWrapFactory().wrap(cx, scope, arg, null);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  614 */     return f.call(cx, scope, thisObj, args);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Scriptable runScript(Script script) {
/*  619 */     return ContextFactory.getGlobal().<Scriptable>call(cx -> {
/*      */           ScriptableObject global = ScriptRuntime.getGlobal(cx);
/*      */           script.exec(cx, global);
/*      */           return global;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void generateCtor(ClassFileWriter cfw, String adapterName, String superName, Constructor<?> superCtor) {
/*  629 */     short locals = 3;
/*  630 */     Class<?>[] parameters = superCtor.getParameterTypes();
/*      */ 
/*      */ 
/*      */     
/*  634 */     if (parameters.length == 0) {
/*  635 */       cfw.startMethod("<init>", "(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/ContextFactory;)V", (short)1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  641 */       cfw.add(42);
/*  642 */       cfw.addInvoke(183, superName, "<init>", "()V");
/*      */     } else {
/*  644 */       StringBuilder sig = new StringBuilder("(Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/ContextFactory;");
/*      */ 
/*      */       
/*  647 */       int marker = sig.length();
/*  648 */       for (Class<?> c : parameters) {
/*  649 */         appendTypeString(sig, c);
/*      */       }
/*  651 */       sig.append(")V");
/*  652 */       cfw.startMethod("<init>", sig.toString(), (short)1);
/*      */ 
/*      */       
/*  655 */       cfw.add(42);
/*  656 */       short paramOffset = 3;
/*  657 */       for (Class<?> parameter : parameters) {
/*  658 */         paramOffset = (short)(paramOffset + generatePushParam(cfw, paramOffset, parameter));
/*      */       }
/*  660 */       locals = paramOffset;
/*  661 */       sig.delete(1, marker);
/*  662 */       cfw.addInvoke(183, superName, "<init>", sig.toString());
/*      */     } 
/*      */ 
/*      */     
/*  666 */     cfw.add(42);
/*  667 */     cfw.add(43);
/*  668 */     cfw.add(181, adapterName, "delegee", "Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */     
/*  672 */     cfw.add(42);
/*  673 */     cfw.add(44);
/*  674 */     cfw.add(181, adapterName, "factory", "Lorg/mozilla/javascript/ContextFactory;");
/*      */ 
/*      */     
/*  677 */     cfw.add(42);
/*      */     
/*  679 */     cfw.add(43);
/*  680 */     cfw.add(42);
/*  681 */     cfw.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "createAdapterWrapper", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  687 */     cfw.add(181, adapterName, "self", "Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */     
/*  690 */     cfw.add(177);
/*  691 */     cfw.stopMethod(locals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void generateSerialCtor(ClassFileWriter cfw, String adapterName, String superName) {
/*  698 */     cfw.startMethod("<init>", "(Lorg/mozilla/javascript/ContextFactory;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Scriptable;)V", (short)1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  706 */     cfw.add(42);
/*  707 */     cfw.addInvoke(183, superName, "<init>", "()V");
/*      */ 
/*      */     
/*  710 */     cfw.add(42);
/*  711 */     cfw.add(43);
/*  712 */     cfw.add(181, adapterName, "factory", "Lorg/mozilla/javascript/ContextFactory;");
/*      */ 
/*      */ 
/*      */     
/*  716 */     cfw.add(42);
/*  717 */     cfw.add(44);
/*  718 */     cfw.add(181, adapterName, "delegee", "Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */     
/*  721 */     cfw.add(42);
/*  722 */     cfw.add(45);
/*  723 */     cfw.add(181, adapterName, "self", "Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */     
/*  726 */     cfw.add(177);
/*  727 */     cfw.stopMethod((short)4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void generateEmptyCtor(ClassFileWriter cfw, String adapterName, String superName, String scriptClassName) {
/*  735 */     cfw.startMethod("<init>", "()V", (short)1);
/*      */ 
/*      */     
/*  738 */     cfw.add(42);
/*  739 */     cfw.addInvoke(183, superName, "<init>", "()V");
/*      */ 
/*      */     
/*  742 */     cfw.add(42);
/*  743 */     cfw.add(1);
/*  744 */     cfw.add(181, adapterName, "factory", "Lorg/mozilla/javascript/ContextFactory;");
/*      */ 
/*      */ 
/*      */     
/*  748 */     cfw.add(187, scriptClassName);
/*  749 */     cfw.add(89);
/*  750 */     cfw.addInvoke(183, scriptClassName, "<init>", "()V");
/*      */ 
/*      */     
/*  753 */     cfw.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "runScript", "(Lorg/mozilla/javascript/Script;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  758 */     cfw.add(76);
/*      */ 
/*      */     
/*  761 */     cfw.add(42);
/*  762 */     cfw.add(43);
/*  763 */     cfw.add(181, adapterName, "delegee", "Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */     
/*  766 */     cfw.add(42);
/*      */     
/*  768 */     cfw.add(43);
/*  769 */     cfw.add(42);
/*  770 */     cfw.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "createAdapterWrapper", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/Object;)Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  776 */     cfw.add(181, adapterName, "self", "Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */     
/*  779 */     cfw.add(177);
/*  780 */     cfw.stopMethod((short)2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void generatePushWrappedArgs(ClassFileWriter cfw, Class<?>[] argTypes, int arrayLength) {
/*  793 */     cfw.addPush(arrayLength);
/*  794 */     cfw.add(189, "java/lang/Object");
/*  795 */     int paramOffset = 1;
/*  796 */     for (int i = 0; i != argTypes.length; i++) {
/*  797 */       cfw.add(89);
/*  798 */       cfw.addPush(i);
/*  799 */       paramOffset += generateWrapArg(cfw, paramOffset, argTypes[i]);
/*  800 */       cfw.add(83);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int generateWrapArg(ClassFileWriter cfw, int paramOffset, Class<?> argType) {
/*  812 */     int size = 1;
/*  813 */     if (!argType.isPrimitive()) {
/*  814 */       cfw.add(25, paramOffset);
/*      */     }
/*  816 */     else if (argType == boolean.class) {
/*      */       
/*  818 */       cfw.add(187, "java/lang/Boolean");
/*  819 */       cfw.add(89);
/*  820 */       cfw.add(21, paramOffset);
/*  821 */       cfw.addInvoke(183, "java/lang/Boolean", "<init>", "(Z)V");
/*      */     
/*      */     }
/*  824 */     else if (argType == char.class) {
/*      */       
/*  826 */       cfw.add(21, paramOffset);
/*  827 */       cfw.addInvoke(184, "java/lang/String", "valueOf", "(C)Ljava/lang/String;");
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  832 */       cfw.add(187, "java/lang/Double");
/*  833 */       cfw.add(89);
/*  834 */       String typeName = argType.getName();
/*  835 */       switch (typeName.charAt(0)) {
/*      */         
/*      */         case 'b':
/*      */         case 'i':
/*      */         case 's':
/*  840 */           cfw.add(21, paramOffset);
/*  841 */           cfw.add(135);
/*      */           break;
/*      */         
/*      */         case 'l':
/*  845 */           cfw.add(22, paramOffset);
/*  846 */           cfw.add(138);
/*  847 */           size = 2;
/*      */           break;
/*      */         
/*      */         case 'f':
/*  851 */           cfw.add(23, paramOffset);
/*  852 */           cfw.add(141);
/*      */           break;
/*      */         case 'd':
/*  855 */           cfw.add(24, paramOffset);
/*  856 */           size = 2;
/*      */           break;
/*      */       } 
/*  859 */       cfw.addInvoke(183, "java/lang/Double", "<init>", "(D)V");
/*      */     } 
/*      */     
/*  862 */     return size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void generateReturnResult(ClassFileWriter cfw, Class<?> retType, boolean callConvertResult) {
/*  875 */     if (retType == void.class) {
/*  876 */       cfw.add(87);
/*  877 */       cfw.add(177);
/*      */     }
/*  879 */     else if (retType == boolean.class) {
/*  880 */       cfw.addInvoke(184, "org/mozilla/javascript/Context", "toBoolean", "(Ljava/lang/Object;)Z");
/*      */ 
/*      */       
/*  883 */       cfw.add(172);
/*      */     }
/*  885 */     else if (retType == char.class) {
/*      */ 
/*      */ 
/*      */       
/*  889 */       cfw.addInvoke(184, "org/mozilla/javascript/Context", "toString", "(Ljava/lang/Object;)Ljava/lang/String;");
/*      */ 
/*      */ 
/*      */       
/*  893 */       cfw.add(3);
/*  894 */       cfw.addInvoke(182, "java/lang/String", "charAt", "(I)C");
/*      */       
/*  896 */       cfw.add(172);
/*      */     } else {
/*  898 */       if (retType.isPrimitive()) {
/*  899 */         cfw.addInvoke(184, "org/mozilla/javascript/Context", "toNumber", "(Ljava/lang/Object;)D");
/*      */ 
/*      */         
/*  902 */         String typeName = retType.getName();
/*  903 */         switch (typeName.charAt(0)) {
/*      */           case 'b':
/*      */           case 'i':
/*      */           case 's':
/*  907 */             cfw.add(142);
/*  908 */             cfw.add(172);
/*      */             return;
/*      */           case 'l':
/*  911 */             cfw.add(143);
/*  912 */             cfw.add(173);
/*      */             return;
/*      */           case 'f':
/*  915 */             cfw.add(144);
/*  916 */             cfw.add(174);
/*      */             return;
/*      */           case 'd':
/*  919 */             cfw.add(175);
/*      */             return;
/*      */         } 
/*  922 */         throw new RuntimeException("Unexpected return type " + retType);
/*      */       } 
/*      */ 
/*      */       
/*  926 */       String retTypeStr = retType.getName();
/*  927 */       if (callConvertResult) {
/*  928 */         cfw.addLoadConstant(retTypeStr);
/*  929 */         cfw.addInvoke(184, "java/lang/Class", "forName", "(Ljava/lang/String;)Ljava/lang/Class;");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  934 */         cfw.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "convertResult", "(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  942 */       cfw.add(192, retTypeStr);
/*  943 */       cfw.add(176);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void generateMethod(ClassFileWriter cfw, String genName, String methodName, Class<?>[] parms, Class<?> returnType, boolean convertResult) {
/*  951 */     StringBuilder sb = new StringBuilder();
/*  952 */     int paramsEnd = appendMethodSignature(parms, returnType, sb);
/*  953 */     String methodSignature = sb.toString();
/*  954 */     cfw.startMethod(methodName, methodSignature, (short)1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  960 */     cfw.add(42);
/*  961 */     cfw.add(180, genName, "factory", "Lorg/mozilla/javascript/ContextFactory;");
/*      */ 
/*      */ 
/*      */     
/*  965 */     cfw.add(42);
/*  966 */     cfw.add(180, genName, "self", "Lorg/mozilla/javascript/Scriptable;");
/*      */ 
/*      */ 
/*      */     
/*  970 */     cfw.add(42);
/*  971 */     cfw.add(180, genName, "delegee", "Lorg/mozilla/javascript/Scriptable;");
/*      */     
/*  973 */     cfw.addPush(methodName);
/*  974 */     cfw.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "getFunction", "(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;)Lorg/mozilla/javascript/Function;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  982 */     generatePushWrappedArgs(cfw, parms, parms.length);
/*      */ 
/*      */     
/*  985 */     if (parms.length > 64)
/*      */     {
/*      */       
/*  988 */       throw Context.reportRuntimeErrorById("JavaAdapter can not subclass methods with more then 64 arguments.", new Object[0]);
/*      */     }
/*      */ 
/*      */     
/*  992 */     long convertionMask = 0L;
/*  993 */     for (int i = 0; i != parms.length; i++) {
/*  994 */       if (!parms[i].isPrimitive()) {
/*  995 */         convertionMask |= (1 << i);
/*      */       }
/*      */     } 
/*  998 */     cfw.addPush(convertionMask);
/*      */ 
/*      */ 
/*      */     
/* 1002 */     cfw.addInvoke(184, "org/mozilla/javascript/JavaAdapter", "callMethod", "(Lorg/mozilla/javascript/ContextFactory;Lorg/mozilla/javascript/Scriptable;Lorg/mozilla/javascript/Function;[Ljava/lang/Object;J)Ljava/lang/Object;");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1012 */     generateReturnResult(cfw, returnType, convertResult);
/*      */     
/* 1014 */     cfw.stopMethod((short)paramsEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int generatePushParam(ClassFileWriter cfw, int paramOffset, Class<?> paramType) {
/* 1024 */     if (!paramType.isPrimitive()) {
/* 1025 */       cfw.addALoad(paramOffset);
/* 1026 */       return 1;
/*      */     } 
/* 1028 */     String typeName = paramType.getName();
/* 1029 */     switch (typeName.charAt(0)) {
/*      */       
/*      */       case 'b':
/*      */       case 'c':
/*      */       case 'i':
/*      */       case 's':
/*      */       case 'z':
/* 1036 */         cfw.addILoad(paramOffset);
/* 1037 */         return 1;
/*      */       
/*      */       case 'l':
/* 1040 */         cfw.addLLoad(paramOffset);
/* 1041 */         return 2;
/*      */       
/*      */       case 'f':
/* 1044 */         cfw.addFLoad(paramOffset);
/* 1045 */         return 1;
/*      */       case 'd':
/* 1047 */         cfw.addDLoad(paramOffset);
/* 1048 */         return 2;
/*      */     } 
/* 1050 */     throw Kit.codeBug();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void generatePopResult(ClassFileWriter cfw, Class<?> retType) {
/* 1061 */     if (retType.isPrimitive()) {
/* 1062 */       String typeName = retType.getName();
/* 1063 */       switch (typeName.charAt(0)) {
/*      */         case 'b':
/*      */         case 'c':
/*      */         case 'i':
/*      */         case 's':
/*      */         case 'z':
/* 1069 */           cfw.add(172);
/*      */           break;
/*      */         case 'l':
/* 1072 */           cfw.add(173);
/*      */           break;
/*      */         case 'f':
/* 1075 */           cfw.add(174);
/*      */           break;
/*      */         case 'd':
/* 1078 */           cfw.add(175);
/*      */           break;
/*      */       } 
/*      */     } else {
/* 1082 */       cfw.add(176);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void generateSuper(ClassFileWriter cfw, String genName, String superName, String methodName, String methodSignature, Class<?>[] parms, Class<?> returnType) {
/* 1096 */     cfw.startMethod("super$" + methodName, methodSignature, (short)1);
/*      */ 
/*      */ 
/*      */     
/* 1100 */     cfw.add(25, 0);
/*      */ 
/*      */     
/* 1103 */     int paramOffset = 1;
/* 1104 */     for (Class<?> parm : parms) {
/* 1105 */       paramOffset += generatePushParam(cfw, paramOffset, parm);
/*      */     }
/*      */ 
/*      */     
/* 1109 */     cfw.addInvoke(183, superName, methodName, methodSignature);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1115 */     Class<?> retType = returnType;
/* 1116 */     if (!retType.equals(void.class)) {
/* 1117 */       generatePopResult(cfw, retType);
/*      */     } else {
/* 1119 */       cfw.add(177);
/*      */     } 
/* 1121 */     cfw.stopMethod((short)(paramOffset + 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getMethodSignature(Method method, Class<?>[] argTypes) {
/* 1129 */     StringBuilder sb = new StringBuilder();
/* 1130 */     appendMethodSignature(argTypes, method.getReturnType(), sb);
/* 1131 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int appendMethodSignature(Class<?>[] argTypes, Class<?> returnType, StringBuilder sb) {
/* 1138 */     sb.append('(');
/* 1139 */     int firstLocal = 1 + argTypes.length;
/* 1140 */     for (Class<?> type : argTypes) {
/* 1141 */       appendTypeString(sb, type);
/* 1142 */       if (type == long.class || type == double.class)
/*      */       {
/* 1144 */         firstLocal++;
/*      */       }
/*      */     } 
/* 1147 */     sb.append(')');
/* 1148 */     appendTypeString(sb, returnType);
/* 1149 */     return firstLocal;
/*      */   }
/*      */ 
/*      */   
/*      */   private static StringBuilder appendTypeString(StringBuilder sb, Class<?> type) {
/* 1154 */     while (type.isArray()) {
/* 1155 */       sb.append('[');
/* 1156 */       type = type.getComponentType();
/*      */     } 
/* 1158 */     if (type.isPrimitive()) {
/*      */       char typeLetter;
/* 1160 */       if (type == boolean.class) {
/* 1161 */         typeLetter = 'Z';
/* 1162 */       } else if (type == long.class) {
/* 1163 */         typeLetter = 'J';
/*      */       } else {
/* 1165 */         String typeName = type.getName();
/* 1166 */         typeLetter = Character.toUpperCase(typeName.charAt(0));
/*      */       } 
/* 1168 */       sb.append(typeLetter);
/*      */     } else {
/* 1170 */       sb.append('L');
/* 1171 */       sb.append(type.getName().replace('.', '/'));
/* 1172 */       sb.append(';');
/*      */     } 
/* 1174 */     return sb;
/*      */   }
/*      */ 
/*      */   
/*      */   static int[] getArgsToConvert(Class<?>[] argTypes) {
/* 1179 */     int count = 0;
/* 1180 */     for (int i = 0; i != argTypes.length; i++) {
/* 1181 */       if (!argTypes[i].isPrimitive())
/* 1182 */         count++; 
/*      */     } 
/* 1184 */     if (count == 0)
/* 1185 */       return null; 
/* 1186 */     int[] array = new int[count];
/* 1187 */     count = 0;
/* 1188 */     for (int j = 0; j != argTypes.length; j++) {
/* 1189 */       if (!argTypes[j].isPrimitive())
/* 1190 */         array[count++] = j; 
/*      */     } 
/* 1192 */     return array;
/*      */   }
/*      */   
/* 1195 */   private static final Object FTAG = "JavaAdapter";
/*      */   private static final int Id_JavaAdapter = 1;
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\JavaAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */