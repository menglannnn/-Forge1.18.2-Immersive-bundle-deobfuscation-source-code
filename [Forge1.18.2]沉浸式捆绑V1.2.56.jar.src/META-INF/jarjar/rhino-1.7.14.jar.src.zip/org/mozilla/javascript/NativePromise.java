/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativePromise
/*     */   extends ScriptableObject
/*     */ {
/*     */   enum State
/*     */   {
/*  13 */     PENDING,
/*  14 */     FULFILLED,
/*  15 */     REJECTED;
/*     */   }
/*     */   
/*     */   enum ReactionType {
/*  19 */     FULFILL,
/*  20 */     REJECT;
/*     */   }
/*     */   
/*  23 */   private State state = State.PENDING;
/*  24 */   private Object result = null;
/*     */   
/*     */   private boolean handled = false;
/*  27 */   private ArrayList<Reaction> fulfillReactions = new ArrayList<>();
/*  28 */   private ArrayList<Reaction> rejectReactions = new ArrayList<>();
/*     */   
/*     */   public static void init(Context cx, Scriptable scope, boolean sealed) {
/*  31 */     LambdaConstructor constructor = new LambdaConstructor(scope, "Promise", 1, 2, NativePromise::constructor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  38 */     constructor.setStandardPropertyAttributes(3);
/*  39 */     constructor.setPrototypePropertyAttributes(7);
/*     */     
/*  41 */     constructor.defineConstructorMethod(scope, "resolve", 1, NativePromise::resolve, 2, 3);
/*     */     
/*  43 */     constructor.defineConstructorMethod(scope, "reject", 1, NativePromise::reject, 2, 3);
/*     */     
/*  45 */     constructor.defineConstructorMethod(scope, "all", 1, NativePromise::all, 2, 3);
/*     */     
/*  47 */     constructor.defineConstructorMethod(scope, "race", 1, NativePromise::race, 2, 3);
/*     */ 
/*     */     
/*  50 */     ScriptableObject speciesDescriptor = (ScriptableObject)cx.newObject(scope);
/*  51 */     ScriptableObject.putProperty(speciesDescriptor, "enumerable", Boolean.valueOf(false));
/*  52 */     ScriptableObject.putProperty(speciesDescriptor, "configurable", Boolean.valueOf(true));
/*  53 */     ScriptableObject.putProperty(speciesDescriptor, "get", new LambdaFunction(scope, "get [Symbol.species]", 0, (lcx, lscope, thisObj, args) -> constructor));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     constructor.defineOwnProperty(cx, SymbolKey.SPECIES, speciesDescriptor, false);
/*     */     
/*  64 */     constructor.definePrototypeMethod(scope, "then", 2, (lcx, lscope, thisObj, args) -> { NativePromise self = LambdaConstructor.<NativePromise>convertThisObject(thisObj, NativePromise.class); return self.then(lcx, lscope, constructor, args); }2, 3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     constructor.definePrototypeMethod(scope, "catch", 1, NativePromise::doCatch, 2, 3);
/*     */     
/*  77 */     constructor.definePrototypeMethod(scope, "finally", 1, (lcx, lscope, thisObj, args) -> doFinally(lcx, lscope, thisObj, constructor, args), 2, 3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     constructor.definePrototypeProperty(SymbolKey.TO_STRING_TAG, "Promise", 3);
/*     */ 
/*     */     
/*  89 */     ScriptableObject.defineProperty(scope, "Promise", constructor, 2);
/*  90 */     if (sealed) {
/*  91 */       constructor.sealObject();
/*     */     }
/*     */   }
/*     */   
/*     */   private static Scriptable constructor(Context cx, Scriptable scope, Object[] args) {
/*  96 */     if (args.length < 1 || !(args[0] instanceof Callable)) {
/*  97 */       throw ScriptRuntime.typeErrorById("msg.function.expected", new Object[0]);
/*     */     }
/*  99 */     Callable executor = (Callable)args[0];
/* 100 */     NativePromise promise = new NativePromise();
/* 101 */     ResolvingFunctions resolving = new ResolvingFunctions(scope, promise);
/*     */     
/* 103 */     Scriptable thisObj = Undefined.SCRIPTABLE_UNDEFINED;
/* 104 */     if (!cx.isStrictMode()) {
/* 105 */       Scriptable tcs = cx.topCallScope;
/* 106 */       if (tcs != null) {
/* 107 */         thisObj = tcs;
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 112 */       executor.call(cx, scope, thisObj, new Object[] { resolving.resolve, resolving.reject });
/* 113 */     } catch (RhinoException re) {
/* 114 */       resolving.reject.call(cx, scope, thisObj, new Object[] { getErrorObject(cx, scope, re) });
/*     */     } 
/*     */     
/* 117 */     return promise;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 122 */     return "Promise";
/*     */   }
/*     */   
/*     */   Object getResult() {
/* 126 */     return this.result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object resolve(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 131 */     if (!ScriptRuntime.isObject(thisObj)) {
/* 132 */       throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] { ScriptRuntime.typeof(thisObj) });
/*     */     }
/* 134 */     Object arg = (args.length > 0) ? args[0] : Undefined.instance;
/* 135 */     return resolveInternal(cx, scope, thisObj, arg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object resolveInternal(Context cx, Scriptable scope, Object constructor, Object arg) {
/* 141 */     if (arg instanceof NativePromise) {
/* 142 */       Object argConstructor = ScriptRuntime.getObjectProp(arg, "constructor", cx, scope);
/* 143 */       if (argConstructor == constructor) {
/* 144 */         return arg;
/*     */       }
/*     */     } 
/* 147 */     Capability cap = new Capability(cx, scope, constructor);
/* 148 */     cap.resolve.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] { arg });
/* 149 */     return cap.promise;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object reject(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 154 */     if (!ScriptRuntime.isObject(thisObj)) {
/* 155 */       throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] { ScriptRuntime.typeof(thisObj) });
/*     */     }
/* 157 */     Object arg = (args.length > 0) ? args[0] : Undefined.instance;
/* 158 */     Capability cap = new Capability(cx, scope, thisObj);
/* 159 */     cap.reject.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] { arg });
/* 160 */     return cap.promise;
/*     */   }
/*     */   
/*     */   private static Object all(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     IteratorLikeIterable iterable;
/* 165 */     Capability cap = new Capability(cx, scope, thisObj);
/* 166 */     Object arg = (args.length > 0) ? args[0] : Undefined.instance;
/*     */ 
/*     */     
/*     */     try {
/* 170 */       Object maybeIterable = ScriptRuntime.callIterator(arg, cx, scope);
/* 171 */       iterable = new IteratorLikeIterable(cx, scope, maybeIterable);
/* 172 */     } catch (RhinoException re) {
/* 173 */       cap.reject.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] {
/*     */ 
/*     */ 
/*     */             
/* 177 */             getErrorObject(cx, scope, re) });
/* 178 */       return cap.promise;
/*     */     } 
/*     */     
/* 181 */     IteratorLikeIterable.Itr iterator = iterable.iterator();
/*     */     try {
/* 183 */       PromiseAllResolver resolver = new PromiseAllResolver(iterator, thisObj, cap);
/*     */       try {
/* 185 */         return resolver.resolve(cx, scope);
/*     */       } finally {
/* 187 */         if (!iterator.isDone()) {
/* 188 */           iterable.close();
/*     */         }
/*     */       } 
/* 191 */     } catch (RhinoException re) {
/* 192 */       cap.reject.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] {
/*     */ 
/*     */ 
/*     */             
/* 196 */             getErrorObject(cx, scope, re) });
/* 197 */       return cap.promise;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object race(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/*     */     IteratorLikeIterable iterable;
/* 203 */     Capability cap = new Capability(cx, scope, thisObj);
/* 204 */     Object arg = (args.length > 0) ? args[0] : Undefined.instance;
/*     */ 
/*     */     
/*     */     try {
/* 208 */       Object maybeIterable = ScriptRuntime.callIterator(arg, cx, scope);
/* 209 */       iterable = new IteratorLikeIterable(cx, scope, maybeIterable);
/* 210 */     } catch (RhinoException re) {
/* 211 */       cap.reject.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] {
/*     */ 
/*     */ 
/*     */             
/* 215 */             getErrorObject(cx, scope, re) });
/* 216 */       return cap.promise;
/*     */     } 
/*     */     
/* 219 */     IteratorLikeIterable.Itr iterator = iterable.iterator();
/*     */     try {
/*     */       try {
/* 222 */         return performRace(cx, scope, iterator, thisObj, cap);
/*     */       } finally {
/* 224 */         if (!iterator.isDone()) {
/* 225 */           iterable.close();
/*     */         }
/*     */       } 
/* 228 */     } catch (RhinoException re) {
/* 229 */       cap.reject.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] {
/*     */ 
/*     */ 
/*     */             
/* 233 */             getErrorObject(cx, scope, re) });
/* 234 */       return cap.promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object performRace(Context cx, Scriptable scope, IteratorLikeIterable.Itr iterator, Scriptable thisObj, Capability cap) {
/* 244 */     Callable resolve = ScriptRuntime.getPropFunctionAndThis(thisObj, "resolve", cx, scope);
/* 245 */     Scriptable localThis = ScriptRuntime.lastStoredScriptable(cx);
/*     */     
/*     */     while (true) {
/*     */       boolean hasNext;
/*     */       
/* 250 */       Object nextVal = Undefined.instance;
/* 251 */       boolean nextOk = false;
/*     */       try {
/* 253 */         hasNext = iterator.hasNext();
/* 254 */         if (hasNext) {
/* 255 */           nextVal = iterator.next();
/*     */         }
/* 257 */         nextOk = true;
/*     */       } finally {
/* 259 */         if (!nextOk) {
/* 260 */           iterator.setDone(true);
/*     */         }
/*     */       } 
/*     */       
/* 264 */       if (!hasNext) {
/* 265 */         return cap.promise;
/*     */       }
/*     */ 
/*     */       
/* 269 */       Object nextPromise = resolve.call(cx, scope, localThis, new Object[] { nextVal });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 274 */       Callable thenFunc = ScriptRuntime.getPropFunctionAndThis(nextPromise, "then", cx, scope);
/* 275 */       thenFunc.call(cx, scope, 
/*     */ 
/*     */           
/* 278 */           ScriptRuntime.lastStoredScriptable(cx), new Object[] { cap.resolve, cap.reject });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object then(Context cx, Scriptable scope, LambdaConstructor defaultConstructor, Object[] args) {
/* 287 */     Constructable constructable = AbstractEcmaObjectOperations.speciesConstructor(cx, this, defaultConstructor);
/* 288 */     Capability capability = new Capability(cx, scope, constructable);
/*     */     
/* 290 */     Callable onFulfilled = null;
/* 291 */     if (args.length >= 1 && args[0] instanceof Callable) {
/* 292 */       onFulfilled = (Callable)args[0];
/*     */     }
/* 294 */     Callable onRejected = null;
/* 295 */     if (args.length >= 2 && args[1] instanceof Callable) {
/* 296 */       onRejected = (Callable)args[1];
/*     */     }
/*     */     
/* 299 */     Reaction fulfillReaction = new Reaction(capability, ReactionType.FULFILL, onFulfilled);
/* 300 */     Reaction rejectReaction = new Reaction(capability, ReactionType.REJECT, onRejected);
/*     */     
/* 302 */     if (this.state == State.PENDING) {
/* 303 */       this.fulfillReactions.add(fulfillReaction);
/* 304 */       this.rejectReactions.add(rejectReaction);
/* 305 */     } else if (this.state == State.FULFILLED) {
/* 306 */       cx.enqueueMicrotask(() -> fulfillReaction.invoke(cx, scope, this.result));
/*     */     } else {
/* 308 */       assert this.state == State.REJECTED;
/* 309 */       if (!this.handled) {
/* 310 */         cx.getUnhandledPromiseTracker().promiseHandled(this);
/*     */       }
/* 312 */       cx.enqueueMicrotask(() -> rejectReaction.invoke(cx, scope, this.result));
/*     */     } 
/* 314 */     this.handled = true;
/* 315 */     return capability.promise;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object doCatch(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 320 */     Object arg = (args.length > 0) ? args[0] : Undefined.instance;
/* 321 */     Scriptable coercedThis = ScriptRuntime.toObject(cx, scope, thisObj);
/*     */     
/* 323 */     Callable thenFunc = ScriptRuntime.getPropFunctionAndThis(coercedThis, "then", cx, scope);
/* 324 */     return thenFunc.call(cx, scope, 
/*     */ 
/*     */         
/* 327 */         ScriptRuntime.lastStoredScriptable(cx), new Object[] { Undefined.instance, arg });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object doFinally(Context cx, Scriptable scope, Scriptable thisObj, LambdaConstructor defaultConstructor, Object[] args) {
/* 338 */     if (!ScriptRuntime.isObject(thisObj)) {
/* 339 */       throw ScriptRuntime.typeErrorById("msg.arg.not.object", new Object[] { ScriptRuntime.typeof(thisObj) });
/*     */     }
/* 341 */     Object onFinally = (args.length > 0) ? args[0] : Undefined.SCRIPTABLE_UNDEFINED;
/* 342 */     Object thenFinally = onFinally;
/* 343 */     Object catchFinally = onFinally;
/*     */     
/* 345 */     Constructable constructor = AbstractEcmaObjectOperations.speciesConstructor(cx, thisObj, defaultConstructor);
/* 346 */     if (onFinally instanceof Callable) {
/* 347 */       Callable callableOnFinally = (Callable)thenFinally;
/* 348 */       thenFinally = makeThenFinally(scope, constructor, callableOnFinally);
/* 349 */       catchFinally = makeCatchFinally(scope, constructor, callableOnFinally);
/*     */     } 
/* 351 */     Callable thenFunc = ScriptRuntime.getPropFunctionAndThis(thisObj, "then", cx, scope);
/* 352 */     Scriptable to = ScriptRuntime.lastStoredScriptable(cx);
/* 353 */     return thenFunc.call(cx, scope, to, new Object[] { thenFinally, catchFinally });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Callable makeThenFinally(Scriptable scope, Object constructor, Callable onFinally) {
/* 359 */     return new LambdaFunction(scope, 1, (cx, ls, thisObj, args) -> {
/*     */           Object value = (args.length > 0) ? args[0] : Undefined.instance;
/*     */           LambdaFunction valueThunk = new LambdaFunction(scope, 0, ());
/*     */           Object result = onFinally.call(cx, ls, Undefined.SCRIPTABLE_UNDEFINED, ScriptRuntime.emptyArgs);
/*     */           Object promise = resolveInternal(cx, scope, constructor, result);
/*     */           Callable thenFunc = ScriptRuntime.getPropFunctionAndThis(promise, "then", cx, scope);
/*     */           return thenFunc.call(cx, scope, ScriptRuntime.lastStoredScriptable(cx), new Object[] { valueThunk });
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Callable makeCatchFinally(Scriptable scope, Object constructor, Callable onFinally) {
/* 390 */     return new LambdaFunction(scope, 1, (cx, ls, thisObj, args) -> {
/*     */           Object reason = (args.length > 0) ? args[0] : Undefined.instance;
/*     */           LambdaFunction reasonThrower = new LambdaFunction(scope, 0, ());
/*     */           Object result = onFinally.call(cx, ls, Undefined.SCRIPTABLE_UNDEFINED, ScriptRuntime.emptyArgs);
/*     */           Object promise = resolveInternal(cx, scope, constructor, result);
/*     */           Callable thenFunc = ScriptRuntime.getPropFunctionAndThis(promise, "then", cx, scope);
/*     */           return thenFunc.call(cx, scope, ScriptRuntime.lastStoredScriptable(cx), new Object[] { reasonThrower });
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object fulfillPromise(Context cx, Scriptable scope, Object value) {
/* 421 */     assert this.state == State.PENDING;
/* 422 */     this.result = value;
/* 423 */     ArrayList<Reaction> reactions = this.fulfillReactions;
/* 424 */     this.fulfillReactions = new ArrayList<>();
/* 425 */     if (!this.rejectReactions.isEmpty()) {
/* 426 */       this.rejectReactions = new ArrayList<>();
/*     */     }
/* 428 */     this.state = State.FULFILLED;
/* 429 */     for (Reaction r : reactions) {
/* 430 */       cx.enqueueMicrotask(() -> r.invoke(cx, scope, value));
/*     */     }
/* 432 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object rejectPromise(Context cx, Scriptable scope, Object reason) {
/* 437 */     assert this.state == State.PENDING;
/* 438 */     this.result = reason;
/* 439 */     ArrayList<Reaction> reactions = this.rejectReactions;
/* 440 */     this.rejectReactions = new ArrayList<>();
/* 441 */     if (!this.fulfillReactions.isEmpty()) {
/* 442 */       this.fulfillReactions = new ArrayList<>();
/*     */     }
/* 444 */     this.state = State.REJECTED;
/* 445 */     cx.getUnhandledPromiseTracker().promiseRejected(this);
/* 446 */     for (Reaction r : reactions) {
/* 447 */       cx.enqueueMicrotask(() -> r.invoke(cx, scope, reason));
/*     */     }
/* 449 */     return Undefined.instance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void callThenable(Context cx, Scriptable scope, Object resolution, Callable thenFunc) {
/* 455 */     ResolvingFunctions resolving = new ResolvingFunctions(scope, this);
/* 456 */     Scriptable thisObj = (resolution instanceof Scriptable) ? (Scriptable)resolution : Undefined.SCRIPTABLE_UNDEFINED;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 461 */       thenFunc.call(cx, scope, thisObj, new Object[] { resolving.resolve, resolving.reject });
/* 462 */     } catch (RhinoException re) {
/* 463 */       resolving.reject.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] {
/*     */ 
/*     */ 
/*     */             
/* 467 */             getErrorObject(cx, scope, re) });
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object getErrorObject(Context cx, Scriptable scope, RhinoException re) {
/* 472 */     if (re instanceof JavaScriptException) {
/* 473 */       return ((JavaScriptException)re).getValue();
/*     */     }
/*     */     
/* 476 */     TopLevel.NativeErrors constructor = TopLevel.NativeErrors.Error;
/* 477 */     if (re instanceof EcmaError) {
/* 478 */       EcmaError ee = (EcmaError)re;
/* 479 */       switch (ee.getName()) {
/*     */         case "EvalError":
/* 481 */           constructor = TopLevel.NativeErrors.EvalError;
/*     */           break;
/*     */         case "RangeError":
/* 484 */           constructor = TopLevel.NativeErrors.RangeError;
/*     */           break;
/*     */         case "ReferenceError":
/* 487 */           constructor = TopLevel.NativeErrors.ReferenceError;
/*     */           break;
/*     */         case "SyntaxError":
/* 490 */           constructor = TopLevel.NativeErrors.SyntaxError;
/*     */           break;
/*     */         case "TypeError":
/* 493 */           constructor = TopLevel.NativeErrors.TypeError;
/*     */           break;
/*     */         case "URIError":
/* 496 */           constructor = TopLevel.NativeErrors.URIError;
/*     */           break;
/*     */         case "InternalError":
/* 499 */           constructor = TopLevel.NativeErrors.InternalError;
/*     */           break;
/*     */         case "JavaException":
/* 502 */           constructor = TopLevel.NativeErrors.JavaException;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 508 */     return ScriptRuntime.newNativeError(cx, scope, constructor, new Object[] { re.getMessage() });
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ResolvingFunctions
/*     */   {
/*     */     private boolean alreadyResolved = false;
/*     */     
/*     */     LambdaFunction resolve;
/*     */     
/*     */     LambdaFunction reject;
/*     */     
/*     */     ResolvingFunctions(Scriptable topScope, NativePromise promise) {
/* 521 */       this.resolve = new LambdaFunction(topScope, 1, (cx, scope, thisObj, args) -> resolve(cx, scope, promise, (args.length > 0) ? args[0] : Undefined.instance));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 531 */       this.resolve.setStandardPropertyAttributes(3);
/* 532 */       this.reject = new LambdaFunction(topScope, 1, (cx, scope, thisObj, args) -> reject(cx, scope, promise, (args.length > 0) ? args[0] : Undefined.instance));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 542 */       this.reject.setStandardPropertyAttributes(3);
/*     */     }
/*     */     
/*     */     private Object reject(Context cx, Scriptable scope, NativePromise promise, Object reason) {
/* 546 */       if (this.alreadyResolved) {
/* 547 */         return Undefined.instance;
/*     */       }
/* 549 */       this.alreadyResolved = true;
/* 550 */       return promise.rejectPromise(cx, scope, reason);
/*     */     }
/*     */ 
/*     */     
/*     */     private Object resolve(Context cx, Scriptable scope, NativePromise promise, Object resolution) {
/* 555 */       if (this.alreadyResolved) {
/* 556 */         return Undefined.instance;
/*     */       }
/* 558 */       this.alreadyResolved = true;
/*     */       
/* 560 */       if (resolution == promise) {
/*     */         
/* 562 */         Object err = ScriptRuntime.newNativeError(cx, scope, TopLevel.NativeErrors.TypeError, new Object[] { "No promise self-resolution" });
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 567 */         return promise.rejectPromise(cx, scope, err);
/*     */       } 
/*     */       
/* 570 */       if (!ScriptRuntime.isObject(resolution)) {
/* 571 */         return promise.fulfillPromise(cx, scope, resolution);
/*     */       }
/*     */       
/* 574 */       Scriptable sresolution = ScriptableObject.ensureScriptable(resolution);
/* 575 */       Object thenObj = ScriptableObject.getProperty(sresolution, "then");
/* 576 */       if (!(thenObj instanceof Callable)) {
/* 577 */         return promise.fulfillPromise(cx, scope, resolution);
/*     */       }
/*     */       
/* 580 */       cx.enqueueMicrotask(() -> promise.callThenable(cx, scope, resolution, (Callable)thenObj));
/*     */       
/* 582 */       return Undefined.instance;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Reaction
/*     */   {
/*     */     NativePromise.Capability capability;
/* 589 */     NativePromise.ReactionType reaction = NativePromise.ReactionType.REJECT;
/*     */     Callable handler;
/*     */     
/*     */     Reaction(NativePromise.Capability cap, NativePromise.ReactionType type, Callable handler) {
/* 593 */       this.capability = cap;
/* 594 */       this.reaction = type;
/* 595 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     void invoke(Context cx, Scriptable scope, Object arg) {
/*     */       try {
/* 601 */         Object result = null;
/* 602 */         if (this.handler == null) {
/* 603 */           switch (this.reaction) {
/*     */             case FULFILL:
/* 605 */               result = arg;
/*     */               break;
/*     */             case REJECT:
/* 608 */               this.capability.reject.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] { arg });
/*     */               return;
/*     */           } 
/*     */ 
/*     */         
/*     */         } else {
/* 614 */           result = this.handler.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] { arg });
/*     */         } 
/*     */         
/* 617 */         this.capability.resolve.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] { result });
/*     */       
/*     */       }
/* 620 */       catch (RhinoException re) {
/* 621 */         this.capability.reject.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] {
/*     */ 
/*     */ 
/*     */               
/* 625 */               NativePromise.access$300(cx, scope, re)
/*     */             });
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Capability
/*     */   {
/*     */     Object promise;
/* 635 */     private Object rawResolve = Undefined.instance;
/*     */     Callable resolve;
/* 637 */     private Object rawReject = Undefined.instance;
/*     */ 
/*     */     
/*     */     Callable reject;
/*     */ 
/*     */     
/*     */     Capability(Context topCx, Scriptable topScope, Object pc) {
/* 644 */       if (!(pc instanceof Constructable)) {
/* 645 */         throw ScriptRuntime.typeErrorById("msg.constructor.expected", new Object[0]);
/*     */       }
/* 647 */       Constructable promiseConstructor = (Constructable)pc;
/* 648 */       LambdaFunction executorFunc = new LambdaFunction(topScope, 2, (cx, scope, thisObj, args) -> executor(args));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 654 */       executorFunc.setStandardPropertyAttributes(3);
/*     */       
/* 656 */       this.promise = promiseConstructor.construct(topCx, topScope, new Object[] { executorFunc });
/*     */       
/* 658 */       if (!(this.rawResolve instanceof Callable)) {
/* 659 */         throw ScriptRuntime.typeErrorById("msg.function.expected", new Object[0]);
/*     */       }
/* 661 */       this.resolve = (Callable)this.rawResolve;
/*     */       
/* 663 */       if (!(this.rawReject instanceof Callable)) {
/* 664 */         throw ScriptRuntime.typeErrorById("msg.function.expected", new Object[0]);
/*     */       }
/* 666 */       this.reject = (Callable)this.rawReject;
/*     */     }
/*     */     
/*     */     private Object executor(Object[] args) {
/* 670 */       if (!Undefined.isUndefined(this.rawResolve) || !Undefined.isUndefined(this.rawReject)) {
/* 671 */         throw ScriptRuntime.typeErrorById("msg.promise.capability.state", new Object[0]);
/*     */       }
/* 673 */       if (args.length > 0) {
/* 674 */         this.rawResolve = args[0];
/*     */       }
/* 676 */       if (args.length > 1) {
/* 677 */         this.rawReject = args[1];
/*     */       }
/* 679 */       return Undefined.instance;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class PromiseAllResolver
/*     */   {
/*     */     private static final int MAX_PROMISES = 2097152;
/*     */     
/* 688 */     final ArrayList<Object> values = new ArrayList();
/* 689 */     int remainingElements = 1;
/*     */     
/*     */     IteratorLikeIterable.Itr iterator;
/*     */     Scriptable thisObj;
/*     */     NativePromise.Capability capability;
/*     */     
/*     */     PromiseAllResolver(IteratorLikeIterable.Itr iter, Scriptable thisObj, NativePromise.Capability cap) {
/* 696 */       this.iterator = iter;
/* 697 */       this.thisObj = thisObj;
/* 698 */       this.capability = cap;
/*     */     }
/*     */     
/*     */     Object resolve(Context topCx, Scriptable topScope) {
/* 702 */       int index = 0;
/*     */ 
/*     */ 
/*     */       
/* 706 */       Callable resolve = ScriptRuntime.getPropFunctionAndThis(this.thisObj, "resolve", topCx, topScope);
/* 707 */       Scriptable storedThis = ScriptRuntime.lastStoredScriptable(topCx);
/*     */       
/*     */       while (true) {
/*     */         boolean hasNext;
/* 711 */         if (index == 2097152) {
/* 712 */           throw ScriptRuntime.rangeErrorById("msg.promise.all.toobig", new Object[0]);
/*     */         }
/*     */         
/* 715 */         Object nextVal = Undefined.instance;
/* 716 */         boolean nextOk = false;
/*     */         try {
/* 718 */           hasNext = this.iterator.hasNext();
/* 719 */           if (hasNext) {
/* 720 */             nextVal = this.iterator.next();
/*     */           }
/* 722 */           nextOk = true;
/*     */         } finally {
/* 724 */           if (!nextOk) {
/* 725 */             this.iterator.setDone(true);
/*     */           }
/*     */         } 
/*     */         
/* 729 */         if (!hasNext) {
/* 730 */           if (--this.remainingElements == 0) {
/* 731 */             finalResolution(topCx, topScope);
/*     */           }
/* 733 */           return this.capability.promise;
/*     */         } 
/*     */         
/* 736 */         this.values.add(Undefined.instance);
/*     */ 
/*     */ 
/*     */         
/* 740 */         Object nextPromise = resolve.call(topCx, topScope, storedThis, new Object[] { nextVal });
/*     */ 
/*     */         
/* 743 */         NativePromise.PromiseElementResolver eltResolver = new NativePromise.PromiseElementResolver(index);
/* 744 */         LambdaFunction resolveFunc = new LambdaFunction(topScope, 1, (cx, scope, thisObj, args) -> eltResolver.resolve(cx, scope, (args.length > 0) ? args[0] : Undefined.instance, this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 754 */         resolveFunc.setStandardPropertyAttributes(3);
/* 755 */         this.remainingElements++;
/*     */ 
/*     */ 
/*     */         
/* 759 */         Callable thenFunc = ScriptRuntime.getPropFunctionAndThis(nextPromise, "then", topCx, topScope);
/* 760 */         thenFunc.call(topCx, topScope, 
/*     */ 
/*     */             
/* 763 */             ScriptRuntime.lastStoredScriptable(topCx), new Object[] { resolveFunc, this.capability.reject });
/*     */         
/* 765 */         index++;
/*     */       } 
/*     */     }
/*     */     
/*     */     void finalResolution(Context cx, Scriptable scope) {
/* 770 */       Scriptable newArray = cx.newArray(scope, this.values.toArray());
/* 771 */       this.capability.resolve.call(cx, scope, Undefined.SCRIPTABLE_UNDEFINED, new Object[] { newArray });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class PromiseElementResolver
/*     */   {
/*     */     private boolean alreadyCalled = false;
/*     */     
/*     */     private final int index;
/*     */     
/*     */     PromiseElementResolver(int ix) {
/* 783 */       this.index = ix;
/*     */     }
/*     */     
/*     */     Object resolve(Context cx, Scriptable scope, Object result, NativePromise.PromiseAllResolver resolver) {
/* 787 */       if (this.alreadyCalled) {
/* 788 */         return Undefined.instance;
/*     */       }
/* 790 */       this.alreadyCalled = true;
/* 791 */       resolver.values.set(this.index, result);
/* 792 */       if (--resolver.remainingElements == 0) {
/* 793 */         resolver.finalResolution(cx, scope);
/*     */       }
/* 795 */       return Undefined.instance;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\NativePromise.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */