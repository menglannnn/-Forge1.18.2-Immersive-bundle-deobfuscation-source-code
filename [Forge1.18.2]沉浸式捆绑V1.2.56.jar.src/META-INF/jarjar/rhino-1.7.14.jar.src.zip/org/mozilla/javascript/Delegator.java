/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Delegator
/*     */   implements Function, SymbolScriptable
/*     */ {
/*  29 */   protected Scriptable obj = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Delegator() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Delegator(Scriptable obj) {
/*  50 */     this.obj = obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Delegator newInstance() {
/*     */     try {
/*  62 */       return (Delegator)getClass().newInstance();
/*  63 */     } catch (Exception ex) {
/*  64 */       throw Context.throwAsScriptRuntimeEx(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getDelegee() {
/*  74 */     return this.obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelegee(Scriptable obj) {
/*  84 */     this.obj = obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/*  92 */     return getDelegee().getClassName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String name, Scriptable start) {
/* 100 */     return getDelegee().get(name, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Symbol key, Scriptable start) {
/* 105 */     Scriptable delegee = getDelegee();
/* 106 */     if (delegee instanceof SymbolScriptable) {
/* 107 */       return ((SymbolScriptable)delegee).get(key, start);
/*     */     }
/* 109 */     return Scriptable.NOT_FOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int index, Scriptable start) {
/* 117 */     return getDelegee().get(index, start);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(String name, Scriptable start) {
/* 125 */     return getDelegee().has(name, start);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean has(Symbol key, Scriptable start) {
/* 130 */     Scriptable delegee = getDelegee();
/* 131 */     if (delegee instanceof SymbolScriptable) {
/* 132 */       return ((SymbolScriptable)delegee).has(key, start);
/*     */     }
/* 134 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(int index, Scriptable start) {
/* 142 */     return getDelegee().has(index, start);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String name, Scriptable start, Object value) {
/* 150 */     getDelegee().put(name, start, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Symbol symbol, Scriptable start, Object value) {
/* 158 */     Scriptable delegee = getDelegee();
/* 159 */     if (delegee instanceof SymbolScriptable) {
/* 160 */       ((SymbolScriptable)delegee).put(symbol, start, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(int index, Scriptable start, Object value) {
/* 169 */     getDelegee().put(index, start, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(String name) {
/* 177 */     getDelegee().delete(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(Symbol key) {
/* 182 */     Scriptable delegee = getDelegee();
/* 183 */     if (delegee instanceof SymbolScriptable) {
/* 184 */       ((SymbolScriptable)delegee).delete(key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int index) {
/* 193 */     getDelegee().delete(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getPrototype() {
/* 201 */     return getDelegee().getPrototype();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrototype(Scriptable prototype) {
/* 209 */     getDelegee().setPrototype(prototype);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable getParentScope() {
/* 217 */     return getDelegee().getParentScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentScope(Scriptable parent) {
/* 225 */     getDelegee().setParentScope(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getIds() {
/* 233 */     return getDelegee().getIds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDefaultValue(Class<?> hint) {
/* 250 */     return (hint == null || hint == ScriptRuntime.ScriptableClass || hint == ScriptRuntime.FunctionClass) ? this : 
/*     */ 
/*     */       
/* 253 */       getDelegee().getDefaultValue(hint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasInstance(Scriptable instance) {
/* 261 */     return getDelegee().hasInstance(instance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args) {
/* 271 */     return ((Function)getDelegee()).call(cx, scope, thisObj, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scriptable construct(Context cx, Scriptable scope, Object[] args) {
/* 292 */     Scriptable myDelegee = getDelegee();
/* 293 */     if (myDelegee == null) {
/*     */       Scriptable delegee;
/* 295 */       Delegator n = newInstance();
/*     */       
/* 297 */       if (args.length == 0) {
/* 298 */         delegee = new NativeObject();
/*     */       } else {
/* 300 */         delegee = ScriptRuntime.toObject(cx, scope, args[0]);
/*     */       } 
/* 302 */       n.setDelegee(delegee);
/* 303 */       return n;
/*     */     } 
/* 305 */     return ((Function)myDelegee).construct(cx, scope, args);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Delegator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */