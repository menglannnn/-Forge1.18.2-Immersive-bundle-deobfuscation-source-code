/*     */ package org.mozilla.javascript.jdk18;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ContextFactory;
/*     */ import org.mozilla.javascript.InterfaceAdapter;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.VMBridge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VMBridge_jdk18
/*     */   extends VMBridge
/*     */ {
/*  24 */   private static final ThreadLocal<Object[]> contextLocal = new ThreadLocal();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getThreadContextHelper() {
/*  38 */     Object[] storage = contextLocal.get();
/*  39 */     if (storage == null) {
/*  40 */       storage = new Object[1];
/*  41 */       contextLocal.set(storage);
/*     */     } 
/*  43 */     return storage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Context getContext(Object contextHelper) {
/*  49 */     Object[] storage = (Object[])contextHelper;
/*  50 */     return (Context)storage[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setContext(Object contextHelper, Context cx) {
/*  56 */     Object[] storage = (Object[])contextHelper;
/*  57 */     storage[0] = cx;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean tryToMakeAccessible(AccessibleObject accessible) {
/*  63 */     if (accessible.isAccessible()) {
/*  64 */       return true;
/*     */     }
/*     */     try {
/*  67 */       accessible.setAccessible(true);
/*  68 */     } catch (Exception exception) {}
/*     */     
/*  70 */     return accessible.isAccessible();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getInterfaceProxyHelper(ContextFactory cf, Class<?>[] interfaces) {
/*     */     Constructor<?> c;
/*  79 */     ClassLoader loader = interfaces[0].getClassLoader();
/*  80 */     Class<?> cl = Proxy.getProxyClass(loader, interfaces);
/*     */     
/*     */     try {
/*  83 */       c = cl.getConstructor(new Class[] { InvocationHandler.class });
/*  84 */     } catch (NoSuchMethodException ex) {
/*     */       
/*  86 */       throw new IllegalStateException(ex);
/*     */     } 
/*  88 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object newInterfaceProxy(Object proxyHelper, final ContextFactory cf, final InterfaceAdapter adapter, final Object target, final Scriptable topScope) {
/*     */     Object proxy;
/*  98 */     Constructor<?> c = (Constructor)proxyHelper;
/*     */     
/* 100 */     InvocationHandler handler = new InvocationHandler()
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object invoke(Object proxy, Method method, Object[] args)
/*     */         {
/* 109 */           if (method.getDeclaringClass() == Object.class) {
/* 110 */             String methodName = method.getName();
/* 111 */             if (methodName.equals("equals")) {
/* 112 */               Object other = args[0];
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 117 */               return Boolean.valueOf((proxy == other));
/*     */             } 
/* 119 */             if (methodName.equals("hashCode")) {
/* 120 */               return Integer.valueOf(target.hashCode());
/*     */             }
/* 122 */             if (methodName.equals("toString")) {
/* 123 */               return "Proxy[" + target.toString() + "]";
/*     */             }
/*     */           } 
/* 126 */           return adapter.invoke(cf, target, topScope, proxy, method, args);
/*     */         }
/*     */       };
/*     */     
/*     */     try {
/* 131 */       proxy = c.newInstance(new Object[] { handler });
/* 132 */     } catch (InvocationTargetException ex) {
/* 133 */       throw Context.throwAsScriptRuntimeEx(ex);
/* 134 */     } catch (IllegalAccessException ex) {
/*     */       
/* 136 */       throw new IllegalStateException(ex);
/* 137 */     } catch (InstantiationException ex) {
/*     */       
/* 139 */       throw new IllegalStateException(ex);
/*     */     } 
/* 141 */     return proxy;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\jdk18\VMBridge_jdk18.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */