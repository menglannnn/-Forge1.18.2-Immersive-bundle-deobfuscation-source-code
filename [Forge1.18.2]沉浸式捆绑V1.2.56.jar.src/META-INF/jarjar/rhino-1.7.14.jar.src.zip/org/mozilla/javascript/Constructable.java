package org.mozilla.javascript;

public interface Constructable {
  Scriptable construct(Context paramContext, Scriptable paramScriptable, Object[] paramArrayOfObject);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\Constructable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */