/*    */ package org.mozilla.javascript;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ScriptStackElement
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6416688260860477449L;
/*    */   public final String fileName;
/*    */   public final String functionName;
/*    */   public final int lineNumber;
/*    */   
/*    */   public ScriptStackElement(String fileName, String functionName, int lineNumber) {
/* 24 */     this.fileName = fileName;
/* 25 */     this.functionName = functionName;
/* 26 */     this.lineNumber = lineNumber;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 31 */     StringBuilder sb = new StringBuilder();
/* 32 */     renderMozillaStyle(sb);
/* 33 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderJavaStyle(StringBuilder sb) {
/* 43 */     sb.append("\tat ").append(this.fileName);
/* 44 */     if (this.lineNumber > -1) {
/* 45 */       sb.append(':').append(this.lineNumber);
/*    */     }
/* 47 */     if (this.functionName != null) {
/* 48 */       sb.append(" (").append(this.functionName).append(')');
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderMozillaStyle(StringBuilder sb) {
/* 59 */     if (this.functionName != null) {
/* 60 */       sb.append(this.functionName).append("()");
/*    */     }
/* 62 */     sb.append('@').append(this.fileName);
/* 63 */     if (this.lineNumber > -1) {
/* 64 */       sb.append(':').append(this.lineNumber);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderV8Style(StringBuilder sb) {
/* 77 */     sb.append("    at ");
/*    */     
/* 79 */     if (this.functionName == null || "anonymous".equals(this.functionName) || "undefined"
/* 80 */       .equals(this.functionName)) {
/*    */       
/* 82 */       appendV8Location(sb);
/*    */     } else {
/*    */       
/* 85 */       sb.append(this.functionName).append(" (");
/* 86 */       appendV8Location(sb);
/* 87 */       sb.append(')');
/*    */     } 
/*    */   }
/*    */   
/*    */   private void appendV8Location(StringBuilder sb) {
/* 92 */     sb.append(this.fileName).append(':');
/* 93 */     sb.append((this.lineNumber > -1) ? this.lineNumber : 0).append(":0");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ScriptStackElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */