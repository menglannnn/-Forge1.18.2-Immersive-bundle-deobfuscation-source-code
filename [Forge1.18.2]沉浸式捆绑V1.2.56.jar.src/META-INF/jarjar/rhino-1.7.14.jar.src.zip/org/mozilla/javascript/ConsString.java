/*     */ package org.mozilla.javascript;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayDeque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConsString
/*     */   implements CharSequence, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8432806714471372570L;
/*     */   private CharSequence left;
/*     */   private CharSequence right;
/*     */   private final int length;
/*     */   private boolean isFlat;
/*     */   
/*     */   public ConsString(CharSequence str1, CharSequence str2) {
/*  37 */     this.left = str1;
/*  38 */     this.right = str2;
/*  39 */     this.length = this.left.length() + this.right.length();
/*  40 */     this.isFlat = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object writeReplace() {
/*  45 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  50 */     return this.isFlat ? (String)this.left : flatten();
/*     */   }
/*     */   
/*     */   private synchronized String flatten() {
/*  54 */     if (!this.isFlat) {
/*  55 */       char[] chars = new char[this.length];
/*  56 */       int charPos = this.length;
/*     */       
/*  58 */       ArrayDeque<CharSequence> stack = new ArrayDeque<>();
/*  59 */       stack.addFirst(this.left);
/*     */       
/*  61 */       CharSequence next = this.right;
/*     */       while (true) {
/*  63 */         if (next instanceof ConsString)
/*  64 */         { ConsString casted = (ConsString)next;
/*  65 */           if (casted.isFlat)
/*  66 */           { next = casted.left; }
/*     */           else
/*  68 */           { stack.addFirst(casted.left);
/*  69 */             next = casted.right;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  78 */             if (next == null) break;  }  }  String str = (String)next; charPos -= str.length(); str.getChars(0, str.length(), chars, charPos); next = stack.isEmpty() ? null : stack.removeFirst(); if (next == null)
/*     */           break; 
/*  80 */       }  this.left = new String(chars);
/*  81 */       this.right = "";
/*  82 */       this.isFlat = true;
/*     */     } 
/*  84 */     return (String)this.left;
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  89 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/*  94 */     String str = this.isFlat ? (String)this.left : flatten();
/*  95 */     return str.charAt(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/* 100 */     String str = this.isFlat ? (String)this.left : flatten();
/* 101 */     return str.substring(start, end);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\rhino-1.7.14.jar!\org\mozilla\javascript\ConsString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */