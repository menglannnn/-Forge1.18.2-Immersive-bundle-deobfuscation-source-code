/*     */ package io.netty.util;
/*     */ 
/*     */ import io.netty.util.concurrent.ImmediateExecutor;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HashedWheelTimer
/*     */   implements Timer
/*     */ {
/*  88 */   static final InternalLogger logger = InternalLoggerFactory.getInstance(HashedWheelTimer.class);
/*     */   
/*  90 */   private static final AtomicInteger INSTANCE_COUNTER = new AtomicInteger();
/*  91 */   private static final AtomicBoolean WARNED_TOO_MANY_INSTANCES = new AtomicBoolean();
/*     */   private static final int INSTANCE_COUNT_LIMIT = 64;
/*  93 */   private static final long MILLISECOND_NANOS = TimeUnit.MILLISECONDS.toNanos(1L);
/*  94 */   private static final ResourceLeakDetector<HashedWheelTimer> leakDetector = ResourceLeakDetectorFactory.instance()
/*  95 */     .newResourceLeakDetector(HashedWheelTimer.class, 1);
/*     */ 
/*     */   
/*  98 */   private static final AtomicIntegerFieldUpdater<HashedWheelTimer> WORKER_STATE_UPDATER = AtomicIntegerFieldUpdater.newUpdater(HashedWheelTimer.class, "workerState");
/*     */   
/*     */   private final ResourceLeakTracker<HashedWheelTimer> leak;
/* 101 */   private final Worker worker = new Worker();
/*     */   
/*     */   private final Thread workerThread;
/*     */   
/*     */   public static final int WORKER_STATE_INIT = 0;
/*     */   
/*     */   public static final int WORKER_STATE_STARTED = 1;
/*     */   public static final int WORKER_STATE_SHUTDOWN = 2;
/*     */   private volatile int workerState;
/*     */   private final long tickDuration;
/*     */   private final HashedWheelBucket[] wheel;
/*     */   private final int mask;
/* 113 */   private final CountDownLatch startTimeInitialized = new CountDownLatch(1);
/* 114 */   private final Queue<HashedWheelTimeout> timeouts = PlatformDependent.newMpscQueue();
/* 115 */   private final Queue<HashedWheelTimeout> cancelledTimeouts = PlatformDependent.newMpscQueue();
/* 116 */   private final AtomicLong pendingTimeouts = new AtomicLong(0L);
/*     */ 
/*     */   
/*     */   private final long maxPendingTimeouts;
/*     */ 
/*     */   
/*     */   private final Executor taskExecutor;
/*     */   
/*     */   private volatile long startTime;
/*     */ 
/*     */   
/*     */   public HashedWheelTimer() {
/* 128 */     this(Executors.defaultThreadFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashedWheelTimer(long tickDuration, TimeUnit unit) {
/* 142 */     this(Executors.defaultThreadFactory(), tickDuration, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashedWheelTimer(long tickDuration, TimeUnit unit, int ticksPerWheel) {
/* 156 */     this(Executors.defaultThreadFactory(), tickDuration, unit, ticksPerWheel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashedWheelTimer(ThreadFactory threadFactory) {
/* 169 */     this(threadFactory, 100L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashedWheelTimer(ThreadFactory threadFactory, long tickDuration, TimeUnit unit) {
/* 185 */     this(threadFactory, tickDuration, unit, 512);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashedWheelTimer(ThreadFactory threadFactory, long tickDuration, TimeUnit unit, int ticksPerWheel) {
/* 203 */     this(threadFactory, tickDuration, unit, ticksPerWheel, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashedWheelTimer(ThreadFactory threadFactory, long tickDuration, TimeUnit unit, int ticksPerWheel, boolean leakDetection) {
/* 224 */     this(threadFactory, tickDuration, unit, ticksPerWheel, leakDetection, -1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashedWheelTimer(ThreadFactory threadFactory, long tickDuration, TimeUnit unit, int ticksPerWheel, boolean leakDetection, long maxPendingTimeouts) {
/* 251 */     this(threadFactory, tickDuration, unit, ticksPerWheel, leakDetection, maxPendingTimeouts, (Executor)ImmediateExecutor.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashedWheelTimer(ThreadFactory threadFactory, long tickDuration, TimeUnit unit, int ticksPerWheel, boolean leakDetection, long maxPendingTimeouts, Executor taskExecutor) {
/* 282 */     ObjectUtil.checkNotNull(threadFactory, "threadFactory");
/* 283 */     ObjectUtil.checkNotNull(unit, "unit");
/* 284 */     ObjectUtil.checkPositive(tickDuration, "tickDuration");
/* 285 */     ObjectUtil.checkPositive(ticksPerWheel, "ticksPerWheel");
/* 286 */     this.taskExecutor = (Executor)ObjectUtil.checkNotNull(taskExecutor, "taskExecutor");
/*     */ 
/*     */     
/* 289 */     this.wheel = createWheel(ticksPerWheel);
/* 290 */     this.mask = this.wheel.length - 1;
/*     */ 
/*     */     
/* 293 */     long duration = unit.toNanos(tickDuration);
/*     */ 
/*     */     
/* 296 */     if (duration >= Long.MAX_VALUE / this.wheel.length) {
/* 297 */       throw new IllegalArgumentException(String.format("tickDuration: %d (expected: 0 < tickDuration in nanos < %d", new Object[] {
/*     */               
/* 299 */               Long.valueOf(tickDuration), Long.valueOf(Long.MAX_VALUE / this.wheel.length)
/*     */             }));
/*     */     }
/* 302 */     if (duration < MILLISECOND_NANOS) {
/* 303 */       logger.warn("Configured tickDuration {} smaller than {}, using 1ms.", 
/* 304 */           Long.valueOf(tickDuration), Long.valueOf(MILLISECOND_NANOS));
/* 305 */       this.tickDuration = MILLISECOND_NANOS;
/*     */     } else {
/* 307 */       this.tickDuration = duration;
/*     */     } 
/*     */     
/* 310 */     this.workerThread = threadFactory.newThread(this.worker);
/*     */     
/* 312 */     this.leak = (leakDetection || !this.workerThread.isDaemon()) ? leakDetector.track(this) : null;
/*     */     
/* 314 */     this.maxPendingTimeouts = maxPendingTimeouts;
/*     */     
/* 316 */     if (INSTANCE_COUNTER.incrementAndGet() > 64 && WARNED_TOO_MANY_INSTANCES
/* 317 */       .compareAndSet(false, true)) {
/* 318 */       reportTooManyInstances();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/*     */     try {
/* 325 */       super.finalize();
/*     */     }
/*     */     finally {
/*     */       
/* 329 */       if (WORKER_STATE_UPDATER.getAndSet(this, 2) != 2) {
/* 330 */         INSTANCE_COUNTER.decrementAndGet();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static HashedWheelBucket[] createWheel(int ticksPerWheel) {
/* 337 */     ObjectUtil.checkInRange(ticksPerWheel, 1, 1073741824, "ticksPerWheel");
/*     */     
/* 339 */     ticksPerWheel = normalizeTicksPerWheel(ticksPerWheel);
/* 340 */     HashedWheelBucket[] wheel = new HashedWheelBucket[ticksPerWheel];
/* 341 */     for (int i = 0; i < wheel.length; i++) {
/* 342 */       wheel[i] = new HashedWheelBucket();
/*     */     }
/* 344 */     return wheel;
/*     */   }
/*     */   
/*     */   private static int normalizeTicksPerWheel(int ticksPerWheel) {
/* 348 */     int normalizedTicksPerWheel = 1;
/* 349 */     while (normalizedTicksPerWheel < ticksPerWheel) {
/* 350 */       normalizedTicksPerWheel <<= 1;
/*     */     }
/* 352 */     return normalizedTicksPerWheel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 363 */     switch (WORKER_STATE_UPDATER.get((T)this)) {
/*     */       case 0:
/* 365 */         if (WORKER_STATE_UPDATER.compareAndSet(this, 0, 1)) {
/* 366 */           this.workerThread.start();
/*     */         }
/*     */         break;
/*     */       case 1:
/*     */         break;
/*     */       case 2:
/* 372 */         throw new IllegalStateException("cannot be started once stopped");
/*     */       default:
/* 374 */         throw new Error("Invalid WorkerState");
/*     */     } 
/*     */ 
/*     */     
/* 378 */     while (this.startTime == 0L) {
/*     */       try {
/* 380 */         this.startTimeInitialized.await();
/* 381 */       } catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Timeout> stop() {
/* 389 */     if (Thread.currentThread() == this.workerThread) {
/* 390 */       throw new IllegalStateException(HashedWheelTimer.class
/* 391 */           .getSimpleName() + ".stop() cannot be called from " + TimerTask.class
/*     */           
/* 393 */           .getSimpleName());
/*     */     }
/*     */     
/* 396 */     if (!WORKER_STATE_UPDATER.compareAndSet(this, 1, 2)) {
/*     */       
/* 398 */       if (WORKER_STATE_UPDATER.getAndSet(this, 2) != 2) {
/* 399 */         INSTANCE_COUNTER.decrementAndGet();
/* 400 */         if (this.leak != null) {
/* 401 */           boolean closed = this.leak.close(this);
/* 402 */           assert closed;
/*     */         } 
/*     */       } 
/*     */       
/* 406 */       return Collections.emptySet();
/*     */     } 
/*     */     
/*     */     try {
/* 410 */       boolean interrupted = false;
/* 411 */       while (this.workerThread.isAlive()) {
/* 412 */         this.workerThread.interrupt();
/*     */         try {
/* 414 */           this.workerThread.join(100L);
/* 415 */         } catch (InterruptedException ignored) {
/* 416 */           interrupted = true;
/*     */         } 
/*     */       } 
/*     */       
/* 420 */       if (interrupted) {
/* 421 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     } finally {
/* 424 */       INSTANCE_COUNTER.decrementAndGet();
/* 425 */       if (this.leak != null) {
/* 426 */         boolean closed = this.leak.close(this);
/* 427 */         assert closed;
/*     */       } 
/*     */     } 
/* 430 */     return this.worker.unprocessedTimeouts();
/*     */   }
/*     */ 
/*     */   
/*     */   public Timeout newTimeout(TimerTask task, long delay, TimeUnit unit) {
/* 435 */     ObjectUtil.checkNotNull(task, "task");
/* 436 */     ObjectUtil.checkNotNull(unit, "unit");
/*     */     
/* 438 */     long pendingTimeoutsCount = this.pendingTimeouts.incrementAndGet();
/*     */     
/* 440 */     if (this.maxPendingTimeouts > 0L && pendingTimeoutsCount > this.maxPendingTimeouts) {
/* 441 */       this.pendingTimeouts.decrementAndGet();
/* 442 */       throw new RejectedExecutionException("Number of pending timeouts (" + pendingTimeoutsCount + ") is greater than or equal to maximum allowed pending timeouts (" + this.maxPendingTimeouts + ")");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 447 */     start();
/*     */ 
/*     */ 
/*     */     
/* 451 */     long deadline = System.nanoTime() + unit.toNanos(delay) - this.startTime;
/*     */ 
/*     */     
/* 454 */     if (delay > 0L && deadline < 0L) {
/* 455 */       deadline = Long.MAX_VALUE;
/*     */     }
/* 457 */     HashedWheelTimeout timeout = new HashedWheelTimeout(this, task, deadline);
/* 458 */     this.timeouts.add(timeout);
/* 459 */     return timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long pendingTimeouts() {
/* 466 */     return this.pendingTimeouts.get();
/*     */   }
/*     */   
/*     */   private static void reportTooManyInstances() {
/* 470 */     if (logger.isErrorEnabled()) {
/* 471 */       String resourceType = StringUtil.simpleClassName(HashedWheelTimer.class);
/* 472 */       logger.error("You are creating too many " + resourceType + " instances. " + resourceType + " is a shared resource that must be reused across the JVM, so that only a few instances are created.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private final class Worker
/*     */     implements Runnable
/*     */   {
/* 479 */     private final Set<Timeout> unprocessedTimeouts = new HashSet<Timeout>();
/*     */ 
/*     */     
/*     */     private long tick;
/*     */ 
/*     */     
/*     */     public void run() {
/* 486 */       HashedWheelTimer.this.startTime = System.nanoTime();
/* 487 */       if (HashedWheelTimer.this.startTime == 0L)
/*     */       {
/* 489 */         HashedWheelTimer.this.startTime = 1L;
/*     */       }
/*     */ 
/*     */       
/* 493 */       HashedWheelTimer.this.startTimeInitialized.countDown();
/*     */       
/*     */       do {
/* 496 */         long deadline = waitForNextTick();
/* 497 */         if (deadline <= 0L)
/* 498 */           continue;  int idx = (int)(this.tick & HashedWheelTimer.this.mask);
/* 499 */         processCancelledTasks();
/*     */         
/* 501 */         HashedWheelTimer.HashedWheelBucket bucket = HashedWheelTimer.this.wheel[idx];
/* 502 */         transferTimeoutsToBuckets();
/* 503 */         bucket.expireTimeouts(deadline);
/* 504 */         this.tick++;
/*     */       }
/* 506 */       while (HashedWheelTimer.WORKER_STATE_UPDATER.get(HashedWheelTimer.this) == 1);
/*     */ 
/*     */       
/* 509 */       for (HashedWheelTimer.HashedWheelBucket bucket : HashedWheelTimer.this.wheel) {
/* 510 */         bucket.clearTimeouts(this.unprocessedTimeouts);
/*     */       }
/*     */       while (true) {
/* 513 */         HashedWheelTimer.HashedWheelTimeout timeout = HashedWheelTimer.this.timeouts.poll();
/* 514 */         if (timeout == null) {
/*     */           break;
/*     */         }
/* 517 */         if (!timeout.isCancelled()) {
/* 518 */           this.unprocessedTimeouts.add(timeout);
/*     */         }
/*     */       } 
/* 521 */       processCancelledTasks();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void transferTimeoutsToBuckets() {
/* 527 */       for (int i = 0; i < 100000; i++) {
/* 528 */         HashedWheelTimer.HashedWheelTimeout timeout = HashedWheelTimer.this.timeouts.poll();
/* 529 */         if (timeout == null) {
/*     */           break;
/*     */         }
/*     */         
/* 533 */         if (timeout.state() != 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 538 */           long calculated = timeout.deadline / HashedWheelTimer.this.tickDuration;
/* 539 */           timeout.remainingRounds = (calculated - this.tick) / HashedWheelTimer.this.wheel.length;
/*     */           
/* 541 */           long ticks = Math.max(calculated, this.tick);
/* 542 */           int stopIndex = (int)(ticks & HashedWheelTimer.this.mask);
/*     */           
/* 544 */           HashedWheelTimer.HashedWheelBucket bucket = HashedWheelTimer.this.wheel[stopIndex];
/* 545 */           bucket.addTimeout(timeout);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     private void processCancelledTasks() {
/*     */       while (true) {
/* 551 */         HashedWheelTimer.HashedWheelTimeout timeout = HashedWheelTimer.this.cancelledTimeouts.poll();
/* 552 */         if (timeout == null) {
/*     */           break;
/*     */         }
/*     */         
/*     */         try {
/* 557 */           timeout.remove();
/* 558 */         } catch (Throwable t) {
/* 559 */           if (HashedWheelTimer.logger.isWarnEnabled()) {
/* 560 */             HashedWheelTimer.logger.warn("An exception was thrown while process a cancellation task", t);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private long waitForNextTick() {
/* 573 */       long deadline = HashedWheelTimer.this.tickDuration * (this.tick + 1L);
/*     */       
/*     */       while (true) {
/* 576 */         long currentTime = System.nanoTime() - HashedWheelTimer.this.startTime;
/* 577 */         long sleepTimeMs = (deadline - currentTime + 999999L) / 1000000L;
/*     */         
/* 579 */         if (sleepTimeMs <= 0L) {
/* 580 */           if (currentTime == Long.MIN_VALUE) {
/* 581 */             return -9223372036854775807L;
/*     */           }
/* 583 */           return currentTime;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 592 */         if (PlatformDependent.isWindows()) {
/* 593 */           sleepTimeMs = sleepTimeMs / 10L * 10L;
/* 594 */           if (sleepTimeMs == 0L) {
/* 595 */             sleepTimeMs = 1L;
/*     */           }
/*     */         } 
/*     */         
/*     */         try {
/* 600 */           Thread.sleep(sleepTimeMs);
/* 601 */         } catch (InterruptedException ignored) {
/* 602 */           if (HashedWheelTimer.WORKER_STATE_UPDATER.get(HashedWheelTimer.this) == 2) {
/* 603 */             return Long.MIN_VALUE;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public Set<Timeout> unprocessedTimeouts() {
/* 610 */       return Collections.unmodifiableSet(this.unprocessedTimeouts);
/*     */     }
/*     */     
/*     */     private Worker() {}
/*     */   }
/*     */   
/*     */   private static final class HashedWheelTimeout implements Timeout, Runnable {
/*     */     private static final int ST_INIT = 0;
/*     */     private static final int ST_CANCELLED = 1;
/*     */     private static final int ST_EXPIRED = 2;
/* 620 */     private static final AtomicIntegerFieldUpdater<HashedWheelTimeout> STATE_UPDATER = AtomicIntegerFieldUpdater.newUpdater(HashedWheelTimeout.class, "state");
/*     */     
/*     */     private final HashedWheelTimer timer;
/*     */     
/*     */     private final TimerTask task;
/*     */     private final long deadline;
/* 626 */     private volatile int state = 0;
/*     */ 
/*     */     
/*     */     long remainingRounds;
/*     */ 
/*     */     
/*     */     HashedWheelTimeout next;
/*     */ 
/*     */     
/*     */     HashedWheelTimeout prev;
/*     */ 
/*     */     
/*     */     HashedWheelTimer.HashedWheelBucket bucket;
/*     */ 
/*     */     
/*     */     HashedWheelTimeout(HashedWheelTimer timer, TimerTask task, long deadline) {
/* 642 */       this.timer = timer;
/* 643 */       this.task = task;
/* 644 */       this.deadline = deadline;
/*     */     }
/*     */ 
/*     */     
/*     */     public Timer timer() {
/* 649 */       return this.timer;
/*     */     }
/*     */ 
/*     */     
/*     */     public TimerTask task() {
/* 654 */       return this.task;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean cancel() {
/* 660 */       if (!compareAndSetState(0, 1)) {
/* 661 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 666 */       this.timer.cancelledTimeouts.add(this);
/* 667 */       return true;
/*     */     }
/*     */     
/*     */     void remove() {
/* 671 */       HashedWheelTimer.HashedWheelBucket bucket = this.bucket;
/* 672 */       if (bucket != null) {
/* 673 */         bucket.remove(this);
/*     */       } else {
/* 675 */         this.timer.pendingTimeouts.decrementAndGet();
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean compareAndSetState(int expected, int state) {
/* 680 */       return STATE_UPDATER.compareAndSet(this, expected, state);
/*     */     }
/*     */     
/*     */     public int state() {
/* 684 */       return this.state;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCancelled() {
/* 689 */       return (state() == 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isExpired() {
/* 694 */       return (state() == 2);
/*     */     }
/*     */     
/*     */     public void expire() {
/* 698 */       if (!compareAndSetState(0, 2)) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/* 703 */         this.timer.taskExecutor.execute(this);
/* 704 */       } catch (Throwable t) {
/* 705 */         if (HashedWheelTimer.logger.isWarnEnabled()) {
/* 706 */           HashedWheelTimer.logger.warn("An exception was thrown while submit " + TimerTask.class.getSimpleName() + " for execution.", t);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 715 */         this.task.run(this);
/* 716 */       } catch (Throwable t) {
/* 717 */         if (HashedWheelTimer.logger.isWarnEnabled()) {
/* 718 */           HashedWheelTimer.logger.warn("An exception was thrown by " + TimerTask.class.getSimpleName() + '.', t);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 725 */       long currentTime = System.nanoTime();
/* 726 */       long remaining = this.deadline - currentTime + this.timer.startTime;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 731 */       StringBuilder buf = (new StringBuilder(192)).append(StringUtil.simpleClassName(this)).append('(').append("deadline: ");
/* 732 */       if (remaining > 0L) {
/* 733 */         buf.append(remaining)
/* 734 */           .append(" ns later");
/* 735 */       } else if (remaining < 0L) {
/* 736 */         buf.append(-remaining)
/* 737 */           .append(" ns ago");
/*     */       } else {
/* 739 */         buf.append("now");
/*     */       } 
/*     */       
/* 742 */       if (isCancelled()) {
/* 743 */         buf.append(", cancelled");
/*     */       }
/*     */       
/* 746 */       return buf.append(", task: ")
/* 747 */         .append(task())
/* 748 */         .append(')')
/* 749 */         .toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class HashedWheelBucket
/*     */   {
/*     */     private HashedWheelTimer.HashedWheelTimeout head;
/*     */ 
/*     */     
/*     */     private HashedWheelTimer.HashedWheelTimeout tail;
/*     */ 
/*     */     
/*     */     private HashedWheelBucket() {}
/*     */ 
/*     */     
/*     */     public void addTimeout(HashedWheelTimer.HashedWheelTimeout timeout) {
/* 767 */       assert timeout.bucket == null;
/* 768 */       timeout.bucket = this;
/* 769 */       if (this.head == null) {
/* 770 */         this.head = this.tail = timeout;
/*     */       } else {
/* 772 */         this.tail.next = timeout;
/* 773 */         timeout.prev = this.tail;
/* 774 */         this.tail = timeout;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void expireTimeouts(long deadline) {
/* 782 */       HashedWheelTimer.HashedWheelTimeout timeout = this.head;
/*     */ 
/*     */       
/* 785 */       while (timeout != null) {
/* 786 */         HashedWheelTimer.HashedWheelTimeout next = timeout.next;
/* 787 */         if (timeout.remainingRounds <= 0L) {
/* 788 */           next = remove(timeout);
/* 789 */           if (timeout.deadline <= deadline) {
/* 790 */             timeout.expire();
/*     */           } else {
/*     */             
/* 793 */             throw new IllegalStateException(String.format("timeout.deadline (%d) > deadline (%d)", new Object[] {
/* 794 */                     Long.valueOf(HashedWheelTimer.HashedWheelTimeout.access$800(timeout)), Long.valueOf(deadline) }));
/*     */           } 
/* 796 */         } else if (timeout.isCancelled()) {
/* 797 */           next = remove(timeout);
/*     */         } else {
/* 799 */           timeout.remainingRounds--;
/*     */         } 
/* 801 */         timeout = next;
/*     */       } 
/*     */     }
/*     */     
/*     */     public HashedWheelTimer.HashedWheelTimeout remove(HashedWheelTimer.HashedWheelTimeout timeout) {
/* 806 */       HashedWheelTimer.HashedWheelTimeout next = timeout.next;
/*     */       
/* 808 */       if (timeout.prev != null) {
/* 809 */         timeout.prev.next = next;
/*     */       }
/* 811 */       if (timeout.next != null) {
/* 812 */         timeout.next.prev = timeout.prev;
/*     */       }
/*     */       
/* 815 */       if (timeout == this.head) {
/*     */         
/* 817 */         if (timeout == this.tail) {
/* 818 */           this.tail = null;
/* 819 */           this.head = null;
/*     */         } else {
/* 821 */           this.head = next;
/*     */         } 
/* 823 */       } else if (timeout == this.tail) {
/*     */         
/* 825 */         this.tail = timeout.prev;
/*     */       } 
/*     */       
/* 828 */       timeout.prev = null;
/* 829 */       timeout.next = null;
/* 830 */       timeout.bucket = null;
/* 831 */       timeout.timer.pendingTimeouts.decrementAndGet();
/* 832 */       return next;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clearTimeouts(Set<Timeout> set) {
/*     */       while (true) {
/* 840 */         HashedWheelTimer.HashedWheelTimeout timeout = pollTimeout();
/* 841 */         if (timeout == null) {
/*     */           return;
/*     */         }
/* 844 */         if (timeout.isExpired() || timeout.isCancelled()) {
/*     */           continue;
/*     */         }
/* 847 */         set.add(timeout);
/*     */       } 
/*     */     }
/*     */     
/*     */     private HashedWheelTimer.HashedWheelTimeout pollTimeout() {
/* 852 */       HashedWheelTimer.HashedWheelTimeout head = this.head;
/* 853 */       if (head == null) {
/* 854 */         return null;
/*     */       }
/* 856 */       HashedWheelTimer.HashedWheelTimeout next = head.next;
/* 857 */       if (next == null) {
/* 858 */         this.tail = this.head = null;
/*     */       } else {
/* 860 */         this.head = next;
/* 861 */         next.prev = null;
/*     */       } 
/*     */ 
/*     */       
/* 865 */       head.next = null;
/* 866 */       head.prev = null;
/* 867 */       head.bucket = null;
/* 868 */       return head;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\HashedWheelTimer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */