/*      */ package io.netty.util;
/*      */ 
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import io.netty.util.internal.SystemPropertyUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.net.Inet4Address;
/*      */ import java.net.Inet6Address;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.NetworkInterface;
/*      */ import java.net.UnknownHostException;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class NetUtil
/*      */ {
/*      */   public static final Inet4Address LOCALHOST4;
/*      */   public static final Inet6Address LOCALHOST6;
/*      */   public static final InetAddress LOCALHOST;
/*      */   public static final NetworkInterface LOOPBACK_IF;
/*      */   public static final Collection<NetworkInterface> NETWORK_INTERFACES;
/*      */   public static final int SOMAXCONN;
/*      */   private static final int IPV6_WORD_COUNT = 8;
/*      */   private static final int IPV6_MAX_CHAR_COUNT = 39;
/*      */   private static final int IPV6_BYTE_COUNT = 16;
/*      */   private static final int IPV6_MAX_CHAR_BETWEEN_SEPARATOR = 4;
/*      */   private static final int IPV6_MIN_SEPARATORS = 2;
/*      */   private static final int IPV6_MAX_SEPARATORS = 8;
/*      */   private static final int IPV4_MAX_CHAR_BETWEEN_SEPARATOR = 3;
/*      */   private static final int IPV4_SEPARATORS = 3;
/*  128 */   private static final boolean IPV4_PREFERRED = SystemPropertyUtil.getBoolean("java.net.preferIPv4Stack", false);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean IPV6_ADDRESSES_PREFERRED;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(NetUtil.class);
/*      */   
/*      */   static {
/*  141 */     String prefer = SystemPropertyUtil.get("java.net.preferIPv6Addresses", "false");
/*  142 */     if ("true".equalsIgnoreCase(prefer.trim())) {
/*  143 */       IPV6_ADDRESSES_PREFERRED = true;
/*      */     } else {
/*      */       
/*  146 */       IPV6_ADDRESSES_PREFERRED = false;
/*      */     } 
/*  148 */     logger.debug("-Djava.net.preferIPv4Stack: {}", Boolean.valueOf(IPV4_PREFERRED));
/*  149 */     logger.debug("-Djava.net.preferIPv6Addresses: {}", prefer);
/*      */     
/*  151 */     NETWORK_INTERFACES = NetUtilInitializations.networkInterfaces();
/*      */ 
/*      */     
/*  154 */     LOCALHOST4 = NetUtilInitializations.createLocalhost4();
/*      */ 
/*      */     
/*  157 */     LOCALHOST6 = NetUtilInitializations.createLocalhost6();
/*      */ 
/*      */     
/*  160 */     NetUtilInitializations.NetworkIfaceAndInetAddress loopback = NetUtilInitializations.determineLoopback(NETWORK_INTERFACES, LOCALHOST4, LOCALHOST6);
/*  161 */     LOOPBACK_IF = loopback.iface();
/*  162 */     LOCALHOST = loopback.address();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  167 */     SOMAXCONN = ((Integer)AccessController.<Integer>doPrivileged(new SoMaxConnAction())).intValue();
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class SoMaxConnAction
/*      */     implements PrivilegedAction<Integer>
/*      */   {
/*      */     private SoMaxConnAction() {}
/*      */     
/*      */     public Integer run() {
/*  177 */       int somaxconn = PlatformDependent.isWindows() ? 200 : 128;
/*  178 */       File file = new File("/proc/sys/net/core/somaxconn");
/*  179 */       BufferedReader in = null;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  184 */         if (file.exists()) {
/*  185 */           in = new BufferedReader(new FileReader(file));
/*  186 */           somaxconn = Integer.parseInt(in.readLine());
/*  187 */           if (NetUtil.logger.isDebugEnabled()) {
/*  188 */             NetUtil.logger.debug("{}: {}", file, Integer.valueOf(somaxconn));
/*      */           }
/*      */         } else {
/*      */           
/*  192 */           Integer tmp = null;
/*  193 */           if (SystemPropertyUtil.getBoolean("io.netty.net.somaxconn.trySysctl", false)) {
/*  194 */             tmp = NetUtil.sysctlGetInt("kern.ipc.somaxconn");
/*  195 */             if (tmp == null) {
/*  196 */               tmp = NetUtil.sysctlGetInt("kern.ipc.soacceptqueue");
/*  197 */               if (tmp != null) {
/*  198 */                 somaxconn = tmp.intValue();
/*      */               }
/*      */             } else {
/*  201 */               somaxconn = tmp.intValue();
/*      */             } 
/*      */           } 
/*      */           
/*  205 */           if (tmp == null) {
/*  206 */             NetUtil.logger.debug("Failed to get SOMAXCONN from sysctl and file {}. Default: {}", file, 
/*  207 */                 Integer.valueOf(somaxconn));
/*      */           }
/*      */         } 
/*  210 */       } catch (Exception e) {
/*  211 */         if (NetUtil.logger.isDebugEnabled()) {
/*  212 */           NetUtil.logger.debug("Failed to get SOMAXCONN from sysctl and file {}. Default: {}", new Object[] { file, 
/*  213 */                 Integer.valueOf(somaxconn), e });
/*      */         }
/*      */       } finally {
/*  216 */         if (in != null) {
/*      */           try {
/*  218 */             in.close();
/*  219 */           } catch (Exception exception) {}
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  224 */       return Integer.valueOf(somaxconn);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Integer sysctlGetInt(String sysctlKey) throws IOException {
/*  234 */     Process process = (new ProcessBuilder(new String[] { "sysctl", sysctlKey })).start();
/*      */     
/*      */     try {
/*  237 */       InputStream is = process.getInputStream();
/*  238 */       InputStreamReader isr = new InputStreamReader(is);
/*  239 */       BufferedReader br = new BufferedReader(isr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  257 */       process.destroy();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIpV4StackPreferred() {
/*  269 */     return IPV4_PREFERRED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIpV6AddressesPreferred() {
/*  280 */     return IPV6_ADDRESSES_PREFERRED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] createByteArrayFromIpAddressString(String ipAddressString) {
/*  288 */     if (isValidIpV4Address(ipAddressString)) {
/*  289 */       return validIpV4ToBytes(ipAddressString);
/*      */     }
/*      */     
/*  292 */     if (isValidIpV6Address(ipAddressString)) {
/*  293 */       if (ipAddressString.charAt(0) == '[') {
/*  294 */         ipAddressString = ipAddressString.substring(1, ipAddressString.length() - 1);
/*      */       }
/*      */       
/*  297 */       int percentPos = ipAddressString.indexOf('%');
/*  298 */       if (percentPos >= 0) {
/*  299 */         ipAddressString = ipAddressString.substring(0, percentPos);
/*      */       }
/*      */       
/*  302 */       return getIPv6ByName(ipAddressString, true);
/*      */     } 
/*  304 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InetAddress createInetAddressFromIpAddressString(String ipAddressString) {
/*  312 */     if (isValidIpV4Address(ipAddressString)) {
/*  313 */       byte[] bytes = validIpV4ToBytes(ipAddressString);
/*      */       try {
/*  315 */         return InetAddress.getByAddress(bytes);
/*  316 */       } catch (UnknownHostException e) {
/*      */         
/*  318 */         throw new IllegalStateException(e);
/*      */       } 
/*      */     } 
/*      */     
/*  322 */     if (isValidIpV6Address(ipAddressString)) {
/*  323 */       if (ipAddressString.charAt(0) == '[') {
/*  324 */         ipAddressString = ipAddressString.substring(1, ipAddressString.length() - 1);
/*      */       }
/*      */       
/*  327 */       int percentPos = ipAddressString.indexOf('%');
/*  328 */       if (percentPos >= 0) {
/*      */         try {
/*  330 */           int scopeId = Integer.parseInt(ipAddressString.substring(percentPos + 1));
/*  331 */           ipAddressString = ipAddressString.substring(0, percentPos);
/*  332 */           byte[] arrayOfByte = getIPv6ByName(ipAddressString, true);
/*  333 */           if (arrayOfByte == null) {
/*  334 */             return null;
/*      */           }
/*      */           try {
/*  337 */             return Inet6Address.getByAddress((String)null, arrayOfByte, scopeId);
/*  338 */           } catch (UnknownHostException e) {
/*      */             
/*  340 */             throw new IllegalStateException(e);
/*      */           } 
/*  342 */         } catch (NumberFormatException e) {
/*  343 */           return null;
/*      */         } 
/*      */       }
/*  346 */       byte[] bytes = getIPv6ByName(ipAddressString, true);
/*  347 */       if (bytes == null) {
/*  348 */         return null;
/*      */       }
/*      */       try {
/*  351 */         return InetAddress.getByAddress(bytes);
/*  352 */       } catch (UnknownHostException e) {
/*      */         
/*  354 */         throw new IllegalStateException(e);
/*      */       } 
/*      */     } 
/*  357 */     return null;
/*      */   }
/*      */   
/*      */   private static int decimalDigit(String str, int pos) {
/*  361 */     return str.charAt(pos) - 48;
/*      */   }
/*      */   
/*      */   private static byte ipv4WordToByte(String ip, int from, int toExclusive) {
/*  365 */     int ret = decimalDigit(ip, from);
/*  366 */     from++;
/*  367 */     if (from == toExclusive) {
/*  368 */       return (byte)ret;
/*      */     }
/*  370 */     ret = ret * 10 + decimalDigit(ip, from);
/*  371 */     from++;
/*  372 */     if (from == toExclusive) {
/*  373 */       return (byte)ret;
/*      */     }
/*  375 */     return (byte)(ret * 10 + decimalDigit(ip, from));
/*      */   }
/*      */ 
/*      */   
/*      */   static byte[] validIpV4ToBytes(String ip) {
/*      */     int i;
/*  381 */     return new byte[] {
/*  382 */         ipv4WordToByte(ip, 0, i = ip.indexOf('.', 1)), 
/*  383 */         ipv4WordToByte(ip, i + 1, i = ip.indexOf('.', i + 2)), 
/*  384 */         ipv4WordToByte(ip, i + 1, i = ip.indexOf('.', i + 2)), 
/*  385 */         ipv4WordToByte(ip, i + 1, ip.length())
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ipv4AddressToInt(Inet4Address ipAddress) {
/*  393 */     byte[] octets = ipAddress.getAddress();
/*      */     
/*  395 */     return (octets[0] & 0xFF) << 24 | (octets[1] & 0xFF) << 16 | (octets[2] & 0xFF) << 8 | octets[3] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String intToIpAddress(int i) {
/*  405 */     StringBuilder buf = new StringBuilder(15);
/*  406 */     buf.append(i >> 24 & 0xFF);
/*  407 */     buf.append('.');
/*  408 */     buf.append(i >> 16 & 0xFF);
/*  409 */     buf.append('.');
/*  410 */     buf.append(i >> 8 & 0xFF);
/*  411 */     buf.append('.');
/*  412 */     buf.append(i & 0xFF);
/*  413 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String bytesToIpAddress(byte[] bytes) {
/*  423 */     return bytesToIpAddress(bytes, 0, bytes.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String bytesToIpAddress(byte[] bytes, int offset, int length) {
/*  433 */     switch (length) {
/*      */       case 4:
/*  435 */         return (new StringBuilder(15))
/*  436 */           .append(bytes[offset] & 0xFF)
/*  437 */           .append('.')
/*  438 */           .append(bytes[offset + 1] & 0xFF)
/*  439 */           .append('.')
/*  440 */           .append(bytes[offset + 2] & 0xFF)
/*  441 */           .append('.')
/*  442 */           .append(bytes[offset + 3] & 0xFF).toString();
/*      */       
/*      */       case 16:
/*  445 */         return toAddressString(bytes, offset, false);
/*      */     } 
/*  447 */     throw new IllegalArgumentException("length: " + length + " (expected: 4 or 16)");
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isValidIpV6Address(String ip) {
/*  452 */     return isValidIpV6Address(ip);
/*      */   }
/*      */   
/*      */   public static boolean isValidIpV6Address(CharSequence ip) {
/*  456 */     int start, colons, compressBegin, end = ip.length();
/*  457 */     if (end < 2) {
/*  458 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  463 */     char c = ip.charAt(0);
/*  464 */     if (c == '[') {
/*  465 */       end--;
/*  466 */       if (ip.charAt(end) != ']')
/*      */       {
/*  468 */         return false;
/*      */       }
/*  470 */       start = 1;
/*  471 */       c = ip.charAt(1);
/*      */     } else {
/*  473 */       start = 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  478 */     if (c == ':') {
/*      */       
/*  480 */       if (ip.charAt(start + 1) != ':') {
/*  481 */         return false;
/*      */       }
/*  483 */       colons = 2;
/*  484 */       compressBegin = start;
/*  485 */       start += 2;
/*      */     } else {
/*  487 */       colons = 0;
/*  488 */       compressBegin = -1;
/*      */     } 
/*      */     
/*  491 */     int wordLen = 0;
/*      */     
/*  493 */     for (int i = start; i < end; i++) {
/*  494 */       c = ip.charAt(i);
/*  495 */       if (isValidHexChar(c)) {
/*  496 */         if (wordLen < 4) {
/*  497 */           wordLen++;
/*      */         } else {
/*      */           
/*  500 */           return false;
/*      */         } 
/*      */       } else {
/*  503 */         int ipv4Start; int j; int ipv4End; switch (c) {
/*      */           case ':':
/*  505 */             if (colons > 7) {
/*  506 */               return false;
/*      */             }
/*  508 */             if (ip.charAt(i - 1) == ':') {
/*  509 */               if (compressBegin >= 0) {
/*  510 */                 return false;
/*      */               }
/*  512 */               compressBegin = i - 1;
/*      */             } else {
/*  514 */               wordLen = 0;
/*      */             } 
/*  516 */             colons++;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case '.':
/*  522 */             if ((compressBegin < 0 && colons != 6) || (colons == 7 && compressBegin >= start) || colons > 7)
/*      */             {
/*      */ 
/*      */               
/*  526 */               return false;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  532 */             ipv4Start = i - wordLen;
/*  533 */             j = ipv4Start - 2;
/*  534 */             if (isValidIPv4MappedChar(ip.charAt(j))) {
/*  535 */               if (!isValidIPv4MappedChar(ip.charAt(j - 1)) || 
/*  536 */                 !isValidIPv4MappedChar(ip.charAt(j - 2)) || 
/*  537 */                 !isValidIPv4MappedChar(ip.charAt(j - 3))) {
/*  538 */                 return false;
/*      */               }
/*  540 */               j -= 5;
/*      */             } 
/*      */             
/*  543 */             for (; j >= start; j--) {
/*  544 */               char tmpChar = ip.charAt(j);
/*  545 */               if (tmpChar != '0' && tmpChar != ':') {
/*  546 */                 return false;
/*      */               }
/*      */             } 
/*      */ 
/*      */             
/*  551 */             ipv4End = AsciiString.indexOf(ip, '%', ipv4Start + 7);
/*  552 */             if (ipv4End < 0) {
/*  553 */               ipv4End = end;
/*      */             }
/*  555 */             return isValidIpV4Address(ip, ipv4Start, ipv4End);
/*      */           
/*      */           case '%':
/*  558 */             end = i;
/*      */             break;
/*      */           default:
/*  561 */             return false;
/*      */         } 
/*      */       
/*      */       } 
/*      */     } 
/*  566 */     if (compressBegin < 0) {
/*  567 */       return (colons == 7 && wordLen > 0);
/*      */     }
/*      */     
/*  570 */     return (compressBegin + 2 == end || (wordLen > 0 && (colons < 8 || compressBegin <= start)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isValidIpV4Word(CharSequence word, int from, int toExclusive) {
/*  576 */     int len = toExclusive - from;
/*      */     char c0;
/*  578 */     if (len < 1 || len > 3 || (c0 = word.charAt(from)) < '0') {
/*  579 */       return false;
/*      */     }
/*  581 */     if (len == 3) {
/*  582 */       char c1; char c2; return ((c1 = word.charAt(from + 1)) >= '0' && (
/*  583 */         c2 = word.charAt(from + 2)) >= '0' && ((c0 <= '1' && c1 <= '9' && c2 <= '9') || (c0 == '2' && c1 <= '5' && (c2 <= '5' || (c1 < '5' && c2 <= '9')))));
/*      */     } 
/*      */ 
/*      */     
/*  587 */     return (c0 <= '9' && (len == 1 || isValidNumericChar(word.charAt(from + 1))));
/*      */   }
/*      */   
/*      */   private static boolean isValidHexChar(char c) {
/*  591 */     return ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f'));
/*      */   }
/*      */   
/*      */   private static boolean isValidNumericChar(char c) {
/*  595 */     return (c >= '0' && c <= '9');
/*      */   }
/*      */   
/*      */   private static boolean isValidIPv4MappedChar(char c) {
/*  599 */     return (c == 'f' || c == 'F');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isValidIPv4MappedSeparators(byte b0, byte b1, boolean mustBeZero) {
/*  606 */     return (b0 == b1 && (b0 == 0 || (!mustBeZero && b1 == -1)));
/*      */   }
/*      */   
/*      */   private static boolean isValidIPv4Mapped(byte[] bytes, int currentIndex, int compressBegin, int compressLength) {
/*  610 */     boolean mustBeZero = (compressBegin + compressLength >= 14);
/*  611 */     return (currentIndex <= 12 && currentIndex >= 2 && (!mustBeZero || compressBegin < 12) && 
/*  612 */       isValidIPv4MappedSeparators(bytes[currentIndex - 1], bytes[currentIndex - 2], mustBeZero) && 
/*  613 */       PlatformDependent.isZero(bytes, 0, currentIndex - 3));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidIpV4Address(CharSequence ip) {
/*  623 */     return isValidIpV4Address(ip, 0, ip.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidIpV4Address(String ip) {
/*  633 */     return isValidIpV4Address(ip, 0, ip.length());
/*      */   }
/*      */   
/*      */   private static boolean isValidIpV4Address(CharSequence ip, int from, int toExcluded) {
/*  637 */     return (ip instanceof String) ? isValidIpV4Address((String)ip, from, toExcluded) : ((ip instanceof AsciiString) ? 
/*  638 */       isValidIpV4Address((AsciiString)ip, from, toExcluded) : 
/*  639 */       isValidIpV4Address0(ip, from, toExcluded));
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isValidIpV4Address(String ip, int from, int toExcluded) {
/*  644 */     int len = toExcluded - from;
/*      */     int i;
/*  646 */     return (len <= 15 && len >= 7 && (
/*  647 */       i = ip.indexOf('.', from + 1)) > 0 && isValidIpV4Word(ip, from, i) && (
/*  648 */       i = ip.indexOf('.', from = i + 2)) > 0 && isValidIpV4Word(ip, from - 1, i) && (
/*  649 */       i = ip.indexOf('.', from = i + 2)) > 0 && isValidIpV4Word(ip, from - 1, i) && 
/*  650 */       isValidIpV4Word(ip, i + 1, toExcluded));
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isValidIpV4Address(AsciiString ip, int from, int toExcluded) {
/*  655 */     int len = toExcluded - from;
/*      */     int i;
/*  657 */     return (len <= 15 && len >= 7 && (
/*  658 */       i = ip.indexOf('.', from + 1)) > 0 && isValidIpV4Word(ip, from, i) && (
/*  659 */       i = ip.indexOf('.', from = i + 2)) > 0 && isValidIpV4Word(ip, from - 1, i) && (
/*  660 */       i = ip.indexOf('.', from = i + 2)) > 0 && isValidIpV4Word(ip, from - 1, i) && 
/*  661 */       isValidIpV4Word(ip, i + 1, toExcluded));
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isValidIpV4Address0(CharSequence ip, int from, int toExcluded) {
/*  666 */     int len = toExcluded - from;
/*      */     int i;
/*  668 */     return (len <= 15 && len >= 7 && (
/*  669 */       i = AsciiString.indexOf(ip, '.', from + 1)) > 0 && isValidIpV4Word(ip, from, i) && (
/*  670 */       i = AsciiString.indexOf(ip, '.', from = i + 2)) > 0 && isValidIpV4Word(ip, from - 1, i) && (
/*  671 */       i = AsciiString.indexOf(ip, '.', from = i + 2)) > 0 && isValidIpV4Word(ip, from - 1, i) && 
/*  672 */       isValidIpV4Word(ip, i + 1, toExcluded));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Inet6Address getByName(CharSequence ip) {
/*  683 */     return getByName(ip, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Inet6Address getByName(CharSequence ip, boolean ipv4Mapped) {
/*  701 */     byte[] bytes = getIPv6ByName(ip, ipv4Mapped);
/*  702 */     if (bytes == null) {
/*  703 */       return null;
/*      */     }
/*      */     try {
/*  706 */       return Inet6Address.getByAddress((String)null, bytes, -1);
/*  707 */     } catch (UnknownHostException e) {
/*  708 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static byte[] getIPv6ByName(CharSequence ip, boolean ipv4Mapped) {
/*  728 */     byte[] bytes = new byte[16];
/*  729 */     int ipLength = ip.length();
/*  730 */     int compressBegin = 0;
/*  731 */     int compressLength = 0;
/*  732 */     int currentIndex = 0;
/*  733 */     int value = 0;
/*  734 */     int begin = -1;
/*  735 */     int i = 0;
/*  736 */     int ipv6Separators = 0;
/*  737 */     int ipv4Separators = 0;
/*      */     
/*  739 */     for (; i < ipLength; i++) {
/*  740 */       int tmp; char c = ip.charAt(i);
/*  741 */       switch (c) {
/*      */         case ':':
/*  743 */           ipv6Separators++;
/*  744 */           if (i - begin > 4 || ipv4Separators > 0 || ipv6Separators > 8 || currentIndex + 1 >= bytes.length)
/*      */           {
/*      */             
/*  747 */             return null;
/*      */           }
/*  749 */           value <<= 4 - i - begin << 2;
/*      */           
/*  751 */           if (compressLength > 0) {
/*  752 */             compressLength -= 2;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  758 */           bytes[currentIndex++] = (byte)((value & 0xF) << 4 | value >> 4 & 0xF);
/*  759 */           bytes[currentIndex++] = (byte)((value >> 8 & 0xF) << 4 | value >> 12 & 0xF);
/*  760 */           tmp = i + 1;
/*  761 */           if (tmp < ipLength && ip.charAt(tmp) == ':') {
/*  762 */             tmp++;
/*  763 */             if (compressBegin != 0 || (tmp < ipLength && ip.charAt(tmp) == ':')) {
/*  764 */               return null;
/*      */             }
/*  766 */             ipv6Separators++;
/*  767 */             compressBegin = currentIndex;
/*  768 */             compressLength = bytes.length - compressBegin - 2;
/*  769 */             i++;
/*      */           } 
/*  771 */           value = 0;
/*  772 */           begin = -1;
/*      */           break;
/*      */         case '.':
/*  775 */           ipv4Separators++;
/*  776 */           tmp = i - begin;
/*  777 */           if (tmp > 3 || begin < 0 || ipv4Separators > 3 || (ipv6Separators > 0 && currentIndex + compressLength < 12) || i + 1 >= ipLength || currentIndex >= bytes.length || (ipv4Separators == 1 && (!ipv4Mapped || (currentIndex != 0 && 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  785 */             !isValidIPv4Mapped(bytes, currentIndex, compressBegin, compressLength)) || (tmp == 3 && (
/*      */             
/*  787 */             !isValidNumericChar(ip.charAt(i - 1)) || 
/*  788 */             !isValidNumericChar(ip.charAt(i - 2)) || 
/*  789 */             !isValidNumericChar(ip.charAt(i - 3)))) || (tmp == 2 && (
/*  790 */             !isValidNumericChar(ip.charAt(i - 1)) || 
/*  791 */             !isValidNumericChar(ip.charAt(i - 2)))) || (tmp == 1 && 
/*  792 */             !isValidNumericChar(ip.charAt(i - 1)))))) {
/*  793 */             return null;
/*      */           }
/*  795 */           value <<= 3 - tmp << 2;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  800 */           begin = (value & 0xF) * 100 + (value >> 4 & 0xF) * 10 + (value >> 8 & 0xF);
/*  801 */           if (begin > 255) {
/*  802 */             return null;
/*      */           }
/*  804 */           bytes[currentIndex++] = (byte)begin;
/*  805 */           value = 0;
/*  806 */           begin = -1;
/*      */           break;
/*      */         default:
/*  809 */           if (!isValidHexChar(c) || (ipv4Separators > 0 && !isValidNumericChar(c))) {
/*  810 */             return null;
/*      */           }
/*  812 */           if (begin < 0) {
/*  813 */             begin = i;
/*  814 */           } else if (i - begin > 4) {
/*  815 */             return null;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  821 */           value += StringUtil.decodeHexNibble(c) << i - begin << 2;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/*  826 */     boolean isCompressed = (compressBegin > 0);
/*      */     
/*  828 */     if (ipv4Separators > 0) {
/*  829 */       if ((begin > 0 && i - begin > 3) || ipv4Separators != 3 || currentIndex >= bytes.length)
/*      */       {
/*      */         
/*  832 */         return null;
/*      */       }
/*  834 */       if (ipv6Separators != 0 && (ipv6Separators < 2 || ((isCompressed || ipv6Separators != 6 || ip
/*  835 */         .charAt(0) == ':') && (!isCompressed || ipv6Separators >= 8 || (ip
/*      */         
/*  837 */         .charAt(0) == ':' && compressBegin > 2))))) {
/*  838 */         return null;
/*      */       }
/*  840 */       value <<= 3 - i - begin << 2;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  845 */       begin = (value & 0xF) * 100 + (value >> 4 & 0xF) * 10 + (value >> 8 & 0xF);
/*  846 */       if (begin > 255) {
/*  847 */         return null;
/*      */       }
/*  849 */       bytes[currentIndex++] = (byte)begin;
/*      */     } else {
/*  851 */       int tmp = ipLength - 1;
/*  852 */       if ((begin > 0 && i - begin > 4) || ipv6Separators < 2 || (!isCompressed && (ipv6Separators + 1 != 8 || ip
/*      */ 
/*      */         
/*  855 */         .charAt(0) == ':' || ip.charAt(tmp) == ':')) || (isCompressed && (ipv6Separators > 8 || (ipv6Separators == 8 && ((compressBegin <= 2 && ip
/*      */ 
/*      */         
/*  858 */         .charAt(0) != ':') || (compressBegin >= 14 && ip
/*  859 */         .charAt(tmp) != ':'))))) || currentIndex + 1 >= bytes.length || (begin < 0 && ip
/*      */         
/*  861 */         .charAt(tmp - 1) != ':') || (compressBegin > 2 && ip
/*  862 */         .charAt(0) == ':')) {
/*  863 */         return null;
/*      */       }
/*  865 */       if (begin >= 0 && i - begin <= 4) {
/*  866 */         value <<= 4 - i - begin << 2;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  871 */       bytes[currentIndex++] = (byte)((value & 0xF) << 4 | value >> 4 & 0xF);
/*  872 */       bytes[currentIndex++] = (byte)((value >> 8 & 0xF) << 4 | value >> 12 & 0xF);
/*      */     } 
/*      */     
/*  875 */     if (currentIndex < bytes.length) {
/*  876 */       int toBeCopiedLength = currentIndex - compressBegin;
/*  877 */       int targetIndex = bytes.length - toBeCopiedLength;
/*  878 */       System.arraycopy(bytes, compressBegin, bytes, targetIndex, toBeCopiedLength);
/*      */       
/*  880 */       Arrays.fill(bytes, compressBegin, targetIndex, (byte)0);
/*      */     } 
/*      */     
/*  883 */     if (ipv4Separators > 0) {
/*      */ 
/*      */ 
/*      */       
/*  887 */       bytes[11] = -1; bytes[10] = -1;
/*      */     } 
/*      */     
/*  890 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toSocketAddressString(InetSocketAddress addr) {
/*      */     StringBuilder sb;
/*  901 */     String port = String.valueOf(addr.getPort());
/*      */ 
/*      */     
/*  904 */     if (addr.isUnresolved()) {
/*  905 */       String hostname = getHostname(addr);
/*  906 */       sb = newSocketAddressStringBuilder(hostname, port, !isValidIpV6Address(hostname));
/*      */     } else {
/*  908 */       InetAddress address = addr.getAddress();
/*  909 */       String hostString = toAddressString(address);
/*  910 */       sb = newSocketAddressStringBuilder(hostString, port, address instanceof Inet4Address);
/*      */     } 
/*  912 */     return sb.append(':').append(port).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toSocketAddressString(String host, int port) {
/*  919 */     String portStr = String.valueOf(port);
/*  920 */     return newSocketAddressStringBuilder(host, portStr, 
/*  921 */         !isValidIpV6Address(host)).append(':').append(portStr).toString();
/*      */   }
/*      */   
/*      */   private static StringBuilder newSocketAddressStringBuilder(String host, String port, boolean ipv4) {
/*  925 */     int hostLen = host.length();
/*  926 */     if (ipv4)
/*      */     {
/*  928 */       return (new StringBuilder(hostLen + 1 + port.length())).append(host);
/*      */     }
/*      */     
/*  931 */     StringBuilder stringBuilder = new StringBuilder(hostLen + 3 + port.length());
/*  932 */     if (hostLen > 1 && host.charAt(0) == '[' && host.charAt(hostLen - 1) == ']') {
/*  933 */       return stringBuilder.append(host);
/*      */     }
/*  935 */     return stringBuilder.append('[').append(host).append(']');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toAddressString(InetAddress ip) {
/*  951 */     return toAddressString(ip, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toAddressString(InetAddress ip, boolean ipv4Mapped) {
/*  979 */     if (ip instanceof Inet4Address) {
/*  980 */       return ip.getHostAddress();
/*      */     }
/*  982 */     if (!(ip instanceof Inet6Address)) {
/*  983 */       throw new IllegalArgumentException("Unhandled type: " + ip);
/*      */     }
/*      */     
/*  986 */     return toAddressString(ip.getAddress(), 0, ipv4Mapped);
/*      */   }
/*      */   
/*      */   private static String toAddressString(byte[] bytes, int offset, boolean ipv4Mapped) {
/*  990 */     int[] words = new int[8];
/*      */     
/*  992 */     int end = offset + words.length; int i;
/*  993 */     for (i = offset; i < end; i++) {
/*  994 */       words[i] = (bytes[i << 1] & 0xFF) << 8 | bytes[(i << 1) + 1] & 0xFF;
/*      */     }
/*      */ 
/*      */     
/*  998 */     int currentStart = -1;
/*      */     
/* 1000 */     int shortestStart = -1;
/* 1001 */     int shortestLength = 0;
/* 1002 */     for (i = 0; i < words.length; i++) {
/* 1003 */       if (words[i] == 0) {
/* 1004 */         if (currentStart < 0) {
/* 1005 */           currentStart = i;
/*      */         }
/* 1007 */       } else if (currentStart >= 0) {
/* 1008 */         int currentLength = i - currentStart;
/* 1009 */         if (currentLength > shortestLength) {
/* 1010 */           shortestStart = currentStart;
/* 1011 */           shortestLength = currentLength;
/*      */         } 
/* 1013 */         currentStart = -1;
/*      */       } 
/*      */     } 
/*      */     
/* 1017 */     if (currentStart >= 0) {
/* 1018 */       int currentLength = i - currentStart;
/* 1019 */       if (currentLength > shortestLength) {
/* 1020 */         shortestStart = currentStart;
/* 1021 */         shortestLength = currentLength;
/*      */       } 
/*      */     } 
/*      */     
/* 1025 */     if (shortestLength == 1) {
/* 1026 */       shortestLength = 0;
/* 1027 */       shortestStart = -1;
/*      */     } 
/*      */ 
/*      */     
/* 1031 */     int shortestEnd = shortestStart + shortestLength;
/* 1032 */     StringBuilder b = new StringBuilder(39);
/* 1033 */     if (shortestEnd < 0) {
/* 1034 */       b.append(Integer.toHexString(words[0]));
/* 1035 */       for (i = 1; i < words.length; i++) {
/* 1036 */         b.append(':');
/* 1037 */         b.append(Integer.toHexString(words[i]));
/*      */       } 
/*      */     } else {
/*      */       boolean isIpv4Mapped;
/*      */       
/* 1042 */       if (inRangeEndExclusive(0, shortestStart, shortestEnd)) {
/* 1043 */         b.append("::");
/* 1044 */         isIpv4Mapped = (ipv4Mapped && shortestEnd == 5 && words[5] == 65535);
/*      */       } else {
/* 1046 */         b.append(Integer.toHexString(words[0]));
/* 1047 */         isIpv4Mapped = false;
/*      */       } 
/* 1049 */       for (i = 1; i < words.length; i++) {
/* 1050 */         if (!inRangeEndExclusive(i, shortestStart, shortestEnd)) {
/* 1051 */           if (!inRangeEndExclusive(i - 1, shortestStart, shortestEnd))
/*      */           {
/* 1053 */             if (!isIpv4Mapped || i == 6) {
/* 1054 */               b.append(':');
/*      */             } else {
/* 1056 */               b.append('.');
/*      */             } 
/*      */           }
/* 1059 */           if (isIpv4Mapped && i > 5) {
/* 1060 */             b.append(words[i] >> 8);
/* 1061 */             b.append('.');
/* 1062 */             b.append(words[i] & 0xFF);
/*      */           } else {
/* 1064 */             b.append(Integer.toHexString(words[i]));
/*      */           } 
/* 1066 */         } else if (!inRangeEndExclusive(i - 1, shortestStart, shortestEnd)) {
/*      */           
/* 1068 */           b.append("::");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1073 */     return b.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getHostname(InetSocketAddress addr) {
/* 1083 */     return (PlatformDependent.javaVersion() >= 7) ? addr.getHostString() : addr.getHostName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean inRangeEndExclusive(int value, int start, int end) {
/* 1098 */     return (value >= start && value < end);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\NetUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */