package io.netty.util.collection;

import java.util.Map;

public interface CharObjectMap<V> extends Map<Character, V> {
  V get(char paramChar);
  
  V put(char paramChar, V paramV);
  
  V remove(char paramChar);
  
  Iterable<PrimitiveEntry<V>> entries();
  
  boolean containsKey(char paramChar);
  
  public static interface PrimitiveEntry<V> {
    char key();
    
    V value();
    
    void setValue(V param1V);
  }
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\collection\CharObjectMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */