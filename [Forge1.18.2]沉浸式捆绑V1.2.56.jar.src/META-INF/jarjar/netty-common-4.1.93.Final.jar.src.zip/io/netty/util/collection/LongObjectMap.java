package io.netty.util.collection;

import java.util.Map;

public interface LongObjectMap<V> extends Map<Long, V> {
  V get(long paramLong);
  
  V put(long paramLong, V paramV);
  
  V remove(long paramLong);
  
  Iterable<PrimitiveEntry<V>> entries();
  
  boolean containsKey(long paramLong);
  
  public static interface PrimitiveEntry<V> {
    long key();
    
    V value();
    
    void setValue(V param1V);
  }
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\collection\LongObjectMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */