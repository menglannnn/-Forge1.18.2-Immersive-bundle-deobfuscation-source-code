/*     */ package io.netty.util;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConstantPool<T extends Constant<T>>
/*     */ {
/*  34 */   private final ConcurrentMap<String, T> constants = PlatformDependent.newConcurrentHashMap();
/*     */   
/*  36 */   private final AtomicInteger nextId = new AtomicInteger(1);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T valueOf(Class<?> firstNameComponent, String secondNameComponent) {
/*  42 */     return valueOf((
/*  43 */         (Class)ObjectUtil.checkNotNull(firstNameComponent, "firstNameComponent")).getName() + '#' + 
/*     */         
/*  45 */         (String)ObjectUtil.checkNotNull(secondNameComponent, "secondNameComponent"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T valueOf(String name) {
/*  57 */     return getOrCreate(ObjectUtil.checkNonEmpty(name, "name"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private T getOrCreate(String name) {
/*  66 */     Constant constant = (Constant)this.constants.get(name);
/*  67 */     if (constant == null) {
/*  68 */       T tempConstant = newConstant(nextId(), name);
/*  69 */       constant = (Constant)this.constants.putIfAbsent(name, tempConstant);
/*  70 */       if (constant == null) {
/*  71 */         return tempConstant;
/*     */       }
/*     */     } 
/*     */     
/*  75 */     return (T)constant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exists(String name) {
/*  82 */     return this.constants.containsKey(ObjectUtil.checkNonEmpty(name, "name"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T newInstance(String name) {
/*  90 */     return createOrThrow(ObjectUtil.checkNonEmpty(name, "name"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private T createOrThrow(String name) {
/*  99 */     Constant constant = (Constant)this.constants.get(name);
/* 100 */     if (constant == null) {
/* 101 */       T tempConstant = newConstant(nextId(), name);
/* 102 */       constant = (Constant)this.constants.putIfAbsent(name, tempConstant);
/* 103 */       if (constant == null) {
/* 104 */         return tempConstant;
/*     */       }
/*     */     } 
/*     */     
/* 108 */     throw new IllegalArgumentException(String.format("'%s' is already in use", new Object[] { name }));
/*     */   }
/*     */   
/*     */   protected abstract T newConstant(int paramInt, String paramString);
/*     */   
/*     */   @Deprecated
/*     */   public final int nextId() {
/* 115 */     return this.nextId.getAndIncrement();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\ConstantPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */