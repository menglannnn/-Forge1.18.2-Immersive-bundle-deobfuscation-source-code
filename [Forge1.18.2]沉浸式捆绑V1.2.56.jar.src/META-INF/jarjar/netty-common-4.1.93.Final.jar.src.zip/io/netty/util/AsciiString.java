/*      */ package io.netty.util;
/*      */ 
/*      */ import io.netty.util.internal.EmptyArrays;
/*      */ import io.netty.util.internal.InternalThreadLocalMap;
/*      */ import io.netty.util.internal.MathUtil;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class AsciiString
/*      */   implements CharSequence, Comparable<CharSequence>
/*      */ {
/*   48 */   public static final AsciiString EMPTY_STRING = cached("");
/*      */ 
/*      */ 
/*      */   
/*      */   private static final char MAX_CHAR_VALUE = 'ÿ';
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int INDEX_NOT_FOUND = -1;
/*      */ 
/*      */ 
/*      */   
/*      */   private final byte[] value;
/*      */ 
/*      */ 
/*      */   
/*      */   private final int offset;
/*      */ 
/*      */ 
/*      */   
/*      */   private final int length;
/*      */ 
/*      */   
/*      */   private int hash;
/*      */ 
/*      */   
/*      */   private String string;
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(byte[] value) {
/*   79 */     this(value, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(byte[] value, boolean copy) {
/*   87 */     this(value, 0, value.length, copy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(byte[] value, int start, int length, boolean copy) {
/*   96 */     if (copy) {
/*   97 */       byte[] rangedCopy = new byte[length];
/*   98 */       System.arraycopy(value, start, rangedCopy, 0, rangedCopy.length);
/*   99 */       this.value = rangedCopy;
/*  100 */       this.offset = 0;
/*      */     } else {
/*  102 */       if (MathUtil.isOutOfBounds(start, length, value.length)) {
/*  103 */         throw new IndexOutOfBoundsException("expected: 0 <= start(" + start + ") <= start + length(" + length + ") <= value.length(" + value.length + ')');
/*      */       }
/*      */       
/*  106 */       this.value = value;
/*  107 */       this.offset = start;
/*      */     } 
/*  109 */     this.length = length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(ByteBuffer value) {
/*  117 */     this(value, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(ByteBuffer value, boolean copy) {
/*  127 */     this(value, value.position(), value.remaining(), copy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(ByteBuffer value, int start, int length, boolean copy) {
/*  137 */     if (MathUtil.isOutOfBounds(start, length, value.capacity())) {
/*  138 */       throw new IndexOutOfBoundsException("expected: 0 <= start(" + start + ") <= start + length(" + length + ") <= value.capacity(" + value
/*  139 */           .capacity() + ')');
/*      */     }
/*      */     
/*  142 */     if (value.hasArray()) {
/*  143 */       if (copy) {
/*  144 */         int bufferOffset = value.arrayOffset() + start;
/*  145 */         this.value = Arrays.copyOfRange(value.array(), bufferOffset, bufferOffset + length);
/*  146 */         this.offset = 0;
/*      */       } else {
/*  148 */         this.value = value.array();
/*  149 */         this.offset = start;
/*      */       } 
/*      */     } else {
/*  152 */       this.value = PlatformDependent.allocateUninitializedArray(length);
/*  153 */       int oldPos = value.position();
/*  154 */       value.get(this.value, 0, length);
/*  155 */       value.position(oldPos);
/*  156 */       this.offset = 0;
/*      */     } 
/*  158 */     this.length = length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(char[] value) {
/*  165 */     this(value, 0, value.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(char[] value, int start, int length) {
/*  173 */     if (MathUtil.isOutOfBounds(start, length, value.length)) {
/*  174 */       throw new IndexOutOfBoundsException("expected: 0 <= start(" + start + ") <= start + length(" + length + ") <= value.length(" + value.length + ')');
/*      */     }
/*      */ 
/*      */     
/*  178 */     this.value = PlatformDependent.allocateUninitializedArray(length);
/*  179 */     for (int i = 0, j = start; i < length; i++, j++) {
/*  180 */       this.value[i] = c2b(value[j]);
/*      */     }
/*  182 */     this.offset = 0;
/*  183 */     this.length = length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(char[] value, Charset charset) {
/*  190 */     this(value, charset, 0, value.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(char[] value, Charset charset, int start, int length) {
/*  198 */     CharBuffer cbuf = CharBuffer.wrap(value, start, length);
/*  199 */     CharsetEncoder encoder = CharsetUtil.encoder(charset);
/*  200 */     ByteBuffer nativeBuffer = ByteBuffer.allocate((int)(encoder.maxBytesPerChar() * length));
/*  201 */     encoder.encode(cbuf, nativeBuffer, true);
/*  202 */     int bufferOffset = nativeBuffer.arrayOffset();
/*  203 */     this.value = Arrays.copyOfRange(nativeBuffer.array(), bufferOffset, bufferOffset + nativeBuffer.position());
/*  204 */     this.offset = 0;
/*  205 */     this.length = this.value.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(CharSequence value) {
/*  212 */     this(value, 0, value.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(CharSequence value, int start, int length) {
/*  220 */     if (MathUtil.isOutOfBounds(start, length, value.length())) {
/*  221 */       throw new IndexOutOfBoundsException("expected: 0 <= start(" + start + ") <= start + length(" + length + ") <= value.length(" + value
/*  222 */           .length() + ')');
/*      */     }
/*      */     
/*  225 */     this.value = PlatformDependent.allocateUninitializedArray(length);
/*  226 */     for (int i = 0, j = start; i < length; i++, j++) {
/*  227 */       this.value[i] = c2b(value.charAt(j));
/*      */     }
/*  229 */     this.offset = 0;
/*  230 */     this.length = length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(CharSequence value, Charset charset) {
/*  237 */     this(value, charset, 0, value.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString(CharSequence value, Charset charset, int start, int length) {
/*  245 */     CharBuffer cbuf = CharBuffer.wrap(value, start, start + length);
/*  246 */     CharsetEncoder encoder = CharsetUtil.encoder(charset);
/*  247 */     ByteBuffer nativeBuffer = ByteBuffer.allocate((int)(encoder.maxBytesPerChar() * length));
/*  248 */     encoder.encode(cbuf, nativeBuffer, true);
/*  249 */     int offset = nativeBuffer.arrayOffset();
/*  250 */     this.value = Arrays.copyOfRange(nativeBuffer.array(), offset, offset + nativeBuffer.position());
/*  251 */     this.offset = 0;
/*  252 */     this.length = this.value.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int forEachByte(ByteProcessor visitor) throws Exception {
/*  262 */     return forEachByte0(0, length(), visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int forEachByte(int index, int length, ByteProcessor visitor) throws Exception {
/*  273 */     if (MathUtil.isOutOfBounds(index, length, length())) {
/*  274 */       throw new IndexOutOfBoundsException("expected: 0 <= index(" + index + ") <= start + length(" + length + ") <= length(" + 
/*  275 */           length() + ')');
/*      */     }
/*  277 */     return forEachByte0(index, length, visitor);
/*      */   }
/*      */   
/*      */   private int forEachByte0(int index, int length, ByteProcessor visitor) throws Exception {
/*  281 */     int len = this.offset + index + length;
/*  282 */     for (int i = this.offset + index; i < len; i++) {
/*  283 */       if (!visitor.process(this.value[i])) {
/*  284 */         return i - this.offset;
/*      */       }
/*      */     } 
/*  287 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int forEachByteDesc(ByteProcessor visitor) throws Exception {
/*  297 */     return forEachByteDesc0(0, length(), visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int forEachByteDesc(int index, int length, ByteProcessor visitor) throws Exception {
/*  308 */     if (MathUtil.isOutOfBounds(index, length, length())) {
/*  309 */       throw new IndexOutOfBoundsException("expected: 0 <= index(" + index + ") <= start + length(" + length + ") <= length(" + 
/*  310 */           length() + ')');
/*      */     }
/*  312 */     return forEachByteDesc0(index, length, visitor);
/*      */   }
/*      */   
/*      */   private int forEachByteDesc0(int index, int length, ByteProcessor visitor) throws Exception {
/*  316 */     int end = this.offset + index;
/*  317 */     for (int i = this.offset + index + length - 1; i >= end; i--) {
/*  318 */       if (!visitor.process(this.value[i])) {
/*  319 */         return i - this.offset;
/*      */       }
/*      */     } 
/*  322 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte byteAt(int index) {
/*  328 */     if (index < 0 || index >= this.length) {
/*  329 */       throw new IndexOutOfBoundsException("index: " + index + " must be in the range [0," + this.length + ")");
/*      */     }
/*      */     
/*  332 */     if (PlatformDependent.hasUnsafe()) {
/*  333 */       return PlatformDependent.getByte(this.value, index + this.offset);
/*      */     }
/*  335 */     return this.value[index + this.offset];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  342 */     return (this.length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int length() {
/*  350 */     return this.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void arrayChanged() {
/*  358 */     this.string = null;
/*  359 */     this.hash = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] array() {
/*  370 */     return this.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int arrayOffset() {
/*  379 */     return this.offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEntireArrayUsed() {
/*  387 */     return (this.offset == 0 && this.length == this.value.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] toByteArray() {
/*  394 */     return toByteArray(0, length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] toByteArray(int start, int end) {
/*  402 */     return Arrays.copyOfRange(this.value, start + this.offset, end + this.offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copy(int srcIdx, byte[] dst, int dstIdx, int length) {
/*  414 */     if (MathUtil.isOutOfBounds(srcIdx, length, length())) {
/*  415 */       throw new IndexOutOfBoundsException("expected: 0 <= srcIdx(" + srcIdx + ") <= srcIdx + length(" + length + ") <= srcLen(" + 
/*  416 */           length() + ')');
/*      */     }
/*      */     
/*  419 */     System.arraycopy(this.value, srcIdx + this.offset, ObjectUtil.checkNotNull(dst, "dst"), dstIdx, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public char charAt(int index) {
/*  424 */     return b2c(byteAt(index));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(CharSequence cs) {
/*  434 */     return (indexOf(cs) >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareTo(CharSequence string) {
/*  452 */     if (this == string) {
/*  453 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*  457 */     int length1 = length();
/*  458 */     int length2 = string.length();
/*  459 */     int minLength = Math.min(length1, length2);
/*  460 */     for (int i = 0, j = arrayOffset(); i < minLength; i++, j++) {
/*  461 */       int result = b2c(this.value[j]) - string.charAt(i);
/*  462 */       if (result != 0) {
/*  463 */         return result;
/*      */       }
/*      */     } 
/*      */     
/*  467 */     return length1 - length2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString concat(CharSequence string) {
/*  477 */     int thisLen = length();
/*  478 */     int thatLen = string.length();
/*  479 */     if (thatLen == 0) {
/*  480 */       return this;
/*      */     }
/*      */     
/*  483 */     if (string instanceof AsciiString) {
/*  484 */       AsciiString that = (AsciiString)string;
/*  485 */       if (isEmpty()) {
/*  486 */         return that;
/*      */       }
/*      */       
/*  489 */       byte[] arrayOfByte = PlatformDependent.allocateUninitializedArray(thisLen + thatLen);
/*  490 */       System.arraycopy(this.value, arrayOffset(), arrayOfByte, 0, thisLen);
/*  491 */       System.arraycopy(that.value, that.arrayOffset(), arrayOfByte, thisLen, thatLen);
/*  492 */       return new AsciiString(arrayOfByte, false);
/*      */     } 
/*      */     
/*  495 */     if (isEmpty()) {
/*  496 */       return new AsciiString(string);
/*      */     }
/*      */     
/*  499 */     byte[] newValue = PlatformDependent.allocateUninitializedArray(thisLen + thatLen);
/*  500 */     System.arraycopy(this.value, arrayOffset(), newValue, 0, thisLen);
/*  501 */     for (int i = thisLen, j = 0; i < newValue.length; i++, j++) {
/*  502 */       newValue[i] = c2b(string.charAt(j));
/*      */     }
/*      */     
/*  505 */     return new AsciiString(newValue, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean endsWith(CharSequence suffix) {
/*  516 */     int suffixLen = suffix.length();
/*  517 */     return regionMatches(length() - suffixLen, suffix, 0, suffixLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contentEqualsIgnoreCase(CharSequence string) {
/*  528 */     if (this == string) {
/*  529 */       return true;
/*      */     }
/*      */     
/*  532 */     if (string == null || string.length() != length()) {
/*  533 */       return false;
/*      */     }
/*      */     
/*  536 */     if (string instanceof AsciiString) {
/*  537 */       AsciiString rhs = (AsciiString)string;
/*  538 */       for (int k = arrayOffset(), m = rhs.arrayOffset(), n = k + length(); k < n; k++, m++) {
/*  539 */         if (!equalsIgnoreCase(this.value[k], rhs.value[m])) {
/*  540 */           return false;
/*      */         }
/*      */       } 
/*  543 */       return true;
/*      */     } 
/*      */     
/*  546 */     for (int i = arrayOffset(), j = 0, end = length(); j < end; i++, j++) {
/*  547 */       if (!equalsIgnoreCase(b2c(this.value[i]), string.charAt(j))) {
/*  548 */         return false;
/*      */       }
/*      */     } 
/*  551 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] toCharArray() {
/*  560 */     return toCharArray(0, length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] toCharArray(int start, int end) {
/*  569 */     int length = end - start;
/*  570 */     if (length == 0) {
/*  571 */       return EmptyArrays.EMPTY_CHARS;
/*      */     }
/*      */     
/*  574 */     if (MathUtil.isOutOfBounds(start, length, length())) {
/*  575 */       throw new IndexOutOfBoundsException("expected: 0 <= start(" + start + ") <= srcIdx + length(" + length + ") <= srcLen(" + 
/*  576 */           length() + ')');
/*      */     }
/*      */     
/*  579 */     char[] buffer = new char[length];
/*  580 */     for (int i = 0, j = start + arrayOffset(); i < length; i++, j++) {
/*  581 */       buffer[i] = b2c(this.value[j]);
/*      */     }
/*  583 */     return buffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copy(int srcIdx, char[] dst, int dstIdx, int length) {
/*  595 */     ObjectUtil.checkNotNull(dst, "dst");
/*      */     
/*  597 */     if (MathUtil.isOutOfBounds(srcIdx, length, length())) {
/*  598 */       throw new IndexOutOfBoundsException("expected: 0 <= srcIdx(" + srcIdx + ") <= srcIdx + length(" + length + ") <= srcLen(" + 
/*  599 */           length() + ')');
/*      */     }
/*      */     
/*  602 */     int dstEnd = dstIdx + length;
/*  603 */     for (int i = dstIdx, j = srcIdx + arrayOffset(); i < dstEnd; i++, j++) {
/*  604 */       dst[i] = b2c(this.value[j]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString subSequence(int start) {
/*  615 */     return subSequence(start, length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString subSequence(int start, int end) {
/*  627 */     return subSequence(start, end, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString subSequence(int start, int end, boolean copy) {
/*  640 */     if (MathUtil.isOutOfBounds(start, end - start, length())) {
/*  641 */       throw new IndexOutOfBoundsException("expected: 0 <= start(" + start + ") <= end (" + end + ") <= length(" + 
/*  642 */           length() + ')');
/*      */     }
/*      */     
/*  645 */     if (start == 0 && end == length()) {
/*  646 */       return this;
/*      */     }
/*      */     
/*  649 */     if (end == start) {
/*  650 */       return EMPTY_STRING;
/*      */     }
/*      */     
/*  653 */     return new AsciiString(this.value, start + this.offset, end - start, copy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(CharSequence string) {
/*  666 */     return indexOf(string, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(CharSequence subString, int start) {
/*  680 */     int subCount = subString.length();
/*  681 */     if (start < 0) {
/*  682 */       start = 0;
/*      */     }
/*  684 */     if (subCount <= 0) {
/*  685 */       return (start < this.length) ? start : this.length;
/*      */     }
/*  687 */     if (subCount > this.length - start) {
/*  688 */       return -1;
/*      */     }
/*      */     
/*  691 */     char firstChar = subString.charAt(0);
/*  692 */     if (firstChar > 'ÿ') {
/*  693 */       return -1;
/*      */     }
/*  695 */     byte firstCharAsByte = c2b0(firstChar);
/*  696 */     int len = this.offset + this.length - subCount;
/*  697 */     for (int i = start + this.offset; i <= len; i++) {
/*  698 */       if (this.value[i] == firstCharAsByte) {
/*  699 */         int o1 = i, o2 = 0;
/*  700 */         while (++o2 < subCount && b2c(this.value[++o1]) == subString.charAt(o2));
/*      */ 
/*      */         
/*  703 */         if (o2 == subCount) {
/*  704 */           return i - this.offset;
/*      */         }
/*      */       } 
/*      */     } 
/*  708 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(char ch, int start) {
/*  721 */     if (ch > 'ÿ') {
/*  722 */       return -1;
/*      */     }
/*      */     
/*  725 */     if (start < 0) {
/*  726 */       start = 0;
/*      */     }
/*      */     
/*  729 */     byte chAsByte = c2b0(ch);
/*  730 */     int len = this.offset + this.length;
/*  731 */     for (int i = start + this.offset; i < len; i++) {
/*  732 */       if (this.value[i] == chAsByte) {
/*  733 */         return i - this.offset;
/*      */       }
/*      */     } 
/*  736 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lastIndexOf(CharSequence string) {
/*  750 */     return lastIndexOf(string, this.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lastIndexOf(CharSequence subString, int start) {
/*  764 */     int subCount = subString.length();
/*  765 */     start = Math.min(start, this.length - subCount);
/*  766 */     if (start < 0) {
/*  767 */       return -1;
/*      */     }
/*  769 */     if (subCount == 0) {
/*  770 */       return start;
/*      */     }
/*      */     
/*  773 */     char firstChar = subString.charAt(0);
/*  774 */     if (firstChar > 'ÿ') {
/*  775 */       return -1;
/*      */     }
/*  777 */     byte firstCharAsByte = c2b0(firstChar);
/*  778 */     for (int i = this.offset + start; i >= 0; i--) {
/*  779 */       if (this.value[i] == firstCharAsByte) {
/*  780 */         int o1 = i, o2 = 0;
/*  781 */         while (++o2 < subCount && b2c(this.value[++o1]) == subString.charAt(o2));
/*      */ 
/*      */         
/*  784 */         if (o2 == subCount) {
/*  785 */           return i - this.offset;
/*      */         }
/*      */       } 
/*      */     } 
/*  789 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean regionMatches(int thisStart, CharSequence string, int start, int length) {
/*  804 */     ObjectUtil.checkNotNull(string, "string");
/*      */     
/*  806 */     if (start < 0 || string.length() - start < length) {
/*  807 */       return false;
/*      */     }
/*      */     
/*  810 */     int thisLen = length();
/*  811 */     if (thisStart < 0 || thisLen - thisStart < length) {
/*  812 */       return false;
/*      */     }
/*      */     
/*  815 */     if (length <= 0) {
/*  816 */       return true;
/*      */     }
/*      */     
/*  819 */     int thatEnd = start + length;
/*  820 */     for (int i = start, j = thisStart + arrayOffset(); i < thatEnd; i++, j++) {
/*  821 */       if (b2c(this.value[j]) != string.charAt(i)) {
/*  822 */         return false;
/*      */       }
/*      */     } 
/*  825 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean regionMatches(boolean ignoreCase, int thisStart, CharSequence string, int start, int length) {
/*  841 */     if (!ignoreCase) {
/*  842 */       return regionMatches(thisStart, string, start, length);
/*      */     }
/*      */     
/*  845 */     ObjectUtil.checkNotNull(string, "string");
/*      */     
/*  847 */     int thisLen = length();
/*  848 */     if (thisStart < 0 || length > thisLen - thisStart) {
/*  849 */       return false;
/*      */     }
/*  851 */     if (start < 0 || length > string.length() - start) {
/*  852 */       return false;
/*      */     }
/*      */     
/*  855 */     thisStart += arrayOffset();
/*  856 */     int thisEnd = thisStart + length;
/*  857 */     while (thisStart < thisEnd) {
/*  858 */       if (!equalsIgnoreCase(b2c(this.value[thisStart++]), string.charAt(start++))) {
/*  859 */         return false;
/*      */       }
/*      */     } 
/*  862 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString replace(char oldChar, char newChar) {
/*  873 */     if (oldChar > 'ÿ') {
/*  874 */       return this;
/*      */     }
/*      */     
/*  877 */     byte oldCharAsByte = c2b0(oldChar);
/*  878 */     byte newCharAsByte = c2b(newChar);
/*  879 */     int len = this.offset + this.length;
/*  880 */     for (int i = this.offset; i < len; i++) {
/*  881 */       if (this.value[i] == oldCharAsByte) {
/*  882 */         byte[] buffer = PlatformDependent.allocateUninitializedArray(length());
/*  883 */         System.arraycopy(this.value, this.offset, buffer, 0, i - this.offset);
/*  884 */         buffer[i - this.offset] = newCharAsByte;
/*  885 */         i++;
/*  886 */         for (; i < len; i++) {
/*  887 */           byte oldValue = this.value[i];
/*  888 */           buffer[i - this.offset] = (oldValue != oldCharAsByte) ? oldValue : newCharAsByte;
/*      */         } 
/*  890 */         return new AsciiString(buffer, false);
/*      */       } 
/*      */     } 
/*  893 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean startsWith(CharSequence prefix) {
/*  904 */     return startsWith(prefix, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean startsWith(CharSequence prefix, int start) {
/*  918 */     return regionMatches(start, prefix, 0, prefix.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString toLowerCase() {
/*  927 */     boolean lowercased = true;
/*      */     
/*  929 */     int len = length() + arrayOffset(); int i;
/*  930 */     for (i = arrayOffset(); i < len; i++) {
/*  931 */       byte b = this.value[i];
/*  932 */       if (b >= 65 && b <= 90) {
/*  933 */         lowercased = false;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/*  939 */     if (lowercased) {
/*  940 */       return this;
/*      */     }
/*      */     
/*  943 */     byte[] newValue = PlatformDependent.allocateUninitializedArray(length()); int j;
/*  944 */     for (i = 0, j = arrayOffset(); i < newValue.length; i++, j++) {
/*  945 */       newValue[i] = toLowerCase(this.value[j]);
/*      */     }
/*      */     
/*  948 */     return new AsciiString(newValue, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString toUpperCase() {
/*  957 */     boolean uppercased = true;
/*      */     
/*  959 */     int len = length() + arrayOffset(); int i;
/*  960 */     for (i = arrayOffset(); i < len; i++) {
/*  961 */       byte b = this.value[i];
/*  962 */       if (b >= 97 && b <= 122) {
/*  963 */         uppercased = false;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/*  969 */     if (uppercased) {
/*  970 */       return this;
/*      */     }
/*      */     
/*  973 */     byte[] newValue = PlatformDependent.allocateUninitializedArray(length()); int j;
/*  974 */     for (i = 0, j = arrayOffset(); i < newValue.length; i++, j++) {
/*  975 */       newValue[i] = toUpperCase(this.value[j]);
/*      */     }
/*      */     
/*  978 */     return new AsciiString(newValue, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CharSequence trim(CharSequence c) {
/*  989 */     if (c instanceof AsciiString) {
/*  990 */       return ((AsciiString)c).trim();
/*      */     }
/*  992 */     if (c instanceof String) {
/*  993 */       return ((String)c).trim();
/*      */     }
/*  995 */     int start = 0, last = c.length() - 1;
/*  996 */     int end = last;
/*  997 */     while (start <= end && c.charAt(start) <= ' ') {
/*  998 */       start++;
/*      */     }
/* 1000 */     while (end >= start && c.charAt(end) <= ' ') {
/* 1001 */       end--;
/*      */     }
/* 1003 */     if (start == 0 && end == last) {
/* 1004 */       return c;
/*      */     }
/* 1006 */     return c.subSequence(start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString trim() {
/* 1016 */     int start = arrayOffset(), last = arrayOffset() + length() - 1;
/* 1017 */     int end = last;
/* 1018 */     while (start <= end && this.value[start] <= 32) {
/* 1019 */       start++;
/*      */     }
/* 1021 */     while (end >= start && this.value[end] <= 32) {
/* 1022 */       end--;
/*      */     }
/* 1024 */     if (start == 0 && end == last) {
/* 1025 */       return this;
/*      */     }
/* 1027 */     return new AsciiString(this.value, start, end - start + 1, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contentEquals(CharSequence a) {
/* 1037 */     if (this == a) {
/* 1038 */       return true;
/*      */     }
/*      */     
/* 1041 */     if (a == null || a.length() != length()) {
/* 1042 */       return false;
/*      */     }
/* 1044 */     if (a instanceof AsciiString) {
/* 1045 */       return equals(a);
/*      */     }
/*      */     
/* 1048 */     for (int i = arrayOffset(), j = 0; j < a.length(); i++, j++) {
/* 1049 */       if (b2c(this.value[i]) != a.charAt(j)) {
/* 1050 */         return false;
/*      */       }
/*      */     } 
/* 1053 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String expr) {
/* 1065 */     return Pattern.matches(expr, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString[] split(String expr, int max) {
/* 1080 */     return toAsciiStringArray(Pattern.compile(expr).split(this, max));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsciiString[] split(char delim) {
/* 1087 */     List<AsciiString> res = InternalThreadLocalMap.get().arrayList();
/*      */     
/* 1089 */     int start = 0;
/* 1090 */     int length = length(); int i;
/* 1091 */     for (i = start; i < length; i++) {
/* 1092 */       if (charAt(i) == delim) {
/* 1093 */         if (start == i) {
/* 1094 */           res.add(EMPTY_STRING);
/*      */         } else {
/* 1096 */           res.add(new AsciiString(this.value, start + arrayOffset(), i - start, false));
/*      */         } 
/* 1098 */         start = i + 1;
/*      */       } 
/*      */     } 
/*      */     
/* 1102 */     if (start == 0) {
/* 1103 */       res.add(this);
/*      */     }
/* 1105 */     else if (start != length) {
/*      */       
/* 1107 */       res.add(new AsciiString(this.value, start + arrayOffset(), length - start, false));
/*      */     } else {
/*      */       
/* 1110 */       for (i = res.size() - 1; i >= 0 && (
/* 1111 */         (AsciiString)res.get(i)).isEmpty(); i--) {
/* 1112 */         res.remove(i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1120 */     return res.<AsciiString>toArray(new AsciiString[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1130 */     int h = this.hash;
/* 1131 */     if (h == 0) {
/* 1132 */       h = PlatformDependent.hashCodeAscii(this.value, this.offset, this.length);
/* 1133 */       this.hash = h;
/*      */     } 
/* 1135 */     return h;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1140 */     if (obj == null || obj.getClass() != AsciiString.class) {
/* 1141 */       return false;
/*      */     }
/* 1143 */     if (this == obj) {
/* 1144 */       return true;
/*      */     }
/*      */     
/* 1147 */     AsciiString other = (AsciiString)obj;
/* 1148 */     return (length() == other.length() && 
/* 1149 */       hashCode() == other.hashCode() && 
/* 1150 */       PlatformDependent.equals(array(), arrayOffset(), other.array(), other.arrayOffset(), length()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1159 */     String cache = this.string;
/* 1160 */     if (cache == null) {
/* 1161 */       cache = toString(0);
/* 1162 */       this.string = cache;
/*      */     } 
/* 1164 */     return cache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(int start) {
/* 1172 */     return toString(start, length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(int start, int end) {
/* 1179 */     int length = end - start;
/* 1180 */     if (length == 0) {
/* 1181 */       return "";
/*      */     }
/*      */     
/* 1184 */     if (MathUtil.isOutOfBounds(start, length, length())) {
/* 1185 */       throw new IndexOutOfBoundsException("expected: 0 <= start(" + start + ") <= srcIdx + length(" + length + ") <= srcLen(" + 
/* 1186 */           length() + ')');
/*      */     }
/*      */ 
/*      */     
/* 1190 */     String str = new String(this.value, 0, start + this.offset, length);
/* 1191 */     return str;
/*      */   }
/*      */   
/*      */   public boolean parseBoolean() {
/* 1195 */     return (this.length >= 1 && this.value[this.offset] != 0);
/*      */   }
/*      */   
/*      */   public char parseChar() {
/* 1199 */     return parseChar(0);
/*      */   }
/*      */   
/*      */   public char parseChar(int start) {
/* 1203 */     if (start + 1 >= length()) {
/* 1204 */       throw new IndexOutOfBoundsException("2 bytes required to convert to character. index " + start + " would go out of bounds.");
/*      */     }
/*      */     
/* 1207 */     int startWithOffset = start + this.offset;
/* 1208 */     return (char)(b2c(this.value[startWithOffset]) << 8 | b2c(this.value[startWithOffset + 1]));
/*      */   }
/*      */   
/*      */   public short parseShort() {
/* 1212 */     return parseShort(0, length(), 10);
/*      */   }
/*      */   
/*      */   public short parseShort(int radix) {
/* 1216 */     return parseShort(0, length(), radix);
/*      */   }
/*      */   
/*      */   public short parseShort(int start, int end) {
/* 1220 */     return parseShort(start, end, 10);
/*      */   }
/*      */   
/*      */   public short parseShort(int start, int end, int radix) {
/* 1224 */     int intValue = parseInt(start, end, radix);
/* 1225 */     short result = (short)intValue;
/* 1226 */     if (result != intValue) {
/* 1227 */       throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */     }
/* 1229 */     return result;
/*      */   }
/*      */   
/*      */   public int parseInt() {
/* 1233 */     return parseInt(0, length(), 10);
/*      */   }
/*      */   
/*      */   public int parseInt(int radix) {
/* 1237 */     return parseInt(0, length(), radix);
/*      */   }
/*      */   
/*      */   public int parseInt(int start, int end) {
/* 1241 */     return parseInt(start, end, 10);
/*      */   }
/*      */   
/*      */   public int parseInt(int start, int end, int radix) {
/* 1245 */     if (radix < 2 || radix > 36) {
/* 1246 */       throw new NumberFormatException();
/*      */     }
/*      */     
/* 1249 */     if (start == end) {
/* 1250 */       throw new NumberFormatException();
/*      */     }
/*      */     
/* 1253 */     int i = start;
/* 1254 */     boolean negative = (byteAt(i) == 45);
/* 1255 */     if (negative && ++i == end) {
/* 1256 */       throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */     }
/*      */     
/* 1259 */     return parseInt(i, end, radix, negative);
/*      */   }
/*      */   
/*      */   private int parseInt(int start, int end, int radix, boolean negative) {
/* 1263 */     int max = Integer.MIN_VALUE / radix;
/* 1264 */     int result = 0;
/* 1265 */     int currOffset = start;
/* 1266 */     while (currOffset < end) {
/* 1267 */       int digit = Character.digit((char)(this.value[currOffset++ + this.offset] & 0xFF), radix);
/* 1268 */       if (digit == -1) {
/* 1269 */         throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */       }
/* 1271 */       if (max > result) {
/* 1272 */         throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */       }
/* 1274 */       int next = result * radix - digit;
/* 1275 */       if (next > result) {
/* 1276 */         throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */       }
/* 1278 */       result = next;
/*      */     } 
/* 1280 */     if (!negative) {
/* 1281 */       result = -result;
/* 1282 */       if (result < 0) {
/* 1283 */         throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */       }
/*      */     } 
/* 1286 */     return result;
/*      */   }
/*      */   
/*      */   public long parseLong() {
/* 1290 */     return parseLong(0, length(), 10);
/*      */   }
/*      */   
/*      */   public long parseLong(int radix) {
/* 1294 */     return parseLong(0, length(), radix);
/*      */   }
/*      */   
/*      */   public long parseLong(int start, int end) {
/* 1298 */     return parseLong(start, end, 10);
/*      */   }
/*      */   
/*      */   public long parseLong(int start, int end, int radix) {
/* 1302 */     if (radix < 2 || radix > 36) {
/* 1303 */       throw new NumberFormatException();
/*      */     }
/*      */     
/* 1306 */     if (start == end) {
/* 1307 */       throw new NumberFormatException();
/*      */     }
/*      */     
/* 1310 */     int i = start;
/* 1311 */     boolean negative = (byteAt(i) == 45);
/* 1312 */     if (negative && ++i == end) {
/* 1313 */       throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */     }
/*      */     
/* 1316 */     return parseLong(i, end, radix, negative);
/*      */   }
/*      */   
/*      */   private long parseLong(int start, int end, int radix, boolean negative) {
/* 1320 */     long max = Long.MIN_VALUE / radix;
/* 1321 */     long result = 0L;
/* 1322 */     int currOffset = start;
/* 1323 */     while (currOffset < end) {
/* 1324 */       int digit = Character.digit((char)(this.value[currOffset++ + this.offset] & 0xFF), radix);
/* 1325 */       if (digit == -1) {
/* 1326 */         throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */       }
/* 1328 */       if (max > result) {
/* 1329 */         throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */       }
/* 1331 */       long next = result * radix - digit;
/* 1332 */       if (next > result) {
/* 1333 */         throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */       }
/* 1335 */       result = next;
/*      */     } 
/* 1337 */     if (!negative) {
/* 1338 */       result = -result;
/* 1339 */       if (result < 0L) {
/* 1340 */         throw new NumberFormatException(subSequence(start, end, false).toString());
/*      */       }
/*      */     } 
/* 1343 */     return result;
/*      */   }
/*      */   
/*      */   public float parseFloat() {
/* 1347 */     return parseFloat(0, length());
/*      */   }
/*      */   
/*      */   public float parseFloat(int start, int end) {
/* 1351 */     return Float.parseFloat(toString(start, end));
/*      */   }
/*      */   
/*      */   public double parseDouble() {
/* 1355 */     return parseDouble(0, length());
/*      */   }
/*      */   
/*      */   public double parseDouble(int start, int end) {
/* 1359 */     return Double.parseDouble(toString(start, end));
/*      */   }
/*      */   
/* 1362 */   public static final HashingStrategy<CharSequence> CASE_INSENSITIVE_HASHER = new HashingStrategy<CharSequence>()
/*      */     {
/*      */       public int hashCode(CharSequence o)
/*      */       {
/* 1366 */         return AsciiString.hashCode(o);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(CharSequence a, CharSequence b) {
/* 1371 */         return AsciiString.contentEqualsIgnoreCase(a, b);
/*      */       }
/*      */     };
/*      */   
/* 1375 */   public static final HashingStrategy<CharSequence> CASE_SENSITIVE_HASHER = new HashingStrategy<CharSequence>()
/*      */     {
/*      */       public int hashCode(CharSequence o)
/*      */       {
/* 1379 */         return AsciiString.hashCode(o);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(CharSequence a, CharSequence b) {
/* 1384 */         return AsciiString.contentEquals(a, b);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AsciiString of(CharSequence string) {
/* 1393 */     return (string instanceof AsciiString) ? (AsciiString)string : new AsciiString(string);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AsciiString cached(String string) {
/* 1403 */     AsciiString asciiString = new AsciiString(string);
/* 1404 */     asciiString.string = string;
/* 1405 */     return asciiString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hashCode(CharSequence value) {
/* 1414 */     if (value == null) {
/* 1415 */       return 0;
/*      */     }
/* 1417 */     if (value instanceof AsciiString) {
/* 1418 */       return value.hashCode();
/*      */     }
/*      */     
/* 1421 */     return PlatformDependent.hashCodeAscii(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(CharSequence a, CharSequence b) {
/* 1428 */     return contains(a, b, DefaultCharEqualityComparator.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsIgnoreCase(CharSequence a, CharSequence b) {
/* 1435 */     return contains(a, b, AsciiCaseInsensitiveCharEqualityComparator.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEqualsIgnoreCase(CharSequence a, CharSequence b) {
/* 1443 */     if (a == null || b == null) {
/* 1444 */       return (a == b);
/*      */     }
/*      */     
/* 1447 */     if (a instanceof AsciiString) {
/* 1448 */       return ((AsciiString)a).contentEqualsIgnoreCase(b);
/*      */     }
/* 1450 */     if (b instanceof AsciiString) {
/* 1451 */       return ((AsciiString)b).contentEqualsIgnoreCase(a);
/*      */     }
/*      */     
/* 1454 */     if (a.length() != b.length()) {
/* 1455 */       return false;
/*      */     }
/* 1457 */     for (int i = 0; i < a.length(); i++) {
/* 1458 */       if (!equalsIgnoreCase(a.charAt(i), b.charAt(i))) {
/* 1459 */         return false;
/*      */       }
/*      */     } 
/* 1462 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsContentEqualsIgnoreCase(Collection<CharSequence> collection, CharSequence value) {
/* 1475 */     for (CharSequence v : collection) {
/* 1476 */       if (contentEqualsIgnoreCase(value, v)) {
/* 1477 */         return true;
/*      */       }
/*      */     } 
/* 1480 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsAllContentEqualsIgnoreCase(Collection<CharSequence> a, Collection<CharSequence> b) {
/* 1493 */     for (CharSequence v : b) {
/* 1494 */       if (!containsContentEqualsIgnoreCase(a, v)) {
/* 1495 */         return false;
/*      */       }
/*      */     } 
/* 1498 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contentEquals(CharSequence a, CharSequence b) {
/* 1505 */     if (a == null || b == null) {
/* 1506 */       return (a == b);
/*      */     }
/*      */     
/* 1509 */     if (a instanceof AsciiString) {
/* 1510 */       return ((AsciiString)a).contentEquals(b);
/*      */     }
/*      */     
/* 1513 */     if (b instanceof AsciiString) {
/* 1514 */       return ((AsciiString)b).contentEquals(a);
/*      */     }
/*      */     
/* 1517 */     if (a.length() != b.length()) {
/* 1518 */       return false;
/*      */     }
/* 1520 */     for (int i = 0; i < a.length(); i++) {
/* 1521 */       if (a.charAt(i) != b.charAt(i)) {
/* 1522 */         return false;
/*      */       }
/*      */     } 
/* 1525 */     return true;
/*      */   }
/*      */   
/*      */   private static AsciiString[] toAsciiStringArray(String[] jdkResult) {
/* 1529 */     AsciiString[] res = new AsciiString[jdkResult.length];
/* 1530 */     for (int i = 0; i < jdkResult.length; i++) {
/* 1531 */       res[i] = new AsciiString(jdkResult[i]);
/*      */     }
/* 1533 */     return res;
/*      */   }
/*      */   
/*      */   private static interface CharEqualityComparator {
/*      */     boolean equals(char param1Char1, char param1Char2);
/*      */   }
/*      */   
/*      */   private static final class DefaultCharEqualityComparator implements CharEqualityComparator {
/* 1541 */     static final DefaultCharEqualityComparator INSTANCE = new DefaultCharEqualityComparator();
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(char a, char b) {
/* 1546 */       return (a == b);
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class AsciiCaseInsensitiveCharEqualityComparator
/*      */     implements CharEqualityComparator {
/* 1552 */     static final AsciiCaseInsensitiveCharEqualityComparator INSTANCE = new AsciiCaseInsensitiveCharEqualityComparator();
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(char a, char b) {
/* 1557 */       return AsciiString.equalsIgnoreCase(a, b);
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class GeneralCaseInsensitiveCharEqualityComparator
/*      */     implements CharEqualityComparator {
/* 1563 */     static final GeneralCaseInsensitiveCharEqualityComparator INSTANCE = new GeneralCaseInsensitiveCharEqualityComparator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(char a, char b) {
/* 1569 */       return (Character.toUpperCase(a) == Character.toUpperCase(b) || 
/* 1570 */         Character.toLowerCase(a) == Character.toLowerCase(b));
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean contains(CharSequence a, CharSequence b, CharEqualityComparator cmp) {
/* 1575 */     if (a == null || b == null || a.length() < b.length()) {
/* 1576 */       return false;
/*      */     }
/* 1578 */     if (b.length() == 0) {
/* 1579 */       return true;
/*      */     }
/* 1581 */     int bStart = 0;
/* 1582 */     for (int i = 0; i < a.length(); i++) {
/* 1583 */       if (cmp.equals(b.charAt(bStart), a.charAt(i))) {
/*      */         
/* 1585 */         if (++bStart == b.length())
/* 1586 */           return true; 
/*      */       } else {
/* 1588 */         if (a.length() - i < b.length())
/*      */         {
/* 1590 */           return false;
/*      */         }
/* 1592 */         bStart = 0;
/*      */       } 
/*      */     } 
/* 1595 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean regionMatchesCharSequences(CharSequence cs, int csStart, CharSequence string, int start, int length, CharEqualityComparator charEqualityComparator) {
/* 1602 */     if (csStart < 0 || length > cs.length() - csStart) {
/* 1603 */       return false;
/*      */     }
/* 1605 */     if (start < 0 || length > string.length() - start) {
/* 1606 */       return false;
/*      */     }
/*      */     
/* 1609 */     int csIndex = csStart;
/* 1610 */     int csEnd = csIndex + length;
/* 1611 */     int stringIndex = start;
/*      */     
/* 1613 */     while (csIndex < csEnd) {
/* 1614 */       char c1 = cs.charAt(csIndex++);
/* 1615 */       char c2 = string.charAt(stringIndex++);
/*      */       
/* 1617 */       if (!charEqualityComparator.equals(c1, c2)) {
/* 1618 */         return false;
/*      */       }
/*      */     } 
/* 1621 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean regionMatches(CharSequence cs, boolean ignoreCase, int csStart, CharSequence string, int start, int length) {
/* 1636 */     if (cs == null || string == null) {
/* 1637 */       return false;
/*      */     }
/*      */     
/* 1640 */     if (cs instanceof String && string instanceof String) {
/* 1641 */       return ((String)cs).regionMatches(ignoreCase, csStart, (String)string, start, length);
/*      */     }
/*      */     
/* 1644 */     if (cs instanceof AsciiString) {
/* 1645 */       return ((AsciiString)cs).regionMatches(ignoreCase, csStart, string, start, length);
/*      */     }
/*      */     
/* 1648 */     return regionMatchesCharSequences(cs, csStart, string, start, length, ignoreCase ? GeneralCaseInsensitiveCharEqualityComparator.INSTANCE : DefaultCharEqualityComparator.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean regionMatchesAscii(CharSequence cs, boolean ignoreCase, int csStart, CharSequence string, int start, int length) {
/* 1665 */     if (cs == null || string == null) {
/* 1666 */       return false;
/*      */     }
/*      */     
/* 1669 */     if (!ignoreCase && cs instanceof String && string instanceof String)
/*      */     {
/*      */ 
/*      */       
/* 1673 */       return ((String)cs).regionMatches(false, csStart, (String)string, start, length);
/*      */     }
/*      */     
/* 1676 */     if (cs instanceof AsciiString) {
/* 1677 */       return ((AsciiString)cs).regionMatches(ignoreCase, csStart, string, start, length);
/*      */     }
/*      */     
/* 1680 */     return regionMatchesCharSequences(cs, csStart, string, start, length, ignoreCase ? AsciiCaseInsensitiveCharEqualityComparator.INSTANCE : DefaultCharEqualityComparator.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos) {
/* 1716 */     if (str == null || searchStr == null) {
/* 1717 */       return -1;
/*      */     }
/* 1719 */     if (startPos < 0) {
/* 1720 */       startPos = 0;
/*      */     }
/* 1722 */     int searchStrLen = searchStr.length();
/* 1723 */     int endLimit = str.length() - searchStrLen + 1;
/* 1724 */     if (startPos > endLimit) {
/* 1725 */       return -1;
/*      */     }
/* 1727 */     if (searchStrLen == 0) {
/* 1728 */       return startPos;
/*      */     }
/* 1730 */     for (int i = startPos; i < endLimit; i++) {
/* 1731 */       if (regionMatches(str, true, i, searchStr, 0, searchStrLen)) {
/* 1732 */         return i;
/*      */       }
/*      */     } 
/* 1735 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCaseAscii(CharSequence str, CharSequence searchStr, int startPos) {
/* 1769 */     if (str == null || searchStr == null) {
/* 1770 */       return -1;
/*      */     }
/* 1772 */     if (startPos < 0) {
/* 1773 */       startPos = 0;
/*      */     }
/* 1775 */     int searchStrLen = searchStr.length();
/* 1776 */     int endLimit = str.length() - searchStrLen + 1;
/* 1777 */     if (startPos > endLimit) {
/* 1778 */       return -1;
/*      */     }
/* 1780 */     if (searchStrLen == 0) {
/* 1781 */       return startPos;
/*      */     }
/* 1783 */     for (int i = startPos; i < endLimit; i++) {
/* 1784 */       if (regionMatchesAscii(str, true, i, searchStr, 0, searchStrLen)) {
/* 1785 */         return i;
/*      */       }
/*      */     } 
/* 1788 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence cs, char searchChar, int start) {
/* 1803 */     if (cs instanceof String)
/* 1804 */       return ((String)cs).indexOf(searchChar, start); 
/* 1805 */     if (cs instanceof AsciiString) {
/* 1806 */       return ((AsciiString)cs).indexOf(searchChar, start);
/*      */     }
/* 1808 */     if (cs == null) {
/* 1809 */       return -1;
/*      */     }
/* 1811 */     int sz = cs.length();
/* 1812 */     for (int i = (start < 0) ? 0 : start; i < sz; i++) {
/* 1813 */       if (cs.charAt(i) == searchChar) {
/* 1814 */         return i;
/*      */       }
/*      */     } 
/* 1817 */     return -1;
/*      */   }
/*      */   
/*      */   private static boolean equalsIgnoreCase(byte a, byte b) {
/* 1821 */     return (a == b || toLowerCase(a) == toLowerCase(b));
/*      */   }
/*      */   
/*      */   private static boolean equalsIgnoreCase(char a, char b) {
/* 1825 */     return (a == b || toLowerCase(a) == toLowerCase(b));
/*      */   }
/*      */   
/*      */   private static byte toLowerCase(byte b) {
/* 1829 */     return isUpperCase(b) ? (byte)(b + 32) : b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char toLowerCase(char c) {
/* 1839 */     return isUpperCase(c) ? (char)(c + 32) : c;
/*      */   }
/*      */   
/*      */   private static byte toUpperCase(byte b) {
/* 1843 */     return isLowerCase(b) ? (byte)(b - 32) : b;
/*      */   }
/*      */   
/*      */   private static boolean isLowerCase(byte value) {
/* 1847 */     return (value >= 97 && value <= 122);
/*      */   }
/*      */   
/*      */   public static boolean isUpperCase(byte value) {
/* 1851 */     return (value >= 65 && value <= 90);
/*      */   }
/*      */   
/*      */   public static boolean isUpperCase(char value) {
/* 1855 */     return (value >= 'A' && value <= 'Z');
/*      */   }
/*      */   
/*      */   public static byte c2b(char c) {
/* 1859 */     return (byte)((c > 'ÿ') ? 63 : c);
/*      */   }
/*      */   
/*      */   private static byte c2b0(char c) {
/* 1863 */     return (byte)c;
/*      */   }
/*      */   
/*      */   public static char b2c(byte b) {
/* 1867 */     return (char)(b & 0xFF);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\AsciiString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */