/*     */ package io.netty.util;
/*     */ 
/*     */ import io.netty.util.concurrent.FastThreadLocal;
/*     */ import io.netty.util.internal.ObjectPool;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueue;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import org.jetbrains.annotations.VisibleForTesting;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Recycler<T>
/*     */ {
/*  43 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(Recycler.class);
/*  44 */   private static final EnhancedHandle<?> NOOP_HANDLE = new EnhancedHandle()
/*     */     {
/*     */       public void recycle(Object object) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void unguardedRecycle(Object object) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String toString() {
/*  57 */         return "NOOP_HANDLE";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_INITIAL_MAX_CAPACITY_PER_THREAD = 4096;
/*     */   
/*     */   private static final int DEFAULT_MAX_CAPACITY_PER_THREAD;
/*     */   
/*     */   private static final int RATIO;
/*     */ 
/*     */   
/*     */   static {
/*  71 */     int maxCapacityPerThread = SystemPropertyUtil.getInt("io.netty.recycler.maxCapacityPerThread", 
/*  72 */         SystemPropertyUtil.getInt("io.netty.recycler.maxCapacity", 4096));
/*  73 */     if (maxCapacityPerThread < 0) {
/*  74 */       maxCapacityPerThread = 4096;
/*     */     }
/*     */     
/*  77 */     DEFAULT_MAX_CAPACITY_PER_THREAD = maxCapacityPerThread;
/*  78 */   } private static final int DEFAULT_QUEUE_CHUNK_SIZE_PER_THREAD = SystemPropertyUtil.getInt("io.netty.recycler.chunkSize", 32);
/*     */   private static final boolean BLOCKING_POOL;
/*     */   private static final boolean BATCH_FAST_TL_ONLY;
/*     */   
/*     */   static {
/*  83 */     RATIO = Math.max(0, SystemPropertyUtil.getInt("io.netty.recycler.ratio", 8));
/*     */     
/*  85 */     BLOCKING_POOL = SystemPropertyUtil.getBoolean("io.netty.recycler.blocking", false);
/*  86 */     BATCH_FAST_TL_ONLY = SystemPropertyUtil.getBoolean("io.netty.recycler.batchFastThreadLocalOnly", true);
/*     */     
/*  88 */     if (logger.isDebugEnabled())
/*  89 */       if (DEFAULT_MAX_CAPACITY_PER_THREAD == 0) {
/*  90 */         logger.debug("-Dio.netty.recycler.maxCapacityPerThread: disabled");
/*  91 */         logger.debug("-Dio.netty.recycler.ratio: disabled");
/*  92 */         logger.debug("-Dio.netty.recycler.chunkSize: disabled");
/*  93 */         logger.debug("-Dio.netty.recycler.blocking: disabled");
/*  94 */         logger.debug("-Dio.netty.recycler.batchFastThreadLocalOnly: disabled");
/*     */       } else {
/*  96 */         logger.debug("-Dio.netty.recycler.maxCapacityPerThread: {}", Integer.valueOf(DEFAULT_MAX_CAPACITY_PER_THREAD));
/*  97 */         logger.debug("-Dio.netty.recycler.ratio: {}", Integer.valueOf(RATIO));
/*  98 */         logger.debug("-Dio.netty.recycler.chunkSize: {}", Integer.valueOf(DEFAULT_QUEUE_CHUNK_SIZE_PER_THREAD));
/*  99 */         logger.debug("-Dio.netty.recycler.blocking: {}", Boolean.valueOf(BLOCKING_POOL));
/* 100 */         logger.debug("-Dio.netty.recycler.batchFastThreadLocalOnly: {}", Boolean.valueOf(BATCH_FAST_TL_ONLY));
/*     */       }  
/*     */   }
/*     */   
/*     */   private final int maxCapacityPerThread;
/*     */   private final int interval;
/*     */   private final int chunkSize;
/*     */   
/* 108 */   private final FastThreadLocal<LocalPool<T>> threadLocal = new FastThreadLocal<LocalPool<T>>()
/*     */     {
/*     */       protected Recycler.LocalPool<T> initialValue() {
/* 111 */         return new Recycler.LocalPool<T>(Recycler.this.maxCapacityPerThread, Recycler.this.interval, Recycler.this.chunkSize);
/*     */       }
/*     */ 
/*     */       
/*     */       protected void onRemoval(Recycler.LocalPool<T> value) throws Exception {
/* 116 */         super.onRemoval(value);
/* 117 */         MessagePassingQueue<Recycler.DefaultHandle<T>> handles = value.pooledHandles;
/* 118 */         value.pooledHandles = null;
/* 119 */         value.owner = null;
/* 120 */         handles.clear();
/*     */       }
/*     */     };
/*     */   
/*     */   protected Recycler() {
/* 125 */     this(DEFAULT_MAX_CAPACITY_PER_THREAD);
/*     */   }
/*     */   
/*     */   protected Recycler(int maxCapacityPerThread) {
/* 129 */     this(maxCapacityPerThread, RATIO, DEFAULT_QUEUE_CHUNK_SIZE_PER_THREAD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Recycler(int maxCapacityPerThread, int maxSharedCapacityFactor) {
/* 139 */     this(maxCapacityPerThread, RATIO, DEFAULT_QUEUE_CHUNK_SIZE_PER_THREAD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Recycler(int maxCapacityPerThread, int maxSharedCapacityFactor, int ratio, int maxDelayedQueuesPerThread) {
/* 150 */     this(maxCapacityPerThread, ratio, DEFAULT_QUEUE_CHUNK_SIZE_PER_THREAD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Recycler(int maxCapacityPerThread, int maxSharedCapacityFactor, int ratio, int maxDelayedQueuesPerThread, int delayedQueueRatio) {
/* 161 */     this(maxCapacityPerThread, ratio, DEFAULT_QUEUE_CHUNK_SIZE_PER_THREAD);
/*     */   }
/*     */   
/*     */   protected Recycler(int maxCapacityPerThread, int ratio, int chunkSize) {
/* 165 */     this.interval = Math.max(0, ratio);
/* 166 */     if (maxCapacityPerThread <= 0) {
/* 167 */       this.maxCapacityPerThread = 0;
/* 168 */       this.chunkSize = 0;
/*     */     } else {
/* 170 */       this.maxCapacityPerThread = Math.max(4, maxCapacityPerThread);
/* 171 */       this.chunkSize = Math.max(2, Math.min(chunkSize, this.maxCapacityPerThread >> 1));
/*     */     } 
/*     */   }
/*     */   
/*     */   public final T get() {
/*     */     T obj;
/* 177 */     if (this.maxCapacityPerThread == 0) {
/* 178 */       return newObject((Handle)NOOP_HANDLE);
/*     */     }
/* 180 */     LocalPool<T> localPool = (LocalPool<T>)this.threadLocal.get();
/* 181 */     DefaultHandle<T> handle = localPool.claim();
/*     */     
/* 183 */     if (handle == null) {
/* 184 */       handle = localPool.newHandle();
/* 185 */       if (handle != null) {
/* 186 */         obj = newObject(handle);
/* 187 */         handle.set(obj);
/*     */       } else {
/* 189 */         obj = newObject((Handle)NOOP_HANDLE);
/*     */       } 
/*     */     } else {
/* 192 */       obj = handle.get();
/*     */     } 
/*     */     
/* 195 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final boolean recycle(T o, Handle<T> handle) {
/* 203 */     if (handle == NOOP_HANDLE) {
/* 204 */       return false;
/*     */     }
/*     */     
/* 207 */     handle.recycle(o);
/* 208 */     return true;
/*     */   }
/*     */   
/*     */   @VisibleForTesting
/*     */   final int threadLocalSize() {
/* 213 */     LocalPool<T> localPool = (LocalPool<T>)this.threadLocal.getIfExists();
/* 214 */     return (localPool == null) ? 0 : (localPool.pooledHandles.size() + localPool.batch.size());
/*     */   }
/*     */   
/*     */   protected abstract T newObject(Handle<T> paramHandle);
/*     */   
/*     */   public static interface Handle<T>
/*     */     extends ObjectPool.Handle<T> {}
/*     */   
/*     */   public static abstract class EnhancedHandle<T>
/*     */     implements Handle<T> {
/*     */     private EnhancedHandle() {}
/*     */     
/*     */     public abstract void unguardedRecycle(Object param1Object);
/*     */   }
/*     */   
/*     */   private static final class DefaultHandle<T>
/*     */     extends EnhancedHandle<T> {
/*     */     private static final int STATE_CLAIMED = 0;
/*     */     private static final int STATE_AVAILABLE = 1;
/*     */     private static final AtomicIntegerFieldUpdater<DefaultHandle<?>> STATE_UPDATER;
/*     */     private volatile int state;
/*     */     private final Recycler.LocalPool<T> localPool;
/*     */     private T value;
/*     */     
/*     */     static {
/* 239 */       AtomicIntegerFieldUpdater<?> updater = AtomicIntegerFieldUpdater.newUpdater(DefaultHandle.class, "state");
/*     */       
/* 241 */       STATE_UPDATER = (AtomicIntegerFieldUpdater)updater;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DefaultHandle(Recycler.LocalPool<T> localPool) {
/* 249 */       this.localPool = localPool;
/*     */     }
/*     */ 
/*     */     
/*     */     public void recycle(Object object) {
/* 254 */       if (object != this.value) {
/* 255 */         throw new IllegalArgumentException("object does not belong to handle");
/*     */       }
/* 257 */       this.localPool.release(this, true);
/*     */     }
/*     */ 
/*     */     
/*     */     public void unguardedRecycle(Object object) {
/* 262 */       if (object != this.value) {
/* 263 */         throw new IllegalArgumentException("object does not belong to handle");
/*     */       }
/* 265 */       this.localPool.release(this, false);
/*     */     }
/*     */     
/*     */     T get() {
/* 269 */       return this.value;
/*     */     }
/*     */     
/*     */     void set(T value) {
/* 273 */       this.value = value;
/*     */     }
/*     */     
/*     */     void toClaimed() {
/* 277 */       assert this.state == 1;
/* 278 */       STATE_UPDATER.lazySet(this, 0);
/*     */     }
/*     */     
/*     */     void toAvailable() {
/* 282 */       int prev = STATE_UPDATER.getAndSet(this, 1);
/* 283 */       if (prev == 1) {
/* 284 */         throw new IllegalStateException("Object has been recycled already.");
/*     */       }
/*     */     }
/*     */     
/*     */     void unguardedToAvailable() {
/* 289 */       int prev = this.state;
/* 290 */       if (prev == 1) {
/* 291 */         throw new IllegalStateException("Object has been recycled already.");
/*     */       }
/* 293 */       STATE_UPDATER.lazySet(this, 1);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class LocalPool<T>
/*     */     implements MessagePassingQueue.Consumer<DefaultHandle<T>> {
/*     */     private final int ratioInterval;
/*     */     private final int chunkSize;
/*     */     private final ArrayDeque<Recycler.DefaultHandle<T>> batch;
/*     */     private volatile Thread owner;
/*     */     private volatile MessagePassingQueue<Recycler.DefaultHandle<T>> pooledHandles;
/*     */     private int ratioCounter;
/*     */     
/*     */     LocalPool(int maxCapacity, int ratioInterval, int chunkSize) {
/* 307 */       this.ratioInterval = ratioInterval;
/* 308 */       this.chunkSize = chunkSize;
/* 309 */       this.batch = new ArrayDeque<Recycler.DefaultHandle<T>>(chunkSize);
/* 310 */       Thread currentThread = Thread.currentThread();
/* 311 */       this.owner = (!Recycler.BATCH_FAST_TL_ONLY || currentThread instanceof io.netty.util.concurrent.FastThreadLocalThread) ? currentThread : null;
/* 312 */       if (Recycler.BLOCKING_POOL) {
/* 313 */         this.pooledHandles = new Recycler.BlockingMessageQueue<Recycler.DefaultHandle<T>>(maxCapacity);
/*     */       } else {
/* 315 */         this.pooledHandles = (MessagePassingQueue<Recycler.DefaultHandle<T>>)PlatformDependent.newMpscQueue(chunkSize, maxCapacity);
/*     */       } 
/* 317 */       this.ratioCounter = ratioInterval;
/*     */     }
/*     */     
/*     */     Recycler.DefaultHandle<T> claim() {
/* 321 */       MessagePassingQueue<Recycler.DefaultHandle<T>> handles = this.pooledHandles;
/* 322 */       if (handles == null) {
/* 323 */         return null;
/*     */       }
/* 325 */       if (this.batch.isEmpty()) {
/* 326 */         handles.drain(this, this.chunkSize);
/*     */       }
/* 328 */       Recycler.DefaultHandle<T> handle = this.batch.pollFirst();
/* 329 */       if (null != handle) {
/* 330 */         handle.toClaimed();
/*     */       }
/* 332 */       return handle;
/*     */     }
/*     */     
/*     */     void release(Recycler.DefaultHandle<T> handle, boolean guarded) {
/* 336 */       if (guarded) {
/* 337 */         handle.toAvailable();
/*     */       } else {
/* 339 */         handle.unguardedToAvailable();
/*     */       } 
/* 341 */       Thread owner = this.owner;
/* 342 */       if (owner != null && Thread.currentThread() == owner && this.batch.size() < this.chunkSize) {
/* 343 */         accept(handle);
/* 344 */       } else if (owner != null && isTerminated(owner)) {
/* 345 */         this.owner = null;
/* 346 */         this.pooledHandles = null;
/*     */       } else {
/* 348 */         MessagePassingQueue<Recycler.DefaultHandle<T>> handles = this.pooledHandles;
/* 349 */         if (handles != null) {
/* 350 */           handles.relaxedOffer(handle);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean isTerminated(Thread owner) {
/* 358 */       return PlatformDependent.isJ9Jvm() ? (!owner.isAlive()) : ((owner.getState() == Thread.State.TERMINATED));
/*     */     }
/*     */     
/*     */     Recycler.DefaultHandle<T> newHandle() {
/* 362 */       if (++this.ratioCounter >= this.ratioInterval) {
/* 363 */         this.ratioCounter = 0;
/* 364 */         return new Recycler.DefaultHandle<T>(this);
/*     */       } 
/* 366 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Recycler.DefaultHandle<T> e) {
/* 371 */       this.batch.addLast(e);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class BlockingMessageQueue<T>
/*     */     implements MessagePassingQueue<T>
/*     */   {
/*     */     private final Queue<T> deque;
/*     */     
/*     */     private final int maxCapacity;
/*     */ 
/*     */     
/*     */     BlockingMessageQueue(int maxCapacity) {
/* 386 */       this.maxCapacity = maxCapacity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 396 */       this.deque = new ArrayDeque<T>();
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized boolean offer(T e) {
/* 401 */       if (this.deque.size() == this.maxCapacity) {
/* 402 */         return false;
/*     */       }
/* 404 */       return this.deque.offer(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized T poll() {
/* 409 */       return this.deque.poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized T peek() {
/* 414 */       return this.deque.peek();
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized int size() {
/* 419 */       return this.deque.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void clear() {
/* 424 */       this.deque.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized boolean isEmpty() {
/* 429 */       return this.deque.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public int capacity() {
/* 434 */       return this.maxCapacity;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean relaxedOffer(T e) {
/* 439 */       return offer(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public T relaxedPoll() {
/* 444 */       return poll();
/*     */     }
/*     */ 
/*     */     
/*     */     public T relaxedPeek() {
/* 449 */       return peek();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int drain(MessagePassingQueue.Consumer<T> c, int limit) {
/* 455 */       int i = 0; T obj;
/* 456 */       for (; i < limit && (obj = poll()) != null; i++) {
/* 457 */         c.accept(obj);
/*     */       }
/* 459 */       return i;
/*     */     }
/*     */ 
/*     */     
/*     */     public int fill(MessagePassingQueue.Supplier<T> s, int limit) {
/* 464 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int drain(MessagePassingQueue.Consumer<T> c) {
/* 469 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int fill(MessagePassingQueue.Supplier<T> s) {
/* 474 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void drain(MessagePassingQueue.Consumer<T> c, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
/* 479 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void fill(MessagePassingQueue.Supplier<T> s, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
/* 484 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\Recycler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */