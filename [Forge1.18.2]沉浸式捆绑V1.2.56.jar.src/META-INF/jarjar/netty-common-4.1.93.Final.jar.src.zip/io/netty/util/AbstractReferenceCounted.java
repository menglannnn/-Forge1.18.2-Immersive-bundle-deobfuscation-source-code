/*    */ package io.netty.util;
/*    */ 
/*    */ import io.netty.util.internal.ReferenceCountUpdater;
/*    */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractReferenceCounted
/*    */   implements ReferenceCounted
/*    */ {
/* 27 */   private static final long REFCNT_FIELD_OFFSET = ReferenceCountUpdater.getUnsafeOffset(AbstractReferenceCounted.class, "refCnt");
/*    */   
/* 29 */   private static final AtomicIntegerFieldUpdater<AbstractReferenceCounted> AIF_UPDATER = AtomicIntegerFieldUpdater.newUpdater(AbstractReferenceCounted.class, "refCnt");
/*    */   
/* 31 */   private static final ReferenceCountUpdater<AbstractReferenceCounted> updater = new ReferenceCountUpdater<AbstractReferenceCounted>()
/*    */     {
/*    */       protected AtomicIntegerFieldUpdater<AbstractReferenceCounted> updater()
/*    */       {
/* 35 */         return AbstractReferenceCounted.AIF_UPDATER;
/*    */       }
/*    */       
/*    */       protected long unsafeOffset() {
/* 39 */         return AbstractReferenceCounted.REFCNT_FIELD_OFFSET;
/*    */       }
/*    */     };
/*    */ 
/*    */   
/* 44 */   private volatile int refCnt = updater
/* 45 */     .initialValue();
/*    */ 
/*    */   
/*    */   public int refCnt() {
/* 49 */     return updater.refCnt(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void setRefCnt(int refCnt) {
/* 56 */     updater.setRefCnt(this, refCnt);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReferenceCounted retain() {
/* 61 */     return updater.retain(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReferenceCounted retain(int increment) {
/* 66 */     return updater.retain(this, increment);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReferenceCounted touch() {
/* 71 */     return touch(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean release() {
/* 76 */     return handleRelease(updater.release(this));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean release(int decrement) {
/* 81 */     return handleRelease(updater.release(this, decrement));
/*    */   }
/*    */   
/*    */   private boolean handleRelease(boolean result) {
/* 85 */     if (result) {
/* 86 */       deallocate();
/*    */     }
/* 88 */     return result;
/*    */   }
/*    */   
/*    */   protected abstract void deallocate();
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\AbstractReferenceCounted.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */