package io.netty.util;

final class ByteProcessorUtils {
  static final byte SPACE = 32;
  
  static final byte HTAB = 9;
  
  static final byte CARRIAGE_RETURN = 13;
  
  static final byte LINE_FEED = 10;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\ByteProcessorUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */