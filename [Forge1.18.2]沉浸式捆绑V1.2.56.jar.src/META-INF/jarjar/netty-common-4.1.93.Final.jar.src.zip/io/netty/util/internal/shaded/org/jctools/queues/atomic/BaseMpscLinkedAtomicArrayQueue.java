/*     */ package io.netty.util.internal.shaded.org.jctools.queues.atomic;
/*     */ 
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueue;
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueueUtil;
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.QueueProgressIndicators;
/*     */ import io.netty.util.internal.shaded.org.jctools.util.PortableJvmInfo;
/*     */ import io.netty.util.internal.shaded.org.jctools.util.Pow2;
/*     */ import io.netty.util.internal.shaded.org.jctools.util.RangeUtil;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseMpscLinkedAtomicArrayQueue<E>
/*     */   extends BaseMpscLinkedAtomicArrayQueueColdProducerFields<E>
/*     */   implements MessagePassingQueue<E>, QueueProgressIndicators
/*     */ {
/* 288 */   private static final Object JUMP = new Object();
/*     */   
/* 290 */   private static final Object BUFFER_CONSUMED = new Object();
/*     */ 
/*     */   
/*     */   private static final int CONTINUE_TO_P_INDEX_CAS = 0;
/*     */ 
/*     */   
/*     */   private static final int RETRY = 1;
/*     */ 
/*     */   
/*     */   private static final int QUEUE_FULL = 2;
/*     */   
/*     */   private static final int QUEUE_RESIZE = 3;
/*     */ 
/*     */   
/*     */   public BaseMpscLinkedAtomicArrayQueue(int initialCapacity) {
/* 305 */     RangeUtil.checkGreaterThanOrEqual(initialCapacity, 2, "initialCapacity");
/* 306 */     int p2capacity = Pow2.roundToPowerOfTwo(initialCapacity);
/*     */     
/* 308 */     long mask = (p2capacity - 1 << 1);
/*     */     
/* 310 */     AtomicReferenceArray<E> buffer = AtomicQueueUtil.allocateRefArray(p2capacity + 1);
/* 311 */     this.producerBuffer = buffer;
/* 312 */     this.producerMask = mask;
/* 313 */     this.consumerBuffer = buffer;
/* 314 */     this.consumerMask = mask;
/*     */     
/* 316 */     soProducerLimit(mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 328 */     long after = lvConsumerIndex();
/*     */     
/*     */     while (true) {
/* 331 */       long before = after;
/* 332 */       long currentProducerIndex = lvProducerIndex();
/* 333 */       after = lvConsumerIndex();
/* 334 */       if (before == after) {
/* 335 */         long size = currentProducerIndex - after >> 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 340 */         if (size > 2147483647L) {
/* 341 */           return Integer.MAX_VALUE;
/*     */         }
/* 343 */         return (int)size;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 350 */     return (lvConsumerIndex() == lvProducerIndex());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 355 */     return getClass().getName();
/*     */   } public boolean offer(E e) {
/*     */     long mask;
/*     */     AtomicReferenceArray<E> buffer;
/*     */     long pIndex;
/* 360 */     if (null == e) {
/* 361 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 367 */       long producerLimit = lvProducerLimit();
/* 368 */       pIndex = lvProducerIndex();
/*     */       
/* 370 */       if ((pIndex & 0x1L) == 1L) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 375 */       mask = this.producerMask;
/* 376 */       buffer = this.producerBuffer;
/*     */       
/* 378 */       if (producerLimit <= pIndex) {
/* 379 */         int result = offerSlowPath(mask, pIndex, producerLimit);
/* 380 */         switch (result) {
/*     */           case 1:
/*     */             continue;
/*     */ 
/*     */           
/*     */           case 2:
/* 386 */             return false;
/*     */           case 3:
/* 388 */             resize(mask, buffer, pIndex, e, (MessagePassingQueue.Supplier<E>)null);
/* 389 */             return true;
/*     */         } 
/*     */       } 
/* 392 */       if (casProducerIndex(pIndex, pIndex + 2L)) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 397 */     int offset = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(pIndex, mask);
/*     */     
/* 399 */     AtomicQueueUtil.soRefElement(buffer, offset, e);
/* 400 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E poll() {
/* 411 */     AtomicReferenceArray<E> buffer = this.consumerBuffer;
/* 412 */     long index = lpConsumerIndex();
/* 413 */     long mask = this.consumerMask;
/* 414 */     int offset = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(index, mask);
/* 415 */     Object e = AtomicQueueUtil.lvRefElement(buffer, offset);
/* 416 */     if (e == null) {
/* 417 */       if (index != lvProducerIndex()) {
/*     */         
/*     */         do {
/* 420 */           e = AtomicQueueUtil.lvRefElement(buffer, offset);
/* 421 */         } while (e == null);
/*     */       } else {
/* 423 */         return null;
/*     */       } 
/*     */     }
/* 426 */     if (e == JUMP) {
/* 427 */       AtomicReferenceArray<E> nextBuffer = nextBuffer(buffer, mask);
/* 428 */       return newBufferPoll(nextBuffer, index);
/*     */     } 
/*     */     
/* 431 */     AtomicQueueUtil.soRefElement(buffer, offset, null);
/*     */     
/* 433 */     soConsumerIndex(index + 2L);
/* 434 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E peek() {
/* 445 */     AtomicReferenceArray<E> buffer = this.consumerBuffer;
/* 446 */     long index = lpConsumerIndex();
/* 447 */     long mask = this.consumerMask;
/* 448 */     int offset = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(index, mask);
/* 449 */     Object e = AtomicQueueUtil.lvRefElement(buffer, offset);
/* 450 */     if (e == null && index != lvProducerIndex()) {
/*     */       
/*     */       do {
/* 453 */         e = AtomicQueueUtil.lvRefElement(buffer, offset);
/* 454 */       } while (e == null);
/*     */     }
/* 456 */     if (e == JUMP) {
/* 457 */       return newBufferPeek(nextBuffer(buffer, mask), index);
/*     */     }
/* 459 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int offerSlowPath(long mask, long pIndex, long producerLimit) {
/* 466 */     long cIndex = lvConsumerIndex();
/* 467 */     long bufferCapacity = getCurrentBufferCapacity(mask);
/* 468 */     if (cIndex + bufferCapacity > pIndex) {
/* 469 */       if (!casProducerLimit(producerLimit, cIndex + bufferCapacity))
/*     */       {
/* 471 */         return 1;
/*     */       }
/*     */       
/* 474 */       return 0;
/*     */     } 
/*     */     
/* 477 */     if (availableInQueue(pIndex, cIndex) <= 0L)
/*     */     {
/* 479 */       return 2;
/*     */     }
/* 481 */     if (casProducerIndex(pIndex, pIndex + 1L))
/*     */     {
/* 483 */       return 3;
/*     */     }
/*     */     
/* 486 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AtomicReferenceArray<E> nextBuffer(AtomicReferenceArray<E> buffer, long mask) {
/* 497 */     int offset = nextArrayOffset(mask);
/* 498 */     AtomicReferenceArray<E> nextBuffer = AtomicQueueUtil.<AtomicReferenceArray<E>>lvRefElement((AtomicReferenceArray)buffer, offset);
/* 499 */     this.consumerBuffer = nextBuffer;
/* 500 */     this.consumerMask = (AtomicQueueUtil.length(nextBuffer) - 2 << 1);
/* 501 */     AtomicQueueUtil.soRefElement(buffer, offset, BUFFER_CONSUMED);
/* 502 */     return nextBuffer;
/*     */   }
/*     */   
/*     */   private static int nextArrayOffset(long mask) {
/* 506 */     return AtomicQueueUtil.modifiedCalcCircularRefElementOffset(mask + 2L, Long.MAX_VALUE);
/*     */   }
/*     */   
/*     */   private E newBufferPoll(AtomicReferenceArray<E> nextBuffer, long index) {
/* 510 */     int offset = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(index, this.consumerMask);
/* 511 */     E n = AtomicQueueUtil.lvRefElement(nextBuffer, offset);
/* 512 */     if (n == null) {
/* 513 */       throw new IllegalStateException("new buffer must have at least one element");
/*     */     }
/* 515 */     AtomicQueueUtil.soRefElement(nextBuffer, offset, null);
/* 516 */     soConsumerIndex(index + 2L);
/* 517 */     return n;
/*     */   }
/*     */   
/*     */   private E newBufferPeek(AtomicReferenceArray<E> nextBuffer, long index) {
/* 521 */     int offset = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(index, this.consumerMask);
/* 522 */     E n = AtomicQueueUtil.lvRefElement(nextBuffer, offset);
/* 523 */     if (null == n) {
/* 524 */       throw new IllegalStateException("new buffer must have at least one element");
/*     */     }
/* 526 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public long currentProducerIndex() {
/* 531 */     return lvProducerIndex() / 2L;
/*     */   }
/*     */ 
/*     */   
/*     */   public long currentConsumerIndex() {
/* 536 */     return lvConsumerIndex() / 2L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean relaxedOffer(E e) {
/* 544 */     return offer(e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E relaxedPoll() {
/* 550 */     AtomicReferenceArray<E> buffer = this.consumerBuffer;
/* 551 */     long index = lpConsumerIndex();
/* 552 */     long mask = this.consumerMask;
/* 553 */     int offset = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(index, mask);
/* 554 */     Object e = AtomicQueueUtil.lvRefElement(buffer, offset);
/* 555 */     if (e == null) {
/* 556 */       return null;
/*     */     }
/* 558 */     if (e == JUMP) {
/* 559 */       AtomicReferenceArray<E> nextBuffer = nextBuffer(buffer, mask);
/* 560 */       return newBufferPoll(nextBuffer, index);
/*     */     } 
/* 562 */     AtomicQueueUtil.soRefElement(buffer, offset, null);
/* 563 */     soConsumerIndex(index + 2L);
/* 564 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E relaxedPeek() {
/* 570 */     AtomicReferenceArray<E> buffer = this.consumerBuffer;
/* 571 */     long index = lpConsumerIndex();
/* 572 */     long mask = this.consumerMask;
/* 573 */     int offset = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(index, mask);
/* 574 */     Object e = AtomicQueueUtil.lvRefElement(buffer, offset);
/* 575 */     if (e == JUMP) {
/* 576 */       return newBufferPeek(nextBuffer(buffer, mask), index);
/*     */     }
/* 578 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int fill(MessagePassingQueue.Supplier<E> s) {
/* 584 */     long result = 0L;
/* 585 */     int capacity = capacity();
/*     */     while (true) {
/* 587 */       int filled = fill(s, PortableJvmInfo.RECOMENDED_OFFER_BATCH);
/* 588 */       if (filled == 0) {
/* 589 */         return (int)result;
/*     */       }
/* 591 */       result += filled;
/* 592 */       if (result > capacity)
/* 593 */         return (int)result; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int fill(MessagePassingQueue.Supplier<E> s, int limit) {
/* 598 */     if (null == s)
/* 599 */       throw new IllegalArgumentException("supplier is null"); 
/* 600 */     if (limit < 0)
/* 601 */       throw new IllegalArgumentException("limit is negative:" + limit); 
/* 602 */     if (limit == 0) {
/* 603 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 609 */       long producerLimit = lvProducerLimit();
/* 610 */       long pIndex = lvProducerIndex();
/*     */       
/* 612 */       if ((pIndex & 0x1L) == 1L) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 619 */       long mask = this.producerMask;
/* 620 */       AtomicReferenceArray<E> buffer = this.producerBuffer;
/*     */ 
/*     */ 
/*     */       
/* 624 */       long batchIndex = Math.min(producerLimit, pIndex + 2L * limit);
/* 625 */       if (pIndex >= producerLimit) {
/* 626 */         int result = offerSlowPath(mask, pIndex, producerLimit);
/* 627 */         switch (result) {
/*     */           case 0:
/*     */           case 1:
/*     */             continue;
/*     */           
/*     */           case 2:
/* 633 */             return 0;
/*     */           case 3:
/* 635 */             resize(mask, buffer, pIndex, (E)null, s);
/* 636 */             return 1;
/*     */         } 
/*     */       
/*     */       } 
/* 640 */       if (casProducerIndex(pIndex, batchIndex)) {
/* 641 */         int claimedSlots = (int)((batchIndex - pIndex) / 2L);
/*     */ 
/*     */ 
/*     */         
/* 645 */         for (int i = 0; i < claimedSlots; i++) {
/* 646 */           int offset = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(pIndex + 2L * i, mask);
/* 647 */           AtomicQueueUtil.soRefElement(buffer, offset, s.get());
/*     */         } 
/* 649 */         return claimedSlots;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void fill(MessagePassingQueue.Supplier<E> s, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
/* 654 */     MessagePassingQueueUtil.fill(this, s, wait, exit);
/*     */   }
/*     */ 
/*     */   
/*     */   public int drain(MessagePassingQueue.Consumer<E> c) {
/* 659 */     return drain(c, capacity());
/*     */   }
/*     */ 
/*     */   
/*     */   public int drain(MessagePassingQueue.Consumer<E> c, int limit) {
/* 664 */     return MessagePassingQueueUtil.drain(this, c, limit);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drain(MessagePassingQueue.Consumer<E> c, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
/* 669 */     MessagePassingQueueUtil.drain(this, c, wait, exit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 684 */     return new WeakIterator<E>(this.consumerBuffer, lvConsumerIndex(), lvProducerIndex());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class WeakIterator<E>
/*     */     implements Iterator<E>
/*     */   {
/*     */     private final long pIndex;
/*     */     
/*     */     private long nextIndex;
/*     */     
/*     */     private E nextElement;
/*     */     
/*     */     private AtomicReferenceArray<E> currentBuffer;
/*     */     
/*     */     private int mask;
/*     */ 
/*     */     
/*     */     WeakIterator(AtomicReferenceArray<E> currentBuffer, long cIndex, long pIndex) {
/* 704 */       this.pIndex = pIndex >> 1L;
/* 705 */       this.nextIndex = cIndex >> 1L;
/* 706 */       setBuffer(currentBuffer);
/* 707 */       this.nextElement = getNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 712 */       throw new UnsupportedOperationException("remove");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 717 */       return (this.nextElement != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 722 */       E e = this.nextElement;
/* 723 */       if (e == null) {
/* 724 */         throw new NoSuchElementException();
/*     */       }
/* 726 */       this.nextElement = getNext();
/* 727 */       return e;
/*     */     }
/*     */     
/*     */     private void setBuffer(AtomicReferenceArray<E> buffer) {
/* 731 */       this.currentBuffer = buffer;
/* 732 */       this.mask = AtomicQueueUtil.length(buffer) - 2;
/*     */     }
/*     */     
/*     */     private E getNext() {
/* 736 */       while (this.nextIndex < this.pIndex) {
/* 737 */         long index = this.nextIndex++;
/* 738 */         E e = AtomicQueueUtil.lvRefElement(this.currentBuffer, AtomicQueueUtil.calcCircularRefElementOffset(index, this.mask));
/*     */         
/* 740 */         if (e == null) {
/*     */           continue;
/*     */         }
/*     */         
/* 744 */         if (e != BaseMpscLinkedAtomicArrayQueue.JUMP) {
/* 745 */           return e;
/*     */         }
/*     */         
/* 748 */         int nextBufferIndex = this.mask + 1;
/* 749 */         Object nextBuffer = AtomicQueueUtil.lvRefElement(this.currentBuffer, AtomicQueueUtil.calcRefElementOffset(nextBufferIndex));
/* 750 */         if (nextBuffer == BaseMpscLinkedAtomicArrayQueue.BUFFER_CONSUMED || nextBuffer == null)
/*     */         {
/* 752 */           return null;
/*     */         }
/* 754 */         setBuffer((AtomicReferenceArray<E>)nextBuffer);
/*     */         
/* 756 */         e = AtomicQueueUtil.lvRefElement(this.currentBuffer, AtomicQueueUtil.calcCircularRefElementOffset(index, this.mask));
/*     */         
/* 758 */         if (e == null) {
/*     */           continue;
/*     */         }
/* 761 */         return e;
/*     */       } 
/*     */       
/* 764 */       return null;
/*     */     } }
/*     */   
/*     */   private void resize(long oldMask, AtomicReferenceArray<E> oldBuffer, long pIndex, E e, MessagePassingQueue.Supplier<E> s) {
/*     */     AtomicReferenceArray<E> newBuffer;
/* 769 */     assert e == null || s != null;
/* 770 */     int newBufferLength = getNextBufferSize(oldBuffer);
/*     */     
/*     */     try {
/* 773 */       newBuffer = AtomicQueueUtil.allocateRefArray(newBufferLength);
/* 774 */     } catch (OutOfMemoryError oom) {
/* 775 */       assert lvProducerIndex() == pIndex + 1L;
/* 776 */       soProducerIndex(pIndex);
/* 777 */       throw oom;
/*     */     } 
/* 779 */     this.producerBuffer = newBuffer;
/* 780 */     int newMask = newBufferLength - 2 << 1;
/* 781 */     this.producerMask = newMask;
/* 782 */     int offsetInOld = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(pIndex, oldMask);
/* 783 */     int offsetInNew = AtomicQueueUtil.modifiedCalcCircularRefElementOffset(pIndex, newMask);
/*     */     
/* 785 */     AtomicQueueUtil.soRefElement(newBuffer, offsetInNew, (e == null) ? s.get() : e);
/*     */     
/* 787 */     AtomicQueueUtil.soRefElement(oldBuffer, nextArrayOffset(oldMask), newBuffer);
/*     */     
/* 789 */     long cIndex = lvConsumerIndex();
/* 790 */     long availableInQueue = availableInQueue(pIndex, cIndex);
/* 791 */     RangeUtil.checkPositive(availableInQueue, "availableInQueue");
/*     */ 
/*     */     
/* 794 */     soProducerLimit(pIndex + Math.min(newMask, availableInQueue));
/*     */     
/* 796 */     soProducerIndex(pIndex + 2L);
/*     */ 
/*     */     
/* 799 */     AtomicQueueUtil.soRefElement(oldBuffer, offsetInOld, JUMP);
/*     */   }
/*     */   
/*     */   protected abstract long availableInQueue(long paramLong1, long paramLong2);
/*     */   
/*     */   public abstract int capacity();
/*     */   
/*     */   protected abstract int getNextBufferSize(AtomicReferenceArray<E> paramAtomicReferenceArray);
/*     */   
/*     */   protected abstract long getCurrentBufferCapacity(long paramLong);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\atomic\BaseMpscLinkedAtomicArrayQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */