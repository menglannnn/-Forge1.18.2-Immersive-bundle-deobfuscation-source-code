/*     */ package io.netty.util.internal.shaded.org.jctools.queues.atomic;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseLinkedAtomicQueueProducerNodeRef<E>
/*     */   extends BaseLinkedAtomicQueuePad0<E>
/*     */ {
/*  87 */   private static final AtomicReferenceFieldUpdater<BaseLinkedAtomicQueueProducerNodeRef, LinkedQueueAtomicNode> P_NODE_UPDATER = AtomicReferenceFieldUpdater.newUpdater(BaseLinkedAtomicQueueProducerNodeRef.class, LinkedQueueAtomicNode.class, "producerNode");
/*     */   
/*     */   private volatile LinkedQueueAtomicNode<E> producerNode;
/*     */   
/*     */   final void spProducerNode(LinkedQueueAtomicNode<E> newValue) {
/*  92 */     P_NODE_UPDATER.lazySet(this, newValue);
/*     */   }
/*     */   
/*     */   final void soProducerNode(LinkedQueueAtomicNode<E> newValue) {
/*  96 */     P_NODE_UPDATER.lazySet(this, newValue);
/*     */   }
/*     */   
/*     */   final LinkedQueueAtomicNode<E> lvProducerNode() {
/* 100 */     return this.producerNode;
/*     */   }
/*     */   
/*     */   final boolean casProducerNode(LinkedQueueAtomicNode<E> expect, LinkedQueueAtomicNode<E> newValue) {
/* 104 */     return P_NODE_UPDATER.compareAndSet(this, expect, newValue);
/*     */   }
/*     */   
/*     */   final LinkedQueueAtomicNode<E> lpProducerNode() {
/* 108 */     return this.producerNode;
/*     */   }
/*     */   
/*     */   protected final LinkedQueueAtomicNode<E> xchgProducerNode(LinkedQueueAtomicNode<E> newValue) {
/* 112 */     return P_NODE_UPDATER.getAndSet(this, newValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\atomic\BaseLinkedAtomicQueueProducerNodeRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */