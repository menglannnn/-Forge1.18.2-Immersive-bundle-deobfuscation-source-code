/*    */ package io.netty.util.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.AbstractSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class ConcurrentSet<E>
/*    */   extends AbstractSet<E>
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6761513279741915432L;
/* 37 */   private final ConcurrentMap<E, Boolean> map = PlatformDependent.newConcurrentHashMap();
/*    */ 
/*    */ 
/*    */   
/*    */   public int size() {
/* 42 */     return this.map.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(Object o) {
/* 47 */     return this.map.containsKey(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean add(E o) {
/* 52 */     return (this.map.putIfAbsent(o, Boolean.TRUE) == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean remove(Object o) {
/* 57 */     return (this.map.remove(o) != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public void clear() {
/* 62 */     this.map.clear();
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<E> iterator() {
/* 67 */     return this.map.keySet().iterator();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\ConcurrentSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */