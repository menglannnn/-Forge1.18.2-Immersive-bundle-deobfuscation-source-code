/*    */ package io.netty.util.internal.logging;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum InternalLogLevel
/*    */ {
/* 25 */   TRACE,
/*    */ 
/*    */ 
/*    */   
/* 29 */   DEBUG,
/*    */ 
/*    */ 
/*    */   
/* 33 */   INFO,
/*    */ 
/*    */ 
/*    */   
/* 37 */   WARN,
/*    */ 
/*    */ 
/*    */   
/* 41 */   ERROR;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\logging\InternalLogLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */