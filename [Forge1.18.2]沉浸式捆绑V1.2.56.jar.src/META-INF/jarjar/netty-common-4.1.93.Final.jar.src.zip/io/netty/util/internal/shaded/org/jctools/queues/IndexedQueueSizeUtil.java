/*    */ package io.netty.util.internal.shaded.org.jctools.queues;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IndexedQueueSizeUtil
/*    */ {
/*    */   public static int size(IndexedQueue iq) {
/* 45 */     long before, currentProducerIndex, after = iq.lvConsumerIndex();
/*    */ 
/*    */     
/*    */     do {
/* 49 */       before = after;
/* 50 */       currentProducerIndex = iq.lvProducerIndex();
/* 51 */       after = iq.lvConsumerIndex();
/* 52 */     } while (before != after);
/*    */     
/* 54 */     long size = currentProducerIndex - after;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 60 */     if (size > 2147483647L)
/*    */     {
/* 62 */       return Integer.MAX_VALUE;
/*    */     }
/*    */ 
/*    */     
/* 66 */     if (size < 0L)
/*    */     {
/* 68 */       return 0;
/*    */     }
/* 70 */     if (iq.capacity() != -1 && size > iq.capacity())
/*    */     {
/* 72 */       return iq.capacity();
/*    */     }
/*    */ 
/*    */     
/* 76 */     return (int)size;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isEmpty(IndexedQueue iq) {
/* 86 */     return (iq.lvConsumerIndex() >= iq.lvProducerIndex());
/*    */   }
/*    */   
/*    */   public static interface IndexedQueue {
/*    */     long lvConsumerIndex();
/*    */     
/*    */     long lvProducerIndex();
/*    */     
/*    */     int capacity();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\IndexedQueueSizeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */