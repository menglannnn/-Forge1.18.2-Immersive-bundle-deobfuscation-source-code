package io.netty.util.internal.shaded.org.jctools.queues;

public interface QueueProgressIndicators {
  long currentProducerIndex();
  
  long currentConsumerIndex();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\QueueProgressIndicators.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */