/*    */ package io.netty.util.internal.shaded.org.jctools.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PortableJvmInfo
/*    */ {
/* 21 */   public static final int CACHE_LINE_SIZE = Integer.getInteger("jctools.cacheLineSize", 64).intValue();
/* 22 */   public static final int CPUs = Runtime.getRuntime().availableProcessors();
/* 23 */   public static final int RECOMENDED_OFFER_BATCH = CPUs * 4;
/* 24 */   public static final int RECOMENDED_POLL_BATCH = CPUs * 4;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctool\\util\PortableJvmInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */