/*     */ package io.netty.util.internal;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.nio.channels.DatagramChannel;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SocketUtils
/*     */ {
/*  46 */   private static final Enumeration<Object> EMPTY = Collections.enumeration(Collections.emptyList());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> Enumeration<T> empty() {
/*  53 */     return (Enumeration)EMPTY;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void connect(final Socket socket, final SocketAddress remoteAddress, final int timeout) throws IOException {
/*     */     try {
/*  59 */       AccessController.doPrivileged(new PrivilegedExceptionAction<Void>()
/*     */           {
/*     */             public Void run() throws IOException {
/*  62 */               socket.connect(remoteAddress, timeout);
/*  63 */               return null;
/*     */             }
/*     */           });
/*  66 */     } catch (PrivilegedActionException e) {
/*  67 */       throw (IOException)e.getCause();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void bind(final Socket socket, final SocketAddress bindpoint) throws IOException {
/*     */     try {
/*  73 */       AccessController.doPrivileged(new PrivilegedExceptionAction<Void>()
/*     */           {
/*     */             public Void run() throws IOException {
/*  76 */               socket.bind(bindpoint);
/*  77 */               return null;
/*     */             }
/*     */           });
/*  80 */     } catch (PrivilegedActionException e) {
/*  81 */       throw (IOException)e.getCause();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean connect(final SocketChannel socketChannel, final SocketAddress remoteAddress) throws IOException {
/*     */     try {
/*  88 */       return ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedExceptionAction<Boolean>()
/*     */           {
/*     */             public Boolean run() throws IOException {
/*  91 */               return Boolean.valueOf(socketChannel.connect(remoteAddress));
/*     */             }
/*     */           })).booleanValue();
/*  94 */     } catch (PrivilegedActionException e) {
/*  95 */       throw (IOException)e.getCause();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   public static void bind(final SocketChannel socketChannel, final SocketAddress address) throws IOException {
/*     */     try {
/* 102 */       AccessController.doPrivileged(new PrivilegedExceptionAction<Void>()
/*     */           {
/*     */             public Void run() throws IOException {
/* 105 */               socketChannel.bind(address);
/* 106 */               return null;
/*     */             }
/*     */           });
/* 109 */     } catch (PrivilegedActionException e) {
/* 110 */       throw (IOException)e.getCause();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static SocketChannel accept(final ServerSocketChannel serverSocketChannel) throws IOException {
/*     */     try {
/* 116 */       return AccessController.<SocketChannel>doPrivileged(new PrivilegedExceptionAction<SocketChannel>()
/*     */           {
/*     */             public SocketChannel run() throws IOException {
/* 119 */               return serverSocketChannel.accept();
/*     */             }
/*     */           });
/* 122 */     } catch (PrivilegedActionException e) {
/* 123 */       throw (IOException)e.getCause();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   public static void bind(final DatagramChannel networkChannel, final SocketAddress address) throws IOException {
/*     */     try {
/* 130 */       AccessController.doPrivileged(new PrivilegedExceptionAction<Void>()
/*     */           {
/*     */             public Void run() throws IOException {
/* 133 */               networkChannel.bind(address);
/* 134 */               return null;
/*     */             }
/*     */           });
/* 137 */     } catch (PrivilegedActionException e) {
/* 138 */       throw (IOException)e.getCause();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static SocketAddress localSocketAddress(final ServerSocket socket) {
/* 143 */     return AccessController.<SocketAddress>doPrivileged(new PrivilegedAction<SocketAddress>()
/*     */         {
/*     */           public SocketAddress run() {
/* 146 */             return socket.getLocalSocketAddress();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static InetAddress addressByName(final String hostname) throws UnknownHostException {
/*     */     try {
/* 153 */       return AccessController.<InetAddress>doPrivileged(new PrivilegedExceptionAction<InetAddress>()
/*     */           {
/*     */             public InetAddress run() throws UnknownHostException {
/* 156 */               return InetAddress.getByName(hostname);
/*     */             }
/*     */           });
/* 159 */     } catch (PrivilegedActionException e) {
/* 160 */       throw (UnknownHostException)e.getCause();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static InetAddress[] allAddressesByName(final String hostname) throws UnknownHostException {
/*     */     try {
/* 166 */       return AccessController.<InetAddress[]>doPrivileged((PrivilegedExceptionAction)new PrivilegedExceptionAction<InetAddress[]>()
/*     */           {
/*     */             public InetAddress[] run() throws UnknownHostException {
/* 169 */               return InetAddress.getAllByName(hostname);
/*     */             }
/*     */           });
/* 172 */     } catch (PrivilegedActionException e) {
/* 173 */       throw (UnknownHostException)e.getCause();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static InetSocketAddress socketAddress(final String hostname, final int port) {
/* 178 */     return AccessController.<InetSocketAddress>doPrivileged(new PrivilegedAction<InetSocketAddress>()
/*     */         {
/*     */           public InetSocketAddress run() {
/* 181 */             return new InetSocketAddress(hostname, port);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static Enumeration<InetAddress> addressesFromNetworkInterface(final NetworkInterface intf) {
/* 188 */     Enumeration<InetAddress> addresses = AccessController.<Enumeration<InetAddress>>doPrivileged(new PrivilegedAction<Enumeration<InetAddress>>()
/*     */         {
/*     */           public Enumeration<InetAddress> run() {
/* 191 */             return intf.getInetAddresses();
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 197 */     if (addresses == null) {
/* 198 */       return empty();
/*     */     }
/* 200 */     return addresses;
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */   public static InetAddress loopbackAddress() {
/* 205 */     return AccessController.<InetAddress>doPrivileged(new PrivilegedAction<InetAddress>()
/*     */         {
/*     */           public InetAddress run() {
/* 208 */             if (PlatformDependent.javaVersion() >= 7) {
/* 209 */               return InetAddress.getLoopbackAddress();
/*     */             }
/*     */             try {
/* 212 */               return InetAddress.getByName(null);
/* 213 */             } catch (UnknownHostException e) {
/* 214 */               throw new IllegalStateException(e);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static byte[] hardwareAddressFromNetworkInterface(final NetworkInterface intf) throws SocketException {
/*     */     try {
/* 222 */       return AccessController.<byte[]>doPrivileged((PrivilegedExceptionAction)new PrivilegedExceptionAction<byte[]>()
/*     */           {
/*     */             public byte[] run() throws SocketException {
/* 225 */               return intf.getHardwareAddress();
/*     */             }
/*     */           });
/* 228 */     } catch (PrivilegedActionException e) {
/* 229 */       throw (SocketException)e.getCause();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\SocketUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */