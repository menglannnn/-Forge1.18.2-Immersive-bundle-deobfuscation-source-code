/*    */ package io.netty.util.internal.shaded.org.jctools.queues;
/*    */ 
/*    */ import io.netty.util.internal.shaded.org.jctools.util.UnsafeAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class LinkedQueueNode<E>
/*    */ {
/* 21 */   private static final long NEXT_OFFSET = UnsafeAccess.fieldOffset(LinkedQueueNode.class, "next");
/*    */   
/*    */   private E value;
/*    */   
/*    */   private volatile LinkedQueueNode<E> next;
/*    */   
/*    */   LinkedQueueNode() {
/* 28 */     this(null);
/*    */   }
/*    */ 
/*    */   
/*    */   LinkedQueueNode(E val) {
/* 33 */     spValue(val);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public E getAndNullValue() {
/* 43 */     E temp = lpValue();
/* 44 */     spValue(null);
/* 45 */     return temp;
/*    */   }
/*    */ 
/*    */   
/*    */   public E lpValue() {
/* 50 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void spValue(E newValue) {
/* 55 */     this.value = newValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void soNext(LinkedQueueNode<E> n) {
/* 60 */     UnsafeAccess.UNSAFE.putOrderedObject(this, NEXT_OFFSET, n);
/*    */   }
/*    */ 
/*    */   
/*    */   public void spNext(LinkedQueueNode<E> n) {
/* 65 */     UnsafeAccess.UNSAFE.putObject(this, NEXT_OFFSET, n);
/*    */   }
/*    */ 
/*    */   
/*    */   public LinkedQueueNode<E> lvNext() {
/* 70 */     return this.next;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\LinkedQueueNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */