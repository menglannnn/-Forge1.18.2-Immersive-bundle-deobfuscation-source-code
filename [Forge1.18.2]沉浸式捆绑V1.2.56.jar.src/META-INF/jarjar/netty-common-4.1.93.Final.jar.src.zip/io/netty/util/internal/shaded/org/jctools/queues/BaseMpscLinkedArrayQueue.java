/*     */ package io.netty.util.internal.shaded.org.jctools.queues;
/*     */ 
/*     */ import io.netty.util.internal.shaded.org.jctools.util.PortableJvmInfo;
/*     */ import io.netty.util.internal.shaded.org.jctools.util.Pow2;
/*     */ import io.netty.util.internal.shaded.org.jctools.util.RangeUtil;
/*     */ import io.netty.util.internal.shaded.org.jctools.util.UnsafeRefArrayAccess;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseMpscLinkedArrayQueue<E>
/*     */   extends BaseMpscLinkedArrayQueueColdProducerFields<E>
/*     */   implements MessagePassingQueue<E>, QueueProgressIndicators
/*     */ {
/* 177 */   private static final Object JUMP = new Object();
/* 178 */   private static final Object BUFFER_CONSUMED = new Object();
/*     */ 
/*     */   
/*     */   private static final int CONTINUE_TO_P_INDEX_CAS = 0;
/*     */   
/*     */   private static final int RETRY = 1;
/*     */   
/*     */   private static final int QUEUE_FULL = 2;
/*     */   
/*     */   private static final int QUEUE_RESIZE = 3;
/*     */ 
/*     */   
/*     */   public BaseMpscLinkedArrayQueue(int initialCapacity) {
/* 191 */     RangeUtil.checkGreaterThanOrEqual(initialCapacity, 2, "initialCapacity");
/*     */     
/* 193 */     int p2capacity = Pow2.roundToPowerOfTwo(initialCapacity);
/*     */     
/* 195 */     long mask = (p2capacity - 1 << 1);
/*     */     
/* 197 */     E[] buffer = (E[])UnsafeRefArrayAccess.allocateRefArray(p2capacity + 1);
/* 198 */     this.producerBuffer = buffer;
/* 199 */     this.producerMask = mask;
/* 200 */     this.consumerBuffer = buffer;
/* 201 */     this.consumerMask = mask;
/* 202 */     soProducerLimit(mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 216 */     long before, currentProducerIndex, after = lvConsumerIndex();
/*     */ 
/*     */     
/*     */     do {
/* 220 */       before = after;
/* 221 */       currentProducerIndex = lvProducerIndex();
/* 222 */       after = lvConsumerIndex();
/* 223 */     } while (before != after);
/*     */     
/* 225 */     long size = currentProducerIndex - after >> 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     if (size > 2147483647L)
/*     */     {
/* 233 */       return Integer.MAX_VALUE;
/*     */     }
/*     */ 
/*     */     
/* 237 */     return (int)size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 248 */     return (lvConsumerIndex() == lvProducerIndex());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 254 */     return getClass().getName();
/*     */   }
/*     */   public boolean offer(E e) {
/*     */     long mask;
/*     */     E[] buffer;
/*     */     long pIndex;
/* 260 */     if (null == e)
/*     */     {
/* 262 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 271 */       long producerLimit = lvProducerLimit();
/* 272 */       pIndex = lvProducerIndex();
/*     */       
/* 274 */       if ((pIndex & 0x1L) == 1L) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 281 */       mask = this.producerMask;
/* 282 */       buffer = this.producerBuffer;
/*     */ 
/*     */ 
/*     */       
/* 286 */       if (producerLimit <= pIndex) {
/*     */         
/* 288 */         int result = offerSlowPath(mask, pIndex, producerLimit);
/* 289 */         switch (result) {
/*     */           case 1:
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case 2:
/* 296 */             return false;
/*     */           case 3:
/* 298 */             resize(mask, buffer, pIndex, e, (MessagePassingQueue.Supplier<E>)null);
/* 299 */             return true;
/*     */         } 
/*     */       
/*     */       } 
/* 303 */       if (casProducerIndex(pIndex, pIndex + 2L)) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 309 */     long offset = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(pIndex, mask);
/* 310 */     UnsafeRefArrayAccess.soRefElement((Object[])buffer, offset, e);
/* 311 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E poll() {
/* 323 */     E[] buffer = this.consumerBuffer;
/* 324 */     long index = lpConsumerIndex();
/* 325 */     long mask = this.consumerMask;
/*     */     
/* 327 */     long offset = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(index, mask);
/* 328 */     Object e = UnsafeRefArrayAccess.lvRefElement((Object[])buffer, offset);
/* 329 */     if (e == null)
/*     */     {
/* 331 */       if (index != lvProducerIndex()) {
/*     */         
/*     */         do
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 338 */           e = UnsafeRefArrayAccess.lvRefElement((Object[])buffer, offset);
/*     */         }
/* 340 */         while (e == null);
/*     */       }
/*     */       else {
/*     */         
/* 344 */         return null;
/*     */       } 
/*     */     }
/*     */     
/* 348 */     if (e == JUMP) {
/*     */       
/* 350 */       E[] nextBuffer = nextBuffer(buffer, mask);
/* 351 */       return newBufferPoll(nextBuffer, index);
/*     */     } 
/*     */     
/* 354 */     UnsafeRefArrayAccess.soRefElement((Object[])buffer, offset, null);
/* 355 */     soConsumerIndex(index + 2L);
/* 356 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E peek() {
/* 368 */     E[] buffer = this.consumerBuffer;
/* 369 */     long index = lpConsumerIndex();
/* 370 */     long mask = this.consumerMask;
/*     */     
/* 372 */     long offset = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(index, mask);
/* 373 */     Object e = UnsafeRefArrayAccess.lvRefElement((Object[])buffer, offset);
/* 374 */     if (e == null && index != lvProducerIndex()) {
/*     */       do
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 380 */         e = UnsafeRefArrayAccess.lvRefElement((Object[])buffer, offset);
/*     */       }
/* 382 */       while (e == null);
/*     */     }
/* 384 */     if (e == JUMP)
/*     */     {
/* 386 */       return newBufferPeek(nextBuffer(buffer, mask), index);
/*     */     }
/* 388 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int offerSlowPath(long mask, long pIndex, long producerLimit) {
/* 396 */     long cIndex = lvConsumerIndex();
/* 397 */     long bufferCapacity = getCurrentBufferCapacity(mask);
/*     */     
/* 399 */     if (cIndex + bufferCapacity > pIndex) {
/*     */       
/* 401 */       if (!casProducerLimit(producerLimit, cIndex + bufferCapacity))
/*     */       {
/*     */         
/* 404 */         return 1;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 409 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 413 */     if (availableInQueue(pIndex, cIndex) <= 0L)
/*     */     {
/*     */       
/* 416 */       return 2;
/*     */     }
/*     */     
/* 419 */     if (casProducerIndex(pIndex, pIndex + 1L))
/*     */     {
/*     */       
/* 422 */       return 3;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 427 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private E[] nextBuffer(E[] buffer, long mask) {
/* 439 */     long offset = nextArrayOffset(mask);
/* 440 */     E[] nextBuffer = (E[])UnsafeRefArrayAccess.lvRefElement((Object[])buffer, offset);
/* 441 */     this.consumerBuffer = nextBuffer;
/* 442 */     this.consumerMask = (LinkedArrayQueueUtil.length((Object[])nextBuffer) - 2 << 1);
/* 443 */     UnsafeRefArrayAccess.soRefElement((Object[])buffer, offset, BUFFER_CONSUMED);
/* 444 */     return nextBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   private static long nextArrayOffset(long mask) {
/* 449 */     return LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(mask + 2L, Long.MAX_VALUE);
/*     */   }
/*     */ 
/*     */   
/*     */   private E newBufferPoll(E[] nextBuffer, long index) {
/* 454 */     long offset = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(index, this.consumerMask);
/* 455 */     E n = (E)UnsafeRefArrayAccess.lvRefElement((Object[])nextBuffer, offset);
/* 456 */     if (n == null)
/*     */     {
/* 458 */       throw new IllegalStateException("new buffer must have at least one element");
/*     */     }
/* 460 */     UnsafeRefArrayAccess.soRefElement((Object[])nextBuffer, offset, null);
/* 461 */     soConsumerIndex(index + 2L);
/* 462 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   private E newBufferPeek(E[] nextBuffer, long index) {
/* 467 */     long offset = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(index, this.consumerMask);
/* 468 */     E n = (E)UnsafeRefArrayAccess.lvRefElement((Object[])nextBuffer, offset);
/* 469 */     if (null == n)
/*     */     {
/* 471 */       throw new IllegalStateException("new buffer must have at least one element");
/*     */     }
/* 473 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long currentProducerIndex() {
/* 479 */     return lvProducerIndex() / 2L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long currentConsumerIndex() {
/* 485 */     return lvConsumerIndex() / 2L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean relaxedOffer(E e) {
/* 494 */     return offer(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E relaxedPoll() {
/* 501 */     E[] buffer = this.consumerBuffer;
/* 502 */     long index = lpConsumerIndex();
/* 503 */     long mask = this.consumerMask;
/*     */     
/* 505 */     long offset = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(index, mask);
/* 506 */     Object e = UnsafeRefArrayAccess.lvRefElement((Object[])buffer, offset);
/* 507 */     if (e == null)
/*     */     {
/* 509 */       return null;
/*     */     }
/* 511 */     if (e == JUMP) {
/*     */       
/* 513 */       E[] nextBuffer = nextBuffer(buffer, mask);
/* 514 */       return newBufferPoll(nextBuffer, index);
/*     */     } 
/* 516 */     UnsafeRefArrayAccess.soRefElement((Object[])buffer, offset, null);
/* 517 */     soConsumerIndex(index + 2L);
/* 518 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E relaxedPeek() {
/* 525 */     E[] buffer = this.consumerBuffer;
/* 526 */     long index = lpConsumerIndex();
/* 527 */     long mask = this.consumerMask;
/*     */     
/* 529 */     long offset = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(index, mask);
/* 530 */     Object e = UnsafeRefArrayAccess.lvRefElement((Object[])buffer, offset);
/* 531 */     if (e == JUMP)
/*     */     {
/* 533 */       return newBufferPeek(nextBuffer(buffer, mask), index);
/*     */     }
/* 535 */     return (E)e;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int fill(MessagePassingQueue.Supplier<E> s) {
/* 541 */     long result = 0L;
/* 542 */     int capacity = capacity();
/*     */     
/*     */     while (true) {
/* 545 */       int filled = fill(s, PortableJvmInfo.RECOMENDED_OFFER_BATCH);
/* 546 */       if (filled == 0)
/*     */       {
/* 548 */         return (int)result;
/*     */       }
/* 550 */       result += filled;
/*     */       
/* 552 */       if (result > capacity)
/* 553 */         return (int)result; 
/*     */     } 
/*     */   } public int fill(MessagePassingQueue.Supplier<E> s, int limit) {
/*     */     long mask;
/*     */     E[] buffer;
/*     */     long pIndex, batchIndex;
/* 559 */     if (null == s)
/* 560 */       throw new IllegalArgumentException("supplier is null"); 
/* 561 */     if (limit < 0)
/* 562 */       throw new IllegalArgumentException("limit is negative:" + limit); 
/* 563 */     if (limit == 0) {
/* 564 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 572 */       long producerLimit = lvProducerLimit();
/* 573 */       pIndex = lvProducerIndex();
/*     */       
/* 575 */       if ((pIndex & 0x1L) == 1L) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 584 */       mask = this.producerMask;
/* 585 */       buffer = this.producerBuffer;
/*     */ 
/*     */ 
/*     */       
/* 589 */       batchIndex = Math.min(producerLimit, pIndex + 2L * limit);
/*     */       
/* 591 */       if (pIndex >= producerLimit) {
/*     */         
/* 593 */         int result = offerSlowPath(mask, pIndex, producerLimit);
/* 594 */         switch (result) {
/*     */           case 0:
/*     */           case 1:
/*     */             continue;
/*     */ 
/*     */           
/*     */           case 2:
/* 601 */             return 0;
/*     */           case 3:
/* 603 */             resize(mask, buffer, pIndex, (E)null, s);
/* 604 */             return 1;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 609 */       if (casProducerIndex(pIndex, batchIndex))
/*     */         break; 
/* 611 */     }  int claimedSlots = (int)((batchIndex - pIndex) / 2L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 616 */     for (int i = 0; i < claimedSlots; i++) {
/*     */       
/* 618 */       long offset = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(pIndex + 2L * i, mask);
/* 619 */       UnsafeRefArrayAccess.soRefElement((Object[])buffer, offset, s.get());
/*     */     } 
/* 621 */     return claimedSlots;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(MessagePassingQueue.Supplier<E> s, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
/* 627 */     MessagePassingQueueUtil.fill(this, s, wait, exit);
/*     */   }
/*     */ 
/*     */   
/*     */   public int drain(MessagePassingQueue.Consumer<E> c) {
/* 632 */     return drain(c, capacity());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int drain(MessagePassingQueue.Consumer<E> c, int limit) {
/* 638 */     return MessagePassingQueueUtil.drain(this, c, limit);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drain(MessagePassingQueue.Consumer<E> c, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
/* 644 */     MessagePassingQueueUtil.drain(this, c, wait, exit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 659 */     return new WeakIterator<E>(this.consumerBuffer, lvConsumerIndex(), lvProducerIndex());
/*     */   }
/*     */   
/*     */   private static class WeakIterator<E>
/*     */     implements Iterator<E>
/*     */   {
/*     */     private final long pIndex;
/*     */     private long nextIndex;
/*     */     private E nextElement;
/*     */     private E[] currentBuffer;
/*     */     private int mask;
/*     */     
/*     */     WeakIterator(E[] currentBuffer, long cIndex, long pIndex) {
/* 672 */       this.pIndex = pIndex >> 1L;
/* 673 */       this.nextIndex = cIndex >> 1L;
/* 674 */       setBuffer(currentBuffer);
/* 675 */       this.nextElement = getNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 680 */       throw new UnsupportedOperationException("remove");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 686 */       return (this.nextElement != null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public E next() {
/* 692 */       E e = this.nextElement;
/* 693 */       if (e == null)
/*     */       {
/* 695 */         throw new NoSuchElementException();
/*     */       }
/* 697 */       this.nextElement = getNext();
/* 698 */       return e;
/*     */     }
/*     */ 
/*     */     
/*     */     private void setBuffer(E[] buffer) {
/* 703 */       this.currentBuffer = buffer;
/* 704 */       this.mask = LinkedArrayQueueUtil.length((Object[])buffer) - 2;
/*     */     }
/*     */ 
/*     */     
/*     */     private E getNext() {
/* 709 */       while (this.nextIndex < this.pIndex) {
/*     */         
/* 711 */         long index = this.nextIndex++;
/* 712 */         E e = (E)UnsafeRefArrayAccess.lvRefElement((Object[])this.currentBuffer, UnsafeRefArrayAccess.calcCircularRefElementOffset(index, this.mask));
/*     */         
/* 714 */         if (e == null) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 720 */         if (e != BaseMpscLinkedArrayQueue.JUMP)
/*     */         {
/* 722 */           return e;
/*     */         }
/*     */ 
/*     */         
/* 726 */         int nextBufferIndex = this.mask + 1;
/* 727 */         Object nextBuffer = UnsafeRefArrayAccess.lvRefElement((Object[])this.currentBuffer, 
/* 728 */             UnsafeRefArrayAccess.calcRefElementOffset(nextBufferIndex));
/*     */         
/* 730 */         if (nextBuffer == BaseMpscLinkedArrayQueue.BUFFER_CONSUMED || nextBuffer == null)
/*     */         {
/*     */           
/* 733 */           return null;
/*     */         }
/*     */         
/* 736 */         setBuffer((E[])nextBuffer);
/*     */         
/* 738 */         e = (E)UnsafeRefArrayAccess.lvRefElement((Object[])this.currentBuffer, UnsafeRefArrayAccess.calcCircularRefElementOffset(index, this.mask));
/*     */         
/* 740 */         if (e == null) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 746 */         return e;
/*     */       } 
/*     */ 
/*     */       
/* 750 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private void resize(long oldMask, E[] oldBuffer, long pIndex, E e, MessagePassingQueue.Supplier<E> s) {
/*     */     E[] newBuffer;
/* 756 */     assert e == null || s != null;
/* 757 */     int newBufferLength = getNextBufferSize(oldBuffer);
/*     */ 
/*     */     
/*     */     try {
/* 761 */       newBuffer = (E[])UnsafeRefArrayAccess.allocateRefArray(newBufferLength);
/*     */     }
/* 763 */     catch (OutOfMemoryError oom) {
/*     */       
/* 765 */       assert lvProducerIndex() == pIndex + 1L;
/* 766 */       soProducerIndex(pIndex);
/* 767 */       throw oom;
/*     */     } 
/*     */     
/* 770 */     this.producerBuffer = newBuffer;
/* 771 */     int newMask = newBufferLength - 2 << 1;
/* 772 */     this.producerMask = newMask;
/*     */     
/* 774 */     long offsetInOld = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(pIndex, oldMask);
/* 775 */     long offsetInNew = LinkedArrayQueueUtil.modifiedCalcCircularRefElementOffset(pIndex, newMask);
/*     */     
/* 777 */     UnsafeRefArrayAccess.soRefElement((Object[])newBuffer, offsetInNew, (e == null) ? s.get() : e);
/* 778 */     UnsafeRefArrayAccess.soRefElement((Object[])oldBuffer, nextArrayOffset(oldMask), newBuffer);
/*     */ 
/*     */     
/* 781 */     long cIndex = lvConsumerIndex();
/* 782 */     long availableInQueue = availableInQueue(pIndex, cIndex);
/* 783 */     RangeUtil.checkPositive(availableInQueue, "availableInQueue");
/*     */ 
/*     */ 
/*     */     
/* 787 */     soProducerLimit(pIndex + Math.min(newMask, availableInQueue));
/*     */ 
/*     */     
/* 790 */     soProducerIndex(pIndex + 2L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 795 */     UnsafeRefArrayAccess.soRefElement((Object[])oldBuffer, offsetInOld, JUMP);
/*     */   }
/*     */   
/*     */   protected abstract long availableInQueue(long paramLong1, long paramLong2);
/*     */   
/*     */   public abstract int capacity();
/*     */   
/*     */   protected abstract int getNextBufferSize(E[] paramArrayOfE);
/*     */   
/*     */   protected abstract long getCurrentBufferCapacity(long paramLong);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\BaseMpscLinkedArrayQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */