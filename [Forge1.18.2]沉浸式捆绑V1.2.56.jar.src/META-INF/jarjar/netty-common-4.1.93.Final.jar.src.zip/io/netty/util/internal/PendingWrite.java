/*    */ package io.netty.util.internal;
/*    */ 
/*    */ import io.netty.util.ReferenceCountUtil;
/*    */ import io.netty.util.concurrent.Promise;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PendingWrite
/*    */ {
/* 27 */   private static final ObjectPool<PendingWrite> RECYCLER = ObjectPool.newPool(new ObjectPool.ObjectCreator<PendingWrite>()
/*    */       {
/*    */         public PendingWrite newObject(ObjectPool.Handle<PendingWrite> handle) {
/* 30 */           return new PendingWrite(handle);
/*    */         }
/*    */       });
/*    */ 
/*    */   
/*    */   private final ObjectPool.Handle<PendingWrite> handle;
/*    */   
/*    */   public static PendingWrite newInstance(Object msg, Promise<Void> promise) {
/* 38 */     PendingWrite pending = RECYCLER.get();
/* 39 */     pending.msg = msg;
/* 40 */     pending.promise = promise;
/* 41 */     return pending;
/*    */   }
/*    */ 
/*    */   
/*    */   private Object msg;
/*    */   private Promise<Void> promise;
/*    */   
/*    */   private PendingWrite(ObjectPool.Handle<PendingWrite> handle) {
/* 49 */     this.handle = handle;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean recycle() {
/* 56 */     this.msg = null;
/* 57 */     this.promise = null;
/* 58 */     this.handle.recycle(this);
/* 59 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean failAndRecycle(Throwable cause) {
/* 66 */     ReferenceCountUtil.release(this.msg);
/* 67 */     if (this.promise != null) {
/* 68 */       this.promise.setFailure(cause);
/*    */     }
/* 70 */     return recycle();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean successAndRecycle() {
/* 77 */     if (this.promise != null) {
/* 78 */       this.promise.setSuccess(null);
/*    */     }
/* 80 */     return recycle();
/*    */   }
/*    */   
/*    */   public Object msg() {
/* 84 */     return this.msg;
/*    */   }
/*    */   
/*    */   public Promise<Void> promise() {
/* 88 */     return this.promise;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Promise<Void> recycleAndGet() {
/* 95 */     Promise<Void> promise = this.promise;
/* 96 */     recycle();
/* 97 */     return promise;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\PendingWrite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */