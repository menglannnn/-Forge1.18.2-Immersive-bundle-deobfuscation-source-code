/*     */ package io.netty.util.internal;
/*     */ 
/*     */ import io.netty.util.IllegalReferenceCountException;
/*     */ import io.netty.util.ReferenceCounted;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReferenceCountUpdater<T extends ReferenceCounted>
/*     */ {
/*     */   public static long getUnsafeOffset(Class<? extends ReferenceCounted> clz, String fieldName) {
/*     */     try {
/*  45 */       if (PlatformDependent.hasUnsafe()) {
/*  46 */         return PlatformDependent.objectFieldOffset(clz.getDeclaredField(fieldName));
/*     */       }
/*  48 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/*  51 */     return -1L;
/*     */   }
/*     */   
/*     */   protected abstract AtomicIntegerFieldUpdater<T> updater();
/*     */   
/*     */   protected abstract long unsafeOffset();
/*     */   
/*     */   public final int initialValue() {
/*  59 */     return 2;
/*     */   }
/*     */   
/*     */   public void setInitialValue(T instance) {
/*  63 */     long offset = unsafeOffset();
/*  64 */     if (offset == -1L) {
/*  65 */       updater().set(instance, initialValue());
/*     */     } else {
/*  67 */       PlatformDependent.safeConstructPutInt(instance, offset, initialValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int realRefCnt(int rawCnt) {
/*  72 */     return (rawCnt != 2 && rawCnt != 4 && (rawCnt & 0x1) != 0) ? 0 : (rawCnt >>> 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int toLiveRealRefCnt(int rawCnt, int decrement) {
/*  79 */     if (rawCnt == 2 || rawCnt == 4 || (rawCnt & 0x1) == 0) {
/*  80 */       return rawCnt >>> 1;
/*     */     }
/*     */     
/*  83 */     throw new IllegalReferenceCountException(0, -decrement);
/*     */   }
/*     */ 
/*     */   
/*     */   private int nonVolatileRawCnt(T instance) {
/*  88 */     long offset = unsafeOffset();
/*  89 */     return (offset != -1L) ? PlatformDependent.getInt(instance, offset) : updater().get(instance);
/*     */   }
/*     */   
/*     */   public final int refCnt(T instance) {
/*  93 */     return realRefCnt(updater().get(instance));
/*     */   }
/*     */   
/*     */   public final boolean isLiveNonVolatile(T instance) {
/*  97 */     long offset = unsafeOffset();
/*  98 */     int rawCnt = (offset != -1L) ? PlatformDependent.getInt(instance, offset) : updater().get(instance);
/*     */ 
/*     */     
/* 101 */     return (rawCnt == 2 || rawCnt == 4 || rawCnt == 6 || rawCnt == 8 || (rawCnt & 0x1) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRefCnt(T instance, int refCnt) {
/* 108 */     updater().set(instance, (refCnt > 0) ? (refCnt << 1) : 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void resetRefCnt(T instance) {
/* 116 */     updater().lazySet(instance, initialValue());
/*     */   }
/*     */   
/*     */   public final T retain(T instance) {
/* 120 */     return retain0(instance, 1, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public final T retain(T instance, int increment) {
/* 125 */     int rawIncrement = ObjectUtil.checkPositive(increment, "increment") << 1;
/* 126 */     return retain0(instance, increment, rawIncrement);
/*     */   }
/*     */ 
/*     */   
/*     */   private T retain0(T instance, int increment, int rawIncrement) {
/* 131 */     int oldRef = updater().getAndAdd(instance, rawIncrement);
/* 132 */     if (oldRef != 2 && oldRef != 4 && (oldRef & 0x1) != 0) {
/* 133 */       throw new IllegalReferenceCountException(0, increment);
/*     */     }
/*     */     
/* 136 */     if ((oldRef <= 0 && oldRef + rawIncrement >= 0) || (oldRef >= 0 && oldRef + rawIncrement < oldRef)) {
/*     */ 
/*     */       
/* 139 */       updater().getAndAdd(instance, -rawIncrement);
/* 140 */       throw new IllegalReferenceCountException(realRefCnt(oldRef), increment);
/*     */     } 
/* 142 */     return instance;
/*     */   }
/*     */   
/*     */   public final boolean release(T instance) {
/* 146 */     int rawCnt = nonVolatileRawCnt(instance);
/* 147 */     return (rawCnt == 2) ? ((tryFinalRelease0(instance, 2) || retryRelease0(instance, 1))) : 
/* 148 */       nonFinalRelease0(instance, 1, rawCnt, toLiveRealRefCnt(rawCnt, 1));
/*     */   }
/*     */   
/*     */   public final boolean release(T instance, int decrement) {
/* 152 */     int rawCnt = nonVolatileRawCnt(instance);
/* 153 */     int realCnt = toLiveRealRefCnt(rawCnt, ObjectUtil.checkPositive(decrement, "decrement"));
/* 154 */     return (decrement == realCnt) ? ((tryFinalRelease0(instance, rawCnt) || retryRelease0(instance, decrement))) : 
/* 155 */       nonFinalRelease0(instance, decrement, rawCnt, realCnt);
/*     */   }
/*     */   
/*     */   private boolean tryFinalRelease0(T instance, int expectRawCnt) {
/* 159 */     return updater().compareAndSet(instance, expectRawCnt, 1);
/*     */   }
/*     */   
/*     */   private boolean nonFinalRelease0(T instance, int decrement, int rawCnt, int realCnt) {
/* 163 */     if (decrement < realCnt && 
/*     */       
/* 165 */       updater().compareAndSet(instance, rawCnt, rawCnt - (decrement << 1))) {
/* 166 */       return false;
/*     */     }
/* 168 */     return retryRelease0(instance, decrement);
/*     */   }
/*     */   
/*     */   private boolean retryRelease0(T instance, int decrement) {
/*     */     while (true) {
/* 173 */       int rawCnt = updater().get(instance), realCnt = toLiveRealRefCnt(rawCnt, decrement);
/* 174 */       if (decrement == realCnt) {
/* 175 */         if (tryFinalRelease0(instance, rawCnt)) {
/* 176 */           return true;
/*     */         }
/* 178 */       } else if (decrement < realCnt) {
/*     */         
/* 180 */         if (updater().compareAndSet(instance, rawCnt, rawCnt - (decrement << 1))) {
/* 181 */           return false;
/*     */         }
/*     */       } else {
/* 184 */         throw new IllegalReferenceCountException(realCnt, -decrement);
/*     */       } 
/* 186 */       Thread.yield();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\ReferenceCountUpdater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */