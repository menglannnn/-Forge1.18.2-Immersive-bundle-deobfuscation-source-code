/*     */ package io.netty.util.internal;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjectUtil
/*     */ {
/*     */   private static final float FLOAT_ZERO = 0.0F;
/*     */   private static final double DOUBLE_ZERO = 0.0D;
/*     */   private static final long LONG_ZERO = 0L;
/*     */   private static final int INT_ZERO = 0;
/*     */   
/*     */   public static <T> T checkNotNull(T arg, String text) {
/*  38 */     if (arg == null) {
/*  39 */       throw new NullPointerException(text);
/*     */     }
/*  41 */     return arg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T[] deepCheckNotNull(String text, T... varargs) {
/*  52 */     if (varargs == null) {
/*  53 */       throw new NullPointerException(text);
/*     */     }
/*     */     
/*  56 */     for (T element : varargs) {
/*  57 */       if (element == null) {
/*  58 */         throw new NullPointerException(text);
/*     */       }
/*     */     } 
/*  61 */     return varargs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T checkNotNullWithIAE(T arg, String paramName) throws IllegalArgumentException {
/*  69 */     if (arg == null) {
/*  70 */       throw new IllegalArgumentException("Param '" + paramName + "' must not be null");
/*     */     }
/*  72 */     return arg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T checkNotNullArrayParam(T value, int index, String name) throws IllegalArgumentException {
/*  87 */     if (value == null) {
/*  88 */       throw new IllegalArgumentException("Array index " + index + " of parameter '" + name + "' must not be null");
/*     */     }
/*     */     
/*  91 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int checkPositive(int i, String name) {
/*  99 */     if (i <= 0) {
/* 100 */       throw new IllegalArgumentException(name + " : " + i + " (expected: > 0)");
/*     */     }
/* 102 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long checkPositive(long l, String name) {
/* 110 */     if (l <= 0L) {
/* 111 */       throw new IllegalArgumentException(name + " : " + l + " (expected: > 0)");
/*     */     }
/* 113 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double checkPositive(double d, String name) {
/* 121 */     if (d <= 0.0D) {
/* 122 */       throw new IllegalArgumentException(name + " : " + d + " (expected: > 0)");
/*     */     }
/* 124 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float checkPositive(float f, String name) {
/* 132 */     if (f <= 0.0F) {
/* 133 */       throw new IllegalArgumentException(name + " : " + f + " (expected: > 0)");
/*     */     }
/* 135 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int checkPositiveOrZero(int i, String name) {
/* 143 */     if (i < 0) {
/* 144 */       throw new IllegalArgumentException(name + " : " + i + " (expected: >= 0)");
/*     */     }
/* 146 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long checkPositiveOrZero(long l, String name) {
/* 154 */     if (l < 0L) {
/* 155 */       throw new IllegalArgumentException(name + " : " + l + " (expected: >= 0)");
/*     */     }
/* 157 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double checkPositiveOrZero(double d, String name) {
/* 165 */     if (d < 0.0D) {
/* 166 */       throw new IllegalArgumentException(name + " : " + d + " (expected: >= 0)");
/*     */     }
/* 168 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float checkPositiveOrZero(float f, String name) {
/* 176 */     if (f < 0.0F) {
/* 177 */       throw new IllegalArgumentException(name + " : " + f + " (expected: >= 0)");
/*     */     }
/* 179 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int checkInRange(int i, int start, int end, String name) {
/* 187 */     if (i < start || i > end) {
/* 188 */       throw new IllegalArgumentException(name + ": " + i + " (expected: " + start + "-" + end + ")");
/*     */     }
/* 190 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long checkInRange(long l, long start, long end, String name) {
/* 198 */     if (l < start || l > end) {
/* 199 */       throw new IllegalArgumentException(name + ": " + l + " (expected: " + start + "-" + end + ")");
/*     */     }
/* 201 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T[] checkNonEmpty(T[] array, String name) {
/* 211 */     if (((Object[])checkNotNull((T)array, name)).length == 0) {
/* 212 */       throw new IllegalArgumentException("Param '" + name + "' must not be empty");
/*     */     }
/* 214 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] checkNonEmpty(byte[] array, String name) {
/* 224 */     if (((byte[])checkNotNull((T)array, name)).length == 0) {
/* 225 */       throw new IllegalArgumentException("Param '" + name + "' must not be empty");
/*     */     }
/* 227 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] checkNonEmpty(char[] array, String name) {
/* 237 */     if (((char[])checkNotNull((T)array, name)).length == 0) {
/* 238 */       throw new IllegalArgumentException("Param '" + name + "' must not be empty");
/*     */     }
/* 240 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Collection<?>> T checkNonEmpty(T collection, String name) {
/* 250 */     if (((Collection)checkNotNull((Collection)collection, name)).isEmpty()) {
/* 251 */       throw new IllegalArgumentException("Param '" + name + "' must not be empty");
/*     */     }
/* 253 */     return collection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String checkNonEmpty(String value, String name) {
/* 262 */     if (((String)checkNotNull(value, name)).isEmpty()) {
/* 263 */       throw new IllegalArgumentException("Param '" + name + "' must not be empty");
/*     */     }
/* 265 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V, T extends Map<K, V>> T checkNonEmpty(T value, String name) {
/* 274 */     if (((Map)checkNotNull((Map)value, name)).isEmpty()) {
/* 275 */       throw new IllegalArgumentException("Param '" + name + "' must not be empty");
/*     */     }
/* 277 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence checkNonEmpty(CharSequence value, String name) {
/* 286 */     if (((CharSequence)checkNotNull(value, name)).length() == 0) {
/* 287 */       throw new IllegalArgumentException("Param '" + name + "' must not be empty");
/*     */     }
/* 289 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String checkNonEmptyAfterTrim(String value, String name) {
/* 304 */     String trimmed = ((String)checkNotNull(value, name)).trim();
/* 305 */     return checkNonEmpty(trimmed, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int intValue(Integer wrapper, int defaultValue) {
/* 315 */     return (wrapper != null) ? wrapper.intValue() : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long longValue(Long wrapper, long defaultValue) {
/* 325 */     return (wrapper != null) ? wrapper.longValue() : defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\ObjectUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */