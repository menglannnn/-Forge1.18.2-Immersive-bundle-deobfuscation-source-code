/*     */ package io.netty.util.internal;
/*     */ 
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThreadLocalRandom
/*     */   extends Random
/*     */ {
/*  65 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(ThreadLocalRandom.class);
/*     */   
/*  67 */   private static final AtomicLong seedUniquifier = new AtomicLong();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private static volatile long initialSeedUniquifier = SystemPropertyUtil.getLong("io.netty.initialSeedUniquifier", 0L); private static final Thread seedGeneratorThread; private static final BlockingQueue<Long> seedQueue; private static final long seedGeneratorStartTime; private static volatile long seedGeneratorEndTime; private static final long multiplier = 25214903917L; private static final long addend = 11L; private static final long mask = 281474976710655L; private long rnd; boolean initialized; static {
/*  78 */     if (initialSeedUniquifier == 0L) {
/*  79 */       boolean secureRandom = SystemPropertyUtil.getBoolean("java.util.secureRandomSeed", false);
/*  80 */       if (secureRandom) {
/*  81 */         seedQueue = new LinkedBlockingQueue<Long>();
/*  82 */         seedGeneratorStartTime = System.nanoTime();
/*     */ 
/*     */ 
/*     */         
/*  86 */         seedGeneratorThread = new Thread("initialSeedUniquifierGenerator")
/*     */           {
/*     */             public void run() {
/*  89 */               SecureRandom random = new SecureRandom();
/*  90 */               byte[] seed = random.generateSeed(8);
/*  91 */               ThreadLocalRandom.seedGeneratorEndTime = System.nanoTime();
/*  92 */               long s = (seed[0] & 0xFFL) << 56L | (seed[1] & 0xFFL) << 48L | (seed[2] & 0xFFL) << 40L | (seed[3] & 0xFFL) << 32L | (seed[4] & 0xFFL) << 24L | (seed[5] & 0xFFL) << 16L | (seed[6] & 0xFFL) << 8L | seed[7] & 0xFFL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 100 */               ThreadLocalRandom.seedQueue.add(Long.valueOf(s));
/*     */             }
/*     */           };
/* 103 */         seedGeneratorThread.setDaemon(true);
/* 104 */         seedGeneratorThread.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler()
/*     */             {
/*     */               public void uncaughtException(Thread t, Throwable e) {
/* 107 */                 ThreadLocalRandom.logger.debug("An exception has been raised by {}", t.getName(), e);
/*     */               }
/*     */             });
/* 110 */         seedGeneratorThread.start();
/*     */       } else {
/* 112 */         initialSeedUniquifier = mix64(System.currentTimeMillis()) ^ mix64(System.nanoTime());
/* 113 */         seedGeneratorThread = null;
/* 114 */         seedQueue = null;
/* 115 */         seedGeneratorStartTime = 0L;
/*     */       } 
/*     */     } else {
/* 118 */       seedGeneratorThread = null;
/* 119 */       seedQueue = null;
/* 120 */       seedGeneratorStartTime = 0L;
/*     */     } 
/*     */   }
/*     */   private long pad0; private long pad1; private long pad2; private long pad3; private long pad4; private long pad5; private long pad6; private long pad7; private static final long serialVersionUID = -5851777807851030925L;
/*     */   public static void setInitialSeedUniquifier(long initialSeedUniquifier) {
/* 125 */     ThreadLocalRandom.initialSeedUniquifier = initialSeedUniquifier;
/*     */   }
/*     */ 
/*     */   
/*     */   public static long getInitialSeedUniquifier() {
/* 130 */     long initialSeedUniquifier = ThreadLocalRandom.initialSeedUniquifier;
/* 131 */     if (initialSeedUniquifier != 0L) {
/* 132 */       return initialSeedUniquifier;
/*     */     }
/*     */     
/* 135 */     synchronized (ThreadLocalRandom.class) {
/* 136 */       initialSeedUniquifier = ThreadLocalRandom.initialSeedUniquifier;
/* 137 */       if (initialSeedUniquifier != 0L) {
/* 138 */         return initialSeedUniquifier;
/*     */       }
/*     */ 
/*     */       
/* 142 */       long timeoutSeconds = 3L;
/* 143 */       long deadLine = seedGeneratorStartTime + TimeUnit.SECONDS.toNanos(3L);
/* 144 */       boolean interrupted = false;
/*     */       while (true) {
/* 146 */         long waitTime = deadLine - System.nanoTime();
/*     */         try {
/*     */           Long seed;
/* 149 */           if (waitTime <= 0L) {
/* 150 */             seed = seedQueue.poll();
/*     */           } else {
/* 152 */             seed = seedQueue.poll(waitTime, TimeUnit.NANOSECONDS);
/*     */           } 
/*     */           
/* 155 */           if (seed != null) {
/* 156 */             initialSeedUniquifier = seed.longValue();
/*     */             break;
/*     */           } 
/* 159 */         } catch (InterruptedException e) {
/* 160 */           interrupted = true;
/* 161 */           logger.warn("Failed to generate a seed from SecureRandom due to an InterruptedException.");
/*     */           
/*     */           break;
/*     */         } 
/* 165 */         if (waitTime <= 0L) {
/* 166 */           seedGeneratorThread.interrupt();
/* 167 */           logger.warn("Failed to generate a seed from SecureRandom within {} seconds. Not enough entropy?", 
/*     */               
/* 169 */               Long.valueOf(3L));
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 176 */       initialSeedUniquifier ^= 0x3255ECDC33BAE119L;
/* 177 */       initialSeedUniquifier ^= Long.reverse(System.nanoTime());
/*     */       
/* 179 */       ThreadLocalRandom.initialSeedUniquifier = initialSeedUniquifier;
/*     */       
/* 181 */       if (interrupted) {
/*     */         
/* 183 */         Thread.currentThread().interrupt();
/*     */ 
/*     */ 
/*     */         
/* 187 */         seedGeneratorThread.interrupt();
/*     */       } 
/*     */       
/* 190 */       if (seedGeneratorEndTime == 0L) {
/* 191 */         seedGeneratorEndTime = System.nanoTime();
/*     */       }
/*     */       
/* 194 */       return initialSeedUniquifier;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static long newSeed() {
/*     */     while (true) {
/* 200 */       long current = seedUniquifier.get();
/* 201 */       long actualCurrent = (current != 0L) ? current : getInitialSeedUniquifier();
/*     */ 
/*     */       
/* 204 */       long next = actualCurrent * 181783497276652981L;
/*     */       
/* 206 */       if (seedUniquifier.compareAndSet(current, next)) {
/* 207 */         if (current == 0L && logger.isDebugEnabled()) {
/* 208 */           if (seedGeneratorEndTime != 0L) {
/* 209 */             logger.debug(String.format("-Dio.netty.initialSeedUniquifier: 0x%016x (took %d ms)", new Object[] {
/*     */                     
/* 211 */                     Long.valueOf(actualCurrent), 
/* 212 */                     Long.valueOf(TimeUnit.NANOSECONDS.toMillis(seedGeneratorEndTime - seedGeneratorStartTime)) }));
/*     */           } else {
/* 214 */             logger.debug(String.format("-Dio.netty.initialSeedUniquifier: 0x%016x", new Object[] { Long.valueOf(actualCurrent) }));
/*     */           } 
/*     */         }
/* 217 */         return next ^ System.nanoTime();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static long mix64(long z) {
/* 225 */     z = (z ^ z >>> 33L) * -49064778989728563L;
/* 226 */     z = (z ^ z >>> 33L) * -4265267296055464877L;
/* 227 */     return z ^ z >>> 33L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ThreadLocalRandom() {
/* 257 */     super(newSeed());
/* 258 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ThreadLocalRandom current() {
/* 267 */     return InternalThreadLocalMap.get().random();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSeed(long seed) {
/* 278 */     if (this.initialized) {
/* 279 */       throw new UnsupportedOperationException();
/*     */     }
/* 281 */     this.rnd = (seed ^ 0x5DEECE66DL) & 0xFFFFFFFFFFFFL;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int next(int bits) {
/* 286 */     this.rnd = this.rnd * 25214903917L + 11L & 0xFFFFFFFFFFFFL;
/* 287 */     return (int)(this.rnd >>> 48 - bits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nextInt(int least, int bound) {
/* 301 */     if (least >= bound) {
/* 302 */       throw new IllegalArgumentException();
/*     */     }
/* 304 */     return nextInt(bound - least) + least;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long nextLong(long n) {
/* 317 */     ObjectUtil.checkPositive(n, "n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     long offset = 0L;
/* 325 */     while (n >= 2147483647L) {
/* 326 */       int bits = next(2);
/* 327 */       long half = n >>> 1L;
/* 328 */       long nextn = ((bits & 0x2) == 0) ? half : (n - half);
/* 329 */       if ((bits & 0x1) == 0) {
/* 330 */         offset += n - nextn;
/*     */       }
/* 332 */       n = nextn;
/*     */     } 
/* 334 */     return offset + nextInt((int)n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long nextLong(long least, long bound) {
/* 348 */     if (least >= bound) {
/* 349 */       throw new IllegalArgumentException();
/*     */     }
/* 351 */     return nextLong(bound - least) + least;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double nextDouble(double n) {
/* 364 */     ObjectUtil.checkPositive(n, "n");
/* 365 */     return nextDouble() * n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double nextDouble(double least, double bound) {
/* 379 */     if (least >= bound) {
/* 380 */       throw new IllegalArgumentException();
/*     */     }
/* 382 */     return nextDouble() * (bound - least) + least;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\ThreadLocalRandom.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */