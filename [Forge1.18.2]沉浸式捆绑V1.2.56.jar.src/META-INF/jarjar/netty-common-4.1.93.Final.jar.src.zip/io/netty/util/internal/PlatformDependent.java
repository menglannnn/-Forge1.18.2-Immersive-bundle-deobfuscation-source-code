/*      */ package io.netty.util.internal;
/*      */ 
/*      */ import io.netty.util.CharsetUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import io.netty.util.internal.shaded.org.jctools.queues.MpscArrayQueue;
/*      */ import io.netty.util.internal.shaded.org.jctools.queues.MpscChunkedArrayQueue;
/*      */ import io.netty.util.internal.shaded.org.jctools.queues.MpscUnboundedArrayQueue;
/*      */ import io.netty.util.internal.shaded.org.jctools.queues.SpscLinkedQueue;
/*      */ import io.netty.util.internal.shaded.org.jctools.queues.atomic.MpscAtomicArrayQueue;
/*      */ import io.netty.util.internal.shaded.org.jctools.queues.atomic.MpscChunkedAtomicArrayQueue;
/*      */ import io.netty.util.internal.shaded.org.jctools.queues.atomic.MpscUnboundedAtomicArrayQueue;
/*      */ import io.netty.util.internal.shaded.org.jctools.queues.atomic.SpscLinkedAtomicQueue;
/*      */ import io.netty.util.internal.shaded.org.jctools.util.Pow2;
/*      */ import io.netty.util.internal.shaded.org.jctools.util.UnsafeAccess;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.attribute.FileAttribute;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Deque;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentLinkedDeque;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.LinkedBlockingDeque;
/*      */ import java.util.concurrent.ThreadLocalRandom;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class PlatformDependent
/*      */ {
/*   81 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(PlatformDependent.class);
/*      */   
/*   83 */   private static final Pattern MAX_DIRECT_MEMORY_SIZE_ARG_PATTERN = Pattern.compile("\\s*-XX:MaxDirectMemorySize\\s*=\\s*([0-9]+)\\s*([kKmMgG]?)\\s*$");
/*      */ 
/*      */   
/*      */   private static final boolean MAYBE_SUPER_USER;
/*      */   
/*   88 */   private static final boolean CAN_ENABLE_TCP_NODELAY_BY_DEFAULT = !isAndroid();
/*      */   
/*   90 */   private static final Throwable UNSAFE_UNAVAILABILITY_CAUSE = unsafeUnavailabilityCause0();
/*      */   private static final boolean DIRECT_BUFFER_PREFERRED;
/*   92 */   private static final long MAX_DIRECT_MEMORY = estimateMaxDirectMemory();
/*      */   
/*      */   private static final int MPSC_CHUNK_SIZE = 1024;
/*      */   
/*      */   private static final int MIN_MAX_MPSC_CAPACITY = 2048;
/*      */   private static final int MAX_ALLOWED_MPSC_CAPACITY = 1073741824;
/*   98 */   private static final long BYTE_ARRAY_BASE_OFFSET = byteArrayBaseOffset0();
/*      */   
/*  100 */   private static final File TMPDIR = tmpdir0();
/*      */   
/*  102 */   private static final int BIT_MODE = bitMode0();
/*  103 */   private static final String NORMALIZED_ARCH = normalizeArch(SystemPropertyUtil.get("os.arch", ""));
/*  104 */   private static final String NORMALIZED_OS = normalizeOs(SystemPropertyUtil.get("os.name", ""));
/*      */ 
/*      */   
/*  107 */   private static final String[] ALLOWED_LINUX_OS_CLASSIFIERS = new String[] { "fedora", "suse", "arch" };
/*      */   
/*      */   private static final Set<String> LINUX_OS_CLASSIFIERS;
/*  110 */   private static final boolean IS_WINDOWS = isWindows0();
/*  111 */   private static final boolean IS_OSX = isOsx0();
/*  112 */   private static final boolean IS_J9_JVM = isJ9Jvm0();
/*  113 */   private static final boolean IS_IVKVM_DOT_NET = isIkvmDotNet0();
/*      */   
/*  115 */   private static final int ADDRESS_SIZE = addressSize0();
/*      */   
/*      */   private static final boolean USE_DIRECT_BUFFER_NO_CLEANER;
/*      */   private static final AtomicLong DIRECT_MEMORY_COUNTER;
/*      */   private static final long DIRECT_MEMORY_LIMIT;
/*      */   private static final ThreadLocalRandomProvider RANDOM_PROVIDER;
/*      */   private static final Cleaner CLEANER;
/*      */   private static final int UNINITIALIZED_ARRAY_ALLOCATION_THRESHOLD;
/*  123 */   private static final String[] OS_RELEASE_FILES = new String[] { "/etc/os-release", "/usr/lib/os-release" };
/*      */   private static final String LINUX_ID_PREFIX = "ID=";
/*      */   private static final String LINUX_ID_LIKE_PREFIX = "ID_LIKE=";
/*  126 */   public static final boolean BIG_ENDIAN_NATIVE_ORDER = (ByteOrder.nativeOrder() == ByteOrder.BIG_ENDIAN);
/*      */   
/*  128 */   private static final Cleaner NOOP = new Cleaner()
/*      */     {
/*      */       public void freeDirectBuffer(ByteBuffer buffer) {}
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  136 */     if (javaVersion() >= 7) {
/*  137 */       RANDOM_PROVIDER = new ThreadLocalRandomProvider()
/*      */         {
/*      */           @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*      */           public Random current() {
/*  141 */             return ThreadLocalRandom.current();
/*      */           }
/*      */         };
/*      */     } else {
/*  145 */       RANDOM_PROVIDER = new ThreadLocalRandomProvider()
/*      */         {
/*      */           public Random current() {
/*  148 */             return ThreadLocalRandom.current();
/*      */           }
/*      */         };
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  160 */     long maxDirectMemory = SystemPropertyUtil.getLong("io.netty.maxDirectMemory", -1L);
/*      */     
/*  162 */     if (maxDirectMemory == 0L || !hasUnsafe() || !PlatformDependent0.hasDirectBufferNoCleanerConstructor()) {
/*  163 */       USE_DIRECT_BUFFER_NO_CLEANER = false;
/*  164 */       DIRECT_MEMORY_COUNTER = null;
/*      */     } else {
/*  166 */       USE_DIRECT_BUFFER_NO_CLEANER = true;
/*  167 */       if (maxDirectMemory < 0L) {
/*  168 */         maxDirectMemory = MAX_DIRECT_MEMORY;
/*  169 */         if (maxDirectMemory <= 0L) {
/*  170 */           DIRECT_MEMORY_COUNTER = null;
/*      */         } else {
/*  172 */           DIRECT_MEMORY_COUNTER = new AtomicLong();
/*      */         } 
/*      */       } else {
/*  175 */         DIRECT_MEMORY_COUNTER = new AtomicLong();
/*      */       } 
/*      */     } 
/*  178 */     logger.debug("-Dio.netty.maxDirectMemory: {} bytes", Long.valueOf(maxDirectMemory));
/*  179 */     DIRECT_MEMORY_LIMIT = (maxDirectMemory >= 1L) ? maxDirectMemory : MAX_DIRECT_MEMORY;
/*      */ 
/*      */     
/*  182 */     int tryAllocateUninitializedArray = SystemPropertyUtil.getInt("io.netty.uninitializedArrayAllocationThreshold", 1024);
/*  183 */     UNINITIALIZED_ARRAY_ALLOCATION_THRESHOLD = (javaVersion() >= 9 && PlatformDependent0.hasAllocateArrayMethod()) ? tryAllocateUninitializedArray : -1;
/*      */     
/*  185 */     logger.debug("-Dio.netty.uninitializedArrayAllocationThreshold: {}", Integer.valueOf(UNINITIALIZED_ARRAY_ALLOCATION_THRESHOLD));
/*      */     
/*  187 */     MAYBE_SUPER_USER = maybeSuperUser0();
/*      */     
/*  189 */     if (!isAndroid()) {
/*      */ 
/*      */       
/*  192 */       if (javaVersion() >= 9) {
/*  193 */         CLEANER = CleanerJava9.isSupported() ? new CleanerJava9() : NOOP;
/*      */       } else {
/*  195 */         CLEANER = CleanerJava6.isSupported() ? new CleanerJava6() : NOOP;
/*      */       } 
/*      */     } else {
/*  198 */       CLEANER = NOOP;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  203 */     DIRECT_BUFFER_PREFERRED = (CLEANER != NOOP && !SystemPropertyUtil.getBoolean("io.netty.noPreferDirect", false));
/*  204 */     if (logger.isDebugEnabled()) {
/*  205 */       logger.debug("-Dio.netty.noPreferDirect: {}", Boolean.valueOf(!DIRECT_BUFFER_PREFERRED));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  212 */     if (CLEANER == NOOP && !PlatformDependent0.isExplicitNoUnsafe()) {
/*  213 */       logger.info("Your platform does not provide complete low-level API for accessing direct buffers reliably. Unless explicitly requested, heap buffer will always be preferred to avoid potential system instability.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  219 */     Set<String> allowedClassifiers = Collections.unmodifiableSet(new HashSet<String>(
/*  220 */           Arrays.asList(ALLOWED_LINUX_OS_CLASSIFIERS)));
/*  221 */     Set<String> availableClassifiers = new LinkedHashSet<String>();
/*      */     
/*  223 */     if (!addPropertyOsClassifiers(allowedClassifiers, availableClassifiers)) {
/*  224 */       addFilesystemOsClassifiers(allowedClassifiers, availableClassifiers);
/*      */     }
/*  226 */     LINUX_OS_CLASSIFIERS = Collections.unmodifiableSet(availableClassifiers);
/*      */   }
/*      */ 
/*      */   
/*      */   static void addFilesystemOsClassifiers(final Set<String> allowedClassifiers, final Set<String> availableClassifiers) {
/*  231 */     for (String osReleaseFileName : OS_RELEASE_FILES) {
/*  232 */       final File file = new File(osReleaseFileName);
/*  233 */       boolean found = ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>()
/*      */           {
/*      */             public Boolean run() {
/*      */               try {
/*  237 */                 if (file.exists()) {
/*  238 */                   BufferedReader reader = null;
/*      */                   try {
/*  240 */                     reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), CharsetUtil.UTF_8));
/*      */ 
/*      */                     
/*      */                     String line;
/*      */                     
/*  245 */                     while ((line = reader.readLine()) != null) {
/*  246 */                       if (line.startsWith("ID=")) {
/*  247 */                         String id = PlatformDependent.normalizeOsReleaseVariableValue(line
/*  248 */                             .substring("ID=".length()));
/*  249 */                         PlatformDependent.addClassifier(allowedClassifiers, availableClassifiers, new String[] { id }); continue;
/*  250 */                       }  if (line.startsWith("ID_LIKE=")) {
/*  251 */                         line = PlatformDependent.normalizeOsReleaseVariableValue(line
/*  252 */                             .substring("ID_LIKE=".length()));
/*  253 */                         PlatformDependent.addClassifier(allowedClassifiers, availableClassifiers, line.split("[ ]+"));
/*      */                       } 
/*      */                     } 
/*  256 */                   } catch (SecurityException e) {
/*  257 */                     PlatformDependent.logger.debug("Unable to read {}", osReleaseFileName, e);
/*  258 */                   } catch (IOException e) {
/*  259 */                     PlatformDependent.logger.debug("Error while reading content of {}", osReleaseFileName, e);
/*      */                   } finally {
/*  261 */                     if (reader != null) {
/*      */                       try {
/*  263 */                         reader.close();
/*  264 */                       } catch (IOException iOException) {}
/*      */                     }
/*      */                   } 
/*      */ 
/*      */ 
/*      */                   
/*  270 */                   return Boolean.valueOf(true);
/*      */                 } 
/*  272 */               } catch (SecurityException e) {
/*  273 */                 PlatformDependent.logger.debug("Unable to check if {} exists", osReleaseFileName, e);
/*      */               } 
/*  275 */               return Boolean.valueOf(false);
/*      */             }
/*      */           })).booleanValue();
/*      */       
/*  279 */       if (found) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean addPropertyOsClassifiers(Set<String> allowedClassifiers, Set<String> availableClassifiers) {
/*  290 */     String osClassifiersPropertyName = "io.netty.osClassifiers";
/*  291 */     String osClassifiers = SystemPropertyUtil.get(osClassifiersPropertyName);
/*  292 */     if (osClassifiers == null) {
/*  293 */       return false;
/*      */     }
/*  295 */     if (osClassifiers.isEmpty())
/*      */     {
/*  297 */       return true;
/*      */     }
/*  299 */     String[] classifiers = osClassifiers.split(",");
/*  300 */     if (classifiers.length == 0) {
/*  301 */       throw new IllegalArgumentException(osClassifiersPropertyName + " property is not empty, but contains no classifiers: " + osClassifiers);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  306 */     if (classifiers.length > 2) {
/*  307 */       throw new IllegalArgumentException(osClassifiersPropertyName + " property contains more than 2 classifiers: " + osClassifiers);
/*      */     }
/*      */     
/*  310 */     for (String classifier : classifiers) {
/*  311 */       addClassifier(allowedClassifiers, availableClassifiers, new String[] { classifier });
/*      */     } 
/*  313 */     return true;
/*      */   }
/*      */   
/*      */   public static long byteArrayBaseOffset() {
/*  317 */     return BYTE_ARRAY_BASE_OFFSET;
/*      */   }
/*      */   
/*      */   public static boolean hasDirectBufferNoCleanerConstructor() {
/*  321 */     return PlatformDependent0.hasDirectBufferNoCleanerConstructor();
/*      */   }
/*      */   
/*      */   public static byte[] allocateUninitializedArray(int size) {
/*  325 */     return (UNINITIALIZED_ARRAY_ALLOCATION_THRESHOLD < 0 || UNINITIALIZED_ARRAY_ALLOCATION_THRESHOLD > size) ? new byte[size] : 
/*  326 */       PlatformDependent0.allocateUninitializedArray(size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAndroid() {
/*  333 */     return PlatformDependent0.isAndroid();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWindows() {
/*  340 */     return IS_WINDOWS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isOsx() {
/*  347 */     return IS_OSX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean maybeSuperUser() {
/*  355 */     return MAYBE_SUPER_USER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int javaVersion() {
/*  362 */     return PlatformDependent0.javaVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean canEnableTcpNoDelayByDefault() {
/*  369 */     return CAN_ENABLE_TCP_NODELAY_BY_DEFAULT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasUnsafe() {
/*  377 */     return (UNSAFE_UNAVAILABILITY_CAUSE == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable getUnsafeUnavailabilityCause() {
/*  384 */     return UNSAFE_UNAVAILABILITY_CAUSE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isUnaligned() {
/*  393 */     return PlatformDependent0.isUnaligned();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean directBufferPreferred() {
/*  401 */     return DIRECT_BUFFER_PREFERRED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long maxDirectMemory() {
/*  408 */     return DIRECT_MEMORY_LIMIT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long usedDirectMemory() {
/*  418 */     return (DIRECT_MEMORY_COUNTER != null) ? DIRECT_MEMORY_COUNTER.get() : -1L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File tmpdir() {
/*  425 */     return TMPDIR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int bitMode() {
/*  432 */     return BIT_MODE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int addressSize() {
/*  440 */     return ADDRESS_SIZE;
/*      */   }
/*      */   
/*      */   public static long allocateMemory(long size) {
/*  444 */     return PlatformDependent0.allocateMemory(size);
/*      */   }
/*      */   
/*      */   public static void freeMemory(long address) {
/*  448 */     PlatformDependent0.freeMemory(address);
/*      */   }
/*      */   
/*      */   public static long reallocateMemory(long address, long newSize) {
/*  452 */     return PlatformDependent0.reallocateMemory(address, newSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void throwException(Throwable t) {
/*  459 */     if (hasUnsafe()) {
/*  460 */       PlatformDependent0.throwException(t);
/*      */     } else {
/*  462 */       throwException0(t);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static <E extends Throwable> void throwException0(Throwable t) throws E {
/*  468 */     throw (E)t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ConcurrentMap<K, V> newConcurrentHashMap() {
/*  475 */     return new ConcurrentHashMap<K, V>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LongCounter newLongCounter() {
/*  482 */     if (javaVersion() >= 8) {
/*  483 */       return new LongAdderCounter();
/*      */     }
/*  485 */     return new AtomicLongCounter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ConcurrentMap<K, V> newConcurrentHashMap(int initialCapacity) {
/*  493 */     return new ConcurrentHashMap<K, V>(initialCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ConcurrentMap<K, V> newConcurrentHashMap(int initialCapacity, float loadFactor) {
/*  500 */     return new ConcurrentHashMap<K, V>(initialCapacity, loadFactor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ConcurrentMap<K, V> newConcurrentHashMap(int initialCapacity, float loadFactor, int concurrencyLevel) {
/*  508 */     return new ConcurrentHashMap<K, V>(initialCapacity, loadFactor, concurrencyLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ConcurrentMap<K, V> newConcurrentHashMap(Map<? extends K, ? extends V> map) {
/*  515 */     return new ConcurrentHashMap<K, V>(map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void freeDirectBuffer(ByteBuffer buffer) {
/*  523 */     CLEANER.freeDirectBuffer(buffer);
/*      */   }
/*      */   
/*      */   public static long directBufferAddress(ByteBuffer buffer) {
/*  527 */     return PlatformDependent0.directBufferAddress(buffer);
/*      */   }
/*      */   
/*      */   public static ByteBuffer directBuffer(long memoryAddress, int size) {
/*  531 */     if (PlatformDependent0.hasDirectBufferNoCleanerConstructor()) {
/*  532 */       return PlatformDependent0.newDirectBuffer(memoryAddress, size);
/*      */     }
/*  534 */     throw new UnsupportedOperationException("sun.misc.Unsafe or java.nio.DirectByteBuffer.<init>(long, int) not available");
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object getObject(Object object, long fieldOffset) {
/*  539 */     return PlatformDependent0.getObject(object, fieldOffset);
/*      */   }
/*      */   
/*      */   public static int getInt(Object object, long fieldOffset) {
/*  543 */     return PlatformDependent0.getInt(object, fieldOffset);
/*      */   }
/*      */   
/*      */   static void safeConstructPutInt(Object object, long fieldOffset, int value) {
/*  547 */     PlatformDependent0.safeConstructPutInt(object, fieldOffset, value);
/*      */   }
/*      */   
/*      */   public static int getIntVolatile(long address) {
/*  551 */     return PlatformDependent0.getIntVolatile(address);
/*      */   }
/*      */   
/*      */   public static void putIntOrdered(long adddress, int newValue) {
/*  555 */     PlatformDependent0.putIntOrdered(adddress, newValue);
/*      */   }
/*      */   
/*      */   public static byte getByte(long address) {
/*  559 */     return PlatformDependent0.getByte(address);
/*      */   }
/*      */   
/*      */   public static short getShort(long address) {
/*  563 */     return PlatformDependent0.getShort(address);
/*      */   }
/*      */   
/*      */   public static int getInt(long address) {
/*  567 */     return PlatformDependent0.getInt(address);
/*      */   }
/*      */   
/*      */   public static long getLong(long address) {
/*  571 */     return PlatformDependent0.getLong(address);
/*      */   }
/*      */   
/*      */   public static byte getByte(byte[] data, int index) {
/*  575 */     return PlatformDependent0.getByte(data, index);
/*      */   }
/*      */   
/*      */   public static byte getByte(byte[] data, long index) {
/*  579 */     return PlatformDependent0.getByte(data, index);
/*      */   }
/*      */   
/*      */   public static short getShort(byte[] data, int index) {
/*  583 */     return PlatformDependent0.getShort(data, index);
/*      */   }
/*      */   
/*      */   public static int getInt(byte[] data, int index) {
/*  587 */     return PlatformDependent0.getInt(data, index);
/*      */   }
/*      */   
/*      */   public static int getInt(int[] data, long index) {
/*  591 */     return PlatformDependent0.getInt(data, index);
/*      */   }
/*      */   
/*      */   public static long getLong(byte[] data, int index) {
/*  595 */     return PlatformDependent0.getLong(data, index);
/*      */   }
/*      */   
/*      */   public static long getLong(long[] data, long index) {
/*  599 */     return PlatformDependent0.getLong(data, index);
/*      */   }
/*      */   
/*      */   private static long getLongSafe(byte[] bytes, int offset) {
/*  603 */     if (BIG_ENDIAN_NATIVE_ORDER) {
/*  604 */       return bytes[offset] << 56L | (bytes[offset + 1] & 0xFFL) << 48L | (bytes[offset + 2] & 0xFFL) << 40L | (bytes[offset + 3] & 0xFFL) << 32L | (bytes[offset + 4] & 0xFFL) << 24L | (bytes[offset + 5] & 0xFFL) << 16L | (bytes[offset + 6] & 0xFFL) << 8L | bytes[offset + 7] & 0xFFL;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  613 */     return bytes[offset] & 0xFFL | (bytes[offset + 1] & 0xFFL) << 8L | (bytes[offset + 2] & 0xFFL) << 16L | (bytes[offset + 3] & 0xFFL) << 24L | (bytes[offset + 4] & 0xFFL) << 32L | (bytes[offset + 5] & 0xFFL) << 40L | (bytes[offset + 6] & 0xFFL) << 48L | bytes[offset + 7] << 56L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getIntSafe(byte[] bytes, int offset) {
/*  624 */     if (BIG_ENDIAN_NATIVE_ORDER) {
/*  625 */       return bytes[offset] << 24 | (bytes[offset + 1] & 0xFF) << 16 | (bytes[offset + 2] & 0xFF) << 8 | bytes[offset + 3] & 0xFF;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  630 */     return bytes[offset] & 0xFF | (bytes[offset + 1] & 0xFF) << 8 | (bytes[offset + 2] & 0xFF) << 16 | bytes[offset + 3] << 24;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static short getShortSafe(byte[] bytes, int offset) {
/*  637 */     if (BIG_ENDIAN_NATIVE_ORDER) {
/*  638 */       return (short)(bytes[offset] << 8 | bytes[offset + 1] & 0xFF);
/*      */     }
/*  640 */     return (short)(bytes[offset] & 0xFF | bytes[offset + 1] << 8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int hashCodeAsciiCompute(CharSequence value, int offset, int hash) {
/*  647 */     if (BIG_ENDIAN_NATIVE_ORDER) {
/*  648 */       return hash * -862048943 + 
/*      */         
/*  650 */         hashCodeAsciiSanitizeInt(value, offset + 4) * 461845907 + 
/*      */         
/*  652 */         hashCodeAsciiSanitizeInt(value, offset);
/*      */     }
/*  654 */     return hash * -862048943 + 
/*      */       
/*  656 */       hashCodeAsciiSanitizeInt(value, offset) * 461845907 + 
/*      */       
/*  658 */       hashCodeAsciiSanitizeInt(value, offset + 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int hashCodeAsciiSanitizeInt(CharSequence value, int offset) {
/*  665 */     if (BIG_ENDIAN_NATIVE_ORDER)
/*      */     {
/*  667 */       return value.charAt(offset + 3) & 0x1F | (value
/*  668 */         .charAt(offset + 2) & 0x1F) << 8 | (value
/*  669 */         .charAt(offset + 1) & 0x1F) << 16 | (value
/*  670 */         .charAt(offset) & 0x1F) << 24;
/*      */     }
/*  672 */     return (value.charAt(offset + 3) & 0x1F) << 24 | (value
/*  673 */       .charAt(offset + 2) & 0x1F) << 16 | (value
/*  674 */       .charAt(offset + 1) & 0x1F) << 8 | value
/*  675 */       .charAt(offset) & 0x1F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int hashCodeAsciiSanitizeShort(CharSequence value, int offset) {
/*  682 */     if (BIG_ENDIAN_NATIVE_ORDER)
/*      */     {
/*  684 */       return value.charAt(offset + 1) & 0x1F | (value
/*  685 */         .charAt(offset) & 0x1F) << 8;
/*      */     }
/*  687 */     return (value.charAt(offset + 1) & 0x1F) << 8 | value
/*  688 */       .charAt(offset) & 0x1F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int hashCodeAsciiSanitizeByte(char value) {
/*  695 */     return value & 0x1F;
/*      */   }
/*      */   
/*      */   public static void putByte(long address, byte value) {
/*  699 */     PlatformDependent0.putByte(address, value);
/*      */   }
/*      */   
/*      */   public static void putShort(long address, short value) {
/*  703 */     PlatformDependent0.putShort(address, value);
/*      */   }
/*      */   
/*      */   public static void putInt(long address, int value) {
/*  707 */     PlatformDependent0.putInt(address, value);
/*      */   }
/*      */   
/*      */   public static void putLong(long address, long value) {
/*  711 */     PlatformDependent0.putLong(address, value);
/*      */   }
/*      */   
/*      */   public static void putByte(byte[] data, int index, byte value) {
/*  715 */     PlatformDependent0.putByte(data, index, value);
/*      */   }
/*      */   
/*      */   public static void putByte(Object data, long offset, byte value) {
/*  719 */     PlatformDependent0.putByte(data, offset, value);
/*      */   }
/*      */   
/*      */   public static void putShort(byte[] data, int index, short value) {
/*  723 */     PlatformDependent0.putShort(data, index, value);
/*      */   }
/*      */   
/*      */   public static void putInt(byte[] data, int index, int value) {
/*  727 */     PlatformDependent0.putInt(data, index, value);
/*      */   }
/*      */   
/*      */   public static void putLong(byte[] data, int index, long value) {
/*  731 */     PlatformDependent0.putLong(data, index, value);
/*      */   }
/*      */   
/*      */   public static void putObject(Object o, long offset, Object x) {
/*  735 */     PlatformDependent0.putObject(o, offset, x);
/*      */   }
/*      */   
/*      */   public static long objectFieldOffset(Field field) {
/*  739 */     return PlatformDependent0.objectFieldOffset(field);
/*      */   }
/*      */   
/*      */   public static void copyMemory(long srcAddr, long dstAddr, long length) {
/*  743 */     PlatformDependent0.copyMemory(srcAddr, dstAddr, length);
/*      */   }
/*      */   
/*      */   public static void copyMemory(byte[] src, int srcIndex, long dstAddr, long length) {
/*  747 */     PlatformDependent0.copyMemory(src, BYTE_ARRAY_BASE_OFFSET + srcIndex, null, dstAddr, length);
/*      */   }
/*      */   
/*      */   public static void copyMemory(byte[] src, int srcIndex, byte[] dst, int dstIndex, long length) {
/*  751 */     PlatformDependent0.copyMemory(src, BYTE_ARRAY_BASE_OFFSET + srcIndex, dst, BYTE_ARRAY_BASE_OFFSET + dstIndex, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void copyMemory(long srcAddr, byte[] dst, int dstIndex, long length) {
/*  756 */     PlatformDependent0.copyMemory(null, srcAddr, dst, BYTE_ARRAY_BASE_OFFSET + dstIndex, length);
/*      */   }
/*      */   
/*      */   public static void setMemory(byte[] dst, int dstIndex, long bytes, byte value) {
/*  760 */     PlatformDependent0.setMemory(dst, BYTE_ARRAY_BASE_OFFSET + dstIndex, bytes, value);
/*      */   }
/*      */   
/*      */   public static void setMemory(long address, long bytes, byte value) {
/*  764 */     PlatformDependent0.setMemory(address, bytes, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer allocateDirectNoCleaner(int capacity) {
/*  772 */     assert USE_DIRECT_BUFFER_NO_CLEANER;
/*      */     
/*  774 */     incrementMemoryCounter(capacity);
/*      */     try {
/*  776 */       return PlatformDependent0.allocateDirectNoCleaner(capacity);
/*  777 */     } catch (Throwable e) {
/*  778 */       decrementMemoryCounter(capacity);
/*  779 */       throwException(e);
/*  780 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteBuffer reallocateDirectNoCleaner(ByteBuffer buffer, int capacity) {
/*  789 */     assert USE_DIRECT_BUFFER_NO_CLEANER;
/*      */     
/*  791 */     int len = capacity - buffer.capacity();
/*  792 */     incrementMemoryCounter(len);
/*      */     try {
/*  794 */       return PlatformDependent0.reallocateDirectNoCleaner(buffer, capacity);
/*  795 */     } catch (Throwable e) {
/*  796 */       decrementMemoryCounter(len);
/*  797 */       throwException(e);
/*  798 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void freeDirectNoCleaner(ByteBuffer buffer) {
/*  807 */     assert USE_DIRECT_BUFFER_NO_CLEANER;
/*      */     
/*  809 */     int capacity = buffer.capacity();
/*  810 */     PlatformDependent0.freeMemory(PlatformDependent0.directBufferAddress(buffer));
/*  811 */     decrementMemoryCounter(capacity);
/*      */   }
/*      */   
/*      */   public static boolean hasAlignDirectByteBuffer() {
/*  815 */     return (hasUnsafe() || PlatformDependent0.hasAlignSliceMethod());
/*      */   }
/*      */   
/*      */   public static ByteBuffer alignDirectBuffer(ByteBuffer buffer, int alignment) {
/*  819 */     if (!buffer.isDirect()) {
/*  820 */       throw new IllegalArgumentException("Cannot get aligned slice of non-direct byte buffer.");
/*      */     }
/*  822 */     if (PlatformDependent0.hasAlignSliceMethod()) {
/*  823 */       return PlatformDependent0.alignSlice(buffer, alignment);
/*      */     }
/*  825 */     if (hasUnsafe()) {
/*  826 */       long address = directBufferAddress(buffer);
/*  827 */       long aligned = align(address, alignment);
/*  828 */       buffer.position((int)(aligned - address));
/*  829 */       return buffer.slice();
/*      */     } 
/*      */     
/*  832 */     throw new UnsupportedOperationException("Cannot align direct buffer. Needs either Unsafe or ByteBuffer.alignSlice method available.");
/*      */   }
/*      */ 
/*      */   
/*      */   public static long align(long value, int alignment) {
/*  837 */     return Pow2.align(value, alignment);
/*      */   }
/*      */   
/*      */   private static void incrementMemoryCounter(int capacity) {
/*  841 */     if (DIRECT_MEMORY_COUNTER != null) {
/*  842 */       long newUsedMemory = DIRECT_MEMORY_COUNTER.addAndGet(capacity);
/*  843 */       if (newUsedMemory > DIRECT_MEMORY_LIMIT) {
/*  844 */         DIRECT_MEMORY_COUNTER.addAndGet(-capacity);
/*  845 */         throw new OutOfDirectMemoryError("failed to allocate " + capacity + " byte(s) of direct memory (used: " + (newUsedMemory - capacity) + ", max: " + DIRECT_MEMORY_LIMIT + ')');
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void decrementMemoryCounter(int capacity) {
/*  853 */     if (DIRECT_MEMORY_COUNTER != null) {
/*  854 */       long usedMemory = DIRECT_MEMORY_COUNTER.addAndGet(-capacity);
/*  855 */       assert usedMemory >= 0L;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean useDirectBufferNoCleaner() {
/*  860 */     return USE_DIRECT_BUFFER_NO_CLEANER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(byte[] bytes1, int startPos1, byte[] bytes2, int startPos2, int length) {
/*  875 */     return (!hasUnsafe() || !PlatformDependent0.unalignedAccess()) ? 
/*  876 */       equalsSafe(bytes1, startPos1, bytes2, startPos2, length) : 
/*  877 */       PlatformDependent0.equals(bytes1, startPos1, bytes2, startPos2, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isZero(byte[] bytes, int startPos, int length) {
/*  888 */     return (!hasUnsafe() || !PlatformDependent0.unalignedAccess()) ? 
/*  889 */       isZeroSafe(bytes, startPos, length) : 
/*  890 */       PlatformDependent0.isZero(bytes, startPos, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int equalsConstantTime(byte[] bytes1, int startPos1, byte[] bytes2, int startPos2, int length) {
/*  915 */     return (!hasUnsafe() || !PlatformDependent0.unalignedAccess()) ? 
/*  916 */       ConstantTimeUtils.equalsConstantTime(bytes1, startPos1, bytes2, startPos2, length) : 
/*  917 */       PlatformDependent0.equalsConstantTime(bytes1, startPos1, bytes2, startPos2, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hashCodeAscii(byte[] bytes, int startPos, int length) {
/*  930 */     return (!hasUnsafe() || !PlatformDependent0.unalignedAccess()) ? 
/*  931 */       hashCodeAsciiSafe(bytes, startPos, length) : 
/*  932 */       PlatformDependent0.hashCodeAscii(bytes, startPos, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hashCodeAscii(CharSequence bytes) {
/*  946 */     int length = bytes.length();
/*  947 */     int remainingBytes = length & 0x7;
/*  948 */     int hash = -1028477387;
/*      */ 
/*      */ 
/*      */     
/*  952 */     if (length >= 32) {
/*  953 */       for (int i = length - 8; i >= remainingBytes; i -= 8) {
/*  954 */         hash = hashCodeAsciiCompute(bytes, i, hash);
/*      */       }
/*  956 */     } else if (length >= 8) {
/*  957 */       hash = hashCodeAsciiCompute(bytes, length - 8, hash);
/*  958 */       if (length >= 16) {
/*  959 */         hash = hashCodeAsciiCompute(bytes, length - 16, hash);
/*  960 */         if (length >= 24) {
/*  961 */           hash = hashCodeAsciiCompute(bytes, length - 24, hash);
/*      */         }
/*      */       } 
/*      */     } 
/*  965 */     if (remainingBytes == 0) {
/*  966 */       return hash;
/*      */     }
/*  968 */     int offset = 0;
/*  969 */     if ((((remainingBytes != 2) ? 1 : 0) & ((remainingBytes != 4) ? 1 : 0) & ((remainingBytes != 6) ? 1 : 0)) != 0) {
/*  970 */       hash = hash * -862048943 + hashCodeAsciiSanitizeByte(bytes.charAt(0));
/*  971 */       offset = 1;
/*      */     } 
/*  973 */     if ((((remainingBytes != 1) ? 1 : 0) & ((remainingBytes != 4) ? 1 : 0) & ((remainingBytes != 5) ? 1 : 0)) != 0) {
/*      */       
/*  975 */       hash = hash * ((offset == 0) ? -862048943 : 461845907) + PlatformDependent0.hashCodeAsciiSanitize(hashCodeAsciiSanitizeShort(bytes, offset));
/*  976 */       offset += 2;
/*      */     } 
/*  978 */     if (remainingBytes >= 4) {
/*  979 */       return hash * (((((offset == 0) ? 1 : 0) | ((offset == 3) ? 1 : 0)) != 0) ? -862048943 : 461845907) + 
/*  980 */         hashCodeAsciiSanitizeInt(bytes, offset);
/*      */     }
/*  982 */     return hash;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class Mpsc
/*      */   {
/*      */     private static final boolean USE_MPSC_CHUNKED_ARRAY_QUEUE;
/*      */ 
/*      */     
/*      */     static {
/*  992 */       Object unsafe = null;
/*  993 */       if (PlatformDependent.hasUnsafe())
/*      */       {
/*      */ 
/*      */         
/*  997 */         unsafe = AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               public Object run()
/*      */               {
/* 1001 */                 return UnsafeAccess.UNSAFE;
/*      */               }
/*      */             });
/*      */       }
/*      */       
/* 1006 */       if (unsafe == null) {
/* 1007 */         PlatformDependent.logger.debug("org.jctools-core.MpscChunkedArrayQueue: unavailable");
/* 1008 */         USE_MPSC_CHUNKED_ARRAY_QUEUE = false;
/*      */       } else {
/* 1010 */         PlatformDependent.logger.debug("org.jctools-core.MpscChunkedArrayQueue: available");
/* 1011 */         USE_MPSC_CHUNKED_ARRAY_QUEUE = true;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static <T> Queue<T> newMpscQueue(int maxCapacity) {
/* 1019 */       int capacity = Math.max(Math.min(maxCapacity, 1073741824), 2048);
/* 1020 */       return newChunkedMpscQueue(1024, capacity);
/*      */     }
/*      */     
/*      */     static <T> Queue<T> newChunkedMpscQueue(int chunkSize, int capacity) {
/* 1024 */       return USE_MPSC_CHUNKED_ARRAY_QUEUE ? (Queue<T>)new MpscChunkedArrayQueue(chunkSize, capacity) : (Queue<T>)new MpscChunkedAtomicArrayQueue(chunkSize, capacity);
/*      */     }
/*      */ 
/*      */     
/*      */     static <T> Queue<T> newMpscQueue() {
/* 1029 */       return USE_MPSC_CHUNKED_ARRAY_QUEUE ? (Queue<T>)new MpscUnboundedArrayQueue(1024) : (Queue<T>)new MpscUnboundedAtomicArrayQueue(1024);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Queue<T> newMpscQueue() {
/* 1040 */     return Mpsc.newMpscQueue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Queue<T> newMpscQueue(int maxCapacity) {
/* 1048 */     return Mpsc.newMpscQueue(maxCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Queue<T> newMpscQueue(int chunkSize, int maxCapacity) {
/* 1057 */     return Mpsc.newChunkedMpscQueue(chunkSize, maxCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Queue<T> newSpscQueue() {
/* 1065 */     return hasUnsafe() ? (Queue<T>)new SpscLinkedQueue() : (Queue<T>)new SpscLinkedAtomicQueue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Queue<T> newFixedMpscQueue(int capacity) {
/* 1073 */     return hasUnsafe() ? (Queue<T>)new MpscArrayQueue(capacity) : (Queue<T>)new MpscAtomicArrayQueue(capacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClassLoader getClassLoader(Class<?> clazz) {
/* 1080 */     return PlatformDependent0.getClassLoader(clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClassLoader getContextClassLoader() {
/* 1087 */     return PlatformDependent0.getContextClassLoader();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClassLoader getSystemClassLoader() {
/* 1094 */     return PlatformDependent0.getSystemClassLoader();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*      */   public static <C> Deque<C> newConcurrentDeque() {
/* 1102 */     if (javaVersion() < 7) {
/* 1103 */       return new LinkedBlockingDeque<C>();
/*      */     }
/* 1105 */     return new ConcurrentLinkedDeque<C>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Random threadLocalRandom() {
/* 1113 */     return RANDOM_PROVIDER.current();
/*      */   }
/*      */   
/*      */   private static boolean isWindows0() {
/* 1117 */     boolean windows = "windows".equals(NORMALIZED_OS);
/* 1118 */     if (windows) {
/* 1119 */       logger.debug("Platform: Windows");
/*      */     }
/* 1121 */     return windows;
/*      */   }
/*      */   
/*      */   private static boolean isOsx0() {
/* 1125 */     boolean osx = "osx".equals(NORMALIZED_OS);
/* 1126 */     if (osx) {
/* 1127 */       logger.debug("Platform: MacOS");
/*      */     }
/* 1129 */     return osx;
/*      */   }
/*      */   
/*      */   private static boolean maybeSuperUser0() {
/* 1133 */     String username = SystemPropertyUtil.get("user.name");
/* 1134 */     if (isWindows()) {
/* 1135 */       return "Administrator".equals(username);
/*      */     }
/*      */     
/* 1138 */     return ("root".equals(username) || "toor".equals(username));
/*      */   }
/*      */   
/*      */   private static Throwable unsafeUnavailabilityCause0() {
/* 1142 */     if (isAndroid()) {
/* 1143 */       logger.debug("sun.misc.Unsafe: unavailable (Android)");
/* 1144 */       return new UnsupportedOperationException("sun.misc.Unsafe: unavailable (Android)");
/*      */     } 
/*      */     
/* 1147 */     if (isIkvmDotNet()) {
/* 1148 */       logger.debug("sun.misc.Unsafe: unavailable (IKVM.NET)");
/* 1149 */       return new UnsupportedOperationException("sun.misc.Unsafe: unavailable (IKVM.NET)");
/*      */     } 
/*      */     
/* 1152 */     Throwable cause = PlatformDependent0.getUnsafeUnavailabilityCause();
/* 1153 */     if (cause != null) {
/* 1154 */       return cause;
/*      */     }
/*      */     
/*      */     try {
/* 1158 */       boolean hasUnsafe = PlatformDependent0.hasUnsafe();
/* 1159 */       logger.debug("sun.misc.Unsafe: {}", hasUnsafe ? "available" : "unavailable");
/* 1160 */       return hasUnsafe ? null : PlatformDependent0.getUnsafeUnavailabilityCause();
/* 1161 */     } catch (Throwable t) {
/* 1162 */       logger.trace("Could not determine if Unsafe is available", t);
/*      */       
/* 1164 */       return new UnsupportedOperationException("Could not determine if Unsafe is available", t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJ9Jvm() {
/* 1173 */     return IS_J9_JVM;
/*      */   }
/*      */   
/*      */   private static boolean isJ9Jvm0() {
/* 1177 */     String vmName = SystemPropertyUtil.get("java.vm.name", "").toLowerCase();
/* 1178 */     return (vmName.startsWith("ibm j9") || vmName.startsWith("eclipse openj9"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIkvmDotNet() {
/* 1185 */     return IS_IVKVM_DOT_NET;
/*      */   }
/*      */   
/*      */   private static boolean isIkvmDotNet0() {
/* 1189 */     String vmName = SystemPropertyUtil.get("java.vm.name", "").toUpperCase(Locale.US);
/* 1190 */     return vmName.equals("IKVM.NET");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long estimateMaxDirectMemory() {
/* 1203 */     long maxDirectMemory = 0L;
/*      */     
/* 1205 */     ClassLoader systemClassLoader = null;
/*      */     try {
/* 1207 */       systemClassLoader = getSystemClassLoader();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1213 */       String vmName = SystemPropertyUtil.get("java.vm.name", "").toLowerCase();
/* 1214 */       if (!vmName.startsWith("ibm j9") && 
/*      */         
/* 1216 */         !vmName.startsWith("eclipse openj9")) {
/*      */         
/* 1218 */         Class<?> vmClass = Class.forName("sun.misc.VM", true, systemClassLoader);
/* 1219 */         Method m = vmClass.getDeclaredMethod("maxDirectMemory", new Class[0]);
/* 1220 */         maxDirectMemory = ((Number)m.invoke(null, new Object[0])).longValue();
/*      */       } 
/* 1222 */     } catch (Throwable throwable) {}
/*      */ 
/*      */ 
/*      */     
/* 1226 */     if (maxDirectMemory > 0L) {
/* 1227 */       return maxDirectMemory;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1233 */       Class<?> mgmtFactoryClass = Class.forName("java.lang.management.ManagementFactory", true, systemClassLoader);
/*      */       
/* 1235 */       Class<?> runtimeClass = Class.forName("java.lang.management.RuntimeMXBean", true, systemClassLoader);
/*      */ 
/*      */       
/* 1238 */       Object runtime = mgmtFactoryClass.getDeclaredMethod("getRuntimeMXBean", new Class[0]).invoke(null, new Object[0]);
/*      */ 
/*      */       
/* 1241 */       List<String> vmArgs = (List<String>)runtimeClass.getDeclaredMethod("getInputArguments", new Class[0]).invoke(runtime, new Object[0]);
/* 1242 */       for (int i = vmArgs.size() - 1; i >= 0; ) {
/* 1243 */         Matcher m = MAX_DIRECT_MEMORY_SIZE_ARG_PATTERN.matcher(vmArgs.get(i));
/* 1244 */         if (!m.matches()) {
/*      */           i--;
/*      */           continue;
/*      */         } 
/* 1248 */         maxDirectMemory = Long.parseLong(m.group(1));
/* 1249 */         switch (m.group(2).charAt(0)) { case 'K':
/*      */           case 'k':
/* 1251 */             maxDirectMemory *= 1024L; break;
/*      */           case 'M':
/*      */           case 'm':
/* 1254 */             maxDirectMemory *= 1048576L; break;
/*      */           case 'G':
/*      */           case 'g':
/* 1257 */             maxDirectMemory *= 1073741824L;
/*      */             break; }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/* 1264 */     } catch (Throwable throwable) {}
/*      */ 
/*      */ 
/*      */     
/* 1268 */     if (maxDirectMemory <= 0L) {
/* 1269 */       maxDirectMemory = Runtime.getRuntime().maxMemory();
/* 1270 */       logger.debug("maxDirectMemory: {} bytes (maybe)", Long.valueOf(maxDirectMemory));
/*      */     } else {
/* 1272 */       logger.debug("maxDirectMemory: {} bytes", Long.valueOf(maxDirectMemory));
/*      */     } 
/*      */     
/* 1275 */     return maxDirectMemory;
/*      */   }
/*      */   
/*      */   private static File tmpdir0() {
/*      */     File f;
/*      */     try {
/* 1281 */       f = toDirectory(SystemPropertyUtil.get("io.netty.tmpdir"));
/* 1282 */       if (f != null) {
/* 1283 */         logger.debug("-Dio.netty.tmpdir: {}", f);
/* 1284 */         return f;
/*      */       } 
/*      */       
/* 1287 */       f = toDirectory(SystemPropertyUtil.get("java.io.tmpdir"));
/* 1288 */       if (f != null) {
/* 1289 */         logger.debug("-Dio.netty.tmpdir: {} (java.io.tmpdir)", f);
/* 1290 */         return f;
/*      */       } 
/*      */ 
/*      */       
/* 1294 */       if (isWindows()) {
/* 1295 */         f = toDirectory(System.getenv("TEMP"));
/* 1296 */         if (f != null) {
/* 1297 */           logger.debug("-Dio.netty.tmpdir: {} (%TEMP%)", f);
/* 1298 */           return f;
/*      */         } 
/*      */         
/* 1301 */         String userprofile = System.getenv("USERPROFILE");
/* 1302 */         if (userprofile != null) {
/* 1303 */           f = toDirectory(userprofile + "\\AppData\\Local\\Temp");
/* 1304 */           if (f != null) {
/* 1305 */             logger.debug("-Dio.netty.tmpdir: {} (%USERPROFILE%\\AppData\\Local\\Temp)", f);
/* 1306 */             return f;
/*      */           } 
/*      */           
/* 1309 */           f = toDirectory(userprofile + "\\Local Settings\\Temp");
/* 1310 */           if (f != null) {
/* 1311 */             logger.debug("-Dio.netty.tmpdir: {} (%USERPROFILE%\\Local Settings\\Temp)", f);
/* 1312 */             return f;
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1316 */         f = toDirectory(System.getenv("TMPDIR"));
/* 1317 */         if (f != null) {
/* 1318 */           logger.debug("-Dio.netty.tmpdir: {} ($TMPDIR)", f);
/* 1319 */           return f;
/*      */         } 
/*      */       } 
/* 1322 */     } catch (Throwable throwable) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1327 */     if (isWindows()) {
/* 1328 */       f = new File("C:\\Windows\\Temp");
/*      */     } else {
/* 1330 */       f = new File("/tmp");
/*      */     } 
/*      */     
/* 1333 */     logger.warn("Failed to get the temporary directory; falling back to: {}", f);
/* 1334 */     return f;
/*      */   }
/*      */ 
/*      */   
/*      */   private static File toDirectory(String path) {
/* 1339 */     if (path == null) {
/* 1340 */       return null;
/*      */     }
/*      */     
/* 1343 */     File f = new File(path);
/* 1344 */     f.mkdirs();
/*      */     
/* 1346 */     if (!f.isDirectory()) {
/* 1347 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 1351 */       return f.getAbsoluteFile();
/* 1352 */     } catch (Exception ignored) {
/* 1353 */       return f;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static int bitMode0() {
/* 1359 */     int bitMode = SystemPropertyUtil.getInt("io.netty.bitMode", 0);
/* 1360 */     if (bitMode > 0) {
/* 1361 */       logger.debug("-Dio.netty.bitMode: {}", Integer.valueOf(bitMode));
/* 1362 */       return bitMode;
/*      */     } 
/*      */ 
/*      */     
/* 1366 */     bitMode = SystemPropertyUtil.getInt("sun.arch.data.model", 0);
/* 1367 */     if (bitMode > 0) {
/* 1368 */       logger.debug("-Dio.netty.bitMode: {} (sun.arch.data.model)", Integer.valueOf(bitMode));
/* 1369 */       return bitMode;
/*      */     } 
/* 1371 */     bitMode = SystemPropertyUtil.getInt("com.ibm.vm.bitmode", 0);
/* 1372 */     if (bitMode > 0) {
/* 1373 */       logger.debug("-Dio.netty.bitMode: {} (com.ibm.vm.bitmode)", Integer.valueOf(bitMode));
/* 1374 */       return bitMode;
/*      */     } 
/*      */ 
/*      */     
/* 1378 */     String arch = SystemPropertyUtil.get("os.arch", "").toLowerCase(Locale.US).trim();
/* 1379 */     if ("amd64".equals(arch) || "x86_64".equals(arch)) {
/* 1380 */       bitMode = 64;
/* 1381 */     } else if ("i386".equals(arch) || "i486".equals(arch) || "i586".equals(arch) || "i686".equals(arch)) {
/* 1382 */       bitMode = 32;
/*      */     } 
/*      */     
/* 1385 */     if (bitMode > 0) {
/* 1386 */       logger.debug("-Dio.netty.bitMode: {} (os.arch: {})", Integer.valueOf(bitMode), arch);
/*      */     }
/*      */ 
/*      */     
/* 1390 */     String vm = SystemPropertyUtil.get("java.vm.name", "").toLowerCase(Locale.US);
/* 1391 */     Pattern bitPattern = Pattern.compile("([1-9][0-9]+)-?bit");
/* 1392 */     Matcher m = bitPattern.matcher(vm);
/* 1393 */     if (m.find()) {
/* 1394 */       return Integer.parseInt(m.group(1));
/*      */     }
/* 1396 */     return 64;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int addressSize0() {
/* 1401 */     if (!hasUnsafe()) {
/* 1402 */       return -1;
/*      */     }
/* 1404 */     return PlatformDependent0.addressSize();
/*      */   }
/*      */   
/*      */   private static long byteArrayBaseOffset0() {
/* 1408 */     if (!hasUnsafe()) {
/* 1409 */       return -1L;
/*      */     }
/* 1411 */     return PlatformDependent0.byteArrayBaseOffset();
/*      */   }
/*      */   
/*      */   private static boolean equalsSafe(byte[] bytes1, int startPos1, byte[] bytes2, int startPos2, int length) {
/* 1415 */     int end = startPos1 + length;
/* 1416 */     for (; startPos1 < end; startPos1++, startPos2++) {
/* 1417 */       if (bytes1[startPos1] != bytes2[startPos2]) {
/* 1418 */         return false;
/*      */       }
/*      */     } 
/* 1421 */     return true;
/*      */   }
/*      */   
/*      */   private static boolean isZeroSafe(byte[] bytes, int startPos, int length) {
/* 1425 */     int end = startPos + length;
/* 1426 */     for (; startPos < end; startPos++) {
/* 1427 */       if (bytes[startPos] != 0) {
/* 1428 */         return false;
/*      */       }
/*      */     } 
/* 1431 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int hashCodeAsciiSafe(byte[] bytes, int startPos, int length) {
/* 1438 */     int hash = -1028477387;
/* 1439 */     int remainingBytes = length & 0x7;
/* 1440 */     int end = startPos + remainingBytes;
/* 1441 */     for (int i = startPos - 8 + length; i >= end; i -= 8) {
/* 1442 */       hash = PlatformDependent0.hashCodeAsciiCompute(getLongSafe(bytes, i), hash);
/*      */     }
/* 1444 */     switch (remainingBytes) {
/*      */       case 7:
/* 1446 */         return ((hash * -862048943 + PlatformDependent0.hashCodeAsciiSanitize(bytes[startPos])) * 461845907 + 
/* 1447 */           PlatformDependent0.hashCodeAsciiSanitize(getShortSafe(bytes, startPos + 1))) * -862048943 + 
/* 1448 */           PlatformDependent0.hashCodeAsciiSanitize(getIntSafe(bytes, startPos + 3));
/*      */       case 6:
/* 1450 */         return (hash * -862048943 + PlatformDependent0.hashCodeAsciiSanitize(getShortSafe(bytes, startPos))) * 461845907 + 
/* 1451 */           PlatformDependent0.hashCodeAsciiSanitize(getIntSafe(bytes, startPos + 2));
/*      */       case 5:
/* 1453 */         return (hash * -862048943 + PlatformDependent0.hashCodeAsciiSanitize(bytes[startPos])) * 461845907 + 
/* 1454 */           PlatformDependent0.hashCodeAsciiSanitize(getIntSafe(bytes, startPos + 1));
/*      */       case 4:
/* 1456 */         return hash * -862048943 + PlatformDependent0.hashCodeAsciiSanitize(getIntSafe(bytes, startPos));
/*      */       case 3:
/* 1458 */         return (hash * -862048943 + PlatformDependent0.hashCodeAsciiSanitize(bytes[startPos])) * 461845907 + 
/* 1459 */           PlatformDependent0.hashCodeAsciiSanitize(getShortSafe(bytes, startPos + 1));
/*      */       case 2:
/* 1461 */         return hash * -862048943 + PlatformDependent0.hashCodeAsciiSanitize(getShortSafe(bytes, startPos));
/*      */       case 1:
/* 1463 */         return hash * -862048943 + PlatformDependent0.hashCodeAsciiSanitize(bytes[startPos]);
/*      */     } 
/* 1465 */     return hash;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String normalizedArch() {
/* 1470 */     return NORMALIZED_ARCH;
/*      */   }
/*      */   
/*      */   public static String normalizedOs() {
/* 1474 */     return NORMALIZED_OS;
/*      */   }
/*      */   
/*      */   public static Set<String> normalizedLinuxClassifiers() {
/* 1478 */     return LINUX_OS_CLASSIFIERS;
/*      */   }
/*      */   @SuppressJava6Requirement(reason = "Guarded by version check")
/*      */   public static File createTempFile(String prefix, String suffix, File directory) throws IOException {
/*      */     File file;
/* 1483 */     if (javaVersion() >= 7) {
/* 1484 */       if (directory == null) {
/* 1485 */         return Files.createTempFile(prefix, suffix, (FileAttribute<?>[])new FileAttribute[0]).toFile();
/*      */       }
/* 1487 */       return Files.createTempFile(directory.toPath(), prefix, suffix, (FileAttribute<?>[])new FileAttribute[0]).toFile();
/*      */     } 
/*      */     
/* 1490 */     if (directory == null) {
/* 1491 */       file = File.createTempFile(prefix, suffix);
/*      */     } else {
/* 1493 */       file = File.createTempFile(prefix, suffix, directory);
/*      */     } 
/*      */ 
/*      */     
/* 1497 */     if (!file.setReadable(false, false)) {
/* 1498 */       throw new IOException("Failed to set permissions on temporary file " + file);
/*      */     }
/* 1500 */     if (!file.setReadable(true, true)) {
/* 1501 */       throw new IOException("Failed to set permissions on temporary file " + file);
/*      */     }
/* 1503 */     return file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addClassifier(Set<String> allowed, Set<String> dest, String... maybeClassifiers) {
/* 1514 */     for (String id : maybeClassifiers) {
/* 1515 */       if (allowed.contains(id)) {
/* 1516 */         dest.add(id);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static String normalizeOsReleaseVariableValue(String value) {
/* 1523 */     return value.trim().replaceAll("[\"']", "");
/*      */   }
/*      */   
/*      */   private static String normalize(String value) {
/* 1527 */     return value.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+", "");
/*      */   }
/*      */   
/*      */   private static String normalizeArch(String value) {
/* 1531 */     value = normalize(value);
/* 1532 */     if (value.matches("^(x8664|amd64|ia32e|em64t|x64)$")) {
/* 1533 */       return "x86_64";
/*      */     }
/* 1535 */     if (value.matches("^(x8632|x86|i[3-6]86|ia32|x32)$")) {
/* 1536 */       return "x86_32";
/*      */     }
/* 1538 */     if (value.matches("^(ia64|itanium64)$")) {
/* 1539 */       return "itanium_64";
/*      */     }
/* 1541 */     if (value.matches("^(sparc|sparc32)$")) {
/* 1542 */       return "sparc_32";
/*      */     }
/* 1544 */     if (value.matches("^(sparcv9|sparc64)$")) {
/* 1545 */       return "sparc_64";
/*      */     }
/* 1547 */     if (value.matches("^(arm|arm32)$")) {
/* 1548 */       return "arm_32";
/*      */     }
/* 1550 */     if ("aarch64".equals(value)) {
/* 1551 */       return "aarch_64";
/*      */     }
/* 1553 */     if (value.matches("^(ppc|ppc32)$")) {
/* 1554 */       return "ppc_32";
/*      */     }
/* 1556 */     if ("ppc64".equals(value)) {
/* 1557 */       return "ppc_64";
/*      */     }
/* 1559 */     if ("ppc64le".equals(value)) {
/* 1560 */       return "ppcle_64";
/*      */     }
/* 1562 */     if ("s390".equals(value)) {
/* 1563 */       return "s390_32";
/*      */     }
/* 1565 */     if ("s390x".equals(value)) {
/* 1566 */       return "s390_64";
/*      */     }
/* 1568 */     if ("loongarch64".equals(value)) {
/* 1569 */       return "loongarch_64";
/*      */     }
/*      */     
/* 1572 */     return "unknown";
/*      */   }
/*      */   
/*      */   private static String normalizeOs(String value) {
/* 1576 */     value = normalize(value);
/* 1577 */     if (value.startsWith("aix")) {
/* 1578 */       return "aix";
/*      */     }
/* 1580 */     if (value.startsWith("hpux")) {
/* 1581 */       return "hpux";
/*      */     }
/* 1583 */     if (value.startsWith("os400"))
/*      */     {
/* 1585 */       if (value.length() <= 5 || !Character.isDigit(value.charAt(5))) {
/* 1586 */         return "os400";
/*      */       }
/*      */     }
/* 1589 */     if (value.startsWith("linux")) {
/* 1590 */       return "linux";
/*      */     }
/* 1592 */     if (value.startsWith("macosx") || value.startsWith("osx") || value.startsWith("darwin")) {
/* 1593 */       return "osx";
/*      */     }
/* 1595 */     if (value.startsWith("freebsd")) {
/* 1596 */       return "freebsd";
/*      */     }
/* 1598 */     if (value.startsWith("openbsd")) {
/* 1599 */       return "openbsd";
/*      */     }
/* 1601 */     if (value.startsWith("netbsd")) {
/* 1602 */       return "netbsd";
/*      */     }
/* 1604 */     if (value.startsWith("solaris") || value.startsWith("sunos")) {
/* 1605 */       return "sunos";
/*      */     }
/* 1607 */     if (value.startsWith("windows")) {
/* 1608 */       return "windows";
/*      */     }
/*      */     
/* 1611 */     return "unknown";
/*      */   }
/*      */   
/*      */   private static final class AtomicLongCounter extends AtomicLong implements LongCounter { private static final long serialVersionUID = 4074772784610639305L;
/*      */     
/*      */     private AtomicLongCounter() {}
/*      */     
/*      */     public void add(long delta) {
/* 1619 */       addAndGet(delta);
/*      */     }
/*      */ 
/*      */     
/*      */     public void increment() {
/* 1624 */       incrementAndGet();
/*      */     }
/*      */ 
/*      */     
/*      */     public void decrement() {
/* 1629 */       decrementAndGet();
/*      */     }
/*      */ 
/*      */     
/*      */     public long value() {
/* 1634 */       return get();
/*      */     } }
/*      */ 
/*      */   
/*      */   private static interface ThreadLocalRandomProvider {
/*      */     Random current();
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\PlatformDependent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */