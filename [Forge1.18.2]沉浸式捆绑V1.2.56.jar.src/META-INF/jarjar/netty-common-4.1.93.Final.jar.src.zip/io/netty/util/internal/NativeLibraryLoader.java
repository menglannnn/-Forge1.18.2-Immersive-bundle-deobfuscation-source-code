/*     */ package io.netty.util.internal;
/*     */ 
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.attribute.PosixFilePermission;
/*     */ import java.security.AccessController;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeLibraryLoader
/*     */ {
/*  50 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(NativeLibraryLoader.class);
/*     */   
/*     */   private static final String NATIVE_RESOURCE_HOME = "META-INF/native/";
/*     */   
/*     */   private static final File WORKDIR;
/*     */   
/*     */   private static final boolean DELETE_NATIVE_LIB_AFTER_LOADING;
/*     */   private static final boolean TRY_TO_PATCH_SHADED_ID;
/*     */   private static final boolean DETECT_NATIVE_LIBRARY_DUPLICATES;
/*  59 */   private static final byte[] UNIQUE_ID_BYTES = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
/*  60 */     .getBytes(CharsetUtil.US_ASCII);
/*     */   
/*     */   static {
/*  63 */     String workdir = SystemPropertyUtil.get("io.netty.native.workdir");
/*  64 */     if (workdir != null) {
/*  65 */       File f = new File(workdir);
/*  66 */       f.mkdirs();
/*     */       
/*     */       try {
/*  69 */         f = f.getAbsoluteFile();
/*  70 */       } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */       
/*  74 */       WORKDIR = f;
/*  75 */       logger.debug("-Dio.netty.native.workdir: " + WORKDIR);
/*     */     } else {
/*  77 */       WORKDIR = PlatformDependent.tmpdir();
/*  78 */       logger.debug("-Dio.netty.native.workdir: " + WORKDIR + " (io.netty.tmpdir)");
/*     */     } 
/*     */     
/*  81 */     DELETE_NATIVE_LIB_AFTER_LOADING = SystemPropertyUtil.getBoolean("io.netty.native.deleteLibAfterLoading", true);
/*     */     
/*  83 */     logger.debug("-Dio.netty.native.deleteLibAfterLoading: {}", Boolean.valueOf(DELETE_NATIVE_LIB_AFTER_LOADING));
/*     */     
/*  85 */     TRY_TO_PATCH_SHADED_ID = SystemPropertyUtil.getBoolean("io.netty.native.tryPatchShadedId", true);
/*     */     
/*  87 */     logger.debug("-Dio.netty.native.tryPatchShadedId: {}", Boolean.valueOf(TRY_TO_PATCH_SHADED_ID));
/*     */     
/*  89 */     DETECT_NATIVE_LIBRARY_DUPLICATES = SystemPropertyUtil.getBoolean("io.netty.native.detectNativeLibraryDuplicates", true);
/*     */     
/*  91 */     logger.debug("-Dio.netty.native.detectNativeLibraryDuplicates: {}", Boolean.valueOf(DETECT_NATIVE_LIBRARY_DUPLICATES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadFirstAvailable(ClassLoader loader, String... names) {
/* 102 */     List<Throwable> suppressed = new ArrayList<Throwable>();
/* 103 */     for (String name : names) {
/*     */       try {
/* 105 */         load(name, loader);
/* 106 */         logger.debug("Loaded library with name '{}'", name);
/*     */         return;
/* 108 */       } catch (Throwable t) {
/* 109 */         suppressed.add(t);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 114 */     IllegalArgumentException iae = new IllegalArgumentException("Failed to load any of the given libraries: " + Arrays.toString((Object[])names));
/* 115 */     ThrowableUtil.addSuppressedAndClear(iae, suppressed);
/* 116 */     throw iae;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String calculateMangledPackagePrefix() {
/* 139 */     String maybeShaded = NativeLibraryLoader.class.getName();
/*     */     
/* 141 */     String expected = "io!netty!util!internal!NativeLibraryLoader".replace('!', '.');
/* 142 */     if (!maybeShaded.endsWith(expected)) {
/* 143 */       throw new UnsatisfiedLinkError(String.format("Could not find prefix added to %s to get %s. When shading, only adding a package prefix is supported", new Object[] { expected, maybeShaded }));
/*     */     }
/*     */ 
/*     */     
/* 147 */     return maybeShaded.substring(0, maybeShaded.length() - expected.length())
/* 148 */       .replace("_", "_1")
/* 149 */       .replace('.', '_');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void load(String originalName, ClassLoader loader) {
/* 156 */     String mangledPackagePrefix = calculateMangledPackagePrefix();
/* 157 */     String name = mangledPackagePrefix + originalName;
/* 158 */     List<Throwable> suppressed = new ArrayList<Throwable>();
/*     */     
/*     */     try {
/* 161 */       loadLibrary(loader, name, false);
/*     */       return;
/* 163 */     } catch (Throwable ex) {
/* 164 */       suppressed.add(ex);
/*     */ 
/*     */       
/* 167 */       String libname = System.mapLibraryName(name);
/* 168 */       String path = "META-INF/native/" + libname;
/*     */       
/* 170 */       InputStream in = null;
/* 171 */       OutputStream out = null;
/* 172 */       File tmpFile = null;
/* 173 */       URL url = getResource(path, loader);
/*     */       try {
/* 175 */         if (url == null) {
/* 176 */           if (PlatformDependent.isOsx()) {
/* 177 */             String fileName = path.endsWith(".jnilib") ? ("META-INF/native/lib" + name + ".dynlib") : ("META-INF/native/lib" + name + ".jnilib");
/*     */             
/* 179 */             url = getResource(fileName, loader);
/* 180 */             if (url == null) {
/* 181 */               FileNotFoundException fnf = new FileNotFoundException(fileName);
/* 182 */               ThrowableUtil.addSuppressedAndClear(fnf, suppressed);
/* 183 */               throw fnf;
/*     */             } 
/*     */           } else {
/* 186 */             FileNotFoundException fnf = new FileNotFoundException(path);
/* 187 */             ThrowableUtil.addSuppressedAndClear(fnf, suppressed);
/* 188 */             throw fnf;
/*     */           } 
/*     */         }
/*     */         
/* 192 */         int index = libname.lastIndexOf('.');
/* 193 */         String prefix = libname.substring(0, index);
/* 194 */         String suffix = libname.substring(index);
/*     */         
/* 196 */         tmpFile = PlatformDependent.createTempFile(prefix, suffix, WORKDIR);
/* 197 */         in = url.openStream();
/* 198 */         out = new FileOutputStream(tmpFile);
/*     */         
/* 200 */         byte[] buffer = new byte[8192];
/*     */         int length;
/* 202 */         while ((length = in.read(buffer)) > 0) {
/* 203 */           out.write(buffer, 0, length);
/*     */         }
/* 205 */         out.flush();
/*     */         
/* 207 */         if (shouldShadedLibraryIdBePatched(mangledPackagePrefix))
/*     */         {
/*     */           
/* 210 */           tryPatchShadedLibraryIdAndSign(tmpFile, originalName);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 215 */         closeQuietly(out);
/* 216 */         out = null;
/*     */         
/* 218 */         loadLibrary(loader, tmpFile.getPath(), true);
/* 219 */       } catch (UnsatisfiedLinkError e) {
/*     */         try {
/* 221 */           if (tmpFile != null && tmpFile.isFile() && tmpFile.canRead() && 
/* 222 */             !NoexecVolumeDetector.canExecuteExecutable(tmpFile))
/*     */           {
/*     */ 
/*     */             
/* 226 */             logger.info("{} exists but cannot be executed even when execute permissions set; check volume for \"noexec\" flag; use -D{}=[path] to set native working directory separately.", tmpFile
/*     */ 
/*     */                 
/* 229 */                 .getPath(), "io.netty.native.workdir");
/*     */           }
/* 231 */         } catch (Throwable t) {
/* 232 */           suppressed.add(t);
/* 233 */           logger.debug("Error checking if {} is on a file store mounted with noexec", tmpFile, t);
/*     */         } 
/*     */         
/* 236 */         ThrowableUtil.addSuppressedAndClear(e, suppressed);
/* 237 */         throw e;
/* 238 */       } catch (Exception e) {
/* 239 */         UnsatisfiedLinkError ule = new UnsatisfiedLinkError("could not load a native library: " + name);
/* 240 */         ule.initCause(e);
/* 241 */         ThrowableUtil.addSuppressedAndClear(ule, suppressed);
/* 242 */         throw ule;
/*     */       } finally {
/* 244 */         closeQuietly(in);
/* 245 */         closeQuietly(out);
/*     */ 
/*     */ 
/*     */         
/* 249 */         if (tmpFile != null && (!DELETE_NATIVE_LIB_AFTER_LOADING || !tmpFile.delete()))
/* 250 */           tmpFile.deleteOnExit(); 
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   private static URL getResource(String path, ClassLoader loader) {
/*     */     Enumeration<URL> urls;
/*     */     try {
/* 258 */       if (loader == null) {
/* 259 */         urls = ClassLoader.getSystemResources(path);
/*     */       } else {
/* 261 */         urls = loader.getResources(path);
/*     */       } 
/* 263 */     } catch (IOException iox) {
/* 264 */       throw new RuntimeException("An error occurred while getting the resources for " + path, iox);
/*     */     } 
/*     */     
/* 267 */     List<URL> urlsList = Collections.list(urls);
/* 268 */     int size = urlsList.size();
/* 269 */     switch (size) {
/*     */       case 0:
/* 271 */         return null;
/*     */       case 1:
/* 273 */         return urlsList.get(0);
/*     */     } 
/* 275 */     if (DETECT_NATIVE_LIBRARY_DUPLICATES) {
/*     */       try {
/* 277 */         MessageDigest md = MessageDigest.getInstance("SHA-256");
/*     */ 
/*     */         
/* 280 */         URL url = urlsList.get(0);
/* 281 */         byte[] digest = digest(md, url);
/* 282 */         boolean allSame = true;
/* 283 */         if (digest != null) {
/* 284 */           for (int i = 1; i < size; i++) {
/* 285 */             byte[] digest2 = digest(md, urlsList.get(i));
/* 286 */             if (digest2 == null || !Arrays.equals(digest, digest2)) {
/* 287 */               allSame = false;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } else {
/* 292 */           allSame = false;
/*     */         } 
/* 294 */         if (allSame) {
/* 295 */           return url;
/*     */         }
/* 297 */       } catch (NoSuchAlgorithmException e) {
/* 298 */         logger.debug("Don't support SHA-256, can't check if resources have same content.", e);
/*     */       } 
/*     */       
/* 301 */       throw new IllegalStateException("Multiple resources found for '" + path + "' with different content: " + urlsList);
/*     */     } 
/*     */     
/* 304 */     logger.warn("Multiple resources found for '" + path + "' with different content: " + urlsList + ". Please fix your dependency graph.");
/*     */     
/* 306 */     return urlsList.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] digest(MessageDigest digest, URL url) {
/* 312 */     InputStream in = null;
/*     */     try {
/* 314 */       in = url.openStream();
/* 315 */       byte[] bytes = new byte[8192];
/*     */       int i;
/* 317 */       while ((i = in.read(bytes)) != -1) {
/* 318 */         digest.update(bytes, 0, i);
/*     */       }
/* 320 */       return digest.digest();
/* 321 */     } catch (IOException e) {
/* 322 */       logger.debug("Can't read resource.", e);
/* 323 */       return null;
/*     */     } finally {
/* 325 */       closeQuietly(in);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void tryPatchShadedLibraryIdAndSign(File libraryFile, String originalName) {
/* 330 */     if (!(new File("/Library/Developer/CommandLineTools")).exists()) {
/* 331 */       logger.debug("Can't patch shaded library id as CommandLineTools are not installed. Consider installing CommandLineTools with 'xcode-select --install'");
/*     */       
/*     */       return;
/*     */     } 
/* 335 */     String newId = new String(generateUniqueId(originalName.length()), CharsetUtil.UTF_8);
/* 336 */     if (!tryExec("install_name_tool -id " + newId + " " + libraryFile.getAbsolutePath())) {
/*     */       return;
/*     */     }
/*     */     
/* 340 */     tryExec("codesign -s - " + libraryFile.getAbsolutePath());
/*     */   }
/*     */   
/*     */   private static boolean tryExec(String cmd) {
/*     */     try {
/* 345 */       int exitValue = Runtime.getRuntime().exec(cmd).waitFor();
/* 346 */       if (exitValue != 0) {
/* 347 */         logger.debug("Execution of '{}' failed: {}", cmd, Integer.valueOf(exitValue));
/* 348 */         return false;
/*     */       } 
/* 350 */       logger.debug("Execution of '{}' succeed: {}", cmd, Integer.valueOf(exitValue));
/* 351 */       return true;
/* 352 */     } catch (InterruptedException e) {
/* 353 */       Thread.currentThread().interrupt();
/* 354 */     } catch (IOException e) {
/* 355 */       logger.info("Execution of '{}' failed.", cmd, e);
/* 356 */     } catch (SecurityException e) {
/* 357 */       logger.error("Execution of '{}' failed.", cmd, e);
/*     */     } 
/* 359 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean shouldShadedLibraryIdBePatched(String packagePrefix) {
/* 363 */     return (TRY_TO_PATCH_SHADED_ID && PlatformDependent.isOsx() && !packagePrefix.isEmpty());
/*     */   }
/*     */   
/*     */   private static byte[] generateUniqueId(int length) {
/* 367 */     byte[] idBytes = new byte[length];
/* 368 */     for (int i = 0; i < idBytes.length; i++)
/*     */     {
/* 370 */       idBytes[i] = UNIQUE_ID_BYTES[PlatformDependent.threadLocalRandom()
/* 371 */           .nextInt(UNIQUE_ID_BYTES.length)];
/*     */     }
/* 373 */     return idBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadLibrary(ClassLoader loader, String name, boolean absolute) {
/* 383 */     Throwable suppressed = null;
/*     */ 
/*     */ 
/*     */     
/* 387 */     try { Class<?> newHelper = tryToLoadClass(loader, NativeLibraryUtil.class);
/* 388 */       loadLibraryByHelper(newHelper, name, absolute);
/* 389 */       logger.debug("Successfully loaded the library {}", name);
/*     */       return; }
/* 391 */     catch (UnsatisfiedLinkError e)
/* 392 */     { suppressed = e;
/*     */ 
/*     */ 
/*     */       
/* 396 */       NativeLibraryUtil.loadLibrary(name, absolute);
/* 397 */       logger.debug("Successfully loaded the library {}", name); } catch (Exception e) { suppressed = e; NativeLibraryUtil.loadLibrary(name, absolute); logger.debug("Successfully loaded the library {}", name); }
/* 398 */     catch (NoSuchMethodError nsme)
/* 399 */     { if (suppressed != null) {
/* 400 */         ThrowableUtil.addSuppressed(nsme, suppressed);
/*     */       }
/* 402 */       rethrowWithMoreDetailsIfPossible(name, nsme); }
/* 403 */     catch (UnsatisfiedLinkError ule)
/* 404 */     { if (suppressed != null) {
/* 405 */         ThrowableUtil.addSuppressed(ule, suppressed);
/*     */       }
/* 407 */       throw ule; }
/*     */   
/*     */   }
/*     */   
/*     */   @SuppressJava6Requirement(reason = "Guarded by version check")
/*     */   private static void rethrowWithMoreDetailsIfPossible(String name, NoSuchMethodError error) {
/* 413 */     if (PlatformDependent.javaVersion() >= 7) {
/* 414 */       throw new LinkageError("Possible multiple incompatible native libraries on the classpath for '" + name + "'?", error);
/*     */     }
/*     */     
/* 417 */     throw error;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadLibraryByHelper(final Class<?> helper, final String name, final boolean absolute) throws UnsatisfiedLinkError {
/* 422 */     Object ret = AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           
/*     */           public Object run()
/*     */           {
/*     */             try {
/* 428 */               Method method = helper.getMethod("loadLibrary", new Class[] { String.class, boolean.class });
/* 429 */               method.setAccessible(true);
/* 430 */               return method.invoke(null, new Object[] { this.val$name, Boolean.valueOf(this.val$absolute) });
/* 431 */             } catch (Exception e) {
/* 432 */               return e;
/*     */             } 
/*     */           }
/*     */         });
/* 436 */     if (ret instanceof Throwable) {
/* 437 */       Throwable t = (Throwable)ret;
/* 438 */       assert !(t instanceof UnsatisfiedLinkError) : t + " should be a wrapper throwable";
/* 439 */       Throwable cause = t.getCause();
/* 440 */       if (cause instanceof UnsatisfiedLinkError) {
/* 441 */         throw (UnsatisfiedLinkError)cause;
/*     */       }
/* 443 */       UnsatisfiedLinkError ule = new UnsatisfiedLinkError(t.getMessage());
/* 444 */       ule.initCause(t);
/* 445 */       throw ule;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> tryToLoadClass(final ClassLoader loader, final Class<?> helper) throws ClassNotFoundException {
/*     */     try {
/* 459 */       return Class.forName(helper.getName(), false, loader);
/* 460 */     } catch (ClassNotFoundException e1) {
/* 461 */       if (loader == null)
/*     */       {
/* 463 */         throw e1;
/*     */       }
/*     */       
/*     */       try {
/* 467 */         final byte[] classBinary = classToByteArray(helper);
/* 468 */         return AccessController.<Class<?>>doPrivileged(new PrivilegedAction<Class<?>>()
/*     */             {
/*     */               
/*     */               public Class<?> run()
/*     */               {
/*     */                 try {
/* 474 */                   Method defineClass = ClassLoader.class.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class });
/*     */                   
/* 476 */                   defineClass.setAccessible(true);
/* 477 */                   return (Class)defineClass.invoke(loader, new Object[] { this.val$helper.getName(), this.val$classBinary, Integer.valueOf(0), 
/* 478 */                         Integer.valueOf(this.val$classBinary.length) });
/* 479 */                 } catch (Exception e) {
/* 480 */                   throw new IllegalStateException("Define class failed!", e);
/*     */                 } 
/*     */               }
/*     */             });
/* 484 */       } catch (ClassNotFoundException e2) {
/* 485 */         ThrowableUtil.addSuppressed(e2, e1);
/* 486 */         throw e2;
/* 487 */       } catch (RuntimeException e2) {
/* 488 */         ThrowableUtil.addSuppressed(e2, e1);
/* 489 */         throw e2;
/* 490 */       } catch (Error e2) {
/* 491 */         ThrowableUtil.addSuppressed(e2, e1);
/* 492 */         throw e2;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] classToByteArray(Class<?> clazz) throws ClassNotFoundException {
/* 504 */     String fileName = clazz.getName();
/* 505 */     int lastDot = fileName.lastIndexOf('.');
/* 506 */     if (lastDot > 0) {
/* 507 */       fileName = fileName.substring(lastDot + 1);
/*     */     }
/* 509 */     URL classUrl = clazz.getResource(fileName + ".class");
/* 510 */     if (classUrl == null) {
/* 511 */       throw new ClassNotFoundException(clazz.getName());
/*     */     }
/* 513 */     byte[] buf = new byte[1024];
/* 514 */     ByteArrayOutputStream out = new ByteArrayOutputStream(4096);
/* 515 */     InputStream in = null;
/*     */     try {
/* 517 */       in = classUrl.openStream(); int r;
/* 518 */       while ((r = in.read(buf)) != -1) {
/* 519 */         out.write(buf, 0, r);
/*     */       }
/* 521 */       return out.toByteArray();
/* 522 */     } catch (IOException ex) {
/* 523 */       throw new ClassNotFoundException(clazz.getName(), ex);
/*     */     } finally {
/* 525 */       closeQuietly(in);
/* 526 */       closeQuietly(out);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void closeQuietly(Closeable c) {
/* 531 */     if (c != null) {
/*     */       try {
/* 533 */         c.close();
/* 534 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class NoexecVolumeDetector
/*     */   {
/*     */     @SuppressJava6Requirement(reason = "Usage guarded by java version check")
/*     */     private static boolean canExecuteExecutable(File file) throws IOException {
/* 548 */       if (PlatformDependent.javaVersion() < 7)
/*     */       {
/*     */         
/* 551 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 555 */       if (file.canExecute()) {
/* 556 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 566 */       Set<PosixFilePermission> existingFilePermissions = Files.getPosixFilePermissions(file.toPath(), new java.nio.file.LinkOption[0]);
/*     */       
/* 568 */       Set<PosixFilePermission> executePermissions = EnumSet.of(PosixFilePermission.OWNER_EXECUTE, PosixFilePermission.GROUP_EXECUTE, PosixFilePermission.OTHERS_EXECUTE);
/*     */ 
/*     */       
/* 571 */       if (existingFilePermissions.containsAll(executePermissions)) {
/* 572 */         return false;
/*     */       }
/*     */       
/* 575 */       Set<PosixFilePermission> newPermissions = EnumSet.copyOf(existingFilePermissions);
/* 576 */       newPermissions.addAll(executePermissions);
/* 577 */       Files.setPosixFilePermissions(file.toPath(), newPermissions);
/* 578 */       return file.canExecute();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\NativeLibraryLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */