/*    */ package io.netty.util.internal.shaded.org.jctools.queues;
/*    */ 
/*    */ import io.netty.util.internal.shaded.org.jctools.util.Pow2;
/*    */ import io.netty.util.internal.shaded.org.jctools.util.RangeUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MpscChunkedArrayQueueColdProducerFields<E>
/*    */   extends BaseMpscLinkedArrayQueue<E>
/*    */ {
/*    */   protected final long maxQueueCapacity;
/*    */   
/*    */   MpscChunkedArrayQueueColdProducerFields(int initialCapacity, int maxCapacity) {
/* 30 */     super(initialCapacity);
/* 31 */     RangeUtil.checkGreaterThanOrEqual(maxCapacity, 4, "maxCapacity");
/* 32 */     RangeUtil.checkLessThan(Pow2.roundToPowerOfTwo(initialCapacity), Pow2.roundToPowerOfTwo(maxCapacity), "initialCapacity");
/*    */     
/* 34 */     this.maxQueueCapacity = Pow2.roundToPowerOfTwo(maxCapacity) << 1L;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\MpscChunkedArrayQueueColdProducerFields.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */