/*     */ package io.netty.util.internal.shaded.org.jctools.queues.atomic;
/*     */ 
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueue;
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueueUtil;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseLinkedAtomicQueue<E>
/*     */   extends BaseLinkedAtomicQueuePad2<E>
/*     */ {
/*     */   public final Iterator<E> iterator() {
/* 261 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 266 */     return getClass().getName();
/*     */   }
/*     */   
/*     */   protected final LinkedQueueAtomicNode<E> newNode() {
/* 270 */     return new LinkedQueueAtomicNode<E>();
/*     */   }
/*     */   
/*     */   protected final LinkedQueueAtomicNode<E> newNode(E e) {
/* 274 */     return new LinkedQueueAtomicNode<E>(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int size() {
/* 291 */     LinkedQueueAtomicNode<E> chaserNode = lvConsumerNode();
/* 292 */     LinkedQueueAtomicNode<E> producerNode = lvProducerNode();
/* 293 */     int size = 0;
/*     */     
/* 295 */     while (chaserNode != producerNode && chaserNode != null && size < Integer.MAX_VALUE) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 300 */       LinkedQueueAtomicNode<E> next = chaserNode.lvNext();
/*     */       
/* 302 */       if (next == chaserNode) {
/* 303 */         return size;
/*     */       }
/* 305 */       chaserNode = next;
/* 306 */       size++;
/*     */     } 
/* 308 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 323 */     LinkedQueueAtomicNode<E> consumerNode = lvConsumerNode();
/* 324 */     LinkedQueueAtomicNode<E> producerNode = lvProducerNode();
/* 325 */     return (consumerNode == producerNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected E getSingleConsumerNodeValue(LinkedQueueAtomicNode<E> currConsumerNode, LinkedQueueAtomicNode<E> nextNode) {
/* 330 */     E nextValue = nextNode.getAndNullValue();
/*     */ 
/*     */ 
/*     */     
/* 334 */     currConsumerNode.soNext(currConsumerNode);
/* 335 */     spConsumerNode(nextNode);
/*     */     
/* 337 */     return nextValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E poll() {
/* 363 */     LinkedQueueAtomicNode<E> currConsumerNode = lpConsumerNode();
/* 364 */     LinkedQueueAtomicNode<E> nextNode = currConsumerNode.lvNext();
/* 365 */     if (nextNode != null)
/* 366 */       return getSingleConsumerNodeValue(currConsumerNode, nextNode); 
/* 367 */     if (currConsumerNode != lvProducerNode()) {
/* 368 */       nextNode = spinWaitForNextNode(currConsumerNode);
/*     */       
/* 370 */       return getSingleConsumerNodeValue(currConsumerNode, nextNode);
/*     */     } 
/* 372 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E peek() {
/* 395 */     LinkedQueueAtomicNode<E> currConsumerNode = lpConsumerNode();
/* 396 */     LinkedQueueAtomicNode<E> nextNode = currConsumerNode.lvNext();
/* 397 */     if (nextNode != null)
/* 398 */       return nextNode.lpValue(); 
/* 399 */     if (currConsumerNode != lvProducerNode()) {
/* 400 */       nextNode = spinWaitForNextNode(currConsumerNode);
/*     */       
/* 402 */       return nextNode.lpValue();
/*     */     } 
/* 404 */     return null;
/*     */   }
/*     */   
/*     */   LinkedQueueAtomicNode<E> spinWaitForNextNode(LinkedQueueAtomicNode<E> currNode) {
/*     */     LinkedQueueAtomicNode<E> nextNode;
/* 409 */     while ((nextNode = currNode.lvNext()) == null);
/*     */ 
/*     */     
/* 412 */     return nextNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public E relaxedPoll() {
/* 417 */     LinkedQueueAtomicNode<E> currConsumerNode = lpConsumerNode();
/* 418 */     LinkedQueueAtomicNode<E> nextNode = currConsumerNode.lvNext();
/* 419 */     if (nextNode != null) {
/* 420 */       return getSingleConsumerNodeValue(currConsumerNode, nextNode);
/*     */     }
/* 422 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public E relaxedPeek() {
/* 427 */     LinkedQueueAtomicNode<E> nextNode = lpConsumerNode().lvNext();
/* 428 */     if (nextNode != null) {
/* 429 */       return nextNode.lpValue();
/*     */     }
/* 431 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean relaxedOffer(E e) {
/* 436 */     return offer(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public int drain(MessagePassingQueue.Consumer<E> c, int limit) {
/* 441 */     if (null == c)
/* 442 */       throw new IllegalArgumentException("c is null"); 
/* 443 */     if (limit < 0)
/* 444 */       throw new IllegalArgumentException("limit is negative: " + limit); 
/* 445 */     if (limit == 0)
/* 446 */       return 0; 
/* 447 */     LinkedQueueAtomicNode<E> chaserNode = lpConsumerNode();
/* 448 */     for (int i = 0; i < limit; i++) {
/* 449 */       LinkedQueueAtomicNode<E> nextNode = chaserNode.lvNext();
/* 450 */       if (nextNode == null) {
/* 451 */         return i;
/*     */       }
/*     */       
/* 454 */       E nextValue = getSingleConsumerNodeValue(chaserNode, nextNode);
/* 455 */       chaserNode = nextNode;
/* 456 */       c.accept(nextValue);
/*     */     } 
/* 458 */     return limit;
/*     */   }
/*     */ 
/*     */   
/*     */   public int drain(MessagePassingQueue.Consumer<E> c) {
/* 463 */     return MessagePassingQueueUtil.drain(this, c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drain(MessagePassingQueue.Consumer<E> c, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
/* 468 */     MessagePassingQueueUtil.drain(this, c, wait, exit);
/*     */   }
/*     */ 
/*     */   
/*     */   public int capacity() {
/* 473 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\atomic\BaseLinkedAtomicQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */