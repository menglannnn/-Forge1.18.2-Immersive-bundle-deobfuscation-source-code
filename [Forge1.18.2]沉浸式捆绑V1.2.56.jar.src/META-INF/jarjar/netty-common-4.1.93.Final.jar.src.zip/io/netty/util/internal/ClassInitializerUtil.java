/*    */ package io.netty.util.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClassInitializerUtil
/*    */ {
/*    */   public static void tryLoadClasses(Class<?> loadingClass, Class<?>... classes) {
/* 32 */     ClassLoader loader = PlatformDependent.getClassLoader(loadingClass);
/* 33 */     for (Class<?> clazz : classes) {
/* 34 */       tryLoadClass(loader, clazz.getName());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private static void tryLoadClass(ClassLoader classLoader, String className) {
/*    */     try {
/* 41 */       Class.forName(className, true, classLoader);
/* 42 */     } catch (ClassNotFoundException classNotFoundException) {
/*    */     
/* 44 */     } catch (SecurityException securityException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\ClassInitializerUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */