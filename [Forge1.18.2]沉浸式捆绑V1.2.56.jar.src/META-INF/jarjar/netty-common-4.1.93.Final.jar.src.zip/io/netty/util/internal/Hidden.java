/*     */ package io.netty.util.internal;
/*     */ 
/*     */ import io.netty.util.concurrent.FastThreadLocalThread;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import reactor.blockhound.BlockHound;
/*     */ import reactor.blockhound.integration.BlockHoundIntegration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Hidden
/*     */ {
/*     */   @SuppressJava6Requirement(reason = "BlockHound is Java 8+, but this class is only loaded by it's SPI")
/*     */   public static final class NettyBlockHoundIntegration
/*     */     implements BlockHoundIntegration
/*     */   {
/*     */     public void applyTo(BlockHound.Builder builder) {
/*  43 */       builder.allowBlockingCallsInside("io.netty.channel.nio.NioEventLoop", "handleLoopException");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  48 */       builder.allowBlockingCallsInside("io.netty.channel.kqueue.KQueueEventLoop", "handleLoopException");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  53 */       builder.allowBlockingCallsInside("io.netty.channel.epoll.EpollEventLoop", "handleLoopException");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  58 */       builder.allowBlockingCallsInside("io.netty.util.HashedWheelTimer", "start");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  63 */       builder.allowBlockingCallsInside("io.netty.util.HashedWheelTimer", "stop");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  68 */       builder.allowBlockingCallsInside("io.netty.util.HashedWheelTimer$Worker", "waitForNextTick");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  73 */       builder.allowBlockingCallsInside("io.netty.util.concurrent.SingleThreadEventExecutor", "confirmShutdown");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  78 */       builder.allowBlockingCallsInside("io.netty.buffer.PoolArena", "lock");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  83 */       builder.allowBlockingCallsInside("io.netty.buffer.PoolSubpage", "lock");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  88 */       builder.allowBlockingCallsInside("io.netty.buffer.PoolChunk", "allocateRun");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       builder.allowBlockingCallsInside("io.netty.buffer.PoolChunk", "free");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  98 */       builder.allowBlockingCallsInside("io.netty.handler.ssl.SslHandler", "handshake");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       builder.allowBlockingCallsInside("io.netty.handler.ssl.SslHandler", "runAllDelegatedTasks");
/*     */ 
/*     */ 
/*     */       
/* 107 */       builder.allowBlockingCallsInside("io.netty.handler.ssl.SslHandler", "runDelegatedTasks");
/*     */ 
/*     */ 
/*     */       
/* 111 */       builder.allowBlockingCallsInside("io.netty.util.concurrent.GlobalEventExecutor", "takeTask");
/*     */ 
/*     */ 
/*     */       
/* 115 */       builder.allowBlockingCallsInside("io.netty.util.concurrent.GlobalEventExecutor", "addTask");
/*     */ 
/*     */ 
/*     */       
/* 119 */       builder.allowBlockingCallsInside("io.netty.util.concurrent.SingleThreadEventExecutor", "takeTask");
/*     */ 
/*     */ 
/*     */       
/* 123 */       builder.allowBlockingCallsInside("io.netty.util.concurrent.SingleThreadEventExecutor", "addTask");
/*     */ 
/*     */ 
/*     */       
/* 127 */       builder.allowBlockingCallsInside("io.netty.handler.ssl.ReferenceCountedOpenSslClientContext$ExtendedTrustManagerVerifyCallback", "verify");
/*     */ 
/*     */ 
/*     */       
/* 131 */       builder.allowBlockingCallsInside("io.netty.handler.ssl.JdkSslContext$Defaults", "init");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 137 */       builder.allowBlockingCallsInside("sun.security.ssl.SSLEngineImpl", "unwrap");
/*     */ 
/*     */ 
/*     */       
/* 141 */       builder.allowBlockingCallsInside("sun.security.ssl.SSLEngineImpl", "wrap");
/*     */ 
/*     */ 
/*     */       
/* 145 */       builder.allowBlockingCallsInside("io.netty.resolver.dns.UnixResolverDnsServerAddressStreamProvider", "parse");
/*     */ 
/*     */ 
/*     */       
/* 149 */       builder.allowBlockingCallsInside("io.netty.resolver.dns.UnixResolverDnsServerAddressStreamProvider", "parseEtcResolverSearchDomains");
/*     */ 
/*     */ 
/*     */       
/* 153 */       builder.allowBlockingCallsInside("io.netty.resolver.dns.UnixResolverDnsServerAddressStreamProvider", "parseEtcResolverOptions");
/*     */ 
/*     */ 
/*     */       
/* 157 */       builder.allowBlockingCallsInside("io.netty.resolver.HostsFileEntriesProvider$ParserImpl", "parse");
/*     */ 
/*     */ 
/*     */       
/* 161 */       builder.allowBlockingCallsInside("io.netty.util.NetUtil$SoMaxConnAction", "run");
/*     */ 
/*     */ 
/*     */       
/* 165 */       builder.allowBlockingCallsInside("io.netty.util.internal.PlatformDependent", "createTempFile");
/* 166 */       builder.nonBlockingThreadPredicate(new Function<Predicate<Thread>, Predicate<Thread>>()
/*     */           {
/*     */             public Predicate<Thread> apply(final Predicate<Thread> p) {
/* 169 */               return new Predicate<Thread>()
/*     */                 {
/*     */                   @SuppressJava6Requirement(reason = "Predicate#test")
/*     */                   public boolean test(Thread thread) {
/* 173 */                     return (p.test(thread) || (thread instanceof FastThreadLocalThread && 
/*     */                       
/* 175 */                       !((FastThreadLocalThread)thread).permitBlockingCalls()));
/*     */                   }
/*     */                 };
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(BlockHoundIntegration o) {
/* 184 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\Hidden.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */