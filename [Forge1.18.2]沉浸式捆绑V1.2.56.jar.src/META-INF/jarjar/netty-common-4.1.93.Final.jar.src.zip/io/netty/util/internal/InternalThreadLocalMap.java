/*     */ package io.netty.util.internal;
/*     */ 
/*     */ import io.netty.util.concurrent.FastThreadLocal;
/*     */ import io.netty.util.concurrent.FastThreadLocalThread;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InternalThreadLocalMap
/*     */   extends UnpaddedInternalThreadLocalMap
/*     */ {
/*  42 */   private static final ThreadLocal<InternalThreadLocalMap> slowThreadLocalMap = new ThreadLocal<InternalThreadLocalMap>();
/*     */   
/*  44 */   private static final AtomicInteger nextIndex = new AtomicInteger();
/*     */   
/*  46 */   public static final int VARIABLES_TO_REMOVE_INDEX = nextVariableIndex();
/*     */   
/*     */   private static final int DEFAULT_ARRAY_LIST_INITIAL_CAPACITY = 8;
/*     */   
/*     */   private static final int ARRAY_LIST_CAPACITY_EXPAND_THRESHOLD = 1073741824;
/*     */   
/*     */   private static final int ARRAY_LIST_CAPACITY_MAX_SIZE = 2147483639;
/*     */   
/*     */   private static final int HANDLER_SHARABLE_CACHE_INITIAL_CAPACITY = 4;
/*     */   
/*     */   private static final int INDEXED_VARIABLE_TABLE_INITIAL_SIZE = 32;
/*     */   
/*     */   private static final int STRING_BUILDER_INITIAL_SIZE;
/*     */   private static final int STRING_BUILDER_MAX_SIZE;
/*     */   private static final InternalLogger logger;
/*  61 */   public static final Object UNSET = new Object();
/*     */   
/*     */   private Object[] indexedVariables;
/*     */   
/*     */   private int futureListenerStackDepth;
/*     */   
/*     */   private int localChannelReaderStackDepth;
/*     */   
/*     */   private Map<Class<?>, Boolean> handlerSharableCache;
/*     */   
/*     */   private IntegerHolder counterHashCode;
/*     */   private ThreadLocalRandom random;
/*     */   private Map<Class<?>, TypeParameterMatcher> typeParameterMatcherGetCache;
/*     */   private Map<Class<?>, Map<String, TypeParameterMatcher>> typeParameterMatcherFindCache;
/*     */   private StringBuilder stringBuilder;
/*     */   private Map<Charset, CharsetEncoder> charsetEncoderCache;
/*     */   private Map<Charset, CharsetDecoder> charsetDecoderCache;
/*     */   private ArrayList<Object> arrayList;
/*     */   private BitSet cleanerFlags;
/*     */   public long rp1;
/*     */   public long rp2;
/*     */   public long rp3;
/*     */   public long rp4;
/*     */   public long rp5;
/*     */   public long rp6;
/*     */   public long rp7;
/*     */   public long rp8;
/*     */   
/*     */   static {
/*  90 */     STRING_BUILDER_INITIAL_SIZE = SystemPropertyUtil.getInt("io.netty.threadLocalMap.stringBuilder.initialSize", 1024);
/*     */     
/*  92 */     STRING_BUILDER_MAX_SIZE = SystemPropertyUtil.getInt("io.netty.threadLocalMap.stringBuilder.maxSize", 4096);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     logger = InternalLoggerFactory.getInstance(InternalThreadLocalMap.class);
/* 100 */     logger.debug("-Dio.netty.threadLocalMap.stringBuilder.initialSize: {}", Integer.valueOf(STRING_BUILDER_INITIAL_SIZE));
/* 101 */     logger.debug("-Dio.netty.threadLocalMap.stringBuilder.maxSize: {}", Integer.valueOf(STRING_BUILDER_MAX_SIZE));
/*     */   }
/*     */   
/*     */   public static InternalThreadLocalMap getIfSet() {
/* 105 */     Thread thread = Thread.currentThread();
/* 106 */     if (thread instanceof FastThreadLocalThread) {
/* 107 */       return ((FastThreadLocalThread)thread).threadLocalMap();
/*     */     }
/* 109 */     return slowThreadLocalMap.get();
/*     */   }
/*     */   
/*     */   public static InternalThreadLocalMap get() {
/* 113 */     Thread thread = Thread.currentThread();
/* 114 */     if (thread instanceof FastThreadLocalThread) {
/* 115 */       return fastGet((FastThreadLocalThread)thread);
/*     */     }
/* 117 */     return slowGet();
/*     */   }
/*     */ 
/*     */   
/*     */   private static InternalThreadLocalMap fastGet(FastThreadLocalThread thread) {
/* 122 */     InternalThreadLocalMap threadLocalMap = thread.threadLocalMap();
/* 123 */     if (threadLocalMap == null) {
/* 124 */       thread.setThreadLocalMap(threadLocalMap = new InternalThreadLocalMap());
/*     */     }
/* 126 */     return threadLocalMap;
/*     */   }
/*     */   
/*     */   private static InternalThreadLocalMap slowGet() {
/* 130 */     InternalThreadLocalMap ret = slowThreadLocalMap.get();
/* 131 */     if (ret == null) {
/* 132 */       ret = new InternalThreadLocalMap();
/* 133 */       slowThreadLocalMap.set(ret);
/*     */     } 
/* 135 */     return ret;
/*     */   }
/*     */   
/*     */   public static void remove() {
/* 139 */     Thread thread = Thread.currentThread();
/* 140 */     if (thread instanceof FastThreadLocalThread) {
/* 141 */       ((FastThreadLocalThread)thread).setThreadLocalMap(null);
/*     */     } else {
/* 143 */       slowThreadLocalMap.remove();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void destroy() {
/* 148 */     slowThreadLocalMap.remove();
/*     */   }
/*     */   
/*     */   public static int nextVariableIndex() {
/* 152 */     int index = nextIndex.getAndIncrement();
/* 153 */     if (index >= 2147483639 || index < 0) {
/* 154 */       nextIndex.set(2147483639);
/* 155 */       throw new IllegalStateException("too many thread-local indexed variables");
/*     */     } 
/* 157 */     return index;
/*     */   }
/*     */   
/*     */   public static int lastVariableIndex() {
/* 161 */     return nextIndex.get() - 1;
/*     */   }
/*     */   
/*     */   private InternalThreadLocalMap() {
/* 165 */     this.indexedVariables = newIndexedVariableTable();
/*     */   }
/*     */   
/*     */   private static Object[] newIndexedVariableTable() {
/* 169 */     Object[] array = new Object[32];
/* 170 */     Arrays.fill(array, UNSET);
/* 171 */     return array;
/*     */   }
/*     */   
/*     */   public int size() {
/* 175 */     int count = 0;
/*     */     
/* 177 */     if (this.futureListenerStackDepth != 0) {
/* 178 */       count++;
/*     */     }
/* 180 */     if (this.localChannelReaderStackDepth != 0) {
/* 181 */       count++;
/*     */     }
/* 183 */     if (this.handlerSharableCache != null) {
/* 184 */       count++;
/*     */     }
/* 186 */     if (this.counterHashCode != null) {
/* 187 */       count++;
/*     */     }
/* 189 */     if (this.random != null) {
/* 190 */       count++;
/*     */     }
/* 192 */     if (this.typeParameterMatcherGetCache != null) {
/* 193 */       count++;
/*     */     }
/* 195 */     if (this.typeParameterMatcherFindCache != null) {
/* 196 */       count++;
/*     */     }
/* 198 */     if (this.stringBuilder != null) {
/* 199 */       count++;
/*     */     }
/* 201 */     if (this.charsetEncoderCache != null) {
/* 202 */       count++;
/*     */     }
/* 204 */     if (this.charsetDecoderCache != null) {
/* 205 */       count++;
/*     */     }
/* 207 */     if (this.arrayList != null) {
/* 208 */       count++;
/*     */     }
/*     */     
/* 211 */     Object v = indexedVariable(VARIABLES_TO_REMOVE_INDEX);
/* 212 */     if (v != null && v != UNSET) {
/*     */       
/* 214 */       Set<FastThreadLocal<?>> variablesToRemove = (Set<FastThreadLocal<?>>)v;
/* 215 */       count += variablesToRemove.size();
/*     */     } 
/*     */     
/* 218 */     return count;
/*     */   }
/*     */   
/*     */   public StringBuilder stringBuilder() {
/* 222 */     StringBuilder sb = this.stringBuilder;
/* 223 */     if (sb == null) {
/* 224 */       return this.stringBuilder = new StringBuilder(STRING_BUILDER_INITIAL_SIZE);
/*     */     }
/* 226 */     if (sb.capacity() > STRING_BUILDER_MAX_SIZE) {
/* 227 */       sb.setLength(STRING_BUILDER_INITIAL_SIZE);
/* 228 */       sb.trimToSize();
/*     */     } 
/* 230 */     sb.setLength(0);
/* 231 */     return sb;
/*     */   }
/*     */   
/*     */   public Map<Charset, CharsetEncoder> charsetEncoderCache() {
/* 235 */     Map<Charset, CharsetEncoder> cache = this.charsetEncoderCache;
/* 236 */     if (cache == null) {
/* 237 */       this.charsetEncoderCache = cache = new IdentityHashMap<Charset, CharsetEncoder>();
/*     */     }
/* 239 */     return cache;
/*     */   }
/*     */   
/*     */   public Map<Charset, CharsetDecoder> charsetDecoderCache() {
/* 243 */     Map<Charset, CharsetDecoder> cache = this.charsetDecoderCache;
/* 244 */     if (cache == null) {
/* 245 */       this.charsetDecoderCache = cache = new IdentityHashMap<Charset, CharsetDecoder>();
/*     */     }
/* 247 */     return cache;
/*     */   }
/*     */   
/*     */   public <E> ArrayList<E> arrayList() {
/* 251 */     return arrayList(8);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E> ArrayList<E> arrayList(int minCapacity) {
/* 256 */     ArrayList<Object> arrayList = this.arrayList;
/* 257 */     if (arrayList == null) {
/* 258 */       this.arrayList = new ArrayList(minCapacity);
/* 259 */       return (ArrayList)this.arrayList;
/*     */     } 
/* 261 */     arrayList.clear();
/* 262 */     arrayList.ensureCapacity(minCapacity);
/* 263 */     return (ArrayList)arrayList;
/*     */   }
/*     */   
/*     */   public int futureListenerStackDepth() {
/* 267 */     return this.futureListenerStackDepth;
/*     */   }
/*     */   
/*     */   public void setFutureListenerStackDepth(int futureListenerStackDepth) {
/* 271 */     this.futureListenerStackDepth = futureListenerStackDepth;
/*     */   }
/*     */   
/*     */   public ThreadLocalRandom random() {
/* 275 */     ThreadLocalRandom r = this.random;
/* 276 */     if (r == null) {
/* 277 */       this.random = r = new ThreadLocalRandom();
/*     */     }
/* 279 */     return r;
/*     */   }
/*     */   
/*     */   public Map<Class<?>, TypeParameterMatcher> typeParameterMatcherGetCache() {
/* 283 */     Map<Class<?>, TypeParameterMatcher> cache = this.typeParameterMatcherGetCache;
/* 284 */     if (cache == null) {
/* 285 */       this.typeParameterMatcherGetCache = cache = new IdentityHashMap<Class<?>, TypeParameterMatcher>();
/*     */     }
/* 287 */     return cache;
/*     */   }
/*     */   
/*     */   public Map<Class<?>, Map<String, TypeParameterMatcher>> typeParameterMatcherFindCache() {
/* 291 */     Map<Class<?>, Map<String, TypeParameterMatcher>> cache = this.typeParameterMatcherFindCache;
/* 292 */     if (cache == null) {
/* 293 */       this.typeParameterMatcherFindCache = cache = new IdentityHashMap<Class<?>, Map<String, TypeParameterMatcher>>();
/*     */     }
/* 295 */     return cache;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public IntegerHolder counterHashCode() {
/* 300 */     return this.counterHashCode;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setCounterHashCode(IntegerHolder counterHashCode) {
/* 305 */     this.counterHashCode = counterHashCode;
/*     */   }
/*     */   
/*     */   public Map<Class<?>, Boolean> handlerSharableCache() {
/* 309 */     Map<Class<?>, Boolean> cache = this.handlerSharableCache;
/* 310 */     if (cache == null)
/*     */     {
/* 312 */       this.handlerSharableCache = cache = new WeakHashMap<Class<?>, Boolean>(4);
/*     */     }
/* 314 */     return cache;
/*     */   }
/*     */   
/*     */   public int localChannelReaderStackDepth() {
/* 318 */     return this.localChannelReaderStackDepth;
/*     */   }
/*     */   
/*     */   public void setLocalChannelReaderStackDepth(int localChannelReaderStackDepth) {
/* 322 */     this.localChannelReaderStackDepth = localChannelReaderStackDepth;
/*     */   }
/*     */   
/*     */   public Object indexedVariable(int index) {
/* 326 */     Object[] lookup = this.indexedVariables;
/* 327 */     return (index < lookup.length) ? lookup[index] : UNSET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setIndexedVariable(int index, Object value) {
/* 334 */     Object[] lookup = this.indexedVariables;
/* 335 */     if (index < lookup.length) {
/* 336 */       Object oldValue = lookup[index];
/* 337 */       lookup[index] = value;
/* 338 */       return (oldValue == UNSET);
/*     */     } 
/* 340 */     expandIndexedVariableTableAndSet(index, value);
/* 341 */     return true;
/*     */   }
/*     */   
/*     */   private void expandIndexedVariableTableAndSet(int index, Object value) {
/*     */     int newCapacity;
/* 346 */     Object[] oldArray = this.indexedVariables;
/* 347 */     int oldCapacity = oldArray.length;
/*     */     
/* 349 */     if (index < 1073741824) {
/* 350 */       newCapacity = index;
/* 351 */       newCapacity |= newCapacity >>> 1;
/* 352 */       newCapacity |= newCapacity >>> 2;
/* 353 */       newCapacity |= newCapacity >>> 4;
/* 354 */       newCapacity |= newCapacity >>> 8;
/* 355 */       newCapacity |= newCapacity >>> 16;
/* 356 */       newCapacity++;
/*     */     } else {
/* 358 */       newCapacity = 2147483639;
/*     */     } 
/*     */     
/* 361 */     Object[] newArray = Arrays.copyOf(oldArray, newCapacity);
/* 362 */     Arrays.fill(newArray, oldCapacity, newArray.length, UNSET);
/* 363 */     newArray[index] = value;
/* 364 */     this.indexedVariables = newArray;
/*     */   }
/*     */   
/*     */   public Object removeIndexedVariable(int index) {
/* 368 */     Object[] lookup = this.indexedVariables;
/* 369 */     if (index < lookup.length) {
/* 370 */       Object v = lookup[index];
/* 371 */       lookup[index] = UNSET;
/* 372 */       return v;
/*     */     } 
/* 374 */     return UNSET;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIndexedVariableSet(int index) {
/* 379 */     Object[] lookup = this.indexedVariables;
/* 380 */     return (index < lookup.length && lookup[index] != UNSET);
/*     */   }
/*     */   
/*     */   public boolean isCleanerFlagSet(int index) {
/* 384 */     return (this.cleanerFlags != null && this.cleanerFlags.get(index));
/*     */   }
/*     */   
/*     */   public void setCleanerFlag(int index) {
/* 388 */     if (this.cleanerFlags == null) {
/* 389 */       this.cleanerFlags = new BitSet();
/*     */     }
/* 391 */     this.cleanerFlags.set(index);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\InternalThreadLocalMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */