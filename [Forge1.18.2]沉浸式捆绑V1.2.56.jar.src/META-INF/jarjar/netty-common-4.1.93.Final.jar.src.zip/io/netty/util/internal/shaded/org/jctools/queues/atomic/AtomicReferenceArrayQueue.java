/*     */ package io.netty.util.internal.shaded.org.jctools.queues.atomic;
/*     */ 
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.IndexedQueueSizeUtil;
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueue;
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.QueueProgressIndicators;
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.SupportsIterator;
/*     */ import io.netty.util.internal.shaded.org.jctools.util.Pow2;
/*     */ import java.util.AbstractQueue;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AtomicReferenceArrayQueue<E>
/*     */   extends AbstractQueue<E>
/*     */   implements IndexedQueueSizeUtil.IndexedQueue, QueueProgressIndicators, MessagePassingQueue<E>, SupportsIterator
/*     */ {
/*     */   protected final AtomicReferenceArray<E> buffer;
/*     */   protected final int mask;
/*     */   
/*     */   public AtomicReferenceArrayQueue(int capacity) {
/*  37 */     int actualCapacity = Pow2.roundToPowerOfTwo(capacity);
/*  38 */     this.mask = actualCapacity - 1;
/*  39 */     this.buffer = new AtomicReferenceArray<E>(actualCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  45 */     return getClass().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  51 */     while (poll() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int capacity() {
/*  60 */     return this.mask + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int size() {
/*  70 */     return IndexedQueueSizeUtil.size(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEmpty() {
/*  76 */     return IndexedQueueSizeUtil.isEmpty(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final long currentProducerIndex() {
/*  82 */     return lvProducerIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final long currentConsumerIndex() {
/*  88 */     return lvConsumerIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Iterator<E> iterator() {
/* 103 */     long cIndex = lvConsumerIndex();
/* 104 */     long pIndex = lvProducerIndex();
/*     */     
/* 106 */     return new WeakIterator<E>(cIndex, pIndex, this.mask, this.buffer);
/*     */   }
/*     */   
/*     */   private static class WeakIterator<E>
/*     */     implements Iterator<E> {
/*     */     private final long pIndex;
/*     */     private final int mask;
/*     */     private final AtomicReferenceArray<E> buffer;
/*     */     private long nextIndex;
/*     */     private E nextElement;
/*     */     
/*     */     WeakIterator(long cIndex, long pIndex, int mask, AtomicReferenceArray<E> buffer) {
/* 118 */       this.nextIndex = cIndex;
/* 119 */       this.pIndex = pIndex;
/* 120 */       this.mask = mask;
/* 121 */       this.buffer = buffer;
/* 122 */       this.nextElement = getNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 127 */       throw new UnsupportedOperationException("remove");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 132 */       return (this.nextElement != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 137 */       E e = this.nextElement;
/* 138 */       if (e == null)
/* 139 */         throw new NoSuchElementException(); 
/* 140 */       this.nextElement = getNext();
/* 141 */       return e;
/*     */     }
/*     */     
/*     */     private E getNext() {
/* 145 */       int mask = this.mask;
/* 146 */       AtomicReferenceArray<E> buffer = this.buffer;
/* 147 */       while (this.nextIndex < this.pIndex) {
/* 148 */         int offset = AtomicQueueUtil.calcCircularRefElementOffset(this.nextIndex++, mask);
/* 149 */         E e = AtomicQueueUtil.lvRefElement(buffer, offset);
/* 150 */         if (e != null) {
/* 151 */           return e;
/*     */         }
/*     */       } 
/* 154 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\atomic\AtomicReferenceArrayQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */