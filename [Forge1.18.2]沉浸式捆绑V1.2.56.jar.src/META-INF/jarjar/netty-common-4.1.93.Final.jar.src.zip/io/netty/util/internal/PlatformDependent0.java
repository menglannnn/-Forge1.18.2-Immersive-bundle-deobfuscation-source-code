/*      */ package io.netty.util.internal;
/*      */ 
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import sun.misc.Unsafe;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @SuppressJava6Requirement(reason = "Unsafe access is guarded")
/*      */ final class PlatformDependent0
/*      */ {
/*      */   private static final InternalLogger logger;
/*      */   private static final long ADDRESS_FIELD_OFFSET;
/*      */   private static final long BYTE_ARRAY_BASE_OFFSET;
/*      */   private static final long INT_ARRAY_BASE_OFFSET;
/*      */   private static final long INT_ARRAY_INDEX_SCALE;
/*      */   private static final long LONG_ARRAY_BASE_OFFSET;
/*      */   private static final long LONG_ARRAY_INDEX_SCALE;
/*      */   private static final Constructor<?> DIRECT_BUFFER_CONSTRUCTOR;
/*      */   private static final Throwable EXPLICIT_NO_UNSAFE_CAUSE;
/*      */   private static final Method ALLOCATE_ARRAY_METHOD;
/*      */   private static final Method ALIGN_SLICE;
/*      */   private static final int JAVA_VERSION;
/*      */   
/*      */   static {
/*   39 */     logger = InternalLoggerFactory.getInstance(PlatformDependent0.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   47 */     EXPLICIT_NO_UNSAFE_CAUSE = explicitNoUnsafeCause0();
/*      */ 
/*      */     
/*   50 */     JAVA_VERSION = javaVersion0();
/*   51 */     IS_ANDROID = isAndroid0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   59 */     RUNNING_IN_NATIVE_IMAGE = SystemPropertyUtil.contains("org.graalvm.nativeimage.imagecode");
/*      */ 
/*      */     
/*   62 */     IS_EXPLICIT_TRY_REFLECTION_SET_ACCESSIBLE = explicitTryReflectionSetAccessible0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   81 */     Field addressField = null;
/*   82 */     Method allocateArrayMethod = null;
/*   83 */     Throwable unsafeUnavailabilityCause = null;
/*      */     
/*   85 */     Object internalUnsafe = null;
/*   86 */     boolean storeFenceAvailable = false;
/*   87 */     if ((unsafeUnavailabilityCause = EXPLICIT_NO_UNSAFE_CAUSE) != null) {
/*   88 */       direct = null;
/*   89 */       addressField = null;
/*   90 */       unsafe = null;
/*   91 */       internalUnsafe = null;
/*      */     } else {
/*   93 */       direct = ByteBuffer.allocateDirect(1);
/*      */ 
/*      */       
/*   96 */       Object maybeUnsafe = AccessController.doPrivileged(new PrivilegedAction()
/*      */           {
/*      */             public Object run() {
/*      */               try {
/*  100 */                 Field unsafeField = Unsafe.class.getDeclaredField("theUnsafe");
/*      */ 
/*      */                 
/*  103 */                 Throwable cause = ReflectionUtil.trySetAccessible(unsafeField, false);
/*  104 */                 if (cause != null) {
/*  105 */                   return cause;
/*      */                 }
/*      */                 
/*  108 */                 return unsafeField.get(null);
/*  109 */               } catch (NoSuchFieldException e) {
/*  110 */                 return e;
/*  111 */               } catch (SecurityException e) {
/*  112 */                 return e;
/*  113 */               } catch (IllegalAccessException e) {
/*  114 */                 return e;
/*  115 */               } catch (NoClassDefFoundError e) {
/*      */ 
/*      */                 
/*  118 */                 return e;
/*      */               } 
/*      */             }
/*      */           });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  127 */       if (maybeUnsafe instanceof Throwable) {
/*  128 */         unsafe = null;
/*  129 */         unsafeUnavailabilityCause = (Throwable)maybeUnsafe;
/*  130 */         if (logger.isTraceEnabled()) {
/*  131 */           logger.debug("sun.misc.Unsafe.theUnsafe: unavailable", (Throwable)maybeUnsafe);
/*      */         } else {
/*  133 */           logger.debug("sun.misc.Unsafe.theUnsafe: unavailable: {}", ((Throwable)maybeUnsafe).getMessage());
/*      */         } 
/*      */       } else {
/*  136 */         unsafe = (Unsafe)maybeUnsafe;
/*  137 */         logger.debug("sun.misc.Unsafe.theUnsafe: available");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  143 */       if (unsafe != null) {
/*  144 */         final Unsafe finalUnsafe = unsafe;
/*  145 */         Object maybeException = AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               public Object run() {
/*      */                 try {
/*  149 */                   finalUnsafe.getClass().getDeclaredMethod("copyMemory", new Class[] { Object.class, long.class, Object.class, long.class, long.class });
/*      */                   
/*  151 */                   return null;
/*  152 */                 } catch (NoSuchMethodException e) {
/*  153 */                   return e;
/*  154 */                 } catch (SecurityException e) {
/*  155 */                   return e;
/*      */                 } 
/*      */               }
/*      */             });
/*      */         
/*  160 */         if (maybeException == null) {
/*  161 */           logger.debug("sun.misc.Unsafe.copyMemory: available");
/*      */         } else {
/*      */           
/*  164 */           unsafe = null;
/*  165 */           unsafeUnavailabilityCause = (Throwable)maybeException;
/*  166 */           if (logger.isTraceEnabled()) {
/*  167 */             logger.debug("sun.misc.Unsafe.copyMemory: unavailable", (Throwable)maybeException);
/*      */           } else {
/*  169 */             logger.debug("sun.misc.Unsafe.copyMemory: unavailable: {}", ((Throwable)maybeException)
/*  170 */                 .getMessage());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  176 */       if (unsafe != null) {
/*  177 */         final Unsafe finalUnsafe = unsafe;
/*  178 */         Object maybeException = AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               public Object run() {
/*      */                 try {
/*  182 */                   finalUnsafe.getClass().getDeclaredMethod("storeFence", new Class[0]);
/*  183 */                   return null;
/*  184 */                 } catch (NoSuchMethodException e) {
/*  185 */                   return e;
/*  186 */                 } catch (SecurityException e) {
/*  187 */                   return e;
/*      */                 } 
/*      */               }
/*      */             });
/*      */         
/*  192 */         if (maybeException == null) {
/*  193 */           logger.debug("sun.misc.Unsafe.storeFence: available");
/*  194 */           storeFenceAvailable = true;
/*      */         } else {
/*  196 */           storeFenceAvailable = false;
/*      */           
/*  198 */           if (logger.isTraceEnabled()) {
/*  199 */             logger.debug("sun.misc.Unsafe.storeFence: unavailable", (Throwable)maybeException);
/*      */           } else {
/*  201 */             logger.debug("sun.misc.Unsafe.storeFence: unavailable: {}", ((Throwable)maybeException)
/*  202 */                 .getMessage());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  207 */       if (unsafe != null) {
/*  208 */         final Unsafe finalUnsafe = unsafe;
/*      */ 
/*      */         
/*  211 */         Object maybeAddressField = AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               public Object run() {
/*      */                 try {
/*  215 */                   Field field = Buffer.class.getDeclaredField("address");
/*      */ 
/*      */                   
/*  218 */                   long offset = finalUnsafe.objectFieldOffset(field);
/*  219 */                   long address = finalUnsafe.getLong(direct, offset);
/*      */ 
/*      */                   
/*  222 */                   if (address == 0L) {
/*  223 */                     return null;
/*      */                   }
/*  225 */                   return field;
/*  226 */                 } catch (NoSuchFieldException e) {
/*  227 */                   return e;
/*  228 */                 } catch (SecurityException e) {
/*  229 */                   return e;
/*      */                 } 
/*      */               }
/*      */             });
/*      */         
/*  234 */         if (maybeAddressField instanceof Field) {
/*  235 */           addressField = (Field)maybeAddressField;
/*  236 */           logger.debug("java.nio.Buffer.address: available");
/*      */         } else {
/*  238 */           unsafeUnavailabilityCause = (Throwable)maybeAddressField;
/*  239 */           if (logger.isTraceEnabled()) {
/*  240 */             logger.debug("java.nio.Buffer.address: unavailable", (Throwable)maybeAddressField);
/*      */           } else {
/*  242 */             logger.debug("java.nio.Buffer.address: unavailable: {}", ((Throwable)maybeAddressField)
/*  243 */                 .getMessage());
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  248 */           unsafe = null;
/*      */         } 
/*      */       } 
/*      */       
/*  252 */       if (unsafe != null) {
/*      */ 
/*      */         
/*  255 */         long byteArrayIndexScale = unsafe.arrayIndexScale(byte[].class);
/*  256 */         if (byteArrayIndexScale != 1L) {
/*  257 */           logger.debug("unsafe.arrayIndexScale is {} (expected: 1). Not using unsafe.", Long.valueOf(byteArrayIndexScale));
/*  258 */           unsafeUnavailabilityCause = new UnsupportedOperationException("Unexpected unsafe.arrayIndexScale");
/*  259 */           unsafe = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*  263 */     UNSAFE_UNAVAILABILITY_CAUSE = unsafeUnavailabilityCause;
/*  264 */     UNSAFE = unsafe;
/*      */     
/*  266 */     if (unsafe == null) {
/*  267 */       ADDRESS_FIELD_OFFSET = -1L;
/*  268 */       BYTE_ARRAY_BASE_OFFSET = -1L;
/*  269 */       LONG_ARRAY_BASE_OFFSET = -1L;
/*  270 */       LONG_ARRAY_INDEX_SCALE = -1L;
/*  271 */       INT_ARRAY_BASE_OFFSET = -1L;
/*  272 */       INT_ARRAY_INDEX_SCALE = -1L;
/*  273 */       UNALIGNED = false;
/*  274 */       DIRECT_BUFFER_CONSTRUCTOR = null;
/*  275 */       ALLOCATE_ARRAY_METHOD = null;
/*  276 */       STORE_FENCE_AVAILABLE = false;
/*      */     } else {
/*      */       Constructor<?> directBufferConstructor; boolean unaligned;
/*  279 */       long address = -1L;
/*      */       
/*      */       try {
/*  282 */         Object maybeDirectBufferConstructor = AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               
/*      */               public Object run()
/*      */               {
/*      */                 try {
/*  288 */                   Constructor<?> constructor = (PlatformDependent0.javaVersion() >= 21) ? direct.getClass().getDeclaredConstructor(new Class[] { long.class, long.class }) : direct.getClass().getDeclaredConstructor(new Class[] { long.class, int.class });
/*  289 */                   Throwable cause = ReflectionUtil.trySetAccessible(constructor, true);
/*  290 */                   if (cause != null) {
/*  291 */                     return cause;
/*      */                   }
/*  293 */                   return constructor;
/*  294 */                 } catch (NoSuchMethodException e) {
/*  295 */                   return e;
/*  296 */                 } catch (SecurityException e) {
/*  297 */                   return e;
/*      */                 } 
/*      */               }
/*      */             });
/*      */         
/*  302 */         if (maybeDirectBufferConstructor instanceof Constructor) {
/*  303 */           address = UNSAFE.allocateMemory(1L);
/*      */           
/*      */           try {
/*  306 */             ((Constructor)maybeDirectBufferConstructor).newInstance(new Object[] { Long.valueOf(address), Integer.valueOf(1) });
/*  307 */             directBufferConstructor = (Constructor)maybeDirectBufferConstructor;
/*  308 */             logger.debug("direct buffer constructor: available");
/*  309 */           } catch (InstantiationException e) {
/*  310 */             directBufferConstructor = null;
/*  311 */           } catch (IllegalAccessException e) {
/*  312 */             directBufferConstructor = null;
/*  313 */           } catch (InvocationTargetException e) {
/*  314 */             directBufferConstructor = null;
/*      */           } 
/*      */         } else {
/*  317 */           if (logger.isTraceEnabled()) {
/*  318 */             logger.debug("direct buffer constructor: unavailable", (Throwable)maybeDirectBufferConstructor);
/*      */           } else {
/*      */             
/*  321 */             logger.debug("direct buffer constructor: unavailable: {}", ((Throwable)maybeDirectBufferConstructor)
/*  322 */                 .getMessage());
/*      */           } 
/*  324 */           directBufferConstructor = null;
/*      */         } 
/*      */       } finally {
/*  327 */         if (address != -1L) {
/*  328 */           UNSAFE.freeMemory(address);
/*      */         }
/*      */       } 
/*  331 */       DIRECT_BUFFER_CONSTRUCTOR = directBufferConstructor;
/*  332 */       ADDRESS_FIELD_OFFSET = objectFieldOffset(addressField);
/*  333 */       BYTE_ARRAY_BASE_OFFSET = UNSAFE.arrayBaseOffset(byte[].class);
/*  334 */       INT_ARRAY_BASE_OFFSET = UNSAFE.arrayBaseOffset(int[].class);
/*  335 */       INT_ARRAY_INDEX_SCALE = UNSAFE.arrayIndexScale(int[].class);
/*  336 */       LONG_ARRAY_BASE_OFFSET = UNSAFE.arrayBaseOffset(long[].class);
/*  337 */       LONG_ARRAY_INDEX_SCALE = UNSAFE.arrayIndexScale(long[].class);
/*      */       
/*  339 */       Object maybeUnaligned = AccessController.doPrivileged(new PrivilegedAction()
/*      */           {
/*      */             public Object run()
/*      */             {
/*      */               try {
/*  344 */                 Class<?> bitsClass = Class.forName("java.nio.Bits", false, PlatformDependent0.getSystemClassLoader());
/*  345 */                 int version = PlatformDependent0.javaVersion();
/*  346 */                 if (PlatformDependent0.unsafeStaticFieldOffsetSupported() && version >= 9) {
/*      */                   
/*  348 */                   String fieldName = (version >= 11) ? "UNALIGNED" : "unaligned";
/*      */ 
/*      */                   
/*      */                   try {
/*  352 */                     Field unalignedField = bitsClass.getDeclaredField(fieldName);
/*  353 */                     if (unalignedField.getType() == boolean.class) {
/*  354 */                       long offset = PlatformDependent0.UNSAFE.staticFieldOffset(unalignedField);
/*  355 */                       Object object = PlatformDependent0.UNSAFE.staticFieldBase(unalignedField);
/*  356 */                       return Boolean.valueOf(PlatformDependent0.UNSAFE.getBoolean(object, offset));
/*      */                     }
/*      */                   
/*      */                   }
/*  360 */                   catch (NoSuchFieldException noSuchFieldException) {}
/*      */                 } 
/*      */ 
/*      */                 
/*  364 */                 Method unalignedMethod = bitsClass.getDeclaredMethod("unaligned", new Class[0]);
/*  365 */                 Throwable cause = ReflectionUtil.trySetAccessible(unalignedMethod, true);
/*  366 */                 if (cause != null) {
/*  367 */                   return cause;
/*      */                 }
/*  369 */                 return unalignedMethod.invoke(null, new Object[0]);
/*  370 */               } catch (NoSuchMethodException e) {
/*  371 */                 return e;
/*  372 */               } catch (SecurityException e) {
/*  373 */                 return e;
/*  374 */               } catch (IllegalAccessException e) {
/*  375 */                 return e;
/*  376 */               } catch (ClassNotFoundException e) {
/*  377 */                 return e;
/*  378 */               } catch (InvocationTargetException e) {
/*  379 */                 return e;
/*      */               } 
/*      */             }
/*      */           });
/*      */       
/*  384 */       if (maybeUnaligned instanceof Boolean) {
/*  385 */         unaligned = ((Boolean)maybeUnaligned).booleanValue();
/*  386 */         logger.debug("java.nio.Bits.unaligned: available, {}", Boolean.valueOf(unaligned));
/*      */       } else {
/*  388 */         String arch = SystemPropertyUtil.get("os.arch", "");
/*      */         
/*  390 */         unaligned = arch.matches("^(i[3-6]86|x86(_64)?|x64|amd64)$");
/*  391 */         Throwable t = (Throwable)maybeUnaligned;
/*  392 */         if (logger.isTraceEnabled()) {
/*  393 */           logger.debug("java.nio.Bits.unaligned: unavailable, {}", Boolean.valueOf(unaligned), t);
/*      */         } else {
/*  395 */           logger.debug("java.nio.Bits.unaligned: unavailable, {}, {}", Boolean.valueOf(unaligned), t.getMessage());
/*      */         } 
/*      */       } 
/*      */       
/*  399 */       UNALIGNED = unaligned;
/*      */       
/*  401 */       if (javaVersion() >= 9) {
/*  402 */         Object maybeException = AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */ 
/*      */               
/*      */               public Object run()
/*      */               {
/*      */                 try {
/*  409 */                   Class<?> internalUnsafeClass = PlatformDependent0.getClassLoader(PlatformDependent0.class).loadClass("jdk.internal.misc.Unsafe");
/*  410 */                   Method method = internalUnsafeClass.getDeclaredMethod("getUnsafe", new Class[0]);
/*  411 */                   return method.invoke(null, new Object[0]);
/*  412 */                 } catch (Throwable e) {
/*  413 */                   return e;
/*      */                 } 
/*      */               }
/*      */             });
/*  417 */         if (!(maybeException instanceof Throwable)) {
/*  418 */           internalUnsafe = maybeException;
/*  419 */           final Object finalInternalUnsafe = internalUnsafe;
/*  420 */           maybeException = AccessController.doPrivileged(new PrivilegedAction()
/*      */               {
/*      */                 public Object run() {
/*      */                   try {
/*  424 */                     return finalInternalUnsafe.getClass().getDeclaredMethod("allocateUninitializedArray", new Class[] { Class.class, int.class });
/*      */                   }
/*  426 */                   catch (NoSuchMethodException e) {
/*  427 */                     return e;
/*  428 */                   } catch (SecurityException e) {
/*  429 */                     return e;
/*      */                   } 
/*      */                 }
/*      */               });
/*      */           
/*  434 */           if (maybeException instanceof Method) {
/*      */             try {
/*  436 */               Method m = (Method)maybeException;
/*  437 */               byte[] bytes = (byte[])m.invoke(finalInternalUnsafe, new Object[] { byte.class, Integer.valueOf(8) });
/*  438 */               assert bytes.length == 8;
/*  439 */               allocateArrayMethod = m;
/*  440 */             } catch (IllegalAccessException e) {
/*  441 */               maybeException = e;
/*  442 */             } catch (InvocationTargetException e) {
/*  443 */               maybeException = e;
/*      */             } 
/*      */           }
/*      */         } 
/*      */         
/*  448 */         if (maybeException instanceof Throwable) {
/*  449 */           if (logger.isTraceEnabled()) {
/*  450 */             logger.debug("jdk.internal.misc.Unsafe.allocateUninitializedArray(int): unavailable", (Throwable)maybeException);
/*      */           } else {
/*      */             
/*  453 */             logger.debug("jdk.internal.misc.Unsafe.allocateUninitializedArray(int): unavailable: {}", ((Throwable)maybeException)
/*  454 */                 .getMessage());
/*      */           } 
/*      */         } else {
/*  457 */           logger.debug("jdk.internal.misc.Unsafe.allocateUninitializedArray(int): available");
/*      */         } 
/*      */       } else {
/*  460 */         logger.debug("jdk.internal.misc.Unsafe.allocateUninitializedArray(int): unavailable prior to Java9");
/*      */       } 
/*  462 */       ALLOCATE_ARRAY_METHOD = allocateArrayMethod;
/*  463 */       STORE_FENCE_AVAILABLE = storeFenceAvailable;
/*      */     } 
/*      */     
/*  466 */     if (javaVersion() > 9) {
/*  467 */       ALIGN_SLICE = AccessController.<Method>doPrivileged(new PrivilegedAction()
/*      */           {
/*      */             public Object run() {
/*      */               try {
/*  471 */                 return ByteBuffer.class.getDeclaredMethod("alignedSlice", new Class[] { int.class });
/*  472 */               } catch (Exception e) {
/*  473 */                 return null;
/*      */               } 
/*      */             }
/*      */           });
/*      */     } else {
/*  478 */       ALIGN_SLICE = null;
/*      */     } 
/*      */     
/*  481 */     INTERNAL_UNSAFE = internalUnsafe;
/*      */     
/*  483 */     logger.debug("java.nio.DirectByteBuffer.<init>(long, {int,long}): {}", (DIRECT_BUFFER_CONSTRUCTOR != null) ? "available" : "unavailable");
/*      */   } private static final boolean IS_ANDROID; private static final boolean STORE_FENCE_AVAILABLE; private static final Throwable UNSAFE_UNAVAILABILITY_CAUSE; private static final Object INTERNAL_UNSAFE; private static final boolean RUNNING_IN_NATIVE_IMAGE; private static final boolean IS_EXPLICIT_TRY_REFLECTION_SET_ACCESSIBLE; static final Unsafe UNSAFE; static final int HASH_CODE_ASCII_SEED = -1028477387; static final int HASH_CODE_C1 = -862048943; static final int HASH_CODE_C2 = 461845907; private static final long UNSAFE_COPY_THRESHOLD = 1048576L; private static final boolean UNALIGNED; static {
/*      */     final ByteBuffer direct;
/*      */     Unsafe unsafe;
/*      */   } private static boolean unsafeStaticFieldOffsetSupported() {
/*  488 */     return !RUNNING_IN_NATIVE_IMAGE;
/*      */   }
/*      */   
/*      */   static boolean isExplicitNoUnsafe() {
/*  492 */     return (EXPLICIT_NO_UNSAFE_CAUSE != null);
/*      */   }
/*      */   private static Throwable explicitNoUnsafeCause0() {
/*      */     String unsafePropName;
/*  496 */     boolean noUnsafe = SystemPropertyUtil.getBoolean("io.netty.noUnsafe", false);
/*  497 */     logger.debug("-Dio.netty.noUnsafe: {}", Boolean.valueOf(noUnsafe));
/*      */     
/*  499 */     if (noUnsafe) {
/*  500 */       logger.debug("sun.misc.Unsafe: unavailable (io.netty.noUnsafe)");
/*  501 */       return new UnsupportedOperationException("sun.misc.Unsafe: unavailable (io.netty.noUnsafe)");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  506 */     if (SystemPropertyUtil.contains("io.netty.tryUnsafe")) {
/*  507 */       unsafePropName = "io.netty.tryUnsafe";
/*      */     } else {
/*  509 */       unsafePropName = "org.jboss.netty.tryUnsafe";
/*      */     } 
/*      */     
/*  512 */     if (!SystemPropertyUtil.getBoolean(unsafePropName, true)) {
/*  513 */       String msg = "sun.misc.Unsafe: unavailable (" + unsafePropName + ")";
/*  514 */       logger.debug(msg);
/*  515 */       return new UnsupportedOperationException(msg);
/*      */     } 
/*      */     
/*  518 */     return null;
/*      */   }
/*      */   
/*      */   static boolean isUnaligned() {
/*  522 */     return UNALIGNED;
/*      */   }
/*      */   
/*      */   static boolean hasUnsafe() {
/*  526 */     return (UNSAFE != null);
/*      */   }
/*      */   
/*      */   static Throwable getUnsafeUnavailabilityCause() {
/*  530 */     return UNSAFE_UNAVAILABILITY_CAUSE;
/*      */   }
/*      */   
/*      */   static boolean unalignedAccess() {
/*  534 */     return UNALIGNED;
/*      */   }
/*      */ 
/*      */   
/*      */   static void throwException(Throwable cause) {
/*  539 */     UNSAFE.throwException(ObjectUtil.<Throwable>checkNotNull(cause, "cause"));
/*      */   }
/*      */   
/*      */   static boolean hasDirectBufferNoCleanerConstructor() {
/*  543 */     return (DIRECT_BUFFER_CONSTRUCTOR != null);
/*      */   }
/*      */   
/*      */   static ByteBuffer reallocateDirectNoCleaner(ByteBuffer buffer, int capacity) {
/*  547 */     return newDirectBuffer(UNSAFE.reallocateMemory(directBufferAddress(buffer), capacity), capacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static ByteBuffer allocateDirectNoCleaner(int capacity) {
/*  554 */     return newDirectBuffer(UNSAFE.allocateMemory(Math.max(1, capacity)), capacity);
/*      */   }
/*      */   
/*      */   static boolean hasAlignSliceMethod() {
/*  558 */     return (ALIGN_SLICE != null);
/*      */   }
/*      */   
/*      */   static ByteBuffer alignSlice(ByteBuffer buffer, int alignment) {
/*      */     try {
/*  563 */       return (ByteBuffer)ALIGN_SLICE.invoke(buffer, new Object[] { Integer.valueOf(alignment) });
/*  564 */     } catch (IllegalAccessException e) {
/*  565 */       throw new Error(e);
/*  566 */     } catch (InvocationTargetException e) {
/*  567 */       throw new Error(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   static boolean hasAllocateArrayMethod() {
/*  572 */     return (ALLOCATE_ARRAY_METHOD != null);
/*      */   }
/*      */   
/*      */   static byte[] allocateUninitializedArray(int size) {
/*      */     try {
/*  577 */       return (byte[])ALLOCATE_ARRAY_METHOD.invoke(INTERNAL_UNSAFE, new Object[] { byte.class, Integer.valueOf(size) });
/*  578 */     } catch (IllegalAccessException e) {
/*  579 */       throw new Error(e);
/*  580 */     } catch (InvocationTargetException e) {
/*  581 */       throw new Error(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   static ByteBuffer newDirectBuffer(long address, int capacity) {
/*  586 */     ObjectUtil.checkPositiveOrZero(capacity, "capacity");
/*      */     
/*      */     try {
/*  589 */       return (ByteBuffer)DIRECT_BUFFER_CONSTRUCTOR.newInstance(new Object[] { Long.valueOf(address), Integer.valueOf(capacity) });
/*  590 */     } catch (Throwable cause) {
/*      */       
/*  592 */       if (cause instanceof Error) {
/*  593 */         throw (Error)cause;
/*      */       }
/*  595 */       throw new Error(cause);
/*      */     } 
/*      */   }
/*      */   
/*      */   static long directBufferAddress(ByteBuffer buffer) {
/*  600 */     return getLong(buffer, ADDRESS_FIELD_OFFSET);
/*      */   }
/*      */   
/*      */   static long byteArrayBaseOffset() {
/*  604 */     return BYTE_ARRAY_BASE_OFFSET;
/*      */   }
/*      */   
/*      */   static Object getObject(Object object, long fieldOffset) {
/*  608 */     return UNSAFE.getObject(object, fieldOffset);
/*      */   }
/*      */   
/*      */   static int getInt(Object object, long fieldOffset) {
/*  612 */     return UNSAFE.getInt(object, fieldOffset);
/*      */   }
/*      */   
/*      */   static void safeConstructPutInt(Object object, long fieldOffset, int value) {
/*  616 */     if (STORE_FENCE_AVAILABLE) {
/*  617 */       UNSAFE.putInt(object, fieldOffset, value);
/*  618 */       UNSAFE.storeFence();
/*      */     } else {
/*  620 */       UNSAFE.putIntVolatile(object, fieldOffset, value);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static long getLong(Object object, long fieldOffset) {
/*  625 */     return UNSAFE.getLong(object, fieldOffset);
/*      */   }
/*      */   
/*      */   static long objectFieldOffset(Field field) {
/*  629 */     return UNSAFE.objectFieldOffset(field);
/*      */   }
/*      */   
/*      */   static byte getByte(long address) {
/*  633 */     return UNSAFE.getByte(address);
/*      */   }
/*      */   
/*      */   static short getShort(long address) {
/*  637 */     return UNSAFE.getShort(address);
/*      */   }
/*      */   
/*      */   static int getInt(long address) {
/*  641 */     return UNSAFE.getInt(address);
/*      */   }
/*      */   
/*      */   static long getLong(long address) {
/*  645 */     return UNSAFE.getLong(address);
/*      */   }
/*      */   
/*      */   static byte getByte(byte[] data, int index) {
/*  649 */     return UNSAFE.getByte(data, BYTE_ARRAY_BASE_OFFSET + index);
/*      */   }
/*      */   
/*      */   static byte getByte(byte[] data, long index) {
/*  653 */     return UNSAFE.getByte(data, BYTE_ARRAY_BASE_OFFSET + index);
/*      */   }
/*      */   
/*      */   static short getShort(byte[] data, int index) {
/*  657 */     return UNSAFE.getShort(data, BYTE_ARRAY_BASE_OFFSET + index);
/*      */   }
/*      */   
/*      */   static int getInt(byte[] data, int index) {
/*  661 */     return UNSAFE.getInt(data, BYTE_ARRAY_BASE_OFFSET + index);
/*      */   }
/*      */   
/*      */   static int getInt(int[] data, long index) {
/*  665 */     return UNSAFE.getInt(data, INT_ARRAY_BASE_OFFSET + INT_ARRAY_INDEX_SCALE * index);
/*      */   }
/*      */   
/*      */   static int getIntVolatile(long address) {
/*  669 */     return UNSAFE.getIntVolatile(null, address);
/*      */   }
/*      */   
/*      */   static void putIntOrdered(long adddress, int newValue) {
/*  673 */     UNSAFE.putOrderedInt(null, adddress, newValue);
/*      */   }
/*      */   
/*      */   static long getLong(byte[] data, int index) {
/*  677 */     return UNSAFE.getLong(data, BYTE_ARRAY_BASE_OFFSET + index);
/*      */   }
/*      */   
/*      */   static long getLong(long[] data, long index) {
/*  681 */     return UNSAFE.getLong(data, LONG_ARRAY_BASE_OFFSET + LONG_ARRAY_INDEX_SCALE * index);
/*      */   }
/*      */   
/*      */   static void putByte(long address, byte value) {
/*  685 */     UNSAFE.putByte(address, value);
/*      */   }
/*      */   
/*      */   static void putShort(long address, short value) {
/*  689 */     UNSAFE.putShort(address, value);
/*      */   }
/*      */   
/*      */   static void putInt(long address, int value) {
/*  693 */     UNSAFE.putInt(address, value);
/*      */   }
/*      */   
/*      */   static void putLong(long address, long value) {
/*  697 */     UNSAFE.putLong(address, value);
/*      */   }
/*      */   
/*      */   static void putByte(byte[] data, int index, byte value) {
/*  701 */     UNSAFE.putByte(data, BYTE_ARRAY_BASE_OFFSET + index, value);
/*      */   }
/*      */   
/*      */   static void putByte(Object data, long offset, byte value) {
/*  705 */     UNSAFE.putByte(data, offset, value);
/*      */   }
/*      */   
/*      */   static void putShort(byte[] data, int index, short value) {
/*  709 */     UNSAFE.putShort(data, BYTE_ARRAY_BASE_OFFSET + index, value);
/*      */   }
/*      */   
/*      */   static void putInt(byte[] data, int index, int value) {
/*  713 */     UNSAFE.putInt(data, BYTE_ARRAY_BASE_OFFSET + index, value);
/*      */   }
/*      */   
/*      */   static void putLong(byte[] data, int index, long value) {
/*  717 */     UNSAFE.putLong(data, BYTE_ARRAY_BASE_OFFSET + index, value);
/*      */   }
/*      */   
/*      */   static void putObject(Object o, long offset, Object x) {
/*  721 */     UNSAFE.putObject(o, offset, x);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void copyMemory(long srcAddr, long dstAddr, long length) {
/*  727 */     if (javaVersion() <= 8) {
/*  728 */       copyMemoryWithSafePointPolling(srcAddr, dstAddr, length);
/*      */     } else {
/*  730 */       UNSAFE.copyMemory(srcAddr, dstAddr, length);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void copyMemoryWithSafePointPolling(long srcAddr, long dstAddr, long length) {
/*  735 */     while (length > 0L) {
/*  736 */       long size = Math.min(length, 1048576L);
/*  737 */       UNSAFE.copyMemory(srcAddr, dstAddr, size);
/*  738 */       length -= size;
/*  739 */       srcAddr += size;
/*  740 */       dstAddr += size;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void copyMemory(Object src, long srcOffset, Object dst, long dstOffset, long length) {
/*  747 */     if (javaVersion() <= 8) {
/*  748 */       copyMemoryWithSafePointPolling(src, srcOffset, dst, dstOffset, length);
/*      */     } else {
/*  750 */       UNSAFE.copyMemory(src, srcOffset, dst, dstOffset, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void copyMemoryWithSafePointPolling(Object src, long srcOffset, Object dst, long dstOffset, long length) {
/*  756 */     while (length > 0L) {
/*  757 */       long size = Math.min(length, 1048576L);
/*  758 */       UNSAFE.copyMemory(src, srcOffset, dst, dstOffset, size);
/*  759 */       length -= size;
/*  760 */       srcOffset += size;
/*  761 */       dstOffset += size;
/*      */     } 
/*      */   }
/*      */   
/*      */   static void setMemory(long address, long bytes, byte value) {
/*  766 */     UNSAFE.setMemory(address, bytes, value);
/*      */   }
/*      */   
/*      */   static void setMemory(Object o, long offset, long bytes, byte value) {
/*  770 */     UNSAFE.setMemory(o, offset, bytes, value);
/*      */   }
/*      */   
/*      */   static boolean equals(byte[] bytes1, int startPos1, byte[] bytes2, int startPos2, int length) {
/*  774 */     int remainingBytes = length & 0x7;
/*  775 */     long baseOffset1 = BYTE_ARRAY_BASE_OFFSET + startPos1;
/*  776 */     long diff = (startPos2 - startPos1);
/*  777 */     if (length >= 8) {
/*  778 */       long end = baseOffset1 + remainingBytes; long i;
/*  779 */       for (i = baseOffset1 - 8L + length; i >= end; i -= 8L) {
/*  780 */         if (UNSAFE.getLong(bytes1, i) != UNSAFE.getLong(bytes2, i + diff)) {
/*  781 */           return false;
/*      */         }
/*      */       } 
/*      */     } 
/*  785 */     if (remainingBytes >= 4) {
/*  786 */       remainingBytes -= 4;
/*  787 */       long pos = baseOffset1 + remainingBytes;
/*  788 */       if (UNSAFE.getInt(bytes1, pos) != UNSAFE.getInt(bytes2, pos + diff)) {
/*  789 */         return false;
/*      */       }
/*      */     } 
/*  792 */     long baseOffset2 = baseOffset1 + diff;
/*  793 */     if (remainingBytes >= 2) {
/*  794 */       return (UNSAFE.getChar(bytes1, baseOffset1) == UNSAFE.getChar(bytes2, baseOffset2) && (remainingBytes == 2 || UNSAFE
/*      */         
/*  796 */         .getByte(bytes1, baseOffset1 + 2L) == UNSAFE.getByte(bytes2, baseOffset2 + 2L)));
/*      */     }
/*  798 */     return (remainingBytes == 0 || UNSAFE
/*  799 */       .getByte(bytes1, baseOffset1) == UNSAFE.getByte(bytes2, baseOffset2));
/*      */   }
/*      */   
/*      */   static int equalsConstantTime(byte[] bytes1, int startPos1, byte[] bytes2, int startPos2, int length) {
/*  803 */     long result = 0L;
/*  804 */     long remainingBytes = (length & 0x7);
/*  805 */     long baseOffset1 = BYTE_ARRAY_BASE_OFFSET + startPos1;
/*  806 */     long end = baseOffset1 + remainingBytes;
/*  807 */     long diff = (startPos2 - startPos1); long i;
/*  808 */     for (i = baseOffset1 - 8L + length; i >= end; i -= 8L) {
/*  809 */       result |= UNSAFE.getLong(bytes1, i) ^ UNSAFE.getLong(bytes2, i + diff);
/*      */     }
/*  811 */     if (remainingBytes >= 4L) {
/*  812 */       result |= (UNSAFE.getInt(bytes1, baseOffset1) ^ UNSAFE.getInt(bytes2, baseOffset1 + diff));
/*  813 */       remainingBytes -= 4L;
/*      */     } 
/*  815 */     if (remainingBytes >= 2L) {
/*  816 */       long pos = end - remainingBytes;
/*  817 */       result |= (UNSAFE.getChar(bytes1, pos) ^ UNSAFE.getChar(bytes2, pos + diff));
/*  818 */       remainingBytes -= 2L;
/*      */     } 
/*  820 */     if (remainingBytes == 1L) {
/*  821 */       long pos = end - 1L;
/*  822 */       result |= (UNSAFE.getByte(bytes1, pos) ^ UNSAFE.getByte(bytes2, pos + diff));
/*      */     } 
/*  824 */     return ConstantTimeUtils.equalsConstantTime(result, 0L);
/*      */   }
/*      */   
/*      */   static boolean isZero(byte[] bytes, int startPos, int length) {
/*  828 */     if (length <= 0) {
/*  829 */       return true;
/*      */     }
/*  831 */     long baseOffset = BYTE_ARRAY_BASE_OFFSET + startPos;
/*  832 */     int remainingBytes = length & 0x7;
/*  833 */     long end = baseOffset + remainingBytes; long i;
/*  834 */     for (i = baseOffset - 8L + length; i >= end; i -= 8L) {
/*  835 */       if (UNSAFE.getLong(bytes, i) != 0L) {
/*  836 */         return false;
/*      */       }
/*      */     } 
/*      */     
/*  840 */     if (remainingBytes >= 4) {
/*  841 */       remainingBytes -= 4;
/*  842 */       if (UNSAFE.getInt(bytes, baseOffset + remainingBytes) != 0) {
/*  843 */         return false;
/*      */       }
/*      */     } 
/*  846 */     if (remainingBytes >= 2) {
/*  847 */       return (UNSAFE.getChar(bytes, baseOffset) == '\000' && (remainingBytes == 2 || bytes[startPos + 2] == 0));
/*      */     }
/*      */     
/*  850 */     return (bytes[startPos] == 0);
/*      */   }
/*      */   
/*      */   static int hashCodeAscii(byte[] bytes, int startPos, int length) {
/*  854 */     int hash = -1028477387;
/*  855 */     long baseOffset = BYTE_ARRAY_BASE_OFFSET + startPos;
/*  856 */     int remainingBytes = length & 0x7;
/*  857 */     long end = baseOffset + remainingBytes; long i;
/*  858 */     for (i = baseOffset - 8L + length; i >= end; i -= 8L) {
/*  859 */       hash = hashCodeAsciiCompute(UNSAFE.getLong(bytes, i), hash);
/*      */     }
/*  861 */     if (remainingBytes == 0) {
/*  862 */       return hash;
/*      */     }
/*  864 */     int hcConst = -862048943;
/*  865 */     if ((((remainingBytes != 2) ? 1 : 0) & ((remainingBytes != 4) ? 1 : 0) & ((remainingBytes != 6) ? 1 : 0)) != 0) {
/*  866 */       hash = hash * -862048943 + hashCodeAsciiSanitize(UNSAFE.getByte(bytes, baseOffset));
/*  867 */       hcConst = 461845907;
/*  868 */       baseOffset++;
/*      */     } 
/*  870 */     if ((((remainingBytes != 1) ? 1 : 0) & ((remainingBytes != 4) ? 1 : 0) & ((remainingBytes != 5) ? 1 : 0)) != 0) {
/*  871 */       hash = hash * hcConst + hashCodeAsciiSanitize(UNSAFE.getShort(bytes, baseOffset));
/*  872 */       hcConst = (hcConst == -862048943) ? 461845907 : -862048943;
/*  873 */       baseOffset += 2L;
/*      */     } 
/*  875 */     if (remainingBytes >= 4) {
/*  876 */       return hash * hcConst + hashCodeAsciiSanitize(UNSAFE.getInt(bytes, baseOffset));
/*      */     }
/*  878 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static int hashCodeAsciiCompute(long value, int hash) {
/*  884 */     return hash * -862048943 + 
/*      */       
/*  886 */       hashCodeAsciiSanitize((int)value) * 461845907 + (int)((value & 0x1F1F1F1F00000000L) >>> 32L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static int hashCodeAsciiSanitize(int value) {
/*  892 */     return value & 0x1F1F1F1F;
/*      */   }
/*      */   
/*      */   static int hashCodeAsciiSanitize(short value) {
/*  896 */     return value & 0x1F1F;
/*      */   }
/*      */   
/*      */   static int hashCodeAsciiSanitize(byte value) {
/*  900 */     return value & 0x1F;
/*      */   }
/*      */   
/*      */   static ClassLoader getClassLoader(final Class<?> clazz) {
/*  904 */     if (System.getSecurityManager() == null) {
/*  905 */       return clazz.getClassLoader();
/*      */     }
/*  907 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*      */         {
/*      */           public ClassLoader run() {
/*  910 */             return clazz.getClassLoader();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   static ClassLoader getContextClassLoader() {
/*  917 */     if (System.getSecurityManager() == null) {
/*  918 */       return Thread.currentThread().getContextClassLoader();
/*      */     }
/*  920 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*      */         {
/*      */           public ClassLoader run() {
/*  923 */             return Thread.currentThread().getContextClassLoader();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   static ClassLoader getSystemClassLoader() {
/*  930 */     if (System.getSecurityManager() == null) {
/*  931 */       return ClassLoader.getSystemClassLoader();
/*      */     }
/*  933 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*      */         {
/*      */           public ClassLoader run() {
/*  936 */             return ClassLoader.getSystemClassLoader();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   static int addressSize() {
/*  943 */     return UNSAFE.addressSize();
/*      */   }
/*      */   
/*      */   static long allocateMemory(long size) {
/*  947 */     return UNSAFE.allocateMemory(size);
/*      */   }
/*      */   
/*      */   static void freeMemory(long address) {
/*  951 */     UNSAFE.freeMemory(address);
/*      */   }
/*      */   
/*      */   static long reallocateMemory(long address, long newSize) {
/*  955 */     return UNSAFE.reallocateMemory(address, newSize);
/*      */   }
/*      */   
/*      */   static boolean isAndroid() {
/*  959 */     return IS_ANDROID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isAndroid0() {
/*  970 */     String vmName = SystemPropertyUtil.get("java.vm.name");
/*  971 */     boolean isAndroid = "Dalvik".equals(vmName);
/*  972 */     if (isAndroid) {
/*  973 */       logger.debug("Platform: Android");
/*      */     }
/*  975 */     return isAndroid;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean explicitTryReflectionSetAccessible0() {
/*  980 */     return SystemPropertyUtil.getBoolean("io.netty.tryReflectionSetAccessible", (
/*  981 */         javaVersion() < 9 || RUNNING_IN_NATIVE_IMAGE));
/*      */   }
/*      */   
/*      */   static boolean isExplicitTryReflectionSetAccessible() {
/*  985 */     return IS_EXPLICIT_TRY_REFLECTION_SET_ACCESSIBLE;
/*      */   }
/*      */   
/*      */   static int javaVersion() {
/*  989 */     return JAVA_VERSION;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int javaVersion0() {
/*      */     int majorVersion;
/*  995 */     if (isAndroid0()) {
/*  996 */       majorVersion = 6;
/*      */     } else {
/*  998 */       majorVersion = majorVersionFromJavaSpecificationVersion();
/*      */     } 
/*      */     
/* 1001 */     logger.debug("Java version: {}", Integer.valueOf(majorVersion));
/*      */     
/* 1003 */     return majorVersion;
/*      */   }
/*      */ 
/*      */   
/*      */   static int majorVersionFromJavaSpecificationVersion() {
/* 1008 */     return majorVersion(SystemPropertyUtil.get("java.specification.version", "1.6"));
/*      */   }
/*      */ 
/*      */   
/*      */   static int majorVersion(String javaSpecVersion) {
/* 1013 */     String[] components = javaSpecVersion.split("\\.");
/* 1014 */     int[] version = new int[components.length];
/* 1015 */     for (int i = 0; i < components.length; i++) {
/* 1016 */       version[i] = Integer.parseInt(components[i]);
/*      */     }
/*      */     
/* 1019 */     if (version[0] == 1) {
/* 1020 */       assert version[1] >= 6;
/* 1021 */       return version[1];
/*      */     } 
/* 1023 */     return version[0];
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\PlatformDependent0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */