/*    */ package io.netty.util.internal;
/*    */ 
/*    */ import io.netty.util.Recycler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ObjectPool<T>
/*    */ {
/*    */   public abstract T get();
/*    */   
/*    */   public static <T> ObjectPool<T> newPool(ObjectCreator<T> creator) {
/* 69 */     return new RecyclerObjectPool<T>(ObjectUtil.<ObjectCreator<T>>checkNotNull(creator, "creator"));
/*    */   }
/*    */ 
/*    */   
/*    */   private static final class RecyclerObjectPool<T>
/*    */     extends ObjectPool<T>
/*    */   {
/* 76 */     private final Recycler<T> recycler = new Recycler<T>()
/*    */       {
/*    */         protected T newObject(Recycler.Handle<T> handle) {
/* 79 */           return creator.newObject((ObjectPool.Handle<T>)handle);
/*    */         }
/*    */       };
/*    */     
/*    */     RecyclerObjectPool(final ObjectPool.ObjectCreator<T> creator) {}
/*    */     
/*    */     public T get() {
/* 86 */       return (T)this.recycler.get();
/*    */     }
/*    */   }
/*    */   
/*    */   public static interface ObjectCreator<T> {
/*    */     T newObject(ObjectPool.Handle<T> param1Handle);
/*    */   }
/*    */   
/*    */   public static interface Handle<T> {
/*    */     void recycle(T param1T);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\ObjectPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */