/*     */ package io.netty.util.internal.shaded.org.jctools.queues.atomic;
/*     */ 
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueue;
/*     */ import io.netty.util.internal.shaded.org.jctools.queues.MessagePassingQueueUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpscLinkedAtomicQueue<E>
/*     */   extends BaseLinkedAtomicQueue<E>
/*     */ {
/*     */   public SpscLinkedAtomicQueue() {
/*  47 */     LinkedQueueAtomicNode<E> node = newNode();
/*  48 */     spProducerNode(node);
/*  49 */     spConsumerNode(node);
/*     */     
/*  51 */     node.soNext(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean offer(E e) {
/*  71 */     if (null == e) {
/*  72 */       throw new NullPointerException();
/*     */     }
/*  74 */     LinkedQueueAtomicNode<E> nextNode = newNode(e);
/*  75 */     LinkedQueueAtomicNode<E> oldNode = lpProducerNode();
/*  76 */     soProducerNode(nextNode);
/*     */ 
/*     */ 
/*     */     
/*  80 */     oldNode.soNext(nextNode);
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int fill(MessagePassingQueue.Supplier<E> s) {
/*  86 */     return MessagePassingQueueUtil.fillUnbounded(this, s);
/*     */   }
/*     */ 
/*     */   
/*     */   public int fill(MessagePassingQueue.Supplier<E> s, int limit) {
/*  91 */     if (null == s)
/*  92 */       throw new IllegalArgumentException("supplier is null"); 
/*  93 */     if (limit < 0)
/*  94 */       throw new IllegalArgumentException("limit is negative:" + limit); 
/*  95 */     if (limit == 0)
/*  96 */       return 0; 
/*  97 */     LinkedQueueAtomicNode<E> tail = newNode((E)s.get());
/*  98 */     LinkedQueueAtomicNode<E> head = tail;
/*  99 */     for (int i = 1; i < limit; i++) {
/* 100 */       LinkedQueueAtomicNode<E> temp = newNode((E)s.get());
/*     */       
/* 102 */       tail.spNext(temp);
/* 103 */       tail = temp;
/*     */     } 
/* 105 */     LinkedQueueAtomicNode<E> oldPNode = lpProducerNode();
/* 106 */     soProducerNode(tail);
/*     */     
/* 108 */     oldPNode.soNext(head);
/* 109 */     return limit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void fill(MessagePassingQueue.Supplier<E> s, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
/* 114 */     MessagePassingQueueUtil.fill(this, s, wait, exit);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\shaded\org\jctools\queues\atomic\SpscLinkedAtomicQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */