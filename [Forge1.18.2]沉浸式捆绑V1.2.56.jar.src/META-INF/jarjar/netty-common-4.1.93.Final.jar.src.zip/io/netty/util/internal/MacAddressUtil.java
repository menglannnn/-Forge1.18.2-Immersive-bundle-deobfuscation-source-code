/*     */ package io.netty.util.internal;
/*     */ 
/*     */ import io.netty.util.NetUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MacAddressUtil
/*     */ {
/*  35 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(MacAddressUtil.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int EUI64_MAC_ADDRESS_LENGTH = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int EUI48_MAC_ADDRESS_LENGTH = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] bestAvailableMac() {
/*  49 */     byte[] bestMacAddr = EmptyArrays.EMPTY_BYTES;
/*  50 */     InetAddress bestInetAddr = NetUtil.LOCALHOST4;
/*     */ 
/*     */     
/*  53 */     Map<NetworkInterface, InetAddress> ifaces = new LinkedHashMap<NetworkInterface, InetAddress>();
/*  54 */     for (NetworkInterface iface : NetUtil.NETWORK_INTERFACES) {
/*     */       
/*  56 */       Enumeration<InetAddress> addrs = SocketUtils.addressesFromNetworkInterface(iface);
/*  57 */       if (addrs.hasMoreElements()) {
/*  58 */         InetAddress a = addrs.nextElement();
/*  59 */         if (!a.isLoopbackAddress()) {
/*  60 */           ifaces.put(iface, a);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  65 */     for (Map.Entry<NetworkInterface, InetAddress> entry : ifaces.entrySet()) {
/*  66 */       byte[] macAddr; NetworkInterface iface = entry.getKey();
/*  67 */       InetAddress inetAddr = entry.getValue();
/*  68 */       if (iface.isVirtual()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/*  74 */         macAddr = SocketUtils.hardwareAddressFromNetworkInterface(iface);
/*  75 */       } catch (SocketException e) {
/*  76 */         logger.debug("Failed to get the hardware address of a network interface: {}", iface, e);
/*     */         
/*     */         continue;
/*     */       } 
/*  80 */       boolean replace = false;
/*  81 */       int res = compareAddresses(bestMacAddr, macAddr);
/*  82 */       if (res < 0) {
/*     */         
/*  84 */         replace = true;
/*  85 */       } else if (res == 0) {
/*     */         
/*  87 */         res = compareAddresses(bestInetAddr, inetAddr);
/*  88 */         if (res < 0) {
/*     */           
/*  90 */           replace = true;
/*  91 */         } else if (res == 0) {
/*     */           
/*  93 */           if (bestMacAddr.length < macAddr.length) {
/*  94 */             replace = true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  99 */       if (replace) {
/* 100 */         bestMacAddr = macAddr;
/* 101 */         bestInetAddr = inetAddr;
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     if (bestMacAddr == EmptyArrays.EMPTY_BYTES) {
/* 106 */       return null;
/*     */     }
/*     */     
/* 109 */     if (bestMacAddr.length == 6) {
/* 110 */       byte[] newAddr = new byte[8];
/* 111 */       System.arraycopy(bestMacAddr, 0, newAddr, 0, 3);
/* 112 */       newAddr[3] = -1;
/* 113 */       newAddr[4] = -2;
/* 114 */       System.arraycopy(bestMacAddr, 3, newAddr, 5, 3);
/* 115 */       bestMacAddr = newAddr;
/*     */     } else {
/*     */       
/* 118 */       bestMacAddr = Arrays.copyOf(bestMacAddr, 8);
/*     */     } 
/*     */     
/* 121 */     return bestMacAddr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] defaultMachineId() {
/* 129 */     byte[] bestMacAddr = bestAvailableMac();
/* 130 */     if (bestMacAddr == null) {
/* 131 */       bestMacAddr = new byte[8];
/* 132 */       PlatformDependent.threadLocalRandom().nextBytes(bestMacAddr);
/* 133 */       logger.warn("Failed to find a usable hardware address from the network interfaces; using random bytes: {}", 
/*     */           
/* 135 */           formatAddress(bestMacAddr));
/*     */     } 
/* 137 */     return bestMacAddr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] parseMAC(String value) {
/*     */     byte[] machineId;
/*     */     char separator;
/* 148 */     switch (value.length()) {
/*     */       case 17:
/* 150 */         separator = value.charAt(2);
/* 151 */         validateMacSeparator(separator);
/* 152 */         machineId = new byte[6];
/*     */         break;
/*     */       case 23:
/* 155 */         separator = value.charAt(2);
/* 156 */         validateMacSeparator(separator);
/* 157 */         machineId = new byte[8];
/*     */         break;
/*     */       default:
/* 160 */         throw new IllegalArgumentException("value is not supported [MAC-48, EUI-48, EUI-64]");
/*     */     } 
/*     */     
/* 163 */     int end = machineId.length - 1;
/* 164 */     int j = 0;
/* 165 */     for (int i = 0; i < end; i++, j += 3) {
/* 166 */       int sIndex = j + 2;
/* 167 */       machineId[i] = StringUtil.decodeHexByte(value, j);
/* 168 */       if (value.charAt(sIndex) != separator) {
/* 169 */         throw new IllegalArgumentException("expected separator '" + separator + " but got '" + value
/* 170 */             .charAt(sIndex) + "' at index: " + sIndex);
/*     */       }
/*     */     } 
/*     */     
/* 174 */     machineId[end] = StringUtil.decodeHexByte(value, j);
/*     */     
/* 176 */     return machineId;
/*     */   }
/*     */   
/*     */   private static void validateMacSeparator(char separator) {
/* 180 */     if (separator != ':' && separator != '-') {
/* 181 */       throw new IllegalArgumentException("unsupported separator: " + separator + " (expected: [:-])");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatAddress(byte[] addr) {
/* 190 */     StringBuilder buf = new StringBuilder(24);
/* 191 */     for (byte b : addr) {
/* 192 */       buf.append(String.format("%02x:", new Object[] { Integer.valueOf(b & 0xFF) }));
/*     */     } 
/* 194 */     return buf.substring(0, buf.length() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int compareAddresses(byte[] current, byte[] candidate) {
/* 202 */     if (candidate == null || candidate.length < 6) {
/* 203 */       return 1;
/*     */     }
/*     */ 
/*     */     
/* 207 */     boolean onlyZeroAndOne = true;
/* 208 */     for (byte b : candidate) {
/* 209 */       if (b != 0 && b != 1) {
/* 210 */         onlyZeroAndOne = false;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 215 */     if (onlyZeroAndOne) {
/* 216 */       return 1;
/*     */     }
/*     */ 
/*     */     
/* 220 */     if ((candidate[0] & 0x1) != 0) {
/* 221 */       return 1;
/*     */     }
/*     */ 
/*     */     
/* 225 */     if ((candidate[0] & 0x2) == 0) {
/* 226 */       if (current.length != 0 && (current[0] & 0x2) == 0)
/*     */       {
/* 228 */         return 0;
/*     */       }
/*     */       
/* 231 */       return -1;
/*     */     } 
/*     */     
/* 234 */     if (current.length != 0 && (current[0] & 0x2) == 0)
/*     */     {
/* 236 */       return 1;
/*     */     }
/*     */     
/* 239 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int compareAddresses(InetAddress current, InetAddress candidate) {
/* 248 */     return scoreAddress(current) - scoreAddress(candidate);
/*     */   }
/*     */   
/*     */   private static int scoreAddress(InetAddress addr) {
/* 252 */     if (addr.isAnyLocalAddress() || addr.isLoopbackAddress()) {
/* 253 */       return 0;
/*     */     }
/* 255 */     if (addr.isMulticastAddress()) {
/* 256 */       return 1;
/*     */     }
/* 258 */     if (addr.isLinkLocalAddress()) {
/* 259 */       return 2;
/*     */     }
/* 261 */     if (addr.isSiteLocalAddress()) {
/* 262 */       return 3;
/*     */     }
/*     */     
/* 265 */     return 4;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\internal\MacAddressUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */