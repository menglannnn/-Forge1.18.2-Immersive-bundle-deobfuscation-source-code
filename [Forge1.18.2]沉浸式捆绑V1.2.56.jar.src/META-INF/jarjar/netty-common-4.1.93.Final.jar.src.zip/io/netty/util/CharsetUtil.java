/*     */ package io.netty.util;
/*     */ 
/*     */ import io.netty.util.internal.InternalThreadLocalMap;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharsetUtil
/*     */ {
/*  37 */   public static final Charset UTF_16 = Charset.forName("UTF-16");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public static final Charset UTF_16BE = Charset.forName("UTF-16BE");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static final Charset UTF_16LE = Charset.forName("UTF-16LE");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final Charset UTF_8 = Charset.forName("UTF-8");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final Charset ISO_8859_1 = Charset.forName("ISO-8859-1");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final Charset US_ASCII = Charset.forName("US-ASCII");
/*     */   
/*  65 */   private static final Charset[] CHARSETS = new Charset[] { UTF_16, UTF_16BE, UTF_16LE, UTF_8, ISO_8859_1, US_ASCII };
/*     */ 
/*     */   
/*     */   public static Charset[] values() {
/*  69 */     return CHARSETS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static CharsetEncoder getEncoder(Charset charset) {
/*  77 */     return encoder(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharsetEncoder encoder(Charset charset, CodingErrorAction malformedInputAction, CodingErrorAction unmappableCharacterAction) {
/*  90 */     ObjectUtil.checkNotNull(charset, "charset");
/*  91 */     CharsetEncoder e = charset.newEncoder();
/*  92 */     e.onMalformedInput(malformedInputAction).onUnmappableCharacter(unmappableCharacterAction);
/*  93 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharsetEncoder encoder(Charset charset, CodingErrorAction codingErrorAction) {
/* 104 */     return encoder(charset, codingErrorAction, codingErrorAction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharsetEncoder encoder(Charset charset) {
/* 114 */     ObjectUtil.checkNotNull(charset, "charset");
/*     */     
/* 116 */     Map<Charset, CharsetEncoder> map = InternalThreadLocalMap.get().charsetEncoderCache();
/* 117 */     CharsetEncoder e = map.get(charset);
/* 118 */     if (e != null) {
/* 119 */       e.reset().onMalformedInput(CodingErrorAction.REPLACE).onUnmappableCharacter(CodingErrorAction.REPLACE);
/* 120 */       return e;
/*     */     } 
/*     */     
/* 123 */     e = encoder(charset, CodingErrorAction.REPLACE, CodingErrorAction.REPLACE);
/* 124 */     map.put(charset, e);
/* 125 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static CharsetDecoder getDecoder(Charset charset) {
/* 133 */     return decoder(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharsetDecoder decoder(Charset charset, CodingErrorAction malformedInputAction, CodingErrorAction unmappableCharacterAction) {
/* 146 */     ObjectUtil.checkNotNull(charset, "charset");
/* 147 */     CharsetDecoder d = charset.newDecoder();
/* 148 */     d.onMalformedInput(malformedInputAction).onUnmappableCharacter(unmappableCharacterAction);
/* 149 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharsetDecoder decoder(Charset charset, CodingErrorAction codingErrorAction) {
/* 160 */     return decoder(charset, codingErrorAction, codingErrorAction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharsetDecoder decoder(Charset charset) {
/* 170 */     ObjectUtil.checkNotNull(charset, "charset");
/*     */     
/* 172 */     Map<Charset, CharsetDecoder> map = InternalThreadLocalMap.get().charsetDecoderCache();
/* 173 */     CharsetDecoder d = map.get(charset);
/* 174 */     if (d != null) {
/* 175 */       d.reset().onMalformedInput(CodingErrorAction.REPLACE).onUnmappableCharacter(CodingErrorAction.REPLACE);
/* 176 */       return d;
/*     */     } 
/*     */     
/* 179 */     d = decoder(charset, CodingErrorAction.REPLACE, CodingErrorAction.REPLACE);
/* 180 */     map.put(charset, d);
/* 181 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\CharsetUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */