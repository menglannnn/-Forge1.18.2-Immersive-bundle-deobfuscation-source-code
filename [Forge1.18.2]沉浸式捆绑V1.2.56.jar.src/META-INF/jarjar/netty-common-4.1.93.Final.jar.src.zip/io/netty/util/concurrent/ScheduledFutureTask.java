/*     */ package io.netty.util.concurrent;
/*     */ 
/*     */ import io.netty.util.internal.DefaultPriorityQueue;
/*     */ import io.netty.util.internal.PriorityQueueNode;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Delayed;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ScheduledFutureTask<V>
/*     */   extends PromiseTask<V>
/*     */   implements ScheduledFuture<V>, PriorityQueueNode
/*     */ {
/*     */   private long id;
/*     */   private long deadlineNanos;
/*     */   private final long periodNanos;
/*  35 */   private int queueIndex = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   ScheduledFutureTask(AbstractScheduledEventExecutor executor, Runnable runnable, long nanoTime) {
/*  40 */     super(executor, runnable);
/*  41 */     this.deadlineNanos = nanoTime;
/*  42 */     this.periodNanos = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ScheduledFutureTask(AbstractScheduledEventExecutor executor, Runnable runnable, long nanoTime, long period) {
/*  48 */     super(executor, runnable);
/*  49 */     this.deadlineNanos = nanoTime;
/*  50 */     this.periodNanos = validatePeriod(period);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ScheduledFutureTask(AbstractScheduledEventExecutor executor, Callable<V> callable, long nanoTime, long period) {
/*  56 */     super(executor, callable);
/*  57 */     this.deadlineNanos = nanoTime;
/*  58 */     this.periodNanos = validatePeriod(period);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ScheduledFutureTask(AbstractScheduledEventExecutor executor, Callable<V> callable, long nanoTime) {
/*  64 */     super(executor, callable);
/*  65 */     this.deadlineNanos = nanoTime;
/*  66 */     this.periodNanos = 0L;
/*     */   }
/*     */   
/*     */   private static long validatePeriod(long period) {
/*  70 */     if (period == 0L) {
/*  71 */       throw new IllegalArgumentException("period: 0 (expected: != 0)");
/*     */     }
/*  73 */     return period;
/*     */   }
/*     */   
/*     */   ScheduledFutureTask<V> setId(long id) {
/*  77 */     if (this.id == 0L) {
/*  78 */       this.id = id;
/*     */     }
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected EventExecutor executor() {
/*  85 */     return super.executor();
/*     */   }
/*     */   
/*     */   public long deadlineNanos() {
/*  89 */     return this.deadlineNanos;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setConsumed() {
/*  95 */     if (this.periodNanos == 0L) {
/*  96 */       assert scheduledExecutor().getCurrentTimeNanos() >= this.deadlineNanos;
/*  97 */       this.deadlineNanos = 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long delayNanos() {
/* 102 */     return delayNanos(scheduledExecutor().getCurrentTimeNanos());
/*     */   }
/*     */   
/*     */   static long deadlineToDelayNanos(long currentTimeNanos, long deadlineNanos) {
/* 106 */     return (deadlineNanos == 0L) ? 0L : Math.max(0L, deadlineNanos - currentTimeNanos);
/*     */   }
/*     */   
/*     */   public long delayNanos(long currentTimeNanos) {
/* 110 */     return deadlineToDelayNanos(currentTimeNanos, this.deadlineNanos);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getDelay(TimeUnit unit) {
/* 115 */     return unit.convert(delayNanos(), TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Delayed o) {
/* 120 */     if (this == o) {
/* 121 */       return 0;
/*     */     }
/*     */     
/* 124 */     ScheduledFutureTask<?> that = (ScheduledFutureTask)o;
/* 125 */     long d = deadlineNanos() - that.deadlineNanos();
/* 126 */     if (d < 0L)
/* 127 */       return -1; 
/* 128 */     if (d > 0L)
/* 129 */       return 1; 
/* 130 */     if (this.id < that.id) {
/* 131 */       return -1;
/*     */     }
/* 133 */     assert this.id != that.id;
/* 134 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 140 */     assert executor().inEventLoop();
/*     */     try {
/* 142 */       if (delayNanos() > 0L) {
/*     */         
/* 144 */         if (isCancelled()) {
/* 145 */           scheduledExecutor().scheduledTaskQueue().removeTyped(this);
/*     */         } else {
/* 147 */           scheduledExecutor().scheduleFromEventLoop(this);
/*     */         } 
/*     */         return;
/*     */       } 
/* 151 */       if (this.periodNanos == 0L) {
/* 152 */         if (setUncancellableInternal()) {
/* 153 */           V result = runTask();
/* 154 */           setSuccessInternal(result);
/*     */         }
/*     */       
/*     */       }
/* 158 */       else if (!isCancelled()) {
/* 159 */         runTask();
/* 160 */         if (!executor().isShutdown()) {
/* 161 */           if (this.periodNanos > 0L) {
/* 162 */             this.deadlineNanos += this.periodNanos;
/*     */           } else {
/* 164 */             this.deadlineNanos = scheduledExecutor().getCurrentTimeNanos() - this.periodNanos;
/*     */           } 
/* 166 */           if (!isCancelled()) {
/* 167 */             scheduledExecutor().scheduledTaskQueue().add(this);
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/* 172 */     } catch (Throwable cause) {
/* 173 */       setFailureInternal(cause);
/*     */     } 
/*     */   }
/*     */   
/*     */   private AbstractScheduledEventExecutor scheduledExecutor() {
/* 178 */     return (AbstractScheduledEventExecutor)executor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cancel(boolean mayInterruptIfRunning) {
/* 188 */     boolean canceled = super.cancel(mayInterruptIfRunning);
/* 189 */     if (canceled) {
/* 190 */       scheduledExecutor().removeScheduled(this);
/*     */     }
/* 192 */     return canceled;
/*     */   }
/*     */   
/*     */   boolean cancelWithoutRemove(boolean mayInterruptIfRunning) {
/* 196 */     return super.cancel(mayInterruptIfRunning);
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringBuilder toStringBuilder() {
/* 201 */     StringBuilder buf = super.toStringBuilder();
/* 202 */     buf.setCharAt(buf.length() - 1, ',');
/*     */     
/* 204 */     return buf.append(" deadline: ")
/* 205 */       .append(this.deadlineNanos)
/* 206 */       .append(", period: ")
/* 207 */       .append(this.periodNanos)
/* 208 */       .append(')');
/*     */   }
/*     */ 
/*     */   
/*     */   public int priorityQueueIndex(DefaultPriorityQueue<?> queue) {
/* 213 */     return this.queueIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void priorityQueueIndex(DefaultPriorityQueue<?> queue, int i) {
/* 218 */     this.queueIndex = i;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\ScheduledFutureTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */