/*     */ package io.netty.util.concurrent;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PriorityQueue;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.ThreadExecutorMap;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.jetbrains.annotations.Async.Schedule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GlobalEventExecutor
/*     */   extends AbstractScheduledEventExecutor
/*     */   implements OrderedEventExecutor
/*     */ {
/*  44 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(GlobalEventExecutor.class);
/*     */   
/*     */   private static final long SCHEDULE_QUIET_PERIOD_INTERVAL;
/*     */   
/*     */   static {
/*  49 */     int quietPeriod = SystemPropertyUtil.getInt("io.netty.globalEventExecutor.quietPeriodSeconds", 1);
/*  50 */     if (quietPeriod <= 0) {
/*  51 */       quietPeriod = 1;
/*     */     }
/*  53 */     logger.debug("-Dio.netty.globalEventExecutor.quietPeriodSeconds: {}", Integer.valueOf(quietPeriod));
/*     */     
/*  55 */     SCHEDULE_QUIET_PERIOD_INTERVAL = TimeUnit.SECONDS.toNanos(quietPeriod);
/*     */   }
/*     */   
/*  58 */   public static final GlobalEventExecutor INSTANCE = new GlobalEventExecutor();
/*     */   
/*  60 */   final BlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<Runnable>();
/*  61 */   final ScheduledFutureTask<Void> quietPeriodTask = new ScheduledFutureTask<Void>(this, 
/*  62 */       Executors.callable(new Runnable()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void run() {}
/*     */         }, 
/*     */         
/*  70 */         null), deadlineNanos(getCurrentTimeNanos(), SCHEDULE_QUIET_PERIOD_INTERVAL), -SCHEDULE_QUIET_PERIOD_INTERVAL);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final ThreadFactory threadFactory;
/*     */ 
/*     */ 
/*     */   
/*  79 */   private final TaskRunner taskRunner = new TaskRunner();
/*  80 */   private final AtomicBoolean started = new AtomicBoolean();
/*     */   
/*     */   volatile Thread thread;
/*  83 */   private final Future<?> terminationFuture = new FailedFuture(this, new UnsupportedOperationException());
/*     */   
/*     */   private GlobalEventExecutor() {
/*  86 */     scheduledTaskQueue().add(this.quietPeriodTask);
/*  87 */     this.threadFactory = ThreadExecutorMap.apply(new DefaultThreadFactory(
/*  88 */           DefaultThreadFactory.toPoolName(getClass()), false, 5, null), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Runnable takeTask() {
/*  97 */     BlockingQueue<Runnable> taskQueue = this.taskQueue;
/*     */     while (true) {
/*  99 */       ScheduledFutureTask<?> scheduledTask = peekScheduledTask();
/* 100 */       if (scheduledTask == null) {
/* 101 */         Runnable runnable = null;
/*     */         try {
/* 103 */           runnable = taskQueue.take();
/* 104 */         } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */         
/* 107 */         return runnable;
/*     */       } 
/* 109 */       long delayNanos = scheduledTask.delayNanos();
/* 110 */       Runnable task = null;
/* 111 */       if (delayNanos > 0L) {
/*     */         try {
/* 113 */           task = taskQueue.poll(delayNanos, TimeUnit.NANOSECONDS);
/* 114 */         } catch (InterruptedException e) {
/*     */           
/* 116 */           return null;
/*     */         } 
/*     */       }
/* 119 */       if (task == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 124 */         fetchFromScheduledTaskQueue();
/* 125 */         task = taskQueue.poll();
/*     */       } 
/*     */       
/* 128 */       if (task != null) {
/* 129 */         return task;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void fetchFromScheduledTaskQueue() {
/* 136 */     long nanoTime = getCurrentTimeNanos();
/* 137 */     Runnable scheduledTask = pollScheduledTask(nanoTime);
/* 138 */     while (scheduledTask != null) {
/* 139 */       this.taskQueue.add(scheduledTask);
/* 140 */       scheduledTask = pollScheduledTask(nanoTime);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int pendingTasks() {
/* 148 */     return this.taskQueue.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addTask(Runnable task) {
/* 156 */     this.taskQueue.add(ObjectUtil.checkNotNull(task, "task"));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inEventLoop(Thread thread) {
/* 161 */     return (thread == this.thread);
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> shutdownGracefully(long quietPeriod, long timeout, TimeUnit unit) {
/* 166 */     return terminationFuture();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> terminationFuture() {
/* 171 */     return this.terminationFuture;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void shutdown() {
/* 177 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShuttingDown() {
/* 182 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShutdown() {
/* 187 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 192 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean awaitTermination(long timeout, TimeUnit unit) {
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean awaitInactivity(long timeout, TimeUnit unit) throws InterruptedException {
/* 209 */     ObjectUtil.checkNotNull(unit, "unit");
/*     */     
/* 211 */     Thread thread = this.thread;
/* 212 */     if (thread == null) {
/* 213 */       throw new IllegalStateException("thread was not started");
/*     */     }
/* 215 */     thread.join(unit.toMillis(timeout));
/* 216 */     return !thread.isAlive();
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(Runnable task) {
/* 221 */     execute0(task);
/*     */   }
/*     */   
/*     */   private void execute0(@Schedule Runnable task) {
/* 225 */     addTask((Runnable)ObjectUtil.checkNotNull(task, "task"));
/* 226 */     if (!inEventLoop()) {
/* 227 */       startThread();
/*     */     }
/*     */   }
/*     */   
/*     */   private void startThread() {
/* 232 */     if (this.started.compareAndSet(false, true)) {
/* 233 */       final Thread t = this.threadFactory.newThread(this.taskRunner);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */           {
/*     */             public Void run() {
/* 242 */               t.setContextClassLoader(null);
/* 243 */               return null;
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 250 */       this.thread = t;
/* 251 */       t.start();
/*     */     } 
/*     */   }
/*     */   
/*     */   final class TaskRunner
/*     */     implements Runnable {
/*     */     public void run() {
/*     */       while (true) {
/* 259 */         Runnable task = GlobalEventExecutor.this.takeTask();
/* 260 */         if (task != null) {
/*     */           try {
/* 262 */             AbstractEventExecutor.runTask(task);
/* 263 */           } catch (Throwable t) {
/* 264 */             GlobalEventExecutor.logger.warn("Unexpected exception from the global event executor: ", t);
/*     */           } 
/*     */           
/* 267 */           if (task != GlobalEventExecutor.this.quietPeriodTask) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 272 */         PriorityQueue<ScheduledFutureTask<?>> priorityQueue = GlobalEventExecutor.this.scheduledTaskQueue;
/*     */         
/* 274 */         if (GlobalEventExecutor.this.taskQueue.isEmpty() && (priorityQueue == null || priorityQueue.size() == 1)) {
/*     */ 
/*     */ 
/*     */           
/* 278 */           boolean stopped = GlobalEventExecutor.this.started.compareAndSet(true, false);
/* 279 */           assert stopped;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 284 */           if (GlobalEventExecutor.this.taskQueue.isEmpty()) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 293 */           if (!GlobalEventExecutor.this.started.compareAndSet(false, true))
/*     */             break; 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\GlobalEventExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */