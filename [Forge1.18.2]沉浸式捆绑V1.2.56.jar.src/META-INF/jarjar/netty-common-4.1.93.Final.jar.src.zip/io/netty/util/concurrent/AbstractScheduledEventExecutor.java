/*     */ package io.netty.util.concurrent;
/*     */ 
/*     */ import io.netty.util.internal.DefaultPriorityQueue;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PriorityQueue;
/*     */ import java.util.Comparator;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractScheduledEventExecutor
/*     */   extends AbstractEventExecutor
/*     */ {
/*  31 */   private static final Comparator<ScheduledFutureTask<?>> SCHEDULED_FUTURE_TASK_COMPARATOR = new Comparator<ScheduledFutureTask<?>>()
/*     */     {
/*     */       public int compare(ScheduledFutureTask<?> o1, ScheduledFutureTask<?> o2)
/*     */       {
/*  35 */         return o1.compareTo(o2);
/*     */       }
/*     */     };
/*     */   
/*  39 */   private static final long START_TIME = System.nanoTime();
/*     */   
/*  41 */   static final Runnable WAKEUP_TASK = new Runnable()
/*     */     {
/*     */       public void run() {}
/*     */     };
/*     */ 
/*     */   
/*     */   PriorityQueue<ScheduledFutureTask<?>> scheduledTaskQueue;
/*     */   
/*     */   long nextTaskId;
/*     */   
/*     */   protected AbstractScheduledEventExecutor() {}
/*     */   
/*     */   protected AbstractScheduledEventExecutor(EventExecutorGroup parent) {
/*  54 */     super(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getCurrentTimeNanos() {
/*  68 */     return defaultCurrentTimeNanos();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected static long nanoTime() {
/*  76 */     return defaultCurrentTimeNanos();
/*     */   }
/*     */   
/*     */   static long defaultCurrentTimeNanos() {
/*  80 */     return System.nanoTime() - START_TIME;
/*     */   }
/*     */   
/*     */   static long deadlineNanos(long nanoTime, long delay) {
/*  84 */     long deadlineNanos = nanoTime + delay;
/*     */     
/*  86 */     return (deadlineNanos < 0L) ? Long.MAX_VALUE : deadlineNanos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static long deadlineToDelayNanos(long deadlineNanos) {
/*  96 */     return ScheduledFutureTask.deadlineToDelayNanos(defaultCurrentTimeNanos(), deadlineNanos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static long initialNanoTime() {
/* 104 */     return START_TIME;
/*     */   }
/*     */   
/*     */   PriorityQueue<ScheduledFutureTask<?>> scheduledTaskQueue() {
/* 108 */     if (this.scheduledTaskQueue == null) {
/* 109 */       this.scheduledTaskQueue = (PriorityQueue<ScheduledFutureTask<?>>)new DefaultPriorityQueue(SCHEDULED_FUTURE_TASK_COMPARATOR, 11);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 114 */     return this.scheduledTaskQueue;
/*     */   }
/*     */   
/*     */   private static boolean isNullOrEmpty(Queue<ScheduledFutureTask<?>> queue) {
/* 118 */     return (queue == null || queue.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cancelScheduledTasks() {
/* 127 */     assert inEventLoop();
/* 128 */     PriorityQueue<ScheduledFutureTask<?>> scheduledTaskQueue = this.scheduledTaskQueue;
/* 129 */     if (isNullOrEmpty((Queue<ScheduledFutureTask<?>>)scheduledTaskQueue)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 134 */     ScheduledFutureTask[] arrayOfScheduledFutureTask = (ScheduledFutureTask[])scheduledTaskQueue.toArray((Object[])new ScheduledFutureTask[0]);
/*     */     
/* 136 */     for (ScheduledFutureTask<?> task : arrayOfScheduledFutureTask) {
/* 137 */       task.cancelWithoutRemove(false);
/*     */     }
/*     */     
/* 140 */     scheduledTaskQueue.clearIgnoringIndexes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Runnable pollScheduledTask() {
/* 147 */     return pollScheduledTask(getCurrentTimeNanos());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Runnable pollScheduledTask(long nanoTime) {
/* 155 */     assert inEventLoop();
/*     */     
/* 157 */     ScheduledFutureTask<?> scheduledTask = peekScheduledTask();
/* 158 */     if (scheduledTask == null || scheduledTask.deadlineNanos() - nanoTime > 0L) {
/* 159 */       return null;
/*     */     }
/* 161 */     this.scheduledTaskQueue.remove();
/* 162 */     scheduledTask.setConsumed();
/* 163 */     return scheduledTask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final long nextScheduledTaskNano() {
/* 170 */     ScheduledFutureTask<?> scheduledTask = peekScheduledTask();
/* 171 */     return (scheduledTask != null) ? scheduledTask.delayNanos() : -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final long nextScheduledTaskDeadlineNanos() {
/* 179 */     ScheduledFutureTask<?> scheduledTask = peekScheduledTask();
/* 180 */     return (scheduledTask != null) ? scheduledTask.deadlineNanos() : -1L;
/*     */   }
/*     */   
/*     */   final ScheduledFutureTask<?> peekScheduledTask() {
/* 184 */     PriorityQueue<ScheduledFutureTask<?>> priorityQueue = this.scheduledTaskQueue;
/* 185 */     return (priorityQueue != null) ? priorityQueue.peek() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean hasScheduledTasks() {
/* 192 */     ScheduledFutureTask<?> scheduledTask = peekScheduledTask();
/* 193 */     return (scheduledTask != null && scheduledTask.deadlineNanos() <= getCurrentTimeNanos());
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
/* 198 */     ObjectUtil.checkNotNull(command, "command");
/* 199 */     ObjectUtil.checkNotNull(unit, "unit");
/* 200 */     if (delay < 0L) {
/* 201 */       delay = 0L;
/*     */     }
/* 203 */     validateScheduled0(delay, unit);
/*     */     
/* 205 */     return schedule(new ScheduledFutureTask(this, command, 
/*     */ 
/*     */           
/* 208 */           deadlineNanos(getCurrentTimeNanos(), unit.toNanos(delay))));
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
/* 213 */     ObjectUtil.checkNotNull(callable, "callable");
/* 214 */     ObjectUtil.checkNotNull(unit, "unit");
/* 215 */     if (delay < 0L) {
/* 216 */       delay = 0L;
/*     */     }
/* 218 */     validateScheduled0(delay, unit);
/*     */     
/* 220 */     return schedule(new ScheduledFutureTask<V>(this, callable, 
/* 221 */           deadlineNanos(getCurrentTimeNanos(), unit.toNanos(delay))));
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
/* 226 */     ObjectUtil.checkNotNull(command, "command");
/* 227 */     ObjectUtil.checkNotNull(unit, "unit");
/* 228 */     if (initialDelay < 0L) {
/* 229 */       throw new IllegalArgumentException(
/* 230 */           String.format("initialDelay: %d (expected: >= 0)", new Object[] { Long.valueOf(initialDelay) }));
/*     */     }
/* 232 */     if (period <= 0L) {
/* 233 */       throw new IllegalArgumentException(
/* 234 */           String.format("period: %d (expected: > 0)", new Object[] { Long.valueOf(period) }));
/*     */     }
/* 236 */     validateScheduled0(initialDelay, unit);
/* 237 */     validateScheduled0(period, unit);
/*     */     
/* 239 */     return schedule(new ScheduledFutureTask(this, command, 
/* 240 */           deadlineNanos(getCurrentTimeNanos(), unit.toNanos(initialDelay)), unit.toNanos(period)));
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
/* 245 */     ObjectUtil.checkNotNull(command, "command");
/* 246 */     ObjectUtil.checkNotNull(unit, "unit");
/* 247 */     if (initialDelay < 0L) {
/* 248 */       throw new IllegalArgumentException(
/* 249 */           String.format("initialDelay: %d (expected: >= 0)", new Object[] { Long.valueOf(initialDelay) }));
/*     */     }
/* 251 */     if (delay <= 0L) {
/* 252 */       throw new IllegalArgumentException(
/* 253 */           String.format("delay: %d (expected: > 0)", new Object[] { Long.valueOf(delay) }));
/*     */     }
/*     */     
/* 256 */     validateScheduled0(initialDelay, unit);
/* 257 */     validateScheduled0(delay, unit);
/*     */     
/* 259 */     return schedule(new ScheduledFutureTask(this, command, 
/* 260 */           deadlineNanos(getCurrentTimeNanos(), unit.toNanos(initialDelay)), -unit.toNanos(delay)));
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateScheduled0(long amount, TimeUnit unit) {
/* 265 */     validateScheduled(amount, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void validateScheduled(long amount, TimeUnit unit) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void scheduleFromEventLoop(ScheduledFutureTask<?> task) {
/* 280 */     scheduledTaskQueue().add(task.setId(++this.nextTaskId));
/*     */   }
/*     */   
/*     */   private <V> ScheduledFuture<V> schedule(ScheduledFutureTask<V> task) {
/* 284 */     if (inEventLoop()) {
/* 285 */       scheduleFromEventLoop(task);
/*     */     } else {
/* 287 */       long deadlineNanos = task.deadlineNanos();
/*     */       
/* 289 */       if (beforeScheduledTaskSubmitted(deadlineNanos)) {
/* 290 */         execute(task);
/*     */       } else {
/* 292 */         lazyExecute(task);
/*     */         
/* 294 */         if (afterScheduledTaskSubmitted(deadlineNanos)) {
/* 295 */           execute(WAKEUP_TASK);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 300 */     return task;
/*     */   }
/*     */   
/*     */   final void removeScheduled(ScheduledFutureTask<?> task) {
/* 304 */     assert task.isCancelled();
/* 305 */     if (inEventLoop()) {
/* 306 */       scheduledTaskQueue().removeTyped(task);
/*     */     } else {
/*     */       
/* 309 */       lazyExecute(task);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean beforeScheduledTaskSubmitted(long deadlineNanos) {
/* 327 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean afterScheduledTaskSubmitted(long deadlineNanos) {
/* 337 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\AbstractScheduledEventExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */