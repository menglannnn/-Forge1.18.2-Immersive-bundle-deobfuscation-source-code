/*     */ package io.netty.util.concurrent;
/*     */ 
/*     */ import io.netty.util.internal.InternalThreadLocalMap;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastThreadLocalThread
/*     */   extends Thread
/*     */ {
/*  28 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(FastThreadLocalThread.class);
/*     */   
/*     */   private final boolean cleanupFastThreadLocals;
/*     */   
/*     */   private InternalThreadLocalMap threadLocalMap;
/*     */ 
/*     */   
/*     */   public FastThreadLocalThread() {
/*  36 */     this.cleanupFastThreadLocals = false;
/*     */   }
/*     */   
/*     */   public FastThreadLocalThread(Runnable target) {
/*  40 */     super(FastThreadLocalRunnable.wrap(target));
/*  41 */     this.cleanupFastThreadLocals = true;
/*     */   }
/*     */   
/*     */   public FastThreadLocalThread(ThreadGroup group, Runnable target) {
/*  45 */     super(group, FastThreadLocalRunnable.wrap(target));
/*  46 */     this.cleanupFastThreadLocals = true;
/*     */   }
/*     */   
/*     */   public FastThreadLocalThread(String name) {
/*  50 */     super(name);
/*  51 */     this.cleanupFastThreadLocals = false;
/*     */   }
/*     */   
/*     */   public FastThreadLocalThread(ThreadGroup group, String name) {
/*  55 */     super(group, name);
/*  56 */     this.cleanupFastThreadLocals = false;
/*     */   }
/*     */   
/*     */   public FastThreadLocalThread(Runnable target, String name) {
/*  60 */     super(FastThreadLocalRunnable.wrap(target), name);
/*  61 */     this.cleanupFastThreadLocals = true;
/*     */   }
/*     */   
/*     */   public FastThreadLocalThread(ThreadGroup group, Runnable target, String name) {
/*  65 */     super(group, FastThreadLocalRunnable.wrap(target), name);
/*  66 */     this.cleanupFastThreadLocals = true;
/*     */   }
/*     */   
/*     */   public FastThreadLocalThread(ThreadGroup group, Runnable target, String name, long stackSize) {
/*  70 */     super(group, FastThreadLocalRunnable.wrap(target), name, stackSize);
/*  71 */     this.cleanupFastThreadLocals = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InternalThreadLocalMap threadLocalMap() {
/*  79 */     if (this != Thread.currentThread() && logger.isWarnEnabled()) {
/*  80 */       logger.warn(new RuntimeException("It's not thread-safe to get 'threadLocalMap' which doesn't belong to the caller thread"));
/*     */     }
/*     */     
/*  83 */     return this.threadLocalMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setThreadLocalMap(InternalThreadLocalMap threadLocalMap) {
/*  91 */     if (this != Thread.currentThread() && logger.isWarnEnabled()) {
/*  92 */       logger.warn(new RuntimeException("It's not thread-safe to set 'threadLocalMap' which doesn't belong to the caller thread"));
/*     */     }
/*     */     
/*  95 */     this.threadLocalMap = threadLocalMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean willCleanupFastThreadLocals() {
/* 103 */     return this.cleanupFastThreadLocals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean willCleanupFastThreadLocals(Thread thread) {
/* 111 */     return (thread instanceof FastThreadLocalThread && ((FastThreadLocalThread)thread)
/* 112 */       .willCleanupFastThreadLocals());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean permitBlockingCalls() {
/* 126 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\FastThreadLocalThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */