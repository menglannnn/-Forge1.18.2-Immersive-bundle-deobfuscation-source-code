/*      */ package io.netty.util.concurrent;
/*      */ 
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.PlatformDependent;
/*      */ import io.netty.util.internal.SystemPropertyUtil;
/*      */ import io.netty.util.internal.ThreadExecutorMap;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.BlockingQueue;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.LinkedBlockingQueue;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.TimeoutException;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import org.jetbrains.annotations.Async.Schedule;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class SingleThreadEventExecutor
/*      */   extends AbstractScheduledEventExecutor
/*      */   implements OrderedEventExecutor
/*      */ {
/*   53 */   static final int DEFAULT_MAX_PENDING_EXECUTOR_TASKS = Math.max(16, 
/*   54 */       SystemPropertyUtil.getInt("io.netty.eventexecutor.maxPendingTasks", 2147483647));
/*      */ 
/*      */   
/*   57 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(SingleThreadEventExecutor.class);
/*      */   
/*      */   private static final int ST_NOT_STARTED = 1;
/*      */   private static final int ST_STARTED = 2;
/*      */   private static final int ST_SHUTTING_DOWN = 3;
/*      */   private static final int ST_SHUTDOWN = 4;
/*      */   private static final int ST_TERMINATED = 5;
/*      */   
/*   65 */   private static final Runnable NOOP_TASK = new Runnable()
/*      */     {
/*      */       public void run() {}
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   73 */   private static final AtomicIntegerFieldUpdater<SingleThreadEventExecutor> STATE_UPDATER = AtomicIntegerFieldUpdater.newUpdater(SingleThreadEventExecutor.class, "state");
/*      */   
/*   75 */   private static final AtomicReferenceFieldUpdater<SingleThreadEventExecutor, ThreadProperties> PROPERTIES_UPDATER = AtomicReferenceFieldUpdater.newUpdater(SingleThreadEventExecutor.class, ThreadProperties.class, "threadProperties");
/*      */   
/*      */   private final Queue<Runnable> taskQueue;
/*      */   
/*      */   private volatile Thread thread;
/*      */   
/*      */   private volatile ThreadProperties threadProperties;
/*      */   
/*      */   private final Executor executor;
/*      */   
/*      */   private volatile boolean interrupted;
/*   86 */   private final CountDownLatch threadLock = new CountDownLatch(1);
/*   87 */   private final Set<Runnable> shutdownHooks = new LinkedHashSet<Runnable>();
/*      */   
/*      */   private final boolean addTaskWakesUp;
/*      */   
/*      */   private final int maxPendingTasks;
/*      */   private final RejectedExecutionHandler rejectedExecutionHandler;
/*      */   private long lastExecutionTime;
/*   94 */   private volatile int state = 1;
/*      */   
/*      */   private volatile long gracefulShutdownQuietPeriod;
/*      */   
/*      */   private volatile long gracefulShutdownTimeout;
/*      */   
/*      */   private long gracefulShutdownStartTime;
/*  101 */   private final Promise<?> terminationFuture = new DefaultPromise(GlobalEventExecutor.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SingleThreadEventExecutor(EventExecutorGroup parent, ThreadFactory threadFactory, boolean addTaskWakesUp) {
/*  113 */     this(parent, new ThreadPerTaskExecutor(threadFactory), addTaskWakesUp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SingleThreadEventExecutor(EventExecutorGroup parent, ThreadFactory threadFactory, boolean addTaskWakesUp, int maxPendingTasks, RejectedExecutionHandler rejectedHandler) {
/*  129 */     this(parent, new ThreadPerTaskExecutor(threadFactory), addTaskWakesUp, maxPendingTasks, rejectedHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SingleThreadEventExecutor(EventExecutorGroup parent, Executor executor, boolean addTaskWakesUp) {
/*  141 */     this(parent, executor, addTaskWakesUp, DEFAULT_MAX_PENDING_EXECUTOR_TASKS, RejectedExecutionHandlers.reject());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SingleThreadEventExecutor(EventExecutorGroup parent, Executor executor, boolean addTaskWakesUp, int maxPendingTasks, RejectedExecutionHandler rejectedHandler) {
/*  157 */     super(parent);
/*  158 */     this.addTaskWakesUp = addTaskWakesUp;
/*  159 */     this.maxPendingTasks = Math.max(16, maxPendingTasks);
/*  160 */     this.executor = ThreadExecutorMap.apply(executor, this);
/*  161 */     this.taskQueue = newTaskQueue(this.maxPendingTasks);
/*  162 */     this.rejectedExecutionHandler = (RejectedExecutionHandler)ObjectUtil.checkNotNull(rejectedHandler, "rejectedHandler");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected SingleThreadEventExecutor(EventExecutorGroup parent, Executor executor, boolean addTaskWakesUp, Queue<Runnable> taskQueue, RejectedExecutionHandler rejectedHandler) {
/*  168 */     super(parent);
/*  169 */     this.addTaskWakesUp = addTaskWakesUp;
/*  170 */     this.maxPendingTasks = DEFAULT_MAX_PENDING_EXECUTOR_TASKS;
/*  171 */     this.executor = ThreadExecutorMap.apply(executor, this);
/*  172 */     this.taskQueue = (Queue<Runnable>)ObjectUtil.checkNotNull(taskQueue, "taskQueue");
/*  173 */     this.rejectedExecutionHandler = (RejectedExecutionHandler)ObjectUtil.checkNotNull(rejectedHandler, "rejectedHandler");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Queue<Runnable> newTaskQueue() {
/*  181 */     return newTaskQueue(this.maxPendingTasks);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Queue<Runnable> newTaskQueue(int maxPendingTasks) {
/*  191 */     return new LinkedBlockingQueue<Runnable>(maxPendingTasks);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void interruptThread() {
/*  198 */     Thread currentThread = this.thread;
/*  199 */     if (currentThread == null) {
/*  200 */       this.interrupted = true;
/*      */     } else {
/*  202 */       currentThread.interrupt();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Runnable pollTask() {
/*  210 */     assert inEventLoop();
/*  211 */     return pollTaskFrom(this.taskQueue);
/*      */   }
/*      */   
/*      */   protected static Runnable pollTaskFrom(Queue<Runnable> taskQueue) {
/*      */     while (true) {
/*  216 */       Runnable task = taskQueue.poll();
/*  217 */       if (task != WAKEUP_TASK) {
/*  218 */         return task;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Runnable takeTask() {
/*  233 */     assert inEventLoop();
/*  234 */     if (!(this.taskQueue instanceof BlockingQueue)) {
/*  235 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     
/*  238 */     BlockingQueue<Runnable> taskQueue = (BlockingQueue<Runnable>)this.taskQueue;
/*      */     while (true) {
/*  240 */       ScheduledFutureTask<?> scheduledTask = peekScheduledTask();
/*  241 */       if (scheduledTask == null) {
/*  242 */         Runnable runnable = null;
/*      */         try {
/*  244 */           runnable = taskQueue.take();
/*  245 */           if (runnable == WAKEUP_TASK) {
/*  246 */             runnable = null;
/*      */           }
/*  248 */         } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */         
/*  251 */         return runnable;
/*      */       } 
/*  253 */       long delayNanos = scheduledTask.delayNanos();
/*  254 */       Runnable task = null;
/*  255 */       if (delayNanos > 0L) {
/*      */         try {
/*  257 */           task = taskQueue.poll(delayNanos, TimeUnit.NANOSECONDS);
/*  258 */         } catch (InterruptedException e) {
/*      */           
/*  260 */           return null;
/*      */         } 
/*      */       }
/*  263 */       if (task == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  268 */         fetchFromScheduledTaskQueue();
/*  269 */         task = taskQueue.poll();
/*      */       } 
/*      */       
/*  272 */       if (task != null) {
/*  273 */         return task;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean fetchFromScheduledTaskQueue() {
/*      */     Runnable scheduledTask;
/*  280 */     if (this.scheduledTaskQueue == null || this.scheduledTaskQueue.isEmpty()) {
/*  281 */       return true;
/*      */     }
/*  283 */     long nanoTime = getCurrentTimeNanos();
/*      */     do {
/*  285 */       scheduledTask = pollScheduledTask(nanoTime);
/*  286 */       if (scheduledTask == null) {
/*  287 */         return true;
/*      */       }
/*  289 */     } while (this.taskQueue.offer(scheduledTask));
/*      */     
/*  291 */     this.scheduledTaskQueue.add(scheduledTask);
/*  292 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean executeExpiredScheduledTasks() {
/*  301 */     if (this.scheduledTaskQueue == null || this.scheduledTaskQueue.isEmpty()) {
/*  302 */       return false;
/*      */     }
/*  304 */     long nanoTime = getCurrentTimeNanos();
/*  305 */     Runnable scheduledTask = pollScheduledTask(nanoTime);
/*  306 */     if (scheduledTask == null) {
/*  307 */       return false;
/*      */     }
/*      */     do {
/*  310 */       safeExecute(scheduledTask);
/*  311 */     } while ((scheduledTask = pollScheduledTask(nanoTime)) != null);
/*  312 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Runnable peekTask() {
/*  319 */     assert inEventLoop();
/*  320 */     return this.taskQueue.peek();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasTasks() {
/*  327 */     assert inEventLoop();
/*  328 */     return !this.taskQueue.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int pendingTasks() {
/*  335 */     return this.taskQueue.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addTask(Runnable task) {
/*  343 */     ObjectUtil.checkNotNull(task, "task");
/*  344 */     if (!offerTask(task)) {
/*  345 */       reject(task);
/*      */     }
/*      */   }
/*      */   
/*      */   final boolean offerTask(Runnable task) {
/*  350 */     if (isShutdown()) {
/*  351 */       reject();
/*      */     }
/*  353 */     return this.taskQueue.offer(task);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean removeTask(Runnable task) {
/*  360 */     return this.taskQueue.remove(ObjectUtil.checkNotNull(task, "task"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean runAllTasks() {
/*      */     boolean fetchedAll;
/*  369 */     assert inEventLoop();
/*      */     
/*  371 */     boolean ranAtLeastOne = false;
/*      */     
/*      */     do {
/*  374 */       fetchedAll = fetchFromScheduledTaskQueue();
/*  375 */       if (!runAllTasksFrom(this.taskQueue))
/*  376 */         continue;  ranAtLeastOne = true;
/*      */     }
/*  378 */     while (!fetchedAll);
/*      */     
/*  380 */     if (ranAtLeastOne) {
/*  381 */       this.lastExecutionTime = getCurrentTimeNanos();
/*      */     }
/*  383 */     afterRunningAllTasks();
/*  384 */     return ranAtLeastOne;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean runScheduledAndExecutorTasks(int maxDrainAttempts) {
/*      */     int i;
/*  396 */     assert inEventLoop();
/*      */     
/*  398 */     int drainAttempt = 0;
/*      */ 
/*      */     
/*      */     do {
/*  402 */       i = runExistingTasksFrom(this.taskQueue) | executeExpiredScheduledTasks();
/*  403 */     } while (i != 0 && ++drainAttempt < maxDrainAttempts);
/*      */     
/*  405 */     if (drainAttempt > 0) {
/*  406 */       this.lastExecutionTime = getCurrentTimeNanos();
/*      */     }
/*  408 */     afterRunningAllTasks();
/*      */     
/*  410 */     return (drainAttempt > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean runAllTasksFrom(Queue<Runnable> taskQueue) {
/*  421 */     Runnable task = pollTaskFrom(taskQueue);
/*  422 */     if (task == null) {
/*  423 */       return false;
/*      */     }
/*      */     while (true) {
/*  426 */       safeExecute(task);
/*  427 */       task = pollTaskFrom(taskQueue);
/*  428 */       if (task == null) {
/*  429 */         return true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean runExistingTasksFrom(Queue<Runnable> taskQueue) {
/*  440 */     Runnable task = pollTaskFrom(taskQueue);
/*  441 */     if (task == null) {
/*  442 */       return false;
/*      */     }
/*  444 */     int remaining = Math.min(this.maxPendingTasks, taskQueue.size());
/*  445 */     safeExecute(task);
/*      */ 
/*      */     
/*  448 */     while (remaining-- > 0 && (task = taskQueue.poll()) != null) {
/*  449 */       safeExecute(task);
/*      */     }
/*  451 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean runAllTasks(long timeoutNanos) {
/*      */     long lastExecutionTime;
/*  459 */     fetchFromScheduledTaskQueue();
/*  460 */     Runnable task = pollTask();
/*  461 */     if (task == null) {
/*  462 */       afterRunningAllTasks();
/*  463 */       return false;
/*      */     } 
/*      */     
/*  466 */     long deadline = (timeoutNanos > 0L) ? (getCurrentTimeNanos() + timeoutNanos) : 0L;
/*  467 */     long runTasks = 0L;
/*      */     
/*      */     while (true) {
/*  470 */       safeExecute(task);
/*      */       
/*  472 */       runTasks++;
/*      */ 
/*      */ 
/*      */       
/*  476 */       if ((runTasks & 0x3FL) == 0L) {
/*  477 */         lastExecutionTime = getCurrentTimeNanos();
/*  478 */         if (lastExecutionTime >= deadline) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */       
/*  483 */       task = pollTask();
/*  484 */       if (task == null) {
/*  485 */         lastExecutionTime = getCurrentTimeNanos();
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  490 */     afterRunningAllTasks();
/*  491 */     this.lastExecutionTime = lastExecutionTime;
/*  492 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void afterRunningAllTasks() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long delayNanos(long currentTimeNanos) {
/*  505 */     currentTimeNanos -= initialNanoTime();
/*      */     
/*  507 */     ScheduledFutureTask<?> scheduledTask = peekScheduledTask();
/*  508 */     if (scheduledTask == null) {
/*  509 */       return SCHEDULE_PURGE_INTERVAL;
/*      */     }
/*      */     
/*  512 */     return scheduledTask.delayNanos(currentTimeNanos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long deadlineNanos() {
/*  521 */     ScheduledFutureTask<?> scheduledTask = peekScheduledTask();
/*  522 */     if (scheduledTask == null) {
/*  523 */       return getCurrentTimeNanos() + SCHEDULE_PURGE_INTERVAL;
/*      */     }
/*  525 */     return scheduledTask.deadlineNanos();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateLastExecutionTime() {
/*  536 */     this.lastExecutionTime = getCurrentTimeNanos();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cleanup() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void wakeup(boolean inEventLoop) {
/*  552 */     if (!inEventLoop)
/*      */     {
/*      */       
/*  555 */       this.taskQueue.offer(WAKEUP_TASK);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean inEventLoop(Thread thread) {
/*  561 */     return (thread == this.thread);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addShutdownHook(final Runnable task) {
/*  568 */     if (inEventLoop()) {
/*  569 */       this.shutdownHooks.add(task);
/*      */     } else {
/*  571 */       execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  574 */               SingleThreadEventExecutor.this.shutdownHooks.add(task);
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeShutdownHook(final Runnable task) {
/*  584 */     if (inEventLoop()) {
/*  585 */       this.shutdownHooks.remove(task);
/*      */     } else {
/*  587 */       execute(new Runnable()
/*      */           {
/*      */             public void run() {
/*  590 */               SingleThreadEventExecutor.this.shutdownHooks.remove(task);
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean runShutdownHooks() {
/*  597 */     boolean ran = false;
/*      */     
/*  599 */     while (!this.shutdownHooks.isEmpty()) {
/*  600 */       List<Runnable> copy = new ArrayList<Runnable>(this.shutdownHooks);
/*  601 */       this.shutdownHooks.clear();
/*  602 */       for (Runnable task : copy) {
/*      */         try {
/*  604 */           runTask(task);
/*  605 */         } catch (Throwable t) {
/*  606 */           logger.warn("Shutdown hook raised an exception.", t);
/*      */         } finally {
/*  608 */           ran = true;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  613 */     if (ran) {
/*  614 */       this.lastExecutionTime = getCurrentTimeNanos();
/*      */     }
/*      */     
/*  617 */     return ran;
/*      */   }
/*      */   public Future<?> shutdownGracefully(long quietPeriod, long timeout, TimeUnit unit) {
/*      */     boolean wakeup;
/*      */     int oldState, newState;
/*  622 */     ObjectUtil.checkPositiveOrZero(quietPeriod, "quietPeriod");
/*  623 */     if (timeout < quietPeriod) {
/*  624 */       throw new IllegalArgumentException("timeout: " + timeout + " (expected >= quietPeriod (" + quietPeriod + "))");
/*      */     }
/*      */     
/*  627 */     ObjectUtil.checkNotNull(unit, "unit");
/*      */     
/*  629 */     if (isShuttingDown()) {
/*  630 */       return terminationFuture();
/*      */     }
/*      */     
/*  633 */     boolean inEventLoop = inEventLoop();
/*      */ 
/*      */     
/*      */     do {
/*  637 */       if (isShuttingDown()) {
/*  638 */         return terminationFuture();
/*      */       }
/*      */       
/*  641 */       wakeup = true;
/*  642 */       oldState = this.state;
/*  643 */       if (inEventLoop) {
/*  644 */         newState = 3;
/*      */       } else {
/*  646 */         switch (oldState) {
/*      */           case 1:
/*      */           case 2:
/*  649 */             newState = 3;
/*      */             break;
/*      */           default:
/*  652 */             newState = oldState;
/*  653 */             wakeup = false; break;
/*      */         } 
/*      */       } 
/*  656 */     } while (!STATE_UPDATER.compareAndSet(this, oldState, newState));
/*      */ 
/*      */ 
/*      */     
/*  660 */     this.gracefulShutdownQuietPeriod = unit.toNanos(quietPeriod);
/*  661 */     this.gracefulShutdownTimeout = unit.toNanos(timeout);
/*      */     
/*  663 */     if (ensureThreadStarted(oldState)) {
/*  664 */       return this.terminationFuture;
/*      */     }
/*      */     
/*  667 */     if (wakeup) {
/*  668 */       this.taskQueue.offer(WAKEUP_TASK);
/*  669 */       if (!this.addTaskWakesUp) {
/*  670 */         wakeup(inEventLoop);
/*      */       }
/*      */     } 
/*      */     
/*  674 */     return terminationFuture();
/*      */   }
/*      */ 
/*      */   
/*      */   public Future<?> terminationFuture() {
/*  679 */     return this.terminationFuture;
/*      */   }
/*      */   @Deprecated
/*      */   public void shutdown() {
/*      */     boolean wakeup;
/*      */     int oldState, newState;
/*  685 */     if (isShutdown()) {
/*      */       return;
/*      */     }
/*      */     
/*  689 */     boolean inEventLoop = inEventLoop();
/*      */ 
/*      */     
/*      */     do {
/*  693 */       if (isShuttingDown()) {
/*      */         return;
/*      */       }
/*      */       
/*  697 */       wakeup = true;
/*  698 */       oldState = this.state;
/*  699 */       if (inEventLoop) {
/*  700 */         newState = 4;
/*      */       } else {
/*  702 */         switch (oldState) {
/*      */           case 1:
/*      */           case 2:
/*      */           case 3:
/*  706 */             newState = 4;
/*      */             break;
/*      */           default:
/*  709 */             newState = oldState;
/*  710 */             wakeup = false; break;
/*      */         } 
/*      */       } 
/*  713 */     } while (!STATE_UPDATER.compareAndSet(this, oldState, newState));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  718 */     if (ensureThreadStarted(oldState)) {
/*      */       return;
/*      */     }
/*      */     
/*  722 */     if (wakeup) {
/*  723 */       this.taskQueue.offer(WAKEUP_TASK);
/*  724 */       if (!this.addTaskWakesUp) {
/*  725 */         wakeup(inEventLoop);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isShuttingDown() {
/*  732 */     return (this.state >= 3);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isShutdown() {
/*  737 */     return (this.state >= 4);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTerminated() {
/*  742 */     return (this.state == 5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean confirmShutdown() {
/*  749 */     if (!isShuttingDown()) {
/*  750 */       return false;
/*      */     }
/*      */     
/*  753 */     if (!inEventLoop()) {
/*  754 */       throw new IllegalStateException("must be invoked from an event loop");
/*      */     }
/*      */     
/*  757 */     cancelScheduledTasks();
/*      */     
/*  759 */     if (this.gracefulShutdownStartTime == 0L) {
/*  760 */       this.gracefulShutdownStartTime = getCurrentTimeNanos();
/*      */     }
/*      */     
/*  763 */     if (runAllTasks() || runShutdownHooks()) {
/*  764 */       if (isShutdown())
/*      */       {
/*  766 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  772 */       if (this.gracefulShutdownQuietPeriod == 0L) {
/*  773 */         return true;
/*      */       }
/*  775 */       this.taskQueue.offer(WAKEUP_TASK);
/*  776 */       return false;
/*      */     } 
/*      */     
/*  779 */     long nanoTime = getCurrentTimeNanos();
/*      */     
/*  781 */     if (isShutdown() || nanoTime - this.gracefulShutdownStartTime > this.gracefulShutdownTimeout) {
/*  782 */       return true;
/*      */     }
/*      */     
/*  785 */     if (nanoTime - this.lastExecutionTime <= this.gracefulShutdownQuietPeriod) {
/*      */ 
/*      */       
/*  788 */       this.taskQueue.offer(WAKEUP_TASK);
/*      */       try {
/*  790 */         Thread.sleep(100L);
/*  791 */       } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */ 
/*      */       
/*  795 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  800 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/*  805 */     ObjectUtil.checkNotNull(unit, "unit");
/*  806 */     if (inEventLoop()) {
/*  807 */       throw new IllegalStateException("cannot await termination of the current thread");
/*      */     }
/*      */     
/*  810 */     this.threadLock.await(timeout, unit);
/*      */     
/*  812 */     return isTerminated();
/*      */   }
/*      */ 
/*      */   
/*      */   public void execute(Runnable task) {
/*  817 */     execute0(task);
/*      */   }
/*      */ 
/*      */   
/*      */   public void lazyExecute(Runnable task) {
/*  822 */     lazyExecute0(task);
/*      */   }
/*      */   
/*      */   private void execute0(@Schedule Runnable task) {
/*  826 */     ObjectUtil.checkNotNull(task, "task");
/*  827 */     execute(task, wakesUpForTask(task));
/*      */   }
/*      */   
/*      */   private void lazyExecute0(@Schedule Runnable task) {
/*  831 */     execute((Runnable)ObjectUtil.checkNotNull(task, "task"), false);
/*      */   }
/*      */   
/*      */   private void execute(Runnable task, boolean immediate) {
/*  835 */     boolean inEventLoop = inEventLoop();
/*  836 */     addTask(task);
/*  837 */     if (!inEventLoop) {
/*  838 */       startThread();
/*  839 */       if (isShutdown()) {
/*  840 */         boolean reject = false;
/*      */         try {
/*  842 */           if (removeTask(task)) {
/*  843 */             reject = true;
/*      */           }
/*  845 */         } catch (UnsupportedOperationException unsupportedOperationException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  850 */         if (reject) {
/*  851 */           reject();
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  856 */     if (!this.addTaskWakesUp && immediate) {
/*  857 */       wakeup(inEventLoop);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
/*  863 */     throwIfInEventLoop("invokeAny");
/*  864 */     return super.invokeAny(tasks);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/*  870 */     throwIfInEventLoop("invokeAny");
/*  871 */     return super.invokeAny(tasks, timeout, unit);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
/*  877 */     throwIfInEventLoop("invokeAll");
/*  878 */     return super.invokeAll(tasks);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
/*  884 */     throwIfInEventLoop("invokeAll");
/*  885 */     return super.invokeAll(tasks, timeout, unit);
/*      */   }
/*      */   
/*      */   private void throwIfInEventLoop(String method) {
/*  889 */     if (inEventLoop()) {
/*  890 */       throw new RejectedExecutionException("Calling " + method + " from within the EventLoop is not allowed");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ThreadProperties threadProperties() {
/*  900 */     ThreadProperties threadProperties = this.threadProperties;
/*  901 */     if (threadProperties == null) {
/*  902 */       Thread thread = this.thread;
/*  903 */       if (thread == null) {
/*  904 */         assert !inEventLoop();
/*  905 */         submit(NOOP_TASK).syncUninterruptibly();
/*  906 */         thread = this.thread;
/*  907 */         assert thread != null;
/*      */       } 
/*      */       
/*  910 */       threadProperties = new DefaultThreadProperties(thread);
/*  911 */       if (!PROPERTIES_UPDATER.compareAndSet(this, null, threadProperties)) {
/*  912 */         threadProperties = this.threadProperties;
/*      */       }
/*      */     } 
/*      */     
/*  916 */     return threadProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean wakesUpForTask(Runnable task) {
/*  930 */     return true;
/*      */   }
/*      */   
/*      */   protected static void reject() {
/*  934 */     throw new RejectedExecutionException("event executor terminated");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void reject(Runnable task) {
/*  943 */     this.rejectedExecutionHandler.rejected(task, this);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  948 */   private static final long SCHEDULE_PURGE_INTERVAL = TimeUnit.SECONDS.toNanos(1L);
/*      */   
/*      */   private void startThread() {
/*  951 */     if (this.state == 1 && 
/*  952 */       STATE_UPDATER.compareAndSet(this, 1, 2)) {
/*  953 */       boolean success = false;
/*      */       try {
/*  955 */         doStartThread();
/*  956 */         success = true;
/*      */       } finally {
/*  958 */         if (!success) {
/*  959 */           STATE_UPDATER.compareAndSet(this, 2, 1);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean ensureThreadStarted(int oldState) {
/*  967 */     if (oldState == 1) {
/*      */       try {
/*  969 */         doStartThread();
/*  970 */       } catch (Throwable cause) {
/*  971 */         STATE_UPDATER.set(this, 5);
/*  972 */         this.terminationFuture.tryFailure(cause);
/*      */         
/*  974 */         if (!(cause instanceof Exception))
/*      */         {
/*  976 */           PlatformDependent.throwException(cause);
/*      */         }
/*  978 */         return true;
/*      */       } 
/*      */     }
/*  981 */     return false;
/*      */   }
/*      */   
/*      */   private void doStartThread() {
/*  985 */     assert this.thread == null;
/*  986 */     this.executor.execute(new Runnable()
/*      */         {
/*      */           public void run() {
/*  989 */             SingleThreadEventExecutor.this.thread = Thread.currentThread();
/*  990 */             if (SingleThreadEventExecutor.this.interrupted) {
/*  991 */               SingleThreadEventExecutor.this.thread.interrupt();
/*      */             }
/*      */             
/*  994 */             boolean success = false;
/*  995 */             SingleThreadEventExecutor.this.updateLastExecutionTime();
/*      */             try {
/*  997 */               SingleThreadEventExecutor.this.run();
/*  998 */               success = true;
/*  999 */             } catch (Throwable t) {
/* 1000 */               SingleThreadEventExecutor.logger.warn("Unexpected exception from an event executor: ", t);
/*      */             } finally {
/*      */               int oldState; do {
/* 1003 */                 oldState = SingleThreadEventExecutor.this.state;
/* 1004 */               } while (oldState < 3 && !SingleThreadEventExecutor.STATE_UPDATER.compareAndSet(SingleThreadEventExecutor.this, oldState, 3));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1011 */               if (success && SingleThreadEventExecutor.this.gracefulShutdownStartTime == 0L && SingleThreadEventExecutor
/* 1012 */                 .logger.isErrorEnabled()) {
/* 1013 */                 SingleThreadEventExecutor.logger.error("Buggy " + EventExecutor.class.getSimpleName() + " implementation; " + SingleThreadEventExecutor.class
/* 1014 */                     .getSimpleName() + ".confirmShutdown() must be called before run() implementation terminates.");
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               try {
/*      */                 do {
/*      */                 
/* 1024 */                 } while (!SingleThreadEventExecutor.this.confirmShutdown());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 do {
/* 1032 */                   oldState = SingleThreadEventExecutor.this.state;
/* 1033 */                 } while (oldState < 4 && !SingleThreadEventExecutor.STATE_UPDATER.compareAndSet(SingleThreadEventExecutor.this, oldState, 4));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1041 */                 SingleThreadEventExecutor.this.confirmShutdown();
/*      */               } finally {
/*      */                 try {
/* 1044 */                   SingleThreadEventExecutor.this.cleanup();
/*      */                 
/*      */                 }
/*      */                 finally {
/*      */ 
/*      */                   
/* 1050 */                   FastThreadLocal.removeAll();
/*      */                   
/* 1052 */                   SingleThreadEventExecutor.STATE_UPDATER.set(SingleThreadEventExecutor.this, 5);
/* 1053 */                   SingleThreadEventExecutor.this.threadLock.countDown();
/* 1054 */                   int numUserTasks = SingleThreadEventExecutor.this.drainTasks();
/* 1055 */                   if (numUserTasks > 0 && SingleThreadEventExecutor.logger.isWarnEnabled()) {
/* 1056 */                     SingleThreadEventExecutor.logger.warn("An event executor terminated with non-empty task queue (" + numUserTasks + ')');
/*      */                   }
/*      */                   
/* 1059 */                   SingleThreadEventExecutor.this.terminationFuture.setSuccess(null);
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           }
/*      */         });
/*      */   }
/*      */   protected abstract void run();
/*      */   final int drainTasks() {
/* 1068 */     int numTasks = 0;
/*      */     while (true) {
/* 1070 */       Runnable runnable = this.taskQueue.poll();
/* 1071 */       if (runnable == null) {
/*      */         break;
/*      */       }
/*      */ 
/*      */       
/* 1076 */       if (WAKEUP_TASK != runnable) {
/* 1077 */         numTasks++;
/*      */       }
/*      */     } 
/* 1080 */     return numTasks;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected static interface NonWakeupRunnable extends AbstractEventExecutor.LazyRunnable {}
/*      */   
/*      */   private static final class DefaultThreadProperties implements ThreadProperties { DefaultThreadProperties(Thread t) {
/* 1087 */       this.t = t;
/*      */     }
/*      */     private final Thread t;
/*      */     
/*      */     public Thread.State state() {
/* 1092 */       return this.t.getState();
/*      */     }
/*      */ 
/*      */     
/*      */     public int priority() {
/* 1097 */       return this.t.getPriority();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isInterrupted() {
/* 1102 */       return this.t.isInterrupted();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDaemon() {
/* 1107 */       return this.t.isDaemon();
/*      */     }
/*      */ 
/*      */     
/*      */     public String name() {
/* 1112 */       return this.t.getName();
/*      */     }
/*      */ 
/*      */     
/*      */     public long id() {
/* 1117 */       return this.t.getId();
/*      */     }
/*      */ 
/*      */     
/*      */     public StackTraceElement[] stackTrace() {
/* 1122 */       return this.t.getStackTrace();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isAlive() {
/* 1127 */       return this.t.isAlive();
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\SingleThreadEventExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */