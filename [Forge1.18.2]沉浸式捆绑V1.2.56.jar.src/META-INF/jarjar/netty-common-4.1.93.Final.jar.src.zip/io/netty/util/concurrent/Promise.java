package io.netty.util.concurrent;

public interface Promise<V> extends Future<V> {
  Promise<V> setSuccess(V paramV);
  
  boolean trySuccess(V paramV);
  
  Promise<V> setFailure(Throwable paramThrowable);
  
  boolean tryFailure(Throwable paramThrowable);
  
  boolean setUncancellable();
  
  Promise<V> addListener(GenericFutureListener<? extends Future<? super V>> paramGenericFutureListener);
  
  Promise<V> addListeners(GenericFutureListener<? extends Future<? super V>>... paramVarArgs);
  
  Promise<V> removeListener(GenericFutureListener<? extends Future<? super V>> paramGenericFutureListener);
  
  Promise<V> removeListeners(GenericFutureListener<? extends Future<? super V>>... paramVarArgs);
  
  Promise<V> await() throws InterruptedException;
  
  Promise<V> awaitUninterruptibly();
  
  Promise<V> sync() throws InterruptedException;
  
  Promise<V> syncUninterruptibly();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\Promise.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */