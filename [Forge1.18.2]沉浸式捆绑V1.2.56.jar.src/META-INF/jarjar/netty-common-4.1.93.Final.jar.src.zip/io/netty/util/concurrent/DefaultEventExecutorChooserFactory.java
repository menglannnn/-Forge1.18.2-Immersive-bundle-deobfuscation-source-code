/*    */ package io.netty.util.concurrent;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultEventExecutorChooserFactory
/*    */   implements EventExecutorChooserFactory
/*    */ {
/* 29 */   public static final DefaultEventExecutorChooserFactory INSTANCE = new DefaultEventExecutorChooserFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EventExecutorChooserFactory.EventExecutorChooser newChooser(EventExecutor[] executors) {
/* 35 */     if (isPowerOfTwo(executors.length)) {
/* 36 */       return new PowerOfTwoEventExecutorChooser(executors);
/*    */     }
/* 38 */     return new GenericEventExecutorChooser(executors);
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean isPowerOfTwo(int val) {
/* 43 */     return ((val & -val) == val);
/*    */   }
/*    */   
/*    */   private static final class PowerOfTwoEventExecutorChooser implements EventExecutorChooserFactory.EventExecutorChooser {
/* 47 */     private final AtomicInteger idx = new AtomicInteger();
/*    */     private final EventExecutor[] executors;
/*    */     
/*    */     PowerOfTwoEventExecutorChooser(EventExecutor[] executors) {
/* 51 */       this.executors = executors;
/*    */     }
/*    */ 
/*    */     
/*    */     public EventExecutor next() {
/* 56 */       return this.executors[this.idx.getAndIncrement() & this.executors.length - 1];
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private static final class GenericEventExecutorChooser
/*    */     implements EventExecutorChooserFactory.EventExecutorChooser
/*    */   {
/* 64 */     private final AtomicLong idx = new AtomicLong();
/*    */     private final EventExecutor[] executors;
/*    */     
/*    */     GenericEventExecutorChooser(EventExecutor[] executors) {
/* 68 */       this.executors = executors;
/*    */     }
/*    */ 
/*    */     
/*    */     public EventExecutor next() {
/* 73 */       return this.executors[(int)Math.abs(this.idx.getAndIncrement() % this.executors.length)];
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\DefaultEventExecutorChooserFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */