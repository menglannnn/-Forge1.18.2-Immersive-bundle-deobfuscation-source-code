/*     */ package io.netty.util.concurrent;
/*     */ 
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Delayed;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.RunnableScheduledFuture;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnorderedThreadPoolEventExecutor
/*     */   extends ScheduledThreadPoolExecutor
/*     */   implements EventExecutor
/*     */ {
/*  44 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(UnorderedThreadPoolEventExecutor.class);
/*     */ 
/*     */   
/*  47 */   private final Promise<?> terminationFuture = GlobalEventExecutor.INSTANCE.newPromise();
/*  48 */   private final Set<EventExecutor> executorSet = Collections.singleton(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnorderedThreadPoolEventExecutor(int corePoolSize) {
/*  55 */     this(corePoolSize, new DefaultThreadFactory(UnorderedThreadPoolEventExecutor.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnorderedThreadPoolEventExecutor(int corePoolSize, ThreadFactory threadFactory) {
/*  62 */     super(corePoolSize, threadFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnorderedThreadPoolEventExecutor(int corePoolSize, RejectedExecutionHandler handler) {
/*  70 */     this(corePoolSize, new DefaultThreadFactory(UnorderedThreadPoolEventExecutor.class), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnorderedThreadPoolEventExecutor(int corePoolSize, ThreadFactory threadFactory, RejectedExecutionHandler handler) {
/*  78 */     super(corePoolSize, threadFactory, handler);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventExecutor next() {
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public EventExecutorGroup parent() {
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inEventLoop() {
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inEventLoop(Thread thread) {
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> Promise<V> newPromise() {
/* 103 */     return new DefaultPromise<V>(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> ProgressivePromise<V> newProgressivePromise() {
/* 108 */     return new DefaultProgressivePromise<V>(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> Future<V> newSucceededFuture(V result) {
/* 113 */     return new SucceededFuture<V>(this, result);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> Future<V> newFailedFuture(Throwable cause) {
/* 118 */     return new FailedFuture<V>(this, cause);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShuttingDown() {
/* 123 */     return isShutdown();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Runnable> shutdownNow() {
/* 128 */     List<Runnable> tasks = super.shutdownNow();
/* 129 */     this.terminationFuture.trySuccess(null);
/* 130 */     return tasks;
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 135 */     super.shutdown();
/* 136 */     this.terminationFuture.trySuccess(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> shutdownGracefully() {
/* 141 */     return shutdownGracefully(2L, 15L, TimeUnit.SECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Future<?> shutdownGracefully(long quietPeriod, long timeout, TimeUnit unit) {
/* 148 */     shutdown();
/* 149 */     return terminationFuture();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> terminationFuture() {
/* 154 */     return this.terminationFuture;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<EventExecutor> iterator() {
/* 159 */     return this.executorSet.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   protected <V> RunnableScheduledFuture<V> decorateTask(Runnable runnable, RunnableScheduledFuture<V> task) {
/* 164 */     return (runnable instanceof NonNotifyRunnable) ? task : new RunnableScheduledFutureTask<V>(this, task, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected <V> RunnableScheduledFuture<V> decorateTask(Callable<V> callable, RunnableScheduledFuture<V> task) {
/* 170 */     return new RunnableScheduledFutureTask<V>(this, task, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
/* 175 */     return (ScheduledFuture)super.schedule(command, delay, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
/* 180 */     return (ScheduledFuture<V>)super.<V>schedule(callable, delay, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
/* 185 */     return (ScheduledFuture)super.scheduleAtFixedRate(command, initialDelay, period, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
/* 190 */     return (ScheduledFuture)super.scheduleWithFixedDelay(command, initialDelay, delay, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> submit(Runnable task) {
/* 195 */     return (Future)super.submit(task);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Runnable task, T result) {
/* 200 */     return (Future<T>)super.<T>submit(task, result);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 205 */     return (Future<T>)super.<T>submit(task);
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(Runnable command) {
/* 210 */     super.schedule(new NonNotifyRunnable(command), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */   
/*     */   private static final class RunnableScheduledFutureTask<V>
/*     */     extends PromiseTask<V> implements RunnableScheduledFuture<V>, ScheduledFuture<V> {
/*     */     private final RunnableScheduledFuture<V> future;
/*     */     private final boolean wasCallable;
/*     */     
/*     */     RunnableScheduledFutureTask(EventExecutor executor, RunnableScheduledFuture<V> future, boolean wasCallable) {
/* 219 */       super(executor, future);
/* 220 */       this.future = future;
/* 221 */       this.wasCallable = wasCallable;
/*     */     }
/*     */ 
/*     */     
/*     */     V runTask() throws Throwable {
/* 226 */       V result = super.runTask();
/* 227 */       if (result == null && this.wasCallable) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 232 */         assert this.future.isDone();
/*     */         try {
/* 234 */           return this.future.get();
/* 235 */         } catch (ExecutionException e) {
/*     */           
/* 237 */           throw e.getCause();
/*     */         } 
/*     */       } 
/* 240 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 245 */       if (!isPeriodic()) {
/* 246 */         super.run();
/* 247 */       } else if (!isDone()) {
/*     */         
/*     */         try {
/* 250 */           runTask();
/* 251 */         } catch (Throwable cause) {
/* 252 */           if (!tryFailureInternal(cause)) {
/* 253 */             UnorderedThreadPoolEventExecutor.logger.warn("Failure during execution of task", cause);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isPeriodic() {
/* 261 */       return this.future.isPeriodic();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getDelay(TimeUnit unit) {
/* 266 */       return this.future.getDelay(unit);
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(Delayed o) {
/* 271 */       return this.future.compareTo(o);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class NonNotifyRunnable
/*     */     implements Runnable
/*     */   {
/*     */     private final Runnable task;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     NonNotifyRunnable(Runnable task) {
/* 287 */       this.task = task;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 292 */       this.task.run();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\UnorderedThreadPoolEventExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */