package io.netty.util.concurrent;

public interface ProgressiveFuture<V> extends Future<V> {
  ProgressiveFuture<V> addListener(GenericFutureListener<? extends Future<? super V>> paramGenericFutureListener);
  
  ProgressiveFuture<V> addListeners(GenericFutureListener<? extends Future<? super V>>... paramVarArgs);
  
  ProgressiveFuture<V> removeListener(GenericFutureListener<? extends Future<? super V>> paramGenericFutureListener);
  
  ProgressiveFuture<V> removeListeners(GenericFutureListener<? extends Future<? super V>>... paramVarArgs);
  
  ProgressiveFuture<V> sync() throws InterruptedException;
  
  ProgressiveFuture<V> syncUninterruptibly();
  
  ProgressiveFuture<V> await() throws InterruptedException;
  
  ProgressiveFuture<V> awaitUninterruptibly();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\ProgressiveFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */