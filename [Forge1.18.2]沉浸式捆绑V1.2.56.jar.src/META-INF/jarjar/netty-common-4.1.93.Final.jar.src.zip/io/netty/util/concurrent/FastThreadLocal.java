/*     */ package io.netty.util.concurrent;
/*     */ 
/*     */ import io.netty.util.internal.InternalThreadLocalMap;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.util.Collections;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastThreadLocal<V>
/*     */ {
/*     */   private final int index;
/*     */   
/*     */   public static void removeAll() {
/*  54 */     InternalThreadLocalMap threadLocalMap = InternalThreadLocalMap.getIfSet();
/*  55 */     if (threadLocalMap == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  60 */       Object v = threadLocalMap.indexedVariable(InternalThreadLocalMap.VARIABLES_TO_REMOVE_INDEX);
/*  61 */       if (v != null && v != InternalThreadLocalMap.UNSET) {
/*     */         
/*  63 */         Set<FastThreadLocal<?>> variablesToRemove = (Set<FastThreadLocal<?>>)v;
/*     */         
/*  65 */         FastThreadLocal[] arrayOfFastThreadLocal = variablesToRemove.<FastThreadLocal>toArray(new FastThreadLocal[0]);
/*  66 */         for (FastThreadLocal<?> tlv : arrayOfFastThreadLocal) {
/*  67 */           tlv.remove(threadLocalMap);
/*     */         }
/*     */       } 
/*     */     } finally {
/*  71 */       InternalThreadLocalMap.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int size() {
/*  79 */     InternalThreadLocalMap threadLocalMap = InternalThreadLocalMap.getIfSet();
/*  80 */     if (threadLocalMap == null) {
/*  81 */       return 0;
/*     */     }
/*  83 */     return threadLocalMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void destroy() {
/*  94 */     InternalThreadLocalMap.destroy();
/*     */   }
/*     */   
/*     */   private static void addToVariablesToRemove(InternalThreadLocalMap threadLocalMap, FastThreadLocal<?> variable) {
/*     */     Set<FastThreadLocal<?>> variablesToRemove;
/*  99 */     Object v = threadLocalMap.indexedVariable(InternalThreadLocalMap.VARIABLES_TO_REMOVE_INDEX);
/*     */     
/* 101 */     if (v == InternalThreadLocalMap.UNSET || v == null) {
/* 102 */       variablesToRemove = Collections.newSetFromMap(new IdentityHashMap<FastThreadLocal<?>, Boolean>());
/* 103 */       threadLocalMap.setIndexedVariable(InternalThreadLocalMap.VARIABLES_TO_REMOVE_INDEX, variablesToRemove);
/*     */     } else {
/* 105 */       variablesToRemove = (Set<FastThreadLocal<?>>)v;
/*     */     } 
/*     */     
/* 108 */     variablesToRemove.add(variable);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void removeFromVariablesToRemove(InternalThreadLocalMap threadLocalMap, FastThreadLocal<?> variable) {
/* 114 */     Object v = threadLocalMap.indexedVariable(InternalThreadLocalMap.VARIABLES_TO_REMOVE_INDEX);
/*     */     
/* 116 */     if (v == InternalThreadLocalMap.UNSET || v == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 121 */     Set<FastThreadLocal<?>> variablesToRemove = (Set<FastThreadLocal<?>>)v;
/* 122 */     variablesToRemove.remove(variable);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FastThreadLocal() {
/* 128 */     this.index = InternalThreadLocalMap.nextVariableIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V get() {
/* 136 */     InternalThreadLocalMap threadLocalMap = InternalThreadLocalMap.get();
/* 137 */     Object v = threadLocalMap.indexedVariable(this.index);
/* 138 */     if (v != InternalThreadLocalMap.UNSET) {
/* 139 */       return (V)v;
/*     */     }
/*     */     
/* 142 */     return initialize(threadLocalMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V getIfExists() {
/* 150 */     InternalThreadLocalMap threadLocalMap = InternalThreadLocalMap.getIfSet();
/* 151 */     if (threadLocalMap != null) {
/* 152 */       Object v = threadLocalMap.indexedVariable(this.index);
/* 153 */       if (v != InternalThreadLocalMap.UNSET) {
/* 154 */         return (V)v;
/*     */       }
/*     */     } 
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V get(InternalThreadLocalMap threadLocalMap) {
/* 166 */     Object v = threadLocalMap.indexedVariable(this.index);
/* 167 */     if (v != InternalThreadLocalMap.UNSET) {
/* 168 */       return (V)v;
/*     */     }
/*     */     
/* 171 */     return initialize(threadLocalMap);
/*     */   }
/*     */   
/*     */   private V initialize(InternalThreadLocalMap threadLocalMap) {
/* 175 */     V v = null;
/*     */     try {
/* 177 */       v = initialValue();
/* 178 */       if (v == InternalThreadLocalMap.UNSET) {
/* 179 */         throw new IllegalArgumentException("InternalThreadLocalMap.UNSET can not be initial value.");
/*     */       }
/* 181 */     } catch (Exception e) {
/* 182 */       PlatformDependent.throwException(e);
/*     */     } 
/*     */     
/* 185 */     threadLocalMap.setIndexedVariable(this.index, v);
/* 186 */     addToVariablesToRemove(threadLocalMap, this);
/* 187 */     return v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(V value) {
/* 194 */     if (value != InternalThreadLocalMap.UNSET) {
/* 195 */       InternalThreadLocalMap threadLocalMap = InternalThreadLocalMap.get();
/* 196 */       setKnownNotUnset(threadLocalMap, value);
/*     */     } else {
/* 198 */       remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(InternalThreadLocalMap threadLocalMap, V value) {
/* 206 */     if (value != InternalThreadLocalMap.UNSET) {
/* 207 */       setKnownNotUnset(threadLocalMap, value);
/*     */     } else {
/* 209 */       remove(threadLocalMap);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setKnownNotUnset(InternalThreadLocalMap threadLocalMap, V value) {
/* 217 */     if (threadLocalMap.setIndexedVariable(this.index, value)) {
/* 218 */       addToVariablesToRemove(threadLocalMap, this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSet() {
/* 226 */     return isSet(InternalThreadLocalMap.getIfSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSet(InternalThreadLocalMap threadLocalMap) {
/* 234 */     return (threadLocalMap != null && threadLocalMap.isIndexedVariableSet(this.index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void remove() {
/* 241 */     remove(InternalThreadLocalMap.getIfSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void remove(InternalThreadLocalMap threadLocalMap) {
/* 251 */     if (threadLocalMap == null) {
/*     */       return;
/*     */     }
/*     */     
/* 255 */     Object v = threadLocalMap.removeIndexedVariable(this.index);
/* 256 */     if (v != InternalThreadLocalMap.UNSET) {
/* 257 */       removeFromVariablesToRemove(threadLocalMap, this);
/*     */       try {
/* 259 */         onRemoval((V)v);
/* 260 */       } catch (Exception e) {
/* 261 */         PlatformDependent.throwException(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected V initialValue() throws Exception {
/* 270 */     return null;
/*     */   }
/*     */   
/*     */   protected void onRemoval(V value) throws Exception {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\FastThreadLocal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */