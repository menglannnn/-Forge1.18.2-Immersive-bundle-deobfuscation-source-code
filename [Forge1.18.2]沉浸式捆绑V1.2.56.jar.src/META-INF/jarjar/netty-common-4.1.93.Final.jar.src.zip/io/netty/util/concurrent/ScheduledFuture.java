package io.netty.util.concurrent;

import java.util.concurrent.ScheduledFuture;

public interface ScheduledFuture<V> extends Future<V>, ScheduledFuture<V> {}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\ScheduledFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */