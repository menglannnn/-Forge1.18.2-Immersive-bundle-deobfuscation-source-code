/*     */ package io.netty.util.concurrent;
/*     */ 
/*     */ import io.netty.util.internal.InternalThreadLocalMap;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import io.netty.util.internal.ThrowableUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.concurrent.CancellationException;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPromise<V>
/*     */   extends AbstractFuture<V>
/*     */   implements Promise<V>
/*     */ {
/*  36 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DefaultPromise.class);
/*     */   
/*  38 */   private static final InternalLogger rejectedExecutionLogger = InternalLoggerFactory.getInstance(DefaultPromise.class.getName() + ".rejectedExecution");
/*  39 */   private static final int MAX_LISTENER_STACK_DEPTH = Math.min(8, 
/*  40 */       SystemPropertyUtil.getInt("io.netty.defaultPromise.maxListenerStackDepth", 8));
/*     */ 
/*     */   
/*  43 */   private static final AtomicReferenceFieldUpdater<DefaultPromise, Object> RESULT_UPDATER = AtomicReferenceFieldUpdater.newUpdater(DefaultPromise.class, Object.class, "result");
/*  44 */   private static final Object SUCCESS = new Object();
/*  45 */   private static final Object UNCANCELLABLE = new Object();
/*  46 */   private static final CauseHolder CANCELLATION_CAUSE_HOLDER = new CauseHolder(
/*  47 */       StacklessCancellationException.newInstance(DefaultPromise.class, "cancel(...)"));
/*  48 */   private static final StackTraceElement[] CANCELLATION_STACK = CANCELLATION_CAUSE_HOLDER.cause.getStackTrace();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile Object result;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final EventExecutor executor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GenericFutureListener<? extends Future<?>> listener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DefaultFutureListeners listeners;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private short waiters;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean notifyingListeners;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPromise(EventExecutor executor) {
/*  84 */     this.executor = (EventExecutor)ObjectUtil.checkNotNull(executor, "executor");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultPromise() {
/*  92 */     this.executor = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> setSuccess(V result) {
/*  97 */     if (setSuccess0(result)) {
/*  98 */       return this;
/*     */     }
/* 100 */     throw new IllegalStateException("complete already: " + this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean trySuccess(V result) {
/* 105 */     return setSuccess0(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> setFailure(Throwable cause) {
/* 110 */     if (setFailure0(cause)) {
/* 111 */       return this;
/*     */     }
/* 113 */     throw new IllegalStateException("complete already: " + this, cause);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean tryFailure(Throwable cause) {
/* 118 */     return setFailure0(cause);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setUncancellable() {
/* 123 */     if (RESULT_UPDATER.compareAndSet(this, null, UNCANCELLABLE)) {
/* 124 */       return true;
/*     */     }
/* 126 */     Object result = this.result;
/* 127 */     return (!isDone0(result) || !isCancelled0(result));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuccess() {
/* 132 */     Object result = this.result;
/* 133 */     return (result != null && result != UNCANCELLABLE && !(result instanceof CauseHolder));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCancellable() {
/* 138 */     return (this.result == null);
/*     */   }
/*     */   
/*     */   private static final class LeanCancellationException extends CancellationException {
/*     */     private static final long serialVersionUID = 2794674970981187807L;
/*     */     
/*     */     private LeanCancellationException() {}
/*     */     
/*     */     public Throwable fillInStackTrace() {
/* 147 */       setStackTrace(DefaultPromise.CANCELLATION_STACK);
/* 148 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 153 */       return CancellationException.class.getName();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable cause() {
/* 159 */     return cause0(this.result);
/*     */   }
/*     */   
/*     */   private Throwable cause0(Object result) {
/* 163 */     if (!(result instanceof CauseHolder)) {
/* 164 */       return null;
/*     */     }
/* 166 */     if (result == CANCELLATION_CAUSE_HOLDER) {
/* 167 */       CancellationException ce = new LeanCancellationException();
/* 168 */       if (RESULT_UPDATER.compareAndSet(this, CANCELLATION_CAUSE_HOLDER, new CauseHolder(ce))) {
/* 169 */         return ce;
/*     */       }
/* 171 */       result = this.result;
/*     */     } 
/* 173 */     return ((CauseHolder)result).cause;
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> addListener(GenericFutureListener<? extends Future<? super V>> listener) {
/* 178 */     ObjectUtil.checkNotNull(listener, "listener");
/*     */     
/* 180 */     synchronized (this) {
/* 181 */       addListener0(listener);
/*     */     } 
/*     */     
/* 184 */     if (isDone()) {
/* 185 */       notifyListeners();
/*     */     }
/*     */     
/* 188 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> addListeners(GenericFutureListener<? extends Future<? super V>>... listeners) {
/* 193 */     ObjectUtil.checkNotNull(listeners, "listeners");
/*     */     
/* 195 */     synchronized (this) {
/* 196 */       for (GenericFutureListener<? extends Future<? super V>> listener : listeners) {
/* 197 */         if (listener == null) {
/*     */           break;
/*     */         }
/* 200 */         addListener0(listener);
/*     */       } 
/*     */     } 
/*     */     
/* 204 */     if (isDone()) {
/* 205 */       notifyListeners();
/*     */     }
/*     */     
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> removeListener(GenericFutureListener<? extends Future<? super V>> listener) {
/* 213 */     ObjectUtil.checkNotNull(listener, "listener");
/*     */     
/* 215 */     synchronized (this) {
/* 216 */       removeListener0(listener);
/*     */     } 
/*     */     
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> removeListeners(GenericFutureListener<? extends Future<? super V>>... listeners) {
/* 224 */     ObjectUtil.checkNotNull(listeners, "listeners");
/*     */     
/* 226 */     synchronized (this) {
/* 227 */       for (GenericFutureListener<? extends Future<? super V>> listener : listeners) {
/* 228 */         if (listener == null) {
/*     */           break;
/*     */         }
/* 231 */         removeListener0(listener);
/*     */       } 
/*     */     } 
/*     */     
/* 235 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> await() throws InterruptedException {
/* 240 */     if (isDone()) {
/* 241 */       return this;
/*     */     }
/*     */     
/* 244 */     if (Thread.interrupted()) {
/* 245 */       throw new InterruptedException(toString());
/*     */     }
/*     */     
/* 248 */     checkDeadLock();
/*     */     
/* 250 */     synchronized (this) {
/* 251 */       while (!isDone()) {
/* 252 */         incWaiters();
/*     */         try {
/* 254 */           wait();
/*     */         } finally {
/* 256 */           decWaiters();
/*     */         } 
/*     */       } 
/*     */     } 
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> awaitUninterruptibly() {
/* 265 */     if (isDone()) {
/* 266 */       return this;
/*     */     }
/*     */     
/* 269 */     checkDeadLock();
/*     */     
/* 271 */     boolean interrupted = false;
/* 272 */     synchronized (this) {
/* 273 */       while (!isDone()) {
/* 274 */         incWaiters();
/*     */         try {
/* 276 */           wait();
/* 277 */         } catch (InterruptedException e) {
/*     */           
/* 279 */           interrupted = true;
/*     */         } finally {
/* 281 */           decWaiters();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 286 */     if (interrupted) {
/* 287 */       Thread.currentThread().interrupt();
/*     */     }
/*     */     
/* 290 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean await(long timeout, TimeUnit unit) throws InterruptedException {
/* 295 */     return await0(unit.toNanos(timeout), true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean await(long timeoutMillis) throws InterruptedException {
/* 300 */     return await0(TimeUnit.MILLISECONDS.toNanos(timeoutMillis), true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean awaitUninterruptibly(long timeout, TimeUnit unit) {
/*     */     try {
/* 306 */       return await0(unit.toNanos(timeout), false);
/* 307 */     } catch (InterruptedException e) {
/*     */       
/* 309 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean awaitUninterruptibly(long timeoutMillis) {
/*     */     try {
/* 316 */       return await0(TimeUnit.MILLISECONDS.toNanos(timeoutMillis), false);
/* 317 */     } catch (InterruptedException e) {
/*     */       
/* 319 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V getNow() {
/* 326 */     Object result = this.result;
/* 327 */     if (result instanceof CauseHolder || result == SUCCESS || result == UNCANCELLABLE) {
/* 328 */       return null;
/*     */     }
/* 330 */     return (V)result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V get() throws InterruptedException, ExecutionException {
/* 336 */     Object result = this.result;
/* 337 */     if (!isDone0(result)) {
/* 338 */       await();
/* 339 */       result = this.result;
/*     */     } 
/* 341 */     if (result == SUCCESS || result == UNCANCELLABLE) {
/* 342 */       return null;
/*     */     }
/* 344 */     Throwable cause = cause0(result);
/* 345 */     if (cause == null) {
/* 346 */       return (V)result;
/*     */     }
/* 348 */     if (cause instanceof CancellationException) {
/* 349 */       throw (CancellationException)cause;
/*     */     }
/* 351 */     throw new ExecutionException(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 357 */     Object result = this.result;
/* 358 */     if (!isDone0(result)) {
/* 359 */       if (!await(timeout, unit)) {
/* 360 */         throw new TimeoutException();
/*     */       }
/* 362 */       result = this.result;
/*     */     } 
/* 364 */     if (result == SUCCESS || result == UNCANCELLABLE) {
/* 365 */       return null;
/*     */     }
/* 367 */     Throwable cause = cause0(result);
/* 368 */     if (cause == null) {
/* 369 */       return (V)result;
/*     */     }
/* 371 */     if (cause instanceof CancellationException) {
/* 372 */       throw (CancellationException)cause;
/*     */     }
/* 374 */     throw new ExecutionException(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cancel(boolean mayInterruptIfRunning) {
/* 384 */     if (RESULT_UPDATER.compareAndSet(this, null, CANCELLATION_CAUSE_HOLDER)) {
/* 385 */       if (checkNotifyWaiters()) {
/* 386 */         notifyListeners();
/*     */       }
/* 388 */       return true;
/*     */     } 
/* 390 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCancelled() {
/* 395 */     return isCancelled0(this.result);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/* 400 */     return isDone0(this.result);
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> sync() throws InterruptedException {
/* 405 */     await();
/* 406 */     rethrowIfFailed();
/* 407 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Promise<V> syncUninterruptibly() {
/* 412 */     awaitUninterruptibly();
/* 413 */     rethrowIfFailed();
/* 414 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 419 */     return toStringBuilder().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringBuilder toStringBuilder() {
/* 426 */     StringBuilder buf = (new StringBuilder(64)).append(StringUtil.simpleClassName(this)).append('@').append(Integer.toHexString(hashCode()));
/*     */     
/* 428 */     Object result = this.result;
/* 429 */     if (result == SUCCESS) {
/* 430 */       buf.append("(success)");
/* 431 */     } else if (result == UNCANCELLABLE) {
/* 432 */       buf.append("(uncancellable)");
/* 433 */     } else if (result instanceof CauseHolder) {
/* 434 */       buf.append("(failure: ")
/* 435 */         .append(((CauseHolder)result).cause)
/* 436 */         .append(')');
/* 437 */     } else if (result != null) {
/* 438 */       buf.append("(success: ")
/* 439 */         .append(result)
/* 440 */         .append(')');
/*     */     } else {
/* 442 */       buf.append("(incomplete)");
/*     */     } 
/*     */     
/* 445 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EventExecutor executor() {
/* 457 */     return this.executor;
/*     */   }
/*     */   
/*     */   protected void checkDeadLock() {
/* 461 */     EventExecutor e = executor();
/* 462 */     if (e != null && e.inEventLoop()) {
/* 463 */       throw new BlockingOperationException(toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void notifyListener(EventExecutor eventExecutor, Future<?> future, GenericFutureListener<?> listener) {
/* 478 */     notifyListenerWithStackOverFlowProtection(
/* 479 */         (EventExecutor)ObjectUtil.checkNotNull(eventExecutor, "eventExecutor"), 
/* 480 */         (Future)ObjectUtil.checkNotNull(future, "future"), 
/* 481 */         (GenericFutureListener)ObjectUtil.checkNotNull(listener, "listener"));
/*     */   }
/*     */   
/*     */   private void notifyListeners() {
/* 485 */     EventExecutor executor = executor();
/* 486 */     if (executor.inEventLoop()) {
/* 487 */       InternalThreadLocalMap threadLocals = InternalThreadLocalMap.get();
/* 488 */       int stackDepth = threadLocals.futureListenerStackDepth();
/* 489 */       if (stackDepth < MAX_LISTENER_STACK_DEPTH) {
/* 490 */         threadLocals.setFutureListenerStackDepth(stackDepth + 1);
/*     */         try {
/* 492 */           notifyListenersNow();
/*     */         } finally {
/* 494 */           threadLocals.setFutureListenerStackDepth(stackDepth);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 500 */     safeExecute(executor, new Runnable()
/*     */         {
/*     */           public void run() {
/* 503 */             DefaultPromise.this.notifyListenersNow();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void notifyListenerWithStackOverFlowProtection(EventExecutor executor, final Future<?> future, final GenericFutureListener<?> listener) {
/* 516 */     if (executor.inEventLoop()) {
/* 517 */       InternalThreadLocalMap threadLocals = InternalThreadLocalMap.get();
/* 518 */       int stackDepth = threadLocals.futureListenerStackDepth();
/* 519 */       if (stackDepth < MAX_LISTENER_STACK_DEPTH) {
/* 520 */         threadLocals.setFutureListenerStackDepth(stackDepth + 1);
/*     */         try {
/* 522 */           notifyListener0(future, listener);
/*     */         } finally {
/* 524 */           threadLocals.setFutureListenerStackDepth(stackDepth);
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 530 */     safeExecute(executor, new Runnable()
/*     */         {
/*     */           public void run() {
/* 533 */             DefaultPromise.notifyListener0(future, listener);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void notifyListenersNow() {
/*     */     GenericFutureListener<? extends Future<?>> listener;
/*     */     DefaultFutureListeners listeners;
/* 541 */     synchronized (this) {
/* 542 */       listener = this.listener;
/* 543 */       listeners = this.listeners;
/*     */       
/* 545 */       if (this.notifyingListeners || (listener == null && listeners == null)) {
/*     */         return;
/*     */       }
/* 548 */       this.notifyingListeners = true;
/* 549 */       if (listener != null) {
/* 550 */         this.listener = null;
/*     */       } else {
/* 552 */         this.listeners = null;
/*     */       } 
/*     */     } 
/*     */     while (true) {
/* 556 */       if (listener != null) {
/* 557 */         notifyListener0(this, listener);
/*     */       } else {
/* 559 */         notifyListeners0(listeners);
/*     */       } 
/* 561 */       synchronized (this) {
/* 562 */         if (this.listener == null && this.listeners == null) {
/*     */ 
/*     */           
/* 565 */           this.notifyingListeners = false;
/*     */           return;
/*     */         } 
/* 568 */         GenericFutureListener<? extends Future<?>> genericFutureListener = this.listener;
/* 569 */         listeners = this.listeners;
/* 570 */         if (genericFutureListener != null) {
/* 571 */           this.listener = null;
/*     */         } else {
/* 573 */           this.listeners = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void notifyListeners0(DefaultFutureListeners listeners) {
/* 580 */     GenericFutureListener[] arrayOfGenericFutureListener = (GenericFutureListener[])listeners.listeners();
/* 581 */     int size = listeners.size();
/* 582 */     for (int i = 0; i < size; i++) {
/* 583 */       notifyListener0(this, arrayOfGenericFutureListener[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void notifyListener0(Future future, GenericFutureListener<Future> l) {
/*     */     try {
/* 590 */       l.operationComplete(future);
/* 591 */     } catch (Throwable t) {
/* 592 */       if (logger.isWarnEnabled()) {
/* 593 */         logger.warn("An exception was thrown by " + l.getClass().getName() + ".operationComplete()", t);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addListener0(GenericFutureListener<? extends Future<? super V>> listener) {
/* 599 */     if (this.listener == null) {
/* 600 */       if (this.listeners == null) {
/* 601 */         this.listener = listener;
/*     */       } else {
/* 603 */         this.listeners.add(listener);
/*     */       } 
/*     */     } else {
/* 606 */       assert this.listeners == null;
/* 607 */       this.listeners = new DefaultFutureListeners(this.listener, listener);
/* 608 */       this.listener = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeListener0(GenericFutureListener<? extends Future<? super V>> toRemove) {
/* 613 */     if (this.listener == toRemove) {
/* 614 */       this.listener = null;
/* 615 */     } else if (this.listeners != null) {
/* 616 */       this.listeners.remove(toRemove);
/*     */       
/* 618 */       if (this.listeners.size() == 0) {
/* 619 */         this.listeners = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean setSuccess0(V result) {
/* 625 */     return setValue0((result == null) ? SUCCESS : result);
/*     */   }
/*     */   
/*     */   private boolean setFailure0(Throwable cause) {
/* 629 */     return setValue0(new CauseHolder((Throwable)ObjectUtil.checkNotNull(cause, "cause")));
/*     */   }
/*     */   
/*     */   private boolean setValue0(Object objResult) {
/* 633 */     if (RESULT_UPDATER.compareAndSet(this, null, objResult) || RESULT_UPDATER
/* 634 */       .compareAndSet(this, UNCANCELLABLE, objResult)) {
/* 635 */       if (checkNotifyWaiters()) {
/* 636 */         notifyListeners();
/*     */       }
/* 638 */       return true;
/*     */     } 
/* 640 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean checkNotifyWaiters() {
/* 648 */     if (this.waiters > 0) {
/* 649 */       notifyAll();
/*     */     }
/* 651 */     return (this.listener != null || this.listeners != null);
/*     */   }
/*     */   
/*     */   private void incWaiters() {
/* 655 */     if (this.waiters == Short.MAX_VALUE) {
/* 656 */       throw new IllegalStateException("too many waiters: " + this);
/*     */     }
/* 658 */     this.waiters = (short)(this.waiters + 1);
/*     */   }
/*     */   
/*     */   private void decWaiters() {
/* 662 */     this.waiters = (short)(this.waiters - 1);
/*     */   }
/*     */   
/*     */   private void rethrowIfFailed() {
/* 666 */     Throwable cause = cause();
/* 667 */     if (cause == null) {
/*     */       return;
/*     */     }
/*     */     
/* 671 */     PlatformDependent.throwException(cause);
/*     */   }
/*     */   
/*     */   private boolean await0(long timeoutNanos, boolean interruptable) throws InterruptedException {
/* 675 */     if (isDone()) {
/* 676 */       return true;
/*     */     }
/*     */     
/* 679 */     if (timeoutNanos <= 0L) {
/* 680 */       return isDone();
/*     */     }
/*     */     
/* 683 */     if (interruptable && Thread.interrupted()) {
/* 684 */       throw new InterruptedException(toString());
/*     */     }
/*     */     
/* 687 */     checkDeadLock();
/*     */ 
/*     */ 
/*     */     
/* 691 */     long startTime = System.nanoTime();
/* 692 */     synchronized (this) {
/* 693 */       boolean interrupted = false;
/*     */       try {
/* 695 */         long waitTime = timeoutNanos;
/* 696 */         while (!isDone() && waitTime > 0L) {
/* 697 */           incWaiters();
/*     */           try {
/* 699 */             wait(waitTime / 1000000L, (int)(waitTime % 1000000L));
/* 700 */           } catch (InterruptedException e) {
/* 701 */             if (interruptable) {
/* 702 */               throw e;
/*     */             }
/* 704 */             interrupted = true;
/*     */           } finally {
/*     */             
/* 707 */             decWaiters();
/*     */           } 
/*     */           
/* 710 */           if (isDone()) {
/* 711 */             return true;
/*     */           }
/*     */ 
/*     */           
/* 715 */           waitTime = timeoutNanos - System.nanoTime() - startTime;
/*     */         } 
/* 717 */         return isDone();
/*     */       } finally {
/* 719 */         if (interrupted) {
/* 720 */           Thread.currentThread().interrupt();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notifyProgressiveListeners(final long progress, final long total) {
/* 738 */     Object listeners = progressiveListeners();
/* 739 */     if (listeners == null) {
/*     */       return;
/*     */     }
/*     */     
/* 743 */     final ProgressiveFuture<V> self = (ProgressiveFuture<V>)this;
/*     */     
/* 745 */     EventExecutor executor = executor();
/* 746 */     if (executor.inEventLoop()) {
/* 747 */       if (listeners instanceof GenericProgressiveFutureListener[]) {
/* 748 */         notifyProgressiveListeners0(self, (GenericProgressiveFutureListener<?>[])listeners, progress, total);
/*     */       } else {
/*     */         
/* 751 */         notifyProgressiveListener0(self, (GenericProgressiveFutureListener)listeners, progress, total);
/*     */       }
/*     */     
/*     */     }
/* 755 */     else if (listeners instanceof GenericProgressiveFutureListener[]) {
/* 756 */       final GenericProgressiveFutureListener[] array = (GenericProgressiveFutureListener[])listeners;
/*     */       
/* 758 */       safeExecute(executor, new Runnable()
/*     */           {
/*     */             public void run() {
/* 761 */               DefaultPromise.notifyProgressiveListeners0(self, (GenericProgressiveFutureListener<?>[])array, progress, total);
/*     */             }
/*     */           });
/*     */     } else {
/* 765 */       final GenericProgressiveFutureListener<ProgressiveFuture<V>> l = (GenericProgressiveFutureListener<ProgressiveFuture<V>>)listeners;
/*     */       
/* 767 */       safeExecute(executor, new Runnable()
/*     */           {
/*     */             public void run() {
/* 770 */               DefaultPromise.notifyProgressiveListener0(self, l, progress, total);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized Object progressiveListeners() {
/* 782 */     GenericFutureListener<? extends Future<?>> listener = this.listener;
/* 783 */     DefaultFutureListeners listeners = this.listeners;
/* 784 */     if (listener == null && listeners == null)
/*     */     {
/* 786 */       return null;
/*     */     }
/*     */     
/* 789 */     if (listeners != null) {
/*     */       
/* 791 */       DefaultFutureListeners dfl = listeners;
/* 792 */       int progressiveSize = dfl.progressiveSize();
/* 793 */       switch (progressiveSize) {
/*     */         case 0:
/* 795 */           return null;
/*     */         case 1:
/* 797 */           for (GenericFutureListener<?> l : dfl.listeners()) {
/* 798 */             if (l instanceof GenericProgressiveFutureListener) {
/* 799 */               return l;
/*     */             }
/*     */           } 
/* 802 */           return null;
/*     */       } 
/*     */       
/* 805 */       GenericFutureListener[] arrayOfGenericFutureListener = (GenericFutureListener[])dfl.listeners();
/* 806 */       GenericProgressiveFutureListener[] arrayOfGenericProgressiveFutureListener = new GenericProgressiveFutureListener[progressiveSize];
/* 807 */       for (int i = 0, j = 0; j < progressiveSize; i++) {
/* 808 */         GenericFutureListener<?> l = arrayOfGenericFutureListener[i];
/* 809 */         if (l instanceof GenericProgressiveFutureListener) {
/* 810 */           arrayOfGenericProgressiveFutureListener[j++] = (GenericProgressiveFutureListener)l;
/*     */         }
/*     */       } 
/*     */       
/* 814 */       return arrayOfGenericProgressiveFutureListener;
/* 815 */     }  if (listener instanceof GenericProgressiveFutureListener) {
/* 816 */       return listener;
/*     */     }
/*     */     
/* 819 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void notifyProgressiveListeners0(ProgressiveFuture<?> future, GenericProgressiveFutureListener<?>[] listeners, long progress, long total) {
/* 825 */     for (GenericProgressiveFutureListener<?> l : listeners) {
/* 826 */       if (l == null) {
/*     */         break;
/*     */       }
/* 829 */       notifyProgressiveListener0(future, l, progress, total);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void notifyProgressiveListener0(ProgressiveFuture future, GenericProgressiveFutureListener<ProgressiveFuture> l, long progress, long total) {
/*     */     try {
/* 837 */       l.operationProgressed(future, progress, total);
/* 838 */     } catch (Throwable t) {
/* 839 */       if (logger.isWarnEnabled()) {
/* 840 */         logger.warn("An exception was thrown by " + l.getClass().getName() + ".operationProgressed()", t);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isCancelled0(Object result) {
/* 846 */     return (result instanceof CauseHolder && ((CauseHolder)result).cause instanceof CancellationException);
/*     */   }
/*     */   
/*     */   private static boolean isDone0(Object result) {
/* 850 */     return (result != null && result != UNCANCELLABLE);
/*     */   }
/*     */   
/*     */   private static final class CauseHolder { final Throwable cause;
/*     */     
/*     */     CauseHolder(Throwable cause) {
/* 856 */       this.cause = cause;
/*     */     } }
/*     */ 
/*     */   
/*     */   private static void safeExecute(EventExecutor executor, Runnable task) {
/*     */     try {
/* 862 */       executor.execute(task);
/* 863 */     } catch (Throwable t) {
/* 864 */       rejectedExecutionLogger.error("Failed to submit a listener notification task. Event loop shut down?", t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class StacklessCancellationException
/*     */     extends CancellationException
/*     */   {
/*     */     private static final long serialVersionUID = -2974906711413716191L;
/*     */ 
/*     */ 
/*     */     
/*     */     public Throwable fillInStackTrace() {
/* 878 */       return this;
/*     */     }
/*     */     
/*     */     static StacklessCancellationException newInstance(Class<?> clazz, String method) {
/* 882 */       return (StacklessCancellationException)ThrowableUtil.unknownStackTrace(new StacklessCancellationException(), clazz, method);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\DefaultPromise.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */