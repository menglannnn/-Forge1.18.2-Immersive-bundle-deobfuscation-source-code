/*     */ package io.netty.util.concurrent;
/*     */ 
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.AbstractExecutorService;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RunnableFuture;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.jetbrains.annotations.Async.Execute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEventExecutor
/*     */   extends AbstractExecutorService
/*     */   implements EventExecutor
/*     */ {
/*  38 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(AbstractEventExecutor.class);
/*     */   
/*     */   static final long DEFAULT_SHUTDOWN_QUIET_PERIOD = 2L;
/*     */   
/*     */   static final long DEFAULT_SHUTDOWN_TIMEOUT = 15L;
/*     */   private final EventExecutorGroup parent;
/*  44 */   private final Collection<EventExecutor> selfCollection = Collections.singleton(this);
/*     */   
/*     */   protected AbstractEventExecutor() {
/*  47 */     this((EventExecutorGroup)null);
/*     */   }
/*     */   
/*     */   protected AbstractEventExecutor(EventExecutorGroup parent) {
/*  51 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public EventExecutorGroup parent() {
/*  56 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public EventExecutor next() {
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inEventLoop() {
/*  66 */     return inEventLoop(Thread.currentThread());
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<EventExecutor> iterator() {
/*  71 */     return this.selfCollection.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> shutdownGracefully() {
/*  76 */     return shutdownGracefully(2L, 15L, TimeUnit.SECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public List<Runnable> shutdownNow() {
/*  92 */     shutdown();
/*  93 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> Promise<V> newPromise() {
/*  98 */     return new DefaultPromise<V>(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> ProgressivePromise<V> newProgressivePromise() {
/* 103 */     return new DefaultProgressivePromise<V>(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> Future<V> newSucceededFuture(V result) {
/* 108 */     return new SucceededFuture<V>(this, result);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> Future<V> newFailedFuture(Throwable cause) {
/* 113 */     return new FailedFuture<V>(this, cause);
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<?> submit(Runnable task) {
/* 118 */     return (Future)super.submit(task);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Runnable task, T result) {
/* 123 */     return (Future<T>)super.<T>submit(task, result);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 128 */     return (Future<T>)super.<T>submit(task);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final <T> RunnableFuture<T> newTaskFor(Runnable runnable, T value) {
/* 133 */     return new PromiseTask<T>(this, runnable, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
/* 138 */     return new PromiseTask<T>(this, callable);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
/* 144 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
/* 149 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
/* 154 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
/* 159 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void safeExecute(Runnable task) {
/*     */     try {
/* 167 */       runTask(task);
/* 168 */     } catch (Throwable t) {
/* 169 */       logger.warn("A task raised an exception. Task: {}", task, t);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected static void runTask(@Execute Runnable task) {
/* 174 */     task.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lazyExecute(Runnable task) {
/* 186 */     execute(task);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public abstract void shutdown();
/*     */   
/*     */   @Deprecated
/*     */   public static interface LazyRunnable extends Runnable {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-common-4.1.93.Final.jar!\io\nett\\util\concurrent\AbstractEventExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */