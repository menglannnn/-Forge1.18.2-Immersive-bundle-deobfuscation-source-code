/*     */ package io.netty.resolver.dns.macos;
/*     */ 
/*     */ import io.netty.resolver.dns.DnsServerAddressStream;
/*     */ import io.netty.resolver.dns.DnsServerAddressStreamProvider;
/*     */ import io.netty.resolver.dns.DnsServerAddressStreamProviders;
/*     */ import io.netty.resolver.dns.DnsServerAddresses;
/*     */ import io.netty.util.internal.ClassInitializerUtil;
/*     */ import io.netty.util.internal.NativeLibraryLoader;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.ThrowableUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MacOSDnsServerAddressStreamProvider
/*     */   implements DnsServerAddressStreamProvider
/*     */ {
/*  46 */   private static final Comparator<DnsResolver> RESOLVER_COMPARATOR = new Comparator<DnsResolver>()
/*     */     {
/*     */ 
/*     */       
/*     */       public int compare(DnsResolver r1, DnsResolver r2)
/*     */       {
/*  52 */         return (r1.searchOrder() < r2.searchOrder()) ? 1 : ((r1.searchOrder() == r2.searchOrder()) ? 0 : -1);
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private static final Throwable UNAVAILABILITY_CAUSE;
/*     */   
/*  59 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(MacOSDnsServerAddressStreamProvider.class);
/*     */ 
/*     */   
/*  62 */   private static final long REFRESH_INTERVAL = TimeUnit.SECONDS.toNanos(10L);
/*     */   
/*     */   private volatile Map<String, DnsServerAddresses> currentMappings;
/*     */   
/*     */   private final AtomicLong lastRefresh;
/*     */ 
/*     */   
/*     */   static {
/*  70 */     ClassInitializerUtil.tryLoadClasses(MacOSDnsServerAddressStreamProvider.class, new Class[] { byte[].class, String.class });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     Throwable cause = null;
/*     */     try {
/*  77 */       loadNativeLibrary();
/*  78 */     } catch (Throwable error) {
/*  79 */       cause = error;
/*     */     } 
/*  81 */     UNAVAILABILITY_CAUSE = cause;
/*     */   }
/*     */   
/*     */   private static void loadNativeLibrary() {
/*  85 */     if (!PlatformDependent.isOsx()) {
/*  86 */       throw new IllegalStateException("Only supported on MacOS/OSX");
/*     */     }
/*  88 */     String staticLibName = "netty_resolver_dns_native_macos";
/*  89 */     String sharedLibName = staticLibName + '_' + PlatformDependent.normalizedArch();
/*  90 */     ClassLoader cl = PlatformDependent.getClassLoader(MacOSDnsServerAddressStreamProvider.class);
/*     */     try {
/*  92 */       NativeLibraryLoader.load(sharedLibName, cl);
/*  93 */     } catch (UnsatisfiedLinkError e1) {
/*     */       try {
/*  95 */         NativeLibraryLoader.load(staticLibName, cl);
/*  96 */         logger.debug("Failed to load {}", sharedLibName, e1);
/*  97 */       } catch (UnsatisfiedLinkError e2) {
/*  98 */         ThrowableUtil.addSuppressed(e1, e2);
/*  99 */         throw e1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isAvailable() {
/* 105 */     return (UNAVAILABILITY_CAUSE == null);
/*     */   }
/*     */   
/*     */   public static void ensureAvailability() {
/* 109 */     if (UNAVAILABILITY_CAUSE != null) {
/* 110 */       throw (Error)(new UnsatisfiedLinkError("failed to load the required native library"))
/* 111 */         .initCause(UNAVAILABILITY_CAUSE);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Throwable unavailabilityCause() {
/* 116 */     return UNAVAILABILITY_CAUSE;
/*     */   }
/*     */   
/*     */   public MacOSDnsServerAddressStreamProvider() {
/* 120 */     ensureAvailability();
/* 121 */     this.currentMappings = retrieveCurrentMappings();
/* 122 */     this.lastRefresh = new AtomicLong(System.nanoTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, DnsServerAddresses> retrieveCurrentMappings() {
/* 129 */     DnsResolver[] resolvers = resolvers();
/*     */     
/* 131 */     if (resolvers == null || resolvers.length == 0) {
/* 132 */       return Collections.emptyMap();
/*     */     }
/* 134 */     Arrays.sort(resolvers, RESOLVER_COMPARATOR);
/* 135 */     Map<String, DnsServerAddresses> resolverMap = new HashMap<String, DnsServerAddresses>(resolvers.length);
/* 136 */     for (DnsResolver resolver : resolvers) {
/*     */       
/* 138 */       if (!"mdns".equalsIgnoreCase(resolver.options())) {
/*     */ 
/*     */         
/* 141 */         InetSocketAddress[] nameservers = resolver.nameservers();
/* 142 */         if (nameservers != null && nameservers.length != 0)
/*     */         
/*     */         { 
/* 145 */           String domain = resolver.domain();
/* 146 */           if (domain == null)
/*     */           {
/* 148 */             domain = "";
/*     */           }
/* 150 */           InetSocketAddress[] servers = resolver.nameservers();
/* 151 */           for (int a = 0; a < servers.length; a++) {
/* 152 */             InetSocketAddress address = servers[a];
/*     */             
/* 154 */             if (address.getPort() == 0) {
/* 155 */               int port = resolver.port();
/* 156 */               if (port == 0) {
/* 157 */                 port = 53;
/*     */               }
/* 159 */               servers[a] = new InetSocketAddress(address.getAddress(), port);
/*     */             } 
/*     */           } 
/*     */           
/* 163 */           resolverMap.put(domain, DnsServerAddresses.sequential(servers)); } 
/*     */       } 
/* 165 */     }  return resolverMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public DnsServerAddressStream nameServerAddressStream(String hostname) {
/* 170 */     long last = this.lastRefresh.get();
/* 171 */     Map<String, DnsServerAddresses> resolverMap = this.currentMappings;
/* 172 */     if (System.nanoTime() - last > REFRESH_INTERVAL)
/*     */     {
/*     */       
/* 175 */       if (this.lastRefresh.compareAndSet(last, System.nanoTime())) {
/* 176 */         resolverMap = this.currentMappings = retrieveCurrentMappings();
/*     */       }
/*     */     }
/*     */     
/* 180 */     String originalHostname = hostname;
/*     */     while (true) {
/* 182 */       int i = hostname.indexOf('.', 1);
/* 183 */       if (i < 0 || i == hostname.length() - 1) {
/*     */         
/* 185 */         DnsServerAddresses dnsServerAddresses = resolverMap.get("");
/* 186 */         if (dnsServerAddresses != null) {
/* 187 */           return dnsServerAddresses.stream();
/*     */         }
/* 189 */         return DnsServerAddressStreamProviders.unixDefault().nameServerAddressStream(originalHostname);
/*     */       } 
/*     */       
/* 192 */       DnsServerAddresses addresses = resolverMap.get(hostname);
/* 193 */       if (addresses != null) {
/* 194 */         return addresses.stream();
/*     */       }
/*     */       
/* 197 */       hostname = hostname.substring(i + 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static native DnsResolver[] resolvers();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-resolver-dns-classes-macos-4.1.93.Final.jar!\io\netty\resolver\dns\macos\MacOSDnsServerAddressStreamProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */