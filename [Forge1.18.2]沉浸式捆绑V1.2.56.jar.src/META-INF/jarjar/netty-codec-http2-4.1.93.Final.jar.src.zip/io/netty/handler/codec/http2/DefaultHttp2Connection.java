/*      */ package io.netty.handler.codec.http2;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.channel.ChannelFuture;
/*      */ import io.netty.util.collection.IntObjectHashMap;
/*      */ import io.netty.util.collection.IntObjectMap;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.Promise;
/*      */ import io.netty.util.concurrent.PromiseNotifier;
/*      */ import io.netty.util.internal.EmptyArrays;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DefaultHttp2Connection
/*      */   implements Http2Connection
/*      */ {
/*   66 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DefaultHttp2Connection.class);
/*      */   
/*   68 */   final IntObjectMap<Http2Stream> streamMap = (IntObjectMap<Http2Stream>)new IntObjectHashMap();
/*   69 */   final PropertyKeyRegistry propertyKeyRegistry = new PropertyKeyRegistry();
/*   70 */   final ConnectionStream connectionStream = new ConnectionStream();
/*      */ 
/*      */ 
/*      */   
/*      */   final DefaultEndpoint<Http2LocalFlowController> localEndpoint;
/*      */ 
/*      */ 
/*      */   
/*      */   final DefaultEndpoint<Http2RemoteFlowController> remoteEndpoint;
/*      */ 
/*      */ 
/*      */   
/*   82 */   final List<Http2Connection.Listener> listeners = new ArrayList<Http2Connection.Listener>(4);
/*      */ 
/*      */   
/*      */   final ActiveStreams activeStreams;
/*      */   
/*      */   Promise<Void> closePromise;
/*      */ 
/*      */   
/*      */   public DefaultHttp2Connection(boolean server) {
/*   91 */     this(server, 100);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DefaultHttp2Connection(boolean server, int maxReservedStreams) {
/*  100 */     this.activeStreams = new ActiveStreams(this.listeners);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  106 */     this.localEndpoint = new DefaultEndpoint<Http2LocalFlowController>(server, server ? Integer.MAX_VALUE : maxReservedStreams);
/*  107 */     this.remoteEndpoint = new DefaultEndpoint<Http2RemoteFlowController>(!server, maxReservedStreams);
/*      */ 
/*      */     
/*  110 */     this.streamMap.put(this.connectionStream.id(), this.connectionStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isClosed() {
/*  117 */     return (this.closePromise != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public Future<Void> close(Promise<Void> promise) {
/*  122 */     ObjectUtil.checkNotNull(promise, "promise");
/*      */ 
/*      */     
/*  125 */     if (this.closePromise != null) {
/*  126 */       if (this.closePromise != promise)
/*      */       {
/*  128 */         if (promise instanceof io.netty.channel.ChannelPromise && ((ChannelFuture)this.closePromise).isVoid()) {
/*  129 */           this.closePromise = promise;
/*      */         } else {
/*  131 */           PromiseNotifier.cascade((Future)this.closePromise, promise);
/*      */         }  } 
/*      */     } else {
/*  134 */       this.closePromise = promise;
/*      */     } 
/*  136 */     if (isStreamMapEmpty()) {
/*  137 */       promise.trySuccess(null);
/*  138 */       return (Future<Void>)promise;
/*      */     } 
/*      */     
/*  141 */     Iterator<IntObjectMap.PrimitiveEntry<Http2Stream>> itr = this.streamMap.entries().iterator();
/*      */ 
/*      */     
/*  144 */     if (this.activeStreams.allowModifications()) {
/*  145 */       this.activeStreams.incrementPendingIterations();
/*      */       try {
/*  147 */         while (itr.hasNext()) {
/*  148 */           DefaultStream stream = (DefaultStream)((IntObjectMap.PrimitiveEntry)itr.next()).value();
/*  149 */           if (stream.id() != 0)
/*      */           {
/*      */ 
/*      */             
/*  153 */             stream.close(itr);
/*      */           }
/*      */         } 
/*      */       } finally {
/*  157 */         this.activeStreams.decrementPendingIterations();
/*      */       } 
/*      */     } else {
/*  160 */       while (itr.hasNext()) {
/*  161 */         Http2Stream stream = (Http2Stream)((IntObjectMap.PrimitiveEntry)itr.next()).value();
/*  162 */         if (stream.id() != 0)
/*      */         {
/*      */           
/*  165 */           stream.close();
/*      */         }
/*      */       } 
/*      */     } 
/*  169 */     return (Future<Void>)this.closePromise;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addListener(Http2Connection.Listener listener) {
/*  174 */     this.listeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeListener(Http2Connection.Listener listener) {
/*  179 */     this.listeners.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isServer() {
/*  184 */     return this.localEndpoint.isServer();
/*      */   }
/*      */ 
/*      */   
/*      */   public Http2Stream connectionStream() {
/*  189 */     return this.connectionStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public Http2Stream stream(int streamId) {
/*  194 */     return (Http2Stream)this.streamMap.get(streamId);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean streamMayHaveExisted(int streamId) {
/*  199 */     return (this.remoteEndpoint.mayHaveCreatedStream(streamId) || this.localEndpoint.mayHaveCreatedStream(streamId));
/*      */   }
/*      */ 
/*      */   
/*      */   public int numActiveStreams() {
/*  204 */     return this.activeStreams.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public Http2Stream forEachActiveStream(Http2StreamVisitor visitor) throws Http2Exception {
/*  209 */     return this.activeStreams.forEachActiveStream(visitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public Http2Connection.Endpoint<Http2LocalFlowController> local() {
/*  214 */     return this.localEndpoint;
/*      */   }
/*      */ 
/*      */   
/*      */   public Http2Connection.Endpoint<Http2RemoteFlowController> remote() {
/*  219 */     return this.remoteEndpoint;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean goAwayReceived() {
/*  224 */     return (this.localEndpoint.lastStreamKnownByPeer >= 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void goAwayReceived(int lastKnownStream, long errorCode, ByteBuf debugData) throws Http2Exception {
/*  229 */     if (this.localEndpoint.lastStreamKnownByPeer() >= 0 && this.localEndpoint.lastStreamKnownByPeer() < lastKnownStream) {
/*  230 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "lastStreamId MUST NOT increase. Current value: %d new value: %d", new Object[] {
/*  231 */             Integer.valueOf(this.localEndpoint.lastStreamKnownByPeer()), Integer.valueOf(lastKnownStream)
/*      */           });
/*      */     }
/*  234 */     this.localEndpoint.lastStreamKnownByPeer(lastKnownStream);
/*  235 */     for (int i = 0; i < this.listeners.size(); i++) {
/*      */       try {
/*  237 */         ((Http2Connection.Listener)this.listeners.get(i)).onGoAwayReceived(lastKnownStream, errorCode, debugData);
/*  238 */       } catch (Throwable cause) {
/*  239 */         logger.error("Caught Throwable from listener onGoAwayReceived.", cause);
/*      */       } 
/*      */     } 
/*      */     
/*  243 */     closeStreamsGreaterThanLastKnownStreamId(lastKnownStream, this.localEndpoint);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean goAwaySent() {
/*  248 */     return (this.remoteEndpoint.lastStreamKnownByPeer >= 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean goAwaySent(int lastKnownStream, long errorCode, ByteBuf debugData) throws Http2Exception {
/*  253 */     if (this.remoteEndpoint.lastStreamKnownByPeer() >= 0) {
/*      */ 
/*      */       
/*  256 */       if (lastKnownStream == this.remoteEndpoint.lastStreamKnownByPeer()) {
/*  257 */         return false;
/*      */       }
/*  259 */       if (lastKnownStream > this.remoteEndpoint.lastStreamKnownByPeer()) {
/*  260 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Last stream identifier must not increase between sending multiple GOAWAY frames (was '%d', is '%d').", new Object[] {
/*      */               
/*  262 */               Integer.valueOf(this.remoteEndpoint.lastStreamKnownByPeer()), Integer.valueOf(lastKnownStream)
/*      */             });
/*      */       }
/*      */     } 
/*  266 */     this.remoteEndpoint.lastStreamKnownByPeer(lastKnownStream);
/*  267 */     for (int i = 0; i < this.listeners.size(); i++) {
/*      */       try {
/*  269 */         ((Http2Connection.Listener)this.listeners.get(i)).onGoAwaySent(lastKnownStream, errorCode, debugData);
/*  270 */       } catch (Throwable cause) {
/*  271 */         logger.error("Caught Throwable from listener onGoAwaySent.", cause);
/*      */       } 
/*      */     } 
/*      */     
/*  275 */     closeStreamsGreaterThanLastKnownStreamId(lastKnownStream, this.remoteEndpoint);
/*  276 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private void closeStreamsGreaterThanLastKnownStreamId(final int lastKnownStream, final DefaultEndpoint<?> endpoint) throws Http2Exception {
/*  281 */     forEachActiveStream(new Http2StreamVisitor()
/*      */         {
/*      */           public boolean visit(Http2Stream stream) {
/*  284 */             if (stream.id() > lastKnownStream && endpoint.isValidStreamId(stream.id())) {
/*  285 */               stream.close();
/*      */             }
/*  287 */             return true;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isStreamMapEmpty() {
/*  296 */     return (this.streamMap.size() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void removeStream(DefaultStream stream, Iterator<?> itr) {
/*      */     boolean removed;
/*  307 */     if (itr == null) {
/*  308 */       removed = (this.streamMap.remove(stream.id()) != null);
/*      */     } else {
/*  310 */       itr.remove();
/*  311 */       removed = true;
/*      */     } 
/*      */     
/*  314 */     if (removed) {
/*  315 */       for (int i = 0; i < this.listeners.size(); i++) {
/*      */         try {
/*  317 */           ((Http2Connection.Listener)this.listeners.get(i)).onStreamRemoved(stream);
/*  318 */         } catch (Throwable cause) {
/*  319 */           logger.error("Caught Throwable from listener onStreamRemoved.", cause);
/*      */         } 
/*      */       } 
/*      */       
/*  323 */       if (this.closePromise != null && isStreamMapEmpty()) {
/*  324 */         this.closePromise.trySuccess(null);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static Http2Stream.State activeState(int streamId, Http2Stream.State initialState, boolean isLocal, boolean halfClosed) throws Http2Exception {
/*  331 */     switch (initialState) {
/*      */       case IDLE:
/*  333 */         return halfClosed ? (isLocal ? Http2Stream.State.HALF_CLOSED_LOCAL : Http2Stream.State.HALF_CLOSED_REMOTE) : Http2Stream.State.OPEN;
/*      */       case RESERVED_LOCAL:
/*  335 */         return Http2Stream.State.HALF_CLOSED_REMOTE;
/*      */       case RESERVED_REMOTE:
/*  337 */         return Http2Stream.State.HALF_CLOSED_LOCAL;
/*      */     } 
/*  339 */     throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Attempting to open a stream in an invalid state: " + initialState, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void notifyHalfClosed(Http2Stream stream) {
/*  345 */     for (int i = 0; i < this.listeners.size(); i++) {
/*      */       try {
/*  347 */         ((Http2Connection.Listener)this.listeners.get(i)).onStreamHalfClosed(stream);
/*  348 */       } catch (Throwable cause) {
/*  349 */         logger.error("Caught Throwable from listener onStreamHalfClosed.", cause);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void notifyClosed(Http2Stream stream) {
/*  355 */     for (int i = 0; i < this.listeners.size(); i++) {
/*      */       try {
/*  357 */         ((Http2Connection.Listener)this.listeners.get(i)).onStreamClosed(stream);
/*  358 */       } catch (Throwable cause) {
/*  359 */         logger.error("Caught Throwable from listener onStreamClosed.", cause);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Http2Connection.PropertyKey newKey() {
/*  366 */     return this.propertyKeyRegistry.newKey();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final DefaultPropertyKey verifyKey(Http2Connection.PropertyKey key) {
/*  377 */     return ((DefaultPropertyKey)ObjectUtil.checkNotNull(key, "key")).verifyConnection(this);
/*      */   }
/*      */ 
/*      */   
/*      */   private class DefaultStream
/*      */     implements Http2Stream
/*      */   {
/*      */     private static final byte META_STATE_SENT_RST = 1;
/*      */     private static final byte META_STATE_SENT_HEADERS = 2;
/*      */     private static final byte META_STATE_SENT_TRAILERS = 4;
/*      */     private static final byte META_STATE_SENT_PUSHPROMISE = 8;
/*      */     private static final byte META_STATE_RECV_HEADERS = 16;
/*      */     private static final byte META_STATE_RECV_TRAILERS = 32;
/*      */     private final int id;
/*  391 */     private final PropertyMap properties = new PropertyMap();
/*      */     private Http2Stream.State state;
/*      */     private byte metaState;
/*      */     
/*      */     DefaultStream(int id, Http2Stream.State state) {
/*  396 */       this.id = id;
/*  397 */       this.state = state;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int id() {
/*  402 */       return this.id;
/*      */     }
/*      */ 
/*      */     
/*      */     public final Http2Stream.State state() {
/*  407 */       return this.state;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isResetSent() {
/*  412 */       return ((this.metaState & 0x1) != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream resetSent() {
/*  417 */       this.metaState = (byte)(this.metaState | 0x1);
/*  418 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream headersSent(boolean isInformational) {
/*  423 */       if (!isInformational) {
/*  424 */         this.metaState = (byte)(this.metaState | (isHeadersSent() ? 4 : 2));
/*      */       }
/*  426 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isHeadersSent() {
/*  431 */       return ((this.metaState & 0x2) != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isTrailersSent() {
/*  436 */       return ((this.metaState & 0x4) != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream headersReceived(boolean isInformational) {
/*  441 */       if (!isInformational) {
/*  442 */         this.metaState = (byte)(this.metaState | (isHeadersReceived() ? 32 : 16));
/*      */       }
/*  444 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isHeadersReceived() {
/*  449 */       return ((this.metaState & 0x10) != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isTrailersReceived() {
/*  454 */       return ((this.metaState & 0x20) != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream pushPromiseSent() {
/*  459 */       this.metaState = (byte)(this.metaState | 0x8);
/*  460 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isPushPromiseSent() {
/*  465 */       return ((this.metaState & 0x8) != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public final <V> V setProperty(Http2Connection.PropertyKey key, V value) {
/*  470 */       return this.properties.add(DefaultHttp2Connection.this.verifyKey(key), value);
/*      */     }
/*      */ 
/*      */     
/*      */     public final <V> V getProperty(Http2Connection.PropertyKey key) {
/*  475 */       return this.properties.get(DefaultHttp2Connection.this.verifyKey(key));
/*      */     }
/*      */ 
/*      */     
/*      */     public final <V> V removeProperty(Http2Connection.PropertyKey key) {
/*  480 */       return this.properties.remove(DefaultHttp2Connection.this.verifyKey(key));
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream open(boolean halfClosed) throws Http2Exception {
/*  485 */       this.state = DefaultHttp2Connection.activeState(this.id, this.state, isLocal(), halfClosed);
/*  486 */       DefaultHttp2Connection.DefaultEndpoint<? extends Http2FlowController> endpoint = createdBy();
/*  487 */       if (!endpoint.canOpenStream()) {
/*  488 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Maximum active streams violated for this endpoint: " + endpoint
/*  489 */             .maxActiveStreams(), new Object[0]);
/*      */       }
/*      */       
/*  492 */       activate();
/*  493 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void activate() {
/*  499 */       if (this.state == Http2Stream.State.HALF_CLOSED_LOCAL) {
/*  500 */         headersSent(false);
/*  501 */       } else if (this.state == Http2Stream.State.HALF_CLOSED_REMOTE) {
/*  502 */         headersReceived(false);
/*      */       } 
/*  504 */       DefaultHttp2Connection.this.activeStreams.activate(this);
/*      */     }
/*      */     
/*      */     Http2Stream close(Iterator<?> itr) {
/*  508 */       if (this.state == Http2Stream.State.CLOSED) {
/*  509 */         return this;
/*      */       }
/*      */       
/*  512 */       this.state = Http2Stream.State.CLOSED;
/*      */       
/*  514 */       (createdBy()).numStreams--;
/*  515 */       DefaultHttp2Connection.this.activeStreams.deactivate(this, itr);
/*  516 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream close() {
/*  521 */       return close(null);
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream closeLocalSide() {
/*  526 */       switch (this.state) {
/*      */         case OPEN:
/*  528 */           this.state = Http2Stream.State.HALF_CLOSED_LOCAL;
/*  529 */           DefaultHttp2Connection.this.notifyHalfClosed(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case HALF_CLOSED_LOCAL:
/*  537 */           return this;
/*      */       } 
/*      */       close();
/*      */     }
/*      */     public Http2Stream closeRemoteSide() {
/*  542 */       switch (this.state) {
/*      */         case OPEN:
/*  544 */           this.state = Http2Stream.State.HALF_CLOSED_REMOTE;
/*  545 */           DefaultHttp2Connection.this.notifyHalfClosed(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case HALF_CLOSED_REMOTE:
/*  553 */           return this;
/*      */       } 
/*      */       close();
/*      */     } DefaultHttp2Connection.DefaultEndpoint<? extends Http2FlowController> createdBy() {
/*  557 */       return DefaultHttp2Connection.this.localEndpoint.isValidStreamId(this.id) ? (DefaultHttp2Connection.DefaultEndpoint)DefaultHttp2Connection.this.localEndpoint : (DefaultHttp2Connection.DefaultEndpoint)DefaultHttp2Connection.this.remoteEndpoint;
/*      */     }
/*      */     
/*      */     final boolean isLocal() {
/*  561 */       return DefaultHttp2Connection.this.localEndpoint.isValidStreamId(this.id);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private class PropertyMap
/*      */     {
/*  568 */       Object[] values = EmptyArrays.EMPTY_OBJECTS;
/*      */       
/*      */       <V> V add(DefaultHttp2Connection.DefaultPropertyKey key, V value) {
/*  571 */         resizeIfNecessary(key.index);
/*      */         
/*  573 */         V prevValue = (V)this.values[key.index];
/*  574 */         this.values[key.index] = value;
/*  575 */         return prevValue;
/*      */       }
/*      */ 
/*      */       
/*      */       <V> V get(DefaultHttp2Connection.DefaultPropertyKey key) {
/*  580 */         if (key.index >= this.values.length) {
/*  581 */           return null;
/*      */         }
/*  583 */         return (V)this.values[key.index];
/*      */       }
/*      */ 
/*      */       
/*      */       <V> V remove(DefaultHttp2Connection.DefaultPropertyKey key) {
/*  588 */         V prevValue = null;
/*  589 */         if (key.index < this.values.length) {
/*  590 */           prevValue = (V)this.values[key.index];
/*  591 */           this.values[key.index] = null;
/*      */         } 
/*  593 */         return prevValue;
/*      */       }
/*      */       
/*      */       void resizeIfNecessary(int index) {
/*  597 */         if (index >= this.values.length)
/*  598 */           this.values = Arrays.copyOf(this.values, DefaultHttp2Connection.this.propertyKeyRegistry.size()); 
/*      */       }
/*      */       
/*      */       private PropertyMap() {}
/*      */     }
/*      */   }
/*      */   
/*      */   private final class ConnectionStream
/*      */     extends DefaultStream
/*      */   {
/*      */     ConnectionStream() {
/*  609 */       super(0, Http2Stream.State.IDLE);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isResetSent() {
/*  614 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     DefaultHttp2Connection.DefaultEndpoint<? extends Http2FlowController> createdBy() {
/*  619 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream resetSent() {
/*  624 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream open(boolean halfClosed) {
/*  629 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream close() {
/*  634 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream closeLocalSide() {
/*  639 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream closeRemoteSide() {
/*  644 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream headersSent(boolean isInformational) {
/*  649 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isHeadersSent() {
/*  654 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Stream pushPromiseSent() {
/*  659 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isPushPromiseSent() {
/*  664 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class DefaultEndpoint<F extends Http2FlowController>
/*      */     implements Http2Connection.Endpoint<F>
/*      */   {
/*      */     private final boolean server;
/*      */ 
/*      */ 
/*      */     
/*      */     private int nextStreamIdToCreate;
/*      */ 
/*      */ 
/*      */     
/*      */     private int nextReservationStreamId;
/*      */ 
/*      */ 
/*      */     
/*  686 */     private int lastStreamKnownByPeer = -1;
/*      */     
/*      */     private boolean pushToAllowed;
/*      */     private F flowController;
/*      */     private int maxStreams;
/*      */     private int maxActiveStreams;
/*      */     private final int maxReservedStreams;
/*      */     int numActiveStreams;
/*      */     int numStreams;
/*      */     
/*      */     DefaultEndpoint(boolean server, int maxReservedStreams) {
/*  697 */       this.server = server;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  703 */       if (server) {
/*  704 */         this.nextStreamIdToCreate = 2;
/*  705 */         this.nextReservationStreamId = 0;
/*      */       } else {
/*  707 */         this.nextStreamIdToCreate = 1;
/*      */         
/*  709 */         this.nextReservationStreamId = 1;
/*      */       } 
/*      */ 
/*      */       
/*  713 */       this.pushToAllowed = !server;
/*  714 */       this.maxActiveStreams = Integer.MAX_VALUE;
/*  715 */       this.maxReservedStreams = ObjectUtil.checkPositiveOrZero(maxReservedStreams, "maxReservedStreams");
/*  716 */       updateMaxStreams();
/*      */     }
/*      */ 
/*      */     
/*      */     public int incrementAndGetNextStreamId() {
/*  721 */       return (this.nextReservationStreamId >= 0) ? (this.nextReservationStreamId += 2) : this.nextReservationStreamId;
/*      */     }
/*      */     
/*      */     private void incrementExpectedStreamId(int streamId) {
/*  725 */       if (streamId > this.nextReservationStreamId && this.nextReservationStreamId >= 0) {
/*  726 */         this.nextReservationStreamId = streamId;
/*      */       }
/*  728 */       this.nextStreamIdToCreate = streamId + 2;
/*  729 */       this.numStreams++;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isValidStreamId(int streamId) {
/*  734 */       return (streamId > 0 && this.server == (((streamId & 0x1) == 0)));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean mayHaveCreatedStream(int streamId) {
/*  739 */       return (isValidStreamId(streamId) && streamId <= lastStreamCreated());
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean canOpenStream() {
/*  744 */       return (this.numActiveStreams < this.maxActiveStreams);
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultHttp2Connection.DefaultStream createStream(int streamId, boolean halfClosed) throws Http2Exception {
/*  749 */       Http2Stream.State state = DefaultHttp2Connection.activeState(streamId, Http2Stream.State.IDLE, isLocal(), halfClosed);
/*      */       
/*  751 */       checkNewStreamAllowed(streamId, state);
/*      */ 
/*      */       
/*  754 */       DefaultHttp2Connection.DefaultStream stream = new DefaultHttp2Connection.DefaultStream(streamId, state);
/*      */       
/*  756 */       incrementExpectedStreamId(streamId);
/*      */       
/*  758 */       addStream(stream);
/*      */       
/*  760 */       stream.activate();
/*  761 */       return stream;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean created(Http2Stream stream) {
/*  766 */       return (stream instanceof DefaultHttp2Connection.DefaultStream && ((DefaultHttp2Connection.DefaultStream)stream).createdBy() == this);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isServer() {
/*  771 */       return this.server;
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultHttp2Connection.DefaultStream reservePushStream(int streamId, Http2Stream parent) throws Http2Exception {
/*  776 */       if (parent == null) {
/*  777 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Parent stream missing", new Object[0]);
/*      */       }
/*  779 */       if (isLocal() ? !parent.state().localSideOpen() : !parent.state().remoteSideOpen()) {
/*  780 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Stream %d is not open for sending push promise", new Object[] { Integer.valueOf(parent.id()) });
/*      */       }
/*  782 */       if (!opposite().allowPushTo()) {
/*  783 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Server push not allowed to opposite endpoint", new Object[0]);
/*      */       }
/*  785 */       Http2Stream.State state = isLocal() ? Http2Stream.State.RESERVED_LOCAL : Http2Stream.State.RESERVED_REMOTE;
/*  786 */       checkNewStreamAllowed(streamId, state);
/*      */ 
/*      */       
/*  789 */       DefaultHttp2Connection.DefaultStream stream = new DefaultHttp2Connection.DefaultStream(streamId, state);
/*      */       
/*  791 */       incrementExpectedStreamId(streamId);
/*      */ 
/*      */       
/*  794 */       addStream(stream);
/*  795 */       return stream;
/*      */     }
/*      */ 
/*      */     
/*      */     private void addStream(DefaultHttp2Connection.DefaultStream stream) {
/*  800 */       DefaultHttp2Connection.this.streamMap.put(stream.id(), stream);
/*      */ 
/*      */       
/*  803 */       for (int i = 0; i < DefaultHttp2Connection.this.listeners.size(); i++) {
/*      */         try {
/*  805 */           ((Http2Connection.Listener)DefaultHttp2Connection.this.listeners.get(i)).onStreamAdded(stream);
/*  806 */         } catch (Throwable cause) {
/*  807 */           DefaultHttp2Connection.logger.error("Caught Throwable from listener onStreamAdded.", cause);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void allowPushTo(boolean allow) {
/*  814 */       if (allow && this.server) {
/*  815 */         throw new IllegalArgumentException("Servers do not allow push");
/*      */       }
/*  817 */       this.pushToAllowed = allow;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean allowPushTo() {
/*  822 */       return this.pushToAllowed;
/*      */     }
/*      */ 
/*      */     
/*      */     public int numActiveStreams() {
/*  827 */       return this.numActiveStreams;
/*      */     }
/*      */ 
/*      */     
/*      */     public int maxActiveStreams() {
/*  832 */       return this.maxActiveStreams;
/*      */     }
/*      */ 
/*      */     
/*      */     public void maxActiveStreams(int maxActiveStreams) {
/*  837 */       this.maxActiveStreams = maxActiveStreams;
/*  838 */       updateMaxStreams();
/*      */     }
/*      */ 
/*      */     
/*      */     public int lastStreamCreated() {
/*  843 */       return (this.nextStreamIdToCreate > 1) ? (this.nextStreamIdToCreate - 2) : 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public int lastStreamKnownByPeer() {
/*  848 */       return this.lastStreamKnownByPeer;
/*      */     }
/*      */     
/*      */     private void lastStreamKnownByPeer(int lastKnownStream) {
/*  852 */       this.lastStreamKnownByPeer = lastKnownStream;
/*      */     }
/*      */ 
/*      */     
/*      */     public F flowController() {
/*  857 */       return this.flowController;
/*      */     }
/*      */ 
/*      */     
/*      */     public void flowController(F flowController) {
/*  862 */       this.flowController = (F)ObjectUtil.checkNotNull(flowController, "flowController");
/*      */     }
/*      */ 
/*      */     
/*      */     public Http2Connection.Endpoint<? extends Http2FlowController> opposite() {
/*  867 */       return isLocal() ? (Http2Connection.Endpoint)DefaultHttp2Connection.this.remoteEndpoint : (Http2Connection.Endpoint)DefaultHttp2Connection.this.localEndpoint;
/*      */     }
/*      */     
/*      */     private void updateMaxStreams() {
/*  871 */       this.maxStreams = (int)Math.min(2147483647L, this.maxActiveStreams + this.maxReservedStreams);
/*      */     }
/*      */     
/*      */     private void checkNewStreamAllowed(int streamId, Http2Stream.State state) throws Http2Exception {
/*  875 */       assert state != Http2Stream.State.IDLE;
/*  876 */       if (this.lastStreamKnownByPeer >= 0 && streamId > this.lastStreamKnownByPeer)
/*  877 */         throw Http2Exception.streamError(streamId, Http2Error.REFUSED_STREAM, "Cannot create stream %d greater than Last-Stream-ID %d from GOAWAY.", new Object[] {
/*      */               
/*  879 */               Integer.valueOf(streamId), Integer.valueOf(this.lastStreamKnownByPeer)
/*      */             }); 
/*  881 */       if (!isValidStreamId(streamId)) {
/*  882 */         if (streamId < 0) {
/*  883 */           throw new Http2NoMoreStreamIdsException();
/*      */         }
/*  885 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Request stream %d is not correct for %s connection", new Object[] { Integer.valueOf(streamId), this.server ? "server" : "client" });
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  890 */       if (streamId < this.nextStreamIdToCreate)
/*  891 */         throw Http2Exception.closedStreamError(Http2Error.PROTOCOL_ERROR, "Request stream %d is behind the next expected stream %d", new Object[] {
/*  892 */               Integer.valueOf(streamId), Integer.valueOf(this.nextStreamIdToCreate)
/*      */             }); 
/*  894 */       if (this.nextStreamIdToCreate <= 0)
/*      */       {
/*      */         
/*  897 */         throw new Http2Exception(Http2Error.REFUSED_STREAM, "Stream IDs are exhausted for this endpoint.", Http2Exception.ShutdownHint.GRACEFUL_SHUTDOWN);
/*      */       }
/*      */       
/*  900 */       boolean isReserved = (state == Http2Stream.State.RESERVED_LOCAL || state == Http2Stream.State.RESERVED_REMOTE);
/*  901 */       if ((!isReserved && !canOpenStream()) || (isReserved && this.numStreams >= this.maxStreams)) {
/*  902 */         throw Http2Exception.streamError(streamId, Http2Error.REFUSED_STREAM, "Maximum active streams violated for this endpoint: " + (isReserved ? this.maxStreams : this.maxActiveStreams), new Object[0]);
/*      */       }
/*      */       
/*  905 */       if (DefaultHttp2Connection.this.isClosed())
/*  906 */         throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, "Attempted to create stream id %d after connection was closed", new Object[] {
/*  907 */               Integer.valueOf(streamId)
/*      */             }); 
/*      */     }
/*      */     
/*      */     private boolean isLocal() {
/*  912 */       return (this == DefaultHttp2Connection.this.localEndpoint);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class ActiveStreams
/*      */   {
/*      */     private final List<Http2Connection.Listener> listeners;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  936 */     private final Queue<DefaultHttp2Connection.Event> pendingEvents = new ArrayDeque<DefaultHttp2Connection.Event>(4);
/*  937 */     private final Set<Http2Stream> streams = new LinkedHashSet<Http2Stream>();
/*      */     private int pendingIterations;
/*      */     
/*      */     ActiveStreams(List<Http2Connection.Listener> listeners) {
/*  941 */       this.listeners = listeners;
/*      */     }
/*      */     
/*      */     public int size() {
/*  945 */       return this.streams.size();
/*      */     }
/*      */     
/*      */     public void activate(final DefaultHttp2Connection.DefaultStream stream) {
/*  949 */       if (allowModifications()) {
/*  950 */         addToActiveStreams(stream);
/*      */       } else {
/*  952 */         this.pendingEvents.add(new DefaultHttp2Connection.Event()
/*      */             {
/*      */               public void process() {
/*  955 */                 DefaultHttp2Connection.ActiveStreams.this.addToActiveStreams(stream);
/*      */               }
/*      */             });
/*      */       } 
/*      */     }
/*      */     
/*      */     public void deactivate(final DefaultHttp2Connection.DefaultStream stream, final Iterator<?> itr) {
/*  962 */       if (allowModifications() || itr != null) {
/*  963 */         removeFromActiveStreams(stream, itr);
/*      */       } else {
/*  965 */         this.pendingEvents.add(new DefaultHttp2Connection.Event()
/*      */             {
/*      */               public void process() {
/*  968 */                 DefaultHttp2Connection.ActiveStreams.this.removeFromActiveStreams(stream, itr);
/*      */               }
/*      */             });
/*      */       } 
/*      */     }
/*      */     
/*      */     public Http2Stream forEachActiveStream(Http2StreamVisitor visitor) throws Http2Exception {
/*  975 */       incrementPendingIterations();
/*      */       try {
/*  977 */         for (Http2Stream stream : this.streams) {
/*  978 */           if (!visitor.visit(stream)) {
/*  979 */             return stream;
/*      */           }
/*      */         } 
/*  982 */         return null;
/*      */       } finally {
/*  984 */         decrementPendingIterations();
/*      */       } 
/*      */     }
/*      */     
/*      */     void addToActiveStreams(DefaultHttp2Connection.DefaultStream stream) {
/*  989 */       if (this.streams.add(stream)) {
/*      */         
/*  991 */         (stream.createdBy()).numActiveStreams++;
/*      */         
/*  993 */         for (int i = 0; i < this.listeners.size(); i++) {
/*      */           try {
/*  995 */             ((Http2Connection.Listener)this.listeners.get(i)).onStreamActive(stream);
/*  996 */           } catch (Throwable cause) {
/*  997 */             DefaultHttp2Connection.logger.error("Caught Throwable from listener onStreamActive.", cause);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     void removeFromActiveStreams(DefaultHttp2Connection.DefaultStream stream, Iterator<?> itr) {
/* 1004 */       if (this.streams.remove(stream)) {
/*      */         
/* 1006 */         (stream.createdBy()).numActiveStreams--;
/* 1007 */         DefaultHttp2Connection.this.notifyClosed(stream);
/*      */       } 
/* 1009 */       DefaultHttp2Connection.this.removeStream(stream, itr);
/*      */     }
/*      */     
/*      */     boolean allowModifications() {
/* 1013 */       return (this.pendingIterations == 0);
/*      */     }
/*      */     
/*      */     void incrementPendingIterations() {
/* 1017 */       this.pendingIterations++;
/*      */     }
/*      */     
/*      */     void decrementPendingIterations() {
/* 1021 */       this.pendingIterations--;
/* 1022 */       if (allowModifications()) {
/*      */         while (true) {
/* 1024 */           DefaultHttp2Connection.Event event = this.pendingEvents.poll();
/* 1025 */           if (event == null) {
/*      */             break;
/*      */           }
/*      */           try {
/* 1029 */             event.process();
/* 1030 */           } catch (Throwable cause) {
/* 1031 */             DefaultHttp2Connection.logger.error("Caught Throwable while processing pending ActiveStreams$Event.", cause);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final class DefaultPropertyKey
/*      */     implements Http2Connection.PropertyKey
/*      */   {
/*      */     final int index;
/*      */     
/*      */     DefaultPropertyKey(int index) {
/* 1045 */       this.index = index;
/*      */     }
/*      */     
/*      */     DefaultPropertyKey verifyConnection(Http2Connection connection) {
/* 1049 */       if (connection != DefaultHttp2Connection.this) {
/* 1050 */         throw new IllegalArgumentException("Using a key that was not created by this connection");
/*      */       }
/* 1052 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class PropertyKeyRegistry
/*      */   {
/* 1065 */     final List<DefaultHttp2Connection.DefaultPropertyKey> keys = new ArrayList<DefaultHttp2Connection.DefaultPropertyKey>(4);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DefaultHttp2Connection.DefaultPropertyKey newKey() {
/* 1071 */       DefaultHttp2Connection.DefaultPropertyKey key = new DefaultHttp2Connection.DefaultPropertyKey(this.keys.size());
/* 1072 */       this.keys.add(key);
/* 1073 */       return key;
/*      */     }
/*      */     
/*      */     int size() {
/* 1077 */       return this.keys.size();
/*      */     }
/*      */     
/*      */     private PropertyKeyRegistry() {}
/*      */   }
/*      */   
/*      */   static interface Event {
/*      */     void process();
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2Connection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */