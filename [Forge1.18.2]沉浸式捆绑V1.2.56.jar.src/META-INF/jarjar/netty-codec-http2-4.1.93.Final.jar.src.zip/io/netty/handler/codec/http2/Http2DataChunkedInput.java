/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.stream.ChunkedInput;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2DataChunkedInput
/*     */   implements ChunkedInput<Http2DataFrame>
/*     */ {
/*     */   private final ChunkedInput<ByteBuf> input;
/*     */   private final Http2FrameStream stream;
/*     */   private boolean endStreamSent;
/*     */   
/*     */   public Http2DataChunkedInput(ChunkedInput<ByteBuf> input, Http2FrameStream stream) {
/*  59 */     this.input = (ChunkedInput<ByteBuf>)ObjectUtil.checkNotNull(input, "input");
/*  60 */     this.stream = (Http2FrameStream)ObjectUtil.checkNotNull(stream, "stream");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEndOfInput() throws Exception {
/*  65 */     if (this.input.isEndOfInput())
/*     */     {
/*  67 */       return this.endStreamSent;
/*     */     }
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws Exception {
/*  74 */     this.input.close();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Http2DataFrame readChunk(ChannelHandlerContext ctx) throws Exception {
/*  80 */     return readChunk(ctx.alloc());
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2DataFrame readChunk(ByteBufAllocator allocator) throws Exception {
/*  85 */     if (this.endStreamSent) {
/*  86 */       return null;
/*     */     }
/*     */     
/*  89 */     if (this.input.isEndOfInput()) {
/*  90 */       this.endStreamSent = true;
/*  91 */       return (new DefaultHttp2DataFrame(true)).stream(this.stream);
/*     */     } 
/*     */     
/*  94 */     ByteBuf buf = (ByteBuf)this.input.readChunk(allocator);
/*  95 */     if (buf == null) {
/*  96 */       return null;
/*     */     }
/*     */     
/*  99 */     Http2DataFrame dataFrame = (new DefaultHttp2DataFrame(buf, this.input.isEndOfInput())).stream(this.stream);
/* 100 */     if (dataFrame.isEndStream()) {
/* 101 */       this.endStreamSent = true;
/*     */     }
/*     */     
/* 104 */     return dataFrame;
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() {
/* 109 */     return this.input.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public long progress() {
/* 114 */     return this.input.progress();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2DataChunkedInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */