/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.socket.ChannelInputShutdownReadComplete;
/*     */ import io.netty.channel.socket.ChannelOutputShutdownEvent;
/*     */ import io.netty.handler.ssl.SslCloseCompletionEvent;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Http2MultiplexCodec
/*     */   extends Http2FrameCodec
/*     */ {
/*     */   private final ChannelHandler inboundStreamHandler;
/*     */   private final ChannelHandler upgradeStreamHandler;
/*  95 */   private final Queue<AbstractHttp2StreamChannel> readCompletePendingQueue = new MaxCapacityQueue<AbstractHttp2StreamChannel>(new ArrayDeque<AbstractHttp2StreamChannel>(8), 100);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean parentReadInProgress;
/*     */ 
/*     */ 
/*     */   
/*     */   private int idCount;
/*     */ 
/*     */   
/*     */   volatile ChannelHandlerContext ctx;
/*     */ 
/*     */ 
/*     */   
/*     */   Http2MultiplexCodec(Http2ConnectionEncoder encoder, Http2ConnectionDecoder decoder, Http2Settings initialSettings, ChannelHandler inboundStreamHandler, ChannelHandler upgradeStreamHandler, boolean decoupleCloseAndGoAway, boolean flushPreface) {
/* 111 */     super(encoder, decoder, initialSettings, decoupleCloseAndGoAway, flushPreface);
/* 112 */     this.inboundStreamHandler = inboundStreamHandler;
/* 113 */     this.upgradeStreamHandler = upgradeStreamHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onHttpClientUpgrade() throws Http2Exception {
/* 119 */     if (this.upgradeStreamHandler == null) {
/* 120 */       throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, "Client is misconfigured for upgrade requests", new Object[0]);
/*     */     }
/*     */     
/* 123 */     super.onHttpClientUpgrade();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void handlerAdded0(ChannelHandlerContext ctx) throws Exception {
/* 128 */     if (ctx.executor() != ctx.channel().eventLoop()) {
/* 129 */       throw new IllegalStateException("EventExecutor must be EventLoop of Channel");
/*     */     }
/* 131 */     this.ctx = ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void handlerRemoved0(ChannelHandlerContext ctx) throws Exception {
/* 136 */     super.handlerRemoved0(ctx);
/*     */     
/* 138 */     this.readCompletePendingQueue.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   final void onHttp2Frame(ChannelHandlerContext ctx, Http2Frame frame) {
/* 143 */     if (frame instanceof Http2StreamFrame) {
/* 144 */       Http2StreamFrame streamFrame = (Http2StreamFrame)frame;
/*     */       
/* 146 */       AbstractHttp2StreamChannel channel = (AbstractHttp2StreamChannel)((Http2FrameCodec.DefaultHttp2FrameStream)streamFrame.stream()).attachment;
/* 147 */       channel.fireChildRead(streamFrame);
/*     */       return;
/*     */     } 
/* 150 */     if (frame instanceof Http2GoAwayFrame) {
/* 151 */       onHttp2GoAwayFrame(ctx, (Http2GoAwayFrame)frame);
/*     */     }
/*     */     
/* 154 */     ctx.fireChannelRead(frame);
/*     */   } final void onHttp2StreamStateChanged(ChannelHandlerContext ctx, Http2FrameCodec.DefaultHttp2FrameStream stream) {
/*     */     Http2MultiplexCodecStreamChannel streamChannel;
/*     */     ChannelFuture future;
/*     */     AbstractHttp2StreamChannel channel;
/* 159 */     switch (stream.state()) {
/*     */       case HALF_CLOSED_LOCAL:
/* 161 */         if (stream.id() != 1) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       case HALF_CLOSED_REMOTE:
/*     */       case OPEN:
/* 169 */         if (stream.attachment != null) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 175 */         if (stream.id() == 1 && !connection().isServer()) {
/*     */ 
/*     */           
/* 178 */           assert this.upgradeStreamHandler != null;
/* 179 */           streamChannel = new Http2MultiplexCodecStreamChannel(stream, this.upgradeStreamHandler);
/* 180 */           streamChannel.closeOutbound();
/*     */         } else {
/* 182 */           streamChannel = new Http2MultiplexCodecStreamChannel(stream, this.inboundStreamHandler);
/*     */         } 
/* 184 */         future = ctx.channel().eventLoop().register(streamChannel);
/* 185 */         if (future.isDone()) {
/* 186 */           Http2MultiplexHandler.registerDone(future); break;
/*     */         } 
/* 188 */         future.addListener((GenericFutureListener)Http2MultiplexHandler.CHILD_CHANNEL_REGISTRATION_LISTENER);
/*     */         break;
/*     */       
/*     */       case CLOSED:
/* 192 */         channel = (AbstractHttp2StreamChannel)stream.attachment;
/* 193 */         if (channel != null) {
/* 194 */           channel.streamClosed();
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Http2StreamChannel newOutboundStream() {
/* 205 */     return new Http2MultiplexCodecStreamChannel(newStream(), null);
/*     */   }
/*     */ 
/*     */   
/*     */   final void onHttp2FrameStreamException(ChannelHandlerContext ctx, Http2FrameStreamException cause) {
/* 210 */     Http2FrameStream stream = cause.stream();
/* 211 */     AbstractHttp2StreamChannel channel = (AbstractHttp2StreamChannel)((Http2FrameCodec.DefaultHttp2FrameStream)stream).attachment;
/*     */     
/*     */     try {
/* 214 */       channel.pipeline().fireExceptionCaught(cause.getCause());
/*     */     }
/*     */     finally {
/*     */       
/* 218 */       channel.closeWithError(cause.error());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void onHttp2GoAwayFrame(ChannelHandlerContext ctx, final Http2GoAwayFrame goAwayFrame) {
/* 223 */     if (goAwayFrame.lastStreamId() == Integer.MAX_VALUE) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 229 */       forEachActiveStream(new Http2FrameStreamVisitor()
/*     */           {
/*     */             public boolean visit(Http2FrameStream stream) {
/* 232 */               int streamId = stream.id();
/* 233 */               AbstractHttp2StreamChannel channel = (AbstractHttp2StreamChannel)((Http2FrameCodec.DefaultHttp2FrameStream)stream).attachment;
/*     */               
/* 235 */               if (streamId > goAwayFrame.lastStreamId() && Http2MultiplexCodec.this.connection().local().isValidStreamId(streamId)) {
/* 236 */                 channel.pipeline().fireUserEventTriggered(goAwayFrame.retainedDuplicate());
/*     */               }
/* 238 */               return true;
/*     */             }
/*     */           });
/* 241 */     } catch (Http2Exception e) {
/* 242 */       ctx.fireExceptionCaught(e);
/* 243 */       ctx.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/* 252 */     processPendingReadCompleteQueue();
/* 253 */     channelReadComplete0(ctx);
/*     */   }
/*     */   
/*     */   private void processPendingReadCompleteQueue() {
/* 257 */     this.parentReadInProgress = true;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       while (true) {
/* 263 */         AbstractHttp2StreamChannel childChannel = this.readCompletePendingQueue.poll();
/* 264 */         if (childChannel == null) {
/*     */           break;
/*     */         }
/* 267 */         childChannel.fireChildReadComplete();
/*     */       } 
/*     */     } finally {
/* 270 */       this.parentReadInProgress = false;
/* 271 */       this.readCompletePendingQueue.clear();
/*     */       
/* 273 */       flush0(this.ctx);
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 278 */     this.parentReadInProgress = true;
/* 279 */     super.channelRead(ctx, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void channelWritabilityChanged(ChannelHandlerContext ctx) throws Exception {
/* 284 */     if (ctx.channel().isWritable())
/*     */     {
/*     */       
/* 287 */       forEachActiveStream(AbstractHttp2StreamChannel.WRITABLE_VISITOR);
/*     */     }
/*     */     
/* 290 */     super.channelWritabilityChanged(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   final void onUserEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
/* 295 */     if (evt == ChannelInputShutdownReadComplete.INSTANCE) {
/* 296 */       forEachActiveStream(AbstractHttp2StreamChannel.CHANNEL_INPUT_SHUTDOWN_READ_COMPLETE_VISITOR);
/* 297 */     } else if (evt == ChannelOutputShutdownEvent.INSTANCE) {
/* 298 */       forEachActiveStream(AbstractHttp2StreamChannel.CHANNEL_OUTPUT_SHUTDOWN_EVENT_VISITOR);
/* 299 */     } else if (evt == SslCloseCompletionEvent.SUCCESS) {
/* 300 */       forEachActiveStream(AbstractHttp2StreamChannel.SSL_CLOSE_COMPLETION_EVENT_VISITOR);
/*     */     } 
/* 302 */     super.onUserEventTriggered(ctx, evt);
/*     */   }
/*     */   
/*     */   final void flush0(ChannelHandlerContext ctx) {
/* 306 */     flush(ctx);
/*     */   }
/*     */   
/*     */   private final class Http2MultiplexCodecStreamChannel
/*     */     extends AbstractHttp2StreamChannel {
/*     */     Http2MultiplexCodecStreamChannel(Http2FrameCodec.DefaultHttp2FrameStream stream, ChannelHandler inboundHandler) {
/* 312 */       super(stream, ++Http2MultiplexCodec.this.idCount, inboundHandler);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isParentReadInProgress() {
/* 317 */       return Http2MultiplexCodec.this.parentReadInProgress;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void addChannelToReadCompletePendingQueue() {
/* 324 */       while (!Http2MultiplexCodec.this.readCompletePendingQueue.offer(this)) {
/* 325 */         Http2MultiplexCodec.this.processPendingReadCompleteQueue();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected ChannelHandlerContext parentContext() {
/* 331 */       return Http2MultiplexCodec.this.ctx;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ChannelFuture write0(ChannelHandlerContext ctx, Object msg) {
/* 336 */       ChannelPromise promise = ctx.newPromise();
/* 337 */       Http2MultiplexCodec.this.write(ctx, msg, promise);
/* 338 */       return (ChannelFuture)promise;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void flush0(ChannelHandlerContext ctx) {
/* 343 */       Http2MultiplexCodec.this.flush0(ctx);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2MultiplexCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */