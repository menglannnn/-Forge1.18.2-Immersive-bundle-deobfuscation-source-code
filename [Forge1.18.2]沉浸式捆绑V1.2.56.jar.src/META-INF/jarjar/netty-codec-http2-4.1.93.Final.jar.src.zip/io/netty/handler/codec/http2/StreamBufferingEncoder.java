/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamBufferingEncoder
/*     */   extends DecoratingHttp2ConnectionEncoder
/*     */ {
/*     */   public static final class Http2ChannelClosedException
/*     */     extends Http2Exception
/*     */   {
/*     */     private static final long serialVersionUID = 4768543442094476971L;
/*     */     
/*     */     public Http2ChannelClosedException() {
/*  68 */       super(Http2Error.REFUSED_STREAM, "Connection closed");
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class GoAwayDetail {
/*     */     private final int lastStreamId;
/*     */     private final long errorCode;
/*     */     private final byte[] debugData;
/*     */     
/*     */     GoAwayDetail(int lastStreamId, long errorCode, byte[] debugData) {
/*  78 */       this.lastStreamId = lastStreamId;
/*  79 */       this.errorCode = errorCode;
/*  80 */       this.debugData = (byte[])debugData.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class Http2GoAwayException
/*     */     extends Http2Exception
/*     */   {
/*     */     private static final long serialVersionUID = 1326785622777291198L;
/*     */     
/*     */     private final StreamBufferingEncoder.GoAwayDetail goAwayDetail;
/*     */     
/*     */     public Http2GoAwayException(int lastStreamId, long errorCode, byte[] debugData) {
/*  93 */       this(new StreamBufferingEncoder.GoAwayDetail(lastStreamId, errorCode, debugData));
/*     */     }
/*     */     
/*     */     Http2GoAwayException(StreamBufferingEncoder.GoAwayDetail goAwayDetail) {
/*  97 */       super(Http2Error.STREAM_CLOSED);
/*  98 */       this.goAwayDetail = goAwayDetail;
/*     */     }
/*     */     
/*     */     public int lastStreamId() {
/* 102 */       return this.goAwayDetail.lastStreamId;
/*     */     }
/*     */     
/*     */     public long errorCode() {
/* 106 */       return this.goAwayDetail.errorCode;
/*     */     }
/*     */     
/*     */     public byte[] debugData() {
/* 110 */       return (byte[])this.goAwayDetail.debugData.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private final TreeMap<Integer, PendingStream> pendingStreams = new TreeMap<Integer, PendingStream>();
/*     */   private int maxConcurrentStreams;
/*     */   private boolean closed;
/*     */   private GoAwayDetail goAwayDetail;
/*     */   
/*     */   public StreamBufferingEncoder(Http2ConnectionEncoder delegate) {
/* 124 */     this(delegate, 100);
/*     */   }
/*     */   
/*     */   public StreamBufferingEncoder(Http2ConnectionEncoder delegate, int initialMaxConcurrentStreams) {
/* 128 */     super(delegate);
/* 129 */     this.maxConcurrentStreams = initialMaxConcurrentStreams;
/* 130 */     connection().addListener(new Http2ConnectionAdapter()
/*     */         {
/*     */           public void onGoAwayReceived(int lastStreamId, long errorCode, ByteBuf debugData)
/*     */           {
/* 134 */             StreamBufferingEncoder.this.goAwayDetail = new StreamBufferingEncoder.GoAwayDetail(lastStreamId, errorCode, 
/*     */ 
/*     */                 
/* 137 */                 ByteBufUtil.getBytes(debugData, debugData.readerIndex(), debugData.readableBytes(), false));
/* 138 */             StreamBufferingEncoder.this.cancelGoAwayStreams(StreamBufferingEncoder.this.goAwayDetail);
/*     */           }
/*     */ 
/*     */           
/*     */           public void onStreamClosed(Http2Stream stream) {
/* 143 */             StreamBufferingEncoder.this.tryCreatePendingStreams();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int numBufferedStreams() {
/* 152 */     return this.pendingStreams.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeHeaders(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endStream, ChannelPromise promise) {
/* 158 */     return writeHeaders(ctx, streamId, headers, 0, (short)16, false, padding, endStream, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeHeaders(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream, ChannelPromise promise) {
/* 166 */     if (this.closed) {
/* 167 */       return (ChannelFuture)promise.setFailure(new Http2ChannelClosedException());
/*     */     }
/* 169 */     if (isExistingStream(streamId) || canCreateStream()) {
/* 170 */       return super.writeHeaders(ctx, streamId, headers, streamDependency, weight, exclusive, padding, endOfStream, promise);
/*     */     }
/*     */     
/* 173 */     if (this.goAwayDetail != null) {
/* 174 */       return (ChannelFuture)promise.setFailure(new Http2GoAwayException(this.goAwayDetail));
/*     */     }
/* 176 */     PendingStream pendingStream = this.pendingStreams.get(Integer.valueOf(streamId));
/* 177 */     if (pendingStream == null) {
/* 178 */       pendingStream = new PendingStream(ctx, streamId);
/* 179 */       this.pendingStreams.put(Integer.valueOf(streamId), pendingStream);
/*     */     } 
/* 181 */     pendingStream.frames.add(new HeadersFrame(headers, streamDependency, weight, exclusive, padding, endOfStream, promise));
/*     */     
/* 183 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeRstStream(ChannelHandlerContext ctx, int streamId, long errorCode, ChannelPromise promise) {
/* 189 */     if (isExistingStream(streamId)) {
/* 190 */       return super.writeRstStream(ctx, streamId, errorCode, promise);
/*     */     }
/*     */ 
/*     */     
/* 194 */     PendingStream stream = this.pendingStreams.remove(Integer.valueOf(streamId));
/* 195 */     if (stream != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 200 */       stream.close(null);
/* 201 */       promise.setSuccess();
/*     */     } else {
/* 203 */       promise.setFailure(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Stream does not exist %d", new Object[] { Integer.valueOf(streamId) }));
/*     */     } 
/* 205 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeData(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream, ChannelPromise promise) {
/* 211 */     if (isExistingStream(streamId)) {
/* 212 */       return super.writeData(ctx, streamId, data, padding, endOfStream, promise);
/*     */     }
/* 214 */     PendingStream pendingStream = this.pendingStreams.get(Integer.valueOf(streamId));
/* 215 */     if (pendingStream != null) {
/* 216 */       pendingStream.frames.add(new DataFrame(data, padding, endOfStream, promise));
/*     */     } else {
/* 218 */       ReferenceCountUtil.safeRelease(data);
/* 219 */       promise.setFailure(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Stream does not exist %d", new Object[] { Integer.valueOf(streamId) }));
/*     */     } 
/* 221 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remoteSettings(Http2Settings settings) throws Http2Exception {
/* 228 */     super.remoteSettings(settings);
/*     */ 
/*     */     
/* 231 */     this.maxConcurrentStreams = connection().local().maxActiveStreams();
/*     */ 
/*     */     
/* 234 */     tryCreatePendingStreams();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 240 */       if (!this.closed) {
/* 241 */         this.closed = true;
/*     */ 
/*     */         
/* 244 */         Http2ChannelClosedException e = new Http2ChannelClosedException();
/* 245 */         while (!this.pendingStreams.isEmpty()) {
/* 246 */           PendingStream stream = (PendingStream)this.pendingStreams.pollFirstEntry().getValue();
/* 247 */           stream.close(e);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 251 */       super.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tryCreatePendingStreams() {
/* 256 */     while (!this.pendingStreams.isEmpty() && canCreateStream()) {
/* 257 */       Map.Entry<Integer, PendingStream> entry = this.pendingStreams.pollFirstEntry();
/* 258 */       PendingStream pendingStream = entry.getValue();
/*     */       try {
/* 260 */         pendingStream.sendFrames();
/* 261 */       } catch (Throwable t) {
/* 262 */         pendingStream.close(t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cancelGoAwayStreams(GoAwayDetail goAwayDetail) {
/* 268 */     Iterator<PendingStream> iter = this.pendingStreams.values().iterator();
/* 269 */     Exception e = new Http2GoAwayException(goAwayDetail);
/* 270 */     while (iter.hasNext()) {
/* 271 */       PendingStream stream = iter.next();
/* 272 */       if (stream.streamId > goAwayDetail.lastStreamId) {
/* 273 */         iter.remove();
/* 274 */         stream.close(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canCreateStream() {
/* 283 */     return (connection().local().numActiveStreams() < this.maxConcurrentStreams);
/*     */   }
/*     */   
/*     */   private boolean isExistingStream(int streamId) {
/* 287 */     return (streamId <= connection().local().lastStreamCreated());
/*     */   }
/*     */   
/*     */   private static final class PendingStream {
/*     */     final ChannelHandlerContext ctx;
/*     */     final int streamId;
/* 293 */     final Queue<StreamBufferingEncoder.Frame> frames = new ArrayDeque<StreamBufferingEncoder.Frame>(2);
/*     */     
/*     */     PendingStream(ChannelHandlerContext ctx, int streamId) {
/* 296 */       this.ctx = ctx;
/* 297 */       this.streamId = streamId;
/*     */     }
/*     */     
/*     */     void sendFrames() {
/* 301 */       for (StreamBufferingEncoder.Frame frame : this.frames) {
/* 302 */         frame.send(this.ctx, this.streamId);
/*     */       }
/*     */     }
/*     */     
/*     */     void close(Throwable t) {
/* 307 */       for (StreamBufferingEncoder.Frame frame : this.frames)
/* 308 */         frame.release(t); 
/*     */     }
/*     */   }
/*     */   
/*     */   private static abstract class Frame
/*     */   {
/*     */     final ChannelPromise promise;
/*     */     
/*     */     Frame(ChannelPromise promise) {
/* 317 */       this.promise = promise;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void release(Throwable t) {
/* 324 */       if (t == null) {
/* 325 */         this.promise.setSuccess();
/*     */       } else {
/* 327 */         this.promise.setFailure(t);
/*     */       } 
/*     */     }
/*     */     
/*     */     abstract void send(ChannelHandlerContext param1ChannelHandlerContext, int param1Int);
/*     */   }
/*     */   
/*     */   private final class HeadersFrame
/*     */     extends Frame {
/*     */     final Http2Headers headers;
/*     */     final int streamDependency;
/*     */     final short weight;
/*     */     final boolean exclusive;
/*     */     final int padding;
/*     */     final boolean endOfStream;
/*     */     
/*     */     HeadersFrame(Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream, ChannelPromise promise) {
/* 344 */       super(promise);
/* 345 */       this.headers = headers;
/* 346 */       this.streamDependency = streamDependency;
/* 347 */       this.weight = weight;
/* 348 */       this.exclusive = exclusive;
/* 349 */       this.padding = padding;
/* 350 */       this.endOfStream = endOfStream;
/*     */     }
/*     */ 
/*     */     
/*     */     void send(ChannelHandlerContext ctx, int streamId) {
/* 355 */       StreamBufferingEncoder.this.writeHeaders(ctx, streamId, this.headers, this.streamDependency, this.weight, this.exclusive, this.padding, this.endOfStream, this.promise);
/*     */     }
/*     */   }
/*     */   
/*     */   private final class DataFrame extends Frame {
/*     */     final ByteBuf data;
/*     */     final int padding;
/*     */     final boolean endOfStream;
/*     */     
/*     */     DataFrame(ByteBuf data, int padding, boolean endOfStream, ChannelPromise promise) {
/* 365 */       super(promise);
/* 366 */       this.data = data;
/* 367 */       this.padding = padding;
/* 368 */       this.endOfStream = endOfStream;
/*     */     }
/*     */ 
/*     */     
/*     */     void release(Throwable t) {
/* 373 */       super.release(t);
/* 374 */       ReferenceCountUtil.safeRelease(this.data);
/*     */     }
/*     */ 
/*     */     
/*     */     void send(ChannelHandlerContext ctx, int streamId) {
/* 379 */       StreamBufferingEncoder.this.writeData(ctx, streamId, this.data, this.padding, this.endOfStream, this.promise);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\StreamBufferingEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */