/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerAdapter;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Http2MultiplexCodecBuilder
/*     */   extends AbstractHttp2ConnectionHandlerBuilder<Http2MultiplexCodec, Http2MultiplexCodecBuilder>
/*     */ {
/*     */   private Http2FrameWriter frameWriter;
/*     */   final ChannelHandler childHandler;
/*     */   private ChannelHandler upgradeStreamHandler;
/*     */   
/*     */   Http2MultiplexCodecBuilder(boolean server, ChannelHandler childHandler) {
/*  39 */     server(server);
/*  40 */     this.childHandler = checkSharable((ChannelHandler)ObjectUtil.checkNotNull(childHandler, "childHandler"));
/*     */     
/*  42 */     gracefulShutdownTimeoutMillis(0L);
/*     */   }
/*     */   
/*     */   private static ChannelHandler checkSharable(ChannelHandler handler) {
/*  46 */     if (handler instanceof ChannelHandlerAdapter && !((ChannelHandlerAdapter)handler).isSharable() && 
/*  47 */       !handler.getClass().isAnnotationPresent((Class)ChannelHandler.Sharable.class)) {
/*  48 */       throw new IllegalArgumentException("The handler must be Sharable");
/*     */     }
/*  50 */     return handler;
/*     */   }
/*     */ 
/*     */   
/*     */   Http2MultiplexCodecBuilder frameWriter(Http2FrameWriter frameWriter) {
/*  55 */     this.frameWriter = (Http2FrameWriter)ObjectUtil.checkNotNull(frameWriter, "frameWriter");
/*  56 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2MultiplexCodecBuilder forClient(ChannelHandler childHandler) {
/*  66 */     return new Http2MultiplexCodecBuilder(false, childHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2MultiplexCodecBuilder forServer(ChannelHandler childHandler) {
/*  76 */     return new Http2MultiplexCodecBuilder(true, childHandler);
/*     */   }
/*     */   
/*     */   public Http2MultiplexCodecBuilder withUpgradeStreamHandler(ChannelHandler upgradeStreamHandler) {
/*  80 */     if (isServer()) {
/*  81 */       throw new IllegalArgumentException("Server codecs don't use an extra handler for the upgrade stream");
/*     */     }
/*  83 */     this.upgradeStreamHandler = upgradeStreamHandler;
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Settings initialSettings() {
/*  89 */     return super.initialSettings();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder initialSettings(Http2Settings settings) {
/*  94 */     return super.initialSettings(settings);
/*     */   }
/*     */ 
/*     */   
/*     */   public long gracefulShutdownTimeoutMillis() {
/*  99 */     return super.gracefulShutdownTimeoutMillis();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder gracefulShutdownTimeoutMillis(long gracefulShutdownTimeoutMillis) {
/* 104 */     return super.gracefulShutdownTimeoutMillis(gracefulShutdownTimeoutMillis);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isServer() {
/* 109 */     return super.isServer();
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxReservedStreams() {
/* 114 */     return super.maxReservedStreams();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder maxReservedStreams(int maxReservedStreams) {
/* 119 */     return super.maxReservedStreams(maxReservedStreams);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValidateHeaders() {
/* 124 */     return super.isValidateHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder validateHeaders(boolean validateHeaders) {
/* 129 */     return super.validateHeaders(validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameLogger frameLogger() {
/* 134 */     return super.frameLogger();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder frameLogger(Http2FrameLogger frameLogger) {
/* 139 */     return super.frameLogger(frameLogger);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean encoderEnforceMaxConcurrentStreams() {
/* 144 */     return super.encoderEnforceMaxConcurrentStreams();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder encoderEnforceMaxConcurrentStreams(boolean encoderEnforceMaxConcurrentStreams) {
/* 149 */     return super.encoderEnforceMaxConcurrentStreams(encoderEnforceMaxConcurrentStreams);
/*     */   }
/*     */ 
/*     */   
/*     */   public int encoderEnforceMaxQueuedControlFrames() {
/* 154 */     return super.encoderEnforceMaxQueuedControlFrames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder encoderEnforceMaxQueuedControlFrames(int maxQueuedControlFrames) {
/* 159 */     return super.encoderEnforceMaxQueuedControlFrames(maxQueuedControlFrames);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector() {
/* 164 */     return super.headerSensitivityDetector();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder headerSensitivityDetector(Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector) {
/* 170 */     return super.headerSensitivityDetector(headerSensitivityDetector);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder encoderIgnoreMaxHeaderListSize(boolean ignoreMaxHeaderListSize) {
/* 175 */     return super.encoderIgnoreMaxHeaderListSize(ignoreMaxHeaderListSize);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Http2MultiplexCodecBuilder initialHuffmanDecodeCapacity(int initialHuffmanDecodeCapacity) {
/* 181 */     return super.initialHuffmanDecodeCapacity(initialHuffmanDecodeCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder autoAckSettingsFrame(boolean autoAckSettings) {
/* 186 */     return super.autoAckSettingsFrame(autoAckSettings);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder autoAckPingFrame(boolean autoAckPingFrame) {
/* 191 */     return super.autoAckPingFrame(autoAckPingFrame);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder decoupleCloseAndGoAway(boolean decoupleCloseAndGoAway) {
/* 196 */     return super.decoupleCloseAndGoAway(decoupleCloseAndGoAway);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder flushPreface(boolean flushPreface) {
/* 201 */     return super.flushPreface(flushPreface);
/*     */   }
/*     */ 
/*     */   
/*     */   public int decoderEnforceMaxConsecutiveEmptyDataFrames() {
/* 206 */     return super.decoderEnforceMaxConsecutiveEmptyDataFrames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodecBuilder decoderEnforceMaxConsecutiveEmptyDataFrames(int maxConsecutiveEmptyFrames) {
/* 211 */     return super.decoderEnforceMaxConsecutiveEmptyDataFrames(maxConsecutiveEmptyFrames);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2MultiplexCodec build() {
/* 216 */     Http2FrameWriter frameWriter = this.frameWriter;
/* 217 */     if (frameWriter != null) {
/*     */ 
/*     */       
/* 220 */       DefaultHttp2Connection connection = new DefaultHttp2Connection(isServer(), maxReservedStreams());
/* 221 */       Long maxHeaderListSize = initialSettings().maxHeaderListSize();
/*     */ 
/*     */       
/* 224 */       Http2FrameReader frameReader = new DefaultHttp2FrameReader((maxHeaderListSize == null) ? new DefaultHttp2HeadersDecoder(isValidateHeaders()) : new DefaultHttp2HeadersDecoder(isValidateHeaders(), maxHeaderListSize.longValue()));
/*     */       
/* 226 */       if (frameLogger() != null) {
/* 227 */         frameWriter = new Http2OutboundFrameLogger(frameWriter, frameLogger());
/* 228 */         frameReader = new Http2InboundFrameLogger(frameReader, frameLogger());
/*     */       } 
/* 230 */       Http2ConnectionEncoder encoder = new DefaultHttp2ConnectionEncoder(connection, frameWriter);
/* 231 */       if (encoderEnforceMaxConcurrentStreams()) {
/* 232 */         encoder = new StreamBufferingEncoder(encoder);
/*     */       }
/*     */       
/* 235 */       Http2ConnectionDecoder decoder = new DefaultHttp2ConnectionDecoder(connection, encoder, frameReader, promisedRequestVerifier(), isAutoAckSettingsFrame(), isAutoAckPingFrame());
/*     */       
/* 237 */       int maxConsecutiveEmptyDataFrames = decoderEnforceMaxConsecutiveEmptyDataFrames();
/* 238 */       if (maxConsecutiveEmptyDataFrames > 0) {
/* 239 */         decoder = new Http2EmptyDataFrameConnectionDecoder(decoder, maxConsecutiveEmptyDataFrames);
/*     */       }
/*     */       
/* 242 */       return build(decoder, encoder, initialSettings());
/*     */     } 
/* 244 */     return super.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2MultiplexCodec build(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
/* 251 */     Http2MultiplexCodec codec = new Http2MultiplexCodec(encoder, decoder, initialSettings, this.childHandler, this.upgradeStreamHandler, decoupleCloseAndGoAway(), flushPreface());
/* 252 */     codec.gracefulShutdownTimeoutMillis(gracefulShutdownTimeoutMillis());
/* 253 */     return codec;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2MultiplexCodecBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */