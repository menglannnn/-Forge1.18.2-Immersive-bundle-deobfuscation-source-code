/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.embedded.EmbeddedChannel;
/*     */ import io.netty.handler.codec.compression.Brotli;
/*     */ import io.netty.handler.codec.compression.BrotliDecoder;
/*     */ import io.netty.handler.codec.compression.ZlibCodecFactory;
/*     */ import io.netty.handler.codec.compression.ZlibWrapper;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaderValues;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingDecompressorFrameListener
/*     */   extends Http2FrameListenerDecorator
/*     */ {
/*     */   private final Http2Connection connection;
/*     */   private final boolean strict;
/*     */   private boolean flowControllerInitialized;
/*     */   private final Http2Connection.PropertyKey propertyKey;
/*     */   
/*     */   public DelegatingDecompressorFrameListener(Http2Connection connection, Http2FrameListener listener) {
/*  54 */     this(connection, listener, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public DelegatingDecompressorFrameListener(Http2Connection connection, Http2FrameListener listener, boolean strict) {
/*  59 */     super(listener);
/*  60 */     this.connection = connection;
/*  61 */     this.strict = strict;
/*     */     
/*  63 */     this.propertyKey = connection.newKey();
/*  64 */     connection.addListener(new Http2ConnectionAdapter()
/*     */         {
/*     */           public void onStreamRemoved(Http2Stream stream) {
/*  67 */             DelegatingDecompressorFrameListener.Http2Decompressor decompressor = DelegatingDecompressorFrameListener.this.decompressor(stream);
/*  68 */             if (decompressor != null) {
/*  69 */               DelegatingDecompressorFrameListener.cleanup(decompressor);
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int onDataRead(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream) throws Http2Exception {
/*  78 */     Http2Stream stream = this.connection.stream(streamId);
/*  79 */     Http2Decompressor decompressor = decompressor(stream);
/*  80 */     if (decompressor == null)
/*     */     {
/*  82 */       return this.listener.onDataRead(ctx, streamId, data, padding, endOfStream);
/*     */     }
/*     */     
/*  85 */     EmbeddedChannel channel = decompressor.decompressor();
/*  86 */     int compressedBytes = data.readableBytes() + padding;
/*  87 */     decompressor.incrementCompressedBytes(compressedBytes);
/*     */     
/*     */     try {
/*  90 */       channel.writeInbound(new Object[] { data.retain() });
/*  91 */       ByteBuf buf = nextReadableBuf(channel);
/*  92 */       if (buf == null && endOfStream && channel.finish()) {
/*  93 */         buf = nextReadableBuf(channel);
/*     */       }
/*  95 */       if (buf == null) {
/*  96 */         if (endOfStream) {
/*  97 */           this.listener.onDataRead(ctx, streamId, Unpooled.EMPTY_BUFFER, padding, true);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 103 */         decompressor.incrementDecompressedBytes(compressedBytes);
/* 104 */         return compressedBytes;
/*     */       } 
/*     */       try {
/* 107 */         Http2LocalFlowController flowController = this.connection.local().flowController();
/* 108 */         decompressor.incrementDecompressedBytes(padding);
/*     */         while (true) {
/* 110 */           ByteBuf nextBuf = nextReadableBuf(channel);
/* 111 */           boolean decompressedEndOfStream = (nextBuf == null && endOfStream);
/* 112 */           if (decompressedEndOfStream && channel.finish()) {
/* 113 */             nextBuf = nextReadableBuf(channel);
/* 114 */             decompressedEndOfStream = (nextBuf == null);
/*     */           } 
/*     */           
/* 117 */           decompressor.incrementDecompressedBytes(buf.readableBytes());
/*     */ 
/*     */ 
/*     */           
/* 121 */           flowController.consumeBytes(stream, this.listener
/* 122 */               .onDataRead(ctx, streamId, buf, padding, decompressedEndOfStream));
/* 123 */           if (nextBuf == null) {
/*     */             break;
/*     */           }
/*     */           
/* 127 */           padding = 0;
/* 128 */           buf.release();
/* 129 */           buf = nextBuf;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 134 */         return 0;
/*     */       } finally {
/* 136 */         buf.release();
/*     */       } 
/* 138 */     } catch (Http2Exception e) {
/* 139 */       throw e;
/* 140 */     } catch (Throwable t) {
/* 141 */       throw Http2Exception.streamError(stream.id(), Http2Error.INTERNAL_ERROR, t, "Decompressor error detected while delegating data read on streamId %d", new Object[] {
/* 142 */             Integer.valueOf(stream.id())
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endStream) throws Http2Exception {
/* 149 */     initDecompressor(ctx, streamId, headers, endStream);
/* 150 */     this.listener.onHeadersRead(ctx, streamId, headers, padding, endStream);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endStream) throws Http2Exception {
/* 156 */     initDecompressor(ctx, streamId, headers, endStream);
/* 157 */     this.listener.onHeadersRead(ctx, streamId, headers, streamDependency, weight, exclusive, padding, endStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EmbeddedChannel newContentDecompressor(ChannelHandlerContext ctx, CharSequence contentEncoding) throws Http2Exception {
/* 171 */     if (HttpHeaderValues.GZIP.contentEqualsIgnoreCase(contentEncoding) || HttpHeaderValues.X_GZIP.contentEqualsIgnoreCase(contentEncoding)) {
/* 172 */       return new EmbeddedChannel(ctx.channel().id(), ctx.channel().metadata().hasDisconnect(), ctx
/* 173 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)ZlibCodecFactory.newZlibDecoder(ZlibWrapper.GZIP) });
/*     */     }
/* 175 */     if (HttpHeaderValues.DEFLATE.contentEqualsIgnoreCase(contentEncoding) || HttpHeaderValues.X_DEFLATE.contentEqualsIgnoreCase(contentEncoding)) {
/* 176 */       ZlibWrapper wrapper = this.strict ? ZlibWrapper.ZLIB : ZlibWrapper.ZLIB_OR_NONE;
/*     */       
/* 178 */       return new EmbeddedChannel(ctx.channel().id(), ctx.channel().metadata().hasDisconnect(), ctx
/* 179 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)ZlibCodecFactory.newZlibDecoder(wrapper) });
/*     */     } 
/* 181 */     if (Brotli.isAvailable() && HttpHeaderValues.BR.contentEqualsIgnoreCase(contentEncoding)) {
/* 182 */       return new EmbeddedChannel(ctx.channel().id(), ctx.channel().metadata().hasDisconnect(), ctx
/* 183 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)new BrotliDecoder() });
/*     */     }
/*     */     
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CharSequence getTargetContentEncoding(CharSequence contentEncoding) throws Http2Exception {
/* 199 */     return (CharSequence)HttpHeaderValues.IDENTITY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initDecompressor(ChannelHandlerContext ctx, int streamId, Http2Headers headers, boolean endOfStream) throws Http2Exception {
/* 214 */     Http2Stream stream = this.connection.stream(streamId);
/* 215 */     if (stream == null) {
/*     */       return;
/*     */     }
/*     */     
/* 219 */     Http2Decompressor decompressor = decompressor(stream);
/* 220 */     if (decompressor == null && !endOfStream) {
/*     */       AsciiString asciiString;
/* 222 */       CharSequence contentEncoding = (CharSequence)headers.get(HttpHeaderNames.CONTENT_ENCODING);
/* 223 */       if (contentEncoding == null) {
/* 224 */         asciiString = HttpHeaderValues.IDENTITY;
/*     */       }
/* 226 */       EmbeddedChannel channel = newContentDecompressor(ctx, (CharSequence)asciiString);
/* 227 */       if (channel != null) {
/* 228 */         decompressor = new Http2Decompressor(channel);
/* 229 */         stream.setProperty(this.propertyKey, decompressor);
/*     */ 
/*     */         
/* 232 */         CharSequence targetContentEncoding = getTargetContentEncoding((CharSequence)asciiString);
/* 233 */         if (HttpHeaderValues.IDENTITY.contentEqualsIgnoreCase(targetContentEncoding)) {
/* 234 */           headers.remove(HttpHeaderNames.CONTENT_ENCODING);
/*     */         } else {
/* 236 */           headers.set(HttpHeaderNames.CONTENT_ENCODING, targetContentEncoding);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 241 */     if (decompressor != null) {
/*     */ 
/*     */ 
/*     */       
/* 245 */       headers.remove(HttpHeaderNames.CONTENT_LENGTH);
/*     */ 
/*     */ 
/*     */       
/* 249 */       if (!this.flowControllerInitialized) {
/* 250 */         this.flowControllerInitialized = true;
/* 251 */         this.connection.local().flowController(new ConsumedBytesConverter(this.connection.local().flowController()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   Http2Decompressor decompressor(Http2Stream stream) {
/* 257 */     return (stream == null) ? null : stream.<Http2Decompressor>getProperty(this.propertyKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void cleanup(Http2Decompressor decompressor) {
/* 266 */     decompressor.decompressor().finishAndReleaseAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ByteBuf nextReadableBuf(EmbeddedChannel decompressor) {
/*     */     ByteBuf buf;
/*     */     while (true) {
/* 278 */       buf = (ByteBuf)decompressor.readInbound();
/* 279 */       if (buf == null) {
/* 280 */         return null;
/*     */       }
/* 282 */       if (!buf.isReadable()) {
/* 283 */         buf.release(); continue;
/*     */       }  break;
/*     */     } 
/* 286 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   private final class ConsumedBytesConverter
/*     */     implements Http2LocalFlowController
/*     */   {
/*     */     private final Http2LocalFlowController flowController;
/*     */ 
/*     */     
/*     */     ConsumedBytesConverter(Http2LocalFlowController flowController) {
/* 297 */       this.flowController = (Http2LocalFlowController)ObjectUtil.checkNotNull(flowController, "flowController");
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2LocalFlowController frameWriter(Http2FrameWriter frameWriter) {
/* 302 */       return this.flowController.frameWriter(frameWriter);
/*     */     }
/*     */ 
/*     */     
/*     */     public void channelHandlerContext(ChannelHandlerContext ctx) throws Http2Exception {
/* 307 */       this.flowController.channelHandlerContext(ctx);
/*     */     }
/*     */ 
/*     */     
/*     */     public void initialWindowSize(int newWindowSize) throws Http2Exception {
/* 312 */       this.flowController.initialWindowSize(newWindowSize);
/*     */     }
/*     */ 
/*     */     
/*     */     public int initialWindowSize() {
/* 317 */       return this.flowController.initialWindowSize();
/*     */     }
/*     */ 
/*     */     
/*     */     public int windowSize(Http2Stream stream) {
/* 322 */       return this.flowController.windowSize(stream);
/*     */     }
/*     */ 
/*     */     
/*     */     public void incrementWindowSize(Http2Stream stream, int delta) throws Http2Exception {
/* 327 */       this.flowController.incrementWindowSize(stream, delta);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void receiveFlowControlledFrame(Http2Stream stream, ByteBuf data, int padding, boolean endOfStream) throws Http2Exception {
/* 333 */       this.flowController.receiveFlowControlledFrame(stream, data, padding, endOfStream);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean consumeBytes(Http2Stream stream, int numBytes) throws Http2Exception {
/* 338 */       DelegatingDecompressorFrameListener.Http2Decompressor decompressor = DelegatingDecompressorFrameListener.this.decompressor(stream);
/* 339 */       if (decompressor != null)
/*     */       {
/* 341 */         numBytes = decompressor.consumeBytes(stream.id(), numBytes);
/*     */       }
/*     */       try {
/* 344 */         return this.flowController.consumeBytes(stream, numBytes);
/* 345 */       } catch (Http2Exception e) {
/* 346 */         throw e;
/* 347 */       } catch (Throwable t) {
/*     */ 
/*     */         
/* 350 */         throw Http2Exception.streamError(stream.id(), Http2Error.INTERNAL_ERROR, t, "Error while returning bytes to flow control window", new Object[0]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int unconsumedBytes(Http2Stream stream) {
/* 356 */       return this.flowController.unconsumedBytes(stream);
/*     */     }
/*     */ 
/*     */     
/*     */     public int initialWindowSize(Http2Stream stream) {
/* 361 */       return this.flowController.initialWindowSize(stream);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Http2Decompressor
/*     */   {
/*     */     private final EmbeddedChannel decompressor;
/*     */     
/*     */     private int compressed;
/*     */     private int decompressed;
/*     */     
/*     */     Http2Decompressor(EmbeddedChannel decompressor) {
/* 374 */       this.decompressor = decompressor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EmbeddedChannel decompressor() {
/* 381 */       return this.decompressor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void incrementCompressedBytes(int delta) {
/* 388 */       assert delta >= 0;
/* 389 */       this.compressed += delta;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void incrementDecompressedBytes(int delta) {
/* 396 */       assert delta >= 0;
/* 397 */       this.decompressed += delta;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int consumeBytes(int streamId, int decompressedBytes) throws Http2Exception {
/* 409 */       ObjectUtil.checkPositiveOrZero(decompressedBytes, "decompressedBytes");
/* 410 */       if (this.decompressed - decompressedBytes < 0)
/* 411 */         throw Http2Exception.streamError(streamId, Http2Error.INTERNAL_ERROR, "Attempting to return too many bytes for stream %d. decompressed: %d decompressedBytes: %d", new Object[] {
/*     */               
/* 413 */               Integer.valueOf(streamId), Integer.valueOf(this.decompressed), Integer.valueOf(decompressedBytes)
/*     */             }); 
/* 415 */       double consumedRatio = decompressedBytes / this.decompressed;
/* 416 */       int consumedCompressed = Math.min(this.compressed, (int)Math.ceil(this.compressed * consumedRatio));
/* 417 */       if (this.compressed - consumedCompressed < 0)
/* 418 */         throw Http2Exception.streamError(streamId, Http2Error.INTERNAL_ERROR, "overflow when converting decompressed bytes to compressed bytes for stream %d.decompressedBytes: %d decompressed: %d compressed: %d consumedCompressed: %d", new Object[] {
/*     */ 
/*     */               
/* 421 */               Integer.valueOf(streamId), Integer.valueOf(decompressedBytes), Integer.valueOf(this.decompressed), Integer.valueOf(this.compressed), Integer.valueOf(consumedCompressed)
/*     */             }); 
/* 423 */       this.decompressed -= decompressedBytes;
/* 424 */       this.compressed -= consumedCompressed;
/*     */       
/* 426 */       return consumedCompressed;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DelegatingDecompressorFrameListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */