package io.netty.handler.codec.http2;

public interface Http2PushPromiseFrame extends Http2StreamFrame {
  Http2StreamFrame pushStream(Http2FrameStream paramHttp2FrameStream);
  
  Http2FrameStream pushStream();
  
  Http2Headers http2Headers();
  
  int padding();
  
  int promisedStreamId();
  
  Http2PushPromiseFrame stream(Http2FrameStream paramHttp2FrameStream);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2PushPromiseFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */