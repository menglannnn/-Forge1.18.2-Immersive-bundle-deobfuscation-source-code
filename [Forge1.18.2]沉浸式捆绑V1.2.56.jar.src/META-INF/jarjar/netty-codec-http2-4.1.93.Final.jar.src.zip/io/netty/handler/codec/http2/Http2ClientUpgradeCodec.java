/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.base64.Base64;
/*     */ import io.netty.handler.codec.base64.Base64Dialect;
/*     */ import io.netty.handler.codec.http.FullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpClientUpgradeHandler;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.collection.CharObjectMap;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Http2ClientUpgradeCodec
/*     */   implements HttpClientUpgradeHandler.UpgradeCodec
/*     */ {
/*  45 */   private static final List<CharSequence> UPGRADE_HEADERS = Collections.singletonList(Http2CodecUtil.HTTP_UPGRADE_SETTINGS_HEADER);
/*     */   
/*     */   private final String handlerName;
/*     */   private final Http2ConnectionHandler connectionHandler;
/*     */   private final ChannelHandler upgradeToHandler;
/*     */   private final ChannelHandler http2MultiplexHandler;
/*     */   
/*     */   public Http2ClientUpgradeCodec(Http2FrameCodec frameCodec, ChannelHandler upgradeToHandler) {
/*  53 */     this((String)null, frameCodec, upgradeToHandler);
/*     */   }
/*     */   
/*     */   public Http2ClientUpgradeCodec(String handlerName, Http2FrameCodec frameCodec, ChannelHandler upgradeToHandler) {
/*  57 */     this(handlerName, frameCodec, upgradeToHandler, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ClientUpgradeCodec(Http2ConnectionHandler connectionHandler) {
/*  67 */     this((String)null, connectionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ClientUpgradeCodec(Http2ConnectionHandler connectionHandler, Http2MultiplexHandler http2MultiplexHandler) {
/*  79 */     this((String)null, connectionHandler, http2MultiplexHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ClientUpgradeCodec(String handlerName, Http2ConnectionHandler connectionHandler) {
/*  90 */     this(handlerName, connectionHandler, (ChannelHandler)connectionHandler, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ClientUpgradeCodec(String handlerName, Http2ConnectionHandler connectionHandler, Http2MultiplexHandler http2MultiplexHandler) {
/* 102 */     this(handlerName, connectionHandler, (ChannelHandler)connectionHandler, http2MultiplexHandler);
/*     */   }
/*     */ 
/*     */   
/*     */   private Http2ClientUpgradeCodec(String handlerName, Http2ConnectionHandler connectionHandler, ChannelHandler upgradeToHandler, Http2MultiplexHandler http2MultiplexHandler) {
/* 107 */     this.handlerName = handlerName;
/* 108 */     this.connectionHandler = (Http2ConnectionHandler)ObjectUtil.checkNotNull(connectionHandler, "connectionHandler");
/* 109 */     this.upgradeToHandler = (ChannelHandler)ObjectUtil.checkNotNull(upgradeToHandler, "upgradeToHandler");
/* 110 */     this.http2MultiplexHandler = (ChannelHandler)http2MultiplexHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence protocol() {
/* 115 */     return Http2CodecUtil.HTTP_UPGRADE_PROTOCOL_NAME;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<CharSequence> setUpgradeHeaders(ChannelHandlerContext ctx, HttpRequest upgradeRequest) {
/* 121 */     CharSequence settingsValue = getSettingsHeaderValue(ctx);
/* 122 */     upgradeRequest.headers().set(Http2CodecUtil.HTTP_UPGRADE_SETTINGS_HEADER, settingsValue);
/* 123 */     return UPGRADE_HEADERS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void upgradeTo(ChannelHandlerContext ctx, FullHttpResponse upgradeResponse) throws Exception {
/*     */     try {
/* 131 */       ctx.pipeline().addAfter(ctx.name(), this.handlerName, this.upgradeToHandler);
/*     */ 
/*     */ 
/*     */       
/* 135 */       if (this.http2MultiplexHandler != null) {
/* 136 */         String name = ctx.pipeline().context((ChannelHandler)this.connectionHandler).name();
/* 137 */         ctx.pipeline().addAfter(name, null, this.http2MultiplexHandler);
/*     */       } 
/*     */ 
/*     */       
/* 141 */       this.connectionHandler.onHttpClientUpgrade();
/* 142 */     } catch (Http2Exception e) {
/* 143 */       ctx.fireExceptionCaught(e);
/* 144 */       ctx.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CharSequence getSettingsHeaderValue(ChannelHandlerContext ctx) {
/* 153 */     ByteBuf buf = null;
/* 154 */     ByteBuf encodedBuf = null;
/*     */     
/*     */     try {
/* 157 */       Http2Settings settings = this.connectionHandler.decoder().localSettings();
/*     */ 
/*     */       
/* 160 */       int payloadLength = 6 * settings.size();
/* 161 */       buf = ctx.alloc().buffer(payloadLength);
/* 162 */       for (CharObjectMap.PrimitiveEntry<Long> entry : (Iterable<CharObjectMap.PrimitiveEntry<Long>>)settings.entries()) {
/* 163 */         buf.writeChar(entry.key());
/* 164 */         buf.writeInt(((Long)entry.value()).intValue());
/*     */       } 
/*     */ 
/*     */       
/* 168 */       encodedBuf = Base64.encode(buf, Base64Dialect.URL_SAFE);
/* 169 */       return encodedBuf.toString(CharsetUtil.UTF_8);
/*     */     } finally {
/* 171 */       ReferenceCountUtil.release(buf);
/* 172 */       ReferenceCountUtil.release(encodedBuf);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2ClientUpgradeCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */