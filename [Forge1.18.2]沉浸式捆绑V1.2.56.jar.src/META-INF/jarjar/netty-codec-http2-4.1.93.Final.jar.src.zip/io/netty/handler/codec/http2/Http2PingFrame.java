package io.netty.handler.codec.http2;

public interface Http2PingFrame extends Http2Frame {
  boolean ack();
  
  long content();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2PingFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */