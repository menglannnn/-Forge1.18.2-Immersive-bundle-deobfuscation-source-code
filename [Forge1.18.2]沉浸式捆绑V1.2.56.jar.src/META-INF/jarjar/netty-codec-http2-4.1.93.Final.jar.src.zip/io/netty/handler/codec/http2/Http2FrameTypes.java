package io.netty.handler.codec.http2;

public final class Http2FrameTypes {
  public static final byte DATA = 0;
  
  public static final byte HEADERS = 1;
  
  public static final byte PRIORITY = 2;
  
  public static final byte RST_STREAM = 3;
  
  public static final byte SETTINGS = 4;
  
  public static final byte PUSH_PROMISE = 5;
  
  public static final byte PING = 6;
  
  public static final byte GO_AWAY = 7;
  
  public static final byte WINDOW_UPDATE = 8;
  
  public static final byte CONTINUATION = 9;
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2FrameTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */