/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.socket.ChannelInputShutdownReadComplete;
/*     */ import io.netty.channel.socket.ChannelOutputShutdownEvent;
/*     */ import io.netty.handler.ssl.SslCloseCompletionEvent;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2MultiplexHandler
/*     */   extends Http2ChannelDuplexHandler
/*     */ {
/*  95 */   static final ChannelFutureListener CHILD_CHANNEL_REGISTRATION_LISTENER = new ChannelFutureListener()
/*     */     {
/*     */       public void operationComplete(ChannelFuture future) {
/*  98 */         Http2MultiplexHandler.registerDone(future);
/*     */       }
/*     */     };
/*     */   
/*     */   private final ChannelHandler inboundStreamHandler;
/*     */   private final ChannelHandler upgradeStreamHandler;
/* 104 */   private final Queue<AbstractHttp2StreamChannel> readCompletePendingQueue = new MaxCapacityQueue<AbstractHttp2StreamChannel>(new ArrayDeque<AbstractHttp2StreamChannel>(8), 100);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean parentReadInProgress;
/*     */ 
/*     */ 
/*     */   
/*     */   private int idCount;
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile ChannelHandlerContext ctx;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2MultiplexHandler(ChannelHandler inboundStreamHandler) {
/* 122 */     this(inboundStreamHandler, (ChannelHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2MultiplexHandler(ChannelHandler inboundStreamHandler, ChannelHandler upgradeStreamHandler) {
/* 134 */     this.inboundStreamHandler = (ChannelHandler)ObjectUtil.checkNotNull(inboundStreamHandler, "inboundStreamHandler");
/* 135 */     this.upgradeStreamHandler = upgradeStreamHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void registerDone(ChannelFuture future) {
/* 142 */     if (!future.isSuccess()) {
/* 143 */       Channel childChannel = future.channel();
/* 144 */       if (childChannel.isRegistered()) {
/* 145 */         childChannel.close();
/*     */       } else {
/* 147 */         childChannel.unsafe().closeForcibly();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handlerAdded0(ChannelHandlerContext ctx) {
/* 154 */     if (ctx.executor() != ctx.channel().eventLoop()) {
/* 155 */       throw new IllegalStateException("EventExecutor must be EventLoop of Channel");
/*     */     }
/* 157 */     this.ctx = ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handlerRemoved0(ChannelHandlerContext ctx) {
/* 162 */     this.readCompletePendingQueue.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 167 */     this.parentReadInProgress = true;
/* 168 */     if (msg instanceof Http2StreamFrame) {
/* 169 */       if (msg instanceof Http2WindowUpdateFrame) {
/*     */         return;
/*     */       }
/*     */       
/* 173 */       Http2StreamFrame streamFrame = (Http2StreamFrame)msg;
/*     */       
/* 175 */       Http2FrameCodec.DefaultHttp2FrameStream s = (Http2FrameCodec.DefaultHttp2FrameStream)streamFrame.stream();
/*     */       
/* 177 */       AbstractHttp2StreamChannel channel = (AbstractHttp2StreamChannel)s.attachment;
/* 178 */       if (msg instanceof Http2ResetFrame) {
/*     */ 
/*     */         
/* 181 */         channel.pipeline().fireUserEventTriggered(msg);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 186 */         channel.fireChildRead(streamFrame);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 191 */     if (msg instanceof Http2GoAwayFrame)
/*     */     {
/*     */       
/* 194 */       onHttp2GoAwayFrame(ctx, (Http2GoAwayFrame)msg);
/*     */     }
/*     */ 
/*     */     
/* 198 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelWritabilityChanged(ChannelHandlerContext ctx) throws Exception {
/* 203 */     if (ctx.channel().isWritable())
/*     */     {
/*     */       
/* 206 */       forEachActiveStream(AbstractHttp2StreamChannel.WRITABLE_VISITOR);
/*     */     }
/*     */     
/* 209 */     ctx.fireChannelWritabilityChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
/* 214 */     if (evt instanceof Http2FrameStreamEvent) {
/* 215 */       Http2FrameStreamEvent event = (Http2FrameStreamEvent)evt;
/* 216 */       Http2FrameCodec.DefaultHttp2FrameStream stream = (Http2FrameCodec.DefaultHttp2FrameStream)event.stream();
/* 217 */       if (event.type() == Http2FrameStreamEvent.Type.State) {
/* 218 */         AbstractHttp2StreamChannel ch; ChannelFuture future; AbstractHttp2StreamChannel channel; switch (stream.state()) {
/*     */           case HALF_CLOSED_LOCAL:
/* 220 */             if (stream.id() != 1) {
/*     */               break;
/*     */             }
/*     */ 
/*     */ 
/*     */           
/*     */           case HALF_CLOSED_REMOTE:
/*     */           case OPEN:
/* 228 */             if (stream.attachment != null) {
/*     */               break;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 234 */             if (stream.id() == 1 && !isServer(ctx)) {
/*     */               
/* 236 */               if (this.upgradeStreamHandler == null) {
/* 237 */                 throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, "Client is misconfigured for upgrade requests", new Object[0]);
/*     */               }
/*     */               
/* 240 */               ch = new Http2MultiplexHandlerStreamChannel(stream, this.upgradeStreamHandler);
/* 241 */               ch.closeOutbound();
/*     */             } else {
/* 243 */               ch = new Http2MultiplexHandlerStreamChannel(stream, this.inboundStreamHandler);
/*     */             } 
/* 245 */             future = ctx.channel().eventLoop().register(ch);
/* 246 */             if (future.isDone()) {
/* 247 */               registerDone(future); break;
/*     */             } 
/* 249 */             future.addListener((GenericFutureListener)CHILD_CHANNEL_REGISTRATION_LISTENER);
/*     */             break;
/*     */           
/*     */           case CLOSED:
/* 253 */             channel = (AbstractHttp2StreamChannel)stream.attachment;
/* 254 */             if (channel != null) {
/* 255 */               channel.streamClosed();
/*     */             }
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*     */       return;
/*     */     } 
/* 265 */     if (evt == ChannelInputShutdownReadComplete.INSTANCE) {
/* 266 */       forEachActiveStream(AbstractHttp2StreamChannel.CHANNEL_INPUT_SHUTDOWN_READ_COMPLETE_VISITOR);
/* 267 */     } else if (evt == ChannelOutputShutdownEvent.INSTANCE) {
/* 268 */       forEachActiveStream(AbstractHttp2StreamChannel.CHANNEL_OUTPUT_SHUTDOWN_EVENT_VISITOR);
/* 269 */     } else if (evt == SslCloseCompletionEvent.SUCCESS) {
/* 270 */       forEachActiveStream(AbstractHttp2StreamChannel.SSL_CLOSE_COMPLETION_EVENT_VISITOR);
/*     */     } 
/* 272 */     ctx.fireUserEventTriggered(evt);
/*     */   }
/*     */ 
/*     */   
/*     */   Http2StreamChannel newOutboundStream() {
/* 277 */     return new Http2MultiplexHandlerStreamChannel((Http2FrameCodec.DefaultHttp2FrameStream)newStream(), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 282 */     if (cause instanceof Http2FrameStreamException) {
/* 283 */       Http2FrameStreamException exception = (Http2FrameStreamException)cause;
/* 284 */       Http2FrameStream stream = exception.stream();
/* 285 */       AbstractHttp2StreamChannel childChannel = (AbstractHttp2StreamChannel)((Http2FrameCodec.DefaultHttp2FrameStream)stream).attachment;
/*     */       
/*     */       try {
/* 288 */         childChannel.pipeline().fireExceptionCaught(cause.getCause());
/*     */       }
/*     */       finally {
/*     */         
/* 292 */         childChannel.closeWithError(exception.error());
/*     */       } 
/*     */       return;
/*     */     } 
/* 296 */     if (cause instanceof Http2MultiplexActiveStreamsException) {
/*     */       
/* 298 */       fireExceptionCaughtForActiveStream(cause.getCause());
/*     */       
/*     */       return;
/*     */     } 
/* 302 */     if (cause.getCause() instanceof javax.net.ssl.SSLException) {
/* 303 */       fireExceptionCaughtForActiveStream(cause);
/*     */     }
/* 305 */     ctx.fireExceptionCaught(cause);
/*     */   }
/*     */   
/*     */   private void fireExceptionCaughtForActiveStream(final Throwable cause) throws Http2Exception {
/* 309 */     forEachActiveStream(new Http2FrameStreamVisitor()
/*     */         {
/*     */           public boolean visit(Http2FrameStream stream) {
/* 312 */             AbstractHttp2StreamChannel childChannel = (AbstractHttp2StreamChannel)((Http2FrameCodec.DefaultHttp2FrameStream)stream).attachment;
/*     */             
/* 314 */             childChannel.pipeline().fireExceptionCaught(cause);
/* 315 */             return true;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private static boolean isServer(ChannelHandlerContext ctx) {
/* 321 */     return ctx.channel().parent() instanceof io.netty.channel.ServerChannel;
/*     */   }
/*     */   
/*     */   private void onHttp2GoAwayFrame(ChannelHandlerContext ctx, final Http2GoAwayFrame goAwayFrame) {
/* 325 */     if (goAwayFrame.lastStreamId() == Integer.MAX_VALUE) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 331 */       final boolean server = isServer(ctx);
/* 332 */       forEachActiveStream(new Http2FrameStreamVisitor()
/*     */           {
/*     */             public boolean visit(Http2FrameStream stream) {
/* 335 */               int streamId = stream.id();
/* 336 */               if (streamId > goAwayFrame.lastStreamId() && Http2CodecUtil.isStreamIdValid(streamId, server)) {
/* 337 */                 AbstractHttp2StreamChannel childChannel = (AbstractHttp2StreamChannel)((Http2FrameCodec.DefaultHttp2FrameStream)stream).attachment;
/*     */                 
/* 339 */                 childChannel.pipeline().fireUserEventTriggered(goAwayFrame.retainedDuplicate());
/*     */               } 
/* 341 */               return true;
/*     */             }
/*     */           });
/* 344 */     } catch (Http2Exception e) {
/* 345 */       ctx.fireExceptionCaught(e);
/* 346 */       ctx.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/* 355 */     processPendingReadCompleteQueue();
/* 356 */     ctx.fireChannelReadComplete();
/*     */   }
/*     */   
/*     */   private void processPendingReadCompleteQueue() {
/* 360 */     this.parentReadInProgress = true;
/*     */ 
/*     */ 
/*     */     
/* 364 */     AbstractHttp2StreamChannel childChannel = this.readCompletePendingQueue.poll();
/* 365 */     if (childChannel != null) {
/*     */       try {
/*     */         do {
/* 368 */           childChannel.fireChildReadComplete();
/* 369 */           childChannel = this.readCompletePendingQueue.poll();
/* 370 */         } while (childChannel != null);
/*     */       } finally {
/* 372 */         this.parentReadInProgress = false;
/* 373 */         this.readCompletePendingQueue.clear();
/* 374 */         this.ctx.flush();
/*     */       } 
/*     */     } else {
/* 377 */       this.parentReadInProgress = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private final class Http2MultiplexHandlerStreamChannel
/*     */     extends AbstractHttp2StreamChannel {
/*     */     Http2MultiplexHandlerStreamChannel(Http2FrameCodec.DefaultHttp2FrameStream stream, ChannelHandler inboundHandler) {
/* 384 */       super(stream, ++Http2MultiplexHandler.this.idCount, inboundHandler);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isParentReadInProgress() {
/* 389 */       return Http2MultiplexHandler.this.parentReadInProgress;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void addChannelToReadCompletePendingQueue() {
/* 396 */       while (!Http2MultiplexHandler.this.readCompletePendingQueue.offer(this)) {
/* 397 */         Http2MultiplexHandler.this.processPendingReadCompleteQueue();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected ChannelHandlerContext parentContext() {
/* 403 */       return Http2MultiplexHandler.this.ctx;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2MultiplexHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */