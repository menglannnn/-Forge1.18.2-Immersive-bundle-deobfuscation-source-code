/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Http2FrameCodecBuilder
/*     */   extends AbstractHttp2ConnectionHandlerBuilder<Http2FrameCodec, Http2FrameCodecBuilder>
/*     */ {
/*     */   private Http2FrameWriter frameWriter;
/*     */   
/*     */   protected Http2FrameCodecBuilder() {}
/*     */   
/*     */   Http2FrameCodecBuilder(boolean server) {
/*  45 */     server(server);
/*     */     
/*  47 */     gracefulShutdownTimeoutMillis(0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2FrameCodecBuilder forClient() {
/*  54 */     return new Http2FrameCodecBuilder(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2FrameCodecBuilder forServer() {
/*  61 */     return new Http2FrameCodecBuilder(true);
/*     */   }
/*     */ 
/*     */   
/*     */   Http2FrameCodecBuilder frameWriter(Http2FrameWriter frameWriter) {
/*  66 */     this.frameWriter = (Http2FrameWriter)ObjectUtil.checkNotNull(frameWriter, "frameWriter");
/*  67 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Settings initialSettings() {
/*  72 */     return super.initialSettings();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder initialSettings(Http2Settings settings) {
/*  77 */     return super.initialSettings(settings);
/*     */   }
/*     */ 
/*     */   
/*     */   public long gracefulShutdownTimeoutMillis() {
/*  82 */     return super.gracefulShutdownTimeoutMillis();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder gracefulShutdownTimeoutMillis(long gracefulShutdownTimeoutMillis) {
/*  87 */     return super.gracefulShutdownTimeoutMillis(gracefulShutdownTimeoutMillis);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isServer() {
/*  92 */     return super.isServer();
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxReservedStreams() {
/*  97 */     return super.maxReservedStreams();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder maxReservedStreams(int maxReservedStreams) {
/* 102 */     return super.maxReservedStreams(maxReservedStreams);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValidateHeaders() {
/* 107 */     return super.isValidateHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder validateHeaders(boolean validateHeaders) {
/* 112 */     return super.validateHeaders(validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameLogger frameLogger() {
/* 117 */     return super.frameLogger();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder frameLogger(Http2FrameLogger frameLogger) {
/* 122 */     return super.frameLogger(frameLogger);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean encoderEnforceMaxConcurrentStreams() {
/* 127 */     return super.encoderEnforceMaxConcurrentStreams();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder encoderEnforceMaxConcurrentStreams(boolean encoderEnforceMaxConcurrentStreams) {
/* 132 */     return super.encoderEnforceMaxConcurrentStreams(encoderEnforceMaxConcurrentStreams);
/*     */   }
/*     */ 
/*     */   
/*     */   public int encoderEnforceMaxQueuedControlFrames() {
/* 137 */     return super.encoderEnforceMaxQueuedControlFrames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder encoderEnforceMaxQueuedControlFrames(int maxQueuedControlFrames) {
/* 142 */     return super.encoderEnforceMaxQueuedControlFrames(maxQueuedControlFrames);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector() {
/* 147 */     return super.headerSensitivityDetector();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder headerSensitivityDetector(Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector) {
/* 153 */     return super.headerSensitivityDetector(headerSensitivityDetector);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder encoderIgnoreMaxHeaderListSize(boolean ignoreMaxHeaderListSize) {
/* 158 */     return super.encoderIgnoreMaxHeaderListSize(ignoreMaxHeaderListSize);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Http2FrameCodecBuilder initialHuffmanDecodeCapacity(int initialHuffmanDecodeCapacity) {
/* 164 */     return super.initialHuffmanDecodeCapacity(initialHuffmanDecodeCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder autoAckSettingsFrame(boolean autoAckSettings) {
/* 169 */     return super.autoAckSettingsFrame(autoAckSettings);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder autoAckPingFrame(boolean autoAckPingFrame) {
/* 174 */     return super.autoAckPingFrame(autoAckPingFrame);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder decoupleCloseAndGoAway(boolean decoupleCloseAndGoAway) {
/* 179 */     return super.decoupleCloseAndGoAway(decoupleCloseAndGoAway);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder flushPreface(boolean flushPreface) {
/* 184 */     return super.flushPreface(flushPreface);
/*     */   }
/*     */ 
/*     */   
/*     */   public int decoderEnforceMaxConsecutiveEmptyDataFrames() {
/* 189 */     return super.decoderEnforceMaxConsecutiveEmptyDataFrames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameCodecBuilder decoderEnforceMaxConsecutiveEmptyDataFrames(int maxConsecutiveEmptyFrames) {
/* 194 */     return super.decoderEnforceMaxConsecutiveEmptyDataFrames(maxConsecutiveEmptyFrames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2FrameCodec build() {
/* 202 */     Http2FrameWriter frameWriter = this.frameWriter;
/* 203 */     if (frameWriter != null) {
/*     */ 
/*     */       
/* 206 */       DefaultHttp2Connection connection = new DefaultHttp2Connection(isServer(), maxReservedStreams());
/* 207 */       Long maxHeaderListSize = initialSettings().maxHeaderListSize();
/*     */ 
/*     */       
/* 210 */       Http2FrameReader frameReader = new DefaultHttp2FrameReader((maxHeaderListSize == null) ? new DefaultHttp2HeadersDecoder(isValidateHeaders()) : new DefaultHttp2HeadersDecoder(isValidateHeaders(), maxHeaderListSize.longValue()));
/*     */       
/* 212 */       if (frameLogger() != null) {
/* 213 */         frameWriter = new Http2OutboundFrameLogger(frameWriter, frameLogger());
/* 214 */         frameReader = new Http2InboundFrameLogger(frameReader, frameLogger());
/*     */       } 
/* 216 */       Http2ConnectionEncoder encoder = new DefaultHttp2ConnectionEncoder(connection, frameWriter);
/* 217 */       if (encoderEnforceMaxConcurrentStreams()) {
/* 218 */         encoder = new StreamBufferingEncoder(encoder);
/*     */       }
/*     */       
/* 221 */       Http2ConnectionDecoder decoder = new DefaultHttp2ConnectionDecoder(connection, encoder, frameReader, promisedRequestVerifier(), isAutoAckSettingsFrame(), isAutoAckPingFrame());
/* 222 */       int maxConsecutiveEmptyDataFrames = decoderEnforceMaxConsecutiveEmptyDataFrames();
/* 223 */       if (maxConsecutiveEmptyDataFrames > 0) {
/* 224 */         decoder = new Http2EmptyDataFrameConnectionDecoder(decoder, maxConsecutiveEmptyDataFrames);
/*     */       }
/* 226 */       return build(decoder, encoder, initialSettings());
/*     */     } 
/* 228 */     return super.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2FrameCodec build(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
/* 235 */     Http2FrameCodec codec = new Http2FrameCodec(encoder, decoder, initialSettings, decoupleCloseAndGoAway(), flushPreface());
/* 236 */     codec.gracefulShutdownTimeoutMillis(gracefulShutdownTimeoutMillis());
/* 237 */     return codec;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2FrameCodecBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */