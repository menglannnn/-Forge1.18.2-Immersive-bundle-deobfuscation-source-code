/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.handler.codec.http.HttpScheme;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpToHttp2ConnectionHandlerBuilder
/*     */   extends AbstractHttp2ConnectionHandlerBuilder<HttpToHttp2ConnectionHandler, HttpToHttp2ConnectionHandlerBuilder>
/*     */ {
/*     */   private HttpScheme httpScheme;
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder validateHeaders(boolean validateHeaders) {
/*  34 */     return super.validateHeaders(validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder initialSettings(Http2Settings settings) {
/*  39 */     return super.initialSettings(settings);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder frameListener(Http2FrameListener frameListener) {
/*  44 */     return super.frameListener(frameListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder gracefulShutdownTimeoutMillis(long gracefulShutdownTimeoutMillis) {
/*  49 */     return super.gracefulShutdownTimeoutMillis(gracefulShutdownTimeoutMillis);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder server(boolean isServer) {
/*  54 */     return super.server(isServer);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder connection(Http2Connection connection) {
/*  59 */     return super.connection(connection);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder codec(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder) {
/*  65 */     return super.codec(decoder, encoder);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder frameLogger(Http2FrameLogger frameLogger) {
/*  70 */     return super.frameLogger(frameLogger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder encoderEnforceMaxConcurrentStreams(boolean encoderEnforceMaxConcurrentStreams) {
/*  76 */     return super.encoderEnforceMaxConcurrentStreams(encoderEnforceMaxConcurrentStreams);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder headerSensitivityDetector(Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector) {
/*  82 */     return super.headerSensitivityDetector(headerSensitivityDetector);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public HttpToHttp2ConnectionHandlerBuilder initialHuffmanDecodeCapacity(int initialHuffmanDecodeCapacity) {
/*  88 */     return super.initialHuffmanDecodeCapacity(initialHuffmanDecodeCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder decoupleCloseAndGoAway(boolean decoupleCloseAndGoAway) {
/*  93 */     return super.decoupleCloseAndGoAway(decoupleCloseAndGoAway);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder flushPreface(boolean flushPreface) {
/*  98 */     return super.flushPreface(flushPreface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandlerBuilder httpScheme(HttpScheme httpScheme) {
/* 108 */     this.httpScheme = httpScheme;
/* 109 */     return self();
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpToHttp2ConnectionHandler build() {
/* 114 */     return super.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpToHttp2ConnectionHandler build(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
/* 120 */     return new HttpToHttp2ConnectionHandler(decoder, encoder, initialSettings, isValidateHeaders(), 
/* 121 */         decoupleCloseAndGoAway(), flushPreface(), this.httpScheme);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\HttpToHttp2ConnectionHandlerBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */