/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2HeadersEncoder
/*     */   implements Http2HeadersEncoder, Http2HeadersEncoder.Configuration
/*     */ {
/*     */   private final HpackEncoder hpackEncoder;
/*     */   private final Http2HeadersEncoder.SensitivityDetector sensitivityDetector;
/*  30 */   private final ByteBuf tableSizeChangeOutput = Unpooled.buffer();
/*     */   
/*     */   public DefaultHttp2HeadersEncoder() {
/*  33 */     this(NEVER_SENSITIVE);
/*     */   }
/*     */   
/*     */   public DefaultHttp2HeadersEncoder(Http2HeadersEncoder.SensitivityDetector sensitivityDetector) {
/*  37 */     this(sensitivityDetector, new HpackEncoder());
/*     */   }
/*     */   
/*     */   public DefaultHttp2HeadersEncoder(Http2HeadersEncoder.SensitivityDetector sensitivityDetector, boolean ignoreMaxHeaderListSize) {
/*  41 */     this(sensitivityDetector, new HpackEncoder(ignoreMaxHeaderListSize));
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultHttp2HeadersEncoder(Http2HeadersEncoder.SensitivityDetector sensitivityDetector, boolean ignoreMaxHeaderListSize, int dynamicTableArraySizeHint) {
/*  46 */     this(sensitivityDetector, ignoreMaxHeaderListSize, dynamicTableArraySizeHint, 512);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultHttp2HeadersEncoder(Http2HeadersEncoder.SensitivityDetector sensitivityDetector, boolean ignoreMaxHeaderListSize, int dynamicTableArraySizeHint, int huffCodeThreshold) {
/*  51 */     this(sensitivityDetector, new HpackEncoder(ignoreMaxHeaderListSize, dynamicTableArraySizeHint, huffCodeThreshold));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultHttp2HeadersEncoder(Http2HeadersEncoder.SensitivityDetector sensitivityDetector, HpackEncoder hpackEncoder) {
/*  60 */     this.sensitivityDetector = (Http2HeadersEncoder.SensitivityDetector)ObjectUtil.checkNotNull(sensitivityDetector, "sensitiveDetector");
/*  61 */     this.hpackEncoder = (HpackEncoder)ObjectUtil.checkNotNull(hpackEncoder, "hpackEncoder");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeHeaders(int streamId, Http2Headers headers, ByteBuf buffer) throws Http2Exception {
/*     */     try {
/*  69 */       if (this.tableSizeChangeOutput.isReadable()) {
/*  70 */         buffer.writeBytes(this.tableSizeChangeOutput);
/*  71 */         this.tableSizeChangeOutput.clear();
/*     */       } 
/*     */       
/*  74 */       this.hpackEncoder.encodeHeaders(streamId, buffer, headers, this.sensitivityDetector);
/*  75 */     } catch (Http2Exception e) {
/*  76 */       throw e;
/*  77 */     } catch (Throwable t) {
/*  78 */       throw Http2Exception.connectionError(Http2Error.COMPRESSION_ERROR, t, "Failed encoding headers block: %s", new Object[] { t.getMessage() });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void maxHeaderTableSize(long max) throws Http2Exception {
/*  84 */     this.hpackEncoder.setMaxHeaderTableSize(this.tableSizeChangeOutput, max);
/*     */   }
/*     */ 
/*     */   
/*     */   public long maxHeaderTableSize() {
/*  89 */     return this.hpackEncoder.getMaxHeaderTableSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void maxHeaderListSize(long max) throws Http2Exception {
/*  94 */     this.hpackEncoder.setMaxHeaderListSize(max);
/*     */   }
/*     */ 
/*     */   
/*     */   public long maxHeaderListSize() {
/*  99 */     return this.hpackEncoder.getMaxHeaderListSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2HeadersEncoder.Configuration configuration() {
/* 104 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2HeadersEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */