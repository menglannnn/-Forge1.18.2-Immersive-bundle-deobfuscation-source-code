/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.util.collection.CharObjectMap;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2FrameWriter
/*     */   implements Http2FrameWriter, Http2FrameSizePolicy, Http2FrameWriter.Configuration
/*     */ {
/*     */   private static final String STREAM_ID = "Stream ID";
/*     */   private static final String STREAM_DEPENDENCY = "Stream Dependency";
/*  82 */   private static final ByteBuf ZERO_BUFFER = Unpooled.unreleasableBuffer(Unpooled.directBuffer(255).writeZero(255)).asReadOnly();
/*     */   
/*     */   private final Http2HeadersEncoder headersEncoder;
/*     */   private int maxFrameSize;
/*     */   
/*     */   public DefaultHttp2FrameWriter() {
/*  88 */     this(new DefaultHttp2HeadersEncoder());
/*     */   }
/*     */   
/*     */   public DefaultHttp2FrameWriter(Http2HeadersEncoder.SensitivityDetector headersSensitivityDetector) {
/*  92 */     this(new DefaultHttp2HeadersEncoder(headersSensitivityDetector));
/*     */   }
/*     */   
/*     */   public DefaultHttp2FrameWriter(Http2HeadersEncoder.SensitivityDetector headersSensitivityDetector, boolean ignoreMaxHeaderListSize) {
/*  96 */     this(new DefaultHttp2HeadersEncoder(headersSensitivityDetector, ignoreMaxHeaderListSize));
/*     */   }
/*     */   
/*     */   public DefaultHttp2FrameWriter(Http2HeadersEncoder headersEncoder) {
/* 100 */     this.headersEncoder = headersEncoder;
/* 101 */     this.maxFrameSize = 16384;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameWriter.Configuration configuration() {
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2HeadersEncoder.Configuration headersConfiguration() {
/* 111 */     return this.headersEncoder.configuration();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameSizePolicy frameSizePolicy() {
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void maxFrameSize(int max) throws Http2Exception {
/* 121 */     if (!Http2CodecUtil.isMaxFrameSizeValid(max)) {
/* 122 */       throw Http2Exception.connectionError(Http2Error.FRAME_SIZE_ERROR, "Invalid MAX_FRAME_SIZE specified in sent settings: %d", new Object[] { Integer.valueOf(max) });
/*     */     }
/* 124 */     this.maxFrameSize = max;
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxFrameSize() {
/* 129 */     return this.maxFrameSize;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeData(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endStream, ChannelPromise promise) {
/* 139 */     Http2CodecUtil.SimpleChannelPromiseAggregator promiseAggregator = new Http2CodecUtil.SimpleChannelPromiseAggregator(promise, ctx.channel(), ctx.executor());
/* 140 */     ByteBuf frameHeader = null;
/*     */     try {
/* 142 */       verifyStreamId(streamId, "Stream ID");
/* 143 */       Http2CodecUtil.verifyPadding(padding);
/*     */       
/* 145 */       int remainingData = data.readableBytes();
/* 146 */       Http2Flags flags = new Http2Flags();
/* 147 */       flags.endOfStream(false);
/* 148 */       flags.paddingPresent(false);
/*     */       
/* 150 */       if (remainingData > this.maxFrameSize) {
/* 151 */         frameHeader = ctx.alloc().buffer(9);
/* 152 */         Http2CodecUtil.writeFrameHeaderInternal(frameHeader, this.maxFrameSize, (byte)0, flags, streamId);
/*     */         
/*     */         do {
/* 155 */           ctx.write(frameHeader.retainedSlice(), promiseAggregator.newPromise());
/*     */ 
/*     */           
/* 158 */           ctx.write(data.readRetainedSlice(this.maxFrameSize), promiseAggregator.newPromise());
/*     */           
/* 160 */           remainingData -= this.maxFrameSize;
/*     */         }
/* 162 */         while (remainingData > this.maxFrameSize);
/*     */       } 
/*     */       
/* 165 */       if (padding == 0) {
/*     */         
/* 167 */         if (frameHeader != null) {
/* 168 */           frameHeader.release();
/* 169 */           frameHeader = null;
/*     */         } 
/* 171 */         ByteBuf frameHeader2 = ctx.alloc().buffer(9);
/* 172 */         flags.endOfStream(endStream);
/* 173 */         Http2CodecUtil.writeFrameHeaderInternal(frameHeader2, remainingData, (byte)0, flags, streamId);
/* 174 */         ctx.write(frameHeader2, promiseAggregator.newPromise());
/*     */ 
/*     */         
/* 177 */         ByteBuf lastFrame = data.readSlice(remainingData);
/* 178 */         data = null;
/* 179 */         ctx.write(lastFrame, promiseAggregator.newPromise());
/*     */       } else {
/* 181 */         if (remainingData != this.maxFrameSize) {
/* 182 */           if (frameHeader != null) {
/* 183 */             frameHeader.release();
/* 184 */             frameHeader = null;
/*     */           } 
/*     */         } else {
/* 187 */           remainingData -= this.maxFrameSize;
/*     */ 
/*     */           
/* 190 */           if (frameHeader == null) {
/* 191 */             lastFrame = ctx.alloc().buffer(9);
/* 192 */             Http2CodecUtil.writeFrameHeaderInternal(lastFrame, this.maxFrameSize, (byte)0, flags, streamId);
/*     */           } else {
/* 194 */             lastFrame = frameHeader.slice();
/* 195 */             frameHeader = null;
/*     */           } 
/* 197 */           ctx.write(lastFrame, promiseAggregator.newPromise());
/*     */ 
/*     */           
/* 200 */           ByteBuf lastFrame = (data.readableBytes() != this.maxFrameSize) ? data.readSlice(this.maxFrameSize) : data;
/* 201 */           data = null;
/* 202 */           ctx.write(lastFrame, promiseAggregator.newPromise());
/*     */         } 
/*     */         
/*     */         do {
/* 206 */           int frameDataBytes = Math.min(remainingData, this.maxFrameSize);
/* 207 */           int framePaddingBytes = Math.min(padding, Math.max(0, this.maxFrameSize - 1 - frameDataBytes));
/*     */ 
/*     */           
/* 210 */           padding -= framePaddingBytes;
/* 211 */           remainingData -= frameDataBytes;
/*     */ 
/*     */           
/* 214 */           ByteBuf frameHeader2 = ctx.alloc().buffer(10);
/* 215 */           flags.endOfStream((endStream && remainingData == 0 && padding == 0));
/* 216 */           flags.paddingPresent((framePaddingBytes > 0));
/* 217 */           Http2CodecUtil.writeFrameHeaderInternal(frameHeader2, framePaddingBytes + frameDataBytes, (byte)0, flags, streamId);
/* 218 */           writePaddingLength(frameHeader2, framePaddingBytes);
/* 219 */           ctx.write(frameHeader2, promiseAggregator.newPromise());
/*     */ 
/*     */           
/* 222 */           if (data != null) {
/* 223 */             if (remainingData == 0) {
/* 224 */               ByteBuf lastFrame = data.readSlice(frameDataBytes);
/* 225 */               data = null;
/* 226 */               ctx.write(lastFrame, promiseAggregator.newPromise());
/*     */             } else {
/* 228 */               ctx.write(data.readRetainedSlice(frameDataBytes), promiseAggregator.newPromise());
/*     */             } 
/*     */           }
/*     */           
/* 232 */           if (paddingBytes(framePaddingBytes) <= 0)
/* 233 */             continue;  ctx.write(ZERO_BUFFER.slice(0, paddingBytes(framePaddingBytes)), promiseAggregator
/* 234 */               .newPromise());
/*     */         }
/* 236 */         while (remainingData != 0 || padding != 0);
/*     */       } 
/* 238 */     } catch (Throwable cause) {
/* 239 */       if (frameHeader != null) {
/* 240 */         frameHeader.release();
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 245 */         if (data != null) {
/* 246 */           data.release();
/*     */         }
/*     */       } finally {
/* 249 */         promiseAggregator.setFailure(cause);
/* 250 */         promiseAggregator.doneAllocatingPromises();
/*     */       } 
/* 252 */       return (ChannelFuture)promiseAggregator;
/*     */     } 
/* 254 */     return (ChannelFuture)promiseAggregator.doneAllocatingPromises();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeHeaders(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endStream, ChannelPromise promise) {
/* 260 */     return writeHeadersInternal(ctx, streamId, headers, padding, endStream, false, 0, (short)0, false, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeHeaders(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endStream, ChannelPromise promise) {
/* 268 */     return writeHeadersInternal(ctx, streamId, headers, padding, endStream, true, streamDependency, weight, exclusive, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writePriority(ChannelHandlerContext ctx, int streamId, int streamDependency, short weight, boolean exclusive, ChannelPromise promise) {
/*     */     try {
/* 276 */       verifyStreamId(streamId, "Stream ID");
/* 277 */       verifyStreamOrConnectionId(streamDependency, "Stream Dependency");
/* 278 */       verifyWeight(weight);
/*     */       
/* 280 */       ByteBuf buf = ctx.alloc().buffer(14);
/* 281 */       Http2CodecUtil.writeFrameHeaderInternal(buf, 5, (byte)2, new Http2Flags(), streamId);
/* 282 */       buf.writeInt(exclusive ? (int)(0x80000000L | streamDependency) : streamDependency);
/*     */       
/* 284 */       buf.writeByte(weight - 1);
/* 285 */       return ctx.write(buf, promise);
/* 286 */     } catch (Throwable t) {
/* 287 */       return (ChannelFuture)promise.setFailure(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeRstStream(ChannelHandlerContext ctx, int streamId, long errorCode, ChannelPromise promise) {
/*     */     try {
/* 295 */       verifyStreamId(streamId, "Stream ID");
/* 296 */       verifyErrorCode(errorCode);
/*     */       
/* 298 */       ByteBuf buf = ctx.alloc().buffer(13);
/* 299 */       Http2CodecUtil.writeFrameHeaderInternal(buf, 4, (byte)3, new Http2Flags(), streamId);
/* 300 */       buf.writeInt((int)errorCode);
/* 301 */       return ctx.write(buf, promise);
/* 302 */     } catch (Throwable t) {
/* 303 */       return (ChannelFuture)promise.setFailure(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeSettings(ChannelHandlerContext ctx, Http2Settings settings, ChannelPromise promise) {
/*     */     try {
/* 311 */       ObjectUtil.checkNotNull(settings, "settings");
/* 312 */       int payloadLength = 6 * settings.size();
/* 313 */       ByteBuf buf = ctx.alloc().buffer(9 + payloadLength);
/* 314 */       Http2CodecUtil.writeFrameHeaderInternal(buf, payloadLength, (byte)4, new Http2Flags(), 0);
/* 315 */       for (CharObjectMap.PrimitiveEntry<Long> entry : (Iterable<CharObjectMap.PrimitiveEntry<Long>>)settings.entries()) {
/* 316 */         buf.writeChar(entry.key());
/* 317 */         buf.writeInt(((Long)entry.value()).intValue());
/*     */       } 
/* 319 */       return ctx.write(buf, promise);
/* 320 */     } catch (Throwable t) {
/* 321 */       return (ChannelFuture)promise.setFailure(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture writeSettingsAck(ChannelHandlerContext ctx, ChannelPromise promise) {
/*     */     try {
/* 328 */       ByteBuf buf = ctx.alloc().buffer(9);
/* 329 */       Http2CodecUtil.writeFrameHeaderInternal(buf, 0, (byte)4, (new Http2Flags()).ack(true), 0);
/* 330 */       return ctx.write(buf, promise);
/* 331 */     } catch (Throwable t) {
/* 332 */       return (ChannelFuture)promise.setFailure(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture writePing(ChannelHandlerContext ctx, boolean ack, long data, ChannelPromise promise) {
/* 338 */     Http2Flags flags = ack ? (new Http2Flags()).ack(true) : new Http2Flags();
/* 339 */     ByteBuf buf = ctx.alloc().buffer(17);
/*     */ 
/*     */     
/* 342 */     Http2CodecUtil.writeFrameHeaderInternal(buf, 8, (byte)6, flags, 0);
/* 343 */     buf.writeLong(data);
/* 344 */     return ctx.write(buf, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writePushPromise(ChannelHandlerContext ctx, int streamId, int promisedStreamId, Http2Headers headers, int padding, ChannelPromise promise) {
/* 350 */     ByteBuf headerBlock = null;
/*     */     
/* 352 */     Http2CodecUtil.SimpleChannelPromiseAggregator promiseAggregator = new Http2CodecUtil.SimpleChannelPromiseAggregator(promise, ctx.channel(), ctx.executor());
/*     */     try {
/* 354 */       verifyStreamId(streamId, "Stream ID");
/* 355 */       verifyStreamId(promisedStreamId, "Promised Stream ID");
/* 356 */       Http2CodecUtil.verifyPadding(padding);
/*     */ 
/*     */       
/* 359 */       headerBlock = ctx.alloc().buffer();
/* 360 */       this.headersEncoder.encodeHeaders(streamId, headers, headerBlock);
/*     */ 
/*     */       
/* 363 */       Http2Flags flags = (new Http2Flags()).paddingPresent((padding > 0));
/*     */       
/* 365 */       int nonFragmentLength = 4 + padding;
/* 366 */       int maxFragmentLength = this.maxFrameSize - nonFragmentLength;
/* 367 */       ByteBuf fragment = headerBlock.readRetainedSlice(Math.min(headerBlock.readableBytes(), maxFragmentLength));
/*     */       
/* 369 */       flags.endOfHeaders(!headerBlock.isReadable());
/*     */       
/* 371 */       int payloadLength = fragment.readableBytes() + nonFragmentLength;
/* 372 */       ByteBuf buf = ctx.alloc().buffer(14);
/* 373 */       Http2CodecUtil.writeFrameHeaderInternal(buf, payloadLength, (byte)5, flags, streamId);
/* 374 */       writePaddingLength(buf, padding);
/*     */ 
/*     */       
/* 377 */       buf.writeInt(promisedStreamId);
/* 378 */       ctx.write(buf, promiseAggregator.newPromise());
/*     */ 
/*     */       
/* 381 */       ctx.write(fragment, promiseAggregator.newPromise());
/*     */ 
/*     */       
/* 384 */       if (paddingBytes(padding) > 0) {
/* 385 */         ctx.write(ZERO_BUFFER.slice(0, paddingBytes(padding)), promiseAggregator.newPromise());
/*     */       }
/*     */       
/* 388 */       if (!flags.endOfHeaders()) {
/* 389 */         writeContinuationFrames(ctx, streamId, headerBlock, promiseAggregator);
/*     */       }
/* 391 */     } catch (Http2Exception e) {
/* 392 */       promiseAggregator.setFailure(e);
/* 393 */     } catch (Throwable t) {
/* 394 */       promiseAggregator.setFailure(t);
/* 395 */       promiseAggregator.doneAllocatingPromises();
/* 396 */       PlatformDependent.throwException(t);
/*     */     } finally {
/* 398 */       if (headerBlock != null) {
/* 399 */         headerBlock.release();
/*     */       }
/*     */     } 
/* 402 */     return (ChannelFuture)promiseAggregator.doneAllocatingPromises();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeGoAway(ChannelHandlerContext ctx, int lastStreamId, long errorCode, ByteBuf debugData, ChannelPromise promise) {
/* 409 */     Http2CodecUtil.SimpleChannelPromiseAggregator promiseAggregator = new Http2CodecUtil.SimpleChannelPromiseAggregator(promise, ctx.channel(), ctx.executor());
/*     */     try {
/* 411 */       verifyStreamOrConnectionId(lastStreamId, "Last Stream ID");
/* 412 */       verifyErrorCode(errorCode);
/*     */       
/* 414 */       int payloadLength = 8 + debugData.readableBytes();
/* 415 */       ByteBuf buf = ctx.alloc().buffer(17);
/*     */ 
/*     */       
/* 418 */       Http2CodecUtil.writeFrameHeaderInternal(buf, payloadLength, (byte)7, new Http2Flags(), 0);
/* 419 */       buf.writeInt(lastStreamId);
/* 420 */       buf.writeInt((int)errorCode);
/* 421 */       ctx.write(buf, promiseAggregator.newPromise());
/* 422 */     } catch (Throwable t) {
/*     */       try {
/* 424 */         debugData.release();
/*     */       } finally {
/* 426 */         promiseAggregator.setFailure(t);
/* 427 */         promiseAggregator.doneAllocatingPromises();
/*     */       } 
/* 429 */       return (ChannelFuture)promiseAggregator;
/*     */     } 
/*     */     
/*     */     try {
/* 433 */       ctx.write(debugData, promiseAggregator.newPromise());
/* 434 */     } catch (Throwable t) {
/* 435 */       promiseAggregator.setFailure(t);
/*     */     } 
/* 437 */     return (ChannelFuture)promiseAggregator.doneAllocatingPromises();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeWindowUpdate(ChannelHandlerContext ctx, int streamId, int windowSizeIncrement, ChannelPromise promise) {
/*     */     try {
/* 444 */       verifyStreamOrConnectionId(streamId, "Stream ID");
/* 445 */       verifyWindowSizeIncrement(windowSizeIncrement);
/*     */       
/* 447 */       ByteBuf buf = ctx.alloc().buffer(13);
/* 448 */       Http2CodecUtil.writeFrameHeaderInternal(buf, 4, (byte)8, new Http2Flags(), streamId);
/* 449 */       buf.writeInt(windowSizeIncrement);
/* 450 */       return ctx.write(buf, promise);
/* 451 */     } catch (Throwable t) {
/* 452 */       return (ChannelFuture)promise.setFailure(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeFrame(ChannelHandlerContext ctx, byte frameType, int streamId, Http2Flags flags, ByteBuf payload, ChannelPromise promise) {
/* 460 */     Http2CodecUtil.SimpleChannelPromiseAggregator promiseAggregator = new Http2CodecUtil.SimpleChannelPromiseAggregator(promise, ctx.channel(), ctx.executor());
/*     */     try {
/* 462 */       verifyStreamOrConnectionId(streamId, "Stream ID");
/* 463 */       ByteBuf buf = ctx.alloc().buffer(9);
/*     */ 
/*     */       
/* 466 */       Http2CodecUtil.writeFrameHeaderInternal(buf, payload.readableBytes(), frameType, flags, streamId);
/* 467 */       ctx.write(buf, promiseAggregator.newPromise());
/* 468 */     } catch (Throwable t) {
/*     */       try {
/* 470 */         payload.release();
/*     */       } finally {
/* 472 */         promiseAggregator.setFailure(t);
/* 473 */         promiseAggregator.doneAllocatingPromises();
/*     */       } 
/* 475 */       return (ChannelFuture)promiseAggregator;
/*     */     } 
/*     */     try {
/* 478 */       ctx.write(payload, promiseAggregator.newPromise());
/* 479 */     } catch (Throwable t) {
/* 480 */       promiseAggregator.setFailure(t);
/*     */     } 
/* 482 */     return (ChannelFuture)promiseAggregator.doneAllocatingPromises();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelFuture writeHeadersInternal(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endStream, boolean hasPriority, int streamDependency, short weight, boolean exclusive, ChannelPromise promise) {
/* 488 */     ByteBuf headerBlock = null;
/*     */     
/* 490 */     Http2CodecUtil.SimpleChannelPromiseAggregator promiseAggregator = new Http2CodecUtil.SimpleChannelPromiseAggregator(promise, ctx.channel(), ctx.executor());
/*     */     try {
/* 492 */       verifyStreamId(streamId, "Stream ID");
/* 493 */       if (hasPriority) {
/* 494 */         verifyStreamOrConnectionId(streamDependency, "Stream Dependency");
/* 495 */         Http2CodecUtil.verifyPadding(padding);
/* 496 */         verifyWeight(weight);
/*     */       } 
/*     */ 
/*     */       
/* 500 */       headerBlock = ctx.alloc().buffer();
/* 501 */       this.headersEncoder.encodeHeaders(streamId, headers, headerBlock);
/*     */ 
/*     */       
/* 504 */       Http2Flags flags = (new Http2Flags()).endOfStream(endStream).priorityPresent(hasPriority).paddingPresent((padding > 0));
/*     */ 
/*     */       
/* 507 */       int nonFragmentBytes = padding + flags.getNumPriorityBytes();
/* 508 */       int maxFragmentLength = this.maxFrameSize - nonFragmentBytes;
/* 509 */       ByteBuf fragment = headerBlock.readRetainedSlice(Math.min(headerBlock.readableBytes(), maxFragmentLength));
/*     */ 
/*     */       
/* 512 */       flags.endOfHeaders(!headerBlock.isReadable());
/*     */       
/* 514 */       int payloadLength = fragment.readableBytes() + nonFragmentBytes;
/* 515 */       ByteBuf buf = ctx.alloc().buffer(15);
/* 516 */       Http2CodecUtil.writeFrameHeaderInternal(buf, payloadLength, (byte)1, flags, streamId);
/* 517 */       writePaddingLength(buf, padding);
/*     */       
/* 519 */       if (hasPriority) {
/* 520 */         buf.writeInt(exclusive ? (int)(0x80000000L | streamDependency) : streamDependency);
/*     */ 
/*     */         
/* 523 */         buf.writeByte(weight - 1);
/*     */       } 
/* 525 */       ctx.write(buf, promiseAggregator.newPromise());
/*     */ 
/*     */       
/* 528 */       ctx.write(fragment, promiseAggregator.newPromise());
/*     */ 
/*     */       
/* 531 */       if (paddingBytes(padding) > 0) {
/* 532 */         ctx.write(ZERO_BUFFER.slice(0, paddingBytes(padding)), promiseAggregator.newPromise());
/*     */       }
/*     */       
/* 535 */       if (!flags.endOfHeaders()) {
/* 536 */         writeContinuationFrames(ctx, streamId, headerBlock, promiseAggregator);
/*     */       }
/* 538 */     } catch (Http2Exception e) {
/* 539 */       promiseAggregator.setFailure(e);
/* 540 */     } catch (Throwable t) {
/* 541 */       promiseAggregator.setFailure(t);
/* 542 */       promiseAggregator.doneAllocatingPromises();
/* 543 */       PlatformDependent.throwException(t);
/*     */     } finally {
/* 545 */       if (headerBlock != null) {
/* 546 */         headerBlock.release();
/*     */       }
/*     */     } 
/* 549 */     return (ChannelFuture)promiseAggregator.doneAllocatingPromises();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelFuture writeContinuationFrames(ChannelHandlerContext ctx, int streamId, ByteBuf headerBlock, Http2CodecUtil.SimpleChannelPromiseAggregator promiseAggregator) {
/* 557 */     Http2Flags flags = new Http2Flags();
/*     */     
/* 559 */     if (headerBlock.isReadable()) {
/*     */       
/* 561 */       int fragmentReadableBytes = Math.min(headerBlock.readableBytes(), this.maxFrameSize);
/* 562 */       ByteBuf buf = ctx.alloc().buffer(10);
/* 563 */       Http2CodecUtil.writeFrameHeaderInternal(buf, fragmentReadableBytes, (byte)9, flags, streamId);
/*     */       
/*     */       do {
/* 566 */         fragmentReadableBytes = Math.min(headerBlock.readableBytes(), this.maxFrameSize);
/* 567 */         ByteBuf fragment = headerBlock.readRetainedSlice(fragmentReadableBytes);
/*     */         
/* 569 */         if (headerBlock.isReadable()) {
/* 570 */           ctx.write(buf.retain(), promiseAggregator.newPromise());
/*     */         } else {
/*     */           
/* 573 */           flags = flags.endOfHeaders(true);
/* 574 */           buf.release();
/* 575 */           buf = ctx.alloc().buffer(10);
/* 576 */           Http2CodecUtil.writeFrameHeaderInternal(buf, fragmentReadableBytes, (byte)9, flags, streamId);
/* 577 */           ctx.write(buf, promiseAggregator.newPromise());
/*     */         } 
/*     */         
/* 580 */         ctx.write(fragment, promiseAggregator.newPromise());
/*     */       }
/* 582 */       while (headerBlock.isReadable());
/*     */     } 
/* 584 */     return (ChannelFuture)promiseAggregator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int paddingBytes(int padding) {
/* 593 */     return padding - 1;
/*     */   }
/*     */   
/*     */   private static void writePaddingLength(ByteBuf buf, int padding) {
/* 597 */     if (padding > 0)
/*     */     {
/*     */       
/* 600 */       buf.writeByte(padding - 1);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void verifyStreamId(int streamId, String argumentName) {
/* 605 */     ObjectUtil.checkPositive(streamId, argumentName);
/*     */   }
/*     */   
/*     */   private static void verifyStreamOrConnectionId(int streamId, String argumentName) {
/* 609 */     ObjectUtil.checkPositiveOrZero(streamId, argumentName);
/*     */   }
/*     */   
/*     */   private static void verifyWeight(short weight) {
/* 613 */     if (weight < 1 || weight > 256) {
/* 614 */       throw new IllegalArgumentException("Invalid weight: " + weight);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void verifyErrorCode(long errorCode) {
/* 619 */     if (errorCode < 0L || errorCode > 4294967295L) {
/* 620 */       throw new IllegalArgumentException("Invalid errorCode: " + errorCode);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void verifyWindowSizeIncrement(int windowSizeIncrement) {
/* 625 */     ObjectUtil.checkPositiveOrZero(windowSizeIncrement, "windowSizeIncrement");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2FrameWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */