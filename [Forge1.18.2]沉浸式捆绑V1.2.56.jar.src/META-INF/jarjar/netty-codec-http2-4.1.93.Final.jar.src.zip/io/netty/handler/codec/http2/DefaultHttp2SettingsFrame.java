/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ import io.netty.util.internal.StringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultHttp2SettingsFrame
/*    */   implements Http2SettingsFrame
/*    */ {
/*    */   private final Http2Settings settings;
/*    */   
/*    */   public DefaultHttp2SettingsFrame(Http2Settings settings) {
/* 32 */     this.settings = (Http2Settings)ObjectUtil.checkNotNull(settings, "settings");
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2Settings settings() {
/* 37 */     return this.settings;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 42 */     return "SETTINGS";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 47 */     if (!(o instanceof Http2SettingsFrame)) {
/* 48 */       return false;
/*    */     }
/* 50 */     Http2SettingsFrame other = (Http2SettingsFrame)o;
/* 51 */     return this.settings.equals(other.settings());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 56 */     return this.settings.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     return StringUtil.simpleClassName(this) + "(settings=" + this.settings + ')';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2SettingsFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */