/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultHttp2PriorityFrame
/*    */   extends AbstractHttp2StreamFrame
/*    */   implements Http2PriorityFrame
/*    */ {
/*    */   private final int streamDependency;
/*    */   private final short weight;
/*    */   private final boolean exclusive;
/*    */   
/*    */   public DefaultHttp2PriorityFrame(int streamDependency, short weight, boolean exclusive) {
/* 31 */     this.streamDependency = streamDependency;
/* 32 */     this.weight = weight;
/* 33 */     this.exclusive = exclusive;
/*    */   }
/*    */ 
/*    */   
/*    */   public int streamDependency() {
/* 38 */     return this.streamDependency;
/*    */   }
/*    */ 
/*    */   
/*    */   public short weight() {
/* 43 */     return this.weight;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean exclusive() {
/* 48 */     return this.exclusive;
/*    */   }
/*    */ 
/*    */   
/*    */   public DefaultHttp2PriorityFrame stream(Http2FrameStream stream) {
/* 53 */     super.stream(stream);
/* 54 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 59 */     return "PRIORITY_FRAME";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 64 */     if (!(o instanceof DefaultHttp2PriorityFrame)) {
/* 65 */       return false;
/*    */     }
/* 67 */     DefaultHttp2PriorityFrame other = (DefaultHttp2PriorityFrame)o;
/* 68 */     boolean same = super.equals(other);
/* 69 */     return (same && this.streamDependency == other.streamDependency && this.weight == other.weight && this.exclusive == other.exclusive);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 75 */     int hash = super.hashCode();
/* 76 */     hash = hash * 31 + this.streamDependency;
/* 77 */     hash = hash * 31 + this.weight;
/* 78 */     hash = hash * 31 + (this.exclusive ? 1 : 0);
/* 79 */     return hash;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 84 */     return "DefaultHttp2PriorityFrame(stream=" + 
/* 85 */       stream() + ", streamDependency=" + this.streamDependency + ", weight=" + this.weight + ", exclusive=" + this.exclusive + ')';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2PriorityFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */