/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Http2FrameStreamEvent
/*    */ {
/*    */   private final Http2FrameStream stream;
/*    */   private final Type type;
/*    */   
/*    */   public enum Type
/*    */   {
/* 28 */     State,
/* 29 */     Writability;
/*    */   }
/*    */   
/*    */   private Http2FrameStreamEvent(Http2FrameStream stream, Type type) {
/* 33 */     this.stream = stream;
/* 34 */     this.type = type;
/*    */   }
/*    */   
/*    */   public Http2FrameStream stream() {
/* 38 */     return this.stream;
/*    */   }
/*    */   
/*    */   public Type type() {
/* 42 */     return this.type;
/*    */   }
/*    */   
/*    */   static Http2FrameStreamEvent stateChanged(Http2FrameStream stream) {
/* 46 */     return new Http2FrameStreamEvent(stream, Type.State);
/*    */   }
/*    */   
/*    */   static Http2FrameStreamEvent writabilityChanged(Http2FrameStream stream) {
/* 50 */     return new Http2FrameStreamEvent(stream, Type.Writability);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2FrameStreamEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */