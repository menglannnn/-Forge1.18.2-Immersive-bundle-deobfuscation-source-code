/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler.Sharable;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.EncoderException;
/*     */ import io.netty.handler.codec.MessageToMessageCodec;
/*     */ import io.netty.handler.codec.http.DefaultHttpContent;
/*     */ import io.netty.handler.codec.http.DefaultLastHttpContent;
/*     */ import io.netty.handler.codec.http.FullHttpMessage;
/*     */ import io.netty.handler.codec.http.HttpContent;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaderValues;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpObject;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.HttpScheme;
/*     */ import io.netty.handler.codec.http.HttpStatusClass;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import io.netty.handler.codec.http.LastHttpContent;
/*     */ import io.netty.handler.ssl.SslHandler;
/*     */ import io.netty.util.Attribute;
/*     */ import io.netty.util.AttributeKey;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Sharable
/*     */ public class Http2StreamFrameToHttpObjectCodec
/*     */   extends MessageToMessageCodec<Http2StreamFrame, HttpObject>
/*     */ {
/*  65 */   private static final AttributeKey<HttpScheme> SCHEME_ATTR_KEY = AttributeKey.valueOf(HttpScheme.class, "STREAMFRAMECODEC_SCHEME");
/*     */   
/*     */   private final boolean isServer;
/*     */   
/*     */   private final boolean validateHeaders;
/*     */   
/*     */   public Http2StreamFrameToHttpObjectCodec(boolean isServer, boolean validateHeaders) {
/*  72 */     this.isServer = isServer;
/*  73 */     this.validateHeaders = validateHeaders;
/*     */   }
/*     */   
/*     */   public Http2StreamFrameToHttpObjectCodec(boolean isServer) {
/*  77 */     this(isServer, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean acceptInboundMessage(Object msg) throws Exception {
/*  82 */     return (msg instanceof Http2HeadersFrame || msg instanceof Http2DataFrame);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, Http2StreamFrame frame, List<Object> out) throws Exception {
/*  87 */     if (frame instanceof Http2HeadersFrame) {
/*  88 */       Http2HeadersFrame headersFrame = (Http2HeadersFrame)frame;
/*  89 */       Http2Headers headers = headersFrame.headers();
/*  90 */       Http2FrameStream stream = headersFrame.stream();
/*  91 */       int id = (stream == null) ? 0 : stream.id();
/*     */       
/*  93 */       CharSequence status = headers.status();
/*     */ 
/*     */ 
/*     */       
/*  97 */       if (null != status && isInformationalResponseHeaderFrame(status)) {
/*  98 */         FullHttpMessage fullMsg = newFullMessage(id, headers, ctx.alloc());
/*  99 */         out.add(fullMsg);
/*     */         
/*     */         return;
/*     */       } 
/* 103 */       if (headersFrame.isEndStream()) {
/* 104 */         if (headers.method() == null && status == null) {
/* 105 */           DefaultLastHttpContent defaultLastHttpContent = new DefaultLastHttpContent(Unpooled.EMPTY_BUFFER, this.validateHeaders);
/* 106 */           HttpConversionUtil.addHttp2ToHttpHeaders(id, headers, defaultLastHttpContent.trailingHeaders(), HttpVersion.HTTP_1_1, true, true);
/*     */           
/* 108 */           out.add(defaultLastHttpContent);
/*     */         } else {
/* 110 */           FullHttpMessage full = newFullMessage(id, headers, ctx.alloc());
/* 111 */           out.add(full);
/*     */         } 
/*     */       } else {
/* 114 */         HttpMessage req = newMessage(id, headers);
/* 115 */         if ((status == null || !isContentAlwaysEmpty(status)) && !HttpUtil.isContentLengthSet(req)) {
/* 116 */           req.headers().add((CharSequence)HttpHeaderNames.TRANSFER_ENCODING, HttpHeaderValues.CHUNKED);
/*     */         }
/* 118 */         out.add(req);
/*     */       } 
/* 120 */     } else if (frame instanceof Http2DataFrame) {
/* 121 */       Http2DataFrame dataFrame = (Http2DataFrame)frame;
/* 122 */       if (dataFrame.isEndStream()) {
/* 123 */         out.add(new DefaultLastHttpContent(dataFrame.content().retain(), this.validateHeaders));
/*     */       } else {
/* 125 */         out.add(new DefaultHttpContent(dataFrame.content().retain()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeLastContent(LastHttpContent last, List<Object> out) {
/* 131 */     boolean needFiller = (!(last instanceof FullHttpMessage) && last.trailingHeaders().isEmpty());
/* 132 */     if (last.content().isReadable() || needFiller) {
/* 133 */       out.add(new DefaultHttp2DataFrame(last.content().retain(), last.trailingHeaders().isEmpty()));
/*     */     }
/* 135 */     if (!last.trailingHeaders().isEmpty()) {
/* 136 */       Http2Headers headers = HttpConversionUtil.toHttp2Headers(last.trailingHeaders(), this.validateHeaders);
/* 137 */       out.add(new DefaultHttp2HeadersFrame(headers, true));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, HttpObject obj, List<Object> out) throws Exception {
/* 157 */     if (obj instanceof HttpResponse) {
/* 158 */       HttpResponse res = (HttpResponse)obj;
/* 159 */       HttpResponseStatus status = res.status();
/* 160 */       int code = status.code();
/* 161 */       HttpStatusClass statusClass = status.codeClass();
/*     */ 
/*     */       
/* 164 */       if (statusClass == HttpStatusClass.INFORMATIONAL && code != 101) {
/* 165 */         if (res instanceof io.netty.handler.codec.http.FullHttpResponse) {
/* 166 */           Http2Headers headers = toHttp2Headers(ctx, (HttpMessage)res);
/* 167 */           out.add(new DefaultHttp2HeadersFrame(headers, false));
/*     */           return;
/*     */         } 
/* 170 */         throw new EncoderException(status + " must be a FullHttpResponse");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 175 */     if (obj instanceof HttpMessage) {
/* 176 */       Http2Headers headers = toHttp2Headers(ctx, (HttpMessage)obj);
/* 177 */       boolean noMoreFrames = false;
/* 178 */       if (obj instanceof FullHttpMessage) {
/* 179 */         FullHttpMessage full = (FullHttpMessage)obj;
/* 180 */         noMoreFrames = (!full.content().isReadable() && full.trailingHeaders().isEmpty());
/*     */       } 
/*     */       
/* 183 */       out.add(new DefaultHttp2HeadersFrame(headers, noMoreFrames));
/*     */     } 
/*     */     
/* 186 */     if (obj instanceof LastHttpContent) {
/* 187 */       LastHttpContent last = (LastHttpContent)obj;
/* 188 */       encodeLastContent(last, out);
/* 189 */     } else if (obj instanceof HttpContent) {
/* 190 */       HttpContent cont = (HttpContent)obj;
/* 191 */       out.add(new DefaultHttp2DataFrame(cont.content().retain(), false));
/*     */     } 
/*     */   }
/*     */   
/*     */   private Http2Headers toHttp2Headers(ChannelHandlerContext ctx, HttpMessage msg) {
/* 196 */     if (msg instanceof io.netty.handler.codec.http.HttpRequest) {
/* 197 */       msg.headers().set((CharSequence)HttpConversionUtil.ExtensionHeaderNames.SCHEME
/* 198 */           .text(), 
/* 199 */           connectionScheme(ctx));
/*     */     }
/*     */     
/* 202 */     return HttpConversionUtil.toHttp2Headers(msg, this.validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   private HttpMessage newMessage(int id, Http2Headers headers) throws Http2Exception {
/* 207 */     return this.isServer ? 
/* 208 */       (HttpMessage)HttpConversionUtil.toHttpRequest(id, headers, this.validateHeaders) : 
/* 209 */       (HttpMessage)HttpConversionUtil.toHttpResponse(id, headers, this.validateHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private FullHttpMessage newFullMessage(int id, Http2Headers headers, ByteBufAllocator alloc) throws Http2Exception {
/* 215 */     return this.isServer ? 
/* 216 */       (FullHttpMessage)HttpConversionUtil.toFullHttpRequest(id, headers, alloc, this.validateHeaders) : 
/* 217 */       (FullHttpMessage)HttpConversionUtil.toFullHttpResponse(id, headers, alloc, this.validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 222 */     super.handlerAdded(ctx);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     Attribute<HttpScheme> schemeAttribute = connectionSchemeAttribute(ctx);
/* 230 */     if (schemeAttribute.get() == null) {
/* 231 */       HttpScheme scheme = isSsl(ctx) ? HttpScheme.HTTPS : HttpScheme.HTTP;
/* 232 */       schemeAttribute.set(scheme);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean isSsl(ChannelHandlerContext ctx) {
/* 237 */     Channel connChannel = connectionChannel(ctx);
/* 238 */     return (null != connChannel.pipeline().get(SslHandler.class));
/*     */   }
/*     */   
/*     */   private static HttpScheme connectionScheme(ChannelHandlerContext ctx) {
/* 242 */     HttpScheme scheme = (HttpScheme)connectionSchemeAttribute(ctx).get();
/* 243 */     return (scheme == null) ? HttpScheme.HTTP : scheme;
/*     */   }
/*     */   
/*     */   private static Attribute<HttpScheme> connectionSchemeAttribute(ChannelHandlerContext ctx) {
/* 247 */     Channel ch = connectionChannel(ctx);
/* 248 */     return ch.attr(SCHEME_ATTR_KEY);
/*     */   }
/*     */   
/*     */   private static Channel connectionChannel(ChannelHandlerContext ctx) {
/* 252 */     Channel ch = ctx.channel();
/* 253 */     return (ch instanceof Http2StreamChannel) ? ch.parent() : ch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isInformationalResponseHeaderFrame(CharSequence status) {
/* 261 */     if (status.length() == 3) {
/* 262 */       char char0 = status.charAt(0);
/* 263 */       char char1 = status.charAt(1);
/* 264 */       char char2 = status.charAt(2);
/* 265 */       return (char0 == '1' && char1 >= '0' && char1 <= '9' && char2 >= '0' && char2 <= '9' && char2 != '1');
/*     */     } 
/*     */ 
/*     */     
/* 269 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isContentAlwaysEmpty(CharSequence status) {
/* 277 */     if (status.length() == 3) {
/* 278 */       char char0 = status.charAt(0);
/* 279 */       char char1 = status.charAt(1);
/* 280 */       char char2 = status.charAt(2);
/* 281 */       return ((char0 == '2' || char0 == '3') && char1 == '0' && char2 == '4');
/*     */     } 
/*     */ 
/*     */     
/* 285 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2StreamFrameToHttpObjectCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */