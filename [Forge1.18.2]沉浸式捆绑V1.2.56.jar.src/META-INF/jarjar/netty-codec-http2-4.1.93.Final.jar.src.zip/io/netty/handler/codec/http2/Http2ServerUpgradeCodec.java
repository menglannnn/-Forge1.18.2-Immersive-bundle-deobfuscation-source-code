/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.base64.Base64;
/*     */ import io.netty.handler.codec.base64.Base64Dialect;
/*     */ import io.netty.handler.codec.http.FullHttpRequest;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpServerUpgradeHandler;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.CharBuffer;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Http2ServerUpgradeCodec
/*     */   implements HttpServerUpgradeHandler.UpgradeCodec
/*     */ {
/*  47 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(Http2ServerUpgradeCodec.class);
/*     */   
/*  49 */   private static final List<CharSequence> REQUIRED_UPGRADE_HEADERS = Collections.singletonList(Http2CodecUtil.HTTP_UPGRADE_SETTINGS_HEADER);
/*  50 */   private static final ChannelHandler[] EMPTY_HANDLERS = new ChannelHandler[0];
/*     */ 
/*     */   
/*     */   private final String handlerName;
/*     */ 
/*     */   
/*     */   private final Http2ConnectionHandler connectionHandler;
/*     */   
/*     */   private final ChannelHandler[] handlers;
/*     */   
/*     */   private final Http2FrameReader frameReader;
/*     */   
/*     */   private Http2Settings settings;
/*     */ 
/*     */   
/*     */   public Http2ServerUpgradeCodec(Http2ConnectionHandler connectionHandler) {
/*  66 */     this(null, connectionHandler, EMPTY_HANDLERS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ServerUpgradeCodec(Http2MultiplexCodec http2Codec) {
/*  76 */     this(null, http2Codec, EMPTY_HANDLERS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ServerUpgradeCodec(String handlerName, Http2ConnectionHandler connectionHandler) {
/*  87 */     this(handlerName, connectionHandler, EMPTY_HANDLERS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ServerUpgradeCodec(String handlerName, Http2MultiplexCodec http2Codec) {
/*  97 */     this(handlerName, http2Codec, EMPTY_HANDLERS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ServerUpgradeCodec(Http2FrameCodec http2Codec, ChannelHandler... handlers) {
/* 108 */     this(null, http2Codec, handlers);
/*     */   }
/*     */ 
/*     */   
/*     */   private Http2ServerUpgradeCodec(String handlerName, Http2ConnectionHandler connectionHandler, ChannelHandler... handlers) {
/* 113 */     this.handlerName = handlerName;
/* 114 */     this.connectionHandler = connectionHandler;
/* 115 */     this.handlers = handlers;
/* 116 */     this.frameReader = new DefaultHttp2FrameReader();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<CharSequence> requiredUpgradeHeaders() {
/* 121 */     return REQUIRED_UPGRADE_HEADERS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean prepareUpgradeResponse(ChannelHandlerContext ctx, FullHttpRequest upgradeRequest, HttpHeaders headers) {
/*     */     try {
/* 130 */       List<String> upgradeHeaders = upgradeRequest.headers().getAll(Http2CodecUtil.HTTP_UPGRADE_SETTINGS_HEADER);
/* 131 */       if (upgradeHeaders.size() != 1) {
/* 132 */         throw new IllegalArgumentException("There must be 1 and only 1 " + Http2CodecUtil.HTTP_UPGRADE_SETTINGS_HEADER + " header.");
/*     */       }
/*     */       
/* 135 */       this.settings = decodeSettingsHeader(ctx, upgradeHeaders.get(0));
/*     */       
/* 137 */       return true;
/* 138 */     } catch (Throwable cause) {
/* 139 */       logger.info("Error during upgrade to HTTP/2", cause);
/* 140 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void upgradeTo(ChannelHandlerContext ctx, FullHttpRequest upgradeRequest) {
/*     */     try {
/* 148 */       ctx.pipeline().addAfter(ctx.name(), this.handlerName, (ChannelHandler)this.connectionHandler);
/*     */ 
/*     */ 
/*     */       
/* 152 */       if (this.handlers != null) {
/* 153 */         String name = ctx.pipeline().context((ChannelHandler)this.connectionHandler).name();
/* 154 */         for (int i = this.handlers.length - 1; i >= 0; i--) {
/* 155 */           ctx.pipeline().addAfter(name, null, this.handlers[i]);
/*     */         }
/*     */       } 
/* 158 */       this.connectionHandler.onHttpServerUpgrade(this.settings);
/* 159 */     } catch (Http2Exception e) {
/* 160 */       ctx.fireExceptionCaught(e);
/* 161 */       ctx.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Http2Settings decodeSettingsHeader(ChannelHandlerContext ctx, CharSequence settingsHeader) throws Http2Exception {
/* 170 */     ByteBuf header = ByteBufUtil.encodeString(ctx.alloc(), CharBuffer.wrap(settingsHeader), CharsetUtil.UTF_8);
/*     */     
/*     */     try {
/* 173 */       ByteBuf payload = Base64.decode(header, Base64Dialect.URL_SAFE);
/*     */ 
/*     */       
/* 176 */       ByteBuf frame = createSettingsFrame(ctx, payload);
/*     */ 
/*     */       
/* 179 */       return decodeSettings(ctx, frame);
/*     */     } finally {
/* 181 */       header.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Http2Settings decodeSettings(ChannelHandlerContext ctx, ByteBuf frame) throws Http2Exception {
/*     */     try {
/* 190 */       final Http2Settings decodedSettings = new Http2Settings();
/* 191 */       this.frameReader.readFrame(ctx, frame, new Http2FrameAdapter()
/*     */           {
/*     */             public void onSettingsRead(ChannelHandlerContext ctx, Http2Settings settings) {
/* 194 */               decodedSettings.copyFrom(settings);
/*     */             }
/*     */           });
/* 197 */       return decodedSettings;
/*     */     } finally {
/* 199 */       frame.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ByteBuf createSettingsFrame(ChannelHandlerContext ctx, ByteBuf payload) {
/* 207 */     ByteBuf frame = ctx.alloc().buffer(9 + payload.readableBytes());
/* 208 */     Http2CodecUtil.writeFrameHeader(frame, payload.readableBytes(), (byte)4, new Http2Flags(), 0);
/* 209 */     frame.writeBytes(payload);
/* 210 */     payload.release();
/* 211 */     return frame;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2ServerUpgradeCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */