/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.internal.MathUtil;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HpackEncoder
/*     */ {
/*     */   static final int NOT_FOUND = -1;
/*     */   static final int HUFF_CODE_THRESHOLD = 512;
/*     */   private final NameEntry[] nameEntries;
/*     */   private final NameValueEntry[] nameValueEntries;
/*  72 */   private final NameValueEntry head = new NameValueEntry(-1, (CharSequence)AsciiString.EMPTY_STRING, (CharSequence)AsciiString.EMPTY_STRING, 2147483647, null);
/*     */ 
/*     */   
/*  75 */   private NameValueEntry latest = this.head;
/*     */   
/*  77 */   private final HpackHuffmanEncoder hpackHuffmanEncoder = new HpackHuffmanEncoder();
/*     */   
/*     */   private final byte hashMask;
/*     */   
/*     */   private final boolean ignoreMaxHeaderListSize;
/*     */   
/*     */   private final int huffCodeThreshold;
/*     */   private long size;
/*     */   private long maxHeaderTableSize;
/*     */   private long maxHeaderListSize;
/*     */   
/*     */   HpackEncoder() {
/*  89 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HpackEncoder(boolean ignoreMaxHeaderListSize) {
/*  96 */     this(ignoreMaxHeaderListSize, 64, 512);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HpackEncoder(boolean ignoreMaxHeaderListSize, int arraySizeHint, int huffCodeThreshold) {
/* 103 */     this.ignoreMaxHeaderListSize = ignoreMaxHeaderListSize;
/* 104 */     this.maxHeaderTableSize = 4096L;
/* 105 */     this.maxHeaderListSize = 4294967295L;
/*     */ 
/*     */     
/* 108 */     this.nameEntries = new NameEntry[MathUtil.findNextPositivePowerOfTwo(Math.max(2, Math.min(arraySizeHint, 128)))];
/* 109 */     this.nameValueEntries = new NameValueEntry[this.nameEntries.length];
/* 110 */     this.hashMask = (byte)(this.nameEntries.length - 1);
/* 111 */     this.huffCodeThreshold = huffCodeThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeHeaders(int streamId, ByteBuf out, Http2Headers headers, Http2HeadersEncoder.SensitivityDetector sensitivityDetector) throws Http2Exception {
/* 121 */     if (this.ignoreMaxHeaderListSize) {
/* 122 */       encodeHeadersIgnoreMaxHeaderListSize(out, headers, sensitivityDetector);
/*     */     } else {
/* 124 */       encodeHeadersEnforceMaxHeaderListSize(streamId, out, headers, sensitivityDetector);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void encodeHeadersEnforceMaxHeaderListSize(int streamId, ByteBuf out, Http2Headers headers, Http2HeadersEncoder.SensitivityDetector sensitivityDetector) throws Http2Exception {
/* 131 */     long headerSize = 0L;
/*     */     
/* 133 */     for (Map.Entry<CharSequence, CharSequence> header : (Iterable<Map.Entry<CharSequence, CharSequence>>)headers) {
/* 134 */       CharSequence name = header.getKey();
/* 135 */       CharSequence value = header.getValue();
/*     */ 
/*     */       
/* 138 */       headerSize += HpackHeaderField.sizeOf(name, value);
/* 139 */       if (headerSize > this.maxHeaderListSize) {
/* 140 */         Http2CodecUtil.headerListSizeExceeded(streamId, this.maxHeaderListSize, false);
/*     */       }
/*     */     } 
/* 143 */     encodeHeadersIgnoreMaxHeaderListSize(out, headers, sensitivityDetector);
/*     */   }
/*     */ 
/*     */   
/*     */   private void encodeHeadersIgnoreMaxHeaderListSize(ByteBuf out, Http2Headers headers, Http2HeadersEncoder.SensitivityDetector sensitivityDetector) {
/* 148 */     for (Map.Entry<CharSequence, CharSequence> header : (Iterable<Map.Entry<CharSequence, CharSequence>>)headers) {
/* 149 */       CharSequence name = header.getKey();
/* 150 */       CharSequence value = header.getValue();
/* 151 */       encodeHeader(out, name, value, sensitivityDetector.isSensitive(name, value), 
/* 152 */           HpackHeaderField.sizeOf(name, value));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void encodeHeader(ByteBuf out, CharSequence name, CharSequence value, boolean sensitive, long headerSize) {
/* 163 */     if (sensitive) {
/* 164 */       int nameIndex = getNameIndex(name);
/* 165 */       encodeLiteral(out, name, value, HpackUtil.IndexType.NEVER, nameIndex);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 170 */     if (this.maxHeaderTableSize == 0L) {
/* 171 */       int staticTableIndex = HpackStaticTable.getIndexInsensitive(name, value);
/* 172 */       if (staticTableIndex == -1) {
/* 173 */         int nameIndex = HpackStaticTable.getIndex(name);
/* 174 */         encodeLiteral(out, name, value, HpackUtil.IndexType.NONE, nameIndex);
/*     */       } else {
/* 176 */         encodeInteger(out, 128, 7, staticTableIndex);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 182 */     if (headerSize > this.maxHeaderTableSize) {
/* 183 */       int nameIndex = getNameIndex(name);
/* 184 */       encodeLiteral(out, name, value, HpackUtil.IndexType.NONE, nameIndex);
/*     */       
/*     */       return;
/*     */     } 
/* 188 */     int nameHash = AsciiString.hashCode(name);
/* 189 */     int valueHash = AsciiString.hashCode(value);
/* 190 */     NameValueEntry headerField = getEntryInsensitive(name, nameHash, value, valueHash);
/* 191 */     if (headerField != null) {
/*     */       
/* 193 */       encodeInteger(out, 128, 7, getIndexPlusOffset(headerField.counter));
/*     */     } else {
/* 195 */       int staticTableIndex = HpackStaticTable.getIndexInsensitive(name, value);
/* 196 */       if (staticTableIndex != -1) {
/*     */         
/* 198 */         encodeInteger(out, 128, 7, staticTableIndex);
/*     */       } else {
/* 200 */         ensureCapacity(headerSize);
/* 201 */         encodeAndAddEntries(out, name, nameHash, value, valueHash);
/* 202 */         this.size += headerSize;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeAndAddEntries(ByteBuf out, CharSequence name, int nameHash, CharSequence value, int valueHash) {
/* 208 */     int staticTableIndex = HpackStaticTable.getIndex(name);
/* 209 */     int nextCounter = latestCounter() - 1;
/* 210 */     if (staticTableIndex == -1) {
/* 211 */       NameEntry e = getEntry(name, nameHash);
/* 212 */       if (e == null) {
/* 213 */         encodeLiteral(out, name, value, HpackUtil.IndexType.INCREMENTAL, -1);
/* 214 */         addNameEntry(name, nameHash, nextCounter);
/* 215 */         addNameValueEntry(name, value, nameHash, valueHash, nextCounter);
/*     */       } else {
/* 217 */         encodeLiteral(out, name, value, HpackUtil.IndexType.INCREMENTAL, getIndexPlusOffset(e.counter));
/* 218 */         addNameValueEntry(e.name, value, nameHash, valueHash, nextCounter);
/*     */ 
/*     */         
/* 221 */         e.counter = nextCounter;
/*     */       } 
/*     */     } else {
/* 224 */       encodeLiteral(out, name, value, HpackUtil.IndexType.INCREMENTAL, staticTableIndex);
/*     */       
/* 226 */       addNameValueEntry(
/* 227 */           (HpackStaticTable.getEntry(staticTableIndex)).name, value, nameHash, valueHash, nextCounter);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxHeaderTableSize(ByteBuf out, long maxHeaderTableSize) throws Http2Exception {
/* 235 */     if (maxHeaderTableSize < 0L || maxHeaderTableSize > 4294967295L)
/* 236 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Header Table Size must be >= %d and <= %d but was %d", new Object[] {
/* 237 */             Long.valueOf(0L), Long.valueOf(4294967295L), Long.valueOf(maxHeaderTableSize)
/*     */           }); 
/* 239 */     if (this.maxHeaderTableSize == maxHeaderTableSize) {
/*     */       return;
/*     */     }
/* 242 */     this.maxHeaderTableSize = maxHeaderTableSize;
/* 243 */     ensureCapacity(0L);
/*     */     
/* 245 */     encodeInteger(out, 32, 5, maxHeaderTableSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxHeaderTableSize() {
/* 252 */     return this.maxHeaderTableSize;
/*     */   }
/*     */   
/*     */   public void setMaxHeaderListSize(long maxHeaderListSize) throws Http2Exception {
/* 256 */     if (maxHeaderListSize < 0L || maxHeaderListSize > 4294967295L)
/* 257 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Header List Size must be >= %d and <= %d but was %d", new Object[] {
/* 258 */             Long.valueOf(0L), Long.valueOf(4294967295L), Long.valueOf(maxHeaderListSize)
/*     */           }); 
/* 260 */     this.maxHeaderListSize = maxHeaderListSize;
/*     */   }
/*     */   
/*     */   public long getMaxHeaderListSize() {
/* 264 */     return this.maxHeaderListSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void encodeInteger(ByteBuf out, int mask, int n, int i) {
/* 271 */     encodeInteger(out, mask, n, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void encodeInteger(ByteBuf out, int mask, int n, long i) {
/* 278 */     assert n >= 0 && n <= 8 : "N: " + n;
/* 279 */     int nbits = 255 >>> 8 - n;
/* 280 */     if (i < nbits) {
/* 281 */       out.writeByte((int)(mask | i));
/*     */     } else {
/* 283 */       out.writeByte(mask | nbits);
/* 284 */       long length = i - nbits;
/* 285 */       for (; (length & 0xFFFFFFFFFFFFFF80L) != 0L; length >>>= 7L) {
/* 286 */         out.writeByte((int)(length & 0x7FL | 0x80L));
/*     */       }
/* 288 */       out.writeByte((int)length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void encodeStringLiteral(ByteBuf out, CharSequence string) {
/*     */     int huffmanLength;
/* 297 */     if (string.length() >= this.huffCodeThreshold && (
/* 298 */       huffmanLength = this.hpackHuffmanEncoder.getEncodedLength(string)) < string.length()) {
/* 299 */       encodeInteger(out, 128, 7, huffmanLength);
/* 300 */       this.hpackHuffmanEncoder.encode(out, string);
/*     */     } else {
/* 302 */       encodeInteger(out, 0, 7, string.length());
/* 303 */       if (string instanceof AsciiString) {
/*     */         
/* 305 */         AsciiString asciiString = (AsciiString)string;
/* 306 */         out.writeBytes(asciiString.array(), asciiString.arrayOffset(), asciiString.length());
/*     */       }
/*     */       else {
/*     */         
/* 310 */         out.writeCharSequence(string, CharsetUtil.ISO_8859_1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void encodeLiteral(ByteBuf out, CharSequence name, CharSequence value, HpackUtil.IndexType indexType, int nameIndex) {
/* 320 */     boolean nameIndexValid = (nameIndex != -1);
/* 321 */     switch (indexType) {
/*     */       case INCREMENTAL:
/* 323 */         encodeInteger(out, 64, 6, nameIndexValid ? nameIndex : 0);
/*     */         break;
/*     */       case NONE:
/* 326 */         encodeInteger(out, 0, 4, nameIndexValid ? nameIndex : 0);
/*     */         break;
/*     */       case NEVER:
/* 329 */         encodeInteger(out, 16, 4, nameIndexValid ? nameIndex : 0);
/*     */         break;
/*     */       default:
/* 332 */         throw new Error("should not reach here");
/*     */     } 
/* 334 */     if (!nameIndexValid) {
/* 335 */       encodeStringLiteral(out, name);
/*     */     }
/* 337 */     encodeStringLiteral(out, value);
/*     */   }
/*     */   
/*     */   private int getNameIndex(CharSequence name) {
/* 341 */     int index = HpackStaticTable.getIndex(name);
/* 342 */     if (index != -1) {
/* 343 */       return index;
/*     */     }
/* 345 */     NameEntry e = getEntry(name, AsciiString.hashCode(name));
/* 346 */     return (e == null) ? -1 : getIndexPlusOffset(e.counter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCapacity(long headerSize) {
/* 354 */     while (this.maxHeaderTableSize - this.size < headerSize) {
/* 355 */       remove();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int length() {
/* 363 */     return isEmpty() ? 0 : getIndex(this.head.after.counter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long size() {
/* 370 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HpackHeaderField getHeaderField(int index) {
/* 377 */     NameValueEntry entry = this.head;
/* 378 */     while (index++ < length()) {
/* 379 */       entry = entry.after;
/*     */     }
/* 381 */     return entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NameValueEntry getEntryInsensitive(CharSequence name, int nameHash, CharSequence value, int valueHash) {
/* 389 */     int h = hash(nameHash, valueHash);
/* 390 */     for (NameValueEntry e = this.nameValueEntries[bucket(h)]; e != null; e = e.next) {
/* 391 */       if (e.hash == h && HpackUtil.equalsVariableTime(value, e.value) && HpackUtil.equalsVariableTime(name, e.name)) {
/* 392 */         return e;
/*     */       }
/*     */     } 
/* 395 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NameEntry getEntry(CharSequence name, int nameHash) {
/* 403 */     for (NameEntry e = this.nameEntries[bucket(nameHash)]; e != null; e = e.next) {
/* 404 */       if (e.hash == nameHash && HpackUtil.equalsConstantTime(name, e.name) != 0) {
/* 405 */         return e;
/*     */       }
/*     */     } 
/* 408 */     return null;
/*     */   }
/*     */   
/*     */   private int getIndexPlusOffset(int counter) {
/* 412 */     return getIndex(counter) + HpackStaticTable.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getIndex(int counter) {
/* 419 */     return counter - latestCounter() + 1;
/*     */   }
/*     */   
/*     */   private int latestCounter() {
/* 423 */     return this.latest.counter;
/*     */   }
/*     */   
/*     */   private void addNameEntry(CharSequence name, int nameHash, int nextCounter) {
/* 427 */     int bucket = bucket(nameHash);
/* 428 */     this.nameEntries[bucket] = new NameEntry(nameHash, name, nextCounter, this.nameEntries[bucket]);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addNameValueEntry(CharSequence name, CharSequence value, int nameHash, int valueHash, int nextCounter) {
/* 433 */     int hash = hash(nameHash, valueHash);
/* 434 */     int bucket = bucket(hash);
/* 435 */     NameValueEntry e = new NameValueEntry(hash, name, value, nextCounter, this.nameValueEntries[bucket]);
/* 436 */     this.nameValueEntries[bucket] = e;
/* 437 */     this.latest.after = e;
/* 438 */     this.latest = e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void remove() {
/* 445 */     NameValueEntry eldest = this.head.after;
/* 446 */     removeNameValueEntry(eldest);
/* 447 */     removeNameEntryMatchingCounter(eldest.name, eldest.counter);
/* 448 */     this.head.after = eldest.after;
/* 449 */     eldest.unlink();
/* 450 */     this.size -= eldest.size();
/* 451 */     if (isEmpty()) {
/* 452 */       this.latest = this.head;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isEmpty() {
/* 457 */     return (this.size == 0L);
/*     */   }
/*     */   
/*     */   private void removeNameValueEntry(NameValueEntry eldest) {
/* 461 */     int bucket = bucket(eldest.hash);
/* 462 */     NameValueEntry e = this.nameValueEntries[bucket];
/* 463 */     if (e == eldest) {
/* 464 */       this.nameValueEntries[bucket] = eldest.next;
/*     */     } else {
/* 466 */       while (e.next != eldest) {
/* 467 */         e = e.next;
/*     */       }
/* 469 */       e.next = eldest.next;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeNameEntryMatchingCounter(CharSequence name, int counter) {
/* 474 */     int hash = AsciiString.hashCode(name);
/* 475 */     int bucket = bucket(hash);
/* 476 */     NameEntry e = this.nameEntries[bucket];
/* 477 */     if (e == null) {
/*     */       return;
/*     */     }
/* 480 */     if (counter == e.counter) {
/* 481 */       this.nameEntries[bucket] = e.next;
/* 482 */       e.unlink();
/*     */     } else {
/* 484 */       NameEntry prev = e;
/* 485 */       e = e.next;
/* 486 */       while (e != null) {
/* 487 */         if (counter == e.counter) {
/* 488 */           prev.next = e.next;
/* 489 */           e.unlink();
/*     */           break;
/*     */         } 
/* 492 */         prev = e;
/* 493 */         e = e.next;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int bucket(int h) {
/* 502 */     return h & this.hashMask;
/*     */   }
/*     */   
/*     */   private static int hash(int nameHash, int valueHash) {
/* 506 */     return 31 * nameHash + valueHash;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class NameEntry
/*     */   {
/*     */     NameEntry next;
/*     */     
/*     */     final CharSequence name;
/*     */     
/*     */     final int hash;
/*     */     int counter;
/*     */     
/*     */     NameEntry(int hash, CharSequence name, int counter, NameEntry next) {
/* 520 */       this.hash = hash;
/* 521 */       this.name = name;
/* 522 */       this.counter = counter;
/* 523 */       this.next = next;
/*     */     }
/*     */     
/*     */     void unlink() {
/* 527 */       this.next = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class NameValueEntry
/*     */     extends HpackHeaderField
/*     */   {
/*     */     NameValueEntry after;
/*     */     
/*     */     NameValueEntry next;
/*     */     
/*     */     final int hash;
/*     */     
/*     */     final int counter;
/*     */     
/*     */     NameValueEntry(int hash, CharSequence name, CharSequence value, int counter, NameValueEntry next) {
/* 544 */       super(name, value);
/* 545 */       this.next = next;
/* 546 */       this.hash = hash;
/* 547 */       this.counter = counter;
/*     */     }
/*     */     
/*     */     void unlink() {
/* 551 */       this.after = null;
/* 552 */       this.next = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\HpackEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */