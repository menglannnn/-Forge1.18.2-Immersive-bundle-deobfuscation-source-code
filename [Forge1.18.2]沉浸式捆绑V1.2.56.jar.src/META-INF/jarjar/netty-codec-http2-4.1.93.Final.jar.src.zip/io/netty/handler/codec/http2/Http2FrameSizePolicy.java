package io.netty.handler.codec.http2;

public interface Http2FrameSizePolicy {
  void maxFrameSize(int paramInt) throws Http2Exception;
  
  int maxFrameSize();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2FrameSizePolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */