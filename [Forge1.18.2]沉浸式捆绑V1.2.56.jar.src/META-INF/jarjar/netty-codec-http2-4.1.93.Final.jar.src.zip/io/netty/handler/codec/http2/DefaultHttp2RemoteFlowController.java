/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2RemoteFlowController
/*     */   implements Http2RemoteFlowController
/*     */ {
/*  47 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DefaultHttp2RemoteFlowController.class);
/*     */   private static final int MIN_WRITABLE_CHUNK = 32768;
/*     */   private final Http2Connection connection;
/*     */   private final Http2Connection.PropertyKey stateKey;
/*     */   private final StreamByteDistributor streamByteDistributor;
/*     */   private final FlowState connectionState;
/*  53 */   private int initialWindowSize = 65535;
/*     */   private WritabilityMonitor monitor;
/*     */   private ChannelHandlerContext ctx;
/*     */   
/*     */   public DefaultHttp2RemoteFlowController(Http2Connection connection) {
/*  58 */     this(connection, (Http2RemoteFlowController.Listener)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultHttp2RemoteFlowController(Http2Connection connection, StreamByteDistributor streamByteDistributor) {
/*  63 */     this(connection, streamByteDistributor, null);
/*     */   }
/*     */   
/*     */   public DefaultHttp2RemoteFlowController(Http2Connection connection, Http2RemoteFlowController.Listener listener) {
/*  67 */     this(connection, new WeightedFairQueueByteDistributor(connection), listener);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2RemoteFlowController(Http2Connection connection, StreamByteDistributor streamByteDistributor, Http2RemoteFlowController.Listener listener) {
/*  73 */     this.connection = (Http2Connection)ObjectUtil.checkNotNull(connection, "connection");
/*  74 */     this.streamByteDistributor = (StreamByteDistributor)ObjectUtil.checkNotNull(streamByteDistributor, "streamWriteDistributor");
/*     */ 
/*     */     
/*  77 */     this.stateKey = connection.newKey();
/*  78 */     this.connectionState = new FlowState(connection.connectionStream());
/*  79 */     connection.connectionStream().setProperty(this.stateKey, this.connectionState);
/*     */ 
/*     */     
/*  82 */     listener(listener);
/*  83 */     this.monitor.windowSize(this.connectionState, this.initialWindowSize);
/*     */ 
/*     */     
/*  86 */     connection.addListener(new Http2ConnectionAdapter()
/*     */         {
/*     */           
/*     */           public void onStreamAdded(Http2Stream stream)
/*     */           {
/*  91 */             stream.setProperty(DefaultHttp2RemoteFlowController.this.stateKey, new DefaultHttp2RemoteFlowController.FlowState(stream));
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onStreamActive(Http2Stream stream) {
/*  98 */             DefaultHttp2RemoteFlowController.this.monitor.windowSize(DefaultHttp2RemoteFlowController.this.state(stream), DefaultHttp2RemoteFlowController.this.initialWindowSize);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onStreamClosed(Http2Stream stream) {
/* 105 */             DefaultHttp2RemoteFlowController.this.state(stream).cancel(Http2Error.STREAM_CLOSED, null);
/*     */           }
/*     */ 
/*     */           
/*     */           public void onStreamHalfClosed(Http2Stream stream) {
/* 110 */             if (Http2Stream.State.HALF_CLOSED_LOCAL == stream.state())
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 122 */               DefaultHttp2RemoteFlowController.this.state(stream).cancel(Http2Error.STREAM_CLOSED, null);
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void channelHandlerContext(ChannelHandlerContext ctx) throws Http2Exception {
/* 135 */     this.ctx = (ChannelHandlerContext)ObjectUtil.checkNotNull(ctx, "ctx");
/*     */ 
/*     */ 
/*     */     
/* 139 */     channelWritabilityChanged();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (isChannelWritable()) {
/* 146 */       writePendingBytes();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelHandlerContext channelHandlerContext() {
/* 152 */     return this.ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialWindowSize(int newWindowSize) throws Http2Exception {
/* 157 */     assert this.ctx == null || this.ctx.executor().inEventLoop();
/* 158 */     this.monitor.initialWindowSize(newWindowSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public int initialWindowSize() {
/* 163 */     return this.initialWindowSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int windowSize(Http2Stream stream) {
/* 168 */     return state(stream).windowSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(Http2Stream stream) {
/* 173 */     return this.monitor.isWritable(state(stream));
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelWritabilityChanged() throws Http2Exception {
/* 178 */     this.monitor.channelWritabilityChange();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDependencyTree(int childStreamId, int parentStreamId, short weight, boolean exclusive) {
/* 184 */     assert weight >= 1 && weight <= 256 : "Invalid weight";
/* 185 */     assert childStreamId != parentStreamId : "A stream cannot depend on itself";
/* 186 */     assert childStreamId > 0 && parentStreamId >= 0 : "childStreamId must be > 0. parentStreamId must be >= 0.";
/*     */     
/* 188 */     this.streamByteDistributor.updateDependencyTree(childStreamId, parentStreamId, weight, exclusive);
/*     */   }
/*     */   
/*     */   private boolean isChannelWritable() {
/* 192 */     return (this.ctx != null && isChannelWritable0());
/*     */   }
/*     */   
/*     */   private boolean isChannelWritable0() {
/* 196 */     return this.ctx.channel().isWritable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void listener(Http2RemoteFlowController.Listener listener) {
/* 201 */     this.monitor = (listener == null) ? new WritabilityMonitor() : new ListenerWritabilityMonitor(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void incrementWindowSize(Http2Stream stream, int delta) throws Http2Exception {
/* 206 */     assert this.ctx == null || this.ctx.executor().inEventLoop();
/* 207 */     this.monitor.incrementWindowSize(state(stream), delta);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFlowControlled(Http2Stream stream, Http2RemoteFlowController.FlowControlled frame) {
/* 213 */     assert this.ctx == null || this.ctx.executor().inEventLoop();
/* 214 */     ObjectUtil.checkNotNull(frame, "frame");
/*     */     try {
/* 216 */       this.monitor.enqueueFrame(state(stream), frame);
/* 217 */     } catch (Throwable t) {
/* 218 */       frame.error(this.ctx, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFlowControlled(Http2Stream stream) {
/* 224 */     return state(stream).hasFrame();
/*     */   }
/*     */   
/*     */   private FlowState state(Http2Stream stream) {
/* 228 */     return stream.<FlowState>getProperty(this.stateKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int connectionWindowSize() {
/* 235 */     return this.connectionState.windowSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int minUsableChannelBytes() {
/* 245 */     return Math.max(this.ctx.channel().config().getWriteBufferLowWaterMark(), 32768);
/*     */   }
/*     */ 
/*     */   
/*     */   private int maxUsableChannelBytes() {
/* 250 */     int channelWritableBytes = (int)Math.min(2147483647L, this.ctx.channel().bytesBeforeUnwritable());
/* 251 */     int usableBytes = (channelWritableBytes > 0) ? Math.max(channelWritableBytes, minUsableChannelBytes()) : 0;
/*     */ 
/*     */     
/* 254 */     return Math.min(this.connectionState.windowSize(), usableBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int writableBytes() {
/* 262 */     return Math.min(connectionWindowSize(), maxUsableChannelBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   public void writePendingBytes() throws Http2Exception {
/* 267 */     this.monitor.writePendingBytes();
/*     */   }
/*     */ 
/*     */   
/*     */   private final class FlowState
/*     */     implements StreamByteDistributor.StreamState
/*     */   {
/*     */     private final Http2Stream stream;
/*     */     
/*     */     private final Deque<Http2RemoteFlowController.FlowControlled> pendingWriteQueue;
/*     */     
/*     */     private int window;
/*     */     
/*     */     private long pendingBytes;
/*     */     
/*     */     private boolean markedWritable;
/*     */     
/*     */     private boolean writing;
/*     */     
/*     */     private boolean cancelled;
/*     */ 
/*     */     
/*     */     FlowState(Http2Stream stream) {
/* 290 */       this.stream = stream;
/* 291 */       this.pendingWriteQueue = new ArrayDeque<Http2RemoteFlowController.FlowControlled>(2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isWritable() {
/* 299 */       return (windowSize() > pendingBytes() && !this.cancelled);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Http2Stream stream() {
/* 307 */       return this.stream;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean markedWritability() {
/* 314 */       return this.markedWritable;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void markedWritability(boolean isWritable) {
/* 321 */       this.markedWritable = isWritable;
/*     */     }
/*     */ 
/*     */     
/*     */     public int windowSize() {
/* 326 */       return this.window;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void windowSize(int initialWindowSize) {
/* 333 */       this.window = initialWindowSize;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int writeAllocatedBytes(int allocated) {
/* 341 */       int writtenBytes, initialAllocated = allocated;
/*     */ 
/*     */       
/* 344 */       Throwable cause = null;
/*     */       
/*     */       try {
/* 347 */         assert !this.writing;
/* 348 */         this.writing = true;
/*     */ 
/*     */         
/* 351 */         boolean writeOccurred = false; Http2RemoteFlowController.FlowControlled frame;
/* 352 */         while (!this.cancelled && (frame = peek()) != null) {
/* 353 */           int maxBytes = Math.min(allocated, writableWindow());
/* 354 */           if (maxBytes <= 0 && frame.size() > 0) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 359 */           writeOccurred = true;
/* 360 */           int initialFrameSize = frame.size();
/*     */           try {
/* 362 */             frame.write(DefaultHttp2RemoteFlowController.this.ctx, Math.max(0, maxBytes));
/* 363 */             if (frame.size() == 0) {
/*     */ 
/*     */ 
/*     */               
/* 367 */               this.pendingWriteQueue.remove();
/* 368 */               frame.writeComplete();
/*     */             } 
/*     */           } finally {
/*     */             
/* 372 */             allocated -= initialFrameSize - frame.size();
/*     */           } 
/*     */         } 
/*     */         
/* 376 */         if (!writeOccurred)
/*     */         {
/* 378 */           return -1;
/*     */         }
/*     */       }
/* 381 */       catch (Throwable t) {
/*     */         
/* 383 */         this.cancelled = true;
/* 384 */         cause = t;
/*     */       } finally {
/* 386 */         this.writing = false;
/*     */ 
/*     */         
/* 389 */         writtenBytes = initialAllocated - allocated;
/*     */         
/* 391 */         decrementPendingBytes(writtenBytes, false);
/* 392 */         decrementFlowControlWindow(writtenBytes);
/*     */ 
/*     */ 
/*     */         
/* 396 */         if (this.cancelled) {
/* 397 */           cancel(Http2Error.INTERNAL_ERROR, cause);
/*     */         }
/*     */       } 
/* 400 */       return writtenBytes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int incrementStreamWindow(int delta) throws Http2Exception {
/* 407 */       if (delta > 0 && Integer.MAX_VALUE - delta < this.window)
/* 408 */         throw Http2Exception.streamError(this.stream.id(), Http2Error.FLOW_CONTROL_ERROR, "Window size overflow for stream: %d", new Object[] {
/* 409 */               Integer.valueOf(this.stream.id())
/*     */             }); 
/* 411 */       this.window += delta;
/*     */       
/* 413 */       DefaultHttp2RemoteFlowController.this.streamByteDistributor.updateStreamableBytes(this);
/* 414 */       return this.window;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int writableWindow() {
/* 421 */       return Math.min(this.window, DefaultHttp2RemoteFlowController.this.connectionWindowSize());
/*     */     }
/*     */ 
/*     */     
/*     */     public long pendingBytes() {
/* 426 */       return this.pendingBytes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void enqueueFrame(Http2RemoteFlowController.FlowControlled frame) {
/* 433 */       Http2RemoteFlowController.FlowControlled last = this.pendingWriteQueue.peekLast();
/* 434 */       if (last == null) {
/* 435 */         enqueueFrameWithoutMerge(frame);
/*     */         
/*     */         return;
/*     */       } 
/* 439 */       int lastSize = last.size();
/* 440 */       if (last.merge(DefaultHttp2RemoteFlowController.this.ctx, frame)) {
/* 441 */         incrementPendingBytes(last.size() - lastSize, true);
/*     */         return;
/*     */       } 
/* 444 */       enqueueFrameWithoutMerge(frame);
/*     */     }
/*     */     
/*     */     private void enqueueFrameWithoutMerge(Http2RemoteFlowController.FlowControlled frame) {
/* 448 */       this.pendingWriteQueue.offer(frame);
/*     */ 
/*     */       
/* 451 */       incrementPendingBytes(frame.size(), true);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasFrame() {
/* 456 */       return !this.pendingWriteQueue.isEmpty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Http2RemoteFlowController.FlowControlled peek() {
/* 463 */       return this.pendingWriteQueue.peek();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void cancel(Http2Error error, Throwable cause) {
/* 472 */       this.cancelled = true;
/*     */       
/* 474 */       if (this.writing) {
/*     */         return;
/*     */       }
/*     */       
/* 478 */       Http2RemoteFlowController.FlowControlled frame = this.pendingWriteQueue.poll();
/* 479 */       if (frame != null) {
/*     */         
/* 481 */         Http2Exception exception = Http2Exception.streamError(this.stream.id(), error, cause, "Stream closed before write could take place", new Object[0]);
/*     */         
/*     */         do {
/* 484 */           writeError(frame, exception);
/* 485 */           frame = this.pendingWriteQueue.poll();
/* 486 */         } while (frame != null);
/*     */       } 
/*     */       
/* 489 */       DefaultHttp2RemoteFlowController.this.streamByteDistributor.updateStreamableBytes(this);
/*     */       
/* 491 */       DefaultHttp2RemoteFlowController.this.monitor.stateCancelled(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void incrementPendingBytes(int numBytes, boolean updateStreamableBytes) {
/* 499 */       this.pendingBytes += numBytes;
/* 500 */       DefaultHttp2RemoteFlowController.this.monitor.incrementPendingBytes(numBytes);
/* 501 */       if (updateStreamableBytes) {
/* 502 */         DefaultHttp2RemoteFlowController.this.streamByteDistributor.updateStreamableBytes(this);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void decrementPendingBytes(int bytes, boolean updateStreamableBytes) {
/* 510 */       incrementPendingBytes(-bytes, updateStreamableBytes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void decrementFlowControlWindow(int bytes) {
/*     */       try {
/* 518 */         int negativeBytes = -bytes;
/* 519 */         DefaultHttp2RemoteFlowController.this.connectionState.incrementStreamWindow(negativeBytes);
/* 520 */         incrementStreamWindow(negativeBytes);
/* 521 */       } catch (Http2Exception e) {
/*     */         
/* 523 */         throw new IllegalStateException("Invalid window state when writing frame: " + e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void writeError(Http2RemoteFlowController.FlowControlled frame, Http2Exception cause) {
/* 532 */       assert DefaultHttp2RemoteFlowController.this.ctx != null;
/* 533 */       decrementPendingBytes(frame.size(), true);
/* 534 */       frame.error(DefaultHttp2RemoteFlowController.this.ctx, cause);
/*     */     }
/*     */   }
/*     */   
/*     */   private class WritabilityMonitor
/*     */     implements StreamByteDistributor.Writer
/*     */   {
/*     */     private boolean inWritePendingBytes;
/*     */     private long totalPendingBytes;
/*     */     
/*     */     private WritabilityMonitor() {}
/*     */     
/*     */     public final void write(Http2Stream stream, int numBytes) {
/* 547 */       DefaultHttp2RemoteFlowController.this.state(stream).writeAllocatedBytes(numBytes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void channelWritabilityChange() throws Http2Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void stateCancelled(DefaultHttp2RemoteFlowController.FlowState state) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void windowSize(DefaultHttp2RemoteFlowController.FlowState state, int initialWindowSize) {
/* 568 */       state.windowSize(initialWindowSize);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void incrementWindowSize(DefaultHttp2RemoteFlowController.FlowState state, int delta) throws Http2Exception {
/* 578 */       state.incrementStreamWindow(delta);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void enqueueFrame(DefaultHttp2RemoteFlowController.FlowState state, Http2RemoteFlowController.FlowControlled frame) throws Http2Exception {
/* 588 */       state.enqueueFrame(frame);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void incrementPendingBytes(int delta) {
/* 597 */       this.totalPendingBytes += delta;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final boolean isWritable(DefaultHttp2RemoteFlowController.FlowState state) {
/* 609 */       return (isWritableConnection() && state.isWritable());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void writePendingBytes() throws Http2Exception {
/* 618 */       if (this.inWritePendingBytes) {
/*     */         return;
/*     */       }
/* 621 */       this.inWritePendingBytes = true;
/*     */       try {
/* 623 */         int bytesToWrite = DefaultHttp2RemoteFlowController.this.writableBytes();
/*     */         
/*     */         do {
/*     */         
/* 627 */         } while (DefaultHttp2RemoteFlowController.this.streamByteDistributor.distribute(bytesToWrite, this) && (
/* 628 */           bytesToWrite = DefaultHttp2RemoteFlowController.this.writableBytes()) > 0 && DefaultHttp2RemoteFlowController.this
/* 629 */           .isChannelWritable0());
/*     */       
/*     */       }
/*     */       finally {
/*     */         
/* 634 */         this.inWritePendingBytes = false;
/*     */       } 
/*     */     }
/*     */     
/*     */     void initialWindowSize(int newWindowSize) throws Http2Exception {
/* 639 */       ObjectUtil.checkPositiveOrZero(newWindowSize, "newWindowSize");
/*     */       
/* 641 */       final int delta = newWindowSize - DefaultHttp2RemoteFlowController.this.initialWindowSize;
/* 642 */       DefaultHttp2RemoteFlowController.this.initialWindowSize = newWindowSize;
/* 643 */       DefaultHttp2RemoteFlowController.this.connection.forEachActiveStream(new Http2StreamVisitor()
/*     */           {
/*     */             public boolean visit(Http2Stream stream) throws Http2Exception {
/* 646 */               DefaultHttp2RemoteFlowController.this.state(stream).incrementStreamWindow(delta);
/* 647 */               return true;
/*     */             }
/*     */           });
/*     */       
/* 651 */       if (delta > 0 && DefaultHttp2RemoteFlowController.this.isChannelWritable())
/*     */       {
/* 653 */         writePendingBytes();
/*     */       }
/*     */     }
/*     */     
/*     */     final boolean isWritableConnection() {
/* 658 */       return (DefaultHttp2RemoteFlowController.this.connectionState.windowSize() - this.totalPendingBytes > 0L && DefaultHttp2RemoteFlowController.this.isChannelWritable());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ListenerWritabilityMonitor
/*     */     extends WritabilityMonitor
/*     */     implements Http2StreamVisitor
/*     */   {
/*     */     private final Http2RemoteFlowController.Listener listener;
/*     */ 
/*     */ 
/*     */     
/*     */     ListenerWritabilityMonitor(Http2RemoteFlowController.Listener listener) {
/* 674 */       this.listener = listener;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean visit(Http2Stream stream) throws Http2Exception {
/* 679 */       DefaultHttp2RemoteFlowController.FlowState state = DefaultHttp2RemoteFlowController.this.state(stream);
/* 680 */       if (isWritable(state) != state.markedWritability()) {
/* 681 */         notifyWritabilityChanged(state);
/*     */       }
/* 683 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     void windowSize(DefaultHttp2RemoteFlowController.FlowState state, int initialWindowSize) {
/* 688 */       super.windowSize(state, initialWindowSize);
/*     */       try {
/* 690 */         checkStateWritability(state);
/* 691 */       } catch (Http2Exception e) {
/* 692 */         throw new RuntimeException("Caught unexpected exception from window", e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void incrementWindowSize(DefaultHttp2RemoteFlowController.FlowState state, int delta) throws Http2Exception {
/* 698 */       super.incrementWindowSize(state, delta);
/* 699 */       checkStateWritability(state);
/*     */     }
/*     */ 
/*     */     
/*     */     void initialWindowSize(int newWindowSize) throws Http2Exception {
/* 704 */       super.initialWindowSize(newWindowSize);
/* 705 */       if (isWritableConnection())
/*     */       {
/*     */         
/* 708 */         checkAllWritabilityChanged();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     void enqueueFrame(DefaultHttp2RemoteFlowController.FlowState state, Http2RemoteFlowController.FlowControlled frame) throws Http2Exception {
/* 714 */       super.enqueueFrame(state, frame);
/* 715 */       checkConnectionThenStreamWritabilityChanged(state);
/*     */     }
/*     */ 
/*     */     
/*     */     void stateCancelled(DefaultHttp2RemoteFlowController.FlowState state) {
/*     */       try {
/* 721 */         checkConnectionThenStreamWritabilityChanged(state);
/* 722 */       } catch (Http2Exception e) {
/* 723 */         throw new RuntimeException("Caught unexpected exception from checkAllWritabilityChanged", e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void channelWritabilityChange() throws Http2Exception {
/* 729 */       if (DefaultHttp2RemoteFlowController.this.connectionState.markedWritability() != DefaultHttp2RemoteFlowController.this.isChannelWritable()) {
/* 730 */         checkAllWritabilityChanged();
/*     */       }
/*     */     }
/*     */     
/*     */     private void checkStateWritability(DefaultHttp2RemoteFlowController.FlowState state) throws Http2Exception {
/* 735 */       if (isWritable(state) != state.markedWritability()) {
/* 736 */         if (state == DefaultHttp2RemoteFlowController.this.connectionState) {
/* 737 */           checkAllWritabilityChanged();
/*     */         } else {
/* 739 */           notifyWritabilityChanged(state);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private void notifyWritabilityChanged(DefaultHttp2RemoteFlowController.FlowState state) {
/* 745 */       state.markedWritability(!state.markedWritability());
/*     */       try {
/* 747 */         this.listener.writabilityChanged(state.stream);
/* 748 */       } catch (Throwable cause) {
/* 749 */         DefaultHttp2RemoteFlowController.logger.error("Caught Throwable from listener.writabilityChanged", cause);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void checkConnectionThenStreamWritabilityChanged(DefaultHttp2RemoteFlowController.FlowState state) throws Http2Exception {
/* 755 */       if (isWritableConnection() != DefaultHttp2RemoteFlowController.this.connectionState.markedWritability()) {
/* 756 */         checkAllWritabilityChanged();
/* 757 */       } else if (isWritable(state) != state.markedWritability()) {
/* 758 */         notifyWritabilityChanged(state);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void checkAllWritabilityChanged() throws Http2Exception {
/* 764 */       DefaultHttp2RemoteFlowController.this.connectionState.markedWritability(isWritableConnection());
/* 765 */       DefaultHttp2RemoteFlowController.this.connection.forEachActiveStream(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2RemoteFlowController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */