/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ import io.netty.util.internal.StringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultHttp2PingFrame
/*    */   implements Http2PingFrame
/*    */ {
/*    */   private final long content;
/*    */   private final boolean ack;
/*    */   
/*    */   public DefaultHttp2PingFrame(long content) {
/* 32 */     this(content, false);
/*    */   }
/*    */   
/*    */   public DefaultHttp2PingFrame(long content, boolean ack) {
/* 36 */     this.content = content;
/* 37 */     this.ack = ack;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean ack() {
/* 42 */     return this.ack;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 47 */     return "PING";
/*    */   }
/*    */ 
/*    */   
/*    */   public long content() {
/* 52 */     return this.content;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 57 */     if (!(o instanceof Http2PingFrame)) {
/* 58 */       return false;
/*    */     }
/* 60 */     Http2PingFrame other = (Http2PingFrame)o;
/* 61 */     return (this.ack == other.ack() && this.content == other.content());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 66 */     int hash = super.hashCode();
/* 67 */     hash = hash * 31 + (this.ack ? 1 : 0);
/* 68 */     return hash;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 73 */     return StringUtil.simpleClassName(this) + "(content=" + this.content + ", ack=" + this.ack + ')';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2PingFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */