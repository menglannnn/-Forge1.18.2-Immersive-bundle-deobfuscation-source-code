/*      */ package io.netty.handler.codec.http2;
/*      */ 
/*      */ import io.netty.buffer.ByteBuf;
/*      */ import io.netty.buffer.ByteBufUtil;
/*      */ import io.netty.buffer.Unpooled;
/*      */ import io.netty.channel.ChannelFuture;
/*      */ import io.netty.channel.ChannelFutureListener;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.channel.ChannelOutboundHandler;
/*      */ import io.netty.channel.ChannelPromise;
/*      */ import io.netty.handler.codec.ByteToMessageDecoder;
/*      */ import io.netty.handler.codec.http.HttpResponseStatus;
/*      */ import io.netty.util.CharsetUtil;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.GenericFutureListener;
/*      */ import io.netty.util.concurrent.Promise;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.net.SocketAddress;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Http2ConnectionHandler
/*      */   extends ByteToMessageDecoder
/*      */   implements Http2LifecycleManager, ChannelOutboundHandler
/*      */ {
/*   69 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(Http2ConnectionHandler.class);
/*      */   
/*   71 */   private static final Http2Headers HEADERS_TOO_LARGE_HEADERS = ReadOnlyHttp2Headers.serverHeaders(false, HttpResponseStatus.REQUEST_HEADER_FIELDS_TOO_LARGE
/*   72 */       .codeAsText(), new io.netty.util.AsciiString[0]);
/*   73 */   private static final ByteBuf HTTP_1_X_BUF = Unpooled.unreleasableBuffer(
/*   74 */       Unpooled.wrappedBuffer(new byte[] { 72, 84, 84, 80, 47, 49, 46 })).asReadOnly();
/*      */   
/*      */   private final Http2ConnectionDecoder decoder;
/*      */   
/*      */   private final Http2ConnectionEncoder encoder;
/*      */   private final Http2Settings initialSettings;
/*      */   private final boolean decoupleCloseAndGoAway;
/*      */   private final boolean flushPreface;
/*      */   private ChannelFutureListener closeListener;
/*      */   private BaseDecoder byteDecoder;
/*      */   private long gracefulShutdownTimeoutMillis;
/*      */   
/*      */   protected Http2ConnectionHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
/*   87 */     this(decoder, encoder, initialSettings, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Http2ConnectionHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings, boolean decoupleCloseAndGoAway) {
/*   92 */     this(decoder, encoder, initialSettings, decoupleCloseAndGoAway, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Http2ConnectionHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings, boolean decoupleCloseAndGoAway, boolean flushPreface) {
/*   98 */     this.initialSettings = (Http2Settings)ObjectUtil.checkNotNull(initialSettings, "initialSettings");
/*   99 */     this.decoder = (Http2ConnectionDecoder)ObjectUtil.checkNotNull(decoder, "decoder");
/*  100 */     this.encoder = (Http2ConnectionEncoder)ObjectUtil.checkNotNull(encoder, "encoder");
/*  101 */     this.decoupleCloseAndGoAway = decoupleCloseAndGoAway;
/*  102 */     this.flushPreface = flushPreface;
/*  103 */     if (encoder.connection() != decoder.connection()) {
/*  104 */       throw new IllegalArgumentException("Encoder and Decoder do not share the same connection object");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long gracefulShutdownTimeoutMillis() {
/*  114 */     return this.gracefulShutdownTimeoutMillis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gracefulShutdownTimeoutMillis(long gracefulShutdownTimeoutMillis) {
/*  124 */     if (gracefulShutdownTimeoutMillis < -1L) {
/*  125 */       throw new IllegalArgumentException("gracefulShutdownTimeoutMillis: " + gracefulShutdownTimeoutMillis + " (expected: -1 for indefinite or >= 0)");
/*      */     }
/*      */     
/*  128 */     this.gracefulShutdownTimeoutMillis = gracefulShutdownTimeoutMillis;
/*      */   }
/*      */   
/*      */   public Http2Connection connection() {
/*  132 */     return this.encoder.connection();
/*      */   }
/*      */   
/*      */   public Http2ConnectionDecoder decoder() {
/*  136 */     return this.decoder;
/*      */   }
/*      */   
/*      */   public Http2ConnectionEncoder encoder() {
/*  140 */     return this.encoder;
/*      */   }
/*      */   
/*      */   private boolean prefaceSent() {
/*  144 */     return (this.byteDecoder != null && this.byteDecoder.prefaceSent());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void onHttpClientUpgrade() throws Http2Exception {
/*  152 */     if (connection().isServer()) {
/*  153 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Client-side HTTP upgrade requested for a server", new Object[0]);
/*      */     }
/*  155 */     if (!prefaceSent())
/*      */     {
/*      */       
/*  158 */       throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, "HTTP upgrade must occur after preface was sent", new Object[0]);
/*      */     }
/*  160 */     if (this.decoder.prefaceReceived()) {
/*  161 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "HTTP upgrade must occur before HTTP/2 preface is received", new Object[0]);
/*      */     }
/*      */ 
/*      */     
/*  165 */     connection().local().createStream(1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void onHttpServerUpgrade(Http2Settings settings) throws Http2Exception {
/*  173 */     if (!connection().isServer()) {
/*  174 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Server-side HTTP upgrade requested for a client", new Object[0]);
/*      */     }
/*  176 */     if (!prefaceSent())
/*      */     {
/*      */       
/*  179 */       throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, "HTTP upgrade must occur after preface was sent", new Object[0]);
/*      */     }
/*  181 */     if (this.decoder.prefaceReceived()) {
/*  182 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "HTTP upgrade must occur before HTTP/2 preface is received", new Object[0]);
/*      */     }
/*      */ 
/*      */     
/*  186 */     this.encoder.remoteSettings(settings);
/*      */ 
/*      */     
/*  189 */     connection().remote().createStream(1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush(ChannelHandlerContext ctx) {
/*      */     try {
/*  196 */       this.encoder.flowController().writePendingBytes();
/*  197 */       ctx.flush();
/*  198 */     } catch (Http2Exception e) {
/*  199 */       onError(ctx, true, e);
/*  200 */     } catch (Throwable cause) {
/*  201 */       onError(ctx, true, Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, cause, "Error flushing", new Object[0]));
/*      */     } 
/*      */   }
/*      */   
/*      */   private abstract class BaseDecoder { private BaseDecoder() {}
/*      */     
/*      */     public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {}
/*      */     
/*      */     public void channelActive(ChannelHandlerContext ctx) throws Exception {}
/*      */     
/*      */     public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/*  212 */       Http2ConnectionHandler.this.encoder().close();
/*  213 */       Http2ConnectionHandler.this.decoder().close();
/*      */ 
/*      */ 
/*      */       
/*  217 */       Http2ConnectionHandler.this.connection().close((Promise<Void>)ctx.voidPromise());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean prefaceSent() {
/*  224 */       return true;
/*      */     }
/*      */     
/*      */     public abstract void decode(ChannelHandlerContext param1ChannelHandlerContext, ByteBuf param1ByteBuf, List<Object> param1List) throws Exception; }
/*      */   
/*      */   private final class PrefaceDecoder extends BaseDecoder {
/*      */     private ByteBuf clientPrefaceString;
/*      */     
/*      */     PrefaceDecoder(ChannelHandlerContext ctx) throws Exception {
/*  233 */       this.clientPrefaceString = Http2ConnectionHandler.clientPrefaceString(Http2ConnectionHandler.this.encoder.connection());
/*      */ 
/*      */       
/*  236 */       sendPreface(ctx);
/*      */     }
/*      */     private boolean prefaceSent;
/*      */     
/*      */     public boolean prefaceSent() {
/*  241 */       return this.prefaceSent;
/*      */     }
/*      */ 
/*      */     
/*      */     public void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/*      */       try {
/*  247 */         if (ctx.channel().isActive() && readClientPrefaceString(in) && verifyFirstFrameIsSettings(in)) {
/*      */           
/*  249 */           Http2ConnectionHandler.this.byteDecoder = new Http2ConnectionHandler.FrameDecoder();
/*  250 */           Http2ConnectionHandler.this.byteDecoder.decode(ctx, in, out);
/*      */         } 
/*  252 */       } catch (Throwable e) {
/*  253 */         Http2ConnectionHandler.this.onError(ctx, false, e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void channelActive(ChannelHandlerContext ctx) throws Exception {
/*  260 */       sendPreface(ctx);
/*      */       
/*  262 */       if (Http2ConnectionHandler.this.flushPreface)
/*      */       {
/*      */ 
/*      */         
/*  266 */         ctx.flush();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/*  272 */       cleanup();
/*  273 */       super.channelInactive(ctx);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
/*  281 */       cleanup();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void cleanup() {
/*  288 */       if (this.clientPrefaceString != null) {
/*  289 */         this.clientPrefaceString.release();
/*  290 */         this.clientPrefaceString = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean readClientPrefaceString(ByteBuf in) throws Http2Exception {
/*  301 */       if (this.clientPrefaceString == null) {
/*  302 */         return true;
/*      */       }
/*      */       
/*  305 */       int prefaceRemaining = this.clientPrefaceString.readableBytes();
/*  306 */       int bytesRead = Math.min(in.readableBytes(), prefaceRemaining);
/*      */ 
/*      */       
/*  309 */       if (bytesRead == 0 || !ByteBufUtil.equals(in, in.readerIndex(), this.clientPrefaceString, this.clientPrefaceString
/*  310 */           .readerIndex(), bytesRead)) {
/*      */         
/*  312 */         int maxSearch = 1024;
/*      */         
/*  314 */         int http1Index = ByteBufUtil.indexOf(Http2ConnectionHandler.HTTP_1_X_BUF, in.slice(in.readerIndex(), Math.min(in.readableBytes(), maxSearch)));
/*  315 */         if (http1Index != -1) {
/*  316 */           String chunk = in.toString(in.readerIndex(), http1Index - in.readerIndex(), CharsetUtil.US_ASCII);
/*  317 */           throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Unexpected HTTP/1.x request: %s", new Object[] { chunk });
/*      */         } 
/*  319 */         String receivedBytes = ByteBufUtil.hexDump(in, in.readerIndex(), 
/*  320 */             Math.min(in.readableBytes(), this.clientPrefaceString.readableBytes()));
/*  321 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "HTTP/2 client preface string missing or corrupt. Hex dump for received bytes: %s", new Object[] { receivedBytes });
/*      */       } 
/*      */       
/*  324 */       in.skipBytes(bytesRead);
/*  325 */       this.clientPrefaceString.skipBytes(bytesRead);
/*      */       
/*  327 */       if (!this.clientPrefaceString.isReadable()) {
/*      */         
/*  329 */         this.clientPrefaceString.release();
/*  330 */         this.clientPrefaceString = null;
/*  331 */         return true;
/*      */       } 
/*  333 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean verifyFirstFrameIsSettings(ByteBuf in) throws Http2Exception {
/*  345 */       if (in.readableBytes() < 5)
/*      */       {
/*  347 */         return false;
/*      */       }
/*      */       
/*  350 */       short frameType = in.getUnsignedByte(in.readerIndex() + 3);
/*  351 */       short flags = in.getUnsignedByte(in.readerIndex() + 4);
/*  352 */       if (frameType != 4 || (flags & 0x1) != 0)
/*  353 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "First received frame was not SETTINGS. Hex dump for first 5 bytes: %s", new Object[] {
/*      */               
/*  355 */               ByteBufUtil.hexDump(in, in.readerIndex(), 5)
/*      */             }); 
/*  357 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void sendPreface(ChannelHandlerContext ctx) throws Exception {
/*  364 */       if (this.prefaceSent || !ctx.channel().isActive()) {
/*      */         return;
/*      */       }
/*      */       
/*  368 */       this.prefaceSent = true;
/*      */       
/*  370 */       boolean isClient = !Http2ConnectionHandler.this.connection().isServer();
/*  371 */       if (isClient)
/*      */       {
/*  373 */         ctx.write(Http2CodecUtil.connectionPrefaceBuf()).addListener((GenericFutureListener)ChannelFutureListener.CLOSE_ON_FAILURE);
/*      */       }
/*      */ 
/*      */       
/*  377 */       Http2ConnectionHandler.this.encoder.writeSettings(ctx, Http2ConnectionHandler.this.initialSettings, ctx.newPromise()).addListener((GenericFutureListener)ChannelFutureListener.CLOSE_ON_FAILURE);
/*      */ 
/*      */       
/*  380 */       if (isClient)
/*      */       {
/*      */ 
/*      */         
/*  384 */         Http2ConnectionHandler.this.userEventTriggered(ctx, Http2ConnectionPrefaceAndSettingsFrameWrittenEvent.INSTANCE); } 
/*      */     }
/*      */   }
/*      */   
/*      */   private final class FrameDecoder extends BaseDecoder {
/*      */     private FrameDecoder() {}
/*      */     
/*      */     public void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/*      */       try {
/*  393 */         Http2ConnectionHandler.this.decoder.decodeFrame(ctx, in, out);
/*  394 */       } catch (Throwable e) {
/*  395 */         Http2ConnectionHandler.this.onError(ctx, false, e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/*  403 */     this.encoder.lifecycleManager(this);
/*  404 */     this.decoder.lifecycleManager(this);
/*  405 */     this.encoder.flowController().channelHandlerContext(ctx);
/*  406 */     this.decoder.flowController().channelHandlerContext(ctx);
/*  407 */     this.byteDecoder = new PrefaceDecoder(ctx);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void handlerRemoved0(ChannelHandlerContext ctx) throws Exception {
/*  412 */     if (this.byteDecoder != null) {
/*  413 */       this.byteDecoder.handlerRemoved(ctx);
/*  414 */       this.byteDecoder = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void channelActive(ChannelHandlerContext ctx) throws Exception {
/*  420 */     if (this.byteDecoder == null) {
/*  421 */       this.byteDecoder = new PrefaceDecoder(ctx);
/*      */     }
/*  423 */     this.byteDecoder.channelActive(ctx);
/*  424 */     super.channelActive(ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
/*  430 */     super.channelInactive(ctx);
/*  431 */     if (this.byteDecoder != null) {
/*  432 */       this.byteDecoder.channelInactive(ctx);
/*  433 */       this.byteDecoder = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void channelWritabilityChanged(ChannelHandlerContext ctx) throws Exception {
/*      */     try {
/*  442 */       if (ctx.channel().isWritable()) {
/*  443 */         flush(ctx);
/*      */       }
/*  445 */       this.encoder.flowController().channelWritabilityChanged();
/*      */     } finally {
/*  447 */       super.channelWritabilityChanged(ctx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/*  453 */     this.byteDecoder.decode(ctx, in, out);
/*      */   }
/*      */ 
/*      */   
/*      */   public void bind(ChannelHandlerContext ctx, SocketAddress localAddress, ChannelPromise promise) throws Exception {
/*  458 */     ctx.bind(localAddress, promise);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void connect(ChannelHandlerContext ctx, SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) throws Exception {
/*  464 */     ctx.connect(remoteAddress, localAddress, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public void disconnect(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/*  469 */     ctx.disconnect(promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public void close(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/*  474 */     if (this.decoupleCloseAndGoAway) {
/*  475 */       ctx.close(promise);
/*      */       return;
/*      */     } 
/*  478 */     promise = promise.unvoid();
/*      */     
/*  480 */     if (!ctx.channel().isActive() || !prefaceSent()) {
/*  481 */       ctx.close(promise);
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  490 */     ChannelFuture f = connection().goAwaySent() ? ctx.write(Unpooled.EMPTY_BUFFER) : goAway(ctx, (Http2Exception)null, ctx.newPromise());
/*  491 */     ctx.flush();
/*  492 */     doGracefulShutdown(ctx, f, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   private ChannelFutureListener newClosingChannelFutureListener(ChannelHandlerContext ctx, ChannelPromise promise) {
/*  497 */     long gracefulShutdownTimeoutMillis = this.gracefulShutdownTimeoutMillis;
/*  498 */     return (gracefulShutdownTimeoutMillis < 0L) ? new ClosingChannelFutureListener(ctx, promise) : new ClosingChannelFutureListener(ctx, promise, gracefulShutdownTimeoutMillis, TimeUnit.MILLISECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void doGracefulShutdown(ChannelHandlerContext ctx, ChannelFuture future, ChannelPromise promise) {
/*  504 */     final ChannelFutureListener listener = newClosingChannelFutureListener(ctx, promise);
/*  505 */     if (isGracefulShutdownComplete()) {
/*      */ 
/*      */       
/*  508 */       future.addListener((GenericFutureListener)listener);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  514 */     else if (this.closeListener == null) {
/*  515 */       this.closeListener = listener;
/*  516 */     } else if (promise != null) {
/*  517 */       final ChannelFutureListener oldCloseListener = this.closeListener;
/*  518 */       this.closeListener = new ChannelFutureListener()
/*      */         {
/*      */           public void operationComplete(ChannelFuture future) throws Exception {
/*      */             try {
/*  522 */               oldCloseListener.operationComplete((Future)future);
/*      */             } finally {
/*  524 */               listener.operationComplete((Future)future);
/*      */             } 
/*      */           }
/*      */         };
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void deregister(ChannelHandlerContext ctx, ChannelPromise promise) throws Exception {
/*  534 */     ctx.deregister(promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public void read(ChannelHandlerContext ctx) throws Exception {
/*  539 */     ctx.read();
/*      */   }
/*      */ 
/*      */   
/*      */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/*  544 */     ctx.write(msg, promise);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
/*      */     try {
/*  553 */       channelReadComplete0(ctx);
/*      */     } finally {
/*  555 */       flush(ctx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final void channelReadComplete0(ChannelHandlerContext ctx) {
/*  561 */     discardSomeReadBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  566 */     if (!ctx.channel().config().isAutoRead()) {
/*  567 */       ctx.read();
/*      */     }
/*      */     
/*  570 */     ctx.fireChannelReadComplete();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/*  578 */     if (Http2CodecUtil.getEmbeddedHttp2Exception(cause) != null) {
/*      */       
/*  580 */       onError(ctx, false, cause);
/*      */     } else {
/*  582 */       super.exceptionCaught(ctx, cause);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeStreamLocal(Http2Stream stream, ChannelFuture future) {
/*  595 */     switch (stream.state()) {
/*      */       case HALF_CLOSED_LOCAL:
/*      */       case OPEN:
/*  598 */         stream.closeLocalSide();
/*      */         return;
/*      */     } 
/*  601 */     closeStream(stream, future);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeStreamRemote(Http2Stream stream, ChannelFuture future) {
/*  615 */     switch (stream.state()) {
/*      */       case OPEN:
/*      */       case HALF_CLOSED_REMOTE:
/*  618 */         stream.closeRemoteSide();
/*      */         return;
/*      */     } 
/*  621 */     closeStream(stream, future);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeStream(final Http2Stream stream, ChannelFuture future) {
/*  628 */     if (future.isDone()) {
/*  629 */       doCloseStream(stream, future);
/*      */     } else {
/*  631 */       future.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */           {
/*      */             public void operationComplete(ChannelFuture future) {
/*  634 */               Http2ConnectionHandler.this.doCloseStream(stream, future);
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void onError(ChannelHandlerContext ctx, boolean outbound, Throwable cause) {
/*  645 */     Http2Exception embedded = Http2CodecUtil.getEmbeddedHttp2Exception(cause);
/*  646 */     if (Http2Exception.isStreamError(embedded)) {
/*  647 */       onStreamError(ctx, outbound, cause, (Http2Exception.StreamException)embedded);
/*  648 */     } else if (embedded instanceof Http2Exception.CompositeStreamException) {
/*  649 */       Http2Exception.CompositeStreamException compositException = (Http2Exception.CompositeStreamException)embedded;
/*  650 */       for (Http2Exception.StreamException streamException : compositException) {
/*  651 */         onStreamError(ctx, outbound, cause, streamException);
/*      */       }
/*      */     } else {
/*  654 */       onConnectionError(ctx, outbound, cause, embedded);
/*      */     } 
/*  656 */     ctx.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isGracefulShutdownComplete() {
/*  665 */     return (connection().numActiveStreams() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void onConnectionError(ChannelHandlerContext ctx, boolean outbound, Throwable cause, Http2Exception http2Ex) {
/*  680 */     if (http2Ex == null) {
/*  681 */       http2Ex = new Http2Exception(Http2Error.INTERNAL_ERROR, cause.getMessage(), cause);
/*      */     }
/*      */     
/*  684 */     ChannelPromise promise = ctx.newPromise();
/*  685 */     ChannelFuture future = goAway(ctx, http2Ex, ctx.newPromise());
/*  686 */     if (http2Ex.shutdownHint() == Http2Exception.ShutdownHint.GRACEFUL_SHUTDOWN) {
/*  687 */       doGracefulShutdown(ctx, future, promise);
/*      */     } else {
/*  689 */       future.addListener((GenericFutureListener)newClosingChannelFutureListener(ctx, promise));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void onStreamError(ChannelHandlerContext ctx, boolean outbound, Throwable cause, Http2Exception.StreamException http2Ex) {
/*  704 */     int streamId = http2Ex.streamId();
/*  705 */     Http2Stream stream = connection().stream(streamId);
/*      */ 
/*      */     
/*  708 */     if (http2Ex instanceof Http2Exception.HeaderListSizeException && ((Http2Exception.HeaderListSizeException)http2Ex)
/*  709 */       .duringDecode() && 
/*  710 */       connection().isServer()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  718 */       if (stream == null) {
/*      */         try {
/*  720 */           stream = this.encoder.connection().remote().createStream(streamId, true);
/*  721 */         } catch (Http2Exception e) {
/*  722 */           resetUnknownStream(ctx, streamId, http2Ex.error().code(), ctx.newPromise());
/*      */           
/*      */           return;
/*      */         } 
/*      */       }
/*      */       
/*  728 */       if (stream != null && !stream.isHeadersSent()) {
/*      */         try {
/*  730 */           handleServerHeaderDecodeSizeError(ctx, stream);
/*  731 */         } catch (Throwable cause2) {
/*  732 */           onError(ctx, outbound, Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, cause2, "Error DecodeSizeError", new Object[0]));
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  737 */     if (stream == null) {
/*  738 */       if (!outbound || connection().local().mayHaveCreatedStream(streamId)) {
/*  739 */         resetUnknownStream(ctx, streamId, http2Ex.error().code(), ctx.newPromise());
/*      */       }
/*      */     } else {
/*  742 */       resetStream(ctx, stream, http2Ex.error().code(), ctx.newPromise());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleServerHeaderDecodeSizeError(ChannelHandlerContext ctx, Http2Stream stream) {
/*  754 */     encoder().writeHeaders(ctx, stream.id(), HEADERS_TOO_LARGE_HEADERS, 0, true, ctx.newPromise());
/*      */   }
/*      */   
/*      */   protected Http2FrameWriter frameWriter() {
/*  758 */     return encoder().frameWriter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ChannelFuture resetUnknownStream(final ChannelHandlerContext ctx, int streamId, long errorCode, ChannelPromise promise) {
/*  768 */     ChannelFuture future = frameWriter().writeRstStream(ctx, streamId, errorCode, promise);
/*  769 */     if (future.isDone()) {
/*  770 */       closeConnectionOnError(ctx, future);
/*      */     } else {
/*  772 */       future.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */           {
/*      */             public void operationComplete(ChannelFuture future) throws Exception {
/*  775 */               Http2ConnectionHandler.this.closeConnectionOnError(ctx, future);
/*      */             }
/*      */           });
/*      */     } 
/*  779 */     return future;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ChannelFuture resetStream(ChannelHandlerContext ctx, int streamId, long errorCode, ChannelPromise promise) {
/*  785 */     Http2Stream stream = connection().stream(streamId);
/*  786 */     if (stream == null) {
/*  787 */       return resetUnknownStream(ctx, streamId, errorCode, promise.unvoid());
/*      */     }
/*      */     
/*  790 */     return resetStream(ctx, stream, errorCode, promise);
/*      */   }
/*      */   
/*      */   private ChannelFuture resetStream(final ChannelHandlerContext ctx, final Http2Stream stream, long errorCode, ChannelPromise promise) {
/*      */     ChannelFuture future;
/*  795 */     promise = promise.unvoid();
/*  796 */     if (stream.isResetSent())
/*      */     {
/*  798 */       return (ChannelFuture)promise.setSuccess();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  805 */     stream.resetSent();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  810 */     if (stream.state() == Http2Stream.State.IDLE || (
/*  811 */       connection().local().created(stream) && !stream.isHeadersSent() && !stream.isPushPromiseSent())) {
/*  812 */       ChannelPromise channelPromise = promise.setSuccess();
/*      */     } else {
/*  814 */       future = frameWriter().writeRstStream(ctx, stream.id(), errorCode, promise);
/*      */     } 
/*  816 */     if (future.isDone()) {
/*  817 */       processRstStreamWriteResult(ctx, stream, future);
/*      */     } else {
/*  819 */       future.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */           {
/*      */             public void operationComplete(ChannelFuture future) throws Exception {
/*  822 */               Http2ConnectionHandler.this.processRstStreamWriteResult(ctx, stream, future);
/*      */             }
/*      */           });
/*      */     } 
/*      */     
/*  827 */     return future;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ChannelFuture goAway(final ChannelHandlerContext ctx, final int lastStreamId, final long errorCode, final ByteBuf debugData, ChannelPromise promise) {
/*  833 */     promise = promise.unvoid();
/*  834 */     Http2Connection connection = connection();
/*      */     try {
/*  836 */       if (!connection.goAwaySent(lastStreamId, errorCode, debugData)) {
/*  837 */         debugData.release();
/*  838 */         promise.trySuccess();
/*  839 */         return (ChannelFuture)promise;
/*      */       } 
/*  841 */     } catch (Throwable cause) {
/*  842 */       debugData.release();
/*  843 */       promise.tryFailure(cause);
/*  844 */       return (ChannelFuture)promise;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  849 */     debugData.retain();
/*  850 */     ChannelFuture future = frameWriter().writeGoAway(ctx, lastStreamId, errorCode, debugData, promise);
/*      */     
/*  852 */     if (future.isDone()) {
/*  853 */       processGoAwayWriteResult(ctx, lastStreamId, errorCode, debugData, future);
/*      */     } else {
/*  855 */       future.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */           {
/*      */             public void operationComplete(ChannelFuture future) throws Exception {
/*  858 */               Http2ConnectionHandler.processGoAwayWriteResult(ctx, lastStreamId, errorCode, debugData, future);
/*      */             }
/*      */           });
/*      */     } 
/*      */     
/*  863 */     return future;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkCloseConnection(ChannelFuture future) {
/*  873 */     if (this.closeListener != null && isGracefulShutdownComplete()) {
/*  874 */       ChannelFutureListener closeListener = this.closeListener;
/*      */ 
/*      */       
/*  877 */       this.closeListener = null;
/*      */       try {
/*  879 */         closeListener.operationComplete((Future)future);
/*  880 */       } catch (Exception e) {
/*  881 */         throw new IllegalStateException("Close listener threw an unexpected exception", e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ChannelFuture goAway(ChannelHandlerContext ctx, Http2Exception cause, ChannelPromise promise) {
/*      */     int lastKnownStream;
/*  891 */     long errorCode = (cause != null) ? cause.error().code() : Http2Error.NO_ERROR.code();
/*      */     
/*  893 */     if (cause != null && cause.shutdownHint() == Http2Exception.ShutdownHint.HARD_SHUTDOWN) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  898 */       lastKnownStream = Integer.MAX_VALUE;
/*      */     } else {
/*  900 */       lastKnownStream = connection().remote().lastStreamCreated();
/*      */     } 
/*  902 */     return goAway(ctx, lastKnownStream, errorCode, Http2CodecUtil.toByteBuf(ctx, cause), promise);
/*      */   }
/*      */   
/*      */   private void processRstStreamWriteResult(ChannelHandlerContext ctx, Http2Stream stream, ChannelFuture future) {
/*  906 */     if (future.isSuccess()) {
/*  907 */       closeStream(stream, future);
/*      */     } else {
/*      */       
/*  910 */       onConnectionError(ctx, true, future.cause(), (Http2Exception)null);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void closeConnectionOnError(ChannelHandlerContext ctx, ChannelFuture future) {
/*  915 */     if (!future.isSuccess()) {
/*  916 */       onConnectionError(ctx, true, future.cause(), (Http2Exception)null);
/*      */     }
/*      */   }
/*      */   
/*      */   private void doCloseStream(Http2Stream stream, ChannelFuture future) {
/*  921 */     stream.close();
/*  922 */     checkCloseConnection(future);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ByteBuf clientPrefaceString(Http2Connection connection) {
/*  929 */     return connection.isServer() ? Http2CodecUtil.connectionPrefaceBuf() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void processGoAwayWriteResult(ChannelHandlerContext ctx, int lastStreamId, long errorCode, ByteBuf debugData, ChannelFuture future) {
/*      */     try {
/*  935 */       if (future.isSuccess()) {
/*  936 */         if (errorCode != Http2Error.NO_ERROR.code()) {
/*  937 */           if (logger.isDebugEnabled()) {
/*  938 */             logger.debug("{} Sent GOAWAY: lastStreamId '{}', errorCode '{}', debugData '{}'. Forcing shutdown of the connection.", new Object[] { ctx
/*      */                   
/*  940 */                   .channel(), Integer.valueOf(lastStreamId), Long.valueOf(errorCode), debugData.toString(CharsetUtil.UTF_8), future.cause() });
/*      */           }
/*  942 */           ctx.close();
/*      */         } 
/*      */       } else {
/*  945 */         if (logger.isDebugEnabled()) {
/*  946 */           logger.debug("{} Sending GOAWAY failed: lastStreamId '{}', errorCode '{}', debugData '{}'. Forcing shutdown of the connection.", new Object[] { ctx
/*      */                 
/*  948 */                 .channel(), Integer.valueOf(lastStreamId), Long.valueOf(errorCode), debugData.toString(CharsetUtil.UTF_8), future.cause() });
/*      */         }
/*  950 */         ctx.close();
/*      */       } 
/*      */     } finally {
/*      */       
/*  954 */       debugData.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class ClosingChannelFutureListener
/*      */     implements ChannelFutureListener
/*      */   {
/*      */     private final ChannelHandlerContext ctx;
/*      */     private final ChannelPromise promise;
/*      */     private final Future<?> timeoutTask;
/*      */     private boolean closed;
/*      */     
/*      */     ClosingChannelFutureListener(ChannelHandlerContext ctx, ChannelPromise promise) {
/*  968 */       this.ctx = ctx;
/*  969 */       this.promise = promise;
/*  970 */       this.timeoutTask = null;
/*      */     }
/*      */ 
/*      */     
/*      */     ClosingChannelFutureListener(ChannelHandlerContext ctx, ChannelPromise promise, long timeout, TimeUnit unit) {
/*  975 */       this.ctx = ctx;
/*  976 */       this.promise = promise;
/*  977 */       this.timeoutTask = (Future<?>)ctx.executor().schedule(new Runnable()
/*      */           {
/*      */             public void run() {
/*  980 */               Http2ConnectionHandler.ClosingChannelFutureListener.this.doClose();
/*      */             }
/*      */           },  timeout, unit);
/*      */     }
/*      */ 
/*      */     
/*      */     public void operationComplete(ChannelFuture sentGoAwayFuture) {
/*  987 */       if (this.timeoutTask != null) {
/*  988 */         this.timeoutTask.cancel(false);
/*      */       }
/*  990 */       doClose();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void doClose() {
/*  996 */       if (this.closed) {
/*      */         
/*  998 */         assert this.timeoutTask != null;
/*      */         return;
/*      */       } 
/* 1001 */       this.closed = true;
/* 1002 */       if (this.promise == null) {
/* 1003 */         this.ctx.close();
/*      */       } else {
/* 1005 */         this.ctx.close(this.promise);
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2ConnectionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */