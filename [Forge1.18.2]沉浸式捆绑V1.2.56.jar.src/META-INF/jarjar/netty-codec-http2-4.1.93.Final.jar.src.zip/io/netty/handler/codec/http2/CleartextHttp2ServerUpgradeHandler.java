/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.ByteToMessageDecoder;
/*     */ import io.netty.handler.codec.http.HttpServerCodec;
/*     */ import io.netty.handler.codec.http.HttpServerUpgradeHandler;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CleartextHttp2ServerUpgradeHandler
/*     */   extends ByteToMessageDecoder
/*     */ {
/*  42 */   private static final ByteBuf CONNECTION_PREFACE = Unpooled.unreleasableBuffer(Http2CodecUtil.connectionPrefaceBuf()).asReadOnly();
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpServerCodec httpServerCodec;
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpServerUpgradeHandler httpServerUpgradeHandler;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ChannelHandler http2ServerHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CleartextHttp2ServerUpgradeHandler(HttpServerCodec httpServerCodec, HttpServerUpgradeHandler httpServerUpgradeHandler, ChannelHandler http2ServerHandler) {
/*  60 */     this.httpServerCodec = (HttpServerCodec)ObjectUtil.checkNotNull(httpServerCodec, "httpServerCodec");
/*  61 */     this.httpServerUpgradeHandler = (HttpServerUpgradeHandler)ObjectUtil.checkNotNull(httpServerUpgradeHandler, "httpServerUpgradeHandler");
/*  62 */     this.http2ServerHandler = (ChannelHandler)ObjectUtil.checkNotNull(http2ServerHandler, "http2ServerHandler");
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/*  67 */     ctx.pipeline()
/*  68 */       .addAfter(ctx.name(), null, (ChannelHandler)this.httpServerUpgradeHandler)
/*  69 */       .addAfter(ctx.name(), null, (ChannelHandler)this.httpServerCodec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
/*  78 */     int prefaceLength = CONNECTION_PREFACE.readableBytes();
/*  79 */     int bytesRead = Math.min(in.readableBytes(), prefaceLength);
/*     */     
/*  81 */     if (!ByteBufUtil.equals(CONNECTION_PREFACE, CONNECTION_PREFACE.readerIndex(), in, in
/*  82 */         .readerIndex(), bytesRead)) {
/*  83 */       ctx.pipeline().remove((ChannelHandler)this);
/*  84 */     } else if (bytesRead == prefaceLength) {
/*     */ 
/*     */       
/*  87 */       ctx.pipeline()
/*  88 */         .remove((ChannelHandler)this.httpServerCodec)
/*  89 */         .remove((ChannelHandler)this.httpServerUpgradeHandler);
/*     */       
/*  91 */       ctx.pipeline().addAfter(ctx.name(), null, this.http2ServerHandler);
/*  92 */       ctx.pipeline().remove((ChannelHandler)this);
/*     */       
/*  94 */       ctx.fireUserEventTriggered(PriorKnowledgeUpgradeEvent.INSTANCE);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class PriorKnowledgeUpgradeEvent
/*     */   {
/* 102 */     private static final PriorKnowledgeUpgradeEvent INSTANCE = new PriorKnowledgeUpgradeEvent();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\CleartextHttp2ServerUpgradeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */