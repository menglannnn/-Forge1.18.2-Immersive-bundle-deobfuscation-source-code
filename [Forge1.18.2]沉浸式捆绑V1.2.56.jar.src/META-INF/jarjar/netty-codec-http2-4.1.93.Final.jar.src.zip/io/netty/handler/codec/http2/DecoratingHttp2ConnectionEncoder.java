/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecoratingHttp2ConnectionEncoder
/*    */   extends DecoratingHttp2FrameWriter
/*    */   implements Http2ConnectionEncoder, Http2SettingsReceivedConsumer
/*    */ {
/*    */   private final Http2ConnectionEncoder delegate;
/*    */   
/*    */   public DecoratingHttp2ConnectionEncoder(Http2ConnectionEncoder delegate) {
/* 30 */     super(delegate);
/* 31 */     this.delegate = (Http2ConnectionEncoder)ObjectUtil.checkNotNull(delegate, "delegate");
/*    */   }
/*    */ 
/*    */   
/*    */   public void lifecycleManager(Http2LifecycleManager lifecycleManager) {
/* 36 */     this.delegate.lifecycleManager(lifecycleManager);
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2Connection connection() {
/* 41 */     return this.delegate.connection();
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2RemoteFlowController flowController() {
/* 46 */     return this.delegate.flowController();
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2FrameWriter frameWriter() {
/* 51 */     return this.delegate.frameWriter();
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2Settings pollSentSettings() {
/* 56 */     return this.delegate.pollSentSettings();
/*    */   }
/*    */ 
/*    */   
/*    */   public void remoteSettings(Http2Settings settings) throws Http2Exception {
/* 61 */     this.delegate.remoteSettings(settings);
/*    */   }
/*    */ 
/*    */   
/*    */   public void consumeReceivedSettings(Http2Settings settings) {
/* 66 */     if (this.delegate instanceof Http2SettingsReceivedConsumer) {
/* 67 */       ((Http2SettingsReceivedConsumer)this.delegate).consumeReceivedSettings(settings);
/*    */     } else {
/* 69 */       throw new IllegalStateException("delegate " + this.delegate + " is not an instance of " + Http2SettingsReceivedConsumer.class);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DecoratingHttp2ConnectionEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */