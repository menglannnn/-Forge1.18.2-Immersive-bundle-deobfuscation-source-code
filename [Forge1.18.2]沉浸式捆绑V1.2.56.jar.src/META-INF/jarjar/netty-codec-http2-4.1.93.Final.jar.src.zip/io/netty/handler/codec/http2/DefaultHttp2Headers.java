/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.handler.codec.CharSequenceValueConverter;
/*     */ import io.netty.handler.codec.DefaultHeaders;
/*     */ import io.netty.handler.codec.Headers;
/*     */ import io.netty.handler.codec.ValueConverter;
/*     */ import io.netty.handler.codec.http.HttpHeaderValidationUtil;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.ByteProcessor;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2Headers
/*     */   extends DefaultHeaders<CharSequence, CharSequence, Http2Headers>
/*     */   implements Http2Headers
/*     */ {
/*  36 */   private static final ByteProcessor HTTP2_NAME_VALIDATOR_PROCESSOR = new ByteProcessor()
/*     */     {
/*     */       public boolean process(byte value) {
/*  39 */         return !AsciiString.isUpperCase(value);
/*     */       }
/*     */     };
/*  42 */   static final DefaultHeaders.NameValidator<CharSequence> HTTP2_NAME_VALIDATOR = new DefaultHeaders.NameValidator<CharSequence>()
/*     */     {
/*     */       public void validateName(CharSequence name) {
/*  45 */         if (name == null || name.length() == 0) {
/*  46 */           PlatformDependent.throwException(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "empty headers are not allowed [%s]", new Object[] { name }));
/*     */         }
/*     */ 
/*     */         
/*  50 */         if (name instanceof AsciiString) {
/*     */           int index;
/*     */           try {
/*  53 */             index = ((AsciiString)name).forEachByte(DefaultHttp2Headers.HTTP2_NAME_VALIDATOR_PROCESSOR);
/*  54 */           } catch (Http2Exception e) {
/*  55 */             PlatformDependent.throwException(e);
/*     */             return;
/*  57 */           } catch (Throwable t) {
/*  58 */             PlatformDependent.throwException(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, t, "unexpected error. invalid header name [%s]", new Object[] { name }));
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*  63 */           if (index != -1) {
/*  64 */             PlatformDependent.throwException(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "invalid header name [%s]", new Object[] { name }));
/*     */           }
/*     */         } else {
/*     */           
/*  68 */           for (int i = 0; i < name.length(); i++) {
/*  69 */             if (AsciiString.isUpperCase(name.charAt(i))) {
/*  70 */               PlatformDependent.throwException(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "invalid header name [%s]", new Object[] { name }));
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/*  76 */         if (Http2Headers.PseudoHeaderName.hasPseudoHeaderFormat(name)) {
/*  77 */           Http2Headers.PseudoHeaderName pseudoHeader = Http2Headers.PseudoHeaderName.getPseudoHeader(name);
/*  78 */           if (pseudoHeader == null) {
/*  79 */             PlatformDependent.throwException(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Invalid HTTP/2 pseudo-header '%s' encountered.", new Object[] { name }));
/*     */           }
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*  86 */   private static final DefaultHeaders.ValueValidator<CharSequence> VALUE_VALIDATOR = new DefaultHeaders.ValueValidator<CharSequence>()
/*     */     {
/*     */       public void validate(CharSequence value) {
/*  89 */         int index = HttpHeaderValidationUtil.validateValidHeaderValue(value);
/*  90 */         if (index != -1) {
/*  91 */           throw new IllegalArgumentException("a header value contains prohibited character 0x" + 
/*  92 */               Integer.toHexString(value.charAt(index)) + " at index " + index + '.');
/*     */         }
/*     */       }
/*     */     };
/*     */   
/*  97 */   private DefaultHeaders.HeaderEntry<CharSequence, CharSequence> firstNonPseudo = this.head;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2Headers() {
/* 106 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2Headers(boolean validate) {
/* 118 */     super(AsciiString.CASE_SENSITIVE_HASHER, (ValueConverter)CharSequenceValueConverter.INSTANCE, validate ? HTTP2_NAME_VALIDATOR : DefaultHeaders.NameValidator.NOT_NULL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2Headers(boolean validate, int arraySizeHint) {
/* 135 */     super(AsciiString.CASE_SENSITIVE_HASHER, (ValueConverter)CharSequenceValueConverter.INSTANCE, validate ? HTTP2_NAME_VALIDATOR : DefaultHeaders.NameValidator.NOT_NULL, arraySizeHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2Headers(boolean validate, boolean validateValues, int arraySizeHint) {
/* 156 */     super(AsciiString.CASE_SENSITIVE_HASHER, (ValueConverter)CharSequenceValueConverter.INSTANCE, validate ? HTTP2_NAME_VALIDATOR : DefaultHeaders.NameValidator.NOT_NULL, arraySizeHint, validateValues ? VALUE_VALIDATOR : DefaultHeaders.ValueValidator.NO_VALIDATION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateName(DefaultHeaders.NameValidator<CharSequence> validator, boolean forAdd, CharSequence name) {
/* 165 */     super.validateName(validator, forAdd, name);
/* 166 */     if (nameValidator() == HTTP2_NAME_VALIDATOR && forAdd && Http2Headers.PseudoHeaderName.hasPseudoHeaderFormat(name) && 
/* 167 */       contains(name)) {
/* 168 */       PlatformDependent.throwException(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Duplicate HTTP/2 pseudo-header '%s' encountered.", new Object[] { name }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateValue(DefaultHeaders.ValueValidator<CharSequence> validator, CharSequence name, CharSequence value) {
/* 177 */     super.validateValue(validator, name, value);
/*     */ 
/*     */     
/* 180 */     if (nameValidator() == HTTP2_NAME_VALIDATOR && (value == null || value.length() == 0) && 
/* 181 */       Http2Headers.PseudoHeaderName.hasPseudoHeaderFormat(name)) {
/* 182 */       PlatformDependent.throwException(Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "HTTP/2 pseudo-header '%s' must not be empty.", new Object[] { name }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Headers clear() {
/* 189 */     this.firstNonPseudo = this.head;
/* 190 */     return (Http2Headers)super.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 195 */     return (o instanceof Http2Headers && equals((Http2Headers)o, AsciiString.CASE_SENSITIVE_HASHER));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 200 */     return hashCode(AsciiString.CASE_SENSITIVE_HASHER);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers method(CharSequence value) {
/* 205 */     set(Http2Headers.PseudoHeaderName.METHOD.value(), value);
/* 206 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers scheme(CharSequence value) {
/* 211 */     set(Http2Headers.PseudoHeaderName.SCHEME.value(), value);
/* 212 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers authority(CharSequence value) {
/* 217 */     set(Http2Headers.PseudoHeaderName.AUTHORITY.value(), value);
/* 218 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers path(CharSequence value) {
/* 223 */     set(Http2Headers.PseudoHeaderName.PATH.value(), value);
/* 224 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers status(CharSequence value) {
/* 229 */     set(Http2Headers.PseudoHeaderName.STATUS.value(), value);
/* 230 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence method() {
/* 235 */     return (CharSequence)get(Http2Headers.PseudoHeaderName.METHOD.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence scheme() {
/* 240 */     return (CharSequence)get(Http2Headers.PseudoHeaderName.SCHEME.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence authority() {
/* 245 */     return (CharSequence)get(Http2Headers.PseudoHeaderName.AUTHORITY.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence path() {
/* 250 */     return (CharSequence)get(Http2Headers.PseudoHeaderName.PATH.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence status() {
/* 255 */     return (CharSequence)get(Http2Headers.PseudoHeaderName.STATUS.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(CharSequence name, CharSequence value) {
/* 260 */     return contains(name, value, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(CharSequence name, CharSequence value, boolean caseInsensitive) {
/* 265 */     return contains(name, value, caseInsensitive ? AsciiString.CASE_INSENSITIVE_HASHER : AsciiString.CASE_SENSITIVE_HASHER);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final DefaultHeaders.HeaderEntry<CharSequence, CharSequence> newHeaderEntry(int h, CharSequence name, CharSequence value, DefaultHeaders.HeaderEntry<CharSequence, CharSequence> next) {
/* 271 */     return new Http2HeaderEntry(h, name, value, next);
/*     */   }
/*     */   
/*     */   private final class Http2HeaderEntry
/*     */     extends DefaultHeaders.HeaderEntry<CharSequence, CharSequence> {
/*     */     Http2HeaderEntry(int hash, CharSequence key, CharSequence value, DefaultHeaders.HeaderEntry<CharSequence, CharSequence> next) {
/* 277 */       super(hash, key);
/* 278 */       this.value = value;
/* 279 */       this.next = next;
/*     */ 
/*     */       
/* 282 */       if (Http2Headers.PseudoHeaderName.hasPseudoHeaderFormat(key)) {
/* 283 */         this.after = DefaultHttp2Headers.this.firstNonPseudo;
/* 284 */         this.before = DefaultHttp2Headers.this.firstNonPseudo.before();
/*     */       } else {
/* 286 */         this.after = DefaultHttp2Headers.this.head;
/* 287 */         this.before = DefaultHttp2Headers.this.head.before();
/* 288 */         if (DefaultHttp2Headers.this.firstNonPseudo == DefaultHttp2Headers.this.head) {
/* 289 */           DefaultHttp2Headers.this.firstNonPseudo = this;
/*     */         }
/*     */       } 
/* 292 */       pointNeighborsToThis();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void remove() {
/* 297 */       if (this == DefaultHttp2Headers.this.firstNonPseudo) {
/* 298 */         DefaultHttp2Headers.this.firstNonPseudo = DefaultHttp2Headers.this.firstNonPseudo.after();
/*     */       }
/* 300 */       super.remove();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2Headers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */