/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.embedded.EmbeddedChannel;
/*     */ import io.netty.handler.codec.compression.Brotli;
/*     */ import io.netty.handler.codec.compression.BrotliEncoder;
/*     */ import io.netty.handler.codec.compression.BrotliOptions;
/*     */ import io.netty.handler.codec.compression.CompressionOptions;
/*     */ import io.netty.handler.codec.compression.DeflateOptions;
/*     */ import io.netty.handler.codec.compression.GzipOptions;
/*     */ import io.netty.handler.codec.compression.StandardCompressionOptions;
/*     */ import io.netty.handler.codec.compression.ZlibCodecFactory;
/*     */ import io.netty.handler.codec.compression.ZlibWrapper;
/*     */ import io.netty.handler.codec.compression.ZstdEncoder;
/*     */ import io.netty.handler.codec.compression.ZstdOptions;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaderValues;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.concurrent.PromiseCombiner;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompressorHttp2ConnectionEncoder
/*     */   extends DecoratingHttp2ConnectionEncoder
/*     */ {
/*     */   public static final int DEFAULT_COMPRESSION_LEVEL = 6;
/*     */   public static final int DEFAULT_WINDOW_BITS = 15;
/*     */   public static final int DEFAULT_MEM_LEVEL = 8;
/*     */   private int compressionLevel;
/*     */   private int windowBits;
/*     */   private int memLevel;
/*     */   private final Http2Connection.PropertyKey propertyKey;
/*     */   private final boolean supportsCompressionOptions;
/*     */   private BrotliOptions brotliOptions;
/*     */   private GzipOptions gzipCompressionOptions;
/*     */   private DeflateOptions deflateOptions;
/*     */   private ZstdOptions zstdOptions;
/*     */   
/*     */   public CompressorHttp2ConnectionEncoder(Http2ConnectionEncoder delegate) {
/*  77 */     this(delegate, defaultCompressionOptions());
/*     */   }
/*     */   
/*     */   private static CompressionOptions[] defaultCompressionOptions() {
/*  81 */     if (Brotli.isAvailable())
/*  82 */       return new CompressionOptions[] {
/*  83 */           (CompressionOptions)StandardCompressionOptions.brotli(), 
/*  84 */           (CompressionOptions)StandardCompressionOptions.gzip(), 
/*  85 */           (CompressionOptions)StandardCompressionOptions.deflate()
/*     */         }; 
/*  87 */     return new CompressionOptions[] { (CompressionOptions)StandardCompressionOptions.gzip(), (CompressionOptions)StandardCompressionOptions.deflate() };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public CompressorHttp2ConnectionEncoder(Http2ConnectionEncoder delegate, int compressionLevel, int windowBits, int memLevel) {
/*  96 */     super(delegate);
/*  97 */     this.compressionLevel = ObjectUtil.checkInRange(compressionLevel, 0, 9, "compressionLevel");
/*  98 */     this.windowBits = ObjectUtil.checkInRange(windowBits, 9, 15, "windowBits");
/*  99 */     this.memLevel = ObjectUtil.checkInRange(memLevel, 1, 9, "memLevel");
/*     */     
/* 101 */     this.propertyKey = connection().newKey();
/* 102 */     connection().addListener(new Http2ConnectionAdapter()
/*     */         {
/*     */           public void onStreamRemoved(Http2Stream stream) {
/* 105 */             EmbeddedChannel compressor = stream.<EmbeddedChannel>getProperty(CompressorHttp2ConnectionEncoder.this.propertyKey);
/* 106 */             if (compressor != null) {
/* 107 */               CompressorHttp2ConnectionEncoder.this.cleanup(stream, compressor);
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 112 */     this.supportsCompressionOptions = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompressorHttp2ConnectionEncoder(Http2ConnectionEncoder delegate, CompressionOptions... compressionOptionsArgs) {
/* 121 */     super(delegate);
/* 122 */     ObjectUtil.checkNotNull(compressionOptionsArgs, "CompressionOptions");
/* 123 */     ObjectUtil.deepCheckNotNull("CompressionOptions", (Object[])compressionOptionsArgs);
/*     */     
/* 125 */     for (CompressionOptions compressionOptions : compressionOptionsArgs) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 132 */       if (Brotli.isAvailable() && compressionOptions instanceof BrotliOptions) {
/* 133 */         this.brotliOptions = (BrotliOptions)compressionOptions;
/* 134 */       } else if (compressionOptions instanceof GzipOptions) {
/* 135 */         this.gzipCompressionOptions = (GzipOptions)compressionOptions;
/* 136 */       } else if (compressionOptions instanceof DeflateOptions) {
/* 137 */         this.deflateOptions = (DeflateOptions)compressionOptions;
/* 138 */       } else if (compressionOptions instanceof ZstdOptions) {
/* 139 */         this.zstdOptions = (ZstdOptions)compressionOptions;
/*     */       } else {
/* 141 */         throw new IllegalArgumentException("Unsupported " + CompressionOptions.class.getSimpleName() + ": " + compressionOptions);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 146 */     this.supportsCompressionOptions = true;
/*     */     
/* 148 */     this.propertyKey = connection().newKey();
/* 149 */     connection().addListener(new Http2ConnectionAdapter()
/*     */         {
/*     */           public void onStreamRemoved(Http2Stream stream) {
/* 152 */             EmbeddedChannel compressor = stream.<EmbeddedChannel>getProperty(CompressorHttp2ConnectionEncoder.this.propertyKey);
/* 153 */             if (compressor != null) {
/* 154 */               CompressorHttp2ConnectionEncoder.this.cleanup(stream, compressor);
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeData(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream, ChannelPromise promise) {
/* 163 */     Http2Stream stream = connection().stream(streamId);
/* 164 */     EmbeddedChannel channel = (stream == null) ? null : stream.<EmbeddedChannel>getProperty(this.propertyKey);
/* 165 */     if (channel == null)
/*     */     {
/* 167 */       return super.writeData(ctx, streamId, data, padding, endOfStream, promise);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 172 */       channel.writeOutbound(new Object[] { data });
/* 173 */       ByteBuf buf = nextReadableBuf(channel);
/* 174 */       if (buf == null) {
/* 175 */         if (endOfStream) {
/* 176 */           if (channel.finish()) {
/* 177 */             buf = nextReadableBuf(channel);
/*     */           }
/* 179 */           return super.writeData(ctx, streamId, (buf == null) ? Unpooled.EMPTY_BUFFER : buf, padding, true, promise);
/*     */         } 
/*     */ 
/*     */         
/* 183 */         promise.setSuccess();
/* 184 */         return (ChannelFuture)promise;
/*     */       } 
/*     */       
/* 187 */       PromiseCombiner combiner = new PromiseCombiner(ctx.executor());
/*     */       while (true) {
/* 189 */         ByteBuf nextBuf = nextReadableBuf(channel);
/* 190 */         boolean compressedEndOfStream = (nextBuf == null && endOfStream);
/* 191 */         if (compressedEndOfStream && channel.finish()) {
/* 192 */           nextBuf = nextReadableBuf(channel);
/* 193 */           compressedEndOfStream = (nextBuf == null);
/*     */         } 
/*     */         
/* 196 */         ChannelPromise bufPromise = ctx.newPromise();
/* 197 */         combiner.add((Promise)bufPromise);
/* 198 */         super.writeData(ctx, streamId, buf, padding, compressedEndOfStream, bufPromise);
/* 199 */         if (nextBuf == null) {
/*     */           break;
/*     */         }
/*     */         
/* 203 */         padding = 0;
/* 204 */         buf = nextBuf;
/*     */       } 
/* 206 */       combiner.finish((Promise)promise);
/* 207 */     } catch (Throwable cause) {
/* 208 */       promise.tryFailure(cause);
/*     */     } finally {
/* 210 */       if (endOfStream) {
/* 211 */         cleanup(stream, channel);
/*     */       }
/*     */     } 
/* 214 */     return (ChannelFuture)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeHeaders(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endStream, ChannelPromise promise) {
/*     */     try {
/* 222 */       EmbeddedChannel compressor = newCompressor(ctx, headers, endStream);
/*     */ 
/*     */       
/* 225 */       ChannelFuture future = super.writeHeaders(ctx, streamId, headers, padding, endStream, promise);
/*     */ 
/*     */       
/* 228 */       bindCompressorToStream(compressor, streamId);
/*     */       
/* 230 */       return future;
/* 231 */     } catch (Throwable e) {
/* 232 */       promise.tryFailure(e);
/*     */       
/* 234 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeHeaders(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream, ChannelPromise promise) {
/*     */     try {
/* 243 */       EmbeddedChannel compressor = newCompressor(ctx, headers, endOfStream);
/*     */ 
/*     */       
/* 246 */       ChannelFuture future = super.writeHeaders(ctx, streamId, headers, streamDependency, weight, exclusive, padding, endOfStream, promise);
/*     */ 
/*     */ 
/*     */       
/* 250 */       bindCompressorToStream(compressor, streamId);
/*     */       
/* 252 */       return future;
/* 253 */     } catch (Throwable e) {
/* 254 */       promise.tryFailure(e);
/*     */       
/* 256 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EmbeddedChannel newContentCompressor(ChannelHandlerContext ctx, CharSequence contentEncoding) throws Http2Exception {
/* 271 */     if (HttpHeaderValues.GZIP.contentEqualsIgnoreCase(contentEncoding) || HttpHeaderValues.X_GZIP.contentEqualsIgnoreCase(contentEncoding)) {
/* 272 */       return newCompressionChannel(ctx, ZlibWrapper.GZIP);
/*     */     }
/* 274 */     if (HttpHeaderValues.DEFLATE.contentEqualsIgnoreCase(contentEncoding) || HttpHeaderValues.X_DEFLATE.contentEqualsIgnoreCase(contentEncoding)) {
/* 275 */       return newCompressionChannel(ctx, ZlibWrapper.ZLIB);
/*     */     }
/* 277 */     if (Brotli.isAvailable() && this.brotliOptions != null && HttpHeaderValues.BR.contentEqualsIgnoreCase(contentEncoding)) {
/* 278 */       return new EmbeddedChannel(ctx.channel().id(), ctx.channel().metadata().hasDisconnect(), ctx
/* 279 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)new BrotliEncoder(this.brotliOptions.parameters()) });
/*     */     }
/* 281 */     if (this.zstdOptions != null && HttpHeaderValues.ZSTD.contentEqualsIgnoreCase(contentEncoding)) {
/* 282 */       return new EmbeddedChannel(ctx.channel().id(), ctx.channel().metadata().hasDisconnect(), ctx
/* 283 */           .channel().config(), new ChannelHandler[] { (ChannelHandler)new ZstdEncoder(this.zstdOptions.compressionLevel(), this.zstdOptions
/* 284 */               .blockSize(), this.zstdOptions.maxEncodeSize()) });
/*     */     }
/*     */     
/* 287 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CharSequence getTargetContentEncoding(CharSequence contentEncoding) throws Http2Exception {
/* 299 */     return contentEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EmbeddedChannel newCompressionChannel(ChannelHandlerContext ctx, ZlibWrapper wrapper) {
/* 308 */     if (this.supportsCompressionOptions) {
/* 309 */       if (wrapper == ZlibWrapper.GZIP && this.gzipCompressionOptions != null)
/* 310 */         return new EmbeddedChannel(ctx.channel().id(), ctx.channel().metadata().hasDisconnect(), ctx
/* 311 */             .channel().config(), new ChannelHandler[] { (ChannelHandler)ZlibCodecFactory.newZlibEncoder(wrapper, this.gzipCompressionOptions
/* 312 */                 .compressionLevel(), this.gzipCompressionOptions.windowBits(), this.gzipCompressionOptions
/* 313 */                 .memLevel()) }); 
/* 314 */       if (wrapper == ZlibWrapper.ZLIB && this.deflateOptions != null) {
/* 315 */         return new EmbeddedChannel(ctx.channel().id(), ctx.channel().metadata().hasDisconnect(), ctx
/* 316 */             .channel().config(), new ChannelHandler[] { (ChannelHandler)ZlibCodecFactory.newZlibEncoder(wrapper, this.deflateOptions
/* 317 */                 .compressionLevel(), this.deflateOptions.windowBits(), this.deflateOptions
/* 318 */                 .memLevel()) });
/*     */       }
/* 320 */       throw new IllegalArgumentException("Unsupported ZlibWrapper: " + wrapper);
/*     */     } 
/*     */     
/* 323 */     return new EmbeddedChannel(ctx.channel().id(), ctx.channel().metadata().hasDisconnect(), ctx
/* 324 */         .channel().config(), new ChannelHandler[] { (ChannelHandler)ZlibCodecFactory.newZlibEncoder(wrapper, this.compressionLevel, this.windowBits, this.memLevel) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EmbeddedChannel newCompressor(ChannelHandlerContext ctx, Http2Headers headers, boolean endOfStream) throws Http2Exception {
/*     */     AsciiString asciiString;
/* 341 */     if (endOfStream) {
/* 342 */       return null;
/*     */     }
/*     */     
/* 345 */     CharSequence encoding = (CharSequence)headers.get(HttpHeaderNames.CONTENT_ENCODING);
/* 346 */     if (encoding == null) {
/* 347 */       asciiString = HttpHeaderValues.IDENTITY;
/*     */     }
/* 349 */     EmbeddedChannel compressor = newContentCompressor(ctx, (CharSequence)asciiString);
/* 350 */     if (compressor != null) {
/* 351 */       CharSequence targetContentEncoding = getTargetContentEncoding((CharSequence)asciiString);
/* 352 */       if (HttpHeaderValues.IDENTITY.contentEqualsIgnoreCase(targetContentEncoding)) {
/* 353 */         headers.remove(HttpHeaderNames.CONTENT_ENCODING);
/*     */       } else {
/* 355 */         headers.set(HttpHeaderNames.CONTENT_ENCODING, targetContentEncoding);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 361 */       headers.remove(HttpHeaderNames.CONTENT_LENGTH);
/*     */     } 
/*     */     
/* 364 */     return compressor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void bindCompressorToStream(EmbeddedChannel compressor, int streamId) {
/* 373 */     if (compressor != null) {
/* 374 */       Http2Stream stream = connection().stream(streamId);
/* 375 */       if (stream != null) {
/* 376 */         stream.setProperty(this.propertyKey, compressor);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void cleanup(Http2Stream stream, EmbeddedChannel compressor) {
/* 388 */     compressor.finishAndReleaseAll();
/* 389 */     stream.removeProperty(this.propertyKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ByteBuf nextReadableBuf(EmbeddedChannel compressor) {
/*     */     ByteBuf buf;
/*     */     while (true) {
/* 400 */       buf = (ByteBuf)compressor.readOutbound();
/* 401 */       if (buf == null) {
/* 402 */         return null;
/*     */       }
/* 404 */       if (!buf.isReadable()) {
/* 405 */         buf.release(); continue;
/*     */       }  break;
/*     */     } 
/* 408 */     return buf;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\CompressorHttp2ConnectionEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */