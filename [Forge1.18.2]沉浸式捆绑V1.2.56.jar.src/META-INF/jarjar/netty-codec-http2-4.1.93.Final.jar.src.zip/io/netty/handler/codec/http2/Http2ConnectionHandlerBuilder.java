/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2ConnectionHandlerBuilder
/*     */   extends AbstractHttp2ConnectionHandlerBuilder<Http2ConnectionHandler, Http2ConnectionHandlerBuilder>
/*     */ {
/*     */   public Http2ConnectionHandlerBuilder validateHeaders(boolean validateHeaders) {
/*  31 */     return super.validateHeaders(validateHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder initialSettings(Http2Settings settings) {
/*  36 */     return super.initialSettings(settings);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Settings initialSettings() {
/*  41 */     return super.initialSettings();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder frameListener(Http2FrameListener frameListener) {
/*  46 */     return super.frameListener(frameListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder gracefulShutdownTimeoutMillis(long gracefulShutdownTimeoutMillis) {
/*  51 */     return super.gracefulShutdownTimeoutMillis(gracefulShutdownTimeoutMillis);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder server(boolean isServer) {
/*  56 */     return super.server(isServer);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder connection(Http2Connection connection) {
/*  61 */     return super.connection(connection);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder maxReservedStreams(int maxReservedStreams) {
/*  66 */     return super.maxReservedStreams(maxReservedStreams);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder codec(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder) {
/*  71 */     return super.codec(decoder, encoder);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder frameLogger(Http2FrameLogger frameLogger) {
/*  76 */     return super.frameLogger(frameLogger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder encoderEnforceMaxConcurrentStreams(boolean encoderEnforceMaxConcurrentStreams) {
/*  82 */     return super.encoderEnforceMaxConcurrentStreams(encoderEnforceMaxConcurrentStreams);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder encoderIgnoreMaxHeaderListSize(boolean encoderIgnoreMaxHeaderListSize) {
/*  87 */     return super.encoderIgnoreMaxHeaderListSize(encoderIgnoreMaxHeaderListSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder headerSensitivityDetector(Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector) {
/*  92 */     return super.headerSensitivityDetector(headerSensitivityDetector);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Http2ConnectionHandlerBuilder initialHuffmanDecodeCapacity(int initialHuffmanDecodeCapacity) {
/*  98 */     return super.initialHuffmanDecodeCapacity(initialHuffmanDecodeCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder decoupleCloseAndGoAway(boolean decoupleCloseAndGoAway) {
/* 103 */     return super.decoupleCloseAndGoAway(decoupleCloseAndGoAway);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandlerBuilder flushPreface(boolean flushPreface) {
/* 108 */     return super.flushPreface(flushPreface);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2ConnectionHandler build() {
/* 113 */     return super.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2ConnectionHandler build(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
/* 119 */     return new Http2ConnectionHandler(decoder, encoder, initialSettings, decoupleCloseAndGoAway(), flushPreface());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2ConnectionHandlerBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */