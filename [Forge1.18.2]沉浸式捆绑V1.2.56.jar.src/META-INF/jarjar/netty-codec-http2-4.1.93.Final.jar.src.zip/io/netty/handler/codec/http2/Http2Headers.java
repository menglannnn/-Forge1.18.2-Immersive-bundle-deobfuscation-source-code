/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.handler.codec.Headers;
/*     */ import io.netty.util.AsciiString;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public interface Http2Headers
/*     */   extends Headers<CharSequence, CharSequence, Http2Headers>
/*     */ {
/*     */   Iterator<Map.Entry<CharSequence, CharSequence>> iterator();
/*     */   
/*     */   Iterator<CharSequence> valueIterator(CharSequence paramCharSequence);
/*     */   
/*     */   Http2Headers method(CharSequence paramCharSequence);
/*     */   
/*     */   Http2Headers scheme(CharSequence paramCharSequence);
/*     */   
/*     */   Http2Headers authority(CharSequence paramCharSequence);
/*     */   
/*     */   Http2Headers path(CharSequence paramCharSequence);
/*     */   
/*     */   Http2Headers status(CharSequence paramCharSequence);
/*     */   
/*     */   CharSequence method();
/*     */   
/*     */   CharSequence scheme();
/*     */   
/*     */   CharSequence authority();
/*     */   
/*     */   CharSequence path();
/*     */   
/*     */   CharSequence status();
/*     */   
/*     */   boolean contains(CharSequence paramCharSequence1, CharSequence paramCharSequence2, boolean paramBoolean);
/*     */   
/*     */   public enum PseudoHeaderName {
/*  38 */     METHOD(":method", true),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     SCHEME(":scheme", true),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     AUTHORITY(":authority", true),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     PATH(":path", true),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     STATUS(":status", false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     PROTOCOL(":protocol", true);
/*     */     
/*     */     private static final char PSEUDO_HEADER_PREFIX = ':';
/*     */     
/*     */     private static final byte PSEUDO_HEADER_PREFIX_BYTE = 58;
/*     */     private final AsciiString value;
/*     */     private final boolean requestOnly;
/*  71 */     private static final CharSequenceMap<PseudoHeaderName> PSEUDO_HEADERS = new CharSequenceMap<PseudoHeaderName>();
/*     */     
/*     */     static {
/*  74 */       for (PseudoHeaderName pseudoHeader : values()) {
/*  75 */         PSEUDO_HEADERS.add(pseudoHeader.value(), pseudoHeader);
/*     */       }
/*     */     }
/*     */     
/*     */     PseudoHeaderName(String value, boolean requestOnly) {
/*  80 */       this.value = AsciiString.cached(value);
/*  81 */       this.requestOnly = requestOnly;
/*     */     }
/*     */ 
/*     */     
/*     */     public AsciiString value() {
/*  86 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static boolean hasPseudoHeaderFormat(CharSequence headerName) {
/*  95 */       if (headerName instanceof AsciiString) {
/*  96 */         AsciiString asciiHeaderName = (AsciiString)headerName;
/*  97 */         return (asciiHeaderName.length() > 0 && asciiHeaderName.byteAt(0) == 58);
/*     */       } 
/*  99 */       return (headerName.length() > 0 && headerName.charAt(0) == ':');
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static boolean isPseudoHeader(CharSequence header) {
/* 107 */       return PSEUDO_HEADERS.contains(header);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static PseudoHeaderName getPseudoHeader(CharSequence header) {
/* 116 */       return (PseudoHeaderName)PSEUDO_HEADERS.get(header);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isRequestOnly() {
/* 125 */       return this.requestOnly;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2Headers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */