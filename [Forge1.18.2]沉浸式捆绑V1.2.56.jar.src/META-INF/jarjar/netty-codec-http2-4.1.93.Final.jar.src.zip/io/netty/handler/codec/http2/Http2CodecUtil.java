/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.DefaultChannelPromise;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.CharsetUtil;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2CodecUtil
/*     */ {
/*     */   public static final int CONNECTION_STREAM_ID = 0;
/*     */   public static final int HTTP_UPGRADE_STREAM_ID = 1;
/*  48 */   public static final CharSequence HTTP_UPGRADE_SETTINGS_HEADER = (CharSequence)AsciiString.cached("HTTP2-Settings");
/*  49 */   public static final CharSequence HTTP_UPGRADE_PROTOCOL_NAME = "h2c";
/*  50 */   public static final CharSequence TLS_UPGRADE_PROTOCOL_NAME = "h2";
/*     */   
/*     */   public static final int PING_FRAME_PAYLOAD_LENGTH = 8;
/*     */   
/*     */   public static final short MAX_UNSIGNED_BYTE = 255;
/*     */   
/*     */   public static final int MAX_PADDING = 256;
/*     */   
/*     */   public static final long MAX_UNSIGNED_INT = 4294967295L;
/*     */   
/*     */   public static final int FRAME_HEADER_LENGTH = 9;
/*     */   
/*     */   public static final int SETTING_ENTRY_LENGTH = 6;
/*     */   
/*     */   public static final int PRIORITY_ENTRY_LENGTH = 5;
/*     */   public static final int INT_FIELD_LENGTH = 4;
/*     */   public static final short MAX_WEIGHT = 256;
/*     */   public static final short MIN_WEIGHT = 1;
/*  68 */   private static final ByteBuf CONNECTION_PREFACE = Unpooled.unreleasableBuffer(Unpooled.directBuffer(24).writeBytes("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n".getBytes(CharsetUtil.UTF_8)))
/*  69 */     .asReadOnly();
/*     */   
/*     */   private static final int MAX_PADDING_LENGTH_LENGTH = 1;
/*     */   
/*     */   public static final int DATA_FRAME_HEADER_LENGTH = 10;
/*     */   
/*     */   public static final int HEADERS_FRAME_HEADER_LENGTH = 15;
/*     */   
/*     */   public static final int PRIORITY_FRAME_LENGTH = 14;
/*     */   
/*     */   public static final int RST_STREAM_FRAME_LENGTH = 13;
/*     */   
/*     */   public static final int PUSH_PROMISE_FRAME_HEADER_LENGTH = 14;
/*     */   
/*     */   public static final int GO_AWAY_FRAME_HEADER_LENGTH = 17;
/*     */   
/*     */   public static final int WINDOW_UPDATE_FRAME_LENGTH = 13;
/*     */   
/*     */   public static final int CONTINUATION_FRAME_HEADER_LENGTH = 10;
/*     */   
/*     */   public static final char SETTINGS_HEADER_TABLE_SIZE = '\001';
/*     */   
/*     */   public static final char SETTINGS_ENABLE_PUSH = '\002';
/*     */   
/*     */   public static final char SETTINGS_MAX_CONCURRENT_STREAMS = '\003';
/*     */   
/*     */   public static final char SETTINGS_INITIAL_WINDOW_SIZE = '\004';
/*     */   
/*     */   public static final char SETTINGS_MAX_FRAME_SIZE = '\005';
/*     */   
/*     */   public static final char SETTINGS_MAX_HEADER_LIST_SIZE = '\006';
/*     */   
/*     */   public static final int NUM_STANDARD_SETTINGS = 6;
/*     */   
/*     */   public static final long MAX_HEADER_TABLE_SIZE = 4294967295L;
/*     */   
/*     */   public static final long MAX_CONCURRENT_STREAMS = 4294967295L;
/*     */   
/*     */   public static final int MAX_INITIAL_WINDOW_SIZE = 2147483647;
/*     */   
/*     */   public static final int MAX_FRAME_SIZE_LOWER_BOUND = 16384;
/*     */   
/*     */   public static final int MAX_FRAME_SIZE_UPPER_BOUND = 16777215;
/*     */   
/*     */   public static final long MAX_HEADER_LIST_SIZE = 4294967295L;
/*     */   
/*     */   public static final long MIN_HEADER_TABLE_SIZE = 0L;
/*     */   
/*     */   public static final long MIN_CONCURRENT_STREAMS = 0L;
/*     */   public static final int MIN_INITIAL_WINDOW_SIZE = 0;
/*     */   public static final long MIN_HEADER_LIST_SIZE = 0L;
/*     */   public static final int DEFAULT_WINDOW_SIZE = 65535;
/*     */   public static final short DEFAULT_PRIORITY_WEIGHT = 16;
/*     */   public static final int DEFAULT_HEADER_TABLE_SIZE = 4096;
/*     */   public static final long DEFAULT_HEADER_LIST_SIZE = 8192L;
/*     */   public static final int DEFAULT_MAX_FRAME_SIZE = 16384;
/*     */   public static final int SMALLEST_MAX_CONCURRENT_STREAMS = 100;
/*     */   static final int DEFAULT_MAX_RESERVED_STREAMS = 100;
/*     */   static final int DEFAULT_MIN_ALLOCATION_CHUNK = 1024;
/*     */   
/*     */   public static long calculateMaxHeaderListSizeGoAway(long maxHeaderListSize) {
/* 130 */     return maxHeaderListSize + (maxHeaderListSize >>> 2L);
/*     */   }
/*     */   
/* 133 */   public static final long DEFAULT_GRACEFUL_SHUTDOWN_TIMEOUT_MILLIS = TimeUnit.MILLISECONDS.convert(30L, TimeUnit.SECONDS);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_MAX_QUEUED_CONTROL_FRAMES = 10000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOutboundStream(boolean server, int streamId) {
/* 144 */     boolean even = ((streamId & 0x1) == 0);
/* 145 */     return (streamId > 0 && server == even);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStreamIdValid(int streamId) {
/* 152 */     return (streamId >= 0);
/*     */   }
/*     */   
/*     */   static boolean isStreamIdValid(int streamId, boolean server) {
/* 156 */     return (isStreamIdValid(streamId) && server == (((streamId & 0x1) == 0)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isMaxFrameSizeValid(int maxFrameSize) {
/* 163 */     return (maxFrameSize >= 16384 && maxFrameSize <= 16777215);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuf connectionPrefaceBuf() {
/* 171 */     return CONNECTION_PREFACE.retainedDuplicate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2Exception getEmbeddedHttp2Exception(Throwable cause) {
/* 179 */     while (cause != null) {
/* 180 */       if (cause instanceof Http2Exception) {
/* 181 */         return (Http2Exception)cause;
/*     */       }
/* 183 */       cause = cause.getCause();
/*     */     } 
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuf toByteBuf(ChannelHandlerContext ctx, Throwable cause) {
/* 193 */     if (cause == null || cause.getMessage() == null) {
/* 194 */       return Unpooled.EMPTY_BUFFER;
/*     */     }
/*     */     
/* 197 */     return ByteBufUtil.writeUtf8(ctx.alloc(), cause.getMessage());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readUnsignedInt(ByteBuf buf) {
/* 204 */     return buf.readInt() & Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeFrameHeader(ByteBuf out, int payloadLength, byte type, Http2Flags flags, int streamId) {
/* 212 */     out.ensureWritable(9 + payloadLength);
/* 213 */     writeFrameHeaderInternal(out, payloadLength, type, flags, streamId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int streamableBytes(StreamByteDistributor.StreamState state) {
/* 220 */     return Math.max(0, (int)Math.min(state.pendingBytes(), state.windowSize()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void headerListSizeExceeded(int streamId, long maxHeaderListSize, boolean onDecode) throws Http2Exception {
/* 233 */     throw Http2Exception.headerListSizeError(streamId, Http2Error.PROTOCOL_ERROR, onDecode, "Header size exceeded max allowed size (%d)", new Object[] {
/* 234 */           Long.valueOf(maxHeaderListSize)
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void headerListSizeExceeded(long maxHeaderListSize) throws Http2Exception {
/* 245 */     throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Header size exceeded max allowed size (%d)", new Object[] {
/* 246 */           Long.valueOf(maxHeaderListSize)
/*     */         });
/*     */   }
/*     */   
/*     */   static void writeFrameHeaderInternal(ByteBuf out, int payloadLength, byte type, Http2Flags flags, int streamId) {
/* 251 */     out.writeMedium(payloadLength);
/* 252 */     out.writeByte(type);
/* 253 */     out.writeByte(flags.value());
/* 254 */     out.writeInt(streamId);
/*     */   }
/*     */ 
/*     */   
/*     */   static final class SimpleChannelPromiseAggregator
/*     */     extends DefaultChannelPromise
/*     */   {
/*     */     private final ChannelPromise promise;
/*     */     
/*     */     private int expectedCount;
/*     */     private int doneCount;
/*     */     private Throwable aggregateFailure;
/*     */     private boolean doneAllocating;
/*     */     
/*     */     SimpleChannelPromiseAggregator(ChannelPromise promise, Channel c, EventExecutor e) {
/* 269 */       super(c, e);
/* 270 */       assert promise != null && !promise.isDone();
/* 271 */       this.promise = promise;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelPromise newPromise() {
/* 280 */       assert !this.doneAllocating : "Done allocating. No more promises can be allocated.";
/* 281 */       this.expectedCount++;
/* 282 */       return (ChannelPromise)this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelPromise doneAllocatingPromises() {
/* 291 */       if (!this.doneAllocating) {
/* 292 */         this.doneAllocating = true;
/* 293 */         if (this.doneCount == this.expectedCount || this.expectedCount == 0) {
/* 294 */           return setPromise();
/*     */         }
/*     */       } 
/* 297 */       return (ChannelPromise)this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryFailure(Throwable cause) {
/* 302 */       if (allowFailure()) {
/* 303 */         this.doneCount++;
/* 304 */         setAggregateFailure(cause);
/* 305 */         if (allPromisesDone()) {
/* 306 */           return tryPromise();
/*     */         }
/*     */ 
/*     */         
/* 310 */         return true;
/*     */       } 
/* 312 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelPromise setFailure(Throwable cause) {
/* 323 */       if (allowFailure()) {
/* 324 */         this.doneCount++;
/* 325 */         setAggregateFailure(cause);
/* 326 */         if (allPromisesDone()) {
/* 327 */           return setPromise();
/*     */         }
/*     */       } 
/* 330 */       return (ChannelPromise)this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ChannelPromise setSuccess(Void result) {
/* 335 */       if (awaitingPromises()) {
/* 336 */         this.doneCount++;
/* 337 */         if (allPromisesDone()) {
/* 338 */           setPromise();
/*     */         }
/*     */       } 
/* 341 */       return (ChannelPromise)this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean trySuccess(Void result) {
/* 346 */       if (awaitingPromises()) {
/* 347 */         this.doneCount++;
/* 348 */         if (allPromisesDone()) {
/* 349 */           return tryPromise();
/*     */         }
/*     */ 
/*     */         
/* 353 */         return true;
/*     */       } 
/* 355 */       return false;
/*     */     }
/*     */     
/*     */     private boolean allowFailure() {
/* 359 */       return (awaitingPromises() || this.expectedCount == 0);
/*     */     }
/*     */     
/*     */     private boolean awaitingPromises() {
/* 363 */       return (this.doneCount < this.expectedCount);
/*     */     }
/*     */     
/*     */     private boolean allPromisesDone() {
/* 367 */       return (this.doneCount == this.expectedCount && this.doneAllocating);
/*     */     }
/*     */     
/*     */     private ChannelPromise setPromise() {
/* 371 */       if (this.aggregateFailure == null) {
/* 372 */         this.promise.setSuccess();
/* 373 */         return super.setSuccess(null);
/*     */       } 
/* 375 */       this.promise.setFailure(this.aggregateFailure);
/* 376 */       return super.setFailure(this.aggregateFailure);
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean tryPromise() {
/* 381 */       if (this.aggregateFailure == null) {
/* 382 */         this.promise.trySuccess();
/* 383 */         return super.trySuccess(null);
/*     */       } 
/* 385 */       this.promise.tryFailure(this.aggregateFailure);
/* 386 */       return super.tryFailure(this.aggregateFailure);
/*     */     }
/*     */ 
/*     */     
/*     */     private void setAggregateFailure(Throwable cause) {
/* 391 */       if (this.aggregateFailure == null) {
/* 392 */         this.aggregateFailure = cause;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void verifyPadding(int padding) {
/* 398 */     if (padding < 0 || padding > 256)
/* 399 */       throw new IllegalArgumentException(String.format("Invalid padding '%d'. Padding must be between 0 and %d (inclusive).", new Object[] {
/* 400 */               Integer.valueOf(padding), Integer.valueOf(256)
/*     */             })); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2CodecUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */