/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ import io.netty.util.internal.ObjectUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HpackHeaderField
/*    */ {
/*    */   static final int HEADER_ENTRY_OVERHEAD = 32;
/*    */   final CharSequence name;
/*    */   final CharSequence value;
/*    */   
/*    */   static long sizeOf(CharSequence name, CharSequence value) {
/* 45 */     return (name.length() + value.length() + 32);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   HpackHeaderField(CharSequence name, CharSequence value) {
/* 53 */     this.name = (CharSequence)ObjectUtil.checkNotNull(name, "name");
/* 54 */     this.value = (CharSequence)ObjectUtil.checkNotNull(value, "value");
/*    */   }
/*    */   
/*    */   final int size() {
/* 58 */     return this.name.length() + this.value.length() + 32;
/*    */   }
/*    */   
/*    */   public final boolean equalsForTest(HpackHeaderField other) {
/* 62 */     return (HpackUtil.equalsVariableTime(this.name, other.name) && HpackUtil.equalsVariableTime(this.value, other.value));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return this.name + ": " + this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\HpackHeaderField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */