/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpStatusClass;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2ConnectionDecoder
/*     */   implements Http2ConnectionDecoder
/*     */ {
/*  54 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(DefaultHttp2ConnectionDecoder.class);
/*  55 */   private Http2FrameListener internalFrameListener = new PrefaceFrameListener();
/*     */   
/*     */   private final Http2Connection connection;
/*     */   
/*     */   private Http2LifecycleManager lifecycleManager;
/*     */   private final Http2ConnectionEncoder encoder;
/*     */   private final Http2FrameReader frameReader;
/*     */   private Http2FrameListener listener;
/*     */   private final Http2PromisedRequestVerifier requestVerifier;
/*     */   private final Http2SettingsReceivedConsumer settingsReceivedConsumer;
/*     */   private final boolean autoAckPing;
/*     */   private final Http2Connection.PropertyKey contentLengthKey;
/*     */   
/*     */   public DefaultHttp2ConnectionDecoder(Http2Connection connection, Http2ConnectionEncoder encoder, Http2FrameReader frameReader) {
/*  69 */     this(connection, encoder, frameReader, Http2PromisedRequestVerifier.ALWAYS_VERIFY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2ConnectionDecoder(Http2Connection connection, Http2ConnectionEncoder encoder, Http2FrameReader frameReader, Http2PromisedRequestVerifier requestVerifier) {
/*  76 */     this(connection, encoder, frameReader, requestVerifier, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2ConnectionDecoder(Http2Connection connection, Http2ConnectionEncoder encoder, Http2FrameReader frameReader, Http2PromisedRequestVerifier requestVerifier, boolean autoAckSettings) {
/*  96 */     this(connection, encoder, frameReader, requestVerifier, autoAckSettings, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2ConnectionDecoder(Http2Connection connection, Http2ConnectionEncoder encoder, Http2FrameReader frameReader, Http2PromisedRequestVerifier requestVerifier, boolean autoAckSettings, boolean autoAckPing) {
/* 120 */     this.autoAckPing = autoAckPing;
/* 121 */     if (autoAckSettings) {
/* 122 */       this.settingsReceivedConsumer = null;
/*     */     } else {
/* 124 */       if (!(encoder instanceof Http2SettingsReceivedConsumer)) {
/* 125 */         throw new IllegalArgumentException("disabling autoAckSettings requires the encoder to be a " + Http2SettingsReceivedConsumer.class);
/*     */       }
/*     */       
/* 128 */       this.settingsReceivedConsumer = (Http2SettingsReceivedConsumer)encoder;
/*     */     } 
/* 130 */     this.connection = (Http2Connection)ObjectUtil.checkNotNull(connection, "connection");
/* 131 */     this.contentLengthKey = this.connection.newKey();
/* 132 */     this.frameReader = (Http2FrameReader)ObjectUtil.checkNotNull(frameReader, "frameReader");
/* 133 */     this.encoder = (Http2ConnectionEncoder)ObjectUtil.checkNotNull(encoder, "encoder");
/* 134 */     this.requestVerifier = (Http2PromisedRequestVerifier)ObjectUtil.checkNotNull(requestVerifier, "requestVerifier");
/* 135 */     if (connection.local().flowController() == null) {
/* 136 */       connection.local().flowController(new DefaultHttp2LocalFlowController(connection));
/*     */     }
/* 138 */     ((Http2LocalFlowController)connection.local().flowController()).frameWriter(encoder.frameWriter());
/*     */   }
/*     */ 
/*     */   
/*     */   public void lifecycleManager(Http2LifecycleManager lifecycleManager) {
/* 143 */     this.lifecycleManager = (Http2LifecycleManager)ObjectUtil.checkNotNull(lifecycleManager, "lifecycleManager");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Connection connection() {
/* 148 */     return this.connection;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Http2LocalFlowController flowController() {
/* 153 */     return this.connection.local().flowController();
/*     */   }
/*     */ 
/*     */   
/*     */   public void frameListener(Http2FrameListener listener) {
/* 158 */     this.listener = (Http2FrameListener)ObjectUtil.checkNotNull(listener, "listener");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameListener frameListener() {
/* 163 */     return this.listener;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean prefaceReceived() {
/* 168 */     return (FrameReadListener.class == this.internalFrameListener.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public void decodeFrame(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Http2Exception {
/* 173 */     this.frameReader.readFrame(ctx, in, this.internalFrameListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Settings localSettings() {
/* 178 */     Http2Settings settings = new Http2Settings();
/* 179 */     Http2FrameReader.Configuration config = this.frameReader.configuration();
/* 180 */     Http2HeadersDecoder.Configuration headersConfig = config.headersConfiguration();
/* 181 */     Http2FrameSizePolicy frameSizePolicy = config.frameSizePolicy();
/* 182 */     settings.initialWindowSize(flowController().initialWindowSize());
/* 183 */     settings.maxConcurrentStreams(this.connection.remote().maxActiveStreams());
/* 184 */     settings.headerTableSize(headersConfig.maxHeaderTableSize());
/* 185 */     settings.maxFrameSize(frameSizePolicy.maxFrameSize());
/* 186 */     settings.maxHeaderListSize(headersConfig.maxHeaderListSize());
/* 187 */     if (!this.connection.isServer())
/*     */     {
/* 189 */       settings.pushEnabled(this.connection.local().allowPushTo());
/*     */     }
/* 191 */     return settings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 196 */     this.frameReader.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long calculateMaxHeaderListSizeGoAway(long maxHeaderListSize) {
/* 207 */     return Http2CodecUtil.calculateMaxHeaderListSizeGoAway(maxHeaderListSize);
/*     */   }
/*     */   
/*     */   private int unconsumedBytes(Http2Stream stream) {
/* 211 */     return flowController().unconsumedBytes(stream);
/*     */   }
/*     */ 
/*     */   
/*     */   void onGoAwayRead0(ChannelHandlerContext ctx, int lastStreamId, long errorCode, ByteBuf debugData) throws Http2Exception {
/* 216 */     this.listener.onGoAwayRead(ctx, lastStreamId, errorCode, debugData);
/* 217 */     this.connection.goAwayReceived(lastStreamId, errorCode, debugData);
/*     */   }
/*     */ 
/*     */   
/*     */   void onUnknownFrame0(ChannelHandlerContext ctx, byte frameType, int streamId, Http2Flags flags, ByteBuf payload) throws Http2Exception {
/* 222 */     this.listener.onUnknownFrame(ctx, frameType, streamId, flags, payload);
/*     */   }
/*     */ 
/*     */   
/*     */   private void verifyContentLength(Http2Stream stream, int data, boolean isEnd) throws Http2Exception {
/* 227 */     ContentLength contentLength = stream.<ContentLength>getProperty(this.contentLengthKey);
/* 228 */     if (contentLength != null) {
/*     */       try {
/* 230 */         contentLength.increaseReceivedBytes(this.connection.isServer(), stream.id(), data, isEnd);
/*     */       } finally {
/* 232 */         if (isEnd) {
/* 233 */           stream.removeProperty(this.contentLengthKey);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private final class FrameReadListener
/*     */     implements Http2FrameListener
/*     */   {
/*     */     private FrameReadListener() {}
/*     */     
/*     */     public int onDataRead(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream) throws Http2Exception {
/*     */       boolean shouldIgnore;
/* 246 */       Http2Stream stream = DefaultHttp2ConnectionDecoder.this.connection.stream(streamId);
/* 247 */       Http2LocalFlowController flowController = DefaultHttp2ConnectionDecoder.this.flowController();
/* 248 */       int readable = data.readableBytes();
/* 249 */       int bytesToReturn = readable + padding;
/*     */ 
/*     */       
/*     */       try {
/* 253 */         shouldIgnore = shouldIgnoreHeadersOrDataFrame(ctx, streamId, stream, "DATA");
/* 254 */       } catch (Http2Exception e) {
/*     */ 
/*     */         
/* 257 */         flowController.receiveFlowControlledFrame(stream, data, padding, endOfStream);
/* 258 */         flowController.consumeBytes(stream, bytesToReturn);
/* 259 */         throw e;
/* 260 */       } catch (Throwable t) {
/* 261 */         throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, t, "Unhandled error on data stream id %d", new Object[] { Integer.valueOf(streamId) });
/*     */       } 
/*     */       
/* 264 */       if (shouldIgnore) {
/*     */ 
/*     */         
/* 267 */         flowController.receiveFlowControlledFrame(stream, data, padding, endOfStream);
/* 268 */         flowController.consumeBytes(stream, bytesToReturn);
/*     */ 
/*     */         
/* 271 */         verifyStreamMayHaveExisted(streamId);
/*     */ 
/*     */         
/* 274 */         return bytesToReturn;
/*     */       } 
/* 276 */       Http2Exception error = null;
/* 277 */       switch (stream.state()) {
/*     */         case OPEN:
/*     */         case HALF_CLOSED_LOCAL:
/*     */           break;
/*     */         case HALF_CLOSED_REMOTE:
/*     */         case CLOSED:
/* 283 */           error = Http2Exception.streamError(stream.id(), Http2Error.STREAM_CLOSED, "Stream %d in unexpected state: %s", new Object[] {
/* 284 */                 Integer.valueOf(stream.id()), stream.state() });
/*     */           break;
/*     */         default:
/* 287 */           error = Http2Exception.streamError(stream.id(), Http2Error.PROTOCOL_ERROR, "Stream %d in unexpected state: %s", new Object[] {
/* 288 */                 Integer.valueOf(stream.id()), stream.state()
/*     */               });
/*     */           break;
/*     */       } 
/* 292 */       int unconsumedBytes = DefaultHttp2ConnectionDecoder.this.unconsumedBytes(stream);
/*     */       try {
/* 294 */         flowController.receiveFlowControlledFrame(stream, data, padding, endOfStream);
/*     */         
/* 296 */         unconsumedBytes = DefaultHttp2ConnectionDecoder.this.unconsumedBytes(stream);
/*     */ 
/*     */         
/* 299 */         if (error != null) {
/* 300 */           throw error;
/*     */         }
/*     */         
/* 303 */         DefaultHttp2ConnectionDecoder.this.verifyContentLength(stream, readable, endOfStream);
/*     */ 
/*     */ 
/*     */         
/* 307 */         bytesToReturn = DefaultHttp2ConnectionDecoder.this.listener.onDataRead(ctx, streamId, data, padding, endOfStream);
/*     */         
/* 309 */         if (endOfStream) {
/* 310 */           DefaultHttp2ConnectionDecoder.this.lifecycleManager.closeStreamRemote(stream, ctx.newSucceededFuture());
/*     */         }
/*     */         
/* 313 */         return bytesToReturn;
/* 314 */       } catch (Http2Exception e) {
/*     */ 
/*     */ 
/*     */         
/* 318 */         int delta = unconsumedBytes - DefaultHttp2ConnectionDecoder.this.unconsumedBytes(stream);
/* 319 */         bytesToReturn -= delta;
/* 320 */         throw e;
/* 321 */       } catch (RuntimeException e) {
/*     */ 
/*     */ 
/*     */         
/* 325 */         int delta = unconsumedBytes - DefaultHttp2ConnectionDecoder.this.unconsumedBytes(stream);
/* 326 */         bytesToReturn -= delta;
/* 327 */         throw e;
/*     */       } finally {
/*     */         
/* 330 */         flowController.consumeBytes(stream, bytesToReturn);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endOfStream) throws Http2Exception {
/* 337 */       onHeadersRead(ctx, streamId, headers, 0, (short)16, false, padding, endOfStream);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream) throws Http2Exception {
/* 343 */       Http2Stream stream = DefaultHttp2ConnectionDecoder.this.connection.stream(streamId);
/* 344 */       boolean allowHalfClosedRemote = false;
/* 345 */       boolean isTrailers = false;
/* 346 */       if (stream == null && !DefaultHttp2ConnectionDecoder.this.connection.streamMayHaveExisted(streamId)) {
/* 347 */         stream = DefaultHttp2ConnectionDecoder.this.connection.remote().createStream(streamId, endOfStream);
/*     */         
/* 349 */         allowHalfClosedRemote = (stream.state() == Http2Stream.State.HALF_CLOSED_REMOTE);
/* 350 */       } else if (stream != null) {
/* 351 */         isTrailers = stream.isHeadersReceived();
/*     */       } 
/*     */       
/* 354 */       if (shouldIgnoreHeadersOrDataFrame(ctx, streamId, stream, "HEADERS")) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 359 */       boolean isInformational = (!DefaultHttp2ConnectionDecoder.this.connection.isServer() && HttpStatusClass.valueOf(headers.status()) == HttpStatusClass.INFORMATIONAL);
/* 360 */       if (((isInformational || !endOfStream) && stream.isHeadersReceived()) || stream.isTrailersReceived()) {
/* 361 */         throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Stream %d received too many headers EOS: %s state: %s", new Object[] {
/*     */               
/* 363 */               Integer.valueOf(streamId), Boolean.valueOf(endOfStream), stream.state()
/*     */             });
/*     */       }
/* 366 */       switch (stream.state()) {
/*     */         case RESERVED_REMOTE:
/* 368 */           stream.open(endOfStream);
/*     */           break;
/*     */         
/*     */         case OPEN:
/*     */         case HALF_CLOSED_LOCAL:
/*     */           break;
/*     */         case HALF_CLOSED_REMOTE:
/* 375 */           if (!allowHalfClosedRemote)
/* 376 */             throw Http2Exception.streamError(stream.id(), Http2Error.STREAM_CLOSED, "Stream %d in unexpected state: %s", new Object[] {
/* 377 */                   Integer.valueOf(stream.id()), stream.state()
/*     */                 }); 
/*     */           break;
/*     */         case CLOSED:
/* 381 */           throw Http2Exception.streamError(stream.id(), Http2Error.STREAM_CLOSED, "Stream %d in unexpected state: %s", new Object[] {
/* 382 */                 Integer.valueOf(stream.id()), stream.state()
/*     */               });
/*     */         default:
/* 385 */           throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Stream %d in unexpected state: %s", new Object[] { Integer.valueOf(stream.id()), stream
/* 386 */                 .state() });
/*     */       } 
/*     */       
/* 389 */       if (!isTrailers) {
/*     */         
/* 391 */         List<? extends CharSequence> contentLength = headers.getAll(HttpHeaderNames.CONTENT_LENGTH);
/* 392 */         if (contentLength != null && !contentLength.isEmpty()) {
/*     */           try {
/* 394 */             long cLength = HttpUtil.normalizeAndGetContentLength(contentLength, false, true);
/* 395 */             if (cLength != -1L) {
/* 396 */               headers.setLong(HttpHeaderNames.CONTENT_LENGTH, cLength);
/* 397 */               stream.setProperty(DefaultHttp2ConnectionDecoder.this.contentLengthKey, new DefaultHttp2ConnectionDecoder.ContentLength(cLength));
/*     */             } 
/* 399 */           } catch (IllegalArgumentException e) {
/* 400 */             throw Http2Exception.streamError(stream.id(), Http2Error.PROTOCOL_ERROR, e, "Multiple content-length headers received", new Object[0]);
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 406 */       stream.headersReceived(isInformational);
/* 407 */       DefaultHttp2ConnectionDecoder.this.verifyContentLength(stream, 0, endOfStream);
/* 408 */       DefaultHttp2ConnectionDecoder.this.encoder.flowController().updateDependencyTree(streamId, streamDependency, weight, exclusive);
/* 409 */       DefaultHttp2ConnectionDecoder.this.listener.onHeadersRead(ctx, streamId, headers, streamDependency, weight, exclusive, padding, endOfStream);
/*     */ 
/*     */       
/* 412 */       if (endOfStream) {
/* 413 */         DefaultHttp2ConnectionDecoder.this.lifecycleManager.closeStreamRemote(stream, ctx.newSucceededFuture());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onPriorityRead(ChannelHandlerContext ctx, int streamId, int streamDependency, short weight, boolean exclusive) throws Http2Exception {
/* 420 */       DefaultHttp2ConnectionDecoder.this.encoder.flowController().updateDependencyTree(streamId, streamDependency, weight, exclusive);
/*     */       
/* 422 */       DefaultHttp2ConnectionDecoder.this.listener.onPriorityRead(ctx, streamId, streamDependency, weight, exclusive);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onRstStreamRead(ChannelHandlerContext ctx, int streamId, long errorCode) throws Http2Exception {
/* 427 */       Http2Stream stream = DefaultHttp2ConnectionDecoder.this.connection.stream(streamId);
/* 428 */       if (stream == null) {
/* 429 */         verifyStreamMayHaveExisted(streamId);
/*     */         
/*     */         return;
/*     */       } 
/* 433 */       switch (stream.state()) {
/*     */         case IDLE:
/* 435 */           throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "RST_STREAM received for IDLE stream %d", new Object[] { Integer.valueOf(streamId) });
/*     */ 
/*     */         
/*     */         case CLOSED:
/*     */           return;
/*     */       } 
/*     */       
/* 442 */       DefaultHttp2ConnectionDecoder.this.listener.onRstStreamRead(ctx, streamId, errorCode);
/*     */       
/* 444 */       DefaultHttp2ConnectionDecoder.this.lifecycleManager.closeStream(stream, ctx.newSucceededFuture());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSettingsAckRead(ChannelHandlerContext ctx) throws Http2Exception {
/* 450 */       Http2Settings settings = DefaultHttp2ConnectionDecoder.this.encoder.pollSentSettings();
/*     */       
/* 452 */       if (settings != null) {
/* 453 */         applyLocalSettings(settings);
/*     */       }
/*     */       
/* 456 */       DefaultHttp2ConnectionDecoder.this.listener.onSettingsAckRead(ctx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void applyLocalSettings(Http2Settings settings) throws Http2Exception {
/* 465 */       Boolean pushEnabled = settings.pushEnabled();
/* 466 */       Http2FrameReader.Configuration config = DefaultHttp2ConnectionDecoder.this.frameReader.configuration();
/* 467 */       Http2HeadersDecoder.Configuration headerConfig = config.headersConfiguration();
/* 468 */       Http2FrameSizePolicy frameSizePolicy = config.frameSizePolicy();
/* 469 */       if (pushEnabled != null) {
/* 470 */         if (DefaultHttp2ConnectionDecoder.this.connection.isServer()) {
/* 471 */           throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Server sending SETTINGS frame with ENABLE_PUSH specified", new Object[0]);
/*     */         }
/* 473 */         DefaultHttp2ConnectionDecoder.this.connection.local().allowPushTo(pushEnabled.booleanValue());
/*     */       } 
/*     */       
/* 476 */       Long maxConcurrentStreams = settings.maxConcurrentStreams();
/* 477 */       if (maxConcurrentStreams != null) {
/* 478 */         DefaultHttp2ConnectionDecoder.this.connection.remote().maxActiveStreams((int)Math.min(maxConcurrentStreams.longValue(), 2147483647L));
/*     */       }
/*     */       
/* 481 */       Long headerTableSize = settings.headerTableSize();
/* 482 */       if (headerTableSize != null) {
/* 483 */         headerConfig.maxHeaderTableSize(headerTableSize.longValue());
/*     */       }
/*     */       
/* 486 */       Long maxHeaderListSize = settings.maxHeaderListSize();
/* 487 */       if (maxHeaderListSize != null) {
/* 488 */         headerConfig.maxHeaderListSize(maxHeaderListSize.longValue(), DefaultHttp2ConnectionDecoder.this.calculateMaxHeaderListSizeGoAway(maxHeaderListSize.longValue()));
/*     */       }
/*     */       
/* 491 */       Integer maxFrameSize = settings.maxFrameSize();
/* 492 */       if (maxFrameSize != null) {
/* 493 */         frameSizePolicy.maxFrameSize(maxFrameSize.intValue());
/*     */       }
/*     */       
/* 496 */       Integer initialWindowSize = settings.initialWindowSize();
/* 497 */       if (initialWindowSize != null) {
/* 498 */         DefaultHttp2ConnectionDecoder.this.flowController().initialWindowSize(initialWindowSize.intValue());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSettingsRead(ChannelHandlerContext ctx, Http2Settings settings) throws Http2Exception {
/* 504 */       if (DefaultHttp2ConnectionDecoder.this.settingsReceivedConsumer == null) {
/*     */ 
/*     */ 
/*     */         
/* 508 */         DefaultHttp2ConnectionDecoder.this.encoder.writeSettingsAck(ctx, ctx.newPromise());
/*     */         
/* 510 */         DefaultHttp2ConnectionDecoder.this.encoder.remoteSettings(settings);
/*     */       } else {
/* 512 */         DefaultHttp2ConnectionDecoder.this.settingsReceivedConsumer.consumeReceivedSettings(settings);
/*     */       } 
/*     */       
/* 515 */       DefaultHttp2ConnectionDecoder.this.listener.onSettingsRead(ctx, settings);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onPingRead(ChannelHandlerContext ctx, long data) throws Http2Exception {
/* 520 */       if (DefaultHttp2ConnectionDecoder.this.autoAckPing)
/*     */       {
/* 522 */         DefaultHttp2ConnectionDecoder.this.encoder.writePing(ctx, true, data, ctx.newPromise());
/*     */       }
/* 524 */       DefaultHttp2ConnectionDecoder.this.listener.onPingRead(ctx, data);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onPingAckRead(ChannelHandlerContext ctx, long data) throws Http2Exception {
/* 529 */       DefaultHttp2ConnectionDecoder.this.listener.onPingAckRead(ctx, data);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onPushPromiseRead(ChannelHandlerContext ctx, int streamId, int promisedStreamId, Http2Headers headers, int padding) throws Http2Exception {
/* 536 */       if (DefaultHttp2ConnectionDecoder.this.connection().isServer()) {
/* 537 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "A client cannot push.", new Object[0]);
/*     */       }
/*     */       
/* 540 */       Http2Stream parentStream = DefaultHttp2ConnectionDecoder.this.connection.stream(streamId);
/*     */       
/* 542 */       if (shouldIgnoreHeadersOrDataFrame(ctx, streamId, parentStream, "PUSH_PROMISE")) {
/*     */         return;
/*     */       }
/*     */       
/* 546 */       switch (parentStream.state()) {
/*     */         case OPEN:
/*     */         case HALF_CLOSED_LOCAL:
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 553 */           throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Stream %d in unexpected state for receiving push promise: %s", new Object[] {
/*     */                 
/* 555 */                 Integer.valueOf(parentStream.id()), parentStream.state()
/*     */               });
/*     */       } 
/* 558 */       if (!DefaultHttp2ConnectionDecoder.this.requestVerifier.isAuthoritative(ctx, headers))
/* 559 */         throw Http2Exception.streamError(promisedStreamId, Http2Error.PROTOCOL_ERROR, "Promised request on stream %d for promised stream %d is not authoritative", new Object[] {
/*     */               
/* 561 */               Integer.valueOf(streamId), Integer.valueOf(promisedStreamId)
/*     */             }); 
/* 563 */       if (!DefaultHttp2ConnectionDecoder.this.requestVerifier.isCacheable(headers))
/* 564 */         throw Http2Exception.streamError(promisedStreamId, Http2Error.PROTOCOL_ERROR, "Promised request on stream %d for promised stream %d is not known to be cacheable", new Object[] {
/*     */               
/* 566 */               Integer.valueOf(streamId), Integer.valueOf(promisedStreamId)
/*     */             }); 
/* 568 */       if (!DefaultHttp2ConnectionDecoder.this.requestVerifier.isSafe(headers)) {
/* 569 */         throw Http2Exception.streamError(promisedStreamId, Http2Error.PROTOCOL_ERROR, "Promised request on stream %d for promised stream %d is not known to be safe", new Object[] {
/*     */               
/* 571 */               Integer.valueOf(streamId), Integer.valueOf(promisedStreamId)
/*     */             });
/*     */       }
/*     */       
/* 575 */       DefaultHttp2ConnectionDecoder.this.connection.remote().reservePushStream(promisedStreamId, parentStream);
/*     */       
/* 577 */       DefaultHttp2ConnectionDecoder.this.listener.onPushPromiseRead(ctx, streamId, promisedStreamId, headers, padding);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onGoAwayRead(ChannelHandlerContext ctx, int lastStreamId, long errorCode, ByteBuf debugData) throws Http2Exception {
/* 583 */       DefaultHttp2ConnectionDecoder.this.onGoAwayRead0(ctx, lastStreamId, errorCode, debugData);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onWindowUpdateRead(ChannelHandlerContext ctx, int streamId, int windowSizeIncrement) throws Http2Exception {
/* 589 */       Http2Stream stream = DefaultHttp2ConnectionDecoder.this.connection.stream(streamId);
/* 590 */       if (stream == null || stream.state() == Http2Stream.State.CLOSED || streamCreatedAfterGoAwaySent(streamId)) {
/*     */         
/* 592 */         verifyStreamMayHaveExisted(streamId);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 597 */       DefaultHttp2ConnectionDecoder.this.encoder.flowController().incrementWindowSize(stream, windowSizeIncrement);
/*     */       
/* 599 */       DefaultHttp2ConnectionDecoder.this.listener.onWindowUpdateRead(ctx, streamId, windowSizeIncrement);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onUnknownFrame(ChannelHandlerContext ctx, byte frameType, int streamId, Http2Flags flags, ByteBuf payload) throws Http2Exception {
/* 605 */       DefaultHttp2ConnectionDecoder.this.onUnknownFrame0(ctx, frameType, streamId, flags, payload);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean shouldIgnoreHeadersOrDataFrame(ChannelHandlerContext ctx, int streamId, Http2Stream stream, String frameName) throws Http2Exception {
/* 614 */       if (stream == null) {
/* 615 */         if (streamCreatedAfterGoAwaySent(streamId)) {
/* 616 */           DefaultHttp2ConnectionDecoder.logger.info("{} ignoring {} frame for stream {}. Stream sent after GOAWAY sent", new Object[] { ctx
/* 617 */                 .channel(), frameName, Integer.valueOf(streamId) });
/* 618 */           return true;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 623 */         verifyStreamMayHaveExisted(streamId);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 628 */         throw Http2Exception.streamError(streamId, Http2Error.STREAM_CLOSED, "Received %s frame for an unknown stream %d", new Object[] { frameName, 
/* 629 */               Integer.valueOf(streamId) });
/*     */       } 
/* 631 */       if (stream.isResetSent() || streamCreatedAfterGoAwaySent(streamId)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 637 */         if (DefaultHttp2ConnectionDecoder.logger.isInfoEnabled()) {
/* 638 */           DefaultHttp2ConnectionDecoder.logger.info("{} ignoring {} frame for stream {}", new Object[] { ctx.channel(), frameName, 
/* 639 */                 stream.isResetSent() ? "RST_STREAM sent." : ("Stream created after GOAWAY sent. Last known stream by peer " + 
/*     */                 
/* 641 */                 DefaultHttp2ConnectionDecoder.access$100(this.this$0).remote().lastStreamKnownByPeer()) });
/*     */         }
/*     */         
/* 644 */         return true;
/*     */       } 
/* 646 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean streamCreatedAfterGoAwaySent(int streamId) {
/* 662 */       Http2Connection.Endpoint<?> remote = DefaultHttp2ConnectionDecoder.this.connection.remote();
/* 663 */       return (DefaultHttp2ConnectionDecoder.this.connection.goAwaySent() && remote.isValidStreamId(streamId) && streamId > remote
/* 664 */         .lastStreamKnownByPeer());
/*     */     }
/*     */     
/*     */     private void verifyStreamMayHaveExisted(int streamId) throws Http2Exception {
/* 668 */       if (!DefaultHttp2ConnectionDecoder.this.connection.streamMayHaveExisted(streamId)) {
/* 669 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Stream %d does not exist", new Object[] { Integer.valueOf(streamId) });
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class PrefaceFrameListener
/*     */     implements Http2FrameListener
/*     */   {
/*     */     private PrefaceFrameListener() {}
/*     */ 
/*     */     
/*     */     private void verifyPrefaceReceived() throws Http2Exception {
/* 682 */       if (!DefaultHttp2ConnectionDecoder.this.prefaceReceived()) {
/* 683 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Received non-SETTINGS as first frame.", new Object[0]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int onDataRead(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream) throws Http2Exception {
/* 690 */       verifyPrefaceReceived();
/* 691 */       return DefaultHttp2ConnectionDecoder.this.internalFrameListener.onDataRead(ctx, streamId, data, padding, endOfStream);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endOfStream) throws Http2Exception {
/* 697 */       verifyPrefaceReceived();
/* 698 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onHeadersRead(ctx, streamId, headers, padding, endOfStream);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream) throws Http2Exception {
/* 704 */       verifyPrefaceReceived();
/* 705 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onHeadersRead(ctx, streamId, headers, streamDependency, weight, exclusive, padding, endOfStream);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onPriorityRead(ChannelHandlerContext ctx, int streamId, int streamDependency, short weight, boolean exclusive) throws Http2Exception {
/* 712 */       verifyPrefaceReceived();
/* 713 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onPriorityRead(ctx, streamId, streamDependency, weight, exclusive);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onRstStreamRead(ChannelHandlerContext ctx, int streamId, long errorCode) throws Http2Exception {
/* 718 */       verifyPrefaceReceived();
/* 719 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onRstStreamRead(ctx, streamId, errorCode);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSettingsAckRead(ChannelHandlerContext ctx) throws Http2Exception {
/* 724 */       verifyPrefaceReceived();
/* 725 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onSettingsAckRead(ctx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSettingsRead(ChannelHandlerContext ctx, Http2Settings settings) throws Http2Exception {
/* 732 */       if (!DefaultHttp2ConnectionDecoder.this.prefaceReceived()) {
/* 733 */         DefaultHttp2ConnectionDecoder.this.internalFrameListener = new DefaultHttp2ConnectionDecoder.FrameReadListener();
/*     */       }
/* 735 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onSettingsRead(ctx, settings);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onPingRead(ChannelHandlerContext ctx, long data) throws Http2Exception {
/* 740 */       verifyPrefaceReceived();
/* 741 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onPingRead(ctx, data);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onPingAckRead(ChannelHandlerContext ctx, long data) throws Http2Exception {
/* 746 */       verifyPrefaceReceived();
/* 747 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onPingAckRead(ctx, data);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onPushPromiseRead(ChannelHandlerContext ctx, int streamId, int promisedStreamId, Http2Headers headers, int padding) throws Http2Exception {
/* 753 */       verifyPrefaceReceived();
/* 754 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onPushPromiseRead(ctx, streamId, promisedStreamId, headers, padding);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onGoAwayRead(ChannelHandlerContext ctx, int lastStreamId, long errorCode, ByteBuf debugData) throws Http2Exception {
/* 760 */       DefaultHttp2ConnectionDecoder.this.onGoAwayRead0(ctx, lastStreamId, errorCode, debugData);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onWindowUpdateRead(ChannelHandlerContext ctx, int streamId, int windowSizeIncrement) throws Http2Exception {
/* 766 */       verifyPrefaceReceived();
/* 767 */       DefaultHttp2ConnectionDecoder.this.internalFrameListener.onWindowUpdateRead(ctx, streamId, windowSizeIncrement);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onUnknownFrame(ChannelHandlerContext ctx, byte frameType, int streamId, Http2Flags flags, ByteBuf payload) throws Http2Exception {
/* 773 */       DefaultHttp2ConnectionDecoder.this.onUnknownFrame0(ctx, frameType, streamId, flags, payload);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ContentLength {
/*     */     private final long expected;
/*     */     private long seen;
/*     */     
/*     */     ContentLength(long expected) {
/* 782 */       this.expected = expected;
/*     */     }
/*     */     
/*     */     void increaseReceivedBytes(boolean server, int streamId, int bytes, boolean isEnd) throws Http2Exception {
/* 786 */       this.seen += bytes;
/*     */       
/* 788 */       if (this.seen < 0L) {
/* 789 */         throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Received amount of data did overflow and so not match content-length header %d", new Object[] {
/* 790 */               Long.valueOf(this.expected)
/*     */             });
/*     */       }
/* 793 */       if (this.seen > this.expected) {
/* 794 */         throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Received amount of data %d does not match content-length header %d", new Object[] {
/* 795 */               Long.valueOf(this.seen), Long.valueOf(this.expected)
/*     */             });
/*     */       }
/* 798 */       if (isEnd) {
/* 799 */         if (this.seen == 0L && !server) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 805 */         if (this.expected > this.seen)
/* 806 */           throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Received amount of data %d does not match content-length header %d", new Object[] {
/* 807 */                 Long.valueOf(this.seen), Long.valueOf(this.expected)
/*     */               }); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2ConnectionDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */