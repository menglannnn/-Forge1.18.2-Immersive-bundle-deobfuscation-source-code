/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ import io.netty.util.internal.StringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultHttp2SettingsAckFrame
/*    */   implements Http2SettingsAckFrame
/*    */ {
/*    */   public String name() {
/* 26 */     return "SETTINGS(ACK)";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 31 */     return StringUtil.simpleClassName(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2SettingsAckFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */