/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.channel.ChannelHandlerAdapter;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.logging.LogLevel;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.logging.InternalLogLevel;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Http2FrameLogger
/*     */   extends ChannelHandlerAdapter
/*     */ {
/*     */   private static final int BUFFER_LENGTH_THRESHOLD = 64;
/*     */   private final InternalLogger logger;
/*     */   private final InternalLogLevel level;
/*     */   
/*     */   public enum Direction
/*     */   {
/*  37 */     INBOUND,
/*  38 */     OUTBOUND;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2FrameLogger(LogLevel level) {
/*  46 */     this(checkAndConvertLevel(level), InternalLoggerFactory.getInstance(Http2FrameLogger.class));
/*     */   }
/*     */   
/*     */   public Http2FrameLogger(LogLevel level, String name) {
/*  50 */     this(checkAndConvertLevel(level), InternalLoggerFactory.getInstance((String)ObjectUtil.checkNotNull(name, "name")));
/*     */   }
/*     */   
/*     */   public Http2FrameLogger(LogLevel level, Class<?> clazz) {
/*  54 */     this(checkAndConvertLevel(level), InternalLoggerFactory.getInstance((Class)ObjectUtil.checkNotNull(clazz, "clazz")));
/*     */   }
/*     */   
/*     */   private Http2FrameLogger(InternalLogLevel level, InternalLogger logger) {
/*  58 */     this.level = level;
/*  59 */     this.logger = logger;
/*     */   }
/*     */   
/*     */   private static InternalLogLevel checkAndConvertLevel(LogLevel level) {
/*  63 */     return ((LogLevel)ObjectUtil.checkNotNull(level, "level")).toInternalLevel();
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  67 */     return this.logger.isEnabled(this.level);
/*     */   }
/*     */ 
/*     */   
/*     */   public void logData(Direction direction, ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endStream) {
/*  72 */     if (isEnabled()) {
/*  73 */       this.logger.log(this.level, "{} {} DATA: streamId={} padding={} endStream={} length={} bytes={}", new Object[] { ctx.channel(), direction
/*  74 */             .name(), Integer.valueOf(streamId), Integer.valueOf(padding), Boolean.valueOf(endStream), Integer.valueOf(data.readableBytes()), toString(data) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void logHeaders(Direction direction, ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endStream) {
/*  80 */     if (isEnabled()) {
/*  81 */       this.logger.log(this.level, "{} {} HEADERS: streamId={} headers={} padding={} endStream={}", new Object[] { ctx.channel(), direction
/*  82 */             .name(), Integer.valueOf(streamId), headers, Integer.valueOf(padding), Boolean.valueOf(endStream) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void logHeaders(Direction direction, ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endStream) {
/*  88 */     if (isEnabled()) {
/*  89 */       this.logger.log(this.level, "{} {} HEADERS: streamId={} headers={} streamDependency={} weight={} exclusive={} padding={} endStream={}", new Object[] { ctx
/*  90 */             .channel(), direction
/*  91 */             .name(), Integer.valueOf(streamId), headers, Integer.valueOf(streamDependency), Short.valueOf(weight), Boolean.valueOf(exclusive), Integer.valueOf(padding), Boolean.valueOf(endStream) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void logPriority(Direction direction, ChannelHandlerContext ctx, int streamId, int streamDependency, short weight, boolean exclusive) {
/*  97 */     if (isEnabled()) {
/*  98 */       this.logger.log(this.level, "{} {} PRIORITY: streamId={} streamDependency={} weight={} exclusive={}", new Object[] { ctx.channel(), direction
/*  99 */             .name(), Integer.valueOf(streamId), Integer.valueOf(streamDependency), Short.valueOf(weight), Boolean.valueOf(exclusive) });
/*     */     }
/*     */   }
/*     */   
/*     */   public void logRstStream(Direction direction, ChannelHandlerContext ctx, int streamId, long errorCode) {
/* 104 */     if (isEnabled()) {
/* 105 */       this.logger.log(this.level, "{} {} RST_STREAM: streamId={} errorCode={}", new Object[] { ctx.channel(), direction
/* 106 */             .name(), Integer.valueOf(streamId), Long.valueOf(errorCode) });
/*     */     }
/*     */   }
/*     */   
/*     */   public void logSettingsAck(Direction direction, ChannelHandlerContext ctx) {
/* 111 */     this.logger.log(this.level, "{} {} SETTINGS: ack=true", ctx.channel(), direction.name());
/*     */   }
/*     */   
/*     */   public void logSettings(Direction direction, ChannelHandlerContext ctx, Http2Settings settings) {
/* 115 */     if (isEnabled()) {
/* 116 */       this.logger.log(this.level, "{} {} SETTINGS: ack=false settings={}", new Object[] { ctx.channel(), direction.name(), settings });
/*     */     }
/*     */   }
/*     */   
/*     */   public void logPing(Direction direction, ChannelHandlerContext ctx, long data) {
/* 121 */     if (isEnabled()) {
/* 122 */       this.logger.log(this.level, "{} {} PING: ack=false bytes={}", new Object[] { ctx.channel(), direction
/* 123 */             .name(), Long.valueOf(data) });
/*     */     }
/*     */   }
/*     */   
/*     */   public void logPingAck(Direction direction, ChannelHandlerContext ctx, long data) {
/* 128 */     if (isEnabled()) {
/* 129 */       this.logger.log(this.level, "{} {} PING: ack=true bytes={}", new Object[] { ctx.channel(), direction
/* 130 */             .name(), Long.valueOf(data) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void logPushPromise(Direction direction, ChannelHandlerContext ctx, int streamId, int promisedStreamId, Http2Headers headers, int padding) {
/* 136 */     if (isEnabled()) {
/* 137 */       this.logger.log(this.level, "{} {} PUSH_PROMISE: streamId={} promisedStreamId={} headers={} padding={}", new Object[] { ctx
/* 138 */             .channel(), direction.name(), Integer.valueOf(streamId), Integer.valueOf(promisedStreamId), headers, Integer.valueOf(padding) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void logGoAway(Direction direction, ChannelHandlerContext ctx, int lastStreamId, long errorCode, ByteBuf debugData) {
/* 144 */     if (isEnabled()) {
/* 145 */       this.logger.log(this.level, "{} {} GO_AWAY: lastStreamId={} errorCode={} length={} bytes={}", new Object[] { ctx.channel(), direction
/* 146 */             .name(), Integer.valueOf(lastStreamId), Long.valueOf(errorCode), Integer.valueOf(debugData.readableBytes()), toString(debugData) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void logWindowsUpdate(Direction direction, ChannelHandlerContext ctx, int streamId, int windowSizeIncrement) {
/* 152 */     if (isEnabled()) {
/* 153 */       this.logger.log(this.level, "{} {} WINDOW_UPDATE: streamId={} windowSizeIncrement={}", new Object[] { ctx.channel(), direction
/* 154 */             .name(), Integer.valueOf(streamId), Integer.valueOf(windowSizeIncrement) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void logUnknownFrame(Direction direction, ChannelHandlerContext ctx, byte frameType, int streamId, Http2Flags flags, ByteBuf data) {
/* 160 */     if (isEnabled()) {
/* 161 */       this.logger.log(this.level, "{} {} UNKNOWN: frameType={} streamId={} flags={} length={} bytes={}", new Object[] { ctx.channel(), direction
/* 162 */             .name(), Integer.valueOf(frameType & 0xFF), Integer.valueOf(streamId), Short.valueOf(flags.value()), Integer.valueOf(data.readableBytes()), toString(data) });
/*     */     }
/*     */   }
/*     */   
/*     */   private String toString(ByteBuf buf) {
/* 167 */     if (this.level == InternalLogLevel.TRACE || buf.readableBytes() <= 64)
/*     */     {
/* 169 */       return ByteBufUtil.hexDump(buf);
/*     */     }
/*     */ 
/*     */     
/* 173 */     int length = Math.min(buf.readableBytes(), 64);
/* 174 */     return ByteBufUtil.hexDump(buf, buf.readerIndex(), length) + "...";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2FrameLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */