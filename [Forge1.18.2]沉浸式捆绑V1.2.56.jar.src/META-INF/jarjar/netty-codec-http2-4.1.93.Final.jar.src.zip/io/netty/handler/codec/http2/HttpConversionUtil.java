/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.handler.codec.Headers;
/*     */ import io.netty.handler.codec.UnsupportedValueConverter;
/*     */ import io.netty.handler.codec.ValueConverter;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpRequest;
/*     */ import io.netty.handler.codec.http.DefaultFullHttpResponse;
/*     */ import io.netty.handler.codec.http.DefaultHttpRequest;
/*     */ import io.netty.handler.codec.http.DefaultHttpResponse;
/*     */ import io.netty.handler.codec.http.FullHttpMessage;
/*     */ import io.netty.handler.codec.http.FullHttpRequest;
/*     */ import io.netty.handler.codec.http.FullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpHeaderValues;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpMethod;
/*     */ import io.netty.handler.codec.http.HttpRequest;
/*     */ import io.netty.handler.codec.http.HttpResponse;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.HttpScheme;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.handler.codec.http.HttpVersion;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.ByteProcessor;
/*     */ import io.netty.util.internal.InternalThreadLocalMap;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import java.net.URI;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpConversionUtil
/*     */ {
/*  76 */   private static final CharSequenceMap<AsciiString> HTTP_TO_HTTP2_HEADER_BLACKLIST = new CharSequenceMap<AsciiString>();
/*     */   
/*     */   static {
/*  79 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(HttpHeaderNames.CONNECTION, AsciiString.EMPTY_STRING);
/*     */     
/*  81 */     AsciiString keepAlive = HttpHeaderNames.KEEP_ALIVE;
/*  82 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(keepAlive, AsciiString.EMPTY_STRING);
/*     */     
/*  84 */     AsciiString proxyConnection = HttpHeaderNames.PROXY_CONNECTION;
/*  85 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(proxyConnection, AsciiString.EMPTY_STRING);
/*  86 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(HttpHeaderNames.TRANSFER_ENCODING, AsciiString.EMPTY_STRING);
/*  87 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(HttpHeaderNames.HOST, AsciiString.EMPTY_STRING);
/*  88 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(HttpHeaderNames.UPGRADE, AsciiString.EMPTY_STRING);
/*  89 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(ExtensionHeaderNames.STREAM_ID.text(), AsciiString.EMPTY_STRING);
/*  90 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(ExtensionHeaderNames.SCHEME.text(), AsciiString.EMPTY_STRING);
/*  91 */     HTTP_TO_HTTP2_HEADER_BLACKLIST.add(ExtensionHeaderNames.PATH.text(), AsciiString.EMPTY_STRING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public static final HttpMethod OUT_OF_MESSAGE_SEQUENCE_METHOD = HttpMethod.OPTIONS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String OUT_OF_MESSAGE_SEQUENCE_PATH = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public static final HttpResponseStatus OUT_OF_MESSAGE_SEQUENCE_RETURN_CODE = HttpResponseStatus.OK;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private static final AsciiString EMPTY_REQUEST_PATH = AsciiString.cached("/");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ExtensionHeaderNames
/*     */   {
/* 131 */     STREAM_ID("x-http2-stream-id"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     SCHEME("x-http2-scheme"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     PATH("x-http2-path"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     STREAM_PROMISE_ID("x-http2-stream-promise-id"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     STREAM_DEPENDENCY_ID("x-http2-stream-dependency-id"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     STREAM_WEIGHT("x-http2-stream-weight");
/*     */     
/*     */     private final AsciiString text;
/*     */     
/*     */     ExtensionHeaderNames(String text) {
/* 171 */       this.text = AsciiString.cached(text);
/*     */     }
/*     */     
/*     */     public AsciiString text() {
/* 175 */       return this.text;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpResponseStatus parseStatus(CharSequence status) throws Http2Exception {
/*     */     HttpResponseStatus result;
/*     */     try {
/* 189 */       result = HttpResponseStatus.parseLine(status);
/* 190 */       if (result == HttpResponseStatus.SWITCHING_PROTOCOLS) {
/* 191 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Invalid HTTP/2 status code '%d'", new Object[] { Integer.valueOf(result.code()) });
/*     */       }
/* 193 */     } catch (Http2Exception e) {
/* 194 */       throw e;
/* 195 */     } catch (Throwable t) {
/* 196 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, t, "Unrecognized HTTP status code '%s' encountered in translation to HTTP/1.x", new Object[] { status });
/*     */     } 
/*     */     
/* 199 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FullHttpResponse toFullHttpResponse(int streamId, Http2Headers http2Headers, ByteBufAllocator alloc, boolean validateHttpHeaders) throws Http2Exception {
/* 217 */     return toFullHttpResponse(streamId, http2Headers, alloc.buffer(), validateHttpHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FullHttpResponse toFullHttpResponse(int streamId, Http2Headers http2Headers, ByteBuf content, boolean validateHttpHeaders) throws Http2Exception {
/* 236 */     HttpResponseStatus status = parseStatus(http2Headers.status());
/*     */ 
/*     */     
/* 239 */     DefaultFullHttpResponse defaultFullHttpResponse = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, status, content, validateHttpHeaders);
/*     */     
/*     */     try {
/* 242 */       addHttp2ToHttpHeaders(streamId, http2Headers, (FullHttpMessage)defaultFullHttpResponse, false);
/* 243 */     } catch (Http2Exception e) {
/* 244 */       defaultFullHttpResponse.release();
/* 245 */       throw e;
/* 246 */     } catch (Throwable t) {
/* 247 */       defaultFullHttpResponse.release();
/* 248 */       throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, t, "HTTP/2 to HTTP/1.x headers conversion error", new Object[0]);
/*     */     } 
/* 250 */     return (FullHttpResponse)defaultFullHttpResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FullHttpRequest toFullHttpRequest(int streamId, Http2Headers http2Headers, ByteBufAllocator alloc, boolean validateHttpHeaders) throws Http2Exception {
/* 268 */     return toFullHttpRequest(streamId, http2Headers, alloc.buffer(), validateHttpHeaders);
/*     */   }
/*     */   
/*     */   private static String extractPath(CharSequence method, Http2Headers headers) {
/* 272 */     if (HttpMethod.CONNECT.asciiName().contentEqualsIgnoreCase(method))
/*     */     {
/* 274 */       return ((CharSequence)ObjectUtil.checkNotNull(headers.authority(), "authority header cannot be null in the conversion to HTTP/1.x"))
/* 275 */         .toString();
/*     */     }
/* 277 */     return ((CharSequence)ObjectUtil.checkNotNull(headers.path(), "path header cannot be null in conversion to HTTP/1.x"))
/* 278 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FullHttpRequest toFullHttpRequest(int streamId, Http2Headers http2Headers, ByteBuf content, boolean validateHttpHeaders) throws Http2Exception {
/* 298 */     CharSequence method = (CharSequence)ObjectUtil.checkNotNull(http2Headers.method(), "method header cannot be null in conversion to HTTP/1.x");
/*     */     
/* 300 */     CharSequence path = extractPath(method, http2Headers);
/*     */     
/* 302 */     DefaultFullHttpRequest defaultFullHttpRequest = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.valueOf(method.toString()), path.toString(), content, validateHttpHeaders);
/*     */     try {
/* 304 */       addHttp2ToHttpHeaders(streamId, http2Headers, (FullHttpMessage)defaultFullHttpRequest, false);
/* 305 */     } catch (Http2Exception e) {
/* 306 */       defaultFullHttpRequest.release();
/* 307 */       throw e;
/* 308 */     } catch (Throwable t) {
/* 309 */       defaultFullHttpRequest.release();
/* 310 */       throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, t, "HTTP/2 to HTTP/1.x headers conversion error", new Object[0]);
/*     */     } 
/* 312 */     return (FullHttpRequest)defaultFullHttpRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpRequest toHttpRequest(int streamId, Http2Headers http2Headers, boolean validateHttpHeaders) throws Http2Exception {
/* 330 */     CharSequence method = (CharSequence)ObjectUtil.checkNotNull(http2Headers.method(), "method header cannot be null in conversion to HTTP/1.x");
/*     */     
/* 332 */     CharSequence path = extractPath(method, http2Headers);
/*     */     
/* 334 */     DefaultHttpRequest defaultHttpRequest = new DefaultHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.valueOf(method.toString()), path.toString(), validateHttpHeaders);
/*     */     try {
/* 336 */       addHttp2ToHttpHeaders(streamId, http2Headers, defaultHttpRequest.headers(), defaultHttpRequest.protocolVersion(), false, true);
/* 337 */     } catch (Http2Exception e) {
/* 338 */       throw e;
/* 339 */     } catch (Throwable t) {
/* 340 */       throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, t, "HTTP/2 to HTTP/1.x headers conversion error", new Object[0]);
/*     */     } 
/* 342 */     return (HttpRequest)defaultHttpRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpResponse toHttpResponse(int streamId, Http2Headers http2Headers, boolean validateHttpHeaders) throws Http2Exception {
/* 361 */     HttpResponseStatus status = parseStatus(http2Headers.status());
/*     */ 
/*     */     
/* 364 */     DefaultHttpResponse defaultHttpResponse = new DefaultHttpResponse(HttpVersion.HTTP_1_1, status, validateHttpHeaders);
/*     */     try {
/* 366 */       addHttp2ToHttpHeaders(streamId, http2Headers, defaultHttpResponse.headers(), defaultHttpResponse.protocolVersion(), false, false);
/* 367 */     } catch (Http2Exception e) {
/* 368 */       throw e;
/* 369 */     } catch (Throwable t) {
/* 370 */       throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, t, "HTTP/2 to HTTP/1.x headers conversion error", new Object[0]);
/*     */     } 
/* 372 */     return (HttpResponse)defaultHttpResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addHttp2ToHttpHeaders(int streamId, Http2Headers inputHeaders, FullHttpMessage destinationMessage, boolean addToTrailer) throws Http2Exception {
/* 387 */     addHttp2ToHttpHeaders(streamId, inputHeaders, addToTrailer ? destinationMessage
/* 388 */         .trailingHeaders() : destinationMessage.headers(), destinationMessage
/* 389 */         .protocolVersion(), addToTrailer, destinationMessage instanceof HttpRequest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addHttp2ToHttpHeaders(int streamId, Http2Headers inputHeaders, HttpHeaders outputHeaders, HttpVersion httpVersion, boolean isTrailer, boolean isRequest) throws Http2Exception {
/* 407 */     Http2ToHttpHeaderTranslator translator = new Http2ToHttpHeaderTranslator(streamId, outputHeaders, isRequest);
/*     */     try {
/* 409 */       translator.translateHeaders((Iterable<Map.Entry<CharSequence, CharSequence>>)inputHeaders);
/* 410 */     } catch (Http2Exception ex) {
/* 411 */       throw ex;
/* 412 */     } catch (Throwable t) {
/* 413 */       throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, t, "HTTP/2 to HTTP/1.x headers conversion error", new Object[0]);
/*     */     } 
/*     */     
/* 416 */     outputHeaders.remove((CharSequence)HttpHeaderNames.TRANSFER_ENCODING);
/* 417 */     outputHeaders.remove((CharSequence)HttpHeaderNames.TRAILER);
/* 418 */     if (!isTrailer) {
/* 419 */       outputHeaders.setInt((CharSequence)ExtensionHeaderNames.STREAM_ID.text(), streamId);
/* 420 */       HttpUtil.setKeepAlive(outputHeaders, httpVersion, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2Headers toHttp2Headers(HttpMessage in, boolean validateHeaders) {
/* 434 */     HttpHeaders inHeaders = in.headers();
/* 435 */     Http2Headers out = new DefaultHttp2Headers(validateHeaders, inHeaders.size());
/* 436 */     if (in instanceof HttpRequest) {
/* 437 */       HttpRequest request = (HttpRequest)in;
/* 438 */       String host = inHeaders.getAsString((CharSequence)HttpHeaderNames.HOST);
/* 439 */       if (HttpUtil.isOriginForm(request.uri()) || HttpUtil.isAsteriskForm(request.uri())) {
/* 440 */         out.path((CharSequence)new AsciiString(request.uri()));
/* 441 */         setHttp2Scheme(inHeaders, out);
/*     */       } else {
/* 443 */         URI requestTargetUri = URI.create(request.uri());
/* 444 */         out.path((CharSequence)toHttp2Path(requestTargetUri));
/*     */         
/* 446 */         host = StringUtil.isNullOrEmpty(host) ? requestTargetUri.getAuthority() : host;
/* 447 */         setHttp2Scheme(inHeaders, requestTargetUri, out);
/*     */       } 
/* 449 */       setHttp2Authority(host, out);
/* 450 */       out.method((CharSequence)request.method().asciiName());
/* 451 */     } else if (in instanceof HttpResponse) {
/* 452 */       HttpResponse response = (HttpResponse)in;
/* 453 */       out.status((CharSequence)response.status().codeAsText());
/*     */     } 
/*     */ 
/*     */     
/* 457 */     toHttp2Headers(inHeaders, out);
/* 458 */     return out;
/*     */   }
/*     */   
/*     */   public static Http2Headers toHttp2Headers(HttpHeaders inHeaders, boolean validateHeaders) {
/* 462 */     if (inHeaders.isEmpty()) {
/* 463 */       return EmptyHttp2Headers.INSTANCE;
/*     */     }
/*     */     
/* 466 */     Http2Headers out = new DefaultHttp2Headers(validateHeaders, inHeaders.size());
/* 467 */     toHttp2Headers(inHeaders, out);
/* 468 */     return out;
/*     */   }
/*     */ 
/*     */   
/*     */   private static CharSequenceMap<AsciiString> toLowercaseMap(Iterator<? extends CharSequence> valuesIter, int arraySizeHint) {
/* 473 */     UnsupportedValueConverter<AsciiString> valueConverter = UnsupportedValueConverter.instance();
/* 474 */     CharSequenceMap<AsciiString> result = new CharSequenceMap<AsciiString>(true, (ValueConverter<AsciiString>)valueConverter, arraySizeHint);
/*     */     
/* 476 */     while (valuesIter.hasNext()) {
/* 477 */       AsciiString lowerCased = AsciiString.of(valuesIter.next()).toLowerCase();
/*     */       try {
/* 479 */         int index = lowerCased.forEachByte(ByteProcessor.FIND_COMMA);
/* 480 */         if (index != -1) {
/* 481 */           int start = 0;
/*     */           do {
/* 483 */             result.add(lowerCased.subSequence(start, index, false).trim(), AsciiString.EMPTY_STRING);
/* 484 */             start = index + 1;
/* 485 */           } while (start < lowerCased.length() && (
/* 486 */             index = lowerCased.forEachByte(start, lowerCased.length() - start, ByteProcessor.FIND_COMMA)) != -1);
/* 487 */           result.add(lowerCased.subSequence(start, lowerCased.length(), false).trim(), AsciiString.EMPTY_STRING); continue;
/*     */         } 
/* 489 */         result.add(lowerCased.trim(), AsciiString.EMPTY_STRING);
/*     */       }
/* 491 */       catch (Exception e) {
/*     */ 
/*     */         
/* 494 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     } 
/* 497 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void toHttp2HeadersFilterTE(Map.Entry<CharSequence, CharSequence> entry, Http2Headers out) {
/* 508 */     if (AsciiString.indexOf(entry.getValue(), ',', 0) == -1) {
/* 509 */       if (AsciiString.contentEqualsIgnoreCase(AsciiString.trim(entry.getValue()), (CharSequence)HttpHeaderValues.TRAILERS)) {
/* 510 */         out.add(HttpHeaderNames.TE, HttpHeaderValues.TRAILERS);
/*     */       }
/*     */     } else {
/* 513 */       List<CharSequence> teValues = StringUtil.unescapeCsvFields(entry.getValue());
/* 514 */       for (CharSequence teValue : teValues) {
/* 515 */         if (AsciiString.contentEqualsIgnoreCase(AsciiString.trim(teValue), (CharSequence)HttpHeaderValues.TRAILERS)) {
/* 516 */           out.add(HttpHeaderNames.TE, HttpHeaderValues.TRAILERS);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void toHttp2Headers(HttpHeaders inHeaders, Http2Headers out) {
/* 524 */     Iterator<Map.Entry<CharSequence, CharSequence>> iter = inHeaders.iteratorCharSequence();
/*     */ 
/*     */ 
/*     */     
/* 528 */     CharSequenceMap<AsciiString> connectionBlacklist = toLowercaseMap(inHeaders.valueCharSequenceIterator((CharSequence)HttpHeaderNames.CONNECTION), 8);
/* 529 */     while (iter.hasNext()) {
/* 530 */       Map.Entry<CharSequence, CharSequence> entry = iter.next();
/* 531 */       AsciiString aName = AsciiString.of(entry.getKey()).toLowerCase();
/* 532 */       if (!HTTP_TO_HTTP2_HEADER_BLACKLIST.contains(aName) && !connectionBlacklist.contains(aName)) {
/*     */         
/* 534 */         if (aName.contentEqualsIgnoreCase((CharSequence)HttpHeaderNames.TE)) {
/* 535 */           toHttp2HeadersFilterTE(entry, out); continue;
/* 536 */         }  if (aName.contentEqualsIgnoreCase((CharSequence)HttpHeaderNames.COOKIE)) {
/* 537 */           AsciiString value = AsciiString.of(entry.getValue());
/*     */ 
/*     */           
/*     */           try {
/* 541 */             int index = value.forEachByte(ByteProcessor.FIND_SEMI_COLON);
/* 542 */             if (index != -1) {
/* 543 */               int start = 0;
/*     */               do {
/* 545 */                 out.add(HttpHeaderNames.COOKIE, value.subSequence(start, index, false));
/*     */                 
/* 547 */                 start = index + 2;
/* 548 */               } while (start < value.length() && (
/* 549 */                 index = value.forEachByte(start, value.length() - start, ByteProcessor.FIND_SEMI_COLON)) != -1);
/* 550 */               if (start >= value.length()) {
/* 551 */                 throw new IllegalArgumentException("cookie value is of unexpected format: " + value);
/*     */               }
/* 553 */               out.add(HttpHeaderNames.COOKIE, value.subSequence(start, value.length(), false)); continue;
/*     */             } 
/* 555 */             out.add(HttpHeaderNames.COOKIE, value);
/*     */           }
/* 557 */           catch (Exception e) {
/*     */ 
/*     */             
/* 560 */             throw new IllegalStateException(e);
/*     */           }  continue;
/*     */         } 
/* 563 */         out.add(aName, entry.getValue());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AsciiString toHttp2Path(URI uri) {
/* 575 */     StringBuilder pathBuilder = new StringBuilder(StringUtil.length(uri.getRawPath()) + StringUtil.length(uri.getRawQuery()) + StringUtil.length(uri.getRawFragment()) + 2);
/* 576 */     if (!StringUtil.isNullOrEmpty(uri.getRawPath())) {
/* 577 */       pathBuilder.append(uri.getRawPath());
/*     */     }
/* 579 */     if (!StringUtil.isNullOrEmpty(uri.getRawQuery())) {
/* 580 */       pathBuilder.append('?');
/* 581 */       pathBuilder.append(uri.getRawQuery());
/*     */     } 
/* 583 */     if (!StringUtil.isNullOrEmpty(uri.getRawFragment())) {
/* 584 */       pathBuilder.append('#');
/* 585 */       pathBuilder.append(uri.getRawFragment());
/*     */     } 
/* 587 */     String path = pathBuilder.toString();
/* 588 */     return path.isEmpty() ? EMPTY_REQUEST_PATH : new AsciiString(path);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void setHttp2Authority(String authority, Http2Headers out) {
/* 594 */     if (authority != null) {
/* 595 */       if (authority.isEmpty()) {
/* 596 */         out.authority((CharSequence)AsciiString.EMPTY_STRING);
/*     */       } else {
/* 598 */         int start = authority.indexOf('@') + 1;
/* 599 */         int length = authority.length() - start;
/* 600 */         if (length == 0) {
/* 601 */           throw new IllegalArgumentException("authority: " + authority);
/*     */         }
/* 603 */         out.authority((CharSequence)new AsciiString(authority, start, length));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static void setHttp2Scheme(HttpHeaders in, Http2Headers out) {
/* 609 */     setHttp2Scheme(in, URI.create(""), out);
/*     */   }
/*     */   
/*     */   private static void setHttp2Scheme(HttpHeaders in, URI uri, Http2Headers out) {
/* 613 */     String value = uri.getScheme();
/* 614 */     if (!StringUtil.isNullOrEmpty(value)) {
/* 615 */       out.scheme((CharSequence)new AsciiString(value));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 620 */     CharSequence cValue = in.get((CharSequence)ExtensionHeaderNames.SCHEME.text());
/* 621 */     if (cValue != null) {
/* 622 */       out.scheme((CharSequence)AsciiString.of(cValue));
/*     */       
/*     */       return;
/*     */     } 
/* 626 */     if (uri.getPort() == HttpScheme.HTTPS.port()) {
/* 627 */       out.scheme((CharSequence)HttpScheme.HTTPS.name());
/* 628 */     } else if (uri.getPort() == HttpScheme.HTTP.port()) {
/* 629 */       out.scheme((CharSequence)HttpScheme.HTTP.name());
/*     */     } else {
/* 631 */       throw new IllegalArgumentException(":scheme must be specified. see https://tools.ietf.org/html/rfc7540#section-8.1.2.3");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Http2ToHttpHeaderTranslator
/*     */   {
/* 644 */     private static final CharSequenceMap<AsciiString> REQUEST_HEADER_TRANSLATIONS = new CharSequenceMap<AsciiString>();
/*     */     
/* 646 */     private static final CharSequenceMap<AsciiString> RESPONSE_HEADER_TRANSLATIONS = new CharSequenceMap<AsciiString>(); private final int streamId;
/*     */     static {
/* 648 */       RESPONSE_HEADER_TRANSLATIONS.add(Http2Headers.PseudoHeaderName.AUTHORITY.value(), HttpHeaderNames.HOST);
/*     */       
/* 650 */       RESPONSE_HEADER_TRANSLATIONS.add(Http2Headers.PseudoHeaderName.SCHEME.value(), HttpConversionUtil.ExtensionHeaderNames.SCHEME
/* 651 */           .text());
/* 652 */       REQUEST_HEADER_TRANSLATIONS.add((Headers)RESPONSE_HEADER_TRANSLATIONS);
/* 653 */       RESPONSE_HEADER_TRANSLATIONS.add(Http2Headers.PseudoHeaderName.PATH.value(), HttpConversionUtil.ExtensionHeaderNames.PATH
/* 654 */           .text());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final HttpHeaders output;
/*     */ 
/*     */ 
/*     */     
/*     */     private final CharSequenceMap<AsciiString> translations;
/*     */ 
/*     */ 
/*     */     
/*     */     Http2ToHttpHeaderTranslator(int streamId, HttpHeaders output, boolean request) {
/* 669 */       this.streamId = streamId;
/* 670 */       this.output = output;
/* 671 */       this.translations = request ? REQUEST_HEADER_TRANSLATIONS : RESPONSE_HEADER_TRANSLATIONS;
/*     */     }
/*     */ 
/*     */     
/*     */     void translateHeaders(Iterable<Map.Entry<CharSequence, CharSequence>> inputHeaders) throws Http2Exception {
/* 676 */       StringBuilder cookies = null;
/*     */       
/* 678 */       for (Map.Entry<CharSequence, CharSequence> entry : inputHeaders) {
/* 679 */         CharSequence name = entry.getKey();
/* 680 */         CharSequence value = entry.getValue();
/* 681 */         AsciiString translatedName = (AsciiString)this.translations.get(name);
/* 682 */         if (translatedName != null) {
/* 683 */           this.output.add((CharSequence)translatedName, AsciiString.of(value)); continue;
/* 684 */         }  if (!Http2Headers.PseudoHeaderName.isPseudoHeader(name)) {
/*     */ 
/*     */           
/* 687 */           if (name.length() == 0 || name.charAt(0) == ':') {
/* 688 */             throw Http2Exception.streamError(this.streamId, Http2Error.PROTOCOL_ERROR, "Invalid HTTP/2 header '%s' encountered in translation to HTTP/1.x", new Object[] { name });
/*     */           }
/*     */           
/* 691 */           if (HttpHeaderNames.COOKIE.equals(name)) {
/*     */ 
/*     */             
/* 694 */             if (cookies == null) {
/* 695 */               cookies = InternalThreadLocalMap.get().stringBuilder();
/* 696 */             } else if (cookies.length() > 0) {
/* 697 */               cookies.append("; ");
/*     */             } 
/* 699 */             cookies.append(value); continue;
/*     */           } 
/* 701 */           this.output.add(name, value);
/*     */         } 
/*     */       } 
/*     */       
/* 705 */       if (cookies != null)
/* 706 */         this.output.add((CharSequence)HttpHeaderNames.COOKIE, cookies.toString()); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\HttpConversionUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */