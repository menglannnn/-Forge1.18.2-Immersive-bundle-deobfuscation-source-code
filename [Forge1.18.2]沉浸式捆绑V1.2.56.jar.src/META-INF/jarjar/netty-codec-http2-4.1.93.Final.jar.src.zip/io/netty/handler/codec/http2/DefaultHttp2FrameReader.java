/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2FrameReader
/*     */   implements Http2FrameReader, Http2FrameSizePolicy, Http2FrameReader.Configuration
/*     */ {
/*     */   private final Http2HeadersDecoder headersDecoder;
/*     */   private boolean readingHeaders = true;
/*     */   private boolean readError;
/*     */   private byte frameType;
/*     */   private int streamId;
/*     */   private Http2Flags flags;
/*     */   private int payloadLength;
/*     */   private HeadersContinuation headersContinuation;
/*     */   private int maxFrameSize;
/*     */   
/*     */   public DefaultHttp2FrameReader() {
/*  79 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2FrameReader(boolean validateHeaders) {
/*  88 */     this(new DefaultHttp2HeadersDecoder(validateHeaders));
/*     */   }
/*     */   
/*     */   public DefaultHttp2FrameReader(Http2HeadersDecoder headersDecoder) {
/*  92 */     this.headersDecoder = headersDecoder;
/*  93 */     this.maxFrameSize = 16384;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2HeadersDecoder.Configuration headersConfiguration() {
/*  98 */     return this.headersDecoder.configuration();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameReader.Configuration configuration() {
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameSizePolicy frameSizePolicy() {
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void maxFrameSize(int max) throws Http2Exception {
/* 113 */     if (!Http2CodecUtil.isMaxFrameSizeValid(max))
/* 114 */       throw Http2Exception.streamError(this.streamId, Http2Error.FRAME_SIZE_ERROR, "Invalid MAX_FRAME_SIZE specified in sent settings: %d", new Object[] {
/* 115 */             Integer.valueOf(max)
/*     */           }); 
/* 117 */     this.maxFrameSize = max;
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxFrameSize() {
/* 122 */     return this.maxFrameSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 127 */     closeHeadersContinuation();
/*     */   }
/*     */   
/*     */   private void closeHeadersContinuation() {
/* 131 */     if (this.headersContinuation != null) {
/* 132 */       this.headersContinuation.close();
/* 133 */       this.headersContinuation = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFrame(ChannelHandlerContext ctx, ByteBuf input, Http2FrameListener listener) throws Http2Exception {
/* 140 */     if (this.readError) {
/* 141 */       input.skipBytes(input.readableBytes());
/*     */       return;
/*     */     } 
/*     */     try {
/*     */       do {
/* 146 */         if (this.readingHeaders) {
/* 147 */           processHeaderState(input);
/* 148 */           if (this.readingHeaders) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 159 */         processPayloadState(ctx, input, listener);
/* 160 */         if (!this.readingHeaders) {
/*     */           return;
/*     */         }
/*     */       }
/* 164 */       while (input.isReadable());
/* 165 */     } catch (Http2Exception e) {
/* 166 */       this.readError = !Http2Exception.isStreamError(e);
/* 167 */       throw e;
/* 168 */     } catch (RuntimeException e) {
/* 169 */       this.readError = true;
/* 170 */       throw e;
/* 171 */     } catch (Throwable cause) {
/* 172 */       this.readError = true;
/* 173 */       PlatformDependent.throwException(cause);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processHeaderState(ByteBuf in) throws Http2Exception {
/* 178 */     if (in.readableBytes() < 9) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 184 */     this.payloadLength = in.readUnsignedMedium();
/* 185 */     if (this.payloadLength > this.maxFrameSize) {
/* 186 */       throw Http2Exception.connectionError(Http2Error.FRAME_SIZE_ERROR, "Frame length: %d exceeds maximum: %d", new Object[] { Integer.valueOf(this.payloadLength), 
/* 187 */             Integer.valueOf(this.maxFrameSize) });
/*     */     }
/* 189 */     this.frameType = in.readByte();
/* 190 */     this.flags = new Http2Flags(in.readUnsignedByte());
/* 191 */     this.streamId = Http2CodecUtil.readUnsignedInt(in);
/*     */ 
/*     */     
/* 194 */     this.readingHeaders = false;
/*     */     
/* 196 */     switch (this.frameType) {
/*     */       case 0:
/* 198 */         verifyDataFrame();
/*     */         return;
/*     */       case 1:
/* 201 */         verifyHeadersFrame();
/*     */         return;
/*     */       case 2:
/* 204 */         verifyPriorityFrame();
/*     */         return;
/*     */       case 3:
/* 207 */         verifyRstStreamFrame();
/*     */         return;
/*     */       case 4:
/* 210 */         verifySettingsFrame();
/*     */         return;
/*     */       case 5:
/* 213 */         verifyPushPromiseFrame();
/*     */         return;
/*     */       case 6:
/* 216 */         verifyPingFrame();
/*     */         return;
/*     */       case 7:
/* 219 */         verifyGoAwayFrame();
/*     */         return;
/*     */       case 8:
/* 222 */         verifyWindowUpdateFrame();
/*     */         return;
/*     */       case 9:
/* 225 */         verifyContinuationFrame();
/*     */         return;
/*     */     } 
/*     */     
/* 229 */     verifyUnknownFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processPayloadState(ChannelHandlerContext ctx, ByteBuf in, Http2FrameListener listener) throws Http2Exception {
/* 236 */     if (in.readableBytes() < this.payloadLength) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 242 */     int payloadEndIndex = in.readerIndex() + this.payloadLength;
/*     */ 
/*     */     
/* 245 */     this.readingHeaders = true;
/*     */ 
/*     */     
/* 248 */     switch (this.frameType) {
/*     */       case 0:
/* 250 */         readDataFrame(ctx, in, payloadEndIndex, listener);
/*     */         break;
/*     */       case 1:
/* 253 */         readHeadersFrame(ctx, in, payloadEndIndex, listener);
/*     */         break;
/*     */       case 2:
/* 256 */         readPriorityFrame(ctx, in, listener);
/*     */         break;
/*     */       case 3:
/* 259 */         readRstStreamFrame(ctx, in, listener);
/*     */         break;
/*     */       case 4:
/* 262 */         readSettingsFrame(ctx, in, listener);
/*     */         break;
/*     */       case 5:
/* 265 */         readPushPromiseFrame(ctx, in, payloadEndIndex, listener);
/*     */         break;
/*     */       case 6:
/* 268 */         readPingFrame(ctx, in.readLong(), listener);
/*     */         break;
/*     */       case 7:
/* 271 */         readGoAwayFrame(ctx, in, payloadEndIndex, listener);
/*     */         break;
/*     */       case 8:
/* 274 */         readWindowUpdateFrame(ctx, in, listener);
/*     */         break;
/*     */       case 9:
/* 277 */         readContinuationFrame(in, payloadEndIndex, listener);
/*     */         break;
/*     */       default:
/* 280 */         readUnknownFrame(ctx, in, payloadEndIndex, listener);
/*     */         break;
/*     */     } 
/* 283 */     in.readerIndex(payloadEndIndex);
/*     */   }
/*     */   
/*     */   private void verifyDataFrame() throws Http2Exception {
/* 287 */     verifyAssociatedWithAStream();
/* 288 */     verifyNotProcessingHeaders();
/*     */     
/* 290 */     if (this.payloadLength < this.flags.getPaddingPresenceFieldLength())
/* 291 */       throw Http2Exception.streamError(this.streamId, Http2Error.FRAME_SIZE_ERROR, "Frame length %d too small.", new Object[] {
/* 292 */             Integer.valueOf(this.payloadLength)
/*     */           }); 
/*     */   }
/*     */   
/*     */   private void verifyHeadersFrame() throws Http2Exception {
/* 297 */     verifyAssociatedWithAStream();
/* 298 */     verifyNotProcessingHeaders();
/*     */     
/* 300 */     int requiredLength = this.flags.getPaddingPresenceFieldLength() + this.flags.getNumPriorityBytes();
/* 301 */     if (this.payloadLength < requiredLength) {
/* 302 */       throw Http2Exception.streamError(this.streamId, Http2Error.FRAME_SIZE_ERROR, "Frame length too small." + this.payloadLength, new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void verifyPriorityFrame() throws Http2Exception {
/* 308 */     verifyAssociatedWithAStream();
/* 309 */     verifyNotProcessingHeaders();
/*     */     
/* 311 */     if (this.payloadLength != 5)
/* 312 */       throw Http2Exception.streamError(this.streamId, Http2Error.FRAME_SIZE_ERROR, "Invalid frame length %d.", new Object[] {
/* 313 */             Integer.valueOf(this.payloadLength)
/*     */           }); 
/*     */   }
/*     */   
/*     */   private void verifyRstStreamFrame() throws Http2Exception {
/* 318 */     verifyAssociatedWithAStream();
/* 319 */     verifyNotProcessingHeaders();
/*     */     
/* 321 */     if (this.payloadLength != 4) {
/* 322 */       throw Http2Exception.connectionError(Http2Error.FRAME_SIZE_ERROR, "Invalid frame length %d.", new Object[] { Integer.valueOf(this.payloadLength) });
/*     */     }
/*     */   }
/*     */   
/*     */   private void verifySettingsFrame() throws Http2Exception {
/* 327 */     verifyNotProcessingHeaders();
/* 328 */     if (this.streamId != 0) {
/* 329 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "A stream ID must be zero.", new Object[0]);
/*     */     }
/* 331 */     if (this.flags.ack() && this.payloadLength > 0) {
/* 332 */       throw Http2Exception.connectionError(Http2Error.FRAME_SIZE_ERROR, "Ack settings frame must have an empty payload.", new Object[0]);
/*     */     }
/* 334 */     if (this.payloadLength % 6 > 0) {
/* 335 */       throw Http2Exception.connectionError(Http2Error.FRAME_SIZE_ERROR, "Frame length %d invalid.", new Object[] { Integer.valueOf(this.payloadLength) });
/*     */     }
/*     */   }
/*     */   
/*     */   private void verifyPushPromiseFrame() throws Http2Exception {
/* 340 */     verifyNotProcessingHeaders();
/*     */ 
/*     */ 
/*     */     
/* 344 */     int minLength = this.flags.getPaddingPresenceFieldLength() + 4;
/* 345 */     if (this.payloadLength < minLength)
/* 346 */       throw Http2Exception.streamError(this.streamId, Http2Error.FRAME_SIZE_ERROR, "Frame length %d too small.", new Object[] {
/* 347 */             Integer.valueOf(this.payloadLength)
/*     */           }); 
/*     */   }
/*     */   
/*     */   private void verifyPingFrame() throws Http2Exception {
/* 352 */     verifyNotProcessingHeaders();
/* 353 */     if (this.streamId != 0) {
/* 354 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "A stream ID must be zero.", new Object[0]);
/*     */     }
/* 356 */     if (this.payloadLength != 8)
/* 357 */       throw Http2Exception.connectionError(Http2Error.FRAME_SIZE_ERROR, "Frame length %d incorrect size for ping.", new Object[] {
/* 358 */             Integer.valueOf(this.payloadLength)
/*     */           }); 
/*     */   }
/*     */   
/*     */   private void verifyGoAwayFrame() throws Http2Exception {
/* 363 */     verifyNotProcessingHeaders();
/*     */     
/* 365 */     if (this.streamId != 0) {
/* 366 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "A stream ID must be zero.", new Object[0]);
/*     */     }
/* 368 */     if (this.payloadLength < 8) {
/* 369 */       throw Http2Exception.connectionError(Http2Error.FRAME_SIZE_ERROR, "Frame length %d too small.", new Object[] { Integer.valueOf(this.payloadLength) });
/*     */     }
/*     */   }
/*     */   
/*     */   private void verifyWindowUpdateFrame() throws Http2Exception {
/* 374 */     verifyNotProcessingHeaders();
/* 375 */     verifyStreamOrConnectionId(this.streamId, "Stream ID");
/*     */     
/* 377 */     if (this.payloadLength != 4) {
/* 378 */       throw Http2Exception.connectionError(Http2Error.FRAME_SIZE_ERROR, "Invalid frame length %d.", new Object[] { Integer.valueOf(this.payloadLength) });
/*     */     }
/*     */   }
/*     */   
/*     */   private void verifyContinuationFrame() throws Http2Exception {
/* 383 */     verifyAssociatedWithAStream();
/*     */     
/* 385 */     if (this.headersContinuation == null) {
/* 386 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Received %s frame but not currently processing headers.", new Object[] {
/* 387 */             Byte.valueOf(this.frameType)
/*     */           });
/*     */     }
/* 390 */     if (this.streamId != this.headersContinuation.getStreamId()) {
/* 391 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Continuation stream ID does not match pending headers. Expected %d, but received %d.", new Object[] {
/* 392 */             Integer.valueOf(this.headersContinuation.getStreamId()), Integer.valueOf(this.streamId)
/*     */           });
/*     */     }
/* 395 */     if (this.payloadLength < this.flags.getPaddingPresenceFieldLength())
/* 396 */       throw Http2Exception.streamError(this.streamId, Http2Error.FRAME_SIZE_ERROR, "Frame length %d too small for padding.", new Object[] {
/* 397 */             Integer.valueOf(this.payloadLength)
/*     */           }); 
/*     */   }
/*     */   
/*     */   private void verifyUnknownFrame() throws Http2Exception {
/* 402 */     verifyNotProcessingHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   private void readDataFrame(ChannelHandlerContext ctx, ByteBuf payload, int payloadEndIndex, Http2FrameListener listener) throws Http2Exception {
/* 407 */     int padding = readPadding(payload);
/* 408 */     verifyPadding(padding);
/*     */ 
/*     */ 
/*     */     
/* 412 */     int dataLength = lengthWithoutTrailingPadding(payloadEndIndex - payload.readerIndex(), padding);
/*     */     
/* 414 */     ByteBuf data = payload.readSlice(dataLength);
/* 415 */     listener.onDataRead(ctx, this.streamId, data, padding, this.flags.endOfStream());
/*     */   }
/*     */ 
/*     */   
/*     */   private void readHeadersFrame(final ChannelHandlerContext ctx, ByteBuf payload, int payloadEndIndex, Http2FrameListener listener) throws Http2Exception {
/* 420 */     final int headersStreamId = this.streamId;
/* 421 */     final Http2Flags headersFlags = this.flags;
/* 422 */     final int padding = readPadding(payload);
/* 423 */     verifyPadding(padding);
/*     */ 
/*     */ 
/*     */     
/* 427 */     if (this.flags.priorityPresent()) {
/* 428 */       long word1 = payload.readUnsignedInt();
/* 429 */       final boolean exclusive = ((word1 & 0x80000000L) != 0L);
/* 430 */       final int streamDependency = (int)(word1 & 0x7FFFFFFFL);
/* 431 */       if (streamDependency == this.streamId) {
/* 432 */         throw Http2Exception.streamError(this.streamId, Http2Error.PROTOCOL_ERROR, "A stream cannot depend on itself.", new Object[0]);
/*     */       }
/* 434 */       final short weight = (short)(payload.readUnsignedByte() + 1);
/* 435 */       int lenToRead = lengthWithoutTrailingPadding(payloadEndIndex - payload.readerIndex(), padding);
/*     */ 
/*     */       
/* 438 */       this.headersContinuation = new HeadersContinuation()
/*     */         {
/*     */           public int getStreamId() {
/* 441 */             return headersStreamId;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void processFragment(boolean endOfHeaders, ByteBuf fragment, int len, Http2FrameListener listener) throws Http2Exception {
/* 447 */             DefaultHttp2FrameReader.HeadersBlockBuilder hdrBlockBuilder = headersBlockBuilder();
/* 448 */             hdrBlockBuilder.addFragment(fragment, len, ctx.alloc(), endOfHeaders);
/* 449 */             if (endOfHeaders) {
/* 450 */               listener.onHeadersRead(ctx, headersStreamId, hdrBlockBuilder.headers(), streamDependency, weight, exclusive, padding, headersFlags
/* 451 */                   .endOfStream());
/*     */             }
/*     */           }
/*     */         };
/*     */ 
/*     */       
/* 457 */       this.headersContinuation.processFragment(this.flags.endOfHeaders(), payload, lenToRead, listener);
/* 458 */       resetHeadersContinuationIfEnd(this.flags.endOfHeaders());
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 464 */     this.headersContinuation = new HeadersContinuation()
/*     */       {
/*     */         public int getStreamId() {
/* 467 */           return headersStreamId;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void processFragment(boolean endOfHeaders, ByteBuf fragment, int len, Http2FrameListener listener) throws Http2Exception {
/* 473 */           DefaultHttp2FrameReader.HeadersBlockBuilder hdrBlockBuilder = headersBlockBuilder();
/* 474 */           hdrBlockBuilder.addFragment(fragment, len, ctx.alloc(), endOfHeaders);
/* 475 */           if (endOfHeaders) {
/* 476 */             listener.onHeadersRead(ctx, headersStreamId, hdrBlockBuilder.headers(), padding, headersFlags
/* 477 */                 .endOfStream());
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 483 */     int len = lengthWithoutTrailingPadding(payloadEndIndex - payload.readerIndex(), padding);
/* 484 */     this.headersContinuation.processFragment(this.flags.endOfHeaders(), payload, len, listener);
/* 485 */     resetHeadersContinuationIfEnd(this.flags.endOfHeaders());
/*     */   }
/*     */   
/*     */   private void resetHeadersContinuationIfEnd(boolean endOfHeaders) {
/* 489 */     if (endOfHeaders) {
/* 490 */       closeHeadersContinuation();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void readPriorityFrame(ChannelHandlerContext ctx, ByteBuf payload, Http2FrameListener listener) throws Http2Exception {
/* 496 */     long word1 = payload.readUnsignedInt();
/* 497 */     boolean exclusive = ((word1 & 0x80000000L) != 0L);
/* 498 */     int streamDependency = (int)(word1 & 0x7FFFFFFFL);
/* 499 */     if (streamDependency == this.streamId) {
/* 500 */       throw Http2Exception.streamError(this.streamId, Http2Error.PROTOCOL_ERROR, "A stream cannot depend on itself.", new Object[0]);
/*     */     }
/* 502 */     short weight = (short)(payload.readUnsignedByte() + 1);
/* 503 */     listener.onPriorityRead(ctx, this.streamId, streamDependency, weight, exclusive);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readRstStreamFrame(ChannelHandlerContext ctx, ByteBuf payload, Http2FrameListener listener) throws Http2Exception {
/* 508 */     long errorCode = payload.readUnsignedInt();
/* 509 */     listener.onRstStreamRead(ctx, this.streamId, errorCode);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readSettingsFrame(ChannelHandlerContext ctx, ByteBuf payload, Http2FrameListener listener) throws Http2Exception {
/* 514 */     if (this.flags.ack()) {
/* 515 */       listener.onSettingsAckRead(ctx);
/*     */     } else {
/* 517 */       int numSettings = this.payloadLength / 6;
/* 518 */       Http2Settings settings = new Http2Settings();
/* 519 */       for (int index = 0; index < numSettings; index++) {
/* 520 */         char id = (char)payload.readUnsignedShort();
/* 521 */         long value = payload.readUnsignedInt();
/*     */         try {
/* 523 */           settings.put(id, Long.valueOf(value));
/* 524 */         } catch (IllegalArgumentException e) {
/* 525 */           if (id == '\004') {
/* 526 */             throw Http2Exception.connectionError(Http2Error.FLOW_CONTROL_ERROR, e, "Failed setting initial window size: %s", new Object[] { e
/* 527 */                   .getMessage() });
/*     */           }
/* 529 */           throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, e, "Protocol error: %s", new Object[] { e.getMessage() });
/*     */         } 
/*     */       } 
/* 532 */       listener.onSettingsRead(ctx, settings);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readPushPromiseFrame(final ChannelHandlerContext ctx, ByteBuf payload, int payloadEndIndex, Http2FrameListener listener) throws Http2Exception {
/* 538 */     final int pushPromiseStreamId = this.streamId;
/* 539 */     final int padding = readPadding(payload);
/* 540 */     verifyPadding(padding);
/* 541 */     final int promisedStreamId = Http2CodecUtil.readUnsignedInt(payload);
/*     */ 
/*     */     
/* 544 */     this.headersContinuation = new HeadersContinuation()
/*     */       {
/*     */         public int getStreamId() {
/* 547 */           return pushPromiseStreamId;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void processFragment(boolean endOfHeaders, ByteBuf fragment, int len, Http2FrameListener listener) throws Http2Exception {
/* 553 */           headersBlockBuilder().addFragment(fragment, len, ctx.alloc(), endOfHeaders);
/* 554 */           if (endOfHeaders) {
/* 555 */             listener.onPushPromiseRead(ctx, pushPromiseStreamId, promisedStreamId, 
/* 556 */                 headersBlockBuilder().headers(), padding);
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 562 */     int len = lengthWithoutTrailingPadding(payloadEndIndex - payload.readerIndex(), padding);
/* 563 */     this.headersContinuation.processFragment(this.flags.endOfHeaders(), payload, len, listener);
/* 564 */     resetHeadersContinuationIfEnd(this.flags.endOfHeaders());
/*     */   }
/*     */ 
/*     */   
/*     */   private void readPingFrame(ChannelHandlerContext ctx, long data, Http2FrameListener listener) throws Http2Exception {
/* 569 */     if (this.flags.ack()) {
/* 570 */       listener.onPingAckRead(ctx, data);
/*     */     } else {
/* 572 */       listener.onPingRead(ctx, data);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void readGoAwayFrame(ChannelHandlerContext ctx, ByteBuf payload, int payloadEndIndex, Http2FrameListener listener) throws Http2Exception {
/* 578 */     int lastStreamId = Http2CodecUtil.readUnsignedInt(payload);
/* 579 */     long errorCode = payload.readUnsignedInt();
/* 580 */     ByteBuf debugData = payload.readSlice(payloadEndIndex - payload.readerIndex());
/* 581 */     listener.onGoAwayRead(ctx, lastStreamId, errorCode, debugData);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readWindowUpdateFrame(ChannelHandlerContext ctx, ByteBuf payload, Http2FrameListener listener) throws Http2Exception {
/* 586 */     int windowSizeIncrement = Http2CodecUtil.readUnsignedInt(payload);
/* 587 */     if (windowSizeIncrement == 0)
/* 588 */       throw Http2Exception.streamError(this.streamId, Http2Error.PROTOCOL_ERROR, "Received WINDOW_UPDATE with delta 0 for stream: %d", new Object[] {
/* 589 */             Integer.valueOf(this.streamId)
/*     */           }); 
/* 591 */     listener.onWindowUpdateRead(ctx, this.streamId, windowSizeIncrement);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readContinuationFrame(ByteBuf payload, int payloadEndIndex, Http2FrameListener listener) throws Http2Exception {
/* 597 */     this.headersContinuation.processFragment(this.flags.endOfHeaders(), payload, payloadEndIndex - payload
/* 598 */         .readerIndex(), listener);
/* 599 */     resetHeadersContinuationIfEnd(this.flags.endOfHeaders());
/*     */   }
/*     */ 
/*     */   
/*     */   private void readUnknownFrame(ChannelHandlerContext ctx, ByteBuf payload, int payloadEndIndex, Http2FrameListener listener) throws Http2Exception {
/* 604 */     payload = payload.readSlice(payloadEndIndex - payload.readerIndex());
/* 605 */     listener.onUnknownFrame(ctx, this.frameType, this.streamId, this.flags, payload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readPadding(ByteBuf payload) {
/* 613 */     if (!this.flags.paddingPresent()) {
/* 614 */       return 0;
/*     */     }
/* 616 */     return payload.readUnsignedByte() + 1;
/*     */   }
/*     */   
/*     */   private void verifyPadding(int padding) throws Http2Exception {
/* 620 */     int len = lengthWithoutTrailingPadding(this.payloadLength, padding);
/* 621 */     if (len < 0) {
/* 622 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Frame payload too small for padding.", new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int lengthWithoutTrailingPadding(int readableBytes, int padding) {
/* 631 */     return (padding == 0) ? readableBytes : (readableBytes - padding - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private abstract class HeadersContinuation
/*     */   {
/* 642 */     private final DefaultHttp2FrameReader.HeadersBlockBuilder builder = new DefaultHttp2FrameReader.HeadersBlockBuilder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final DefaultHttp2FrameReader.HeadersBlockBuilder headersBlockBuilder() {
/* 660 */       return this.builder;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void close() {
/* 667 */       this.builder.close();
/*     */     }
/*     */ 
/*     */     
/*     */     private HeadersContinuation() {}
/*     */     
/*     */     abstract int getStreamId();
/*     */     
/*     */     abstract void processFragment(boolean param1Boolean, ByteBuf param1ByteBuf, int param1Int, Http2FrameListener param1Http2FrameListener) throws Http2Exception;
/*     */   }
/*     */   
/*     */   protected class HeadersBlockBuilder
/*     */   {
/*     */     private ByteBuf headerBlock;
/*     */     
/*     */     private void headerSizeExceeded() throws Http2Exception {
/* 683 */       close();
/* 684 */       Http2CodecUtil.headerListSizeExceeded(DefaultHttp2FrameReader.this.headersDecoder.configuration().maxHeaderListSizeGoAway());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void addFragment(ByteBuf fragment, int len, ByteBufAllocator alloc, boolean endOfHeaders) throws Http2Exception {
/* 698 */       if (this.headerBlock == null) {
/* 699 */         if (len > DefaultHttp2FrameReader.this.headersDecoder.configuration().maxHeaderListSizeGoAway()) {
/* 700 */           headerSizeExceeded();
/*     */         }
/* 702 */         if (endOfHeaders) {
/*     */ 
/*     */           
/* 705 */           this.headerBlock = fragment.readRetainedSlice(len);
/*     */         } else {
/* 707 */           this.headerBlock = alloc.buffer(len).writeBytes(fragment, len);
/*     */         } 
/*     */         return;
/*     */       } 
/* 711 */       if (DefaultHttp2FrameReader.this.headersDecoder.configuration().maxHeaderListSizeGoAway() - len < this.headerBlock
/* 712 */         .readableBytes()) {
/* 713 */         headerSizeExceeded();
/*     */       }
/* 715 */       if (this.headerBlock.isWritable(len)) {
/*     */         
/* 717 */         this.headerBlock.writeBytes(fragment, len);
/*     */       } else {
/*     */         
/* 720 */         ByteBuf buf = alloc.buffer(this.headerBlock.readableBytes() + len);
/* 721 */         buf.writeBytes(this.headerBlock).writeBytes(fragment, len);
/* 722 */         this.headerBlock.release();
/* 723 */         this.headerBlock = buf;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Http2Headers headers() throws Http2Exception {
/*     */       try {
/* 733 */         return DefaultHttp2FrameReader.this.headersDecoder.decodeHeaders(DefaultHttp2FrameReader.this.streamId, this.headerBlock);
/*     */       } finally {
/* 735 */         close();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void close() {
/* 743 */       if (this.headerBlock != null) {
/* 744 */         this.headerBlock.release();
/* 745 */         this.headerBlock = null;
/*     */       } 
/*     */ 
/*     */       
/* 749 */       DefaultHttp2FrameReader.this.headersContinuation = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void verifyNotProcessingHeaders() throws Http2Exception {
/* 758 */     if (this.headersContinuation != null)
/* 759 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Received frame of type %s while processing headers on stream %d.", new Object[] {
/* 760 */             Byte.valueOf(this.frameType), Integer.valueOf(this.headersContinuation.getStreamId())
/*     */           }); 
/*     */   }
/*     */   
/*     */   private void verifyAssociatedWithAStream() throws Http2Exception {
/* 765 */     if (this.streamId == 0) {
/* 766 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Frame of type %s must be associated with a stream.", new Object[] { Byte.valueOf(this.frameType) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void verifyStreamOrConnectionId(int streamId, String argumentName) throws Http2Exception {
/* 772 */     if (streamId < 0)
/* 773 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "%s must be >= 0", new Object[] { argumentName }); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2FrameReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */