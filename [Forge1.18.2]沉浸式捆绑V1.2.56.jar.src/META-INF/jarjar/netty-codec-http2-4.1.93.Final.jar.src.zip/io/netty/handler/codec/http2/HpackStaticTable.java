/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HpackStaticTable
/*     */ {
/*     */   static final int NOT_FOUND = -1;
/*  48 */   private static final List<HpackHeaderField> STATIC_TABLE = Arrays.asList(new HpackHeaderField[] { 
/*  49 */         newEmptyHeaderField(":authority"), 
/*  50 */         newHeaderField(":method", "GET"), 
/*  51 */         newHeaderField(":method", "POST"), 
/*  52 */         newHeaderField(":path", "/"), 
/*  53 */         newHeaderField(":path", "/index.html"), 
/*  54 */         newHeaderField(":scheme", "http"), 
/*  55 */         newHeaderField(":scheme", "https"), 
/*  56 */         newHeaderField(":status", "200"), 
/*  57 */         newHeaderField(":status", "204"), 
/*  58 */         newHeaderField(":status", "206"), 
/*  59 */         newHeaderField(":status", "304"), 
/*  60 */         newHeaderField(":status", "400"), 
/*  61 */         newHeaderField(":status", "404"), 
/*  62 */         newHeaderField(":status", "500"), 
/*  63 */         newEmptyHeaderField("accept-charset"), 
/*  64 */         newHeaderField("accept-encoding", "gzip, deflate"), 
/*  65 */         newEmptyHeaderField("accept-language"), 
/*  66 */         newEmptyHeaderField("accept-ranges"), 
/*  67 */         newEmptyHeaderField("accept"), 
/*  68 */         newEmptyHeaderField("access-control-allow-origin"), 
/*  69 */         newEmptyHeaderField("age"), 
/*  70 */         newEmptyHeaderField("allow"), 
/*  71 */         newEmptyHeaderField("authorization"), 
/*  72 */         newEmptyHeaderField("cache-control"), 
/*  73 */         newEmptyHeaderField("content-disposition"), 
/*  74 */         newEmptyHeaderField("content-encoding"), 
/*  75 */         newEmptyHeaderField("content-language"), 
/*  76 */         newEmptyHeaderField("content-length"), 
/*  77 */         newEmptyHeaderField("content-location"), 
/*  78 */         newEmptyHeaderField("content-range"), 
/*  79 */         newEmptyHeaderField("content-type"), 
/*  80 */         newEmptyHeaderField("cookie"), 
/*  81 */         newEmptyHeaderField("date"), 
/*  82 */         newEmptyHeaderField("etag"), 
/*  83 */         newEmptyHeaderField("expect"), 
/*  84 */         newEmptyHeaderField("expires"), 
/*  85 */         newEmptyHeaderField("from"), 
/*  86 */         newEmptyHeaderField("host"), 
/*  87 */         newEmptyHeaderField("if-match"), 
/*  88 */         newEmptyHeaderField("if-modified-since"), 
/*  89 */         newEmptyHeaderField("if-none-match"), 
/*  90 */         newEmptyHeaderField("if-range"), 
/*  91 */         newEmptyHeaderField("if-unmodified-since"), 
/*  92 */         newEmptyHeaderField("last-modified"), 
/*  93 */         newEmptyHeaderField("link"), 
/*  94 */         newEmptyHeaderField("location"), 
/*  95 */         newEmptyHeaderField("max-forwards"), 
/*  96 */         newEmptyHeaderField("proxy-authenticate"), 
/*  97 */         newEmptyHeaderField("proxy-authorization"), 
/*  98 */         newEmptyHeaderField("range"), 
/*  99 */         newEmptyHeaderField("referer"), 
/* 100 */         newEmptyHeaderField("refresh"), 
/* 101 */         newEmptyHeaderField("retry-after"), 
/* 102 */         newEmptyHeaderField("server"), 
/* 103 */         newEmptyHeaderField("set-cookie"), 
/* 104 */         newEmptyHeaderField("strict-transport-security"), 
/* 105 */         newEmptyHeaderField("transfer-encoding"), 
/* 106 */         newEmptyHeaderField("user-agent"), 
/* 107 */         newEmptyHeaderField("vary"), 
/* 108 */         newEmptyHeaderField("via"), 
/* 109 */         newEmptyHeaderField("www-authenticate") });
/*     */   private static final int HEADER_NAMES_TABLE_SIZE = 512;
/*     */   
/*     */   private static HpackHeaderField newEmptyHeaderField(String name) {
/* 113 */     return new HpackHeaderField((CharSequence)AsciiString.cached(name), (CharSequence)AsciiString.EMPTY_STRING);
/*     */   }
/*     */   
/*     */   private static HpackHeaderField newHeaderField(String name, String value) {
/* 117 */     return new HpackHeaderField((CharSequence)AsciiString.cached(name), (CharSequence)AsciiString.cached(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   private static final int HEADER_NAMES_TABLE_SHIFT = PlatformDependent.BIG_ENDIAN_NATIVE_ORDER ? 22 : 18;
/*     */ 
/*     */   
/* 126 */   private static final HeaderNameIndex[] HEADER_NAMES = new HeaderNameIndex[512];
/*     */   
/*     */   static {
/*     */     int index;
/* 130 */     for (index = STATIC_TABLE.size(); index > 0; index--) {
/* 131 */       HpackHeaderField entry = getEntry(index);
/* 132 */       int bucket = headerNameBucket(entry.name);
/* 133 */       HeaderNameIndex tableEntry = HEADER_NAMES[bucket];
/* 134 */       if (tableEntry != null && !HpackUtil.equalsVariableTime(tableEntry.name, entry.name))
/*     */       {
/* 136 */         throw new IllegalStateException("Hash bucket collision between " + tableEntry.name + " and " + entry.name);
/*     */       }
/*     */       
/* 139 */       HEADER_NAMES[bucket] = new HeaderNameIndex(entry.name, index, (entry.value.length() == 0));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int HEADERS_WITH_NON_EMPTY_VALUES_TABLE_SIZE = 64;
/*     */   
/* 146 */   private static final int HEADERS_WITH_NON_EMPTY_VALUES_TABLE_SHIFT = PlatformDependent.BIG_ENDIAN_NATIVE_ORDER ? 0 : 6;
/*     */ 
/*     */ 
/*     */   
/* 150 */   private static final HeaderIndex[] HEADERS_WITH_NON_EMPTY_VALUES = new HeaderIndex[64];
/*     */   
/*     */   static {
/* 153 */     for (index = STATIC_TABLE.size(); index > 0; index--) {
/* 154 */       HpackHeaderField entry = getEntry(index);
/* 155 */       if (entry.value.length() > 0) {
/* 156 */         int bucket = headerBucket(entry.value);
/* 157 */         HeaderIndex tableEntry = HEADERS_WITH_NON_EMPTY_VALUES[bucket];
/* 158 */         if (tableEntry != null)
/*     */         {
/* 160 */           throw new IllegalStateException("Hash bucket collision between " + tableEntry.value + " and " + entry.value);
/*     */         }
/*     */         
/* 163 */         HEADERS_WITH_NON_EMPTY_VALUES[bucket] = new HeaderIndex(entry.name, entry.value, index);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   static final int length = STATIC_TABLE.size();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HpackHeaderField getEntry(int index) {
/* 177 */     return STATIC_TABLE.get(index - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getIndex(CharSequence name) {
/* 185 */     HeaderNameIndex entry = getEntry(name);
/* 186 */     return (entry == null) ? -1 : entry.index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getIndexInsensitive(CharSequence name, CharSequence value) {
/* 194 */     if (value.length() == 0) {
/* 195 */       HeaderNameIndex entry = getEntry(name);
/* 196 */       return (entry == null || !entry.emptyValue) ? -1 : entry.index;
/*     */     } 
/* 198 */     int bucket = headerBucket(value);
/* 199 */     HeaderIndex header = HEADERS_WITH_NON_EMPTY_VALUES[bucket];
/* 200 */     if (header == null) {
/* 201 */       return -1;
/*     */     }
/* 203 */     if (HpackUtil.equalsVariableTime(header.name, name) && HpackUtil.equalsVariableTime(header.value, value)) {
/* 204 */       return header.index;
/*     */     }
/* 206 */     return -1;
/*     */   }
/*     */   
/*     */   private static HeaderNameIndex getEntry(CharSequence name) {
/* 210 */     int bucket = headerNameBucket(name);
/* 211 */     HeaderNameIndex entry = HEADER_NAMES[bucket];
/* 212 */     if (entry == null) {
/* 213 */       return null;
/*     */     }
/* 215 */     return HpackUtil.equalsVariableTime(entry.name, name) ? entry : null;
/*     */   }
/*     */   
/*     */   private static int headerNameBucket(CharSequence name) {
/* 219 */     return bucket(name, HEADER_NAMES_TABLE_SHIFT, 511);
/*     */   }
/*     */   
/*     */   private static int headerBucket(CharSequence value) {
/* 223 */     return bucket(value, HEADERS_WITH_NON_EMPTY_VALUES_TABLE_SHIFT, 63);
/*     */   }
/*     */   
/*     */   private static int bucket(CharSequence s, int shift, int mask) {
/* 227 */     return AsciiString.hashCode(s) >> shift & mask;
/*     */   }
/*     */   
/*     */   private static final class HeaderNameIndex {
/*     */     final CharSequence name;
/*     */     final int index;
/*     */     final boolean emptyValue;
/*     */     
/*     */     HeaderNameIndex(CharSequence name, int index, boolean emptyValue) {
/* 236 */       this.name = name;
/* 237 */       this.index = index;
/* 238 */       this.emptyValue = emptyValue;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class HeaderIndex {
/*     */     final CharSequence name;
/*     */     final CharSequence value;
/*     */     final int index;
/*     */     
/*     */     HeaderIndex(CharSequence name, CharSequence value, int index) {
/* 248 */       this.name = name;
/* 249 */       this.value = value;
/* 250 */       this.index = index;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\HpackStaticTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */