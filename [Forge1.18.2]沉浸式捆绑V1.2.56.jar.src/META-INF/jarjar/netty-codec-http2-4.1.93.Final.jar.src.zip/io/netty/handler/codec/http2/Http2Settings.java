/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.util.collection.CharObjectHashMap;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Settings
/*     */   extends CharObjectHashMap<Long>
/*     */ {
/*     */   private static final int DEFAULT_CAPACITY = 13;
/*  56 */   private static final Long FALSE = Long.valueOf(0L);
/*  57 */   private static final Long TRUE = Long.valueOf(1L);
/*     */   
/*     */   public Http2Settings() {
/*  60 */     this(13);
/*     */   }
/*     */   
/*     */   public Http2Settings(int initialCapacity, float loadFactor) {
/*  64 */     super(initialCapacity, loadFactor);
/*     */   }
/*     */   
/*     */   public Http2Settings(int initialCapacity) {
/*  68 */     super(initialCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long put(char key, Long value) {
/*  79 */     verifyStandardSetting(key, value);
/*  80 */     return (Long)super.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long headerTableSize() {
/*  87 */     return (Long)get('\001');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Settings headerTableSize(long value) {
/*  96 */     put('\001', Long.valueOf(value));
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean pushEnabled() {
/* 104 */     Long value = (Long)get('\002');
/* 105 */     if (value == null) {
/* 106 */       return null;
/*     */     }
/* 108 */     return Boolean.valueOf(TRUE.equals(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Settings pushEnabled(boolean enabled) {
/* 115 */     put('\002', enabled ? TRUE : FALSE);
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long maxConcurrentStreams() {
/* 123 */     return (Long)get('\003');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Settings maxConcurrentStreams(long value) {
/* 132 */     put('\003', Long.valueOf(value));
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer initialWindowSize() {
/* 140 */     return getIntValue('\004');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Settings initialWindowSize(int value) {
/* 149 */     put('\004', Long.valueOf(value));
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer maxFrameSize() {
/* 157 */     return getIntValue('\005');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Settings maxFrameSize(int value) {
/* 166 */     put('\005', Long.valueOf(value));
/* 167 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long maxHeaderListSize() {
/* 174 */     return (Long)get('\006');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Settings maxHeaderListSize(long value) {
/* 183 */     put('\006', Long.valueOf(value));
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Settings copyFrom(Http2Settings settings) {
/* 191 */     clear();
/* 192 */     putAll((Map)settings);
/* 193 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getIntValue(char key) {
/* 202 */     Long value = (Long)get(key);
/* 203 */     if (value == null) {
/* 204 */       return null;
/*     */     }
/* 206 */     return Integer.valueOf(value.intValue());
/*     */   }
/*     */   
/*     */   private static void verifyStandardSetting(int key, Long value) {
/* 210 */     ObjectUtil.checkNotNull(value, "value");
/* 211 */     switch (key) {
/*     */       case 1:
/* 213 */         if (value.longValue() < 0L || value.longValue() > 4294967295L) {
/* 214 */           throw new IllegalArgumentException("Setting HEADER_TABLE_SIZE is invalid: " + value + ", expected [" + 0L + ", " + 4294967295L + ']');
/*     */         }
/*     */         return;
/*     */       
/*     */       case 2:
/* 219 */         if (value.longValue() != 0L && value.longValue() != 1L) {
/* 220 */           throw new IllegalArgumentException("Setting ENABLE_PUSH is invalid: " + value + ", expected [0, 1]");
/*     */         }
/*     */         return;
/*     */       
/*     */       case 3:
/* 225 */         if (value.longValue() < 0L || value.longValue() > 4294967295L) {
/* 226 */           throw new IllegalArgumentException("Setting MAX_CONCURRENT_STREAMS is invalid: " + value + ", expected [" + 0L + ", " + 4294967295L + ']');
/*     */         }
/*     */         return;
/*     */       
/*     */       case 4:
/* 231 */         if (value.longValue() < 0L || value.longValue() > 2147483647L) {
/* 232 */           throw new IllegalArgumentException("Setting INITIAL_WINDOW_SIZE is invalid: " + value + ", expected [" + Character.MIN_VALUE + ", " + 2147483647 + ']');
/*     */         }
/*     */         return;
/*     */       
/*     */       case 5:
/* 237 */         if (!Http2CodecUtil.isMaxFrameSizeValid(value.intValue())) {
/* 238 */           throw new IllegalArgumentException("Setting MAX_FRAME_SIZE is invalid: " + value + ", expected [" + '䀀' + ", " + 16777215 + ']');
/*     */         }
/*     */         return;
/*     */       
/*     */       case 6:
/* 243 */         if (value.longValue() < 0L || value.longValue() > 4294967295L) {
/* 244 */           throw new IllegalArgumentException("Setting MAX_HEADER_LIST_SIZE is invalid: " + value + ", expected [" + 0L + ", " + 4294967295L + ']');
/*     */         }
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 250 */     if (value.longValue() < 0L || value.longValue() > 4294967295L) {
/* 251 */       throw new IllegalArgumentException("Non-standard setting 0x" + Integer.toHexString(key) + " is invalid: " + value + ", expected unsigned 32-bit value");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String keyToString(char key) {
/* 260 */     switch (key) {
/*     */       case '\001':
/* 262 */         return "HEADER_TABLE_SIZE";
/*     */       case '\002':
/* 264 */         return "ENABLE_PUSH";
/*     */       case '\003':
/* 266 */         return "MAX_CONCURRENT_STREAMS";
/*     */       case '\004':
/* 268 */         return "INITIAL_WINDOW_SIZE";
/*     */       case '\005':
/* 270 */         return "MAX_FRAME_SIZE";
/*     */       case '\006':
/* 272 */         return "MAX_HEADER_LIST_SIZE";
/*     */     } 
/*     */     
/* 275 */     return "0x" + Integer.toHexString(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Http2Settings defaultSettings() {
/* 280 */     return (new Http2Settings()).maxHeaderListSize(8192L);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2Settings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */