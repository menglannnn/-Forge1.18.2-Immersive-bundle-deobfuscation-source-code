/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufAllocator;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.handler.codec.http.FullHttpMessage;
/*     */ import io.netty.handler.codec.http.FullHttpRequest;
/*     */ import io.netty.handler.codec.http.FullHttpResponse;
/*     */ import io.netty.handler.codec.http.HttpHeaderNames;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpResponseStatus;
/*     */ import io.netty.handler.codec.http.HttpStatusClass;
/*     */ import io.netty.handler.codec.http.HttpUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InboundHttp2ToHttpAdapter
/*     */   extends Http2EventAdapter
/*     */ {
/*  43 */   private static final ImmediateSendDetector DEFAULT_SEND_DETECTOR = new ImmediateSendDetector()
/*     */     {
/*     */       public boolean mustSendImmediately(FullHttpMessage msg) {
/*  46 */         if (msg instanceof FullHttpResponse) {
/*  47 */           return (((FullHttpResponse)msg).status().codeClass() == HttpStatusClass.INFORMATIONAL);
/*     */         }
/*  49 */         if (msg instanceof FullHttpRequest) {
/*  50 */           return msg.headers().contains((CharSequence)HttpHeaderNames.EXPECT);
/*     */         }
/*  52 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public FullHttpMessage copyIfNeeded(ByteBufAllocator allocator, FullHttpMessage msg) {
/*  57 */         if (msg instanceof FullHttpRequest) {
/*  58 */           FullHttpRequest copy = ((FullHttpRequest)msg).replace(allocator.buffer(0));
/*  59 */           copy.headers().remove((CharSequence)HttpHeaderNames.EXPECT);
/*  60 */           return (FullHttpMessage)copy;
/*     */         } 
/*  62 */         return null;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private final int maxContentLength;
/*     */   
/*     */   private final ImmediateSendDetector sendDetector;
/*     */   
/*     */   private final Http2Connection.PropertyKey messageKey;
/*     */ 
/*     */   
/*     */   protected InboundHttp2ToHttpAdapter(Http2Connection connection, int maxContentLength, boolean validateHttpHeaders, boolean propagateSettings) {
/*  75 */     this.connection = (Http2Connection)ObjectUtil.checkNotNull(connection, "connection");
/*  76 */     this.maxContentLength = ObjectUtil.checkPositive(maxContentLength, "maxContentLength");
/*  77 */     this.validateHttpHeaders = validateHttpHeaders;
/*  78 */     this.propagateSettings = propagateSettings;
/*  79 */     this.sendDetector = DEFAULT_SEND_DETECTOR;
/*  80 */     this.messageKey = connection.newKey();
/*     */   }
/*     */   private final boolean propagateSettings; protected final Http2Connection connection; protected final boolean validateHttpHeaders;
/*     */   private static interface ImmediateSendDetector {
/*     */     boolean mustSendImmediately(FullHttpMessage param1FullHttpMessage);
/*     */     
/*     */     FullHttpMessage copyIfNeeded(ByteBufAllocator param1ByteBufAllocator, FullHttpMessage param1FullHttpMessage); }
/*     */   
/*     */   protected final void removeMessage(Http2Stream stream, boolean release) {
/*  89 */     FullHttpMessage msg = stream.<FullHttpMessage>removeProperty(this.messageKey);
/*  90 */     if (release && msg != null) {
/*  91 */       msg.release();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final FullHttpMessage getMessage(Http2Stream stream) {
/* 101 */     return stream.<FullHttpMessage>getProperty(this.messageKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void putMessage(Http2Stream stream, FullHttpMessage message) {
/* 110 */     FullHttpMessage previous = stream.<FullHttpMessage>setProperty(this.messageKey, message);
/* 111 */     if (previous != message && previous != null) {
/* 112 */       previous.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStreamRemoved(Http2Stream stream) {
/* 118 */     removeMessage(stream, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireChannelRead(ChannelHandlerContext ctx, FullHttpMessage msg, boolean release, Http2Stream stream) {
/* 131 */     removeMessage(stream, release);
/* 132 */     HttpUtil.setContentLength((HttpMessage)msg, msg.content().readableBytes());
/* 133 */     ctx.fireChannelRead(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FullHttpMessage newMessage(Http2Stream stream, Http2Headers headers, boolean validateHttpHeaders, ByteBufAllocator alloc) throws Http2Exception {
/* 152 */     return this.connection.isServer() ? (FullHttpMessage)HttpConversionUtil.toFullHttpRequest(stream.id(), headers, alloc, validateHttpHeaders) : 
/* 153 */       (FullHttpMessage)HttpConversionUtil.toFullHttpResponse(stream.id(), headers, alloc, validateHttpHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FullHttpMessage processHeadersBegin(ChannelHandlerContext ctx, Http2Stream stream, Http2Headers headers, boolean endOfStream, boolean allowAppend, boolean appendToTrailer) throws Http2Exception {
/* 184 */     FullHttpMessage msg = getMessage(stream);
/* 185 */     boolean release = true;
/* 186 */     if (msg == null) {
/* 187 */       msg = newMessage(stream, headers, this.validateHttpHeaders, ctx.alloc());
/* 188 */     } else if (allowAppend) {
/* 189 */       release = false;
/* 190 */       HttpConversionUtil.addHttp2ToHttpHeaders(stream.id(), headers, msg, appendToTrailer);
/*     */     } else {
/* 192 */       release = false;
/* 193 */       msg = null;
/*     */     } 
/*     */     
/* 196 */     if (this.sendDetector.mustSendImmediately(msg)) {
/*     */ 
/*     */       
/* 199 */       FullHttpMessage copy = endOfStream ? null : this.sendDetector.copyIfNeeded(ctx.alloc(), msg);
/* 200 */       fireChannelRead(ctx, msg, release, stream);
/* 201 */       return copy;
/*     */     } 
/*     */     
/* 204 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processHeadersEnd(ChannelHandlerContext ctx, Http2Stream stream, FullHttpMessage msg, boolean endOfStream) {
/* 218 */     if (endOfStream) {
/*     */       
/* 220 */       fireChannelRead(ctx, msg, (getMessage(stream) != msg), stream);
/*     */     } else {
/* 222 */       putMessage(stream, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int onDataRead(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream) throws Http2Exception {
/* 229 */     Http2Stream stream = this.connection.stream(streamId);
/* 230 */     FullHttpMessage msg = getMessage(stream);
/* 231 */     if (msg == null) {
/* 232 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Data Frame received for unknown stream id %d", new Object[] { Integer.valueOf(streamId) });
/*     */     }
/*     */     
/* 235 */     ByteBuf content = msg.content();
/* 236 */     int dataReadableBytes = data.readableBytes();
/* 237 */     if (content.readableBytes() > this.maxContentLength - dataReadableBytes) {
/* 238 */       throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, "Content length exceeded max of %d for stream id %d", new Object[] {
/* 239 */             Integer.valueOf(this.maxContentLength), Integer.valueOf(streamId)
/*     */           });
/*     */     }
/* 242 */     content.writeBytes(data, data.readerIndex(), dataReadableBytes);
/*     */     
/* 244 */     if (endOfStream) {
/* 245 */       fireChannelRead(ctx, msg, false, stream);
/*     */     }
/*     */ 
/*     */     
/* 249 */     return dataReadableBytes + padding;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endOfStream) throws Http2Exception {
/* 255 */     Http2Stream stream = this.connection.stream(streamId);
/* 256 */     FullHttpMessage msg = processHeadersBegin(ctx, stream, headers, endOfStream, true, true);
/* 257 */     if (msg != null) {
/* 258 */       processHeadersEnd(ctx, stream, msg, endOfStream);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream) throws Http2Exception {
/* 266 */     Http2Stream stream = this.connection.stream(streamId);
/* 267 */     FullHttpMessage msg = processHeadersBegin(ctx, stream, headers, endOfStream, true, true);
/* 268 */     if (msg != null) {
/*     */ 
/*     */       
/* 271 */       if (streamDependency != 0) {
/* 272 */         msg.headers().setInt((CharSequence)HttpConversionUtil.ExtensionHeaderNames.STREAM_DEPENDENCY_ID.text(), streamDependency);
/*     */       }
/*     */       
/* 275 */       msg.headers().setShort((CharSequence)HttpConversionUtil.ExtensionHeaderNames.STREAM_WEIGHT.text(), weight);
/*     */       
/* 277 */       processHeadersEnd(ctx, stream, msg, endOfStream);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRstStreamRead(ChannelHandlerContext ctx, int streamId, long errorCode) throws Http2Exception {
/* 283 */     Http2Stream stream = this.connection.stream(streamId);
/* 284 */     FullHttpMessage msg = getMessage(stream);
/* 285 */     if (msg != null) {
/* 286 */       onRstStreamRead(stream, msg);
/*     */     }
/* 288 */     ctx.fireExceptionCaught(Http2Exception.streamError(streamId, Http2Error.valueOf(errorCode), "HTTP/2 to HTTP layer caught stream reset", new Object[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onPushPromiseRead(ChannelHandlerContext ctx, int streamId, int promisedStreamId, Http2Headers headers, int padding) throws Http2Exception {
/* 296 */     Http2Stream promisedStream = this.connection.stream(promisedStreamId);
/* 297 */     if (headers.status() == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 303 */       headers.status((CharSequence)HttpResponseStatus.OK.codeAsText());
/*     */     }
/* 305 */     FullHttpMessage msg = processHeadersBegin(ctx, promisedStream, headers, false, false, false);
/* 306 */     if (msg == null) {
/* 307 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Push Promise Frame received for pre-existing stream id %d", new Object[] {
/* 308 */             Integer.valueOf(promisedStreamId)
/*     */           });
/*     */     }
/* 311 */     msg.headers().setInt((CharSequence)HttpConversionUtil.ExtensionHeaderNames.STREAM_PROMISE_ID.text(), streamId);
/* 312 */     msg.headers().setShort((CharSequence)HttpConversionUtil.ExtensionHeaderNames.STREAM_WEIGHT.text(), (short)16);
/*     */ 
/*     */     
/* 315 */     processHeadersEnd(ctx, promisedStream, msg, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSettingsRead(ChannelHandlerContext ctx, Http2Settings settings) throws Http2Exception {
/* 320 */     if (this.propagateSettings)
/*     */     {
/* 322 */       ctx.fireChannelRead(settings);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onRstStreamRead(Http2Stream stream, FullHttpMessage msg) {
/* 330 */     removeMessage(stream, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\InboundHttp2ToHttpAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */