/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.handler.codec.http.HttpHeaderValidationUtil;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HpackDecoder
/*     */ {
/*  56 */   private static final Http2Exception DECODE_ULE_128_DECOMPRESSION_EXCEPTION = Http2Exception.newStatic(Http2Error.COMPRESSION_ERROR, "HPACK - decompression failure", Http2Exception.ShutdownHint.HARD_SHUTDOWN, HpackDecoder.class, "decodeULE128(..)");
/*     */ 
/*     */ 
/*     */   
/*  60 */   private static final Http2Exception DECODE_ULE_128_TO_LONG_DECOMPRESSION_EXCEPTION = Http2Exception.newStatic(Http2Error.COMPRESSION_ERROR, "HPACK - long overflow", Http2Exception.ShutdownHint.HARD_SHUTDOWN, HpackDecoder.class, "decodeULE128(..)");
/*     */ 
/*     */   
/*  63 */   private static final Http2Exception DECODE_ULE_128_TO_INT_DECOMPRESSION_EXCEPTION = Http2Exception.newStatic(Http2Error.COMPRESSION_ERROR, "HPACK - int overflow", Http2Exception.ShutdownHint.HARD_SHUTDOWN, HpackDecoder.class, "decodeULE128ToInt(..)");
/*     */ 
/*     */   
/*  66 */   private static final Http2Exception DECODE_ILLEGAL_INDEX_VALUE = Http2Exception.newStatic(Http2Error.COMPRESSION_ERROR, "HPACK - illegal index value", Http2Exception.ShutdownHint.HARD_SHUTDOWN, HpackDecoder.class, "decode(..)");
/*     */ 
/*     */   
/*  69 */   private static final Http2Exception INDEX_HEADER_ILLEGAL_INDEX_VALUE = Http2Exception.newStatic(Http2Error.COMPRESSION_ERROR, "HPACK - illegal index value", Http2Exception.ShutdownHint.HARD_SHUTDOWN, HpackDecoder.class, "indexHeader(..)");
/*     */ 
/*     */   
/*  72 */   private static final Http2Exception READ_NAME_ILLEGAL_INDEX_VALUE = Http2Exception.newStatic(Http2Error.COMPRESSION_ERROR, "HPACK - illegal index value", Http2Exception.ShutdownHint.HARD_SHUTDOWN, HpackDecoder.class, "readName(..)");
/*     */ 
/*     */   
/*  75 */   private static final Http2Exception INVALID_MAX_DYNAMIC_TABLE_SIZE = Http2Exception.newStatic(Http2Error.COMPRESSION_ERROR, "HPACK - invalid max dynamic table size", Http2Exception.ShutdownHint.HARD_SHUTDOWN, HpackDecoder.class, "setDynamicTableSize(..)");
/*     */ 
/*     */ 
/*     */   
/*  79 */   private static final Http2Exception MAX_DYNAMIC_TABLE_SIZE_CHANGE_REQUIRED = Http2Exception.newStatic(Http2Error.COMPRESSION_ERROR, "HPACK - max dynamic table size change required", Http2Exception.ShutdownHint.HARD_SHUTDOWN, HpackDecoder.class, "decode(..)");
/*     */   
/*     */   private static final byte READ_HEADER_REPRESENTATION = 0;
/*     */   
/*     */   private static final byte READ_INDEXED_HEADER = 1;
/*     */   private static final byte READ_INDEXED_HEADER_NAME = 2;
/*     */   private static final byte READ_LITERAL_HEADER_NAME_LENGTH_PREFIX = 3;
/*     */   private static final byte READ_LITERAL_HEADER_NAME_LENGTH = 4;
/*     */   private static final byte READ_LITERAL_HEADER_NAME = 5;
/*     */   private static final byte READ_LITERAL_HEADER_VALUE_LENGTH_PREFIX = 6;
/*     */   private static final byte READ_LITERAL_HEADER_VALUE_LENGTH = 7;
/*     */   private static final byte READ_LITERAL_HEADER_VALUE = 8;
/*  91 */   private final HpackHuffmanDecoder huffmanDecoder = new HpackHuffmanDecoder();
/*     */ 
/*     */   
/*     */   private final HpackDynamicTable hpackDynamicTable;
/*     */   
/*     */   private long maxHeaderListSize;
/*     */   
/*     */   private long maxDynamicTableSize;
/*     */   
/*     */   private long encoderMaxDynamicTableSize;
/*     */   
/*     */   private boolean maxDynamicTableSizeChangeRequired;
/*     */ 
/*     */   
/*     */   HpackDecoder(long maxHeaderListSize) {
/* 106 */     this(maxHeaderListSize, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HpackDecoder(long maxHeaderListSize, int maxHeaderTableSize) {
/* 114 */     this.maxHeaderListSize = ObjectUtil.checkPositive(maxHeaderListSize, "maxHeaderListSize");
/*     */     
/* 116 */     this.maxDynamicTableSize = this.encoderMaxDynamicTableSize = maxHeaderTableSize;
/* 117 */     this.maxDynamicTableSizeChangeRequired = false;
/* 118 */     this.hpackDynamicTable = new HpackDynamicTable(maxHeaderTableSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decode(int streamId, ByteBuf in, Http2Headers headers, boolean validateHeaders) throws Http2Exception {
/* 127 */     Http2HeadersSink sink = new Http2HeadersSink(streamId, headers, this.maxHeaderListSize, validateHeaders);
/*     */ 
/*     */ 
/*     */     
/* 131 */     decodeDynamicTableSizeUpdates(in);
/* 132 */     decode(in, sink);
/*     */ 
/*     */ 
/*     */     
/* 136 */     sink.finish();
/*     */   }
/*     */   
/*     */   private void decodeDynamicTableSizeUpdates(ByteBuf in) throws Http2Exception {
/*     */     byte b;
/* 141 */     while (in.isReadable() && ((b = in.getByte(in.readerIndex())) & 0x20) == 32 && (b & 0xC0) == 0) {
/* 142 */       in.readByte();
/* 143 */       int index = b & 0x1F;
/* 144 */       if (index == 31) {
/* 145 */         setDynamicTableSize(decodeULE128(in, index)); continue;
/*     */       } 
/* 147 */       setDynamicTableSize(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void decode(ByteBuf in, Http2HeadersSink sink) throws Http2Exception {
/* 153 */     int index = 0;
/* 154 */     int nameLength = 0;
/* 155 */     int valueLength = 0;
/* 156 */     byte state = 0;
/* 157 */     boolean huffmanEncoded = false;
/* 158 */     AsciiString name = null;
/* 159 */     HpackUtil.IndexType indexType = HpackUtil.IndexType.NONE;
/* 160 */     while (in.isReadable()) {
/* 161 */       byte b; HpackHeaderField indexedHeader; AsciiString value; switch (state) {
/*     */         case 0:
/* 163 */           b = in.readByte();
/* 164 */           if (this.maxDynamicTableSizeChangeRequired && (b & 0xE0) != 32)
/*     */           {
/* 166 */             throw MAX_DYNAMIC_TABLE_SIZE_CHANGE_REQUIRED;
/*     */           }
/* 168 */           if (b < 0) {
/*     */             
/* 170 */             index = b & Byte.MAX_VALUE;
/* 171 */             switch (index) {
/*     */               case 0:
/* 173 */                 throw DECODE_ILLEGAL_INDEX_VALUE;
/*     */               case 127:
/* 175 */                 state = 1;
/*     */                 continue;
/*     */             } 
/* 178 */             HpackHeaderField hpackHeaderField = getIndexedHeader(index);
/* 179 */             sink.appendToHeaderList((AsciiString)hpackHeaderField.name, (AsciiString)hpackHeaderField.value);
/*     */             
/*     */             continue;
/*     */           } 
/* 183 */           if ((b & 0x40) == 64) {
/*     */             
/* 185 */             indexType = HpackUtil.IndexType.INCREMENTAL;
/* 186 */             index = b & 0x3F;
/* 187 */             switch (index) {
/*     */               case 0:
/* 189 */                 state = 3;
/*     */                 continue;
/*     */               case 63:
/* 192 */                 state = 2;
/*     */                 continue;
/*     */             } 
/*     */             
/* 196 */             name = readName(index);
/* 197 */             nameLength = name.length();
/* 198 */             state = 6; continue;
/*     */           } 
/* 200 */           if ((b & 0x20) == 32)
/*     */           {
/*     */             
/* 203 */             throw Http2Exception.connectionError(Http2Error.COMPRESSION_ERROR, "Dynamic table size update must happen at the beginning of the header block", new Object[0]);
/*     */           }
/*     */ 
/*     */           
/* 207 */           indexType = ((b & 0x10) == 16) ? HpackUtil.IndexType.NEVER : HpackUtil.IndexType.NONE;
/* 208 */           index = b & 0xF;
/* 209 */           switch (index) {
/*     */             case 0:
/* 211 */               state = 3;
/*     */               continue;
/*     */             case 15:
/* 214 */               state = 2;
/*     */               continue;
/*     */           } 
/*     */           
/* 218 */           name = readName(index);
/* 219 */           nameLength = name.length();
/* 220 */           state = 6;
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 226 */           indexedHeader = getIndexedHeader(decodeULE128(in, index));
/* 227 */           sink.appendToHeaderList((AsciiString)indexedHeader.name, (AsciiString)indexedHeader.value);
/*     */ 
/*     */           
/* 230 */           state = 0;
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 2:
/* 235 */           name = readName(decodeULE128(in, index));
/* 236 */           nameLength = name.length();
/* 237 */           state = 6;
/*     */           continue;
/*     */         
/*     */         case 3:
/* 241 */           b = in.readByte();
/* 242 */           huffmanEncoded = ((b & 0x80) == 128);
/* 243 */           index = b & Byte.MAX_VALUE;
/* 244 */           if (index == 127) {
/* 245 */             state = 4; continue;
/*     */           } 
/* 247 */           nameLength = index;
/* 248 */           state = 5;
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/* 254 */           nameLength = decodeULE128(in, index);
/*     */           
/* 256 */           state = 5;
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 5:
/* 261 */           if (in.readableBytes() < nameLength) {
/* 262 */             throw notEnoughDataException(in);
/*     */           }
/*     */           
/* 265 */           name = readStringLiteral(in, nameLength, huffmanEncoded);
/*     */           
/* 267 */           state = 6;
/*     */           continue;
/*     */         
/*     */         case 6:
/* 271 */           b = in.readByte();
/* 272 */           huffmanEncoded = ((b & 0x80) == 128);
/* 273 */           index = b & Byte.MAX_VALUE;
/* 274 */           switch (index) {
/*     */             case 127:
/* 276 */               state = 7;
/*     */               continue;
/*     */             case 0:
/* 279 */               insertHeader(sink, name, AsciiString.EMPTY_STRING, indexType);
/* 280 */               state = 0;
/*     */               continue;
/*     */           } 
/* 283 */           valueLength = index;
/* 284 */           state = 8;
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 7:
/* 291 */           valueLength = decodeULE128(in, index);
/*     */           
/* 293 */           state = 8;
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 8:
/* 298 */           if (in.readableBytes() < valueLength) {
/* 299 */             throw notEnoughDataException(in);
/*     */           }
/*     */           
/* 302 */           value = readStringLiteral(in, valueLength, huffmanEncoded);
/* 303 */           insertHeader(sink, name, value, indexType);
/* 304 */           state = 0;
/*     */           continue;
/*     */       } 
/*     */       
/* 308 */       throw new Error("should not reach here state: " + state);
/*     */     } 
/*     */ 
/*     */     
/* 312 */     if (state != 0) {
/* 313 */       throw Http2Exception.connectionError(Http2Error.COMPRESSION_ERROR, "Incomplete header block fragment.", new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMaxHeaderTableSize(long maxHeaderTableSize) throws Http2Exception {
/* 322 */     if (maxHeaderTableSize < 0L || maxHeaderTableSize > 4294967295L)
/* 323 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Header Table Size must be >= %d and <= %d but was %d", new Object[] {
/* 324 */             Long.valueOf(0L), Long.valueOf(4294967295L), Long.valueOf(maxHeaderTableSize)
/*     */           }); 
/* 326 */     this.maxDynamicTableSize = maxHeaderTableSize;
/* 327 */     if (this.maxDynamicTableSize < this.encoderMaxDynamicTableSize) {
/*     */ 
/*     */       
/* 330 */       this.maxDynamicTableSizeChangeRequired = true;
/* 331 */       this.hpackDynamicTable.setCapacity(this.maxDynamicTableSize);
/*     */     } 
/*     */   }
/*     */   
/*     */   void setMaxHeaderListSize(long maxHeaderListSize) throws Http2Exception {
/* 336 */     if (maxHeaderListSize < 0L || maxHeaderListSize > 4294967295L)
/* 337 */       throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Header List Size must be >= %d and <= %d but was %d", new Object[] {
/* 338 */             Long.valueOf(0L), Long.valueOf(4294967295L), Long.valueOf(maxHeaderListSize)
/*     */           }); 
/* 340 */     this.maxHeaderListSize = maxHeaderListSize;
/*     */   }
/*     */   
/*     */   long getMaxHeaderListSize() {
/* 344 */     return this.maxHeaderListSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getMaxHeaderTableSize() {
/* 352 */     return this.hpackDynamicTable.capacity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int length() {
/* 359 */     return this.hpackDynamicTable.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long size() {
/* 366 */     return this.hpackDynamicTable.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HpackHeaderField getHeaderField(int index) {
/* 373 */     return this.hpackDynamicTable.getEntry(index + 1);
/*     */   }
/*     */   
/*     */   private void setDynamicTableSize(long dynamicTableSize) throws Http2Exception {
/* 377 */     if (dynamicTableSize > this.maxDynamicTableSize) {
/* 378 */       throw INVALID_MAX_DYNAMIC_TABLE_SIZE;
/*     */     }
/* 380 */     this.encoderMaxDynamicTableSize = dynamicTableSize;
/* 381 */     this.maxDynamicTableSizeChangeRequired = false;
/* 382 */     this.hpackDynamicTable.setCapacity(dynamicTableSize);
/*     */   }
/*     */ 
/*     */   
/*     */   private static HeaderType validateHeader(int streamId, AsciiString name, CharSequence value, HeaderType previousHeaderType) throws Http2Exception {
/* 387 */     if (Http2Headers.PseudoHeaderName.hasPseudoHeaderFormat((CharSequence)name)) {
/* 388 */       if (previousHeaderType == HeaderType.REGULAR_HEADER) {
/* 389 */         throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Pseudo-header field '%s' found after regular header.", new Object[] { name });
/*     */       }
/*     */       
/* 392 */       Http2Headers.PseudoHeaderName pseudoHeader = Http2Headers.PseudoHeaderName.getPseudoHeader((CharSequence)name);
/* 393 */       HeaderType currentHeaderType = pseudoHeader.isRequestOnly() ? HeaderType.REQUEST_PSEUDO_HEADER : HeaderType.RESPONSE_PSEUDO_HEADER;
/*     */       
/* 395 */       if (previousHeaderType != null && currentHeaderType != previousHeaderType) {
/* 396 */         throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Mix of request and response pseudo-headers.", new Object[0]);
/*     */       }
/* 398 */       return currentHeaderType;
/*     */     } 
/* 400 */     if (HttpHeaderValidationUtil.isConnectionHeader((CharSequence)name, true)) {
/* 401 */       throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Illegal connection-specific header '%s' encountered.", new Object[] { name });
/*     */     }
/* 403 */     if (HttpHeaderValidationUtil.isTeNotTrailers((CharSequence)name, value)) {
/* 404 */       throw Http2Exception.streamError(streamId, Http2Error.PROTOCOL_ERROR, "Illegal value specified for the 'TE' header (only 'trailers' is allowed).", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 408 */     return HeaderType.REGULAR_HEADER;
/*     */   }
/*     */   
/*     */   private AsciiString readName(int index) throws Http2Exception {
/* 412 */     if (index <= HpackStaticTable.length) {
/* 413 */       HpackHeaderField hpackHeaderField = HpackStaticTable.getEntry(index);
/* 414 */       return (AsciiString)hpackHeaderField.name;
/*     */     } 
/* 416 */     if (index - HpackStaticTable.length <= this.hpackDynamicTable.length()) {
/* 417 */       HpackHeaderField hpackHeaderField = this.hpackDynamicTable.getEntry(index - HpackStaticTable.length);
/* 418 */       return (AsciiString)hpackHeaderField.name;
/*     */     } 
/* 420 */     throw READ_NAME_ILLEGAL_INDEX_VALUE;
/*     */   }
/*     */   
/*     */   private HpackHeaderField getIndexedHeader(int index) throws Http2Exception {
/* 424 */     if (index <= HpackStaticTable.length) {
/* 425 */       return HpackStaticTable.getEntry(index);
/*     */     }
/* 427 */     if (index - HpackStaticTable.length <= this.hpackDynamicTable.length()) {
/* 428 */       return this.hpackDynamicTable.getEntry(index - HpackStaticTable.length);
/*     */     }
/* 430 */     throw INDEX_HEADER_ILLEGAL_INDEX_VALUE;
/*     */   }
/*     */   
/*     */   private void insertHeader(Http2HeadersSink sink, AsciiString name, AsciiString value, HpackUtil.IndexType indexType) {
/* 434 */     sink.appendToHeaderList(name, value);
/*     */     
/* 436 */     switch (indexType) {
/*     */       case NONE:
/*     */       case NEVER:
/*     */         return;
/*     */       
/*     */       case INCREMENTAL:
/* 442 */         this.hpackDynamicTable.add(new HpackHeaderField((CharSequence)name, (CharSequence)value));
/*     */     } 
/*     */ 
/*     */     
/* 446 */     throw new Error("should not reach here");
/*     */   }
/*     */ 
/*     */   
/*     */   private AsciiString readStringLiteral(ByteBuf in, int length, boolean huffmanEncoded) throws Http2Exception {
/* 451 */     if (huffmanEncoded) {
/* 452 */       return this.huffmanDecoder.decode(in, length);
/*     */     }
/* 454 */     byte[] buf = new byte[length];
/* 455 */     in.readBytes(buf);
/* 456 */     return new AsciiString(buf, false);
/*     */   }
/*     */   
/*     */   private static IllegalArgumentException notEnoughDataException(ByteBuf in) {
/* 460 */     return new IllegalArgumentException("decode only works with an entire header block! " + in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int decodeULE128(ByteBuf in, int result) throws Http2Exception {
/* 469 */     int readerIndex = in.readerIndex();
/* 470 */     long v = decodeULE128(in, result);
/* 471 */     if (v > 2147483647L) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 477 */       in.readerIndex(readerIndex);
/* 478 */       throw DECODE_ULE_128_TO_INT_DECOMPRESSION_EXCEPTION;
/*     */     } 
/* 480 */     return (int)v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long decodeULE128(ByteBuf in, long result) throws Http2Exception {
/* 489 */     assert result <= 127L && result >= 0L;
/* 490 */     boolean resultStartedAtZero = (result == 0L);
/* 491 */     int writerIndex = in.writerIndex();
/* 492 */     for (int readerIndex = in.readerIndex(), shift = 0; readerIndex < writerIndex; readerIndex++, shift += 7) {
/* 493 */       byte b = in.getByte(readerIndex);
/* 494 */       if (shift == 56 && ((b & 0x80) != 0 || (b == Byte.MAX_VALUE && !resultStartedAtZero)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 502 */         throw DECODE_ULE_128_TO_LONG_DECOMPRESSION_EXCEPTION;
/*     */       }
/*     */       
/* 505 */       if ((b & 0x80) == 0) {
/* 506 */         in.readerIndex(readerIndex + 1);
/* 507 */         return result + ((b & 0x7FL) << shift);
/*     */       } 
/* 509 */       result += (b & 0x7FL) << shift;
/*     */     } 
/*     */     
/* 512 */     throw DECODE_ULE_128_DECOMPRESSION_EXCEPTION;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private enum HeaderType
/*     */   {
/* 519 */     REGULAR_HEADER,
/* 520 */     REQUEST_PSEUDO_HEADER,
/* 521 */     RESPONSE_PSEUDO_HEADER;
/*     */   }
/*     */   
/*     */   private static final class Http2HeadersSink {
/*     */     private final Http2Headers headers;
/*     */     private final long maxHeaderListSize;
/*     */     private final int streamId;
/*     */     private final boolean validateHeaders;
/*     */     private long headersLength;
/*     */     private boolean exceededMaxLength;
/*     */     private HpackDecoder.HeaderType previousType;
/*     */     private Http2Exception validationException;
/*     */     
/*     */     Http2HeadersSink(int streamId, Http2Headers headers, long maxHeaderListSize, boolean validateHeaders) {
/* 535 */       this.headers = headers;
/* 536 */       this.maxHeaderListSize = maxHeaderListSize;
/* 537 */       this.streamId = streamId;
/* 538 */       this.validateHeaders = validateHeaders;
/*     */     }
/*     */     
/*     */     void finish() throws Http2Exception {
/* 542 */       if (this.exceededMaxLength) {
/* 543 */         Http2CodecUtil.headerListSizeExceeded(this.streamId, this.maxHeaderListSize, true);
/* 544 */       } else if (this.validationException != null) {
/* 545 */         throw this.validationException;
/*     */       } 
/*     */     }
/*     */     
/*     */     void appendToHeaderList(AsciiString name, AsciiString value) {
/* 550 */       this.headersLength += HpackHeaderField.sizeOf((CharSequence)name, (CharSequence)value);
/* 551 */       this.exceededMaxLength |= (this.headersLength > this.maxHeaderListSize) ? 1 : 0;
/*     */       
/* 553 */       if (this.exceededMaxLength || this.validationException != null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 559 */         this.headers.add(name, value);
/* 560 */         if (this.validateHeaders) {
/* 561 */           this.previousType = HpackDecoder.validateHeader(this.streamId, name, (CharSequence)value, this.previousType);
/*     */         }
/* 563 */       } catch (IllegalArgumentException ex) {
/* 564 */         this.validationException = Http2Exception.streamError(this.streamId, Http2Error.PROTOCOL_ERROR, ex, "Validation failed for header '%s': %s", new Object[] { name, ex
/* 565 */               .getMessage() });
/* 566 */       } catch (Http2Exception ex) {
/* 567 */         this.validationException = Http2Exception.streamError(this.streamId, Http2Error.PROTOCOL_ERROR, ex, ex.getMessage(), new Object[0]);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\HpackDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */