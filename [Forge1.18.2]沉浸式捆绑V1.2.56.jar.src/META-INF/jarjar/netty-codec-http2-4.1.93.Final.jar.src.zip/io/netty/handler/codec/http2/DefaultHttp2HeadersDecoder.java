/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2HeadersDecoder
/*     */   implements Http2HeadersDecoder, Http2HeadersDecoder.Configuration
/*     */ {
/*     */   private static final float HEADERS_COUNT_WEIGHT_NEW = 0.2F;
/*     */   private static final float HEADERS_COUNT_WEIGHT_HISTORICAL = 0.8F;
/*     */   private final HpackDecoder hpackDecoder;
/*     */   private final boolean validateHeaders;
/*     */   private final boolean validateHeaderValues;
/*     */   private long maxHeaderListSizeGoAway;
/*  41 */   private float headerArraySizeAccumulator = 8.0F;
/*     */   
/*     */   public DefaultHttp2HeadersDecoder() {
/*  44 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2HeadersDecoder(boolean validateHeaders) {
/*  52 */     this(validateHeaders, 8192L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2HeadersDecoder(boolean validateHeaders, boolean validateHeaderValues) {
/*  64 */     this(validateHeaders, validateHeaderValues, 8192L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2HeadersDecoder(boolean validateHeaders, long maxHeaderListSize) {
/*  76 */     this(validateHeaders, false, new HpackDecoder(maxHeaderListSize));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2HeadersDecoder(boolean validateHeaders, boolean validateHeaderValues, long maxHeaderListSize) {
/*  91 */     this(validateHeaders, validateHeaderValues, new HpackDecoder(maxHeaderListSize));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2HeadersDecoder(boolean validateHeaders, long maxHeaderListSize, @Deprecated int initialHuffmanDecodeCapacity) {
/* 106 */     this(validateHeaders, false, new HpackDecoder(maxHeaderListSize));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultHttp2HeadersDecoder(boolean validateHeaders, boolean validateHeaderValues, HpackDecoder hpackDecoder) {
/* 114 */     this.hpackDecoder = (HpackDecoder)ObjectUtil.checkNotNull(hpackDecoder, "hpackDecoder");
/* 115 */     this.validateHeaders = validateHeaders;
/* 116 */     this.validateHeaderValues = validateHeaderValues;
/* 117 */     this
/* 118 */       .maxHeaderListSizeGoAway = Http2CodecUtil.calculateMaxHeaderListSizeGoAway(hpackDecoder.getMaxHeaderListSize());
/*     */   }
/*     */ 
/*     */   
/*     */   public void maxHeaderTableSize(long max) throws Http2Exception {
/* 123 */     this.hpackDecoder.setMaxHeaderTableSize(max);
/*     */   }
/*     */ 
/*     */   
/*     */   public long maxHeaderTableSize() {
/* 128 */     return this.hpackDecoder.getMaxHeaderTableSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void maxHeaderListSize(long max, long goAwayMax) throws Http2Exception {
/* 133 */     if (goAwayMax < max || goAwayMax < 0L)
/* 134 */       throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, "Header List Size GO_AWAY %d must be non-negative and >= %d", new Object[] {
/* 135 */             Long.valueOf(goAwayMax), Long.valueOf(max)
/*     */           }); 
/* 137 */     this.hpackDecoder.setMaxHeaderListSize(max);
/* 138 */     this.maxHeaderListSizeGoAway = goAwayMax;
/*     */   }
/*     */ 
/*     */   
/*     */   public long maxHeaderListSize() {
/* 143 */     return this.hpackDecoder.getMaxHeaderListSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public long maxHeaderListSizeGoAway() {
/* 148 */     return this.maxHeaderListSizeGoAway;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2HeadersDecoder.Configuration configuration() {
/* 153 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers decodeHeaders(int streamId, ByteBuf headerBlock) throws Http2Exception {
/*     */     try {
/* 159 */       Http2Headers headers = newHeaders();
/* 160 */       this.hpackDecoder.decode(streamId, headerBlock, headers, this.validateHeaders);
/* 161 */       this.headerArraySizeAccumulator = 0.2F * headers.size() + 0.8F * this.headerArraySizeAccumulator;
/*     */       
/* 163 */       return headers;
/* 164 */     } catch (Http2Exception e) {
/* 165 */       throw e;
/* 166 */     } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */       
/* 170 */       throw Http2Exception.connectionError(Http2Error.COMPRESSION_ERROR, e, "Error decoding headers: %s", new Object[] { e.getMessage() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int numberOfHeadersGuess() {
/* 179 */     return (int)this.headerArraySizeAccumulator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean validateHeaders() {
/* 191 */     return this.validateHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean validateHeaderValues() {
/* 203 */     return this.validateHeaderValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2Headers newHeaders() {
/* 211 */     return new DefaultHttp2Headers(this.validateHeaders, this.validateHeaderValues, (int)this.headerArraySizeAccumulator);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2HeadersDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */