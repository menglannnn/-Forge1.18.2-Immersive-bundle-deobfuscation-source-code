/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UniformStreamByteDistributor
/*     */   implements StreamByteDistributor
/*     */ {
/*     */   private final Http2Connection.PropertyKey stateKey;
/*  40 */   private final Deque<State> queue = new ArrayDeque<State>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private int minAllocationChunk = 1024;
/*     */   
/*     */   private long totalStreamableBytes;
/*     */   
/*     */   public UniformStreamByteDistributor(Http2Connection connection) {
/*  51 */     this.stateKey = connection.newKey();
/*  52 */     Http2Stream connectionStream = connection.connectionStream();
/*  53 */     connectionStream.setProperty(this.stateKey, new State(connectionStream));
/*     */ 
/*     */     
/*  56 */     connection.addListener(new Http2ConnectionAdapter()
/*     */         {
/*     */           public void onStreamAdded(Http2Stream stream) {
/*  59 */             stream.setProperty(UniformStreamByteDistributor.this.stateKey, new UniformStreamByteDistributor.State(stream));
/*     */           }
/*     */ 
/*     */           
/*     */           public void onStreamClosed(Http2Stream stream) {
/*  64 */             UniformStreamByteDistributor.this.state(stream).close();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void minAllocationChunk(int minAllocationChunk) {
/*  76 */     ObjectUtil.checkPositive(minAllocationChunk, "minAllocationChunk");
/*  77 */     this.minAllocationChunk = minAllocationChunk;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateStreamableBytes(StreamByteDistributor.StreamState streamState) {
/*  82 */     state(streamState.stream()).updateStreamableBytes(Http2CodecUtil.streamableBytes(streamState), streamState
/*  83 */         .hasFrame(), streamState
/*  84 */         .windowSize());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDependencyTree(int childStreamId, int parentStreamId, short weight, boolean exclusive) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean distribute(int maxBytes, StreamByteDistributor.Writer writer) throws Http2Exception {
/*  94 */     int size = this.queue.size();
/*  95 */     if (size == 0) {
/*  96 */       return (this.totalStreamableBytes > 0L);
/*     */     }
/*     */     
/*  99 */     int chunkSize = Math.max(this.minAllocationChunk, maxBytes / size);
/*     */     
/* 101 */     State state = this.queue.pollFirst();
/*     */     do {
/* 103 */       state.enqueued = false;
/* 104 */       if (state.windowNegative) {
/*     */         continue;
/*     */       }
/* 107 */       if (maxBytes == 0 && state.streamableBytes > 0) {
/*     */ 
/*     */ 
/*     */         
/* 111 */         this.queue.addFirst(state);
/* 112 */         state.enqueued = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */       
/* 117 */       int chunk = Math.min(chunkSize, Math.min(maxBytes, state.streamableBytes));
/* 118 */       maxBytes -= chunk;
/*     */ 
/*     */       
/* 121 */       state.write(chunk, writer);
/* 122 */     } while ((state = this.queue.pollFirst()) != null);
/*     */     
/* 124 */     return (this.totalStreamableBytes > 0L);
/*     */   }
/*     */   
/*     */   private State state(Http2Stream stream) {
/* 128 */     return ((Http2Stream)ObjectUtil.checkNotNull(stream, "stream")).<State>getProperty(this.stateKey);
/*     */   }
/*     */ 
/*     */   
/*     */   private final class State
/*     */   {
/*     */     final Http2Stream stream;
/*     */     
/*     */     int streamableBytes;
/*     */     boolean windowNegative;
/*     */     boolean enqueued;
/*     */     boolean writing;
/*     */     
/*     */     State(Http2Stream stream) {
/* 142 */       this.stream = stream;
/*     */     }
/*     */     
/*     */     void updateStreamableBytes(int newStreamableBytes, boolean hasFrame, int windowSize) {
/* 146 */       assert hasFrame || newStreamableBytes == 0 : "hasFrame: " + hasFrame + " newStreamableBytes: " + newStreamableBytes;
/*     */ 
/*     */       
/* 149 */       int delta = newStreamableBytes - this.streamableBytes;
/* 150 */       if (delta != 0) {
/* 151 */         this.streamableBytes = newStreamableBytes;
/* 152 */         UniformStreamByteDistributor.this.totalStreamableBytes = UniformStreamByteDistributor.this.totalStreamableBytes + delta;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 161 */       this.windowNegative = (windowSize < 0);
/* 162 */       if (hasFrame && (windowSize > 0 || (windowSize == 0 && !this.writing))) {
/* 163 */         addToQueue();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void write(int numBytes, StreamByteDistributor.Writer writer) throws Http2Exception {
/* 172 */       this.writing = true;
/*     */       
/*     */       try {
/* 175 */         writer.write(this.stream, numBytes);
/* 176 */       } catch (Throwable t) {
/* 177 */         throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, t, "byte distribution write error", new Object[0]);
/*     */       } finally {
/* 179 */         this.writing = false;
/*     */       } 
/*     */     }
/*     */     
/*     */     void addToQueue() {
/* 184 */       if (!this.enqueued) {
/* 185 */         this.enqueued = true;
/* 186 */         UniformStreamByteDistributor.this.queue.addLast(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     void removeFromQueue() {
/* 191 */       if (this.enqueued) {
/* 192 */         this.enqueued = false;
/* 193 */         UniformStreamByteDistributor.this.queue.remove(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void close() {
/* 199 */       removeFromQueue();
/*     */ 
/*     */       
/* 202 */       updateStreamableBytes(0, false, 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\UniformStreamByteDistributor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */