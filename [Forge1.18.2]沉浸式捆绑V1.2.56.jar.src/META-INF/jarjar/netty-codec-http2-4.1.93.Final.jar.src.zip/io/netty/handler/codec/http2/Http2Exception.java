/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ import io.netty.util.internal.SuppressJava6Requirement;
/*     */ import io.netty.util.internal.ThrowableUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Http2Exception
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -6941186345430164209L;
/*     */   private final Http2Error error;
/*     */   private final ShutdownHint shutdownHint;
/*     */   
/*     */   public Http2Exception(Http2Error error) {
/*  41 */     this(error, ShutdownHint.HARD_SHUTDOWN);
/*     */   }
/*     */   
/*     */   public Http2Exception(Http2Error error, ShutdownHint shutdownHint) {
/*  45 */     this.error = (Http2Error)ObjectUtil.checkNotNull(error, "error");
/*  46 */     this.shutdownHint = (ShutdownHint)ObjectUtil.checkNotNull(shutdownHint, "shutdownHint");
/*     */   }
/*     */   
/*     */   public Http2Exception(Http2Error error, String message) {
/*  50 */     this(error, message, ShutdownHint.HARD_SHUTDOWN);
/*     */   }
/*     */   
/*     */   public Http2Exception(Http2Error error, String message, ShutdownHint shutdownHint) {
/*  54 */     super(message);
/*  55 */     this.error = (Http2Error)ObjectUtil.checkNotNull(error, "error");
/*  56 */     this.shutdownHint = (ShutdownHint)ObjectUtil.checkNotNull(shutdownHint, "shutdownHint");
/*     */   }
/*     */   
/*     */   public Http2Exception(Http2Error error, String message, Throwable cause) {
/*  60 */     this(error, message, cause, ShutdownHint.HARD_SHUTDOWN);
/*     */   }
/*     */   
/*     */   public Http2Exception(Http2Error error, String message, Throwable cause, ShutdownHint shutdownHint) {
/*  64 */     super(message, cause);
/*  65 */     this.error = (Http2Error)ObjectUtil.checkNotNull(error, "error");
/*  66 */     this.shutdownHint = (ShutdownHint)ObjectUtil.checkNotNull(shutdownHint, "shutdownHint");
/*     */   }
/*     */ 
/*     */   
/*     */   static Http2Exception newStatic(Http2Error error, String message, ShutdownHint shutdownHint, Class<?> clazz, String method) {
/*     */     Http2Exception exception;
/*  72 */     if (PlatformDependent.javaVersion() >= 7) {
/*  73 */       exception = new StacklessHttp2Exception(error, message, shutdownHint, true);
/*     */     } else {
/*  75 */       exception = new StacklessHttp2Exception(error, message, shutdownHint);
/*     */     } 
/*  77 */     return (Http2Exception)ThrowableUtil.unknownStackTrace(exception, clazz, method);
/*     */   }
/*     */ 
/*     */   
/*     */   @SuppressJava6Requirement(reason = "uses Java 7+ Exception.<init>(String, Throwable, boolean, boolean) but is guarded by version checks")
/*     */   private Http2Exception(Http2Error error, String message, ShutdownHint shutdownHint, boolean shared) {
/*  83 */     super(message, null, false, true);
/*  84 */     assert shared;
/*  85 */     this.error = (Http2Error)ObjectUtil.checkNotNull(error, "error");
/*  86 */     this.shutdownHint = (ShutdownHint)ObjectUtil.checkNotNull(shutdownHint, "shutdownHint");
/*     */   }
/*     */   
/*     */   public Http2Error error() {
/*  90 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShutdownHint shutdownHint() {
/*  97 */     return this.shutdownHint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2Exception connectionError(Http2Error error, String fmt, Object... args) {
/* 109 */     return new Http2Exception(error, formatErrorMessage(fmt, args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2Exception connectionError(Http2Error error, Throwable cause, String fmt, Object... args) {
/* 123 */     return new Http2Exception(error, formatErrorMessage(fmt, args), cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2Exception closedStreamError(Http2Error error, String fmt, Object... args) {
/* 135 */     return new ClosedStreamCreationException(error, formatErrorMessage(fmt, args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2Exception streamError(int id, Http2Error error, String fmt, Object... args) {
/* 151 */     return (0 == id) ? 
/* 152 */       connectionError(error, fmt, args) : new StreamException(id, error, 
/* 153 */         formatErrorMessage(fmt, args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2Exception streamError(int id, Http2Error error, Throwable cause, String fmt, Object... args) {
/* 171 */     return (0 == id) ? 
/* 172 */       connectionError(error, cause, fmt, args) : new StreamException(id, error, 
/* 173 */         formatErrorMessage(fmt, args), cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Http2Exception headerListSizeError(int id, Http2Error error, boolean onDecode, String fmt, Object... args) {
/* 193 */     return (0 == id) ? 
/* 194 */       connectionError(error, fmt, args) : new HeaderListSizeException(id, error, 
/* 195 */         formatErrorMessage(fmt, args), onDecode);
/*     */   }
/*     */   
/*     */   private static String formatErrorMessage(String fmt, Object[] args) {
/* 199 */     if (fmt == null) {
/* 200 */       if (args == null || args.length == 0) {
/* 201 */         return "Unexpected error";
/*     */       }
/* 203 */       return "Unexpected error: " + Arrays.toString(args);
/*     */     } 
/* 205 */     return String.format(fmt, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStreamError(Http2Exception e) {
/* 215 */     return e instanceof StreamException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int streamId(Http2Exception e) {
/* 225 */     return isStreamError(e) ? ((StreamException)e).streamId() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ShutdownHint
/*     */   {
/* 235 */     NO_SHUTDOWN,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     GRACEFUL_SHUTDOWN,
/*     */ 
/*     */ 
/*     */     
/* 244 */     HARD_SHUTDOWN;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class ClosedStreamCreationException
/*     */     extends Http2Exception
/*     */   {
/*     */     private static final long serialVersionUID = -6746542974372246206L;
/*     */     
/*     */     public ClosedStreamCreationException(Http2Error error) {
/* 254 */       super(error);
/*     */     }
/*     */     
/*     */     public ClosedStreamCreationException(Http2Error error, String message) {
/* 258 */       super(error, message);
/*     */     }
/*     */     
/*     */     public ClosedStreamCreationException(Http2Error error, String message, Throwable cause) {
/* 262 */       super(error, message, cause);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class StreamException
/*     */     extends Http2Exception
/*     */   {
/*     */     private static final long serialVersionUID = 602472544416984384L;
/*     */     private final int streamId;
/*     */     
/*     */     StreamException(int streamId, Http2Error error, String message) {
/* 274 */       super(error, message, Http2Exception.ShutdownHint.NO_SHUTDOWN);
/* 275 */       this.streamId = streamId;
/*     */     }
/*     */     
/*     */     StreamException(int streamId, Http2Error error, String message, Throwable cause) {
/* 279 */       super(error, message, cause, Http2Exception.ShutdownHint.NO_SHUTDOWN);
/* 280 */       this.streamId = streamId;
/*     */     }
/*     */     
/*     */     public int streamId() {
/* 284 */       return this.streamId;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class HeaderListSizeException
/*     */     extends StreamException {
/*     */     private static final long serialVersionUID = -8807603212183882637L;
/*     */     private final boolean decode;
/*     */     
/*     */     HeaderListSizeException(int streamId, Http2Error error, String message, boolean decode) {
/* 294 */       super(streamId, error, message);
/* 295 */       this.decode = decode;
/*     */     }
/*     */     
/*     */     public boolean duringDecode() {
/* 299 */       return this.decode;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class CompositeStreamException
/*     */     extends Http2Exception
/*     */     implements Iterable<StreamException>
/*     */   {
/*     */     private static final long serialVersionUID = 7091134858213711015L;
/*     */     private final List<Http2Exception.StreamException> exceptions;
/*     */     
/*     */     public CompositeStreamException(Http2Error error, int initialCapacity) {
/* 311 */       super(error, Http2Exception.ShutdownHint.NO_SHUTDOWN);
/* 312 */       this.exceptions = new ArrayList<Http2Exception.StreamException>(initialCapacity);
/*     */     }
/*     */     
/*     */     public void add(Http2Exception.StreamException e) {
/* 316 */       this.exceptions.add(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Http2Exception.StreamException> iterator() {
/* 321 */       return this.exceptions.iterator();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class StacklessHttp2Exception
/*     */     extends Http2Exception {
/*     */     private static final long serialVersionUID = 1077888485687219443L;
/*     */     
/*     */     StacklessHttp2Exception(Http2Error error, String message, Http2Exception.ShutdownHint shutdownHint) {
/* 330 */       super(error, message, shutdownHint);
/*     */     }
/*     */     
/*     */     StacklessHttp2Exception(Http2Error error, String message, Http2Exception.ShutdownHint shutdownHint, boolean shared) {
/* 334 */       super(error, message, shutdownHint, shared);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Throwable fillInStackTrace() {
/* 341 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2Exception.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */