/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Http2MultiplexActiveStreamsException
/*    */   extends Exception
/*    */ {
/*    */   public Http2MultiplexActiveStreamsException(Throwable cause) {
/* 26 */     super(cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable fillInStackTrace() {
/* 31 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2MultiplexActiveStreamsException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */