/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.ByteBufUtil;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.UnsupportedMessageTypeException;
/*     */ import io.netty.handler.codec.http.FullHttpMessage;
/*     */ import io.netty.handler.codec.http.HttpServerUpgradeHandler;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ import io.netty.util.collection.IntObjectHashMap;
/*     */ import io.netty.util.collection.IntObjectMap;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.logging.InternalLogLevel;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Http2FrameCodec
/*     */   extends Http2ConnectionHandler
/*     */ {
/* 150 */   private static final InternalLogger LOG = InternalLoggerFactory.getInstance(Http2FrameCodec.class);
/*     */ 
/*     */   
/*     */   protected final Http2Connection.PropertyKey streamKey;
/*     */   
/*     */   private final Http2Connection.PropertyKey upgradeKey;
/*     */   
/*     */   private final Integer initialFlowControlWindowSize;
/*     */   
/*     */   ChannelHandlerContext ctx;
/*     */   
/*     */   private int numBufferedStreams;
/*     */   
/* 163 */   private final IntObjectMap<DefaultHttp2FrameStream> frameStreamToInitializeMap = (IntObjectMap<DefaultHttp2FrameStream>)new IntObjectHashMap(8);
/*     */ 
/*     */ 
/*     */   
/*     */   Http2FrameCodec(Http2ConnectionEncoder encoder, Http2ConnectionDecoder decoder, Http2Settings initialSettings, boolean decoupleCloseAndGoAway, boolean flushPreface) {
/* 168 */     super(decoder, encoder, initialSettings, decoupleCloseAndGoAway, flushPreface);
/*     */     
/* 170 */     decoder.frameListener(new FrameListener());
/* 171 */     connection().addListener(new ConnectionListener());
/* 172 */     ((Http2RemoteFlowController)connection().remote().flowController()).listener(new Http2RemoteFlowControllerListener());
/* 173 */     this.streamKey = connection().newKey();
/* 174 */     this.upgradeKey = connection().newKey();
/* 175 */     this.initialFlowControlWindowSize = initialSettings.initialWindowSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultHttp2FrameStream newStream() {
/* 182 */     return new DefaultHttp2FrameStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void forEachActiveStream(final Http2FrameStreamVisitor streamVisitor) throws Http2Exception {
/* 191 */     assert this.ctx.executor().inEventLoop();
/* 192 */     if (connection().numActiveStreams() > 0) {
/* 193 */       connection().forEachActiveStream(new Http2StreamVisitor()
/*     */           {
/*     */             public boolean visit(Http2Stream stream) {
/*     */               try {
/* 197 */                 return streamVisitor.visit(stream.<Http2FrameStream>getProperty(Http2FrameCodec.this.streamKey));
/* 198 */               } catch (Throwable cause) {
/* 199 */                 Http2FrameCodec.this.onError(Http2FrameCodec.this.ctx, false, cause);
/* 200 */                 return false;
/*     */               } 
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int numInitializingStreams() {
/* 213 */     return this.frameStreamToInitializeMap.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void handlerAdded(ChannelHandlerContext ctx) throws Exception {
/* 218 */     this.ctx = ctx;
/* 219 */     super.handlerAdded(ctx);
/* 220 */     handlerAdded0(ctx);
/*     */ 
/*     */     
/* 223 */     Http2Connection connection = connection();
/* 224 */     if (connection.isServer()) {
/* 225 */       tryExpandConnectionFlowControlWindow(connection);
/*     */     }
/*     */   }
/*     */   
/*     */   private void tryExpandConnectionFlowControlWindow(Http2Connection connection) throws Http2Exception {
/* 230 */     if (this.initialFlowControlWindowSize != null) {
/*     */ 
/*     */       
/* 233 */       Http2Stream connectionStream = connection.connectionStream();
/* 234 */       Http2LocalFlowController localFlowController = connection.local().flowController();
/* 235 */       int delta = this.initialFlowControlWindowSize.intValue() - localFlowController.initialWindowSize(connectionStream);
/*     */       
/* 237 */       if (delta > 0) {
/*     */         
/* 239 */         localFlowController.incrementWindowSize(connectionStream, Math.max(delta << 1, delta));
/* 240 */         flush(this.ctx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handlerAdded0(ChannelHandlerContext ctx) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void userEventTriggered(final ChannelHandlerContext ctx, final Object evt) throws Exception {
/* 255 */     if (evt == Http2ConnectionPrefaceAndSettingsFrameWrittenEvent.INSTANCE) {
/*     */       
/* 257 */       tryExpandConnectionFlowControlWindow(connection());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       ctx.executor().execute(new Runnable()
/*     */           {
/*     */             public void run() {
/* 265 */               ctx.fireUserEventTriggered(evt);
/*     */             }
/*     */           });
/* 268 */     } else if (evt instanceof HttpServerUpgradeHandler.UpgradeEvent) {
/* 269 */       HttpServerUpgradeHandler.UpgradeEvent upgrade = (HttpServerUpgradeHandler.UpgradeEvent)evt;
/*     */       try {
/* 271 */         onUpgradeEvent(ctx, upgrade.retain());
/* 272 */         Http2Stream stream = connection().stream(1);
/* 273 */         if (stream.getProperty(this.streamKey) == null)
/*     */         {
/*     */ 
/*     */           
/* 277 */           onStreamActive0(stream);
/*     */         }
/* 279 */         upgrade.upgradeRequest().headers().setInt((CharSequence)HttpConversionUtil.ExtensionHeaderNames.STREAM_ID
/* 280 */             .text(), 1);
/* 281 */         stream.setProperty(this.upgradeKey, Boolean.valueOf(true));
/* 282 */         InboundHttpToHttp2Adapter.handle(ctx, 
/* 283 */             connection(), decoder().frameListener(), (FullHttpMessage)upgrade.upgradeRequest().retain());
/*     */       } finally {
/* 285 */         upgrade.release();
/*     */       } 
/*     */     } else {
/* 288 */       onUserEventTriggered(ctx, evt);
/* 289 */       ctx.fireUserEventTriggered(evt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void onUserEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/* 303 */     if (msg instanceof Http2DataFrame) {
/* 304 */       Http2DataFrame dataFrame = (Http2DataFrame)msg;
/* 305 */       encoder().writeData(ctx, dataFrame.stream().id(), dataFrame.content(), dataFrame
/* 306 */           .padding(), dataFrame.isEndStream(), promise);
/* 307 */     } else if (msg instanceof Http2HeadersFrame) {
/* 308 */       writeHeadersFrame(ctx, (Http2HeadersFrame)msg, promise);
/* 309 */     } else if (msg instanceof Http2WindowUpdateFrame) {
/* 310 */       Http2WindowUpdateFrame frame = (Http2WindowUpdateFrame)msg;
/* 311 */       Http2FrameStream frameStream = frame.stream();
/*     */ 
/*     */       
/*     */       try {
/* 315 */         if (frameStream == null) {
/* 316 */           increaseInitialConnectionWindow(frame.windowSizeIncrement());
/*     */         } else {
/* 318 */           consumeBytes(frameStream.id(), frame.windowSizeIncrement());
/*     */         } 
/* 320 */         promise.setSuccess();
/* 321 */       } catch (Throwable t) {
/* 322 */         promise.setFailure(t);
/*     */       } 
/* 324 */     } else if (msg instanceof Http2ResetFrame) {
/* 325 */       Http2ResetFrame rstFrame = (Http2ResetFrame)msg;
/* 326 */       int id = rstFrame.stream().id();
/*     */ 
/*     */       
/* 329 */       if (connection().streamMayHaveExisted(id)) {
/* 330 */         encoder().writeRstStream(ctx, rstFrame.stream().id(), rstFrame.errorCode(), promise);
/*     */       } else {
/* 332 */         ReferenceCountUtil.release(rstFrame);
/* 333 */         promise.setFailure(Http2Exception.streamError(rstFrame
/* 334 */               .stream().id(), Http2Error.PROTOCOL_ERROR, "Stream never existed", new Object[0]));
/*     */       } 
/* 336 */     } else if (msg instanceof Http2PingFrame) {
/* 337 */       Http2PingFrame frame = (Http2PingFrame)msg;
/* 338 */       encoder().writePing(ctx, frame.ack(), frame.content(), promise);
/* 339 */     } else if (msg instanceof Http2SettingsFrame) {
/* 340 */       encoder().writeSettings(ctx, ((Http2SettingsFrame)msg).settings(), promise);
/* 341 */     } else if (msg instanceof Http2SettingsAckFrame) {
/*     */ 
/*     */       
/* 344 */       encoder().writeSettingsAck(ctx, promise);
/* 345 */     } else if (msg instanceof Http2GoAwayFrame) {
/* 346 */       writeGoAwayFrame(ctx, (Http2GoAwayFrame)msg, promise);
/* 347 */     } else if (msg instanceof Http2PushPromiseFrame) {
/* 348 */       Http2PushPromiseFrame pushPromiseFrame = (Http2PushPromiseFrame)msg;
/* 349 */       writePushPromise(ctx, pushPromiseFrame, promise);
/* 350 */     } else if (msg instanceof Http2PriorityFrame) {
/* 351 */       Http2PriorityFrame priorityFrame = (Http2PriorityFrame)msg;
/* 352 */       encoder().writePriority(ctx, priorityFrame.stream().id(), priorityFrame.streamDependency(), priorityFrame
/* 353 */           .weight(), priorityFrame.exclusive(), promise);
/* 354 */     } else if (msg instanceof Http2UnknownFrame) {
/* 355 */       Http2UnknownFrame unknownFrame = (Http2UnknownFrame)msg;
/* 356 */       encoder().writeFrame(ctx, unknownFrame.frameType(), unknownFrame.stream().id(), unknownFrame
/* 357 */           .flags(), unknownFrame.content(), promise);
/* 358 */     } else if (!(msg instanceof Http2Frame)) {
/* 359 */       ctx.write(msg, promise);
/*     */     } else {
/* 361 */       ReferenceCountUtil.release(msg);
/* 362 */       throw new UnsupportedMessageTypeException(msg, new Class[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void increaseInitialConnectionWindow(int deltaBytes) throws Http2Exception {
/* 368 */     ((Http2LocalFlowController)connection().local().flowController()).incrementWindowSize(connection().connectionStream(), deltaBytes);
/*     */   }
/*     */   
/*     */   final boolean consumeBytes(int streamId, int bytes) throws Http2Exception {
/* 372 */     Http2Stream stream = connection().stream(streamId);
/*     */ 
/*     */     
/* 375 */     if (stream != null && streamId == 1) {
/* 376 */       Boolean upgraded = stream.<Boolean>getProperty(this.upgradeKey);
/* 377 */       if (Boolean.TRUE.equals(upgraded)) {
/* 378 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 382 */     return ((Http2LocalFlowController)connection().local().flowController()).consumeBytes(stream, bytes);
/*     */   }
/*     */   
/*     */   private void writeGoAwayFrame(ChannelHandlerContext ctx, Http2GoAwayFrame frame, ChannelPromise promise) {
/* 386 */     if (frame.lastStreamId() > -1) {
/* 387 */       frame.release();
/* 388 */       throw new IllegalArgumentException("Last stream id must not be set on GOAWAY frame");
/*     */     } 
/*     */     
/* 391 */     int lastStreamCreated = connection().remote().lastStreamCreated();
/* 392 */     long lastStreamId = lastStreamCreated + frame.extraStreamIds() * 2L;
/*     */     
/* 394 */     if (lastStreamId > 2147483647L) {
/* 395 */       lastStreamId = 2147483647L;
/*     */     }
/* 397 */     goAway(ctx, (int)lastStreamId, frame.errorCode(), frame.content(), promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeHeadersFrame(ChannelHandlerContext ctx, Http2HeadersFrame headersFrame, ChannelPromise promise) {
/* 403 */     if (Http2CodecUtil.isStreamIdValid(headersFrame.stream().id())) {
/* 404 */       encoder().writeHeaders(ctx, headersFrame.stream().id(), headersFrame.headers(), headersFrame.padding(), headersFrame
/* 405 */           .isEndStream(), promise);
/* 406 */     } else if (initializeNewStream(ctx, (DefaultHttp2FrameStream)headersFrame.stream(), promise)) {
/* 407 */       final int streamId = headersFrame.stream().id();
/*     */       
/* 409 */       encoder().writeHeaders(ctx, streamId, headersFrame.headers(), headersFrame.padding(), headersFrame
/* 410 */           .isEndStream(), promise);
/*     */       
/* 412 */       if (!promise.isDone()) {
/* 413 */         this.numBufferedStreams++;
/*     */ 
/*     */         
/* 416 */         promise.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */             {
/*     */               public void operationComplete(ChannelFuture channelFuture) {
/* 419 */                 Http2FrameCodec.this.numBufferedStreams--;
/* 420 */                 Http2FrameCodec.this.handleHeaderFuture(channelFuture, streamId);
/*     */               }
/*     */             });
/*     */       } else {
/* 424 */         handleHeaderFuture((ChannelFuture)promise, streamId);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writePushPromise(ChannelHandlerContext ctx, Http2PushPromiseFrame pushPromiseFrame, ChannelPromise promise) {
/* 431 */     if (Http2CodecUtil.isStreamIdValid(pushPromiseFrame.pushStream().id())) {
/* 432 */       encoder().writePushPromise(ctx, pushPromiseFrame.stream().id(), pushPromiseFrame.pushStream().id(), pushPromiseFrame
/* 433 */           .http2Headers(), pushPromiseFrame.padding(), promise);
/* 434 */     } else if (initializeNewStream(ctx, (DefaultHttp2FrameStream)pushPromiseFrame.pushStream(), promise)) {
/* 435 */       final int streamId = pushPromiseFrame.stream().id();
/* 436 */       encoder().writePushPromise(ctx, streamId, pushPromiseFrame.pushStream().id(), pushPromiseFrame
/* 437 */           .http2Headers(), pushPromiseFrame.padding(), promise);
/*     */       
/* 439 */       if (promise.isDone()) {
/* 440 */         handleHeaderFuture((ChannelFuture)promise, streamId);
/*     */       } else {
/* 442 */         this.numBufferedStreams++;
/*     */ 
/*     */         
/* 445 */         promise.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */             {
/*     */               public void operationComplete(ChannelFuture channelFuture) {
/* 448 */                 Http2FrameCodec.this.numBufferedStreams--;
/* 449 */                 Http2FrameCodec.this.handleHeaderFuture(channelFuture, streamId);
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean initializeNewStream(ChannelHandlerContext ctx, DefaultHttp2FrameStream http2FrameStream, ChannelPromise promise) {
/* 458 */     Http2Connection connection = connection();
/* 459 */     int streamId = connection.local().incrementAndGetNextStreamId();
/* 460 */     if (streamId < 0) {
/* 461 */       promise.setFailure(new Http2NoMoreStreamIdsException());
/*     */ 
/*     */ 
/*     */       
/* 465 */       onHttp2Frame(ctx, new DefaultHttp2GoAwayFrame(connection.isServer() ? Integer.MAX_VALUE : 2147483646, Http2Error.NO_ERROR
/* 466 */             .code(), 
/* 467 */             ByteBufUtil.writeAscii(ctx.alloc(), "Stream IDs exhausted on local stream creation")));
/*     */       
/* 469 */       return false;
/*     */     } 
/* 471 */     http2FrameStream.id = streamId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     Object old = this.frameStreamToInitializeMap.put(streamId, http2FrameStream);
/*     */ 
/*     */     
/* 481 */     assert old == null;
/* 482 */     return true;
/*     */   }
/*     */   
/*     */   private void handleHeaderFuture(ChannelFuture channelFuture, int streamId) {
/* 486 */     if (!channelFuture.isSuccess()) {
/* 487 */       this.frameStreamToInitializeMap.remove(streamId);
/*     */     }
/*     */   }
/*     */   
/*     */   private void onStreamActive0(Http2Stream stream) {
/* 492 */     if (stream.id() != 1 && 
/* 493 */       connection().local().isValidStreamId(stream.id())) {
/*     */       return;
/*     */     }
/*     */     
/* 497 */     DefaultHttp2FrameStream stream2 = newStream().setStreamAndProperty(this.streamKey, stream);
/* 498 */     onHttp2StreamStateChanged(this.ctx, stream2);
/*     */   }
/*     */   
/*     */   private final class ConnectionListener
/*     */     extends Http2ConnectionAdapter {
/*     */     public void onStreamAdded(Http2Stream stream) {
/* 504 */       Http2FrameCodec.DefaultHttp2FrameStream frameStream = (Http2FrameCodec.DefaultHttp2FrameStream)Http2FrameCodec.this.frameStreamToInitializeMap.remove(stream.id());
/*     */       
/* 506 */       if (frameStream != null)
/* 507 */         frameStream.setStreamAndProperty(Http2FrameCodec.this.streamKey, stream); 
/*     */     }
/*     */     
/*     */     private ConnectionListener() {}
/*     */     
/*     */     public void onStreamActive(Http2Stream stream) {
/* 513 */       Http2FrameCodec.this.onStreamActive0(stream);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStreamClosed(Http2Stream stream) {
/* 518 */       onHttp2StreamStateChanged0(stream);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onStreamHalfClosed(Http2Stream stream) {
/* 523 */       onHttp2StreamStateChanged0(stream);
/*     */     }
/*     */     
/*     */     private void onHttp2StreamStateChanged0(Http2Stream stream) {
/* 527 */       Http2FrameCodec.DefaultHttp2FrameStream stream2 = stream.<Http2FrameCodec.DefaultHttp2FrameStream>getProperty(Http2FrameCodec.this.streamKey);
/* 528 */       if (stream2 != null) {
/* 529 */         Http2FrameCodec.this.onHttp2StreamStateChanged(Http2FrameCodec.this.ctx, stream2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onConnectionError(ChannelHandlerContext ctx, boolean outbound, Throwable cause, Http2Exception http2Ex) {
/* 537 */     if (!outbound)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 542 */       ctx.fireExceptionCaught(cause);
/*     */     }
/* 544 */     super.onConnectionError(ctx, outbound, cause, http2Ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void onStreamError(ChannelHandlerContext ctx, boolean outbound, Throwable cause, Http2Exception.StreamException streamException) {
/* 554 */     int streamId = streamException.streamId();
/* 555 */     Http2Stream connectionStream = connection().stream(streamId);
/* 556 */     if (connectionStream == null) {
/* 557 */       onHttp2UnknownStreamError(ctx, cause, streamException);
/*     */       
/* 559 */       super.onStreamError(ctx, outbound, cause, streamException);
/*     */       
/*     */       return;
/*     */     } 
/* 563 */     Http2FrameStream stream = connectionStream.<Http2FrameStream>getProperty(this.streamKey);
/* 564 */     if (stream == null) {
/* 565 */       LOG.warn("Stream exception thrown without stream object attached.", cause);
/*     */       
/* 567 */       super.onStreamError(ctx, outbound, cause, streamException);
/*     */       
/*     */       return;
/*     */     } 
/* 571 */     if (!outbound)
/*     */     {
/* 573 */       onHttp2FrameStreamException(ctx, new Http2FrameStreamException(stream, streamException.error(), cause));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void onHttp2UnknownStreamError(ChannelHandlerContext ctx, Throwable cause, Http2Exception.StreamException streamException) {
/* 584 */     LOG.log(InternalLogLevel.DEBUG, "Stream exception thrown for unknown stream {}.", Integer.valueOf(streamException.streamId()), cause);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final boolean isGracefulShutdownComplete() {
/* 589 */     return (super.isGracefulShutdownComplete() && this.numBufferedStreams == 0);
/*     */   }
/*     */   
/*     */   private final class FrameListener
/*     */     implements Http2FrameListener {
/*     */     private FrameListener() {}
/*     */     
/*     */     public void onUnknownFrame(ChannelHandlerContext ctx, byte frameType, int streamId, Http2Flags flags, ByteBuf payload) {
/* 597 */       if (streamId == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 601 */       Http2FrameCodec.this.onHttp2Frame(ctx, (new DefaultHttp2UnknownFrame(frameType, flags, payload))
/* 602 */           .stream(requireStream(streamId)).retain());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSettingsRead(ChannelHandlerContext ctx, Http2Settings settings) {
/* 607 */       Http2FrameCodec.this.onHttp2Frame(ctx, new DefaultHttp2SettingsFrame(settings));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onPingRead(ChannelHandlerContext ctx, long data) {
/* 612 */       Http2FrameCodec.this.onHttp2Frame(ctx, new DefaultHttp2PingFrame(data, false));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onPingAckRead(ChannelHandlerContext ctx, long data) {
/* 617 */       Http2FrameCodec.this.onHttp2Frame(ctx, new DefaultHttp2PingFrame(data, true));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onRstStreamRead(ChannelHandlerContext ctx, int streamId, long errorCode) {
/* 622 */       Http2FrameCodec.this.onHttp2Frame(ctx, (new DefaultHttp2ResetFrame(errorCode)).stream(requireStream(streamId)));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onWindowUpdateRead(ChannelHandlerContext ctx, int streamId, int windowSizeIncrement) {
/* 627 */       if (streamId == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 631 */       Http2FrameCodec.this.onHttp2Frame(ctx, (new DefaultHttp2WindowUpdateFrame(windowSizeIncrement)).stream(requireStream(streamId)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endStream) {
/* 638 */       onHeadersRead(ctx, streamId, headers, padding, endStream);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onHeadersRead(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endOfStream) {
/* 644 */       Http2FrameCodec.this.onHttp2Frame(ctx, (new DefaultHttp2HeadersFrame(headers, endOfStream, padding))
/* 645 */           .stream(requireStream(streamId)));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int onDataRead(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream) {
/* 651 */       Http2FrameCodec.this.onHttp2Frame(ctx, (new DefaultHttp2DataFrame(data, endOfStream, padding))
/* 652 */           .stream(requireStream(streamId)).retain());
/*     */       
/* 654 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onGoAwayRead(ChannelHandlerContext ctx, int lastStreamId, long errorCode, ByteBuf debugData) {
/* 659 */       Http2FrameCodec.this.onHttp2Frame(ctx, (new DefaultHttp2GoAwayFrame(lastStreamId, errorCode, debugData)).retain());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onPriorityRead(ChannelHandlerContext ctx, int streamId, int streamDependency, short weight, boolean exclusive) {
/* 666 */       Http2Stream stream = Http2FrameCodec.this.connection().stream(streamId);
/* 667 */       if (stream == null) {
/*     */         return;
/*     */       }
/*     */       
/* 671 */       Http2FrameCodec.this.onHttp2Frame(ctx, (new DefaultHttp2PriorityFrame(streamDependency, weight, exclusive))
/* 672 */           .stream(requireStream(streamId)));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSettingsAckRead(ChannelHandlerContext ctx) {
/* 677 */       Http2FrameCodec.this.onHttp2Frame(ctx, Http2SettingsAckFrame.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onPushPromiseRead(ChannelHandlerContext ctx, int streamId, int promisedStreamId, Http2Headers headers, int padding) {
/* 683 */       Http2FrameCodec.this.onHttp2Frame(ctx, (new DefaultHttp2PushPromiseFrame(headers, padding, promisedStreamId))
/* 684 */           .pushStream((new Http2FrameCodec.DefaultHttp2FrameStream())
/* 685 */             .setStreamAndProperty(Http2FrameCodec.this.streamKey, Http2FrameCodec.this.connection().stream(promisedStreamId)))
/* 686 */           .stream(requireStream(streamId)));
/*     */     }
/*     */     
/*     */     private Http2FrameStream requireStream(int streamId) {
/* 690 */       Http2FrameStream stream = Http2FrameCodec.this.connection().stream(streamId).<Http2FrameStream>getProperty(Http2FrameCodec.this.streamKey);
/* 691 */       if (stream == null) {
/* 692 */         throw new IllegalStateException("Stream object required for identifier: " + streamId);
/*     */       }
/* 694 */       return stream;
/*     */     }
/*     */   }
/*     */   
/*     */   private void onUpgradeEvent(ChannelHandlerContext ctx, HttpServerUpgradeHandler.UpgradeEvent evt) {
/* 699 */     ctx.fireUserEventTriggered(evt);
/*     */   }
/*     */ 
/*     */   
/*     */   private void onHttp2StreamWritabilityChanged(ChannelHandlerContext ctx, DefaultHttp2FrameStream stream, boolean writable) {
/* 704 */     ctx.fireUserEventTriggered(stream.writabilityChanged);
/*     */   }
/*     */   
/*     */   void onHttp2StreamStateChanged(ChannelHandlerContext ctx, DefaultHttp2FrameStream stream) {
/* 708 */     ctx.fireUserEventTriggered(stream.stateChanged);
/*     */   }
/*     */   
/*     */   void onHttp2Frame(ChannelHandlerContext ctx, Http2Frame frame) {
/* 712 */     ctx.fireChannelRead(frame);
/*     */   }
/*     */   
/*     */   void onHttp2FrameStreamException(ChannelHandlerContext ctx, Http2FrameStreamException cause) {
/* 716 */     ctx.fireExceptionCaught(cause);
/*     */   }
/*     */   
/*     */   private final class Http2RemoteFlowControllerListener
/*     */     implements Http2RemoteFlowController.Listener {
/*     */     public void writabilityChanged(Http2Stream stream) {
/* 722 */       Http2FrameCodec.DefaultHttp2FrameStream frameStream = stream.<Http2FrameCodec.DefaultHttp2FrameStream>getProperty(Http2FrameCodec.this.streamKey);
/* 723 */       if (frameStream == null) {
/*     */         return;
/*     */       }
/* 726 */       Http2FrameCodec.this.onHttp2StreamWritabilityChanged(Http2FrameCodec.this.ctx, frameStream, ((Http2RemoteFlowController)Http2FrameCodec.this
/* 727 */           .connection().remote().flowController()).isWritable(stream));
/*     */     }
/*     */ 
/*     */     
/*     */     private Http2RemoteFlowControllerListener() {}
/*     */   }
/*     */   
/*     */   static class DefaultHttp2FrameStream
/*     */     implements Http2FrameStream
/*     */   {
/* 737 */     private volatile int id = -1;
/*     */     
/*     */     private volatile Http2Stream stream;
/* 740 */     final Http2FrameStreamEvent stateChanged = Http2FrameStreamEvent.stateChanged(this);
/* 741 */     final Http2FrameStreamEvent writabilityChanged = Http2FrameStreamEvent.writabilityChanged(this);
/*     */     
/*     */     Channel attachment;
/*     */     
/*     */     DefaultHttp2FrameStream setStreamAndProperty(Http2Connection.PropertyKey streamKey, Http2Stream stream) {
/* 746 */       assert this.id == -1 || stream.id() == this.id;
/* 747 */       this.stream = stream;
/* 748 */       stream.setProperty(streamKey, this);
/* 749 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public int id() {
/* 754 */       Http2Stream stream = this.stream;
/* 755 */       return (stream == null) ? this.id : stream.id();
/*     */     }
/*     */ 
/*     */     
/*     */     public Http2Stream.State state() {
/* 760 */       Http2Stream stream = this.stream;
/* 761 */       return (stream == null) ? Http2Stream.State.IDLE : stream.state();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 766 */       return String.valueOf(id());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2FrameCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */