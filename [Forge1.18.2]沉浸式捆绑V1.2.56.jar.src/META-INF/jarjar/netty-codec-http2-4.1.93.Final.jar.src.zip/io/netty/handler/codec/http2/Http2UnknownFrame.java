package io.netty.handler.codec.http2;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufHolder;

public interface Http2UnknownFrame extends Http2StreamFrame, ByteBufHolder {
  Http2FrameStream stream();
  
  Http2UnknownFrame stream(Http2FrameStream paramHttp2FrameStream);
  
  byte frameType();
  
  Http2Flags flags();
  
  Http2UnknownFrame copy();
  
  Http2UnknownFrame duplicate();
  
  Http2UnknownFrame retainedDuplicate();
  
  Http2UnknownFrame replace(ByteBuf paramByteBuf);
  
  Http2UnknownFrame retain();
  
  Http2UnknownFrame retain(int paramInt);
  
  Http2UnknownFrame touch();
  
  Http2UnknownFrame touch(Object paramObject);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2UnknownFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */