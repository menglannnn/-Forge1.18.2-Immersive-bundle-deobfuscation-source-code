/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultHttp2PushPromiseFrame
/*    */   implements Http2PushPromiseFrame
/*    */ {
/*    */   private Http2FrameStream pushStreamFrame;
/*    */   private final Http2Headers http2Headers;
/*    */   private Http2FrameStream streamFrame;
/*    */   private final int padding;
/*    */   private final int promisedStreamId;
/*    */   
/*    */   public DefaultHttp2PushPromiseFrame(Http2Headers http2Headers) {
/* 33 */     this(http2Headers, 0);
/*    */   }
/*    */   
/*    */   public DefaultHttp2PushPromiseFrame(Http2Headers http2Headers, int padding) {
/* 37 */     this(http2Headers, padding, -1);
/*    */   }
/*    */   
/*    */   DefaultHttp2PushPromiseFrame(Http2Headers http2Headers, int padding, int promisedStreamId) {
/* 41 */     this.http2Headers = http2Headers;
/* 42 */     this.padding = padding;
/* 43 */     this.promisedStreamId = promisedStreamId;
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2StreamFrame pushStream(Http2FrameStream stream) {
/* 48 */     this.pushStreamFrame = stream;
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2FrameStream pushStream() {
/* 54 */     return this.pushStreamFrame;
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2Headers http2Headers() {
/* 59 */     return this.http2Headers;
/*    */   }
/*    */ 
/*    */   
/*    */   public int padding() {
/* 64 */     return this.padding;
/*    */   }
/*    */ 
/*    */   
/*    */   public int promisedStreamId() {
/* 69 */     if (this.pushStreamFrame != null) {
/* 70 */       return this.pushStreamFrame.id();
/*    */     }
/* 72 */     return this.promisedStreamId;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Http2PushPromiseFrame stream(Http2FrameStream stream) {
/* 78 */     this.streamFrame = stream;
/* 79 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Http2FrameStream stream() {
/* 84 */     return this.streamFrame;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 89 */     return "PUSH_PROMISE_FRAME";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 94 */     return "DefaultHttp2PushPromiseFrame{pushStreamFrame=" + this.pushStreamFrame + ", http2Headers=" + this.http2Headers + ", streamFrame=" + this.streamFrame + ", padding=" + this.padding + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2PushPromiseFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */