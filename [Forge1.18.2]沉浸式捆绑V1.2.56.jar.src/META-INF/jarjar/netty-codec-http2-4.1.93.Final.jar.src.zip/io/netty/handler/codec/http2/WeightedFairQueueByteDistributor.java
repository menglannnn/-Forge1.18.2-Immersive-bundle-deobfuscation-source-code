/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.util.collection.IntCollections;
/*     */ import io.netty.util.collection.IntObjectHashMap;
/*     */ import io.netty.util.collection.IntObjectMap;
/*     */ import io.netty.util.internal.DefaultPriorityQueue;
/*     */ import io.netty.util.internal.EmptyPriorityQueue;
/*     */ import io.netty.util.internal.MathUtil;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PriorityQueue;
/*     */ import io.netty.util.internal.PriorityQueueNode;
/*     */ import io.netty.util.internal.SystemPropertyUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WeightedFairQueueByteDistributor
/*     */   implements StreamByteDistributor
/*     */ {
/*  70 */   static final int INITIAL_CHILDREN_MAP_SIZE = Math.max(1, SystemPropertyUtil.getInt("io.netty.http2.childrenMapSize", 2));
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_MAX_STATE_ONLY_SIZE = 5;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Http2Connection.PropertyKey stateKey;
/*     */ 
/*     */   
/*     */   private final IntObjectMap<State> stateOnlyMap;
/*     */ 
/*     */   
/*     */   private final PriorityQueue<State> stateOnlyRemovalQueue;
/*     */ 
/*     */   
/*     */   private final Http2Connection connection;
/*     */ 
/*     */   
/*     */   private final State connectionState;
/*     */ 
/*     */   
/*  93 */   private int allocationQuantum = 1024;
/*     */   private final int maxStateOnlySize;
/*     */   
/*     */   public WeightedFairQueueByteDistributor(Http2Connection connection) {
/*  97 */     this(connection, 5);
/*     */   }
/*     */   
/*     */   public WeightedFairQueueByteDistributor(Http2Connection connection, int maxStateOnlySize) {
/* 101 */     ObjectUtil.checkPositiveOrZero(maxStateOnlySize, "maxStateOnlySize");
/* 102 */     if (maxStateOnlySize == 0) {
/* 103 */       this.stateOnlyMap = IntCollections.emptyMap();
/* 104 */       this.stateOnlyRemovalQueue = (PriorityQueue<State>)EmptyPriorityQueue.instance();
/*     */     } else {
/* 106 */       this.stateOnlyMap = (IntObjectMap<State>)new IntObjectHashMap(maxStateOnlySize);
/*     */ 
/*     */       
/* 109 */       this.stateOnlyRemovalQueue = (PriorityQueue<State>)new DefaultPriorityQueue(StateOnlyComparator.INSTANCE, maxStateOnlySize + 2);
/*     */     } 
/* 111 */     this.maxStateOnlySize = maxStateOnlySize;
/*     */     
/* 113 */     this.connection = connection;
/* 114 */     this.stateKey = connection.newKey();
/* 115 */     Http2Stream connectionStream = connection.connectionStream();
/* 116 */     connectionStream.setProperty(this.stateKey, this.connectionState = new State(connectionStream, 16));
/*     */ 
/*     */     
/* 119 */     connection.addListener(new Http2ConnectionAdapter()
/*     */         {
/*     */           public void onStreamAdded(Http2Stream stream) {
/* 122 */             WeightedFairQueueByteDistributor.State state = (WeightedFairQueueByteDistributor.State)WeightedFairQueueByteDistributor.this.stateOnlyMap.remove(stream.id());
/* 123 */             if (state == null) {
/* 124 */               state = new WeightedFairQueueByteDistributor.State(stream);
/*     */               
/* 126 */               List<WeightedFairQueueByteDistributor.ParentChangedEvent> events = new ArrayList<WeightedFairQueueByteDistributor.ParentChangedEvent>(1);
/* 127 */               WeightedFairQueueByteDistributor.this.connectionState.takeChild(state, false, events);
/* 128 */               WeightedFairQueueByteDistributor.this.notifyParentChanged(events);
/*     */             } else {
/* 130 */               WeightedFairQueueByteDistributor.this.stateOnlyRemovalQueue.removeTyped(state);
/* 131 */               state.stream = stream;
/*     */             } 
/* 133 */             switch (stream.state()) {
/*     */               case RESERVED_REMOTE:
/*     */               case RESERVED_LOCAL:
/* 136 */                 state.setStreamReservedOrActivated();
/*     */                 break;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 143 */             stream.setProperty(WeightedFairQueueByteDistributor.this.stateKey, state);
/*     */           }
/*     */ 
/*     */           
/*     */           public void onStreamActive(Http2Stream stream) {
/* 148 */             WeightedFairQueueByteDistributor.this.state(stream).setStreamReservedOrActivated();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onStreamClosed(Http2Stream stream) {
/* 155 */             WeightedFairQueueByteDistributor.this.state(stream).close();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onStreamRemoved(Http2Stream stream) {
/* 163 */             WeightedFairQueueByteDistributor.State state = WeightedFairQueueByteDistributor.this.state(stream);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 168 */             state.stream = null;
/*     */             
/* 170 */             if (WeightedFairQueueByteDistributor.this.maxStateOnlySize == 0) {
/* 171 */               state.parent.removeChild(state);
/*     */               return;
/*     */             } 
/* 174 */             if (WeightedFairQueueByteDistributor.this.stateOnlyRemovalQueue.size() == WeightedFairQueueByteDistributor.this.maxStateOnlySize) {
/* 175 */               WeightedFairQueueByteDistributor.State stateToRemove = (WeightedFairQueueByteDistributor.State)WeightedFairQueueByteDistributor.this.stateOnlyRemovalQueue.peek();
/* 176 */               if (WeightedFairQueueByteDistributor.StateOnlyComparator.INSTANCE.compare(stateToRemove, state) >= 0) {
/*     */ 
/*     */                 
/* 179 */                 state.parent.removeChild(state);
/*     */                 return;
/*     */               } 
/* 182 */               WeightedFairQueueByteDistributor.this.stateOnlyRemovalQueue.poll();
/* 183 */               stateToRemove.parent.removeChild(stateToRemove);
/* 184 */               WeightedFairQueueByteDistributor.this.stateOnlyMap.remove(stateToRemove.streamId);
/*     */             } 
/* 186 */             WeightedFairQueueByteDistributor.this.stateOnlyRemovalQueue.add(state);
/* 187 */             WeightedFairQueueByteDistributor.this.stateOnlyMap.put(state.streamId, state);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateStreamableBytes(StreamByteDistributor.StreamState state) {
/* 194 */     state(state.stream()).updateStreamableBytes(Http2CodecUtil.streamableBytes(state), (state
/* 195 */         .hasFrame() && state.windowSize() >= 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateDependencyTree(int childStreamId, int parentStreamId, short weight, boolean exclusive) {
/* 200 */     State state = state(childStreamId);
/* 201 */     if (state == null) {
/*     */ 
/*     */ 
/*     */       
/* 205 */       if (this.maxStateOnlySize == 0) {
/*     */         return;
/*     */       }
/* 208 */       state = new State(childStreamId);
/* 209 */       this.stateOnlyRemovalQueue.add(state);
/* 210 */       this.stateOnlyMap.put(childStreamId, state);
/*     */     } 
/*     */     
/* 213 */     State newParent = state(parentStreamId);
/* 214 */     if (newParent == null) {
/*     */ 
/*     */ 
/*     */       
/* 218 */       if (this.maxStateOnlySize == 0) {
/*     */         return;
/*     */       }
/* 221 */       newParent = new State(parentStreamId);
/* 222 */       this.stateOnlyRemovalQueue.add(newParent);
/* 223 */       this.stateOnlyMap.put(parentStreamId, newParent);
/*     */       
/* 225 */       List<ParentChangedEvent> events = new ArrayList<ParentChangedEvent>(1);
/* 226 */       this.connectionState.takeChild(newParent, false, events);
/* 227 */       notifyParentChanged(events);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 232 */     if (state.activeCountForTree != 0 && state.parent != null) {
/* 233 */       state.parent.totalQueuedWeights += (weight - state.weight);
/*     */     }
/* 235 */     state.weight = weight;
/*     */     
/* 237 */     if (newParent != state.parent || (exclusive && newParent.children.size() != 1)) {
/*     */       List<ParentChangedEvent> events;
/* 239 */       if (newParent.isDescendantOf(state)) {
/* 240 */         events = new ArrayList<ParentChangedEvent>(2 + (exclusive ? newParent.children.size() : 0));
/* 241 */         state.parent.takeChild(newParent, false, events);
/*     */       } else {
/* 243 */         events = new ArrayList<ParentChangedEvent>(1 + (exclusive ? newParent.children.size() : 0));
/*     */       } 
/* 245 */       newParent.takeChild(state, exclusive, events);
/* 246 */       notifyParentChanged(events);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     while (this.stateOnlyRemovalQueue.size() > this.maxStateOnlySize) {
/* 253 */       State stateToRemove = (State)this.stateOnlyRemovalQueue.poll();
/* 254 */       stateToRemove.parent.removeChild(stateToRemove);
/* 255 */       this.stateOnlyMap.remove(stateToRemove.streamId);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean distribute(int maxBytes, StreamByteDistributor.Writer writer) throws Http2Exception {
/*     */     int oldIsActiveCountForTree;
/* 262 */     if (this.connectionState.activeCountForTree == 0) {
/* 263 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 271 */       oldIsActiveCountForTree = this.connectionState.activeCountForTree;
/*     */       
/* 273 */       maxBytes -= distributeToChildren(maxBytes, writer, this.connectionState);
/* 274 */     } while (this.connectionState.activeCountForTree != 0 && (maxBytes > 0 || oldIsActiveCountForTree != this.connectionState.activeCountForTree));
/*     */ 
/*     */     
/* 277 */     return (this.connectionState.activeCountForTree != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void allocationQuantum(int allocationQuantum) {
/* 285 */     ObjectUtil.checkPositive(allocationQuantum, "allocationQuantum");
/* 286 */     this.allocationQuantum = allocationQuantum;
/*     */   }
/*     */   
/*     */   private int distribute(int maxBytes, StreamByteDistributor.Writer writer, State state) throws Http2Exception {
/* 290 */     if (state.isActive()) {
/* 291 */       int nsent = Math.min(maxBytes, state.streamableBytes);
/* 292 */       state.write(nsent, writer);
/* 293 */       if (nsent == 0 && maxBytes != 0)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 298 */         state.updateStreamableBytes(state.streamableBytes, false);
/*     */       }
/* 300 */       return nsent;
/*     */     } 
/*     */     
/* 303 */     return distributeToChildren(maxBytes, writer, state);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int distributeToChildren(int maxBytes, StreamByteDistributor.Writer writer, State state) throws Http2Exception {
/* 317 */     long oldTotalQueuedWeights = state.totalQueuedWeights;
/* 318 */     State childState = state.pollPseudoTimeQueue();
/* 319 */     State nextChildState = state.peekPseudoTimeQueue();
/* 320 */     childState.setDistributing();
/*     */     try {
/* 322 */       assert nextChildState == null || nextChildState.pseudoTimeToWrite >= childState.pseudoTimeToWrite : "nextChildState[" + nextChildState.streamId + "].pseudoTime(" + nextChildState.pseudoTimeToWrite + ") <  childState[" + childState.streamId + "].pseudoTime(" + childState.pseudoTimeToWrite + 41;
/*     */ 
/*     */       
/* 325 */       int nsent = distribute((nextChildState == null) ? maxBytes : 
/* 326 */           Math.min(maxBytes, (int)Math.min((nextChildState.pseudoTimeToWrite - childState.pseudoTimeToWrite) * childState.weight / oldTotalQueuedWeights + this.allocationQuantum, 2147483647L)), writer, childState);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 331 */       state.pseudoTime += nsent;
/* 332 */       childState.updatePseudoTime(state, nsent, oldTotalQueuedWeights);
/* 333 */       return nsent;
/*     */     } finally {
/* 335 */       childState.unsetDistributing();
/*     */ 
/*     */ 
/*     */       
/* 339 */       if (childState.activeCountForTree != 0) {
/* 340 */         state.offerPseudoTimeQueue(childState);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private State state(Http2Stream stream) {
/* 346 */     return stream.<State>getProperty(this.stateKey);
/*     */   }
/*     */   
/*     */   private State state(int streamId) {
/* 350 */     Http2Stream stream = this.connection.stream(streamId);
/* 351 */     return (stream != null) ? state(stream) : (State)this.stateOnlyMap.get(streamId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isChild(int childId, int parentId, short weight) {
/* 358 */     State parent = state(parentId);
/*     */     State child;
/* 360 */     return (parent.children.containsKey(childId) && 
/* 361 */       (child = state(childId)).parent == parent && child.weight == weight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int numChildren(int streamId) {
/* 368 */     State state = state(streamId);
/* 369 */     return (state == null) ? 0 : state.children.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notifyParentChanged(List<ParentChangedEvent> events) {
/* 377 */     for (int i = 0; i < events.size(); i++) {
/* 378 */       ParentChangedEvent event = events.get(i);
/* 379 */       this.stateOnlyRemovalQueue.priorityChanged(event.state);
/* 380 */       if (event.state.parent != null && event.state.activeCountForTree != 0) {
/* 381 */         event.state.parent.offerAndInitializePseudoTime(event.state);
/* 382 */         event.state.parent.activeCountChangeForTree(event.state.activeCountForTree);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class StateOnlyComparator
/*     */     implements Comparator<State>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = -4806936913002105966L;
/*     */ 
/*     */ 
/*     */     
/* 398 */     static final StateOnlyComparator INSTANCE = new StateOnlyComparator();
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(WeightedFairQueueByteDistributor.State o1, WeightedFairQueueByteDistributor.State o2) {
/* 403 */       boolean o1Actived = o1.wasStreamReservedOrActivated();
/* 404 */       if (o1Actived != o2.wasStreamReservedOrActivated()) {
/* 405 */         return o1Actived ? -1 : 1;
/*     */       }
/*     */       
/* 408 */       int x = o2.dependencyTreeDepth - o1.dependencyTreeDepth;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 417 */       return (x != 0) ? x : (o1.streamId - o2.streamId);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class StatePseudoTimeComparator
/*     */     implements Comparator<State>, Serializable {
/*     */     private static final long serialVersionUID = -1437548640227161828L;
/* 424 */     static final StatePseudoTimeComparator INSTANCE = new StatePseudoTimeComparator();
/*     */ 
/*     */     
/*     */     public int compare(WeightedFairQueueByteDistributor.State o1, WeightedFairQueueByteDistributor.State o2) {
/* 428 */       return MathUtil.compare(o1.pseudoTimeToWrite, o2.pseudoTimeToWrite);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class State
/*     */     implements PriorityQueueNode
/*     */   {
/*     */     private static final byte STATE_IS_ACTIVE = 1;
/*     */     
/*     */     private static final byte STATE_IS_DISTRIBUTING = 2;
/*     */     
/*     */     private static final byte STATE_STREAM_ACTIVATED = 4;
/*     */     
/*     */     Http2Stream stream;
/*     */     
/*     */     State parent;
/* 445 */     IntObjectMap<State> children = IntCollections.emptyMap();
/*     */     
/*     */     private final PriorityQueue<State> pseudoTimeQueue;
/*     */     
/*     */     final int streamId;
/*     */     
/*     */     int streamableBytes;
/*     */     int dependencyTreeDepth;
/*     */     int activeCountForTree;
/* 454 */     private int pseudoTimeQueueIndex = -1;
/* 455 */     private int stateOnlyQueueIndex = -1;
/*     */ 
/*     */     
/*     */     long pseudoTimeToWrite;
/*     */     
/*     */     long pseudoTime;
/*     */     
/*     */     long totalQueuedWeights;
/*     */     
/*     */     private byte flags;
/*     */     
/* 466 */     short weight = 16;
/*     */     
/*     */     State(int streamId) {
/* 469 */       this(streamId, null, 0);
/*     */     }
/*     */     
/*     */     State(Http2Stream stream) {
/* 473 */       this(stream, 0);
/*     */     }
/*     */     
/*     */     State(Http2Stream stream, int initialSize) {
/* 477 */       this(stream.id(), stream, initialSize);
/*     */     }
/*     */     
/*     */     State(int streamId, Http2Stream stream, int initialSize) {
/* 481 */       this.stream = stream;
/* 482 */       this.streamId = streamId;
/* 483 */       this.pseudoTimeQueue = (PriorityQueue<State>)new DefaultPriorityQueue(WeightedFairQueueByteDistributor.StatePseudoTimeComparator.INSTANCE, initialSize);
/*     */     }
/*     */     
/*     */     boolean isDescendantOf(State state) {
/* 487 */       State next = this.parent;
/* 488 */       while (next != null) {
/* 489 */         if (next == state) {
/* 490 */           return true;
/*     */         }
/* 492 */         next = next.parent;
/*     */       } 
/* 494 */       return false;
/*     */     }
/*     */     
/*     */     void takeChild(State child, boolean exclusive, List<WeightedFairQueueByteDistributor.ParentChangedEvent> events) {
/* 498 */       takeChild(null, child, exclusive, events);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void takeChild(Iterator<IntObjectMap.PrimitiveEntry<State>> childItr, State child, boolean exclusive, List<WeightedFairQueueByteDistributor.ParentChangedEvent> events) {
/* 507 */       State oldParent = child.parent;
/*     */       
/* 509 */       if (oldParent != this) {
/* 510 */         events.add(new WeightedFairQueueByteDistributor.ParentChangedEvent(child, oldParent));
/* 511 */         child.setParent(this);
/*     */ 
/*     */ 
/*     */         
/* 515 */         if (childItr != null) {
/* 516 */           childItr.remove();
/* 517 */         } else if (oldParent != null) {
/* 518 */           oldParent.children.remove(child.streamId);
/*     */         } 
/*     */ 
/*     */         
/* 522 */         initChildrenIfEmpty();
/*     */         
/* 524 */         State oldChild = (State)this.children.put(child.streamId, child);
/* 525 */         assert oldChild == null : "A stream with the same stream ID was already in the child map.";
/*     */       } 
/*     */       
/* 528 */       if (exclusive && !this.children.isEmpty()) {
/*     */ 
/*     */         
/* 531 */         Iterator<IntObjectMap.PrimitiveEntry<State>> itr = removeAllChildrenExcept(child).entries().iterator();
/* 532 */         while (itr.hasNext()) {
/* 533 */           child.takeChild(itr, (State)((IntObjectMap.PrimitiveEntry)itr.next()).value(), false, events);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeChild(State child) {
/* 542 */       if (this.children.remove(child.streamId) != null) {
/* 543 */         List<WeightedFairQueueByteDistributor.ParentChangedEvent> events = new ArrayList<WeightedFairQueueByteDistributor.ParentChangedEvent>(1 + child.children.size());
/* 544 */         events.add(new WeightedFairQueueByteDistributor.ParentChangedEvent(child, child.parent));
/* 545 */         child.setParent(null);
/*     */         
/* 547 */         if (!child.children.isEmpty()) {
/*     */           
/* 549 */           Iterator<IntObjectMap.PrimitiveEntry<State>> itr = child.children.entries().iterator();
/* 550 */           long totalWeight = child.getTotalWeight();
/*     */           
/*     */           do {
/* 553 */             State dependency = (State)((IntObjectMap.PrimitiveEntry)itr.next()).value();
/* 554 */             dependency.weight = (short)(int)Math.max(1L, (dependency.weight * child.weight) / totalWeight);
/* 555 */             takeChild(itr, dependency, false, events);
/* 556 */           } while (itr.hasNext());
/*     */         } 
/*     */         
/* 559 */         WeightedFairQueueByteDistributor.this.notifyParentChanged(events);
/*     */       } 
/*     */     }
/*     */     
/*     */     private long getTotalWeight() {
/* 564 */       long totalWeight = 0L;
/* 565 */       for (State state : this.children.values()) {
/* 566 */         totalWeight += state.weight;
/*     */       }
/* 568 */       return totalWeight;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private IntObjectMap<State> removeAllChildrenExcept(State stateToRetain) {
/* 577 */       stateToRetain = (State)this.children.remove(stateToRetain.streamId);
/* 578 */       IntObjectMap<State> prevChildren = this.children;
/*     */ 
/*     */       
/* 581 */       initChildren();
/* 582 */       if (stateToRetain != null) {
/* 583 */         this.children.put(stateToRetain.streamId, stateToRetain);
/*     */       }
/* 585 */       return prevChildren;
/*     */     }
/*     */ 
/*     */     
/*     */     private void setParent(State newParent) {
/* 590 */       if (this.activeCountForTree != 0 && this.parent != null) {
/* 591 */         this.parent.removePseudoTimeQueue(this);
/* 592 */         this.parent.activeCountChangeForTree(-this.activeCountForTree);
/*     */       } 
/* 594 */       this.parent = newParent;
/*     */       
/* 596 */       this.dependencyTreeDepth = (newParent == null) ? Integer.MAX_VALUE : (newParent.dependencyTreeDepth + 1);
/*     */     }
/*     */     
/*     */     private void initChildrenIfEmpty() {
/* 600 */       if (this.children == IntCollections.emptyMap()) {
/* 601 */         initChildren();
/*     */       }
/*     */     }
/*     */     
/*     */     private void initChildren() {
/* 606 */       this.children = (IntObjectMap<State>)new IntObjectHashMap(WeightedFairQueueByteDistributor.INITIAL_CHILDREN_MAP_SIZE);
/*     */     }
/*     */     
/*     */     void write(int numBytes, StreamByteDistributor.Writer writer) throws Http2Exception {
/* 610 */       assert this.stream != null;
/*     */       try {
/* 612 */         writer.write(this.stream, numBytes);
/* 613 */       } catch (Throwable t) {
/* 614 */         throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, t, "byte distribution write error", new Object[0]);
/*     */       } 
/*     */     }
/*     */     
/*     */     void activeCountChangeForTree(int increment) {
/* 619 */       assert this.activeCountForTree + increment >= 0;
/* 620 */       this.activeCountForTree += increment;
/* 621 */       if (this.parent != null) {
/* 622 */         assert this.activeCountForTree != increment || this.pseudoTimeQueueIndex == -1 || this.parent.pseudoTimeQueue
/*     */           
/* 624 */           .containsTyped(this) : "State[" + this.streamId + "].activeCountForTree changed from 0 to " + increment + " is in a pseudoTimeQueue, but not in parent[ " + this.parent.streamId + "]'s pseudoTimeQueue";
/*     */ 
/*     */         
/* 627 */         if (this.activeCountForTree == 0) {
/* 628 */           this.parent.removePseudoTimeQueue(this);
/* 629 */         } else if (this.activeCountForTree == increment && !isDistributing()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 638 */           this.parent.offerAndInitializePseudoTime(this);
/*     */         } 
/* 640 */         this.parent.activeCountChangeForTree(increment);
/*     */       } 
/*     */     }
/*     */     
/*     */     void updateStreamableBytes(int newStreamableBytes, boolean isActive) {
/* 645 */       if (isActive() != isActive) {
/* 646 */         if (isActive) {
/* 647 */           activeCountChangeForTree(1);
/* 648 */           setActive();
/*     */         } else {
/* 650 */           activeCountChangeForTree(-1);
/* 651 */           unsetActive();
/*     */         } 
/*     */       }
/*     */       
/* 655 */       this.streamableBytes = newStreamableBytes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void updatePseudoTime(State parentState, int nsent, long totalQueuedWeights) {
/* 662 */       assert this.streamId != 0 && nsent >= 0;
/*     */ 
/*     */       
/* 665 */       this.pseudoTimeToWrite = Math.min(this.pseudoTimeToWrite, parentState.pseudoTime) + nsent * totalQueuedWeights / this.weight;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void offerAndInitializePseudoTime(State state) {
/* 674 */       state.pseudoTimeToWrite = this.pseudoTime;
/* 675 */       offerPseudoTimeQueue(state);
/*     */     }
/*     */     
/*     */     void offerPseudoTimeQueue(State state) {
/* 679 */       this.pseudoTimeQueue.offer(state);
/* 680 */       this.totalQueuedWeights += state.weight;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     State pollPseudoTimeQueue() {
/* 687 */       State state = (State)this.pseudoTimeQueue.poll();
/*     */       
/* 689 */       this.totalQueuedWeights -= state.weight;
/* 690 */       return state;
/*     */     }
/*     */     
/*     */     void removePseudoTimeQueue(State state) {
/* 694 */       if (this.pseudoTimeQueue.removeTyped(state)) {
/* 695 */         this.totalQueuedWeights -= state.weight;
/*     */       }
/*     */     }
/*     */     
/*     */     State peekPseudoTimeQueue() {
/* 700 */       return (State)this.pseudoTimeQueue.peek();
/*     */     }
/*     */     
/*     */     void close() {
/* 704 */       updateStreamableBytes(0, false);
/* 705 */       this.stream = null;
/*     */     }
/*     */     
/*     */     boolean wasStreamReservedOrActivated() {
/* 709 */       return ((this.flags & 0x4) != 0);
/*     */     }
/*     */     
/*     */     void setStreamReservedOrActivated() {
/* 713 */       this.flags = (byte)(this.flags | 0x4);
/*     */     }
/*     */     
/*     */     boolean isActive() {
/* 717 */       return ((this.flags & 0x1) != 0);
/*     */     }
/*     */     
/*     */     private void setActive() {
/* 721 */       this.flags = (byte)(this.flags | 0x1);
/*     */     }
/*     */     
/*     */     private void unsetActive() {
/* 725 */       this.flags = (byte)(this.flags & 0xFFFFFFFE);
/*     */     }
/*     */     
/*     */     boolean isDistributing() {
/* 729 */       return ((this.flags & 0x2) != 0);
/*     */     }
/*     */     
/*     */     void setDistributing() {
/* 733 */       this.flags = (byte)(this.flags | 0x2);
/*     */     }
/*     */     
/*     */     void unsetDistributing() {
/* 737 */       this.flags = (byte)(this.flags & 0xFFFFFFFD);
/*     */     }
/*     */ 
/*     */     
/*     */     public int priorityQueueIndex(DefaultPriorityQueue<?> queue) {
/* 742 */       return (queue == WeightedFairQueueByteDistributor.this.stateOnlyRemovalQueue) ? this.stateOnlyQueueIndex : this.pseudoTimeQueueIndex;
/*     */     }
/*     */ 
/*     */     
/*     */     public void priorityQueueIndex(DefaultPriorityQueue<?> queue, int i) {
/* 747 */       if (queue == WeightedFairQueueByteDistributor.this.stateOnlyRemovalQueue) {
/* 748 */         this.stateOnlyQueueIndex = i;
/*     */       } else {
/* 750 */         this.pseudoTimeQueueIndex = i;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 757 */       StringBuilder sb = new StringBuilder(256 * ((this.activeCountForTree > 0) ? this.activeCountForTree : 1));
/* 758 */       toString(sb);
/* 759 */       return sb.toString();
/*     */     }
/*     */     
/*     */     private void toString(StringBuilder sb) {
/* 763 */       sb.append("{streamId ").append(this.streamId)
/* 764 */         .append(" streamableBytes ").append(this.streamableBytes)
/* 765 */         .append(" activeCountForTree ").append(this.activeCountForTree)
/* 766 */         .append(" pseudoTimeQueueIndex ").append(this.pseudoTimeQueueIndex)
/* 767 */         .append(" pseudoTimeToWrite ").append(this.pseudoTimeToWrite)
/* 768 */         .append(" pseudoTime ").append(this.pseudoTime)
/* 769 */         .append(" flags ").append(this.flags)
/* 770 */         .append(" pseudoTimeQueue.size() ").append(this.pseudoTimeQueue.size())
/* 771 */         .append(" stateOnlyQueueIndex ").append(this.stateOnlyQueueIndex)
/* 772 */         .append(" parent.streamId ").append((this.parent == null) ? -1 : this.parent.streamId).append("} [");
/*     */       
/* 774 */       if (!this.pseudoTimeQueue.isEmpty()) {
/* 775 */         for (State s : this.pseudoTimeQueue) {
/* 776 */           s.toString(sb);
/* 777 */           sb.append(", ");
/*     */         } 
/*     */         
/* 780 */         sb.setLength(sb.length() - 2);
/*     */       } 
/* 782 */       sb.append(']');
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ParentChangedEvent
/*     */   {
/*     */     final WeightedFairQueueByteDistributor.State state;
/*     */ 
/*     */     
/*     */     final WeightedFairQueueByteDistributor.State oldParent;
/*     */ 
/*     */ 
/*     */     
/*     */     ParentChangedEvent(WeightedFairQueueByteDistributor.State state, WeightedFairQueueByteDistributor.State oldParent) {
/* 799 */       this.state = state;
/* 800 */       this.oldParent = oldParent;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\WeightedFairQueueByteDistributor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */