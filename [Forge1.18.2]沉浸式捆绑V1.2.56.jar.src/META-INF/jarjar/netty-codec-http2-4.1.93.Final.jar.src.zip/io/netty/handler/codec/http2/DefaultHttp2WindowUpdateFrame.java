/*    */ package io.netty.handler.codec.http2;
/*    */ 
/*    */ import io.netty.util.internal.StringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultHttp2WindowUpdateFrame
/*    */   extends AbstractHttp2StreamFrame
/*    */   implements Http2WindowUpdateFrame
/*    */ {
/*    */   private final int windowUpdateIncrement;
/*    */   
/*    */   public DefaultHttp2WindowUpdateFrame(int windowUpdateIncrement) {
/* 30 */     this.windowUpdateIncrement = windowUpdateIncrement;
/*    */   }
/*    */ 
/*    */   
/*    */   public DefaultHttp2WindowUpdateFrame stream(Http2FrameStream stream) {
/* 35 */     super.stream(stream);
/* 36 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 41 */     return "WINDOW_UPDATE";
/*    */   }
/*    */ 
/*    */   
/*    */   public int windowSizeIncrement() {
/* 46 */     return this.windowUpdateIncrement;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 51 */     return StringUtil.simpleClassName(this) + "(stream=" + 
/* 52 */       stream() + ", windowUpdateIncrement=" + this.windowUpdateIncrement + ')';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2WindowUpdateFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */