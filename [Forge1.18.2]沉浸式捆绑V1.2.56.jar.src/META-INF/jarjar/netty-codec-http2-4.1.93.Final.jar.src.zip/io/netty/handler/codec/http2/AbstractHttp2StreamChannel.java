/*      */ package io.netty.handler.codec.http2;
/*      */ 
/*      */ import io.netty.buffer.ByteBufAllocator;
/*      */ import io.netty.channel.Channel;
/*      */ import io.netty.channel.ChannelConfig;
/*      */ import io.netty.channel.ChannelFuture;
/*      */ import io.netty.channel.ChannelFutureListener;
/*      */ import io.netty.channel.ChannelHandler;
/*      */ import io.netty.channel.ChannelHandlerContext;
/*      */ import io.netty.channel.ChannelId;
/*      */ import io.netty.channel.ChannelMetadata;
/*      */ import io.netty.channel.ChannelOutboundBuffer;
/*      */ import io.netty.channel.ChannelOutboundInvoker;
/*      */ import io.netty.channel.ChannelPipeline;
/*      */ import io.netty.channel.ChannelProgressivePromise;
/*      */ import io.netty.channel.ChannelPromise;
/*      */ import io.netty.channel.DefaultChannelConfig;
/*      */ import io.netty.channel.DefaultChannelPipeline;
/*      */ import io.netty.channel.EventLoop;
/*      */ import io.netty.channel.MessageSizeEstimator;
/*      */ import io.netty.channel.RecvByteBufAllocator;
/*      */ import io.netty.channel.VoidChannelPromise;
/*      */ import io.netty.channel.socket.ChannelInputShutdownReadComplete;
/*      */ import io.netty.channel.socket.ChannelOutputShutdownEvent;
/*      */ import io.netty.handler.ssl.SslCloseCompletionEvent;
/*      */ import io.netty.util.DefaultAttributeMap;
/*      */ import io.netty.util.ReferenceCountUtil;
/*      */ import io.netty.util.concurrent.Future;
/*      */ import io.netty.util.concurrent.GenericFutureListener;
/*      */ import io.netty.util.internal.ObjectUtil;
/*      */ import io.netty.util.internal.StringUtil;
/*      */ import io.netty.util.internal.logging.InternalLogger;
/*      */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*      */ import java.net.SocketAddress;
/*      */ import java.nio.channels.ClosedChannelException;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*      */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class AbstractHttp2StreamChannel
/*      */   extends DefaultAttributeMap
/*      */   implements Http2StreamChannel
/*      */ {
/*   63 */   static final Http2FrameStreamVisitor WRITABLE_VISITOR = new Http2FrameStreamVisitor()
/*      */     {
/*      */       public boolean visit(Http2FrameStream stream) {
/*   66 */         AbstractHttp2StreamChannel childChannel = (AbstractHttp2StreamChannel)((Http2FrameCodec.DefaultHttp2FrameStream)stream).attachment;
/*      */         
/*   68 */         childChannel.trySetWritable();
/*   69 */         return true;
/*      */       }
/*      */     };
/*      */   
/*   73 */   static final Http2FrameStreamVisitor CHANNEL_INPUT_SHUTDOWN_READ_COMPLETE_VISITOR = new UserEventStreamVisitor(ChannelInputShutdownReadComplete.INSTANCE);
/*      */ 
/*      */   
/*   76 */   static final Http2FrameStreamVisitor CHANNEL_OUTPUT_SHUTDOWN_EVENT_VISITOR = new UserEventStreamVisitor(ChannelOutputShutdownEvent.INSTANCE);
/*      */ 
/*      */   
/*   79 */   static final Http2FrameStreamVisitor SSL_CLOSE_COMPLETION_EVENT_VISITOR = new UserEventStreamVisitor(SslCloseCompletionEvent.SUCCESS);
/*      */ 
/*      */   
/*   82 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(AbstractHttp2StreamChannel.class);
/*      */   
/*   84 */   private static final ChannelMetadata METADATA = new ChannelMetadata(false, 16);
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MIN_HTTP2_FRAME_SIZE = 9;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class UserEventStreamVisitor
/*      */     implements Http2FrameStreamVisitor
/*      */   {
/*      */     private final Object event;
/*      */ 
/*      */ 
/*      */     
/*      */     UserEventStreamVisitor(Object event) {
/*  100 */       this.event = ObjectUtil.checkNotNull(event, "event");
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean visit(Http2FrameStream stream) {
/*  105 */       AbstractHttp2StreamChannel childChannel = (AbstractHttp2StreamChannel)((Http2FrameCodec.DefaultHttp2FrameStream)stream).attachment;
/*      */       
/*  107 */       childChannel.pipeline().fireUserEventTriggered(this.event);
/*  108 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class FlowControlledFrameSizeEstimator
/*      */     implements MessageSizeEstimator
/*      */   {
/*  117 */     static final FlowControlledFrameSizeEstimator INSTANCE = new FlowControlledFrameSizeEstimator();
/*      */     
/*  119 */     private static final MessageSizeEstimator.Handle HANDLE_INSTANCE = new MessageSizeEstimator.Handle()
/*      */       {
/*      */         public int size(Object msg) {
/*  122 */           return (msg instanceof Http2DataFrame) ? 
/*      */             
/*  124 */             (int)Math.min(2147483647L, ((Http2DataFrame)msg).initialFlowControlledBytes() + 9L) : 9;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */     
/*      */     public MessageSizeEstimator.Handle newHandle() {
/*  131 */       return HANDLE_INSTANCE;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*  136 */   private static final AtomicLongFieldUpdater<AbstractHttp2StreamChannel> TOTAL_PENDING_SIZE_UPDATER = AtomicLongFieldUpdater.newUpdater(AbstractHttp2StreamChannel.class, "totalPendingSize");
/*      */ 
/*      */   
/*  139 */   private static final AtomicIntegerFieldUpdater<AbstractHttp2StreamChannel> UNWRITABLE_UPDATER = AtomicIntegerFieldUpdater.newUpdater(AbstractHttp2StreamChannel.class, "unwritable");
/*      */   
/*      */   private static void windowUpdateFrameWriteComplete(ChannelFuture future, Channel streamChannel) {
/*  142 */     Throwable cause = future.cause();
/*  143 */     if (cause != null) {
/*      */       Throwable unwrappedCause;
/*      */       
/*  146 */       if (cause instanceof Http2FrameStreamException && (unwrappedCause = cause.getCause()) != null) {
/*  147 */         cause = unwrappedCause;
/*      */       }
/*      */ 
/*      */       
/*  151 */       streamChannel.pipeline().fireExceptionCaught(cause);
/*  152 */       streamChannel.unsafe().close(streamChannel.unsafe().voidPromise());
/*      */     } 
/*      */   }
/*      */   
/*  156 */   private final ChannelFutureListener windowUpdateFrameWriteListener = new ChannelFutureListener()
/*      */     {
/*      */       public void operationComplete(ChannelFuture future) {
/*  159 */         AbstractHttp2StreamChannel.windowUpdateFrameWriteComplete(future, AbstractHttp2StreamChannel.this);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum ReadStatus
/*      */   {
/*  170 */     IDLE,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  175 */     IN_PROGRESS,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  180 */     REQUESTED;
/*      */   }
/*      */   
/*  183 */   private final Http2StreamChannelConfig config = new Http2StreamChannelConfig(this);
/*  184 */   private final Http2ChannelUnsafe unsafe = new Http2ChannelUnsafe();
/*      */ 
/*      */   
/*      */   private final ChannelId channelId;
/*      */   
/*      */   private final ChannelPipeline pipeline;
/*      */   
/*      */   private final Http2FrameCodec.DefaultHttp2FrameStream stream;
/*      */   
/*      */   private final ChannelPromise closePromise;
/*      */   
/*      */   private volatile boolean registered;
/*      */   
/*      */   private volatile long totalPendingSize;
/*      */   
/*      */   private volatile int unwritable;
/*      */   
/*      */   private Runnable fireChannelWritabilityChangedTask;
/*      */   
/*      */   private boolean outboundClosed;
/*      */   
/*      */   private int flowControlledBytes;
/*      */   
/*  207 */   private ReadStatus readStatus = ReadStatus.IDLE;
/*      */   
/*      */   private Queue<Object> inboundBuffer;
/*      */   
/*      */   private boolean firstFrameWritten;
/*      */   
/*      */   private boolean readCompletePending;
/*      */   
/*      */   AbstractHttp2StreamChannel(Http2FrameCodec.DefaultHttp2FrameStream stream, int id, ChannelHandler inboundHandler) {
/*  216 */     this.stream = stream;
/*  217 */     stream.attachment = this;
/*  218 */     this.pipeline = (ChannelPipeline)new DefaultChannelPipeline(this)
/*      */       {
/*      */         protected void incrementPendingOutboundBytes(long size) {
/*  221 */           AbstractHttp2StreamChannel.this.incrementPendingOutboundBytes(size, true);
/*      */         }
/*      */ 
/*      */         
/*      */         protected void decrementPendingOutboundBytes(long size) {
/*  226 */           AbstractHttp2StreamChannel.this.decrementPendingOutboundBytes(size, true);
/*      */         }
/*      */       };
/*      */     
/*  230 */     this.closePromise = this.pipeline.newPromise();
/*  231 */     this.channelId = new Http2StreamChannelId(parent().id(), id);
/*      */     
/*  233 */     if (inboundHandler != null)
/*      */     {
/*  235 */       this.pipeline.addLast(new ChannelHandler[] { inboundHandler });
/*      */     }
/*      */   }
/*      */   
/*      */   private void incrementPendingOutboundBytes(long size, boolean invokeLater) {
/*  240 */     if (size == 0L) {
/*      */       return;
/*      */     }
/*      */     
/*  244 */     long newWriteBufferSize = TOTAL_PENDING_SIZE_UPDATER.addAndGet(this, size);
/*  245 */     if (newWriteBufferSize > config().getWriteBufferHighWaterMark()) {
/*  246 */       setUnwritable(invokeLater);
/*      */     }
/*      */   }
/*      */   
/*      */   private void decrementPendingOutboundBytes(long size, boolean invokeLater) {
/*  251 */     if (size == 0L) {
/*      */       return;
/*      */     }
/*      */     
/*  255 */     long newWriteBufferSize = TOTAL_PENDING_SIZE_UPDATER.addAndGet(this, -size);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  261 */     if (newWriteBufferSize < config().getWriteBufferLowWaterMark() && parent().isWritable()) {
/*  262 */       setWritable(invokeLater);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void trySetWritable() {
/*  271 */     if (this.totalPendingSize < config().getWriteBufferLowWaterMark()) {
/*  272 */       setWritable(false);
/*      */     }
/*      */   }
/*      */   
/*      */   private void setWritable(boolean invokeLater) {
/*      */     while (true) {
/*  278 */       int oldValue = this.unwritable;
/*  279 */       int newValue = oldValue & 0xFFFFFFFE;
/*  280 */       if (UNWRITABLE_UPDATER.compareAndSet(this, oldValue, newValue)) {
/*  281 */         if (oldValue != 0 && newValue == 0) {
/*  282 */           fireChannelWritabilityChanged(invokeLater);
/*      */         }
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setUnwritable(boolean invokeLater) {
/*      */     while (true) {
/*  291 */       int oldValue = this.unwritable;
/*  292 */       int newValue = oldValue | 0x1;
/*  293 */       if (UNWRITABLE_UPDATER.compareAndSet(this, oldValue, newValue)) {
/*  294 */         if (oldValue == 0) {
/*  295 */           fireChannelWritabilityChanged(invokeLater);
/*      */         }
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fireChannelWritabilityChanged(boolean invokeLater) {
/*  303 */     final ChannelPipeline pipeline = pipeline();
/*  304 */     if (invokeLater) {
/*  305 */       Runnable task = this.fireChannelWritabilityChangedTask;
/*  306 */       if (task == null) {
/*  307 */         this.fireChannelWritabilityChangedTask = task = new Runnable()
/*      */           {
/*      */             public void run() {
/*  310 */               pipeline.fireChannelWritabilityChanged();
/*      */             }
/*      */           };
/*      */       }
/*  314 */       eventLoop().execute(task);
/*      */     } else {
/*  316 */       pipeline.fireChannelWritabilityChanged();
/*      */     } 
/*      */   }
/*      */   
/*      */   public Http2FrameStream stream() {
/*  321 */     return this.stream;
/*      */   }
/*      */   
/*      */   void closeOutbound() {
/*  325 */     this.outboundClosed = true;
/*      */   }
/*      */   
/*      */   void streamClosed() {
/*  329 */     this.unsafe.readEOS();
/*      */ 
/*      */     
/*  332 */     this.unsafe.doBeginRead();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelMetadata metadata() {
/*  337 */     return METADATA;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelConfig config() {
/*  342 */     return (ChannelConfig)this.config;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isOpen() {
/*  347 */     return !this.closePromise.isDone();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isActive() {
/*  352 */     return isOpen();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWritable() {
/*  357 */     return (this.unwritable == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelId id() {
/*  362 */     return this.channelId;
/*      */   }
/*      */ 
/*      */   
/*      */   public EventLoop eventLoop() {
/*  367 */     return parent().eventLoop();
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel parent() {
/*  372 */     return parentContext().channel();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRegistered() {
/*  377 */     return this.registered;
/*      */   }
/*      */ 
/*      */   
/*      */   public SocketAddress localAddress() {
/*  382 */     return parent().localAddress();
/*      */   }
/*      */ 
/*      */   
/*      */   public SocketAddress remoteAddress() {
/*  387 */     return parent().remoteAddress();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture closeFuture() {
/*  392 */     return (ChannelFuture)this.closePromise;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long bytesBeforeUnwritable() {
/*  398 */     long bytes = config().getWriteBufferHighWaterMark() - this.totalPendingSize + 1L;
/*      */ 
/*      */ 
/*      */     
/*  402 */     return (bytes > 0L && isWritable()) ? bytes : 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long bytesBeforeWritable() {
/*  408 */     long bytes = this.totalPendingSize - config().getWriteBufferLowWaterMark() + 1L;
/*      */ 
/*      */ 
/*      */     
/*  412 */     return (bytes <= 0L || isWritable()) ? 0L : bytes;
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel.Unsafe unsafe() {
/*  417 */     return this.unsafe;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelPipeline pipeline() {
/*  422 */     return this.pipeline;
/*      */   }
/*      */ 
/*      */   
/*      */   public ByteBufAllocator alloc() {
/*  427 */     return config().getAllocator();
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel read() {
/*  432 */     pipeline().read();
/*  433 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Channel flush() {
/*  438 */     pipeline().flush();
/*  439 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture bind(SocketAddress localAddress) {
/*  444 */     return pipeline().bind(localAddress);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress) {
/*  449 */     return pipeline().connect(remoteAddress);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
/*  454 */     return pipeline().connect(remoteAddress, localAddress);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture disconnect() {
/*  459 */     return pipeline().disconnect();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture close() {
/*  464 */     return pipeline().close();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture deregister() {
/*  469 */     return pipeline().deregister();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture bind(SocketAddress localAddress, ChannelPromise promise) {
/*  474 */     return pipeline().bind(localAddress, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress, ChannelPromise promise) {
/*  479 */     return pipeline().connect(remoteAddress, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
/*  484 */     return pipeline().connect(remoteAddress, localAddress, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture disconnect(ChannelPromise promise) {
/*  489 */     return pipeline().disconnect(promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture close(ChannelPromise promise) {
/*  494 */     return pipeline().close(promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture deregister(ChannelPromise promise) {
/*  499 */     return pipeline().deregister(promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture write(Object msg) {
/*  504 */     return pipeline().write(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture write(Object msg, ChannelPromise promise) {
/*  509 */     return pipeline().write(msg, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture writeAndFlush(Object msg, ChannelPromise promise) {
/*  514 */     return pipeline().writeAndFlush(msg, promise);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture writeAndFlush(Object msg) {
/*  519 */     return pipeline().writeAndFlush(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelPromise newPromise() {
/*  524 */     return pipeline().newPromise();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelProgressivePromise newProgressivePromise() {
/*  529 */     return pipeline().newProgressivePromise();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture newSucceededFuture() {
/*  534 */     return pipeline().newSucceededFuture();
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelFuture newFailedFuture(Throwable cause) {
/*  539 */     return pipeline().newFailedFuture(cause);
/*      */   }
/*      */ 
/*      */   
/*      */   public ChannelPromise voidPromise() {
/*  544 */     return pipeline().voidPromise();
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  549 */     return id().hashCode();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/*  554 */     return (this == o);
/*      */   }
/*      */ 
/*      */   
/*      */   public int compareTo(Channel o) {
/*  559 */     if (this == o) {
/*  560 */       return 0;
/*      */     }
/*      */     
/*  563 */     return id().compareTo(o.id());
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  568 */     return parent().toString() + "(H2 - " + this.stream + ')';
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fireChildRead(Http2Frame frame) {
/*  576 */     assert eventLoop().inEventLoop();
/*  577 */     if (!isActive()) {
/*  578 */       ReferenceCountUtil.release(frame);
/*  579 */     } else if (this.readStatus != ReadStatus.IDLE) {
/*      */ 
/*      */       
/*  582 */       assert this.inboundBuffer == null || this.inboundBuffer.isEmpty();
/*  583 */       RecvByteBufAllocator.Handle allocHandle = this.unsafe.recvBufAllocHandle();
/*  584 */       this.unsafe.doRead0(frame, allocHandle);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  589 */       if (allocHandle.continueReading()) {
/*  590 */         maybeAddChannelToReadCompletePendingQueue();
/*      */       } else {
/*  592 */         this.unsafe.notifyReadComplete(allocHandle, true);
/*      */       } 
/*      */     } else {
/*  595 */       if (this.inboundBuffer == null) {
/*  596 */         this.inboundBuffer = new ArrayDeque(4);
/*      */       }
/*  598 */       this.inboundBuffer.add(frame);
/*      */     } 
/*      */   }
/*      */   
/*      */   void fireChildReadComplete() {
/*  603 */     assert eventLoop().inEventLoop();
/*  604 */     assert this.readStatus != ReadStatus.IDLE || !this.readCompletePending;
/*  605 */     this.unsafe.notifyReadComplete(this.unsafe.recvBufAllocHandle(), false);
/*      */   }
/*      */   
/*      */   final void closeWithError(Http2Error error) {
/*  609 */     assert eventLoop().inEventLoop();
/*  610 */     this.unsafe.close(this.unsafe.voidPromise(), error);
/*      */   }
/*      */   
/*      */   private final class Http2ChannelUnsafe implements Channel.Unsafe {
/*  614 */     private final VoidChannelPromise unsafeVoidPromise = new VoidChannelPromise(AbstractHttp2StreamChannel.this, false);
/*      */     
/*      */     private RecvByteBufAllocator.Handle recvHandle;
/*      */     
/*      */     private boolean writeDoneAndNoFlush;
/*      */     
/*      */     private boolean closeInitiated;
/*      */     
/*      */     private boolean readEOS;
/*      */     
/*      */     public void connect(SocketAddress remoteAddress, SocketAddress localAddress, ChannelPromise promise) {
/*  625 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*  628 */       promise.setFailure(new UnsupportedOperationException());
/*      */     }
/*      */ 
/*      */     
/*      */     public RecvByteBufAllocator.Handle recvBufAllocHandle() {
/*  633 */       if (this.recvHandle == null) {
/*  634 */         this.recvHandle = AbstractHttp2StreamChannel.this.config().getRecvByteBufAllocator().newHandle();
/*  635 */         this.recvHandle.reset(AbstractHttp2StreamChannel.this.config());
/*      */       } 
/*  637 */       return this.recvHandle;
/*      */     }
/*      */ 
/*      */     
/*      */     public SocketAddress localAddress() {
/*  642 */       return AbstractHttp2StreamChannel.this.parent().unsafe().localAddress();
/*      */     }
/*      */ 
/*      */     
/*      */     public SocketAddress remoteAddress() {
/*  647 */       return AbstractHttp2StreamChannel.this.parent().unsafe().remoteAddress();
/*      */     }
/*      */ 
/*      */     
/*      */     public void register(EventLoop eventLoop, ChannelPromise promise) {
/*  652 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*  655 */       if (AbstractHttp2StreamChannel.this.registered) {
/*  656 */         promise.setFailure(new UnsupportedOperationException("Re-register is not supported"));
/*      */         
/*      */         return;
/*      */       } 
/*  660 */       AbstractHttp2StreamChannel.this.registered = true;
/*      */       
/*  662 */       promise.setSuccess();
/*      */       
/*  664 */       AbstractHttp2StreamChannel.this.pipeline().fireChannelRegistered();
/*  665 */       if (AbstractHttp2StreamChannel.this.isActive()) {
/*  666 */         AbstractHttp2StreamChannel.this.pipeline().fireChannelActive();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void bind(SocketAddress localAddress, ChannelPromise promise) {
/*  672 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*  675 */       promise.setFailure(new UnsupportedOperationException());
/*      */     }
/*      */ 
/*      */     
/*      */     public void disconnect(ChannelPromise promise) {
/*  680 */       close(promise);
/*      */     }
/*      */ 
/*      */     
/*      */     public void close(ChannelPromise promise) {
/*  685 */       close(promise, Http2Error.CANCEL);
/*      */     }
/*      */     
/*      */     void close(final ChannelPromise promise, Http2Error error) {
/*  689 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*  692 */       if (this.closeInitiated) {
/*  693 */         if (AbstractHttp2StreamChannel.this.closePromise.isDone()) {
/*      */           
/*  695 */           promise.setSuccess();
/*  696 */         } else if (!(promise instanceof VoidChannelPromise)) {
/*      */           
/*  698 */           AbstractHttp2StreamChannel.this.closePromise.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */               {
/*      */                 public void operationComplete(ChannelFuture future) {
/*  701 */                   promise.setSuccess();
/*      */                 }
/*      */               });
/*      */         } 
/*      */         return;
/*      */       } 
/*  707 */       this.closeInitiated = true;
/*      */       
/*  709 */       AbstractHttp2StreamChannel.this.readCompletePending = false;
/*      */       
/*  711 */       boolean wasActive = AbstractHttp2StreamChannel.this.isActive();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  718 */       if (AbstractHttp2StreamChannel.this.parent().isActive() && !this.readEOS && Http2CodecUtil.isStreamIdValid(AbstractHttp2StreamChannel.this.stream.id())) {
/*  719 */         Http2StreamFrame resetFrame = (new DefaultHttp2ResetFrame(error)).stream(AbstractHttp2StreamChannel.this.stream());
/*  720 */         write(resetFrame, AbstractHttp2StreamChannel.this.unsafe().voidPromise());
/*  721 */         flush();
/*      */       } 
/*      */       
/*  724 */       if (AbstractHttp2StreamChannel.this.inboundBuffer != null) {
/*      */         while (true) {
/*  726 */           Object msg = AbstractHttp2StreamChannel.this.inboundBuffer.poll();
/*  727 */           if (msg == null) {
/*      */             break;
/*      */           }
/*  730 */           ReferenceCountUtil.release(msg);
/*      */         } 
/*  732 */         AbstractHttp2StreamChannel.this.inboundBuffer = null;
/*      */       } 
/*      */ 
/*      */       
/*  736 */       AbstractHttp2StreamChannel.this.outboundClosed = true;
/*  737 */       AbstractHttp2StreamChannel.this.closePromise.setSuccess();
/*  738 */       promise.setSuccess();
/*      */       
/*  740 */       fireChannelInactiveAndDeregister(voidPromise(), wasActive);
/*      */     }
/*      */ 
/*      */     
/*      */     public void closeForcibly() {
/*  745 */       close(AbstractHttp2StreamChannel.this.unsafe().voidPromise());
/*      */     }
/*      */ 
/*      */     
/*      */     public void deregister(ChannelPromise promise) {
/*  750 */       fireChannelInactiveAndDeregister(promise, false);
/*      */     }
/*      */ 
/*      */     
/*      */     private void fireChannelInactiveAndDeregister(final ChannelPromise promise, final boolean fireChannelInactive) {
/*  755 */       if (!promise.setUncancellable()) {
/*      */         return;
/*      */       }
/*      */       
/*  759 */       if (!AbstractHttp2StreamChannel.this.registered) {
/*  760 */         promise.setSuccess();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  771 */       invokeLater(new Runnable()
/*      */           {
/*      */             public void run() {
/*  774 */               if (fireChannelInactive) {
/*  775 */                 AbstractHttp2StreamChannel.this.pipeline.fireChannelInactive();
/*      */               }
/*      */ 
/*      */               
/*  779 */               if (AbstractHttp2StreamChannel.this.registered) {
/*  780 */                 AbstractHttp2StreamChannel.this.registered = false;
/*  781 */                 AbstractHttp2StreamChannel.this.pipeline.fireChannelUnregistered();
/*      */               } 
/*  783 */               AbstractHttp2StreamChannel.Http2ChannelUnsafe.this.safeSetSuccess(promise);
/*      */             }
/*      */           });
/*      */     }
/*      */     
/*      */     private void safeSetSuccess(ChannelPromise promise) {
/*  789 */       if (!(promise instanceof VoidChannelPromise) && !promise.trySuccess()) {
/*  790 */         AbstractHttp2StreamChannel.logger.warn("Failed to mark a promise as success because it is done already: {}", promise);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void invokeLater(Runnable task) {
/*      */       try {
/*  807 */         AbstractHttp2StreamChannel.this.eventLoop().execute(task);
/*  808 */       } catch (RejectedExecutionException e) {
/*  809 */         AbstractHttp2StreamChannel.logger.warn("Can't invoke task later as EventLoop rejected it", e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void beginRead() {
/*  815 */       if (!AbstractHttp2StreamChannel.this.isActive()) {
/*      */         return;
/*      */       }
/*  818 */       updateLocalWindowIfNeeded();
/*      */       
/*  820 */       switch (AbstractHttp2StreamChannel.this.readStatus) {
/*      */         case IDLE:
/*  822 */           AbstractHttp2StreamChannel.this.readStatus = AbstractHttp2StreamChannel.ReadStatus.IN_PROGRESS;
/*  823 */           doBeginRead();
/*      */           break;
/*      */         case IN_PROGRESS:
/*  826 */           AbstractHttp2StreamChannel.this.readStatus = AbstractHttp2StreamChannel.ReadStatus.REQUESTED;
/*      */           break;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private Object pollQueuedMessage() {
/*  834 */       return (AbstractHttp2StreamChannel.this.inboundBuffer == null) ? null : AbstractHttp2StreamChannel.this.inboundBuffer.poll();
/*      */     }
/*      */ 
/*      */     
/*      */     void doBeginRead() {
/*  839 */       while (AbstractHttp2StreamChannel.this.readStatus != AbstractHttp2StreamChannel.ReadStatus.IDLE) {
/*  840 */         Object message = pollQueuedMessage();
/*  841 */         if (message == null) {
/*  842 */           if (this.readEOS) {
/*  843 */             AbstractHttp2StreamChannel.this.unsafe.closeForcibly();
/*      */           }
/*      */ 
/*      */           
/*  847 */           flush();
/*      */           break;
/*      */         } 
/*  850 */         RecvByteBufAllocator.Handle allocHandle = recvBufAllocHandle();
/*  851 */         allocHandle.reset(AbstractHttp2StreamChannel.this.config());
/*  852 */         boolean continueReading = false;
/*      */         do {
/*  854 */           doRead0((Http2Frame)message, allocHandle);
/*  855 */         } while ((this.readEOS || (continueReading = allocHandle.continueReading())) && (
/*  856 */           message = pollQueuedMessage()) != null);
/*      */         
/*  858 */         if (continueReading && AbstractHttp2StreamChannel.this.isParentReadInProgress() && !this.readEOS) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  863 */           AbstractHttp2StreamChannel.this.maybeAddChannelToReadCompletePendingQueue(); continue;
/*      */         } 
/*  865 */         notifyReadComplete(allocHandle, true);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void readEOS() {
/*  871 */       this.readEOS = true;
/*      */     }
/*      */     
/*      */     private void updateLocalWindowIfNeeded() {
/*  875 */       if (AbstractHttp2StreamChannel.this.flowControlledBytes != 0) {
/*  876 */         int bytes = AbstractHttp2StreamChannel.this.flowControlledBytes;
/*  877 */         AbstractHttp2StreamChannel.this.flowControlledBytes = 0;
/*  878 */         ChannelFuture future = AbstractHttp2StreamChannel.this.write0(AbstractHttp2StreamChannel.this.parentContext(), (new DefaultHttp2WindowUpdateFrame(bytes)).stream(AbstractHttp2StreamChannel.this.stream));
/*      */ 
/*      */ 
/*      */         
/*  882 */         this.writeDoneAndNoFlush = true;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  887 */         if (future.isDone()) {
/*  888 */           AbstractHttp2StreamChannel.windowUpdateFrameWriteComplete(future, AbstractHttp2StreamChannel.this);
/*      */         } else {
/*  890 */           future.addListener((GenericFutureListener)AbstractHttp2StreamChannel.this.windowUpdateFrameWriteListener);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     void notifyReadComplete(RecvByteBufAllocator.Handle allocHandle, boolean forceReadComplete) {
/*  896 */       if (!AbstractHttp2StreamChannel.this.readCompletePending && !forceReadComplete) {
/*      */         return;
/*      */       }
/*      */       
/*  900 */       AbstractHttp2StreamChannel.this.readCompletePending = false;
/*      */       
/*  902 */       if (AbstractHttp2StreamChannel.this.readStatus == AbstractHttp2StreamChannel.ReadStatus.REQUESTED) {
/*  903 */         AbstractHttp2StreamChannel.this.readStatus = AbstractHttp2StreamChannel.ReadStatus.IN_PROGRESS;
/*      */       } else {
/*  905 */         AbstractHttp2StreamChannel.this.readStatus = AbstractHttp2StreamChannel.ReadStatus.IDLE;
/*      */       } 
/*      */       
/*  908 */       allocHandle.readComplete();
/*  909 */       AbstractHttp2StreamChannel.this.pipeline().fireChannelReadComplete();
/*      */ 
/*      */ 
/*      */       
/*  913 */       flush();
/*  914 */       if (this.readEOS) {
/*  915 */         AbstractHttp2StreamChannel.this.unsafe.closeForcibly();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     void doRead0(Http2Frame frame, RecvByteBufAllocator.Handle allocHandle) {
/*      */       int bytes;
/*  922 */       if (frame instanceof Http2DataFrame) {
/*  923 */         bytes = ((Http2DataFrame)frame).initialFlowControlledBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  930 */         AbstractHttp2StreamChannel.this.flowControlledBytes = AbstractHttp2StreamChannel.this.flowControlledBytes + bytes;
/*      */       } else {
/*  932 */         bytes = 9;
/*      */       } 
/*      */       
/*  935 */       allocHandle.attemptedBytesRead(bytes);
/*  936 */       allocHandle.lastBytesRead(bytes);
/*  937 */       allocHandle.incMessagesRead(1);
/*      */       
/*  939 */       AbstractHttp2StreamChannel.this.pipeline().fireChannelRead(frame);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void write(Object msg, ChannelPromise promise) {
/*  945 */       if (!promise.setUncancellable()) {
/*  946 */         ReferenceCountUtil.release(msg);
/*      */         
/*      */         return;
/*      */       } 
/*  950 */       if (!AbstractHttp2StreamChannel.this.isActive() || (AbstractHttp2StreamChannel.this
/*      */         
/*  952 */         .outboundClosed && (msg instanceof Http2HeadersFrame || msg instanceof Http2DataFrame))) {
/*  953 */         ReferenceCountUtil.release(msg);
/*  954 */         promise.setFailure(new ClosedChannelException());
/*      */         
/*      */         return;
/*      */       } 
/*      */       try {
/*  959 */         if (msg instanceof Http2StreamFrame) {
/*  960 */           Http2StreamFrame frame = validateStreamFrame((Http2StreamFrame)msg).stream(AbstractHttp2StreamChannel.this.stream());
/*  961 */           writeHttp2StreamFrame(frame, promise);
/*      */         } else {
/*  963 */           String msgStr = msg.toString();
/*  964 */           ReferenceCountUtil.release(msg);
/*  965 */           promise.setFailure(new IllegalArgumentException("Message must be an " + 
/*  966 */                 StringUtil.simpleClassName(Http2StreamFrame.class) + ": " + msgStr));
/*      */         }
/*      */       
/*  969 */       } catch (Throwable t) {
/*  970 */         promise.tryFailure(t);
/*      */       } 
/*      */     }
/*      */     private void writeHttp2StreamFrame(Http2StreamFrame frame, final ChannelPromise promise) {
/*      */       final boolean firstWrite;
/*  975 */       if (!AbstractHttp2StreamChannel.this.firstFrameWritten && !Http2CodecUtil.isStreamIdValid(AbstractHttp2StreamChannel.this.stream().id()) && !(frame instanceof Http2HeadersFrame)) {
/*  976 */         ReferenceCountUtil.release(frame);
/*  977 */         promise.setFailure(new IllegalArgumentException("The first frame must be a headers frame. Was: " + frame
/*      */               
/*  979 */               .name()));
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  984 */       if (AbstractHttp2StreamChannel.this.firstFrameWritten) {
/*  985 */         firstWrite = false;
/*      */       } else {
/*  987 */         firstWrite = AbstractHttp2StreamChannel.this.firstFrameWritten = true;
/*      */       } 
/*      */       
/*  990 */       ChannelFuture f = AbstractHttp2StreamChannel.this.write0(AbstractHttp2StreamChannel.this.parentContext(), frame);
/*  991 */       if (f.isDone()) {
/*  992 */         if (firstWrite) {
/*  993 */           firstWriteComplete(f, promise);
/*      */         } else {
/*  995 */           writeComplete(f, promise);
/*      */         } 
/*      */       } else {
/*  998 */         final long bytes = AbstractHttp2StreamChannel.FlowControlledFrameSizeEstimator.HANDLE_INSTANCE.size(frame);
/*  999 */         AbstractHttp2StreamChannel.this.incrementPendingOutboundBytes(bytes, false);
/* 1000 */         f.addListener((GenericFutureListener)new ChannelFutureListener()
/*      */             {
/*      */               public void operationComplete(ChannelFuture future) {
/* 1003 */                 if (firstWrite) {
/* 1004 */                   AbstractHttp2StreamChannel.Http2ChannelUnsafe.this.firstWriteComplete(future, promise);
/*      */                 } else {
/* 1006 */                   AbstractHttp2StreamChannel.Http2ChannelUnsafe.this.writeComplete(future, promise);
/*      */                 } 
/* 1008 */                 AbstractHttp2StreamChannel.this.decrementPendingOutboundBytes(bytes, false);
/*      */               }
/*      */             });
/* 1011 */         this.writeDoneAndNoFlush = true;
/*      */       } 
/*      */     }
/*      */     
/*      */     private void firstWriteComplete(ChannelFuture future, ChannelPromise promise) {
/* 1016 */       Throwable cause = future.cause();
/* 1017 */       if (cause == null) {
/* 1018 */         promise.setSuccess();
/*      */       } else {
/*      */         
/* 1021 */         closeForcibly();
/* 1022 */         promise.setFailure(wrapStreamClosedError(cause));
/*      */       } 
/*      */     }
/*      */     
/*      */     private void writeComplete(ChannelFuture future, ChannelPromise promise) {
/* 1027 */       Throwable cause = future.cause();
/* 1028 */       if (cause == null) {
/* 1029 */         promise.setSuccess();
/*      */       } else {
/* 1031 */         Throwable error = wrapStreamClosedError(cause);
/*      */         
/* 1033 */         if (error instanceof java.io.IOException) {
/* 1034 */           if (AbstractHttp2StreamChannel.this.config.isAutoClose()) {
/*      */             
/* 1036 */             closeForcibly();
/*      */           } else {
/*      */             
/* 1039 */             AbstractHttp2StreamChannel.this.outboundClosed = true;
/*      */           } 
/*      */         }
/* 1042 */         promise.setFailure(error);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private Throwable wrapStreamClosedError(Throwable cause) {
/* 1049 */       if (cause instanceof Http2Exception && ((Http2Exception)cause).error() == Http2Error.STREAM_CLOSED) {
/* 1050 */         return (new ClosedChannelException()).initCause(cause);
/*      */       }
/* 1052 */       return cause;
/*      */     }
/*      */     
/*      */     private Http2StreamFrame validateStreamFrame(Http2StreamFrame frame) {
/* 1056 */       if (frame.stream() != null && frame.stream() != AbstractHttp2StreamChannel.this.stream) {
/* 1057 */         String msgString = frame.toString();
/* 1058 */         ReferenceCountUtil.release(frame);
/* 1059 */         throw new IllegalArgumentException("Stream " + frame
/* 1060 */             .stream() + " must not be set on the frame: " + msgString);
/*      */       } 
/* 1062 */       return frame;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void flush() {
/* 1071 */       if (!this.writeDoneAndNoFlush || AbstractHttp2StreamChannel.this.isParentReadInProgress()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1077 */       this.writeDoneAndNoFlush = false;
/* 1078 */       AbstractHttp2StreamChannel.this.flush0(AbstractHttp2StreamChannel.this.parentContext());
/*      */     }
/*      */ 
/*      */     
/*      */     public ChannelPromise voidPromise() {
/* 1083 */       return (ChannelPromise)this.unsafeVoidPromise;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public ChannelOutboundBuffer outboundBuffer() {
/* 1089 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     private Http2ChannelUnsafe() {}
/*      */   }
/*      */   
/*      */   private static final class Http2StreamChannelConfig
/*      */     extends DefaultChannelConfig
/*      */   {
/*      */     Http2StreamChannelConfig(Channel channel) {
/* 1100 */       super(channel);
/*      */     }
/*      */ 
/*      */     
/*      */     public MessageSizeEstimator getMessageSizeEstimator() {
/* 1105 */       return AbstractHttp2StreamChannel.FlowControlledFrameSizeEstimator.INSTANCE;
/*      */     }
/*      */ 
/*      */     
/*      */     public ChannelConfig setMessageSizeEstimator(MessageSizeEstimator estimator) {
/* 1110 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public ChannelConfig setRecvByteBufAllocator(RecvByteBufAllocator allocator) {
/* 1115 */       if (!(allocator.newHandle() instanceof RecvByteBufAllocator.ExtendedHandle)) {
/* 1116 */         throw new IllegalArgumentException("allocator.newHandle() must return an object of type: " + RecvByteBufAllocator.ExtendedHandle.class);
/*      */       }
/*      */       
/* 1119 */       super.setRecvByteBufAllocator(allocator);
/* 1120 */       return (ChannelConfig)this;
/*      */     }
/*      */   }
/*      */   
/*      */   private void maybeAddChannelToReadCompletePendingQueue() {
/* 1125 */     if (!this.readCompletePending) {
/* 1126 */       this.readCompletePending = true;
/* 1127 */       addChannelToReadCompletePendingQueue();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void flush0(ChannelHandlerContext ctx) {
/* 1132 */     ctx.flush();
/*      */   }
/*      */   
/*      */   protected ChannelFuture write0(ChannelHandlerContext ctx, Object msg) {
/* 1136 */     ChannelPromise promise = ctx.newPromise();
/* 1137 */     ctx.write(msg, promise);
/* 1138 */     return (ChannelFuture)promise;
/*      */   }
/*      */   
/*      */   protected abstract boolean isParentReadInProgress();
/*      */   
/*      */   protected abstract void addChannelToReadCompletePendingQueue();
/*      */   
/*      */   protected abstract ChannelHandlerContext parentContext();
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\AbstractHttp2StreamChannel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */