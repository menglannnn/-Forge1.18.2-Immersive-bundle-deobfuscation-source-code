/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.http.EmptyHttpHeaders;
/*     */ import io.netty.handler.codec.http.FullHttpMessage;
/*     */ import io.netty.handler.codec.http.HttpContent;
/*     */ import io.netty.handler.codec.http.HttpHeaders;
/*     */ import io.netty.handler.codec.http.HttpMessage;
/*     */ import io.netty.handler.codec.http.HttpScheme;
/*     */ import io.netty.handler.codec.http.LastHttpContent;
/*     */ import io.netty.util.ReferenceCountUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpToHttp2ConnectionHandler
/*     */   extends Http2ConnectionHandler
/*     */ {
/*     */   private final boolean validateHeaders;
/*     */   private int currentStreamId;
/*     */   private HttpScheme httpScheme;
/*     */   
/*     */   protected HttpToHttp2ConnectionHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings, boolean validateHeaders) {
/*  46 */     super(decoder, encoder, initialSettings);
/*  47 */     this.validateHeaders = validateHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpToHttp2ConnectionHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings, boolean validateHeaders, boolean decoupleCloseAndGoAway) {
/*  53 */     this(decoder, encoder, initialSettings, validateHeaders, decoupleCloseAndGoAway, (HttpScheme)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpToHttp2ConnectionHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings, boolean validateHeaders, boolean decoupleCloseAndGoAway, HttpScheme httpScheme) {
/*  59 */     super(decoder, encoder, initialSettings, decoupleCloseAndGoAway);
/*  60 */     this.validateHeaders = validateHeaders;
/*  61 */     this.httpScheme = httpScheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpToHttp2ConnectionHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings, boolean validateHeaders, boolean decoupleCloseAndGoAway, boolean flushPreface, HttpScheme httpScheme) {
/*  68 */     super(decoder, encoder, initialSettings, decoupleCloseAndGoAway, flushPreface);
/*  69 */     this.validateHeaders = validateHeaders;
/*  70 */     this.httpScheme = httpScheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getStreamId(HttpHeaders httpHeaders) throws Exception {
/*  81 */     return httpHeaders.getInt((CharSequence)HttpConversionUtil.ExtensionHeaderNames.STREAM_ID.text(), 
/*  82 */         connection().local().incrementAndGetNextStreamId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
/*  91 */     if (!(msg instanceof HttpMessage) && !(msg instanceof HttpContent)) {
/*  92 */       ctx.write(msg, promise);
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     boolean release = true;
/*     */     
/*  98 */     Http2CodecUtil.SimpleChannelPromiseAggregator promiseAggregator = new Http2CodecUtil.SimpleChannelPromiseAggregator(promise, ctx.channel(), ctx.executor());
/*     */     try {
/* 100 */       Http2ConnectionEncoder encoder = encoder();
/* 101 */       boolean endStream = false;
/* 102 */       if (msg instanceof HttpMessage) {
/* 103 */         HttpMessage httpMsg = (HttpMessage)msg;
/*     */ 
/*     */         
/* 106 */         this.currentStreamId = getStreamId(httpMsg.headers());
/*     */ 
/*     */         
/* 109 */         if (this.httpScheme != null && 
/* 110 */           !httpMsg.headers().contains((CharSequence)HttpConversionUtil.ExtensionHeaderNames.SCHEME.text())) {
/* 111 */           httpMsg.headers().set((CharSequence)HttpConversionUtil.ExtensionHeaderNames.SCHEME.text(), this.httpScheme.name());
/*     */         }
/*     */ 
/*     */         
/* 115 */         Http2Headers http2Headers = HttpConversionUtil.toHttp2Headers(httpMsg, this.validateHeaders);
/* 116 */         endStream = (msg instanceof FullHttpMessage && !((FullHttpMessage)msg).content().isReadable());
/* 117 */         writeHeaders(ctx, encoder, this.currentStreamId, httpMsg.headers(), http2Headers, endStream, promiseAggregator);
/*     */       } 
/*     */ 
/*     */       
/* 121 */       if (!endStream && msg instanceof HttpContent) {
/* 122 */         HttpHeaders httpHeaders; boolean isLastContent = false;
/* 123 */         EmptyHttpHeaders emptyHttpHeaders = EmptyHttpHeaders.INSTANCE;
/* 124 */         Http2Headers http2Trailers = EmptyHttp2Headers.INSTANCE;
/* 125 */         if (msg instanceof LastHttpContent) {
/* 126 */           isLastContent = true;
/*     */ 
/*     */           
/* 129 */           LastHttpContent lastContent = (LastHttpContent)msg;
/* 130 */           httpHeaders = lastContent.trailingHeaders();
/* 131 */           http2Trailers = HttpConversionUtil.toHttp2Headers(httpHeaders, this.validateHeaders);
/*     */         } 
/*     */ 
/*     */         
/* 135 */         ByteBuf content = ((HttpContent)msg).content();
/* 136 */         endStream = (isLastContent && httpHeaders.isEmpty());
/* 137 */         encoder.writeData(ctx, this.currentStreamId, content, 0, endStream, promiseAggregator.newPromise());
/* 138 */         release = false;
/*     */         
/* 140 */         if (!httpHeaders.isEmpty())
/*     */         {
/* 142 */           writeHeaders(ctx, encoder, this.currentStreamId, httpHeaders, http2Trailers, true, promiseAggregator);
/*     */         }
/*     */       } 
/* 145 */     } catch (Throwable t) {
/* 146 */       onError(ctx, true, t);
/* 147 */       promiseAggregator.setFailure(t);
/*     */     } finally {
/* 149 */       if (release) {
/* 150 */         ReferenceCountUtil.release(msg);
/*     */       }
/* 152 */       promiseAggregator.doneAllocatingPromises();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void writeHeaders(ChannelHandlerContext ctx, Http2ConnectionEncoder encoder, int streamId, HttpHeaders headers, Http2Headers http2Headers, boolean endStream, Http2CodecUtil.SimpleChannelPromiseAggregator promiseAggregator) {
/* 159 */     int dependencyId = headers.getInt((CharSequence)HttpConversionUtil.ExtensionHeaderNames.STREAM_DEPENDENCY_ID
/* 160 */         .text(), 0);
/* 161 */     short weight = headers.getShort((CharSequence)HttpConversionUtil.ExtensionHeaderNames.STREAM_WEIGHT
/* 162 */         .text(), (short)16);
/* 163 */     encoder.writeHeaders(ctx, streamId, http2Headers, dependencyId, weight, false, 0, endStream, promiseAggregator
/* 164 */         .newPromise());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\HttpToHttp2ConnectionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */