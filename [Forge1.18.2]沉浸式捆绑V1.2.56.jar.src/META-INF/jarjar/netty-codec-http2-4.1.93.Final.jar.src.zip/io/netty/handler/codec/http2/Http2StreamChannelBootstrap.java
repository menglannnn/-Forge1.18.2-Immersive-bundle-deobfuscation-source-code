/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import io.netty.util.AttributeKey;
/*     */ import io.netty.util.concurrent.EventExecutor;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.concurrent.Promise;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.StringUtil;
/*     */ import io.netty.util.internal.logging.InternalLogger;
/*     */ import io.netty.util.internal.logging.InternalLoggerFactory;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2StreamChannelBootstrap
/*     */ {
/*  42 */   private static final InternalLogger logger = InternalLoggerFactory.getInstance(Http2StreamChannelBootstrap.class);
/*     */   
/*  44 */   private static final Map.Entry<ChannelOption<?>, Object>[] EMPTY_OPTION_ARRAY = (Map.Entry<ChannelOption<?>, Object>[])new Map.Entry[0];
/*     */   
/*  46 */   private static final Map.Entry<AttributeKey<?>, Object>[] EMPTY_ATTRIBUTE_ARRAY = (Map.Entry<AttributeKey<?>, Object>[])new Map.Entry[0];
/*     */ 
/*     */ 
/*     */   
/*  50 */   private final Map<ChannelOption<?>, Object> options = new LinkedHashMap<ChannelOption<?>, Object>();
/*  51 */   private final Map<AttributeKey<?>, Object> attrs = new ConcurrentHashMap<AttributeKey<?>, Object>();
/*     */   
/*     */   private final Channel channel;
/*     */   
/*     */   private volatile ChannelHandler handler;
/*     */   private volatile ChannelHandlerContext multiplexCtx;
/*     */   
/*     */   public Http2StreamChannelBootstrap(Channel channel) {
/*  59 */     this.channel = (Channel)ObjectUtil.checkNotNull(channel, "channel");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Http2StreamChannelBootstrap option(ChannelOption<T> option, T value) {
/*  67 */     ObjectUtil.checkNotNull(option, "option");
/*     */     
/*  69 */     synchronized (this.options) {
/*  70 */       if (value == null) {
/*  71 */         this.options.remove(option);
/*     */       } else {
/*  73 */         this.options.put(option, value);
/*     */       } 
/*     */     } 
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Http2StreamChannelBootstrap attr(AttributeKey<T> key, T value) {
/*  84 */     ObjectUtil.checkNotNull(key, "key");
/*  85 */     if (value == null) {
/*  86 */       this.attrs.remove(key);
/*     */     } else {
/*  88 */       this.attrs.put(key, value);
/*     */     } 
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2StreamChannelBootstrap handler(ChannelHandler handler) {
/*  97 */     this.handler = (ChannelHandler)ObjectUtil.checkNotNull(handler, "handler");
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Future<Http2StreamChannel> open() {
/* 106 */     return open(this.channel.eventLoop().newPromise());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Future<Http2StreamChannel> open(final Promise<Http2StreamChannel> promise) {
/*     */     try {
/* 115 */       ChannelHandlerContext ctx = findCtx();
/* 116 */       EventExecutor executor = ctx.executor();
/* 117 */       if (executor.inEventLoop()) {
/* 118 */         open0(ctx, promise);
/*     */       } else {
/* 120 */         final ChannelHandlerContext finalCtx = ctx;
/* 121 */         executor.execute(new Runnable()
/*     */             {
/*     */               public void run() {
/* 124 */                 if (Http2StreamChannelBootstrap.this.channel.isActive()) {
/* 125 */                   Http2StreamChannelBootstrap.this.open0(finalCtx, promise);
/*     */                 } else {
/* 127 */                   promise.setFailure(new ClosedChannelException());
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } 
/* 132 */     } catch (Throwable cause) {
/* 133 */       promise.setFailure(cause);
/*     */     } 
/* 135 */     return (Future<Http2StreamChannel>)promise;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelHandlerContext findCtx() throws ClosedChannelException {
/* 141 */     ChannelHandlerContext ctx = this.multiplexCtx;
/* 142 */     if (ctx != null && !ctx.isRemoved()) {
/* 143 */       return ctx;
/*     */     }
/* 145 */     ChannelPipeline pipeline = this.channel.pipeline();
/* 146 */     ctx = pipeline.context(Http2MultiplexCodec.class);
/* 147 */     if (ctx == null) {
/* 148 */       ctx = pipeline.context(Http2MultiplexHandler.class);
/*     */     }
/* 150 */     if (ctx == null) {
/* 151 */       if (this.channel.isActive()) {
/* 152 */         throw new IllegalStateException(StringUtil.simpleClassName(Http2MultiplexCodec.class) + " or " + 
/* 153 */             StringUtil.simpleClassName(Http2MultiplexHandler.class) + " must be in the ChannelPipeline of Channel " + this.channel);
/*     */       }
/*     */       
/* 156 */       throw new ClosedChannelException();
/*     */     } 
/*     */     
/* 159 */     this.multiplexCtx = ctx;
/* 160 */     return ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void open0(ChannelHandlerContext ctx, final Promise<Http2StreamChannel> promise) {
/*     */     final Http2StreamChannel streamChannel;
/* 168 */     assert ctx.executor().inEventLoop();
/* 169 */     if (!promise.setUncancellable()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 174 */       if (ctx.handler() instanceof Http2MultiplexCodec) {
/* 175 */         streamChannel = ((Http2MultiplexCodec)ctx.handler()).newOutboundStream();
/*     */       } else {
/* 177 */         streamChannel = ((Http2MultiplexHandler)ctx.handler()).newOutboundStream();
/*     */       } 
/* 179 */     } catch (Exception e) {
/* 180 */       promise.setFailure(e);
/*     */       return;
/*     */     } 
/*     */     try {
/* 184 */       init(streamChannel);
/* 185 */     } catch (Exception e) {
/* 186 */       streamChannel.unsafe().closeForcibly();
/* 187 */       promise.setFailure(e);
/*     */       
/*     */       return;
/*     */     } 
/* 191 */     ChannelFuture future = ctx.channel().eventLoop().register(streamChannel);
/* 192 */     future.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */         {
/*     */           public void operationComplete(ChannelFuture future) {
/* 195 */             if (future.isSuccess()) {
/* 196 */               promise.setSuccess(streamChannel);
/* 197 */             } else if (future.isCancelled()) {
/* 198 */               promise.cancel(false);
/*     */             } else {
/* 200 */               if (streamChannel.isRegistered()) {
/* 201 */                 streamChannel.close();
/*     */               } else {
/* 203 */                 streamChannel.unsafe().closeForcibly();
/*     */               } 
/*     */               
/* 206 */               promise.setFailure(future.cause());
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   private void init(Channel channel) {
/*     */     Map.Entry[] arrayOfEntry;
/* 213 */     ChannelPipeline p = channel.pipeline();
/* 214 */     ChannelHandler handler = this.handler;
/* 215 */     if (handler != null) {
/* 216 */       p.addLast(new ChannelHandler[] { handler });
/*     */     }
/*     */     
/* 219 */     synchronized (this.options) {
/* 220 */       arrayOfEntry = (Map.Entry[])this.options.entrySet().toArray((Object[])EMPTY_OPTION_ARRAY);
/*     */     } 
/*     */     
/* 223 */     setChannelOptions(channel, (Map.Entry<ChannelOption<?>, Object>[])arrayOfEntry);
/* 224 */     setAttributes(channel, (Map.Entry<AttributeKey<?>, Object>[])this.attrs.entrySet().toArray((Object[])EMPTY_ATTRIBUTE_ARRAY));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void setChannelOptions(Channel channel, Map.Entry<ChannelOption<?>, Object>[] options) {
/* 229 */     for (Map.Entry<ChannelOption<?>, Object> e : options) {
/* 230 */       setChannelOption(channel, e.getKey(), e.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setChannelOption(Channel channel, ChannelOption<?> option, Object value) {
/*     */     try {
/* 238 */       ChannelOption<Object> opt = (ChannelOption)option;
/* 239 */       if (!channel.config().setOption(opt, value)) {
/* 240 */         logger.warn("Unknown channel option '{}' for channel '{}'", option, channel);
/*     */       }
/* 242 */     } catch (Throwable t) {
/* 243 */       logger.warn("Failed to set channel option '{}' with value '{}' for channel '{}'", new Object[] { option, value, channel, t });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setAttributes(Channel channel, Map.Entry<AttributeKey<?>, Object>[] options) {
/* 250 */     for (Map.Entry<AttributeKey<?>, Object> e : options) {
/*     */       
/* 252 */       AttributeKey<Object> key = (AttributeKey<Object>)e.getKey();
/* 253 */       channel.attr(key).set(e.getValue());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\Http2StreamChannelBootstrap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */