/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import io.netty.util.internal.PlatformDependent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2LocalFlowController
/*     */   implements Http2LocalFlowController
/*     */ {
/*     */   public static final float DEFAULT_WINDOW_UPDATE_RATIO = 0.5F;
/*     */   private final Http2Connection connection;
/*     */   private final Http2Connection.PropertyKey stateKey;
/*     */   private Http2FrameWriter frameWriter;
/*     */   private ChannelHandlerContext ctx;
/*     */   private float windowUpdateRatio;
/*  56 */   private int initialWindowSize = 65535;
/*     */   
/*     */   public DefaultHttp2LocalFlowController(Http2Connection connection) {
/*  59 */     this(connection, 0.5F, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHttp2LocalFlowController(Http2Connection connection, float windowUpdateRatio, boolean autoRefillConnectionWindow) {
/*  78 */     this.connection = (Http2Connection)ObjectUtil.checkNotNull(connection, "connection");
/*  79 */     windowUpdateRatio(windowUpdateRatio);
/*     */ 
/*     */     
/*  82 */     this.stateKey = connection.newKey();
/*     */ 
/*     */     
/*  85 */     FlowState connectionState = autoRefillConnectionWindow ? new AutoRefillState(connection.connectionStream(), this.initialWindowSize) : new DefaultState(connection.connectionStream(), this.initialWindowSize);
/*  86 */     connection.connectionStream().setProperty(this.stateKey, connectionState);
/*     */ 
/*     */     
/*  89 */     connection.addListener(new Http2ConnectionAdapter()
/*     */         {
/*     */           
/*     */           public void onStreamAdded(Http2Stream stream)
/*     */           {
/*  94 */             stream.setProperty(DefaultHttp2LocalFlowController.this.stateKey, DefaultHttp2LocalFlowController.REDUCED_FLOW_STATE);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onStreamActive(Http2Stream stream) {
/* 101 */             stream.setProperty(DefaultHttp2LocalFlowController.this.stateKey, new DefaultHttp2LocalFlowController.DefaultState(stream, DefaultHttp2LocalFlowController.this.initialWindowSize));
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onStreamClosed(Http2Stream stream) {
/*     */             try {
/* 109 */               DefaultHttp2LocalFlowController.FlowState state = DefaultHttp2LocalFlowController.this.state(stream);
/* 110 */               int unconsumedBytes = state.unconsumedBytes();
/* 111 */               if (DefaultHttp2LocalFlowController.this.ctx != null && unconsumedBytes > 0 && 
/* 112 */                 DefaultHttp2LocalFlowController.this.consumeAllBytes(state, unconsumedBytes))
/*     */               {
/*     */                 
/* 115 */                 DefaultHttp2LocalFlowController.this.ctx.flush();
/*     */               }
/*     */             }
/* 118 */             catch (Http2Exception e) {
/* 119 */               PlatformDependent.throwException(e);
/*     */             
/*     */             }
/*     */             finally {
/*     */               
/* 124 */               stream.setProperty(DefaultHttp2LocalFlowController.this.stateKey, DefaultHttp2LocalFlowController.REDUCED_FLOW_STATE);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultHttp2LocalFlowController frameWriter(Http2FrameWriter frameWriter) {
/* 132 */     this.frameWriter = (Http2FrameWriter)ObjectUtil.checkNotNull(frameWriter, "frameWriter");
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void channelHandlerContext(ChannelHandlerContext ctx) {
/* 138 */     this.ctx = (ChannelHandlerContext)ObjectUtil.checkNotNull(ctx, "ctx");
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialWindowSize(int newWindowSize) throws Http2Exception {
/* 143 */     assert this.ctx == null || this.ctx.executor().inEventLoop();
/* 144 */     int delta = newWindowSize - this.initialWindowSize;
/* 145 */     this.initialWindowSize = newWindowSize;
/*     */     
/* 147 */     WindowUpdateVisitor visitor = new WindowUpdateVisitor(delta);
/* 148 */     this.connection.forEachActiveStream(visitor);
/* 149 */     visitor.throwIfError();
/*     */   }
/*     */ 
/*     */   
/*     */   public int initialWindowSize() {
/* 154 */     return this.initialWindowSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int windowSize(Http2Stream stream) {
/* 159 */     return state(stream).windowSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public int initialWindowSize(Http2Stream stream) {
/* 164 */     return state(stream).initialWindowSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void incrementWindowSize(Http2Stream stream, int delta) throws Http2Exception {
/* 169 */     assert this.ctx != null && this.ctx.executor().inEventLoop();
/* 170 */     FlowState state = state(stream);
/*     */ 
/*     */     
/* 173 */     state.incrementInitialStreamWindow(delta);
/* 174 */     state.writeWindowUpdateIfNeeded();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean consumeBytes(Http2Stream stream, int numBytes) throws Http2Exception {
/* 179 */     assert this.ctx != null && this.ctx.executor().inEventLoop();
/* 180 */     ObjectUtil.checkPositiveOrZero(numBytes, "numBytes");
/* 181 */     if (numBytes == 0) {
/* 182 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 187 */     if (stream != null && !isClosed(stream)) {
/* 188 */       if (stream.id() == 0) {
/* 189 */         throw new UnsupportedOperationException("Returning bytes for the connection window is not supported");
/*     */       }
/*     */       
/* 192 */       return consumeAllBytes(state(stream), numBytes);
/*     */     } 
/* 194 */     return false;
/*     */   }
/*     */   
/*     */   private boolean consumeAllBytes(FlowState state, int numBytes) throws Http2Exception {
/* 198 */     return connectionState().consumeBytes(numBytes) | state.consumeBytes(numBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public int unconsumedBytes(Http2Stream stream) {
/* 203 */     return state(stream).unconsumedBytes();
/*     */   }
/*     */   
/*     */   private static void checkValidRatio(float ratio) {
/* 207 */     if (Double.compare(ratio, 0.0D) <= 0 || Double.compare(ratio, 1.0D) >= 0) {
/* 208 */       throw new IllegalArgumentException("Invalid ratio: " + ratio);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowUpdateRatio(float ratio) {
/* 220 */     assert this.ctx == null || this.ctx.executor().inEventLoop();
/* 221 */     checkValidRatio(ratio);
/* 222 */     this.windowUpdateRatio = ratio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float windowUpdateRatio() {
/* 231 */     return this.windowUpdateRatio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowUpdateRatio(Http2Stream stream, float ratio) throws Http2Exception {
/* 248 */     assert this.ctx != null && this.ctx.executor().inEventLoop();
/* 249 */     checkValidRatio(ratio);
/* 250 */     FlowState state = state(stream);
/* 251 */     state.windowUpdateRatio(ratio);
/* 252 */     state.writeWindowUpdateIfNeeded();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float windowUpdateRatio(Http2Stream stream) throws Http2Exception {
/* 262 */     return state(stream).windowUpdateRatio();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void receiveFlowControlledFrame(Http2Stream stream, ByteBuf data, int padding, boolean endOfStream) throws Http2Exception {
/* 268 */     assert this.ctx != null && this.ctx.executor().inEventLoop();
/* 269 */     int dataLength = data.readableBytes() + padding;
/*     */ 
/*     */     
/* 272 */     FlowState connectionState = connectionState();
/* 273 */     connectionState.receiveFlowControlledFrame(dataLength);
/*     */     
/* 275 */     if (stream != null && !isClosed(stream)) {
/*     */       
/* 277 */       FlowState state = state(stream);
/* 278 */       state.endOfStream(endOfStream);
/* 279 */       state.receiveFlowControlledFrame(dataLength);
/* 280 */     } else if (dataLength > 0) {
/*     */       
/* 282 */       connectionState.consumeBytes(dataLength);
/*     */     } 
/*     */   }
/*     */   
/*     */   private FlowState connectionState() {
/* 287 */     return this.connection.connectionStream().<FlowState>getProperty(this.stateKey);
/*     */   }
/*     */   
/*     */   private FlowState state(Http2Stream stream) {
/* 291 */     return stream.<FlowState>getProperty(this.stateKey);
/*     */   }
/*     */   
/*     */   private static boolean isClosed(Http2Stream stream) {
/* 295 */     return (stream.state() == Http2Stream.State.CLOSED);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class AutoRefillState
/*     */     extends DefaultState
/*     */   {
/*     */     AutoRefillState(Http2Stream stream, int initialWindowSize) {
/* 304 */       super(stream, initialWindowSize);
/*     */     }
/*     */ 
/*     */     
/*     */     public void receiveFlowControlledFrame(int dataLength) throws Http2Exception {
/* 309 */       super.receiveFlowControlledFrame(dataLength);
/*     */       
/* 311 */       super.consumeBytes(dataLength);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean consumeBytes(int numBytes) throws Http2Exception {
/* 317 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class DefaultState
/*     */     implements FlowState
/*     */   {
/*     */     private final Http2Stream stream;
/*     */ 
/*     */ 
/*     */     
/*     */     private int window;
/*     */ 
/*     */ 
/*     */     
/*     */     private int processedWindow;
/*     */ 
/*     */ 
/*     */     
/*     */     private int initialStreamWindowSize;
/*     */ 
/*     */ 
/*     */     
/*     */     private float streamWindowUpdateRatio;
/*     */ 
/*     */ 
/*     */     
/*     */     private int lowerBound;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean endOfStream;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DefaultState(Http2Stream stream, int initialWindowSize) {
/* 357 */       this.stream = stream;
/* 358 */       window(initialWindowSize);
/* 359 */       this.streamWindowUpdateRatio = DefaultHttp2LocalFlowController.this.windowUpdateRatio;
/*     */     }
/*     */ 
/*     */     
/*     */     public void window(int initialWindowSize) {
/* 364 */       assert DefaultHttp2LocalFlowController.this.ctx == null || DefaultHttp2LocalFlowController.this.ctx.executor().inEventLoop();
/* 365 */       this.window = this.processedWindow = this.initialStreamWindowSize = initialWindowSize;
/*     */     }
/*     */ 
/*     */     
/*     */     public int windowSize() {
/* 370 */       return this.window;
/*     */     }
/*     */ 
/*     */     
/*     */     public int initialWindowSize() {
/* 375 */       return this.initialStreamWindowSize;
/*     */     }
/*     */ 
/*     */     
/*     */     public void endOfStream(boolean endOfStream) {
/* 380 */       this.endOfStream = endOfStream;
/*     */     }
/*     */ 
/*     */     
/*     */     public float windowUpdateRatio() {
/* 385 */       return this.streamWindowUpdateRatio;
/*     */     }
/*     */ 
/*     */     
/*     */     public void windowUpdateRatio(float ratio) {
/* 390 */       assert DefaultHttp2LocalFlowController.this.ctx == null || DefaultHttp2LocalFlowController.this.ctx.executor().inEventLoop();
/* 391 */       this.streamWindowUpdateRatio = ratio;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void incrementInitialStreamWindow(int delta) {
/* 397 */       int newValue = (int)Math.min(2147483647L, 
/* 398 */           Math.max(0L, this.initialStreamWindowSize + delta));
/* 399 */       delta = newValue - this.initialStreamWindowSize;
/*     */       
/* 401 */       this.initialStreamWindowSize += delta;
/*     */     }
/*     */ 
/*     */     
/*     */     public void incrementFlowControlWindows(int delta) throws Http2Exception {
/* 406 */       if (delta > 0 && this.window > Integer.MAX_VALUE - delta) {
/* 407 */         throw Http2Exception.streamError(this.stream.id(), Http2Error.FLOW_CONTROL_ERROR, "Flow control window overflowed for stream: %d", new Object[] {
/* 408 */               Integer.valueOf(this.stream.id())
/*     */             });
/*     */       }
/* 411 */       this.window += delta;
/* 412 */       this.processedWindow += delta;
/* 413 */       this.lowerBound = Math.min(delta, 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public void receiveFlowControlledFrame(int dataLength) throws Http2Exception {
/* 418 */       assert dataLength >= 0;
/*     */ 
/*     */       
/* 421 */       this.window -= dataLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 428 */       if (this.window < this.lowerBound)
/* 429 */         throw Http2Exception.streamError(this.stream.id(), Http2Error.FLOW_CONTROL_ERROR, "Flow control window exceeded for stream: %d", new Object[] {
/* 430 */               Integer.valueOf(this.stream.id())
/*     */             }); 
/*     */     }
/*     */     
/*     */     private void returnProcessedBytes(int delta) throws Http2Exception {
/* 435 */       if (this.processedWindow - delta < this.window)
/* 436 */         throw Http2Exception.streamError(this.stream.id(), Http2Error.INTERNAL_ERROR, "Attempting to return too many bytes for stream %d", new Object[] {
/* 437 */               Integer.valueOf(this.stream.id())
/*     */             }); 
/* 439 */       this.processedWindow -= delta;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean consumeBytes(int numBytes) throws Http2Exception {
/* 445 */       returnProcessedBytes(numBytes);
/* 446 */       return writeWindowUpdateIfNeeded();
/*     */     }
/*     */ 
/*     */     
/*     */     public int unconsumedBytes() {
/* 451 */       return this.processedWindow - this.window;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean writeWindowUpdateIfNeeded() throws Http2Exception {
/* 456 */       if (this.endOfStream || this.initialStreamWindowSize <= 0 || DefaultHttp2LocalFlowController
/*     */         
/* 458 */         .isClosed(this.stream)) {
/* 459 */         return false;
/*     */       }
/*     */       
/* 462 */       int threshold = (int)(this.initialStreamWindowSize * this.streamWindowUpdateRatio);
/* 463 */       if (this.processedWindow <= threshold) {
/* 464 */         writeWindowUpdate();
/* 465 */         return true;
/*     */       } 
/* 467 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void writeWindowUpdate() throws Http2Exception {
/* 476 */       int deltaWindowSize = this.initialStreamWindowSize - this.processedWindow;
/*     */       try {
/* 478 */         incrementFlowControlWindows(deltaWindowSize);
/* 479 */       } catch (Throwable t) {
/* 480 */         throw Http2Exception.connectionError(Http2Error.INTERNAL_ERROR, t, "Attempting to return too many bytes for stream %d", new Object[] {
/* 481 */               Integer.valueOf(this.stream.id())
/*     */             });
/*     */       } 
/*     */       
/* 485 */       DefaultHttp2LocalFlowController.this.frameWriter.writeWindowUpdate(DefaultHttp2LocalFlowController.this.ctx, this.stream.id(), deltaWindowSize, DefaultHttp2LocalFlowController.this.ctx.newPromise());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 493 */   private static final FlowState REDUCED_FLOW_STATE = new FlowState()
/*     */     {
/*     */       public int windowSize()
/*     */       {
/* 497 */         return 0;
/*     */       }
/*     */ 
/*     */       
/*     */       public int initialWindowSize() {
/* 502 */         return 0;
/*     */       }
/*     */ 
/*     */       
/*     */       public void window(int initialWindowSize) {
/* 507 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void incrementInitialStreamWindow(int delta) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean writeWindowUpdateIfNeeded() throws Http2Exception {
/* 518 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean consumeBytes(int numBytes) throws Http2Exception {
/* 523 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public int unconsumedBytes() {
/* 528 */         return 0;
/*     */       }
/*     */ 
/*     */       
/*     */       public float windowUpdateRatio() {
/* 533 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */       
/*     */       public void windowUpdateRatio(float ratio) {
/* 538 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */       
/*     */       public void receiveFlowControlledFrame(int dataLength) throws Http2Exception {
/* 543 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void incrementFlowControlWindows(int delta) throws Http2Exception {}
/*     */ 
/*     */ 
/*     */       
/*     */       public void endOfStream(boolean endOfStream) {
/* 554 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class WindowUpdateVisitor
/*     */     implements Http2StreamVisitor
/*     */   {
/*     */     private Http2Exception.CompositeStreamException compositeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int delta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     WindowUpdateVisitor(int delta) {
/* 623 */       this.delta = delta;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean visit(Http2Stream stream) throws Http2Exception {
/*     */       try {
/* 630 */         DefaultHttp2LocalFlowController.FlowState state = DefaultHttp2LocalFlowController.this.state(stream);
/* 631 */         state.incrementFlowControlWindows(this.delta);
/* 632 */         state.incrementInitialStreamWindow(this.delta);
/* 633 */       } catch (StreamException e) {
/* 634 */         if (this.compositeException == null) {
/* 635 */           this.compositeException = new Http2Exception.CompositeStreamException(e.error(), 4);
/*     */         }
/* 637 */         this.compositeException.add(e);
/*     */       } 
/* 639 */       return true;
/*     */     }
/*     */     
/*     */     public void throwIfError() throws Http2Exception.CompositeStreamException {
/* 643 */       if (this.compositeException != null)
/* 644 */         throw this.compositeException; 
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface FlowState {
/*     */     int windowSize();
/*     */     
/*     */     int initialWindowSize();
/*     */     
/*     */     void window(int param1Int);
/*     */     
/*     */     void incrementInitialStreamWindow(int param1Int);
/*     */     
/*     */     boolean writeWindowUpdateIfNeeded() throws Http2Exception;
/*     */     
/*     */     boolean consumeBytes(int param1Int) throws Http2Exception;
/*     */     
/*     */     int unconsumedBytes();
/*     */     
/*     */     float windowUpdateRatio();
/*     */     
/*     */     void windowUpdateRatio(float param1Float);
/*     */     
/*     */     void receiveFlowControlledFrame(int param1Int) throws Http2Exception;
/*     */     
/*     */     void incrementFlowControlWindows(int param1Int) throws Http2Exception;
/*     */     
/*     */     void endOfStream(boolean param1Boolean);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2LocalFlowController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */