/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.handler.codec.CharSequenceValueConverter;
/*     */ import io.netty.handler.codec.Headers;
/*     */ import io.netty.util.AsciiString;
/*     */ import io.netty.util.HashingStrategy;
/*     */ import io.netty.util.internal.EmptyArrays;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadOnlyHttp2Headers
/*     */   implements Http2Headers
/*     */ {
/*     */   private static final byte PSEUDO_HEADER_TOKEN = 58;
/*     */   private final AsciiString[] pseudoHeaders;
/*     */   private final AsciiString[] otherHeaders;
/*     */   
/*     */   public static ReadOnlyHttp2Headers trailers(boolean validateHeaders, AsciiString... otherHeaders) {
/*  66 */     return new ReadOnlyHttp2Headers(validateHeaders, EmptyArrays.EMPTY_ASCII_STRINGS, otherHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadOnlyHttp2Headers clientHeaders(boolean validateHeaders, AsciiString method, AsciiString path, AsciiString scheme, AsciiString authority, AsciiString... otherHeaders) {
/*  88 */     return new ReadOnlyHttp2Headers(validateHeaders, new AsciiString[] { Http2Headers.PseudoHeaderName.METHOD
/*     */           
/*  90 */           .value(), method, Http2Headers.PseudoHeaderName.PATH.value(), path, Http2Headers.PseudoHeaderName.SCHEME
/*  91 */           .value(), scheme, Http2Headers.PseudoHeaderName.AUTHORITY.value(), authority }, otherHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadOnlyHttp2Headers serverHeaders(boolean validateHeaders, AsciiString status, AsciiString... otherHeaders) {
/* 111 */     return new ReadOnlyHttp2Headers(validateHeaders, new AsciiString[] { Http2Headers.PseudoHeaderName.STATUS
/* 112 */           .value(), status }, otherHeaders);
/*     */   }
/*     */ 
/*     */   
/*     */   private ReadOnlyHttp2Headers(boolean validateHeaders, AsciiString[] pseudoHeaders, AsciiString... otherHeaders) {
/* 117 */     assert (pseudoHeaders.length & 0x1) == 0;
/* 118 */     if ((otherHeaders.length & 0x1) != 0) {
/* 119 */       throw newInvalidArraySizeException();
/*     */     }
/* 121 */     if (validateHeaders) {
/* 122 */       validateHeaders(pseudoHeaders, otherHeaders);
/*     */     }
/* 124 */     this.pseudoHeaders = pseudoHeaders;
/* 125 */     this.otherHeaders = otherHeaders;
/*     */   }
/*     */   
/*     */   private static IllegalArgumentException newInvalidArraySizeException() {
/* 129 */     return new IllegalArgumentException("pseudoHeaders and otherHeaders must be arrays of [name, value] pairs");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void validateHeaders(AsciiString[] pseudoHeaders, AsciiString... otherHeaders) {
/* 134 */     for (int i = 1; i < pseudoHeaders.length; i += 2)
/*     */     {
/* 136 */       ObjectUtil.checkNotNullArrayParam(pseudoHeaders[i], i, "pseudoHeaders");
/*     */     }
/*     */     
/* 139 */     boolean seenNonPseudoHeader = false;
/* 140 */     int otherHeadersEnd = otherHeaders.length - 1;
/* 141 */     for (int j = 0; j < otherHeadersEnd; j += 2) {
/* 142 */       AsciiString name = otherHeaders[j];
/* 143 */       DefaultHttp2Headers.HTTP2_NAME_VALIDATOR.validateName(name);
/* 144 */       if (!seenNonPseudoHeader && !name.isEmpty() && name.byteAt(0) != 58) {
/* 145 */         seenNonPseudoHeader = true;
/* 146 */       } else if (seenNonPseudoHeader && !name.isEmpty() && name.byteAt(0) == 58) {
/* 147 */         throw new IllegalArgumentException("otherHeaders name at index " + j + " is a pseudo header that appears after non-pseudo headers.");
/*     */       } 
/*     */       
/* 150 */       ObjectUtil.checkNotNullArrayParam(otherHeaders[j + 1], j + 1, "otherHeaders");
/*     */     } 
/*     */   }
/*     */   
/*     */   private AsciiString get0(CharSequence name) {
/* 155 */     int nameHash = AsciiString.hashCode(name);
/*     */     
/* 157 */     int pseudoHeadersEnd = this.pseudoHeaders.length - 1;
/* 158 */     for (int i = 0; i < pseudoHeadersEnd; i += 2) {
/* 159 */       AsciiString roName = this.pseudoHeaders[i];
/* 160 */       if (roName.hashCode() == nameHash && roName.contentEqualsIgnoreCase(name)) {
/* 161 */         return this.pseudoHeaders[i + 1];
/*     */       }
/*     */     } 
/*     */     
/* 165 */     int otherHeadersEnd = this.otherHeaders.length - 1;
/* 166 */     for (int j = 0; j < otherHeadersEnd; j += 2) {
/* 167 */       AsciiString roName = this.otherHeaders[j];
/* 168 */       if (roName.hashCode() == nameHash && roName.contentEqualsIgnoreCase(name)) {
/* 169 */         return this.otherHeaders[j + 1];
/*     */       }
/*     */     } 
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence get(CharSequence name) {
/* 177 */     return (CharSequence)get0(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence get(CharSequence name, CharSequence defaultValue) {
/* 182 */     CharSequence value = get(name);
/* 183 */     return (value != null) ? value : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence getAndRemove(CharSequence name) {
/* 188 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence getAndRemove(CharSequence name, CharSequence defaultValue) {
/* 193 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public List<CharSequence> getAll(CharSequence name) {
/* 198 */     int nameHash = AsciiString.hashCode(name);
/* 199 */     List<CharSequence> values = new ArrayList<CharSequence>();
/*     */     
/* 201 */     int pseudoHeadersEnd = this.pseudoHeaders.length - 1;
/* 202 */     for (int i = 0; i < pseudoHeadersEnd; i += 2) {
/* 203 */       AsciiString roName = this.pseudoHeaders[i];
/* 204 */       if (roName.hashCode() == nameHash && roName.contentEqualsIgnoreCase(name)) {
/* 205 */         values.add(this.pseudoHeaders[i + 1]);
/*     */       }
/*     */     } 
/*     */     
/* 209 */     int otherHeadersEnd = this.otherHeaders.length - 1;
/* 210 */     for (int j = 0; j < otherHeadersEnd; j += 2) {
/* 211 */       AsciiString roName = this.otherHeaders[j];
/* 212 */       if (roName.hashCode() == nameHash && roName.contentEqualsIgnoreCase(name)) {
/* 213 */         values.add(this.otherHeaders[j + 1]);
/*     */       }
/*     */     } 
/*     */     
/* 217 */     return values;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<CharSequence> getAllAndRemove(CharSequence name) {
/* 222 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean getBoolean(CharSequence name) {
/* 227 */     AsciiString value = get0(name);
/* 228 */     return (value != null) ? Boolean.valueOf(CharSequenceValueConverter.INSTANCE.convertToBoolean((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(CharSequence name, boolean defaultValue) {
/* 233 */     Boolean value = getBoolean(name);
/* 234 */     return (value != null) ? value.booleanValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte getByte(CharSequence name) {
/* 239 */     AsciiString value = get0(name);
/* 240 */     return (value != null) ? Byte.valueOf(CharSequenceValueConverter.INSTANCE.convertToByte((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(CharSequence name, byte defaultValue) {
/* 245 */     Byte value = getByte(name);
/* 246 */     return (value != null) ? value.byteValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Character getChar(CharSequence name) {
/* 251 */     AsciiString value = get0(name);
/* 252 */     return (value != null) ? Character.valueOf(CharSequenceValueConverter.INSTANCE.convertToChar((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar(CharSequence name, char defaultValue) {
/* 257 */     Character value = getChar(name);
/* 258 */     return (value != null) ? value.charValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Short getShort(CharSequence name) {
/* 263 */     AsciiString value = get0(name);
/* 264 */     return (value != null) ? Short.valueOf(CharSequenceValueConverter.INSTANCE.convertToShort((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(CharSequence name, short defaultValue) {
/* 269 */     Short value = getShort(name);
/* 270 */     return (value != null) ? value.shortValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getInt(CharSequence name) {
/* 275 */     AsciiString value = get0(name);
/* 276 */     return (value != null) ? Integer.valueOf(CharSequenceValueConverter.INSTANCE.convertToInt((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(CharSequence name, int defaultValue) {
/* 281 */     Integer value = getInt(name);
/* 282 */     return (value != null) ? value.intValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getLong(CharSequence name) {
/* 287 */     AsciiString value = get0(name);
/* 288 */     return (value != null) ? Long.valueOf(CharSequenceValueConverter.INSTANCE.convertToLong((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(CharSequence name, long defaultValue) {
/* 293 */     Long value = getLong(name);
/* 294 */     return (value != null) ? value.longValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Float getFloat(CharSequence name) {
/* 299 */     AsciiString value = get0(name);
/* 300 */     return (value != null) ? Float.valueOf(CharSequenceValueConverter.INSTANCE.convertToFloat((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(CharSequence name, float defaultValue) {
/* 305 */     Float value = getFloat(name);
/* 306 */     return (value != null) ? value.floatValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Double getDouble(CharSequence name) {
/* 311 */     AsciiString value = get0(name);
/* 312 */     return (value != null) ? Double.valueOf(CharSequenceValueConverter.INSTANCE.convertToDouble((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(CharSequence name, double defaultValue) {
/* 317 */     Double value = getDouble(name);
/* 318 */     return (value != null) ? value.doubleValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getTimeMillis(CharSequence name) {
/* 323 */     AsciiString value = get0(name);
/* 324 */     return (value != null) ? Long.valueOf(CharSequenceValueConverter.INSTANCE.convertToTimeMillis((CharSequence)value)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTimeMillis(CharSequence name, long defaultValue) {
/* 329 */     Long value = getTimeMillis(name);
/* 330 */     return (value != null) ? value.longValue() : defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean getBooleanAndRemove(CharSequence name) {
/* 335 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBooleanAndRemove(CharSequence name, boolean defaultValue) {
/* 340 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte getByteAndRemove(CharSequence name) {
/* 345 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByteAndRemove(CharSequence name, byte defaultValue) {
/* 350 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Character getCharAndRemove(CharSequence name) {
/* 355 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getCharAndRemove(CharSequence name, char defaultValue) {
/* 360 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Short getShortAndRemove(CharSequence name) {
/* 365 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShortAndRemove(CharSequence name, short defaultValue) {
/* 370 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getIntAndRemove(CharSequence name) {
/* 375 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntAndRemove(CharSequence name, int defaultValue) {
/* 380 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getLongAndRemove(CharSequence name) {
/* 385 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLongAndRemove(CharSequence name, long defaultValue) {
/* 390 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Float getFloatAndRemove(CharSequence name) {
/* 395 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatAndRemove(CharSequence name, float defaultValue) {
/* 400 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Double getDoubleAndRemove(CharSequence name) {
/* 405 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDoubleAndRemove(CharSequence name, double defaultValue) {
/* 410 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getTimeMillisAndRemove(CharSequence name) {
/* 415 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTimeMillisAndRemove(CharSequence name, long defaultValue) {
/* 420 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(CharSequence name) {
/* 425 */     return (get(name) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(CharSequence name, CharSequence value) {
/* 430 */     return contains(name, value, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsObject(CharSequence name, Object value) {
/* 435 */     if (value instanceof CharSequence) {
/* 436 */       return contains(name, (CharSequence)value);
/*     */     }
/* 438 */     return contains(name, value.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsBoolean(CharSequence name, boolean value) {
/* 443 */     return contains(name, String.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsByte(CharSequence name, byte value) {
/* 448 */     return contains(name, String.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsChar(CharSequence name, char value) {
/* 453 */     return contains(name, String.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsShort(CharSequence name, short value) {
/* 458 */     return contains(name, String.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsInt(CharSequence name, int value) {
/* 463 */     return contains(name, String.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsLong(CharSequence name, long value) {
/* 468 */     return contains(name, String.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsFloat(CharSequence name, float value) {
/* 473 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsDouble(CharSequence name, double value) {
/* 478 */     return contains(name, String.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsTimeMillis(CharSequence name, long value) {
/* 483 */     return contains(name, String.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 488 */     return this.pseudoHeaders.length + this.otherHeaders.length >>> 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 493 */     return (this.pseudoHeaders.length == 0 && this.otherHeaders.length == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<CharSequence> names() {
/* 498 */     if (isEmpty()) {
/* 499 */       return Collections.emptySet();
/*     */     }
/* 501 */     Set<CharSequence> names = new LinkedHashSet<CharSequence>(size());
/* 502 */     int pseudoHeadersEnd = this.pseudoHeaders.length - 1;
/* 503 */     for (int i = 0; i < pseudoHeadersEnd; i += 2) {
/* 504 */       names.add(this.pseudoHeaders[i]);
/*     */     }
/*     */     
/* 507 */     int otherHeadersEnd = this.otherHeaders.length - 1;
/* 508 */     for (int j = 0; j < otherHeadersEnd; j += 2) {
/* 509 */       names.add(this.otherHeaders[j]);
/*     */     }
/* 511 */     return names;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers add(CharSequence name, CharSequence value) {
/* 516 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers add(CharSequence name, Iterable<? extends CharSequence> values) {
/* 521 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers add(CharSequence name, CharSequence... values) {
/* 526 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addObject(CharSequence name, Object value) {
/* 531 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addObject(CharSequence name, Iterable<?> values) {
/* 536 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addObject(CharSequence name, Object... values) {
/* 541 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addBoolean(CharSequence name, boolean value) {
/* 546 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addByte(CharSequence name, byte value) {
/* 551 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addChar(CharSequence name, char value) {
/* 556 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addShort(CharSequence name, short value) {
/* 561 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addInt(CharSequence name, int value) {
/* 566 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addLong(CharSequence name, long value) {
/* 571 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addFloat(CharSequence name, float value) {
/* 576 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addDouble(CharSequence name, double value) {
/* 581 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers addTimeMillis(CharSequence name, long value) {
/* 586 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers add(Headers<? extends CharSequence, ? extends CharSequence, ?> headers) {
/* 591 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers set(CharSequence name, CharSequence value) {
/* 596 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers set(CharSequence name, Iterable<? extends CharSequence> values) {
/* 601 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers set(CharSequence name, CharSequence... values) {
/* 606 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setObject(CharSequence name, Object value) {
/* 611 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setObject(CharSequence name, Iterable<?> values) {
/* 616 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setObject(CharSequence name, Object... values) {
/* 621 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setBoolean(CharSequence name, boolean value) {
/* 626 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setByte(CharSequence name, byte value) {
/* 631 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setChar(CharSequence name, char value) {
/* 636 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setShort(CharSequence name, short value) {
/* 641 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setInt(CharSequence name, int value) {
/* 646 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setLong(CharSequence name, long value) {
/* 651 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setFloat(CharSequence name, float value) {
/* 656 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setDouble(CharSequence name, double value) {
/* 661 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setTimeMillis(CharSequence name, long value) {
/* 666 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers set(Headers<? extends CharSequence, ? extends CharSequence, ?> headers) {
/* 671 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers setAll(Headers<? extends CharSequence, ? extends CharSequence, ?> headers) {
/* 676 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(CharSequence name) {
/* 681 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers clear() {
/* 686 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Map.Entry<CharSequence, CharSequence>> iterator() {
/* 691 */     return new ReadOnlyIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<CharSequence> valueIterator(CharSequence name) {
/* 696 */     return new ReadOnlyValueIterator(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers method(CharSequence value) {
/* 701 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers scheme(CharSequence value) {
/* 706 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers authority(CharSequence value) {
/* 711 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers path(CharSequence value) {
/* 716 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Headers status(CharSequence value) {
/* 721 */     throw new UnsupportedOperationException("read only");
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence method() {
/* 726 */     return get((CharSequence)Http2Headers.PseudoHeaderName.METHOD.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence scheme() {
/* 731 */     return get((CharSequence)Http2Headers.PseudoHeaderName.SCHEME.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence authority() {
/* 736 */     return get((CharSequence)Http2Headers.PseudoHeaderName.AUTHORITY.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence path() {
/* 741 */     return get((CharSequence)Http2Headers.PseudoHeaderName.PATH.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence status() {
/* 746 */     return get((CharSequence)Http2Headers.PseudoHeaderName.STATUS.value());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(CharSequence name, CharSequence value, boolean caseInsensitive) {
/* 751 */     int nameHash = AsciiString.hashCode(name);
/* 752 */     HashingStrategy<CharSequence> strategy = caseInsensitive ? AsciiString.CASE_INSENSITIVE_HASHER : AsciiString.CASE_SENSITIVE_HASHER;
/*     */     
/* 754 */     int valueHash = strategy.hashCode(value);
/*     */     
/* 756 */     return (contains(name, nameHash, value, valueHash, strategy, this.otherHeaders) || 
/* 757 */       contains(name, nameHash, value, valueHash, strategy, this.pseudoHeaders));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean contains(CharSequence name, int nameHash, CharSequence value, int valueHash, HashingStrategy<CharSequence> hashingStrategy, AsciiString[] headers) {
/* 762 */     int headersEnd = headers.length - 1;
/* 763 */     for (int i = 0; i < headersEnd; i += 2) {
/* 764 */       AsciiString roName = headers[i];
/* 765 */       AsciiString roValue = headers[i + 1];
/* 766 */       if (roName.hashCode() == nameHash && roValue.hashCode() == valueHash && roName
/* 767 */         .contentEqualsIgnoreCase(name) && hashingStrategy.equals(roValue, value)) {
/* 768 */         return true;
/*     */       }
/*     */     } 
/* 771 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 776 */     StringBuilder builder = (new StringBuilder(getClass().getSimpleName())).append('[');
/* 777 */     String separator = "";
/* 778 */     for (Map.Entry<CharSequence, CharSequence> entry : (Iterable<Map.Entry<CharSequence, CharSequence>>)this) {
/* 779 */       builder.append(separator);
/* 780 */       builder.append(entry.getKey()).append(": ").append(entry.getValue());
/* 781 */       separator = ", ";
/*     */     } 
/* 783 */     return builder.append(']').toString();
/*     */   }
/*     */   
/*     */   private final class ReadOnlyValueIterator implements Iterator<CharSequence> {
/*     */     private int i;
/*     */     private final int nameHash;
/*     */     private final CharSequence name;
/* 790 */     private AsciiString[] current = (ReadOnlyHttp2Headers.this.pseudoHeaders.length != 0) ? ReadOnlyHttp2Headers.this.pseudoHeaders : ReadOnlyHttp2Headers.this.otherHeaders;
/*     */     private AsciiString next;
/*     */     
/*     */     ReadOnlyValueIterator(CharSequence name) {
/* 794 */       this.nameHash = AsciiString.hashCode(name);
/* 795 */       this.name = name;
/* 796 */       calculateNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 801 */       return (this.next != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence next() {
/* 806 */       if (!hasNext()) {
/* 807 */         throw new NoSuchElementException();
/*     */       }
/* 809 */       AsciiString asciiString = this.next;
/* 810 */       calculateNext();
/* 811 */       return (CharSequence)asciiString;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 816 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */     
/*     */     private void calculateNext() {
/* 820 */       for (; this.i < this.current.length; this.i += 2) {
/* 821 */         AsciiString roName = this.current[this.i];
/* 822 */         if (roName.hashCode() == this.nameHash && roName.contentEqualsIgnoreCase(this.name)) {
/* 823 */           if (this.i + 1 < this.current.length) {
/* 824 */             this.next = this.current[this.i + 1];
/* 825 */             this.i += 2;
/*     */           } 
/*     */           return;
/*     */         } 
/*     */       } 
/* 830 */       if (this.current == ReadOnlyHttp2Headers.this.pseudoHeaders) {
/* 831 */         this.i = 0;
/* 832 */         this.current = ReadOnlyHttp2Headers.this.otherHeaders;
/* 833 */         calculateNext();
/*     */       } else {
/* 835 */         this.next = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private final class ReadOnlyIterator
/*     */     implements Map.Entry<CharSequence, CharSequence>, Iterator<Map.Entry<CharSequence, CharSequence>> {
/*     */     private int i;
/* 843 */     private AsciiString[] current = (ReadOnlyHttp2Headers.this.pseudoHeaders.length != 0) ? ReadOnlyHttp2Headers.this.pseudoHeaders : ReadOnlyHttp2Headers.this.otherHeaders;
/*     */     
/*     */     private AsciiString key;
/*     */     private AsciiString value;
/*     */     
/*     */     public boolean hasNext() {
/* 849 */       return (this.i != this.current.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<CharSequence, CharSequence> next() {
/* 854 */       if (!hasNext()) {
/* 855 */         throw new NoSuchElementException();
/*     */       }
/* 857 */       this.key = this.current[this.i];
/* 858 */       this.value = this.current[this.i + 1];
/* 859 */       this.i += 2;
/* 860 */       if (this.i == this.current.length && this.current == ReadOnlyHttp2Headers.this.pseudoHeaders) {
/* 861 */         this.current = ReadOnlyHttp2Headers.this.otherHeaders;
/* 862 */         this.i = 0;
/*     */       } 
/* 864 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence getKey() {
/* 869 */       return (CharSequence)this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence getValue() {
/* 874 */       return (CharSequence)this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public CharSequence setValue(CharSequence value) {
/* 879 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 884 */       throw new UnsupportedOperationException("read only");
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 889 */       return this.key.toString() + '=' + this.value.toString();
/*     */     }
/*     */     
/*     */     private ReadOnlyIterator() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\ReadOnlyHttp2Headers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */