/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHttp2ConnectionHandlerBuilder<T extends Http2ConnectionHandler, B extends AbstractHttp2ConnectionHandlerBuilder<T, B>>
/*     */ {
/*  78 */   private static final Http2HeadersEncoder.SensitivityDetector DEFAULT_HEADER_SENSITIVITY_DETECTOR = Http2HeadersEncoder.NEVER_SENSITIVE;
/*     */ 
/*     */   
/*  81 */   private Http2Settings initialSettings = Http2Settings.defaultSettings();
/*     */   private Http2FrameListener frameListener;
/*  83 */   private long gracefulShutdownTimeoutMillis = Http2CodecUtil.DEFAULT_GRACEFUL_SHUTDOWN_TIMEOUT_MILLIS;
/*     */   
/*     */   private boolean decoupleCloseAndGoAway;
/*     */   
/*     */   private boolean flushPreface = true;
/*     */   
/*     */   private Boolean isServer;
/*     */   
/*     */   private Integer maxReservedStreams;
/*     */   
/*     */   private Http2Connection connection;
/*     */   
/*     */   private Http2ConnectionDecoder decoder;
/*     */   
/*     */   private Http2ConnectionEncoder encoder;
/*     */   
/*     */   private Boolean validateHeaders;
/*     */   
/*     */   private Http2FrameLogger frameLogger;
/*     */   
/*     */   private Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector;
/*     */   
/*     */   private Boolean encoderEnforceMaxConcurrentStreams;
/*     */   private Boolean encoderIgnoreMaxHeaderListSize;
/* 107 */   private Http2PromisedRequestVerifier promisedRequestVerifier = Http2PromisedRequestVerifier.ALWAYS_VERIFY;
/*     */   private boolean autoAckSettingsFrame = true;
/*     */   private boolean autoAckPingFrame = true;
/* 110 */   private int maxQueuedControlFrames = 10000;
/* 111 */   private int maxConsecutiveEmptyFrames = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2Settings initialSettings() {
/* 117 */     return this.initialSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B initialSettings(Http2Settings settings) {
/* 124 */     this.initialSettings = (Http2Settings)ObjectUtil.checkNotNull(settings, "settings");
/* 125 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2FrameListener frameListener() {
/* 134 */     return this.frameListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B frameListener(Http2FrameListener frameListener) {
/* 142 */     this.frameListener = (Http2FrameListener)ObjectUtil.checkNotNull(frameListener, "frameListener");
/* 143 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long gracefulShutdownTimeoutMillis() {
/* 151 */     return this.gracefulShutdownTimeoutMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B gracefulShutdownTimeoutMillis(long gracefulShutdownTimeoutMillis) {
/* 158 */     if (gracefulShutdownTimeoutMillis < -1L) {
/* 159 */       throw new IllegalArgumentException("gracefulShutdownTimeoutMillis: " + gracefulShutdownTimeoutMillis + " (expected: -1 for indefinite or >= 0)");
/*     */     }
/*     */     
/* 162 */     this.gracefulShutdownTimeoutMillis = gracefulShutdownTimeoutMillis;
/* 163 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isServer() {
/* 171 */     return (this.isServer != null) ? this.isServer.booleanValue() : true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B server(boolean isServer) {
/* 179 */     enforceConstraint("server", "connection", this.connection);
/* 180 */     enforceConstraint("server", "codec", this.decoder);
/* 181 */     enforceConstraint("server", "codec", this.encoder);
/*     */     
/* 183 */     this.isServer = Boolean.valueOf(isServer);
/* 184 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int maxReservedStreams() {
/* 195 */     return (this.maxReservedStreams != null) ? this.maxReservedStreams.intValue() : 100;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B maxReservedStreams(int maxReservedStreams) {
/* 202 */     enforceConstraint("server", "connection", this.connection);
/* 203 */     enforceConstraint("server", "codec", this.decoder);
/* 204 */     enforceConstraint("server", "codec", this.encoder);
/*     */     
/* 206 */     this.maxReservedStreams = Integer.valueOf(ObjectUtil.checkPositiveOrZero(maxReservedStreams, "maxReservedStreams"));
/* 207 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2Connection connection() {
/* 216 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B connection(Http2Connection connection) {
/* 223 */     enforceConstraint("connection", "maxReservedStreams", this.maxReservedStreams);
/* 224 */     enforceConstraint("connection", "server", this.isServer);
/* 225 */     enforceConstraint("connection", "codec", this.decoder);
/* 226 */     enforceConstraint("connection", "codec", this.encoder);
/*     */     
/* 228 */     this.connection = (Http2Connection)ObjectUtil.checkNotNull(connection, "connection");
/*     */     
/* 230 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2ConnectionDecoder decoder() {
/* 239 */     return this.decoder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2ConnectionEncoder encoder() {
/* 248 */     return this.encoder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B codec(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder) {
/* 255 */     enforceConstraint("codec", "server", this.isServer);
/* 256 */     enforceConstraint("codec", "maxReservedStreams", this.maxReservedStreams);
/* 257 */     enforceConstraint("codec", "connection", this.connection);
/* 258 */     enforceConstraint("codec", "frameLogger", this.frameLogger);
/* 259 */     enforceConstraint("codec", "validateHeaders", this.validateHeaders);
/* 260 */     enforceConstraint("codec", "headerSensitivityDetector", this.headerSensitivityDetector);
/* 261 */     enforceConstraint("codec", "encoderEnforceMaxConcurrentStreams", this.encoderEnforceMaxConcurrentStreams);
/*     */     
/* 263 */     ObjectUtil.checkNotNull(decoder, "decoder");
/* 264 */     ObjectUtil.checkNotNull(encoder, "encoder");
/*     */     
/* 266 */     if (decoder.connection() != encoder.connection()) {
/* 267 */       throw new IllegalArgumentException("The specified encoder and decoder have different connections.");
/*     */     }
/*     */     
/* 270 */     this.decoder = decoder;
/* 271 */     this.encoder = encoder;
/*     */     
/* 273 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValidateHeaders() {
/* 281 */     return (this.validateHeaders != null) ? this.validateHeaders.booleanValue() : true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B validateHeaders(boolean validateHeaders) {
/* 289 */     enforceNonCodecConstraints("validateHeaders");
/* 290 */     this.validateHeaders = Boolean.valueOf(validateHeaders);
/* 291 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2FrameLogger frameLogger() {
/* 300 */     return this.frameLogger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B frameLogger(Http2FrameLogger frameLogger) {
/* 307 */     enforceNonCodecConstraints("frameLogger");
/* 308 */     this.frameLogger = (Http2FrameLogger)ObjectUtil.checkNotNull(frameLogger, "frameLogger");
/* 309 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean encoderEnforceMaxConcurrentStreams() {
/* 317 */     return (this.encoderEnforceMaxConcurrentStreams != null) ? this.encoderEnforceMaxConcurrentStreams.booleanValue() : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B encoderEnforceMaxConcurrentStreams(boolean encoderEnforceMaxConcurrentStreams) {
/* 325 */     enforceNonCodecConstraints("encoderEnforceMaxConcurrentStreams");
/* 326 */     this.encoderEnforceMaxConcurrentStreams = Boolean.valueOf(encoderEnforceMaxConcurrentStreams);
/* 327 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int encoderEnforceMaxQueuedControlFrames() {
/* 338 */     return this.maxQueuedControlFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B encoderEnforceMaxQueuedControlFrames(int maxQueuedControlFrames) {
/* 349 */     enforceNonCodecConstraints("encoderEnforceMaxQueuedControlFrames");
/* 350 */     this.maxQueuedControlFrames = ObjectUtil.checkPositiveOrZero(maxQueuedControlFrames, "maxQueuedControlFrames");
/* 351 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector() {
/* 358 */     return (this.headerSensitivityDetector != null) ? this.headerSensitivityDetector : DEFAULT_HEADER_SENSITIVITY_DETECTOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B headerSensitivityDetector(Http2HeadersEncoder.SensitivityDetector headerSensitivityDetector) {
/* 365 */     enforceNonCodecConstraints("headerSensitivityDetector");
/* 366 */     this.headerSensitivityDetector = (Http2HeadersEncoder.SensitivityDetector)ObjectUtil.checkNotNull(headerSensitivityDetector, "headerSensitivityDetector");
/* 367 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B encoderIgnoreMaxHeaderListSize(boolean ignoreMaxHeaderListSize) {
/* 378 */     enforceNonCodecConstraints("encoderIgnoreMaxHeaderListSize");
/* 379 */     this.encoderIgnoreMaxHeaderListSize = Boolean.valueOf(ignoreMaxHeaderListSize);
/* 380 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected B initialHuffmanDecodeCapacity(int initialHuffmanDecodeCapacity) {
/* 390 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B promisedRequestVerifier(Http2PromisedRequestVerifier promisedRequestVerifier) {
/* 398 */     enforceNonCodecConstraints("promisedRequestVerifier");
/* 399 */     this.promisedRequestVerifier = (Http2PromisedRequestVerifier)ObjectUtil.checkNotNull(promisedRequestVerifier, "promisedRequestVerifier");
/* 400 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Http2PromisedRequestVerifier promisedRequestVerifier() {
/* 408 */     return this.promisedRequestVerifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int decoderEnforceMaxConsecutiveEmptyDataFrames() {
/* 419 */     return this.maxConsecutiveEmptyFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B decoderEnforceMaxConsecutiveEmptyDataFrames(int maxConsecutiveEmptyFrames) {
/* 430 */     enforceNonCodecConstraints("maxConsecutiveEmptyFrames");
/* 431 */     this.maxConsecutiveEmptyFrames = ObjectUtil.checkPositiveOrZero(maxConsecutiveEmptyFrames, "maxConsecutiveEmptyFrames");
/*     */     
/* 433 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B autoAckSettingsFrame(boolean autoAckSettings) {
/* 441 */     enforceNonCodecConstraints("autoAckSettingsFrame");
/* 442 */     this.autoAckSettingsFrame = autoAckSettings;
/* 443 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAutoAckSettingsFrame() {
/* 451 */     return this.autoAckSettingsFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B autoAckPingFrame(boolean autoAckPingFrame) {
/* 459 */     enforceNonCodecConstraints("autoAckPingFrame");
/* 460 */     this.autoAckPingFrame = autoAckPingFrame;
/* 461 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAutoAckPingFrame() {
/* 469 */     return this.autoAckPingFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B decoupleCloseAndGoAway(boolean decoupleCloseAndGoAway) {
/* 479 */     this.decoupleCloseAndGoAway = decoupleCloseAndGoAway;
/* 480 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean decoupleCloseAndGoAway() {
/* 487 */     return this.decoupleCloseAndGoAway;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected B flushPreface(boolean flushPreface) {
/* 502 */     this.flushPreface = flushPreface;
/* 503 */     return self();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean flushPreface() {
/* 517 */     return this.flushPreface;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T build() {
/* 524 */     if (this.encoder != null) {
/* 525 */       assert this.decoder != null;
/* 526 */       return buildFromCodec(this.decoder, this.encoder);
/*     */     } 
/*     */     
/* 529 */     Http2Connection connection = this.connection;
/* 530 */     if (connection == null) {
/* 531 */       connection = new DefaultHttp2Connection(isServer(), maxReservedStreams());
/*     */     }
/*     */     
/* 534 */     return buildFromConnection(connection);
/*     */   }
/*     */   
/*     */   private T buildFromConnection(Http2Connection connection) {
/* 538 */     Long maxHeaderListSize = this.initialSettings.maxHeaderListSize();
/*     */     
/* 540 */     Http2FrameReader reader = new DefaultHttp2FrameReader(new DefaultHttp2HeadersDecoder(isValidateHeaders(), (maxHeaderListSize == null) ? 8192L : maxHeaderListSize.longValue(), -1));
/*     */ 
/*     */ 
/*     */     
/* 544 */     Http2FrameWriter writer = (this.encoderIgnoreMaxHeaderListSize == null) ? new DefaultHttp2FrameWriter(headerSensitivityDetector()) : new DefaultHttp2FrameWriter(headerSensitivityDetector(), this.encoderIgnoreMaxHeaderListSize.booleanValue());
/*     */     
/* 546 */     if (this.frameLogger != null) {
/* 547 */       reader = new Http2InboundFrameLogger(reader, this.frameLogger);
/* 548 */       writer = new Http2OutboundFrameLogger(writer, this.frameLogger);
/*     */     } 
/*     */     
/* 551 */     Http2ConnectionEncoder encoder = new DefaultHttp2ConnectionEncoder(connection, writer);
/* 552 */     boolean encoderEnforceMaxConcurrentStreams = encoderEnforceMaxConcurrentStreams();
/*     */     
/* 554 */     if (this.maxQueuedControlFrames != 0) {
/* 555 */       encoder = new Http2ControlFrameLimitEncoder(encoder, this.maxQueuedControlFrames);
/*     */     }
/* 557 */     if (encoderEnforceMaxConcurrentStreams) {
/* 558 */       if (connection.isServer()) {
/* 559 */         encoder.close();
/* 560 */         reader.close();
/* 561 */         throw new IllegalArgumentException("encoderEnforceMaxConcurrentStreams: " + encoderEnforceMaxConcurrentStreams + " not supported for server");
/*     */       } 
/*     */ 
/*     */       
/* 565 */       encoder = new StreamBufferingEncoder(encoder);
/*     */     } 
/*     */ 
/*     */     
/* 569 */     DefaultHttp2ConnectionDecoder decoder = new DefaultHttp2ConnectionDecoder(connection, encoder, reader, promisedRequestVerifier(), isAutoAckSettingsFrame(), isAutoAckPingFrame());
/* 570 */     return buildFromCodec(decoder, encoder);
/*     */   }
/*     */   private T buildFromCodec(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder) {
/*     */     T handler;
/* 574 */     int maxConsecutiveEmptyDataFrames = decoderEnforceMaxConsecutiveEmptyDataFrames();
/* 575 */     if (maxConsecutiveEmptyDataFrames > 0) {
/* 576 */       decoder = new Http2EmptyDataFrameConnectionDecoder(decoder, maxConsecutiveEmptyDataFrames);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 581 */       handler = build(decoder, encoder, this.initialSettings);
/* 582 */     } catch (Throwable t) {
/* 583 */       encoder.close();
/* 584 */       decoder.close();
/* 585 */       throw new IllegalStateException("failed to build an Http2ConnectionHandler", t);
/*     */     } 
/*     */ 
/*     */     
/* 589 */     handler.gracefulShutdownTimeoutMillis(this.gracefulShutdownTimeoutMillis);
/* 590 */     if (handler.decoder().frameListener() == null) {
/* 591 */       handler.decoder().frameListener(this.frameListener);
/*     */     }
/* 593 */     return handler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T build(Http2ConnectionDecoder paramHttp2ConnectionDecoder, Http2ConnectionEncoder paramHttp2ConnectionEncoder, Http2Settings paramHttp2Settings) throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final B self() {
/* 613 */     return (B)this;
/*     */   }
/*     */   
/*     */   private void enforceNonCodecConstraints(String rejected) {
/* 617 */     enforceConstraint(rejected, "server/connection", this.decoder);
/* 618 */     enforceConstraint(rejected, "server/connection", this.encoder);
/*     */   }
/*     */   
/*     */   private static void enforceConstraint(String methodName, String rejectorName, Object value) {
/* 622 */     if (value != null)
/* 623 */       throw new IllegalStateException(methodName + "() cannot be called because " + rejectorName + "() has been called already."); 
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\AbstractHttp2ConnectionHandlerBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */