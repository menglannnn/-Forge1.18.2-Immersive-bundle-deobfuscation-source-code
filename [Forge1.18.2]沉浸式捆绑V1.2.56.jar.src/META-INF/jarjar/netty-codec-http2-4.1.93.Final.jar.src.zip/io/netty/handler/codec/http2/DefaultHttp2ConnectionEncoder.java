/*     */ package io.netty.handler.codec.http2;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.AbstractCoalescingBufferQueue;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelFutureListener;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.channel.CoalescingBufferQueue;
/*     */ import io.netty.handler.codec.http.HttpStatusClass;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import io.netty.util.internal.ObjectUtil;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttp2ConnectionEncoder
/*     */   implements Http2ConnectionEncoder, Http2SettingsReceivedConsumer
/*     */ {
/*     */   private final Http2FrameWriter frameWriter;
/*     */   private final Http2Connection connection;
/*     */   private Http2LifecycleManager lifecycleManager;
/*  49 */   private final Queue<Http2Settings> outstandingLocalSettingsQueue = new ArrayDeque<Http2Settings>(4);
/*     */   private Queue<Http2Settings> outstandingRemoteSettingsQueue;
/*     */   
/*     */   public DefaultHttp2ConnectionEncoder(Http2Connection connection, Http2FrameWriter frameWriter) {
/*  53 */     this.connection = (Http2Connection)ObjectUtil.checkNotNull(connection, "connection");
/*  54 */     this.frameWriter = (Http2FrameWriter)ObjectUtil.checkNotNull(frameWriter, "frameWriter");
/*  55 */     if (connection.remote().flowController() == null) {
/*  56 */       connection.remote().flowController(new DefaultHttp2RemoteFlowController(connection));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void lifecycleManager(Http2LifecycleManager lifecycleManager) {
/*  62 */     this.lifecycleManager = (Http2LifecycleManager)ObjectUtil.checkNotNull(lifecycleManager, "lifecycleManager");
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameWriter frameWriter() {
/*  67 */     return this.frameWriter;
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Connection connection() {
/*  72 */     return this.connection;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Http2RemoteFlowController flowController() {
/*  77 */     return connection().remote().flowController();
/*     */   }
/*     */ 
/*     */   
/*     */   public void remoteSettings(Http2Settings settings) throws Http2Exception {
/*  82 */     Boolean pushEnabled = settings.pushEnabled();
/*  83 */     Http2FrameWriter.Configuration config = configuration();
/*  84 */     Http2HeadersEncoder.Configuration outboundHeaderConfig = config.headersConfiguration();
/*  85 */     Http2FrameSizePolicy outboundFrameSizePolicy = config.frameSizePolicy();
/*  86 */     if (pushEnabled != null) {
/*  87 */       if (!this.connection.isServer() && pushEnabled.booleanValue()) {
/*  88 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Client received a value of ENABLE_PUSH specified to other than 0", new Object[0]);
/*     */       }
/*     */       
/*  91 */       this.connection.remote().allowPushTo(pushEnabled.booleanValue());
/*     */     } 
/*     */     
/*  94 */     Long maxConcurrentStreams = settings.maxConcurrentStreams();
/*  95 */     if (maxConcurrentStreams != null) {
/*  96 */       this.connection.local().maxActiveStreams((int)Math.min(maxConcurrentStreams.longValue(), 2147483647L));
/*     */     }
/*     */     
/*  99 */     Long headerTableSize = settings.headerTableSize();
/* 100 */     if (headerTableSize != null) {
/* 101 */       outboundHeaderConfig.maxHeaderTableSize(headerTableSize.longValue());
/*     */     }
/*     */     
/* 104 */     Long maxHeaderListSize = settings.maxHeaderListSize();
/* 105 */     if (maxHeaderListSize != null) {
/* 106 */       outboundHeaderConfig.maxHeaderListSize(maxHeaderListSize.longValue());
/*     */     }
/*     */     
/* 109 */     Integer maxFrameSize = settings.maxFrameSize();
/* 110 */     if (maxFrameSize != null) {
/* 111 */       outboundFrameSizePolicy.maxFrameSize(maxFrameSize.intValue());
/*     */     }
/*     */     
/* 114 */     Integer initialWindowSize = settings.initialWindowSize();
/* 115 */     if (initialWindowSize != null) {
/* 116 */       flowController().initialWindowSize(initialWindowSize.intValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeData(ChannelHandlerContext ctx, int streamId, ByteBuf data, int padding, boolean endOfStream, ChannelPromise promise) {
/* 123 */     promise = promise.unvoid();
/*     */     
/*     */     try {
/* 126 */       Http2Stream stream = requireStream(streamId);
/*     */ 
/*     */       
/* 129 */       switch (stream.state()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case OPEN:
/*     */         case HALF_CLOSED_REMOTE:
/* 143 */           flowController().addFlowControlled(stream, new FlowControlledData(stream, data, padding, endOfStream, promise));
/*     */           
/* 145 */           return (ChannelFuture)promise;
/*     */       } 
/*     */       throw new IllegalStateException("Stream " + stream.id() + " in unexpected state " + stream.state());
/*     */     } catch (Throwable e) {
/*     */       data.release();
/*     */       return (ChannelFuture)promise.setFailure(e);
/* 151 */     }  } public ChannelFuture writeHeaders(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int padding, boolean endStream, ChannelPromise promise) { return writeHeaders0(ctx, streamId, headers, false, 0, (short)0, false, padding, endStream, promise); }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean validateHeadersSentState(Http2Stream stream, Http2Headers headers, boolean isServer, boolean endOfStream) {
/* 156 */     boolean isInformational = (isServer && HttpStatusClass.valueOf(headers.status()) == HttpStatusClass.INFORMATIONAL);
/* 157 */     if (((isInformational || !endOfStream) && stream.isHeadersSent()) || stream.isTrailersSent()) {
/* 158 */       throw new IllegalStateException("Stream " + stream.id() + " sent too many headers EOS: " + endOfStream);
/*     */     }
/* 160 */     return isInformational;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeHeaders(ChannelHandlerContext ctx, int streamId, Http2Headers headers, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream, ChannelPromise promise) {
/* 167 */     return writeHeaders0(ctx, streamId, headers, true, streamDependency, weight, exclusive, padding, endOfStream, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ChannelFuture sendHeaders(Http2FrameWriter frameWriter, ChannelHandlerContext ctx, int streamId, Http2Headers headers, boolean hasPriority, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream, ChannelPromise promise) {
/* 180 */     if (hasPriority) {
/* 181 */       return frameWriter.writeHeaders(ctx, streamId, headers, streamDependency, weight, exclusive, padding, endOfStream, promise);
/*     */     }
/*     */     
/* 184 */     return frameWriter.writeHeaders(ctx, streamId, headers, padding, endOfStream, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChannelFuture writeHeaders0(ChannelHandlerContext ctx, int streamId, Http2Headers headers, boolean hasPriority, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream, ChannelPromise promise) {
/*     */     try {
/* 193 */       Http2Stream stream = this.connection.stream(streamId);
/* 194 */       if (stream == null) {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */           
/* 201 */           stream = this.connection.local().createStream(streamId, false);
/* 202 */         } catch (Http2Exception cause) {
/* 203 */           if (this.connection.remote().mayHaveCreatedStream(streamId)) {
/* 204 */             promise.tryFailure(new IllegalStateException("Stream no longer exists: " + streamId, cause));
/* 205 */             return (ChannelFuture)promise;
/*     */           } 
/* 207 */           throw cause;
/*     */         } 
/*     */       } else {
/* 210 */         switch (stream.state()) {
/*     */           case RESERVED_LOCAL:
/* 212 */             stream.open(endOfStream);
/*     */             break;
/*     */           
/*     */           case OPEN:
/*     */           case HALF_CLOSED_REMOTE:
/*     */             break;
/*     */           default:
/* 219 */             throw new IllegalStateException("Stream " + stream.id() + " in unexpected state " + stream
/* 220 */                 .state());
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 226 */       Http2RemoteFlowController flowController = flowController();
/* 227 */       if (!endOfStream || !flowController.hasFlowControlled(stream)) {
/*     */ 
/*     */         
/* 230 */         promise = promise.unvoid();
/* 231 */         boolean isInformational = validateHeadersSentState(stream, headers, this.connection.isServer(), endOfStream);
/*     */         
/* 233 */         ChannelFuture future = sendHeaders(this.frameWriter, ctx, streamId, headers, hasPriority, streamDependency, weight, exclusive, padding, endOfStream, promise);
/*     */ 
/*     */ 
/*     */         
/* 237 */         Throwable failureCause = future.cause();
/* 238 */         if (failureCause == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 244 */           stream.headersSent(isInformational);
/*     */           
/* 246 */           if (!future.isSuccess())
/*     */           {
/* 248 */             notifyLifecycleManagerOnError(future, ctx);
/*     */           }
/*     */         } else {
/* 251 */           this.lifecycleManager.onError(ctx, true, failureCause);
/*     */         } 
/*     */         
/* 254 */         if (endOfStream)
/*     */         {
/*     */ 
/*     */           
/* 258 */           this.lifecycleManager.closeStreamLocal(stream, future);
/*     */         }
/*     */         
/* 261 */         return future;
/*     */       } 
/*     */       
/* 264 */       flowController.addFlowControlled(stream, new FlowControlledHeaders(stream, headers, hasPriority, streamDependency, weight, exclusive, padding, true, promise));
/*     */ 
/*     */       
/* 267 */       return (ChannelFuture)promise;
/*     */     }
/* 269 */     catch (Throwable t) {
/* 270 */       this.lifecycleManager.onError(ctx, true, t);
/* 271 */       promise.tryFailure(t);
/* 272 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writePriority(ChannelHandlerContext ctx, int streamId, int streamDependency, short weight, boolean exclusive, ChannelPromise promise) {
/* 279 */     return this.frameWriter.writePriority(ctx, streamId, streamDependency, weight, exclusive, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeRstStream(ChannelHandlerContext ctx, int streamId, long errorCode, ChannelPromise promise) {
/* 286 */     return this.lifecycleManager.resetStream(ctx, streamId, errorCode, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeSettings(ChannelHandlerContext ctx, Http2Settings settings, ChannelPromise promise) {
/* 292 */     this.outstandingLocalSettingsQueue.add(settings);
/*     */     try {
/* 294 */       Boolean pushEnabled = settings.pushEnabled();
/* 295 */       if (pushEnabled != null && this.connection.isServer()) {
/* 296 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Server sending SETTINGS frame with ENABLE_PUSH specified", new Object[0]);
/*     */       }
/* 298 */     } catch (Throwable e) {
/* 299 */       return (ChannelFuture)promise.setFailure(e);
/*     */     } 
/*     */     
/* 302 */     return this.frameWriter.writeSettings(ctx, settings, promise);
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture writeSettingsAck(ChannelHandlerContext ctx, ChannelPromise promise) {
/* 307 */     if (this.outstandingRemoteSettingsQueue == null) {
/* 308 */       return this.frameWriter.writeSettingsAck(ctx, promise);
/*     */     }
/* 310 */     Http2Settings settings = this.outstandingRemoteSettingsQueue.poll();
/* 311 */     if (settings == null) {
/* 312 */       return (ChannelFuture)promise.setFailure(new Http2Exception(Http2Error.INTERNAL_ERROR, "attempted to write a SETTINGS ACK with no  pending SETTINGS"));
/*     */     }
/*     */ 
/*     */     
/* 316 */     Http2CodecUtil.SimpleChannelPromiseAggregator aggregator = new Http2CodecUtil.SimpleChannelPromiseAggregator(promise, ctx.channel(), ctx.executor());
/*     */ 
/*     */ 
/*     */     
/* 320 */     this.frameWriter.writeSettingsAck(ctx, aggregator.newPromise());
/*     */ 
/*     */ 
/*     */     
/* 324 */     ChannelPromise applySettingsPromise = aggregator.newPromise();
/*     */     try {
/* 326 */       remoteSettings(settings);
/* 327 */       applySettingsPromise.setSuccess();
/* 328 */     } catch (Throwable e) {
/* 329 */       applySettingsPromise.setFailure(e);
/* 330 */       this.lifecycleManager.onError(ctx, true, e);
/*     */     } 
/* 332 */     return (ChannelFuture)aggregator.doneAllocatingPromises();
/*     */   }
/*     */ 
/*     */   
/*     */   public ChannelFuture writePing(ChannelHandlerContext ctx, boolean ack, long data, ChannelPromise promise) {
/* 337 */     return this.frameWriter.writePing(ctx, ack, data, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writePushPromise(ChannelHandlerContext ctx, int streamId, int promisedStreamId, Http2Headers headers, int padding, ChannelPromise promise) {
/*     */     try {
/* 344 */       if (this.connection.goAwayReceived()) {
/* 345 */         throw Http2Exception.connectionError(Http2Error.PROTOCOL_ERROR, "Sending PUSH_PROMISE after GO_AWAY received.", new Object[0]);
/*     */       }
/*     */       
/* 348 */       Http2Stream stream = requireStream(streamId);
/*     */       
/* 350 */       this.connection.local().reservePushStream(promisedStreamId, stream);
/*     */       
/* 352 */       promise = promise.unvoid();
/* 353 */       ChannelFuture future = this.frameWriter.writePushPromise(ctx, streamId, promisedStreamId, headers, padding, promise);
/*     */ 
/*     */       
/* 356 */       Throwable failureCause = future.cause();
/* 357 */       if (failureCause == null) {
/*     */ 
/*     */         
/* 360 */         stream.pushPromiseSent();
/*     */         
/* 362 */         if (!future.isSuccess())
/*     */         {
/* 364 */           notifyLifecycleManagerOnError(future, ctx);
/*     */         }
/*     */       } else {
/* 367 */         this.lifecycleManager.onError(ctx, true, failureCause);
/*     */       } 
/* 369 */       return future;
/* 370 */     } catch (Throwable t) {
/* 371 */       this.lifecycleManager.onError(ctx, true, t);
/* 372 */       promise.tryFailure(t);
/* 373 */       return (ChannelFuture)promise;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeGoAway(ChannelHandlerContext ctx, int lastStreamId, long errorCode, ByteBuf debugData, ChannelPromise promise) {
/* 380 */     return this.lifecycleManager.goAway(ctx, lastStreamId, errorCode, debugData, promise);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeWindowUpdate(ChannelHandlerContext ctx, int streamId, int windowSizeIncrement, ChannelPromise promise) {
/* 386 */     return (ChannelFuture)promise.setFailure(new UnsupportedOperationException("Use the Http2[Inbound|Outbound]FlowController objects to control window sizes"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelFuture writeFrame(ChannelHandlerContext ctx, byte frameType, int streamId, Http2Flags flags, ByteBuf payload, ChannelPromise promise) {
/* 393 */     return this.frameWriter.writeFrame(ctx, frameType, streamId, flags, payload, promise);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 398 */     this.frameWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2Settings pollSentSettings() {
/* 403 */     return this.outstandingLocalSettingsQueue.poll();
/*     */   }
/*     */ 
/*     */   
/*     */   public Http2FrameWriter.Configuration configuration() {
/* 408 */     return this.frameWriter.configuration();
/*     */   }
/*     */   
/*     */   private Http2Stream requireStream(int streamId) {
/* 412 */     Http2Stream stream = this.connection.stream(streamId);
/* 413 */     if (stream == null) {
/*     */       String message;
/* 415 */       if (this.connection.streamMayHaveExisted(streamId)) {
/* 416 */         message = "Stream no longer exists: " + streamId;
/*     */       } else {
/* 418 */         message = "Stream does not exist: " + streamId;
/*     */       } 
/* 420 */       throw new IllegalArgumentException(message);
/*     */     } 
/* 422 */     return stream;
/*     */   }
/*     */ 
/*     */   
/*     */   public void consumeReceivedSettings(Http2Settings settings) {
/* 427 */     if (this.outstandingRemoteSettingsQueue == null) {
/* 428 */       this.outstandingRemoteSettingsQueue = new ArrayDeque<Http2Settings>(2);
/*     */     }
/* 430 */     this.outstandingRemoteSettingsQueue.add(settings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class FlowControlledData
/*     */     extends FlowControlledBase
/*     */   {
/*     */     private final CoalescingBufferQueue queue;
/*     */ 
/*     */ 
/*     */     
/*     */     private int dataSize;
/*     */ 
/*     */ 
/*     */     
/*     */     FlowControlledData(Http2Stream stream, ByteBuf buf, int padding, boolean endOfStream, ChannelPromise promise) {
/* 448 */       super(stream, padding, endOfStream, promise);
/* 449 */       this.queue = new CoalescingBufferQueue(promise.channel());
/* 450 */       this.queue.add(buf, promise);
/* 451 */       this.dataSize = this.queue.readableBytes();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 456 */       return this.dataSize + this.padding;
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(ChannelHandlerContext ctx, Throwable cause) {
/* 461 */       this.queue.releaseAndFailAll(cause);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 467 */       DefaultHttp2ConnectionEncoder.this.lifecycleManager.onError(ctx, true, cause);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(ChannelHandlerContext ctx, int allowedBytes) {
/* 472 */       int queuedData = this.queue.readableBytes();
/* 473 */       if (!this.endOfStream) {
/* 474 */         if (queuedData == 0) {
/* 475 */           if (this.queue.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 482 */             this.padding = this.dataSize = 0;
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 487 */             ChannelPromise channelPromise = ctx.newPromise().addListener((GenericFutureListener)this);
/* 488 */             ctx.write(this.queue.remove(0, channelPromise), channelPromise);
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/* 493 */         if (allowedBytes == 0) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 499 */       int writableData = Math.min(queuedData, allowedBytes);
/* 500 */       ChannelPromise writePromise = ctx.newPromise().addListener((GenericFutureListener)this);
/* 501 */       ByteBuf toWrite = this.queue.remove(writableData, writePromise);
/* 502 */       this.dataSize = this.queue.readableBytes();
/*     */ 
/*     */       
/* 505 */       int writablePadding = Math.min(allowedBytes - writableData, this.padding);
/* 506 */       this.padding -= writablePadding;
/*     */ 
/*     */       
/* 509 */       DefaultHttp2ConnectionEncoder.this.frameWriter().writeData(ctx, this.stream.id(), toWrite, writablePadding, (this.endOfStream && 
/* 510 */           size() == 0), writePromise);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean merge(ChannelHandlerContext ctx, Http2RemoteFlowController.FlowControlled next) {
/*     */       FlowControlledData nextData;
/* 516 */       if (FlowControlledData.class != next.getClass() || Integer.MAX_VALUE - (nextData = (FlowControlledData)next)
/* 517 */         .size() < size()) {
/* 518 */         return false;
/*     */       }
/* 520 */       nextData.queue.copyTo((AbstractCoalescingBufferQueue)this.queue);
/* 521 */       this.dataSize = this.queue.readableBytes();
/*     */       
/* 523 */       this.padding = Math.max(this.padding, nextData.padding);
/* 524 */       this.endOfStream = nextData.endOfStream;
/* 525 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyLifecycleManagerOnError(ChannelFuture future, final ChannelHandlerContext ctx) {
/* 530 */     future.addListener((GenericFutureListener)new ChannelFutureListener()
/*     */         {
/*     */           public void operationComplete(ChannelFuture future) throws Exception {
/* 533 */             Throwable cause = future.cause();
/* 534 */             if (cause != null) {
/* 535 */               DefaultHttp2ConnectionEncoder.this.lifecycleManager.onError(ctx, true, cause);
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private final class FlowControlledHeaders
/*     */     extends FlowControlledBase
/*     */   {
/*     */     private final Http2Headers headers;
/*     */     
/*     */     private final boolean hasPriority;
/*     */     
/*     */     private final int streamDependency;
/*     */     
/*     */     private final short weight;
/*     */     
/*     */     private final boolean exclusive;
/*     */     
/*     */     FlowControlledHeaders(Http2Stream stream, Http2Headers headers, boolean hasPriority, int streamDependency, short weight, boolean exclusive, int padding, boolean endOfStream, ChannelPromise promise) {
/* 556 */       super(stream, padding, endOfStream, promise.unvoid());
/* 557 */       this.headers = headers;
/* 558 */       this.hasPriority = hasPriority;
/* 559 */       this.streamDependency = streamDependency;
/* 560 */       this.weight = weight;
/* 561 */       this.exclusive = exclusive;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 566 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(ChannelHandlerContext ctx, Throwable cause) {
/* 571 */       if (ctx != null) {
/* 572 */         DefaultHttp2ConnectionEncoder.this.lifecycleManager.onError(ctx, true, cause);
/*     */       }
/* 574 */       this.promise.tryFailure(cause);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(ChannelHandlerContext ctx, int allowedBytes) {
/* 579 */       boolean isInformational = DefaultHttp2ConnectionEncoder.validateHeadersSentState(this.stream, this.headers, DefaultHttp2ConnectionEncoder.this.connection.isServer(), this.endOfStream);
/*     */ 
/*     */       
/* 582 */       this.promise.addListener((GenericFutureListener)this);
/*     */       
/* 584 */       ChannelFuture f = DefaultHttp2ConnectionEncoder.sendHeaders(DefaultHttp2ConnectionEncoder.this.frameWriter, ctx, this.stream.id(), this.headers, this.hasPriority, this.streamDependency, this.weight, this.exclusive, this.padding, this.endOfStream, this.promise);
/*     */ 
/*     */       
/* 587 */       Throwable failureCause = f.cause();
/* 588 */       if (failureCause == null)
/*     */       {
/*     */         
/* 591 */         this.stream.headersSent(isInformational);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean merge(ChannelHandlerContext ctx, Http2RemoteFlowController.FlowControlled next) {
/* 597 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract class FlowControlledBase
/*     */     implements Http2RemoteFlowController.FlowControlled, ChannelFutureListener
/*     */   {
/*     */     protected final Http2Stream stream;
/*     */     
/*     */     protected ChannelPromise promise;
/*     */     
/*     */     protected boolean endOfStream;
/*     */     protected int padding;
/*     */     
/*     */     FlowControlledBase(Http2Stream stream, int padding, boolean endOfStream, ChannelPromise promise) {
/* 613 */       ObjectUtil.checkPositiveOrZero(padding, "padding");
/* 614 */       this.padding = padding;
/* 615 */       this.endOfStream = endOfStream;
/* 616 */       this.stream = stream;
/* 617 */       this.promise = promise;
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeComplete() {
/* 622 */       if (this.endOfStream) {
/* 623 */         DefaultHttp2ConnectionEncoder.this.lifecycleManager.closeStreamLocal(this.stream, (ChannelFuture)this.promise);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void operationComplete(ChannelFuture future) throws Exception {
/* 629 */       if (!future.isSuccess())
/* 630 */         error(DefaultHttp2ConnectionEncoder.this.flowController().channelHandlerContext(), future.cause()); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\netty-codec-http2-4.1.93.Final.jar!\io\netty\handler\codec\http2\DefaultHttp2ConnectionEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */