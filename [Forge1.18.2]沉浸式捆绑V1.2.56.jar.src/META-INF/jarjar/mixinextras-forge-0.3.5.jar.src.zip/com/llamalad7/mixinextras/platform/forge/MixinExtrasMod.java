/*    */ package com.llamalad7.mixinextras.platform.forge;
/*    */ import net.minecraftforge.fml.IExtensionPoint;
/*    */ import net.minecraftforge.fml.ModContainer;
/*    */ import net.minecraftforge.fml.ModList;
/*    */ import net.minecraftforge.fml.ModLoadingContext;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import org.apache.maven.artifact.versioning.ArtifactVersion;
/*    */ import org.apache.maven.artifact.versioning.DefaultArtifactVersion;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ @Mod("mixinextras")
/*    */ public class MixinExtrasMod {
/* 14 */   private static final Logger LOGGER = LoggerFactory.getLogger("MixinExtras|Forge");
/*    */   private static final String IGNORESERVERONLY = "OHNOES😱😱😱😱😱😱😱😱😱😱😱😱😱😱😱😱😱";
/*    */   
/*    */   public MixinExtrasMod() {
/* 18 */     ArtifactVersion version = getForgeVersion();
/* 19 */     if (version == null) {
/*    */       return;
/*    */     }
/* 22 */     if (version.compareTo(new DefaultArtifactVersion("41.1.0")) < 0)
/*    */     {
/* 24 */       markAsOneSided();
/*    */     }
/*    */   }
/*    */   
/*    */   private ArtifactVersion getForgeVersion() {
/* 29 */     return ModList.get().getModContainerById("forge").map(it -> it.getModInfo().getVersion()).orElse(null);
/*    */   }
/*    */   
/*    */   private void markAsOneSided() {
/*    */     try {
/* 34 */       ModLoadingContext.get().registerExtensionPoint(IExtensionPoint.DisplayTest.class, () -> new IExtensionPoint.DisplayTest((), ()));
/* 35 */     } catch (Exception e) {
/*    */       
/* 37 */       LOGGER.warn("Failed to mark MixinExtras as a one-sided mod", e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\mixinextras-forge-0.3.5.jar!\com\llamalad7\mixinextras\platform\forge\MixinExtrasMod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */