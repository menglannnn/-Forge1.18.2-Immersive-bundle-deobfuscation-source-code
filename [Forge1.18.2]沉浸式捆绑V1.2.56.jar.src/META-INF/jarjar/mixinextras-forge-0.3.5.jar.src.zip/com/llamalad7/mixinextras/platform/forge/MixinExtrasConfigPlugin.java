/*    */ package com.llamalad7.mixinextras.platform.forge;
/*    */ 
/*    */ import com.llamalad7.mixinextras.MixinExtrasBootstrap;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
/*    */ 
/*    */ public class MixinExtrasConfigPlugin
/*    */   implements IMixinConfigPlugin
/*    */ {
/*    */   public void onLoad(String mixinPackage) {
/* 14 */     MixinExtrasBootstrap.init();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getRefMapperConfig() {
/* 19 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
/* 24 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}
/*    */ 
/*    */   
/*    */   public List<String> getMixins() {
/* 33 */     return null;
/*    */   }
/*    */   
/*    */   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */   
/*    */   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\mixinextras-forge-0.3.5.jar!\com\llamalad7\mixinextras\platform\forge\MixinExtrasConfigPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */