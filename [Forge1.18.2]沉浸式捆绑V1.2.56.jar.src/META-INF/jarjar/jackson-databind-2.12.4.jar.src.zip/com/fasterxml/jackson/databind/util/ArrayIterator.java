/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayIterator<T>
/*    */   implements Iterator<T>, Iterable<T>
/*    */ {
/*    */   private final T[] _a;
/*    */   private int _index;
/*    */   
/*    */   public ArrayIterator(T[] a) {
/* 18 */     this._a = a;
/* 19 */     this._index = 0;
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 23 */     return (this._index < this._a.length);
/*    */   }
/*    */   
/*    */   public T next() {
/* 27 */     if (this._index >= this._a.length) {
/* 28 */       throw new NoSuchElementException();
/*    */     }
/* 30 */     return this._a[this._index++];
/*    */   }
/*    */   
/* 33 */   public void remove() { throw new UnsupportedOperationException(); } public Iterator<T> iterator() {
/* 34 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databin\\util\ArrayIterator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */