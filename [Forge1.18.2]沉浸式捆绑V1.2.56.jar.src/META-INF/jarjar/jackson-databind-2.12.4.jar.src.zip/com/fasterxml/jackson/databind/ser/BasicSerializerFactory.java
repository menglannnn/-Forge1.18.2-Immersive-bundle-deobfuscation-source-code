/*      */ package com.fasterxml.jackson.databind.ser;
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.JsonSerializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.SerializationConfig;
/*      */ import com.fasterxml.jackson.databind.SerializationFeature;
/*      */ import com.fasterxml.jackson.databind.SerializerProvider;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.IndexedStringListSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.MapEntrySerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.StringArraySerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.StringCollectionSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.AtomicReferenceSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.BooleanSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.CalendarSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.DateSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.EnumSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.JsonValueSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.MapSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.NumberSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.StdKeySerializers;
/*      */ import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
/*      */ import com.fasterxml.jackson.databind.type.ArrayType;
/*      */ import com.fasterxml.jackson.databind.type.CollectionLikeType;
/*      */ import com.fasterxml.jackson.databind.type.CollectionType;
/*      */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*      */ import com.fasterxml.jackson.databind.type.MapType;
/*      */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.BeanUtil;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.Converter;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ public abstract class BasicSerializerFactory extends SerializerFactory implements Serializable {
/*      */   static {
/*   63 */     HashMap<String, Class<? extends JsonSerializer<?>>> concLazy = new HashMap<>();
/*      */     
/*   65 */     HashMap<String, JsonSerializer<?>> concrete = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   72 */     concrete.put(String.class.getName(), new StringSerializer());
/*   73 */     ToStringSerializer sls = ToStringSerializer.instance;
/*   74 */     concrete.put(StringBuffer.class.getName(), sls);
/*   75 */     concrete.put(StringBuilder.class.getName(), sls);
/*   76 */     concrete.put(Character.class.getName(), sls);
/*   77 */     concrete.put(char.class.getName(), sls);
/*      */ 
/*      */     
/*   80 */     NumberSerializers.addAll(concrete);
/*   81 */     concrete.put(boolean.class.getName(), new BooleanSerializer(true));
/*   82 */     concrete.put(Boolean.class.getName(), new BooleanSerializer(false));
/*      */ 
/*      */     
/*   85 */     concrete.put(BigInteger.class.getName(), new NumberSerializer(BigInteger.class));
/*   86 */     concrete.put(BigDecimal.class.getName(), new NumberSerializer(BigDecimal.class));
/*      */ 
/*      */ 
/*      */     
/*   90 */     concrete.put(Calendar.class.getName(), CalendarSerializer.instance);
/*   91 */     concrete.put(Date.class.getName(), DateSerializer.instance);
/*      */ 
/*      */     
/*   94 */     for (Map.Entry<Class<?>, Object> en : (Iterable<Map.Entry<Class<?>, Object>>)StdJdkSerializers.all()) {
/*   95 */       Object value = en.getValue();
/*   96 */       if (value instanceof JsonSerializer) {
/*   97 */         concrete.put(((Class)en.getKey()).getName(), (JsonSerializer)value);
/*      */         continue;
/*      */       } 
/*  100 */       Class<? extends JsonSerializer<?>> cls = (Class<? extends JsonSerializer<?>>)value;
/*  101 */       concLazy.put(((Class)en.getKey()).getName(), cls);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  107 */     concLazy.put(TokenBuffer.class.getName(), TokenBufferSerializer.class);
/*      */     
/*  109 */     _concrete = concrete;
/*  110 */     _concreteLazy = concLazy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final HashMap<String, JsonSerializer<?>> _concrete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final HashMap<String, Class<? extends JsonSerializer<?>>> _concreteLazy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializerFactoryConfig _factoryConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BasicSerializerFactory(SerializerFactoryConfig config) {
/*  137 */     this._factoryConfig = (config == null) ? new SerializerFactoryConfig() : config;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerFactoryConfig getFactoryConfig() {
/*  148 */     return this._factoryConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SerializerFactory withAdditionalSerializers(Serializers additional) {
/*  169 */     return withConfig(this._factoryConfig.withAdditionalSerializers(additional));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SerializerFactory withAdditionalKeySerializers(Serializers additional) {
/*  178 */     return withConfig(this._factoryConfig.withAdditionalKeySerializers(additional));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SerializerFactory withSerializerModifier(BeanSerializerModifier modifier) {
/*  187 */     return withConfig(this._factoryConfig.withSerializerModifier(modifier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> createKeySerializer(SerializerProvider ctxt, JavaType keyType, JsonSerializer<Object> defaultImpl) throws JsonMappingException {
/*  209 */     SerializationConfig config = ctxt.getConfig();
/*  210 */     BeanDescription beanDesc = config.introspect(keyType);
/*  211 */     JsonSerializer<?> ser = null;
/*      */     
/*  213 */     if (this._factoryConfig.hasKeySerializers())
/*      */     {
/*  215 */       for (Serializers serializers : this._factoryConfig.keySerializers()) {
/*  216 */         ser = serializers.findSerializer(config, keyType, beanDesc);
/*  217 */         if (ser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*  222 */     if (ser == null) {
/*      */       
/*  224 */       ser = _findKeySerializer(ctxt, (Annotated)beanDesc.getClassInfo());
/*  225 */       if (ser == null) {
/*      */ 
/*      */ 
/*      */         
/*  229 */         ser = defaultImpl;
/*  230 */         if (ser == null) {
/*      */ 
/*      */           
/*  233 */           ser = StdKeySerializers.getStdKeySerializer(config, keyType.getRawClass(), false);
/*  234 */           if (ser == null) {
/*  235 */             AnnotatedMember acc = beanDesc.findJsonKeyAccessor();
/*  236 */             if (acc == null)
/*      */             {
/*  238 */               acc = beanDesc.findJsonValueAccessor();
/*      */             }
/*  240 */             if (acc != null) {
/*  241 */               JsonSerializer<?> delegate = createKeySerializer(ctxt, acc.getType(), defaultImpl);
/*  242 */               if (config.canOverrideAccessModifiers()) {
/*  243 */                 ClassUtil.checkAndFixAccess(acc.getMember(), config
/*  244 */                     .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */               }
/*      */               
/*  247 */               JsonValueSerializer jsonValueSerializer = new JsonValueSerializer(acc, null, delegate);
/*      */             } else {
/*  249 */               ser = StdKeySerializers.getFallbackKeySerializer(config, keyType.getRawClass());
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  257 */     if (this._factoryConfig.hasSerializerModifiers()) {
/*  258 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  259 */         ser = mod.modifyKeySerializer(config, keyType, beanDesc, ser);
/*      */       }
/*      */     }
/*  262 */     return (JsonSerializer)ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonSerializer<Object> createKeySerializer(SerializationConfig config, JavaType keyType, JsonSerializer<Object> defaultImpl) {
/*  271 */     BeanDescription beanDesc = config.introspect(keyType);
/*  272 */     JsonSerializer<?> ser = null;
/*  273 */     if (this._factoryConfig.hasKeySerializers()) {
/*  274 */       for (Serializers serializers : this._factoryConfig.keySerializers()) {
/*  275 */         ser = serializers.findSerializer(config, keyType, beanDesc);
/*  276 */         if (ser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*  281 */     if (ser == null) {
/*  282 */       ser = defaultImpl;
/*  283 */       if (ser == null) {
/*  284 */         ser = StdKeySerializers.getStdKeySerializer(config, keyType.getRawClass(), false);
/*  285 */         if (ser == null) {
/*  286 */           ser = StdKeySerializers.getFallbackKeySerializer(config, keyType.getRawClass());
/*      */         }
/*      */       } 
/*      */     } 
/*  290 */     if (this._factoryConfig.hasSerializerModifiers()) {
/*  291 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  292 */         ser = mod.modifyKeySerializer(config, keyType, beanDesc, ser);
/*      */       }
/*      */     }
/*  295 */     return (JsonSerializer)ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeSerializer createTypeSerializer(SerializationConfig config, JavaType baseType) {
/*  307 */     BeanDescription bean = config.introspectClassAnnotations(baseType.getRawClass());
/*  308 */     AnnotatedClass ac = bean.getClassInfo();
/*  309 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/*  310 */     TypeResolverBuilder<?> b = ai.findTypeResolver((MapperConfig)config, ac, baseType);
/*      */ 
/*      */ 
/*      */     
/*  314 */     Collection<NamedType> subtypes = null;
/*  315 */     if (b == null) {
/*  316 */       b = config.getDefaultTyper(baseType);
/*      */     } else {
/*  318 */       subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass((MapperConfig)config, ac);
/*      */     } 
/*  320 */     if (b == null) {
/*  321 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  325 */     return b.buildTypeSerializer(config, baseType, subtypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<?> findSerializerByLookup(JavaType type, SerializationConfig config, BeanDescription beanDesc, boolean staticTyping) {
/*  350 */     Class<?> raw = type.getRawClass();
/*  351 */     String clsName = raw.getName();
/*  352 */     JsonSerializer<?> ser = _concrete.get(clsName);
/*  353 */     if (ser == null) {
/*  354 */       Class<? extends JsonSerializer<?>> serClass = _concreteLazy.get(clsName);
/*  355 */       if (serClass != null)
/*      */       {
/*      */ 
/*      */         
/*  359 */         return (JsonSerializer)ClassUtil.createInstance(serClass, false);
/*      */       }
/*      */     } 
/*  362 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<?> findSerializerByAnnotations(SerializerProvider prov, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*  385 */     Class<?> raw = type.getRawClass();
/*      */     
/*  387 */     if (JsonSerializable.class.isAssignableFrom(raw)) {
/*  388 */       return (JsonSerializer<?>)SerializableSerializer.instance;
/*      */     }
/*      */     
/*  391 */     AnnotatedMember valueAccessor = beanDesc.findJsonValueAccessor();
/*  392 */     if (valueAccessor != null) {
/*  393 */       if (prov.canOverrideAccessModifiers()) {
/*  394 */         ClassUtil.checkAndFixAccess(valueAccessor.getMember(), prov
/*  395 */             .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */       }
/*  397 */       JavaType valueType = valueAccessor.getType();
/*  398 */       JsonSerializer<Object> valueSerializer = findSerializerFromAnnotation(prov, (Annotated)valueAccessor);
/*  399 */       if (valueSerializer == null) {
/*  400 */         valueSerializer = (JsonSerializer<Object>)valueType.getValueHandler();
/*      */       }
/*  402 */       TypeSerializer typeSerializer = (TypeSerializer)valueType.getTypeHandler();
/*  403 */       if (typeSerializer == null) {
/*  404 */         typeSerializer = createTypeSerializer(prov.getConfig(), valueType);
/*      */       }
/*  406 */       return (JsonSerializer<?>)new JsonValueSerializer(valueAccessor, typeSerializer, valueSerializer);
/*      */     } 
/*      */     
/*  409 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<?> findSerializerByPrimaryType(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/*  424 */     if (type.isEnumType()) {
/*  425 */       return buildEnumSerializer(prov.getConfig(), type, beanDesc);
/*      */     }
/*      */     
/*  428 */     Class<?> raw = type.getRawClass();
/*      */     
/*  430 */     JsonSerializer<?> ser = findOptionalStdSerializer(prov, type, beanDesc, staticTyping);
/*  431 */     if (ser != null) {
/*  432 */       return ser;
/*      */     }
/*      */     
/*  435 */     if (Calendar.class.isAssignableFrom(raw)) {
/*  436 */       return (JsonSerializer<?>)CalendarSerializer.instance;
/*      */     }
/*  438 */     if (Date.class.isAssignableFrom(raw)) {
/*  439 */       return (JsonSerializer<?>)DateSerializer.instance;
/*      */     }
/*  441 */     if (Map.Entry.class.isAssignableFrom(raw)) {
/*      */       
/*  443 */       JavaType mapEntryType = type.findSuperType(Map.Entry.class);
/*      */ 
/*      */       
/*  446 */       JavaType kt = mapEntryType.containedTypeOrUnknown(0);
/*  447 */       JavaType vt = mapEntryType.containedTypeOrUnknown(1);
/*  448 */       return buildMapEntrySerializer(prov, type, beanDesc, staticTyping, kt, vt);
/*      */     } 
/*  450 */     if (ByteBuffer.class.isAssignableFrom(raw)) {
/*  451 */       return (JsonSerializer<?>)new ByteBufferSerializer();
/*      */     }
/*  453 */     if (InetAddress.class.isAssignableFrom(raw)) {
/*  454 */       return (JsonSerializer<?>)new InetAddressSerializer();
/*      */     }
/*  456 */     if (InetSocketAddress.class.isAssignableFrom(raw)) {
/*  457 */       return (JsonSerializer<?>)new InetSocketAddressSerializer();
/*      */     }
/*  459 */     if (TimeZone.class.isAssignableFrom(raw)) {
/*  460 */       return (JsonSerializer<?>)new TimeZoneSerializer();
/*      */     }
/*  462 */     if (Charset.class.isAssignableFrom(raw)) {
/*  463 */       return (JsonSerializer<?>)ToStringSerializer.instance;
/*      */     }
/*  465 */     if (Number.class.isAssignableFrom(raw)) {
/*      */       
/*  467 */       JsonFormat.Value format = beanDesc.findExpectedFormat(null);
/*  468 */       switch (format.getShape()) {
/*      */         case NON_DEFAULT:
/*  470 */           return (JsonSerializer<?>)ToStringSerializer.instance;
/*      */         case NON_ABSENT:
/*      */         case NON_EMPTY:
/*  473 */           return null;
/*      */       } 
/*      */       
/*  476 */       return (JsonSerializer<?>)NumberSerializer.instance;
/*      */     } 
/*  478 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> findOptionalStdSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/*  490 */     return OptionalHandlerFactory.instance.findSerializer(prov.getConfig(), type, beanDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<?> findSerializerByAddonType(SerializationConfig config, JavaType javaType, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/*  504 */     Class<?> rawType = javaType.getRawClass();
/*      */     
/*  506 */     if (Iterator.class.isAssignableFrom(rawType)) {
/*  507 */       JavaType[] params = config.getTypeFactory().findTypeParameters(javaType, Iterator.class);
/*      */       
/*  509 */       JavaType vt = (params == null || params.length != 1) ? TypeFactory.unknownType() : params[0];
/*  510 */       return buildIteratorSerializer(config, javaType, beanDesc, staticTyping, vt);
/*      */     } 
/*  512 */     if (Iterable.class.isAssignableFrom(rawType)) {
/*  513 */       JavaType[] params = config.getTypeFactory().findTypeParameters(javaType, Iterable.class);
/*      */       
/*  515 */       JavaType vt = (params == null || params.length != 1) ? TypeFactory.unknownType() : params[0];
/*  516 */       return buildIterableSerializer(config, javaType, beanDesc, staticTyping, vt);
/*      */     } 
/*  518 */     if (CharSequence.class.isAssignableFrom(rawType)) {
/*  519 */       return (JsonSerializer<?>)ToStringSerializer.instance;
/*      */     }
/*  521 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> findSerializerFromAnnotation(SerializerProvider prov, Annotated a) throws JsonMappingException {
/*  536 */     Object serDef = prov.getAnnotationIntrospector().findSerializer(a);
/*  537 */     if (serDef == null) {
/*  538 */       return null;
/*      */     }
/*  540 */     JsonSerializer<Object> ser = prov.serializerInstance(a, serDef);
/*      */     
/*  542 */     return (JsonSerializer)findConvertingSerializer(prov, a, ser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> findConvertingSerializer(SerializerProvider prov, Annotated a, JsonSerializer<?> ser) throws JsonMappingException {
/*  555 */     Converter<Object, Object> conv = findConverter(prov, a);
/*  556 */     if (conv == null) {
/*  557 */       return ser;
/*      */     }
/*  559 */     JavaType delegateType = conv.getOutputType(prov.getTypeFactory());
/*  560 */     return (JsonSerializer<?>)new StdDelegatingSerializer(conv, delegateType, ser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Converter<Object, Object> findConverter(SerializerProvider prov, Annotated a) throws JsonMappingException {
/*  567 */     Object convDef = prov.getAnnotationIntrospector().findSerializationConverter(a);
/*  568 */     if (convDef == null) {
/*  569 */       return null;
/*      */     }
/*  571 */     return prov.converterInstance(a, convDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildContainerSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/*  587 */     SerializationConfig config = prov.getConfig();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  593 */     if (!staticTyping && type.useStaticType() && (
/*  594 */       !type.isContainerType() || !type.getContentType().isJavaLangObject())) {
/*  595 */       staticTyping = true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  600 */     JavaType elementType = type.getContentType();
/*  601 */     TypeSerializer elementTypeSerializer = createTypeSerializer(config, elementType);
/*      */ 
/*      */ 
/*      */     
/*  605 */     if (elementTypeSerializer != null) {
/*  606 */       staticTyping = false;
/*      */     }
/*  608 */     JsonSerializer<Object> elementValueSerializer = _findContentSerializer(prov, (Annotated)beanDesc
/*  609 */         .getClassInfo());
/*  610 */     if (type.isMapLikeType()) {
/*  611 */       MapLikeType mlt = (MapLikeType)type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  617 */       JsonSerializer<Object> keySerializer = _findKeySerializer(prov, (Annotated)beanDesc.getClassInfo());
/*  618 */       if (mlt instanceof MapType) {
/*  619 */         return buildMapSerializer(prov, (MapType)mlt, beanDesc, staticTyping, keySerializer, elementTypeSerializer, elementValueSerializer);
/*      */       }
/*      */ 
/*      */       
/*  623 */       JsonSerializer<?> ser = null;
/*  624 */       MapLikeType mlType = (MapLikeType)type;
/*  625 */       for (Serializers serializers : customSerializers()) {
/*  626 */         ser = serializers.findMapLikeSerializer(config, mlType, beanDesc, keySerializer, elementTypeSerializer, elementValueSerializer);
/*      */         
/*  628 */         if (ser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*  632 */       if (ser == null) {
/*  633 */         ser = findSerializerByAnnotations(prov, type, beanDesc);
/*      */       }
/*  635 */       if (ser != null && 
/*  636 */         this._factoryConfig.hasSerializerModifiers()) {
/*  637 */         for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  638 */           ser = mod.modifyMapLikeSerializer(config, mlType, beanDesc, ser);
/*      */         }
/*      */       }
/*      */       
/*  642 */       return ser;
/*      */     } 
/*  644 */     if (type.isCollectionLikeType()) {
/*  645 */       CollectionLikeType clt = (CollectionLikeType)type;
/*  646 */       if (clt instanceof CollectionType) {
/*  647 */         return buildCollectionSerializer(prov, (CollectionType)clt, beanDesc, staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */       }
/*      */ 
/*      */       
/*  651 */       JsonSerializer<?> ser = null;
/*  652 */       CollectionLikeType clType = (CollectionLikeType)type;
/*  653 */       for (Serializers serializers : customSerializers()) {
/*  654 */         ser = serializers.findCollectionLikeSerializer(config, clType, beanDesc, elementTypeSerializer, elementValueSerializer);
/*      */         
/*  656 */         if (ser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*  660 */       if (ser == null) {
/*  661 */         ser = findSerializerByAnnotations(prov, type, beanDesc);
/*      */       }
/*  663 */       if (ser != null && 
/*  664 */         this._factoryConfig.hasSerializerModifiers()) {
/*  665 */         for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  666 */           ser = mod.modifyCollectionLikeSerializer(config, clType, beanDesc, ser);
/*      */         }
/*      */       }
/*      */       
/*  670 */       return ser;
/*      */     } 
/*  672 */     if (type.isArrayType()) {
/*  673 */       return buildArraySerializer(prov, (ArrayType)type, beanDesc, staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */     }
/*      */     
/*  676 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildCollectionSerializer(SerializerProvider prov, CollectionType type, BeanDescription beanDesc, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) throws JsonMappingException {
/*      */     ContainerSerializer<?> containerSerializer;
/*      */     JsonSerializer<?> jsonSerializer1;
/*  690 */     SerializationConfig config = prov.getConfig();
/*  691 */     JsonSerializer<?> ser = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  696 */     for (Serializers serializers : customSerializers()) {
/*  697 */       ser = serializers.findCollectionSerializer(config, type, beanDesc, elementTypeSerializer, elementValueSerializer);
/*      */       
/*  699 */       if (ser != null) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  704 */     if (ser == null) {
/*  705 */       ser = findSerializerByAnnotations(prov, (JavaType)type, beanDesc);
/*  706 */       if (ser == null) {
/*      */ 
/*      */         
/*  709 */         JsonFormat.Value format = beanDesc.findExpectedFormat(null);
/*  710 */         if (format.getShape() == JsonFormat.Shape.OBJECT) {
/*  711 */           return null;
/*      */         }
/*  713 */         Class<?> raw = type.getRawClass();
/*  714 */         if (EnumSet.class.isAssignableFrom(raw)) {
/*      */           
/*  716 */           JavaType enumType = type.getContentType();
/*      */           
/*  718 */           if (!enumType.isEnumImplType()) {
/*  719 */             enumType = null;
/*      */           }
/*  721 */           ser = buildEnumSetSerializer(enumType);
/*      */         } else {
/*  723 */           StringCollectionSerializer stringCollectionSerializer; Class<?> elementRaw = type.getContentType().getRawClass();
/*  724 */           if (isIndexedList(raw)) {
/*  725 */             if (elementRaw == String.class) {
/*      */               
/*  727 */               if (ClassUtil.isJacksonStdImpl(elementValueSerializer)) {
/*  728 */                 IndexedStringListSerializer indexedStringListSerializer = IndexedStringListSerializer.instance;
/*      */               }
/*      */             } else {
/*  731 */               containerSerializer = buildIndexedListSerializer(type.getContentType(), staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */             }
/*      */           
/*  734 */           } else if (elementRaw == String.class) {
/*      */             
/*  736 */             if (ClassUtil.isJacksonStdImpl(elementValueSerializer)) {
/*  737 */               stringCollectionSerializer = StringCollectionSerializer.instance;
/*      */             }
/*      */           } 
/*  740 */           if (stringCollectionSerializer == null) {
/*  741 */             containerSerializer = buildCollectionSerializer(type.getContentType(), staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  748 */     if (this._factoryConfig.hasSerializerModifiers()) {
/*  749 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  750 */         jsonSerializer1 = mod.modifyCollectionSerializer(config, type, beanDesc, (JsonSerializer<?>)containerSerializer);
/*      */       }
/*      */     }
/*  753 */     return jsonSerializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isIndexedList(Class<?> cls) {
/*  764 */     return RandomAccess.class.isAssignableFrom(cls);
/*      */   }
/*      */ 
/*      */   
/*      */   public ContainerSerializer<?> buildIndexedListSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, JsonSerializer<Object> valueSerializer) {
/*  769 */     return (ContainerSerializer<?>)new IndexedListSerializer(elemType, staticTyping, vts, valueSerializer);
/*      */   }
/*      */ 
/*      */   
/*      */   public ContainerSerializer<?> buildCollectionSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, JsonSerializer<Object> valueSerializer) {
/*  774 */     return (ContainerSerializer<?>)new CollectionSerializer(elemType, staticTyping, vts, valueSerializer);
/*      */   }
/*      */   
/*      */   public JsonSerializer<?> buildEnumSetSerializer(JavaType enumType) {
/*  778 */     return (JsonSerializer<?>)new EnumSetSerializer(enumType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildMapSerializer(SerializerProvider prov, MapType type, BeanDescription beanDesc, boolean staticTyping, JsonSerializer<Object> keySerializer, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) throws JsonMappingException {
/*      */     MapSerializer mapSerializer;
/*      */     JsonSerializer<?> jsonSerializer1;
/*  799 */     JsonFormat.Value format = beanDesc.findExpectedFormat(null);
/*  800 */     if (format.getShape() == JsonFormat.Shape.OBJECT) {
/*  801 */       return null;
/*      */     }
/*      */     
/*  804 */     JsonSerializer<?> ser = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  811 */     SerializationConfig config = prov.getConfig();
/*  812 */     for (Serializers serializers : customSerializers()) {
/*  813 */       ser = serializers.findMapSerializer(config, type, beanDesc, keySerializer, elementTypeSerializer, elementValueSerializer);
/*      */       
/*  815 */       if (ser != null)
/*      */         break; 
/*  817 */     }  if (ser == null) {
/*  818 */       ser = findSerializerByAnnotations(prov, (JavaType)type, beanDesc);
/*  819 */       if (ser == null) {
/*  820 */         Object filterId = findFilterId(config, beanDesc);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  825 */         JsonIgnoreProperties.Value ignorals = config.getDefaultPropertyIgnorals(Map.class, beanDesc
/*  826 */             .getClassInfo());
/*      */         
/*  828 */         Set<String> ignored = (ignorals == null) ? null : ignorals.findIgnoredForSerialization();
/*  829 */         JsonIncludeProperties.Value inclusions = config.getDefaultPropertyInclusions(Map.class, beanDesc
/*  830 */             .getClassInfo());
/*      */         
/*  832 */         Set<String> included = (inclusions == null) ? null : inclusions.getIncluded();
/*  833 */         MapSerializer mapSer = MapSerializer.construct(ignored, included, (JavaType)type, staticTyping, elementTypeSerializer, keySerializer, elementValueSerializer, filterId);
/*      */ 
/*      */         
/*  836 */         mapSerializer = _checkMapContentInclusion(prov, beanDesc, mapSer);
/*      */       } 
/*      */     } 
/*      */     
/*  840 */     if (this._factoryConfig.hasSerializerModifiers()) {
/*  841 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  842 */         jsonSerializer1 = mod.modifyMapSerializer(config, type, beanDesc, (JsonSerializer<?>)mapSerializer);
/*      */       }
/*      */     }
/*  845 */     return jsonSerializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapSerializer _checkMapContentInclusion(SerializerProvider prov, BeanDescription beanDesc, MapSerializer mapSer) throws JsonMappingException {
/*  859 */     JavaType contentType = mapSer.getContentType();
/*  860 */     JsonInclude.Value inclV = _findInclusionWithContent(prov, beanDesc, contentType, Map.class);
/*      */ 
/*      */ 
/*      */     
/*  864 */     JsonInclude.Include incl = (inclV == null) ? JsonInclude.Include.USE_DEFAULTS : inclV.getContentInclusion();
/*  865 */     if (incl == JsonInclude.Include.USE_DEFAULTS || incl == JsonInclude.Include.ALWAYS) {
/*      */       
/*  867 */       if (!prov.isEnabled(SerializationFeature.WRITE_NULL_MAP_VALUES)) {
/*  868 */         return mapSer.withContentInclusion(null, true);
/*      */       }
/*  870 */       return mapSer;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  876 */     boolean suppressNulls = true;
/*      */     
/*  878 */     switch (incl)
/*      */     { case NON_DEFAULT:
/*  880 */         valueToSuppress = BeanUtil.getDefaultValue(contentType);
/*  881 */         if (valueToSuppress != null && 
/*  882 */           valueToSuppress.getClass().isArray()) {
/*  883 */           valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  908 */         return mapSer.withContentInclusion(valueToSuppress, suppressNulls);case NON_ABSENT: valueToSuppress = contentType.isReferenceType() ? MapSerializer.MARKER_FOR_EMPTY : null; return mapSer.withContentInclusion(valueToSuppress, suppressNulls);case NON_EMPTY: valueToSuppress = MapSerializer.MARKER_FOR_EMPTY; return mapSer.withContentInclusion(valueToSuppress, suppressNulls);case CUSTOM: valueToSuppress = prov.includeFilterInstance(null, inclV.getContentFilter()); if (valueToSuppress == null) { suppressNulls = true; } else { suppressNulls = prov.includeFilterSuppressNulls(valueToSuppress); }  return mapSer.withContentInclusion(valueToSuppress, suppressNulls); }  Object valueToSuppress = null; return mapSer.withContentInclusion(valueToSuppress, suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildMapEntrySerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping, JavaType keyType, JavaType valueType) throws JsonMappingException {
/*  921 */     JsonFormat.Value formatOverride = prov.getDefaultPropertyFormat(Map.Entry.class);
/*  922 */     JsonFormat.Value formatFromAnnotation = beanDesc.findExpectedFormat(null);
/*  923 */     JsonFormat.Value format = JsonFormat.Value.merge(formatFromAnnotation, formatOverride);
/*  924 */     if (format.getShape() == JsonFormat.Shape.OBJECT) {
/*  925 */       return null;
/*      */     }
/*      */     
/*  928 */     MapEntrySerializer ser = new MapEntrySerializer(valueType, keyType, valueType, staticTyping, createTypeSerializer(prov.getConfig(), valueType), null);
/*      */     
/*  930 */     JavaType contentType = ser.getContentType();
/*  931 */     JsonInclude.Value inclV = _findInclusionWithContent(prov, beanDesc, contentType, Map.Entry.class);
/*      */ 
/*      */ 
/*      */     
/*  935 */     JsonInclude.Include incl = (inclV == null) ? JsonInclude.Include.USE_DEFAULTS : inclV.getContentInclusion();
/*  936 */     if (incl == JsonInclude.Include.USE_DEFAULTS || incl == JsonInclude.Include.ALWAYS)
/*      */     {
/*  938 */       return (JsonSerializer<?>)ser;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  944 */     boolean suppressNulls = true;
/*      */     
/*  946 */     switch (incl)
/*      */     { case NON_DEFAULT:
/*  948 */         valueToSuppress = BeanUtil.getDefaultValue(contentType);
/*  949 */         if (valueToSuppress != null && 
/*  950 */           valueToSuppress.getClass().isArray()) {
/*  951 */           valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  975 */         return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case NON_ABSENT: valueToSuppress = contentType.isReferenceType() ? MapSerializer.MARKER_FOR_EMPTY : null; return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case NON_EMPTY: valueToSuppress = MapSerializer.MARKER_FOR_EMPTY; return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case CUSTOM: valueToSuppress = prov.includeFilterInstance(null, inclV.getContentFilter()); if (valueToSuppress == null) { suppressNulls = true; } else { suppressNulls = prov.includeFilterSuppressNulls(valueToSuppress); }  return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls); }  Object valueToSuppress = null; return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonInclude.Value _findInclusionWithContent(SerializerProvider prov, BeanDescription beanDesc, JavaType contentType, Class<?> configType) throws JsonMappingException {
/*  991 */     SerializationConfig config = prov.getConfig();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  998 */     JsonInclude.Value inclV = beanDesc.findPropertyInclusion(config.getDefaultPropertyInclusion());
/*  999 */     inclV = config.getDefaultPropertyInclusion(configType, inclV);
/*      */ 
/*      */ 
/*      */     
/* 1003 */     JsonInclude.Value valueIncl = config.getDefaultPropertyInclusion(contentType.getRawClass(), null);
/*      */     
/* 1005 */     if (valueIncl != null) {
/* 1006 */       switch (valueIncl.getValueInclusion()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case USE_DEFAULTS:
/* 1016 */           return inclV;
/*      */         case CUSTOM:
/*      */           inclV = inclV.withContentFilter(valueIncl.getContentFilter());
/*      */       } 
/*      */       inclV = inclV.withContentInclusion(valueIncl.getValueInclusion());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildArraySerializer(SerializerProvider prov, ArrayType type, BeanDescription beanDesc, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) throws JsonMappingException {
/*      */     ObjectArraySerializer objectArraySerializer;
/*      */     JsonSerializer<?> jsonSerializer1;
/* 1039 */     SerializationConfig config = prov.getConfig();
/* 1040 */     JsonSerializer<?> ser = null;
/*      */     
/* 1042 */     for (Serializers serializers : customSerializers()) {
/* 1043 */       ser = serializers.findArraySerializer(config, type, beanDesc, elementTypeSerializer, elementValueSerializer);
/*      */       
/* 1045 */       if (ser != null) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 1050 */     if (ser == null) {
/* 1051 */       Class<?> raw = type.getRawClass();
/*      */       
/* 1053 */       if (elementValueSerializer == null || ClassUtil.isJacksonStdImpl(elementValueSerializer)) {
/* 1054 */         if (String[].class == raw) {
/* 1055 */           StringArraySerializer stringArraySerializer = StringArraySerializer.instance;
/*      */         } else {
/*      */           
/* 1058 */           ser = StdArraySerializers.findStandardImpl(raw);
/*      */         } 
/*      */       }
/* 1061 */       if (ser == null) {
/* 1062 */         objectArraySerializer = new ObjectArraySerializer(type.getContentType(), staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1067 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 1068 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 1069 */         jsonSerializer1 = mod.modifyArraySerializer(config, type, beanDesc, (JsonSerializer<?>)objectArraySerializer);
/*      */       }
/*      */     }
/* 1072 */     return jsonSerializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> findReferenceSerializer(SerializerProvider prov, ReferenceType refType, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 1089 */     JavaType contentType = refType.getContentType();
/* 1090 */     TypeSerializer contentTypeSerializer = (TypeSerializer)contentType.getTypeHandler();
/* 1091 */     SerializationConfig config = prov.getConfig();
/* 1092 */     if (contentTypeSerializer == null) {
/* 1093 */       contentTypeSerializer = createTypeSerializer(config, contentType);
/*      */     }
/* 1095 */     JsonSerializer<Object> contentSerializer = (JsonSerializer<Object>)contentType.getValueHandler();
/* 1096 */     for (Serializers serializers : customSerializers()) {
/* 1097 */       JsonSerializer<?> ser = serializers.findReferenceSerializer(config, refType, beanDesc, contentTypeSerializer, contentSerializer);
/*      */       
/* 1099 */       if (ser != null) {
/* 1100 */         return ser;
/*      */       }
/*      */     } 
/* 1103 */     if (refType.isTypeOrSubTypeOf(AtomicReference.class)) {
/* 1104 */       return buildAtomicReferenceSerializer(prov, refType, beanDesc, staticTyping, contentTypeSerializer, contentSerializer);
/*      */     }
/*      */     
/* 1107 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildAtomicReferenceSerializer(SerializerProvider prov, ReferenceType refType, BeanDescription beanDesc, boolean staticTyping, TypeSerializer contentTypeSerializer, JsonSerializer<Object> contentSerializer) throws JsonMappingException {
/*      */     Object valueToSuppress;
/*      */     boolean suppressNulls;
/* 1115 */     JavaType contentType = refType.getReferencedType();
/* 1116 */     JsonInclude.Value inclV = _findInclusionWithContent(prov, beanDesc, contentType, AtomicReference.class);
/*      */ 
/*      */ 
/*      */     
/* 1120 */     JsonInclude.Include incl = (inclV == null) ? JsonInclude.Include.USE_DEFAULTS : inclV.getContentInclusion();
/*      */ 
/*      */ 
/*      */     
/* 1124 */     if (incl == JsonInclude.Include.USE_DEFAULTS || incl == JsonInclude.Include.ALWAYS)
/*      */     
/* 1126 */     { valueToSuppress = null;
/* 1127 */       suppressNulls = false; }
/*      */     else
/* 1129 */     { AtomicReferenceSerializer ser; suppressNulls = true;
/* 1130 */       switch (incl)
/*      */       { case NON_DEFAULT:
/* 1132 */           valueToSuppress = BeanUtil.getDefaultValue(contentType);
/* 1133 */           if (valueToSuppress != null && 
/* 1134 */             valueToSuppress.getClass().isArray()) {
/* 1135 */             valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1160 */           ser = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer);
/*      */           
/* 1162 */           return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case NON_ABSENT: valueToSuppress = contentType.isReferenceType() ? MapSerializer.MARKER_FOR_EMPTY : null; ser = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer); return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case NON_EMPTY: valueToSuppress = MapSerializer.MARKER_FOR_EMPTY; ser = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer); return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case CUSTOM: valueToSuppress = prov.includeFilterInstance(null, inclV.getContentFilter()); if (valueToSuppress == null) { suppressNulls = true; } else { suppressNulls = prov.includeFilterSuppressNulls(valueToSuppress); }  ser = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer); return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls); }  valueToSuppress = null; }  AtomicReferenceSerializer atomicReferenceSerializer = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer); return (JsonSerializer<?>)atomicReferenceSerializer.withContentInclusion(valueToSuppress, suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildIteratorSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc, boolean staticTyping, JavaType valueType) throws JsonMappingException {
/* 1179 */     return (JsonSerializer<?>)new IteratorSerializer(valueType, staticTyping, createTypeSerializer(config, valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildIterableSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc, boolean staticTyping, JavaType valueType) throws JsonMappingException {
/* 1190 */     return (JsonSerializer<?>)new IterableSerializer(valueType, staticTyping, createTypeSerializer(config, valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildEnumSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     JsonSerializer<?> jsonSerializer;
/* 1202 */     JsonFormat.Value format = beanDesc.findExpectedFormat(null);
/* 1203 */     if (format.getShape() == JsonFormat.Shape.OBJECT) {
/*      */       
/* 1205 */       ((BasicBeanDescription)beanDesc).removeProperty("declaringClass");
/*      */       
/* 1207 */       return null;
/*      */     } 
/*      */     
/* 1210 */     Class<Enum<?>> enumClass = type.getRawClass();
/* 1211 */     EnumSerializer enumSerializer = EnumSerializer.construct(enumClass, config, beanDesc, format);
/*      */     
/* 1213 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 1214 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 1215 */         jsonSerializer = mod.modifyEnumSerializer(config, type, beanDesc, (JsonSerializer<?>)enumSerializer);
/*      */       }
/*      */     }
/* 1218 */     return jsonSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _findKeySerializer(SerializerProvider prov, Annotated a) throws JsonMappingException {
/* 1236 */     AnnotationIntrospector intr = prov.getAnnotationIntrospector();
/* 1237 */     Object serDef = intr.findKeySerializer(a);
/* 1238 */     if (serDef != null) {
/* 1239 */       return prov.serializerInstance(a, serDef);
/*      */     }
/* 1241 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _findContentSerializer(SerializerProvider prov, Annotated a) throws JsonMappingException {
/* 1253 */     AnnotationIntrospector intr = prov.getAnnotationIntrospector();
/* 1254 */     Object serDef = intr.findContentSerializer(a);
/* 1255 */     if (serDef != null) {
/* 1256 */       return prov.serializerInstance(a, serDef);
/*      */     }
/* 1258 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object findFilterId(SerializationConfig config, BeanDescription beanDesc) {
/* 1266 */     return config.getAnnotationIntrospector().findFilterId((Annotated)beanDesc.getClassInfo());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean usesStaticTyping(SerializationConfig config, BeanDescription beanDesc, TypeSerializer typeSer) {
/* 1283 */     if (typeSer != null) {
/* 1284 */       return false;
/*      */     }
/* 1286 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 1287 */     JsonSerialize.Typing t = intr.findSerializationTyping((Annotated)beanDesc.getClassInfo());
/* 1288 */     if (t != null && t != JsonSerialize.Typing.DEFAULT_TYPING) {
/* 1289 */       return (t == JsonSerialize.Typing.STATIC);
/*      */     }
/* 1291 */     return config.isEnabled(MapperFeature.USE_STATIC_TYPING);
/*      */   }
/*      */   
/*      */   public abstract SerializerFactory withConfig(SerializerFactoryConfig paramSerializerFactoryConfig);
/*      */   
/*      */   public abstract JsonSerializer<Object> createSerializer(SerializerProvider paramSerializerProvider, JavaType paramJavaType) throws JsonMappingException;
/*      */   
/*      */   protected abstract Iterable<Serializers> customSerializers();
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databind\ser\BasicSerializerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */