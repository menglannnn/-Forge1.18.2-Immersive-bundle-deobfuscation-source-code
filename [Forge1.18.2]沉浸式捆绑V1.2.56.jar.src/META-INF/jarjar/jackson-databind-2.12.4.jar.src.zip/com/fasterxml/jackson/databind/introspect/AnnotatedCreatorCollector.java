/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AnnotatedCreatorCollector
/*     */   extends CollectorBase
/*     */ {
/*     */   private final TypeResolutionContext _typeContext;
/*     */   private final boolean _collectAnnotations;
/*     */   private AnnotatedConstructor _defaultConstructor;
/*     */   
/*     */   AnnotatedCreatorCollector(AnnotationIntrospector intr, TypeResolutionContext tc, boolean collectAnnotations) {
/*  43 */     super(intr);
/*  44 */     this._typeContext = tc;
/*  45 */     this._collectAnnotations = collectAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotatedClass.Creators collectCreators(AnnotationIntrospector intr, TypeFactory typeFactory, TypeResolutionContext tc, JavaType type, Class<?> primaryMixIn, boolean collectAnnotations) {
/*  57 */     int i = collectAnnotations | ((primaryMixIn != null) ? 1 : 0);
/*     */ 
/*     */     
/*  60 */     return (new AnnotatedCreatorCollector(intr, tc, i))
/*  61 */       .collect(typeFactory, type, primaryMixIn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotatedClass.Creators collect(TypeFactory typeFactory, JavaType type, Class<?> primaryMixIn) {
/*  70 */     List<AnnotatedConstructor> constructors = _findPotentialConstructors(type, primaryMixIn);
/*  71 */     List<AnnotatedMethod> factories = _findPotentialFactories(typeFactory, type, primaryMixIn);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     if (this._collectAnnotations) {
/*  78 */       if (this._defaultConstructor != null && 
/*  79 */         this._intr.hasIgnoreMarker(this._defaultConstructor)) {
/*  80 */         this._defaultConstructor = null;
/*     */       }
/*     */       
/*     */       int i;
/*  84 */       for (i = constructors.size(); --i >= 0;) {
/*  85 */         if (this._intr.hasIgnoreMarker(constructors.get(i))) {
/*  86 */           constructors.remove(i);
/*     */         }
/*     */       } 
/*  89 */       for (i = factories.size(); --i >= 0;) {
/*  90 */         if (this._intr.hasIgnoreMarker(factories.get(i))) {
/*  91 */           factories.remove(i);
/*     */         }
/*     */       } 
/*     */     } 
/*  95 */     return new AnnotatedClass.Creators(this._defaultConstructor, constructors, factories);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<AnnotatedConstructor> _findPotentialConstructors(JavaType type, Class<?> primaryMixIn) {
/*     */     List<AnnotatedConstructor> result;
/*     */     int ctorCount;
/* 106 */     ClassUtil.Ctor defaultCtor = null;
/* 107 */     List<ClassUtil.Ctor> ctors = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     if (!type.isEnumType()) {
/* 115 */       ClassUtil.Ctor[] declaredCtors = ClassUtil.getConstructors(type.getRawClass());
/* 116 */       for (ClassUtil.Ctor ctor : declaredCtors) {
/* 117 */         if (isIncludableConstructor(ctor.getConstructor()))
/*     */         {
/*     */           
/* 120 */           if (ctor.getParamCount() == 0) {
/* 121 */             defaultCtor = ctor;
/*     */           } else {
/* 123 */             if (ctors == null) {
/* 124 */               ctors = new ArrayList<>();
/*     */             }
/* 126 */             ctors.add(ctor);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     if (ctors == null) {
/* 133 */       result = Collections.emptyList();
/*     */       
/* 135 */       if (defaultCtor == null) {
/* 136 */         return result;
/*     */       }
/* 138 */       ctorCount = 0;
/*     */     } else {
/* 140 */       ctorCount = ctors.size();
/* 141 */       result = new ArrayList<>(ctorCount);
/* 142 */       for (int j = 0; j < ctorCount; j++) {
/* 143 */         result.add(null);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 148 */     if (primaryMixIn != null) {
/* 149 */       MemberKey[] ctorKeys = null;
/* 150 */       for (ClassUtil.Ctor mixinCtor : ClassUtil.getConstructors(primaryMixIn)) {
/* 151 */         if (mixinCtor.getParamCount() == 0) {
/* 152 */           if (defaultCtor != null) {
/* 153 */             this._defaultConstructor = constructDefaultConstructor(defaultCtor, mixinCtor);
/* 154 */             defaultCtor = null;
/*     */           }
/*     */         
/*     */         }
/* 158 */         else if (ctors != null) {
/* 159 */           if (ctorKeys == null) {
/* 160 */             ctorKeys = new MemberKey[ctorCount];
/* 161 */             for (int k = 0; k < ctorCount; k++) {
/* 162 */               ctorKeys[k] = new MemberKey(((ClassUtil.Ctor)ctors.get(k)).getConstructor());
/*     */             }
/*     */           } 
/* 165 */           MemberKey key = new MemberKey(mixinCtor.getConstructor());
/*     */           
/* 167 */           for (int j = 0; j < ctorCount; j++) {
/* 168 */             if (key.equals(ctorKeys[j])) {
/* 169 */               result.set(j, 
/* 170 */                   constructNonDefaultConstructor(ctors.get(j), mixinCtor));
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 178 */     if (defaultCtor != null) {
/* 179 */       this._defaultConstructor = constructDefaultConstructor(defaultCtor, (ClassUtil.Ctor)null);
/*     */     }
/* 181 */     for (int i = 0; i < ctorCount; i++) {
/* 182 */       AnnotatedConstructor ctor = result.get(i);
/* 183 */       if (ctor == null) {
/* 184 */         result.set(i, 
/* 185 */             constructNonDefaultConstructor(ctors.get(i), (ClassUtil.Ctor)null));
/*     */       }
/*     */     } 
/* 188 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<AnnotatedMethod> _findPotentialFactories(TypeFactory typeFactory, JavaType type, Class<?> primaryMixIn) {
/* 194 */     List<Method> candidates = null;
/*     */ 
/*     */     
/* 197 */     for (Method m : ClassUtil.getClassMethods(type.getRawClass())) {
/* 198 */       if (_isIncludableFactoryMethod(m)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 203 */         if (candidates == null) {
/* 204 */           candidates = new ArrayList<>();
/*     */         }
/* 206 */         candidates.add(m);
/*     */       } 
/*     */     } 
/* 209 */     if (candidates == null) {
/* 210 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     TypeResolutionContext emptyTypeResCtxt = new TypeResolutionContext.Empty(typeFactory);
/*     */     
/* 227 */     int factoryCount = candidates.size();
/* 228 */     List<AnnotatedMethod> result = new ArrayList<>(factoryCount); int i;
/* 229 */     for (i = 0; i < factoryCount; i++) {
/* 230 */       result.add(null);
/*     */     }
/*     */     
/* 233 */     if (primaryMixIn != null) {
/* 234 */       MemberKey[] methodKeys = null;
/* 235 */       for (Method mixinFactory : primaryMixIn.getDeclaredMethods()) {
/* 236 */         if (_isIncludableFactoryMethod(mixinFactory)) {
/*     */ 
/*     */           
/* 239 */           if (methodKeys == null) {
/* 240 */             methodKeys = new MemberKey[factoryCount];
/* 241 */             for (int k = 0; k < factoryCount; k++) {
/* 242 */               methodKeys[k] = new MemberKey(candidates.get(k));
/*     */             }
/*     */           } 
/* 245 */           MemberKey key = new MemberKey(mixinFactory);
/* 246 */           for (int j = 0; j < factoryCount; j++) {
/* 247 */             if (key.equals(methodKeys[j])) {
/* 248 */               result.set(j, 
/* 249 */                   constructFactoryCreator(candidates.get(j), emptyTypeResCtxt, mixinFactory));
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 257 */     for (i = 0; i < factoryCount; i++) {
/* 258 */       AnnotatedMethod factory = result.get(i);
/* 259 */       if (factory == null) {
/* 260 */         Method candidate = candidates.get(i);
/*     */ 
/*     */ 
/*     */         
/* 264 */         TypeResolutionContext typeResCtxt = MethodGenericTypeResolver.narrowMethodTypeParameters(candidate, type, typeFactory, emptyTypeResCtxt);
/*     */         
/* 266 */         result.set(i, 
/* 267 */             constructFactoryCreator(candidate, typeResCtxt, (Method)null));
/*     */       } 
/*     */     } 
/* 270 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean _isIncludableFactoryMethod(Method m) {
/* 275 */     return (Modifier.isStatic(m.getModifiers()) && 
/*     */ 
/*     */       
/* 278 */       !m.isSynthetic());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedConstructor constructDefaultConstructor(ClassUtil.Ctor ctor, ClassUtil.Ctor mixin) {
/* 284 */     return new AnnotatedConstructor(this._typeContext, ctor.getConstructor(), 
/* 285 */         collectAnnotations(ctor, mixin), NO_ANNOTATION_MAPS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedConstructor constructNonDefaultConstructor(ClassUtil.Ctor ctor, ClassUtil.Ctor mixin) {
/*     */     AnnotationMap[] resolvedAnnotations;
/* 293 */     int paramCount = ctor.getParamCount();
/* 294 */     if (this._intr == null) {
/* 295 */       return new AnnotatedConstructor(this._typeContext, ctor.getConstructor(), 
/* 296 */           _emptyAnnotationMap(), _emptyAnnotationMaps(paramCount));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     if (paramCount == 0) {
/* 304 */       return new AnnotatedConstructor(this._typeContext, ctor.getConstructor(), 
/* 305 */           collectAnnotations(ctor, mixin), NO_ANNOTATION_MAPS);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 310 */     Annotation[][] paramAnns = ctor.getParameterAnnotations();
/* 311 */     if (paramCount != paramAnns.length) {
/*     */ 
/*     */ 
/*     */       
/* 315 */       resolvedAnnotations = null;
/* 316 */       Class<?> dc = ctor.getDeclaringClass();
/*     */       
/* 318 */       if (ClassUtil.isEnumType(dc) && paramCount == paramAnns.length + 2) {
/* 319 */         Annotation[][] old = paramAnns;
/* 320 */         paramAnns = new Annotation[old.length + 2][];
/* 321 */         System.arraycopy(old, 0, paramAnns, 2, old.length);
/* 322 */         resolvedAnnotations = collectAnnotations(paramAnns, (Annotation[][])null);
/* 323 */       } else if (dc.isMemberClass()) {
/*     */         
/* 325 */         if (paramCount == paramAnns.length + 1) {
/*     */           
/* 327 */           Annotation[][] old = paramAnns;
/* 328 */           paramAnns = new Annotation[old.length + 1][];
/* 329 */           System.arraycopy(old, 0, paramAnns, 1, old.length);
/* 330 */           paramAnns[0] = NO_ANNOTATIONS;
/* 331 */           resolvedAnnotations = collectAnnotations(paramAnns, (Annotation[][])null);
/*     */         } 
/*     */       } 
/* 334 */       if (resolvedAnnotations == null) {
/* 335 */         throw new IllegalStateException(String.format("Internal error: constructor for %s has mismatch: %d parameters; %d sets of annotations", new Object[] { ctor
/*     */                 
/* 337 */                 .getDeclaringClass().getName(), Integer.valueOf(paramCount), Integer.valueOf(paramAnns.length) }));
/*     */       }
/*     */     } else {
/* 340 */       resolvedAnnotations = collectAnnotations(paramAnns, (mixin == null) ? (Annotation[][])null : mixin
/* 341 */           .getParameterAnnotations());
/*     */     } 
/* 343 */     return new AnnotatedConstructor(this._typeContext, ctor.getConstructor(), 
/* 344 */         collectAnnotations(ctor, mixin), resolvedAnnotations);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedMethod constructFactoryCreator(Method m, TypeResolutionContext typeResCtxt, Method mixin) {
/* 350 */     int paramCount = (m.getParameterTypes()).length;
/* 351 */     if (this._intr == null) {
/* 352 */       return new AnnotatedMethod(typeResCtxt, m, _emptyAnnotationMap(), 
/* 353 */           _emptyAnnotationMaps(paramCount));
/*     */     }
/* 355 */     if (paramCount == 0) {
/* 356 */       return new AnnotatedMethod(typeResCtxt, m, collectAnnotations(m, mixin), NO_ANNOTATION_MAPS);
/*     */     }
/*     */     
/* 359 */     return new AnnotatedMethod(typeResCtxt, m, collectAnnotations(m, mixin), 
/* 360 */         collectAnnotations(m.getParameterAnnotations(), (mixin == null) ? (Annotation[][])null : mixin
/* 361 */           .getParameterAnnotations()));
/*     */   }
/*     */   
/*     */   private AnnotationMap[] collectAnnotations(Annotation[][] mainAnns, Annotation[][] mixinAnns) {
/* 365 */     if (this._collectAnnotations) {
/* 366 */       int count = mainAnns.length;
/* 367 */       AnnotationMap[] result = new AnnotationMap[count];
/* 368 */       for (int i = 0; i < count; i++) {
/* 369 */         AnnotationCollector c = collectAnnotations(AnnotationCollector.emptyCollector(), mainAnns[i]);
/*     */         
/* 371 */         if (mixinAnns != null) {
/* 372 */           c = collectAnnotations(c, mixinAnns[i]);
/*     */         }
/* 374 */         result[i] = c.asAnnotationMap();
/*     */       } 
/* 376 */       return result;
/*     */     } 
/* 378 */     return NO_ANNOTATION_MAPS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private AnnotationMap collectAnnotations(ClassUtil.Ctor main, ClassUtil.Ctor mixin) {
/* 384 */     if (this._collectAnnotations) {
/* 385 */       AnnotationCollector c = collectAnnotations(main.getDeclaredAnnotations());
/* 386 */       if (mixin != null) {
/* 387 */         c = collectAnnotations(c, mixin.getDeclaredAnnotations());
/*     */       }
/* 389 */       return c.asAnnotationMap();
/*     */     } 
/* 391 */     return _emptyAnnotationMap();
/*     */   }
/*     */   
/*     */   private final AnnotationMap collectAnnotations(AnnotatedElement main, AnnotatedElement mixin) {
/* 395 */     AnnotationCollector c = collectAnnotations(main.getDeclaredAnnotations());
/* 396 */     if (mixin != null) {
/* 397 */       c = collectAnnotations(c, mixin.getDeclaredAnnotations());
/*     */     }
/* 399 */     return c.asAnnotationMap();
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isIncludableConstructor(Constructor<?> c) {
/* 404 */     return !c.isSynthetic();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databind\introspect\AnnotatedCreatorCollector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */