package com.fasterxml.jackson.databind.deser;

import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.util.AccessPattern;

public interface NullValueProvider {
  Object getNullValue(DeserializationContext paramDeserializationContext) throws JsonMappingException;
  
  AccessPattern getNullAccessPattern();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databind\deser\NullValueProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */