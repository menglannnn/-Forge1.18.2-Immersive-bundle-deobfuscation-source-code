/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanAsArrayDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*      */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BeanDeserializer
/*      */   extends BeanDeserializerBase
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected transient Exception _nullFromCreator;
/*      */   private volatile transient NameTransformer _currentlyTransforming;
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, boolean hasViews) {
/*   69 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, (Set<String>)null, hasViews);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, Set<String> includableProps, boolean hasViews) {
/*   83 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, includableProps, hasViews);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src) {
/*   92 */     super(src, src._ignoreAllUnknown);
/*      */   }
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src, boolean ignoreAllUnknown) {
/*   96 */     super(src, ignoreAllUnknown);
/*      */   }
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src, NameTransformer unwrapper) {
/*  100 */     super(src, unwrapper);
/*      */   }
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, ObjectIdReader oir) {
/*  104 */     super(src, oir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializer(BeanDeserializerBase src, Set<String> ignorableProps) {
/*  112 */     super(src, ignorableProps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, Set<String> ignorableProps, Set<String> includableProps) {
/*  119 */     super(src, ignorableProps, includableProps);
/*      */   }
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, BeanPropertyMap props) {
/*  123 */     super(src, props);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer transformer) {
/*  131 */     if (getClass() != BeanDeserializer.class) {
/*  132 */       return (JsonDeserializer<Object>)this;
/*      */     }
/*      */ 
/*      */     
/*  136 */     if (this._currentlyTransforming == transformer) {
/*  137 */       return (JsonDeserializer<Object>)this;
/*      */     }
/*  139 */     this._currentlyTransforming = transformer;
/*      */     
/*  141 */     try { return (JsonDeserializer<Object>)new BeanDeserializer(this, transformer); }
/*  142 */     finally { this._currentlyTransforming = null; }
/*      */   
/*      */   }
/*      */   
/*      */   public BeanDeserializer withObjectIdReader(ObjectIdReader oir) {
/*  147 */     return new BeanDeserializer(this, oir);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer withByNameInclusion(Set<String> ignorableProps, Set<String> includableProps) {
/*  153 */     return new BeanDeserializer(this, ignorableProps, includableProps);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withIgnoreAllUnknown(boolean ignoreUnknown) {
/*  158 */     return new BeanDeserializer(this, ignoreUnknown);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withBeanProperties(BeanPropertyMap props) {
/*  163 */     return new BeanDeserializer(this, props);
/*      */   }
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase asArrayDeserializer() {
/*  168 */     SettableBeanProperty[] props = this._beanProperties.getPropertiesInInsertionOrder();
/*  169 */     return (BeanDeserializerBase)new BeanAsArrayDeserializer(this, props);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  185 */     if (p.isExpectedStartObjectToken()) {
/*  186 */       if (this._vanillaProcessing) {
/*  187 */         return vanillaDeserialize(p, ctxt, p.nextToken());
/*      */       }
/*      */ 
/*      */       
/*  191 */       p.nextToken();
/*  192 */       if (this._objectIdReader != null) {
/*  193 */         return deserializeWithObjectId(p, ctxt);
/*      */       }
/*  195 */       return deserializeFromObject(p, ctxt);
/*      */     } 
/*  197 */     return _deserializeOther(p, ctxt, p.currentToken());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _deserializeOther(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/*  204 */     if (t != null) {
/*  205 */       switch (t) {
/*      */         case AsEmpty:
/*  207 */           return deserializeFromString(p, ctxt);
/*      */         case AsNull:
/*  209 */           return deserializeFromNumber(p, ctxt);
/*      */         case TryConvert:
/*  211 */           return deserializeFromDouble(p, ctxt);
/*      */         case null:
/*  213 */           return deserializeFromEmbedded(p, ctxt);
/*      */         case null:
/*      */         case null:
/*  216 */           return deserializeFromBoolean(p, ctxt);
/*      */         case null:
/*  218 */           return deserializeFromNull(p, ctxt);
/*      */         
/*      */         case null:
/*  221 */           return _deserializeFromArray(p, ctxt);
/*      */         case null:
/*      */         case null:
/*  224 */           if (this._vanillaProcessing) {
/*  225 */             return vanillaDeserialize(p, ctxt, t);
/*      */           }
/*  227 */           if (this._objectIdReader != null) {
/*  228 */             return deserializeWithObjectId(p, ctxt);
/*      */           }
/*  230 */           return deserializeFromObject(p, ctxt);
/*      */       } 
/*      */     
/*      */     }
/*  234 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected Object _missingToken(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  239 */     throw ctxt.endOfInputException(handledType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*      */     String propName;
/*  251 */     p.setCurrentValue(bean);
/*  252 */     if (this._injectables != null) {
/*  253 */       injectValues(ctxt, bean);
/*      */     }
/*  255 */     if (this._unwrappedPropertyHandler != null) {
/*  256 */       return deserializeWithUnwrapped(p, ctxt, bean);
/*      */     }
/*  258 */     if (this._externalTypeIdHandler != null) {
/*  259 */       return deserializeWithExternalTypeId(p, ctxt, bean);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  264 */     if (p.isExpectedStartObjectToken()) {
/*  265 */       propName = p.nextFieldName();
/*  266 */       if (propName == null) {
/*  267 */         return bean;
/*      */       }
/*      */     }
/*  270 */     else if (p.hasTokenId(5)) {
/*  271 */       propName = p.currentName();
/*      */     } else {
/*  273 */       return bean;
/*      */     } 
/*      */     
/*  276 */     if (this._needViewProcesing) {
/*  277 */       Class<?> view = ctxt.getActiveView();
/*  278 */       if (view != null) {
/*  279 */         return deserializeWithView(p, ctxt, bean, view);
/*      */       }
/*      */     } 
/*      */     while (true) {
/*  283 */       p.nextToken();
/*  284 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */       
/*  286 */       if (prop != null) {
/*      */         try {
/*  288 */           prop.deserializeAndSet(p, ctxt, bean);
/*  289 */         } catch (Exception e) {
/*  290 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } else {
/*      */         
/*  294 */         handleUnknownVanilla(p, ctxt, bean, propName);
/*  295 */       }  if ((propName = p.nextFieldName()) == null) {
/*  296 */         return bean;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Object vanillaDeserialize(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/*  313 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */     
/*  315 */     p.setCurrentValue(bean);
/*  316 */     if (p.hasTokenId(5)) {
/*  317 */       String propName = p.currentName();
/*      */       do {
/*  319 */         p.nextToken();
/*  320 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */         
/*  322 */         if (prop != null)
/*      */         { try {
/*  324 */             prop.deserializeAndSet(p, ctxt, bean);
/*  325 */           } catch (Exception e) {
/*  326 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }  }
/*      */         else
/*      */         
/*  330 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  331 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  333 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  349 */     if (this._objectIdReader != null && this._objectIdReader.maySerializeAsObject() && 
/*  350 */       p.hasTokenId(5) && this._objectIdReader
/*  351 */       .isValidReferencePropertyName(p.currentName(), p)) {
/*  352 */       return deserializeFromObjectId(p, ctxt);
/*      */     }
/*      */     
/*  355 */     if (this._nonStandardCreation) {
/*  356 */       if (this._unwrappedPropertyHandler != null) {
/*  357 */         return deserializeWithUnwrapped(p, ctxt);
/*      */       }
/*  359 */       if (this._externalTypeIdHandler != null) {
/*  360 */         return deserializeWithExternalTypeId(p, ctxt);
/*      */       }
/*  362 */       Object object = deserializeFromObjectUsingNonDefault(p, ctxt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  375 */       return object;
/*      */     } 
/*  377 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */     
/*  379 */     p.setCurrentValue(bean);
/*  380 */     if (p.canReadObjectId()) {
/*  381 */       Object id = p.getObjectId();
/*  382 */       if (id != null) {
/*  383 */         _handleTypedObjectId(p, ctxt, bean, id);
/*      */       }
/*      */     } 
/*  386 */     if (this._injectables != null) {
/*  387 */       injectValues(ctxt, bean);
/*      */     }
/*  389 */     if (this._needViewProcesing) {
/*  390 */       Class<?> view = ctxt.getActiveView();
/*  391 */       if (view != null) {
/*  392 */         return deserializeWithView(p, ctxt, bean, view);
/*      */       }
/*      */     } 
/*  395 */     if (p.hasTokenId(5)) {
/*  396 */       String propName = p.currentName();
/*      */       do {
/*  398 */         p.nextToken();
/*  399 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  400 */         if (prop != null)
/*      */         { try {
/*  402 */             prop.deserializeAndSet(p, ctxt, bean);
/*  403 */           } catch (Exception e) {
/*  404 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }  }
/*      */         else
/*      */         
/*  408 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  409 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  411 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeUsingPropertyBased(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Object bean;
/*  426 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*  427 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*  428 */     TokenBuffer unknown = null;
/*  429 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*      */     
/*  431 */     JsonToken t = p.currentToken();
/*  432 */     List<BeanReferring> referrings = null;
/*  433 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  434 */       String propName = p.currentName();
/*  435 */       p.nextToken();
/*  436 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/*  438 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */ 
/*      */         
/*  442 */         if (creatorProp != null) {
/*      */ 
/*      */           
/*  445 */           if (activeView != null && !creatorProp.visibleInView(activeView)) {
/*  446 */             p.skipChildren();
/*      */           } else {
/*      */             
/*  449 */             Object value = _deserializeWithErrorWrapping(p, ctxt, creatorProp);
/*  450 */             if (buffer.assignParameter(creatorProp, value)) {
/*  451 */               Object object; p.nextToken();
/*      */               
/*      */               try {
/*  454 */                 object = creator.build(ctxt, buffer);
/*  455 */               } catch (Exception e) {
/*  456 */                 object = wrapInstantiationProblem(e, ctxt);
/*      */               } 
/*  458 */               if (object == null) {
/*  459 */                 return ctxt.handleInstantiationProblem(handledType(), null, 
/*  460 */                     _creatorReturnedNullException());
/*      */               }
/*      */               
/*  463 */               p.setCurrentValue(object);
/*      */ 
/*      */               
/*  466 */               if (object.getClass() != this._beanType.getRawClass()) {
/*  467 */                 return handlePolymorphic(p, ctxt, object, unknown);
/*      */               }
/*  469 */               if (unknown != null) {
/*  470 */                 object = handleUnknownProperties(ctxt, object, unknown);
/*      */               }
/*      */               
/*  473 */               return deserialize(p, ctxt, object);
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  478 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/*  479 */           if (prop != null) {
/*      */             try {
/*  481 */               buffer.bufferProperty(prop, _deserializeWithErrorWrapping(p, ctxt, prop));
/*  482 */             } catch (UnresolvedForwardReference reference) {
/*      */ 
/*      */ 
/*      */               
/*  486 */               BeanReferring referring = handleUnresolvedReference(ctxt, prop, buffer, reference);
/*      */               
/*  488 */               if (referrings == null) {
/*  489 */                 referrings = new ArrayList<>();
/*      */               }
/*  491 */               referrings.add(referring);
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  496 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  497 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */           
/*      */           }
/*  501 */           else if (this._anySetter != null) {
/*      */             try {
/*  503 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(p, ctxt));
/*  504 */             } catch (Exception e) {
/*  505 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  510 */             if (unknown == null) {
/*  511 */               unknown = new TokenBuffer(p, ctxt);
/*      */             }
/*  513 */             unknown.writeFieldName(propName);
/*  514 */             unknown.copyCurrentStructure(p);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */     try {
/*  520 */       bean = creator.build(ctxt, buffer);
/*  521 */     } catch (Exception e) {
/*  522 */       wrapInstantiationProblem(e, ctxt);
/*  523 */       bean = null;
/*      */     } 
/*      */     
/*  526 */     if (this._injectables != null) {
/*  527 */       injectValues(ctxt, bean);
/*      */     }
/*      */     
/*  530 */     if (referrings != null) {
/*  531 */       for (BeanReferring referring : referrings) {
/*  532 */         referring.setBean(bean);
/*      */       }
/*      */     }
/*  535 */     if (unknown != null) {
/*      */       
/*  537 */       if (bean.getClass() != this._beanType.getRawClass()) {
/*  538 */         return handlePolymorphic((JsonParser)null, ctxt, bean, unknown);
/*      */       }
/*      */       
/*  541 */       return handleUnknownProperties(ctxt, bean, unknown);
/*      */     } 
/*  543 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BeanReferring handleUnresolvedReference(DeserializationContext ctxt, SettableBeanProperty prop, PropertyValueBuffer buffer, UnresolvedForwardReference reference) throws JsonMappingException {
/*  555 */     BeanReferring referring = new BeanReferring(ctxt, reference, prop.getType(), buffer, prop);
/*  556 */     reference.getRoid().appendReferring(referring);
/*  557 */     return referring;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _deserializeWithErrorWrapping(JsonParser p, DeserializationContext ctxt, SettableBeanProperty prop) throws IOException {
/*      */     try {
/*  565 */       return prop.deserialize(p, ctxt);
/*  566 */     } catch (Exception e) {
/*  567 */       wrapAndThrow(e, this._beanType.getRawClass(), prop.getName(), ctxt);
/*      */       
/*  569 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeFromNull(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  587 */     if (p.requiresCustomCodec()) {
/*      */       
/*  589 */       TokenBuffer tb = new TokenBuffer(p, ctxt);
/*  590 */       tb.writeEndObject();
/*  591 */       JsonParser p2 = tb.asParser(p);
/*  592 */       p2.nextToken();
/*      */ 
/*      */       
/*  595 */       Object ob = this._vanillaProcessing ? vanillaDeserialize(p2, ctxt, JsonToken.END_OBJECT) : deserializeFromObject(p2, ctxt);
/*  596 */       p2.close();
/*  597 */       return ob;
/*      */     } 
/*  599 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  606 */     JsonDeserializer<Object> delegateDeser = this._arrayDelegateDeserializer;
/*      */     
/*  608 */     if (delegateDeser != null || (delegateDeser = this._delegateDeserializer) != null) {
/*  609 */       Object bean = this._valueInstantiator.createUsingArrayDelegate(ctxt, delegateDeser
/*  610 */           .deserialize(p, ctxt));
/*  611 */       if (this._injectables != null) {
/*  612 */         injectValues(ctxt, bean);
/*      */       }
/*  614 */       return bean;
/*      */     } 
/*  616 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/*  617 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/*  619 */     if (unwrap || act != CoercionAction.Fail) {
/*  620 */       JsonToken t = p.nextToken();
/*  621 */       if (t == JsonToken.END_ARRAY) {
/*  622 */         switch (act) {
/*      */           case AsEmpty:
/*  624 */             return getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/*  627 */             return getNullValue(ctxt);
/*      */         } 
/*      */         
/*  630 */         return ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */       } 
/*  632 */       if (unwrap) {
/*  633 */         Object value = deserialize(p, ctxt);
/*  634 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/*  635 */           handleMissingEndArrayForSingle(p, ctxt);
/*      */         }
/*  637 */         return value;
/*      */       } 
/*      */     } 
/*  640 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object deserializeWithView(JsonParser p, DeserializationContext ctxt, Object bean, Class<?> activeView) throws IOException {
/*  653 */     if (p.hasTokenId(5)) {
/*  654 */       String propName = p.currentName();
/*      */       do {
/*  656 */         p.nextToken();
/*      */         
/*  658 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  659 */         if (prop != null)
/*  660 */         { if (!prop.visibleInView(activeView)) {
/*  661 */             p.skipChildren();
/*      */           } else {
/*      */             
/*      */             try {
/*  665 */               prop.deserializeAndSet(p, ctxt, bean);
/*  666 */             } catch (Exception e) {
/*  667 */               wrapAndThrow(e, bean, propName, ctxt);
/*      */             } 
/*      */           }  }
/*      */         else
/*  671 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  672 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  674 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  691 */     if (this._delegateDeserializer != null) {
/*  692 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer.deserialize(p, ctxt));
/*      */     }
/*  694 */     if (this._propertyBasedCreator != null) {
/*  695 */       return deserializeUsingPropertyBasedWithUnwrapped(p, ctxt);
/*      */     }
/*  697 */     TokenBuffer tokens = new TokenBuffer(p, ctxt);
/*  698 */     tokens.writeStartObject();
/*  699 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */ 
/*      */     
/*  702 */     p.setCurrentValue(bean);
/*      */     
/*  704 */     if (this._injectables != null) {
/*  705 */       injectValues(ctxt, bean);
/*      */     }
/*  707 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  708 */     String propName = p.hasTokenId(5) ? p.currentName() : null;
/*      */     
/*  710 */     for (; propName != null; propName = p.nextFieldName()) {
/*  711 */       p.nextToken();
/*  712 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  713 */       if (prop != null) {
/*  714 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  715 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  719 */             prop.deserializeAndSet(p, ctxt, bean);
/*  720 */           } catch (Exception e) {
/*  721 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  726 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  727 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  734 */       else if (this._anySetter == null) {
/*      */         
/*  736 */         tokens.writeFieldName(propName);
/*  737 */         tokens.copyCurrentStructure(p);
/*      */       }
/*      */       else {
/*      */         
/*  741 */         TokenBuffer b2 = TokenBuffer.asCopyOfValue(p);
/*  742 */         tokens.writeFieldName(propName);
/*  743 */         tokens.append(b2);
/*      */         try {
/*  745 */           this._anySetter.deserializeAndSet(b2.asParserOnFirstToken(), ctxt, bean, propName);
/*  746 */         } catch (Exception e) {
/*  747 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } 
/*  750 */     }  tokens.writeEndObject();
/*  751 */     this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*  752 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*  760 */     JsonToken t = p.currentToken();
/*  761 */     if (t == JsonToken.START_OBJECT) {
/*  762 */       t = p.nextToken();
/*      */     }
/*  764 */     TokenBuffer tokens = new TokenBuffer(p, ctxt);
/*  765 */     tokens.writeStartObject();
/*  766 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  767 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  768 */       String propName = p.currentName();
/*  769 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  770 */       p.nextToken();
/*  771 */       if (prop != null) {
/*  772 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  773 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  777 */             prop.deserializeAndSet(p, ctxt, bean);
/*  778 */           } catch (Exception e) {
/*  779 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         } 
/*  783 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  784 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  791 */       else if (this._anySetter == null) {
/*      */         
/*  793 */         tokens.writeFieldName(propName);
/*  794 */         tokens.copyCurrentStructure(p);
/*      */       } else {
/*      */         
/*  797 */         TokenBuffer b2 = TokenBuffer.asCopyOfValue(p);
/*  798 */         tokens.writeFieldName(propName);
/*  799 */         tokens.append(b2);
/*      */         try {
/*  801 */           this._anySetter.deserializeAndSet(b2.asParserOnFirstToken(), ctxt, bean, propName);
/*  802 */         } catch (Exception e) {
/*  803 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  808 */     tokens.writeEndObject();
/*  809 */     this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*  810 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeUsingPropertyBasedWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Object bean;
/*  821 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*  822 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*      */     
/*  824 */     TokenBuffer tokens = new TokenBuffer(p, ctxt);
/*  825 */     tokens.writeStartObject();
/*      */     
/*  827 */     JsonToken t = p.currentToken();
/*  828 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  829 */       String propName = p.currentName();
/*  830 */       p.nextToken();
/*      */       
/*  832 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/*  834 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */         
/*  837 */         if (creatorProp != null) {
/*      */           
/*  839 */           if (buffer.assignParameter(creatorProp, 
/*  840 */               _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
/*  841 */             Object object; t = p.nextToken();
/*      */             
/*      */             try {
/*  844 */               object = creator.build(ctxt, buffer);
/*  845 */             } catch (Exception e) {
/*  846 */               object = wrapInstantiationProblem(e, ctxt);
/*      */             } 
/*      */             
/*  849 */             p.setCurrentValue(object);
/*      */             
/*  851 */             while (t == JsonToken.FIELD_NAME) {
/*      */               
/*  853 */               tokens.copyCurrentStructure(p);
/*  854 */               t = p.nextToken();
/*      */             } 
/*      */ 
/*      */             
/*  858 */             if (t != JsonToken.END_OBJECT)
/*  859 */               ctxt.reportWrongTokenException((JsonDeserializer)this, JsonToken.END_OBJECT, "Attempted to unwrap '%s' value", new Object[] {
/*      */                     
/*  861 */                     handledType().getName()
/*      */                   }); 
/*  863 */             tokens.writeEndObject();
/*  864 */             if (object.getClass() != this._beanType.getRawClass()) {
/*      */ 
/*      */               
/*  867 */               ctxt.reportInputMismatch((BeanProperty)creatorProp, "Cannot create polymorphic instances with unwrapped values", new Object[0]);
/*      */               
/*  869 */               return null;
/*      */             } 
/*  871 */             return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, object, tokens);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  876 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/*  877 */           if (prop != null) {
/*  878 */             buffer.bufferProperty(prop, _deserializeWithErrorWrapping(p, ctxt, prop));
/*      */ 
/*      */           
/*      */           }
/*  882 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  883 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  890 */           else if (this._anySetter == null) {
/*      */             
/*  892 */             tokens.writeFieldName(propName);
/*  893 */             tokens.copyCurrentStructure(p);
/*      */           } else {
/*      */             
/*  896 */             TokenBuffer b2 = TokenBuffer.asCopyOfValue(p);
/*  897 */             tokens.writeFieldName(propName);
/*  898 */             tokens.append(b2);
/*      */             try {
/*  900 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter
/*  901 */                   .deserialize(b2.asParserOnFirstToken(), ctxt));
/*  902 */             } catch (Exception e) {
/*  903 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  912 */       bean = creator.build(ctxt, buffer);
/*  913 */     } catch (Exception e) {
/*  914 */       wrapInstantiationProblem(e, ctxt);
/*  915 */       return null;
/*      */     } 
/*  917 */     return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  930 */     if (this._propertyBasedCreator != null) {
/*  931 */       return deserializeUsingPropertyBasedWithExternalTypeId(p, ctxt);
/*      */     }
/*  933 */     if (this._delegateDeserializer != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  939 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/*  940 */           .deserialize(p, ctxt));
/*      */     }
/*      */     
/*  943 */     return deserializeWithExternalTypeId(p, ctxt, this._valueInstantiator.createUsingDefault(ctxt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*  950 */     return _deserializeWithExternalTypeId(p, ctxt, bean, this._externalTypeIdHandler
/*  951 */         .start());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean, ExternalTypeHandler ext) throws IOException {
/*  958 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  959 */     for (JsonToken t = p.currentToken(); t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  960 */       String propName = p.currentName();
/*  961 */       t = p.nextToken();
/*  962 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  963 */       if (prop != null) {
/*      */         
/*  965 */         if (t.isScalarValue()) {
/*  966 */           ext.handleTypePropertyValue(p, ctxt, propName, bean);
/*      */         }
/*  968 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  969 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  973 */             prop.deserializeAndSet(p, ctxt, bean);
/*  974 */           } catch (Exception e) {
/*  975 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  980 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  981 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */       
/*      */       }
/*  985 */       else if (!ext.handlePropertyValue(p, ctxt, propName, bean)) {
/*      */ 
/*      */ 
/*      */         
/*  989 */         if (this._anySetter != null) {
/*      */           try {
/*  991 */             this._anySetter.deserializeAndSet(p, ctxt, bean, propName);
/*  992 */           } catch (Exception e) {
/*  993 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  998 */           handleUnknownProperty(p, ctxt, bean, propName);
/*      */         } 
/*      */       } 
/* 1001 */     }  return ext.complete(p, ctxt, bean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeUsingPropertyBasedWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1009 */     ExternalTypeHandler ext = this._externalTypeIdHandler.start();
/* 1010 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 1011 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/* 1012 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*      */     
/* 1014 */     JsonToken t = p.currentToken();
/* 1015 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 1016 */       String propName = p.currentName();
/* 1017 */       t = p.nextToken();
/*      */       
/* 1019 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/* 1021 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */         
/* 1024 */         if (creatorProp != null) {
/*      */ 
/*      */ 
/*      */           
/* 1028 */           if (!ext.handlePropertyValue(p, ctxt, propName, null))
/*      */           {
/*      */ 
/*      */             
/* 1032 */             if (buffer.assignParameter(creatorProp, 
/* 1033 */                 _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
/* 1034 */               Object bean; t = p.nextToken();
/*      */               
/*      */               try {
/* 1037 */                 bean = creator.build(ctxt, buffer);
/* 1038 */               } catch (Exception e) {
/* 1039 */                 wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */               } 
/*      */               
/* 1042 */               if (bean.getClass() != this._beanType.getRawClass())
/*      */               {
/*      */                 
/* 1045 */                 return ctxt.reportBadDefinition(this._beanType, String.format("Cannot create polymorphic instances with external type ids (%s -> %s)", new Object[] { this._beanType, bean
/*      */                         
/* 1047 */                         .getClass() }));
/*      */               }
/* 1049 */               return _deserializeWithExternalTypeId(p, ctxt, bean, ext);
/*      */             }
/*      */           
/*      */           }
/*      */         } else {
/*      */           
/* 1055 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1056 */           if (prop != null) {
/*      */             
/* 1058 */             if (t.isScalarValue()) {
/* 1059 */               ext.handleTypePropertyValue(p, ctxt, propName, null);
/*      */             }
/*      */             
/* 1062 */             if (activeView != null && !prop.visibleInView(activeView)) {
/* 1063 */               p.skipChildren();
/*      */             } else {
/* 1065 */               buffer.bufferProperty(prop, prop.deserialize(p, ctxt));
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1070 */           else if (!ext.handlePropertyValue(p, ctxt, propName, null)) {
/*      */ 
/*      */ 
/*      */             
/* 1074 */             if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 1075 */               handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */             
/*      */             }
/* 1079 */             else if (this._anySetter != null) {
/* 1080 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter
/* 1081 */                   .deserialize(p, ctxt));
/*      */             }
/*      */             else {
/*      */               
/* 1085 */               handleUnknownProperty(p, ctxt, this._valueClass, propName);
/*      */             } 
/*      */           } 
/*      */         }  } 
/*      */     }  try {
/* 1090 */       return ext.complete(p, ctxt, buffer, creator);
/* 1091 */     } catch (Exception e) {
/* 1092 */       return wrapInstantiationProblem(e, ctxt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Exception _creatorReturnedNullException() {
/* 1103 */     if (this._nullFromCreator == null) {
/* 1104 */       this._nullFromCreator = new NullPointerException("JSON Creator returned null");
/*      */     }
/* 1106 */     return this._nullFromCreator;
/*      */   }
/*      */ 
/*      */   
/*      */   static class BeanReferring
/*      */     extends ReadableObjectId.Referring
/*      */   {
/*      */     private final DeserializationContext _context;
/*      */     
/*      */     private final SettableBeanProperty _prop;
/*      */     
/*      */     private Object _bean;
/*      */ 
/*      */     
/*      */     BeanReferring(DeserializationContext ctxt, UnresolvedForwardReference ref, JavaType valueType, PropertyValueBuffer buffer, SettableBeanProperty prop) {
/* 1121 */       super(ref, valueType);
/* 1122 */       this._context = ctxt;
/* 1123 */       this._prop = prop;
/*      */     }
/*      */     
/*      */     public void setBean(Object bean) {
/* 1127 */       this._bean = bean;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 1133 */       if (this._bean == null) {
/* 1134 */         this._context.reportInputMismatch((BeanProperty)this._prop, "Cannot resolve ObjectId forward reference using property '%s' (of type %s): Bean not yet resolved", new Object[] { this._prop
/*      */               
/* 1136 */               .getName(), this._prop.getDeclaringClass().getName() });
/*      */       }
/* 1138 */       this._prop.set(this._bean, value);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */