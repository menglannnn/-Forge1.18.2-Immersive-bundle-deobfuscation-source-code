/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.ResolvedType;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializable;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class TypeBase extends JavaType implements JsonSerializable {
/*     */   private static final long serialVersionUID = 1L;
/*  20 */   private static final TypeBindings NO_BINDINGS = TypeBindings.emptyBindings();
/*  21 */   private static final JavaType[] NO_TYPES = new JavaType[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType _superClass;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType[] _superInterfaces;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TypeBindings _bindings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   volatile transient String _canonicalName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBase(Class<?> raw, TypeBindings bindings, JavaType superClass, JavaType[] superInts, int hash, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  48 */     super(raw, hash, valueHandler, typeHandler, asStatic);
/*  49 */     this._bindings = (bindings == null) ? NO_BINDINGS : bindings;
/*  50 */     this._superClass = superClass;
/*  51 */     this._superInterfaces = superInts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBase(TypeBase base) {
/*  60 */     super(base);
/*  61 */     this._superClass = base._superClass;
/*  62 */     this._superInterfaces = base._superInterfaces;
/*  63 */     this._bindings = base._bindings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toCanonical() {
/*  69 */     String str = this._canonicalName;
/*  70 */     if (str == null) {
/*  71 */       str = buildCanonicalName();
/*     */     }
/*  73 */     return str;
/*     */   }
/*     */   
/*     */   protected String buildCanonicalName() {
/*  77 */     return this._class.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBindings getBindings() {
/*  88 */     return this._bindings;
/*     */   }
/*     */ 
/*     */   
/*     */   public int containedTypeCount() {
/*  93 */     return this._bindings.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType containedType(int index) {
/*  98 */     return this._bindings.getBoundType(index);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String containedTypeName(int index) {
/* 104 */     return this._bindings.getBoundName(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getSuperClass() {
/* 109 */     return this._superClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<JavaType> getInterfaces() {
/* 114 */     if (this._superInterfaces == null) {
/* 115 */       return Collections.emptyList();
/*     */     }
/* 117 */     switch (this._superInterfaces.length) {
/*     */       case 0:
/* 119 */         return Collections.emptyList();
/*     */       case 1:
/* 121 */         return Collections.singletonList(this._superInterfaces[0]);
/*     */     } 
/* 123 */     return Arrays.asList(this._superInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final JavaType findSuperType(Class<?> rawTarget) {
/* 129 */     if (rawTarget == this._class) {
/* 130 */       return this;
/*     */     }
/*     */     
/* 133 */     if (rawTarget.isInterface() && this._superInterfaces != null) {
/* 134 */       for (int i = 0, count = this._superInterfaces.length; i < count; i++) {
/* 135 */         JavaType type = this._superInterfaces[i].findSuperType(rawTarget);
/* 136 */         if (type != null) {
/* 137 */           return type;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 142 */     if (this._superClass != null) {
/* 143 */       JavaType type = this._superClass.findSuperType(rawTarget);
/* 144 */       if (type != null) {
/* 145 */         return type;
/*     */       }
/*     */     } 
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType[] findTypeParameters(Class<?> expType) {
/* 154 */     JavaType match = findSuperType(expType);
/* 155 */     if (match == null) {
/* 156 */       return NO_TYPES;
/*     */     }
/* 158 */     return match.getBindings().typeParameterArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 172 */     WritableTypeId typeIdDef = new WritableTypeId(this, JsonToken.VALUE_STRING);
/* 173 */     typeSer.writeTypePrefix(g, typeIdDef);
/* 174 */     serialize(g, provider);
/* 175 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(JsonGenerator gen, SerializerProvider provider) throws IOException, JsonProcessingException {
/* 182 */     gen.writeString(toCanonical());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static StringBuilder _classSignature(Class<?> cls, StringBuilder sb, boolean trailingSemicolon) {
/* 198 */     if (cls.isPrimitive()) {
/* 199 */       if (cls == boolean.class) {
/* 200 */         sb.append('Z');
/* 201 */       } else if (cls == byte.class) {
/* 202 */         sb.append('B');
/*     */       }
/* 204 */       else if (cls == short.class) {
/* 205 */         sb.append('S');
/*     */       }
/* 207 */       else if (cls == char.class) {
/* 208 */         sb.append('C');
/*     */       }
/* 210 */       else if (cls == int.class) {
/* 211 */         sb.append('I');
/*     */       }
/* 213 */       else if (cls == long.class) {
/* 214 */         sb.append('J');
/*     */       }
/* 216 */       else if (cls == float.class) {
/* 217 */         sb.append('F');
/*     */       }
/* 219 */       else if (cls == double.class) {
/* 220 */         sb.append('D');
/*     */       }
/* 222 */       else if (cls == void.class) {
/* 223 */         sb.append('V');
/*     */       } else {
/* 225 */         throw new IllegalStateException("Unrecognized primitive type: " + cls.getName());
/*     */       } 
/*     */     } else {
/* 228 */       sb.append('L');
/* 229 */       String name = cls.getName();
/* 230 */       for (int i = 0, len = name.length(); i < len; i++) {
/* 231 */         char c = name.charAt(i);
/* 232 */         if (c == '.') c = '/'; 
/* 233 */         sb.append(c);
/*     */       } 
/* 235 */       if (trailingSemicolon) {
/* 236 */         sb.append(';');
/*     */       }
/*     */     } 
/* 239 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static JavaType _bogusSuperClass(Class<?> cls) {
/* 252 */     Class<?> parent = cls.getSuperclass();
/* 253 */     if (parent == null) {
/* 254 */       return null;
/*     */     }
/* 256 */     return TypeFactory.unknownType();
/*     */   }
/*     */   
/*     */   protected boolean _hasNTypeParameters(int count) {
/* 260 */     TypeVariable[] arrayOfTypeVariable = this._class.getTypeParameters();
/* 261 */     return (arrayOfTypeVariable.length == count);
/*     */   }
/*     */   
/*     */   public abstract StringBuilder getGenericSignature(StringBuilder paramStringBuilder);
/*     */   
/*     */   public abstract StringBuilder getErasedSignature(StringBuilder paramStringBuilder);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databind\type\TypeBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */