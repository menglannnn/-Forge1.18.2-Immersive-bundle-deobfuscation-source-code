/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*     */ import com.fasterxml.jackson.databind.node.BooleanNode;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.node.NullNode;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.node.TextNode;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.RawValue;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseNodeDeserializer<T extends JsonNode>
/*     */   extends StdDeserializer<T>
/*     */ {
/*     */   protected final Boolean _supportsUpdates;
/*     */   
/*     */   public BaseNodeDeserializer(Class<T> vc, Boolean supportsUpdates) {
/* 175 */     super(vc);
/* 176 */     this._supportsUpdates = supportsUpdates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 185 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 190 */     return LogicalType.Untyped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 197 */     return true;
/*     */   }
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 201 */     return this._supportsUpdates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _handleDuplicateField(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory, String fieldName, ObjectNode objectNode, JsonNode oldValue, JsonNode newValue) throws JsonProcessingException {
/* 230 */     if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_READING_DUP_TREE_KEY))
/*     */     {
/*     */ 
/*     */       
/* 234 */       ctxt.reportInputMismatch(JsonNode.class, "Duplicate field '%s' for `ObjectNode`: not allowed when `DeserializationFeature.FAIL_ON_READING_DUP_TREE_KEY` enabled", new Object[] { fieldName });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES))
/*     */     {
/*     */       
/* 242 */       if (oldValue.isArray()) {
/* 243 */         ((ArrayNode)oldValue).add(newValue);
/* 244 */         objectNode.replace(fieldName, oldValue);
/*     */       } else {
/* 246 */         ArrayNode arr = nodeFactory.arrayNode();
/* 247 */         arr.add(oldValue);
/* 248 */         arr.add(newValue);
/* 249 */         objectNode.replace(fieldName, (JsonNode)arr);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ObjectNode deserializeObject(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory) throws IOException {
/* 267 */     ObjectNode node = nodeFactory.objectNode();
/* 268 */     String key = p.nextFieldName();
/* 269 */     for (; key != null; key = p.nextFieldName()) {
/*     */       ObjectNode objectNode; ArrayNode arrayNode; JsonNode jsonNode2; TextNode textNode; JsonNode jsonNode1; BooleanNode booleanNode2, booleanNode1; NullNode nullNode; JsonNode value;
/* 271 */       JsonToken t = p.nextToken();
/* 272 */       if (t == null) {
/* 273 */         t = JsonToken.NOT_AVAILABLE;
/*     */       }
/* 275 */       switch (t.id()) {
/*     */         case 1:
/* 277 */           objectNode = deserializeObject(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 3:
/* 280 */           arrayNode = deserializeArray(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 12:
/* 283 */           jsonNode2 = _fromEmbedded(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 6:
/* 286 */           textNode = nodeFactory.textNode(p.getText());
/*     */           break;
/*     */         case 7:
/* 289 */           jsonNode1 = _fromInt(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 9:
/* 292 */           booleanNode2 = nodeFactory.booleanNode(true);
/*     */           break;
/*     */         case 10:
/* 295 */           booleanNode1 = nodeFactory.booleanNode(false);
/*     */           break;
/*     */         case 11:
/* 298 */           nullNode = nodeFactory.nullNode();
/*     */           break;
/*     */         default:
/* 301 */           value = deserializeAny(p, ctxt, nodeFactory); break;
/*     */       } 
/* 303 */       JsonNode old = node.replace(key, value);
/* 304 */       if (old != null) {
/* 305 */         _handleDuplicateField(p, ctxt, nodeFactory, key, node, old, value);
/*     */       }
/*     */     } 
/*     */     
/* 309 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ObjectNode deserializeObjectAtName(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory) throws IOException {
/* 321 */     ObjectNode node = nodeFactory.objectNode();
/* 322 */     String key = p.currentName();
/* 323 */     for (; key != null; key = p.nextFieldName()) {
/*     */       ObjectNode objectNode; ArrayNode arrayNode; JsonNode jsonNode2; TextNode textNode; JsonNode jsonNode1; BooleanNode booleanNode2, booleanNode1; NullNode nullNode; JsonNode value;
/* 325 */       JsonToken t = p.nextToken();
/* 326 */       if (t == null) {
/* 327 */         t = JsonToken.NOT_AVAILABLE;
/*     */       }
/* 329 */       switch (t.id()) {
/*     */         case 1:
/* 331 */           objectNode = deserializeObject(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 3:
/* 334 */           arrayNode = deserializeArray(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 12:
/* 337 */           jsonNode2 = _fromEmbedded(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 6:
/* 340 */           textNode = nodeFactory.textNode(p.getText());
/*     */           break;
/*     */         case 7:
/* 343 */           jsonNode1 = _fromInt(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 9:
/* 346 */           booleanNode2 = nodeFactory.booleanNode(true);
/*     */           break;
/*     */         case 10:
/* 349 */           booleanNode1 = nodeFactory.booleanNode(false);
/*     */           break;
/*     */         case 11:
/* 352 */           nullNode = nodeFactory.nullNode();
/*     */           break;
/*     */         default:
/* 355 */           value = deserializeAny(p, ctxt, nodeFactory); break;
/*     */       } 
/* 357 */       JsonNode old = node.replace(key, value);
/* 358 */       if (old != null) {
/* 359 */         _handleDuplicateField(p, ctxt, nodeFactory, key, node, old, value);
/*     */       }
/*     */     } 
/*     */     
/* 363 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonNode updateObject(JsonParser p, DeserializationContext ctxt, ObjectNode node) throws IOException {
/* 376 */     if (p.isExpectedStartObjectToken()) {
/* 377 */       str = p.nextFieldName();
/*     */     } else {
/* 379 */       if (!p.hasToken(JsonToken.FIELD_NAME)) {
/* 380 */         return (JsonNode)deserialize(p, ctxt);
/*     */       }
/* 382 */       str = p.currentName();
/*     */     }  String str;
/* 384 */     for (; str != null; str = p.nextFieldName()) {
/*     */       ObjectNode objectNode; ArrayNode arrayNode; JsonNode jsonNode2; TextNode textNode; JsonNode jsonNode1; BooleanNode booleanNode2, booleanNode1; NullNode nullNode; JsonNode value;
/* 386 */       JsonToken t = p.nextToken();
/*     */ 
/*     */       
/* 389 */       JsonNode old = node.get(str);
/* 390 */       if (old != null) {
/* 391 */         if (old instanceof ObjectNode) {
/*     */ 
/*     */           
/* 394 */           if (t == JsonToken.START_OBJECT) {
/* 395 */             JsonNode newValue = updateObject(p, ctxt, (ObjectNode)old);
/* 396 */             if (newValue != old) {
/* 397 */               node.set(str, newValue);
/*     */             }
/*     */             continue;
/*     */           } 
/* 401 */         } else if (old instanceof ArrayNode) {
/*     */ 
/*     */           
/* 404 */           if (t == JsonToken.START_ARRAY) {
/* 405 */             JsonNode newValue = updateArray(p, ctxt, (ArrayNode)old);
/* 406 */             if (newValue != old) {
/* 407 */               node.set(str, newValue);
/*     */             }
/*     */             continue;
/*     */           } 
/*     */         } 
/*     */       }
/* 413 */       if (t == null) {
/* 414 */         t = JsonToken.NOT_AVAILABLE;
/*     */       }
/*     */       
/* 417 */       JsonNodeFactory nodeFactory = ctxt.getNodeFactory();
/* 418 */       switch (t.id()) {
/*     */         case 1:
/* 420 */           objectNode = deserializeObject(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 3:
/* 423 */           arrayNode = deserializeArray(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 12:
/* 426 */           jsonNode2 = _fromEmbedded(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 6:
/* 429 */           textNode = nodeFactory.textNode(p.getText());
/*     */           break;
/*     */         case 7:
/* 432 */           jsonNode1 = _fromInt(p, ctxt, nodeFactory);
/*     */           break;
/*     */         case 9:
/* 435 */           booleanNode2 = nodeFactory.booleanNode(true);
/*     */           break;
/*     */         case 10:
/* 438 */           booleanNode1 = nodeFactory.booleanNode(false);
/*     */           break;
/*     */         case 11:
/* 441 */           nullNode = nodeFactory.nullNode();
/*     */           break;
/*     */         default:
/* 444 */           value = deserializeAny(p, ctxt, nodeFactory);
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 455 */       node.set(str, value); continue;
/*     */     } 
/* 457 */     return (JsonNode)node;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ArrayNode deserializeArray(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory) throws IOException {
/* 463 */     ArrayNode node = nodeFactory.arrayNode();
/*     */     
/*     */     JsonToken t;
/* 466 */     while ((t = p.nextToken()) != null) {
/* 467 */       switch (t.id()) {
/*     */         case 1:
/* 469 */           node.add((JsonNode)deserializeObject(p, ctxt, nodeFactory));
/*     */           continue;
/*     */         case 3:
/* 472 */           node.add((JsonNode)deserializeArray(p, ctxt, nodeFactory));
/*     */           continue;
/*     */         case 4:
/* 475 */           return node;
/*     */         case 12:
/* 477 */           node.add(_fromEmbedded(p, ctxt, nodeFactory));
/*     */           continue;
/*     */         case 6:
/* 480 */           node.add((JsonNode)nodeFactory.textNode(p.getText()));
/*     */           continue;
/*     */         case 7:
/* 483 */           node.add(_fromInt(p, ctxt, nodeFactory));
/*     */           continue;
/*     */         case 9:
/* 486 */           node.add((JsonNode)nodeFactory.booleanNode(true));
/*     */           continue;
/*     */         case 10:
/* 489 */           node.add((JsonNode)nodeFactory.booleanNode(false));
/*     */           continue;
/*     */         case 11:
/* 492 */           node.add((JsonNode)nodeFactory.nullNode());
/*     */           continue;
/*     */       } 
/* 495 */       node.add(deserializeAny(p, ctxt, nodeFactory));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 500 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonNode updateArray(JsonParser p, DeserializationContext ctxt, ArrayNode node) throws IOException {
/* 512 */     JsonNodeFactory nodeFactory = ctxt.getNodeFactory();
/*     */     while (true) {
/* 514 */       JsonToken t = p.nextToken();
/* 515 */       switch (t.id()) {
/*     */         case 1:
/* 517 */           node.add((JsonNode)deserializeObject(p, ctxt, nodeFactory));
/*     */           continue;
/*     */         case 3:
/* 520 */           node.add((JsonNode)deserializeArray(p, ctxt, nodeFactory));
/*     */           continue;
/*     */         case 4:
/* 523 */           return (JsonNode)node;
/*     */         case 12:
/* 525 */           node.add(_fromEmbedded(p, ctxt, nodeFactory));
/*     */           continue;
/*     */         case 6:
/* 528 */           node.add((JsonNode)nodeFactory.textNode(p.getText()));
/*     */           continue;
/*     */         case 7:
/* 531 */           node.add(_fromInt(p, ctxt, nodeFactory));
/*     */           continue;
/*     */         case 9:
/* 534 */           node.add((JsonNode)nodeFactory.booleanNode(true));
/*     */           continue;
/*     */         case 10:
/* 537 */           node.add((JsonNode)nodeFactory.booleanNode(false));
/*     */           continue;
/*     */         case 11:
/* 540 */           node.add((JsonNode)nodeFactory.nullNode());
/*     */           continue;
/*     */       } 
/* 543 */       node.add(deserializeAny(p, ctxt, nodeFactory));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonNode deserializeAny(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory) throws IOException {
/* 552 */     switch (p.currentTokenId()) {
/*     */       case 2:
/* 554 */         return (JsonNode)nodeFactory.objectNode();
/*     */       case 5:
/* 556 */         return (JsonNode)deserializeObjectAtName(p, ctxt, nodeFactory);
/*     */       case 12:
/* 558 */         return _fromEmbedded(p, ctxt, nodeFactory);
/*     */       case 6:
/* 560 */         return (JsonNode)nodeFactory.textNode(p.getText());
/*     */       case 7:
/* 562 */         return _fromInt(p, ctxt, nodeFactory);
/*     */       case 8:
/* 564 */         return _fromFloat(p, ctxt, nodeFactory);
/*     */       case 9:
/* 566 */         return (JsonNode)nodeFactory.booleanNode(true);
/*     */       case 10:
/* 568 */         return (JsonNode)nodeFactory.booleanNode(false);
/*     */       case 11:
/* 570 */         return (JsonNode)nodeFactory.nullNode();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 587 */     return (JsonNode)ctxt.handleUnexpectedToken(handledType(), p);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonNode _fromInt(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory) throws IOException {
/*     */     JsonParser.NumberType nt;
/* 594 */     int feats = ctxt.getDeserializationFeatures();
/* 595 */     if ((feats & F_MASK_INT_COERCIONS) != 0) {
/* 596 */       if (DeserializationFeature.USE_BIG_INTEGER_FOR_INTS.enabledIn(feats)) {
/* 597 */         nt = JsonParser.NumberType.BIG_INTEGER;
/* 598 */       } else if (DeserializationFeature.USE_LONG_FOR_INTS.enabledIn(feats)) {
/* 599 */         nt = JsonParser.NumberType.LONG;
/*     */       } else {
/* 601 */         nt = p.getNumberType();
/*     */       } 
/*     */     } else {
/* 604 */       nt = p.getNumberType();
/*     */     } 
/* 606 */     if (nt == JsonParser.NumberType.INT) {
/* 607 */       return (JsonNode)nodeFactory.numberNode(p.getIntValue());
/*     */     }
/* 609 */     if (nt == JsonParser.NumberType.LONG) {
/* 610 */       return (JsonNode)nodeFactory.numberNode(p.getLongValue());
/*     */     }
/* 612 */     return (JsonNode)nodeFactory.numberNode(p.getBigIntegerValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonNode _fromFloat(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory) throws IOException {
/* 618 */     JsonParser.NumberType nt = p.getNumberType();
/* 619 */     if (nt == JsonParser.NumberType.BIG_DECIMAL) {
/* 620 */       return (JsonNode)nodeFactory.numberNode(p.getDecimalValue());
/*     */     }
/* 622 */     if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*     */ 
/*     */       
/* 625 */       if (p.isNaN()) {
/* 626 */         return (JsonNode)nodeFactory.numberNode(p.getDoubleValue());
/*     */       }
/* 628 */       return (JsonNode)nodeFactory.numberNode(p.getDecimalValue());
/*     */     } 
/* 630 */     if (nt == JsonParser.NumberType.FLOAT) {
/* 631 */       return (JsonNode)nodeFactory.numberNode(p.getFloatValue());
/*     */     }
/* 633 */     return (JsonNode)nodeFactory.numberNode(p.getDoubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonNode _fromEmbedded(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory) throws IOException {
/* 639 */     Object ob = p.getEmbeddedObject();
/* 640 */     if (ob == null) {
/* 641 */       return (JsonNode)nodeFactory.nullNode();
/*     */     }
/* 643 */     Class<?> type = ob.getClass();
/* 644 */     if (type == byte[].class) {
/* 645 */       return (JsonNode)nodeFactory.binaryNode((byte[])ob);
/*     */     }
/*     */     
/* 648 */     if (ob instanceof RawValue) {
/* 649 */       return (JsonNode)nodeFactory.rawValueNode((RawValue)ob);
/*     */     }
/* 651 */     if (ob instanceof JsonNode)
/*     */     {
/* 653 */       return (JsonNode)ob;
/*     */     }
/*     */     
/* 656 */     return (JsonNode)nodeFactory.pojoNode(ob);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databind\deser\std\BaseNodeDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */