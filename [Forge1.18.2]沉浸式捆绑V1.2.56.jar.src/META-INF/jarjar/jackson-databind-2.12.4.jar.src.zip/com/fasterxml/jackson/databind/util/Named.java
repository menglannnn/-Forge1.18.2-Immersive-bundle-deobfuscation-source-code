package com.fasterxml.jackson.databind.util;

public interface Named {
  String getName();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databin\\util\Named.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */