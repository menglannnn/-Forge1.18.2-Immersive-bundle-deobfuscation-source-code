/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoercionConfig
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 13 */   private static final int INPUT_SHAPE_COUNT = (CoercionInputShape.values()).length;
/*    */ 
/*    */   
/*    */   protected Boolean _acceptBlankAsEmpty;
/*    */ 
/*    */   
/*    */   protected final CoercionAction[] _coercionsByShape;
/*    */ 
/*    */ 
/*    */   
/*    */   public CoercionConfig() {
/* 24 */     this._coercionsByShape = new CoercionAction[INPUT_SHAPE_COUNT];
/* 25 */     this._acceptBlankAsEmpty = Boolean.valueOf(false);
/*    */   }
/*    */   
/*    */   protected CoercionConfig(CoercionConfig src) {
/* 29 */     this._acceptBlankAsEmpty = src._acceptBlankAsEmpty;
/* 30 */     this._coercionsByShape = Arrays.<CoercionAction>copyOf(src._coercionsByShape, src._coercionsByShape.length);
/*    */   }
/*    */ 
/*    */   
/*    */   public CoercionAction findAction(CoercionInputShape shape) {
/* 35 */     return this._coercionsByShape[shape.ordinal()];
/*    */   }
/*    */   
/*    */   public Boolean getAcceptBlankAsEmpty() {
/* 39 */     return this._acceptBlankAsEmpty;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.12.4.jar!\com\fasterxml\jackson\databind\cfg\CoercionConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */