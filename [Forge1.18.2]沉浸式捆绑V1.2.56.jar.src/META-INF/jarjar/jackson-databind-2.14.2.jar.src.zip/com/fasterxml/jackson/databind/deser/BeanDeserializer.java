/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanAsArrayDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*      */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BeanDeserializer
/*      */   extends BeanDeserializerBase
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected transient Exception _nullFromCreator;
/*      */   private volatile transient NameTransformer _currentlyTransforming;
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, boolean hasViews) {
/*   59 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, (Set<String>)null, hasViews);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, Set<String> includableProps, boolean hasViews) {
/*   73 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, includableProps, hasViews);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src) {
/*   82 */     super(src, src._ignoreAllUnknown);
/*      */   }
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src, boolean ignoreAllUnknown) {
/*   86 */     super(src, ignoreAllUnknown);
/*      */   }
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src, NameTransformer unwrapper) {
/*   90 */     super(src, unwrapper);
/*      */   }
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, ObjectIdReader oir) {
/*   94 */     super(src, oir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializer(BeanDeserializerBase src, Set<String> ignorableProps) {
/*  102 */     super(src, ignorableProps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, Set<String> ignorableProps, Set<String> includableProps) {
/*  109 */     super(src, ignorableProps, includableProps);
/*      */   }
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, BeanPropertyMap props) {
/*  113 */     super(src, props);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer transformer) {
/*  121 */     if (getClass() != BeanDeserializer.class) {
/*  122 */       return (JsonDeserializer<Object>)this;
/*      */     }
/*      */ 
/*      */     
/*  126 */     if (this._currentlyTransforming == transformer) {
/*  127 */       return (JsonDeserializer<Object>)this;
/*      */     }
/*  129 */     this._currentlyTransforming = transformer;
/*      */     
/*  131 */     try { return (JsonDeserializer<Object>)new BeanDeserializer(this, transformer); }
/*  132 */     finally { this._currentlyTransforming = null; }
/*      */   
/*      */   }
/*      */   
/*      */   public BeanDeserializer withObjectIdReader(ObjectIdReader oir) {
/*  137 */     return new BeanDeserializer(this, oir);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer withByNameInclusion(Set<String> ignorableProps, Set<String> includableProps) {
/*  143 */     return new BeanDeserializer(this, ignorableProps, includableProps);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withIgnoreAllUnknown(boolean ignoreUnknown) {
/*  148 */     return new BeanDeserializer(this, ignoreUnknown);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withBeanProperties(BeanPropertyMap props) {
/*  153 */     return new BeanDeserializer(this, props);
/*      */   }
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase asArrayDeserializer() {
/*  158 */     SettableBeanProperty[] props = this._beanProperties.getPropertiesInInsertionOrder();
/*  159 */     return (BeanDeserializerBase)new BeanAsArrayDeserializer(this, props);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  175 */     if (p.isExpectedStartObjectToken()) {
/*  176 */       if (this._vanillaProcessing) {
/*  177 */         return vanillaDeserialize(p, ctxt, p.nextToken());
/*      */       }
/*      */ 
/*      */       
/*  181 */       p.nextToken();
/*  182 */       if (this._objectIdReader != null) {
/*  183 */         return deserializeWithObjectId(p, ctxt);
/*      */       }
/*  185 */       return deserializeFromObject(p, ctxt);
/*      */     } 
/*  187 */     return _deserializeOther(p, ctxt, p.currentToken());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _deserializeOther(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/*  194 */     if (t != null) {
/*  195 */       switch (t) {
/*      */         case AsEmpty:
/*  197 */           return deserializeFromString(p, ctxt);
/*      */         case AsNull:
/*  199 */           return deserializeFromNumber(p, ctxt);
/*      */         case TryConvert:
/*  201 */           return deserializeFromDouble(p, ctxt);
/*      */         case null:
/*  203 */           return deserializeFromEmbedded(p, ctxt);
/*      */         case null:
/*      */         case null:
/*  206 */           return deserializeFromBoolean(p, ctxt);
/*      */         case null:
/*  208 */           return deserializeFromNull(p, ctxt);
/*      */         
/*      */         case null:
/*  211 */           return _deserializeFromArray(p, ctxt);
/*      */         case null:
/*      */         case null:
/*  214 */           if (this._vanillaProcessing) {
/*  215 */             return vanillaDeserialize(p, ctxt, t);
/*      */           }
/*  217 */           if (this._objectIdReader != null) {
/*  218 */             return deserializeWithObjectId(p, ctxt);
/*      */           }
/*  220 */           return deserializeFromObject(p, ctxt);
/*      */       } 
/*      */     
/*      */     }
/*  224 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected Object _missingToken(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  229 */     throw ctxt.endOfInputException(handledType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*      */     String propName;
/*  241 */     p.setCurrentValue(bean);
/*  242 */     if (this._injectables != null) {
/*  243 */       injectValues(ctxt, bean);
/*      */     }
/*  245 */     if (this._unwrappedPropertyHandler != null) {
/*  246 */       return deserializeWithUnwrapped(p, ctxt, bean);
/*      */     }
/*  248 */     if (this._externalTypeIdHandler != null) {
/*  249 */       return deserializeWithExternalTypeId(p, ctxt, bean);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  254 */     if (p.isExpectedStartObjectToken()) {
/*  255 */       propName = p.nextFieldName();
/*  256 */       if (propName == null) {
/*  257 */         return bean;
/*      */       }
/*      */     }
/*  260 */     else if (p.hasTokenId(5)) {
/*  261 */       propName = p.currentName();
/*      */     } else {
/*  263 */       return bean;
/*      */     } 
/*      */     
/*  266 */     if (this._needViewProcesing) {
/*  267 */       Class<?> view = ctxt.getActiveView();
/*  268 */       if (view != null) {
/*  269 */         return deserializeWithView(p, ctxt, bean, view);
/*      */       }
/*      */     } 
/*      */     while (true) {
/*  273 */       p.nextToken();
/*  274 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */       
/*  276 */       if (prop != null) {
/*      */         try {
/*  278 */           prop.deserializeAndSet(p, ctxt, bean);
/*  279 */         } catch (Exception e) {
/*  280 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } else {
/*      */         
/*  284 */         handleUnknownVanilla(p, ctxt, bean, propName);
/*  285 */       }  if ((propName = p.nextFieldName()) == null) {
/*  286 */         return bean;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Object vanillaDeserialize(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/*  303 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */     
/*  305 */     p.setCurrentValue(bean);
/*  306 */     if (p.hasTokenId(5)) {
/*  307 */       String propName = p.currentName();
/*      */       do {
/*  309 */         p.nextToken();
/*  310 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */         
/*  312 */         if (prop != null)
/*      */         { try {
/*  314 */             prop.deserializeAndSet(p, ctxt, bean);
/*  315 */           } catch (Exception e) {
/*  316 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }  }
/*      */         else
/*      */         
/*  320 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  321 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  323 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  339 */     if (this._objectIdReader != null && this._objectIdReader.maySerializeAsObject() && 
/*  340 */       p.hasTokenId(5) && this._objectIdReader
/*  341 */       .isValidReferencePropertyName(p.currentName(), p)) {
/*  342 */       return deserializeFromObjectId(p, ctxt);
/*      */     }
/*      */     
/*  345 */     if (this._nonStandardCreation) {
/*  346 */       if (this._unwrappedPropertyHandler != null) {
/*  347 */         return deserializeWithUnwrapped(p, ctxt);
/*      */       }
/*  349 */       if (this._externalTypeIdHandler != null) {
/*  350 */         return deserializeWithExternalTypeId(p, ctxt);
/*      */       }
/*  352 */       Object object = deserializeFromObjectUsingNonDefault(p, ctxt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  365 */       return object;
/*      */     } 
/*  367 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */     
/*  369 */     p.setCurrentValue(bean);
/*  370 */     if (p.canReadObjectId()) {
/*  371 */       Object id = p.getObjectId();
/*  372 */       if (id != null) {
/*  373 */         _handleTypedObjectId(p, ctxt, bean, id);
/*      */       }
/*      */     } 
/*  376 */     if (this._injectables != null) {
/*  377 */       injectValues(ctxt, bean);
/*      */     }
/*  379 */     if (this._needViewProcesing) {
/*  380 */       Class<?> view = ctxt.getActiveView();
/*  381 */       if (view != null) {
/*  382 */         return deserializeWithView(p, ctxt, bean, view);
/*      */       }
/*      */     } 
/*  385 */     if (p.hasTokenId(5)) {
/*  386 */       String propName = p.currentName();
/*      */       do {
/*  388 */         p.nextToken();
/*  389 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  390 */         if (prop != null)
/*      */         { try {
/*  392 */             prop.deserializeAndSet(p, ctxt, bean);
/*  393 */           } catch (Exception e) {
/*  394 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }  }
/*      */         else
/*      */         
/*  398 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  399 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  401 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeUsingPropertyBased(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Object bean;
/*  416 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*  417 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*  418 */     TokenBuffer unknown = null;
/*  419 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*      */     
/*  421 */     JsonToken t = p.currentToken();
/*  422 */     List<BeanReferring> referrings = null;
/*  423 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  424 */       String propName = p.currentName();
/*  425 */       p.nextToken();
/*  426 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/*  428 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */ 
/*      */         
/*  432 */         if (creatorProp != null) {
/*      */ 
/*      */           
/*  435 */           if (activeView != null && !creatorProp.visibleInView(activeView)) {
/*  436 */             p.skipChildren();
/*      */           } else {
/*      */             
/*  439 */             Object value = _deserializeWithErrorWrapping(p, ctxt, creatorProp);
/*  440 */             if (buffer.assignParameter(creatorProp, value)) {
/*  441 */               Object object; p.nextToken();
/*      */               
/*      */               try {
/*  444 */                 object = creator.build(ctxt, buffer);
/*  445 */               } catch (Exception e) {
/*  446 */                 object = wrapInstantiationProblem(e, ctxt);
/*      */               } 
/*  448 */               if (object == null) {
/*  449 */                 return ctxt.handleInstantiationProblem(handledType(), null, 
/*  450 */                     _creatorReturnedNullException());
/*      */               }
/*      */               
/*  453 */               p.setCurrentValue(object);
/*      */ 
/*      */               
/*  456 */               if (object.getClass() != this._beanType.getRawClass()) {
/*  457 */                 return handlePolymorphic(p, ctxt, object, unknown);
/*      */               }
/*  459 */               if (unknown != null) {
/*  460 */                 object = handleUnknownProperties(ctxt, object, unknown);
/*      */               }
/*      */               
/*  463 */               return deserialize(p, ctxt, object);
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  468 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/*  469 */           if (prop != null) {
/*      */             try {
/*  471 */               buffer.bufferProperty(prop, _deserializeWithErrorWrapping(p, ctxt, prop));
/*  472 */             } catch (UnresolvedForwardReference reference) {
/*      */ 
/*      */ 
/*      */               
/*  476 */               BeanReferring referring = handleUnresolvedReference(ctxt, prop, buffer, reference);
/*      */               
/*  478 */               if (referrings == null) {
/*  479 */                 referrings = new ArrayList<>();
/*      */               }
/*  481 */               referrings.add(referring);
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  486 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  487 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */           
/*      */           }
/*  491 */           else if (this._anySetter != null) {
/*      */             try {
/*  493 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(p, ctxt));
/*  494 */             } catch (Exception e) {
/*  495 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  503 */           else if (this._ignoreAllUnknown) {
/*      */             
/*  505 */             p.skipChildren();
/*      */           }
/*      */           else {
/*      */             
/*  509 */             if (unknown == null) {
/*  510 */               unknown = ctxt.bufferForInputBuffering(p);
/*      */             }
/*  512 */             unknown.writeFieldName(propName);
/*  513 */             unknown.copyCurrentStructure(p);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */     try {
/*  519 */       bean = creator.build(ctxt, buffer);
/*  520 */     } catch (Exception e) {
/*  521 */       wrapInstantiationProblem(e, ctxt);
/*  522 */       bean = null;
/*      */     } 
/*      */     
/*  525 */     if (this._injectables != null) {
/*  526 */       injectValues(ctxt, bean);
/*      */     }
/*      */     
/*  529 */     if (referrings != null) {
/*  530 */       for (BeanReferring referring : referrings) {
/*  531 */         referring.setBean(bean);
/*      */       }
/*      */     }
/*  534 */     if (unknown != null) {
/*      */       
/*  536 */       if (bean.getClass() != this._beanType.getRawClass()) {
/*  537 */         return handlePolymorphic((JsonParser)null, ctxt, bean, unknown);
/*      */       }
/*      */       
/*  540 */       return handleUnknownProperties(ctxt, bean, unknown);
/*      */     } 
/*  542 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BeanReferring handleUnresolvedReference(DeserializationContext ctxt, SettableBeanProperty prop, PropertyValueBuffer buffer, UnresolvedForwardReference reference) throws JsonMappingException {
/*  554 */     BeanReferring referring = new BeanReferring(ctxt, reference, prop.getType(), buffer, prop);
/*  555 */     reference.getRoid().appendReferring(referring);
/*  556 */     return referring;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _deserializeWithErrorWrapping(JsonParser p, DeserializationContext ctxt, SettableBeanProperty prop) throws IOException {
/*      */     try {
/*  564 */       return prop.deserialize(p, ctxt);
/*  565 */     } catch (Exception e) {
/*  566 */       wrapAndThrow(e, this._beanType.getRawClass(), prop.getName(), ctxt);
/*      */       
/*  568 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeFromNull(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  586 */     if (p.requiresCustomCodec()) {
/*      */       
/*  588 */       TokenBuffer tb = ctxt.bufferForInputBuffering(p);
/*  589 */       tb.writeEndObject();
/*  590 */       JsonParser p2 = tb.asParser(p);
/*  591 */       p2.nextToken();
/*      */ 
/*      */       
/*  594 */       Object ob = this._vanillaProcessing ? vanillaDeserialize(p2, ctxt, JsonToken.END_OBJECT) : deserializeFromObject(p2, ctxt);
/*  595 */       p2.close();
/*  596 */       return ob;
/*      */     } 
/*  598 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  605 */     JsonDeserializer<Object> delegateDeser = this._arrayDelegateDeserializer;
/*      */     
/*  607 */     if (delegateDeser != null || (delegateDeser = this._delegateDeserializer) != null) {
/*  608 */       Object bean = this._valueInstantiator.createUsingArrayDelegate(ctxt, delegateDeser
/*  609 */           .deserialize(p, ctxt));
/*  610 */       if (this._injectables != null) {
/*  611 */         injectValues(ctxt, bean);
/*      */       }
/*  613 */       return bean;
/*      */     } 
/*  615 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/*  616 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/*  618 */     if (unwrap || act != CoercionAction.Fail) {
/*  619 */       JsonToken unwrappedToken = p.nextToken();
/*  620 */       if (unwrappedToken == JsonToken.END_ARRAY) {
/*  621 */         switch (act) {
/*      */           case AsEmpty:
/*  623 */             return getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/*  626 */             return getNullValue(ctxt);
/*      */         } 
/*      */         
/*  629 */         return ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */       } 
/*  631 */       if (unwrap) {
/*      */ 
/*      */         
/*  634 */         if (unwrappedToken == JsonToken.START_ARRAY) {
/*  635 */           JavaType targetType = getValueType(ctxt);
/*  636 */           return ctxt.handleUnexpectedToken(targetType, JsonToken.START_ARRAY, p, "Cannot deserialize value of type %s from deeply-nested Array: only single wrapper allowed with `%s`", new Object[] {
/*      */                 
/*  638 */                 ClassUtil.getTypeDescription(targetType), "DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS"
/*      */               });
/*      */         } 
/*  641 */         Object value = deserialize(p, ctxt);
/*  642 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/*  643 */           handleMissingEndArrayForSingle(p, ctxt);
/*      */         }
/*  645 */         return value;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  650 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object deserializeWithView(JsonParser p, DeserializationContext ctxt, Object bean, Class<?> activeView) throws IOException {
/*  663 */     if (p.hasTokenId(5)) {
/*  664 */       String propName = p.currentName();
/*      */       do {
/*  666 */         p.nextToken();
/*      */         
/*  668 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  669 */         if (prop != null)
/*  670 */         { if (!prop.visibleInView(activeView)) {
/*  671 */             p.skipChildren();
/*      */           } else {
/*      */             
/*      */             try {
/*  675 */               prop.deserializeAndSet(p, ctxt, bean);
/*  676 */             } catch (Exception e) {
/*  677 */               wrapAndThrow(e, bean, propName, ctxt);
/*      */             } 
/*      */           }  }
/*      */         else
/*  681 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  682 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  684 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  701 */     if (this._delegateDeserializer != null) {
/*  702 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer.deserialize(p, ctxt));
/*      */     }
/*  704 */     if (this._propertyBasedCreator != null) {
/*  705 */       return deserializeUsingPropertyBasedWithUnwrapped(p, ctxt);
/*      */     }
/*  707 */     TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/*  708 */     tokens.writeStartObject();
/*  709 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */ 
/*      */     
/*  712 */     p.setCurrentValue(bean);
/*      */     
/*  714 */     if (this._injectables != null) {
/*  715 */       injectValues(ctxt, bean);
/*      */     }
/*  717 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  718 */     String propName = p.hasTokenId(5) ? p.currentName() : null;
/*      */     
/*  720 */     for (; propName != null; propName = p.nextFieldName()) {
/*  721 */       p.nextToken();
/*  722 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  723 */       if (prop != null) {
/*  724 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  725 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  729 */             prop.deserializeAndSet(p, ctxt, bean);
/*  730 */           } catch (Exception e) {
/*  731 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  736 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  737 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  744 */       else if (this._anySetter == null) {
/*      */         
/*  746 */         tokens.writeFieldName(propName);
/*  747 */         tokens.copyCurrentStructure(p);
/*      */       }
/*      */       else {
/*      */         
/*  751 */         TokenBuffer b2 = ctxt.bufferAsCopyOfValue(p);
/*  752 */         tokens.writeFieldName(propName);
/*  753 */         tokens.append(b2);
/*      */         try {
/*  755 */           this._anySetter.deserializeAndSet(b2.asParserOnFirstToken(), ctxt, bean, propName);
/*  756 */         } catch (Exception e) {
/*  757 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } 
/*  760 */     }  tokens.writeEndObject();
/*  761 */     this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*  762 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*  770 */     JsonToken t = p.currentToken();
/*  771 */     if (t == JsonToken.START_OBJECT) {
/*  772 */       t = p.nextToken();
/*      */     }
/*  774 */     TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/*  775 */     tokens.writeStartObject();
/*  776 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  777 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  778 */       String propName = p.currentName();
/*  779 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  780 */       p.nextToken();
/*  781 */       if (prop != null) {
/*  782 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  783 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  787 */             prop.deserializeAndSet(p, ctxt, bean);
/*  788 */           } catch (Exception e) {
/*  789 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         } 
/*  793 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  794 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  801 */       else if (this._anySetter == null) {
/*      */         
/*  803 */         tokens.writeFieldName(propName);
/*  804 */         tokens.copyCurrentStructure(p);
/*      */       } else {
/*      */         
/*  807 */         TokenBuffer b2 = ctxt.bufferAsCopyOfValue(p);
/*  808 */         tokens.writeFieldName(propName);
/*  809 */         tokens.append(b2);
/*      */         try {
/*  811 */           this._anySetter.deserializeAndSet(b2.asParserOnFirstToken(), ctxt, bean, propName);
/*  812 */         } catch (Exception e) {
/*  813 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  818 */     tokens.writeEndObject();
/*  819 */     this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*  820 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeUsingPropertyBasedWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Object bean;
/*  831 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*  832 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*      */     
/*  834 */     TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/*  835 */     tokens.writeStartObject();
/*      */     
/*  837 */     JsonToken t = p.currentToken();
/*  838 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  839 */       String propName = p.currentName();
/*  840 */       p.nextToken();
/*      */       
/*  842 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/*  844 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */         
/*  847 */         if (creatorProp != null) {
/*      */           
/*  849 */           if (buffer.assignParameter(creatorProp, 
/*  850 */               _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
/*  851 */             Object object; t = p.nextToken();
/*      */             
/*      */             try {
/*  854 */               object = creator.build(ctxt, buffer);
/*  855 */             } catch (Exception e) {
/*  856 */               object = wrapInstantiationProblem(e, ctxt);
/*      */             } 
/*      */             
/*  859 */             p.setCurrentValue(object);
/*      */             
/*  861 */             while (t == JsonToken.FIELD_NAME) {
/*      */               
/*  863 */               tokens.copyCurrentStructure(p);
/*  864 */               t = p.nextToken();
/*      */             } 
/*      */ 
/*      */             
/*  868 */             if (t != JsonToken.END_OBJECT)
/*  869 */               ctxt.reportWrongTokenException((JsonDeserializer)this, JsonToken.END_OBJECT, "Attempted to unwrap '%s' value", new Object[] {
/*      */                     
/*  871 */                     handledType().getName()
/*      */                   }); 
/*  873 */             tokens.writeEndObject();
/*  874 */             if (object.getClass() != this._beanType.getRawClass()) {
/*      */ 
/*      */               
/*  877 */               ctxt.reportInputMismatch((BeanProperty)creatorProp, "Cannot create polymorphic instances with unwrapped values", new Object[0]);
/*      */               
/*  879 */               return null;
/*      */             } 
/*  881 */             return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, object, tokens);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  886 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/*  887 */           if (prop != null) {
/*  888 */             buffer.bufferProperty(prop, _deserializeWithErrorWrapping(p, ctxt, prop));
/*      */ 
/*      */           
/*      */           }
/*  892 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  893 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  900 */           else if (this._anySetter == null) {
/*      */             
/*  902 */             tokens.writeFieldName(propName);
/*  903 */             tokens.copyCurrentStructure(p);
/*      */           } else {
/*      */             
/*  906 */             TokenBuffer b2 = ctxt.bufferAsCopyOfValue(p);
/*  907 */             tokens.writeFieldName(propName);
/*  908 */             tokens.append(b2);
/*      */             try {
/*  910 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter
/*  911 */                   .deserialize(b2.asParserOnFirstToken(), ctxt));
/*  912 */             } catch (Exception e) {
/*  913 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  922 */       bean = creator.build(ctxt, buffer);
/*  923 */     } catch (Exception e) {
/*  924 */       wrapInstantiationProblem(e, ctxt);
/*  925 */       return null;
/*      */     } 
/*  927 */     return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  940 */     if (this._propertyBasedCreator != null) {
/*  941 */       return deserializeUsingPropertyBasedWithExternalTypeId(p, ctxt);
/*      */     }
/*  943 */     if (this._delegateDeserializer != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  949 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/*  950 */           .deserialize(p, ctxt));
/*      */     }
/*      */     
/*  953 */     return deserializeWithExternalTypeId(p, ctxt, this._valueInstantiator.createUsingDefault(ctxt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*  960 */     return _deserializeWithExternalTypeId(p, ctxt, bean, this._externalTypeIdHandler
/*  961 */         .start());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean, ExternalTypeHandler ext) throws IOException {
/*  968 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  969 */     for (JsonToken t = p.currentToken(); t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  970 */       String propName = p.currentName();
/*  971 */       t = p.nextToken();
/*  972 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  973 */       if (prop != null) {
/*      */         
/*  975 */         if (t.isScalarValue()) {
/*  976 */           ext.handleTypePropertyValue(p, ctxt, propName, bean);
/*      */         }
/*  978 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  979 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  983 */             prop.deserializeAndSet(p, ctxt, bean);
/*  984 */           } catch (Exception e) {
/*  985 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  990 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  991 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */       
/*      */       }
/*  995 */       else if (!ext.handlePropertyValue(p, ctxt, propName, bean)) {
/*      */ 
/*      */ 
/*      */         
/*  999 */         if (this._anySetter != null) {
/*      */           try {
/* 1001 */             this._anySetter.deserializeAndSet(p, ctxt, bean, propName);
/* 1002 */           } catch (Exception e) {
/* 1003 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1008 */           handleUnknownProperty(p, ctxt, bean, propName);
/*      */         } 
/*      */       } 
/* 1011 */     }  return ext.complete(p, ctxt, bean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeUsingPropertyBasedWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1019 */     ExternalTypeHandler ext = this._externalTypeIdHandler.start();
/* 1020 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 1021 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/* 1022 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*      */     
/* 1024 */     JsonToken t = p.currentToken();
/* 1025 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 1026 */       String propName = p.currentName();
/* 1027 */       t = p.nextToken();
/*      */       
/* 1029 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/* 1031 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */         
/* 1034 */         if (creatorProp != null) {
/*      */ 
/*      */ 
/*      */           
/* 1038 */           if (!ext.handlePropertyValue(p, ctxt, propName, null))
/*      */           {
/*      */ 
/*      */             
/* 1042 */             if (buffer.assignParameter(creatorProp, 
/* 1043 */                 _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
/* 1044 */               Object bean; t = p.nextToken();
/*      */               
/*      */               try {
/* 1047 */                 bean = creator.build(ctxt, buffer);
/* 1048 */               } catch (Exception e) {
/* 1049 */                 wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */               } 
/*      */               
/* 1052 */               if (bean.getClass() != this._beanType.getRawClass())
/*      */               {
/*      */                 
/* 1055 */                 return ctxt.reportBadDefinition(this._beanType, String.format("Cannot create polymorphic instances with external type ids (%s -> %s)", new Object[] { this._beanType, bean
/*      */                         
/* 1057 */                         .getClass() }));
/*      */               }
/* 1059 */               return _deserializeWithExternalTypeId(p, ctxt, bean, ext);
/*      */             }
/*      */           
/*      */           }
/*      */         } else {
/*      */           
/* 1065 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1066 */           if (prop != null) {
/*      */             
/* 1068 */             if (t.isScalarValue()) {
/* 1069 */               ext.handleTypePropertyValue(p, ctxt, propName, null);
/*      */             }
/*      */             
/* 1072 */             if (activeView != null && !prop.visibleInView(activeView)) {
/* 1073 */               p.skipChildren();
/*      */             } else {
/* 1075 */               buffer.bufferProperty(prop, prop.deserialize(p, ctxt));
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1080 */           else if (!ext.handlePropertyValue(p, ctxt, propName, null)) {
/*      */ 
/*      */ 
/*      */             
/* 1084 */             if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 1085 */               handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */             
/*      */             }
/* 1089 */             else if (this._anySetter != null) {
/* 1090 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter
/* 1091 */                   .deserialize(p, ctxt));
/*      */             }
/*      */             else {
/*      */               
/* 1095 */               handleUnknownProperty(p, ctxt, this._valueClass, propName);
/*      */             } 
/*      */           } 
/*      */         }  } 
/*      */     }  try {
/* 1100 */       return ext.complete(p, ctxt, buffer, creator);
/* 1101 */     } catch (Exception e) {
/* 1102 */       return wrapInstantiationProblem(e, ctxt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Exception _creatorReturnedNullException() {
/* 1113 */     if (this._nullFromCreator == null) {
/* 1114 */       this._nullFromCreator = new NullPointerException("JSON Creator returned null");
/*      */     }
/* 1116 */     return this._nullFromCreator;
/*      */   }
/*      */ 
/*      */   
/*      */   static class BeanReferring
/*      */     extends ReadableObjectId.Referring
/*      */   {
/*      */     private final DeserializationContext _context;
/*      */     
/*      */     private final SettableBeanProperty _prop;
/*      */     
/*      */     private Object _bean;
/*      */ 
/*      */     
/*      */     BeanReferring(DeserializationContext ctxt, UnresolvedForwardReference ref, JavaType valueType, PropertyValueBuffer buffer, SettableBeanProperty prop) {
/* 1131 */       super(ref, valueType);
/* 1132 */       this._context = ctxt;
/* 1133 */       this._prop = prop;
/*      */     }
/*      */     
/*      */     public void setBean(Object bean) {
/* 1137 */       this._bean = bean;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 1143 */       if (this._bean == null) {
/* 1144 */         this._context.reportInputMismatch((BeanProperty)this._prop, "Cannot resolve ObjectId forward reference using property '%s' (of type %s): Bean not yet resolved", new Object[] { this._prop
/*      */               
/* 1146 */               .getName(), this._prop.getDeclaringClass().getName() });
/*      */       }
/* 1148 */       this._prop.set(this._bean, value);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */