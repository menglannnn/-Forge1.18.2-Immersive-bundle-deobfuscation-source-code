/*    */ package com.fasterxml.jackson.databind.jsontype.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*    */ import com.fasterxml.jackson.databind.BeanProperty;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsDeductionTypeSerializer
/*    */   extends TypeSerializerBase
/*    */ {
/* 15 */   private static final AsDeductionTypeSerializer INSTANCE = new AsDeductionTypeSerializer();
/*    */   
/*    */   protected AsDeductionTypeSerializer() {
/* 18 */     super(null, null);
/*    */   }
/*    */   
/*    */   public static AsDeductionTypeSerializer instance() {
/* 22 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public AsDeductionTypeSerializer forProperty(BeanProperty prop) {
/* 27 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonTypeInfo.As getTypeInclusion() {
/* 32 */     return JsonTypeInfo.As.EXISTING_PROPERTY;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WritableTypeId writeTypePrefix(JsonGenerator g, WritableTypeId idMetadata) throws IOException {
/* 42 */     if (idMetadata.valueShape.isStructStart() && 
/*    */       
/* 44 */       !g.canWriteTypeId()) {
/* 45 */       return g.writeTypePrefix(idMetadata);
/*    */     }
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WritableTypeId writeTypeSuffix(JsonGenerator g, WritableTypeId idMetadata) throws IOException {
/* 54 */     return (idMetadata == null) ? null : g
/* 55 */       .writeTypeSuffix(idMetadata);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\AsDeductionTypeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */