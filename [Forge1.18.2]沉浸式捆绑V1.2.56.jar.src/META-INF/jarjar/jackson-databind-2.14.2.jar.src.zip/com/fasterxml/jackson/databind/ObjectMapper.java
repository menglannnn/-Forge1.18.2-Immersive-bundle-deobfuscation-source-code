/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter;
/*      */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*      */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.Base64Variants;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JsonEncoding;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.PrettyPrinter;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.StreamWriteFeature;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.Versioned;
/*      */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*      */ import com.fasterxml.jackson.core.exc.StreamWriteException;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.SegmentedStringWriter;
/*      */ import com.fasterxml.jackson.core.type.ResolvedType;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.databind.cfg.BaseSettings;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionConfigs;
/*      */ import com.fasterxml.jackson.databind.cfg.ConfigOverrides;
/*      */ import com.fasterxml.jackson.databind.cfg.ConstructorDetector;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*      */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.MutableCoercionConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.MutableConfigOverride;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
/*      */ import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*      */ import com.fasterxml.jackson.databind.deser.KeyDeserializers;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiators;
/*      */ import com.fasterxml.jackson.databind.exc.MismatchedInputException;
/*      */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.introspect.BasicClassIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.DefaultAccessorNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*      */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*      */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*      */ import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*      */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.LaissezFaireSubTypeValidator;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.node.NullNode;
/*      */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*      */ import com.fasterxml.jackson.databind.node.POJONode;
/*      */ import com.fasterxml.jackson.databind.node.TreeTraversingParser;
/*      */ import com.fasterxml.jackson.databind.ser.BeanSerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
/*      */ import com.fasterxml.jackson.databind.ser.DefaultSerializerProvider;
/*      */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.Serializers;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.type.TypeModifier;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*      */ import com.fasterxml.jackson.databind.util.StdDateFormat;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.text.DateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.ServiceLoader;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ObjectMapper
/*      */   extends ObjectCodec
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   
/*      */   public enum DefaultTyping
/*      */   {
/*  159 */     JAVA_LANG_OBJECT,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  169 */     OBJECT_AND_NON_CONCRETE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  178 */     NON_CONCRETE_AND_ARRAYS,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  189 */     NON_FINAL,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  214 */     EVERYTHING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DefaultTypeResolverBuilder
/*      */     extends StdTypeResolverBuilder
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final ObjectMapper.DefaultTyping _appliesFor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final PolymorphicTypeValidator _subtypeValidator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public DefaultTypeResolverBuilder(ObjectMapper.DefaultTyping t) {
/*  252 */       this(t, (PolymorphicTypeValidator)LaissezFaireSubTypeValidator.instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DefaultTypeResolverBuilder(ObjectMapper.DefaultTyping t, PolymorphicTypeValidator ptv) {
/*  259 */       this._appliesFor = _requireNonNull(t, "Can not pass `null` DefaultTyping");
/*  260 */       this._subtypeValidator = _requireNonNull(ptv, "Can not pass `null` PolymorphicTypeValidator");
/*      */     }
/*      */ 
/*      */     
/*      */     protected DefaultTypeResolverBuilder(DefaultTypeResolverBuilder base, Class<?> defaultImpl) {
/*  265 */       super(base, defaultImpl);
/*  266 */       this._appliesFor = base._appliesFor;
/*  267 */       this._subtypeValidator = base._subtypeValidator;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static <T> T _requireNonNull(T value, String msg) {
/*  273 */       if (value == null) {
/*  274 */         throw new NullPointerException(msg);
/*      */       }
/*  276 */       return value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static DefaultTypeResolverBuilder construct(ObjectMapper.DefaultTyping t, PolymorphicTypeValidator ptv) {
/*  284 */       return new DefaultTypeResolverBuilder(t, ptv);
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultTypeResolverBuilder withDefaultImpl(Class<?> defaultImpl) {
/*  289 */       if (this._defaultImpl == defaultImpl) {
/*  290 */         return this;
/*      */       }
/*  292 */       ClassUtil.verifyMustOverride(DefaultTypeResolverBuilder.class, this, "withDefaultImpl");
/*  293 */       return new DefaultTypeResolverBuilder(this, defaultImpl);
/*      */     }
/*      */ 
/*      */     
/*      */     public PolymorphicTypeValidator subTypeValidator(MapperConfig<?> config) {
/*  298 */       return this._subtypeValidator;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/*  305 */       return useForType(baseType) ? super.buildTypeDeserializer(config, baseType, subtypes) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/*  312 */       return useForType(baseType) ? super.buildTypeSerializer(config, baseType, subtypes) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean useForType(JavaType t) {
/*  327 */       if (t.isPrimitive()) {
/*  328 */         return false;
/*      */       }
/*      */       
/*  331 */       switch (this._appliesFor) {
/*      */         case NON_CONCRETE_AND_ARRAYS:
/*  333 */           while (t.isArrayType()) {
/*  334 */             t = t.getContentType();
/*      */           }
/*      */ 
/*      */         
/*      */         case OBJECT_AND_NON_CONCRETE:
/*  339 */           while (t.isReferenceType()) {
/*  340 */             t = t.getReferencedType();
/*      */           }
/*  342 */           return (t.isJavaLangObject() || (
/*  343 */             !t.isConcrete() && 
/*      */             
/*  345 */             !TreeNode.class.isAssignableFrom(t.getRawClass())));
/*      */         
/*      */         case NON_FINAL:
/*  348 */           while (t.isArrayType()) {
/*  349 */             t = t.getContentType();
/*      */           }
/*      */           
/*  352 */           while (t.isReferenceType()) {
/*  353 */             t = t.getReferencedType();
/*      */           }
/*      */           
/*  356 */           return (!t.isFinal() && !TreeNode.class.isAssignableFrom(t.getRawClass()));
/*      */ 
/*      */         
/*      */         case EVERYTHING:
/*  360 */           return true;
/*      */       } 
/*      */       
/*  363 */       return t.isJavaLangObject();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  375 */   protected static final AnnotationIntrospector DEFAULT_ANNOTATION_INTROSPECTOR = (AnnotationIntrospector)new JacksonAnnotationIntrospector();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  381 */   protected static final BaseSettings DEFAULT_BASE = new BaseSettings(null, DEFAULT_ANNOTATION_INTROSPECTOR, null, 
/*      */ 
/*      */       
/*  384 */       TypeFactory.defaultInstance(), null, (DateFormat)StdDateFormat.instance, null, 
/*      */       
/*  386 */       Locale.getDefault(), null, 
/*      */       
/*  388 */       Base64Variants.getDefaultVariant(), (PolymorphicTypeValidator)LaissezFaireSubTypeValidator.instance, (AccessorNamingStrategy.Provider)new DefaultAccessorNamingStrategy.Provider());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonFactory _jsonFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeFactory _typeFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InjectableValues _injectableValues;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SubtypeResolver _subtypeResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ConfigOverrides _configOverrides;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final CoercionConfigs _coercionConfigs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SimpleMixInResolver _mixIns;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializationConfig _serializationConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultSerializerProvider _serializerProvider;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializerFactory _serializerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationConfig _deserializationConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultDeserializationContext _deserializationContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Set<Object> _registeredModuleTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  554 */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _rootDeserializers = new ConcurrentHashMap<>(64, 0.6F, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper() {
/*  576 */     this(null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper(JsonFactory jf) {
/*  585 */     this(jf, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectMapper(ObjectMapper src) {
/*  595 */     this(src, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectMapper(ObjectMapper src, JsonFactory factory) {
/*  605 */     this._jsonFactory = (factory != null) ? factory : src._jsonFactory.copy();
/*  606 */     this._jsonFactory.setCodec(this);
/*  607 */     this._subtypeResolver = src._subtypeResolver.copy();
/*  608 */     this._typeFactory = src._typeFactory;
/*  609 */     this._injectableValues = src._injectableValues;
/*  610 */     this._configOverrides = src._configOverrides.copy();
/*  611 */     this._coercionConfigs = src._coercionConfigs.copy();
/*  612 */     this._mixIns = src._mixIns.copy();
/*      */     
/*  614 */     RootNameLookup rootNames = new RootNameLookup();
/*  615 */     this._serializationConfig = new SerializationConfig(src._serializationConfig, this._subtypeResolver, this._mixIns, rootNames, this._configOverrides);
/*      */     
/*  617 */     this._deserializationConfig = new DeserializationConfig(src._deserializationConfig, this._subtypeResolver, this._mixIns, rootNames, this._configOverrides, this._coercionConfigs);
/*      */ 
/*      */     
/*  620 */     this._serializerProvider = src._serializerProvider.copy();
/*  621 */     this._deserializationContext = src._deserializationContext.copy();
/*      */ 
/*      */     
/*  624 */     this._serializerFactory = src._serializerFactory;
/*      */ 
/*      */     
/*  627 */     Set<Object> reg = src._registeredModuleTypes;
/*  628 */     if (reg == null) {
/*  629 */       this._registeredModuleTypes = null;
/*      */     } else {
/*  631 */       this._registeredModuleTypes = new LinkedHashSet(reg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper(JsonFactory jf, DefaultSerializerProvider sp, DefaultDeserializationContext dc) {
/*  652 */     if (jf == null) {
/*  653 */       this._jsonFactory = new MappingJsonFactory(this);
/*      */     } else {
/*  655 */       this._jsonFactory = jf;
/*  656 */       if (jf.getCodec() == null) {
/*  657 */         this._jsonFactory.setCodec(this);
/*      */       }
/*      */     } 
/*  660 */     this._subtypeResolver = (SubtypeResolver)new StdSubtypeResolver();
/*  661 */     RootNameLookup rootNames = new RootNameLookup();
/*      */     
/*  663 */     this._typeFactory = TypeFactory.defaultInstance();
/*      */     
/*  665 */     SimpleMixInResolver mixins = new SimpleMixInResolver(null);
/*  666 */     this._mixIns = mixins;
/*  667 */     BaseSettings base = DEFAULT_BASE.withClassIntrospector(defaultClassIntrospector());
/*  668 */     this._configOverrides = new ConfigOverrides();
/*  669 */     this._coercionConfigs = new CoercionConfigs();
/*  670 */     this
/*      */       
/*  672 */       ._serializationConfig = new SerializationConfig(base, this._subtypeResolver, mixins, rootNames, this._configOverrides, DatatypeFeatures.defaultFeatures());
/*  673 */     this
/*      */ 
/*      */       
/*  676 */       ._deserializationConfig = new DeserializationConfig(base, this._subtypeResolver, mixins, rootNames, this._configOverrides, this._coercionConfigs, DatatypeFeatures.defaultFeatures());
/*      */ 
/*      */     
/*  679 */     boolean needOrder = this._jsonFactory.requiresPropertyOrdering();
/*  680 */     if (needOrder ^ this._serializationConfig.isEnabled(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY)) {
/*  681 */       configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, needOrder);
/*      */     }
/*      */     
/*  684 */     this._serializerProvider = (sp == null) ? (DefaultSerializerProvider)new DefaultSerializerProvider.Impl() : sp;
/*  685 */     this._deserializationContext = (dc == null) ? (DefaultDeserializationContext)new DefaultDeserializationContext.Impl((DeserializerFactory)BeanDeserializerFactory.instance) : dc;
/*      */ 
/*      */ 
/*      */     
/*  689 */     this._serializerFactory = (SerializerFactory)BeanSerializerFactory.instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ClassIntrospector defaultClassIntrospector() {
/*  699 */     return (ClassIntrospector)new BasicClassIntrospector();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper copy() {
/*  724 */     _checkInvalidCopy(ObjectMapper.class);
/*  725 */     return new ObjectMapper(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper copyWith(JsonFactory factory) {
/*  738 */     _checkInvalidCopy(ObjectMapper.class);
/*  739 */     return new ObjectMapper(this, factory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkInvalidCopy(Class<?> exp) {
/*  747 */     if (getClass() != exp)
/*      */     {
/*  749 */       throw new IllegalStateException("Failed copy()/copyWith(): " + getClass().getName() + " (version: " + 
/*  750 */           version() + ") does not override copy()/copyWith(); it has to");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _newReader(DeserializationConfig config) {
/*  768 */     return new ObjectReader(this, config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _newReader(DeserializationConfig config, JavaType valueType, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues) {
/*  780 */     return new ObjectReader(this, config, valueType, valueToUpdate, schema, injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _newWriter(SerializationConfig config) {
/*  790 */     return new ObjectWriter(this, config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _newWriter(SerializationConfig config, FormatSchema schema) {
/*  800 */     return new ObjectWriter(this, config, schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _newWriter(SerializationConfig config, JavaType rootType, PrettyPrinter pp) {
/*  811 */     return new ObjectWriter(this, config, rootType, pp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  826 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper registerModule(Module module) {
/*  844 */     _assertNotNull("module", module);
/*      */ 
/*      */ 
/*      */     
/*  848 */     String name = module.getModuleName();
/*  849 */     if (name == null) {
/*  850 */       throw new IllegalArgumentException("Module without defined name");
/*      */     }
/*  852 */     Version version = module.version();
/*  853 */     if (version == null) {
/*  854 */       throw new IllegalArgumentException("Module without defined version");
/*      */     }
/*      */ 
/*      */     
/*  858 */     for (Module dep : module.getDependencies()) {
/*  859 */       registerModule(dep);
/*      */     }
/*      */ 
/*      */     
/*  863 */     if (isEnabled(MapperFeature.IGNORE_DUPLICATE_MODULE_REGISTRATIONS)) {
/*  864 */       Object typeId = module.getTypeId();
/*  865 */       if (typeId != null) {
/*  866 */         if (this._registeredModuleTypes == null)
/*      */         {
/*      */           
/*  869 */           this._registeredModuleTypes = new LinkedHashSet();
/*      */         }
/*      */         
/*  872 */         if (!this._registeredModuleTypes.add(typeId)) {
/*  873 */           return this;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  879 */     module.setupModule(new Module.SetupContext()
/*      */         {
/*      */ 
/*      */           
/*      */           public Version getMapperVersion()
/*      */           {
/*  885 */             return ObjectMapper.this.version();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public <C extends ObjectCodec> C getOwner() {
/*  892 */             return (C)ObjectMapper.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public TypeFactory getTypeFactory() {
/*  897 */             return ObjectMapper.this._typeFactory;
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(MapperFeature f) {
/*  902 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(DeserializationFeature f) {
/*  907 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(SerializationFeature f) {
/*  912 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(JsonFactory.Feature f) {
/*  917 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(JsonParser.Feature f) {
/*  922 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(JsonGenerator.Feature f) {
/*  927 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MutableConfigOverride configOverride(Class<?> type) {
/*  934 */             return ObjectMapper.this.configOverride(type);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void addDeserializers(Deserializers d) {
/*  941 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAdditionalDeserializers(d);
/*  942 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addKeyDeserializers(KeyDeserializers d) {
/*  947 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAdditionalKeyDeserializers(d);
/*  948 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addBeanDeserializerModifier(BeanDeserializerModifier modifier) {
/*  953 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withDeserializerModifier(modifier);
/*  954 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void addSerializers(Serializers s) {
/*  961 */             ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withAdditionalSerializers(s);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addKeySerializers(Serializers s) {
/*  966 */             ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withAdditionalKeySerializers(s);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addBeanSerializerModifier(BeanSerializerModifier modifier) {
/*  971 */             ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withSerializerModifier(modifier);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void addAbstractTypeResolver(AbstractTypeResolver resolver) {
/*  978 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAbstractTypeResolver(resolver);
/*  979 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addTypeModifier(TypeModifier modifier) {
/*  984 */             TypeFactory f = ObjectMapper.this._typeFactory;
/*  985 */             f = f.withModifier(modifier);
/*  986 */             ObjectMapper.this.setTypeFactory(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addValueInstantiators(ValueInstantiators instantiators) {
/*  991 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withValueInstantiators(instantiators);
/*  992 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */           
/*      */           public void setClassIntrospector(ClassIntrospector ci) {
/*  997 */             ObjectMapper.this._deserializationConfig = (DeserializationConfig)ObjectMapper.this._deserializationConfig.with(ci);
/*  998 */             ObjectMapper.this._serializationConfig = (SerializationConfig)ObjectMapper.this._serializationConfig.with(ci);
/*      */           }
/*      */ 
/*      */           
/*      */           public void insertAnnotationIntrospector(AnnotationIntrospector ai) {
/* 1003 */             ObjectMapper.this._deserializationConfig = (DeserializationConfig)ObjectMapper.this._deserializationConfig.withInsertedAnnotationIntrospector(ai);
/* 1004 */             ObjectMapper.this._serializationConfig = (SerializationConfig)ObjectMapper.this._serializationConfig.withInsertedAnnotationIntrospector(ai);
/*      */           }
/*      */ 
/*      */           
/*      */           public void appendAnnotationIntrospector(AnnotationIntrospector ai) {
/* 1009 */             ObjectMapper.this._deserializationConfig = (DeserializationConfig)ObjectMapper.this._deserializationConfig.withAppendedAnnotationIntrospector(ai);
/* 1010 */             ObjectMapper.this._serializationConfig = (SerializationConfig)ObjectMapper.this._serializationConfig.withAppendedAnnotationIntrospector(ai);
/*      */           }
/*      */ 
/*      */           
/*      */           public void registerSubtypes(Class<?>... subtypes) {
/* 1015 */             ObjectMapper.this.registerSubtypes(subtypes);
/*      */           }
/*      */ 
/*      */           
/*      */           public void registerSubtypes(NamedType... subtypes) {
/* 1020 */             ObjectMapper.this.registerSubtypes(subtypes);
/*      */           }
/*      */ 
/*      */           
/*      */           public void registerSubtypes(Collection<Class<?>> subtypes) {
/* 1025 */             ObjectMapper.this.registerSubtypes(subtypes);
/*      */           }
/*      */ 
/*      */           
/*      */           public void setMixInAnnotations(Class<?> target, Class<?> mixinSource) {
/* 1030 */             ObjectMapper.this.addMixIn(target, mixinSource);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addDeserializationProblemHandler(DeserializationProblemHandler handler) {
/* 1035 */             ObjectMapper.this.addHandler(handler);
/*      */           }
/*      */ 
/*      */           
/*      */           public void setNamingStrategy(PropertyNamingStrategy naming) {
/* 1040 */             ObjectMapper.this.setPropertyNamingStrategy(naming);
/*      */           }
/*      */         });
/*      */     
/* 1044 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper registerModules(Module... modules) {
/* 1060 */     for (Module module : modules) {
/* 1061 */       registerModule(module);
/*      */     }
/* 1063 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper registerModules(Iterable<? extends Module> modules) {
/* 1079 */     _assertNotNull("modules", modules);
/* 1080 */     for (Module module : modules) {
/* 1081 */       registerModule(module);
/*      */     }
/* 1083 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Object> getRegisteredModuleIds() {
/* 1101 */     return (this._registeredModuleTypes == null) ? 
/* 1102 */       Collections.<Object>emptySet() : Collections.<Object>unmodifiableSet(this._registeredModuleTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Module> findModules() {
/* 1115 */     return findModules(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Module> findModules(ClassLoader classLoader) {
/* 1129 */     ArrayList<Module> modules = new ArrayList<>();
/* 1130 */     ServiceLoader<Module> loader = secureGetServiceLoader(Module.class, classLoader);
/* 1131 */     for (Module module : loader) {
/* 1132 */       modules.add(module);
/*      */     }
/* 1134 */     return modules;
/*      */   }
/*      */   
/*      */   private static <T> ServiceLoader<T> secureGetServiceLoader(final Class<T> clazz, final ClassLoader classLoader) {
/* 1138 */     SecurityManager sm = System.getSecurityManager();
/* 1139 */     if (sm == null) {
/* 1140 */       return (classLoader == null) ? 
/* 1141 */         ServiceLoader.<T>load(clazz) : ServiceLoader.<T>load(clazz, classLoader);
/*      */     }
/* 1143 */     return AccessController.<ServiceLoader<T>>doPrivileged((PrivilegedAction)new PrivilegedAction<ServiceLoader<ServiceLoader<T>>>()
/*      */         {
/*      */           public ServiceLoader<T> run() {
/* 1146 */             return (classLoader == null) ? 
/* 1147 */               ServiceLoader.<T>load(clazz) : ServiceLoader.<T>load(clazz, classLoader);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper findAndRegisterModules() {
/* 1165 */     return registerModules(findModules());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out) throws IOException {
/* 1184 */     _assertNotNull("out", out);
/* 1185 */     JsonGenerator g = this._jsonFactory.createGenerator(out, JsonEncoding.UTF8);
/* 1186 */     this._serializationConfig.initialize(g);
/* 1187 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/* 1199 */     _assertNotNull("out", out);
/* 1200 */     JsonGenerator g = this._jsonFactory.createGenerator(out, enc);
/* 1201 */     this._serializationConfig.initialize(g);
/* 1202 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(Writer w) throws IOException {
/* 1214 */     _assertNotNull("w", w);
/* 1215 */     JsonGenerator g = this._jsonFactory.createGenerator(w);
/* 1216 */     this._serializationConfig.initialize(g);
/* 1217 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(File outputFile, JsonEncoding enc) throws IOException {
/* 1229 */     _assertNotNull("outputFile", outputFile);
/* 1230 */     JsonGenerator g = this._jsonFactory.createGenerator(outputFile, enc);
/* 1231 */     this._serializationConfig.initialize(g);
/* 1232 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out) throws IOException {
/* 1244 */     _assertNotNull("out", out);
/* 1245 */     JsonGenerator g = this._jsonFactory.createGenerator(out);
/* 1246 */     this._serializationConfig.initialize(g);
/* 1247 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(File src) throws IOException {
/* 1265 */     _assertNotNull("src", src);
/* 1266 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(src));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(URL src) throws IOException {
/* 1278 */     _assertNotNull("src", src);
/* 1279 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(src));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(InputStream in) throws IOException {
/* 1291 */     _assertNotNull("in", in);
/* 1292 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(in));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(Reader r) throws IOException {
/* 1304 */     _assertNotNull("r", r);
/* 1305 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(r));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] content) throws IOException {
/* 1317 */     _assertNotNull("content", content);
/* 1318 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] content, int offset, int len) throws IOException {
/* 1330 */     _assertNotNull("content", content);
/* 1331 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(String content) throws IOException {
/* 1343 */     _assertNotNull("content", content);
/* 1344 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content) throws IOException {
/* 1356 */     _assertNotNull("content", content);
/* 1357 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content, int offset, int len) throws IOException {
/* 1369 */     _assertNotNull("content", content);
/* 1370 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(DataInput content) throws IOException {
/* 1382 */     _assertNotNull("content", content);
/* 1383 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteArrayParser() throws IOException {
/* 1395 */     return this._deserializationConfig.initialize(this._jsonFactory.createNonBlockingByteArrayParser());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializationConfig getSerializationConfig() {
/* 1413 */     return this._serializationConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig getDeserializationConfig() {
/* 1426 */     return this._deserializationConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationContext getDeserializationContext() {
/* 1437 */     return (DeserializationContext)this._deserializationContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setSerializerFactory(SerializerFactory f) {
/* 1451 */     this._serializerFactory = f;
/* 1452 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerFactory getSerializerFactory() {
/* 1463 */     return this._serializerFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setSerializerProvider(DefaultSerializerProvider p) {
/* 1472 */     this._serializerProvider = p;
/* 1473 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerProvider getSerializerProvider() {
/* 1484 */     return (SerializerProvider)this._serializerProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerProvider getSerializerProviderInstance() {
/* 1496 */     return (SerializerProvider)_serializerProvider(this._serializationConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setMixIns(Map<Class<?>, Class<?>> sourceMixins) {
/* 1525 */     this._mixIns.setLocalDefinitions(sourceMixins);
/* 1526 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper addMixIn(Class<?> target, Class<?> mixinSource) {
/* 1543 */     this._mixIns.addLocalDefinition(target, mixinSource);
/* 1544 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setMixInResolver(ClassIntrospector.MixInResolver resolver) {
/* 1557 */     SimpleMixInResolver r = this._mixIns.withOverrides(resolver);
/* 1558 */     if (r != this._mixIns) {
/* 1559 */       this._mixIns = r;
/* 1560 */       this._deserializationConfig = new DeserializationConfig(this._deserializationConfig, r);
/* 1561 */       this._serializationConfig = new SerializationConfig(this._serializationConfig, r);
/*      */     } 
/* 1563 */     return this;
/*      */   }
/*      */   
/*      */   public Class<?> findMixInClassFor(Class<?> cls) {
/* 1567 */     return this._mixIns.findMixInClassFor(cls);
/*      */   }
/*      */ 
/*      */   
/*      */   public int mixInCount() {
/* 1572 */     return this._mixIns.localSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setMixInAnnotations(Map<Class<?>, Class<?>> sourceMixins) {
/* 1580 */     setMixIns(sourceMixins);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void addMixInAnnotations(Class<?> target, Class<?> mixinSource) {
/* 1588 */     addMixIn(target, mixinSource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VisibilityChecker<?> getVisibilityChecker() {
/* 1603 */     return this._serializationConfig.getDefaultVisibilityChecker();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setVisibility(VisibilityChecker<?> vc) {
/* 1617 */     this._configOverrides.setDefaultVisibility(vc);
/* 1618 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setVisibility(PropertyAccessor forMethod, JsonAutoDetect.Visibility visibility) {
/* 1647 */     VisibilityChecker<?> vc = this._configOverrides.getDefaultVisibility();
/* 1648 */     vc = vc.withVisibility(forMethod, visibility);
/* 1649 */     this._configOverrides.setDefaultVisibility(vc);
/* 1650 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubtypeResolver getSubtypeResolver() {
/* 1657 */     return this._subtypeResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setSubtypeResolver(SubtypeResolver str) {
/* 1664 */     this._subtypeResolver = str;
/* 1665 */     this._deserializationConfig = this._deserializationConfig.with(str);
/* 1666 */     this._serializationConfig = this._serializationConfig.with(str);
/* 1667 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setAnnotationIntrospector(AnnotationIntrospector ai) {
/* 1681 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(ai);
/* 1682 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(ai);
/* 1683 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setAnnotationIntrospectors(AnnotationIntrospector serializerAI, AnnotationIntrospector deserializerAI) {
/* 1703 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(serializerAI);
/* 1704 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(deserializerAI);
/* 1705 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setPropertyNamingStrategy(PropertyNamingStrategy s) {
/* 1712 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(s);
/* 1713 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(s);
/* 1714 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyNamingStrategy getPropertyNamingStrategy() {
/* 1722 */     return this._serializationConfig.getPropertyNamingStrategy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setAccessorNaming(AccessorNamingStrategy.Provider s) {
/* 1731 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(s);
/* 1732 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(s);
/* 1733 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultPrettyPrinter(PrettyPrinter pp) {
/* 1747 */     this._serializationConfig = this._serializationConfig.withDefaultPrettyPrinter(pp);
/* 1748 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setVisibilityChecker(VisibilityChecker<?> vc) {
/* 1756 */     setVisibility(vc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setPolymorphicTypeValidator(PolymorphicTypeValidator ptv) {
/* 1768 */     BaseSettings s = this._deserializationConfig.getBaseSettings().with(ptv);
/* 1769 */     this._deserializationConfig = this._deserializationConfig._withBase(s);
/* 1770 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PolymorphicTypeValidator getPolymorphicTypeValidator() {
/* 1782 */     return this._deserializationConfig.getBaseSettings().getPolymorphicTypeValidator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setSerializationInclusion(JsonInclude.Include incl) {
/* 1801 */     setPropertyInclusion(JsonInclude.Value.construct(incl, incl));
/* 1802 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper setPropertyInclusion(JsonInclude.Value incl) {
/* 1811 */     return setDefaultPropertyInclusion(incl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultPropertyInclusion(JsonInclude.Value incl) {
/* 1822 */     this._configOverrides.setDefaultInclusion(incl);
/* 1823 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultPropertyInclusion(JsonInclude.Include incl) {
/* 1835 */     this._configOverrides.setDefaultInclusion(JsonInclude.Value.construct(incl, incl));
/* 1836 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultSetterInfo(JsonSetter.Value v) {
/* 1847 */     this._configOverrides.setDefaultSetterInfo(v);
/* 1848 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultVisibility(JsonAutoDetect.Value vis) {
/* 1860 */     this._configOverrides.setDefaultVisibility((VisibilityChecker)VisibilityChecker.Std.construct(vis));
/* 1861 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultMergeable(Boolean b) {
/* 1872 */     this._configOverrides.setDefaultMergeable(b);
/* 1873 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultLeniency(Boolean b) {
/* 1880 */     this._configOverrides.setDefaultLeniency(b);
/* 1881 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerSubtypes(Class<?>... classes) {
/* 1898 */     getSubtypeResolver().registerSubtypes(classes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerSubtypes(NamedType... types) {
/* 1910 */     getSubtypeResolver().registerSubtypes(types);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerSubtypes(Collection<Class<?>> subtypes) {
/* 1917 */     getSubtypeResolver().registerSubtypes(subtypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv) {
/* 1941 */     return activateDefaultTyping(ptv, DefaultTyping.OBJECT_AND_NON_CONCRETE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv, DefaultTyping applicability) {
/* 1962 */     return activateDefaultTyping(ptv, applicability, JsonTypeInfo.As.WRAPPER_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv, DefaultTyping applicability, JsonTypeInfo.As includeAs) {
/* 1990 */     if (includeAs == JsonTypeInfo.As.EXTERNAL_PROPERTY) {
/* 1991 */       throw new IllegalArgumentException("Cannot use includeAs of " + includeAs);
/*      */     }
/*      */     
/* 1994 */     TypeResolverBuilder<?> typer = _constructDefaultTypeResolverBuilder(applicability, ptv);
/*      */     
/* 1996 */     typer = typer.init(JsonTypeInfo.Id.CLASS, null);
/* 1997 */     typer = typer.inclusion(includeAs);
/* 1998 */     return setDefaultTyping(typer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper activateDefaultTypingAsProperty(PolymorphicTypeValidator ptv, DefaultTyping applicability, String propertyName) {
/* 2023 */     TypeResolverBuilder<?> typer = _constructDefaultTypeResolverBuilder(applicability, ptv);
/*      */ 
/*      */     
/* 2026 */     typer = typer.init(JsonTypeInfo.Id.CLASS, null);
/* 2027 */     typer = typer.inclusion(JsonTypeInfo.As.PROPERTY);
/* 2028 */     typer = typer.typeProperty(propertyName);
/* 2029 */     return setDefaultTyping(typer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper deactivateDefaultTyping() {
/* 2041 */     return setDefaultTyping(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultTyping(TypeResolverBuilder<?> typer) {
/* 2060 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(typer);
/* 2061 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(typer);
/* 2062 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping() {
/* 2076 */     return activateDefaultTyping(getPolymorphicTypeValidator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping(DefaultTyping dti) {
/* 2084 */     return enableDefaultTyping(dti, JsonTypeInfo.As.WRAPPER_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping(DefaultTyping applicability, JsonTypeInfo.As includeAs) {
/* 2092 */     return activateDefaultTyping(getPolymorphicTypeValidator(), applicability, includeAs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTypingAsProperty(DefaultTyping applicability, String propertyName) {
/* 2100 */     return activateDefaultTypingAsProperty(getPolymorphicTypeValidator(), applicability, propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper disableDefaultTyping() {
/* 2108 */     return setDefaultTyping(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutableConfigOverride configOverride(Class<?> type) {
/* 2135 */     return this._configOverrides.findOrCreateOverride(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutableCoercionConfig coercionConfigDefaults() {
/* 2154 */     return this._coercionConfigs.defaultCoercions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutableCoercionConfig coercionConfigFor(LogicalType logicalType) {
/* 2164 */     return this._coercionConfigs.findOrCreateCoercion(logicalType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutableCoercionConfig coercionConfigFor(Class<?> physicalType) {
/* 2174 */     return this._coercionConfigs.findOrCreateCoercion(physicalType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeFactory getTypeFactory() {
/* 2187 */     return this._typeFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setTypeFactory(TypeFactory f) {
/* 2199 */     this._typeFactory = f;
/* 2200 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(f);
/* 2201 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(f);
/* 2202 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructType(Type t) {
/* 2211 */     _assertNotNull("t", t);
/* 2212 */     return this._typeFactory.constructType(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructType(TypeReference<?> typeRef) {
/* 2222 */     _assertNotNull("typeRef", typeRef);
/* 2223 */     return this._typeFactory.constructType(typeRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNodeFactory getNodeFactory() {
/* 2243 */     return this._deserializationConfig.getNodeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setNodeFactory(JsonNodeFactory f) {
/* 2252 */     this._deserializationConfig = this._deserializationConfig.with(f);
/* 2253 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setConstructorDetector(ConstructorDetector cd) {
/* 2265 */     this._deserializationConfig = this._deserializationConfig.with(cd);
/* 2266 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper addHandler(DeserializationProblemHandler h) {
/* 2274 */     this._deserializationConfig = this._deserializationConfig.withHandler(h);
/* 2275 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper clearProblemHandlers() {
/* 2283 */     this._deserializationConfig = this._deserializationConfig.withNoProblemHandlers();
/* 2284 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setConfig(DeserializationConfig config) {
/* 2302 */     _assertNotNull("config", config);
/* 2303 */     this._deserializationConfig = config;
/* 2304 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setFilters(FilterProvider filterProvider) {
/* 2318 */     this._serializationConfig = this._serializationConfig.withFilters(filterProvider);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setFilterProvider(FilterProvider filterProvider) {
/* 2333 */     this._serializationConfig = this._serializationConfig.withFilters(filterProvider);
/* 2334 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setBase64Variant(Base64Variant v) {
/* 2348 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(v);
/* 2349 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(v);
/* 2350 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setConfig(SerializationConfig config) {
/* 2368 */     _assertNotNull("config", config);
/* 2369 */     this._serializationConfig = config;
/* 2370 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory tokenStreamFactory() {
/* 2398 */     return this._jsonFactory;
/*      */   }
/*      */   public JsonFactory getFactory() {
/* 2401 */     return this._jsonFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDateFormat(DateFormat dateFormat) {
/* 2415 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(dateFormat);
/* 2416 */     this._serializationConfig = this._serializationConfig.with(dateFormat);
/* 2417 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DateFormat getDateFormat() {
/* 2425 */     return this._serializationConfig.getDateFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object setHandlerInstantiator(HandlerInstantiator hi) {
/* 2437 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(hi);
/* 2438 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(hi);
/* 2439 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setInjectableValues(InjectableValues injectableValues) {
/* 2447 */     this._injectableValues = injectableValues;
/* 2448 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InjectableValues getInjectableValues() {
/* 2455 */     return this._injectableValues;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setLocale(Locale l) {
/* 2463 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(l);
/* 2464 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(l);
/* 2465 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setTimeZone(TimeZone tz) {
/* 2473 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(tz);
/* 2474 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(tz);
/* 2475 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultAttributes(ContextAttributes attrs) {
/* 2487 */     this._deserializationConfig = this._deserializationConfig.with(attrs);
/* 2488 */     this._serializationConfig = this._serializationConfig.with(attrs);
/* 2489 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(MapperFeature f) {
/* 2503 */     return this._serializationConfig.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper configure(MapperFeature f, boolean state) {
/* 2511 */     this
/* 2512 */       ._serializationConfig = state ? (SerializationConfig)this._serializationConfig.with(new MapperFeature[] { f }) : (SerializationConfig)this._serializationConfig.without(new MapperFeature[] { f });
/* 2513 */     this
/* 2514 */       ._deserializationConfig = state ? (DeserializationConfig)this._deserializationConfig.with(new MapperFeature[] { f }) : (DeserializationConfig)this._deserializationConfig.without(new MapperFeature[] { f });
/* 2515 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enable(MapperFeature... f) {
/* 2523 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(f);
/* 2524 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(f);
/* 2525 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper disable(MapperFeature... f) {
/* 2533 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.without(f);
/* 2534 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.without(f);
/* 2535 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(SerializationFeature f) {
/* 2549 */     return this._serializationConfig.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(SerializationFeature f, boolean state) {
/* 2557 */     this
/* 2558 */       ._serializationConfig = state ? this._serializationConfig.with(f) : this._serializationConfig.without(f);
/* 2559 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(SerializationFeature f) {
/* 2567 */     this._serializationConfig = this._serializationConfig.with(f);
/* 2568 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(SerializationFeature first, SerializationFeature... f) {
/* 2577 */     this._serializationConfig = this._serializationConfig.with(first, f);
/* 2578 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(SerializationFeature f) {
/* 2586 */     this._serializationConfig = this._serializationConfig.without(f);
/* 2587 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(SerializationFeature first, SerializationFeature... f) {
/* 2596 */     this._serializationConfig = this._serializationConfig.without(first, f);
/* 2597 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(DeserializationFeature f) {
/* 2611 */     return this._deserializationConfig.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(DeserializationFeature f, boolean state) {
/* 2619 */     this
/* 2620 */       ._deserializationConfig = state ? this._deserializationConfig.with(f) : this._deserializationConfig.without(f);
/* 2621 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(DeserializationFeature feature) {
/* 2629 */     this._deserializationConfig = this._deserializationConfig.with(feature);
/* 2630 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(DeserializationFeature first, DeserializationFeature... f) {
/* 2639 */     this._deserializationConfig = this._deserializationConfig.with(first, f);
/* 2640 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(DeserializationFeature feature) {
/* 2648 */     this._deserializationConfig = this._deserializationConfig.without(feature);
/* 2649 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(DeserializationFeature first, DeserializationFeature... f) {
/* 2658 */     this._deserializationConfig = this._deserializationConfig.without(first, f);
/* 2659 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(DatatypeFeature f, boolean state) {
/* 2673 */     if (state) {
/* 2674 */       this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(f);
/* 2675 */       this._serializationConfig = (SerializationConfig)this._serializationConfig.with(f);
/*      */     } else {
/* 2677 */       this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.without(f);
/* 2678 */       this._serializationConfig = (SerializationConfig)this._serializationConfig.without(f);
/*      */     } 
/* 2680 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonParser.Feature f) {
/* 2690 */     return this._deserializationConfig.isEnabled(f, this._jsonFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(JsonParser.Feature f, boolean state) {
/* 2705 */     this._jsonFactory.configure(f, state);
/* 2706 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(JsonParser.Feature... features) {
/* 2722 */     for (JsonParser.Feature f : features) {
/* 2723 */       this._jsonFactory.enable(f);
/*      */     }
/* 2725 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(JsonParser.Feature... features) {
/* 2741 */     for (JsonParser.Feature f : features) {
/* 2742 */       this._jsonFactory.disable(f);
/*      */     }
/* 2744 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonGenerator.Feature f) {
/* 2754 */     return this._serializationConfig.isEnabled(f, this._jsonFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(JsonGenerator.Feature f, boolean state) {
/* 2769 */     this._jsonFactory.configure(f, state);
/* 2770 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(JsonGenerator.Feature... features) {
/* 2786 */     for (JsonGenerator.Feature f : features) {
/* 2787 */       this._jsonFactory.enable(f);
/*      */     }
/* 2789 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(JsonGenerator.Feature... features) {
/* 2805 */     for (JsonGenerator.Feature f : features) {
/* 2806 */       this._jsonFactory.disable(f);
/*      */     }
/* 2808 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonFactory.Feature f) {
/* 2824 */     return this._jsonFactory.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamReadFeature f) {
/* 2837 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamWriteFeature f) {
/* 2844 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 2878 */     _assertNotNull("p", p);
/* 2879 */     return (T)_readValue(getDeserializationConfig(), p, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 2903 */     _assertNotNull("p", p);
/* 2904 */     return (T)_readValue(getDeserializationConfig(), p, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T> T readValue(JsonParser p, ResolvedType valueType) throws IOException, StreamReadException, DatabindException {
/* 2927 */     _assertNotNull("p", p);
/* 2928 */     return (T)_readValue(getDeserializationConfig(), p, (JavaType)valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 2947 */     _assertNotNull("p", p);
/* 2948 */     return (T)_readValue(getDeserializationConfig(), p, valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends TreeNode> T readTree(JsonParser p) throws IOException {
/*      */     NullNode nullNode;
/* 2978 */     _assertNotNull("p", p);
/*      */     
/* 2980 */     DeserializationConfig cfg = getDeserializationConfig();
/* 2981 */     JsonToken t = p.currentToken();
/* 2982 */     if (t == null) {
/* 2983 */       t = p.nextToken();
/* 2984 */       if (t == null) {
/* 2985 */         return null;
/*      */       }
/*      */     } 
/*      */     
/* 2989 */     JsonNode n = (JsonNode)_readValue(cfg, p, constructType(JsonNode.class));
/* 2990 */     if (n == null) {
/* 2991 */       nullNode = getNodeFactory().nullNode();
/*      */     }
/*      */     
/* 2994 */     return (T)nullNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, ResolvedType valueType) throws IOException {
/* 3020 */     return readValues(p, (JavaType)valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, JavaType valueType) throws IOException {
/* 3034 */     _assertNotNull("p", p);
/* 3035 */     DeserializationConfig config = getDeserializationConfig();
/* 3036 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p, config);
/* 3037 */     JsonDeserializer<?> deser = _findRootDeserializer((DeserializationContext)defaultDeserializationContext, valueType);
/*      */     
/* 3039 */     return new MappingIterator<>(valueType, p, (DeserializationContext)defaultDeserializationContext, deser, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, Class<T> valueType) throws IOException {
/* 3055 */     return readValues(p, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, TypeReference<T> valueTypeRef) throws IOException {
/* 3065 */     return readValues(p, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(InputStream in) throws IOException {
/* 3103 */     _assertNotNull("in", in);
/* 3104 */     return _readTreeAndClose(this._jsonFactory.createParser(in));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(Reader r) throws IOException {
/* 3112 */     _assertNotNull("r", r);
/* 3113 */     return _readTreeAndClose(this._jsonFactory.createParser(r));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(String content) throws JsonProcessingException, JsonMappingException {
/* 3122 */     _assertNotNull("content", content);
/*      */     try {
/* 3124 */       return _readTreeAndClose(this._jsonFactory.createParser(content));
/* 3125 */     } catch (JsonProcessingException e) {
/* 3126 */       throw e;
/* 3127 */     } catch (IOException e) {
/* 3128 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(byte[] content) throws IOException {
/* 3137 */     _assertNotNull("content", content);
/* 3138 */     return _readTreeAndClose(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(byte[] content, int offset, int len) throws IOException {
/* 3146 */     _assertNotNull("content", content);
/* 3147 */     return _readTreeAndClose(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(File file) throws IOException {
/* 3156 */     _assertNotNull("file", file);
/* 3157 */     return _readTreeAndClose(this._jsonFactory.createParser(file));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(URL source) throws IOException {
/* 3172 */     _assertNotNull("source", source);
/* 3173 */     return _readTreeAndClose(this._jsonFactory.createParser(source));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(JsonGenerator g, Object value) throws IOException, StreamWriteException, DatabindException {
/* 3191 */     _assertNotNull("g", g);
/* 3192 */     SerializationConfig config = getSerializationConfig();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3200 */     if (config.isEnabled(SerializationFeature.INDENT_OUTPUT) && 
/* 3201 */       g.getPrettyPrinter() == null) {
/* 3202 */       g.setPrettyPrinter(config.constructDefaultPrettyPrinter());
/*      */     }
/*      */     
/* 3205 */     if (config.isEnabled(SerializationFeature.CLOSE_CLOSEABLE) && value instanceof Closeable) {
/* 3206 */       _writeCloseableValue(g, value, config);
/*      */     } else {
/* 3208 */       _serializerProvider(config).serializeValue(g, value);
/* 3209 */       if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3210 */         g.flush();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTree(JsonGenerator g, TreeNode rootNode) throws IOException {
/* 3225 */     _assertNotNull("g", g);
/* 3226 */     SerializationConfig config = getSerializationConfig();
/* 3227 */     _serializerProvider(config).serializeValue(g, rootNode);
/* 3228 */     if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3229 */       g.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTree(JsonGenerator g, JsonNode rootNode) throws IOException {
/* 3240 */     _assertNotNull("g", g);
/* 3241 */     SerializationConfig config = getSerializationConfig();
/* 3242 */     _serializerProvider(config).serializeValue(g, rootNode);
/* 3243 */     if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3244 */       g.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode createObjectNode() {
/* 3257 */     return this._deserializationConfig.getNodeFactory().objectNode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode createArrayNode() {
/* 3269 */     return this._deserializationConfig.getNodeFactory().arrayNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode missingNode() {
/* 3274 */     return this._deserializationConfig.getNodeFactory().missingNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode nullNode() {
/* 3279 */     return (JsonNode)this._deserializationConfig.getNodeFactory().nullNode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser treeAsTokens(TreeNode n) {
/* 3290 */     _assertNotNull("n", n);
/* 3291 */     return (JsonParser)new TreeTraversingParser((JsonNode)n, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, Class<T> valueType) throws IllegalArgumentException, JsonProcessingException {
/* 3316 */     if (n == null) {
/* 3317 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 3322 */       if (TreeNode.class.isAssignableFrom(valueType) && valueType
/* 3323 */         .isAssignableFrom(n.getClass())) {
/* 3324 */         return (T)n;
/*      */       }
/* 3326 */       JsonToken tt = n.asToken();
/*      */ 
/*      */       
/* 3329 */       if (tt == JsonToken.VALUE_EMBEDDED_OBJECT && 
/* 3330 */         n instanceof POJONode) {
/* 3331 */         Object ob = ((POJONode)n).getPojo();
/* 3332 */         if (ob == null || valueType.isInstance(ob)) {
/* 3333 */           return (T)ob;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3343 */       return readValue(treeAsTokens(n), valueType);
/* 3344 */     } catch (JsonProcessingException e) {
/*      */ 
/*      */       
/* 3347 */       throw e;
/* 3348 */     } catch (IOException e) {
/* 3349 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, JavaType valueType) throws IllegalArgumentException, JsonProcessingException {
/* 3365 */     if (n == null) {
/* 3366 */       return null;
/*      */     }
/*      */     try {
/* 3369 */       if (valueType.isTypeOrSubTypeOf(TreeNode.class) && valueType
/* 3370 */         .isTypeOrSuperTypeOf(n.getClass())) {
/* 3371 */         return (T)n;
/*      */       }
/* 3373 */       JsonToken tt = n.asToken();
/* 3374 */       if (tt == JsonToken.VALUE_EMBEDDED_OBJECT && 
/* 3375 */         n instanceof POJONode) {
/* 3376 */         Object ob = ((POJONode)n).getPojo();
/* 3377 */         if (ob == null || valueType.isTypeOrSuperTypeOf(ob.getClass())) {
/* 3378 */           return (T)ob;
/*      */         }
/*      */       } 
/*      */       
/* 3382 */       return readValue(treeAsTokens(n), valueType);
/* 3383 */     } catch (JsonProcessingException e) {
/*      */ 
/*      */       
/* 3386 */       throw e;
/* 3387 */     } catch (IOException e) {
/* 3388 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T valueToTree(Object fromValue) throws IllegalArgumentException {
/* 3422 */     if (fromValue == null) {
/* 3423 */       return (T)getNodeFactory().nullNode();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3428 */     SerializationConfig config = getSerializationConfig().without(SerializationFeature.WRAP_ROOT_VALUE);
/* 3429 */     DefaultSerializerProvider context = _serializerProvider(config);
/*      */ 
/*      */     
/* 3432 */     TokenBuffer buf = context.bufferForValueConversion(this);
/* 3433 */     if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 3434 */       buf = buf.forceUseOfBigDecimal(true);
/*      */     }
/*      */     try {
/* 3437 */       context.serializeValue((JsonGenerator)buf, fromValue);
/* 3438 */       try (JsonParser p = buf.asParser()) {
/* 3439 */         return (T)readTree(p);
/*      */       } 
/* 3441 */     } catch (IOException e) {
/* 3442 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canSerialize(Class<?> type) {
/* 3468 */     return _serializerProvider(getSerializationConfig()).hasSerializerFor(type, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canSerialize(Class<?> type, AtomicReference<Throwable> cause) {
/* 3479 */     return _serializerProvider(getSerializationConfig()).hasSerializerFor(type, cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canDeserialize(JavaType type) {
/* 3501 */     return createDeserializationContext(null, 
/* 3502 */         getDeserializationConfig()).hasValueDeserializerFor(type, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canDeserialize(JavaType type, AtomicReference<Throwable> cause) {
/* 3514 */     return createDeserializationContext(null, 
/* 3515 */         getDeserializationConfig()).hasValueDeserializerFor(type, cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3541 */     _assertNotNull("src", src);
/* 3542 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3561 */     _assertNotNull("src", src);
/* 3562 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3581 */     _assertNotNull("src", src);
/* 3582 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3607 */     _assertNotNull("src", src);
/* 3608 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3618 */     _assertNotNull("src", src);
/* 3619 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3629 */     _assertNotNull("src", src);
/* 3630 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String content, Class<T> valueType) throws JsonProcessingException, JsonMappingException {
/* 3644 */     _assertNotNull("content", content);
/* 3645 */     return readValue(content, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String content, TypeReference<T> valueTypeRef) throws JsonProcessingException, JsonMappingException {
/* 3659 */     _assertNotNull("content", content);
/* 3660 */     return readValue(content, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String content, JavaType valueType) throws JsonProcessingException, JsonMappingException {
/* 3675 */     _assertNotNull("content", content);
/*      */     try {
/* 3677 */       return (T)_readMapAndClose(this._jsonFactory.createParser(content), valueType);
/* 3678 */     } catch (JsonProcessingException e) {
/* 3679 */       throw e;
/* 3680 */     } catch (IOException e) {
/* 3681 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3689 */     _assertNotNull("src", src);
/* 3690 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3697 */     _assertNotNull("src", src);
/* 3698 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3705 */     _assertNotNull("src", src);
/* 3706 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3713 */     _assertNotNull("src", src);
/* 3714 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3721 */     _assertNotNull("src", src);
/* 3722 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3729 */     _assertNotNull("src", src);
/* 3730 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3737 */     _assertNotNull("src", src);
/* 3738 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, int offset, int len, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3746 */     _assertNotNull("src", src);
/* 3747 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3754 */     _assertNotNull("src", src);
/* 3755 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, int offset, int len, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3762 */     _assertNotNull("src", src);
/* 3763 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3770 */     _assertNotNull("src", src);
/* 3771 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, int offset, int len, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3778 */     _assertNotNull("src", src);
/* 3779 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(DataInput src, Class<T> valueType) throws IOException {
/* 3785 */     _assertNotNull("src", src);
/* 3786 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory
/* 3787 */         .constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(DataInput src, JavaType valueType) throws IOException {
/* 3793 */     _assertNotNull("src", src);
/* 3794 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(File resultFile, Object value) throws IOException, StreamWriteException, DatabindException {
/* 3811 */     _writeValueAndClose(createGenerator(resultFile, JsonEncoding.UTF8), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(OutputStream out, Object value) throws IOException, StreamWriteException, DatabindException {
/* 3828 */     _writeValueAndClose(createGenerator(out, JsonEncoding.UTF8), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(DataOutput out, Object value) throws IOException {
/* 3836 */     _writeValueAndClose(createGenerator(out), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(Writer w, Object value) throws IOException, StreamWriteException, DatabindException {
/* 3852 */     _writeValueAndClose(createGenerator(w), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String writeValueAsString(Object value) throws JsonProcessingException {
/* 3867 */     SegmentedStringWriter sw = new SegmentedStringWriter(this._jsonFactory._getBufferRecycler());
/*      */     try {
/* 3869 */       _writeValueAndClose(createGenerator((Writer)sw), value);
/* 3870 */     } catch (JsonProcessingException e) {
/* 3871 */       throw e;
/* 3872 */     } catch (IOException e) {
/* 3873 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/* 3875 */     return sw.getAndClear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] writeValueAsBytes(Object value) throws JsonProcessingException {
/* 3891 */     try (ByteArrayBuilder bb = new ByteArrayBuilder(this._jsonFactory._getBufferRecycler())) {
/* 3892 */       _writeValueAndClose(createGenerator((OutputStream)bb, JsonEncoding.UTF8), value);
/* 3893 */       byte[] result = bb.toByteArray();
/* 3894 */       bb.release();
/* 3895 */       return result;
/* 3896 */     } catch (JsonProcessingException e) {
/* 3897 */       throw e;
/* 3898 */     } catch (IOException e) {
/* 3899 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer() {
/* 3915 */     return _newWriter(getSerializationConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(SerializationFeature feature) {
/* 3924 */     return _newWriter(getSerializationConfig().with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(SerializationFeature first, SerializationFeature... other) {
/* 3934 */     return _newWriter(getSerializationConfig().with(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(DateFormat df) {
/* 3943 */     return _newWriter(getSerializationConfig().with(df));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerWithView(Class<?> serializationView) {
/* 3951 */     return _newWriter(getSerializationConfig().withView(serializationView));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerFor(Class<?> rootType) {
/* 3966 */     return _newWriter(getSerializationConfig(), (rootType == null) ? null : this._typeFactory
/* 3967 */         .constructType(rootType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerFor(TypeReference<?> rootType) {
/* 3983 */     return _newWriter(getSerializationConfig(), (rootType == null) ? null : this._typeFactory
/* 3984 */         .constructType(rootType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerFor(JavaType rootType) {
/* 4000 */     return _newWriter(getSerializationConfig(), rootType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(PrettyPrinter pp) {
/* 4009 */     if (pp == null) {
/* 4010 */       pp = ObjectWriter.NULL_PRETTY_PRINTER;
/*      */     }
/* 4012 */     return _newWriter(getSerializationConfig(), null, pp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerWithDefaultPrettyPrinter() {
/* 4020 */     SerializationConfig config = getSerializationConfig();
/* 4021 */     return _newWriter(config, null, config
/* 4022 */         .getDefaultPrettyPrinter());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(FilterProvider filterProvider) {
/* 4030 */     return _newWriter(getSerializationConfig().withFilters(filterProvider));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(FormatSchema schema) {
/* 4041 */     _verifySchemaType(schema);
/* 4042 */     return _newWriter(getSerializationConfig(), schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(Base64Variant defaultBase64) {
/* 4052 */     return _newWriter((SerializationConfig)getSerializationConfig().with(defaultBase64));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(CharacterEscapes escapes) {
/* 4062 */     return _newWriter(getSerializationConfig()).with(escapes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(ContextAttributes attrs) {
/* 4072 */     return _newWriter(getSerializationConfig().with(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(Class<?> rootType) {
/* 4080 */     return _newWriter(getSerializationConfig(), (rootType == null) ? null : this._typeFactory
/*      */         
/* 4082 */         .constructType(rootType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(TypeReference<?> rootType) {
/* 4091 */     return _newWriter(getSerializationConfig(), (rootType == null) ? null : this._typeFactory
/*      */         
/* 4093 */         .constructType(rootType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(JavaType rootType) {
/* 4102 */     return _newWriter(getSerializationConfig(), rootType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader() {
/* 4118 */     return _newReader(getDeserializationConfig()).with(this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(DeserializationFeature feature) {
/* 4129 */     return _newReader(getDeserializationConfig().with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(DeserializationFeature first, DeserializationFeature... other) {
/* 4141 */     return _newReader(getDeserializationConfig().with(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerForUpdating(Object valueToUpdate) {
/* 4156 */     JavaType t = (valueToUpdate == null) ? null : this._typeFactory.constructType(valueToUpdate.getClass());
/* 4157 */     return _newReader(getDeserializationConfig(), t, valueToUpdate, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerFor(JavaType type) {
/* 4168 */     return _newReader(getDeserializationConfig(), type, null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerFor(Class<?> type) {
/* 4179 */     JavaType t = (type == null) ? null : this._typeFactory.constructType(type);
/* 4180 */     return _newReader(getDeserializationConfig(), t, null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerFor(TypeReference<?> typeRef) {
/* 4191 */     _assertNotNull("type", typeRef);
/* 4192 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(typeRef), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerForArrayOf(Class<?> type) {
/* 4207 */     _assertNotNull("type", type);
/* 4208 */     return _newReader(getDeserializationConfig(), (JavaType)this._typeFactory
/* 4209 */         .constructArrayType(type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerForListOf(Class<?> type) {
/* 4224 */     _assertNotNull("type", type);
/* 4225 */     return _newReader(getDeserializationConfig(), (JavaType)this._typeFactory
/* 4226 */         .constructCollectionType(List.class, type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerForMapOf(Class<?> type) {
/* 4241 */     _assertNotNull("type", type);
/* 4242 */     return _newReader(getDeserializationConfig(), (JavaType)this._typeFactory
/* 4243 */         .constructMapType(Map.class, String.class, type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(JsonNodeFactory nodeFactory) {
/* 4252 */     _assertNotNull("nodeFactory", nodeFactory);
/* 4253 */     return _newReader(getDeserializationConfig()).with(nodeFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(FormatSchema schema) {
/* 4265 */     _verifySchemaType(schema);
/* 4266 */     return _newReader(getDeserializationConfig(), null, null, schema, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(InjectableValues injectableValues) {
/* 4277 */     return _newReader(getDeserializationConfig(), null, null, null, injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerWithView(Class<?> view) {
/* 4286 */     return _newReader(getDeserializationConfig().withView(view));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(Base64Variant defaultBase64) {
/* 4296 */     return _newReader((DeserializationConfig)getDeserializationConfig().with(defaultBase64));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(ContextAttributes attrs) {
/* 4306 */     return _newReader(getDeserializationConfig().with(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader reader(JavaType type) {
/* 4314 */     return _newReader(getDeserializationConfig(), type, null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader reader(Class<?> type) {
/* 4323 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader reader(TypeReference<?> type) {
/* 4332 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T convertValue(Object fromValue, Class<T> toValueType) throws IllegalArgumentException {
/* 4380 */     return (T)_convert(fromValue, this._typeFactory.constructType(toValueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T convertValue(Object fromValue, TypeReference<T> toValueTypeRef) throws IllegalArgumentException {
/* 4390 */     return (T)_convert(fromValue, this._typeFactory.constructType(toValueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T convertValue(Object fromValue, JavaType toValueType) throws IllegalArgumentException {
/* 4400 */     return (T)_convert(fromValue, toValueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _convert(Object fromValue, JavaType toValueType) throws IllegalArgumentException {
/* 4417 */     SerializationConfig config = getSerializationConfig().without(SerializationFeature.WRAP_ROOT_VALUE);
/* 4418 */     DefaultSerializerProvider context = _serializerProvider(config);
/*      */ 
/*      */     
/* 4421 */     TokenBuffer buf = context.bufferForValueConversion(this);
/* 4422 */     if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 4423 */       buf = buf.forceUseOfBigDecimal(true);
/*      */     }
/*      */     try {
/*      */       Object result;
/* 4427 */       context.serializeValue((JsonGenerator)buf, fromValue);
/*      */ 
/*      */       
/* 4430 */       JsonParser p = buf.asParser();
/*      */ 
/*      */       
/* 4433 */       DeserializationConfig deserConfig = getDeserializationConfig();
/* 4434 */       JsonToken t = _initForReading(p, toValueType);
/* 4435 */       if (t == JsonToken.VALUE_NULL) {
/* 4436 */         DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p, deserConfig);
/* 4437 */         result = _findRootDeserializer((DeserializationContext)defaultDeserializationContext, toValueType).getNullValue((DeserializationContext)defaultDeserializationContext);
/* 4438 */       } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 4439 */         result = null;
/*      */       } else {
/* 4441 */         DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p, deserConfig);
/* 4442 */         JsonDeserializer<Object> deser = _findRootDeserializer((DeserializationContext)defaultDeserializationContext, toValueType);
/*      */         
/* 4444 */         result = deser.deserialize(p, (DeserializationContext)defaultDeserializationContext);
/*      */       } 
/* 4446 */       p.close();
/* 4447 */       return result;
/* 4448 */     } catch (IOException e) {
/* 4449 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T updateValue(T valueToUpdate, Object overrides) throws JsonMappingException {
/* 4492 */     T result = valueToUpdate;
/* 4493 */     if (valueToUpdate != null && overrides != null) {
/*      */       
/* 4495 */       SerializationConfig config = getSerializationConfig().without(SerializationFeature.WRAP_ROOT_VALUE);
/* 4496 */       DefaultSerializerProvider context = _serializerProvider(config);
/*      */       
/* 4498 */       TokenBuffer buf = context.bufferForValueConversion(this);
/* 4499 */       if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 4500 */         buf = buf.forceUseOfBigDecimal(true);
/*      */       }
/*      */       try {
/* 4503 */         context.serializeValue((JsonGenerator)buf, overrides);
/* 4504 */         JsonParser p = buf.asParser();
/* 4505 */         result = readerForUpdating(valueToUpdate).readValue(p);
/* 4506 */         p.close();
/* 4507 */       } catch (IOException e) {
/* 4508 */         if (e instanceof JsonMappingException) {
/* 4509 */           throw (JsonMappingException)e;
/*      */         }
/*      */         
/* 4512 */         throw JsonMappingException.fromUnexpectedIOE(e);
/*      */       } 
/*      */     } 
/* 4515 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonSchema generateJsonSchema(Class<?> t) throws JsonMappingException {
/* 4537 */     return _serializerProvider(getSerializationConfig()).generateJsonSchema(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptJsonFormatVisitor(Class<?> type, JsonFormatVisitorWrapper visitor) throws JsonMappingException {
/* 4554 */     acceptJsonFormatVisitor(this._typeFactory.constructType(type), visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptJsonFormatVisitor(JavaType type, JsonFormatVisitorWrapper visitor) throws JsonMappingException {
/* 4572 */     if (type == null) {
/* 4573 */       throw new IllegalArgumentException("type must be provided");
/*      */     }
/* 4575 */     _serializerProvider(getSerializationConfig()).acceptJsonFormatVisitor(type, visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeResolverBuilder<?> _constructDefaultTypeResolverBuilder(DefaultTyping applicability, PolymorphicTypeValidator ptv) {
/* 4592 */     return (TypeResolverBuilder<?>)DefaultTypeResolverBuilder.construct(applicability, ptv);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultSerializerProvider _serializerProvider(SerializationConfig config) {
/* 4606 */     return this._serializerProvider.createInstance(config, this._serializerFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writeValueAndClose(JsonGenerator g, Object value) throws IOException {
/* 4618 */     SerializationConfig cfg = getSerializationConfig();
/* 4619 */     if (cfg.isEnabled(SerializationFeature.CLOSE_CLOSEABLE) && value instanceof Closeable) {
/* 4620 */       _writeCloseable(g, value, cfg);
/*      */       return;
/*      */     } 
/*      */     try {
/* 4624 */       _serializerProvider(cfg).serializeValue(g, value);
/* 4625 */     } catch (Exception e) {
/* 4626 */       ClassUtil.closeOnFailAndThrowAsIOE(g, e);
/*      */       return;
/*      */     } 
/* 4629 */     g.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCloseable(JsonGenerator g, Object value, SerializationConfig cfg) throws IOException {
/* 4639 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 4641 */       _serializerProvider(cfg).serializeValue(g, value);
/* 4642 */       Closeable tmpToClose = toClose;
/* 4643 */       toClose = null;
/* 4644 */       tmpToClose.close();
/* 4645 */     } catch (Exception e) {
/* 4646 */       ClassUtil.closeOnFailAndThrowAsIOE(g, toClose, e);
/*      */       return;
/*      */     } 
/* 4649 */     g.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCloseableValue(JsonGenerator g, Object value, SerializationConfig cfg) throws IOException {
/* 4659 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 4661 */       _serializerProvider(cfg).serializeValue(g, value);
/* 4662 */       if (cfg.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 4663 */         g.flush();
/*      */       }
/* 4665 */     } catch (Exception e) {
/* 4666 */       ClassUtil.closeOnFailAndThrowAsIOE(null, toClose, e);
/*      */       return;
/*      */     } 
/* 4669 */     toClose.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final void _configAndWriteValue(JsonGenerator g, Object value) throws IOException {
/* 4677 */     getSerializationConfig().initialize(g);
/* 4678 */     _writeValueAndClose(g, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _readValue(DeserializationConfig cfg, JsonParser p, JavaType valueType) throws IOException {
/*      */     Object result;
/* 4698 */     JsonToken t = _initForReading(p, valueType);
/* 4699 */     DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 4700 */     if (t == JsonToken.VALUE_NULL) {
/*      */       
/* 4702 */       result = _findRootDeserializer((DeserializationContext)ctxt, valueType).getNullValue((DeserializationContext)ctxt);
/* 4703 */     } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 4704 */       result = null;
/*      */     } else {
/* 4706 */       result = ctxt.readRootValue(p, valueType, _findRootDeserializer((DeserializationContext)ctxt, valueType), null);
/*      */     } 
/*      */     
/* 4709 */     p.clearCurrentToken();
/* 4710 */     if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 4711 */       _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, valueType);
/*      */     }
/* 4713 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _readMapAndClose(JsonParser p0, JavaType valueType) throws IOException {
/* 4719 */     try (JsonParser p = p0) {
/*      */       Object result;
/* 4721 */       DeserializationConfig cfg = getDeserializationConfig();
/* 4722 */       DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 4723 */       JsonToken t = _initForReading(p, valueType);
/* 4724 */       if (t == JsonToken.VALUE_NULL) {
/*      */         
/* 4726 */         result = _findRootDeserializer((DeserializationContext)ctxt, valueType).getNullValue((DeserializationContext)ctxt);
/* 4727 */       } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 4728 */         result = null;
/*      */       } else {
/* 4730 */         result = ctxt.readRootValue(p, valueType, 
/* 4731 */             _findRootDeserializer((DeserializationContext)ctxt, valueType), null);
/* 4732 */         ctxt.checkUnresolvedObjectId();
/*      */       } 
/* 4734 */       if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 4735 */         _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, valueType);
/*      */       }
/* 4737 */       return result;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonNode _readTreeAndClose(JsonParser p0) throws IOException {
/* 4749 */     try (JsonParser p = p0) {
/* 4750 */       JsonNode resultNode; JavaType valueType = constructType(JsonNode.class);
/*      */       
/* 4752 */       DeserializationConfig cfg = getDeserializationConfig();
/*      */ 
/*      */ 
/*      */       
/* 4756 */       cfg.initialize(p);
/* 4757 */       JsonToken t = p.currentToken();
/* 4758 */       if (t == null) {
/* 4759 */         t = p.nextToken();
/* 4760 */         if (t == null) {
/*      */ 
/*      */           
/* 4763 */           resultNode = cfg.getNodeFactory().missingNode(); return resultNode;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 4768 */       DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 4769 */       if (t == JsonToken.VALUE_NULL) {
/* 4770 */         NullNode nullNode = cfg.getNodeFactory().nullNode();
/*      */       } else {
/* 4772 */         resultNode = (JsonNode)ctxt.readRootValue(p, valueType, 
/* 4773 */             _findRootDeserializer((DeserializationContext)ctxt, valueType), null);
/*      */       } 
/*      */ 
/*      */       
/* 4777 */       if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 4778 */         _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, valueType);
/*      */       }
/* 4780 */       return resultNode;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultDeserializationContext createDeserializationContext(JsonParser p, DeserializationConfig cfg) {
/* 4793 */     return this._deserializationContext.createInstance(cfg, p, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _initForReading(JsonParser p, JavaType targetType) throws IOException {
/* 4809 */     this._deserializationConfig.initialize(p);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4814 */     JsonToken t = p.currentToken();
/* 4815 */     if (t == null) {
/*      */       
/* 4817 */       t = p.nextToken();
/* 4818 */       if (t == null)
/*      */       {
/*      */         
/* 4821 */         throw MismatchedInputException.from(p, targetType, "No content to map due to end-of-input");
/*      */       }
/*      */     } 
/*      */     
/* 4825 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNoTrailingTokens(JsonParser p, DeserializationContext ctxt, JavaType bindType) throws IOException {
/* 4835 */     JsonToken t = p.nextToken();
/* 4836 */     if (t != null) {
/* 4837 */       Class<?> bt = ClassUtil.rawClass(bindType);
/* 4838 */       ctxt.reportTrailingTokens(bt, p, t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findRootDeserializer(DeserializationContext ctxt, JavaType valueType) throws DatabindException {
/* 4856 */     JsonDeserializer<Object> deser = this._rootDeserializers.get(valueType);
/* 4857 */     if (deser != null) {
/* 4858 */       return deser;
/*      */     }
/*      */     
/* 4861 */     deser = ctxt.findRootValueDeserializer(valueType);
/* 4862 */     if (deser == null) {
/* 4863 */       return ctxt.<JsonDeserializer<Object>>reportBadDefinition(valueType, "Cannot find a deserializer for type " + valueType);
/*      */     }
/*      */     
/* 4866 */     this._rootDeserializers.put(valueType, deser);
/* 4867 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _verifySchemaType(FormatSchema schema) {
/* 4875 */     if (schema != null && 
/* 4876 */       !this._jsonFactory.canUseSchema(schema)) {
/* 4877 */       throw new IllegalArgumentException("Cannot use FormatSchema of type " + schema.getClass().getName() + " for format " + this._jsonFactory
/* 4878 */           .getFormatName());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _assertNotNull(String paramName, Object src) {
/* 4884 */     if (src == null)
/* 4885 */       throw new IllegalArgumentException(String.format("argument \"%s\" is null", new Object[] { paramName })); 
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ObjectMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */