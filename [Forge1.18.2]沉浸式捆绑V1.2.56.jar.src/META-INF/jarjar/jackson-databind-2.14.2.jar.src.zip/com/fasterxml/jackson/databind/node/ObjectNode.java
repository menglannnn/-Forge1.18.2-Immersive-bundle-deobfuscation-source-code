/*      */ package com.fasterxml.jackson.databind.node;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonPointer;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.SerializationFeature;
/*      */ import com.fasterxml.jackson.databind.SerializerProvider;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.JsonNodeFeature;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.util.RawValue;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public class ObjectNode
/*      */   extends ContainerNode<ObjectNode> implements Serializable {
/*      */   public ObjectNode(JsonNodeFactory nc) {
/*   31 */     super(nc);
/*   32 */     this._children = new LinkedHashMap<>();
/*      */   }
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected final Map<String, JsonNode> _children;
/*      */   
/*      */   public ObjectNode(JsonNodeFactory nc, Map<String, JsonNode> kids) {
/*   39 */     super(nc);
/*   40 */     this._children = kids;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonNode _at(JsonPointer ptr) {
/*   45 */     return get(ptr.getMatchingProperty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode deepCopy() {
/*   56 */     ObjectNode ret = new ObjectNode(this._nodeFactory);
/*      */     
/*   58 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*   59 */       ret._children.put(entry.getKey(), ((JsonNode)entry.getValue()).deepCopy());
/*      */     }
/*   61 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectNode with(String exprOrProperty) {
/*   74 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*   75 */     if (ptr != null) {
/*   76 */       return withObject(ptr);
/*      */     }
/*   78 */     JsonNode n = this._children.get(exprOrProperty);
/*   79 */     if (n != null) {
/*   80 */       if (n instanceof ObjectNode) {
/*   81 */         return (ObjectNode)n;
/*      */       }
/*   83 */       throw new UnsupportedOperationException("Property '" + exprOrProperty + "' has value that is not of type `ObjectNode` (but `" + n
/*      */           
/*   85 */           .getClass().getName() + "`)");
/*      */     } 
/*   87 */     ObjectNode result = objectNode();
/*   88 */     this._children.put(exprOrProperty, result);
/*   89 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode withArray(String exprOrProperty) {
/*   96 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*   97 */     if (ptr != null) {
/*   98 */       return withArray(ptr);
/*      */     }
/*  100 */     JsonNode n = this._children.get(exprOrProperty);
/*  101 */     if (n != null) {
/*  102 */       if (n instanceof ArrayNode) {
/*  103 */         return (ArrayNode)n;
/*      */       }
/*  105 */       throw new UnsupportedOperationException("Property '" + exprOrProperty + "' has value that is not of type `ArrayNode` (but `" + n
/*      */           
/*  107 */           .getClass().getName() + "`)");
/*      */     } 
/*  109 */     ArrayNode result = arrayNode();
/*  110 */     this._children.put(exprOrProperty, result);
/*  111 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectNode _withObject(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/*  119 */     if (currentPtr.matches()) {
/*  120 */       return this;
/*      */     }
/*      */     
/*  123 */     JsonNode n = _at(currentPtr);
/*      */     
/*  125 */     if (n != null && n instanceof BaseJsonNode) {
/*  126 */       ObjectNode found = ((BaseJsonNode)n)._withObject(origPtr, currentPtr.tail(), overwriteMode, preferIndex);
/*      */       
/*  128 */       if (found != null) {
/*  129 */         return found;
/*      */       }
/*      */       
/*  132 */       _withXxxVerifyReplace(origPtr, currentPtr, overwriteMode, preferIndex, n);
/*      */     } 
/*      */     
/*  135 */     return _withObjectAddTailProperty(currentPtr, preferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayNode _withArray(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/*  143 */     if (currentPtr.matches())
/*      */     {
/*  145 */       return null;
/*      */     }
/*      */     
/*  148 */     JsonNode n = _at(currentPtr);
/*      */     
/*  150 */     if (n != null && n instanceof BaseJsonNode) {
/*  151 */       ArrayNode found = ((BaseJsonNode)n)._withArray(origPtr, currentPtr.tail(), overwriteMode, preferIndex);
/*      */       
/*  153 */       if (found != null) {
/*  154 */         return found;
/*      */       }
/*      */       
/*  157 */       _withXxxVerifyReplace(origPtr, currentPtr, overwriteMode, preferIndex, n);
/*      */     } 
/*      */     
/*  160 */     return _withArrayAddTailProperty(currentPtr, preferIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ObjectNode _withObjectAddTailProperty(JsonPointer tail, boolean preferIndex) {
/*  165 */     String propName = tail.getMatchingProperty();
/*  166 */     tail = tail.tail();
/*      */ 
/*      */     
/*  169 */     if (tail.matches()) {
/*  170 */       return putObject(propName);
/*      */     }
/*      */ 
/*      */     
/*  174 */     if (preferIndex && tail.mayMatchElement()) {
/*  175 */       return putArray(propName)._withObjectAddTailElement(tail, preferIndex);
/*      */     }
/*  177 */     return putObject(propName)._withObjectAddTailProperty(tail, preferIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ArrayNode _withArrayAddTailProperty(JsonPointer tail, boolean preferIndex) {
/*  182 */     String propName = tail.getMatchingProperty();
/*  183 */     tail = tail.tail();
/*      */ 
/*      */     
/*  186 */     if (tail.matches()) {
/*  187 */       return putArray(propName);
/*      */     }
/*      */ 
/*      */     
/*  191 */     if (preferIndex && tail.mayMatchElement()) {
/*  192 */       return putArray(propName)._withArrayAddTailElement(tail, preferIndex);
/*      */     }
/*  194 */     return putObject(propName)._withArrayAddTailProperty(tail, preferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty(SerializerProvider serializers) {
/*  206 */     return this._children.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNodeType getNodeType() {
/*  217 */     return JsonNodeType.OBJECT;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isObject() {
/*  222 */     return true;
/*      */   }
/*      */   public JsonToken asToken() {
/*  225 */     return JsonToken.START_OBJECT;
/*      */   }
/*      */   
/*      */   public int size() {
/*  229 */     return this._children.size();
/*      */   }
/*      */   
/*      */   public boolean isEmpty() {
/*  233 */     return this._children.isEmpty();
/*      */   }
/*      */   
/*      */   public Iterator<JsonNode> elements() {
/*  237 */     return this._children.values().iterator();
/*      */   }
/*      */   
/*      */   public JsonNode get(int index) {
/*  241 */     return null;
/*      */   }
/*      */   
/*      */   public JsonNode get(String propertyName) {
/*  245 */     return this._children.get(propertyName);
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterator<String> fieldNames() {
/*  250 */     return this._children.keySet().iterator();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode path(int index) {
/*  255 */     return MissingNode.getInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode path(String propertyName) {
/*  261 */     JsonNode n = this._children.get(propertyName);
/*  262 */     if (n != null) {
/*  263 */       return n;
/*      */     }
/*  265 */     return MissingNode.getInstance();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode required(String propertyName) {
/*  270 */     JsonNode n = this._children.get(propertyName);
/*  271 */     if (n != null) {
/*  272 */       return n;
/*      */     }
/*  274 */     return (JsonNode)_reportRequiredViolation("No value for property '%s' of `ObjectNode`", new Object[] { propertyName });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<Map.Entry<String, JsonNode>> fields() {
/*  283 */     return this._children.entrySet().iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Comparator<JsonNode> comparator, JsonNode o) {
/*  289 */     if (!(o instanceof ObjectNode)) {
/*  290 */       return false;
/*      */     }
/*  292 */     ObjectNode other = (ObjectNode)o;
/*  293 */     Map<String, JsonNode> m1 = this._children;
/*  294 */     Map<String, JsonNode> m2 = other._children;
/*      */     
/*  296 */     int len = m1.size();
/*  297 */     if (m2.size() != len) {
/*  298 */       return false;
/*      */     }
/*      */     
/*  301 */     for (Map.Entry<String, JsonNode> entry : m1.entrySet()) {
/*  302 */       JsonNode v2 = m2.get(entry.getKey());
/*  303 */       if (v2 == null || !((JsonNode)entry.getValue()).equals(comparator, v2)) {
/*  304 */         return false;
/*      */       }
/*      */     } 
/*  307 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode findValue(String propertyName) {
/*  319 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*  320 */       if (propertyName.equals(entry.getKey())) {
/*  321 */         return entry.getValue();
/*      */       }
/*  323 */       JsonNode value = ((JsonNode)entry.getValue()).findValue(propertyName);
/*  324 */       if (value != null) {
/*  325 */         return value;
/*      */       }
/*      */     } 
/*  328 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JsonNode> findValues(String propertyName, List<JsonNode> foundSoFar) {
/*  334 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*  335 */       if (propertyName.equals(entry.getKey())) {
/*  336 */         if (foundSoFar == null) {
/*  337 */           foundSoFar = new ArrayList<>();
/*      */         }
/*  339 */         foundSoFar.add(entry.getValue()); continue;
/*      */       } 
/*  341 */       foundSoFar = ((JsonNode)entry.getValue()).findValues(propertyName, foundSoFar);
/*      */     } 
/*      */     
/*  344 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> findValuesAsText(String propertyName, List<String> foundSoFar) {
/*  350 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*  351 */       if (propertyName.equals(entry.getKey())) {
/*  352 */         if (foundSoFar == null) {
/*  353 */           foundSoFar = new ArrayList<>();
/*      */         }
/*  355 */         foundSoFar.add(((JsonNode)entry.getValue()).asText()); continue;
/*      */       } 
/*  357 */       foundSoFar = ((JsonNode)entry.getValue()).findValuesAsText(propertyName, foundSoFar);
/*      */     } 
/*      */ 
/*      */     
/*  361 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode findParent(String propertyName) {
/*  367 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*  368 */       if (propertyName.equals(entry.getKey())) {
/*  369 */         return this;
/*      */       }
/*  371 */       JsonNode value = ((JsonNode)entry.getValue()).findParent(propertyName);
/*  372 */       if (value != null) {
/*  373 */         return (ObjectNode)value;
/*      */       }
/*      */     } 
/*  376 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JsonNode> findParents(String propertyName, List<JsonNode> foundSoFar) {
/*  382 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*  383 */       if (propertyName.equals(entry.getKey())) {
/*  384 */         if (foundSoFar == null) {
/*  385 */           foundSoFar = new ArrayList<>();
/*      */         }
/*  387 */         foundSoFar.add(this);
/*      */         continue;
/*      */       } 
/*  390 */       foundSoFar = ((JsonNode)entry.getValue()).findParents(propertyName, foundSoFar);
/*      */     } 
/*      */     
/*  393 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serialize(JsonGenerator g, SerializerProvider provider) throws IOException {
/*  411 */     if (provider != null) {
/*  412 */       boolean trimEmptyArray = !provider.isEnabled(SerializationFeature.WRITE_EMPTY_JSON_ARRAYS);
/*  413 */       boolean skipNulls = !provider.isEnabled((DatatypeFeature)JsonNodeFeature.WRITE_NULL_PROPERTIES);
/*  414 */       if (trimEmptyArray || skipNulls) {
/*  415 */         g.writeStartObject(this);
/*  416 */         serializeFilteredContents(g, provider, trimEmptyArray, skipNulls);
/*  417 */         g.writeEndObject();
/*      */         return;
/*      */       } 
/*      */     } 
/*  421 */     g.writeStartObject(this);
/*  422 */     for (Map.Entry<String, JsonNode> en : this._children.entrySet()) {
/*  423 */       JsonNode value = en.getValue();
/*  424 */       g.writeFieldName(en.getKey());
/*  425 */       value.serialize(g, provider);
/*      */     } 
/*  427 */     g.writeEndObject();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeWithType(JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  436 */     boolean trimEmptyArray = false;
/*  437 */     boolean skipNulls = false;
/*  438 */     if (provider != null) {
/*  439 */       trimEmptyArray = !provider.isEnabled(SerializationFeature.WRITE_EMPTY_JSON_ARRAYS);
/*  440 */       skipNulls = !provider.isEnabled((DatatypeFeature)JsonNodeFeature.WRITE_NULL_PROPERTIES);
/*      */     } 
/*      */     
/*  443 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  444 */         .typeId(this, JsonToken.START_OBJECT));
/*      */     
/*  446 */     if (trimEmptyArray || skipNulls) {
/*  447 */       serializeFilteredContents(g, provider, trimEmptyArray, skipNulls);
/*      */     } else {
/*  449 */       for (Map.Entry<String, JsonNode> en : this._children.entrySet()) {
/*  450 */         JsonNode value = en.getValue();
/*  451 */         g.writeFieldName(en.getKey());
/*  452 */         value.serialize(g, provider);
/*      */       } 
/*      */     } 
/*  455 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void serializeFilteredContents(JsonGenerator g, SerializerProvider provider, boolean trimEmptyArray, boolean skipNulls) throws IOException {
/*  468 */     for (Map.Entry<String, JsonNode> en : this._children.entrySet()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  473 */       BaseJsonNode value = (BaseJsonNode)en.getValue();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  478 */       if (trimEmptyArray && value.isArray() && value.isEmpty(provider)) {
/*      */         continue;
/*      */       }
/*  481 */       if (skipNulls && value.isNull()) {
/*      */         continue;
/*      */       }
/*  484 */       g.writeFieldName(en.getKey());
/*  485 */       value.serialize(g, provider);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T set(String propertyName, JsonNode value) {
/*  517 */     if (value == null) {
/*  518 */       value = nullNode();
/*      */     }
/*  520 */     this._children.put(propertyName, value);
/*  521 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T setAll(Map<String, ? extends JsonNode> properties) {
/*  539 */     for (Map.Entry<String, ? extends JsonNode> en : properties.entrySet()) {
/*  540 */       JsonNode n = en.getValue();
/*  541 */       if (n == null) {
/*  542 */         n = nullNode();
/*      */       }
/*  544 */       this._children.put(en.getKey(), n);
/*      */     } 
/*  546 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T setAll(ObjectNode other) {
/*  564 */     this._children.putAll(other._children);
/*  565 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode replace(String propertyName, JsonNode value) {
/*  582 */     if (value == null) {
/*  583 */       value = nullNode();
/*      */     }
/*  585 */     return this._children.put(propertyName, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T without(String propertyName) {
/*  601 */     this._children.remove(propertyName);
/*  602 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T without(Collection<String> propertyNames) {
/*  620 */     this._children.keySet().removeAll(propertyNames);
/*  621 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonNode put(String propertyName, JsonNode value) {
/*  646 */     if (value == null) {
/*  647 */       value = nullNode();
/*      */     }
/*  649 */     return this._children.put(propertyName, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode putIfAbsent(String propertyName, JsonNode value) {
/*  677 */     if (value == null) {
/*  678 */       value = nullNode();
/*      */     }
/*  680 */     return this._children.putIfAbsent(propertyName, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode remove(String propertyName) {
/*  691 */     return this._children.remove(propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode remove(Collection<String> propertyNames) {
/*  704 */     this._children.keySet().removeAll(propertyNames);
/*  705 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode removeAll() {
/*  717 */     this._children.clear();
/*  718 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonNode putAll(Map<String, ? extends JsonNode> properties) {
/*  733 */     return setAll(properties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonNode putAll(ObjectNode other) {
/*  748 */     return setAll(other);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode retain(Collection<String> propertyNames) {
/*  761 */     this._children.keySet().retainAll(propertyNames);
/*  762 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode retain(String... propertyNames) {
/*  774 */     return retain(Arrays.asList(propertyNames));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode putArray(String propertyName) {
/*  796 */     ArrayNode n = arrayNode();
/*  797 */     _put(propertyName, n);
/*  798 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode putObject(String propertyName) {
/*  814 */     ObjectNode n = objectNode();
/*  815 */     _put(propertyName, n);
/*  816 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode putPOJO(String propertyName, Object pojo) {
/*  838 */     return _put(propertyName, pojoNode(pojo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode putRawValue(String propertyName, RawValue raw) {
/*  845 */     return _put(propertyName, rawValueNode(raw));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode putNull(String propertyName) {
/*  857 */     this._children.put(propertyName, nullNode());
/*  858 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, short v) {
/*  867 */     return _put(propertyName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, Short v) {
/*  877 */     return _put(fieldName, (v == null) ? nullNode() : 
/*  878 */         numberNode(v.shortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, int v) {
/*  891 */     return _put(fieldName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, Integer v) {
/*  901 */     return _put(fieldName, (v == null) ? nullNode() : 
/*  902 */         numberNode(v.intValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, long v) {
/*  915 */     return _put(fieldName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, Long v) {
/*  931 */     return _put(fieldName, (v == null) ? nullNode() : 
/*  932 */         numberNode(v.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, float v) {
/*  941 */     return _put(fieldName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, Float v) {
/*  951 */     return _put(fieldName, (v == null) ? nullNode() : 
/*  952 */         numberNode(v.floatValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, double v) {
/*  961 */     return _put(fieldName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, Double v) {
/*  971 */     return _put(fieldName, (v == null) ? nullNode() : 
/*  972 */         numberNode(v.doubleValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, BigDecimal v) {
/*  981 */     return _put(fieldName, (v == null) ? nullNode() : 
/*  982 */         numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, BigInteger v) {
/*  993 */     return _put(fieldName, (v == null) ? nullNode() : 
/*  994 */         numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, String v) {
/* 1003 */     return _put(fieldName, (v == null) ? nullNode() : 
/* 1004 */         textNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, boolean v) {
/* 1013 */     return _put(fieldName, booleanNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, Boolean v) {
/* 1023 */     return _put(fieldName, (v == null) ? nullNode() : 
/* 1024 */         booleanNode(v.booleanValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String fieldName, byte[] v) {
/* 1033 */     return _put(fieldName, (v == null) ? nullNode() : 
/* 1034 */         binaryNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/* 1046 */     if (o == this) return true; 
/* 1047 */     if (o == null) return false; 
/* 1048 */     if (o instanceof ObjectNode) {
/* 1049 */       return _childrenEqual((ObjectNode)o);
/*      */     }
/* 1051 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _childrenEqual(ObjectNode other) {
/* 1059 */     return this._children.equals(other._children);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1065 */     return this._children.hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectNode _put(String fieldName, JsonNode value) {
/* 1076 */     this._children.put(fieldName, value);
/* 1077 */     return this;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\node\ObjectNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */