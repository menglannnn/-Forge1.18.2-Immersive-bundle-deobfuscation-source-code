/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ReadOnlyClassToSerializerMap;
/*     */ import com.fasterxml.jackson.databind.util.LRUMap;
/*     */ import com.fasterxml.jackson.databind.util.TypeKey;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SerializerCache
/*     */ {
/*     */   public static final int DEFAULT_MAX_CACHED = 4000;
/*     */   private final LRUMap<TypeKey, JsonSerializer<Object>> _sharedMap;
/*     */   private final AtomicReference<ReadOnlyClassToSerializerMap> _readOnlyMap;
/*     */   
/*     */   public SerializerCache() {
/*  47 */     this(4000);
/*     */   }
/*     */   
/*     */   public SerializerCache(int maxCached) {
/*  51 */     int initial = Math.min(64, maxCached >> 2);
/*  52 */     this._sharedMap = new LRUMap(initial, maxCached);
/*  53 */     this._readOnlyMap = new AtomicReference<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyClassToSerializerMap getReadOnlyLookupMap() {
/*  62 */     ReadOnlyClassToSerializerMap m = this._readOnlyMap.get();
/*  63 */     if (m != null) {
/*  64 */       return m;
/*     */     }
/*  66 */     return _makeReadOnlyLookupMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final synchronized ReadOnlyClassToSerializerMap _makeReadOnlyLookupMap() {
/*  72 */     ReadOnlyClassToSerializerMap m = this._readOnlyMap.get();
/*  73 */     if (m == null) {
/*  74 */       m = ReadOnlyClassToSerializerMap.from(this._sharedMap);
/*  75 */       this._readOnlyMap.set(m);
/*     */     } 
/*  77 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int size() {
/*  87 */     return this._sharedMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> untypedValueSerializer(Class<?> type) {
/*  96 */     synchronized (this) {
/*  97 */       return (JsonSerializer<Object>)this._sharedMap.get(new TypeKey(type, false));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> untypedValueSerializer(JavaType type) {
/* 103 */     synchronized (this) {
/* 104 */       return (JsonSerializer<Object>)this._sharedMap.get(new TypeKey(type, false));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> typedValueSerializer(JavaType type) {
/* 110 */     synchronized (this) {
/* 111 */       return (JsonSerializer<Object>)this._sharedMap.get(new TypeKey(type, true));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> typedValueSerializer(Class<?> cls) {
/* 117 */     synchronized (this) {
/* 118 */       return (JsonSerializer<Object>)this._sharedMap.get(new TypeKey(cls, true));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTypedSerializer(JavaType type, JsonSerializer<Object> ser) {
/* 135 */     synchronized (this) {
/* 136 */       if (this._sharedMap.put(new TypeKey(type, true), ser) == null)
/*     */       {
/* 138 */         this._readOnlyMap.set(null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addTypedSerializer(Class<?> cls, JsonSerializer<Object> ser) {
/* 145 */     synchronized (this) {
/* 146 */       if (this._sharedMap.put(new TypeKey(cls, true), ser) == null)
/*     */       {
/* 148 */         this._readOnlyMap.set(null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAndResolveNonTypedSerializer(Class<?> type, JsonSerializer<Object> ser, SerializerProvider provider) throws JsonMappingException {
/* 157 */     synchronized (this) {
/* 158 */       if (this._sharedMap.put(new TypeKey(type, false), ser) == null) {
/* 159 */         this._readOnlyMap.set(null);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 166 */       if (ser instanceof ResolvableSerializer) {
/* 167 */         ((ResolvableSerializer)ser).resolve(provider);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAndResolveNonTypedSerializer(JavaType type, JsonSerializer<Object> ser, SerializerProvider provider) throws JsonMappingException {
/* 176 */     synchronized (this) {
/* 177 */       if (this._sharedMap.put(new TypeKey(type, false), ser) == null) {
/* 178 */         this._readOnlyMap.set(null);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       if (ser instanceof ResolvableSerializer) {
/* 186 */         ((ResolvableSerializer)ser).resolve(provider);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAndResolveNonTypedSerializer(Class<?> rawType, JavaType fullType, JsonSerializer<Object> ser, SerializerProvider provider) throws JsonMappingException {
/* 202 */     synchronized (this) {
/* 203 */       Object ob1 = this._sharedMap.put(new TypeKey(rawType, false), ser);
/* 204 */       Object ob2 = this._sharedMap.put(new TypeKey(fullType, false), ser);
/* 205 */       if (ob1 == null || ob2 == null) {
/* 206 */         this._readOnlyMap.set(null);
/*     */       }
/* 208 */       if (ser instanceof ResolvableSerializer) {
/* 209 */         ((ResolvableSerializer)ser).resolve(provider);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void flush() {
/* 219 */     this._sharedMap.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ser\SerializerCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */