/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import java.io.Closeable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnresolvedForwardReference
/*     */   extends JsonMappingException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private ReadableObjectId _roid;
/*     */   private List<UnresolvedId> _unresolvedIds;
/*     */   
/*     */   public UnresolvedForwardReference(JsonParser p, String msg, JsonLocation loc, ReadableObjectId roid) {
/*  28 */     super((Closeable)p, msg, loc);
/*  29 */     this._roid = roid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnresolvedForwardReference(JsonParser p, String msg) {
/*  36 */     super((Closeable)p, msg);
/*  37 */     this._unresolvedIds = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadableObjectId getRoid() {
/*  47 */     return this._roid;
/*     */   }
/*     */   
/*     */   public Object getUnresolvedId() {
/*  51 */     return (this._roid.getKey()).key;
/*     */   }
/*     */   
/*     */   public void addUnresolvedId(Object id, Class<?> type, JsonLocation where) {
/*  55 */     this._unresolvedIds.add(new UnresolvedId(id, type, where));
/*     */   }
/*     */   
/*     */   public List<UnresolvedId> getUnresolvedIds() {
/*  59 */     return this._unresolvedIds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*  65 */     String msg = super.getMessage();
/*  66 */     if (this._unresolvedIds == null) {
/*  67 */       return msg;
/*     */     }
/*     */     
/*  70 */     StringBuilder sb = new StringBuilder(msg);
/*  71 */     Iterator<UnresolvedId> iterator = this._unresolvedIds.iterator();
/*  72 */     while (iterator.hasNext()) {
/*  73 */       UnresolvedId unresolvedId = iterator.next();
/*  74 */       sb.append(unresolvedId.toString());
/*  75 */       if (iterator.hasNext()) {
/*  76 */         sb.append(", ");
/*     */       }
/*     */     } 
/*  79 */     sb.append('.');
/*  80 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized UnresolvedForwardReference fillInStackTrace() {
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnresolvedForwardReference withStackTrace() {
/* 104 */     super.fillInStackTrace();
/* 105 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\UnresolvedForwardReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */