/*      */ package com.fasterxml.jackson.databind.util;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.StreamWriteCapability;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.core.json.JsonWriteContext;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class TokenBuffer extends JsonGenerator {
/*   29 */   protected static final int DEFAULT_GENERATOR_FEATURES = JsonGenerator.Feature.collectDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonStreamContext _parentContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _generatorFeatures;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _closed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasNativeTypeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasNativeObjectIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _mayHaveNativeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _forceBigDecimal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Segment _first;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Segment _last;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _appendAt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _typeId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _objectId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasNativeId = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonWriteContext _writeContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer(ObjectCodec codec, boolean hasNativeIds) {
/*  148 */     this._objectCodec = codec;
/*  149 */     this._generatorFeatures = DEFAULT_GENERATOR_FEATURES;
/*  150 */     this._writeContext = JsonWriteContext.createRootContext(null);
/*      */     
/*  152 */     this._first = this._last = new Segment();
/*  153 */     this._appendAt = 0;
/*  154 */     this._hasNativeTypeIds = hasNativeIds;
/*  155 */     this._hasNativeObjectIds = hasNativeIds;
/*      */     
/*  157 */     this._mayHaveNativeIds = (this._hasNativeTypeIds || this._hasNativeObjectIds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer(JsonParser p) {
/*  164 */     this(p, (DeserializationContext)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer(JsonParser p, DeserializationContext ctxt) {
/*  172 */     this._objectCodec = p.getCodec();
/*  173 */     this._parentContext = p.getParsingContext();
/*  174 */     this._generatorFeatures = DEFAULT_GENERATOR_FEATURES;
/*  175 */     this._writeContext = JsonWriteContext.createRootContext(null);
/*      */     
/*  177 */     this._first = this._last = new Segment();
/*  178 */     this._appendAt = 0;
/*  179 */     this._hasNativeTypeIds = p.canReadTypeId();
/*  180 */     this._hasNativeObjectIds = p.canReadObjectId();
/*  181 */     this._mayHaveNativeIds = (this._hasNativeTypeIds || this._hasNativeObjectIds);
/*  182 */     this
/*  183 */       ._forceBigDecimal = (ctxt == null) ? false : ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static TokenBuffer asCopyOfValue(JsonParser p) throws IOException {
/*  200 */     TokenBuffer b = new TokenBuffer(p);
/*  201 */     b.copyCurrentStructure(p);
/*  202 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer overrideParentContext(JsonStreamContext ctxt) {
/*  214 */     this._parentContext = ctxt;
/*  215 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer forceUseOfBigDecimal(boolean b) {
/*  222 */     this._forceBigDecimal = b;
/*  223 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Version version() {
/*  228 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParser() {
/*  242 */     return asParser(this._objectCodec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParserOnFirstToken() throws IOException {
/*  256 */     JsonParser p = asParser(this._objectCodec);
/*  257 */     p.nextToken();
/*  258 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParser(ObjectCodec codec) {
/*  276 */     return (JsonParser)new Parser(this._first, codec, this._hasNativeTypeIds, this._hasNativeObjectIds, this._parentContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParser(JsonParser src) {
/*  285 */     Parser p = new Parser(this._first, src.getCodec(), this._hasNativeTypeIds, this._hasNativeObjectIds, this._parentContext);
/*  286 */     p.setLocation(src.getTokenLocation());
/*  287 */     return (JsonParser)p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken firstToken() {
/*  298 */     return this._first.type(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  310 */     return (this._appendAt == 0 && this._first == this._last);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer append(TokenBuffer other) throws IOException {
/*  329 */     if (!this._hasNativeTypeIds) {
/*  330 */       this._hasNativeTypeIds = other.canWriteTypeId();
/*      */     }
/*  332 */     if (!this._hasNativeObjectIds) {
/*  333 */       this._hasNativeObjectIds = other.canWriteObjectId();
/*      */     }
/*  335 */     this._mayHaveNativeIds = (this._hasNativeTypeIds || this._hasNativeObjectIds);
/*      */     
/*  337 */     JsonParser p = other.asParser();
/*  338 */     while (p.nextToken() != null) {
/*  339 */       copyCurrentStructure(p);
/*      */     }
/*  341 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serialize(JsonGenerator gen) throws IOException {
/*  356 */     Segment segment = this._first;
/*  357 */     int ptr = -1;
/*      */     
/*  359 */     boolean checkIds = this._mayHaveNativeIds;
/*  360 */     boolean hasIds = (checkIds && segment.hasIds());
/*      */     while (true) {
/*      */       Object ob, n, value;
/*  363 */       if (++ptr >= 16) {
/*  364 */         ptr = 0;
/*  365 */         segment = segment.next();
/*  366 */         if (segment == null)
/*  367 */           break;  hasIds = (checkIds && segment.hasIds());
/*      */       } 
/*  369 */       JsonToken t = segment.type(ptr);
/*  370 */       if (t == null)
/*      */         break; 
/*  372 */       if (hasIds) {
/*  373 */         Object id = segment.findObjectId(ptr);
/*  374 */         if (id != null) {
/*  375 */           gen.writeObjectId(id);
/*      */         }
/*  377 */         id = segment.findTypeId(ptr);
/*  378 */         if (id != null) {
/*  379 */           gen.writeTypeId(id);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  384 */       switch (t) {
/*      */         case INT:
/*  386 */           gen.writeStartObject();
/*      */           continue;
/*      */         case BIG_INTEGER:
/*  389 */           gen.writeEndObject();
/*      */           continue;
/*      */         case BIG_DECIMAL:
/*  392 */           gen.writeStartArray();
/*      */           continue;
/*      */         case FLOAT:
/*  395 */           gen.writeEndArray();
/*      */           continue;
/*      */ 
/*      */         
/*      */         case LONG:
/*  400 */           ob = segment.get(ptr);
/*  401 */           if (ob instanceof SerializableString) {
/*  402 */             gen.writeFieldName((SerializableString)ob); continue;
/*      */           } 
/*  404 */           gen.writeFieldName((String)ob);
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/*  410 */           ob = segment.get(ptr);
/*  411 */           if (ob instanceof SerializableString) {
/*  412 */             gen.writeString((SerializableString)ob); continue;
/*      */           } 
/*  414 */           gen.writeString((String)ob);
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/*  420 */           n = segment.get(ptr);
/*  421 */           if (n instanceof Integer) {
/*  422 */             gen.writeNumber(((Integer)n).intValue()); continue;
/*  423 */           }  if (n instanceof BigInteger) {
/*  424 */             gen.writeNumber((BigInteger)n); continue;
/*  425 */           }  if (n instanceof Long) {
/*  426 */             gen.writeNumber(((Long)n).longValue()); continue;
/*  427 */           }  if (n instanceof Short) {
/*  428 */             gen.writeNumber(((Short)n).shortValue()); continue;
/*      */           } 
/*  430 */           gen.writeNumber(((Number)n).intValue());
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/*  436 */           n = segment.get(ptr);
/*  437 */           if (n instanceof Double) {
/*  438 */             gen.writeNumber(((Double)n).doubleValue()); continue;
/*  439 */           }  if (n instanceof BigDecimal) {
/*  440 */             gen.writeNumber((BigDecimal)n); continue;
/*  441 */           }  if (n instanceof Float) {
/*  442 */             gen.writeNumber(((Float)n).floatValue()); continue;
/*  443 */           }  if (n == null) {
/*  444 */             gen.writeNull(); continue;
/*  445 */           }  if (n instanceof String) {
/*  446 */             gen.writeNumber((String)n); continue;
/*      */           } 
/*  448 */           _reportError(String.format("Unrecognized value type for VALUE_NUMBER_FLOAT: %s, cannot serialize", new Object[] { n
/*      */                   
/*  450 */                   .getClass().getName() }));
/*      */           continue;
/*      */ 
/*      */         
/*      */         case null:
/*  455 */           gen.writeBoolean(true);
/*      */           continue;
/*      */         case null:
/*  458 */           gen.writeBoolean(false);
/*      */           continue;
/*      */         case null:
/*  461 */           gen.writeNull();
/*      */           continue;
/*      */         
/*      */         case null:
/*  465 */           value = segment.get(ptr);
/*      */ 
/*      */ 
/*      */           
/*  469 */           if (value instanceof RawValue) {
/*  470 */             ((RawValue)value).serialize(gen); continue;
/*  471 */           }  if (value instanceof com.fasterxml.jackson.databind.JsonSerializable) {
/*  472 */             gen.writeObject(value); continue;
/*      */           } 
/*  474 */           gen.writeEmbeddedObject(value);
/*      */           continue;
/*      */       } 
/*      */ 
/*      */       
/*  479 */       throw new RuntimeException("Internal error: should never end up through this code path");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  491 */     if (!p.hasToken(JsonToken.FIELD_NAME)) {
/*  492 */       copyCurrentStructure(p);
/*  493 */       return this;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  499 */     writeStartObject(); JsonToken t;
/*      */     do {
/*  501 */       copyCurrentStructure(p);
/*  502 */     } while ((t = p.nextToken()) == JsonToken.FIELD_NAME);
/*  503 */     if (t != JsonToken.END_OBJECT) {
/*  504 */       ctxt.reportWrongTokenException(TokenBuffer.class, JsonToken.END_OBJECT, "Expected END_OBJECT after copying contents of a JsonParser into TokenBuffer, got " + t, new Object[0]);
/*      */     }
/*      */ 
/*      */     
/*  508 */     writeEndObject();
/*  509 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  517 */     int MAX_COUNT = 100;
/*      */     
/*  519 */     StringBuilder sb = new StringBuilder();
/*  520 */     sb.append("[TokenBuffer: ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  527 */     JsonParser jp = asParser();
/*  528 */     int count = 0;
/*  529 */     boolean hasNativeIds = (this._hasNativeTypeIds || this._hasNativeObjectIds);
/*      */ 
/*      */     
/*      */     while (true) {
/*      */       try {
/*  534 */         JsonToken t = jp.nextToken();
/*  535 */         if (t == null)
/*      */           break; 
/*  537 */         if (hasNativeIds) {
/*  538 */           _appendNativeIds(sb);
/*      */         }
/*      */         
/*  541 */         if (count < 100) {
/*  542 */           if (count > 0) {
/*  543 */             sb.append(", ");
/*      */           }
/*  545 */           sb.append(t.toString());
/*  546 */           if (t == JsonToken.FIELD_NAME) {
/*  547 */             sb.append('(');
/*  548 */             sb.append(jp.currentName());
/*  549 */             sb.append(')');
/*      */           } 
/*      */         } 
/*  552 */       } catch (IOException ioe) {
/*  553 */         throw new IllegalStateException(ioe);
/*      */       } 
/*  555 */       count++;
/*      */     } 
/*      */     
/*  558 */     if (count >= 100) {
/*  559 */       sb.append(" ... (truncated ").append(count - 100).append(" entries)");
/*      */     }
/*  561 */     sb.append(']');
/*  562 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _appendNativeIds(StringBuilder sb) {
/*  567 */     Object objectId = this._last.findObjectId(this._appendAt - 1);
/*  568 */     if (objectId != null) {
/*  569 */       sb.append("[objectId=").append(String.valueOf(objectId)).append(']');
/*      */     }
/*  571 */     Object typeId = this._last.findTypeId(this._appendAt - 1);
/*  572 */     if (typeId != null) {
/*  573 */       sb.append("[typeId=").append(String.valueOf(typeId)).append(']');
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator enable(JsonGenerator.Feature f) {
/*  585 */     this._generatorFeatures |= f.getMask();
/*  586 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonGenerator disable(JsonGenerator.Feature f) {
/*  591 */     this._generatorFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  592 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonGenerator.Feature f) {
/*  599 */     return ((this._generatorFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFeatureMask() {
/*  604 */     return this._generatorFeatures;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator setFeatureMask(int mask) {
/*  611 */     this._generatorFeatures = mask;
/*  612 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonGenerator overrideStdFeatures(int values, int mask) {
/*  617 */     int oldState = getFeatureMask();
/*  618 */     this._generatorFeatures = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  619 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator useDefaultPrettyPrinter() {
/*  625 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonGenerator setCodec(ObjectCodec oc) {
/*  630 */     this._objectCodec = oc;
/*  631 */     return this;
/*      */   }
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  635 */     return this._objectCodec;
/*      */   }
/*      */   public final JsonWriteContext getOutputContext() {
/*  638 */     return this._writeContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteBinaryNatively() {
/*  651 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities() {
/*  660 */     return DEFAULT_WRITE_CAPABILITIES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/*  674 */     this._closed = true;
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/*  678 */     return this._closed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartArray() throws IOException {
/*  689 */     this._writeContext.writeValue();
/*  690 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  691 */     this._writeContext = this._writeContext.createChildArrayContext();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue) throws IOException {
/*  696 */     this._writeContext.writeValue();
/*  697 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  698 */     this._writeContext = this._writeContext.createChildArrayContext(forValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue, int size) throws IOException {
/*  703 */     this._writeContext.writeValue();
/*  704 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  705 */     this._writeContext = this._writeContext.createChildArrayContext(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeEndArray() throws IOException {
/*  711 */     _appendEndMarker(JsonToken.END_ARRAY);
/*      */     
/*  713 */     JsonWriteContext c = this._writeContext.getParent();
/*  714 */     if (c != null) {
/*  715 */       this._writeContext = c;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartObject() throws IOException {
/*  722 */     this._writeContext.writeValue();
/*  723 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  724 */     this._writeContext = this._writeContext.createChildObjectContext();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/*  730 */     this._writeContext.writeValue();
/*  731 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  732 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  733 */     this._writeContext = ctxt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/*  739 */     this._writeContext.writeValue();
/*  740 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  741 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  742 */     this._writeContext = ctxt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeEndObject() throws IOException {
/*  748 */     _appendEndMarker(JsonToken.END_OBJECT);
/*      */     
/*  750 */     JsonWriteContext c = this._writeContext.getParent();
/*  751 */     if (c != null) {
/*  752 */       this._writeContext = c;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeFieldName(String name) throws IOException {
/*  759 */     this._writeContext.writeFieldName(name);
/*  760 */     _appendFieldName(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(SerializableString name) throws IOException {
/*  766 */     this._writeContext.writeFieldName(name.getValue());
/*  767 */     _appendFieldName(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(String text) throws IOException {
/*  778 */     if (text == null) {
/*  779 */       writeNull();
/*      */     } else {
/*  781 */       _appendValue(JsonToken.VALUE_STRING, text);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException {
/*  787 */     writeString(new String(text, offset, len));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeString(SerializableString text) throws IOException {
/*  792 */     if (text == null) {
/*  793 */       writeNull();
/*      */     } else {
/*  795 */       _appendValue(JsonToken.VALUE_STRING, text);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length) throws IOException {
/*  803 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int length) throws IOException {
/*  810 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(String text) throws IOException {
/*  815 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException {
/*  820 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException {
/*  825 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(char[] text, int offset, int len) throws IOException {
/*  830 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(char c) throws IOException {
/*  835 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRawValue(String text) throws IOException {
/*  840 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new RawValue(text));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRawValue(String text, int offset, int len) throws IOException {
/*  845 */     if (offset > 0 || len != text.length()) {
/*  846 */       text = text.substring(offset, offset + len);
/*      */     }
/*  848 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new RawValue(text));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRawValue(char[] text, int offset, int len) throws IOException {
/*  853 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new String(text, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short i) throws IOException {
/*  864 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Short.valueOf(i));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(int i) throws IOException {
/*  869 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Integer.valueOf(i));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(long l) throws IOException {
/*  874 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Long.valueOf(l));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(double d) throws IOException {
/*  879 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, Double.valueOf(d));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(float f) throws IOException {
/*  884 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, Float.valueOf(f));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(BigDecimal dec) throws IOException {
/*  889 */     if (dec == null) {
/*  890 */       writeNull();
/*      */     } else {
/*  892 */       _appendValue(JsonToken.VALUE_NUMBER_FLOAT, dec);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(BigInteger v) throws IOException {
/*  898 */     if (v == null) {
/*  899 */       writeNull();
/*      */     } else {
/*  901 */       _appendValue(JsonToken.VALUE_NUMBER_INT, v);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue) throws IOException {
/*  910 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, encodedValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeBoolean(boolean state) throws IOException {
/*  915 */     _appendValue(state ? JsonToken.VALUE_TRUE : JsonToken.VALUE_FALSE);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNull() throws IOException {
/*  920 */     _appendValue(JsonToken.VALUE_NULL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObject(Object value) throws IOException {
/*  932 */     if (value == null) {
/*  933 */       writeNull();
/*      */       return;
/*      */     } 
/*  936 */     Class<?> raw = value.getClass();
/*  937 */     if (raw == byte[].class || value instanceof RawValue) {
/*  938 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, value);
/*      */       return;
/*      */     } 
/*  941 */     if (this._objectCodec == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  946 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, value);
/*      */     } else {
/*  948 */       this._objectCodec.writeValue(this, value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTree(TreeNode node) throws IOException {
/*  955 */     if (node == null) {
/*  956 */       writeNull();
/*      */       
/*      */       return;
/*      */     } 
/*  960 */     if (this._objectCodec == null) {
/*      */       
/*  962 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, node);
/*      */     } else {
/*  964 */       this._objectCodec.writeTree(this, node);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException {
/*  983 */     byte[] copy = new byte[len];
/*  984 */     System.arraycopy(data, offset, copy, 0, len);
/*  985 */     writeObject(copy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) {
/*  996 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteTypeId() {
/* 1007 */     return this._hasNativeTypeIds;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean canWriteObjectId() {
/* 1012 */     return this._hasNativeObjectIds;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeTypeId(Object id) {
/* 1017 */     this._typeId = id;
/* 1018 */     this._hasNativeId = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeObjectId(Object id) {
/* 1023 */     this._objectId = id;
/* 1024 */     this._hasNativeId = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeEmbeddedObject(Object object) throws IOException {
/* 1029 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentEvent(JsonParser p) throws IOException {
/* 1041 */     if (this._mayHaveNativeIds) {
/* 1042 */       _checkNativeIds(p);
/*      */     }
/* 1044 */     switch (p.currentToken()) {
/*      */       case INT:
/* 1046 */         writeStartObject();
/*      */         return;
/*      */       case BIG_INTEGER:
/* 1049 */         writeEndObject();
/*      */         return;
/*      */       case BIG_DECIMAL:
/* 1052 */         writeStartArray();
/*      */         return;
/*      */       case FLOAT:
/* 1055 */         writeEndArray();
/*      */         return;
/*      */       case LONG:
/* 1058 */         writeFieldName(p.currentName());
/*      */         return;
/*      */       case null:
/* 1061 */         if (p.hasTextCharacters()) {
/* 1062 */           writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */         } else {
/* 1064 */           writeString(p.getText());
/*      */         } 
/*      */         return;
/*      */       case null:
/* 1068 */         switch (p.getNumberType()) {
/*      */           case INT:
/* 1070 */             writeNumber(p.getIntValue());
/*      */             return;
/*      */           case BIG_INTEGER:
/* 1073 */             writeNumber(p.getBigIntegerValue());
/*      */             return;
/*      */         } 
/* 1076 */         writeNumber(p.getLongValue());
/*      */         return;
/*      */       
/*      */       case null:
/* 1080 */         if (this._forceBigDecimal) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1085 */           writeNumber(p.getDecimalValue());
/*      */         } else {
/* 1087 */           switch (p.getNumberType()) {
/*      */             case BIG_DECIMAL:
/* 1089 */               writeNumber(p.getDecimalValue());
/*      */               return;
/*      */             case FLOAT:
/* 1092 */               writeNumber(p.getFloatValue());
/*      */               return;
/*      */           } 
/* 1095 */           writeNumber(p.getDoubleValue());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case null:
/* 1100 */         writeBoolean(true);
/*      */         return;
/*      */       case null:
/* 1103 */         writeBoolean(false);
/*      */         return;
/*      */       case null:
/* 1106 */         writeNull();
/*      */         return;
/*      */       case null:
/* 1109 */         writeObject(p.getEmbeddedObject());
/*      */         return;
/*      */     } 
/* 1112 */     throw new RuntimeException("Internal error: unexpected token: " + p.currentToken());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentStructure(JsonParser p) throws IOException {
/* 1119 */     JsonToken t = p.currentToken();
/*      */ 
/*      */     
/* 1122 */     if (t == JsonToken.FIELD_NAME) {
/* 1123 */       if (this._mayHaveNativeIds) {
/* 1124 */         _checkNativeIds(p);
/*      */       }
/* 1126 */       writeFieldName(p.currentName());
/* 1127 */       t = p.nextToken();
/*      */     }
/* 1129 */     else if (t == null) {
/* 1130 */       throw new IllegalStateException("No token available from argument `JsonParser`");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1136 */     switch (t) {
/*      */       case BIG_DECIMAL:
/* 1138 */         if (this._mayHaveNativeIds) {
/* 1139 */           _checkNativeIds(p);
/*      */         }
/* 1141 */         writeStartArray();
/* 1142 */         _copyBufferContents(p);
/*      */         return;
/*      */       case INT:
/* 1145 */         if (this._mayHaveNativeIds) {
/* 1146 */           _checkNativeIds(p);
/*      */         }
/* 1148 */         writeStartObject();
/* 1149 */         _copyBufferContents(p);
/*      */         return;
/*      */       case FLOAT:
/* 1152 */         writeEndArray();
/*      */         return;
/*      */       case BIG_INTEGER:
/* 1155 */         writeEndObject();
/*      */         return;
/*      */     } 
/* 1158 */     _copyBufferValue(p, t);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _copyBufferContents(JsonParser p) throws IOException {
/* 1164 */     int depth = 1;
/*      */     
/*      */     JsonToken t;
/* 1167 */     while ((t = p.nextToken()) != null) {
/* 1168 */       switch (t) {
/*      */         case LONG:
/* 1170 */           if (this._mayHaveNativeIds) {
/* 1171 */             _checkNativeIds(p);
/*      */           }
/* 1173 */           writeFieldName(p.currentName());
/*      */           continue;
/*      */         
/*      */         case BIG_DECIMAL:
/* 1177 */           if (this._mayHaveNativeIds) {
/* 1178 */             _checkNativeIds(p);
/*      */           }
/* 1180 */           writeStartArray();
/* 1181 */           depth++;
/*      */           continue;
/*      */         
/*      */         case INT:
/* 1185 */           if (this._mayHaveNativeIds) {
/* 1186 */             _checkNativeIds(p);
/*      */           }
/* 1188 */           writeStartObject();
/* 1189 */           depth++;
/*      */           continue;
/*      */         
/*      */         case FLOAT:
/* 1193 */           writeEndArray();
/* 1194 */           if (--depth == 0) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */         case BIG_INTEGER:
/* 1199 */           writeEndObject();
/* 1200 */           if (--depth == 0) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */       } 
/*      */       
/* 1206 */       _copyBufferValue(p, t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _copyBufferValue(JsonParser p, JsonToken t) throws IOException {
/* 1214 */     if (this._mayHaveNativeIds) {
/* 1215 */       _checkNativeIds(p);
/*      */     }
/* 1217 */     switch (t) {
/*      */       case null:
/* 1219 */         if (p.hasTextCharacters()) {
/* 1220 */           writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */         } else {
/* 1222 */           writeString(p.getText());
/*      */         } 
/*      */         return;
/*      */       case null:
/* 1226 */         switch (p.getNumberType()) {
/*      */           case INT:
/* 1228 */             writeNumber(p.getIntValue());
/*      */             return;
/*      */           case BIG_INTEGER:
/* 1231 */             writeNumber(p.getBigIntegerValue());
/*      */             return;
/*      */         } 
/* 1234 */         writeNumber(p.getLongValue());
/*      */         return;
/*      */       
/*      */       case null:
/* 1238 */         if (this._forceBigDecimal) {
/* 1239 */           writeNumber(p.getDecimalValue());
/*      */         }
/*      */         else {
/*      */           
/* 1243 */           Number n = p.getNumberValueExact();
/* 1244 */           _appendValue(JsonToken.VALUE_NUMBER_FLOAT, n);
/*      */         } 
/*      */         return;
/*      */       case null:
/* 1248 */         writeBoolean(true);
/*      */         return;
/*      */       case null:
/* 1251 */         writeBoolean(false);
/*      */         return;
/*      */       case null:
/* 1254 */         writeNull();
/*      */         return;
/*      */       case null:
/* 1257 */         writeObject(p.getEmbeddedObject());
/*      */         return;
/*      */     } 
/* 1260 */     throw new RuntimeException("Internal error: unexpected token: " + t);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _checkNativeIds(JsonParser p) throws IOException {
/* 1266 */     if ((this._typeId = p.getTypeId()) != null) {
/* 1267 */       this._hasNativeId = true;
/*      */     }
/* 1269 */     if ((this._objectId = p.getObjectId()) != null) {
/* 1270 */       this._hasNativeId = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendValue(JsonToken type) {
/*      */     Segment next;
/* 1323 */     this._writeContext.writeValue();
/*      */     
/* 1325 */     if (this._hasNativeId) {
/* 1326 */       next = this._last.append(this._appendAt, type, this._objectId, this._typeId);
/*      */     } else {
/* 1328 */       next = this._last.append(this._appendAt, type);
/*      */     } 
/* 1330 */     if (next == null) {
/* 1331 */       this._appendAt++;
/*      */     } else {
/* 1333 */       this._last = next;
/* 1334 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendValue(JsonToken type, Object value) {
/*      */     Segment next;
/* 1346 */     this._writeContext.writeValue();
/*      */     
/* 1348 */     if (this._hasNativeId) {
/* 1349 */       next = this._last.append(this._appendAt, type, value, this._objectId, this._typeId);
/*      */     } else {
/* 1351 */       next = this._last.append(this._appendAt, type, value);
/*      */     } 
/* 1353 */     if (next == null) {
/* 1354 */       this._appendAt++;
/*      */     } else {
/* 1356 */       this._last = next;
/* 1357 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendFieldName(Object value) {
/*      */     Segment next;
/* 1371 */     if (this._hasNativeId) {
/* 1372 */       next = this._last.append(this._appendAt, JsonToken.FIELD_NAME, value, this._objectId, this._typeId);
/*      */     } else {
/* 1374 */       next = this._last.append(this._appendAt, JsonToken.FIELD_NAME, value);
/*      */     } 
/* 1376 */     if (next == null) {
/* 1377 */       this._appendAt++;
/*      */     } else {
/* 1379 */       this._last = next;
/* 1380 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendStartMarker(JsonToken type) {
/*      */     Segment next;
/* 1392 */     if (this._hasNativeId) {
/* 1393 */       next = this._last.append(this._appendAt, type, this._objectId, this._typeId);
/*      */     } else {
/* 1395 */       next = this._last.append(this._appendAt, type);
/*      */     } 
/* 1397 */     if (next == null) {
/* 1398 */       this._appendAt++;
/*      */     } else {
/* 1400 */       this._last = next;
/* 1401 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendEndMarker(JsonToken type) {
/* 1413 */     Segment next = this._last.append(this._appendAt, type);
/* 1414 */     if (next == null) {
/* 1415 */       this._appendAt++;
/*      */     } else {
/* 1417 */       this._last = next;
/* 1418 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _reportUnsupportedOperation() {
/* 1424 */     throw new UnsupportedOperationException("Called operation not supported for TokenBuffer");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class Parser
/*      */     extends ParserMinimalBase
/*      */   {
/*      */     protected ObjectCodec _codec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean _hasNativeTypeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean _hasNativeObjectIds;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean _hasNativeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected TokenBuffer.Segment _segment;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected int _segmentPtr;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected TokenBufferReadContext _parsingContext;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean _closed;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected transient ByteArrayBuilder _byteBuilder;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1482 */     protected JsonLocation _location = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public Parser(TokenBuffer.Segment firstSeg, ObjectCodec codec, boolean hasNativeTypeIds, boolean hasNativeObjectIds) {
/* 1494 */       this(firstSeg, codec, hasNativeTypeIds, hasNativeObjectIds, (JsonStreamContext)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Parser(TokenBuffer.Segment firstSeg, ObjectCodec codec, boolean hasNativeTypeIds, boolean hasNativeObjectIds, JsonStreamContext parentContext) {
/* 1505 */       this._segment = firstSeg;
/* 1506 */       this._segmentPtr = -1;
/* 1507 */       this._codec = codec;
/* 1508 */       this._parsingContext = TokenBufferReadContext.createRootContext(parentContext);
/* 1509 */       this._hasNativeTypeIds = hasNativeTypeIds;
/* 1510 */       this._hasNativeObjectIds = hasNativeObjectIds;
/* 1511 */       this._hasNativeIds = (hasNativeTypeIds || hasNativeObjectIds);
/*      */     }
/*      */     
/*      */     public void setLocation(JsonLocation l) {
/* 1515 */       this._location = l;
/*      */     }
/*      */     
/*      */     public ObjectCodec getCodec() {
/* 1519 */       return this._codec;
/*      */     }
/*      */     public void setCodec(ObjectCodec c) {
/* 1522 */       this._codec = c;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Version version() {
/* 1532 */       return PackageVersion.VERSION;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/* 1541 */       return DEFAULT_READ_CAPABILITIES;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonToken peekNextToken() throws IOException {
/* 1553 */       if (this._closed) return null; 
/* 1554 */       TokenBuffer.Segment seg = this._segment;
/* 1555 */       int ptr = this._segmentPtr + 1;
/* 1556 */       if (ptr >= 16) {
/* 1557 */         ptr = 0;
/* 1558 */         seg = (seg == null) ? null : seg.next();
/*      */       } 
/* 1560 */       return (seg == null) ? null : seg.type(ptr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 1571 */       if (!this._closed) {
/* 1572 */         this._closed = true;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonToken nextToken() throws IOException {
/* 1586 */       if (this._closed || this._segment == null) return null;
/*      */ 
/*      */       
/* 1589 */       if (++this._segmentPtr >= 16) {
/* 1590 */         this._segmentPtr = 0;
/* 1591 */         this._segment = this._segment.next();
/* 1592 */         if (this._segment == null) {
/* 1593 */           return null;
/*      */         }
/*      */       } 
/* 1596 */       this._currToken = this._segment.type(this._segmentPtr);
/*      */       
/* 1598 */       if (this._currToken == JsonToken.FIELD_NAME) {
/* 1599 */         Object ob = _currentObject();
/* 1600 */         String name = (ob instanceof String) ? (String)ob : ob.toString();
/* 1601 */         this._parsingContext.setCurrentName(name);
/* 1602 */       } else if (this._currToken == JsonToken.START_OBJECT) {
/* 1603 */         this._parsingContext = this._parsingContext.createChildObjectContext();
/* 1604 */       } else if (this._currToken == JsonToken.START_ARRAY) {
/* 1605 */         this._parsingContext = this._parsingContext.createChildArrayContext();
/* 1606 */       } else if (this._currToken == JsonToken.END_OBJECT || this._currToken == JsonToken.END_ARRAY) {
/*      */ 
/*      */         
/* 1609 */         this._parsingContext = this._parsingContext.parentOrCopy();
/*      */       } else {
/* 1611 */         this._parsingContext.updateForValue();
/*      */       } 
/* 1613 */       return this._currToken;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String nextFieldName() throws IOException {
/* 1620 */       if (this._closed || this._segment == null) {
/* 1621 */         return null;
/*      */       }
/*      */       
/* 1624 */       int ptr = this._segmentPtr + 1;
/* 1625 */       if (ptr < 16 && this._segment.type(ptr) == JsonToken.FIELD_NAME) {
/* 1626 */         this._segmentPtr = ptr;
/* 1627 */         this._currToken = JsonToken.FIELD_NAME;
/* 1628 */         Object ob = this._segment.get(ptr);
/* 1629 */         String name = (ob instanceof String) ? (String)ob : ob.toString();
/* 1630 */         this._parsingContext.setCurrentName(name);
/* 1631 */         return name;
/*      */       } 
/* 1633 */       return (nextToken() == JsonToken.FIELD_NAME) ? currentName() : null;
/*      */     }
/*      */     
/*      */     public boolean isClosed() {
/* 1637 */       return this._closed;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonStreamContext getParsingContext() {
/* 1646 */       return this._parsingContext;
/*      */     }
/*      */     public JsonLocation getTokenLocation() {
/* 1649 */       return getCurrentLocation();
/*      */     }
/*      */     
/*      */     public JsonLocation getCurrentLocation() {
/* 1653 */       return (this._location == null) ? JsonLocation.NA : this._location;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String currentName() {
/* 1659 */       if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/* 1660 */         JsonStreamContext parent = this._parsingContext.getParent();
/* 1661 */         return parent.getCurrentName();
/*      */       } 
/* 1663 */       return this._parsingContext.getCurrentName();
/*      */     }
/*      */     
/*      */     public String getCurrentName() {
/* 1667 */       return currentName();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void overrideCurrentName(String name) {
/* 1673 */       JsonStreamContext ctxt = this._parsingContext;
/* 1674 */       if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/* 1675 */         ctxt = ctxt.getParent();
/*      */       }
/* 1677 */       if (ctxt instanceof TokenBufferReadContext) {
/*      */         try {
/* 1679 */           ((TokenBufferReadContext)ctxt).setCurrentName(name);
/* 1680 */         } catch (IOException e) {
/* 1681 */           throw new RuntimeException(e);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getText() {
/* 1696 */       if (this._currToken == JsonToken.VALUE_STRING || this._currToken == JsonToken.FIELD_NAME) {
/*      */         
/* 1698 */         Object ob = _currentObject();
/* 1699 */         if (ob instanceof String) {
/* 1700 */           return (String)ob;
/*      */         }
/* 1702 */         return ClassUtil.nullOrToString(ob);
/*      */       } 
/* 1704 */       if (this._currToken == null) {
/* 1705 */         return null;
/*      */       }
/* 1707 */       switch (this._currToken) {
/*      */         case null:
/*      */         case null:
/* 1710 */           return ClassUtil.nullOrToString(_currentObject());
/*      */       } 
/* 1712 */       return this._currToken.asString();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public char[] getTextCharacters() {
/* 1718 */       String str = getText();
/* 1719 */       return (str == null) ? null : str.toCharArray();
/*      */     }
/*      */ 
/*      */     
/*      */     public int getTextLength() {
/* 1724 */       String str = getText();
/* 1725 */       return (str == null) ? 0 : str.length();
/*      */     }
/*      */     
/*      */     public int getTextOffset() {
/* 1729 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasTextCharacters() {
/* 1734 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isNaN() {
/* 1746 */       if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/* 1747 */         Object value = _currentObject();
/* 1748 */         if (value instanceof Double) {
/* 1749 */           Double v = (Double)value;
/* 1750 */           return (v.isNaN() || v.isInfinite());
/*      */         } 
/* 1752 */         if (value instanceof Float) {
/* 1753 */           Float v = (Float)value;
/* 1754 */           return (v.isNaN() || v.isInfinite());
/*      */         } 
/*      */       } 
/* 1757 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public BigInteger getBigIntegerValue() throws IOException {
/* 1763 */       Number n = getNumberValue();
/* 1764 */       if (n instanceof BigInteger) {
/* 1765 */         return (BigInteger)n;
/*      */       }
/* 1767 */       if (getNumberType() == JsonParser.NumberType.BIG_DECIMAL) {
/* 1768 */         return ((BigDecimal)n).toBigInteger();
/*      */       }
/*      */       
/* 1771 */       return BigInteger.valueOf(n.longValue());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public BigDecimal getDecimalValue() throws IOException {
/* 1777 */       Number n = getNumberValue();
/* 1778 */       if (n instanceof BigDecimal) {
/* 1779 */         return (BigDecimal)n;
/*      */       }
/* 1781 */       switch (getNumberType()) {
/*      */         case INT:
/*      */         case LONG:
/* 1784 */           return BigDecimal.valueOf(n.longValue());
/*      */         case BIG_INTEGER:
/* 1786 */           return new BigDecimal((BigInteger)n);
/*      */       } 
/*      */ 
/*      */       
/* 1790 */       return BigDecimal.valueOf(n.doubleValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public double getDoubleValue() throws IOException {
/* 1795 */       return getNumberValue().doubleValue();
/*      */     }
/*      */ 
/*      */     
/*      */     public float getFloatValue() throws IOException {
/* 1800 */       return getNumberValue().floatValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getIntValue() throws IOException {
/* 1807 */       Number n = (this._currToken == JsonToken.VALUE_NUMBER_INT) ? (Number)_currentObject() : getNumberValue();
/* 1808 */       if (n instanceof Integer || _smallerThanInt(n)) {
/* 1809 */         return n.intValue();
/*      */       }
/* 1811 */       return _convertNumberToInt(n);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public long getLongValue() throws IOException {
/* 1817 */       Number n = (this._currToken == JsonToken.VALUE_NUMBER_INT) ? (Number)_currentObject() : getNumberValue();
/* 1818 */       if (n instanceof Long || _smallerThanLong(n)) {
/* 1819 */         return n.longValue();
/*      */       }
/* 1821 */       return _convertNumberToLong(n);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonParser.NumberType getNumberType() throws IOException {
/* 1827 */       Number n = getNumberValue();
/* 1828 */       if (n instanceof Integer) return JsonParser.NumberType.INT; 
/* 1829 */       if (n instanceof Long) return JsonParser.NumberType.LONG; 
/* 1830 */       if (n instanceof Double) return JsonParser.NumberType.DOUBLE; 
/* 1831 */       if (n instanceof BigDecimal) return JsonParser.NumberType.BIG_DECIMAL; 
/* 1832 */       if (n instanceof BigInteger) return JsonParser.NumberType.BIG_INTEGER; 
/* 1833 */       if (n instanceof Float) return JsonParser.NumberType.FLOAT; 
/* 1834 */       if (n instanceof Short) return JsonParser.NumberType.INT; 
/* 1835 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public final Number getNumberValue() throws IOException {
/* 1840 */       _checkIsNumber();
/* 1841 */       Object value = _currentObject();
/* 1842 */       if (value instanceof Number) {
/* 1843 */         return (Number)value;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1848 */       if (value instanceof String) {
/* 1849 */         String str = (String)value;
/* 1850 */         if (str.indexOf('.') >= 0) {
/* 1851 */           return Double.valueOf(NumberInput.parseDouble(str, isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER)));
/*      */         }
/* 1853 */         return Long.valueOf(NumberInput.parseLong(str));
/*      */       } 
/* 1855 */       if (value == null) {
/* 1856 */         return null;
/*      */       }
/* 1858 */       throw new IllegalStateException("Internal error: entry should be a Number, but is of type " + value
/* 1859 */           .getClass().getName());
/*      */     }
/*      */     
/*      */     private final boolean _smallerThanInt(Number n) {
/* 1863 */       return (n instanceof Short || n instanceof Byte);
/*      */     }
/*      */     
/*      */     private final boolean _smallerThanLong(Number n) {
/* 1867 */       return (n instanceof Integer || n instanceof Short || n instanceof Byte);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected int _convertNumberToInt(Number n) throws IOException {
/* 1874 */       if (n instanceof Long) {
/* 1875 */         long l = n.longValue();
/* 1876 */         int result = (int)l;
/* 1877 */         if (result != l) {
/* 1878 */           reportOverflowInt();
/*      */         }
/* 1880 */         return result;
/*      */       } 
/* 1882 */       if (n instanceof BigInteger) {
/* 1883 */         BigInteger big = (BigInteger)n;
/* 1884 */         if (BI_MIN_INT.compareTo(big) > 0 || BI_MAX_INT
/* 1885 */           .compareTo(big) < 0)
/* 1886 */           reportOverflowInt(); 
/*      */       } else {
/* 1888 */         if (n instanceof Double || n instanceof Float) {
/* 1889 */           double d = n.doubleValue();
/*      */           
/* 1891 */           if (d < -2.147483648E9D || d > 2.147483647E9D) {
/* 1892 */             reportOverflowInt();
/*      */           }
/* 1894 */           return (int)d;
/* 1895 */         }  if (n instanceof BigDecimal) {
/* 1896 */           BigDecimal big = (BigDecimal)n;
/* 1897 */           if (BD_MIN_INT.compareTo(big) > 0 || BD_MAX_INT
/* 1898 */             .compareTo(big) < 0) {
/* 1899 */             reportOverflowInt();
/*      */           }
/*      */         } else {
/* 1902 */           _throwInternal();
/*      */         } 
/* 1904 */       }  return n.intValue();
/*      */     }
/*      */ 
/*      */     
/*      */     protected long _convertNumberToLong(Number n) throws IOException {
/* 1909 */       if (n instanceof BigInteger) {
/* 1910 */         BigInteger big = (BigInteger)n;
/* 1911 */         if (BI_MIN_LONG.compareTo(big) > 0 || BI_MAX_LONG
/* 1912 */           .compareTo(big) < 0)
/* 1913 */           reportOverflowLong(); 
/*      */       } else {
/* 1915 */         if (n instanceof Double || n instanceof Float) {
/* 1916 */           double d = n.doubleValue();
/*      */           
/* 1918 */           if (d < -9.223372036854776E18D || d > 9.223372036854776E18D) {
/* 1919 */             reportOverflowLong();
/*      */           }
/* 1921 */           return (long)d;
/* 1922 */         }  if (n instanceof BigDecimal) {
/* 1923 */           BigDecimal big = (BigDecimal)n;
/* 1924 */           if (BD_MIN_LONG.compareTo(big) > 0 || BD_MAX_LONG
/* 1925 */             .compareTo(big) < 0) {
/* 1926 */             reportOverflowLong();
/*      */           }
/*      */         } else {
/* 1929 */           _throwInternal();
/*      */         } 
/* 1931 */       }  return n.longValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object getEmbeddedObject() {
/* 1943 */       if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 1944 */         return _currentObject();
/*      */       }
/* 1946 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/* 1954 */       if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) {
/*      */         
/* 1956 */         Object ob = _currentObject();
/* 1957 */         if (ob instanceof byte[]) {
/* 1958 */           return (byte[])ob;
/*      */         }
/*      */       } 
/*      */       
/* 1962 */       if (this._currToken != JsonToken.VALUE_STRING) {
/* 1963 */         throw _constructError("Current token (" + this._currToken + ") not VALUE_STRING (or VALUE_EMBEDDED_OBJECT with byte[]), cannot access as binary");
/*      */       }
/* 1965 */       String str = getText();
/* 1966 */       if (str == null) {
/* 1967 */         return null;
/*      */       }
/* 1969 */       ByteArrayBuilder builder = this._byteBuilder;
/* 1970 */       if (builder == null) {
/* 1971 */         this._byteBuilder = builder = new ByteArrayBuilder(100);
/*      */       } else {
/* 1973 */         this._byteBuilder.reset();
/*      */       } 
/* 1975 */       _decodeBase64(str, builder, b64variant);
/* 1976 */       return builder.toByteArray();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/* 1982 */       byte[] data = getBinaryValue(b64variant);
/* 1983 */       if (data != null) {
/* 1984 */         out.write(data, 0, data.length);
/* 1985 */         return data.length;
/*      */       } 
/* 1987 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean canReadObjectId() {
/* 1998 */       return this._hasNativeObjectIds;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean canReadTypeId() {
/* 2003 */       return this._hasNativeTypeIds;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getTypeId() {
/* 2008 */       return this._segment.findTypeId(this._segmentPtr);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getObjectId() {
/* 2013 */       return this._segment.findObjectId(this._segmentPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final Object _currentObject() {
/* 2023 */       return this._segment.get(this._segmentPtr);
/*      */     }
/*      */ 
/*      */     
/*      */     protected final void _checkIsNumber() throws JacksonException {
/* 2028 */       if (this._currToken == null || !this._currToken.isNumeric()) {
/* 2029 */         throw _constructError("Current token (" + this._currToken + ") not numeric, cannot use numeric value accessors");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     protected void _handleEOF() {
/* 2035 */       _throwInternal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class Segment
/*      */   {
/*      */     public static final int TOKENS_PER_SEGMENT = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2057 */     private static final JsonToken[] TOKEN_TYPES_BY_INDEX = new JsonToken[16]; protected Segment _next; protected long _tokenTypes; static {
/* 2058 */       JsonToken[] t = JsonToken.values();
/*      */       
/* 2060 */       System.arraycopy(t, 1, TOKEN_TYPES_BY_INDEX, 1, Math.min(15, t.length - 1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2078 */     protected final Object[] _tokens = new Object[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected TreeMap<Integer, Object> _nativeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonToken type(int index) {
/* 2091 */       long l = this._tokenTypes;
/* 2092 */       if (index > 0) {
/* 2093 */         l >>= index << 2;
/*      */       }
/* 2095 */       int ix = (int)l & 0xF;
/* 2096 */       return TOKEN_TYPES_BY_INDEX[ix];
/*      */     }
/*      */ 
/*      */     
/*      */     public int rawType(int index) {
/* 2101 */       long l = this._tokenTypes;
/* 2102 */       if (index > 0) {
/* 2103 */         l >>= index << 2;
/*      */       }
/* 2105 */       int ix = (int)l & 0xF;
/* 2106 */       return ix;
/*      */     }
/*      */     
/*      */     public Object get(int index) {
/* 2110 */       return this._tokens[index];
/*      */     }
/*      */     public Segment next() {
/* 2113 */       return this._next;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasIds() {
/* 2120 */       return (this._nativeIds != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType) {
/* 2127 */       if (index < 16) {
/* 2128 */         set(index, tokenType);
/* 2129 */         return null;
/*      */       } 
/* 2131 */       this._next = new Segment();
/* 2132 */       this._next.set(0, tokenType);
/* 2133 */       return this._next;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType, Object objectId, Object typeId) {
/* 2139 */       if (index < 16) {
/* 2140 */         set(index, tokenType, objectId, typeId);
/* 2141 */         return null;
/*      */       } 
/* 2143 */       this._next = new Segment();
/* 2144 */       this._next.set(0, tokenType, objectId, typeId);
/* 2145 */       return this._next;
/*      */     }
/*      */ 
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType, Object value) {
/* 2150 */       if (index < 16) {
/* 2151 */         set(index, tokenType, value);
/* 2152 */         return null;
/*      */       } 
/* 2154 */       this._next = new Segment();
/* 2155 */       this._next.set(0, tokenType, value);
/* 2156 */       return this._next;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType, Object value, Object objectId, Object typeId) {
/* 2162 */       if (index < 16) {
/* 2163 */         set(index, tokenType, value, objectId, typeId);
/* 2164 */         return null;
/*      */       } 
/* 2166 */       this._next = new Segment();
/* 2167 */       this._next.set(0, tokenType, value, objectId, typeId);
/* 2168 */       return this._next;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void set(int index, JsonToken tokenType) {
/* 2222 */       long typeCode = tokenType.ordinal();
/* 2223 */       if (index > 0) {
/* 2224 */         typeCode <<= index << 2;
/*      */       }
/* 2226 */       this._tokenTypes |= typeCode;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void set(int index, JsonToken tokenType, Object objectId, Object typeId) {
/* 2232 */       long typeCode = tokenType.ordinal();
/* 2233 */       if (index > 0) {
/* 2234 */         typeCode <<= index << 2;
/*      */       }
/* 2236 */       this._tokenTypes |= typeCode;
/* 2237 */       assignNativeIds(index, objectId, typeId);
/*      */     }
/*      */ 
/*      */     
/*      */     private void set(int index, JsonToken tokenType, Object value) {
/* 2242 */       this._tokens[index] = value;
/* 2243 */       long typeCode = tokenType.ordinal();
/* 2244 */       if (index > 0) {
/* 2245 */         typeCode <<= index << 2;
/*      */       }
/* 2247 */       this._tokenTypes |= typeCode;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void set(int index, JsonToken tokenType, Object value, Object objectId, Object typeId) {
/* 2253 */       this._tokens[index] = value;
/* 2254 */       long typeCode = tokenType.ordinal();
/* 2255 */       if (index > 0) {
/* 2256 */         typeCode <<= index << 2;
/*      */       }
/* 2258 */       this._tokenTypes |= typeCode;
/* 2259 */       assignNativeIds(index, objectId, typeId);
/*      */     }
/*      */ 
/*      */     
/*      */     private final void assignNativeIds(int index, Object objectId, Object typeId) {
/* 2264 */       if (this._nativeIds == null) {
/* 2265 */         this._nativeIds = new TreeMap<>();
/*      */       }
/* 2267 */       if (objectId != null) {
/* 2268 */         this._nativeIds.put(Integer.valueOf(_objectIdIndex(index)), objectId);
/*      */       }
/* 2270 */       if (typeId != null) {
/* 2271 */         this._nativeIds.put(Integer.valueOf(_typeIdIndex(index)), typeId);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Object findObjectId(int index) {
/* 2279 */       return (this._nativeIds == null) ? null : this._nativeIds.get(Integer.valueOf(_objectIdIndex(index)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Object findTypeId(int index) {
/* 2286 */       return (this._nativeIds == null) ? null : this._nativeIds.get(Integer.valueOf(_typeIdIndex(index)));
/*      */     }
/*      */     
/* 2289 */     private final int _typeIdIndex(int i) { return i + i; } private final int _objectIdIndex(int i) {
/* 2290 */       return i + i + 1;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databin\\util\TokenBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */