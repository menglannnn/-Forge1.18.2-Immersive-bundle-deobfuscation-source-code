/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.core.FormatFeature;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.PrettyPrinter;
/*     */ import com.fasterxml.jackson.core.json.JsonWriteFeature;
/*     */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*     */ import com.fasterxml.jackson.core.util.Instantiatable;
/*     */ import com.fasterxml.jackson.databind.cfg.BaseSettings;
/*     */ import com.fasterxml.jackson.databind.cfg.ConfigOverrides;
/*     */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfigBase;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*     */ import java.io.Serializable;
/*     */ import java.text.DateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SerializationConfig
/*     */   extends MapperConfigBase<SerializationFeature, SerializationConfig>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  38 */   protected static final PrettyPrinter DEFAULT_PRETTY_PRINTER = (PrettyPrinter)new DefaultPrettyPrinter();
/*     */ 
/*     */   
/*  41 */   private static final int SER_FEATURE_DEFAULTS = collectFeatureDefaults(SerializationFeature.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final FilterProvider _filterProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PrettyPrinter _defaultPrettyPrinter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _serFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _generatorFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _generatorFeaturesToChange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _formatWriteFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _formatWriteFeaturesToChange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides, DatatypeFeatures datatypeFeatures) {
/* 119 */     super(base, str, mixins, rootNames, configOverrides, datatypeFeatures);
/* 120 */     this._serFeatures = SER_FEATURE_DEFAULTS;
/* 121 */     this._filterProvider = null;
/* 122 */     this._defaultPrettyPrinter = DEFAULT_PRETTY_PRINTER;
/* 123 */     this._generatorFeatures = 0;
/* 124 */     this._generatorFeaturesToChange = 0;
/* 125 */     this._formatWriteFeatures = 0;
/* 126 */     this._formatWriteFeaturesToChange = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SerializationConfig(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides) {
/* 137 */     this(base, str, mixins, rootNames, configOverrides, 
/* 138 */         DatatypeFeatures.defaultFeatures());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides) {
/* 150 */     super(src, str, mixins, rootNames, configOverrides);
/* 151 */     this._serFeatures = src._serFeatures;
/* 152 */     this._filterProvider = src._filterProvider;
/* 153 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 154 */     this._generatorFeatures = src._generatorFeatures;
/* 155 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 156 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 157 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, SubtypeResolver str) {
/* 169 */     super(src, str);
/* 170 */     this._serFeatures = src._serFeatures;
/* 171 */     this._filterProvider = src._filterProvider;
/* 172 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 173 */     this._generatorFeatures = src._generatorFeatures;
/* 174 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 175 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 176 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, long mapperFeatures, int serFeatures, int generatorFeatures, int generatorFeatureMask, int formatFeatures, int formatFeaturesMask) {
/* 184 */     super(src, mapperFeatures);
/* 185 */     this._serFeatures = serFeatures;
/* 186 */     this._filterProvider = src._filterProvider;
/* 187 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 188 */     this._generatorFeatures = generatorFeatures;
/* 189 */     this._generatorFeaturesToChange = generatorFeatureMask;
/* 190 */     this._formatWriteFeatures = formatFeatures;
/* 191 */     this._formatWriteFeaturesToChange = formatFeaturesMask;
/*     */   }
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, BaseSettings base) {
/* 196 */     super(src, base);
/* 197 */     this._serFeatures = src._serFeatures;
/* 198 */     this._filterProvider = src._filterProvider;
/* 199 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 200 */     this._generatorFeatures = src._generatorFeatures;
/* 201 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 202 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 203 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, FilterProvider filters) {
/* 208 */     super(src);
/* 209 */     this._serFeatures = src._serFeatures;
/* 210 */     this._filterProvider = filters;
/* 211 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 212 */     this._generatorFeatures = src._generatorFeatures;
/* 213 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 214 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 215 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, Class<?> view) {
/* 220 */     super(src, view);
/* 221 */     this._serFeatures = src._serFeatures;
/* 222 */     this._filterProvider = src._filterProvider;
/* 223 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 224 */     this._generatorFeatures = src._generatorFeatures;
/* 225 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 226 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 227 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, PropertyName rootName) {
/* 232 */     super(src, rootName);
/* 233 */     this._serFeatures = src._serFeatures;
/* 234 */     this._filterProvider = src._filterProvider;
/* 235 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 236 */     this._generatorFeatures = src._generatorFeatures;
/* 237 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 238 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 239 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, ContextAttributes attrs) {
/* 247 */     super(src, attrs);
/* 248 */     this._serFeatures = src._serFeatures;
/* 249 */     this._filterProvider = src._filterProvider;
/* 250 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 251 */     this._generatorFeatures = src._generatorFeatures;
/* 252 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 253 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 254 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, SimpleMixInResolver mixins) {
/* 262 */     super(src, mixins);
/* 263 */     this._serFeatures = src._serFeatures;
/* 264 */     this._filterProvider = src._filterProvider;
/* 265 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 266 */     this._generatorFeatures = src._generatorFeatures;
/* 267 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 268 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 269 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, PrettyPrinter defaultPP) {
/* 277 */     super(src);
/* 278 */     this._serFeatures = src._serFeatures;
/* 279 */     this._filterProvider = src._filterProvider;
/* 280 */     this._defaultPrettyPrinter = defaultPP;
/* 281 */     this._generatorFeatures = src._generatorFeatures;
/* 282 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 283 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 284 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, DatatypeFeatures dtFeatures) {
/* 292 */     super(src, dtFeatures);
/* 293 */     this._serFeatures = src._serFeatures;
/* 294 */     this._filterProvider = src._filterProvider;
/* 295 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 296 */     this._generatorFeatures = src._generatorFeatures;
/* 297 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 298 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 299 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SerializationConfig _withBase(BaseSettings newBase) {
/* 310 */     return (this._base == newBase) ? this : new SerializationConfig(this, newBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final SerializationConfig _withMapperFeatures(long mapperFeatures) {
/* 315 */     return new SerializationConfig(this, mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SerializationConfig _with(DatatypeFeatures dtFeatures) {
/* 322 */     return new SerializationConfig(this, dtFeatures);
/*     */   }
/*     */ 
/*     */   
/*     */   public SerializationConfig withRootName(PropertyName rootName) {
/* 327 */     if (rootName == null) {
/* 328 */       if (this._rootName == null) {
/* 329 */         return this;
/*     */       }
/* 331 */     } else if (rootName.equals(this._rootName)) {
/* 332 */       return this;
/*     */     } 
/* 334 */     return new SerializationConfig(this, rootName);
/*     */   }
/*     */ 
/*     */   
/*     */   public SerializationConfig with(SubtypeResolver str) {
/* 339 */     return (str == this._subtypeResolver) ? this : new SerializationConfig(this, str);
/*     */   }
/*     */ 
/*     */   
/*     */   public SerializationConfig withView(Class<?> view) {
/* 344 */     return (this._view == view) ? this : new SerializationConfig(this, view);
/*     */   }
/*     */ 
/*     */   
/*     */   public SerializationConfig with(ContextAttributes attrs) {
/* 349 */     return (attrs == this._attributes) ? this : new SerializationConfig(this, attrs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(DateFormat df) {
/* 365 */     SerializationConfig cfg = (SerializationConfig)super.with(df);
/*     */     
/* 367 */     if (df == null) {
/* 368 */       return cfg.with(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
/*     */     }
/* 370 */     return cfg.without(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(SerializationFeature feature) {
/* 385 */     int newSerFeatures = this._serFeatures | feature.getMask();
/* 386 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(SerializationFeature first, SerializationFeature... features) {
/* 398 */     int newSerFeatures = this._serFeatures | first.getMask();
/* 399 */     for (SerializationFeature f : features) {
/* 400 */       newSerFeatures |= f.getMask();
/*     */     }
/* 402 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withFeatures(SerializationFeature... features) {
/* 414 */     int newSerFeatures = this._serFeatures;
/* 415 */     for (SerializationFeature f : features) {
/* 416 */       newSerFeatures |= f.getMask();
/*     */     }
/* 418 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig without(SerializationFeature feature) {
/* 430 */     int newSerFeatures = this._serFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/* 431 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig without(SerializationFeature first, SerializationFeature... features) {
/* 443 */     int newSerFeatures = this._serFeatures & (first.getMask() ^ 0xFFFFFFFF);
/* 444 */     for (SerializationFeature f : features) {
/* 445 */       newSerFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*     */     }
/* 447 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withoutFeatures(SerializationFeature... features) {
/* 459 */     int newSerFeatures = this._serFeatures;
/* 460 */     for (SerializationFeature f : features) {
/* 461 */       newSerFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*     */     }
/* 463 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(JsonGenerator.Feature feature) {
/* 482 */     int newSet = this._generatorFeatures | feature.getMask();
/* 483 */     int newMask = this._generatorFeaturesToChange | feature.getMask();
/* 484 */     return (this._generatorFeatures == newSet && this._generatorFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, newSet, newMask, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withFeatures(JsonGenerator.Feature... features) {
/* 498 */     int newSet = this._generatorFeatures;
/* 499 */     int newMask = this._generatorFeaturesToChange;
/* 500 */     for (JsonGenerator.Feature f : features) {
/* 501 */       int mask = f.getMask();
/* 502 */       newSet |= mask;
/* 503 */       newMask |= mask;
/*     */     } 
/* 505 */     return (this._generatorFeatures == newSet && this._generatorFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, newSet, newMask, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig without(JsonGenerator.Feature feature) {
/* 519 */     int newSet = this._generatorFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/* 520 */     int newMask = this._generatorFeaturesToChange | feature.getMask();
/* 521 */     return (this._generatorFeatures == newSet && this._generatorFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, newSet, newMask, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withoutFeatures(JsonGenerator.Feature... features) {
/* 535 */     int newSet = this._generatorFeatures;
/* 536 */     int newMask = this._generatorFeaturesToChange;
/* 537 */     for (JsonGenerator.Feature f : features) {
/* 538 */       int mask = f.getMask();
/* 539 */       newSet &= mask ^ 0xFFFFFFFF;
/* 540 */       newMask |= mask;
/*     */     } 
/* 542 */     return (this._generatorFeatures == newSet && this._generatorFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, newSet, newMask, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(FormatFeature feature) {
/* 562 */     if (feature instanceof JsonWriteFeature) {
/* 563 */       return _withJsonWriteFeatures(new FormatFeature[] { feature });
/*     */     }
/* 565 */     int newSet = this._formatWriteFeatures | feature.getMask();
/* 566 */     int newMask = this._formatWriteFeaturesToChange | feature.getMask();
/* 567 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withFeatures(FormatFeature... features) {
/* 582 */     if (features.length > 0 && features[0] instanceof JsonWriteFeature) {
/* 583 */       return _withJsonWriteFeatures(features);
/*     */     }
/* 585 */     int newSet = this._formatWriteFeatures;
/* 586 */     int newMask = this._formatWriteFeaturesToChange;
/* 587 */     for (FormatFeature f : features) {
/* 588 */       int mask = f.getMask();
/* 589 */       newSet |= mask;
/* 590 */       newMask |= mask;
/*     */     } 
/* 592 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig without(FormatFeature feature) {
/* 607 */     if (feature instanceof JsonWriteFeature) {
/* 608 */       return _withoutJsonWriteFeatures(new FormatFeature[] { feature });
/*     */     }
/* 610 */     int newSet = this._formatWriteFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/* 611 */     int newMask = this._formatWriteFeaturesToChange | feature.getMask();
/* 612 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withoutFeatures(FormatFeature... features) {
/* 626 */     if (features.length > 0 && features[0] instanceof JsonWriteFeature) {
/* 627 */       return _withoutJsonWriteFeatures(features);
/*     */     }
/* 629 */     int newSet = this._formatWriteFeatures;
/* 630 */     int newMask = this._formatWriteFeaturesToChange;
/* 631 */     for (FormatFeature f : features) {
/* 632 */       int mask = f.getMask();
/* 633 */       newSet &= mask ^ 0xFFFFFFFF;
/* 634 */       newMask |= mask;
/*     */     } 
/* 636 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SerializationConfig _withJsonWriteFeatures(FormatFeature... features) {
/* 644 */     int parserSet = this._generatorFeatures;
/* 645 */     int parserMask = this._generatorFeaturesToChange;
/* 646 */     int newSet = this._formatWriteFeatures;
/* 647 */     int newMask = this._formatWriteFeaturesToChange;
/* 648 */     for (FormatFeature f : features) {
/* 649 */       int mask = f.getMask();
/* 650 */       newSet |= mask;
/* 651 */       newMask |= mask;
/*     */       
/* 653 */       if (f instanceof JsonWriteFeature) {
/* 654 */         JsonGenerator.Feature oldF = ((JsonWriteFeature)f).mappedFeature();
/* 655 */         if (oldF != null) {
/* 656 */           int pmask = oldF.getMask();
/* 657 */           parserSet |= pmask;
/* 658 */           parserMask |= pmask;
/*     */         } 
/*     */       } 
/*     */     } 
/* 662 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask && this._generatorFeatures == parserSet && this._generatorFeaturesToChange == parserMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, parserSet, parserMask, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SerializationConfig _withoutJsonWriteFeatures(FormatFeature... features) {
/* 671 */     int parserSet = this._generatorFeatures;
/* 672 */     int parserMask = this._generatorFeaturesToChange;
/* 673 */     int newSet = this._formatWriteFeatures;
/* 674 */     int newMask = this._formatWriteFeaturesToChange;
/* 675 */     for (FormatFeature f : features) {
/* 676 */       int mask = f.getMask();
/* 677 */       newSet &= mask ^ 0xFFFFFFFF;
/* 678 */       newMask |= mask;
/*     */       
/* 680 */       if (f instanceof JsonWriteFeature) {
/* 681 */         JsonGenerator.Feature oldF = ((JsonWriteFeature)f).mappedFeature();
/* 682 */         if (oldF != null) {
/* 683 */           int pmask = oldF.getMask();
/* 684 */           parserSet &= pmask ^ 0xFFFFFFFF;
/* 685 */           parserMask |= pmask;
/*     */         } 
/*     */       } 
/*     */     } 
/* 689 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask && this._generatorFeatures == parserSet && this._generatorFeaturesToChange == parserMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, parserSet, parserMask, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withFilters(FilterProvider filterProvider) {
/* 703 */     return (filterProvider == this._filterProvider) ? this : new SerializationConfig(this, filterProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SerializationConfig withPropertyInclusion(JsonInclude.Value incl) {
/* 716 */     this._configOverrides.setDefaultInclusion(incl);
/* 717 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withDefaultPrettyPrinter(PrettyPrinter pp) {
/* 724 */     return (this._defaultPrettyPrinter == pp) ? this : new SerializationConfig(this, pp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrettyPrinter constructDefaultPrettyPrinter() {
/* 734 */     PrettyPrinter pp = this._defaultPrettyPrinter;
/* 735 */     if (pp instanceof Instantiatable) {
/* 736 */       pp = (PrettyPrinter)((Instantiatable)pp).createInstance();
/*     */     }
/* 738 */     return pp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(JsonGenerator g) {
/* 756 */     if (SerializationFeature.INDENT_OUTPUT.enabledIn(this._serFeatures))
/*     */     {
/* 758 */       if (g.getPrettyPrinter() == null) {
/* 759 */         PrettyPrinter pp = constructDefaultPrettyPrinter();
/* 760 */         if (pp != null) {
/* 761 */           g.setPrettyPrinter(pp);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 766 */     boolean useBigDec = SerializationFeature.WRITE_BIGDECIMAL_AS_PLAIN.enabledIn(this._serFeatures);
/*     */     
/* 768 */     int mask = this._generatorFeaturesToChange;
/* 769 */     if (mask != 0 || useBigDec) {
/* 770 */       int newFlags = this._generatorFeatures;
/*     */       
/* 772 */       if (useBigDec) {
/* 773 */         int f = JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN.getMask();
/* 774 */         newFlags |= f;
/* 775 */         mask |= f;
/*     */       } 
/* 777 */       g.overrideStdFeatures(newFlags, mask);
/*     */     } 
/* 779 */     if (this._formatWriteFeaturesToChange != 0) {
/* 780 */       g.overrideFormatFeatures(this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonInclude.Include getSerializationInclusion() {
/* 796 */     JsonInclude.Include incl = getDefaultPropertyInclusion().getValueInclusion();
/* 797 */     return (incl == JsonInclude.Include.USE_DEFAULTS) ? JsonInclude.Include.ALWAYS : incl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean useRootWrapping() {
/* 809 */     if (this._rootName != null) {
/* 810 */       return !this._rootName.isEmpty();
/*     */     }
/* 812 */     return isEnabled(SerializationFeature.WRAP_ROOT_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnabled(SerializationFeature feature) {
/* 824 */     return ((this._serFeatures & feature.getMask()) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnabled(JsonGenerator.Feature f, JsonFactory factory) {
/* 835 */     int mask = f.getMask();
/* 836 */     if ((this._generatorFeaturesToChange & mask) != 0) {
/* 837 */       return ((this._generatorFeatures & f.getMask()) != 0);
/*     */     }
/* 839 */     return factory.isEnabled(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasSerializationFeatures(int featureMask) {
/* 849 */     return ((this._serFeatures & featureMask) == featureMask);
/*     */   }
/*     */   
/*     */   public final int getSerializationFeatures() {
/* 853 */     return this._serFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnabled(DatatypeFeature feature) {
/* 867 */     return this._datatypeFeatures.isEnabled(feature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterProvider getFilterProvider() {
/* 877 */     return this._filterProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrettyPrinter getDefaultPrettyPrinter() {
/* 891 */     return this._defaultPrettyPrinter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDescription introspect(JavaType type) {
/* 905 */     return getClassIntrospector().forSerialization(this, type, (ClassIntrospector.MixInResolver)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\SerializationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */