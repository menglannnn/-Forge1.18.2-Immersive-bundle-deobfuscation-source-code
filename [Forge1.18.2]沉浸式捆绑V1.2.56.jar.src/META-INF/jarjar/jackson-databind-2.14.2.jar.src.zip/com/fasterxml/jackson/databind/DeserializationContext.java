/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualKeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerCache;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.UnresolvedForwardReference;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.deser.impl.TypeWrappedDeserializer;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidFormatException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidTypeIdException;
/*      */ import com.fasterxml.jackson.databind.exc.MismatchedInputException;
/*      */ import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
/*      */ import com.fasterxml.jackson.databind.exc.ValueInstantiationException;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.node.TreeTraversingParser;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.LinkedNode;
/*      */ import com.fasterxml.jackson.databind.util.Named;
/*      */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParseException;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class DeserializationContext
/*      */   extends DatabindContext
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected final DeserializerCache _cache;
/*      */   protected final DeserializerFactory _factory;
/*      */   protected final DeserializationConfig _config;
/*      */   protected final int _featureFlags;
/*      */   protected final JacksonFeatureSet<StreamReadCapability> _readCapabilities;
/*      */   protected final Class<?> _view;
/*      */   protected transient JsonParser _parser;
/*      */   protected final InjectableValues _injectableValues;
/*      */   protected transient ArrayBuilders _arrayBuilders;
/*      */   protected transient ObjectBuffer _objectBuffer;
/*      */   protected transient DateFormat _dateFormat;
/*      */   protected transient ContextAttributes _attributes;
/*      */   protected LinkedNode<JavaType> _currentType;
/*      */   
/*      */   protected DeserializationContext(DeserializerFactory df) {
/*  164 */     this(df, (DeserializerCache)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializerFactory df, DeserializerCache cache) {
/*  170 */     if (df == null) {
/*  171 */       throw new NullPointerException("Cannot pass null DeserializerFactory");
/*      */     }
/*  173 */     this._factory = df;
/*  174 */     if (cache == null) {
/*  175 */       cache = new DeserializerCache();
/*      */     }
/*  177 */     this._cache = cache;
/*  178 */     this._featureFlags = 0;
/*  179 */     this._readCapabilities = null;
/*  180 */     this._config = null;
/*  181 */     this._injectableValues = null;
/*  182 */     this._view = null;
/*  183 */     this._attributes = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src, DeserializerFactory factory) {
/*  189 */     this._cache = src._cache;
/*  190 */     this._factory = factory;
/*      */     
/*  192 */     this._config = src._config;
/*  193 */     this._featureFlags = src._featureFlags;
/*  194 */     this._readCapabilities = src._readCapabilities;
/*  195 */     this._view = src._view;
/*  196 */     this._parser = src._parser;
/*  197 */     this._injectableValues = src._injectableValues;
/*  198 */     this._attributes = src._attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src, DeserializationConfig config, JsonParser p, InjectableValues injectableValues) {
/*  208 */     this._cache = src._cache;
/*  209 */     this._factory = src._factory;
/*      */ 
/*      */ 
/*      */     
/*  213 */     this._readCapabilities = (p == null) ? null : p.getReadCapabilities();
/*      */     
/*  215 */     this._config = config;
/*  216 */     this._featureFlags = config.getDeserializationFeatures();
/*  217 */     this._view = config.getActiveView();
/*  218 */     this._parser = p;
/*  219 */     this._injectableValues = injectableValues;
/*  220 */     this._attributes = config.getAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src, DeserializationConfig config) {
/*  232 */     this._cache = src._cache;
/*  233 */     this._factory = src._factory;
/*  234 */     this._readCapabilities = null;
/*      */     
/*  236 */     this._config = config;
/*  237 */     this._featureFlags = config.getDeserializationFeatures();
/*  238 */     this._view = null;
/*  239 */     this._parser = null;
/*  240 */     this._injectableValues = null;
/*  241 */     this._attributes = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src) {
/*  248 */     this._cache = new DeserializerCache();
/*  249 */     this._factory = src._factory;
/*      */     
/*  251 */     this._config = src._config;
/*  252 */     this._featureFlags = src._featureFlags;
/*  253 */     this._readCapabilities = src._readCapabilities;
/*  254 */     this._view = src._view;
/*  255 */     this._injectableValues = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig getConfig() {
/*  265 */     return this._config;
/*      */   }
/*      */   public final Class<?> getActiveView() {
/*  268 */     return this._view;
/*      */   }
/*      */   
/*      */   public final boolean canOverrideAccessModifiers() {
/*  272 */     return this._config.canOverrideAccessModifiers();
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(MapperFeature feature) {
/*  277 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DatatypeFeature feature) {
/*  282 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */   
/*      */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> baseType) {
/*  287 */     return this._config.getDefaultPropertyFormat(baseType);
/*      */   }
/*      */ 
/*      */   
/*      */   public final AnnotationIntrospector getAnnotationIntrospector() {
/*  292 */     return this._config.getAnnotationIntrospector();
/*      */   }
/*      */ 
/*      */   
/*      */   public final TypeFactory getTypeFactory() {
/*  297 */     return this._config.getTypeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass) throws IllegalArgumentException {
/*  304 */     if (baseType.hasRawClass(subclass)) {
/*  305 */       return baseType;
/*      */     }
/*      */ 
/*      */     
/*  309 */     return getConfig().getTypeFactory().constructSpecializedType(baseType, subclass, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Locale getLocale() {
/*  320 */     return this._config.getLocale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TimeZone getTimeZone() {
/*  331 */     return this._config.getTimeZone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAttribute(Object key) {
/*  342 */     return this._attributes.getAttribute(key);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationContext setAttribute(Object key, Object value) {
/*  348 */     this._attributes = this._attributes.withPerCallAttribute(key, value);
/*  349 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getContextualType() {
/*  366 */     return (this._currentType == null) ? null : (JavaType)this._currentType.value();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializerFactory getFactory() {
/*  379 */     return this._factory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DeserializationFeature feat) {
/*  390 */     return ((this._featureFlags & feat.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(StreamReadCapability cap) {
/*  402 */     return this._readCapabilities.isEnabled((JacksonFeature)cap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getDeserializationFeatures() {
/*  412 */     return this._featureFlags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasDeserializationFeatures(int featureMask) {
/*  422 */     return ((this._featureFlags & featureMask) == featureMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasSomeOfFeatures(int featureMask) {
/*  432 */     return ((this._featureFlags & featureMask) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonParser getParser() {
/*  443 */     return this._parser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object findInjectableValue(Object valueId, BeanProperty forProperty, Object beanInstance) throws JsonMappingException {
/*  449 */     if (this._injectableValues == null) {
/*  450 */       return reportBadDefinition(ClassUtil.classOf(valueId), String.format("No 'injectableValues' configured, cannot inject value with id [%s]", new Object[] { valueId }));
/*      */     }
/*      */     
/*  453 */     return this._injectableValues.findInjectableValue(valueId, this, forProperty, beanInstance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Base64Variant getBase64Variant() {
/*  465 */     return this._config.getBase64Variant();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonNodeFactory getNodeFactory() {
/*  475 */     return this._config.getNodeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoercionAction findCoercionAction(LogicalType targetType, Class<?> targetClass, CoercionInputShape inputShape) {
/*  499 */     return this._config.findCoercionAction(targetType, targetClass, inputShape);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoercionAction findCoercionFromBlankString(LogicalType targetType, Class<?> targetClass, CoercionAction actionIfBlankNotAllowed) {
/*  522 */     return this._config.findCoercionFromBlankString(targetType, targetClass, actionIfBlankNotAllowed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer bufferForInputBuffering(JsonParser p) {
/*  541 */     return new TokenBuffer(p, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TokenBuffer bufferForInputBuffering() {
/*  551 */     return bufferForInputBuffering(getParser());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer bufferAsCopyOfValue(JsonParser p) throws IOException {
/*  570 */     TokenBuffer buf = bufferForInputBuffering(p);
/*  571 */     buf.copyCurrentStructure(p);
/*  572 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasValueDeserializerFor(JavaType type, AtomicReference<Throwable> cause) {
/*      */     try {
/*  593 */       return this._cache.hasValueDeserializerFor(this, this._factory, type);
/*  594 */     } catch (DatabindException e) {
/*  595 */       if (cause != null) {
/*  596 */         cause.set(e);
/*      */       }
/*  598 */     } catch (RuntimeException e) {
/*  599 */       if (cause == null) {
/*  600 */         throw e;
/*      */       }
/*  602 */       cause.set(e);
/*      */     } 
/*  604 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonDeserializer<Object> findContextualValueDeserializer(JavaType type, BeanProperty prop) throws JsonMappingException {
/*  615 */     JsonDeserializer<Object> deser = this._cache.findValueDeserializer(this, this._factory, type);
/*  616 */     if (deser != null) {
/*  617 */       deser = (JsonDeserializer)handleSecondaryContextualization(deser, prop, type);
/*      */     }
/*  619 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonDeserializer<Object> findNonContextualValueDeserializer(JavaType type) throws JsonMappingException {
/*  638 */     return this._cache.findValueDeserializer(this, this._factory, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonDeserializer<Object> findRootValueDeserializer(JavaType type) throws JsonMappingException {
/*  648 */     JsonDeserializer<Object> deser = this._cache.findValueDeserializer(this, this._factory, type);
/*      */     
/*  650 */     if (deser == null) {
/*  651 */       return null;
/*      */     }
/*  653 */     deser = (JsonDeserializer)handleSecondaryContextualization(deser, (BeanProperty)null, type);
/*  654 */     TypeDeserializer typeDeser = this._factory.findTypeDeserializer(this._config, type);
/*  655 */     if (typeDeser != null) {
/*      */       
/*  657 */       typeDeser = typeDeser.forProperty(null);
/*  658 */       return (JsonDeserializer<Object>)new TypeWrappedDeserializer(typeDeser, deser);
/*      */     } 
/*  660 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final KeyDeserializer findKeyDeserializer(JavaType keyType, BeanProperty prop) throws JsonMappingException {
/*      */     KeyDeserializer kd;
/*      */     try {
/*  675 */       kd = this._cache.findKeyDeserializer(this, this._factory, keyType);
/*  676 */     } catch (IllegalArgumentException iae) {
/*      */ 
/*      */       
/*  679 */       reportBadDefinition(keyType, ClassUtil.exceptionMessage(iae));
/*  680 */       kd = null;
/*      */     } 
/*      */     
/*  683 */     if (kd instanceof ContextualKeyDeserializer) {
/*  684 */       kd = ((ContextualKeyDeserializer)kd).createContextual(this, prop);
/*      */     }
/*  686 */     return kd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JavaType constructType(Class<?> cls) {
/*  723 */     return (cls == null) ? null : this._config.constructType(cls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findClass(String className) throws ClassNotFoundException {
/*  737 */     return getTypeFactory().findClass(className);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectBuffer leaseObjectBuffer() {
/*  754 */     ObjectBuffer buf = this._objectBuffer;
/*  755 */     if (buf == null) {
/*  756 */       buf = new ObjectBuffer();
/*      */     } else {
/*  758 */       this._objectBuffer = null;
/*      */     } 
/*  760 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void returnObjectBuffer(ObjectBuffer buf) {
/*  773 */     if (this._objectBuffer == null || buf
/*  774 */       .initialCapacity() >= this._objectBuffer.initialCapacity()) {
/*  775 */       this._objectBuffer = buf;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ArrayBuilders getArrayBuilders() {
/*  785 */     if (this._arrayBuilders == null) {
/*  786 */       this._arrayBuilders = new ArrayBuilders();
/*      */     }
/*  788 */     return this._arrayBuilders;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> handlePrimaryContextualization(JsonDeserializer<?> deser, BeanProperty prop, JavaType type) throws JsonMappingException {
/*  827 */     if (deser instanceof ContextualDeserializer) {
/*  828 */       this._currentType = new LinkedNode(type, this._currentType);
/*      */       try {
/*  830 */         deser = ((ContextualDeserializer)deser).createContextual(this, prop);
/*      */       } finally {
/*  832 */         this._currentType = this._currentType.next();
/*      */       } 
/*      */     } 
/*  835 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> handleSecondaryContextualization(JsonDeserializer<?> deser, BeanProperty prop, JavaType type) throws JsonMappingException {
/*  858 */     if (deser instanceof ContextualDeserializer) {
/*  859 */       this._currentType = new LinkedNode(type, this._currentType);
/*      */       try {
/*  861 */         deser = ((ContextualDeserializer)deser).createContextual(this, prop);
/*      */       } finally {
/*  863 */         this._currentType = this._currentType.next();
/*      */       } 
/*      */     } 
/*  866 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date parseDate(String dateStr) throws IllegalArgumentException {
/*      */     try {
/*  888 */       DateFormat df = _getDateFormat();
/*  889 */       return df.parse(dateStr);
/*  890 */     } catch (ParseException e) {
/*  891 */       throw new IllegalArgumentException(String.format("Failed to parse Date value '%s': %s", new Object[] { dateStr, 
/*      */               
/*  893 */               ClassUtil.exceptionMessage(e) }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Calendar constructCalendar(Date d) {
/*  903 */     Calendar c = Calendar.getInstance(getTimeZone());
/*  904 */     c.setTime(d);
/*  905 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String extractScalarFromObject(JsonParser p, JsonDeserializer<?> deser, Class<?> scalarType) throws IOException {
/*  937 */     return (String)handleUnexpectedToken(scalarType, p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, Class<T> type) throws IOException {
/*  958 */     return readValue(p, getTypeFactory().constructType(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, JavaType type) throws IOException {
/*  966 */     JsonDeserializer<Object> deser = findRootValueDeserializer(type);
/*  967 */     if (deser == null) {
/*  968 */       return reportBadDefinition(type, "Could not find JsonDeserializer for type " + 
/*  969 */           ClassUtil.getTypeDescription(type));
/*      */     }
/*  971 */     return (T)deser.deserialize(p, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readPropertyValue(JsonParser p, BeanProperty prop, Class<T> type) throws IOException {
/*  987 */     return readPropertyValue(p, prop, getTypeFactory().constructType(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readPropertyValue(JsonParser p, BeanProperty prop, JavaType type) throws IOException {
/*  999 */     JsonDeserializer<Object> deser = findContextualValueDeserializer(type, prop);
/* 1000 */     if (deser == null)
/* 1001 */       return reportBadDefinition(type, String.format("Could not find JsonDeserializer for type %s (via property %s)", new Object[] {
/*      */               
/* 1003 */               ClassUtil.getTypeDescription(type), ClassUtil.nameOf(prop)
/*      */             })); 
/* 1005 */     return (T)deser.deserialize(p, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(JsonParser p) throws IOException {
/* 1019 */     JsonToken t = p.currentToken();
/* 1020 */     if (t == null) {
/* 1021 */       t = p.nextToken();
/* 1022 */       if (t == null) {
/* 1023 */         return getNodeFactory().missingNode();
/*      */       }
/*      */     } 
/* 1026 */     if (t == JsonToken.VALUE_NULL) {
/* 1027 */       return (JsonNode)getNodeFactory().nullNode();
/*      */     }
/* 1029 */     return (JsonNode)findRootValueDeserializer(this._config.constructType(JsonNode.class))
/* 1030 */       .deserialize(p, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readTreeAsValue(JsonNode n, Class<T> targetType) throws IOException {
/* 1056 */     if (n == null) {
/* 1057 */       return null;
/*      */     }
/* 1059 */     try (TreeTraversingParser p = _treeAsTokens(n)) {
/* 1060 */       return (T)readValue((JsonParser)p, (Class)targetType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readTreeAsValue(JsonNode n, JavaType targetType) throws IOException {
/* 1080 */     if (n == null) {
/* 1081 */       return null;
/*      */     }
/* 1083 */     try (TreeTraversingParser p = _treeAsTokens(n)) {
/* 1084 */       return (T)readValue((JsonParser)p, targetType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private TreeTraversingParser _treeAsTokens(JsonNode n) throws IOException {
/* 1091 */     ObjectCodec codec = (this._parser == null) ? null : this._parser.getCodec();
/* 1092 */     TreeTraversingParser p = new TreeTraversingParser(n, codec);
/*      */     
/* 1094 */     p.nextToken();
/* 1095 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean handleUnknownProperty(JsonParser p, JsonDeserializer<?> deser, Object instanceOrClass, String propName) throws IOException {
/* 1117 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1118 */     while (h != null) {
/*      */       
/* 1120 */       if (((DeserializationProblemHandler)h.value()).handleUnknownProperty(this, p, deser, instanceOrClass, propName)) {
/* 1121 */         return true;
/*      */       }
/* 1123 */       h = h.next();
/*      */     } 
/*      */     
/* 1126 */     if (!isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)) {
/* 1127 */       p.skipChildren();
/* 1128 */       return true;
/*      */     } 
/*      */     
/* 1131 */     Collection<Object> propIds = (deser == null) ? null : deser.getKnownPropertyNames();
/* 1132 */     throw UnrecognizedPropertyException.from(this._parser, instanceOrClass, propName, propIds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleWeirdKey(Class<?> keyClass, String keyValue, String msg, Object... msgArgs) throws IOException {
/* 1160 */     msg = _format(msg, msgArgs);
/* 1161 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1162 */     while (h != null) {
/*      */       
/* 1164 */       Object key = ((DeserializationProblemHandler)h.value()).handleWeirdKey(this, keyClass, keyValue, msg);
/* 1165 */       if (key != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1167 */         if (key == null || keyClass.isInstance(key)) {
/* 1168 */           return key;
/*      */         }
/* 1170 */         throw weirdStringException(keyValue, keyClass, String.format("DeserializationProblemHandler.handleWeirdStringValue() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1172 */                 ClassUtil.getClassDescription(keyClass), 
/* 1173 */                 ClassUtil.getClassDescription(key)
/*      */               }));
/*      */       } 
/* 1176 */       h = h.next();
/*      */     } 
/* 1178 */     throw weirdKeyException(keyClass, keyValue, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleWeirdStringValue(Class<?> targetClass, String value, String msg, Object... msgArgs) throws IOException {
/* 1206 */     msg = _format(msg, msgArgs);
/* 1207 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1208 */     while (h != null) {
/*      */       
/* 1210 */       Object instance = ((DeserializationProblemHandler)h.value()).handleWeirdStringValue(this, targetClass, value, msg);
/* 1211 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1213 */         if (_isCompatible(targetClass, instance)) {
/* 1214 */           return instance;
/*      */         }
/* 1216 */         throw weirdStringException(value, targetClass, String.format("DeserializationProblemHandler.handleWeirdStringValue() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1218 */                 ClassUtil.getClassDescription(targetClass), 
/* 1219 */                 ClassUtil.getClassDescription(instance)
/*      */               }));
/*      */       } 
/* 1222 */       h = h.next();
/*      */     } 
/* 1224 */     throw weirdStringException(value, targetClass, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleWeirdNumberValue(Class<?> targetClass, Number value, String msg, Object... msgArgs) throws IOException {
/* 1251 */     msg = _format(msg, msgArgs);
/* 1252 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1253 */     while (h != null) {
/*      */       
/* 1255 */       Object key = ((DeserializationProblemHandler)h.value()).handleWeirdNumberValue(this, targetClass, value, msg);
/* 1256 */       if (key != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1258 */         if (_isCompatible(targetClass, key)) {
/* 1259 */           return key;
/*      */         }
/* 1261 */         throw weirdNumberException(value, targetClass, _format("DeserializationProblemHandler.handleWeirdNumberValue() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1263 */                 ClassUtil.getClassDescription(targetClass), 
/* 1264 */                 ClassUtil.getClassDescription(key)
/*      */               }));
/*      */       } 
/* 1267 */       h = h.next();
/*      */     } 
/* 1269 */     throw weirdNumberException(value, targetClass, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleWeirdNativeValue(JavaType targetType, Object badValue, JsonParser p) throws IOException {
/* 1276 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1277 */     Class<?> raw = targetType.getRawClass();
/* 1278 */     for (; h != null; h = h.next()) {
/*      */       
/* 1280 */       Object goodValue = ((DeserializationProblemHandler)h.value()).handleWeirdNativeValue(this, targetType, badValue, p);
/* 1281 */       if (goodValue != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1283 */         if (goodValue == null || raw.isInstance(goodValue)) {
/* 1284 */           return goodValue;
/*      */         }
/* 1286 */         throw JsonMappingException.from(p, _format("DeserializationProblemHandler.handleWeirdNativeValue() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1288 */                 ClassUtil.getClassDescription(targetType), 
/* 1289 */                 ClassUtil.getClassDescription(goodValue)
/*      */               }));
/*      */       } 
/*      */     } 
/* 1293 */     throw weirdNativeValueException(badValue, raw);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleMissingInstantiator(Class<?> instClass, ValueInstantiator valueInst, JsonParser p, String msg, Object... msgArgs) throws IOException {
/* 1318 */     if (p == null) {
/* 1319 */       p = getParser();
/*      */     }
/* 1321 */     msg = _format(msg, msgArgs);
/* 1322 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1323 */     while (h != null) {
/*      */       
/* 1325 */       Object instance = ((DeserializationProblemHandler)h.value()).handleMissingInstantiator(this, instClass, valueInst, p, msg);
/*      */       
/* 1327 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1329 */         if (_isCompatible(instClass, instance)) {
/* 1330 */           return instance;
/*      */         }
/* 1332 */         reportBadDefinition(constructType(instClass), String.format("DeserializationProblemHandler.handleMissingInstantiator() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1334 */                 ClassUtil.getClassDescription(instClass), 
/* 1335 */                 ClassUtil.getClassDescription(instance)
/*      */               }));
/*      */       } 
/* 1338 */       h = h.next();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1346 */     if (valueInst == null) {
/* 1347 */       msg = String.format("Cannot construct instance of %s: %s", new Object[] {
/* 1348 */             ClassUtil.nameOf(instClass), msg });
/* 1349 */       return reportBadDefinition(instClass, msg);
/*      */     } 
/* 1351 */     if (!valueInst.canInstantiate()) {
/* 1352 */       msg = String.format("Cannot construct instance of %s (no Creators, like default constructor, exist): %s", new Object[] {
/* 1353 */             ClassUtil.nameOf(instClass), msg });
/* 1354 */       return reportBadDefinition(instClass, msg);
/*      */     } 
/* 1356 */     msg = String.format("Cannot construct instance of %s (although at least one Creator exists): %s", new Object[] {
/* 1357 */           ClassUtil.nameOf(instClass), msg });
/* 1358 */     return reportInputMismatch(instClass, msg, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleInstantiationProblem(Class<?> instClass, Object argument, Throwable t) throws IOException {
/* 1382 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1383 */     while (h != null) {
/*      */       
/* 1385 */       Object instance = ((DeserializationProblemHandler)h.value()).handleInstantiationProblem(this, instClass, argument, t);
/* 1386 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1388 */         if (_isCompatible(instClass, instance)) {
/* 1389 */           return instance;
/*      */         }
/* 1391 */         reportBadDefinition(constructType(instClass), String.format("DeserializationProblemHandler.handleInstantiationProblem() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1393 */                 ClassUtil.getClassDescription(instClass), 
/* 1394 */                 ClassUtil.classNameOf(instance)
/*      */               }));
/*      */       } 
/* 1397 */       h = h.next();
/*      */     } 
/*      */     
/* 1400 */     ClassUtil.throwIfIOE(t);
/*      */     
/* 1402 */     if (!isEnabled(DeserializationFeature.WRAP_EXCEPTIONS)) {
/* 1403 */       ClassUtil.throwIfRTE(t);
/*      */     }
/* 1405 */     throw instantiationException(instClass, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleUnexpectedToken(Class<?> instClass, JsonParser p) throws IOException {
/* 1425 */     return handleUnexpectedToken(constructType(instClass), p.currentToken(), p, (String)null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleUnexpectedToken(Class<?> instClass, JsonToken t, JsonParser p, String msg, Object... msgArgs) throws IOException {
/* 1447 */     return handleUnexpectedToken(constructType(instClass), t, p, msg, msgArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleUnexpectedToken(JavaType targetType, JsonParser p) throws IOException {
/* 1467 */     return handleUnexpectedToken(targetType, p.currentToken(), p, (String)null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleUnexpectedToken(JavaType targetType, JsonToken t, JsonParser p, String msg, Object... msgArgs) throws IOException {
/* 1489 */     msg = _format(msg, msgArgs);
/* 1490 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1491 */     while (h != null) {
/* 1492 */       Object instance = ((DeserializationProblemHandler)h.value()).handleUnexpectedToken(this, targetType, t, p, msg);
/*      */       
/* 1494 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/* 1495 */         if (_isCompatible(targetType.getRawClass(), instance)) {
/* 1496 */           return instance;
/*      */         }
/* 1498 */         reportBadDefinition(targetType, String.format("DeserializationProblemHandler.handleUnexpectedToken() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1500 */                 ClassUtil.getTypeDescription(targetType), 
/* 1501 */                 ClassUtil.classNameOf(instance)
/*      */               }));
/*      */       } 
/* 1504 */       h = h.next();
/*      */     } 
/* 1506 */     if (msg == null) {
/* 1507 */       String targetDesc = ClassUtil.getTypeDescription(targetType);
/* 1508 */       if (t == null) {
/* 1509 */         msg = String.format("Unexpected end-of-input when trying read value of type %s", new Object[] { targetDesc });
/*      */       } else {
/*      */         
/* 1512 */         msg = String.format("Cannot deserialize value of type %s from %s (token `JsonToken.%s`)", new Object[] { targetDesc, 
/* 1513 */               _shapeForToken(t), t });
/*      */       } 
/*      */     } 
/*      */     
/* 1517 */     if (t != null && t.isScalarValue()) {
/* 1518 */       p.getText();
/*      */     }
/* 1520 */     reportInputMismatch(targetType, msg, new Object[0]);
/* 1521 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType handleUnknownTypeId(JavaType baseType, String id, TypeIdResolver idResolver, String extraDesc) throws IOException {
/* 1547 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1548 */     while (h != null) {
/*      */       
/* 1550 */       JavaType type = ((DeserializationProblemHandler)h.value()).handleUnknownTypeId(this, baseType, id, idResolver, extraDesc);
/* 1551 */       if (type != null) {
/* 1552 */         if (type.hasRawClass(Void.class)) {
/* 1553 */           return null;
/*      */         }
/*      */         
/* 1556 */         if (type.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 1557 */           return type;
/*      */         }
/* 1559 */         throw invalidTypeIdException(baseType, id, "problem handler tried to resolve into non-subtype: " + 
/*      */             
/* 1561 */             ClassUtil.getTypeDescription(type));
/*      */       } 
/* 1563 */       h = h.next();
/*      */     } 
/*      */     
/* 1566 */     if (!isEnabled(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE)) {
/* 1567 */       return null;
/*      */     }
/* 1569 */     throw invalidTypeIdException(baseType, id, extraDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType handleMissingTypeId(JavaType baseType, TypeIdResolver idResolver, String extraDesc) throws IOException {
/* 1578 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1579 */     while (h != null) {
/*      */       
/* 1581 */       JavaType type = ((DeserializationProblemHandler)h.value()).handleMissingTypeId(this, baseType, idResolver, extraDesc);
/* 1582 */       if (type != null) {
/* 1583 */         if (type.hasRawClass(Void.class)) {
/* 1584 */           return null;
/*      */         }
/*      */         
/* 1587 */         if (type.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 1588 */           return type;
/*      */         }
/* 1590 */         throw invalidTypeIdException(baseType, null, "problem handler tried to resolve into non-subtype: " + 
/*      */             
/* 1592 */             ClassUtil.getTypeDescription(type));
/*      */       } 
/* 1594 */       h = h.next();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1601 */     throw missingTypeIdException(baseType, extraDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleBadMerge(JsonDeserializer<?> deser) throws JsonMappingException {
/* 1617 */     if (!isEnabled(MapperFeature.IGNORE_MERGE_FOR_UNMERGEABLE)) {
/* 1618 */       JavaType type = constructType(deser.handledType());
/* 1619 */       String msg = String.format("Invalid configuration: values of type %s cannot be merged", new Object[] {
/* 1620 */             ClassUtil.getTypeDescription(type) });
/* 1621 */       throw InvalidDefinitionException.from(getParser(), msg, type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isCompatible(Class<?> target, Object value) {
/* 1630 */     if (value == null || target.isInstance(value)) {
/* 1631 */       return true;
/*      */     }
/*      */     
/* 1634 */     return (target.isPrimitive() && 
/* 1635 */       ClassUtil.wrapperType(target).isInstance(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportWrongTokenException(JsonDeserializer<?> deser, JsonToken expToken, String msg, Object... msgArgs) throws JsonMappingException {
/* 1659 */     msg = _format(msg, msgArgs);
/* 1660 */     throw wrongTokenException(getParser(), deser.handledType(), expToken, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportWrongTokenException(JavaType targetType, JsonToken expToken, String msg, Object... msgArgs) throws JsonMappingException {
/* 1677 */     msg = _format(msg, msgArgs);
/* 1678 */     throw wrongTokenException(getParser(), targetType, expToken, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportWrongTokenException(Class<?> targetType, JsonToken expToken, String msg, Object... msgArgs) throws JsonMappingException {
/* 1695 */     msg = _format(msg, msgArgs);
/* 1696 */     throw wrongTokenException(getParser(), targetType, expToken, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportUnresolvedObjectId(ObjectIdReader oidReader, Object bean) throws JsonMappingException {
/* 1705 */     String msg = String.format("No Object Id found for an instance of %s, to assign to property '%s'", new Object[] {
/* 1706 */           ClassUtil.classNameOf(bean), oidReader.propertyName });
/* 1707 */     return reportInputMismatch((BeanProperty)oidReader.idProperty, msg, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportInputMismatch(JsonDeserializer<?> src, String msg, Object... msgArgs) throws JsonMappingException {
/* 1719 */     msg = _format(msg, msgArgs);
/* 1720 */     throw MismatchedInputException.from(getParser(), src.handledType(), msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportInputMismatch(Class<?> targetType, String msg, Object... msgArgs) throws JsonMappingException {
/* 1732 */     msg = _format(msg, msgArgs);
/* 1733 */     throw MismatchedInputException.from(getParser(), targetType, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportInputMismatch(JavaType targetType, String msg, Object... msgArgs) throws JsonMappingException {
/* 1745 */     msg = _format(msg, msgArgs);
/* 1746 */     throw MismatchedInputException.from(getParser(), targetType, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportInputMismatch(BeanProperty prop, String msg, Object... msgArgs) throws JsonMappingException {
/* 1758 */     msg = _format(msg, msgArgs);
/* 1759 */     JavaType type = (prop == null) ? null : prop.getType();
/* 1760 */     MismatchedInputException e = MismatchedInputException.from(getParser(), type, msg);
/*      */     
/* 1762 */     if (prop != null) {
/* 1763 */       AnnotatedMember member = prop.getMember();
/* 1764 */       if (member != null) {
/* 1765 */         e.prependPath(member.getDeclaringClass(), prop.getName());
/*      */       }
/*      */     } 
/* 1768 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportPropertyInputMismatch(Class<?> targetType, String propertyName, String msg, Object... msgArgs) throws JsonMappingException {
/* 1780 */     msg = _format(msg, msgArgs);
/* 1781 */     MismatchedInputException e = MismatchedInputException.from(getParser(), targetType, msg);
/* 1782 */     if (propertyName != null) {
/* 1783 */       e.prependPath(targetType, propertyName);
/*      */     }
/* 1785 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportPropertyInputMismatch(JavaType targetType, String propertyName, String msg, Object... msgArgs) throws JsonMappingException {
/* 1797 */     return reportPropertyInputMismatch(targetType.getRawClass(), propertyName, msg, msgArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadCoercion(JsonDeserializer<?> src, Class<?> targetType, Object inputValue, String msg, Object... msgArgs) throws JsonMappingException {
/* 1810 */     msg = _format(msg, msgArgs);
/* 1811 */     InvalidFormatException e = InvalidFormatException.from(getParser(), msg, inputValue, targetType);
/*      */     
/* 1813 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportTrailingTokens(Class<?> targetType, JsonParser p, JsonToken trailingToken) throws JsonMappingException {
/* 1819 */     throw MismatchedInputException.from(p, targetType, String.format("Trailing token (of type %s) found after value (bound as %s): not allowed as per `DeserializationFeature.FAIL_ON_TRAILING_TOKENS`", new Object[] { trailingToken, 
/*      */             
/* 1821 */             ClassUtil.nameOf(targetType) }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void reportWrongTokenException(JsonParser p, JsonToken expToken, String msg, Object... msgArgs) throws JsonMappingException {
/* 1830 */     msg = _format(msg, msgArgs);
/* 1831 */     throw wrongTokenException(p, expToken, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void reportUnknownProperty(Object instanceOrClass, String fieldName, JsonDeserializer<?> deser) throws JsonMappingException {
/* 1850 */     if (isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)) {
/*      */       
/* 1852 */       Collection<Object> propIds = (deser == null) ? null : deser.getKnownPropertyNames();
/* 1853 */       throw UnrecognizedPropertyException.from(this._parser, instanceOrClass, fieldName, propIds);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void reportMissingContent(String msg, Object... msgArgs) throws JsonMappingException {
/* 1865 */     throw MismatchedInputException.from(getParser(), (JavaType)null, "No content to map due to end-of-input");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadTypeDefinition(BeanDescription bean, String msg, Object... msgArgs) throws JsonMappingException {
/* 1884 */     msg = _format(msg, msgArgs);
/* 1885 */     String beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/* 1886 */     msg = String.format("Invalid type definition for type %s: %s", new Object[] { beanDesc, msg });
/* 1887 */     throw InvalidDefinitionException.from(this._parser, msg, bean, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadPropertyDefinition(BeanDescription bean, BeanPropertyDefinition prop, String msg, Object... msgArgs) throws JsonMappingException {
/* 1899 */     msg = _format(msg, msgArgs);
/* 1900 */     String propName = ClassUtil.nameOf((Named)prop);
/* 1901 */     String beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/* 1902 */     msg = String.format("Invalid definition for property %s (of type %s): %s", new Object[] { propName, beanDesc, msg });
/*      */     
/* 1904 */     throw InvalidDefinitionException.from(this._parser, msg, bean, prop);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T reportBadDefinition(JavaType type, String msg) throws JsonMappingException {
/* 1909 */     throw InvalidDefinitionException.from(this._parser, msg, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public <T> T reportBadMerge(JsonDeserializer<?> deser) throws JsonMappingException {
/* 1917 */     handleBadMerge(deser);
/* 1918 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException wrongTokenException(JsonParser p, JavaType targetType, JsonToken expToken, String extra) {
/* 1941 */     String msg = String.format("Unexpected token (%s), expected %s", new Object[] { p
/* 1942 */           .currentToken(), expToken });
/* 1943 */     msg = _colonConcat(msg, extra);
/* 1944 */     return (JsonMappingException)MismatchedInputException.from(p, targetType, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException wrongTokenException(JsonParser p, Class<?> targetType, JsonToken expToken, String extra) {
/* 1950 */     String msg = String.format("Unexpected token (%s), expected %s", new Object[] { p
/* 1951 */           .currentToken(), expToken });
/* 1952 */     msg = _colonConcat(msg, extra);
/* 1953 */     return (JsonMappingException)MismatchedInputException.from(p, targetType, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException wrongTokenException(JsonParser p, JsonToken expToken, String msg) {
/* 1960 */     return wrongTokenException(p, (JavaType)null, expToken, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException weirdKeyException(Class<?> keyClass, String keyValue, String msg) {
/* 1973 */     return (JsonMappingException)InvalidFormatException.from(this._parser, 
/* 1974 */         String.format("Cannot deserialize Map key of type %s from String %s: %s", new Object[] {
/* 1975 */             ClassUtil.nameOf(keyClass), _quotedString(keyValue), msg
/*      */           }), keyValue, keyClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException weirdStringException(String value, Class<?> instClass, String msgBase) {
/* 1994 */     String msg = String.format("Cannot deserialize value of type %s from String %s: %s", new Object[] {
/* 1995 */           ClassUtil.nameOf(instClass), _quotedString(value), msgBase });
/* 1996 */     return (JsonMappingException)InvalidFormatException.from(this._parser, msg, value, instClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException weirdNumberException(Number value, Class<?> instClass, String msg) {
/* 2008 */     return (JsonMappingException)InvalidFormatException.from(this._parser, 
/* 2009 */         String.format("Cannot deserialize value of type %s from number %s: %s", new Object[] {
/* 2010 */             ClassUtil.nameOf(instClass), String.valueOf(value), msg
/*      */           }), value, instClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException weirdNativeValueException(Object value, Class<?> instClass) {
/* 2026 */     return (JsonMappingException)InvalidFormatException.from(this._parser, String.format("Cannot deserialize value of type %s from native value (`JsonToken.VALUE_EMBEDDED_OBJECT`) of type %s: incompatible types", new Object[] {
/*      */             
/* 2028 */             ClassUtil.nameOf(instClass), ClassUtil.classNameOf(value)
/*      */           }), value, instClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException instantiationException(Class<?> instClass, Throwable cause) {
/*      */     String excMsg;
/* 2043 */     if (cause == null) {
/* 2044 */       excMsg = "N/A";
/* 2045 */     } else if ((excMsg = ClassUtil.exceptionMessage(cause)) == null) {
/* 2046 */       excMsg = ClassUtil.nameOf(cause.getClass());
/*      */     } 
/* 2048 */     String msg = String.format("Cannot construct instance of %s, problem: %s", new Object[] {
/* 2049 */           ClassUtil.nameOf(instClass), excMsg
/*      */         });
/*      */     
/* 2052 */     return (JsonMappingException)ValueInstantiationException.from(this._parser, msg, constructType(instClass), cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException instantiationException(Class<?> instClass, String msg0) {
/* 2067 */     return (JsonMappingException)ValueInstantiationException.from(this._parser, 
/* 2068 */         String.format("Cannot construct instance of %s: %s", new Object[] {
/* 2069 */             ClassUtil.nameOf(instClass), msg0
/* 2070 */           }), constructType(instClass));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException invalidTypeIdException(JavaType baseType, String typeId, String extraDesc) {
/* 2076 */     String msg = String.format("Could not resolve type id '%s' as a subtype of %s", new Object[] { typeId, 
/* 2077 */           ClassUtil.getTypeDescription(baseType) });
/* 2078 */     return (JsonMappingException)InvalidTypeIdException.from(this._parser, _colonConcat(msg, extraDesc), baseType, typeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException missingTypeIdException(JavaType baseType, String extraDesc) {
/* 2086 */     String msg = String.format("Could not resolve subtype of %s", new Object[] { baseType });
/*      */     
/* 2088 */     return (JsonMappingException)InvalidTypeIdException.from(this._parser, _colonConcat(msg, extraDesc), baseType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException unknownTypeException(JavaType type, String id, String extraDesc) {
/* 2106 */     String msg = String.format("Could not resolve type id '%s' into a subtype of %s", new Object[] { id, 
/* 2107 */           ClassUtil.getTypeDescription(type) });
/* 2108 */     msg = _colonConcat(msg, extraDesc);
/* 2109 */     return (JsonMappingException)MismatchedInputException.from(this._parser, type, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException endOfInputException(Class<?> instClass) {
/* 2120 */     return (JsonMappingException)MismatchedInputException.from(this._parser, instClass, "Unexpected end-of-input when trying to deserialize a " + instClass
/* 2121 */         .getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void reportMappingException(String msg, Object... msgArgs) throws JsonMappingException {
/* 2145 */     throw JsonMappingException.from(getParser(), _format(msg, msgArgs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(String message) {
/* 2161 */     return JsonMappingException.from(getParser(), message);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(String msg, Object... msgArgs) {
/* 2177 */     return JsonMappingException.from(getParser(), _format(msg, msgArgs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(Class<?> targetClass) {
/* 2187 */     return mappingException(targetClass, this._parser.currentToken());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(Class<?> targetClass, JsonToken token) {
/* 2195 */     return JsonMappingException.from(this._parser, 
/* 2196 */         String.format("Cannot deserialize instance of %s out of %s token", new Object[] {
/* 2197 */             ClassUtil.nameOf(targetClass), token
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected DateFormat getDateFormat() {
/* 2208 */     return _getDateFormat();
/*      */   }
/*      */   
/*      */   protected DateFormat _getDateFormat() {
/* 2212 */     if (this._dateFormat != null) {
/* 2213 */       return this._dateFormat;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2220 */     DateFormat df = this._config.getDateFormat();
/* 2221 */     this._dateFormat = df = (DateFormat)df.clone();
/* 2222 */     return df;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _shapeForToken(JsonToken t) {
/* 2231 */     if (t != null) {
/* 2232 */       switch (t) {
/*      */         
/*      */         case START_OBJECT:
/*      */         case END_OBJECT:
/*      */         case FIELD_NAME:
/* 2237 */           return "Object value";
/*      */ 
/*      */         
/*      */         case START_ARRAY:
/*      */         case END_ARRAY:
/* 2242 */           return "Array value";
/*      */         
/*      */         case VALUE_FALSE:
/*      */         case VALUE_TRUE:
/* 2246 */           return "Boolean value";
/*      */         
/*      */         case VALUE_EMBEDDED_OBJECT:
/* 2249 */           return "Embedded Object";
/*      */         
/*      */         case VALUE_NUMBER_FLOAT:
/* 2252 */           return "Floating-point value";
/*      */         case VALUE_NUMBER_INT:
/* 2254 */           return "Integer value";
/*      */         case VALUE_STRING:
/* 2256 */           return "String value";
/*      */         
/*      */         case VALUE_NULL:
/* 2259 */           return "Null value";
/*      */       } 
/*      */ 
/*      */       
/* 2263 */       return "[Unavailable value]";
/*      */     } 
/*      */     
/* 2266 */     return "<end of input>";
/*      */   }
/*      */   
/*      */   public abstract ReadableObjectId findObjectId(Object paramObject, ObjectIdGenerator<?> paramObjectIdGenerator, ObjectIdResolver paramObjectIdResolver);
/*      */   
/*      */   public abstract void checkUnresolvedObjectId() throws UnresolvedForwardReference;
/*      */   
/*      */   public abstract JsonDeserializer<Object> deserializerInstance(Annotated paramAnnotated, Object paramObject) throws JsonMappingException;
/*      */   
/*      */   public abstract KeyDeserializer keyDeserializerInstance(Annotated paramAnnotated, Object paramObject) throws JsonMappingException;
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\DeserializationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */