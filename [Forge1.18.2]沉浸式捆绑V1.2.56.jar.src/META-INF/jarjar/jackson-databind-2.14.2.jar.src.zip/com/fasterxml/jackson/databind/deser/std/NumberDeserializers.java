/*      */ package com.fasterxml.jackson.databind.deser.std;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JacksonException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.HashSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NumberDeserializers
/*      */ {
/*   28 */   private static final HashSet<String> _classNames = new HashSet<>();
/*      */   
/*      */   static {
/*   31 */     Class<?>[] numberTypes = new Class[] { Boolean.class, Byte.class, Short.class, Character.class, Integer.class, Long.class, Float.class, Double.class, Number.class, BigDecimal.class, BigInteger.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   43 */     for (Class<?> cls : numberTypes) {
/*   44 */       _classNames.add(cls.getName());
/*      */     }
/*      */   }
/*      */   
/*      */   public static JsonDeserializer<?> find(Class<?> rawType, String clsName) {
/*   49 */     if (rawType.isPrimitive()) {
/*   50 */       if (rawType == int.class) {
/*   51 */         return IntegerDeserializer.primitiveInstance;
/*      */       }
/*   53 */       if (rawType == boolean.class) {
/*   54 */         return BooleanDeserializer.primitiveInstance;
/*      */       }
/*   56 */       if (rawType == long.class) {
/*   57 */         return LongDeserializer.primitiveInstance;
/*      */       }
/*   59 */       if (rawType == double.class) {
/*   60 */         return DoubleDeserializer.primitiveInstance;
/*      */       }
/*   62 */       if (rawType == char.class) {
/*   63 */         return CharacterDeserializer.primitiveInstance;
/*      */       }
/*   65 */       if (rawType == byte.class) {
/*   66 */         return ByteDeserializer.primitiveInstance;
/*      */       }
/*   68 */       if (rawType == short.class) {
/*   69 */         return ShortDeserializer.primitiveInstance;
/*      */       }
/*   71 */       if (rawType == float.class) {
/*   72 */         return FloatDeserializer.primitiveInstance;
/*      */       }
/*      */ 
/*      */       
/*   76 */       if (rawType == void.class) {
/*   77 */         return NullifyingDeserializer.instance;
/*      */       }
/*   79 */     } else if (_classNames.contains(clsName)) {
/*      */       
/*   81 */       if (rawType == Integer.class) {
/*   82 */         return IntegerDeserializer.wrapperInstance;
/*      */       }
/*   84 */       if (rawType == Boolean.class) {
/*   85 */         return BooleanDeserializer.wrapperInstance;
/*      */       }
/*   87 */       if (rawType == Long.class) {
/*   88 */         return LongDeserializer.wrapperInstance;
/*      */       }
/*   90 */       if (rawType == Double.class) {
/*   91 */         return DoubleDeserializer.wrapperInstance;
/*      */       }
/*   93 */       if (rawType == Character.class) {
/*   94 */         return CharacterDeserializer.wrapperInstance;
/*      */       }
/*   96 */       if (rawType == Byte.class) {
/*   97 */         return ByteDeserializer.wrapperInstance;
/*      */       }
/*   99 */       if (rawType == Short.class) {
/*  100 */         return ShortDeserializer.wrapperInstance;
/*      */       }
/*  102 */       if (rawType == Float.class) {
/*  103 */         return FloatDeserializer.wrapperInstance;
/*      */       }
/*  105 */       if (rawType == Number.class) {
/*  106 */         return NumberDeserializer.instance;
/*      */       }
/*  108 */       if (rawType == BigDecimal.class) {
/*  109 */         return BigDecimalDeserializer.instance;
/*      */       }
/*  111 */       if (rawType == BigInteger.class) {
/*  112 */         return BigIntegerDeserializer.instance;
/*      */       }
/*      */     } else {
/*  115 */       return null;
/*      */     } 
/*      */     
/*  118 */     throw new IllegalArgumentException("Internal error: can't find deserializer for " + rawType.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static abstract class PrimitiveOrWrapperDeserializer<T>
/*      */     extends StdScalarDeserializer<T>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final LogicalType _logicalType;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final T _nullValue;
/*      */ 
/*      */     
/*      */     protected final T _emptyValue;
/*      */ 
/*      */     
/*      */     protected final boolean _primitive;
/*      */ 
/*      */ 
/*      */     
/*      */     protected PrimitiveOrWrapperDeserializer(Class<T> vc, LogicalType logicalType, T nvl, T empty) {
/*  146 */       super(vc);
/*  147 */       this._logicalType = logicalType;
/*  148 */       this._nullValue = nvl;
/*  149 */       this._emptyValue = empty;
/*  150 */       this._primitive = vc.isPrimitive();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     protected PrimitiveOrWrapperDeserializer(Class<T> vc, T nvl, T empty) {
/*  155 */       this(vc, LogicalType.OtherScalar, nvl, empty);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AccessPattern getNullAccessPattern() {
/*  162 */       if (this._primitive) {
/*  163 */         return AccessPattern.DYNAMIC;
/*      */       }
/*  165 */       if (this._nullValue == null) {
/*  166 */         return AccessPattern.ALWAYS_NULL;
/*      */       }
/*  168 */       return AccessPattern.CONSTANT;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final T getNullValue(DeserializationContext ctxt) throws JsonMappingException {
/*  175 */       if (this._primitive && ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES))
/*  176 */         ctxt.reportInputMismatch(this, "Cannot map `null` into type %s (set DeserializationConfig.DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES to 'false' to allow)", new Object[] {
/*      */               
/*  178 */               ClassUtil.classNameOf(handledType())
/*      */             }); 
/*  180 */       return this._nullValue;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/*  185 */       return this._emptyValue;
/*      */     }
/*      */ 
/*      */     
/*      */     public final LogicalType logicalType() {
/*  190 */       return this._logicalType;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static final class BooleanDeserializer
/*      */     extends PrimitiveOrWrapperDeserializer<Boolean>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */     
/*  206 */     static final BooleanDeserializer primitiveInstance = new BooleanDeserializer((Class)boolean.class, Boolean.FALSE);
/*  207 */     static final BooleanDeserializer wrapperInstance = new BooleanDeserializer(Boolean.class, null);
/*      */ 
/*      */     
/*      */     public BooleanDeserializer(Class<Boolean> cls, Boolean nvl) {
/*  211 */       super(cls, LogicalType.Boolean, nvl, Boolean.FALSE);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Boolean deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  217 */       JsonToken t = p.currentToken();
/*  218 */       if (t == JsonToken.VALUE_TRUE) {
/*  219 */         return Boolean.TRUE;
/*      */       }
/*  221 */       if (t == JsonToken.VALUE_FALSE) {
/*  222 */         return Boolean.FALSE;
/*      */       }
/*  224 */       if (this._primitive) {
/*  225 */         return Boolean.valueOf(_parseBooleanPrimitive(p, ctxt));
/*      */       }
/*  227 */       return _parseBoolean(p, ctxt, this._valueClass);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Boolean deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/*  237 */       JsonToken t = p.currentToken();
/*  238 */       if (t == JsonToken.VALUE_TRUE) {
/*  239 */         return Boolean.TRUE;
/*      */       }
/*  241 */       if (t == JsonToken.VALUE_FALSE) {
/*  242 */         return Boolean.FALSE;
/*      */       }
/*  244 */       if (this._primitive) {
/*  245 */         return Boolean.valueOf(_parseBooleanPrimitive(p, ctxt));
/*      */       }
/*  247 */       return _parseBoolean(p, ctxt, this._valueClass);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static class ByteDeserializer
/*      */     extends PrimitiveOrWrapperDeserializer<Byte>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  257 */     static final ByteDeserializer primitiveInstance = new ByteDeserializer((Class)byte.class, Byte.valueOf((byte)0));
/*  258 */     static final ByteDeserializer wrapperInstance = new ByteDeserializer(Byte.class, null);
/*      */ 
/*      */     
/*      */     public ByteDeserializer(Class<Byte> cls, Byte nvl) {
/*  262 */       super(cls, LogicalType.Integer, nvl, Byte.valueOf((byte)0));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Byte deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  268 */       if (p.isExpectedNumberIntToken()) {
/*  269 */         return Byte.valueOf(p.getByteValue());
/*      */       }
/*  271 */       if (this._primitive) {
/*  272 */         return Byte.valueOf(_parseBytePrimitive(p, ctxt));
/*      */       }
/*  274 */       return _parseByte(p, ctxt);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Byte _parseByte(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */       int value;
/*  282 */       switch (p.currentTokenId()) {
/*      */         case 6:
/*  284 */           text = p.getText();
/*      */           break;
/*      */         case 8:
/*  287 */           act = _checkFloatToIntCoercion(p, ctxt, this._valueClass);
/*  288 */           if (act == CoercionAction.AsNull) {
/*  289 */             return getNullValue(ctxt);
/*      */           }
/*  291 */           if (act == CoercionAction.AsEmpty) {
/*  292 */             return (Byte)getEmptyValue(ctxt);
/*      */           }
/*  294 */           return Byte.valueOf(p.getByteValue());
/*      */         case 11:
/*  296 */           return getNullValue(ctxt);
/*      */         case 7:
/*  298 */           return Byte.valueOf(p.getByteValue());
/*      */         case 3:
/*  300 */           return _deserializeFromArray(p, ctxt);
/*      */         
/*      */         case 1:
/*  303 */           text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */           break;
/*      */         default:
/*  306 */           return (Byte)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */       } 
/*      */ 
/*      */       
/*  310 */       CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  311 */       if (act == CoercionAction.AsNull) {
/*  312 */         return getNullValue(ctxt);
/*      */       }
/*  314 */       if (act == CoercionAction.AsEmpty) {
/*  315 */         return (Byte)getEmptyValue(ctxt);
/*      */       }
/*  317 */       String text = text.trim();
/*  318 */       if (_checkTextualNull(ctxt, text)) {
/*  319 */         return getNullValue(ctxt);
/*      */       }
/*      */       
/*      */       try {
/*  323 */         value = NumberInput.parseInt(text);
/*  324 */       } catch (IllegalArgumentException iae) {
/*  325 */         return (Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid Byte value", new Object[0]);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  330 */       if (_byteOverflow(value)) {
/*  331 */         return (Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "overflow, value cannot be represented as 8-bit value", new Object[0]);
/*      */       }
/*      */ 
/*      */       
/*  335 */       return Byte.valueOf((byte)value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static class ShortDeserializer
/*      */     extends PrimitiveOrWrapperDeserializer<Short>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  345 */     static final ShortDeserializer primitiveInstance = new ShortDeserializer((Class)short.class, Short.valueOf((short)0));
/*  346 */     static final ShortDeserializer wrapperInstance = new ShortDeserializer(Short.class, null);
/*      */ 
/*      */     
/*      */     public ShortDeserializer(Class<Short> cls, Short nvl) {
/*  350 */       super(cls, LogicalType.Integer, nvl, Short.valueOf((short)0));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Short deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  357 */       if (p.isExpectedNumberIntToken()) {
/*  358 */         return Short.valueOf(p.getShortValue());
/*      */       }
/*  360 */       if (this._primitive) {
/*  361 */         return Short.valueOf(_parseShortPrimitive(p, ctxt));
/*      */       }
/*  363 */       return _parseShort(p, ctxt);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected Short _parseShort(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */       int value;
/*  370 */       switch (p.currentTokenId()) {
/*      */         case 6:
/*  372 */           text = p.getText();
/*      */           break;
/*      */         case 8:
/*  375 */           act = _checkFloatToIntCoercion(p, ctxt, this._valueClass);
/*  376 */           if (act == CoercionAction.AsNull) {
/*  377 */             return getNullValue(ctxt);
/*      */           }
/*  379 */           if (act == CoercionAction.AsEmpty) {
/*  380 */             return (Short)getEmptyValue(ctxt);
/*      */           }
/*  382 */           return Short.valueOf(p.getShortValue());
/*      */         case 11:
/*  384 */           return getNullValue(ctxt);
/*      */         case 7:
/*  386 */           return Short.valueOf(p.getShortValue());
/*      */         
/*      */         case 1:
/*  389 */           text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */           break;
/*      */         case 3:
/*  392 */           return _deserializeFromArray(p, ctxt);
/*      */         default:
/*  394 */           return (Short)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */       } 
/*      */ 
/*      */       
/*  398 */       CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  399 */       if (act == CoercionAction.AsNull) {
/*  400 */         return getNullValue(ctxt);
/*      */       }
/*  402 */       if (act == CoercionAction.AsEmpty) {
/*  403 */         return (Short)getEmptyValue(ctxt);
/*      */       }
/*  405 */       String text = text.trim();
/*  406 */       if (_checkTextualNull(ctxt, text)) {
/*  407 */         return getNullValue(ctxt);
/*      */       }
/*      */       
/*      */       try {
/*  411 */         value = NumberInput.parseInt(text);
/*  412 */       } catch (IllegalArgumentException iae) {
/*  413 */         return (Short)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid Short value", new Object[0]);
/*      */       } 
/*      */ 
/*      */       
/*  417 */       if (_shortOverflow(value)) {
/*  418 */         return (Short)ctxt.handleWeirdStringValue(this._valueClass, text, "overflow, value cannot be represented as 16-bit value", new Object[0]);
/*      */       }
/*      */       
/*  421 */       return Short.valueOf((short)value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static class CharacterDeserializer
/*      */     extends PrimitiveOrWrapperDeserializer<Character>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  431 */     static final CharacterDeserializer primitiveInstance = new CharacterDeserializer((Class)char.class, Character.valueOf(false));
/*  432 */     static final CharacterDeserializer wrapperInstance = new CharacterDeserializer(Character.class, null);
/*      */ 
/*      */     
/*      */     public CharacterDeserializer(Class<Character> cls, Character nvl) {
/*  436 */       super(cls, LogicalType.Integer, nvl, 
/*      */           
/*  438 */           Character.valueOf(false));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Character deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */       int value;
/*  446 */       switch (p.currentTokenId()) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 6:
/*  451 */           text = p.getText();
/*      */           break;
/*      */         case 7:
/*  454 */           act = ctxt.findCoercionAction(logicalType(), this._valueClass, CoercionInputShape.Integer);
/*  455 */           switch (act) {
/*      */             case Fail:
/*  457 */               _checkCoercionFail(ctxt, act, this._valueClass, p.getNumberValue(), "Integer value (" + p
/*  458 */                   .getText() + ")");
/*      */             
/*      */             case AsNull:
/*  461 */               return getNullValue(ctxt);
/*      */             case AsEmpty:
/*  463 */               return (Character)getEmptyValue(ctxt);
/*      */           } 
/*      */           
/*  466 */           value = p.getIntValue();
/*  467 */           if (value >= 0 && value <= 65535) {
/*  468 */             return Character.valueOf((char)value);
/*      */           }
/*  470 */           return (Character)ctxt.handleWeirdNumberValue(handledType(), Integer.valueOf(value), "value outside valid Character range (0x0000 - 0xFFFF)", new Object[0]);
/*      */         
/*      */         case 11:
/*  473 */           if (this._primitive) {
/*  474 */             _verifyNullForPrimitive(ctxt);
/*      */           }
/*  476 */           return getNullValue(ctxt);
/*      */         
/*      */         case 1:
/*  479 */           text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */           break;
/*      */         case 3:
/*  482 */           return _deserializeFromArray(p, ctxt);
/*      */         default:
/*  484 */           return (Character)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */       } 
/*      */       
/*  487 */       if (text.length() == 1) {
/*  488 */         return Character.valueOf(text.charAt(0));
/*      */       }
/*  490 */       CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  491 */       if (act == CoercionAction.AsNull) {
/*  492 */         return getNullValue(ctxt);
/*      */       }
/*  494 */       if (act == CoercionAction.AsEmpty) {
/*  495 */         return (Character)getEmptyValue(ctxt);
/*      */       }
/*  497 */       String text = text.trim();
/*  498 */       if (_checkTextualNull(ctxt, text)) {
/*  499 */         return getNullValue(ctxt);
/*      */       }
/*  501 */       return (Character)ctxt.handleWeirdStringValue(handledType(), text, "Expected either Integer value code or 1-character String", new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static final class IntegerDeserializer
/*      */     extends PrimitiveOrWrapperDeserializer<Integer>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*  512 */     static final IntegerDeserializer primitiveInstance = new IntegerDeserializer((Class)int.class, Integer.valueOf(0));
/*  513 */     static final IntegerDeserializer wrapperInstance = new IntegerDeserializer(Integer.class, null);
/*      */     
/*      */     public IntegerDeserializer(Class<Integer> cls, Integer nvl) {
/*  516 */       super(cls, LogicalType.Integer, nvl, Integer.valueOf(0));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isCachable() {
/*  521 */       return true;
/*      */     }
/*      */     
/*      */     public Integer deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  525 */       if (p.isExpectedNumberIntToken()) {
/*  526 */         return Integer.valueOf(p.getIntValue());
/*      */       }
/*  528 */       if (this._primitive) {
/*  529 */         return Integer.valueOf(_parseIntPrimitive(p, ctxt));
/*      */       }
/*  531 */       return _parseInteger(p, ctxt, Integer.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Integer deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/*  540 */       if (p.isExpectedNumberIntToken()) {
/*  541 */         return Integer.valueOf(p.getIntValue());
/*      */       }
/*  543 */       if (this._primitive) {
/*  544 */         return Integer.valueOf(_parseIntPrimitive(p, ctxt));
/*      */       }
/*  546 */       return _parseInteger(p, ctxt, Integer.class);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static final class LongDeserializer
/*      */     extends PrimitiveOrWrapperDeserializer<Long>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  556 */     static final LongDeserializer primitiveInstance = new LongDeserializer((Class)long.class, Long.valueOf(0L));
/*  557 */     static final LongDeserializer wrapperInstance = new LongDeserializer(Long.class, null);
/*      */     
/*      */     public LongDeserializer(Class<Long> cls, Long nvl) {
/*  560 */       super(cls, LogicalType.Integer, nvl, Long.valueOf(0L));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isCachable() {
/*  565 */       return true;
/*      */     }
/*      */     
/*      */     public Long deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  569 */       if (p.isExpectedNumberIntToken()) {
/*  570 */         return Long.valueOf(p.getLongValue());
/*      */       }
/*  572 */       if (this._primitive) {
/*  573 */         return Long.valueOf(_parseLongPrimitive(p, ctxt));
/*      */       }
/*  575 */       return _parseLong(p, ctxt, Long.class);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static class FloatDeserializer
/*      */     extends PrimitiveOrWrapperDeserializer<Float>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  585 */     static final FloatDeserializer primitiveInstance = new FloatDeserializer((Class)float.class, Float.valueOf(0.0F));
/*  586 */     static final FloatDeserializer wrapperInstance = new FloatDeserializer(Float.class, null);
/*      */     
/*      */     public FloatDeserializer(Class<Float> cls, Float nvl) {
/*  589 */       super(cls, LogicalType.Float, nvl, Float.valueOf(0.0F));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Float deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  595 */       if (p.hasToken(JsonToken.VALUE_NUMBER_FLOAT)) {
/*  596 */         return Float.valueOf(p.getFloatValue());
/*      */       }
/*  598 */       if (this._primitive) {
/*  599 */         return Float.valueOf(_parseFloatPrimitive(p, ctxt));
/*      */       }
/*  601 */       return _parseFloat(p, ctxt);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected final Float _parseFloat(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */       CoercionAction coercionAction1;
/*  608 */       switch (p.currentTokenId()) {
/*      */         case 6:
/*  610 */           text = p.getText();
/*      */           break;
/*      */         case 11:
/*  613 */           return getNullValue(ctxt);
/*      */         case 7:
/*  615 */           coercionAction1 = _checkIntToFloatCoercion(p, ctxt, this._valueClass);
/*  616 */           if (coercionAction1 == CoercionAction.AsNull) {
/*  617 */             return getNullValue(ctxt);
/*      */           }
/*  619 */           if (coercionAction1 == CoercionAction.AsEmpty) {
/*  620 */             return (Float)getEmptyValue(ctxt);
/*      */           }
/*      */         
/*      */         case 8:
/*  624 */           return Float.valueOf(p.getFloatValue());
/*      */         
/*      */         case 1:
/*  627 */           text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */           break;
/*      */         case 3:
/*  630 */           return _deserializeFromArray(p, ctxt);
/*      */         default:
/*  632 */           return (Float)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  639 */       Float nan = _checkFloatSpecialValue(text);
/*  640 */       if (nan != null) {
/*  641 */         return nan;
/*      */       }
/*      */       
/*  644 */       CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  645 */       if (act == CoercionAction.AsNull) {
/*  646 */         return getNullValue(ctxt);
/*      */       }
/*  648 */       if (act == CoercionAction.AsEmpty) {
/*  649 */         return (Float)getEmptyValue(ctxt);
/*      */       }
/*  651 */       String text = text.trim();
/*  652 */       if (_checkTextualNull(ctxt, text)) {
/*  653 */         return getNullValue(ctxt);
/*      */       }
/*      */       try {
/*  656 */         return Float.valueOf(NumberInput.parseFloat(text, p.isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER)));
/*  657 */       } catch (IllegalArgumentException illegalArgumentException) {
/*  658 */         return (Float)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid `Float` value", new Object[0]);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static class DoubleDeserializer
/*      */     extends PrimitiveOrWrapperDeserializer<Double>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  669 */     static final DoubleDeserializer primitiveInstance = new DoubleDeserializer((Class)double.class, Double.valueOf(0.0D));
/*  670 */     static final DoubleDeserializer wrapperInstance = new DoubleDeserializer(Double.class, null);
/*      */     
/*      */     public DoubleDeserializer(Class<Double> cls, Double nvl) {
/*  673 */       super(cls, LogicalType.Float, nvl, Double.valueOf(0.0D));
/*      */     }
/*      */ 
/*      */     
/*      */     public Double deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  678 */       if (p.hasToken(JsonToken.VALUE_NUMBER_FLOAT)) {
/*  679 */         return Double.valueOf(p.getDoubleValue());
/*      */       }
/*  681 */       if (this._primitive) {
/*  682 */         return Double.valueOf(_parseDoublePrimitive(p, ctxt));
/*      */       }
/*  684 */       return _parseDouble(p, ctxt);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Double deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/*  693 */       if (p.hasToken(JsonToken.VALUE_NUMBER_FLOAT)) {
/*  694 */         return Double.valueOf(p.getDoubleValue());
/*      */       }
/*  696 */       if (this._primitive) {
/*  697 */         return Double.valueOf(_parseDoublePrimitive(p, ctxt));
/*      */       }
/*  699 */       return _parseDouble(p, ctxt);
/*      */     }
/*      */ 
/*      */     
/*      */     protected final Double _parseDouble(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */       CoercionAction coercionAction1;
/*  705 */       switch (p.currentTokenId()) {
/*      */         case 6:
/*  707 */           text = p.getText();
/*      */           break;
/*      */         case 11:
/*  710 */           return getNullValue(ctxt);
/*      */         case 7:
/*  712 */           coercionAction1 = _checkIntToFloatCoercion(p, ctxt, this._valueClass);
/*  713 */           if (coercionAction1 == CoercionAction.AsNull) {
/*  714 */             return getNullValue(ctxt);
/*      */           }
/*  716 */           if (coercionAction1 == CoercionAction.AsEmpty) {
/*  717 */             return (Double)getEmptyValue(ctxt);
/*      */           }
/*      */         
/*      */         case 8:
/*  721 */           return Double.valueOf(p.getDoubleValue());
/*      */         
/*      */         case 1:
/*  724 */           text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */           break;
/*      */         case 3:
/*  727 */           return _deserializeFromArray(p, ctxt);
/*      */         default:
/*  729 */           return (Double)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  736 */       Double nan = _checkDoubleSpecialValue(text);
/*  737 */       if (nan != null) {
/*  738 */         return nan;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  743 */       CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  744 */       if (act == CoercionAction.AsNull) {
/*  745 */         return getNullValue(ctxt);
/*      */       }
/*  747 */       if (act == CoercionAction.AsEmpty) {
/*  748 */         return (Double)getEmptyValue(ctxt);
/*      */       }
/*  750 */       String text = text.trim();
/*  751 */       if (_checkTextualNull(ctxt, text)) {
/*  752 */         return getNullValue(ctxt);
/*      */       }
/*      */       try {
/*  755 */         return Double.valueOf(_parseDouble(text, p.isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER)));
/*  756 */       } catch (IllegalArgumentException illegalArgumentException) {
/*  757 */         return (Double)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid `Double` value", new Object[0]);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static class NumberDeserializer
/*      */     extends StdScalarDeserializer<Object>
/*      */   {
/*  777 */     public static final NumberDeserializer instance = new NumberDeserializer();
/*      */     
/*      */     public NumberDeserializer() {
/*  780 */       super(Number.class);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final LogicalType logicalType() {
/*  786 */       return LogicalType.Integer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  793 */       switch (p.currentTokenId()) {
/*      */         case 6:
/*  795 */           text = p.getText();
/*      */           break;
/*      */         case 7:
/*  798 */           if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/*  799 */             return _coerceIntegral(p, ctxt);
/*      */           }
/*  801 */           return p.getNumberValue();
/*      */         
/*      */         case 8:
/*  804 */           if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS))
/*      */           {
/*  806 */             if (!p.isNaN()) {
/*  807 */               return p.getDecimalValue();
/*      */             }
/*      */           }
/*  810 */           return p.getNumberValue();
/*      */         
/*      */         case 1:
/*  813 */           text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */           break;
/*      */         case 3:
/*  816 */           return _deserializeFromArray(p, ctxt);
/*      */         default:
/*  818 */           return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  823 */       CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  824 */       if (act == CoercionAction.AsNull) {
/*  825 */         return getNullValue(ctxt);
/*      */       }
/*  827 */       if (act == CoercionAction.AsEmpty) {
/*  828 */         return getEmptyValue(ctxt);
/*      */       }
/*  830 */       String text = text.trim();
/*  831 */       if (_hasTextualNull(text))
/*      */       {
/*  833 */         return getNullValue(ctxt);
/*      */       }
/*  835 */       if (_isPosInf(text)) {
/*  836 */         return Double.valueOf(Double.POSITIVE_INFINITY);
/*      */       }
/*  838 */       if (_isNegInf(text)) {
/*  839 */         return Double.valueOf(Double.NEGATIVE_INFINITY);
/*      */       }
/*  841 */       if (_isNaN(text)) {
/*  842 */         return Double.valueOf(Double.NaN);
/*      */       }
/*      */       try {
/*  845 */         if (!_isIntNumber(text)) {
/*  846 */           if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  847 */             return NumberInput.parseBigDecimal(text);
/*      */           }
/*  849 */           return Double.valueOf(
/*  850 */               NumberInput.parseDouble(text, p.isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER)));
/*      */         } 
/*  852 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS)) {
/*  853 */           return NumberInput.parseBigInteger(text);
/*      */         }
/*  855 */         long value = NumberInput.parseLong(text);
/*  856 */         if (!ctxt.isEnabled(DeserializationFeature.USE_LONG_FOR_INTS) && 
/*  857 */           value <= 2147483647L && value >= -2147483648L) {
/*  858 */           return Integer.valueOf((int)value);
/*      */         }
/*      */         
/*  861 */         return Long.valueOf(value);
/*  862 */       } catch (IllegalArgumentException iae) {
/*  863 */         return ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid number", new Object[0]);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/*  879 */       switch (p.currentTokenId()) {
/*      */         
/*      */         case 6:
/*      */         case 7:
/*      */         case 8:
/*  884 */           return deserialize(p, ctxt);
/*      */       } 
/*  886 */       return typeDeserializer.deserializeTypedFromScalar(p, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static class BigIntegerDeserializer
/*      */     extends StdScalarDeserializer<BigInteger>
/*      */   {
/*  905 */     public static final BigIntegerDeserializer instance = new BigIntegerDeserializer();
/*      */     public BigIntegerDeserializer() {
/*  907 */       super(BigInteger.class);
/*      */     }
/*      */     
/*      */     public Object getEmptyValue(DeserializationContext ctxt) {
/*  911 */       return BigInteger.ZERO;
/*      */     }
/*      */ 
/*      */     
/*      */     public final LogicalType logicalType() {
/*  916 */       return LogicalType.Integer;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public BigInteger deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  922 */       if (p.isExpectedNumberIntToken()) {
/*  923 */         return p.getBigIntegerValue();
/*      */       }
/*      */ 
/*      */       
/*  927 */       switch (p.currentTokenId()) {
/*      */         case 6:
/*  929 */           text = p.getText();
/*      */           break;
/*      */         case 8:
/*  932 */           act = _checkFloatToIntCoercion(p, ctxt, this._valueClass);
/*  933 */           if (act == CoercionAction.AsNull) {
/*  934 */             return (BigInteger)getNullValue(ctxt);
/*      */           }
/*  936 */           if (act == CoercionAction.AsEmpty) {
/*  937 */             return (BigInteger)getEmptyValue(ctxt);
/*      */           }
/*  939 */           return p.getDecimalValue().toBigInteger();
/*      */         
/*      */         case 1:
/*  942 */           text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */           break;
/*      */         case 3:
/*  945 */           return _deserializeFromArray(p, ctxt);
/*      */         
/*      */         default:
/*  948 */           return (BigInteger)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */       } 
/*      */       
/*  951 */       CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  952 */       if (act == CoercionAction.AsNull) {
/*  953 */         return (BigInteger)getNullValue(ctxt);
/*      */       }
/*  955 */       if (act == CoercionAction.AsEmpty) {
/*  956 */         return (BigInteger)getEmptyValue(ctxt);
/*      */       }
/*  958 */       String text = text.trim();
/*  959 */       if (_hasTextualNull(text))
/*      */       {
/*  961 */         return (BigInteger)getNullValue(ctxt);
/*      */       }
/*      */       try {
/*  964 */         return NumberInput.parseBigInteger(text);
/*  965 */       } catch (IllegalArgumentException illegalArgumentException) {
/*  966 */         return (BigInteger)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid representation", new Object[0]);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @JacksonStdImpl
/*      */   public static class BigDecimalDeserializer
/*      */     extends StdScalarDeserializer<BigDecimal>
/*      */   {
/*  976 */     public static final BigDecimalDeserializer instance = new BigDecimalDeserializer();
/*      */     public BigDecimalDeserializer() {
/*  978 */       super(BigDecimal.class);
/*      */     }
/*      */     
/*      */     public Object getEmptyValue(DeserializationContext ctxt) {
/*  982 */       return BigDecimal.ZERO;
/*      */     }
/*      */ 
/*      */     
/*      */     public final LogicalType logicalType() {
/*  987 */       return LogicalType.Float;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BigDecimal deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  995 */       switch (p.currentTokenId()) {
/*      */         case 7:
/*  997 */           act = _checkIntToFloatCoercion(p, ctxt, this._valueClass);
/*  998 */           if (act == CoercionAction.AsNull) {
/*  999 */             return (BigDecimal)getNullValue(ctxt);
/*      */           }
/* 1001 */           if (act == CoercionAction.AsEmpty) {
/* 1002 */             return (BigDecimal)getEmptyValue(ctxt);
/*      */           }
/*      */         
/*      */         case 8:
/* 1006 */           return p.getDecimalValue();
/*      */         case 6:
/* 1008 */           text = p.getText();
/*      */           break;
/*      */         
/*      */         case 1:
/* 1012 */           text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */           break;
/*      */         case 3:
/* 1015 */           return _deserializeFromArray(p, ctxt);
/*      */         default:
/* 1017 */           return (BigDecimal)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */       } 
/*      */       
/* 1020 */       CoercionAction act = _checkFromStringCoercion(ctxt, text);
/* 1021 */       if (act == CoercionAction.AsNull) {
/* 1022 */         return (BigDecimal)getNullValue(ctxt);
/*      */       }
/* 1024 */       if (act == CoercionAction.AsEmpty) {
/* 1025 */         return (BigDecimal)getEmptyValue(ctxt);
/*      */       }
/* 1027 */       String text = text.trim();
/* 1028 */       if (_hasTextualNull(text))
/*      */       {
/* 1030 */         return (BigDecimal)getNullValue(ctxt);
/*      */       }
/*      */       try {
/* 1033 */         return NumberInput.parseBigDecimal(text);
/* 1034 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 1035 */         return (BigDecimal)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid representation", new Object[0]);
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\NumberDeserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */