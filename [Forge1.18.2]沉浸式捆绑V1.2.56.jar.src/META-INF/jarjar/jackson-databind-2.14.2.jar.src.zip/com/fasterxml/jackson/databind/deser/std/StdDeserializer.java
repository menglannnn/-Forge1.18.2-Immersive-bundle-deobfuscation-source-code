/*      */ package com.fasterxml.jackson.databind.deser.std;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.Nulls;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerBase;
/*      */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*      */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsAsEmptyProvider;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsFailProvider;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.Converter;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class StdDeserializer<T>
/*      */   extends JsonDeserializer<T>
/*      */   implements Serializable, ValueInstantiator.Gettable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   51 */   protected static final int F_MASK_INT_COERCIONS = DeserializationFeature.USE_BIG_INTEGER_FOR_INTS
/*   52 */     .getMask() | DeserializationFeature.USE_LONG_FOR_INTS
/*   53 */     .getMask();
/*      */   
/*      */   @Deprecated
/*   56 */   protected static final int F_MASK_ACCEPT_ARRAYS = DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS
/*   57 */     .getMask() | DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT
/*   58 */     .getMask();
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Class<?> _valueClass;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JavaType _valueType;
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdDeserializer(Class<?> vc) {
/*   71 */     this._valueClass = vc;
/*   72 */     this._valueType = null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected StdDeserializer(JavaType valueType) {
/*   77 */     this._valueClass = (valueType == null) ? Object.class : valueType.getRawClass();
/*   78 */     this._valueType = valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdDeserializer(StdDeserializer<?> src) {
/*   88 */     this._valueClass = src._valueClass;
/*   89 */     this._valueType = src._valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> handledType() {
/*   99 */     return this._valueClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Class<?> getValueClass() {
/*  111 */     return this._valueClass;
/*      */   }
/*      */ 
/*      */   
/*      */   public JavaType getValueType() {
/*  116 */     return this._valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getValueType(DeserializationContext ctxt) {
/*  132 */     if (this._valueType != null) {
/*  133 */       return this._valueType;
/*      */     }
/*  135 */     return ctxt.constructType(this._valueClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ValueInstantiator getValueInstantiator() {
/*  142 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isDefaultDeserializer(JsonDeserializer<?> deserializer) {
/*  151 */     return ClassUtil.isJacksonStdImpl(deserializer);
/*      */   }
/*      */   
/*      */   protected boolean isDefaultKeyDeserializer(KeyDeserializer keyDeser) {
/*  155 */     return ClassUtil.isJacksonStdImpl(keyDeser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/*  172 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  200 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/*  201 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/*  203 */     if (unwrap || act != CoercionAction.Fail) {
/*  204 */       JsonToken t = p.nextToken();
/*  205 */       if (t == JsonToken.END_ARRAY) {
/*  206 */         switch (act) {
/*      */           case AsEmpty:
/*  208 */             return (T)getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/*  211 */             return (T)getNullValue(ctxt);
/*      */         } 
/*      */       
/*  214 */       } else if (unwrap) {
/*  215 */         T parsed = _deserializeWrappedValue(p, ctxt);
/*  216 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/*  217 */           handleMissingEndArrayForSingle(p, ctxt);
/*      */         }
/*  219 */         return parsed;
/*      */       } 
/*      */     } 
/*  222 */     return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected T _deserializeFromEmpty(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  238 */     if (p.hasToken(JsonToken.START_ARRAY) && 
/*  239 */       ctxt.isEnabled(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT)) {
/*  240 */       JsonToken t = p.nextToken();
/*  241 */       if (t == JsonToken.END_ARRAY) {
/*  242 */         return null;
/*      */       }
/*  244 */       return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  247 */     return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeFromString(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  260 */     ValueInstantiator inst = getValueInstantiator();
/*  261 */     Class<?> rawTargetType = handledType();
/*  262 */     String value = p.getValueAsString();
/*      */     
/*  264 */     if (inst != null && inst.canCreateFromString()) {
/*  265 */       return (T)inst.createFromString(ctxt, value);
/*      */     }
/*  267 */     if (value.isEmpty()) {
/*  268 */       CoercionAction act = ctxt.findCoercionAction(logicalType(), rawTargetType, CoercionInputShape.EmptyString);
/*      */       
/*  270 */       return (T)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "empty String (\"\")");
/*      */     } 
/*      */     
/*  273 */     if (_isBlank(value)) {
/*  274 */       CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), rawTargetType, CoercionAction.Fail);
/*      */       
/*  276 */       return (T)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "blank String (all whitespace)");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  283 */     if (inst != null) {
/*  284 */       value = value.trim();
/*  285 */       if (inst.canCreateFromInt() && 
/*  286 */         ctxt.findCoercionAction(LogicalType.Integer, Integer.class, CoercionInputShape.String) == CoercionAction.TryConvert)
/*      */       {
/*  288 */         return (T)inst.createFromInt(ctxt, _parseIntPrimitive(ctxt, value));
/*      */       }
/*      */       
/*  291 */       if (inst.canCreateFromLong() && 
/*  292 */         ctxt.findCoercionAction(LogicalType.Integer, Long.class, CoercionInputShape.String) == CoercionAction.TryConvert)
/*      */       {
/*  294 */         return (T)inst.createFromLong(ctxt, _parseLongPrimitive(ctxt, value));
/*      */       }
/*      */       
/*  297 */       if (inst.canCreateFromBoolean())
/*      */       {
/*  299 */         if (ctxt.findCoercionAction(LogicalType.Boolean, Boolean.class, CoercionInputShape.String) == CoercionAction.TryConvert) {
/*      */           
/*  301 */           String str = value.trim();
/*  302 */           if ("true".equals(str)) {
/*  303 */             return (T)inst.createFromBoolean(ctxt, true);
/*      */           }
/*  305 */           if ("false".equals(str)) {
/*  306 */             return (T)inst.createFromBoolean(ctxt, false);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*  311 */     return (T)ctxt.handleMissingInstantiator(rawTargetType, inst, ctxt.getParser(), "no String-argument constructor/factory method to deserialize from String value ('%s')", new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeFromEmptyString(JsonParser p, DeserializationContext ctxt, CoercionAction act, Class<?> rawTargetType, String desc) throws IOException {
/*  320 */     switch (act) {
/*      */       case AsEmpty:
/*  322 */         return getEmptyValue(ctxt);
/*      */       
/*      */       case Fail:
/*  325 */         _checkCoercionFail(ctxt, act, rawTargetType, "", "empty String (\"\")");
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  331 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeWrappedValue(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  359 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/*      */       
/*  361 */       T result = (T)handleNestedArrayForSingle(p, ctxt);
/*  362 */       return result;
/*      */     } 
/*  364 */     return (T)deserialize(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final boolean _parseBooleanPrimitive(DeserializationContext ctxt, JsonParser p, Class<?> targetType) throws IOException {
/*  378 */     return _parseBooleanPrimitive(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _parseBooleanPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  389 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  391 */         text = p.getText();
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*  397 */         return Boolean.TRUE.equals(_coerceBooleanFromInt(p, ctxt, boolean.class));
/*      */       case 9:
/*  399 */         return true;
/*      */       case 10:
/*  401 */         return false;
/*      */       case 11:
/*  403 */         _verifyNullForPrimitive(ctxt);
/*  404 */         return false;
/*      */       
/*      */       case 1:
/*  407 */         text = ctxt.extractScalarFromObject(p, this, boolean.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  411 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  412 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  413 */             return ((Boolean)handleNestedArrayForSingle(p, ctxt)).booleanValue();
/*      */           }
/*  415 */           boolean parsed = _parseBooleanPrimitive(p, ctxt);
/*  416 */           _verifyEndArrayForSingle(p, ctxt);
/*  417 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  421 */         return ((Boolean)ctxt.handleUnexpectedToken(boolean.class, p)).booleanValue();
/*      */     } 
/*      */     
/*  424 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Boolean, boolean.class);
/*      */     
/*  426 */     if (act == CoercionAction.AsNull) {
/*  427 */       _verifyNullForPrimitive(ctxt);
/*  428 */       return false;
/*      */     } 
/*  430 */     if (act == CoercionAction.AsEmpty) {
/*  431 */       return false;
/*      */     }
/*  433 */     String text = text.trim();
/*  434 */     int len = text.length();
/*      */ 
/*      */ 
/*      */     
/*  438 */     if (len == 4) {
/*  439 */       if (_isTrue(text)) {
/*  440 */         return true;
/*      */       }
/*  442 */     } else if (len == 5 && 
/*  443 */       _isFalse(text)) {
/*  444 */       return false;
/*      */     } 
/*      */     
/*  447 */     if (_hasTextualNull(text)) {
/*  448 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  449 */       return false;
/*      */     } 
/*  451 */     Boolean b = (Boolean)ctxt.handleWeirdStringValue(boolean.class, text, "only \"true\"/\"True\"/\"TRUE\" or \"false\"/\"False\"/\"FALSE\" recognized", new Object[0]);
/*      */     
/*  453 */     return Boolean.TRUE.equals(b);
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _isTrue(String text) {
/*  458 */     char c = text.charAt(0);
/*  459 */     if (c == 't') {
/*  460 */       return "true".equals(text);
/*      */     }
/*  462 */     if (c == 'T') {
/*  463 */       return ("TRUE".equals(text) || "True".equals(text));
/*      */     }
/*  465 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean _isFalse(String text) {
/*  469 */     char c = text.charAt(0);
/*  470 */     if (c == 'f') {
/*  471 */       return "false".equals(text);
/*      */     }
/*  473 */     if (c == 'F') {
/*  474 */       return ("FALSE".equals(text) || "False".equals(text));
/*      */     }
/*  476 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Boolean _parseBoolean(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  502 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  504 */         text = p.getText();
/*      */         break;
/*      */       
/*      */       case 7:
/*  508 */         return _coerceBooleanFromInt(p, ctxt, targetType);
/*      */       case 9:
/*  510 */         return Boolean.valueOf(true);
/*      */       case 10:
/*  512 */         return Boolean.valueOf(false);
/*      */       case 11:
/*  514 */         return null;
/*      */       
/*      */       case 1:
/*  517 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  520 */         return (Boolean)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  522 */         return (Boolean)ctxt.handleUnexpectedToken(targetType, p);
/*      */     } 
/*      */     
/*  525 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Boolean, targetType);
/*      */     
/*  527 */     if (act == CoercionAction.AsNull) {
/*  528 */       return null;
/*      */     }
/*  530 */     if (act == CoercionAction.AsEmpty) {
/*  531 */       return Boolean.valueOf(false);
/*      */     }
/*  533 */     String text = text.trim();
/*  534 */     int len = text.length();
/*      */ 
/*      */ 
/*      */     
/*  538 */     if (len == 4) {
/*  539 */       if (_isTrue(text)) {
/*  540 */         return Boolean.valueOf(true);
/*      */       }
/*  542 */     } else if (len == 5 && 
/*  543 */       _isFalse(text)) {
/*  544 */       return Boolean.valueOf(false);
/*      */     } 
/*      */     
/*  547 */     if (_checkTextualNull(ctxt, text)) {
/*  548 */       return null;
/*      */     }
/*  550 */     return (Boolean)ctxt.handleWeirdStringValue(targetType, text, "only \"true\" or \"false\" recognized", new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte _parseBytePrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     int value;
/*  558 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  560 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  563 */         act = _checkFloatToIntCoercion(p, ctxt, byte.class);
/*  564 */         if (act == CoercionAction.AsNull) {
/*  565 */           return 0;
/*      */         }
/*  567 */         if (act == CoercionAction.AsEmpty) {
/*  568 */           return 0;
/*      */         }
/*  570 */         return p.getByteValue();
/*      */       case 7:
/*  572 */         return p.getByteValue();
/*      */       case 11:
/*  574 */         _verifyNullForPrimitive(ctxt);
/*  575 */         return 0;
/*      */       
/*      */       case 1:
/*  578 */         text = ctxt.extractScalarFromObject(p, this, byte.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  582 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  583 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  584 */             return ((Byte)handleNestedArrayForSingle(p, ctxt)).byteValue();
/*      */           }
/*  586 */           byte parsed = _parseBytePrimitive(p, ctxt);
/*  587 */           _verifyEndArrayForSingle(p, ctxt);
/*  588 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  592 */         return ((Byte)ctxt.handleUnexpectedToken(ctxt.constructType(byte.class), p)).byteValue();
/*      */     } 
/*      */ 
/*      */     
/*  596 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, byte.class);
/*      */     
/*  598 */     if (act == CoercionAction.AsNull) {
/*      */       
/*  600 */       _verifyNullForPrimitive(ctxt);
/*  601 */       return 0;
/*      */     } 
/*  603 */     if (act == CoercionAction.AsEmpty) {
/*  604 */       return 0;
/*      */     }
/*  606 */     String text = text.trim();
/*  607 */     if (_hasTextualNull(text)) {
/*  608 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  609 */       return 0;
/*      */     } 
/*      */     
/*      */     try {
/*  613 */       value = NumberInput.parseInt(text);
/*  614 */     } catch (IllegalArgumentException iae) {
/*  615 */       return ((Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid `byte` value", new Object[0])).byteValue();
/*      */     } 
/*      */ 
/*      */     
/*  619 */     if (_byteOverflow(value)) {
/*  620 */       return ((Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "overflow, value cannot be represented as 8-bit value", new Object[0])).byteValue();
/*      */     }
/*      */     
/*  623 */     return (byte)value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final short _parseShortPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     int value;
/*  630 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  632 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  635 */         act = _checkFloatToIntCoercion(p, ctxt, short.class);
/*  636 */         if (act == CoercionAction.AsNull) {
/*  637 */           return 0;
/*      */         }
/*  639 */         if (act == CoercionAction.AsEmpty) {
/*  640 */           return 0;
/*      */         }
/*  642 */         return p.getShortValue();
/*      */       case 7:
/*  644 */         return p.getShortValue();
/*      */       case 11:
/*  646 */         _verifyNullForPrimitive(ctxt);
/*  647 */         return 0;
/*      */       
/*      */       case 1:
/*  650 */         text = ctxt.extractScalarFromObject(p, this, short.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  654 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  655 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  656 */             return ((Short)handleNestedArrayForSingle(p, ctxt)).shortValue();
/*      */           }
/*  658 */           short parsed = _parseShortPrimitive(p, ctxt);
/*  659 */           _verifyEndArrayForSingle(p, ctxt);
/*  660 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  664 */         return ((Short)ctxt.handleUnexpectedToken(ctxt.constructType(short.class), p)).shortValue();
/*      */     } 
/*      */     
/*  667 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, short.class);
/*      */     
/*  669 */     if (act == CoercionAction.AsNull) {
/*      */       
/*  671 */       _verifyNullForPrimitive(ctxt);
/*  672 */       return 0;
/*      */     } 
/*  674 */     if (act == CoercionAction.AsEmpty) {
/*  675 */       return 0;
/*      */     }
/*  677 */     String text = text.trim();
/*  678 */     if (_hasTextualNull(text)) {
/*  679 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  680 */       return 0;
/*      */     } 
/*      */     
/*      */     try {
/*  684 */       value = NumberInput.parseInt(text);
/*  685 */     } catch (IllegalArgumentException iae) {
/*  686 */       return ((Short)ctxt.handleWeirdStringValue(short.class, text, "not a valid `short` value", new Object[0])).shortValue();
/*      */     } 
/*      */     
/*  689 */     if (_shortOverflow(value)) {
/*  690 */       return ((Short)ctxt.handleWeirdStringValue(short.class, text, "overflow, value cannot be represented as 16-bit value", new Object[0])).shortValue();
/*      */     }
/*      */     
/*  693 */     return (short)value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parseIntPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  700 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  702 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  705 */         act = _checkFloatToIntCoercion(p, ctxt, int.class);
/*  706 */         if (act == CoercionAction.AsNull) {
/*  707 */           return 0;
/*      */         }
/*  709 */         if (act == CoercionAction.AsEmpty) {
/*  710 */           return 0;
/*      */         }
/*  712 */         return p.getValueAsInt();
/*      */       case 7:
/*  714 */         return p.getIntValue();
/*      */       case 11:
/*  716 */         _verifyNullForPrimitive(ctxt);
/*  717 */         return 0;
/*      */       
/*      */       case 1:
/*  720 */         text = ctxt.extractScalarFromObject(p, this, int.class);
/*      */         break;
/*      */       case 3:
/*  723 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  724 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  725 */             return ((Integer)handleNestedArrayForSingle(p, ctxt)).intValue();
/*      */           }
/*  727 */           int parsed = _parseIntPrimitive(p, ctxt);
/*  728 */           _verifyEndArrayForSingle(p, ctxt);
/*  729 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  733 */         return ((Number)ctxt.handleUnexpectedToken(int.class, p)).intValue();
/*      */     } 
/*      */     
/*  736 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, int.class);
/*      */     
/*  738 */     if (act == CoercionAction.AsNull) {
/*      */       
/*  740 */       _verifyNullForPrimitive(ctxt);
/*  741 */       return 0;
/*      */     } 
/*  743 */     if (act == CoercionAction.AsEmpty) {
/*  744 */       return 0;
/*      */     }
/*  746 */     String text = text.trim();
/*  747 */     if (_hasTextualNull(text)) {
/*  748 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  749 */       return 0;
/*      */     } 
/*  751 */     return _parseIntPrimitive(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parseIntPrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/*  760 */       if (text.length() > 9) {
/*  761 */         long l = NumberInput.parseLong(text);
/*  762 */         if (_intOverflow(l)) {
/*  763 */           Number v = (Number)ctxt.handleWeirdStringValue(int.class, text, "Overflow: numeric value (%s) out of range of int (%d -%d)", new Object[] { text, 
/*      */                 
/*  765 */                 Integer.valueOf(-2147483648), Integer.valueOf(2147483647) });
/*  766 */           return _nonNullNumber(v).intValue();
/*      */         } 
/*  768 */         return (int)l;
/*      */       } 
/*  770 */       return NumberInput.parseInt(text);
/*  771 */     } catch (IllegalArgumentException iae) {
/*  772 */       Number v = (Number)ctxt.handleWeirdStringValue(int.class, text, "not a valid `int` value", new Object[0]);
/*      */       
/*  774 */       return _nonNullNumber(v).intValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Integer _parseInteger(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  786 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  788 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  791 */         act = _checkFloatToIntCoercion(p, ctxt, targetType);
/*  792 */         if (act == CoercionAction.AsNull) {
/*  793 */           return (Integer)getNullValue(ctxt);
/*      */         }
/*  795 */         if (act == CoercionAction.AsEmpty) {
/*  796 */           return (Integer)getEmptyValue(ctxt);
/*      */         }
/*  798 */         return Integer.valueOf(p.getValueAsInt());
/*      */       case 7:
/*  800 */         return Integer.valueOf(p.getIntValue());
/*      */       case 11:
/*  802 */         return (Integer)getNullValue(ctxt);
/*      */       
/*      */       case 1:
/*  805 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  808 */         return (Integer)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  810 */         return (Integer)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  813 */     CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  814 */     if (act == CoercionAction.AsNull) {
/*  815 */       return (Integer)getNullValue(ctxt);
/*      */     }
/*  817 */     if (act == CoercionAction.AsEmpty) {
/*  818 */       return (Integer)getEmptyValue(ctxt);
/*      */     }
/*  820 */     String text = text.trim();
/*  821 */     if (_checkTextualNull(ctxt, text)) {
/*  822 */       return (Integer)getNullValue(ctxt);
/*      */     }
/*  824 */     return _parseInteger(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Integer _parseInteger(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/*  833 */       if (text.length() > 9) {
/*  834 */         long l = NumberInput.parseLong(text);
/*  835 */         if (_intOverflow(l)) {
/*  836 */           return (Integer)ctxt.handleWeirdStringValue(Integer.class, text, "Overflow: numeric value (%s) out of range of `java.lang.Integer` (%d -%d)", new Object[] { text, 
/*      */                 
/*  838 */                 Integer.valueOf(-2147483648), Integer.valueOf(2147483647) });
/*      */         }
/*  840 */         return Integer.valueOf((int)l);
/*      */       } 
/*  842 */       return Integer.valueOf(NumberInput.parseInt(text));
/*  843 */     } catch (IllegalArgumentException iae) {
/*  844 */       return (Integer)ctxt.handleWeirdStringValue(Integer.class, text, "not a valid `java.lang.Integer` value", new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final long _parseLongPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  853 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  855 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  858 */         act = _checkFloatToIntCoercion(p, ctxt, long.class);
/*  859 */         if (act == CoercionAction.AsNull) {
/*  860 */           return 0L;
/*      */         }
/*  862 */         if (act == CoercionAction.AsEmpty) {
/*  863 */           return 0L;
/*      */         }
/*  865 */         return p.getValueAsLong();
/*      */       case 7:
/*  867 */         return p.getLongValue();
/*      */       case 11:
/*  869 */         _verifyNullForPrimitive(ctxt);
/*  870 */         return 0L;
/*      */       
/*      */       case 1:
/*  873 */         text = ctxt.extractScalarFromObject(p, this, long.class);
/*      */         break;
/*      */       case 3:
/*  876 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  877 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  878 */             return ((Long)handleNestedArrayForSingle(p, ctxt)).longValue();
/*      */           }
/*  880 */           long parsed = _parseLongPrimitive(p, ctxt);
/*  881 */           _verifyEndArrayForSingle(p, ctxt);
/*  882 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  886 */         return ((Number)ctxt.handleUnexpectedToken(long.class, p)).longValue();
/*      */     } 
/*      */     
/*  889 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, long.class);
/*      */     
/*  891 */     if (act == CoercionAction.AsNull) {
/*      */       
/*  893 */       _verifyNullForPrimitive(ctxt);
/*  894 */       return 0L;
/*      */     } 
/*  896 */     if (act == CoercionAction.AsEmpty) {
/*  897 */       return 0L;
/*      */     }
/*  899 */     String text = text.trim();
/*  900 */     if (_hasTextualNull(text)) {
/*  901 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  902 */       return 0L;
/*      */     } 
/*  904 */     return _parseLongPrimitive(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final long _parseLongPrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/*  913 */       return NumberInput.parseLong(text);
/*  914 */     } catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  916 */       Number v = (Number)ctxt.handleWeirdStringValue(long.class, text, "not a valid `long` value", new Object[0]);
/*      */       
/*  918 */       return _nonNullNumber(v).longValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Long _parseLong(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  930 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  932 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  935 */         act = _checkFloatToIntCoercion(p, ctxt, targetType);
/*  936 */         if (act == CoercionAction.AsNull) {
/*  937 */           return (Long)getNullValue(ctxt);
/*      */         }
/*  939 */         if (act == CoercionAction.AsEmpty) {
/*  940 */           return (Long)getEmptyValue(ctxt);
/*      */         }
/*  942 */         return Long.valueOf(p.getValueAsLong());
/*      */       case 11:
/*  944 */         return (Long)getNullValue(ctxt);
/*      */       case 7:
/*  946 */         return Long.valueOf(p.getLongValue());
/*      */       
/*      */       case 1:
/*  949 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  952 */         return (Long)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  954 */         return (Long)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  957 */     CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  958 */     if (act == CoercionAction.AsNull) {
/*  959 */       return (Long)getNullValue(ctxt);
/*      */     }
/*  961 */     if (act == CoercionAction.AsEmpty) {
/*  962 */       return (Long)getEmptyValue(ctxt);
/*      */     }
/*  964 */     String text = text.trim();
/*  965 */     if (_checkTextualNull(ctxt, text)) {
/*  966 */       return (Long)getNullValue(ctxt);
/*      */     }
/*      */     
/*  969 */     return _parseLong(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Long _parseLong(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/*  978 */       return Long.valueOf(NumberInput.parseLong(text));
/*  979 */     } catch (IllegalArgumentException illegalArgumentException) {
/*  980 */       return (Long)ctxt.handleWeirdStringValue(Long.class, text, "not a valid `java.lang.Long` value", new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final float _parseFloatPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     CoercionAction coercionAction1;
/*  988 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  990 */         text = p.getText();
/*      */         break;
/*      */       case 7:
/*  993 */         coercionAction1 = _checkIntToFloatCoercion(p, ctxt, float.class);
/*  994 */         if (coercionAction1 == CoercionAction.AsNull) {
/*  995 */           return 0.0F;
/*      */         }
/*  997 */         if (coercionAction1 == CoercionAction.AsEmpty) {
/*  998 */           return 0.0F;
/*      */         }
/*      */       
/*      */       case 8:
/* 1002 */         return p.getFloatValue();
/*      */       case 11:
/* 1004 */         _verifyNullForPrimitive(ctxt);
/* 1005 */         return 0.0F;
/*      */       
/*      */       case 1:
/* 1008 */         text = ctxt.extractScalarFromObject(p, this, float.class);
/*      */         break;
/*      */       case 3:
/* 1011 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 1012 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/* 1013 */             return ((Float)handleNestedArrayForSingle(p, ctxt)).floatValue();
/*      */           }
/* 1015 */           float parsed = _parseFloatPrimitive(p, ctxt);
/* 1016 */           _verifyEndArrayForSingle(p, ctxt);
/* 1017 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/* 1021 */         return ((Number)ctxt.handleUnexpectedToken(float.class, p)).floatValue();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1028 */     Float nan = _checkFloatSpecialValue(text);
/* 1029 */     if (nan != null) {
/* 1030 */       return nan.floatValue();
/*      */     }
/*      */ 
/*      */     
/* 1034 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, float.class);
/*      */     
/* 1036 */     if (act == CoercionAction.AsNull) {
/*      */       
/* 1038 */       _verifyNullForPrimitive(ctxt);
/* 1039 */       return 0.0F;
/*      */     } 
/* 1041 */     if (act == CoercionAction.AsEmpty) {
/* 1042 */       return 0.0F;
/*      */     }
/* 1044 */     String text = text.trim();
/* 1045 */     if (_hasTextualNull(text)) {
/* 1046 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/* 1047 */       return 0.0F;
/*      */     } 
/* 1049 */     return _parseFloatPrimitive(p, ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final float _parseFloatPrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/* 1059 */       return NumberInput.parseFloat(text);
/* 1060 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1061 */       Number v = (Number)ctxt.handleWeirdStringValue(float.class, text, "not a valid `float` value", new Object[0]);
/*      */       
/* 1063 */       return _nonNullNumber(v).floatValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final float _parseFloatPrimitive(JsonParser p, DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/* 1073 */       return NumberInput.parseFloat(text, p.isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER));
/* 1074 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1075 */       Number v = (Number)ctxt.handleWeirdStringValue(float.class, text, "not a valid `float` value", new Object[0]);
/*      */       
/* 1077 */       return _nonNullNumber(v).floatValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Float _checkFloatSpecialValue(String text) {
/* 1094 */     if (!text.isEmpty()) {
/* 1095 */       switch (text.charAt(0)) {
/*      */         case 'I':
/* 1097 */           if (_isPosInf(text)) {
/* 1098 */             return Float.valueOf(Float.POSITIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */         case 'N':
/* 1102 */           if (_isNaN(text)) return Float.valueOf(Float.NaN); 
/*      */           break;
/*      */         case '-':
/* 1105 */           if (_isNegInf(text)) {
/* 1106 */             return Float.valueOf(Float.NEGATIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     
/*      */     }
/* 1112 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final double _parseDoublePrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     CoercionAction coercionAction1;
/* 1119 */     switch (p.currentTokenId()) {
/*      */       case 6:
/* 1121 */         text = p.getText();
/*      */         break;
/*      */       case 7:
/* 1124 */         coercionAction1 = _checkIntToFloatCoercion(p, ctxt, double.class);
/* 1125 */         if (coercionAction1 == CoercionAction.AsNull) {
/* 1126 */           return 0.0D;
/*      */         }
/* 1128 */         if (coercionAction1 == CoercionAction.AsEmpty) {
/* 1129 */           return 0.0D;
/*      */         }
/*      */       
/*      */       case 8:
/* 1133 */         return p.getDoubleValue();
/*      */       case 11:
/* 1135 */         _verifyNullForPrimitive(ctxt);
/* 1136 */         return 0.0D;
/*      */       
/*      */       case 1:
/* 1139 */         text = ctxt.extractScalarFromObject(p, this, double.class);
/*      */         break;
/*      */       case 3:
/* 1142 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 1143 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/* 1144 */             return ((Double)handleNestedArrayForSingle(p, ctxt)).doubleValue();
/*      */           }
/* 1146 */           double parsed = _parseDoublePrimitive(p, ctxt);
/* 1147 */           _verifyEndArrayForSingle(p, ctxt);
/* 1148 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/* 1152 */         return ((Number)ctxt.handleUnexpectedToken(double.class, p)).doubleValue();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1159 */     Double nan = _checkDoubleSpecialValue(text);
/* 1160 */     if (nan != null) {
/* 1161 */       return nan.doubleValue();
/*      */     }
/*      */ 
/*      */     
/* 1165 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, double.class);
/*      */     
/* 1167 */     if (act == CoercionAction.AsNull) {
/*      */       
/* 1169 */       _verifyNullForPrimitive(ctxt);
/* 1170 */       return 0.0D;
/*      */     } 
/* 1172 */     if (act == CoercionAction.AsEmpty) {
/* 1173 */       return 0.0D;
/*      */     }
/* 1175 */     String text = text.trim();
/* 1176 */     if (_hasTextualNull(text)) {
/* 1177 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/* 1178 */       return 0.0D;
/*      */     } 
/* 1180 */     return _parseDoublePrimitive(p, ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final double _parseDoublePrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/* 1190 */       return _parseDouble(text);
/* 1191 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1192 */       Number v = (Number)ctxt.handleWeirdStringValue(double.class, text, "not a valid `double` value (as String to convert)", new Object[0]);
/*      */       
/* 1194 */       return _nonNullNumber(v).doubleValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final double _parseDoublePrimitive(JsonParser p, DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/* 1204 */       return _parseDouble(text, p.isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER));
/* 1205 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1206 */       Number v = (Number)ctxt.handleWeirdStringValue(double.class, text, "not a valid `double` value (as String to convert)", new Object[0]);
/*      */       
/* 1208 */       return _nonNullNumber(v).doubleValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final double _parseDouble(String numStr) throws NumberFormatException {
/* 1220 */     return _parseDouble(numStr, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final double _parseDouble(String numStr, boolean useFastParser) throws NumberFormatException {
/* 1231 */     return NumberInput.parseDouble(numStr, useFastParser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Double _checkDoubleSpecialValue(String text) {
/* 1248 */     if (!text.isEmpty()) {
/* 1249 */       switch (text.charAt(0)) {
/*      */         case 'I':
/* 1251 */           if (_isPosInf(text)) {
/* 1252 */             return Double.valueOf(Double.POSITIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */         case 'N':
/* 1256 */           if (_isNaN(text)) {
/* 1257 */             return Double.valueOf(Double.NaN);
/*      */           }
/*      */           break;
/*      */         case '-':
/* 1261 */           if (_isNegInf(text)) {
/* 1262 */             return Double.valueOf(Double.NEGATIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     
/*      */     }
/* 1268 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Date _parseDate(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     String text;
/*      */     long ts;
/* 1275 */     switch (p.currentTokenId()) {
/*      */       case 6:
/* 1277 */         text = p.getText();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1304 */         return _parseDate(text.trim(), ctxt);case 7: try { ts = p.getLongValue(); } catch (StreamReadException e) { Number v = (Number)ctxt.handleWeirdNumberValue(this._valueClass, p.getNumberValue(), "not a valid 64-bit `long` for creating `java.util.Date`", new Object[0]); ts = v.longValue(); }  return new Date(ts);case 11: return (Date)getNullValue(ctxt);case 1: text = ctxt.extractScalarFromObject(p, this, this._valueClass); return _parseDate(text.trim(), ctxt);
/*      */       case 3:
/*      */         return _parseDateFromArray(p, ctxt);
/*      */     } 
/*      */     return (Date)ctxt.handleUnexpectedToken(this._valueClass, p);
/*      */   }
/*      */   protected Date _parseDateFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1311 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/* 1312 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/* 1314 */     if (unwrap || act != CoercionAction.Fail) {
/* 1315 */       JsonToken t = p.nextToken();
/* 1316 */       if (t == JsonToken.END_ARRAY) {
/* 1317 */         switch (act) {
/*      */           case AsEmpty:
/* 1319 */             return (Date)getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/* 1322 */             return (Date)getNullValue(ctxt);
/*      */         } 
/*      */       
/* 1325 */       } else if (unwrap) {
/* 1326 */         if (t == JsonToken.START_ARRAY) {
/* 1327 */           return (Date)handleNestedArrayForSingle(p, ctxt);
/*      */         }
/* 1329 */         Date parsed = _parseDate(p, ctxt);
/* 1330 */         _verifyEndArrayForSingle(p, ctxt);
/* 1331 */         return parsed;
/*      */       } 
/*      */     } 
/* 1334 */     return (Date)ctxt.handleUnexpectedToken(this._valueClass, JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Date _parseDate(String value, DeserializationContext ctxt) throws IOException {
/*      */     try {
/* 1345 */       if (value.isEmpty()) {
/* 1346 */         CoercionAction act = _checkFromStringCoercion(ctxt, value);
/* 1347 */         switch (act) {
/*      */           case AsEmpty:
/* 1349 */             return new Date(0L);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1354 */         return null;
/*      */       } 
/*      */       
/* 1357 */       if (_hasTextualNull(value)) {
/* 1358 */         return null;
/*      */       }
/* 1360 */       return ctxt.parseDate(value);
/* 1361 */     } catch (IllegalArgumentException iae) {
/* 1362 */       return (Date)ctxt.handleWeirdStringValue(this._valueClass, value, "not a valid representation (error: %s)", new Object[] {
/*      */             
/* 1364 */             ClassUtil.exceptionMessage(iae)
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final String _parseString(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1376 */     return _parseString(p, ctxt, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1381 */         (NullValueProvider)NullsConstantProvider.nuller());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseString(JsonParser p, DeserializationContext ctxt, NullValueProvider nullProvider) throws IOException {
/*      */     Object ob;
/* 1403 */     CoercionAction act = CoercionAction.TryConvert;
/*      */     
/* 1405 */     switch (p.currentTokenId()) {
/*      */       case 6:
/* 1407 */         return p.getText();
/*      */       
/*      */       case 12:
/* 1410 */         ob = p.getEmbeddedObject();
/* 1411 */         if (ob instanceof byte[]) {
/* 1412 */           return ctxt.getBase64Variant().encode((byte[])ob, false);
/*      */         }
/* 1414 */         if (ob == null) {
/* 1415 */           return null;
/*      */         }
/*      */         
/* 1418 */         return ob.toString();
/*      */       
/*      */       case 1:
/* 1421 */         return ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */       case 7:
/* 1423 */         act = _checkIntToStringCoercion(p, ctxt, this._valueClass);
/*      */         break;
/*      */       case 8:
/* 1426 */         act = _checkFloatToStringCoercion(p, ctxt, this._valueClass);
/*      */         break;
/*      */       case 9:
/*      */       case 10:
/* 1430 */         act = _checkBooleanToStringCoercion(p, ctxt, this._valueClass);
/*      */         break;
/*      */     } 
/*      */     
/* 1434 */     if (act == CoercionAction.AsNull) {
/* 1435 */       return (String)nullProvider.getNullValue(ctxt);
/*      */     }
/* 1437 */     if (act == CoercionAction.AsEmpty) {
/* 1438 */       return "";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1444 */     if (p.currentToken().isScalarValue()) {
/* 1445 */       String text = p.getValueAsString();
/* 1446 */       if (text != null) {
/* 1447 */         return text;
/*      */       }
/*      */     } 
/* 1450 */     return (String)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasTextualNull(String value) {
/* 1461 */     return "null".equals(value);
/*      */   }
/*      */   
/*      */   protected final boolean _isNegInf(String text) {
/* 1465 */     return ("-Infinity".equals(text) || "-INF".equals(text));
/*      */   }
/*      */   
/*      */   protected final boolean _isPosInf(String text) {
/* 1469 */     return ("Infinity".equals(text) || "INF".equals(text));
/*      */   }
/*      */   protected final boolean _isNaN(String text) {
/* 1472 */     return "NaN".equals(text);
/*      */   }
/*      */ 
/*      */   
/*      */   protected static final boolean _isBlank(String text) {
/* 1477 */     int len = text.length();
/* 1478 */     for (int i = 0; i < len; i++) {
/* 1479 */       if (text.charAt(i) > ' ') {
/* 1480 */         return false;
/*      */       }
/*      */     } 
/* 1483 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFromStringCoercion(DeserializationContext ctxt, String value) throws IOException {
/* 1498 */     return _checkFromStringCoercion(ctxt, value, logicalType(), handledType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFromStringCoercion(DeserializationContext ctxt, String value, LogicalType logicalType, Class<?> rawTargetType) throws IOException {
/* 1515 */     if (value.isEmpty()) {
/* 1516 */       CoercionAction coercionAction = ctxt.findCoercionAction(logicalType, rawTargetType, CoercionInputShape.EmptyString);
/*      */       
/* 1518 */       return _checkCoercionFail(ctxt, coercionAction, rawTargetType, value, "empty String (\"\")");
/*      */     } 
/* 1520 */     if (_isBlank(value)) {
/* 1521 */       CoercionAction coercionAction = ctxt.findCoercionFromBlankString(logicalType, rawTargetType, CoercionAction.Fail);
/* 1522 */       return _checkCoercionFail(ctxt, coercionAction, rawTargetType, value, "blank String (all whitespace)");
/*      */     } 
/*      */ 
/*      */     
/* 1526 */     if (ctxt.isEnabled(StreamReadCapability.UNTYPED_SCALARS)) {
/* 1527 */       return CoercionAction.TryConvert;
/*      */     }
/* 1529 */     CoercionAction act = ctxt.findCoercionAction(logicalType, rawTargetType, CoercionInputShape.String);
/* 1530 */     if (act == CoercionAction.Fail)
/*      */     {
/* 1532 */       ctxt.reportInputMismatch(this, "Cannot coerce String value (\"%s\") to %s (but might if coercion using `CoercionConfig` was enabled)", new Object[] { value, 
/*      */             
/* 1534 */             _coercedTypeDesc() });
/*      */     }
/*      */     
/* 1537 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFloatToIntCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1547 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Integer, rawTargetType, CoercionInputShape.Float);
/*      */     
/* 1549 */     if (act == CoercionAction.Fail) {
/* 1550 */       return _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Floating-point value (" + p
/* 1551 */           .getText() + ")");
/*      */     }
/* 1553 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkIntToStringCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1563 */     return _checkToStringCoercion(p, ctxt, rawTargetType, p.getNumberValue(), CoercionInputShape.Integer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFloatToStringCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1573 */     return _checkToStringCoercion(p, ctxt, rawTargetType, p.getNumberValue(), CoercionInputShape.Float);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkBooleanToStringCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1583 */     return _checkToStringCoercion(p, ctxt, rawTargetType, Boolean.valueOf(p.getBooleanValue()), CoercionInputShape.Boolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkToStringCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType, Object inputValue, CoercionInputShape inputShape) throws IOException {
/* 1593 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Textual, rawTargetType, inputShape);
/*      */     
/* 1595 */     if (act == CoercionAction.Fail) {
/* 1596 */       return _checkCoercionFail(ctxt, act, rawTargetType, inputValue, inputShape
/* 1597 */           .name() + " value (" + p.getText() + ")");
/*      */     }
/* 1599 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkIntToFloatCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1609 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Float, rawTargetType, CoercionInputShape.Integer);
/*      */     
/* 1611 */     if (act == CoercionAction.Fail) {
/* 1612 */       return _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Integer value (" + p
/* 1613 */           .getText() + ")");
/*      */     }
/* 1615 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Boolean _coerceBooleanFromInt(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1625 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Boolean, rawTargetType, CoercionInputShape.Integer);
/* 1626 */     switch (act) {
/*      */       case Fail:
/* 1628 */         _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Integer value (" + p
/* 1629 */             .getText() + ")");
/* 1630 */         return Boolean.FALSE;
/*      */       case AsNull:
/* 1632 */         return null;
/*      */       case AsEmpty:
/* 1634 */         return Boolean.FALSE;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1640 */     if (p.getNumberType() == JsonParser.NumberType.INT)
/*      */     {
/* 1642 */       return Boolean.valueOf((p.getIntValue() != 0));
/*      */     }
/* 1644 */     return Boolean.valueOf(!"0".equals(p.getText()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkCoercionFail(DeserializationContext ctxt, CoercionAction act, Class<?> targetType, Object inputValue, String inputDesc) throws IOException {
/* 1655 */     if (act == CoercionAction.Fail) {
/* 1656 */       ctxt.reportBadCoercion(this, targetType, inputValue, "Cannot coerce %s to %s (but could if coercion was enabled using `CoercionConfig`)", new Object[] { inputDesc, 
/*      */             
/* 1658 */             _coercedTypeDesc() });
/*      */     }
/* 1660 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _checkTextualNull(DeserializationContext ctxt, String text) throws JsonMappingException {
/* 1673 */     if (_hasTextualNull(text)) {
/* 1674 */       if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1675 */         _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, "String \"null\"");
/*      */       }
/* 1677 */       return true;
/*      */     } 
/* 1679 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _coerceIntegral(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1701 */     if (ctxt.isEnabled(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS)) {
/* 1702 */       return p.getBigIntegerValue();
/*      */     }
/* 1704 */     if (ctxt.isEnabled(DeserializationFeature.USE_LONG_FOR_INTS)) {
/* 1705 */       return Long.valueOf(p.getLongValue());
/*      */     }
/* 1707 */     return p.getNumberValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNullForPrimitive(DeserializationContext ctxt) throws JsonMappingException {
/* 1720 */     if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1721 */       ctxt.reportInputMismatch(this, "Cannot coerce `null` to %s (disable `DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES` to allow)", new Object[] {
/*      */             
/* 1723 */             _coercedTypeDesc()
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNullForPrimitiveCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/*      */     DeserializationFeature deserializationFeature;
/*      */     boolean enable;
/* 1740 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1741 */       MapperFeature mapperFeature = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1742 */       enable = true;
/* 1743 */     } else if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1744 */       deserializationFeature = DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES;
/* 1745 */       enable = false;
/*      */     } else {
/*      */       return;
/*      */     } 
/* 1749 */     String strDesc = str.isEmpty() ? "empty String (\"\")" : String.format("String \"%s\"", new Object[] { str });
/* 1750 */     _reportFailedNullCoerce(ctxt, enable, (Enum<?>)deserializationFeature, strDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportFailedNullCoerce(DeserializationContext ctxt, boolean state, Enum<?> feature, String inputDesc) throws JsonMappingException {
/* 1756 */     String enableDesc = state ? "enable" : "disable";
/* 1757 */     ctxt.reportInputMismatch(this, "Cannot coerce %s to Null value as %s (%s `%s.%s` to allow)", new Object[] { inputDesc, 
/* 1758 */           _coercedTypeDesc(), enableDesc, feature.getDeclaringClass().getSimpleName(), feature.name() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _coercedTypeDesc() {
/*      */     boolean structured;
/*      */     String typeDesc;
/* 1774 */     JavaType t = getValueType();
/* 1775 */     if (t != null && !t.isPrimitive()) {
/* 1776 */       structured = (t.isContainerType() || t.isReferenceType());
/* 1777 */       typeDesc = ClassUtil.getTypeDescription(t);
/*      */     } else {
/* 1779 */       Class<?> cls = handledType();
/*      */       
/* 1781 */       structured = (cls.isArray() || Collection.class.isAssignableFrom(cls) || Map.class.isAssignableFrom(cls));
/* 1782 */       typeDesc = ClassUtil.getClassDescription(cls);
/*      */     } 
/* 1784 */     if (structured) {
/* 1785 */       return "element of " + typeDesc;
/*      */     }
/* 1787 */     return typeDesc + " value";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean _parseBooleanFromInt(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1804 */     _verifyNumberForScalarCoercion(ctxt, p);
/*      */ 
/*      */     
/* 1807 */     return !"0".equals(p.getText());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _verifyStringForScalarCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/* 1816 */     MapperFeature feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1817 */     if (!ctxt.isEnabled(feat)) {
/* 1818 */       ctxt.reportInputMismatch(this, "Cannot coerce String \"%s\" to %s (enable `%s.%s` to allow)", new Object[] { str, 
/* 1819 */             _coercedTypeDesc(), feat.getDeclaringClass().getSimpleName(), feat.name() });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceEmptyString(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/*      */     DeserializationFeature deserializationFeature;
/*      */     boolean enable;
/* 1834 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1835 */       MapperFeature mapperFeature = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1836 */       enable = true;
/* 1837 */     } else if (isPrimitive && ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1838 */       deserializationFeature = DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES;
/* 1839 */       enable = false;
/*      */     } else {
/* 1841 */       return getNullValue(ctxt);
/*      */     } 
/* 1843 */     _reportFailedNullCoerce(ctxt, enable, (Enum<?>)deserializationFeature, "empty String (\"\")");
/* 1844 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _failDoubleToIntCoercion(JsonParser p, DeserializationContext ctxt, String type) throws IOException {
/* 1851 */     ctxt.reportInputMismatch(handledType(), "Cannot coerce a floating-point value ('%s') into %s (enable `DeserializationFeature.ACCEPT_FLOAT_AS_INT` to allow)", new Object[] { p
/*      */           
/* 1853 */           .getValueAsString(), type });
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final void _verifyNullForScalarCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/* 1859 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1860 */       String strDesc = str.isEmpty() ? "empty String (\"\")" : String.format("String \"%s\"", new Object[] { str });
/* 1861 */       _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, strDesc);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _verifyNumberForScalarCoercion(DeserializationContext ctxt, JsonParser p) throws IOException {
/* 1868 */     MapperFeature feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1869 */     if (!ctxt.isEnabled(feat)) {
/*      */ 
/*      */       
/* 1872 */       String valueDesc = p.getText();
/* 1873 */       ctxt.reportInputMismatch(this, "Cannot coerce Number (%s) to %s (enable `%s.%s` to allow)", new Object[] { valueDesc, 
/* 1874 */             _coercedTypeDesc(), feat.getDeclaringClass().getSimpleName(), feat.name() });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceNullToken(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/* 1881 */     if (isPrimitive) {
/* 1882 */       _verifyNullForPrimitive(ctxt);
/*      */     }
/* 1884 */     return getNullValue(ctxt);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceTextualNull(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/* 1889 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1890 */       _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, "String \"null\"");
/*      */     }
/* 1892 */     return getNullValue(ctxt);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected boolean _isEmptyOrTextualNull(String value) {
/* 1897 */     return (value.isEmpty() || "null".equals(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> findDeserializer(DeserializationContext ctxt, JavaType type, BeanProperty property) throws JsonMappingException {
/* 1919 */     return ctxt.findContextualValueDeserializer(type, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _isIntNumber(String text) {
/* 1931 */     int len = text.length();
/* 1932 */     if (len > 0) {
/* 1933 */       int i; char c = text.charAt(0);
/*      */ 
/*      */ 
/*      */       
/* 1937 */       if (c == '-' || c == '+') {
/* 1938 */         if (len == 1) {
/* 1939 */           return false;
/*      */         }
/* 1941 */         i = 1;
/*      */       } else {
/* 1943 */         i = 0;
/*      */       } 
/*      */       
/* 1946 */       for (; i < len; i++) {
/* 1947 */         int ch = text.charAt(i);
/* 1948 */         if (ch > 57 || ch < 48) {
/* 1949 */           return false;
/*      */         }
/*      */       } 
/* 1952 */       return true;
/*      */     } 
/* 1954 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> findConvertingContentDeserializer(DeserializationContext ctxt, BeanProperty prop, JsonDeserializer<?> existingDeserializer) throws JsonMappingException {
/* 1977 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 1978 */     if (_neitherNull(intr, prop)) {
/* 1979 */       AnnotatedMember member = prop.getMember();
/* 1980 */       if (member != null) {
/* 1981 */         Object convDef = intr.findDeserializationContentConverter(member);
/* 1982 */         if (convDef != null) {
/* 1983 */           Converter<Object, Object> conv = ctxt.converterInstance((Annotated)prop.getMember(), convDef);
/* 1984 */           JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/* 1985 */           if (existingDeserializer == null) {
/* 1986 */             existingDeserializer = ctxt.findContextualValueDeserializer(delegateType, prop);
/*      */           }
/* 1988 */           return new StdDelegatingDeserializer(conv, delegateType, existingDeserializer);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1992 */     return existingDeserializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonFormat.Value findFormatOverrides(DeserializationContext ctxt, BeanProperty prop, Class<?> typeForDefaults) {
/* 2013 */     if (prop != null) {
/* 2014 */       return prop.findPropertyFormat((MapperConfig)ctxt.getConfig(), typeForDefaults);
/*      */     }
/*      */     
/* 2017 */     return ctxt.getDefaultPropertyFormat(typeForDefaults);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Boolean findFormatFeature(DeserializationContext ctxt, BeanProperty prop, Class<?> typeForDefaults, JsonFormat.Feature feat) {
/* 2033 */     JsonFormat.Value format = findFormatOverrides(ctxt, prop, typeForDefaults);
/* 2034 */     if (format != null) {
/* 2035 */       return format.getFeature(feat);
/*      */     }
/* 2037 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final NullValueProvider findValueNullProvider(DeserializationContext ctxt, SettableBeanProperty prop, PropertyMetadata propMetadata) throws JsonMappingException {
/* 2051 */     if (prop != null) {
/* 2052 */       return _findNullProvider(ctxt, (BeanProperty)prop, propMetadata.getValueNulls(), prop
/* 2053 */           .getValueDeserializer());
/*      */     }
/* 2055 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NullValueProvider findContentNullProvider(DeserializationContext ctxt, BeanProperty prop, JsonDeserializer<?> valueDeser) throws JsonMappingException {
/* 2070 */     Nulls nulls = findContentNullStyle(ctxt, prop);
/* 2071 */     if (nulls == Nulls.SKIP) {
/* 2072 */       return (NullValueProvider)NullsConstantProvider.skipper();
/*      */     }
/*      */ 
/*      */     
/* 2076 */     if (nulls == Nulls.FAIL) {
/* 2077 */       if (prop == null) {
/* 2078 */         JavaType type = ctxt.constructType(valueDeser.handledType());
/*      */         
/* 2080 */         if (type.isContainerType()) {
/* 2081 */           type = type.getContentType();
/*      */         }
/* 2083 */         return (NullValueProvider)NullsFailProvider.constructForRootValue(type);
/*      */       } 
/* 2085 */       return (NullValueProvider)NullsFailProvider.constructForProperty(prop, prop.getType().getContentType());
/*      */     } 
/*      */     
/* 2088 */     NullValueProvider prov = _findNullProvider(ctxt, prop, nulls, valueDeser);
/* 2089 */     if (prov != null) {
/* 2090 */       return prov;
/*      */     }
/* 2092 */     return (NullValueProvider)valueDeser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Nulls findContentNullStyle(DeserializationContext ctxt, BeanProperty prop) throws JsonMappingException {
/* 2098 */     if (prop != null) {
/* 2099 */       return prop.getMetadata().getContentNulls();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2104 */     return ctxt.getConfig().getDefaultSetterInfo().getContentNulls();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final NullValueProvider _findNullProvider(DeserializationContext ctxt, BeanProperty prop, Nulls nulls, JsonDeserializer<?> valueDeser) throws JsonMappingException {
/* 2112 */     if (nulls == Nulls.FAIL) {
/* 2113 */       if (prop == null) {
/* 2114 */         Class<?> rawType = (valueDeser == null) ? Object.class : valueDeser.handledType();
/* 2115 */         return (NullValueProvider)NullsFailProvider.constructForRootValue(ctxt.constructType(rawType));
/*      */       } 
/* 2117 */       return (NullValueProvider)NullsFailProvider.constructForProperty(prop);
/*      */     } 
/* 2119 */     if (nulls == Nulls.AS_EMPTY) {
/*      */ 
/*      */       
/* 2122 */       if (valueDeser == null) {
/* 2123 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2129 */       if (valueDeser instanceof BeanDeserializerBase) {
/* 2130 */         BeanDeserializerBase bd = (BeanDeserializerBase)valueDeser;
/* 2131 */         ValueInstantiator vi = bd.getValueInstantiator();
/* 2132 */         if (!vi.canCreateUsingDefault()) {
/* 2133 */           JavaType type = (prop == null) ? bd.getValueType() : prop.getType();
/* 2134 */           return (NullValueProvider)ctxt.reportBadDefinition(type, 
/* 2135 */               String.format("Cannot create empty instance of %s, no default Creator", new Object[] { type }));
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 2140 */       AccessPattern access = valueDeser.getEmptyAccessPattern();
/* 2141 */       if (access == AccessPattern.ALWAYS_NULL) {
/* 2142 */         return (NullValueProvider)NullsConstantProvider.nuller();
/*      */       }
/* 2144 */       if (access == AccessPattern.CONSTANT) {
/* 2145 */         return (NullValueProvider)NullsConstantProvider.forValue(valueDeser.getEmptyValue(ctxt));
/*      */       }
/*      */       
/* 2148 */       return (NullValueProvider)new NullsAsEmptyProvider(valueDeser);
/*      */     } 
/* 2150 */     if (nulls == Nulls.SKIP) {
/* 2151 */       return (NullValueProvider)NullsConstantProvider.skipper();
/*      */     }
/* 2153 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromEmptyString(DeserializationContext ctxt) {
/* 2158 */     return ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromEmptyArray(DeserializationContext ctxt) {
/* 2164 */     return ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyArray);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromBlankString(DeserializationContext ctxt) {
/* 2170 */     return ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleUnknownProperty(JsonParser p, DeserializationContext ctxt, Object<?> instanceOrClass, String propName) throws IOException {
/* 2198 */     if (instanceOrClass == null) {
/* 2199 */       instanceOrClass = (Object<?>)handledType();
/*      */     }
/*      */     
/* 2202 */     if (ctxt.handleUnknownProperty(p, this, instanceOrClass, propName)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2208 */     p.skipChildren();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleMissingEndArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 2214 */     ctxt.reportWrongTokenException(this, JsonToken.END_ARRAY, "Attempted to unwrap '%s' value from an array (with `DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS`) but it contains more than one value", new Object[] {
/*      */           
/* 2216 */           handledType().getName()
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object handleNestedArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 2229 */     String msg = String.format("Cannot deserialize instance of %s out of %s token: nested Arrays not allowed with %s", new Object[] {
/*      */           
/* 2231 */           ClassUtil.nameOf(this._valueClass), JsonToken.START_ARRAY, "DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS"
/*      */         });
/* 2233 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p.currentToken(), p, msg, new Object[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _verifyEndArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 2238 */     JsonToken t = p.nextToken();
/* 2239 */     if (t != JsonToken.END_ARRAY) {
/* 2240 */       handleMissingEndArrayForSingle(p, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final boolean _neitherNull(Object a, Object b) {
/* 2254 */     return (a != null && b != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _byteOverflow(int value) {
/* 2263 */     return (value < -128 || value > 255);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _shortOverflow(int value) {
/* 2270 */     return (value < -32768 || value > 32767);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _intOverflow(long value) {
/* 2277 */     return (value < -2147483648L || value > 2147483647L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Number _nonNullNumber(Number n) {
/* 2284 */     if (n == null) {
/* 2285 */       n = Integer.valueOf(0);
/*      */     }
/* 2287 */     return n;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\StdDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */