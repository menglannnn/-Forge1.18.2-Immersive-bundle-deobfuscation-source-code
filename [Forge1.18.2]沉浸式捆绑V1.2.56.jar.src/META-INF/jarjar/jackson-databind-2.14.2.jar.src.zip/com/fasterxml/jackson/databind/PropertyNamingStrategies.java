/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyNamingStrategies
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  36 */   public static final PropertyNamingStrategy LOWER_CAMEL_CASE = LowerCamelCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final PropertyNamingStrategy UPPER_CAMEL_CASE = UpperCamelCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final PropertyNamingStrategy SNAKE_CASE = SnakeCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final PropertyNamingStrategy UPPER_SNAKE_CASE = UpperSnakeCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final PropertyNamingStrategy LOWER_CASE = LowerCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public static final PropertyNamingStrategy KEBAB_CASE = KebabCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static final PropertyNamingStrategy LOWER_DOT_CASE = LowerDotCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class NamingBase
/*     */     extends PropertyNamingStrategy
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String nameForField(MapperConfig<?> config, AnnotatedField field, String defaultName) {
/* 107 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */     
/*     */     public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
/* 112 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */     
/*     */     public String nameForSetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
/* 117 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String nameForConstructorParameter(MapperConfig<?> config, AnnotatedParameter ctorParam, String defaultName) {
/* 123 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract String translate(String param1String);
/*     */ 
/*     */ 
/*     */     
/*     */     protected String translateLowerCaseWithSeparator(String input, char separator) {
/* 133 */       if (input == null) {
/* 134 */         return input;
/*     */       }
/* 136 */       int length = input.length();
/* 137 */       if (length == 0) {
/* 138 */         return input;
/*     */       }
/*     */       
/* 141 */       StringBuilder result = new StringBuilder(length + (length >> 1));
/* 142 */       int upperCount = 0;
/* 143 */       for (int i = 0; i < length; i++) {
/* 144 */         char ch = input.charAt(i);
/* 145 */         char lc = Character.toLowerCase(ch);
/*     */         
/* 147 */         if (lc == ch) {
/*     */ 
/*     */           
/* 150 */           if (upperCount > 1)
/*     */           {
/* 152 */             result.insert(result.length() - 1, separator);
/*     */           }
/* 154 */           upperCount = 0;
/*     */         } else {
/*     */           
/* 157 */           if (upperCount == 0 && i > 0) {
/* 158 */             result.append(separator);
/*     */           }
/* 160 */           upperCount++;
/*     */         } 
/* 162 */         result.append(lc);
/*     */       } 
/* 164 */       return result.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SnakeCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     public static final SnakeCaseStrategy INSTANCE = new SnakeCaseStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 236 */       if (input == null) return input; 
/* 237 */       int length = input.length();
/* 238 */       StringBuilder result = new StringBuilder(length * 2);
/* 239 */       int resultLength = 0;
/* 240 */       boolean wasPrevTranslated = false;
/* 241 */       for (int i = 0; i < length; i++) {
/*     */         
/* 243 */         char c = input.charAt(i);
/* 244 */         if (i > 0 || c != '_') {
/*     */           
/* 246 */           if (Character.isUpperCase(c)) {
/*     */             
/* 248 */             if (!wasPrevTranslated && resultLength > 0 && result.charAt(resultLength - 1) != '_') {
/*     */               
/* 250 */               result.append('_');
/* 251 */               resultLength++;
/*     */             } 
/* 253 */             c = Character.toLowerCase(c);
/* 254 */             wasPrevTranslated = true;
/*     */           }
/*     */           else {
/*     */             
/* 258 */             wasPrevTranslated = false;
/*     */           } 
/* 260 */           result.append(c);
/* 261 */           resultLength++;
/*     */         } 
/*     */       } 
/* 264 */       return (resultLength > 0) ? result.toString() : input;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class UpperSnakeCaseStrategy
/*     */     extends SnakeCaseStrategy
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     public static final UpperSnakeCaseStrategy INSTANCE = new UpperSnakeCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 287 */       String output = super.translate(input);
/* 288 */       if (output == null)
/* 289 */         return null; 
/* 290 */       return super.translate(input).toUpperCase();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerCamelCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */     
/* 305 */     public static final LowerCamelCaseStrategy INSTANCE = new LowerCamelCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 310 */       return input;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class UpperCamelCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 334 */     public static final UpperCamelCaseStrategy INSTANCE = new UpperCamelCaseStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 348 */       if (input == null || input.isEmpty()) {
/* 349 */         return input;
/*     */       }
/*     */       
/* 352 */       char c = input.charAt(0);
/* 353 */       char uc = Character.toUpperCase(c);
/* 354 */       if (c == uc) {
/* 355 */         return input;
/*     */       }
/* 357 */       StringBuilder sb = new StringBuilder(input);
/* 358 */       sb.setCharAt(0, uc);
/* 359 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     public static final LowerCaseStrategy INSTANCE = new LowerCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 381 */       return input.toLowerCase();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class KebabCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 398 */     public static final KebabCaseStrategy INSTANCE = new KebabCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 403 */       return translateLowerCaseWithSeparator(input, '-');
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerDotCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 419 */     public static final LowerDotCaseStrategy INSTANCE = new LowerDotCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 424 */       return translateLowerCaseWithSeparator(input, '.');
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\PropertyNamingStrategies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */