/*      */ package com.fasterxml.jackson.databind.type;
/*      */ 
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.LRUMap;
/*      */ import com.fasterxml.jackson.databind.util.LookupCache;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.GenericArrayType;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.lang.reflect.WildcardType;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TypeFactory
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   68 */   private static final JavaType[] NO_TYPES = new JavaType[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   75 */   protected static final TypeFactory instance = new TypeFactory();
/*      */   
/*   77 */   protected static final TypeBindings EMPTY_BINDINGS = TypeBindings.emptyBindings();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   89 */   private static final Class<?> CLS_STRING = String.class;
/*   90 */   private static final Class<?> CLS_OBJECT = Object.class;
/*      */   
/*   92 */   private static final Class<?> CLS_COMPARABLE = Comparable.class;
/*   93 */   private static final Class<?> CLS_ENUM = Enum.class;
/*   94 */   private static final Class<?> CLS_JSON_NODE = JsonNode.class;
/*      */   
/*   96 */   private static final Class<?> CLS_BOOL = boolean.class;
/*   97 */   private static final Class<?> CLS_INT = int.class;
/*   98 */   private static final Class<?> CLS_LONG = long.class;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  107 */   protected static final SimpleType CORE_TYPE_BOOL = new SimpleType(CLS_BOOL);
/*  108 */   protected static final SimpleType CORE_TYPE_INT = new SimpleType(CLS_INT);
/*  109 */   protected static final SimpleType CORE_TYPE_LONG = new SimpleType(CLS_LONG);
/*      */ 
/*      */   
/*  112 */   protected static final SimpleType CORE_TYPE_STRING = new SimpleType(CLS_STRING);
/*      */ 
/*      */   
/*  115 */   protected static final SimpleType CORE_TYPE_OBJECT = new SimpleType(CLS_OBJECT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   protected static final SimpleType CORE_TYPE_COMPARABLE = new SimpleType(CLS_COMPARABLE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  131 */   protected static final SimpleType CORE_TYPE_ENUM = new SimpleType(CLS_ENUM);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   protected static final SimpleType CORE_TYPE_JSON_NODE = new SimpleType(CLS_JSON_NODE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final LookupCache<Object, JavaType> _typeCache;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final TypeModifier[] _modifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final TypeParser _parser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ClassLoader _classLoader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeFactory() {
/*  174 */     this((LookupCache<Object, JavaType>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected TypeFactory(LRUMap<Object, JavaType> typeCache) {
/*  183 */     this((LookupCache<Object, JavaType>)typeCache);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeFactory(LookupCache<Object, JavaType> typeCache) {
/*      */     LRUMap lRUMap;
/*  190 */     if (typeCache == null) {
/*  191 */       lRUMap = new LRUMap(16, 200);
/*      */     }
/*  193 */     this._typeCache = (LookupCache<Object, JavaType>)lRUMap;
/*  194 */     this._parser = new TypeParser(this);
/*  195 */     this._modifiers = null;
/*  196 */     this._classLoader = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected TypeFactory(LRUMap<Object, JavaType> typeCache, TypeParser p, TypeModifier[] mods, ClassLoader classLoader) {
/*  206 */     this((LookupCache<Object, JavaType>)typeCache, p, mods, classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeFactory(LookupCache<Object, JavaType> typeCache, TypeParser p, TypeModifier[] mods, ClassLoader classLoader) {
/*      */     LRUMap lRUMap;
/*  215 */     if (typeCache == null) {
/*  216 */       lRUMap = new LRUMap(16, 200);
/*      */     }
/*  218 */     this._typeCache = (LookupCache<Object, JavaType>)lRUMap;
/*      */     
/*  220 */     this._parser = p.withFactory(this);
/*  221 */     this._modifiers = mods;
/*  222 */     this._classLoader = classLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeFactory withModifier(TypeModifier mod) {
/*      */     TypeModifier[] mods;
/*  232 */     LookupCache<Object, JavaType> typeCache = this._typeCache;
/*      */     
/*  234 */     if (mod == null) {
/*  235 */       mods = null;
/*      */ 
/*      */       
/*  238 */       typeCache = null;
/*  239 */     } else if (this._modifiers == null) {
/*  240 */       mods = new TypeModifier[] { mod };
/*      */ 
/*      */       
/*  243 */       typeCache = null;
/*      */     } else {
/*      */       
/*  246 */       mods = (TypeModifier[])ArrayBuilders.insertInListNoDup((Object[])this._modifiers, mod);
/*      */     } 
/*  248 */     return new TypeFactory(typeCache, this._parser, mods, this._classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeFactory withClassLoader(ClassLoader classLoader) {
/*  256 */     return new TypeFactory(this._typeCache, this._parser, this._modifiers, classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public TypeFactory withCache(LRUMap<Object, JavaType> cache) {
/*  269 */     return new TypeFactory(cache, this._parser, this._modifiers, this._classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeFactory withCache(LookupCache<Object, JavaType> cache) {
/*  280 */     return new TypeFactory(cache, this._parser, this._modifiers, this._classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeFactory defaultInstance() {
/*  288 */     return instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearCache() {
/*  301 */     this._typeCache.clear();
/*      */   }
/*      */   
/*      */   public ClassLoader getClassLoader() {
/*  305 */     return this._classLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JavaType unknownType() {
/*  320 */     return defaultInstance()._unknownType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> rawClass(Type t) {
/*  330 */     if (t instanceof Class) {
/*  331 */       return (Class)t;
/*      */     }
/*      */     
/*  334 */     return defaultInstance().constructType(t).getRawClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findClass(String className) throws ClassNotFoundException {
/*  351 */     if (className.indexOf('.') < 0) {
/*  352 */       Class<?> prim = _findPrimitive(className);
/*  353 */       if (prim != null) {
/*  354 */         return prim;
/*      */       }
/*      */     } 
/*      */     
/*  358 */     Throwable prob = null;
/*  359 */     ClassLoader loader = getClassLoader();
/*  360 */     if (loader == null) {
/*  361 */       loader = Thread.currentThread().getContextClassLoader();
/*      */     }
/*  363 */     if (loader != null) {
/*      */       try {
/*  365 */         return classForName(className, true, loader);
/*  366 */       } catch (Exception e) {
/*  367 */         prob = ClassUtil.getRootCause(e);
/*      */       } 
/*      */     }
/*      */     try {
/*  371 */       return classForName(className);
/*  372 */     } catch (Exception e) {
/*  373 */       if (prob == null) {
/*  374 */         prob = ClassUtil.getRootCause(e);
/*      */       }
/*      */       
/*  377 */       ClassUtil.throwIfRTE(prob);
/*  378 */       throw new ClassNotFoundException(prob.getMessage(), prob);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected Class<?> classForName(String name, boolean initialize, ClassLoader loader) throws ClassNotFoundException {
/*  383 */     return Class.forName(name, true, loader);
/*      */   }
/*      */   
/*      */   protected Class<?> classForName(String name) throws ClassNotFoundException {
/*  387 */     return Class.forName(name);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Class<?> _findPrimitive(String className) {
/*  392 */     if ("int".equals(className)) return int.class; 
/*  393 */     if ("long".equals(className)) return long.class; 
/*  394 */     if ("float".equals(className)) return float.class; 
/*  395 */     if ("double".equals(className)) return double.class; 
/*  396 */     if ("boolean".equals(className)) return boolean.class; 
/*  397 */     if ("byte".equals(className)) return byte.class; 
/*  398 */     if ("char".equals(className)) return char.class; 
/*  399 */     if ("short".equals(className)) return short.class; 
/*  400 */     if ("void".equals(className)) return void.class; 
/*  401 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass) throws IllegalArgumentException {
/*  426 */     return constructSpecializedType(baseType, subclass, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass, boolean relaxedCompatibilityCheck) throws IllegalArgumentException {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: invokevirtual getRawClass : ()Ljava/lang/Class;
/*      */     //   4: astore #4
/*      */     //   6: aload #4
/*      */     //   8: aload_2
/*      */     //   9: if_acmpne -> 14
/*      */     //   12: aload_1
/*      */     //   13: areturn
/*      */     //   14: aload #4
/*      */     //   16: ldc java/lang/Object
/*      */     //   18: if_acmpne -> 35
/*      */     //   21: aload_0
/*      */     //   22: aconst_null
/*      */     //   23: aload_2
/*      */     //   24: getstatic com/fasterxml/jackson/databind/type/TypeFactory.EMPTY_BINDINGS : Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   27: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   30: astore #5
/*      */     //   32: goto -> 266
/*      */     //   35: aload #4
/*      */     //   37: aload_2
/*      */     //   38: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*      */     //   41: ifne -> 75
/*      */     //   44: new java/lang/IllegalArgumentException
/*      */     //   47: dup
/*      */     //   48: ldc 'Class %s not subtype of %s'
/*      */     //   50: iconst_2
/*      */     //   51: anewarray java/lang/Object
/*      */     //   54: dup
/*      */     //   55: iconst_0
/*      */     //   56: aload_2
/*      */     //   57: invokestatic nameOf : (Ljava/lang/Class;)Ljava/lang/String;
/*      */     //   60: aastore
/*      */     //   61: dup
/*      */     //   62: iconst_1
/*      */     //   63: aload_1
/*      */     //   64: invokestatic getTypeDescription : (Lcom/fasterxml/jackson/databind/JavaType;)Ljava/lang/String;
/*      */     //   67: aastore
/*      */     //   68: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   71: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   74: athrow
/*      */     //   75: aload_1
/*      */     //   76: invokevirtual isContainerType : ()Z
/*      */     //   79: ifeq -> 195
/*      */     //   82: aload_1
/*      */     //   83: invokevirtual isMapLikeType : ()Z
/*      */     //   86: ifeq -> 136
/*      */     //   89: aload_2
/*      */     //   90: ldc java/util/HashMap
/*      */     //   92: if_acmpeq -> 113
/*      */     //   95: aload_2
/*      */     //   96: ldc java/util/LinkedHashMap
/*      */     //   98: if_acmpeq -> 113
/*      */     //   101: aload_2
/*      */     //   102: ldc java/util/EnumMap
/*      */     //   104: if_acmpeq -> 113
/*      */     //   107: aload_2
/*      */     //   108: ldc java/util/TreeMap
/*      */     //   110: if_acmpne -> 195
/*      */     //   113: aload_0
/*      */     //   114: aconst_null
/*      */     //   115: aload_2
/*      */     //   116: aload_2
/*      */     //   117: aload_1
/*      */     //   118: invokevirtual getKeyType : ()Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   121: aload_1
/*      */     //   122: invokevirtual getContentType : ()Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   125: invokestatic create : (Ljava/lang/Class;Lcom/fasterxml/jackson/databind/JavaType;Lcom/fasterxml/jackson/databind/JavaType;)Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   128: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   131: astore #5
/*      */     //   133: goto -> 266
/*      */     //   136: aload_1
/*      */     //   137: invokevirtual isCollectionLikeType : ()Z
/*      */     //   140: ifeq -> 195
/*      */     //   143: aload_2
/*      */     //   144: ldc java/util/ArrayList
/*      */     //   146: if_acmpeq -> 167
/*      */     //   149: aload_2
/*      */     //   150: ldc java/util/LinkedList
/*      */     //   152: if_acmpeq -> 167
/*      */     //   155: aload_2
/*      */     //   156: ldc java/util/HashSet
/*      */     //   158: if_acmpeq -> 167
/*      */     //   161: aload_2
/*      */     //   162: ldc java/util/TreeSet
/*      */     //   164: if_acmpne -> 186
/*      */     //   167: aload_0
/*      */     //   168: aconst_null
/*      */     //   169: aload_2
/*      */     //   170: aload_2
/*      */     //   171: aload_1
/*      */     //   172: invokevirtual getContentType : ()Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   175: invokestatic create : (Ljava/lang/Class;Lcom/fasterxml/jackson/databind/JavaType;)Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   178: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   181: astore #5
/*      */     //   183: goto -> 266
/*      */     //   186: aload #4
/*      */     //   188: ldc java/util/EnumSet
/*      */     //   190: if_acmpne -> 195
/*      */     //   193: aload_1
/*      */     //   194: areturn
/*      */     //   195: aload_1
/*      */     //   196: invokevirtual getBindings : ()Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   199: invokevirtual isEmpty : ()Z
/*      */     //   202: ifeq -> 219
/*      */     //   205: aload_0
/*      */     //   206: aconst_null
/*      */     //   207: aload_2
/*      */     //   208: getstatic com/fasterxml/jackson/databind/type/TypeFactory.EMPTY_BINDINGS : Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   211: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   214: astore #5
/*      */     //   216: goto -> 266
/*      */     //   219: aload_2
/*      */     //   220: invokevirtual getTypeParameters : ()[Ljava/lang/reflect/TypeVariable;
/*      */     //   223: arraylength
/*      */     //   224: istore #6
/*      */     //   226: iload #6
/*      */     //   228: ifne -> 245
/*      */     //   231: aload_0
/*      */     //   232: aconst_null
/*      */     //   233: aload_2
/*      */     //   234: getstatic com/fasterxml/jackson/databind/type/TypeFactory.EMPTY_BINDINGS : Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   237: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   240: astore #5
/*      */     //   242: goto -> 266
/*      */     //   245: aload_0
/*      */     //   246: aload_1
/*      */     //   247: iload #6
/*      */     //   249: aload_2
/*      */     //   250: iload_3
/*      */     //   251: invokespecial _bindingsForSubtype : (Lcom/fasterxml/jackson/databind/JavaType;ILjava/lang/Class;Z)Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   254: astore #7
/*      */     //   256: aload_0
/*      */     //   257: aconst_null
/*      */     //   258: aload_2
/*      */     //   259: aload #7
/*      */     //   261: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   264: astore #5
/*      */     //   266: aload #5
/*      */     //   268: aload_1
/*      */     //   269: invokevirtual withHandlersFrom : (Lcom/fasterxml/jackson/databind/JavaType;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   272: astore #5
/*      */     //   274: aload #5
/*      */     //   276: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #451	-> 0
/*      */     //   #452	-> 6
/*      */     //   #453	-> 12
/*      */     //   #459	-> 14
/*      */     //   #460	-> 21
/*      */     //   #461	-> 32
/*      */     //   #463	-> 35
/*      */     //   #464	-> 44
/*      */     //   #465	-> 57
/*      */     //   #464	-> 68
/*      */     //   #471	-> 75
/*      */     //   #472	-> 82
/*      */     //   #473	-> 89
/*      */     //   #477	-> 113
/*      */     //   #478	-> 118
/*      */     //   #477	-> 128
/*      */     //   #479	-> 133
/*      */     //   #481	-> 136
/*      */     //   #482	-> 143
/*      */     //   #486	-> 167
/*      */     //   #487	-> 172
/*      */     //   #486	-> 178
/*      */     //   #488	-> 183
/*      */     //   #492	-> 186
/*      */     //   #493	-> 193
/*      */     //   #498	-> 195
/*      */     //   #499	-> 205
/*      */     //   #500	-> 216
/*      */     //   #504	-> 219
/*      */     //   #505	-> 226
/*      */     //   #506	-> 231
/*      */     //   #507	-> 242
/*      */     //   #510	-> 245
/*      */     //   #512	-> 256
/*      */     //   #518	-> 266
/*      */     //   #519	-> 274
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   32	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   133	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   183	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   216	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   242	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   226	40	6	typeParamCount	I
/*      */     //   256	10	7	tb	Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   0	277	0	this	Lcom/fasterxml/jackson/databind/type/TypeFactory;
/*      */     //   0	277	1	baseType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   0	277	2	subclass	Ljava/lang/Class;
/*      */     //   0	277	3	relaxedCompatibilityCheck	Z
/*      */     //   6	271	4	rawBase	Ljava/lang/Class;
/*      */     //   266	11	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	277	2	subclass	Ljava/lang/Class<*>;
/*      */     //   6	271	4	rawBase	Ljava/lang/Class<*>;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeBindings _bindingsForSubtype(JavaType baseType, int typeParamCount, Class<?> subclass, boolean relaxedCompatibilityCheck) {
/*  525 */     PlaceholderForType[] placeholders = new PlaceholderForType[typeParamCount];
/*  526 */     for (int i = 0; i < typeParamCount; i++) {
/*  527 */       placeholders[i] = new PlaceholderForType(i);
/*      */     }
/*  529 */     TypeBindings b = TypeBindings.create(subclass, (JavaType[])placeholders);
/*      */     
/*  531 */     JavaType tmpSub = _fromClass(null, subclass, b);
/*      */     
/*  533 */     JavaType baseWithPlaceholders = tmpSub.findSuperType(baseType.getRawClass());
/*  534 */     if (baseWithPlaceholders == null) {
/*  535 */       throw new IllegalArgumentException(String.format("Internal error: unable to locate supertype (%s) from resolved subtype %s", new Object[] { baseType
/*  536 */               .getRawClass().getName(), subclass
/*  537 */               .getName() }));
/*      */     }
/*      */     
/*  540 */     String error = _resolveTypePlaceholders(baseType, baseWithPlaceholders);
/*  541 */     if (error != null)
/*      */     {
/*      */       
/*  544 */       if (!relaxedCompatibilityCheck) {
/*  545 */         throw new IllegalArgumentException("Failed to specialize base type " + baseType.toCanonical() + " as " + subclass
/*  546 */             .getName() + ", problem: " + error);
/*      */       }
/*      */     }
/*      */     
/*  550 */     JavaType[] typeParams = new JavaType[typeParamCount];
/*  551 */     for (int j = 0; j < typeParamCount; j++) {
/*  552 */       JavaType t = placeholders[j].actualType();
/*      */ 
/*      */ 
/*      */       
/*  556 */       if (t == null) {
/*  557 */         t = unknownType();
/*      */       }
/*  559 */       typeParams[j] = t;
/*      */     } 
/*  561 */     return TypeBindings.create(subclass, typeParams);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String _resolveTypePlaceholders(JavaType sourceType, JavaType actualType) throws IllegalArgumentException {
/*  567 */     List<JavaType> expectedTypes = sourceType.getBindings().getTypeParameters();
/*  568 */     List<JavaType> actualTypes = actualType.getBindings().getTypeParameters();
/*      */     
/*  570 */     int actCount = actualTypes.size();
/*      */     
/*  572 */     for (int i = 0, expCount = expectedTypes.size(); i < expCount; i++) {
/*  573 */       JavaType exp = expectedTypes.get(i);
/*  574 */       JavaType act = (i < actCount) ? actualTypes.get(i) : unknownType();
/*      */       
/*  576 */       if (!_verifyAndResolvePlaceholders(exp, act))
/*      */       {
/*      */ 
/*      */         
/*  580 */         if (!exp.hasRawClass(Object.class))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  589 */           if (i != 0 || 
/*  590 */             !sourceType.isMapLikeType() || 
/*  591 */             !act.hasRawClass(Object.class))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  597 */             if (!exp.isInterface() || 
/*  598 */               !exp.isTypeOrSuperTypeOf(act.getRawClass()))
/*      */             {
/*      */ 
/*      */               
/*  602 */               return String.format("Type parameter #%d/%d differs; can not specialize %s with %s", new Object[] {
/*  603 */                     Integer.valueOf(i + 1), Integer.valueOf(expCount), exp.toCanonical(), act.toCanonical()
/*      */                   }); }  }  }  } 
/*      */     } 
/*  606 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _verifyAndResolvePlaceholders(JavaType exp, JavaType act) {
/*  612 */     if (act instanceof PlaceholderForType) {
/*  613 */       ((PlaceholderForType)act).actualType(exp);
/*  614 */       return true;
/*      */     } 
/*      */ 
/*      */     
/*  618 */     if (exp.getRawClass() != act.getRawClass()) {
/*  619 */       return false;
/*      */     }
/*      */     
/*  622 */     List<JavaType> expectedTypes = exp.getBindings().getTypeParameters();
/*  623 */     List<JavaType> actualTypes = act.getBindings().getTypeParameters();
/*  624 */     for (int i = 0, len = expectedTypes.size(); i < len; i++) {
/*  625 */       JavaType exp2 = expectedTypes.get(i);
/*  626 */       JavaType act2 = actualTypes.get(i);
/*  627 */       if (!_verifyAndResolvePlaceholders(exp2, act2)) {
/*  628 */         return false;
/*      */       }
/*      */     } 
/*  631 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructGeneralizedType(JavaType baseType, Class<?> superClass) {
/*  647 */     Class<?> rawBase = baseType.getRawClass();
/*  648 */     if (rawBase == superClass) {
/*  649 */       return baseType;
/*      */     }
/*  651 */     JavaType superType = baseType.findSuperType(superClass);
/*  652 */     if (superType == null) {
/*      */       
/*  654 */       if (!superClass.isAssignableFrom(rawBase)) {
/*  655 */         throw new IllegalArgumentException(String.format("Class %s not a super-type of %s", new Object[] { superClass
/*  656 */                 .getName(), baseType }));
/*      */       }
/*      */       
/*  659 */       throw new IllegalArgumentException(String.format("Internal error: class %s not included as super-type for %s", new Object[] { superClass
/*      */               
/*  661 */               .getName(), baseType }));
/*      */     } 
/*  663 */     return superType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructFromCanonical(String canonical) throws IllegalArgumentException {
/*  678 */     return this._parser.parse(canonical);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType[] findTypeParameters(JavaType type, Class<?> expType) {
/*  692 */     JavaType match = type.findSuperType(expType);
/*  693 */     if (match == null) {
/*  694 */       return NO_TYPES;
/*      */     }
/*  696 */     return match.getBindings().typeParameterArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType[] findTypeParameters(Class<?> clz, Class<?> expType, TypeBindings bindings) {
/*  704 */     return findTypeParameters(constructType(clz, bindings), expType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType[] findTypeParameters(Class<?> clz, Class<?> expType) {
/*  712 */     return findTypeParameters(constructType(clz), expType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType moreSpecificType(JavaType type1, JavaType type2) {
/*  727 */     if (type1 == null) {
/*  728 */       return type2;
/*      */     }
/*  730 */     if (type2 == null) {
/*  731 */       return type1;
/*      */     }
/*  733 */     Class<?> raw1 = type1.getRawClass();
/*  734 */     Class<?> raw2 = type2.getRawClass();
/*  735 */     if (raw1 == raw2) {
/*  736 */       return type1;
/*      */     }
/*      */     
/*  739 */     if (raw1.isAssignableFrom(raw2)) {
/*  740 */       return type2;
/*      */     }
/*  742 */     return type1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructType(Type type) {
/*  752 */     return _fromAny(null, type, EMPTY_BINDINGS);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructType(TypeReference<?> typeRef) {
/*  758 */     return _fromAny(null, typeRef.getType(), EMPTY_BINDINGS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType resolveMemberType(Type type, TypeBindings contextBindings) {
/*  796 */     return _fromAny(null, type, contextBindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructType(Type type, TypeBindings bindings) {
/*  819 */     if (type instanceof Class) {
/*  820 */       JavaType resultType = _fromClass(null, (Class)type, bindings);
/*  821 */       return _applyModifiers(type, resultType);
/*      */     } 
/*  823 */     return _fromAny(null, type, bindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructType(Type type, Class<?> contextClass) {
/*  831 */     JavaType contextType = (contextClass == null) ? null : constructType(contextClass);
/*  832 */     return constructType(type, contextType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructType(Type type, JavaType contextType) {
/*      */     TypeBindings bindings;
/*  841 */     if (contextType == null) {
/*  842 */       bindings = EMPTY_BINDINGS;
/*      */     } else {
/*  844 */       bindings = contextType.getBindings();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  849 */       if (type.getClass() != Class.class)
/*      */       {
/*      */         
/*  852 */         while (bindings.isEmpty()) {
/*  853 */           contextType = contextType.getSuperClass();
/*  854 */           if (contextType == null) {
/*      */             break;
/*      */           }
/*  857 */           bindings = contextType.getBindings();
/*      */         } 
/*      */       }
/*      */     } 
/*  861 */     return _fromAny(null, type, bindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayType constructArrayType(Class<?> elementType) {
/*  877 */     return ArrayType.construct(_fromAny(null, elementType, null), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayType constructArrayType(JavaType elementType) {
/*  887 */     return ArrayType.construct(elementType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionType constructCollectionType(Class<? extends Collection> collectionClass, Class<?> elementClass) {
/*  898 */     return constructCollectionType(collectionClass, 
/*  899 */         _fromClass(null, elementClass, EMPTY_BINDINGS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionType constructCollectionType(Class<? extends Collection> collectionClass, JavaType elementType) {
/*  911 */     TypeBindings bindings = TypeBindings.createIfNeeded(collectionClass, elementType);
/*  912 */     CollectionType result = (CollectionType)_fromClass(null, collectionClass, bindings);
/*      */ 
/*      */     
/*  915 */     if (bindings.isEmpty() && elementType != null) {
/*  916 */       JavaType t = result.findSuperType(Collection.class);
/*  917 */       JavaType realET = t.getContentType();
/*  918 */       if (!realET.equals(elementType))
/*  919 */         throw new IllegalArgumentException(String.format("Non-generic Collection class %s did not resolve to something with element type %s but %s ", new Object[] {
/*      */                 
/*  921 */                 ClassUtil.nameOf(collectionClass), elementType, realET
/*      */               })); 
/*      */     } 
/*  924 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionLikeType constructCollectionLikeType(Class<?> collectionClass, Class<?> elementClass) {
/*  934 */     return constructCollectionLikeType(collectionClass, 
/*  935 */         _fromClass(null, elementClass, EMPTY_BINDINGS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionLikeType constructCollectionLikeType(Class<?> collectionClass, JavaType elementType) {
/*  945 */     JavaType type = _fromClass(null, collectionClass, 
/*  946 */         TypeBindings.createIfNeeded(collectionClass, elementType));
/*  947 */     if (type instanceof CollectionLikeType) {
/*  948 */       return (CollectionLikeType)type;
/*      */     }
/*  950 */     return CollectionLikeType.upgradeFrom(type, elementType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapType constructMapType(Class<? extends Map> mapClass, Class<?> keyClass, Class<?> valueClass) {
/*      */     JavaType kt;
/*      */     JavaType vt;
/*  962 */     if (mapClass == Properties.class) {
/*  963 */       kt = vt = CORE_TYPE_STRING;
/*      */     } else {
/*  965 */       kt = _fromClass(null, keyClass, EMPTY_BINDINGS);
/*  966 */       vt = _fromClass(null, valueClass, EMPTY_BINDINGS);
/*      */     } 
/*  968 */     return constructMapType(mapClass, kt, vt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapType constructMapType(Class<? extends Map> mapClass, JavaType keyType, JavaType valueType) {
/*  977 */     TypeBindings bindings = TypeBindings.createIfNeeded(mapClass, new JavaType[] { keyType, valueType });
/*  978 */     MapType result = (MapType)_fromClass(null, mapClass, bindings);
/*      */ 
/*      */     
/*  981 */     if (bindings.isEmpty()) {
/*  982 */       JavaType t = result.findSuperType(Map.class);
/*  983 */       JavaType realKT = t.getKeyType();
/*  984 */       if (!realKT.equals(keyType))
/*  985 */         throw new IllegalArgumentException(String.format("Non-generic Map class %s did not resolve to something with key type %s but %s ", new Object[] {
/*      */                 
/*  987 */                 ClassUtil.nameOf(mapClass), keyType, realKT
/*      */               })); 
/*  989 */       JavaType realVT = t.getContentType();
/*  990 */       if (!realVT.equals(valueType))
/*  991 */         throw new IllegalArgumentException(String.format("Non-generic Map class %s did not resolve to something with value type %s but %s ", new Object[] {
/*      */                 
/*  993 */                 ClassUtil.nameOf(mapClass), valueType, realVT
/*      */               })); 
/*      */     } 
/*  996 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapLikeType constructMapLikeType(Class<?> mapClass, Class<?> keyClass, Class<?> valueClass) {
/* 1006 */     return constructMapLikeType(mapClass, 
/* 1007 */         _fromClass(null, keyClass, EMPTY_BINDINGS), 
/* 1008 */         _fromClass(null, valueClass, EMPTY_BINDINGS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapLikeType constructMapLikeType(Class<?> mapClass, JavaType keyType, JavaType valueType) {
/* 1019 */     JavaType type = _fromClass(null, mapClass, 
/* 1020 */         TypeBindings.createIfNeeded(mapClass, new JavaType[] { keyType, valueType }));
/* 1021 */     if (type instanceof MapLikeType) {
/* 1022 */       return (MapLikeType)type;
/*      */     }
/* 1024 */     return MapLikeType.upgradeFrom(type, keyType, valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSimpleType(Class<?> rawType, JavaType[] parameterTypes) {
/* 1033 */     return _fromClass(null, rawType, TypeBindings.create(rawType, parameterTypes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructSimpleType(Class<?> rawType, Class<?> parameterTarget, JavaType[] parameterTypes) {
/* 1047 */     return constructSimpleType(rawType, parameterTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructReferenceType(Class<?> rawType, JavaType referredType) {
/* 1060 */     return ReferenceType.construct(rawType, 
/* 1061 */         TypeBindings.create(rawType, referredType), null, null, referredType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType uncheckedSimpleType(Class<?> cls) {
/* 1080 */     return _constructSimple(cls, EMPTY_BINDINGS, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructParametricType(Class<?> parametrized, Class<?>... parameterClasses) {
/* 1101 */     int len = parameterClasses.length;
/* 1102 */     JavaType[] pt = new JavaType[len];
/* 1103 */     for (int i = 0; i < len; i++) {
/* 1104 */       pt[i] = _fromClass(null, parameterClasses[i], EMPTY_BINDINGS);
/*      */     }
/* 1106 */     return constructParametricType(parametrized, pt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructParametricType(Class<?> rawType, JavaType... parameterTypes) {
/* 1127 */     return constructParametricType(rawType, TypeBindings.create(rawType, parameterTypes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructParametricType(Class<?> rawType, TypeBindings parameterTypes) {
/* 1151 */     JavaType resultType = _fromClass(null, rawType, parameterTypes);
/* 1152 */     return _applyModifiers(rawType, resultType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructParametrizedType(Class<?> parametrized, Class<?> parametersFor, JavaType... parameterTypes) {
/* 1163 */     return constructParametricType(parametrized, parameterTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructParametrizedType(Class<?> parametrized, Class<?> parametersFor, Class<?>... parameterClasses) {
/* 1174 */     return constructParametricType(parametrized, parameterClasses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionType constructRawCollectionType(Class<? extends Collection> collectionClass) {
/* 1196 */     return constructCollectionType(collectionClass, unknownType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionLikeType constructRawCollectionLikeType(Class<?> collectionClass) {
/* 1211 */     return constructCollectionLikeType(collectionClass, unknownType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapType constructRawMapType(Class<? extends Map> mapClass) {
/* 1226 */     return constructMapType(mapClass, unknownType(), unknownType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapLikeType constructRawMapLikeType(Class<?> mapClass) {
/* 1241 */     return constructMapLikeType(mapClass, unknownType(), unknownType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JavaType _mapType(Class<?> rawClass, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/*      */     JavaType kt;
/*      */     JavaType vt;
/* 1256 */     if (rawClass == Properties.class)
/* 1257 */     { kt = vt = CORE_TYPE_STRING; }
/*      */     else
/* 1259 */     { List<JavaType> typeParams = bindings.getTypeParameters();
/*      */       
/* 1261 */       int pc = typeParams.size();
/* 1262 */       switch (pc)
/*      */       { case 0:
/* 1264 */           kt = vt = _unknownType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1276 */           return MapType.construct(rawClass, bindings, superClass, superInterfaces, kt, vt);case 2: kt = typeParams.get(0); vt = typeParams.get(1); return MapType.construct(rawClass, bindings, superClass, superInterfaces, kt, vt); }  throw new IllegalArgumentException(String.format("Strange Map type %s with %d type parameter%s (%s), can not resolve", new Object[] { ClassUtil.nameOf(rawClass), Integer.valueOf(pc), (pc == 1) ? "" : "s", bindings })); }  return MapType.construct(rawClass, bindings, superClass, superInterfaces, kt, vt);
/*      */   }
/*      */ 
/*      */   
/*      */   private JavaType _collectionType(Class<?> rawClass, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/*      */     JavaType ct;
/* 1282 */     List<JavaType> typeParams = bindings.getTypeParameters();
/*      */ 
/*      */     
/* 1285 */     if (typeParams.isEmpty()) {
/* 1286 */       ct = _unknownType();
/* 1287 */     } else if (typeParams.size() == 1) {
/* 1288 */       ct = typeParams.get(0);
/*      */     } else {
/* 1290 */       throw new IllegalArgumentException("Strange Collection type " + rawClass.getName() + ": cannot determine type parameters");
/*      */     } 
/* 1292 */     return CollectionType.construct(rawClass, bindings, superClass, superInterfaces, ct);
/*      */   }
/*      */ 
/*      */   
/*      */   private JavaType _referenceType(Class<?> rawClass, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/*      */     JavaType ct;
/* 1298 */     List<JavaType> typeParams = bindings.getTypeParameters();
/*      */ 
/*      */     
/* 1301 */     if (typeParams.isEmpty()) {
/* 1302 */       ct = _unknownType();
/* 1303 */     } else if (typeParams.size() == 1) {
/* 1304 */       ct = typeParams.get(0);
/*      */     } else {
/* 1306 */       throw new IllegalArgumentException("Strange Reference type " + rawClass.getName() + ": cannot determine type parameters");
/*      */     } 
/* 1308 */     return ReferenceType.construct(rawClass, bindings, superClass, superInterfaces, ct);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _constructSimple(Class<?> raw, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 1322 */     if (bindings.isEmpty()) {
/* 1323 */       JavaType result = _findWellKnownSimple(raw);
/* 1324 */       if (result != null) {
/* 1325 */         return result;
/*      */       }
/*      */     } 
/* 1328 */     return _newSimpleType(raw, bindings, superClass, superInterfaces);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _newSimpleType(Class<?> raw, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 1341 */     return new SimpleType(raw, bindings, superClass, superInterfaces);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _unknownType() {
/* 1350 */     return CORE_TYPE_OBJECT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _findWellKnownSimple(Class<?> clz) {
/* 1361 */     if (clz.isPrimitive()) {
/* 1362 */       if (clz == CLS_BOOL) return CORE_TYPE_BOOL; 
/* 1363 */       if (clz == CLS_INT) return CORE_TYPE_INT; 
/* 1364 */       if (clz == CLS_LONG) return CORE_TYPE_LONG; 
/*      */     } else {
/* 1366 */       if (clz == CLS_STRING) return CORE_TYPE_STRING; 
/* 1367 */       if (clz == CLS_OBJECT) return CORE_TYPE_OBJECT; 
/* 1368 */       if (clz == CLS_JSON_NODE) return CORE_TYPE_JSON_NODE; 
/*      */     } 
/* 1370 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromAny(ClassStack context, Type srcType, TypeBindings bindings) {
/*      */     JavaType resultType;
/* 1389 */     if (srcType instanceof Class) {
/*      */       
/* 1391 */       resultType = _fromClass(context, (Class)srcType, EMPTY_BINDINGS);
/*      */     
/*      */     }
/* 1394 */     else if (srcType instanceof ParameterizedType) {
/* 1395 */       resultType = _fromParamType(context, (ParameterizedType)srcType, bindings);
/*      */     } else {
/* 1397 */       if (srcType instanceof JavaType)
/*      */       {
/* 1399 */         return (JavaType)srcType;
/*      */       }
/* 1401 */       if (srcType instanceof GenericArrayType) {
/* 1402 */         resultType = _fromArrayType(context, (GenericArrayType)srcType, bindings);
/*      */       }
/* 1404 */       else if (srcType instanceof TypeVariable) {
/* 1405 */         resultType = _fromVariable(context, (TypeVariable)srcType, bindings);
/*      */       }
/* 1407 */       else if (srcType instanceof WildcardType) {
/* 1408 */         resultType = _fromWildcard(context, (WildcardType)srcType, bindings);
/*      */       } else {
/*      */         
/* 1411 */         throw new IllegalArgumentException("Unrecognized Type: " + ((srcType == null) ? "[null]" : srcType.toString()));
/*      */       } 
/*      */     } 
/*      */     
/* 1415 */     return _applyModifiers(srcType, resultType);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType _applyModifiers(Type srcType, JavaType resolvedType) {
/* 1420 */     if (this._modifiers == null) {
/* 1421 */       return resolvedType;
/*      */     }
/* 1423 */     JavaType resultType = resolvedType;
/* 1424 */     TypeBindings b = resultType.getBindings();
/* 1425 */     if (b == null) {
/* 1426 */       b = EMPTY_BINDINGS;
/*      */     }
/* 1428 */     for (TypeModifier mod : this._modifiers) {
/* 1429 */       JavaType t = mod.modifyType(resultType, srcType, b, this);
/* 1430 */       if (t == null) {
/* 1431 */         throw new IllegalStateException(String.format("TypeModifier %s (of type %s) return null for type %s", new Object[] { mod, mod
/*      */                 
/* 1433 */                 .getClass().getName(), resultType }));
/*      */       }
/* 1435 */       resultType = t;
/*      */     } 
/* 1437 */     return resultType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromClass(ClassStack context, Class<?> rawType, TypeBindings bindings) {
/*      */     Object key;
/* 1447 */     JavaType result = _findWellKnownSimple(rawType);
/* 1448 */     if (result != null) {
/* 1449 */       return result;
/*      */     }
/*      */ 
/*      */     
/* 1453 */     if (bindings == null || bindings.isEmpty()) {
/* 1454 */       key = rawType;
/*      */     } else {
/* 1456 */       key = bindings.asKey(rawType);
/*      */     } 
/* 1458 */     result = (JavaType)this._typeCache.get(key);
/* 1459 */     if (result != null) {
/* 1460 */       return result;
/*      */     }
/*      */ 
/*      */     
/* 1464 */     if (context == null) {
/* 1465 */       context = new ClassStack(rawType);
/*      */     } else {
/* 1467 */       ClassStack prev = context.find(rawType);
/* 1468 */       if (prev != null) {
/*      */         
/* 1470 */         ResolvedRecursiveType selfRef = new ResolvedRecursiveType(rawType, EMPTY_BINDINGS);
/* 1471 */         prev.addSelfReference(selfRef);
/* 1472 */         return selfRef;
/*      */       } 
/*      */       
/* 1475 */       context = context.child(rawType);
/*      */     } 
/*      */ 
/*      */     
/* 1479 */     if (rawType.isArray()) {
/* 1480 */       result = ArrayType.construct(_fromAny(context, rawType.getComponentType(), bindings), bindings);
/*      */     } else {
/*      */       JavaType superClass;
/*      */ 
/*      */       
/*      */       JavaType[] superInterfaces;
/*      */ 
/*      */       
/* 1488 */       if (rawType.isInterface()) {
/* 1489 */         superClass = null;
/* 1490 */         superInterfaces = _resolveSuperInterfaces(context, rawType, bindings);
/*      */       } else {
/*      */         
/* 1493 */         superClass = _resolveSuperClass(context, rawType, bindings);
/* 1494 */         superInterfaces = _resolveSuperInterfaces(context, rawType, bindings);
/*      */       } 
/*      */ 
/*      */       
/* 1498 */       if (rawType == Properties.class) {
/* 1499 */         result = MapType.construct(rawType, bindings, superClass, superInterfaces, CORE_TYPE_STRING, CORE_TYPE_STRING);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1504 */       else if (superClass != null) {
/* 1505 */         result = superClass.refine(rawType, bindings, superClass, superInterfaces);
/*      */       } 
/*      */       
/* 1508 */       if (result == null) {
/* 1509 */         result = _fromWellKnownClass(context, rawType, bindings, superClass, superInterfaces);
/* 1510 */         if (result == null) {
/* 1511 */           result = _fromWellKnownInterface(context, rawType, bindings, superClass, superInterfaces);
/* 1512 */           if (result == null)
/*      */           {
/* 1514 */             result = _newSimpleType(rawType, bindings, superClass, superInterfaces);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1519 */     context.resolveSelfReferences(result);
/*      */ 
/*      */     
/* 1522 */     if (!result.hasHandlers()) {
/* 1523 */       this._typeCache.putIfAbsent(key, result);
/*      */     }
/* 1525 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType _resolveSuperClass(ClassStack context, Class<?> rawType, TypeBindings parentBindings) {
/* 1530 */     Type parent = ClassUtil.getGenericSuperclass(rawType);
/* 1531 */     if (parent == null) {
/* 1532 */       return null;
/*      */     }
/* 1534 */     return _fromAny(context, parent, parentBindings);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType[] _resolveSuperInterfaces(ClassStack context, Class<?> rawType, TypeBindings parentBindings) {
/* 1539 */     Type[] types = ClassUtil.getGenericInterfaces(rawType);
/* 1540 */     if (types == null || types.length == 0) {
/* 1541 */       return NO_TYPES;
/*      */     }
/* 1543 */     int len = types.length;
/* 1544 */     JavaType[] resolved = new JavaType[len];
/* 1545 */     for (int i = 0; i < len; i++) {
/* 1546 */       Type type = types[i];
/* 1547 */       resolved[i] = _fromAny(context, type, parentBindings);
/*      */     } 
/* 1549 */     return resolved;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromWellKnownClass(ClassStack context, Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 1560 */     if (bindings == null) {
/* 1561 */       bindings = EMPTY_BINDINGS;
/*      */     }
/*      */     
/* 1564 */     if (rawType == Map.class) {
/* 1565 */       return _mapType(rawType, bindings, superClass, superInterfaces);
/*      */     }
/* 1567 */     if (rawType == Collection.class) {
/* 1568 */       return _collectionType(rawType, bindings, superClass, superInterfaces);
/*      */     }
/*      */     
/* 1571 */     if (rawType == AtomicReference.class) {
/* 1572 */       return _referenceType(rawType, bindings, superClass, superInterfaces);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1578 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromWellKnownInterface(ClassStack context, Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 1586 */     int intCount = superInterfaces.length;
/*      */     
/* 1588 */     for (int i = 0; i < intCount; i++) {
/* 1589 */       JavaType result = superInterfaces[i].refine(rawType, bindings, superClass, superInterfaces);
/* 1590 */       if (result != null) {
/* 1591 */         return result;
/*      */       }
/*      */     } 
/* 1594 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromParamType(ClassStack context, ParameterizedType ptype, TypeBindings parentBindings) {
/*      */     TypeBindings newBindings;
/* 1605 */     Class<?> rawType = (Class)ptype.getRawType();
/*      */ 
/*      */ 
/*      */     
/* 1609 */     if (rawType == CLS_ENUM) {
/* 1610 */       return CORE_TYPE_ENUM;
/*      */     }
/* 1612 */     if (rawType == CLS_COMPARABLE) {
/* 1613 */       return CORE_TYPE_COMPARABLE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1619 */     Type[] args = ptype.getActualTypeArguments();
/* 1620 */     int paramCount = (args == null) ? 0 : args.length;
/*      */ 
/*      */     
/* 1623 */     if (paramCount == 0) {
/* 1624 */       newBindings = EMPTY_BINDINGS;
/*      */     } else {
/* 1626 */       JavaType[] pt = new JavaType[paramCount];
/* 1627 */       for (int i = 0; i < paramCount; i++) {
/* 1628 */         pt[i] = _fromAny(context, args[i], parentBindings);
/*      */       }
/* 1630 */       newBindings = TypeBindings.create(rawType, pt);
/*      */     } 
/* 1632 */     return _fromClass(context, rawType, newBindings);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType _fromArrayType(ClassStack context, GenericArrayType type, TypeBindings bindings) {
/* 1637 */     JavaType elementType = _fromAny(context, type.getGenericComponentType(), bindings);
/* 1638 */     return ArrayType.construct(elementType, bindings);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType _fromVariable(ClassStack context, TypeVariable<?> var, TypeBindings bindings) {
/*      */     Type[] bounds;
/* 1644 */     String name = var.getName();
/* 1645 */     if (bindings == null) {
/* 1646 */       throw new IllegalArgumentException("Null `bindings` passed (type variable \"" + name + "\")");
/*      */     }
/* 1648 */     JavaType type = bindings.findBoundType(name);
/* 1649 */     if (type != null) {
/* 1650 */       return type;
/*      */     }
/*      */ 
/*      */     
/* 1654 */     if (bindings.hasUnbound(name)) {
/* 1655 */       return CORE_TYPE_OBJECT;
/*      */     }
/* 1657 */     bindings = bindings.withUnboundVariable(name);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1668 */     synchronized (var) {
/* 1669 */       bounds = var.getBounds();
/*      */     } 
/* 1671 */     return _fromAny(context, bounds[0], bindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromWildcard(ClassStack context, WildcardType type, TypeBindings bindings) {
/* 1681 */     return _fromAny(context, type.getUpperBounds()[0], bindings);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\type\TypeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */