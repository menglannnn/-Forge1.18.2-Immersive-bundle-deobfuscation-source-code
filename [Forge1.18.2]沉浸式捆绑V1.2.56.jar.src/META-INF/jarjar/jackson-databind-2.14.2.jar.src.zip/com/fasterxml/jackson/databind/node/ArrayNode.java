/*      */ package com.fasterxml.jackson.databind.node;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonPointer;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.SerializerProvider;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.util.RawValue;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ 
/*      */ public class ArrayNode
/*      */   extends ContainerNode<ArrayNode>
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private final List<JsonNode> _children;
/*      */   
/*      */   public ArrayNode(JsonNodeFactory nf) {
/*   30 */     super(nf);
/*   31 */     this._children = new ArrayList<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode(JsonNodeFactory nf, int capacity) {
/*   38 */     super(nf);
/*   39 */     this._children = new ArrayList<>(capacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode(JsonNodeFactory nf, List<JsonNode> children) {
/*   46 */     super(nf);
/*   47 */     this._children = children;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonNode _at(JsonPointer ptr) {
/*   52 */     return get(ptr.getMatchingIndex());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode deepCopy() {
/*   60 */     ArrayNode ret = new ArrayNode(this._nodeFactory);
/*      */     
/*   62 */     for (JsonNode element : this._children) {
/*   63 */       ret._children.add(element.deepCopy());
/*      */     }
/*   65 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectNode with(String exprOrProperty) {
/*   78 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*   79 */     if (ptr != null) {
/*   80 */       return withObject(ptr);
/*      */     }
/*   82 */     return (ObjectNode)super.with(exprOrProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode withArray(String exprOrProperty) {
/*   89 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*   90 */     if (ptr != null) {
/*   91 */       return withArray(ptr);
/*      */     }
/*   93 */     return (ArrayNode)super.withArray(exprOrProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectNode _withObject(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/*  101 */     if (currentPtr.matches())
/*      */     {
/*  103 */       return null;
/*      */     }
/*  105 */     JsonNode n = _at(currentPtr);
/*      */     
/*  107 */     if (n != null && n instanceof BaseJsonNode) {
/*  108 */       ObjectNode found = ((BaseJsonNode)n)._withObject(origPtr, currentPtr.tail(), overwriteMode, preferIndex);
/*      */       
/*  110 */       if (found != null) {
/*  111 */         return found;
/*      */       }
/*      */       
/*  114 */       _withXxxVerifyReplace(origPtr, currentPtr, overwriteMode, preferIndex, n);
/*      */     } 
/*      */     
/*  117 */     return _withObjectAddTailElement(currentPtr, preferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayNode _withArray(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/*  125 */     if (currentPtr.matches()) {
/*  126 */       return this;
/*      */     }
/*  128 */     JsonNode n = _at(currentPtr);
/*      */     
/*  130 */     if (n != null && n instanceof BaseJsonNode) {
/*  131 */       ArrayNode found = ((BaseJsonNode)n)._withArray(origPtr, currentPtr.tail(), overwriteMode, preferIndex);
/*      */       
/*  133 */       if (found != null) {
/*  134 */         return found;
/*      */       }
/*      */       
/*  137 */       _withXxxVerifyReplace(origPtr, currentPtr, overwriteMode, preferIndex, n);
/*      */     } 
/*      */     
/*  140 */     return _withArrayAddTailElement(currentPtr, preferIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ObjectNode _withObjectAddTailElement(JsonPointer tail, boolean preferIndex) {
/*  145 */     int index = tail.getMatchingIndex();
/*  146 */     if (index < 0) {
/*  147 */       return null;
/*      */     }
/*      */     
/*  150 */     tail = tail.tail();
/*      */ 
/*      */     
/*  153 */     if (tail.matches()) {
/*  154 */       ObjectNode result = objectNode();
/*  155 */       _withXxxSetArrayElement(index, result);
/*  156 */       return result;
/*      */     } 
/*      */ 
/*      */     
/*  160 */     if (preferIndex && tail.mayMatchElement()) {
/*  161 */       ArrayNode arrayNode = arrayNode();
/*  162 */       _withXxxSetArrayElement(index, arrayNode);
/*  163 */       return arrayNode._withObjectAddTailElement(tail, preferIndex);
/*      */     } 
/*  165 */     ObjectNode next = objectNode();
/*  166 */     _withXxxSetArrayElement(index, next);
/*  167 */     return next._withObjectAddTailProperty(tail, preferIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ArrayNode _withArrayAddTailElement(JsonPointer tail, boolean preferIndex) {
/*  172 */     int index = tail.getMatchingIndex();
/*  173 */     if (index < 0) {
/*  174 */       return null;
/*      */     }
/*  176 */     tail = tail.tail();
/*      */ 
/*      */     
/*  179 */     if (tail.matches()) {
/*  180 */       ArrayNode result = arrayNode();
/*  181 */       _withXxxSetArrayElement(index, result);
/*  182 */       return result;
/*      */     } 
/*      */ 
/*      */     
/*  186 */     if (preferIndex && tail.mayMatchElement()) {
/*  187 */       ArrayNode arrayNode = arrayNode();
/*  188 */       _withXxxSetArrayElement(index, arrayNode);
/*  189 */       return arrayNode._withArrayAddTailElement(tail, preferIndex);
/*      */     } 
/*  191 */     ArrayNode next = arrayNode();
/*  192 */     _withXxxSetArrayElement(index, next);
/*  193 */     return next._withArrayAddTailElement(tail, preferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _withXxxSetArrayElement(int index, JsonNode value) {
/*  199 */     if (index >= size()) {
/*  200 */       int max = this._nodeFactory.getMaxElementIndexForInsert();
/*  201 */       if (index > max)
/*  202 */         _reportWrongNodeOperation("Too big Array index (%d; max %d) to use for insert with `JsonPointer`", new Object[] {
/*  203 */               Integer.valueOf(index), Integer.valueOf(max)
/*      */             }); 
/*  205 */       while (index >= size()) {
/*  206 */         addNull();
/*      */       }
/*      */     } 
/*  209 */     set(index, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty(SerializerProvider serializers) {
/*  220 */     return this._children.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNodeType getNodeType() {
/*  231 */     return JsonNodeType.ARRAY;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isArray() {
/*  236 */     return true;
/*      */   }
/*      */   public JsonToken asToken() {
/*  239 */     return JsonToken.START_ARRAY;
/*      */   }
/*      */   
/*      */   public int size() {
/*  243 */     return this._children.size();
/*      */   }
/*      */   
/*      */   public boolean isEmpty() {
/*  247 */     return this._children.isEmpty();
/*      */   }
/*      */   
/*      */   public Iterator<JsonNode> elements() {
/*  251 */     return this._children.iterator();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode get(int index) {
/*  256 */     if (index >= 0 && index < this._children.size()) {
/*  257 */       return this._children.get(index);
/*      */     }
/*  259 */     return null;
/*      */   }
/*      */   
/*      */   public JsonNode get(String fieldName) {
/*  263 */     return null;
/*      */   }
/*      */   public JsonNode path(String fieldName) {
/*  266 */     return MissingNode.getInstance();
/*      */   }
/*      */   
/*      */   public JsonNode path(int index) {
/*  270 */     if (index >= 0 && index < this._children.size()) {
/*  271 */       return this._children.get(index);
/*      */     }
/*  273 */     return MissingNode.getInstance();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode required(int index) {
/*  278 */     if (index >= 0 && index < this._children.size()) {
/*  279 */       return this._children.get(index);
/*      */     }
/*  281 */     return (JsonNode)_reportRequiredViolation("No value at index #%d [0, %d) of `ArrayNode`", new Object[] {
/*  282 */           Integer.valueOf(index), Integer.valueOf(this._children.size())
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Comparator<JsonNode> comparator, JsonNode o) {
/*  288 */     if (!(o instanceof ArrayNode)) {
/*  289 */       return false;
/*      */     }
/*  291 */     ArrayNode other = (ArrayNode)o;
/*  292 */     int len = this._children.size();
/*  293 */     if (other.size() != len) {
/*  294 */       return false;
/*      */     }
/*  296 */     List<JsonNode> l1 = this._children;
/*  297 */     List<JsonNode> l2 = other._children;
/*  298 */     for (int i = 0; i < len; i++) {
/*  299 */       if (!((JsonNode)l1.get(i)).equals(comparator, l2.get(i))) {
/*  300 */         return false;
/*      */       }
/*      */     } 
/*  303 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serialize(JsonGenerator g, SerializerProvider provider) throws IOException {
/*  315 */     List<JsonNode> c = this._children;
/*  316 */     int size = c.size();
/*  317 */     g.writeStartArray(this, size);
/*  318 */     for (int i = 0; i < size; i++) {
/*  319 */       JsonNode value = c.get(i);
/*  320 */       value.serialize(g, provider);
/*      */     } 
/*  322 */     g.writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeWithType(JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  329 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  330 */         .typeId(this, JsonToken.START_ARRAY));
/*  331 */     for (JsonNode n : this._children) {
/*  332 */       ((BaseJsonNode)n).serialize(g, provider);
/*      */     }
/*  334 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode findValue(String fieldName) {
/*  346 */     for (JsonNode node : this._children) {
/*  347 */       JsonNode value = node.findValue(fieldName);
/*  348 */       if (value != null) {
/*  349 */         return value;
/*      */       }
/*      */     } 
/*  352 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JsonNode> findValues(String fieldName, List<JsonNode> foundSoFar) {
/*  358 */     for (JsonNode node : this._children) {
/*  359 */       foundSoFar = node.findValues(fieldName, foundSoFar);
/*      */     }
/*  361 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> findValuesAsText(String fieldName, List<String> foundSoFar) {
/*  367 */     for (JsonNode node : this._children) {
/*  368 */       foundSoFar = node.findValuesAsText(fieldName, foundSoFar);
/*      */     }
/*  370 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode findParent(String fieldName) {
/*  376 */     for (JsonNode node : this._children) {
/*  377 */       JsonNode parent = node.findParent(fieldName);
/*  378 */       if (parent != null) {
/*  379 */         return (ObjectNode)parent;
/*      */       }
/*      */     } 
/*  382 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JsonNode> findParents(String fieldName, List<JsonNode> foundSoFar) {
/*  388 */     for (JsonNode node : this._children) {
/*  389 */       foundSoFar = node.findParents(fieldName, foundSoFar);
/*      */     }
/*  391 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode set(int index, JsonNode value) {
/*  413 */     if (value == null) {
/*  414 */       value = nullNode();
/*      */     }
/*  416 */     if (index < 0 || index >= this._children.size()) {
/*  417 */       throw new IndexOutOfBoundsException("Illegal index " + index + ", array size " + size());
/*      */     }
/*  419 */     return this._children.set(index, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(JsonNode value) {
/*  429 */     if (value == null) {
/*  430 */       value = nullNode();
/*      */     }
/*  432 */     _add(value);
/*  433 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addAll(ArrayNode other) {
/*  446 */     this._children.addAll(other._children);
/*  447 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addAll(Collection<? extends JsonNode> nodes) {
/*  459 */     for (JsonNode node : nodes) {
/*  460 */       add(node);
/*      */     }
/*  462 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, JsonNode value) {
/*  476 */     if (value == null) {
/*  477 */       value = nullNode();
/*      */     }
/*  479 */     _insert(index, value);
/*  480 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode remove(int index) {
/*  492 */     if (index >= 0 && index < this._children.size()) {
/*  493 */       return this._children.remove(index);
/*      */     }
/*  495 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode removeAll() {
/*  507 */     this._children.clear();
/*  508 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addArray() {
/*  525 */     ArrayNode n = arrayNode();
/*  526 */     _add(n);
/*  527 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode addObject() {
/*  538 */     ObjectNode n = objectNode();
/*  539 */     _add(n);
/*  540 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addPOJO(Object pojo) {
/*  550 */     return _add((pojo == null) ? nullNode() : pojoNode(pojo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addRawValue(RawValue raw) {
/*  559 */     return _add((raw == null) ? nullNode() : rawValueNode(raw));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addNull() {
/*  568 */     return _add(nullNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(short v) {
/*  579 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Short v) {
/*  591 */     return _add((v == null) ? nullNode() : numberNode(v.shortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(int v) {
/*  600 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Integer v) {
/*  610 */     return _add((v == null) ? nullNode() : numberNode(v.intValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(long v) {
/*  618 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Long v) {
/*  627 */     return _add((v == null) ? nullNode() : numberNode(v.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(float v) {
/*  636 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Float v) {
/*  646 */     return _add((v == null) ? nullNode() : numberNode(v.floatValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(double v) {
/*  655 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Double v) {
/*  665 */     return _add((v == null) ? nullNode() : numberNode(v.doubleValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(BigDecimal v) {
/*  674 */     return _add((v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(BigInteger v) {
/*  685 */     return _add((v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(String v) {
/*  694 */     return _add((v == null) ? nullNode() : textNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(boolean v) {
/*  703 */     return _add(booleanNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Boolean v) {
/*  713 */     return _add((v == null) ? nullNode() : booleanNode(v.booleanValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(byte[] v) {
/*  723 */     return _add((v == null) ? nullNode() : binaryNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insertArray(int index) {
/*  736 */     ArrayNode n = arrayNode();
/*  737 */     _insert(index, n);
/*  738 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode insertObject(int index) {
/*  750 */     ObjectNode n = objectNode();
/*  751 */     _insert(index, n);
/*  752 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insertNull(int index) {
/*  762 */     return _insert(index, nullNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insertPOJO(int index, Object pojo) {
/*  772 */     return _insert(index, (pojo == null) ? nullNode() : pojoNode(pojo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insertRawValue(int index, RawValue raw) {
/*  781 */     return _insert(index, (raw == null) ? nullNode() : rawValueNode(raw));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, short v) {
/*  793 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Short value) {
/*  805 */     return _insert(index, (value == null) ? nullNode() : numberNode(value.shortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, int v) {
/*  815 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Integer v) {
/*  825 */     return _insert(index, (v == null) ? nullNode() : numberNode(v.intValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, long v) {
/*  835 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Long v) {
/*  845 */     return _insert(index, (v == null) ? nullNode() : numberNode(v.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, float v) {
/*  855 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Float v) {
/*  865 */     return _insert(index, (v == null) ? nullNode() : numberNode(v.floatValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, double v) {
/*  875 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Double v) {
/*  885 */     return _insert(index, (v == null) ? nullNode() : numberNode(v.doubleValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, BigDecimal v) {
/*  895 */     return _insert(index, (v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, BigInteger v) {
/*  907 */     return _insert(index, (v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, String v) {
/*  917 */     return _insert(index, (v == null) ? nullNode() : textNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, boolean v) {
/*  927 */     return _insert(index, booleanNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Boolean value) {
/*  937 */     if (value == null) {
/*  938 */       return insertNull(index);
/*      */     }
/*  940 */     return _insert(index, booleanNode(value.booleanValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, byte[] v) {
/*  951 */     if (v == null) {
/*  952 */       return insertNull(index);
/*      */     }
/*  954 */     return _insert(index, binaryNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode setNull(int index) {
/*  963 */     return _set(index, nullNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode setPOJO(int index, Object pojo) {
/*  972 */     return _set(index, (pojo == null) ? nullNode() : pojoNode(pojo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode setRawValue(int index, RawValue raw) {
/*  981 */     return _set(index, (raw == null) ? nullNode() : rawValueNode(raw));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, short v) {
/*  990 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Short v) {
/* 1002 */     return _set(index, (v == null) ? nullNode() : numberNode(v.shortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, int v) {
/* 1011 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Integer v) {
/* 1023 */     return _set(index, (v == null) ? nullNode() : numberNode(v.intValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, long v) {
/* 1032 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Long v) {
/* 1041 */     return _set(index, (v == null) ? nullNode() : numberNode(v.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, float v) {
/* 1052 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Float v) {
/* 1064 */     return _set(index, (v == null) ? nullNode() : numberNode(v.floatValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, double v) {
/* 1075 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Double v) {
/* 1087 */     return _set(index, (v == null) ? nullNode() : numberNode(v.doubleValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, BigDecimal v) {
/* 1098 */     return _set(index, (v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, BigInteger v) {
/* 1109 */     return _set(index, (v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, String v) {
/* 1120 */     return _set(index, (v == null) ? nullNode() : textNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, boolean v) {
/* 1131 */     return _set(index, booleanNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Boolean v) {
/* 1143 */     return _set(index, (v == null) ? nullNode() : booleanNode(v.booleanValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, byte[] v) {
/* 1154 */     return _set(index, (v == null) ? nullNode() : binaryNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/* 1166 */     if (o == this) return true; 
/* 1167 */     if (o == null) return false; 
/* 1168 */     if (o instanceof ArrayNode) {
/* 1169 */       return this._children.equals(((ArrayNode)o)._children);
/*      */     }
/* 1171 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _childrenEqual(ArrayNode other) {
/* 1178 */     return this._children.equals(other._children);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1183 */     return this._children.hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayNode _set(int index, JsonNode node) {
/* 1193 */     if (index < 0 || index >= this._children.size()) {
/* 1194 */       throw new IndexOutOfBoundsException("Illegal index " + index + ", array size " + size());
/*      */     }
/* 1196 */     this._children.set(index, node);
/* 1197 */     return this;
/*      */   }
/*      */   
/*      */   protected ArrayNode _add(JsonNode node) {
/* 1201 */     this._children.add(node);
/* 1202 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   protected ArrayNode _insert(int index, JsonNode node) {
/* 1207 */     if (index < 0) {
/* 1208 */       this._children.add(0, node);
/* 1209 */     } else if (index >= this._children.size()) {
/* 1210 */       this._children.add(node);
/*      */     } else {
/* 1212 */       this._children.add(index, node);
/*      */     } 
/* 1214 */     return this;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\node\ArrayNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */