/*      */ package com.fasterxml.jackson.databind;
/*      */ import com.fasterxml.jackson.core.FormatFeature;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.json.JsonReadFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.BaseSettings;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionConfigs;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.cfg.ConfigOverrides;
/*      */ import com.fasterxml.jackson.databind.cfg.ConstructorDetector;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfigBase;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*      */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.util.LinkedNode;
/*      */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*      */ import java.util.Collection;
/*      */ 
/*      */ public final class DeserializationConfig extends MapperConfigBase<DeserializationFeature, DeserializationConfig> implements Serializable {
/*   33 */   private static final int DESER_FEATURE_DEFAULTS = collectFeatureDefaults(DeserializationFeature.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 2L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final LinkedNode<DeserializationProblemHandler> _problemHandlers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonNodeFactory _nodeFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final CoercionConfigs _coercionConfigs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ConstructorDetector _ctorDetector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _deserFeatures;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parserFeatures;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parserFeaturesToChange;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _formatReadFeatures;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _formatReadFeaturesToChange;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides, CoercionConfigs coercionConfigs, DatatypeFeatures datatypeFeatures) {
/*  120 */     super(base, str, mixins, rootNames, configOverrides, datatypeFeatures);
/*  121 */     this._deserFeatures = DESER_FEATURE_DEFAULTS;
/*  122 */     this._problemHandlers = null;
/*  123 */     this._nodeFactory = JsonNodeFactory.instance;
/*  124 */     this._ctorDetector = null;
/*  125 */     this._coercionConfigs = coercionConfigs;
/*  126 */     this._parserFeatures = 0;
/*  127 */     this._parserFeaturesToChange = 0;
/*  128 */     this._formatReadFeatures = 0;
/*  129 */     this._formatReadFeaturesToChange = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationConfig(DeserializationConfig src, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides, CoercionConfigs coercionConfigs) {
/*  142 */     super(src, str, mixins, rootNames, configOverrides);
/*  143 */     this._deserFeatures = src._deserFeatures;
/*  144 */     this._problemHandlers = src._problemHandlers;
/*  145 */     this._nodeFactory = src._nodeFactory;
/*  146 */     this._ctorDetector = src._ctorDetector;
/*  147 */     this._coercionConfigs = coercionConfigs;
/*  148 */     this._parserFeatures = src._parserFeatures;
/*  149 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  150 */     this._formatReadFeatures = src._formatReadFeatures;
/*  151 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, long mapperFeatures, int deserFeatures, int parserFeatures, int parserFeatureMask, int formatFeatures, int formatFeatureMask) {
/*  166 */     super(src, mapperFeatures);
/*  167 */     this._deserFeatures = deserFeatures;
/*  168 */     this._problemHandlers = src._problemHandlers;
/*  169 */     this._nodeFactory = src._nodeFactory;
/*  170 */     this._coercionConfigs = src._coercionConfigs;
/*  171 */     this._ctorDetector = src._ctorDetector;
/*  172 */     this._parserFeatures = parserFeatures;
/*  173 */     this._parserFeaturesToChange = parserFeatureMask;
/*  174 */     this._formatReadFeatures = formatFeatures;
/*  175 */     this._formatReadFeaturesToChange = formatFeatureMask;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, SubtypeResolver str) {
/*  184 */     super(src, str);
/*  185 */     this._deserFeatures = src._deserFeatures;
/*  186 */     this._problemHandlers = src._problemHandlers;
/*  187 */     this._nodeFactory = src._nodeFactory;
/*  188 */     this._coercionConfigs = src._coercionConfigs;
/*  189 */     this._ctorDetector = src._ctorDetector;
/*  190 */     this._parserFeatures = src._parserFeatures;
/*  191 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  192 */     this._formatReadFeatures = src._formatReadFeatures;
/*  193 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, BaseSettings base) {
/*  198 */     super(src, base);
/*  199 */     this._deserFeatures = src._deserFeatures;
/*  200 */     this._problemHandlers = src._problemHandlers;
/*  201 */     this._nodeFactory = src._nodeFactory;
/*  202 */     this._coercionConfigs = src._coercionConfigs;
/*  203 */     this._ctorDetector = src._ctorDetector;
/*  204 */     this._parserFeatures = src._parserFeatures;
/*  205 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  206 */     this._formatReadFeatures = src._formatReadFeatures;
/*  207 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, JsonNodeFactory f) {
/*  212 */     super(src);
/*  213 */     this._deserFeatures = src._deserFeatures;
/*  214 */     this._problemHandlers = src._problemHandlers;
/*  215 */     this._nodeFactory = f;
/*  216 */     this._coercionConfigs = src._coercionConfigs;
/*  217 */     this._ctorDetector = src._ctorDetector;
/*  218 */     this._parserFeatures = src._parserFeatures;
/*  219 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  220 */     this._formatReadFeatures = src._formatReadFeatures;
/*  221 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, ConstructorDetector ctorDetector) {
/*  227 */     super(src);
/*  228 */     this._deserFeatures = src._deserFeatures;
/*  229 */     this._problemHandlers = src._problemHandlers;
/*  230 */     this._nodeFactory = src._nodeFactory;
/*  231 */     this._coercionConfigs = src._coercionConfigs;
/*  232 */     this._ctorDetector = ctorDetector;
/*  233 */     this._parserFeatures = src._parserFeatures;
/*  234 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  235 */     this._formatReadFeatures = src._formatReadFeatures;
/*  236 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, LinkedNode<DeserializationProblemHandler> problemHandlers) {
/*  242 */     super(src);
/*  243 */     this._deserFeatures = src._deserFeatures;
/*  244 */     this._problemHandlers = problemHandlers;
/*  245 */     this._nodeFactory = src._nodeFactory;
/*  246 */     this._coercionConfigs = src._coercionConfigs;
/*  247 */     this._ctorDetector = src._ctorDetector;
/*  248 */     this._parserFeatures = src._parserFeatures;
/*  249 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  250 */     this._formatReadFeatures = src._formatReadFeatures;
/*  251 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, PropertyName rootName) {
/*  256 */     super(src, rootName);
/*  257 */     this._deserFeatures = src._deserFeatures;
/*  258 */     this._problemHandlers = src._problemHandlers;
/*  259 */     this._nodeFactory = src._nodeFactory;
/*  260 */     this._coercionConfigs = src._coercionConfigs;
/*  261 */     this._ctorDetector = src._ctorDetector;
/*  262 */     this._parserFeatures = src._parserFeatures;
/*  263 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  264 */     this._formatReadFeatures = src._formatReadFeatures;
/*  265 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, Class<?> view) {
/*  270 */     super(src, view);
/*  271 */     this._deserFeatures = src._deserFeatures;
/*  272 */     this._problemHandlers = src._problemHandlers;
/*  273 */     this._nodeFactory = src._nodeFactory;
/*  274 */     this._coercionConfigs = src._coercionConfigs;
/*  275 */     this._ctorDetector = src._ctorDetector;
/*  276 */     this._parserFeatures = src._parserFeatures;
/*  277 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  278 */     this._formatReadFeatures = src._formatReadFeatures;
/*  279 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   protected DeserializationConfig(DeserializationConfig src, ContextAttributes attrs) {
/*  284 */     super(src, attrs);
/*  285 */     this._deserFeatures = src._deserFeatures;
/*  286 */     this._problemHandlers = src._problemHandlers;
/*  287 */     this._nodeFactory = src._nodeFactory;
/*  288 */     this._coercionConfigs = src._coercionConfigs;
/*  289 */     this._ctorDetector = src._ctorDetector;
/*  290 */     this._parserFeatures = src._parserFeatures;
/*  291 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  292 */     this._formatReadFeatures = src._formatReadFeatures;
/*  293 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   protected DeserializationConfig(DeserializationConfig src, SimpleMixInResolver mixins) {
/*  298 */     super(src, mixins);
/*  299 */     this._deserFeatures = src._deserFeatures;
/*  300 */     this._problemHandlers = src._problemHandlers;
/*  301 */     this._nodeFactory = src._nodeFactory;
/*  302 */     this._coercionConfigs = src._coercionConfigs;
/*  303 */     this._ctorDetector = src._ctorDetector;
/*  304 */     this._parserFeatures = src._parserFeatures;
/*  305 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  306 */     this._formatReadFeatures = src._formatReadFeatures;
/*  307 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationConfig(DeserializationConfig src, DatatypeFeatures datatypeFeatures) {
/*  316 */     super(src, datatypeFeatures);
/*  317 */     this._deserFeatures = src._deserFeatures;
/*  318 */     this._problemHandlers = src._problemHandlers;
/*  319 */     this._nodeFactory = src._nodeFactory;
/*  320 */     this._coercionConfigs = src._coercionConfigs;
/*  321 */     this._ctorDetector = src._ctorDetector;
/*  322 */     this._parserFeatures = src._parserFeatures;
/*  323 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  324 */     this._formatReadFeatures = src._formatReadFeatures;
/*  325 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */   
/*      */   protected BaseSettings getBaseSettings() {
/*  329 */     return this._base;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DeserializationConfig _withBase(BaseSettings newBase) {
/*  339 */     return (this._base == newBase) ? this : new DeserializationConfig(this, newBase);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final DeserializationConfig _withMapperFeatures(long mapperFeatures) {
/*  344 */     return new DeserializationConfig(this, mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DeserializationConfig _with(DatatypeFeatures dtFeatures) {
/*  351 */     return new DeserializationConfig(this, dtFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(SubtypeResolver str) {
/*  362 */     return (this._subtypeResolver == str) ? this : new DeserializationConfig(this, str);
/*      */   }
/*      */ 
/*      */   
/*      */   public DeserializationConfig withRootName(PropertyName rootName) {
/*  367 */     if (rootName == null) {
/*  368 */       if (this._rootName == null) {
/*  369 */         return this;
/*      */       }
/*  371 */     } else if (rootName.equals(this._rootName)) {
/*  372 */       return this;
/*      */     } 
/*  374 */     return new DeserializationConfig(this, rootName);
/*      */   }
/*      */ 
/*      */   
/*      */   public DeserializationConfig withView(Class<?> view) {
/*  379 */     return (this._view == view) ? this : new DeserializationConfig(this, view);
/*      */   }
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(ContextAttributes attrs) {
/*  384 */     return (attrs == this._attributes) ? this : new DeserializationConfig(this, attrs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(DeserializationFeature feature) {
/*  399 */     int newDeserFeatures = this._deserFeatures | feature.getMask();
/*  400 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(DeserializationFeature first, DeserializationFeature... features) {
/*  413 */     int newDeserFeatures = this._deserFeatures | first.getMask();
/*  414 */     for (DeserializationFeature f : features) {
/*  415 */       newDeserFeatures |= f.getMask();
/*      */     }
/*  417 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withFeatures(DeserializationFeature... features) {
/*  429 */     int newDeserFeatures = this._deserFeatures;
/*  430 */     for (DeserializationFeature f : features) {
/*  431 */       newDeserFeatures |= f.getMask();
/*      */     }
/*  433 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig without(DeserializationFeature feature) {
/*  445 */     int newDeserFeatures = this._deserFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/*  446 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig without(DeserializationFeature first, DeserializationFeature... features) {
/*  459 */     int newDeserFeatures = this._deserFeatures & (first.getMask() ^ 0xFFFFFFFF);
/*  460 */     for (DeserializationFeature f : features) {
/*  461 */       newDeserFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*      */     }
/*  463 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withoutFeatures(DeserializationFeature... features) {
/*  475 */     int newDeserFeatures = this._deserFeatures;
/*  476 */     for (DeserializationFeature f : features) {
/*  477 */       newDeserFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*      */     }
/*  479 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(JsonParser.Feature feature) {
/*  499 */     int newSet = this._parserFeatures | feature.getMask();
/*  500 */     int newMask = this._parserFeaturesToChange | feature.getMask();
/*  501 */     return (this._parserFeatures == newSet && this._parserFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, newSet, newMask, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withFeatures(JsonParser.Feature... features) {
/*  515 */     int newSet = this._parserFeatures;
/*  516 */     int newMask = this._parserFeaturesToChange;
/*  517 */     for (JsonParser.Feature f : features) {
/*  518 */       int mask = f.getMask();
/*  519 */       newSet |= mask;
/*  520 */       newMask |= mask;
/*      */     } 
/*  522 */     return (this._parserFeatures == newSet && this._parserFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, newSet, newMask, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig without(JsonParser.Feature feature) {
/*  536 */     int newSet = this._parserFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/*  537 */     int newMask = this._parserFeaturesToChange | feature.getMask();
/*  538 */     return (this._parserFeatures == newSet && this._parserFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, newSet, newMask, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withoutFeatures(JsonParser.Feature... features) {
/*  552 */     int newSet = this._parserFeatures;
/*  553 */     int newMask = this._parserFeaturesToChange;
/*  554 */     for (JsonParser.Feature f : features) {
/*  555 */       int mask = f.getMask();
/*  556 */       newSet &= mask ^ 0xFFFFFFFF;
/*  557 */       newMask |= mask;
/*      */     } 
/*  559 */     return (this._parserFeatures == newSet && this._parserFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, newSet, newMask, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(FormatFeature feature) {
/*  580 */     if (feature instanceof JsonReadFeature) {
/*  581 */       return _withJsonReadFeatures(new FormatFeature[] { feature });
/*      */     }
/*  583 */     int newSet = this._formatReadFeatures | feature.getMask();
/*  584 */     int newMask = this._formatReadFeaturesToChange | feature.getMask();
/*  585 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withFeatures(FormatFeature... features) {
/*  600 */     if (features.length > 0 && features[0] instanceof JsonReadFeature) {
/*  601 */       return _withJsonReadFeatures(features);
/*      */     }
/*  603 */     int newSet = this._formatReadFeatures;
/*  604 */     int newMask = this._formatReadFeaturesToChange;
/*  605 */     for (FormatFeature f : features) {
/*  606 */       int mask = f.getMask();
/*  607 */       newSet |= mask;
/*  608 */       newMask |= mask;
/*      */     } 
/*  610 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig without(FormatFeature feature) {
/*  625 */     if (feature instanceof JsonReadFeature) {
/*  626 */       return _withoutJsonReadFeatures(new FormatFeature[] { feature });
/*      */     }
/*  628 */     int newSet = this._formatReadFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/*  629 */     int newMask = this._formatReadFeaturesToChange | feature.getMask();
/*  630 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withoutFeatures(FormatFeature... features) {
/*  645 */     if (features.length > 0 && features[0] instanceof JsonReadFeature) {
/*  646 */       return _withoutJsonReadFeatures(features);
/*      */     }
/*  648 */     int newSet = this._formatReadFeatures;
/*  649 */     int newMask = this._formatReadFeaturesToChange;
/*  650 */     for (FormatFeature f : features) {
/*  651 */       int mask = f.getMask();
/*  652 */       newSet &= mask ^ 0xFFFFFFFF;
/*  653 */       newMask |= mask;
/*      */     } 
/*  655 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig _withJsonReadFeatures(FormatFeature... features) {
/*  663 */     int parserSet = this._parserFeatures;
/*  664 */     int parserMask = this._parserFeaturesToChange;
/*  665 */     int newSet = this._formatReadFeatures;
/*  666 */     int newMask = this._formatReadFeaturesToChange;
/*  667 */     for (FormatFeature f : features) {
/*  668 */       int mask = f.getMask();
/*  669 */       newSet |= mask;
/*  670 */       newMask |= mask;
/*      */       
/*  672 */       if (f instanceof JsonReadFeature) {
/*  673 */         JsonParser.Feature oldF = ((JsonReadFeature)f).mappedFeature();
/*  674 */         if (oldF != null) {
/*  675 */           int pmask = oldF.getMask();
/*  676 */           parserSet |= pmask;
/*  677 */           parserMask |= pmask;
/*      */         } 
/*      */       } 
/*      */     } 
/*  681 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask && this._parserFeatures == parserSet && this._parserFeaturesToChange == parserMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, parserSet, parserMask, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig _withoutJsonReadFeatures(FormatFeature... features) {
/*  690 */     int parserSet = this._parserFeatures;
/*  691 */     int parserMask = this._parserFeaturesToChange;
/*  692 */     int newSet = this._formatReadFeatures;
/*  693 */     int newMask = this._formatReadFeaturesToChange;
/*  694 */     for (FormatFeature f : features) {
/*  695 */       int mask = f.getMask();
/*  696 */       newSet &= mask ^ 0xFFFFFFFF;
/*  697 */       newMask |= mask;
/*      */       
/*  699 */       if (f instanceof JsonReadFeature) {
/*  700 */         JsonParser.Feature oldF = ((JsonReadFeature)f).mappedFeature();
/*  701 */         if (oldF != null) {
/*  702 */           int pmask = oldF.getMask();
/*  703 */           parserSet &= pmask ^ 0xFFFFFFFF;
/*  704 */           parserMask |= pmask;
/*      */         } 
/*      */       } 
/*      */     } 
/*  708 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask && this._parserFeatures == parserSet && this._parserFeaturesToChange == parserMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, parserSet, parserMask, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(JsonNodeFactory f) {
/*  726 */     if (this._nodeFactory == f) {
/*  727 */       return this;
/*      */     }
/*  729 */     return new DeserializationConfig(this, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(ConstructorDetector ctorDetector) {
/*  736 */     if (this._ctorDetector == ctorDetector) {
/*  737 */       return this;
/*      */     }
/*  739 */     return new DeserializationConfig(this, ctorDetector);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withHandler(DeserializationProblemHandler h) {
/*  749 */     if (LinkedNode.contains(this._problemHandlers, h)) {
/*  750 */       return this;
/*      */     }
/*  752 */     return new DeserializationConfig(this, new LinkedNode(h, this._problemHandlers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withNoProblemHandlers() {
/*  761 */     if (this._problemHandlers == null) {
/*  762 */       return this;
/*      */     }
/*  764 */     return new DeserializationConfig(this, (LinkedNode<DeserializationProblemHandler>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser initialize(JsonParser p) {
/*  782 */     if (this._parserFeaturesToChange != 0) {
/*  783 */       p.overrideStdFeatures(this._parserFeatures, this._parserFeaturesToChange);
/*      */     }
/*  785 */     if (this._formatReadFeaturesToChange != 0) {
/*  786 */       p.overrideFormatFeatures(this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */     }
/*  788 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser initialize(JsonParser p, FormatSchema schema) {
/*  795 */     if (this._parserFeaturesToChange != 0) {
/*  796 */       p.overrideStdFeatures(this._parserFeatures, this._parserFeaturesToChange);
/*      */     }
/*  798 */     if (this._formatReadFeaturesToChange != 0) {
/*  799 */       p.overrideFormatFeatures(this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */     }
/*  801 */     if (schema != null) {
/*  802 */       p.setSchema(schema);
/*      */     }
/*  804 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean useRootWrapping() {
/*  816 */     if (this._rootName != null) {
/*  817 */       return !this._rootName.isEmpty();
/*      */     }
/*  819 */     return isEnabled(DeserializationFeature.UNWRAP_ROOT_VALUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DeserializationFeature feature) {
/*  831 */     return ((this._deserFeatures & feature.getMask()) != 0);
/*      */   }
/*      */   
/*      */   public final boolean isEnabled(JsonParser.Feature f, JsonFactory factory) {
/*  835 */     int mask = f.getMask();
/*  836 */     if ((this._parserFeaturesToChange & mask) != 0) {
/*  837 */       return ((this._parserFeatures & f.getMask()) != 0);
/*      */     }
/*  839 */     return factory.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasDeserializationFeatures(int featureMask) {
/*  849 */     return ((this._deserFeatures & featureMask) == featureMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasSomeOfFeatures(int featureMask) {
/*  859 */     return ((this._deserFeatures & featureMask) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getDeserializationFeatures() {
/*  867 */     return this._deserFeatures;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean requiresFullValue() {
/*  879 */     return DeserializationFeature.FAIL_ON_TRAILING_TOKENS.enabledIn(this._deserFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DatatypeFeature feature) {
/*  893 */     return this._datatypeFeatures.isEnabled(feature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LinkedNode<DeserializationProblemHandler> getProblemHandlers() {
/*  907 */     return this._problemHandlers;
/*      */   }
/*      */   
/*      */   public final JsonNodeFactory getNodeFactory() {
/*  911 */     return this._nodeFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstructorDetector getConstructorDetector() {
/*  918 */     if (this._ctorDetector == null) {
/*  919 */       return ConstructorDetector.DEFAULT;
/*      */     }
/*  921 */     return this._ctorDetector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDescription introspect(JavaType type) {
/*  937 */     return getClassIntrospector().forDeserialization(this, type, (ClassIntrospector.MixInResolver)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDescription introspectForCreation(JavaType type) {
/*  945 */     return getClassIntrospector().forCreation(this, type, (ClassIntrospector.MixInResolver)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDescription introspectForBuilder(JavaType builderType, BeanDescription valueTypeDesc) {
/*  952 */     return getClassIntrospector().forDeserializationWithBuilder(this, builderType, (ClassIntrospector.MixInResolver)this, valueTypeDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BeanDescription introspectForBuilder(JavaType type) {
/*  962 */     return getClassIntrospector().forDeserializationWithBuilder(this, type, (ClassIntrospector.MixInResolver)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeserializer findTypeDeserializer(JavaType baseType) throws JsonMappingException {
/*  981 */     BeanDescription bean = introspectClassAnnotations(baseType.getRawClass());
/*  982 */     AnnotatedClass ac = bean.getClassInfo();
/*  983 */     TypeResolverBuilder<?> b = getAnnotationIntrospector().findTypeResolver((MapperConfig<?>)this, ac, baseType);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  988 */     Collection<NamedType> subtypes = null;
/*  989 */     if (b == null) {
/*  990 */       b = getDefaultTyper(baseType);
/*  991 */       if (b == null) {
/*  992 */         return null;
/*      */       }
/*      */     } else {
/*  995 */       subtypes = getSubtypeResolver().collectAndResolveSubtypesByTypeId((MapperConfig)this, ac);
/*      */     } 
/*  997 */     return b.buildTypeDeserializer(this, baseType, subtypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoercionAction findCoercionAction(LogicalType targetType, Class<?> targetClass, CoercionInputShape inputShape) {
/* 1021 */     return this._coercionConfigs.findCoercion(this, targetType, targetClass, inputShape);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoercionAction findCoercionFromBlankString(LogicalType targetType, Class<?> targetClass, CoercionAction actionIfBlankNotAllowed) {
/* 1045 */     return this._coercionConfigs.findCoercionFromBlankString(this, targetType, targetClass, actionIfBlankNotAllowed);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\DeserializationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */