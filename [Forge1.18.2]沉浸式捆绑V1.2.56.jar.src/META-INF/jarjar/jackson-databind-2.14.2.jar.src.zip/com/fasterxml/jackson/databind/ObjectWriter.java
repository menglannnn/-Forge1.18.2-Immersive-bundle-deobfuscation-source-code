/*      */ package com.fasterxml.jackson.databind;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.FormatFeature;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JsonEncoding;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.PrettyPrinter;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamWriteFeature;
/*      */ import com.fasterxml.jackson.core.exc.StreamWriteException;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.SegmentedStringWriter;
/*      */ import com.fasterxml.jackson.core.io.SerializedString;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.Instantiatable;
/*      */ import com.fasterxml.jackson.core.util.MinimalPrettyPrinter;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.DefaultSerializerProvider;
/*      */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerFactory;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.Writer;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ public class ObjectWriter implements Versioned, Serializable {
/*   44 */   protected static final PrettyPrinter NULL_PRETTY_PRINTER = (PrettyPrinter)new MinimalPrettyPrinter();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializationConfig _config;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DefaultSerializerProvider _serializerProvider;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializerFactory _serializerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonFactory _generatorFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final GeneratorSettings _generatorSettings;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Prefetch _prefetch;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config, JavaType rootType, PrettyPrinter pp) {
/*  102 */     this._config = config;
/*  103 */     this._serializerProvider = mapper._serializerProvider;
/*  104 */     this._serializerFactory = mapper._serializerFactory;
/*  105 */     this._generatorFactory = mapper._jsonFactory;
/*  106 */     this._generatorSettings = (pp == null) ? GeneratorSettings.empty : new GeneratorSettings(pp, null, null, null);
/*      */ 
/*      */     
/*  109 */     if (rootType == null) {
/*  110 */       this._prefetch = Prefetch.empty;
/*  111 */     } else if (rootType.hasRawClass(Object.class)) {
/*      */ 
/*      */       
/*  114 */       this._prefetch = Prefetch.empty.forRootType(this, rootType);
/*      */     } else {
/*  116 */       this._prefetch = Prefetch.empty.forRootType(this, rootType.withStaticTyping());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config) {
/*  125 */     this._config = config;
/*  126 */     this._serializerProvider = mapper._serializerProvider;
/*  127 */     this._serializerFactory = mapper._serializerFactory;
/*  128 */     this._generatorFactory = mapper._jsonFactory;
/*      */     
/*  130 */     this._generatorSettings = GeneratorSettings.empty;
/*  131 */     this._prefetch = Prefetch.empty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config, FormatSchema s) {
/*  140 */     this._config = config;
/*      */     
/*  142 */     this._serializerProvider = mapper._serializerProvider;
/*  143 */     this._serializerFactory = mapper._serializerFactory;
/*  144 */     this._generatorFactory = mapper._jsonFactory;
/*      */     
/*  146 */     this._generatorSettings = (s == null) ? GeneratorSettings.empty : new GeneratorSettings(null, s, null, null);
/*      */     
/*  148 */     this._prefetch = Prefetch.empty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter(ObjectWriter base, SerializationConfig config, GeneratorSettings genSettings, Prefetch prefetch) {
/*  157 */     this._config = config;
/*      */     
/*  159 */     this._serializerProvider = base._serializerProvider;
/*  160 */     this._serializerFactory = base._serializerFactory;
/*  161 */     this._generatorFactory = base._generatorFactory;
/*      */     
/*  163 */     this._generatorSettings = genSettings;
/*  164 */     this._prefetch = prefetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter(ObjectWriter base, SerializationConfig config) {
/*  172 */     this._config = config;
/*      */     
/*  174 */     this._serializerProvider = base._serializerProvider;
/*  175 */     this._serializerFactory = base._serializerFactory;
/*  176 */     this._generatorFactory = base._generatorFactory;
/*      */     
/*  178 */     this._generatorSettings = base._generatorSettings;
/*  179 */     this._prefetch = base._prefetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter(ObjectWriter base, JsonFactory f) {
/*  188 */     this
/*  189 */       ._config = (SerializationConfig)base._config.with(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, f.requiresPropertyOrdering());
/*      */     
/*  191 */     this._serializerProvider = base._serializerProvider;
/*  192 */     this._serializerFactory = base._serializerFactory;
/*  193 */     this._generatorFactory = f;
/*      */     
/*  195 */     this._generatorSettings = base._generatorSettings;
/*  196 */     this._prefetch = base._prefetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  205 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _new(ObjectWriter base, JsonFactory f) {
/*  220 */     return new ObjectWriter(base, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _new(ObjectWriter base, SerializationConfig config) {
/*  229 */     if (config == this._config) {
/*  230 */       return this;
/*      */     }
/*  232 */     return new ObjectWriter(base, config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _new(GeneratorSettings genSettings, Prefetch prefetch) {
/*  243 */     if (this._generatorSettings == genSettings && this._prefetch == prefetch) {
/*  244 */       return this;
/*      */     }
/*  246 */     return new ObjectWriter(this, this._config, genSettings, prefetch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SequenceWriter _newSequenceWriter(boolean wrapInArray, JsonGenerator gen, boolean managedInput) throws IOException {
/*  260 */     return (new SequenceWriter(_serializerProvider(), 
/*  261 */         _configureGenerator(gen), managedInput, this._prefetch))
/*  262 */       .init(wrapInArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(SerializationFeature feature) {
/*  276 */     return _new(this, this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(SerializationFeature first, SerializationFeature... other) {
/*  284 */     return _new(this, this._config.with(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withFeatures(SerializationFeature... features) {
/*  292 */     return _new(this, this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter without(SerializationFeature feature) {
/*  300 */     return _new(this, this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter without(SerializationFeature first, SerializationFeature... other) {
/*  308 */     return _new(this, this._config.without(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withoutFeatures(SerializationFeature... features) {
/*  316 */     return _new(this, this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(DatatypeFeature feature) {
/*  332 */     return _new(this, (SerializationConfig)this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withFeatures(DatatypeFeature... features) {
/*  342 */     return _new(this, (SerializationConfig)this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter without(DatatypeFeature feature) {
/*  352 */     return _new(this, (SerializationConfig)this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withoutFeatures(DatatypeFeature... features) {
/*  362 */     return _new(this, (SerializationConfig)this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(JsonGenerator.Feature feature) {
/*  375 */     return _new(this, this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withFeatures(JsonGenerator.Feature... features) {
/*  382 */     return _new(this, this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter without(JsonGenerator.Feature feature) {
/*  389 */     return _new(this, this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withoutFeatures(JsonGenerator.Feature... features) {
/*  396 */     return _new(this, this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(StreamWriteFeature feature) {
/*  409 */     return _new(this, this._config.with(feature.mappedFeature()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter without(StreamWriteFeature feature) {
/*  416 */     return _new(this, this._config.without(feature.mappedFeature()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(FormatFeature feature) {
/*  429 */     return _new(this, this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withFeatures(FormatFeature... features) {
/*  436 */     return _new(this, this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter without(FormatFeature feature) {
/*  443 */     return _new(this, this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withoutFeatures(FormatFeature... features) {
/*  450 */     return _new(this, this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter forType(JavaType rootType) {
/*  470 */     return _new(this._generatorSettings, this._prefetch.forRootType(this, rootType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter forType(Class<?> rootType) {
/*  481 */     return forType(this._config.constructType(rootType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter forType(TypeReference<?> rootType) {
/*  492 */     return forType(this._config.getTypeFactory().constructType(rootType.getType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter withType(JavaType rootType) {
/*  500 */     return forType(rootType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter withType(Class<?> rootType) {
/*  508 */     return forType(rootType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter withType(TypeReference<?> rootType) {
/*  516 */     return forType(rootType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(DateFormat df) {
/*  534 */     return _new(this, this._config.with(df));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withDefaultPrettyPrinter() {
/*  542 */     return with(this._config.getDefaultPrettyPrinter());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(FilterProvider filterProvider) {
/*  550 */     if (filterProvider == this._config.getFilterProvider()) {
/*  551 */       return this;
/*      */     }
/*  553 */     return _new(this, this._config.withFilters(filterProvider));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(PrettyPrinter pp) {
/*  561 */     return _new(this._generatorSettings.with(pp), this._prefetch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withRootName(String rootName) {
/*  576 */     return _new(this, (SerializationConfig)this._config.withRootName(rootName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withRootName(PropertyName rootName) {
/*  583 */     return _new(this, this._config.withRootName(rootName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withoutRootName() {
/*  597 */     return _new(this, this._config.withRootName(PropertyName.NO_NAME));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(FormatSchema schema) {
/*  608 */     _verifySchemaType(schema);
/*  609 */     return _new(this._generatorSettings.with(schema), this._prefetch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter withSchema(FormatSchema schema) {
/*  617 */     return with(schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withView(Class<?> view) {
/*  629 */     return _new(this, this._config.withView(view));
/*      */   }
/*      */   
/*      */   public ObjectWriter with(Locale l) {
/*  633 */     return _new(this, (SerializationConfig)this._config.with(l));
/*      */   }
/*      */   
/*      */   public ObjectWriter with(TimeZone tz) {
/*  637 */     return _new(this, (SerializationConfig)this._config.with(tz));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(Base64Variant b64variant) {
/*  647 */     return _new(this, (SerializationConfig)this._config.with(b64variant));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(CharacterEscapes escapes) {
/*  654 */     return _new(this._generatorSettings.with(escapes), this._prefetch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(JsonFactory f) {
/*  661 */     return (f == this._generatorFactory) ? this : _new(this, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter with(ContextAttributes attrs) {
/*  668 */     return _new(this, this._config.with(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withAttributes(Map<?, ?> attrs) {
/*  678 */     return _new(this, (SerializationConfig)this._config.withAttributes(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withAttribute(Object key, Object value) {
/*  685 */     return _new(this, (SerializationConfig)this._config.withAttribute(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withoutAttribute(Object key) {
/*  692 */     return _new(this, (SerializationConfig)this._config.withoutAttribute(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withRootValueSeparator(String sep) {
/*  699 */     return _new(this._generatorSettings.withRootValueSeparator(sep), this._prefetch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter withRootValueSeparator(SerializableString sep) {
/*  706 */     return _new(this._generatorSettings.withRootValueSeparator(sep), this._prefetch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out) throws IOException {
/*  724 */     _assertNotNull("out", out);
/*  725 */     return _configureGenerator(this._generatorFactory.createGenerator(out, JsonEncoding.UTF8));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/*  737 */     _assertNotNull("out", out);
/*  738 */     return _configureGenerator(this._generatorFactory.createGenerator(out, enc));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(Writer w) throws IOException {
/*  750 */     _assertNotNull("w", w);
/*  751 */     return _configureGenerator(this._generatorFactory.createGenerator(w));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(File outputFile, JsonEncoding enc) throws IOException {
/*  763 */     _assertNotNull("outputFile", outputFile);
/*  764 */     return _configureGenerator(this._generatorFactory.createGenerator(outputFile, enc));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out) throws IOException {
/*  776 */     _assertNotNull("out", out);
/*  777 */     return _configureGenerator(this._generatorFactory.createGenerator(out));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValues(File out) throws IOException {
/*  800 */     return _newSequenceWriter(false, createGenerator(out, JsonEncoding.UTF8), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValues(JsonGenerator g) throws IOException {
/*  819 */     _assertNotNull("g", g);
/*  820 */     return _newSequenceWriter(false, _configureGenerator(g), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValues(Writer out) throws IOException {
/*  837 */     return _newSequenceWriter(false, createGenerator(out), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValues(OutputStream out) throws IOException {
/*  854 */     return _newSequenceWriter(false, createGenerator(out, JsonEncoding.UTF8), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValues(DataOutput out) throws IOException {
/*  861 */     return _newSequenceWriter(false, createGenerator(out), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValuesAsArray(File out) throws IOException {
/*  880 */     return _newSequenceWriter(true, createGenerator(out, JsonEncoding.UTF8), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValuesAsArray(JsonGenerator gen) throws IOException {
/*  900 */     _assertNotNull("gen", gen);
/*  901 */     return _newSequenceWriter(true, gen, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValuesAsArray(Writer out) throws IOException {
/*  920 */     return _newSequenceWriter(true, createGenerator(out), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValuesAsArray(OutputStream out) throws IOException {
/*  939 */     return _newSequenceWriter(true, createGenerator(out, JsonEncoding.UTF8), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SequenceWriter writeValuesAsArray(DataOutput out) throws IOException {
/*  946 */     return _newSequenceWriter(true, createGenerator(out), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(SerializationFeature f) {
/*  956 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */   public boolean isEnabled(MapperFeature f) {
/*  960 */     return this._config.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(DatatypeFeature f) {
/*  967 */     return this._config.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isEnabled(JsonParser.Feature f) {
/*  975 */     return this._generatorFactory.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonGenerator.Feature f) {
/*  982 */     return this._generatorFactory.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamWriteFeature f) {
/*  989 */     return this._generatorFactory.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializationConfig getConfig() {
/*  996 */     return this._config;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory getFactory() {
/* 1003 */     return this._generatorFactory;
/*      */   }
/*      */   
/*      */   public TypeFactory getTypeFactory() {
/* 1007 */     return this._config.getTypeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasPrefetchedSerializer() {
/* 1019 */     return this._prefetch.hasSerializer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextAttributes getAttributes() {
/* 1026 */     return this._config.getAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(JsonGenerator g, Object value) throws IOException {
/* 1044 */     _assertNotNull("g", g);
/* 1045 */     _configureGenerator(g);
/* 1046 */     if (this._config.isEnabled(SerializationFeature.CLOSE_CLOSEABLE) && value instanceof Closeable) {
/*      */ 
/*      */       
/* 1049 */       Closeable toClose = (Closeable)value;
/*      */       try {
/* 1051 */         this._prefetch.serialize(g, value, _serializerProvider());
/* 1052 */         if (this._config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 1053 */           g.flush();
/*      */         }
/* 1055 */       } catch (Exception e) {
/* 1056 */         ClassUtil.closeOnFailAndThrowAsIOE(null, toClose, e);
/*      */         return;
/*      */       } 
/* 1059 */       toClose.close();
/*      */     } else {
/* 1061 */       this._prefetch.serialize(g, value, _serializerProvider());
/* 1062 */       if (this._config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 1063 */         g.flush();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(File resultFile, Object value) throws IOException, StreamWriteException, DatabindException {
/* 1081 */     _writeValueAndClose(createGenerator(resultFile, JsonEncoding.UTF8), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(OutputStream out, Object value) throws IOException, StreamWriteException, DatabindException {
/* 1098 */     _writeValueAndClose(createGenerator(out, JsonEncoding.UTF8), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(Writer w, Object value) throws IOException, StreamWriteException, DatabindException {
/* 1114 */     _writeValueAndClose(createGenerator(w), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(DataOutput out, Object value) throws IOException, StreamWriteException, DatabindException {
/* 1123 */     _writeValueAndClose(createGenerator(out), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String writeValueAsString(Object value) throws JsonProcessingException {
/* 1138 */     SegmentedStringWriter sw = new SegmentedStringWriter(this._generatorFactory._getBufferRecycler());
/*      */     try {
/* 1140 */       _writeValueAndClose(createGenerator((Writer)sw), value);
/* 1141 */     } catch (JsonProcessingException e) {
/* 1142 */       throw e;
/* 1143 */     } catch (IOException e) {
/* 1144 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/* 1146 */     return sw.getAndClear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] writeValueAsBytes(Object value) throws JsonProcessingException {
/* 1162 */     try (ByteArrayBuilder bb = new ByteArrayBuilder(this._generatorFactory._getBufferRecycler())) {
/* 1163 */       _writeValueAndClose(createGenerator((OutputStream)bb, JsonEncoding.UTF8), value);
/* 1164 */       byte[] result = bb.toByteArray();
/* 1165 */       bb.release();
/* 1166 */       return result;
/* 1167 */     } catch (JsonProcessingException e) {
/* 1168 */       throw e;
/* 1169 */     } catch (IOException e) {
/* 1170 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptJsonFormatVisitor(JavaType type, JsonFormatVisitorWrapper visitor) throws JsonMappingException {
/* 1195 */     _assertNotNull("type", type);
/* 1196 */     _assertNotNull("visitor", visitor);
/* 1197 */     _serializerProvider().acceptJsonFormatVisitor(type, visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptJsonFormatVisitor(Class<?> type, JsonFormatVisitorWrapper visitor) throws JsonMappingException {
/* 1206 */     _assertNotNull("type", type);
/* 1207 */     _assertNotNull("visitor", visitor);
/* 1208 */     acceptJsonFormatVisitor(this._config.constructType(type), visitor);
/*      */   }
/*      */   
/*      */   public boolean canSerialize(Class<?> type) {
/* 1212 */     _assertNotNull("type", type);
/* 1213 */     return _serializerProvider().hasSerializerFor(type, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canSerialize(Class<?> type, AtomicReference<Throwable> cause) {
/* 1223 */     _assertNotNull("type", type);
/* 1224 */     return _serializerProvider().hasSerializerFor(type, cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultSerializerProvider _serializerProvider() {
/* 1238 */     return this._serializerProvider.createInstance(this._config, this._serializerFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _verifySchemaType(FormatSchema schema) {
/* 1252 */     if (schema != null && 
/* 1253 */       !this._generatorFactory.canUseSchema(schema)) {
/* 1254 */       throw new IllegalArgumentException("Cannot use FormatSchema of type " + schema.getClass().getName() + " for format " + this._generatorFactory
/* 1255 */           .getFormatName());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writeValueAndClose(JsonGenerator gen, Object value) throws IOException {
/* 1268 */     if (this._config.isEnabled(SerializationFeature.CLOSE_CLOSEABLE) && value instanceof Closeable) {
/* 1269 */       _writeCloseable(gen, value);
/*      */       return;
/*      */     } 
/*      */     try {
/* 1273 */       this._prefetch.serialize(gen, value, _serializerProvider());
/* 1274 */     } catch (Exception e) {
/* 1275 */       ClassUtil.closeOnFailAndThrowAsIOE(gen, e);
/*      */       return;
/*      */     } 
/* 1278 */     gen.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCloseable(JsonGenerator gen, Object value) throws IOException {
/* 1288 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 1290 */       this._prefetch.serialize(gen, value, _serializerProvider());
/* 1291 */       Closeable tmpToClose = toClose;
/* 1292 */       toClose = null;
/* 1293 */       tmpToClose.close();
/* 1294 */     } catch (Exception e) {
/* 1295 */       ClassUtil.closeOnFailAndThrowAsIOE(gen, toClose, e);
/*      */       return;
/*      */     } 
/* 1298 */     gen.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonGenerator _configureGenerator(JsonGenerator gen) {
/* 1311 */     this._config.initialize(gen);
/* 1312 */     this._generatorSettings.initialize(gen);
/* 1313 */     return gen;
/*      */   }
/*      */   
/*      */   protected final void _assertNotNull(String paramName, Object src) {
/* 1317 */     if (src == null) {
/* 1318 */       throw new IllegalArgumentException(String.format("argument \"%s\" is null", new Object[] { paramName }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class GeneratorSettings
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1340 */     public static final GeneratorSettings empty = new GeneratorSettings(null, null, null, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final PrettyPrinter prettyPrinter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final FormatSchema schema;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final CharacterEscapes characterEscapes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final SerializableString rootValueSeparator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public GeneratorSettings(PrettyPrinter pp, FormatSchema sch, CharacterEscapes esc, SerializableString rootSep) {
/* 1371 */       this.prettyPrinter = pp;
/* 1372 */       this.schema = sch;
/* 1373 */       this.characterEscapes = esc;
/* 1374 */       this.rootValueSeparator = rootSep;
/*      */     }
/*      */ 
/*      */     
/*      */     public GeneratorSettings with(PrettyPrinter pp) {
/* 1379 */       if (pp == null) {
/* 1380 */         pp = ObjectWriter.NULL_PRETTY_PRINTER;
/*      */       }
/* 1382 */       return (pp == this.prettyPrinter) ? this : new GeneratorSettings(pp, this.schema, this.characterEscapes, this.rootValueSeparator);
/*      */     }
/*      */ 
/*      */     
/*      */     public GeneratorSettings with(FormatSchema sch) {
/* 1387 */       return (this.schema == sch) ? this : new GeneratorSettings(this.prettyPrinter, sch, this.characterEscapes, this.rootValueSeparator);
/*      */     }
/*      */ 
/*      */     
/*      */     public GeneratorSettings with(CharacterEscapes esc) {
/* 1392 */       return (this.characterEscapes == esc) ? this : new GeneratorSettings(this.prettyPrinter, this.schema, esc, this.rootValueSeparator);
/*      */     }
/*      */ 
/*      */     
/*      */     public GeneratorSettings withRootValueSeparator(String sep) {
/* 1397 */       if (sep == null) {
/* 1398 */         if (this.rootValueSeparator == null) {
/* 1399 */           return this;
/*      */         }
/* 1401 */         return new GeneratorSettings(this.prettyPrinter, this.schema, this.characterEscapes, null);
/*      */       } 
/* 1403 */       if (sep.equals(_rootValueSeparatorAsString())) {
/* 1404 */         return this;
/*      */       }
/* 1406 */       return new GeneratorSettings(this.prettyPrinter, this.schema, this.characterEscapes, (SerializableString)new SerializedString(sep));
/*      */     }
/*      */ 
/*      */     
/*      */     public GeneratorSettings withRootValueSeparator(SerializableString sep) {
/* 1411 */       if (sep == null) {
/* 1412 */         if (this.rootValueSeparator == null) {
/* 1413 */           return this;
/*      */         }
/* 1415 */         return new GeneratorSettings(this.prettyPrinter, this.schema, this.characterEscapes, null);
/*      */       } 
/* 1417 */       if (sep.equals(this.rootValueSeparator)) {
/* 1418 */         return this;
/*      */       }
/* 1420 */       return new GeneratorSettings(this.prettyPrinter, this.schema, this.characterEscapes, sep);
/*      */     }
/*      */     
/*      */     private final String _rootValueSeparatorAsString() {
/* 1424 */       return (this.rootValueSeparator == null) ? null : this.rootValueSeparator.getValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void initialize(JsonGenerator gen) {
/* 1432 */       PrettyPrinter pp = this.prettyPrinter;
/* 1433 */       if (this.prettyPrinter != null) {
/* 1434 */         if (pp == ObjectWriter.NULL_PRETTY_PRINTER) {
/* 1435 */           gen.setPrettyPrinter(null);
/*      */         } else {
/* 1437 */           if (pp instanceof Instantiatable) {
/* 1438 */             pp = (PrettyPrinter)((Instantiatable)pp).createInstance();
/*      */           }
/* 1440 */           gen.setPrettyPrinter(pp);
/*      */         } 
/*      */       }
/* 1443 */       if (this.characterEscapes != null) {
/* 1444 */         gen.setCharacterEscapes(this.characterEscapes);
/*      */       }
/* 1446 */       if (this.schema != null) {
/* 1447 */         gen.setSchema(this.schema);
/*      */       }
/* 1449 */       if (this.rootValueSeparator != null) {
/* 1450 */         gen.setRootValueSeparator(this.rootValueSeparator);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Prefetch
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1467 */     public static final Prefetch empty = new Prefetch(null, null, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final JavaType rootType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final JsonSerializer<Object> valueSerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeSerializer typeSerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Prefetch(JavaType rootT, JsonSerializer<Object> ser, TypeSerializer typeSer) {
/* 1493 */       this.rootType = rootT;
/* 1494 */       this.valueSerializer = ser;
/* 1495 */       this.typeSerializer = typeSer;
/*      */     }
/*      */ 
/*      */     
/*      */     public Prefetch forRootType(ObjectWriter parent, JavaType newType) {
/* 1500 */       if (newType == null) {
/* 1501 */         if (this.rootType == null || this.valueSerializer == null) {
/* 1502 */           return this;
/*      */         }
/* 1504 */         return new Prefetch(null, null, null);
/*      */       } 
/*      */ 
/*      */       
/* 1508 */       if (newType.equals(this.rootType)) {
/* 1509 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1514 */       if (newType.isJavaLangObject()) {
/* 1515 */         TypeSerializer typeSer; DefaultSerializerProvider prov = parent._serializerProvider();
/*      */ 
/*      */         
/*      */         try {
/* 1519 */           typeSer = prov.findTypeSerializer(newType);
/* 1520 */         } catch (JsonMappingException e) {
/*      */ 
/*      */           
/* 1523 */           throw new RuntimeJsonMappingException(e);
/*      */         } 
/* 1525 */         return new Prefetch(null, null, typeSer);
/*      */       } 
/*      */       
/* 1528 */       if (parent.isEnabled(SerializationFeature.EAGER_SERIALIZER_FETCH)) {
/* 1529 */         DefaultSerializerProvider prov = parent._serializerProvider();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1535 */           JsonSerializer<Object> ser = prov.findTypedValueSerializer(newType, true, null);
/*      */           
/* 1537 */           if (ser instanceof TypeWrappedSerializer) {
/* 1538 */             return new Prefetch(newType, null, ((TypeWrappedSerializer)ser)
/* 1539 */                 .typeSerializer());
/*      */           }
/* 1541 */           return new Prefetch(newType, ser, null);
/* 1542 */         } catch (DatabindException typeSer) {}
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1547 */       return new Prefetch(newType, null, this.typeSerializer);
/*      */     }
/*      */     
/*      */     public final JsonSerializer<Object> getValueSerializer() {
/* 1551 */       return this.valueSerializer;
/*      */     }
/*      */     
/*      */     public final TypeSerializer getTypeSerializer() {
/* 1555 */       return this.typeSerializer;
/*      */     }
/*      */     
/*      */     public boolean hasSerializer() {
/* 1559 */       return (this.valueSerializer != null || this.typeSerializer != null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void serialize(JsonGenerator gen, Object value, DefaultSerializerProvider prov) throws IOException {
/* 1565 */       if (this.typeSerializer != null) {
/* 1566 */         prov.serializePolymorphic(gen, value, this.rootType, this.valueSerializer, this.typeSerializer);
/* 1567 */       } else if (this.valueSerializer != null) {
/* 1568 */         prov.serializeValue(gen, value, this.rootType, this.valueSerializer);
/* 1569 */       } else if (this.rootType != null) {
/* 1570 */         prov.serializeValue(gen, value, this.rootType);
/*      */       } else {
/* 1572 */         prov.serializeValue(gen, value);
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ObjectWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */