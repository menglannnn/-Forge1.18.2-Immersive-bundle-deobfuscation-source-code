/*    */ package com.fasterxml.jackson.databind.ser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.SerializationFeature;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import com.fasterxml.jackson.databind.ser.std.ToEmptyObjectSerializer;
/*    */ import com.fasterxml.jackson.databind.util.NativeImageUtil;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ public class UnknownSerializer
/*    */   extends ToEmptyObjectSerializer
/*    */ {
/*    */   public UnknownSerializer() {
/* 17 */     super(Object.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public UnknownSerializer(Class<?> cls) {
/* 22 */     super(cls);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(Object value, JsonGenerator gen, SerializerProvider ctxt) throws IOException {
/* 29 */     if (ctxt.isEnabled(SerializationFeature.FAIL_ON_EMPTY_BEANS)) {
/* 30 */       failForEmpty(ctxt, value);
/*    */     }
/* 32 */     super.serialize(value, gen, ctxt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeWithType(Object value, JsonGenerator gen, SerializerProvider ctxt, TypeSerializer typeSer) throws IOException {
/* 39 */     if (ctxt.isEnabled(SerializationFeature.FAIL_ON_EMPTY_BEANS)) {
/* 40 */       failForEmpty(ctxt, value);
/*    */     }
/* 42 */     super.serializeWithType(value, gen, ctxt, typeSer);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void failForEmpty(SerializerProvider prov, Object value) throws JsonMappingException {
/* 47 */     Class<?> cl = value.getClass();
/* 48 */     if (NativeImageUtil.needsReflectionConfiguration(cl)) {
/* 49 */       prov.reportBadDefinition(handledType(), String.format("No serializer found for class %s and no properties discovered to create BeanSerializer (to avoid exception, disable SerializationFeature.FAIL_ON_EMPTY_BEANS). This appears to be a native image, in which case you may need to configure reflection for the class that is to be serialized", new Object[] { cl
/*    */               
/* 51 */               .getName() }));
/*    */     } else {
/* 53 */       prov.reportBadDefinition(handledType(), String.format("No serializer found for class %s and no properties discovered to create BeanSerializer (to avoid exception, disable SerializationFeature.FAIL_ON_EMPTY_BEANS)", new Object[] { cl
/*    */               
/* 55 */               .getName() }));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ser\impl\UnknownSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */