/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonSetter;
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*     */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*     */ import java.io.Serializable;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public abstract class MapperConfigBase<CFG extends ConfigFeature, T extends MapperConfigBase<CFG, T>> extends MapperConfig<T> implements Serializable {
/*  32 */   protected static final ConfigOverride EMPTY_OVERRIDE = ConfigOverride.empty();
/*     */   
/*  34 */   private static final long DEFAULT_MAPPER_FEATURES = MapperFeature.collectLongDefaults();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private static final long AUTO_DETECT_MASK = MapperFeature.AUTO_DETECT_FIELDS
/*  40 */     .getLongMask() | MapperFeature.AUTO_DETECT_GETTERS
/*  41 */     .getLongMask() | MapperFeature.AUTO_DETECT_IS_GETTERS
/*  42 */     .getLongMask() | MapperFeature.AUTO_DETECT_SETTERS
/*  43 */     .getLongMask() | MapperFeature.AUTO_DETECT_CREATORS
/*  44 */     .getLongMask();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SimpleMixInResolver _mixIns;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SubtypeResolver _subtypeResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PropertyName _rootName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Class<?> _view;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ContextAttributes _attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final RootNameLookup _rootNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ConfigOverrides _configOverrides;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final DatatypeFeatures _datatypeFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides, DatatypeFeatures datatypeFeatures) {
/* 134 */     super(base, DEFAULT_MAPPER_FEATURES);
/* 135 */     this._mixIns = mixins;
/* 136 */     this._subtypeResolver = str;
/* 137 */     this._rootNames = rootNames;
/* 138 */     this._rootName = null;
/* 139 */     this._view = null;
/*     */     
/* 141 */     this._attributes = ContextAttributes.getEmpty();
/* 142 */     this._configOverrides = configOverrides;
/* 143 */     this._datatypeFeatures = datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides) {
/* 158 */     super(src, src._base.copy());
/* 159 */     this._mixIns = mixins;
/* 160 */     this._subtypeResolver = str;
/* 161 */     this._rootNames = rootNames;
/* 162 */     this._rootName = src._rootName;
/* 163 */     this._view = src._view;
/* 164 */     this._attributes = src._attributes;
/* 165 */     this._configOverrides = configOverrides;
/* 166 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src) {
/* 175 */     super(src);
/* 176 */     this._mixIns = src._mixIns;
/* 177 */     this._subtypeResolver = src._subtypeResolver;
/* 178 */     this._rootNames = src._rootNames;
/* 179 */     this._rootName = src._rootName;
/* 180 */     this._view = src._view;
/* 181 */     this._attributes = src._attributes;
/* 182 */     this._configOverrides = src._configOverrides;
/* 183 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, BaseSettings base) {
/* 188 */     super(src, base);
/* 189 */     this._mixIns = src._mixIns;
/* 190 */     this._subtypeResolver = src._subtypeResolver;
/* 191 */     this._rootNames = src._rootNames;
/* 192 */     this._rootName = src._rootName;
/* 193 */     this._view = src._view;
/* 194 */     this._attributes = src._attributes;
/* 195 */     this._configOverrides = src._configOverrides;
/* 196 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, long mapperFeatures) {
/* 201 */     super(src, mapperFeatures);
/* 202 */     this._mixIns = src._mixIns;
/* 203 */     this._subtypeResolver = src._subtypeResolver;
/* 204 */     this._rootNames = src._rootNames;
/* 205 */     this._rootName = src._rootName;
/* 206 */     this._view = src._view;
/* 207 */     this._attributes = src._attributes;
/* 208 */     this._configOverrides = src._configOverrides;
/* 209 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SubtypeResolver str) {
/* 213 */     super(src);
/* 214 */     this._mixIns = src._mixIns;
/* 215 */     this._subtypeResolver = str;
/* 216 */     this._rootNames = src._rootNames;
/* 217 */     this._rootName = src._rootName;
/* 218 */     this._view = src._view;
/* 219 */     this._attributes = src._attributes;
/* 220 */     this._configOverrides = src._configOverrides;
/* 221 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, PropertyName rootName) {
/* 225 */     super(src);
/* 226 */     this._mixIns = src._mixIns;
/* 227 */     this._subtypeResolver = src._subtypeResolver;
/* 228 */     this._rootNames = src._rootNames;
/* 229 */     this._rootName = rootName;
/* 230 */     this._view = src._view;
/* 231 */     this._attributes = src._attributes;
/* 232 */     this._configOverrides = src._configOverrides;
/* 233 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, Class<?> view) {
/* 238 */     super(src);
/* 239 */     this._mixIns = src._mixIns;
/* 240 */     this._subtypeResolver = src._subtypeResolver;
/* 241 */     this._rootNames = src._rootNames;
/* 242 */     this._rootName = src._rootName;
/* 243 */     this._view = view;
/* 244 */     this._attributes = src._attributes;
/* 245 */     this._configOverrides = src._configOverrides;
/* 246 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SimpleMixInResolver mixins) {
/* 254 */     super(src);
/* 255 */     this._mixIns = mixins;
/* 256 */     this._subtypeResolver = src._subtypeResolver;
/* 257 */     this._rootNames = src._rootNames;
/* 258 */     this._rootName = src._rootName;
/* 259 */     this._view = src._view;
/* 260 */     this._attributes = src._attributes;
/* 261 */     this._configOverrides = src._configOverrides;
/* 262 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, ContextAttributes attr) {
/* 270 */     super(src);
/* 271 */     this._mixIns = src._mixIns;
/* 272 */     this._subtypeResolver = src._subtypeResolver;
/* 273 */     this._rootNames = src._rootNames;
/* 274 */     this._rootName = src._rootName;
/* 275 */     this._view = src._view;
/* 276 */     this._attributes = attr;
/* 277 */     this._configOverrides = src._configOverrides;
/* 278 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, DatatypeFeatures datatypeFeatures) {
/* 286 */     super(src);
/* 287 */     this._mixIns = src._mixIns;
/* 288 */     this._subtypeResolver = src._subtypeResolver;
/* 289 */     this._rootNames = src._rootNames;
/* 290 */     this._rootName = src._rootName;
/* 291 */     this._view = src._view;
/* 292 */     this._attributes = src._attributes;
/* 293 */     this._configOverrides = src._configOverrides;
/* 294 */     this._datatypeFeatures = datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DatatypeFeatures _datatypeFeatures() {
/* 322 */     return this._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(MapperFeature... features) {
/* 339 */     long newMapperFlags = this._mapperFeatures;
/* 340 */     for (MapperFeature f : features) {
/* 341 */       newMapperFlags |= f.getLongMask();
/*     */     }
/* 343 */     if (newMapperFlags == this._mapperFeatures) {
/* 344 */       return (T)this;
/*     */     }
/* 346 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T without(MapperFeature... features) {
/* 357 */     long newMapperFlags = this._mapperFeatures;
/* 358 */     for (MapperFeature f : features) {
/* 359 */       newMapperFlags &= f.getLongMask() ^ 0xFFFFFFFFFFFFFFFFL;
/*     */     }
/* 361 */     if (newMapperFlags == this._mapperFeatures) {
/* 362 */       return (T)this;
/*     */     }
/* 364 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(MapperFeature feature, boolean state) {
/*     */     long newMapperFlags;
/* 372 */     if (state) {
/* 373 */       newMapperFlags = this._mapperFeatures | feature.getLongMask();
/*     */     } else {
/* 375 */       newMapperFlags = this._mapperFeatures & (feature.getLongMask() ^ 0xFFFFFFFFFFFFFFFFL);
/*     */     } 
/* 377 */     if (newMapperFlags == this._mapperFeatures) {
/* 378 */       return (T)this;
/*     */     }
/* 380 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(DatatypeFeature feature) {
/* 396 */     return _with(_datatypeFeatures().with(feature));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T withFeatures(DatatypeFeature... features) {
/* 406 */     return _with(_datatypeFeatures().withFeatures(features));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T without(DatatypeFeature feature) {
/* 416 */     return _with(_datatypeFeatures().without(feature));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T withoutFeatures(DatatypeFeature... features) {
/* 426 */     return _with(_datatypeFeatures().withoutFeatures(features));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(DatatypeFeature feature, boolean state) {
/* 436 */     DatatypeFeatures features = _datatypeFeatures();
/* 437 */     features = state ? features.with(feature) : features.without(feature);
/* 438 */     return _with(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(AnnotationIntrospector ai) {
/* 455 */     return _withBase(this._base.withAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T withAppendedAnnotationIntrospector(AnnotationIntrospector ai) {
/* 463 */     return _withBase(this._base.withAppendedAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T withInsertedAnnotationIntrospector(AnnotationIntrospector ai) {
/* 471 */     return _withBase(this._base.withInsertedAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(ClassIntrospector ci) {
/* 483 */     return _withBase(this._base.withClassIntrospector(ci));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T withAttributes(Map<?, ?> attributes) {
/* 507 */     return with(getAttributes().withSharedAttributes(attributes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T withAttribute(Object key, Object value) {
/* 517 */     return with(getAttributes().withSharedAttribute(key, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T withoutAttribute(Object key) {
/* 527 */     return with(getAttributes().withoutSharedAttribute(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(TypeFactory tf) {
/* 542 */     return _withBase(this._base.withTypeFactory(tf));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(TypeResolverBuilder<?> trb) {
/* 550 */     return _withBase(this._base.withTypeResolverBuilder(trb));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(PropertyNamingStrategy pns) {
/* 562 */     return _withBase(this._base.withPropertyNamingStrategy(pns));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(AccessorNamingStrategy.Provider p) {
/* 573 */     return _withBase(this._base.withAccessorNaming(p));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(HandlerInstantiator hi) {
/* 585 */     return _withBase(this._base.withHandlerInstantiator(hi));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(Base64Variant base64) {
/* 599 */     return _withBase(this._base.with(base64));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T with(DateFormat df) {
/* 610 */     return _withBase(this._base.withDateFormat(df));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(Locale l) {
/* 618 */     return _withBase(this._base.with(l));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(TimeZone tz) {
/* 626 */     return _withBase(this._base.with(tz));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T withRootName(String rootName) {
/* 648 */     if (rootName == null) {
/* 649 */       return withRootName((PropertyName)null);
/*     */     }
/* 651 */     return withRootName(PropertyName.construct(rootName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SubtypeResolver getSubtypeResolver() {
/* 683 */     return this._subtypeResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final String getRootName() {
/* 691 */     return (this._rootName == null) ? null : this._rootName.getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PropertyName getFullRootName() {
/* 698 */     return this._rootName;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Class<?> getActiveView() {
/* 703 */     return this._view;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ContextAttributes getAttributes() {
/* 708 */     return this._attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConfigOverride getConfigOverride(Class<?> type) {
/* 719 */     ConfigOverride override = this._configOverrides.findOverride(type);
/* 720 */     return (override == null) ? EMPTY_OVERRIDE : override;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ConfigOverride findConfigOverride(Class<?> type) {
/* 725 */     return this._configOverrides.findOverride(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonInclude.Value getDefaultPropertyInclusion() {
/* 730 */     return this._configOverrides.getDefaultInclusion();
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonInclude.Value getDefaultPropertyInclusion(Class<?> baseType) {
/* 735 */     JsonInclude.Value v = getConfigOverride(baseType).getInclude();
/* 736 */     JsonInclude.Value def = getDefaultPropertyInclusion();
/* 737 */     if (def == null) {
/* 738 */       return v;
/*     */     }
/* 740 */     return def.withOverrides(v);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonInclude.Value getDefaultInclusion(Class<?> baseType, Class<?> propertyType) {
/* 746 */     JsonInclude.Value v = getConfigOverride(propertyType).getIncludeAsProperty();
/* 747 */     JsonInclude.Value def = getDefaultPropertyInclusion(baseType);
/* 748 */     if (def == null) {
/* 749 */       return v;
/*     */     }
/* 751 */     return def.withOverrides(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> type) {
/* 756 */     return this._configOverrides.findFormatDefaults(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonIgnoreProperties.Value getDefaultPropertyIgnorals(Class<?> type) {
/* 761 */     ConfigOverride overrides = this._configOverrides.findOverride(type);
/* 762 */     if (overrides != null) {
/* 763 */       JsonIgnoreProperties.Value v = overrides.getIgnorals();
/* 764 */       if (v != null) {
/* 765 */         return v;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 770 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonIgnoreProperties.Value getDefaultPropertyIgnorals(Class<?> baseType, AnnotatedClass actualClass) {
/* 777 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/*     */     
/* 779 */     JsonIgnoreProperties.Value base = (intr == null) ? null : intr.findPropertyIgnoralByName(this, (Annotated)actualClass);
/* 780 */     JsonIgnoreProperties.Value overrides = getDefaultPropertyIgnorals(baseType);
/* 781 */     return JsonIgnoreProperties.Value.merge(base, overrides);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonIncludeProperties.Value getDefaultPropertyInclusions(Class<?> baseType, AnnotatedClass actualClass) {
/* 788 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/* 789 */     return (intr == null) ? null : intr.findPropertyInclusionByName(this, (Annotated)actualClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final VisibilityChecker<?> getDefaultVisibilityChecker() {
/* 795 */     VisibilityChecker<?> vchecker = this._configOverrides.getDefaultVisibility();
/*     */ 
/*     */     
/* 798 */     if ((this._mapperFeatures & AUTO_DETECT_MASK) != AUTO_DETECT_MASK) {
/* 799 */       if (!isEnabled(MapperFeature.AUTO_DETECT_FIELDS)) {
/* 800 */         vchecker = vchecker.withFieldVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 802 */       if (!isEnabled(MapperFeature.AUTO_DETECT_GETTERS)) {
/* 803 */         vchecker = vchecker.withGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 805 */       if (!isEnabled(MapperFeature.AUTO_DETECT_IS_GETTERS)) {
/* 806 */         vchecker = vchecker.withIsGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 808 */       if (!isEnabled(MapperFeature.AUTO_DETECT_SETTERS)) {
/* 809 */         vchecker = vchecker.withSetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 811 */       if (!isEnabled(MapperFeature.AUTO_DETECT_CREATORS)) {
/* 812 */         vchecker = vchecker.withCreatorVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/*     */     } 
/* 815 */     return vchecker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VisibilityChecker<?> getDefaultVisibilityChecker(Class<?> baseType, AnnotatedClass actualClass) {
/*     */     VisibilityChecker<?> vc;
/* 826 */     if (ClassUtil.isJDKClass(baseType)) {
/* 827 */       VisibilityChecker.Std std = VisibilityChecker.Std.allPublicInstance();
/*     */     } else {
/* 829 */       vc = getDefaultVisibilityChecker();
/*     */     } 
/* 831 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/* 832 */     if (intr != null) {
/* 833 */       vc = intr.findAutoDetectVisibility(actualClass, vc);
/*     */     }
/* 835 */     ConfigOverride overrides = this._configOverrides.findOverride(baseType);
/* 836 */     if (overrides != null) {
/* 837 */       vc = vc.withOverrides(overrides.getVisibility());
/*     */     }
/* 839 */     return vc;
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonSetter.Value getDefaultSetterInfo() {
/* 844 */     return this._configOverrides.getDefaultSetterInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean getDefaultMergeable() {
/* 849 */     return this._configOverrides.getDefaultMergeable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getDefaultMergeable(Class<?> baseType) {
/* 855 */     ConfigOverride cfg = this._configOverrides.findOverride(baseType);
/* 856 */     if (cfg != null) {
/* 857 */       Boolean b = cfg.getMergeable();
/* 858 */       if (b != null) {
/* 859 */         return b;
/*     */       }
/*     */     } 
/* 862 */     return this._configOverrides.getDefaultMergeable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName findRootName(JavaType rootType) {
/* 873 */     if (this._rootName != null) {
/* 874 */       return this._rootName;
/*     */     }
/* 876 */     return this._rootNames.findRootName(rootType, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyName findRootName(Class<?> rawRootType) {
/* 881 */     if (this._rootName != null) {
/* 882 */       return this._rootName;
/*     */     }
/* 884 */     return this._rootNames.findRootName(rawRootType, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Class<?> findMixInClassFor(Class<?> cls) {
/* 899 */     return this._mixIns.findMixInClassFor(cls);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassIntrospector.MixInResolver copy() {
/* 905 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int mixInCount() {
/* 913 */     return this._mixIns.localSize();
/*     */   }
/*     */   
/*     */   protected abstract T _withBase(BaseSettings paramBaseSettings);
/*     */   
/*     */   protected abstract T _withMapperFeatures(long paramLong);
/*     */   
/*     */   protected abstract T _with(DatatypeFeatures paramDatatypeFeatures);
/*     */   
/*     */   public abstract T with(ContextAttributes paramContextAttributes);
/*     */   
/*     */   public abstract T withRootName(PropertyName paramPropertyName);
/*     */   
/*     */   public abstract T with(SubtypeResolver paramSubtypeResolver);
/*     */   
/*     */   public abstract T withView(Class<?> paramClass);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\cfg\MapperConfigBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */