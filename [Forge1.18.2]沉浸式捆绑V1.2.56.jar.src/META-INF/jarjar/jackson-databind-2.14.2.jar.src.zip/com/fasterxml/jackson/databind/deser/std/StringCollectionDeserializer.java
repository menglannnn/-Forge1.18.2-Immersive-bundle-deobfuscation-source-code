/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public final class StringCollectionDeserializer
/*     */   extends ContainerDeserializerBase<Collection<String>>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonDeserializer<String> _valueDeserializer;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final JsonDeserializer<Object> _delegateDeserializer;
/*     */   
/*     */   public StringCollectionDeserializer(JavaType collectionType, JsonDeserializer<?> valueDeser, ValueInstantiator valueInstantiator) {
/*  66 */     this(collectionType, valueInstantiator, (JsonDeserializer<?>)null, valueDeser, (NullValueProvider)valueDeser, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringCollectionDeserializer(JavaType collectionType, ValueInstantiator valueInstantiator, JsonDeserializer<?> delegateDeser, JsonDeserializer<?> valueDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  75 */     super(collectionType, nuller, unwrapSingle);
/*  76 */     this._valueDeserializer = (JsonDeserializer)valueDeser;
/*  77 */     this._valueInstantiator = valueInstantiator;
/*  78 */     this._delegateDeserializer = (JsonDeserializer)delegateDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringCollectionDeserializer withResolved(JsonDeserializer<?> delegateDeser, JsonDeserializer<?> valueDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  85 */     if (Objects.equals(this._unwrapSingle, unwrapSingle) && this._nullProvider == nuller && this._valueDeserializer == valueDeser && this._delegateDeserializer == delegateDeser)
/*     */     {
/*  87 */       return this;
/*     */     }
/*  89 */     return new StringCollectionDeserializer(this._containerType, this._valueInstantiator, delegateDeser, valueDeser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/*  97 */     return (this._valueDeserializer == null && this._delegateDeserializer == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 102 */     return LogicalType.Collection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 115 */     JsonDeserializer<Object> delegate = null;
/* 116 */     if (this._valueInstantiator != null) {
/*     */       
/* 118 */       AnnotatedWithParams delegateCreator = this._valueInstantiator.getArrayDelegateCreator();
/* 119 */       if (delegateCreator != null) {
/* 120 */         JavaType delegateType = this._valueInstantiator.getArrayDelegateType(ctxt.getConfig());
/* 121 */         delegate = findDeserializer(ctxt, delegateType, property);
/* 122 */       } else if ((delegateCreator = this._valueInstantiator.getDelegateCreator()) != null) {
/* 123 */         JavaType delegateType = this._valueInstantiator.getDelegateType(ctxt.getConfig());
/* 124 */         delegate = findDeserializer(ctxt, delegateType, property);
/*     */       } 
/*     */     } 
/* 127 */     JsonDeserializer<?> valueDeser = this._valueDeserializer;
/* 128 */     JavaType valueType = this._containerType.getContentType();
/* 129 */     if (valueDeser == null) {
/*     */       
/* 131 */       valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
/* 132 */       if (valueDeser == null)
/*     */       {
/* 134 */         valueDeser = ctxt.findContextualValueDeserializer(valueType, property);
/*     */       }
/*     */     } else {
/* 137 */       valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, valueType);
/*     */     } 
/*     */ 
/*     */     
/* 141 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, Collection.class, JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */     
/* 143 */     NullValueProvider nuller = findContentNullProvider(ctxt, property, valueDeser);
/* 144 */     if (isDefaultDeserializer(valueDeser)) {
/* 145 */       valueDeser = null;
/*     */     }
/* 147 */     return withResolved(delegate, valueDeser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> getContentDeserializer() {
/* 159 */     JsonDeserializer<?> deser = this._valueDeserializer;
/* 160 */     return (JsonDeserializer)deser;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueInstantiator getValueInstantiator() {
/* 165 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 179 */     if (this._delegateDeserializer != null) {
/* 180 */       return (Collection<String>)this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/* 181 */           .deserialize(p, ctxt));
/*     */     }
/* 183 */     Collection<String> result = (Collection<String>)this._valueInstantiator.createUsingDefault(ctxt);
/* 184 */     return deserialize(p, ctxt, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> deserialize(JsonParser p, DeserializationContext ctxt, Collection<String> result) throws IOException {
/* 193 */     if (!p.isExpectedStartArrayToken()) {
/* 194 */       return handleNonArray(p, ctxt, result);
/*     */     }
/*     */     
/* 197 */     if (this._valueDeserializer != null) {
/* 198 */       return deserializeUsingCustom(p, ctxt, result, this._valueDeserializer);
/*     */     }
/*     */     
/*     */     try {
/*     */       while (true) {
/* 203 */         String value = p.nextTextValue();
/* 204 */         if (value != null) {
/* 205 */           result.add(value);
/*     */           continue;
/*     */         } 
/* 208 */         JsonToken t = p.currentToken();
/* 209 */         if (t == JsonToken.END_ARRAY) {
/*     */           break;
/*     */         }
/* 212 */         if (t == JsonToken.VALUE_NULL) {
/* 213 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 216 */           value = (String)this._nullProvider.getNullValue(ctxt);
/*     */         } else {
/* 218 */           value = _parseString(p, ctxt, this._nullProvider);
/*     */         } 
/* 220 */         result.add(value);
/*     */       } 
/* 222 */     } catch (Exception e) {
/* 223 */       throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */     } 
/* 225 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<String> deserializeUsingCustom(JsonParser p, DeserializationContext ctxt, Collection<String> result, JsonDeserializer<String> deser) throws IOException {
/*     */     try {
/*     */       while (true) {
/*     */         String value;
/* 239 */         if (p.nextTextValue() == null) {
/* 240 */           JsonToken t = p.currentToken();
/* 241 */           if (t == JsonToken.END_ARRAY) {
/*     */             break;
/*     */           }
/*     */           
/* 245 */           if (t == JsonToken.VALUE_NULL) {
/* 246 */             if (this._skipNullValues) {
/*     */               continue;
/*     */             }
/* 249 */             value = (String)this._nullProvider.getNullValue(ctxt);
/*     */           } else {
/* 251 */             value = (String)deser.deserialize(p, ctxt);
/*     */           } 
/*     */         } else {
/* 254 */           value = (String)deser.deserialize(p, ctxt);
/*     */         } 
/* 256 */         result.add(value);
/*     */       } 
/* 258 */     } catch (Exception e) {
/* 259 */       throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */     } 
/* 261 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 268 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Collection<String> handleNonArray(JsonParser p, DeserializationContext ctxt, Collection<String> result) throws IOException {
/*     */     String value;
/* 283 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/* 284 */     if (!canWrap) {
/* 285 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 286 */         return _deserializeFromString(p, ctxt);
/*     */       }
/* 288 */       return (Collection<String>)ctxt.handleUnexpectedToken(this._containerType, p);
/*     */     } 
/*     */     
/* 291 */     JsonDeserializer<String> valueDes = this._valueDeserializer;
/* 292 */     JsonToken t = p.currentToken();
/*     */ 
/*     */ 
/*     */     
/* 296 */     if (t == JsonToken.VALUE_NULL) {
/*     */       
/* 298 */       if (this._skipNullValues) {
/* 299 */         return result;
/*     */       }
/* 301 */       value = (String)this._nullProvider.getNullValue(ctxt);
/*     */     } else {
/* 303 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 304 */         String textValue = p.getText();
/*     */         
/* 306 */         if (textValue.isEmpty()) {
/* 307 */           CoercionAction act = ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*     */           
/* 309 */           if (act != CoercionAction.Fail) {
/* 310 */             return (Collection<String>)_deserializeFromEmptyString(p, ctxt, act, handledType(), "empty String (\"\")");
/*     */           }
/*     */         }
/* 313 */         else if (_isBlank(textValue)) {
/* 314 */           CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*     */           
/* 316 */           if (act != CoercionAction.Fail) {
/* 317 */             return (Collection<String>)_deserializeFromEmptyString(p, ctxt, act, handledType(), "blank String (all whitespace)");
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 325 */         value = (valueDes == null) ? _parseString(p, ctxt, this._nullProvider) : (String)valueDes.deserialize(p, ctxt);
/* 326 */       } catch (Exception e) {
/* 327 */         throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */       } 
/*     */     } 
/* 330 */     result.add(value);
/* 331 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\StringCollectionDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */