/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EnumFeature
/*    */   implements DatatypeFeature
/*    */ {
/* 11 */   BOGUS_FEATURE(false);
/*    */ 
/*    */   
/*    */   private final int _mask;
/*    */ 
/*    */   
/*    */   private final boolean _enabledByDefault;
/*    */   
/*    */   private static final int FEATURE_INDEX = 0;
/*    */ 
/*    */   
/*    */   EnumFeature(boolean enabledByDefault) {
/* 23 */     this._enabledByDefault = enabledByDefault;
/* 24 */     this._mask = 1 << ordinal();
/*    */   }
/*    */   
/*    */   public boolean enabledByDefault() {
/* 28 */     return this._enabledByDefault;
/*    */   } public boolean enabledIn(int flags) {
/* 30 */     return ((flags & this._mask) != 0);
/*    */   } public int getMask() {
/* 32 */     return this._mask;
/*    */   }
/*    */   
/*    */   public int featureIndex() {
/* 36 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\cfg\EnumFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */