/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidTypeIdException;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*      */ import com.fasterxml.jackson.databind.ser.ResolvableSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerCache;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.impl.FailingSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.ReadOnlyClassToSerializerMap;
/*      */ import com.fasterxml.jackson.databind.ser.impl.TypeWrappedSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.UnknownSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.WritableObjectId;
/*      */ import com.fasterxml.jackson.databind.ser.std.NullSerializer;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class SerializerProvider
/*      */   extends DatabindContext
/*      */ {
/*      */   protected static final boolean CACHE_UNKNOWN_MAPPINGS = false;
/*   60 */   public static final JsonSerializer<Object> DEFAULT_NULL_KEY_SERIALIZER = (JsonSerializer<Object>)new FailingSerializer("Null key for a Map not allowed in JSON (use a converting NullKeySerializer?)");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   72 */   protected static final JsonSerializer<Object> DEFAULT_UNKNOWN_SERIALIZER = (JsonSerializer<Object>)new UnknownSerializer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializationConfig _config;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Class<?> _serializationView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializerFactory _serializerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializerCache _serializerCache;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient ContextAttributes _attributes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   protected JsonSerializer<Object> _unknownTypeSerializer = DEFAULT_UNKNOWN_SERIALIZER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _keySerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  147 */   protected JsonSerializer<Object> _nullValueSerializer = (JsonSerializer<Object>)NullSerializer.instance;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  156 */   protected JsonSerializer<Object> _nullKeySerializer = DEFAULT_NULL_KEY_SERIALIZER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ReadOnlyClassToSerializerMap _knownSerializers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DateFormat _dateFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _stdNullValueSerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerProvider() {
/*  197 */     this._config = null;
/*  198 */     this._serializerFactory = null;
/*  199 */     this._serializerCache = new SerializerCache();
/*      */     
/*  201 */     this._knownSerializers = null;
/*      */     
/*  203 */     this._serializationView = null;
/*  204 */     this._attributes = null;
/*      */ 
/*      */     
/*  207 */     this._stdNullValueSerializer = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializerProvider(SerializerProvider src, SerializationConfig config, SerializerFactory f) {
/*  219 */     this._serializerFactory = f;
/*  220 */     this._config = config;
/*      */     
/*  222 */     this._serializerCache = src._serializerCache;
/*  223 */     this._unknownTypeSerializer = src._unknownTypeSerializer;
/*  224 */     this._keySerializer = src._keySerializer;
/*  225 */     this._nullValueSerializer = src._nullValueSerializer;
/*  226 */     this._nullKeySerializer = src._nullKeySerializer;
/*      */     
/*  228 */     this._stdNullValueSerializer = (this._nullValueSerializer == DEFAULT_NULL_KEY_SERIALIZER);
/*      */     
/*  230 */     this._serializationView = config.getActiveView();
/*  231 */     this._attributes = config.getAttributes();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  236 */     this._knownSerializers = this._serializerCache.getReadOnlyLookupMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializerProvider(SerializerProvider src) {
/*  247 */     this._config = null;
/*  248 */     this._serializationView = null;
/*  249 */     this._serializerFactory = null;
/*  250 */     this._knownSerializers = null;
/*      */ 
/*      */     
/*  253 */     this._serializerCache = new SerializerCache();
/*      */     
/*  255 */     this._unknownTypeSerializer = src._unknownTypeSerializer;
/*  256 */     this._keySerializer = src._keySerializer;
/*  257 */     this._nullValueSerializer = src._nullValueSerializer;
/*  258 */     this._nullKeySerializer = src._nullKeySerializer;
/*      */     
/*  260 */     this._stdNullValueSerializer = src._stdNullValueSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultKeySerializer(JsonSerializer<Object> ks) {
/*  280 */     if (ks == null) {
/*  281 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  283 */     this._keySerializer = ks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullValueSerializer(JsonSerializer<Object> nvs) {
/*  297 */     if (nvs == null) {
/*  298 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  300 */     this._nullValueSerializer = nvs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullKeySerializer(JsonSerializer<Object> nks) {
/*  310 */     if (nks == null) {
/*  311 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  313 */     this._nullKeySerializer = nks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SerializationConfig getConfig() {
/*  326 */     return this._config;
/*      */   }
/*      */   
/*      */   public final AnnotationIntrospector getAnnotationIntrospector() {
/*  330 */     return this._config.getAnnotationIntrospector();
/*      */   }
/*      */ 
/*      */   
/*      */   public final TypeFactory getTypeFactory() {
/*  335 */     return this._config.getTypeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass) throws IllegalArgumentException {
/*  342 */     if (baseType.hasRawClass(subclass)) {
/*  343 */       return baseType;
/*      */     }
/*      */ 
/*      */     
/*  347 */     return getConfig().getTypeFactory().constructSpecializedType(baseType, subclass, true);
/*      */   }
/*      */   
/*      */   public final Class<?> getActiveView() {
/*  351 */     return this._serializationView;
/*      */   }
/*      */   
/*      */   public final boolean canOverrideAccessModifiers() {
/*  355 */     return this._config.canOverrideAccessModifiers();
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(MapperFeature feature) {
/*  360 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DatatypeFeature feature) {
/*  365 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */   
/*      */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> baseType) {
/*  370 */     return this._config.getDefaultPropertyFormat(baseType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonInclude.Value getDefaultPropertyInclusion(Class<?> baseType) {
/*  377 */     return this._config.getDefaultPropertyInclusion(baseType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Locale getLocale() {
/*  388 */     return this._config.getLocale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TimeZone getTimeZone() {
/*  399 */     return this._config.getTimeZone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAttribute(Object key) {
/*  410 */     return this._attributes.getAttribute(key);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerProvider setAttribute(Object key, Object value) {
/*  416 */     this._attributes = this._attributes.withPerCallAttribute(key, value);
/*  417 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(SerializationFeature feature) {
/*  435 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasSerializationFeatures(int featureMask) {
/*  445 */     return this._config.hasSerializationFeatures(featureMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final FilterProvider getFilterProvider() {
/*  456 */     return this._config.getFilterProvider();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator getGenerator() {
/*  467 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer bufferForValueConversion(ObjectCodec oc) {
/*  485 */     return new TokenBuffer(oc, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TokenBuffer bufferForValueConversion() {
/*  495 */     return bufferForValueConversion((ObjectCodec)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findValueSerializer(Class<?> valueType, BeanProperty property) throws JsonMappingException {
/*  541 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  542 */     if (ser == null) {
/*      */       
/*  544 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  545 */       if (ser == null) {
/*      */         
/*  547 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  548 */         if (ser == null) {
/*      */           
/*  550 */           ser = _createAndCacheUntypedSerializer(valueType);
/*      */           
/*  552 */           if (ser == null) {
/*  553 */             ser = getUnknownTypeSerializer(valueType);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  558 */             return ser;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  564 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findValueSerializer(JavaType valueType, BeanProperty property) throws JsonMappingException {
/*  583 */     if (valueType == null) {
/*  584 */       reportMappingProblem("Null passed for `valueType` of `findValueSerializer()`", new Object[0]);
/*      */     }
/*      */     
/*  587 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  588 */     if (ser == null) {
/*  589 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  590 */       if (ser == null) {
/*  591 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  592 */         if (ser == null) {
/*  593 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */ 
/*      */ 
/*      */           
/*  597 */           return ser;
/*      */         } 
/*      */       } 
/*      */     } 
/*  601 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findValueSerializer(Class<?> valueType) throws JsonMappingException {
/*  614 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  615 */     if (ser == null) {
/*  616 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  617 */       if (ser == null) {
/*  618 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  619 */         if (ser == null) {
/*  620 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  621 */           if (ser == null) {
/*  622 */             ser = getUnknownTypeSerializer(valueType);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  630 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findValueSerializer(JavaType valueType) throws JsonMappingException {
/*  644 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  645 */     if (ser == null) {
/*  646 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  647 */       if (ser == null) {
/*  648 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  649 */         if (ser == null) {
/*  650 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  657 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findPrimaryPropertySerializer(JavaType valueType, BeanProperty property) throws JsonMappingException {
/*  677 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  678 */     if (ser == null) {
/*  679 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  680 */       if (ser == null) {
/*  681 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  682 */         if (ser == null) {
/*  683 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  688 */           return ser;
/*      */         } 
/*      */       } 
/*      */     } 
/*  692 */     return (JsonSerializer)handlePrimaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findPrimaryPropertySerializer(Class<?> valueType, BeanProperty property) throws JsonMappingException {
/*  705 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  706 */     if (ser == null) {
/*  707 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  708 */       if (ser == null) {
/*  709 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  710 */         if (ser == null) {
/*  711 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  712 */           if (ser == null) {
/*  713 */             ser = getUnknownTypeSerializer(valueType);
/*      */ 
/*      */ 
/*      */             
/*  717 */             return ser;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  722 */     return (JsonSerializer)handlePrimaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findContentValueSerializer(JavaType valueType, BeanProperty property) throws JsonMappingException {
/*  749 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  750 */     if (ser == null) {
/*  751 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  752 */       if (ser == null) {
/*  753 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  754 */         if (ser == null) {
/*  755 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  760 */           return ser;
/*      */         } 
/*      */       } 
/*      */     } 
/*  764 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findContentValueSerializer(Class<?> valueType, BeanProperty property) throws JsonMappingException {
/*  777 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  778 */     if (ser == null) {
/*  779 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  780 */       if (ser == null) {
/*  781 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  782 */         if (ser == null) {
/*  783 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  784 */           if (ser == null) {
/*  785 */             ser = getUnknownTypeSerializer(valueType);
/*      */ 
/*      */ 
/*      */             
/*  789 */             return ser;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  794 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findTypedValueSerializer(Class<?> valueType, boolean cache, BeanProperty property) throws JsonMappingException {
/*      */     TypeWrappedSerializer typeWrappedSerializer;
/*  817 */     JsonSerializer<Object> ser = this._knownSerializers.typedValueSerializer(valueType);
/*  818 */     if (ser != null) {
/*  819 */       return ser;
/*      */     }
/*      */     
/*  822 */     ser = this._serializerCache.typedValueSerializer(valueType);
/*  823 */     if (ser != null) {
/*  824 */       return ser;
/*      */     }
/*      */ 
/*      */     
/*  828 */     ser = findValueSerializer(valueType, property);
/*  829 */     TypeSerializer typeSer = this._serializerFactory.createTypeSerializer(this._config, this._config
/*  830 */         .constructType(valueType));
/*  831 */     if (typeSer != null) {
/*  832 */       typeSer = typeSer.forProperty(property);
/*  833 */       typeWrappedSerializer = new TypeWrappedSerializer(typeSer, ser);
/*      */     } 
/*  835 */     if (cache) {
/*  836 */       this._serializerCache.addTypedSerializer(valueType, (JsonSerializer)typeWrappedSerializer);
/*      */     }
/*  838 */     return (JsonSerializer<Object>)typeWrappedSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findTypedValueSerializer(JavaType valueType, boolean cache, BeanProperty property) throws JsonMappingException {
/*      */     TypeWrappedSerializer typeWrappedSerializer;
/*  862 */     JsonSerializer<Object> ser = this._knownSerializers.typedValueSerializer(valueType);
/*  863 */     if (ser != null) {
/*  864 */       return ser;
/*      */     }
/*      */     
/*  867 */     ser = this._serializerCache.typedValueSerializer(valueType);
/*  868 */     if (ser != null) {
/*  869 */       return ser;
/*      */     }
/*      */ 
/*      */     
/*  873 */     ser = findValueSerializer(valueType, property);
/*  874 */     TypeSerializer typeSer = this._serializerFactory.createTypeSerializer(this._config, valueType);
/*  875 */     if (typeSer != null) {
/*  876 */       typeSer = typeSer.forProperty(property);
/*  877 */       typeWrappedSerializer = new TypeWrappedSerializer(typeSer, ser);
/*      */     } 
/*  879 */     if (cache) {
/*  880 */       this._serializerCache.addTypedSerializer(valueType, (JsonSerializer)typeWrappedSerializer);
/*      */     }
/*  882 */     return (JsonSerializer<Object>)typeWrappedSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeSerializer findTypeSerializer(JavaType javaType) throws JsonMappingException {
/*  893 */     return this._serializerFactory.createTypeSerializer(this._config, javaType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findKeySerializer(JavaType keyType, BeanProperty property) throws JsonMappingException {
/*  909 */     JsonSerializer<Object> ser = this._serializerFactory.createKeySerializer(this, keyType, this._keySerializer);
/*      */     
/*  911 */     return _handleContextualResolvable(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findKeySerializer(Class<?> rawKeyType, BeanProperty property) throws JsonMappingException {
/*  920 */     return findKeySerializer(this._config.constructType(rawKeyType), property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> getDefaultNullKeySerializer() {
/*  933 */     return this._nullKeySerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> getDefaultNullValueSerializer() {
/*  940 */     return this._nullValueSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findNullKeySerializer(JavaType serializationType, BeanProperty property) throws JsonMappingException {
/*  964 */     return this._nullKeySerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findNullValueSerializer(BeanProperty property) throws JsonMappingException {
/*  980 */     return this._nullValueSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> getUnknownTypeSerializer(Class<?> unknownType) {
/*  997 */     if (unknownType == Object.class) {
/*  998 */       return this._unknownTypeSerializer;
/*      */     }
/*      */     
/* 1001 */     return (JsonSerializer<Object>)new UnknownSerializer(unknownType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUnknownTypeSerializer(JsonSerializer<?> ser) {
/* 1012 */     if (ser == this._unknownTypeSerializer || ser == null) {
/* 1013 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 1017 */     if (isEnabled(SerializationFeature.FAIL_ON_EMPTY_BEANS) && 
/* 1018 */       ser.getClass() == UnknownSerializer.class) {
/* 1019 */       return true;
/*      */     }
/*      */     
/* 1022 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> handlePrimaryContextualization(JsonSerializer<?> ser, BeanProperty property) throws JsonMappingException {
/* 1089 */     if (ser != null && 
/* 1090 */       ser instanceof ContextualSerializer) {
/* 1091 */       ser = ((ContextualSerializer)ser).createContextual(this, property);
/*      */     }
/*      */     
/* 1094 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> handleSecondaryContextualization(JsonSerializer<?> ser, BeanProperty property) throws JsonMappingException {
/* 1117 */     if (ser != null && 
/* 1118 */       ser instanceof ContextualSerializer) {
/* 1119 */       ser = ((ContextualSerializer)ser).createContextual(this, property);
/*      */     }
/*      */     
/* 1122 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void defaultSerializeValue(Object value, JsonGenerator gen) throws IOException {
/* 1140 */     if (value == null) {
/* 1141 */       if (this._stdNullValueSerializer) {
/* 1142 */         gen.writeNull();
/*      */       } else {
/* 1144 */         this._nullValueSerializer.serialize(null, gen, this);
/*      */       } 
/*      */     } else {
/* 1147 */       Class<?> cls = value.getClass();
/* 1148 */       findTypedValueSerializer(cls, true, (BeanProperty)null).serialize(value, gen, this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void defaultSerializeField(String fieldName, Object value, JsonGenerator gen) throws IOException {
/* 1160 */     gen.writeFieldName(fieldName);
/* 1161 */     if (value == null) {
/*      */ 
/*      */ 
/*      */       
/* 1165 */       if (this._stdNullValueSerializer) {
/* 1166 */         gen.writeNull();
/*      */       } else {
/* 1168 */         this._nullValueSerializer.serialize(null, gen, this);
/*      */       } 
/*      */     } else {
/* 1171 */       Class<?> cls = value.getClass();
/* 1172 */       findTypedValueSerializer(cls, true, (BeanProperty)null).serialize(value, gen, this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void defaultSerializeDateValue(long timestamp, JsonGenerator gen) throws IOException {
/* 1186 */     if (isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)) {
/* 1187 */       gen.writeNumber(timestamp);
/*      */     } else {
/* 1189 */       gen.writeString(_dateFormat().format(new Date(timestamp)));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void defaultSerializeDateValue(Date date, JsonGenerator gen) throws IOException {
/* 1202 */     if (isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)) {
/* 1203 */       gen.writeNumber(date.getTime());
/*      */     } else {
/* 1205 */       gen.writeString(_dateFormat().format(date));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defaultSerializeDateKey(long timestamp, JsonGenerator gen) throws IOException {
/* 1216 */     if (isEnabled(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS)) {
/* 1217 */       gen.writeFieldName(String.valueOf(timestamp));
/*      */     } else {
/* 1219 */       gen.writeFieldName(_dateFormat().format(new Date(timestamp)));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defaultSerializeDateKey(Date date, JsonGenerator gen) throws IOException {
/* 1230 */     if (isEnabled(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS)) {
/* 1231 */       gen.writeFieldName(String.valueOf(date.getTime()));
/*      */     } else {
/* 1233 */       gen.writeFieldName(_dateFormat().format(date));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void defaultSerializeNull(JsonGenerator gen) throws IOException {
/* 1239 */     if (this._stdNullValueSerializer) {
/* 1240 */       gen.writeNull();
/*      */     } else {
/* 1242 */       this._nullValueSerializer.serialize(null, gen, this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportMappingProblem(String message, Object... args) throws JsonMappingException {
/* 1260 */     throw mappingException(message, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadTypeDefinition(BeanDescription bean, String msg, Object... msgArgs) throws JsonMappingException {
/* 1272 */     String beanDesc = "N/A";
/* 1273 */     if (bean != null) {
/* 1274 */       beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/*      */     }
/* 1276 */     msg = String.format("Invalid type definition for type %s: %s", new Object[] { beanDesc, 
/* 1277 */           _format(msg, msgArgs) });
/* 1278 */     throw InvalidDefinitionException.from(getGenerator(), msg, bean, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadPropertyDefinition(BeanDescription bean, BeanPropertyDefinition prop, String message, Object... msgArgs) throws JsonMappingException {
/* 1290 */     message = _format(message, msgArgs);
/* 1291 */     String propName = "N/A";
/* 1292 */     if (prop != null) {
/* 1293 */       propName = _quotedString(prop.getName());
/*      */     }
/* 1295 */     String beanDesc = "N/A";
/* 1296 */     if (bean != null) {
/* 1297 */       beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/*      */     }
/* 1299 */     message = String.format("Invalid definition for property %s (of type %s): %s", new Object[] { propName, beanDesc, message });
/*      */     
/* 1301 */     throw InvalidDefinitionException.from(getGenerator(), message, bean, prop);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T reportBadDefinition(JavaType type, String msg) throws JsonMappingException {
/* 1306 */     throw InvalidDefinitionException.from(getGenerator(), msg, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadDefinition(JavaType type, String msg, Throwable cause) throws JsonMappingException {
/* 1314 */     throw InvalidDefinitionException.from(getGenerator(), msg, type)
/* 1315 */       .withCause(cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadDefinition(Class<?> raw, String msg, Throwable cause) throws JsonMappingException {
/* 1323 */     throw InvalidDefinitionException.from(getGenerator(), msg, constructType(raw))
/* 1324 */       .withCause(cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportMappingProblem(Throwable t, String message, Object... msgArgs) throws JsonMappingException {
/* 1335 */     message = _format(message, msgArgs);
/* 1336 */     throw JsonMappingException.from(getGenerator(), message, t);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException invalidTypeIdException(JavaType baseType, String typeId, String extraDesc) {
/* 1342 */     String msg = String.format("Could not resolve type id '%s' as a subtype of %s", new Object[] { typeId, 
/* 1343 */           ClassUtil.getTypeDescription(baseType) });
/* 1344 */     return (JsonMappingException)InvalidTypeIdException.from(null, _colonConcat(msg, extraDesc), baseType, typeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(String message, Object... msgArgs) {
/* 1364 */     return JsonMappingException.from(getGenerator(), _format(message, msgArgs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected JsonMappingException mappingException(Throwable t, String message, Object... msgArgs) {
/* 1378 */     return JsonMappingException.from(getGenerator(), _format(message, msgArgs), t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportIncompatibleRootType(Object value, JavaType rootType) throws IOException {
/* 1390 */     if (rootType.isPrimitive()) {
/* 1391 */       Class<?> wrapperType = ClassUtil.wrapperType(rootType.getRawClass());
/*      */       
/* 1393 */       if (wrapperType.isAssignableFrom(value.getClass())) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1397 */     reportBadDefinition(rootType, String.format("Incompatible types: declared root type (%s) vs %s", new Object[] { rootType, 
/*      */             
/* 1399 */             ClassUtil.classNameOf(value) }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _findExplicitUntypedSerializer(Class<?> runtimeType) throws JsonMappingException {
/* 1413 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(runtimeType);
/* 1414 */     if (ser == null) {
/*      */       
/* 1416 */       ser = this._serializerCache.untypedValueSerializer(runtimeType);
/* 1417 */       if (ser == null) {
/* 1418 */         ser = _createAndCacheUntypedSerializer(runtimeType);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1426 */     if (isUnknownTypeSerializer(ser)) {
/* 1427 */       return null;
/*      */     }
/* 1429 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _createAndCacheUntypedSerializer(Class<?> rawType) throws JsonMappingException {
/*      */     JsonSerializer<Object> ser;
/* 1446 */     JavaType fullType = this._config.constructType(rawType);
/*      */     
/*      */     try {
/* 1449 */       ser = _createUntypedSerializer(fullType);
/* 1450 */     } catch (IllegalArgumentException iae) {
/*      */ 
/*      */       
/* 1453 */       reportBadDefinition(fullType, ClassUtil.exceptionMessage(iae));
/* 1454 */       ser = null;
/*      */     } 
/*      */     
/* 1457 */     if (ser != null)
/*      */     {
/* 1459 */       this._serializerCache.addAndResolveNonTypedSerializer(rawType, fullType, ser, this);
/*      */     }
/* 1461 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _createAndCacheUntypedSerializer(JavaType type) throws JsonMappingException {
/*      */     JsonSerializer<Object> ser;
/*      */     try {
/* 1469 */       ser = _createUntypedSerializer(type);
/* 1470 */     } catch (IllegalArgumentException iae) {
/*      */ 
/*      */       
/* 1473 */       ser = null;
/* 1474 */       reportMappingProblem(iae, ClassUtil.exceptionMessage(iae), new Object[0]);
/*      */     } 
/*      */     
/* 1477 */     if (ser != null)
/*      */     {
/* 1479 */       this._serializerCache.addAndResolveNonTypedSerializer(type, ser, this);
/*      */     }
/* 1481 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _createUntypedSerializer(JavaType type) throws JsonMappingException {
/* 1501 */     return this._serializerFactory.createSerializer(this, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _handleContextualResolvable(JsonSerializer<?> ser, BeanProperty property) throws JsonMappingException {
/* 1514 */     if (ser instanceof ResolvableSerializer) {
/* 1515 */       ((ResolvableSerializer)ser).resolve(this);
/*      */     }
/* 1517 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _handleResolvable(JsonSerializer<?> ser) throws JsonMappingException {
/* 1524 */     if (ser instanceof ResolvableSerializer) {
/* 1525 */       ((ResolvableSerializer)ser).resolve(this);
/*      */     }
/* 1527 */     return (JsonSerializer)ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DateFormat _dateFormat() {
/* 1538 */     if (this._dateFormat != null) {
/* 1539 */       return this._dateFormat;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1545 */     DateFormat df = this._config.getDateFormat();
/* 1546 */     this._dateFormat = df = (DateFormat)df.clone();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1555 */     return df;
/*      */   }
/*      */   
/*      */   public abstract WritableObjectId findObjectId(Object paramObject, ObjectIdGenerator<?> paramObjectIdGenerator);
/*      */   
/*      */   public abstract JsonSerializer<Object> serializerInstance(Annotated paramAnnotated, Object paramObject) throws JsonMappingException;
/*      */   
/*      */   public abstract Object includeFilterInstance(BeanPropertyDefinition paramBeanPropertyDefinition, Class<?> paramClass) throws JsonMappingException;
/*      */   
/*      */   public abstract boolean includeFilterSuppressNulls(Object paramObject) throws JsonMappingException;
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\SerializerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */