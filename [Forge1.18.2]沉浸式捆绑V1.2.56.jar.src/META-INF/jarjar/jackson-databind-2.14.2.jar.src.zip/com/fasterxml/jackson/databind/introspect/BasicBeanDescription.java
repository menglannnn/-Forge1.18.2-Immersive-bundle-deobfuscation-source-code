/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BasicBeanDescription extends BeanDescription {
/*  31 */   private static final Class<?>[] NO_VIEWS = new Class[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final POJOPropertiesCollector _propCollector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MapperConfig<?> _config;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotatedClass _classInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?>[] _defaultViews;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _defaultViewsResolved;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyDefinition> _properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectIdInfo _objectIdInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BasicBeanDescription(POJOPropertiesCollector coll, JavaType type, AnnotatedClass classDef) {
/*  96 */     super(type);
/*  97 */     this._propCollector = coll;
/*  98 */     this._config = coll.getConfig();
/*     */     
/* 100 */     if (this._config == null) {
/* 101 */       this._annotationIntrospector = null;
/*     */     } else {
/* 103 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */     } 
/* 105 */     this._classInfo = classDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BasicBeanDescription(MapperConfig<?> config, JavaType type, AnnotatedClass classDef, List<BeanPropertyDefinition> props) {
/* 115 */     super(type);
/* 116 */     this._propCollector = null;
/* 117 */     this._config = config;
/*     */     
/* 119 */     if (this._config == null) {
/* 120 */       this._annotationIntrospector = null;
/*     */     } else {
/* 122 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */     } 
/* 124 */     this._classInfo = classDef;
/* 125 */     this._properties = props;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BasicBeanDescription(POJOPropertiesCollector coll) {
/* 130 */     this(coll, coll.getType(), coll.getClassDef());
/* 131 */     this._objectIdInfo = coll.getObjectIdInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicBeanDescription forDeserialization(POJOPropertiesCollector coll) {
/* 139 */     return new BasicBeanDescription(coll);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicBeanDescription forSerialization(POJOPropertiesCollector coll) {
/* 147 */     return new BasicBeanDescription(coll);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicBeanDescription forOtherUse(MapperConfig<?> config, JavaType type, AnnotatedClass ac) {
/* 158 */     return new BasicBeanDescription(config, type, ac, 
/* 159 */         Collections.emptyList());
/*     */   }
/*     */   
/*     */   protected List<BeanPropertyDefinition> _properties() {
/* 163 */     if (this._properties == null) {
/* 164 */       this._properties = this._propCollector.getProperties();
/*     */     }
/* 166 */     return this._properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeProperty(String propName) {
/* 184 */     Iterator<BeanPropertyDefinition> it = _properties().iterator();
/* 185 */     while (it.hasNext()) {
/* 186 */       BeanPropertyDefinition prop = it.next();
/* 187 */       if (prop.getName().equals(propName)) {
/* 188 */         it.remove();
/* 189 */         return true;
/*     */       } 
/*     */     } 
/* 192 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addProperty(BeanPropertyDefinition def) {
/* 198 */     if (hasProperty(def.getFullName())) {
/* 199 */       return false;
/*     */     }
/* 201 */     _properties().add(def);
/* 202 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperty(PropertyName name) {
/* 209 */     return (findProperty(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyDefinition findProperty(PropertyName name) {
/* 217 */     for (BeanPropertyDefinition prop : _properties()) {
/* 218 */       if (prop.hasName(name)) {
/* 219 */         return prop;
/*     */       }
/*     */     } 
/* 222 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedClass getClassInfo() {
/* 232 */     return this._classInfo;
/*     */   }
/*     */   public ObjectIdInfo getObjectIdInfo() {
/* 235 */     return this._objectIdInfo;
/*     */   }
/*     */   
/*     */   public List<BeanPropertyDefinition> findProperties() {
/* 239 */     return _properties();
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedMember findJsonKeyAccessor() {
/* 244 */     return (this._propCollector == null) ? null : this._propCollector
/* 245 */       .getJsonKeyAccessor();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AnnotatedMethod findJsonValueMethod() {
/* 251 */     return (this._propCollector == null) ? null : this._propCollector
/* 252 */       .getJsonValueMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedMember findJsonValueAccessor() {
/* 257 */     return (this._propCollector == null) ? null : this._propCollector
/* 258 */       .getJsonValueAccessor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getIgnoredPropertyNames() {
/* 264 */     Set<String> ign = (this._propCollector == null) ? null : this._propCollector.getIgnoredPropertyNames();
/* 265 */     if (ign == null) {
/* 266 */       return Collections.emptySet();
/*     */     }
/* 268 */     return ign;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKnownClassAnnotations() {
/* 273 */     return this._classInfo.hasAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotations getClassAnnotations() {
/* 278 */     return this._classInfo.getAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public TypeBindings bindingsForBeanType() {
/* 284 */     return this._type.getBindings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JavaType resolveType(Type jdkType) {
/* 292 */     return this._config.getTypeFactory().resolveMemberType(jdkType, this._type.getBindings());
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedConstructor findDefaultConstructor() {
/* 297 */     return this._classInfo.getDefaultConstructor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedMember findAnySetterAccessor() throws IllegalArgumentException {
/* 303 */     if (this._propCollector != null) {
/* 304 */       AnnotatedMethod anyMethod = this._propCollector.getAnySetterMethod();
/* 305 */       if (anyMethod != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 312 */         Class<?> type = anyMethod.getRawParameterType(0);
/* 313 */         if (type != String.class && type != Object.class) {
/* 314 */           throw new IllegalArgumentException(String.format("Invalid 'any-setter' annotation on method '%s()': first argument not of type String or Object, but %s", new Object[] { anyMethod
/*     */                   
/* 316 */                   .getName(), type.getName() }));
/*     */         }
/* 318 */         return anyMethod;
/*     */       } 
/* 320 */       AnnotatedMember anyField = this._propCollector.getAnySetterField();
/* 321 */       if (anyField != null) {
/*     */ 
/*     */         
/* 324 */         Class<?> type = anyField.getRawType();
/* 325 */         if (!Map.class.isAssignableFrom(type) && 
/* 326 */           !JsonNode.class.isAssignableFrom(type)) {
/* 327 */           throw new IllegalArgumentException(String.format("Invalid 'any-setter' annotation on field '%s': type is not instance of `java.util.Map` or `JsonNode`", new Object[] { anyField
/*     */                   
/* 329 */                   .getName() }));
/*     */         }
/* 331 */         return anyField;
/*     */       } 
/*     */     } 
/* 334 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Object, AnnotatedMember> findInjectables() {
/* 339 */     if (this._propCollector != null) {
/* 340 */       return this._propCollector.getInjectables();
/*     */     }
/* 342 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AnnotatedConstructor> getConstructors() {
/* 347 */     return this._classInfo.getConstructors();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AnnotatedAndMetadata<AnnotatedConstructor, JsonCreator.Mode>> getConstructorsWithMode() {
/* 352 */     List<AnnotatedConstructor> allCtors = this._classInfo.getConstructors();
/* 353 */     if (allCtors.isEmpty()) {
/* 354 */       return Collections.emptyList();
/*     */     }
/* 356 */     List<AnnotatedAndMetadata<AnnotatedConstructor, JsonCreator.Mode>> result = new ArrayList<>();
/* 357 */     for (AnnotatedConstructor ctor : allCtors) {
/* 358 */       JsonCreator.Mode mode = this._annotationIntrospector.findCreatorAnnotation(this._config, ctor);
/* 359 */       if (mode == JsonCreator.Mode.DISABLED) {
/*     */         continue;
/*     */       }
/* 362 */       result.add(AnnotatedAndMetadata.of(ctor, mode));
/*     */     } 
/* 364 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object instantiateBean(boolean fixAccess) {
/* 369 */     AnnotatedConstructor ac = this._classInfo.getDefaultConstructor();
/* 370 */     if (ac == null) {
/* 371 */       return null;
/*     */     }
/* 373 */     if (fixAccess) {
/* 374 */       ac.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/*     */     try {
/* 377 */       return ac.call();
/* 378 */     } catch (Exception e) {
/* 379 */       Throwable t = e;
/* 380 */       while (t.getCause() != null) {
/* 381 */         t = t.getCause();
/*     */       }
/* 383 */       ClassUtil.throwIfError(t);
/* 384 */       ClassUtil.throwIfRTE(t);
/* 385 */       throw new IllegalArgumentException("Failed to instantiate bean of type " + this._classInfo
/* 386 */           .getAnnotated().getName() + ": (" + t.getClass().getName() + ") " + 
/* 387 */           ClassUtil.exceptionMessage(t), t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedMethod findMethod(String name, Class<?>[] paramTypes) {
/* 399 */     return this._classInfo.findMethod(name, paramTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonFormat.Value findExpectedFormat(JsonFormat.Value defValue) {
/* 413 */     if (this._annotationIntrospector != null) {
/* 414 */       JsonFormat.Value value = this._annotationIntrospector.findFormat(this._classInfo);
/* 415 */       if (value != null) {
/* 416 */         if (defValue == null) {
/* 417 */           defValue = value;
/*     */         } else {
/* 419 */           defValue = defValue.withOverrides(value);
/*     */         } 
/*     */       }
/*     */     } 
/* 423 */     JsonFormat.Value v = this._config.getDefaultPropertyFormat(this._classInfo.getRawType());
/* 424 */     if (v != null) {
/* 425 */       if (defValue == null) {
/* 426 */         defValue = v;
/*     */       } else {
/* 428 */         defValue = defValue.withOverrides(v);
/*     */       } 
/*     */     }
/* 431 */     return defValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] findDefaultViews() {
/* 437 */     if (!this._defaultViewsResolved) {
/* 438 */       this._defaultViewsResolved = true;
/*     */       
/* 440 */       Class<?>[] def = (this._annotationIntrospector == null) ? null : this._annotationIntrospector.findViews(this._classInfo);
/*     */       
/* 442 */       if (def == null && 
/* 443 */         !this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION)) {
/* 444 */         def = NO_VIEWS;
/*     */       }
/*     */       
/* 447 */       this._defaultViews = def;
/*     */     } 
/* 449 */     return this._defaultViews;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<Object, Object> findSerializationConverter() {
/* 461 */     if (this._annotationIntrospector == null) {
/* 462 */       return null;
/*     */     }
/* 464 */     return _createConverter(this._annotationIntrospector.findSerializationConverter(this._classInfo));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonInclude.Value findPropertyInclusion(JsonInclude.Value defValue) {
/* 475 */     if (this._annotationIntrospector != null) {
/* 476 */       JsonInclude.Value incl = this._annotationIntrospector.findPropertyInclusion(this._classInfo);
/* 477 */       if (incl != null) {
/* 478 */         return (defValue == null) ? incl : defValue.withOverrides(incl);
/*     */       }
/*     */     } 
/* 481 */     return defValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedMember findAnyGetter() throws IllegalArgumentException {
/* 493 */     if (this._propCollector != null) {
/* 494 */       AnnotatedMember anyGetter = this._propCollector.getAnyGetterMethod();
/* 495 */       if (anyGetter != null) {
/*     */ 
/*     */         
/* 498 */         Class<?> type = anyGetter.getRawType();
/* 499 */         if (!Map.class.isAssignableFrom(type)) {
/* 500 */           throw new IllegalArgumentException(String.format("Invalid 'any-getter' annotation on method %s(): return type is not instance of java.util.Map", new Object[] { anyGetter
/*     */                   
/* 502 */                   .getName() }));
/*     */         }
/* 504 */         return anyGetter;
/*     */       } 
/*     */       
/* 507 */       AnnotatedMember anyField = this._propCollector.getAnyGetterField();
/* 508 */       if (anyField != null) {
/*     */ 
/*     */         
/* 511 */         Class<?> type = anyField.getRawType();
/* 512 */         if (!Map.class.isAssignableFrom(type)) {
/* 513 */           throw new IllegalArgumentException(String.format("Invalid 'any-getter' annotation on field '%s': type is not instance of java.util.Map", new Object[] { anyField
/*     */                   
/* 515 */                   .getName() }));
/*     */         }
/* 517 */         return anyField;
/*     */       } 
/*     */     } 
/* 520 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<BeanPropertyDefinition> findBackReferences() {
/* 526 */     List<BeanPropertyDefinition> result = null;
/* 527 */     HashSet<String> names = null;
/* 528 */     for (BeanPropertyDefinition property : _properties()) {
/* 529 */       AnnotationIntrospector.ReferenceProperty refDef = property.findReferenceType();
/* 530 */       if (refDef == null || !refDef.isBackReference()) {
/*     */         continue;
/*     */       }
/* 533 */       String refName = refDef.getName();
/* 534 */       if (result == null) {
/* 535 */         result = new ArrayList<>();
/* 536 */         names = new HashSet<>();
/* 537 */         names.add(refName);
/*     */       }
/* 539 */       else if (!names.add(refName)) {
/* 540 */         throw new IllegalArgumentException("Multiple back-reference properties with name " + ClassUtil.name(refName));
/*     */       } 
/*     */       
/* 543 */       result.add(property);
/*     */     } 
/* 545 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Map<String, AnnotatedMember> findBackReferenceProperties() {
/* 552 */     List<BeanPropertyDefinition> props = findBackReferences();
/* 553 */     if (props == null) {
/* 554 */       return null;
/*     */     }
/* 556 */     Map<String, AnnotatedMember> result = new HashMap<>();
/* 557 */     for (BeanPropertyDefinition prop : props) {
/* 558 */       result.put(prop.getName(), prop.getMutator());
/*     */     }
/* 560 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotatedMethod> getFactoryMethods() {
/* 573 */     List<AnnotatedMethod> candidates = this._classInfo.getFactoryMethods();
/* 574 */     if (candidates.isEmpty()) {
/* 575 */       return candidates;
/*     */     }
/* 577 */     List<AnnotatedMethod> result = null;
/* 578 */     for (AnnotatedMethod am : candidates) {
/* 579 */       if (isFactoryMethod(am)) {
/* 580 */         if (result == null) {
/* 581 */           result = new ArrayList<>();
/*     */         }
/* 583 */         result.add(am);
/*     */       } 
/*     */     } 
/* 586 */     if (result == null) {
/* 587 */       return Collections.emptyList();
/*     */     }
/* 589 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode>> getFactoryMethodsWithMode() {
/* 595 */     List<AnnotatedMethod> candidates = this._classInfo.getFactoryMethods();
/* 596 */     if (candidates.isEmpty()) {
/* 597 */       return Collections.emptyList();
/*     */     }
/* 599 */     List<AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode>> result = null;
/* 600 */     for (AnnotatedMethod am : candidates) {
/*     */       
/* 602 */       AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode> match = findFactoryMethodMetadata(am);
/* 603 */       if (match != null) {
/* 604 */         if (result == null) {
/* 605 */           result = new ArrayList<>();
/*     */         }
/* 607 */         result.add(match);
/*     */       } 
/*     */     } 
/* 610 */     if (result == null) {
/* 611 */       return Collections.emptyList();
/*     */     }
/* 613 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Constructor<?> findSingleArgConstructor(Class<?>... argTypes) {
/* 620 */     for (AnnotatedConstructor ac : this._classInfo.getConstructors()) {
/*     */       
/* 622 */       if (ac.getParameterCount() == 1) {
/* 623 */         Class<?> actArg = ac.getRawParameterType(0);
/* 624 */         for (Class<?> expArg : argTypes) {
/* 625 */           if (expArg == actArg) {
/* 626 */             return ac.getAnnotated();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 631 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Method findFactoryMethod(Class<?>... expArgTypes) {
/* 639 */     for (AnnotatedMethod am : this._classInfo.getFactoryMethods()) {
/*     */       
/* 641 */       if (isFactoryMethod(am) && am.getParameterCount() == 1) {
/*     */         
/* 643 */         Class<?> actualArgType = am.getRawParameterType(0);
/* 644 */         for (Class<?> expArgType : expArgTypes) {
/*     */           
/* 646 */           if (actualArgType.isAssignableFrom(expArgType)) {
/* 647 */             return am.getAnnotated();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 652 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isFactoryMethod(AnnotatedMethod am) {
/* 659 */     Class<?> rt = am.getRawReturnType();
/* 660 */     if (!getBeanClass().isAssignableFrom(rt)) {
/* 661 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 668 */     JsonCreator.Mode mode = this._annotationIntrospector.findCreatorAnnotation(this._config, am);
/* 669 */     if (mode != null && mode != JsonCreator.Mode.DISABLED) {
/* 670 */       return true;
/*     */     }
/* 672 */     String name = am.getName();
/*     */     
/* 674 */     if ("valueOf".equals(name) && 
/* 675 */       am.getParameterCount() == 1) {
/* 676 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 680 */     if ("fromString".equals(name) && 
/* 681 */       am.getParameterCount() == 1) {
/* 682 */       Class<?> cls = am.getRawParameterType(0);
/* 683 */       if (cls == String.class || CharSequence.class.isAssignableFrom(cls)) {
/* 684 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 688 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode> findFactoryMethodMetadata(AnnotatedMethod am) {
/* 696 */     Class<?> rt = am.getRawReturnType();
/* 697 */     if (!getBeanClass().isAssignableFrom(rt)) {
/* 698 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 704 */     JsonCreator.Mode mode = this._annotationIntrospector.findCreatorAnnotation(this._config, am);
/* 705 */     if (mode != null) {
/* 706 */       if (mode == JsonCreator.Mode.DISABLED) {
/* 707 */         return null;
/*     */       }
/* 709 */       return AnnotatedAndMetadata.of(am, mode);
/*     */     } 
/* 711 */     String name = am.getName();
/*     */     
/* 713 */     if ("valueOf".equals(name) && 
/* 714 */       am.getParameterCount() == 1) {
/* 715 */       return AnnotatedAndMetadata.of(am, mode);
/*     */     }
/*     */ 
/*     */     
/* 719 */     if ("fromString".equals(name) && 
/* 720 */       am.getParameterCount() == 1) {
/* 721 */       Class<?> cls = am.getRawParameterType(0);
/* 722 */       if (cls == String.class || CharSequence.class.isAssignableFrom(cls)) {
/* 723 */         return AnnotatedAndMetadata.of(am, mode);
/*     */       }
/*     */     } 
/*     */     
/* 727 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected PropertyName _findCreatorPropertyName(AnnotatedParameter param) {
/* 736 */     PropertyName name = this._annotationIntrospector.findNameForDeserialization(param);
/* 737 */     if (name == null || name.isEmpty()) {
/* 738 */       String str = this._annotationIntrospector.findImplicitPropertyName(param);
/* 739 */       if (str != null && !str.isEmpty()) {
/* 740 */         name = PropertyName.construct(str);
/*     */       }
/*     */     } 
/* 743 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> findPOJOBuilder() {
/* 754 */     return (this._annotationIntrospector == null) ? null : this._annotationIntrospector
/* 755 */       .findPOJOBuilder(this._classInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPOJOBuilder.Value findPOJOBuilderConfig() {
/* 761 */     return (this._annotationIntrospector == null) ? null : this._annotationIntrospector
/* 762 */       .findPOJOBuilderConfig(this._classInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<Object, Object> findDeserializationConverter() {
/* 768 */     if (this._annotationIntrospector == null) {
/* 769 */       return null;
/*     */     }
/* 771 */     return _createConverter(this._annotationIntrospector.findDeserializationConverter(this._classInfo));
/*     */   }
/*     */ 
/*     */   
/*     */   public String findClassDescription() {
/* 776 */     return (this._annotationIntrospector == null) ? null : this._annotationIntrospector
/* 777 */       .findClassDescription(this._classInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public LinkedHashMap<String, AnnotatedField> _findPropertyFields(Collection<String> ignoredProperties, boolean forSerialization) {
/* 802 */     LinkedHashMap<String, AnnotatedField> results = new LinkedHashMap<>();
/* 803 */     for (BeanPropertyDefinition property : _properties()) {
/* 804 */       AnnotatedField f = property.getField();
/* 805 */       if (f != null) {
/* 806 */         String name = property.getName();
/* 807 */         if (ignoredProperties != null && 
/* 808 */           ignoredProperties.contains(name)) {
/*     */           continue;
/*     */         }
/*     */         
/* 812 */         results.put(name, f);
/*     */       } 
/*     */     } 
/* 815 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Converter<Object, Object> _createConverter(Object converterDef) {
/* 827 */     if (converterDef == null) {
/* 828 */       return null;
/*     */     }
/* 830 */     if (converterDef instanceof Converter) {
/* 831 */       return (Converter<Object, Object>)converterDef;
/*     */     }
/* 833 */     if (!(converterDef instanceof Class)) {
/* 834 */       throw new IllegalStateException("AnnotationIntrospector returned Converter definition of type " + converterDef
/* 835 */           .getClass().getName() + "; expected type Converter or Class<Converter> instead");
/*     */     }
/* 837 */     Class<?> converterClass = (Class)converterDef;
/*     */     
/* 839 */     if (converterClass == Converter.None.class || ClassUtil.isBogusClass(converterClass)) {
/* 840 */       return null;
/*     */     }
/* 842 */     if (!Converter.class.isAssignableFrom(converterClass)) {
/* 843 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + converterClass
/* 844 */           .getName() + "; expected Class<Converter>");
/*     */     }
/* 846 */     HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 847 */     Converter<?, ?> conv = (hi == null) ? null : hi.converterInstance(this._config, this._classInfo, converterClass);
/* 848 */     if (conv == null) {
/* 849 */       conv = (Converter<?, ?>)ClassUtil.createInstance(converterClass, this._config
/* 850 */           .canOverrideAccessModifiers());
/*     */     }
/* 852 */     return (Converter)conv;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\introspect\BasicBeanDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */