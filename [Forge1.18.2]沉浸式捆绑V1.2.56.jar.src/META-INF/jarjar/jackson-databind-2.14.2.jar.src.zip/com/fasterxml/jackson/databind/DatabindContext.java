/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DatabindContext
/*     */ {
/*     */   private static final int MAX_ERROR_STR_LEN = 500;
/*     */   
/*     */   public abstract MapperConfig<?> getConfig();
/*     */   
/*     */   public abstract AnnotationIntrospector getAnnotationIntrospector();
/*     */   
/*     */   public abstract boolean isEnabled(MapperFeature paramMapperFeature);
/*     */   
/*     */   public abstract boolean isEnabled(DatatypeFeature paramDatatypeFeature);
/*     */   
/*     */   public abstract boolean canOverrideAccessModifiers();
/*     */   
/*     */   public abstract Class<?> getActiveView();
/*     */   
/*     */   public abstract Locale getLocale();
/*     */   
/*     */   public abstract TimeZone getTimeZone();
/*     */   
/*     */   public abstract JsonFormat.Value getDefaultPropertyFormat(Class<?> paramClass);
/*     */   
/*     */   public abstract Object getAttribute(Object paramObject);
/*     */   
/*     */   public abstract DatabindContext setAttribute(Object paramObject1, Object paramObject2);
/*     */   
/*     */   public JavaType constructType(Type type) {
/* 156 */     if (type == null) {
/* 157 */       return null;
/*     */     }
/* 159 */     return getTypeFactory().constructType(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JavaType constructSpecializedType(JavaType paramJavaType, Class<?> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType resolveSubType(JavaType baseType, String subClassName) throws JsonMappingException {
/* 185 */     if (subClassName.indexOf('<') > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       JavaType t = getTypeFactory().constructFromCanonical(subClassName);
/* 191 */       if (t.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 192 */         return t;
/*     */       }
/*     */     } else {
/*     */       Class<?> cls;
/*     */       try {
/* 197 */         cls = getTypeFactory().findClass(subClassName);
/* 198 */       } catch (ClassNotFoundException e) {
/* 199 */         return null;
/* 200 */       } catch (Exception e) {
/* 201 */         throw invalidTypeIdException(baseType, subClassName, String.format("problem: (%s) %s", new Object[] { e
/*     */                 
/* 203 */                 .getClass().getName(), 
/* 204 */                 ClassUtil.exceptionMessage(e) }));
/*     */       } 
/* 206 */       if (baseType.isTypeOrSuperTypeOf(cls)) {
/* 207 */         return getTypeFactory().constructSpecializedType(baseType, cls);
/*     */       }
/*     */     } 
/* 210 */     throw invalidTypeIdException(baseType, subClassName, "Not a subtype");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType resolveAndValidateSubType(JavaType baseType, String subClass, PolymorphicTypeValidator ptv) throws JsonMappingException {
/*     */     Class<?> cls;
/* 224 */     int ltIndex = subClass.indexOf('<');
/* 225 */     if (ltIndex > 0) {
/* 226 */       return _resolveAndValidateGeneric(baseType, subClass, ptv, ltIndex);
/*     */     }
/* 228 */     MapperConfig<?> config = getConfig();
/* 229 */     PolymorphicTypeValidator.Validity vld = ptv.validateSubClassName(config, baseType, subClass);
/* 230 */     if (vld == PolymorphicTypeValidator.Validity.DENIED) {
/* 231 */       return _throwSubtypeNameNotAllowed(baseType, subClass, ptv);
/*     */     }
/*     */     
/*     */     try {
/* 235 */       cls = getTypeFactory().findClass(subClass);
/* 236 */     } catch (ClassNotFoundException e) {
/* 237 */       return null;
/* 238 */     } catch (Exception e) {
/* 239 */       throw invalidTypeIdException(baseType, subClass, String.format("problem: (%s) %s", new Object[] { e
/*     */               
/* 241 */               .getClass().getName(), 
/* 242 */               ClassUtil.exceptionMessage(e) }));
/*     */     } 
/* 244 */     if (!baseType.isTypeOrSuperTypeOf(cls)) {
/* 245 */       return _throwNotASubtype(baseType, subClass);
/*     */     }
/* 247 */     JavaType subType = config.getTypeFactory().constructSpecializedType(baseType, cls);
/*     */     
/* 249 */     if (vld == PolymorphicTypeValidator.Validity.INDETERMINATE) {
/* 250 */       vld = ptv.validateSubType(config, baseType, subType);
/* 251 */       if (vld != PolymorphicTypeValidator.Validity.ALLOWED) {
/* 252 */         return _throwSubtypeClassNotAllowed(baseType, subClass, ptv);
/*     */       }
/*     */     } 
/* 255 */     return subType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JavaType _resolveAndValidateGeneric(JavaType baseType, String subClass, PolymorphicTypeValidator ptv, int ltIndex) throws JsonMappingException {
/* 262 */     MapperConfig<?> config = getConfig();
/*     */ 
/*     */ 
/*     */     
/* 266 */     PolymorphicTypeValidator.Validity vld = ptv.validateSubClassName(config, baseType, subClass.substring(0, ltIndex));
/* 267 */     if (vld == PolymorphicTypeValidator.Validity.DENIED) {
/* 268 */       return _throwSubtypeNameNotAllowed(baseType, subClass, ptv);
/*     */     }
/* 270 */     JavaType subType = getTypeFactory().constructFromCanonical(subClass);
/* 271 */     if (!subType.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 272 */       return _throwNotASubtype(baseType, subClass);
/*     */     }
/*     */     
/* 275 */     if (vld != PolymorphicTypeValidator.Validity.ALLOWED && 
/* 276 */       ptv.validateSubType(config, baseType, subType) != PolymorphicTypeValidator.Validity.ALLOWED) {
/* 277 */       return _throwSubtypeClassNotAllowed(baseType, subClass, ptv);
/*     */     }
/*     */     
/* 280 */     return subType;
/*     */   }
/*     */   
/*     */   protected <T> T _throwNotASubtype(JavaType baseType, String subType) throws JsonMappingException {
/* 284 */     throw invalidTypeIdException(baseType, subType, "Not a subtype");
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T> T _throwSubtypeNameNotAllowed(JavaType baseType, String subType, PolymorphicTypeValidator ptv) throws JsonMappingException {
/* 289 */     throw invalidTypeIdException(baseType, subType, "Configured `PolymorphicTypeValidator` (of type " + 
/* 290 */         ClassUtil.classNameOf(ptv) + ") denied resolution");
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T> T _throwSubtypeClassNotAllowed(JavaType baseType, String subType, PolymorphicTypeValidator ptv) throws JsonMappingException {
/* 295 */     throw invalidTypeIdException(baseType, subType, "Configured `PolymorphicTypeValidator` (of type " + 
/* 296 */         ClassUtil.classNameOf(ptv) + ") denied resolution");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract JsonMappingException invalidTypeIdException(JavaType paramJavaType, String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract TypeFactory getTypeFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectIdGenerator<?> objectIdGeneratorInstance(Annotated annotated, ObjectIdInfo objectIdInfo) throws JsonMappingException {
/* 325 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/* 326 */     MapperConfig<?> config = getConfig();
/* 327 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/* 328 */     ObjectIdGenerator<?> gen = (hi == null) ? null : hi.objectIdGeneratorInstance(config, annotated, implClass);
/* 329 */     if (gen == null) {
/* 330 */       gen = (ObjectIdGenerator)ClassUtil.createInstance(implClass, config
/* 331 */           .canOverrideAccessModifiers());
/*     */     }
/* 333 */     return gen.forScope(objectIdInfo.getScope());
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectIdResolver objectIdResolverInstance(Annotated annotated, ObjectIdInfo objectIdInfo) {
/* 338 */     Class<? extends ObjectIdResolver> implClass = objectIdInfo.getResolverType();
/* 339 */     MapperConfig<?> config = getConfig();
/* 340 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/* 341 */     ObjectIdResolver resolver = (hi == null) ? null : hi.resolverIdGeneratorInstance(config, annotated, implClass);
/* 342 */     if (resolver == null) {
/* 343 */       resolver = (ObjectIdResolver)ClassUtil.createInstance(implClass, config.canOverrideAccessModifiers());
/*     */     }
/*     */     
/* 346 */     return resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<Object, Object> converterInstance(Annotated annotated, Object converterDef) throws JsonMappingException {
/* 360 */     if (converterDef == null) {
/* 361 */       return null;
/*     */     }
/* 363 */     if (converterDef instanceof Converter) {
/* 364 */       return (Converter<Object, Object>)converterDef;
/*     */     }
/* 366 */     if (!(converterDef instanceof Class)) {
/* 367 */       throw new IllegalStateException("AnnotationIntrospector returned Converter definition of type " + converterDef
/* 368 */           .getClass().getName() + "; expected type Converter or Class<Converter> instead");
/*     */     }
/* 370 */     Class<?> converterClass = (Class)converterDef;
/*     */     
/* 372 */     if (converterClass == Converter.None.class || ClassUtil.isBogusClass(converterClass)) {
/* 373 */       return null;
/*     */     }
/* 375 */     if (!Converter.class.isAssignableFrom(converterClass)) {
/* 376 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + converterClass
/* 377 */           .getName() + "; expected Class<Converter>");
/*     */     }
/* 379 */     MapperConfig<?> config = getConfig();
/* 380 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/* 381 */     Converter<?, ?> conv = (hi == null) ? null : hi.converterInstance(config, annotated, converterClass);
/* 382 */     if (conv == null) {
/* 383 */       conv = (Converter<?, ?>)ClassUtil.createInstance(converterClass, config
/* 384 */           .canOverrideAccessModifiers());
/*     */     }
/* 386 */     return (Converter)conv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract <T> T reportBadDefinition(JavaType paramJavaType, String paramString) throws JsonMappingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T reportBadDefinition(Class<?> type, String msg) throws JsonMappingException {
/* 408 */     return reportBadDefinition(constructType(type), msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _format(String msg, Object... msgArgs) {
/* 421 */     if (msgArgs.length > 0) {
/* 422 */       return String.format(msg, msgArgs);
/*     */     }
/* 424 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _truncate(String desc) {
/* 431 */     if (desc == null) {
/* 432 */       return "";
/*     */     }
/* 434 */     if (desc.length() <= 500) {
/* 435 */       return desc;
/*     */     }
/* 437 */     return desc.substring(0, 500) + "]...[" + desc.substring(desc.length() - 500);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _quotedString(String desc) {
/* 444 */     if (desc == null) {
/* 445 */       return "[N/A]";
/*     */     }
/*     */     
/* 448 */     return String.format("\"%s\"", new Object[] { _truncate(desc) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _colonConcat(String msgBase, String extra) {
/* 455 */     if (extra == null) {
/* 456 */       return msgBase;
/*     */     }
/* 458 */     return msgBase + ": " + extra;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _desc(String desc) {
/* 465 */     if (desc == null) {
/* 466 */       return "[N/A]";
/*     */     }
/*     */     
/* 469 */     return _truncate(desc);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\DatabindContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */