/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*      */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*      */ import com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig;
/*      */ import com.fasterxml.jackson.databind.deser.impl.FieldProperty;
/*      */ import com.fasterxml.jackson.databind.deser.impl.SetterlessProperty;
/*      */ import com.fasterxml.jackson.databind.deser.std.ThrowableDeserializer;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class BeanDeserializerFactory extends BasicDeserializerFactory implements Serializable {
/*   41 */   private static final Class<?>[] INIT_CAUSE_PARAMS = new Class[] { Throwable.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   53 */   public static final BeanDeserializerFactory instance = new BeanDeserializerFactory(new DeserializerFactoryConfig());
/*      */ 
/*      */   
/*      */   public BeanDeserializerFactory(DeserializerFactoryConfig config) {
/*   57 */     super(config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializerFactory withConfig(DeserializerFactoryConfig config) {
/*   68 */     if (this._factoryConfig == config) {
/*   69 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   77 */     ClassUtil.verifyMustOverride(BeanDeserializerFactory.class, this, "withConfig");
/*   78 */     return new BeanDeserializerFactory(config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> createBeanDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*   98 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  100 */     JsonDeserializer<?> deser = _findCustomBeanDeserializer(type, config, beanDesc);
/*  101 */     if (deser != null) {
/*      */       
/*  103 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/*  104 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  105 */           deser = mod.modifyDeserializer(ctxt.getConfig(), beanDesc, deser);
/*      */         }
/*      */       }
/*  108 */       return (JsonDeserializer)deser;
/*      */     } 
/*      */ 
/*      */     
/*  112 */     if (type.isThrowable()) {
/*  113 */       return buildThrowableDeserializer(ctxt, type, beanDesc);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  120 */     if (type.isAbstract() && !type.isPrimitive() && !type.isEnumType()) {
/*      */       
/*  122 */       JavaType concreteType = materializeAbstractType(ctxt, type, beanDesc);
/*  123 */       if (concreteType != null) {
/*      */ 
/*      */         
/*  126 */         beanDesc = config.introspect(concreteType);
/*  127 */         return buildBeanDeserializer(ctxt, concreteType, beanDesc);
/*      */       } 
/*      */     } 
/*      */     
/*  131 */     deser = findStdDeserializer(ctxt, type, beanDesc);
/*  132 */     if (deser != null) {
/*  133 */       return (JsonDeserializer)deser;
/*      */     }
/*      */ 
/*      */     
/*  137 */     if (!isPotentialBeanType(type.getRawClass())) {
/*  138 */       return null;
/*      */     }
/*      */     
/*  141 */     _validateSubType(ctxt, type, beanDesc);
/*      */ 
/*      */ 
/*      */     
/*  145 */     deser = _findUnsupportedTypeDeserializer(ctxt, type, beanDesc);
/*  146 */     if (deser != null) {
/*  147 */       return (JsonDeserializer)deser;
/*      */     }
/*      */ 
/*      */     
/*  151 */     return buildBeanDeserializer(ctxt, type, beanDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> createBuilderBasedDeserializer(DeserializationContext ctxt, JavaType valueType, BeanDescription valueBeanDesc, Class<?> builderClass) throws JsonMappingException {
/*      */     JavaType builderType;
/*  162 */     if (ctxt.isEnabled(MapperFeature.INFER_BUILDER_TYPE_BINDINGS)) {
/*  163 */       builderType = ctxt.getTypeFactory().constructParametricType(builderClass, valueType.getBindings());
/*      */     } else {
/*  165 */       builderType = ctxt.constructType(builderClass);
/*      */     } 
/*  167 */     BeanDescription builderDesc = ctxt.getConfig().introspectForBuilder(builderType, valueBeanDesc);
/*      */ 
/*      */     
/*  170 */     return buildBuilderBasedDeserializer(ctxt, valueType, builderDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> findStdDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*  183 */     JsonDeserializer<?> deser = findDefaultDeserializer(ctxt, type, beanDesc);
/*      */     
/*  185 */     if (deser != null && 
/*  186 */       this._factoryConfig.hasDeserializerModifiers()) {
/*  187 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  188 */         deser = mod.modifyDeserializer(ctxt.getConfig(), beanDesc, deser);
/*      */       }
/*      */     }
/*      */     
/*  192 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findUnsupportedTypeDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*  210 */     String errorMsg = BeanUtil.checkUnsupportedType(type);
/*  211 */     if (errorMsg != null)
/*      */     {
/*      */       
/*  214 */       if (ctxt.getConfig().findMixInClassFor(type.getRawClass()) == null) {
/*  215 */         return (JsonDeserializer<Object>)new UnsupportedTypeDeserializer(type, errorMsg);
/*      */       }
/*      */     }
/*  218 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType materializeAbstractType(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*  226 */     for (AbstractTypeResolver r : this._factoryConfig.abstractTypeResolvers()) {
/*  227 */       JavaType concrete = r.resolveAbstractType(ctxt.getConfig(), beanDesc);
/*  228 */       if (concrete != null) {
/*  229 */         return concrete;
/*      */       }
/*      */     } 
/*  232 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> buildBeanDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     ValueInstantiator valueInstantiator;
/*      */     JsonDeserializer<?> deserializer;
/*      */     try {
/*  262 */       valueInstantiator = findValueInstantiator(ctxt, beanDesc);
/*  263 */     } catch (NoClassDefFoundError error) {
/*  264 */       return (JsonDeserializer<Object>)new ErrorThrowingDeserializer(error);
/*  265 */     } catch (IllegalArgumentException e0) {
/*      */ 
/*      */ 
/*      */       
/*  269 */       throw InvalidDefinitionException.from(ctxt.getParser(), 
/*  270 */           ClassUtil.exceptionMessage(e0), beanDesc, null)
/*      */         
/*  272 */         .withCause(e0);
/*      */     } 
/*  274 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, beanDesc);
/*  275 */     builder.setValueInstantiator(valueInstantiator);
/*      */     
/*  277 */     addBeanProps(ctxt, beanDesc, builder);
/*  278 */     addObjectIdReader(ctxt, beanDesc, builder);
/*      */ 
/*      */     
/*  281 */     addBackReferenceProperties(ctxt, beanDesc, builder);
/*  282 */     addInjectables(ctxt, beanDesc, builder);
/*      */     
/*  284 */     DeserializationConfig config = ctxt.getConfig();
/*  285 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  286 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  287 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  292 */     if (type.isAbstract() && !valueInstantiator.canInstantiate()) {
/*  293 */       deserializer = builder.buildAbstract();
/*      */     } else {
/*  295 */       deserializer = builder.build();
/*      */     } 
/*      */ 
/*      */     
/*  299 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  300 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  301 */         deserializer = mod.modifyDeserializer(config, beanDesc, deserializer);
/*      */       }
/*      */     }
/*  304 */     return (JsonDeserializer)deserializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> buildBuilderBasedDeserializer(DeserializationContext ctxt, JavaType valueType, BeanDescription builderDesc) throws JsonMappingException {
/*      */     ValueInstantiator valueInstantiator;
/*      */     try {
/*  322 */       valueInstantiator = findValueInstantiator(ctxt, builderDesc);
/*  323 */     } catch (NoClassDefFoundError error) {
/*  324 */       return (JsonDeserializer<Object>)new ErrorThrowingDeserializer(error);
/*  325 */     } catch (IllegalArgumentException e) {
/*      */ 
/*      */ 
/*      */       
/*  329 */       throw InvalidDefinitionException.from(ctxt.getParser(), 
/*  330 */           ClassUtil.exceptionMessage(e), builderDesc, null);
/*      */     } 
/*      */     
/*  333 */     DeserializationConfig config = ctxt.getConfig();
/*  334 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, builderDesc);
/*  335 */     builder.setValueInstantiator(valueInstantiator);
/*      */     
/*  337 */     addBeanProps(ctxt, builderDesc, builder);
/*  338 */     addObjectIdReader(ctxt, builderDesc, builder);
/*      */ 
/*      */     
/*  341 */     addBackReferenceProperties(ctxt, builderDesc, builder);
/*  342 */     addInjectables(ctxt, builderDesc, builder);
/*      */     
/*  344 */     JsonPOJOBuilder.Value builderConfig = builderDesc.findPOJOBuilderConfig();
/*  345 */     String buildMethodName = (builderConfig == null) ? "build" : builderConfig.buildMethodName;
/*      */ 
/*      */ 
/*      */     
/*  349 */     AnnotatedMethod buildMethod = builderDesc.findMethod(buildMethodName, null);
/*  350 */     if (buildMethod != null && 
/*  351 */       config.canOverrideAccessModifiers()) {
/*  352 */       ClassUtil.checkAndFixAccess(buildMethod.getMember(), config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */     }
/*      */     
/*  355 */     builder.setPOJOBuilder(buildMethod, builderConfig);
/*      */     
/*  357 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  358 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  359 */         builder = mod.updateBuilder(config, builderDesc, builder);
/*      */       }
/*      */     }
/*  362 */     JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, buildMethodName);
/*      */ 
/*      */ 
/*      */     
/*  366 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  367 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  368 */         deserializer = mod.modifyDeserializer(config, builderDesc, deserializer);
/*      */       }
/*      */     }
/*  371 */     return (JsonDeserializer)deserializer;
/*      */   }
/*      */   
/*      */   protected void addObjectIdReader(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*      */     JavaType idType;
/*      */     SettableBeanProperty idProp;
/*      */     ObjectIdGenerator<?> gen;
/*  378 */     ObjectIdInfo objectIdInfo = beanDesc.getObjectIdInfo();
/*  379 */     if (objectIdInfo == null) {
/*      */       return;
/*      */     }
/*  382 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  387 */     ObjectIdResolver resolver = ctxt.objectIdResolverInstance((Annotated)beanDesc.getClassInfo(), objectIdInfo);
/*      */ 
/*      */     
/*  390 */     if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/*  391 */       PropertyName propName = objectIdInfo.getPropertyName();
/*  392 */       idProp = builder.findProperty(propName);
/*  393 */       if (idProp == null)
/*  394 */         throw new IllegalArgumentException(String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*      */                 
/*  396 */                 ClassUtil.getTypeDescription(beanDesc.getType()), 
/*  397 */                 ClassUtil.name(propName)
/*      */               })); 
/*  399 */       idType = idProp.getType();
/*  400 */       PropertyBasedObjectIdGenerator propertyBasedObjectIdGenerator = new PropertyBasedObjectIdGenerator(objectIdInfo.getScope());
/*      */     } else {
/*  402 */       JavaType type = ctxt.constructType(implClass);
/*  403 */       idType = ctxt.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/*  404 */       idProp = null;
/*  405 */       gen = ctxt.objectIdGeneratorInstance((Annotated)beanDesc.getClassInfo(), objectIdInfo);
/*      */     } 
/*      */     
/*  408 */     JsonDeserializer<?> deser = ctxt.findRootValueDeserializer(idType);
/*  409 */     builder.setObjectIdReader(ObjectIdReader.construct(idType, objectIdInfo
/*  410 */           .getPropertyName(), gen, deser, idProp, resolver));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> buildThrowableDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     ThrowableDeserializer throwableDeserializer;
/*      */     JsonDeserializer<?> jsonDeserializer1;
/*  418 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  420 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, beanDesc);
/*  421 */     builder.setValueInstantiator(findValueInstantiator(ctxt, beanDesc));
/*      */     
/*  423 */     addBeanProps(ctxt, beanDesc, builder);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  430 */     Iterator<SettableBeanProperty> it = builder.getProperties();
/*  431 */     while (it.hasNext()) {
/*  432 */       SettableBeanProperty prop = it.next();
/*  433 */       if ("setCause".equals(prop.getMember().getName())) {
/*      */         
/*  435 */         it.remove();
/*      */         break;
/*      */       } 
/*      */     } 
/*  439 */     AnnotatedMethod am = beanDesc.findMethod("initCause", INIT_CAUSE_PARAMS);
/*  440 */     if (am != null) {
/*      */       
/*  442 */       String name = "cause";
/*  443 */       PropertyNamingStrategy pts = config.getPropertyNamingStrategy();
/*  444 */       if (pts != null) {
/*  445 */         name = pts.nameForSetterMethod((MapperConfig)config, am, "cause");
/*      */       }
/*  447 */       SimpleBeanPropertyDefinition propDef = SimpleBeanPropertyDefinition.construct((MapperConfig)ctxt.getConfig(), (AnnotatedMember)am, new PropertyName(name));
/*      */       
/*  449 */       SettableBeanProperty prop = constructSettableProperty(ctxt, beanDesc, (BeanPropertyDefinition)propDef, am
/*  450 */           .getParameterType(0));
/*  451 */       if (prop != null)
/*      */       {
/*      */         
/*  454 */         builder.addOrReplaceProperty(prop, true);
/*      */       }
/*      */     } 
/*      */     
/*  458 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  459 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  460 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*      */       }
/*      */     }
/*  463 */     JsonDeserializer<?> deserializer = builder.build();
/*      */ 
/*      */ 
/*      */     
/*  467 */     if (deserializer instanceof BeanDeserializer) {
/*  468 */       throwableDeserializer = ThrowableDeserializer.construct(ctxt, (BeanDeserializer)deserializer);
/*      */     }
/*      */ 
/*      */     
/*  472 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  473 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  474 */         jsonDeserializer1 = mod.modifyDeserializer(config, beanDesc, (JsonDeserializer<?>)throwableDeserializer);
/*      */       }
/*      */     }
/*  477 */     return (JsonDeserializer)jsonDeserializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBuilder constructBeanDeserializerBuilder(DeserializationContext ctxt, BeanDescription beanDesc) {
/*  493 */     return new BeanDeserializerBuilder(beanDesc, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*      */     Set<String> ignored;
/*  507 */     boolean isConcrete = !beanDesc.getType().isAbstract();
/*      */     
/*  509 */     SettableBeanProperty[] creatorProps = isConcrete ? builder.getValueInstantiator().getFromObjectArguments(ctxt.getConfig()) : null;
/*      */     
/*  511 */     boolean hasCreatorProps = (creatorProps != null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  518 */     JsonIgnoreProperties.Value ignorals = ctxt.getConfig().getDefaultPropertyIgnorals(beanDesc.getBeanClass(), beanDesc
/*  519 */         .getClassInfo());
/*      */     
/*  521 */     if (ignorals != null) {
/*  522 */       boolean ignoreAny = ignorals.getIgnoreUnknown();
/*  523 */       builder.setIgnoreUnknownProperties(ignoreAny);
/*      */       
/*  525 */       ignored = ignorals.findIgnoredForDeserialization();
/*  526 */       for (String propName : ignored) {
/*  527 */         builder.addIgnorable(propName);
/*      */       }
/*      */     } else {
/*  530 */       ignored = Collections.emptySet();
/*      */     } 
/*      */     
/*  533 */     JsonIncludeProperties.Value inclusions = ctxt.getConfig().getDefaultPropertyInclusions(beanDesc.getBeanClass(), beanDesc
/*  534 */         .getClassInfo());
/*  535 */     Set<String> included = null;
/*  536 */     if (inclusions != null) {
/*  537 */       included = inclusions.getIncluded();
/*  538 */       if (included != null) {
/*  539 */         for (String propName : included) {
/*  540 */           builder.addIncludable(propName);
/*      */         }
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  546 */     AnnotatedMember anySetter = beanDesc.findAnySetterAccessor();
/*  547 */     if (anySetter != null) {
/*  548 */       builder.setAnySetter(constructAnySetter(ctxt, beanDesc, anySetter));
/*      */     }
/*      */     else {
/*      */       
/*  552 */       Collection<String> ignored2 = beanDesc.getIgnoredPropertyNames();
/*  553 */       if (ignored2 != null) {
/*  554 */         for (String propName : ignored2)
/*      */         {
/*      */           
/*  557 */           builder.addIgnorable(propName);
/*      */         }
/*      */       }
/*      */     } 
/*      */     
/*  562 */     boolean useGettersAsSetters = (ctxt.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS) && ctxt.isEnabled(MapperFeature.AUTO_DETECT_GETTERS));
/*      */ 
/*      */     
/*  565 */     List<BeanPropertyDefinition> propDefs = filterBeanProps(ctxt, beanDesc, builder, beanDesc
/*  566 */         .findProperties(), ignored, included);
/*      */     
/*  568 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  569 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  570 */         propDefs = mod.updateProperties(ctxt.getConfig(), beanDesc, propDefs);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  575 */     for (BeanPropertyDefinition propDef : propDefs) {
/*  576 */       SettableBeanProperty prop = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  581 */       if (propDef.hasSetter()) {
/*  582 */         AnnotatedMethod setter = propDef.getSetter();
/*  583 */         JavaType propertyType = setter.getParameterType(0);
/*  584 */         prop = constructSettableProperty(ctxt, beanDesc, propDef, propertyType);
/*  585 */       } else if (propDef.hasField()) {
/*  586 */         AnnotatedField field = propDef.getField();
/*  587 */         JavaType propertyType = field.getType();
/*  588 */         prop = constructSettableProperty(ctxt, beanDesc, propDef, propertyType);
/*      */       } else {
/*      */         
/*  591 */         AnnotatedMethod getter = propDef.getGetter();
/*  592 */         if (getter != null) {
/*  593 */           if (useGettersAsSetters && _isSetterlessType(getter.getRawType())) {
/*      */ 
/*      */             
/*  596 */             if (!builder.hasIgnorable(propDef.getName()))
/*      */             {
/*      */               
/*  599 */               prop = constructSetterlessProperty(ctxt, beanDesc, propDef);
/*      */             }
/*  601 */           } else if (!propDef.hasConstructorParameter()) {
/*  602 */             PropertyMetadata md = propDef.getMetadata();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  607 */             if (md.getMergeInfo() != null) {
/*  608 */               prop = constructSetterlessProperty(ctxt, beanDesc, propDef);
/*      */             }
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  616 */       if (hasCreatorProps && propDef.hasConstructorParameter()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  622 */         String name = propDef.getName();
/*  623 */         CreatorProperty cprop = null;
/*      */         
/*  625 */         for (SettableBeanProperty cp : creatorProps) {
/*  626 */           if (name.equals(cp.getName()) && cp instanceof CreatorProperty) {
/*  627 */             cprop = (CreatorProperty)cp;
/*      */             break;
/*      */           } 
/*      */         } 
/*  631 */         if (cprop == null) {
/*  632 */           List<String> n = new ArrayList<>();
/*  633 */           for (SettableBeanProperty cp : creatorProps) {
/*  634 */             n.add(cp.getName());
/*      */           }
/*  636 */           ctxt.reportBadPropertyDefinition(beanDesc, propDef, "Could not find creator property with name %s (known Creator properties: %s)", new Object[] {
/*      */                 
/*  638 */                 ClassUtil.name(name), n });
/*      */           continue;
/*      */         } 
/*  641 */         if (prop != null) {
/*  642 */           cprop.setFallbackSetter(prop);
/*      */         }
/*  644 */         Class<?>[] views = propDef.findViews();
/*  645 */         if (views == null) {
/*  646 */           views = beanDesc.findDefaultViews();
/*      */         }
/*  648 */         cprop.setViews(views);
/*  649 */         builder.addCreatorProperty(cprop);
/*      */         continue;
/*      */       } 
/*  652 */       if (prop != null) {
/*      */         
/*  654 */         Class<?>[] views = propDef.findViews();
/*  655 */         if (views == null) {
/*  656 */           views = beanDesc.findDefaultViews();
/*      */         }
/*  658 */         prop.setViews(views);
/*  659 */         builder.addProperty(prop);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _isSetterlessType(Class<?> rawType) {
/*  668 */     return (Collection.class.isAssignableFrom(rawType) || Map.class
/*  669 */       .isAssignableFrom(rawType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected List<BeanPropertyDefinition> filterBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder, List<BeanPropertyDefinition> propDefsIn, Set<String> ignored) throws JsonMappingException {
/*  687 */     return filterBeanProps(ctxt, beanDesc, builder, propDefsIn, ignored, (Set<String>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<BeanPropertyDefinition> filterBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder, List<BeanPropertyDefinition> propDefsIn, Set<String> ignored, Set<String> included) {
/*  705 */     ArrayList<BeanPropertyDefinition> result = new ArrayList<>(Math.max(4, propDefsIn.size()));
/*  706 */     HashMap<Class<?>, Boolean> ignoredTypes = new HashMap<>();
/*      */     
/*  708 */     for (BeanPropertyDefinition property : propDefsIn) {
/*  709 */       String name = property.getName();
/*      */       
/*  711 */       if (IgnorePropertiesUtil.shouldIgnore(name, ignored, included)) {
/*      */         continue;
/*      */       }
/*  714 */       if (!property.hasConstructorParameter()) {
/*  715 */         Class<?> rawPropertyType = property.getRawPrimaryType();
/*      */         
/*  717 */         if (rawPropertyType != null && 
/*  718 */           isIgnorableType(ctxt.getConfig(), property, rawPropertyType, ignoredTypes)) {
/*      */           
/*  720 */           builder.addIgnorable(name);
/*      */           continue;
/*      */         } 
/*      */       } 
/*  724 */       result.add(property);
/*      */     } 
/*  726 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addBackReferenceProperties(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*  740 */     List<BeanPropertyDefinition> refProps = beanDesc.findBackReferences();
/*  741 */     if (refProps != null) {
/*  742 */       for (BeanPropertyDefinition refProp : refProps) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  759 */         String refName = refProp.findReferenceName();
/*  760 */         builder.addBackReferenceProperty(refName, constructSettableProperty(ctxt, beanDesc, refProp, refProp
/*  761 */               .getPrimaryType()));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void addReferenceProperties(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*  771 */     addBackReferenceProperties(ctxt, beanDesc, builder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addInjectables(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*  782 */     Map<Object, AnnotatedMember> raw = beanDesc.findInjectables();
/*  783 */     if (raw != null) {
/*  784 */       for (Map.Entry<Object, AnnotatedMember> entry : raw.entrySet()) {
/*  785 */         AnnotatedMember m = entry.getValue();
/*  786 */         builder.addInjectable(PropertyName.construct(m.getName()), m
/*  787 */             .getType(), beanDesc
/*  788 */             .getClassAnnotations(), m, entry.getKey());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableAnyProperty constructAnySetter(DeserializationContext ctxt, BeanDescription beanDesc, AnnotatedMember mutator) throws JsonMappingException {
/*      */     BeanProperty.Std std;
/*      */     JavaType keyType, valueType;
/*  810 */     boolean isField = mutator instanceof AnnotatedField;
/*      */     
/*  812 */     if (mutator instanceof AnnotatedMethod) {
/*      */       
/*  814 */       AnnotatedMethod am = (AnnotatedMethod)mutator;
/*  815 */       keyType = am.getParameterType(0);
/*  816 */       valueType = am.getParameterType(1);
/*  817 */       valueType = resolveMemberAndTypeAnnotations(ctxt, mutator, valueType);
/*  818 */       std = new BeanProperty.Std(PropertyName.construct(mutator.getName()), valueType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */ 
/*      */     
/*      */     }
/*  822 */     else if (isField) {
/*  823 */       AnnotatedField af = (AnnotatedField)mutator;
/*      */       
/*  825 */       JavaType fieldType = af.getType();
/*      */       
/*  827 */       if (fieldType.isMapLikeType()) {
/*  828 */         fieldType = resolveMemberAndTypeAnnotations(ctxt, mutator, fieldType);
/*  829 */         keyType = fieldType.getKeyType();
/*  830 */         valueType = fieldType.getContentType();
/*  831 */         std = new BeanProperty.Std(PropertyName.construct(mutator.getName()), fieldType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */       } else {
/*  833 */         if (fieldType.hasRawClass(JsonNode.class) || fieldType
/*  834 */           .hasRawClass(ObjectNode.class)) {
/*  835 */           fieldType = resolveMemberAndTypeAnnotations(ctxt, mutator, fieldType);
/*      */           
/*  837 */           valueType = ctxt.constructType(JsonNode.class);
/*  838 */           std = new BeanProperty.Std(PropertyName.construct(mutator.getName()), fieldType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  843 */           return SettableAnyProperty.constructForJsonNodeField(ctxt, (BeanProperty)std, mutator, valueType, ctxt
/*      */               
/*  845 */               .findRootValueDeserializer(valueType));
/*      */         } 
/*  847 */         return (SettableAnyProperty)ctxt.reportBadDefinition(beanDesc.getType(), String.format("Unsupported type for any-setter: %s -- only support `Map`s, `JsonNode` and `ObjectNode` ", new Object[] {
/*      */                 
/*  849 */                 ClassUtil.getTypeDescription(fieldType) }));
/*      */       } 
/*      */     } else {
/*  852 */       return (SettableAnyProperty)ctxt.reportBadDefinition(beanDesc.getType(), String.format("Unrecognized mutator type for any-setter: %s", new Object[] {
/*      */               
/*  854 */               ClassUtil.nameOf(mutator.getClass())
/*      */             }));
/*      */     } 
/*      */     
/*  858 */     KeyDeserializer keyDeser = findKeyDeserializerFromAnnotation(ctxt, (Annotated)mutator);
/*  859 */     if (keyDeser == null) {
/*  860 */       keyDeser = (KeyDeserializer)keyType.getValueHandler();
/*      */     }
/*  862 */     if (keyDeser == null) {
/*  863 */       keyDeser = ctxt.findKeyDeserializer(keyType, (BeanProperty)std);
/*      */     }
/*  865 */     else if (keyDeser instanceof ContextualKeyDeserializer) {
/*      */       
/*  867 */       keyDeser = ((ContextualKeyDeserializer)keyDeser).createContextual(ctxt, (BeanProperty)std);
/*      */     } 
/*      */     
/*  870 */     JsonDeserializer<Object> deser = findContentDeserializerFromAnnotation(ctxt, (Annotated)mutator);
/*  871 */     if (deser == null) {
/*  872 */       deser = (JsonDeserializer<Object>)valueType.getValueHandler();
/*      */     }
/*  874 */     if (deser != null)
/*      */     {
/*  876 */       deser = ctxt.handlePrimaryContextualization(deser, (BeanProperty)std, valueType);
/*      */     }
/*  878 */     TypeDeserializer typeDeser = (TypeDeserializer)valueType.getTypeHandler();
/*  879 */     if (isField) {
/*  880 */       return SettableAnyProperty.constructForMapField(ctxt, (BeanProperty)std, mutator, valueType, keyDeser, deser, typeDeser);
/*      */     }
/*      */     
/*  883 */     return SettableAnyProperty.constructForMethod(ctxt, (BeanProperty)std, mutator, valueType, keyDeser, deser, typeDeser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty constructSettableProperty(DeserializationContext ctxt, BeanDescription beanDesc, BeanPropertyDefinition propDef, JavaType propType0) throws JsonMappingException {
/*      */     FieldProperty fieldProperty;
/*      */     SettableBeanProperty settableBeanProperty;
/*  900 */     AnnotatedMember mutator = propDef.getNonConstructorMutator();
/*      */ 
/*      */ 
/*      */     
/*  904 */     if (mutator == null) {
/*  905 */       ctxt.reportBadPropertyDefinition(beanDesc, propDef, "No non-constructor mutator available", new Object[0]);
/*      */     }
/*  907 */     JavaType type = resolveMemberAndTypeAnnotations(ctxt, mutator, propType0);
/*      */     
/*  909 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */     
/*  911 */     if (mutator instanceof AnnotatedMethod) {
/*      */       
/*  913 */       MethodProperty methodProperty = new MethodProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), (AnnotatedMethod)mutator);
/*      */     }
/*      */     else {
/*      */       
/*  917 */       fieldProperty = new FieldProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), (AnnotatedField)mutator);
/*      */     } 
/*  919 */     JsonDeserializer<?> deser = findDeserializerFromAnnotation(ctxt, (Annotated)mutator);
/*  920 */     if (deser == null) {
/*  921 */       deser = (JsonDeserializer)type.getValueHandler();
/*      */     }
/*  923 */     if (deser != null) {
/*  924 */       deser = ctxt.handlePrimaryContextualization(deser, (BeanProperty)fieldProperty, type);
/*  925 */       settableBeanProperty = fieldProperty.withValueDeserializer(deser);
/*      */     } 
/*      */     
/*  928 */     AnnotationIntrospector.ReferenceProperty ref = propDef.findReferenceType();
/*  929 */     if (ref != null && ref.isManagedReference()) {
/*  930 */       settableBeanProperty.setManagedReferenceName(ref.getName());
/*      */     }
/*  932 */     ObjectIdInfo objectIdInfo = propDef.findObjectIdInfo();
/*  933 */     if (objectIdInfo != null) {
/*  934 */       settableBeanProperty.setObjectIdInfo(objectIdInfo);
/*      */     }
/*  936 */     return settableBeanProperty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty constructSetterlessProperty(DeserializationContext ctxt, BeanDescription beanDesc, BeanPropertyDefinition propDef) throws JsonMappingException {
/*      */     SettableBeanProperty settableBeanProperty;
/*  947 */     AnnotatedMethod getter = propDef.getGetter();
/*  948 */     JavaType type = resolveMemberAndTypeAnnotations(ctxt, (AnnotatedMember)getter, getter.getType());
/*  949 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */     
/*  951 */     SetterlessProperty setterlessProperty = new SetterlessProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), getter);
/*  952 */     JsonDeserializer<?> deser = findDeserializerFromAnnotation(ctxt, (Annotated)getter);
/*  953 */     if (deser == null) {
/*  954 */       deser = (JsonDeserializer)type.getValueHandler();
/*      */     }
/*  956 */     if (deser != null) {
/*  957 */       deser = ctxt.handlePrimaryContextualization(deser, (BeanProperty)setterlessProperty, type);
/*  958 */       settableBeanProperty = setterlessProperty.withValueDeserializer(deser);
/*      */     } 
/*  960 */     return settableBeanProperty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isPotentialBeanType(Class<?> type) {
/*  979 */     String typeStr = ClassUtil.canBeABeanType(type);
/*  980 */     if (typeStr != null) {
/*  981 */       throw new IllegalArgumentException("Cannot deserialize Class " + type.getName() + " (of type " + typeStr + ") as a Bean");
/*      */     }
/*  983 */     if (ClassUtil.isProxyType(type)) {
/*  984 */       throw new IllegalArgumentException("Cannot deserialize Proxy class " + type.getName() + " as a Bean");
/*      */     }
/*      */ 
/*      */     
/*  988 */     typeStr = ClassUtil.isLocalType(type, true);
/*  989 */     if (typeStr != null) {
/*  990 */       throw new IllegalArgumentException("Cannot deserialize Class " + type.getName() + " (of type " + typeStr + ") as a Bean");
/*      */     }
/*  992 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isIgnorableType(DeserializationConfig config, BeanPropertyDefinition propDef, Class<?> type, Map<Class<?>, Boolean> ignoredTypes) {
/* 1002 */     Boolean status = ignoredTypes.get(type);
/* 1003 */     if (status != null) {
/* 1004 */       return status.booleanValue();
/*      */     }
/*      */     
/* 1007 */     if (type == String.class || type.isPrimitive()) {
/* 1008 */       status = Boolean.FALSE;
/*      */     } else {
/*      */       
/* 1011 */       status = config.getConfigOverride(type).getIsIgnoredType();
/* 1012 */       if (status == null) {
/* 1013 */         BeanDescription desc = config.introspectClassAnnotations(type);
/* 1014 */         status = config.getAnnotationIntrospector().isIgnorableType(desc.getClassInfo());
/*      */         
/* 1016 */         if (status == null) {
/* 1017 */           status = Boolean.FALSE;
/*      */         }
/*      */       } 
/*      */     } 
/* 1021 */     ignoredTypes.put(type, status);
/* 1022 */     return status.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _validateSubType(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 1032 */     SubTypeValidator.instance().validateSubType(ctxt, type, beanDesc);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */