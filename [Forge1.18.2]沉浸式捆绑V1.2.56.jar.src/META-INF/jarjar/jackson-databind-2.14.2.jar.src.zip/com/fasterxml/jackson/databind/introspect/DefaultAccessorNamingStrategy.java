/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jdk14.JDK14Util;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultAccessorNamingStrategy
/*     */   extends AccessorNamingStrategy
/*     */ {
/*     */   protected final MapperConfig<?> _config;
/*     */   protected final AnnotatedClass _forClass;
/*     */   protected final BaseNameValidator _baseNameValidator;
/*     */   protected final boolean _stdBeanNaming;
/*     */   protected final boolean _isGettersNonBoolean;
/*     */   protected final String _getterPrefix;
/*     */   protected final String _isGetterPrefix;
/*     */   protected final String _mutatorPrefix;
/*     */   
/*     */   protected DefaultAccessorNamingStrategy(MapperConfig<?> config, AnnotatedClass forClass, String mutatorPrefix, String getterPrefix, String isGetterPrefix, BaseNameValidator baseNameValidator) {
/*  63 */     this._config = config;
/*  64 */     this._forClass = forClass;
/*     */     
/*  66 */     this._stdBeanNaming = config.isEnabled(MapperFeature.USE_STD_BEAN_NAMING);
/*  67 */     this._isGettersNonBoolean = config.isEnabled(MapperFeature.ALLOW_IS_GETTERS_FOR_NON_BOOLEAN);
/*  68 */     this._mutatorPrefix = mutatorPrefix;
/*  69 */     this._getterPrefix = getterPrefix;
/*  70 */     this._isGetterPrefix = isGetterPrefix;
/*  71 */     this._baseNameValidator = baseNameValidator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String findNameForIsGetter(AnnotatedMethod am, String name) {
/*  77 */     if (this._isGetterPrefix != null) {
/*  78 */       Class<?> rt = am.getRawType();
/*  79 */       if ((this._isGettersNonBoolean || rt == Boolean.class || rt == boolean.class) && 
/*  80 */         name.startsWith(this._isGetterPrefix)) {
/*  81 */         return this._stdBeanNaming ? 
/*  82 */           stdManglePropertyName(name, 2) : 
/*  83 */           legacyManglePropertyName(name, 2);
/*     */       }
/*     */     } 
/*     */     
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String findNameForRegularGetter(AnnotatedMethod am, String name) {
/*  93 */     if (this._getterPrefix != null && name.startsWith(this._getterPrefix)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  98 */       if ("getCallbacks".equals(name)) {
/*  99 */         if (_isCglibGetCallbacks(am)) {
/* 100 */           return null;
/*     */         }
/* 102 */       } else if ("getMetaClass".equals(name)) {
/*     */         
/* 104 */         if (_isGroovyMetaClassGetter(am)) {
/* 105 */           return null;
/*     */         }
/*     */       } 
/* 108 */       return this._stdBeanNaming ? 
/* 109 */         stdManglePropertyName(name, this._getterPrefix.length()) : 
/* 110 */         legacyManglePropertyName(name, this._getterPrefix.length());
/*     */     } 
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String findNameForMutator(AnnotatedMethod am, String name) {
/* 118 */     if (this._mutatorPrefix != null && name.startsWith(this._mutatorPrefix)) {
/* 119 */       return this._stdBeanNaming ? 
/* 120 */         stdManglePropertyName(name, this._mutatorPrefix.length()) : 
/* 121 */         legacyManglePropertyName(name, this._mutatorPrefix.length());
/*     */     }
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String modifyFieldName(AnnotatedField field, String name) {
/* 129 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String legacyManglePropertyName(String basename, int offset) {
/* 147 */     int end = basename.length();
/* 148 */     if (end == offset) {
/* 149 */       return null;
/*     */     }
/* 151 */     char c = basename.charAt(offset);
/*     */ 
/*     */     
/* 154 */     if (this._baseNameValidator != null && 
/* 155 */       !this._baseNameValidator.accept(c, basename, offset)) {
/* 156 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 161 */     char d = Character.toLowerCase(c);
/*     */     
/* 163 */     if (c == d) {
/* 164 */       return basename.substring(offset);
/*     */     }
/*     */     
/* 167 */     StringBuilder sb = new StringBuilder(end - offset);
/* 168 */     sb.append(d);
/* 169 */     int i = offset + 1;
/* 170 */     for (; i < end; i++) {
/* 171 */       c = basename.charAt(i);
/* 172 */       d = Character.toLowerCase(c);
/* 173 */       if (c == d) {
/* 174 */         sb.append(basename, i, end);
/*     */         break;
/*     */       } 
/* 177 */       sb.append(d);
/*     */     } 
/* 179 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String stdManglePropertyName(String basename, int offset) {
/* 184 */     int end = basename.length();
/* 185 */     if (end == offset) {
/* 186 */       return null;
/*     */     }
/*     */     
/* 189 */     char c0 = basename.charAt(offset);
/*     */ 
/*     */     
/* 192 */     if (this._baseNameValidator != null && 
/* 193 */       !this._baseNameValidator.accept(c0, basename, offset)) {
/* 194 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 198 */     char c1 = Character.toLowerCase(c0);
/* 199 */     if (c0 == c1) {
/* 200 */       return basename.substring(offset);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 205 */     if (offset + 1 < end && 
/* 206 */       Character.isUpperCase(basename.charAt(offset + 1))) {
/* 207 */       return basename.substring(offset);
/*     */     }
/*     */     
/* 210 */     StringBuilder sb = new StringBuilder(end - offset);
/* 211 */     sb.append(c1);
/* 212 */     sb.append(basename, offset + 1, end);
/* 213 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _isCglibGetCallbacks(AnnotatedMethod am) {
/* 229 */     Class<?> rt = am.getRawType();
/*     */     
/* 231 */     if (rt.isArray()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 236 */       Class<?> compType = rt.getComponentType();
/*     */       
/* 238 */       String className = compType.getName();
/* 239 */       if (className.contains(".cglib")) {
/* 240 */         return (className.startsWith("net.sf.cglib") || className
/*     */           
/* 242 */           .startsWith("org.hibernate.repackage.cglib") || className
/*     */           
/* 244 */           .startsWith("org.springframework.cglib"));
/*     */       }
/*     */     } 
/* 247 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _isGroovyMetaClassGetter(AnnotatedMethod am) {
/* 252 */     return am.getRawType().getName().startsWith("groovy.lang");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface BaseNameValidator
/*     */   {
/*     */     boolean accept(char param1Char, String param1String, int param1Int);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Provider
/*     */     extends AccessorNamingStrategy.Provider
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _setterPrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _withPrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _getterPrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _isGetterPrefix;
/*     */ 
/*     */     
/*     */     protected final DefaultAccessorNamingStrategy.BaseNameValidator _baseNameValidator;
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider() {
/* 294 */       this("set", "with", "get", "is", (DefaultAccessorNamingStrategy.BaseNameValidator)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Provider(Provider p, String setterPrefix, String withPrefix, String getterPrefix, String isGetterPrefix) {
/* 302 */       this(setterPrefix, withPrefix, getterPrefix, isGetterPrefix, p._baseNameValidator);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected Provider(Provider p, DefaultAccessorNamingStrategy.BaseNameValidator vld) {
/* 308 */       this(p._setterPrefix, p._withPrefix, p._getterPrefix, p._isGetterPrefix, vld);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Provider(String setterPrefix, String withPrefix, String getterPrefix, String isGetterPrefix, DefaultAccessorNamingStrategy.BaseNameValidator vld) {
/* 316 */       this._setterPrefix = setterPrefix;
/* 317 */       this._withPrefix = withPrefix;
/* 318 */       this._getterPrefix = getterPrefix;
/* 319 */       this._isGetterPrefix = isGetterPrefix;
/* 320 */       this._baseNameValidator = vld;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withSetterPrefix(String prefix) {
/* 335 */       return new Provider(this, prefix, this._withPrefix, this._getterPrefix, this._isGetterPrefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withBuilderPrefix(String prefix) {
/* 351 */       return new Provider(this, this._setterPrefix, prefix, this._getterPrefix, this._isGetterPrefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withGetterPrefix(String prefix) {
/* 367 */       return new Provider(this, this._setterPrefix, this._withPrefix, prefix, this._isGetterPrefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withIsGetterPrefix(String prefix) {
/* 383 */       return new Provider(this, this._setterPrefix, this._withPrefix, this._getterPrefix, prefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withFirstCharAcceptance(boolean allowLowerCaseFirstChar, boolean allowNonLetterFirstChar) {
/* 415 */       return withBaseNameValidator(
/* 416 */           DefaultAccessorNamingStrategy.FirstCharBasedValidator.forFirstNameRule(allowLowerCaseFirstChar, allowNonLetterFirstChar));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withBaseNameValidator(DefaultAccessorNamingStrategy.BaseNameValidator vld) {
/* 430 */       return new Provider(this, vld);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public AccessorNamingStrategy forPOJO(MapperConfig<?> config, AnnotatedClass targetClass) {
/* 436 */       return new DefaultAccessorNamingStrategy(config, targetClass, this._setterPrefix, this._getterPrefix, this._isGetterPrefix, this._baseNameValidator);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AccessorNamingStrategy forBuilder(MapperConfig<?> config, AnnotatedClass builderClass, BeanDescription valueTypeDesc) {
/* 445 */       AnnotationIntrospector ai = config.isAnnotationProcessingEnabled() ? config.getAnnotationIntrospector() : null;
/* 446 */       JsonPOJOBuilder.Value builderConfig = (ai == null) ? null : ai.findPOJOBuilderConfig(builderClass);
/* 447 */       String mutatorPrefix = (builderConfig == null) ? this._withPrefix : builderConfig.withPrefix;
/* 448 */       return new DefaultAccessorNamingStrategy(config, builderClass, mutatorPrefix, this._getterPrefix, this._isGetterPrefix, this._baseNameValidator);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AccessorNamingStrategy forRecord(MapperConfig<?> config, AnnotatedClass recordClass) {
/* 456 */       return new DefaultAccessorNamingStrategy.RecordNaming(config, recordClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FirstCharBasedValidator
/*     */     implements BaseNameValidator
/*     */   {
/*     */     private final boolean _allowLowerCaseFirstChar;
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean _allowNonLetterFirstChar;
/*     */ 
/*     */ 
/*     */     
/*     */     protected FirstCharBasedValidator(boolean allowLowerCaseFirstChar, boolean allowNonLetterFirstChar) {
/* 475 */       this._allowLowerCaseFirstChar = allowLowerCaseFirstChar;
/* 476 */       this._allowNonLetterFirstChar = allowNonLetterFirstChar;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static DefaultAccessorNamingStrategy.BaseNameValidator forFirstNameRule(boolean allowLowerCaseFirstChar, boolean allowNonLetterFirstChar) {
/* 495 */       if (!allowLowerCaseFirstChar && !allowNonLetterFirstChar) {
/* 496 */         return null;
/*     */       }
/* 498 */       return new FirstCharBasedValidator(allowLowerCaseFirstChar, allowNonLetterFirstChar);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean accept(char firstChar, String basename, int offset) {
/* 506 */       if (Character.isLetter(firstChar)) {
/* 507 */         return (this._allowLowerCaseFirstChar || !Character.isLowerCase(firstChar));
/*     */       }
/*     */       
/* 510 */       return this._allowNonLetterFirstChar;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class RecordNaming
/*     */     extends DefaultAccessorNamingStrategy
/*     */   {
/*     */     protected final Set<String> _fieldNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordNaming(MapperConfig<?> config, AnnotatedClass forClass) {
/* 532 */       super(config, forClass, null, "get", "is", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 538 */       String[] recordFieldNames = JDK14Util.getRecordFieldNames(forClass.getRawType());
/*     */       
/* 540 */       this
/*     */         
/* 542 */         ._fieldNames = (recordFieldNames == null) ? Collections.<String>emptySet() : new HashSet<>(Arrays.asList(recordFieldNames));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String findNameForRegularGetter(AnnotatedMethod am, String name) {
/* 551 */       if (this._fieldNames.contains(name)) {
/* 552 */         return name;
/*     */       }
/*     */       
/* 555 */       return super.findNameForRegularGetter(am, name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\introspect\DefaultAccessorNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */